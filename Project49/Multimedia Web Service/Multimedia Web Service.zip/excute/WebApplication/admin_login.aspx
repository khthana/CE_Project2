<%@ Page language="c#" Codebehind="admin_login.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.member" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>member</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<table style="Z-INDEX: 101; LEFT: 80px; WIDTH: 128px; POSITION: absolute; TOP: 88px; HEIGHT: 32px">
				<TR>
					<TD>��������´�ͧ��Ҫԡ
						<asp:datagrid id="dg" runat="server" Width="136px" Height="112px" AutoGenerateColumns="False">
							<Columns>
								<asp:EditCommandColumn ButtonType="LinkButton" UpdateText="Update" CancelText="Cancel" EditText="Edit"></asp:EditCommandColumn>
								<asp:ButtonColumn Text="Delete" CommandName="Delete"></asp:ButtonColumn>
								<asp:BoundColumn DataField="Title" HeaderText="Title"></asp:BoundColumn>
								<asp:BoundColumn DataField="Decription" HeaderText="Decription"></asp:BoundColumn>
								<asp:BoundColumn DataField="Category" HeaderText="Category"></asp:BoundColumn>
								<asp:BoundColumn DataField="UploadBy" ReadOnly="True" HeaderText="UploadBy"></asp:BoundColumn>
								<asp:BoundColumn DataField="FileName"></asp:BoundColumn>
							</Columns>
						</asp:datagrid></TD>
				</TR>
			</table>
			<asp:LinkButton id="LinkButton1" style="Z-INDEX: 102; LEFT: 80px; POSITION: absolute; TOP: 32px"
				runat="server" Width="72px" Height="24px">Detail File</asp:LinkButton>
			<asp:LinkButton id="LinkButton2" style="Z-INDEX: 103; LEFT: 168px; POSITION: absolute; TOP: 32px"
				runat="server" Width="192px" Height="8px">Create admin and  Delete user</asp:LinkButton>
			<asp:LinkButton id="LinkButton3" style="Z-INDEX: 104; LEFT: 376px; POSITION: absolute; TOP: 32px"
				runat="server" Width="104px" Height="16px">Insert File</asp:LinkButton>
			<asp:Label id="Label1" style="Z-INDEX: 105; LEFT: 88px; POSITION: absolute; TOP: 288px" runat="server"
				Width="488px" Height="56px">Label</asp:Label>
		</form>
	</body>
</HTML>
