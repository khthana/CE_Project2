<%@ Page language="c#" Codebehind="deleteFile.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.deleteFile" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Delete file</title>
		<script language="javascript">
		function confirm_delete()
		{ if (confirm("Are you sure you want to delete the custom search?")==true)��� 
			return true;
			else 
			return false;
		}
		function test(a)
		{ if (confirm("Are you sure you want to delete the custom search?")==true)��� 
			return a;
			else 
			return false;
		}
		</script>
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<TABLE height="23" cellSpacing="0" cellPadding="0" width="52" border="0" ms_2d_layout="TRUE">
			<TR vAlign="top">
				<TD width="52" height="23">
					<form id="Form1" method="post" runat="server">
						<TABLE height="35" cellSpacing="0" cellPadding="0" width="11" border="0" ms_2d_layout="TRUE">
							<TR vAlign="top">
								<TD width="10" height="15"></TD>
								<TD width="1"></TD>
							</TR>
							<TR vAlign="top">
								<TD height="20"></TD>
								<TD>
									<FONT face="Tahoma"></FONT>
								</TD>
							</TR>
						</TABLE>
					</form>
				</TD>
			</TR>
		</TABLE>
	</body>
</HTML>
