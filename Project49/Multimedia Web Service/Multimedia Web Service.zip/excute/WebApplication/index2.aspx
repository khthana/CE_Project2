<%@ Page language="c#" Codebehind="index2.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.index2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:label id="lblFrom1" style="Z-INDEX: 106; LEFT: 216px; POSITION: absolute; TOP: 296px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="104px" Height="16px"></asp:label>
			<asp:label id="lblDecription2" style="Z-INDEX: 151; LEFT: 216px; POSITION: absolute; TOP: 384px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19"></asp:label><asp:label id="lblTitle2" style="Z-INDEX: 149; LEFT: 216px; POSITION: absolute; TOP: 352px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="22px"></asp:label><asp:label id="lblDecription1" style="Z-INDEX: 150; LEFT: 216px; POSITION: absolute; TOP: 264px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="330px" Height="16px"></asp:label><asp:label id="lblTitle1" style="Z-INDEX: 148; LEFT: 216px; POSITION: absolute; TOP: 232px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241" Height="16px"></asp:label>
			<table style="Z-INDEX: 101; LEFT: 728px; WIDTH: 233px; POSITION: absolute; TOP: 248px; HEIGHT: 96px"
				width="233" border="0">
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 29px"><SPAN class="tab"></SPAN><SPAN class="tab"><FONT face="Tahoma"><asp:label id="Label4" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="9" Width="80px"
									Height="7px" Font-Bold="True">User Name :</asp:label></FONT></SPAN></TD>
					<TD style="HEIGHT: 29px"><asp:textbox id="tb_name" runat="server" Width="152px" Height="24px"></asp:textbox></TD>
				</TR>
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 30px"><asp:label id="Label5" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="9" Width="56px"
							Height="16px" Font-Bold="True">Password :</asp:label></TD>
					<TD style="HEIGHT: 30px"><asp:textbox id="tb_password" runat="server" Width="152px" Height="24px" TextMode="Password"></asp:textbox></TD>
				</TR>
				<TR>
					<TD align="center" colSpan="2"><asp:button id="bt_login" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="9" Width="88px"
							Text="Login"></asp:button>&nbsp;
						<asp:button id="btSignUp" runat="server" Width="91px" Height="24px" Text="Sign Up"></asp:button></TD>
				</TR>
			</table>
			<asp:hyperlink id="HyperLink3" style="Z-INDEX: 102; LEFT: 704px; POSITION: absolute; TOP: 40px"
				runat="server" Width="62px" Height="16px" NavigateUrl="insert.aspx">Insert File</asp:hyperlink><asp:hyperlink id="HyperLink1" style="Z-INDEX: 103; LEFT: 504px; POSITION: absolute; TOP: 40px"
				runat="server" Width="56px" Height="16px" EnableViewState="False" Visible="False">Sign Up</asp:hyperlink><asp:hyperlink id="HyperLink2" style="Z-INDEX: 104; LEFT: 648px; POSITION: absolute; TOP: 40px"
				runat="server" Width="54px" Height="16px" NavigateUrl="myfile.aspx">My File</asp:hyperlink><asp:image id="Image1" style="Z-INDEX: 105; LEFT: 104px; POSITION: absolute; TOP: 224px" runat="server"
				Width="98px" Height="96px"></asp:image><asp:label id="lblFrom2" style="Z-INDEX: 107; LEFT: 216px; POSITION: absolute; TOP: 416px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113" Height="19"></asp:label><asp:image id="Image2" style="Z-INDEX: 108; LEFT: 104px; POSITION: absolute; TOP: 344px" runat="server"
				Width="98px" Height="96px"></asp:image><asp:label id="lblFrom3" style="Z-INDEX: 109; LEFT: 216px; POSITION: absolute; TOP: 536px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image3" style="Z-INDEX: 110; LEFT: 104px; POSITION: absolute; TOP: 464px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 111; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 576px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom4" style="Z-INDEX: 112; LEFT: 216px; POSITION: absolute; TOP: 656px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image4" style="Z-INDEX: 113; LEFT: 104px; POSITION: absolute; TOP: 584px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 114; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 216px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<HR style="Z-INDEX: 115; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 336px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<HR style="Z-INDEX: 116; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 456px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="Label16" style="Z-INDEX: 117; LEFT: 656px; POSITION: absolute; TOP: 96px" runat="server"
				Width="96px" Height="16px">Member Login</asp:label><asp:imagebutton id="ImageButton1" style="Z-INDEX: 118; LEFT: 112px; POSITION: absolute; TOP: 168px"
				runat="server" Width="128px" Height="32px"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 119; LEFT: 248px; POSITION: absolute; TOP: 168px"
				runat="server" Width="120px" Height="32px"></asp:imagebutton><asp:label id="lblLogin" style="Z-INDEX: 120; LEFT: 424px; POSITION: absolute; TOP: 40px" runat="server"
				Width="134px" Height="16px"></asp:label><asp:hyperlink id="hylLogout" style="Z-INDEX: 121; LEFT: 776px; POSITION: absolute; TOP: 40px"
				runat="server" Width="54px" Height="16px" NavigateUrl="logout.aspx">Log out</asp:hyperlink>
			<HR style="Z-INDEX: 122; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 600px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom5" style="Z-INDEX: 123; LEFT: 216px; POSITION: absolute; TOP: 672px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image5" style="Z-INDEX: 124; LEFT: 104px; POSITION: absolute; TOP: 608px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 125; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 720px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom6" style="Z-INDEX: 126; LEFT: 216px; POSITION: absolute; TOP: 800px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image6" style="Z-INDEX: 127; LEFT: 104px; POSITION: absolute; TOP: 728px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 128; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 840px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom7" style="Z-INDEX: 129; LEFT: 216px; POSITION: absolute; TOP: 920px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image7" style="Z-INDEX: 130; LEFT: 104px; POSITION: absolute; TOP: 848px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 131; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 960px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom8" style="Z-INDEX: 132; LEFT: 216px; POSITION: absolute; TOP: 1040px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image8" style="Z-INDEX: 133; LEFT: 104px; POSITION: absolute; TOP: 968px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 134; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 1080px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblViews9" style="Z-INDEX: 135; LEFT: 328px; POSITION: absolute; TOP: 1160px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore9" style="Z-INDEX: 136; LEFT: 432px; POSITION: absolute; TOP: 1160px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblFrom9" style="Z-INDEX: 137; LEFT: 216px; POSITION: absolute; TOP: 1160px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image9" style="Z-INDEX: 138; LEFT: 104px; POSITION: absolute; TOP: 1088px" runat="server"
				Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 139; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 1200px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom10" style="Z-INDEX: 140; LEFT: 216px; POSITION: absolute; TOP: 1280px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image10" style="Z-INDEX: 141; LEFT: 104px; POSITION: absolute; TOP: 1208px"
				runat="server" Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 142; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 1320px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom11" style="Z-INDEX: 143; LEFT: 216px; POSITION: absolute; TOP: 1400px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image11" style="Z-INDEX: 144; LEFT: 104px; POSITION: absolute; TOP: 1328px"
				runat="server" Width="98px" Height="96px"></asp:image>
			<HR style="Z-INDEX: 145; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 1440px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="lblFrom12" style="Z-INDEX: 146; LEFT: 216px; POSITION: absolute; TOP: 1520px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="113px" Height="19px"></asp:label><asp:image id="Image12" style="Z-INDEX: 147; LEFT: 104px; POSITION: absolute; TOP: 1448px"
				runat="server" Width="98px" Height="96px"></asp:image><asp:label id="lblTitle3" style="Z-INDEX: 152; LEFT: 216px; POSITION: absolute; TOP: 472px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription3" style="Z-INDEX: 153; LEFT: 216px; POSITION: absolute; TOP: 504px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle4" style="Z-INDEX: 154; LEFT: 216px; POSITION: absolute; TOP: 592px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription4" style="Z-INDEX: 155; LEFT: 216px; POSITION: absolute; TOP: 624px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle5" style="Z-INDEX: 156; LEFT: 216px; POSITION: absolute; TOP: 616px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="6px"></asp:label><asp:label id="lblDecription5" style="Z-INDEX: 157; LEFT: 216px; POSITION: absolute; TOP: 648px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle6" style="Z-INDEX: 158; LEFT: 216px; POSITION: absolute; TOP: 736px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="24px"></asp:label><asp:label id="lblDecription6" style="Z-INDEX: 159; LEFT: 216px; POSITION: absolute; TOP: 768px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle7" style="Z-INDEX: 160; LEFT: 216px; POSITION: absolute; TOP: 856px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription7" style="Z-INDEX: 161; LEFT: 216px; POSITION: absolute; TOP: 888px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle8" style="Z-INDEX: 162; LEFT: 216px; POSITION: absolute; TOP: 976px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription8" style="Z-INDEX: 163; LEFT: 216px; POSITION: absolute; TOP: 1008px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle9" style="Z-INDEX: 164; LEFT: 216px; POSITION: absolute; TOP: 1096px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription9" style="Z-INDEX: 165; LEFT: 216px; POSITION: absolute; TOP: 1128px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="418px" Height="20px"></asp:label><asp:label id="lblTitle10" style="Z-INDEX: 166; LEFT: 216px; POSITION: absolute; TOP: 1216px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="12px"></asp:label><asp:label id="lblDecription10" style="Z-INDEX: 167; LEFT: 216px; POSITION: absolute; TOP: 1248px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle11" style="Z-INDEX: 168; LEFT: 216px; POSITION: absolute; TOP: 1336px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription11" style="Z-INDEX: 169; LEFT: 216px; POSITION: absolute; TOP: 1368px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblTitle12" style="Z-INDEX: 170; LEFT: 216px; POSITION: absolute; TOP: 1456px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="241px" Height="16px"></asp:label><asp:label id="lblDecription12" style="Z-INDEX: 171; LEFT: 216px; POSITION: absolute; TOP: 1488px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="417px" Height="19px"></asp:label><asp:label id="lblViews1" style="Z-INDEX: 172; LEFT: 328px; POSITION: absolute; TOP: 296px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="88px" Height="22px"></asp:label><asp:label id="lblMore1" style="Z-INDEX: 173; LEFT: 432px; POSITION: absolute; TOP: 296px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="158px" Height="24px"></asp:label><asp:label id="lblViews2" style="Z-INDEX: 174; LEFT: 328px; POSITION: absolute; TOP: 416px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89" Height="22"></asp:label><asp:label id="lblMore2" style="Z-INDEX: 175; LEFT: 432px; POSITION: absolute; TOP: 416px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="202px" Height="20px"></asp:label><asp:label id="lblViews3" style="Z-INDEX: 176; LEFT: 328px; POSITION: absolute; TOP: 536px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore3" style="Z-INDEX: 177; LEFT: 432px; POSITION: absolute; TOP: 536px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="202px" Height="24px"></asp:label><asp:label id="lblViews4" style="Z-INDEX: 178; LEFT: 328px; POSITION: absolute; TOP: 656px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore4" style="Z-INDEX: 179; LEFT: 432px; POSITION: absolute; TOP: 656px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews5" style="Z-INDEX: 180; LEFT: 328px; POSITION: absolute; TOP: 672px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore5" style="Z-INDEX: 181; LEFT: 432px; POSITION: absolute; TOP: 672px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews6" style="Z-INDEX: 182; LEFT: 328px; POSITION: absolute; TOP: 800px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore6" style="Z-INDEX: 183; LEFT: 432px; POSITION: absolute; TOP: 800px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews7" style="Z-INDEX: 184; LEFT: 328px; POSITION: absolute; TOP: 912px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore7" style="Z-INDEX: 185; LEFT: 432px; POSITION: absolute; TOP: 912px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews8" style="Z-INDEX: 186; LEFT: 328px; POSITION: absolute; TOP: 1040px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore8" style="Z-INDEX: 187; LEFT: 432px; POSITION: absolute; TOP: 1040px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews10" style="Z-INDEX: 188; LEFT: 328px; POSITION: absolute; TOP: 1280px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore10" style="Z-INDEX: 189; LEFT: 432px; POSITION: absolute; TOP: 1280px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews11" style="Z-INDEX: 190; LEFT: 328px; POSITION: absolute; TOP: 1400px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore11" style="Z-INDEX: 191; LEFT: 432px; POSITION: absolute; TOP: 1400px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label><asp:label id="lblViews12" style="Z-INDEX: 192; LEFT: 328px; POSITION: absolute; TOP: 1520px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="89px" Height="22px"></asp:label><asp:label id="lblMore12" style="Z-INDEX: 193; LEFT: 432px; POSITION: absolute; TOP: 1520px"
				runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="201px" Height="19px"></asp:label>
			<asp:HyperLink id="HyperLink4" style="Z-INDEX: 194; LEFT: 560px; POSITION: absolute; TOP: 40px"
				runat="server" Height="8px" Width="78px" NavigateUrl="admin_login1.aspx" EnableViewState="False">Admin Login</asp:HyperLink></form>
	</body>
</HTML>
