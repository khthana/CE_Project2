<%@ Page language="c#" Codebehind="login.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.login" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Login</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
					height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
					<PARAM NAME="_cx" VALUE="20346">
					<PARAM NAME="_cy" VALUE="3519">
					<PARAM NAME="FlashVars" VALUE="">
					<PARAM NAME="Movie" VALUE="img/10media_3.swf">
					<PARAM NAME="Src" VALUE="img/10media_3.swf">
					<PARAM NAME="WMode" VALUE="Window">
					<PARAM NAME="Play" VALUE="0">
					<PARAM NAME="Loop" VALUE="-1">
					<PARAM NAME="Quality" VALUE="High">
					<PARAM NAME="SAlign" VALUE="">
					<PARAM NAME="Menu" VALUE="-1">
					<PARAM NAME="Base" VALUE="">
					<PARAM NAME="AllowScriptAccess" VALUE="always">
					<PARAM NAME="Scale" VALUE="ShowAll">
					<PARAM NAME="DeviceFont" VALUE="0">
					<PARAM NAME="EmbedMovie" VALUE="0">
					<PARAM NAME="BGColor" VALUE="">
					<PARAM NAME="SWRemote" VALUE="">
					<PARAM NAME="MovieData" VALUE="">
					<PARAM NAME="SeamlessTabbing" VALUE="1">
					<PARAM NAME="Profile" VALUE="0">
					<PARAM NAME="ProfileAddress" VALUE="">
					<PARAM NAME="ProfilePort" VALUE="0">
					<PARAM NAME="AllowNetworking" VALUE="all">
					<PARAM NAME="AllowFullScreen" VALUE="false">
					<embed src="img/10media_3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
						type="application/x-shockwave-flash" width="769" height="133"> </embed>
				</OBJECT>
				<asp:Label id="Label1" style="Z-INDEX: 200; LEFT: 456px; POSITION: absolute; TOP: 224px" runat="server"
					Height="16px" Width="104px" Font-Bold="True" Font-Names="Microsoft Sans Serif" Font-Size="X-Small">Member Login</asp:Label>
			</FONT>
			<TABLE id="Table1" style="Z-INDEX: 199; LEFT: 376px; WIDTH: 233px; POSITION: absolute; TOP: 256px; HEIGHT: 96px"
				width="233" border="1" borderColor="#000000" bgColor="#87ceeb">
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 29px"><SPAN class="tab"></SPAN><SPAN class="tab"><FONT face="Tahoma">
								<asp:label id="Label4" runat="server" Height="7px" Width="80px" Font-Bold="True" Font-Names="Microsoft Sans Serif"
									Font-Size="9">User Name :</asp:label></FONT></SPAN></TD>
					<TD style="HEIGHT: 29px">
						<asp:textbox id="tb_name" runat="server" Height="24px" Width="152px"></asp:textbox></TD>
				</TR>
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 30px">
						<asp:label id="Label5" runat="server" Height="16px" Width="56px" Font-Bold="True" Font-Names="Microsoft Sans Serif"
							Font-Size="9">Password :</asp:label></TD>
					<TD style="HEIGHT: 30px">
						<asp:textbox id="tb_password" runat="server" Height="24px" Width="152px" TextMode="Password"></asp:textbox></TD>
				</TR>
				<TR>
					<TD align="center" colSpan="2">
						<asp:button id="bt_login" runat="server" Width="88px" Font-Names="Microsoft Sans Serif" Font-Size="9"
							Text="Login"></asp:button>&nbsp;</TD>
				</TR>
			</TABLE>
			<HR style="Z-INDEX: 196; LEFT: 104px; WIDTH: 74.06%; POSITION: absolute; TOP: 200px; HEIGHT: 2px"
				width="74.06%" SIZE="2">
			<asp:imagebutton id="ImageButton1" style="Z-INDEX: 197; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="128px"></asp:imagebutton>
			<asp:imagebutton id="ImageButton2" style="Z-INDEX: 198; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="112px"></asp:imagebutton>
		</form>
	</body>
</HTML>
