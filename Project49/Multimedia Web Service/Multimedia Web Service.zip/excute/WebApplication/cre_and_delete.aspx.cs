using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Windows.Forms;
using System.Windows.Forms.ComponentModel;
using System.ComponentModel.Design;




using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for cre_and_delete.
	/// </summary>
	public class cre_and_delete : System.Web.UI.Page 
	{
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Label lblLogin1;
		protected System.Web.UI.WebControls.HyperLink HyperLink4;
		protected System.Web.UI.WebControls.HyperLink HyperLink5;
		protected System.Web.UI.WebControls.DataGrid dg;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			lblLogin1.Text = "Welcome :" + Session["user"].ToString();
			//lblLogin1.Enabled = true;
			if(!IsPostBack)
			{

				this.LoadData();
				
				
			}
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dg.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_CancelCommand);
			this.dg.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_EditCommand);
			this.dg.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_UpdateCommand);
			this.dg.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_DeleteCommand);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("admin_login2.aspx",true);
		}

		
		private void LoadData()
		{
			//System.Web.UI.WebControls.DataGrid
			Session["status"] = "admin";
			
			DataSet dataSet = new DataSet();
			string xmlData;


			DataTable dataTable = new DataTable("row"); // row ��͵���觢����Ţͧ���Ъش
			
			dataTable.Columns.Add("UserName", typeof(string));
			dataTable.Columns.Add("Status", typeof(string));

			
			

			
			//DataTable tblStatus = dataTable.Columns["Status"];
			
			//TblStyle.GridColumnStyles.Add(new DataGridComboBoxColumn(ref tblStatus, 0, 0, true, false, false));
			// Datagrid ComboBox DisplayMember field has order number 0. Name of this column is "State"
			// Datagrid ComboBox ValueMember field has order number 0. It is the same column like for DisplayMember
			
			
			
			
			dataSet.Tables.Add(dataTable);

			


			//string xmlData = "<XmlDS><table1><col1>Value1</col1></table1><table1><col1>Value2</col1></table1></XmlDS>";

			/*string xmlData = "<root>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<UserName>Title1</UserName>";
			
			xmlData = xmlData + "<Status>Decription1</Status>";
			
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<UserName>Title1</UserName>";
			xmlData = xmlData + "<Status>Decription1</Status>";
				
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "</root>";*/

			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			xmlData = ws.showuser();
			//Label1.Text = xmlData;



			System.IO.StringReader xmlSR = new System.IO.StringReader(xmlData);

			dataSet.ReadXml(xmlSR, XmlReadMode.IgnoreSchema);

			
			dg.DataSource = dataSet;
			dg.DataBind();

			
		}
		private void dg_DeleteCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string UserName = e.Item.Cells[2].Text;
			string status = e.Item.Cells[3].Text;
			string result;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
			
			//if(status=="User")
			//{
				result = ws.deleteuser(UserName,status);

				if(result=="success")
				{
					this.LoadData();
				}
			//}

			
			
			

		

		}
		private void dg_EditCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string result;
			string userName = e.Item.Cells[2].Text;
			string status = e.Item.Cells[3].Text;

			if(status=="User")
			{
			
				WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			
				try
				{
					result = ws.updateUser(userName);

					if(result=="success")
					{

						this.LoadData();
					}
				}
				catch (Exception ex)
				{
					//Label1.Text = ex.ToString();
				}
			}

			

		}
		private void dg_CancelCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			dg.EditItemIndex = -1;
			this.LoadData();
		

		}
		private void dg_UpdateCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try
			{
				
				
				
				//TextBox txtCreateStatus = (TextBox)e.Item.Cells[3].Controls[0];

				string userName = e.Item.Cells[2].Text;
			
			

				//string newCreateStatus = txtCreateStatus.Text;
				

				string oldCreateStatus = (string)Session["CreateStatus"];
				
			
				WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
				string result;

				/*if (newCreateStatus =="admin")
				{


					
					result = ws.createStatus(userName,newCreateStatus);
					Label1.Text = result;

			

					dg.EditItemIndex = -1;
				
					this.LoadData();
				}*/


			}
			catch (Exception ex)
			{
				//Label1.Text = ex.ToString();
			}
			
		}

		private void LinkButton2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("cre_and_delete.aspx",true);
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
	}
}
