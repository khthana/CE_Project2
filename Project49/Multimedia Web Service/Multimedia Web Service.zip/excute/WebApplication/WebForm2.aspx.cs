using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for WebForm2.
	/// </summary>
	public class WebForm2 : System.Web.UI.Page
	{


		public string ChangeString(string url)
		{
			if (url == "Arts&Animation")     
			{
				url = "Arts%26Animation";
			}
			else if(url=="Autos&Vehicles")
			{
				url = "Autos%26Vehicles";
			}
			else if(url=="News&Bloge")
			{
				url = "News%26Bloge";
			}
			else if(url=="Pets&Animals")
			{
				url = "Pets%26Animals";
			}
			else if(url=="Science&Technology")
			{
				url = "Science%26Technology";
			}
			else if(url=="Travel&Places")
			{
				url = "Travel%26Places";
			}
			return url;
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			int indexDeta = 0;


			string[] deta =null;

			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			deta = ws.firstPage();
			foreach (string data in deta)
			{
				//data.
			}

		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
