<%@ Page language="c#" Codebehind="result_1.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.result_1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>result_1</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:Label id="lblresult" style="Z-INDEX: 102; LEFT: 104px; POSITION: absolute; TOP: 248px"
				runat="server" Width="312px" Height="16px" Font-Names="Microsoft Sans Serif" Font-Size="X-Small"></asp:Label>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/10media_3.swf">
				<PARAM NAME="Src" VALUE="img/10media_3.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/10media_3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<asp:Button id="btBack" style="Z-INDEX: 101; LEFT: 160px; POSITION: absolute; TOP: 296px" runat="server"
				Width="176px" Height="24px" Text="��Ѻ��ѧ˹��"></asp:Button>
			<HR style="Z-INDEX: 103; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 208px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<TABLE id="Table1" style="Z-INDEX: 106; LEFT: 552px; POSITION: absolute; TOP: 72px">
				<TR>
					<TD>
						<asp:TextBox id="txtSearch" runat="server" Width="192px"></asp:TextBox></TD>
					<TD>&nbsp;
						<asp:Button id="btSearch" runat="server" Height="24px" Width="56px" Text="Search"></asp:Button></TD>
				</TR>
			</TABLE>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 107; LEFT: 696px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="66px" NavigateUrl="insert.aspx">Insert File</asp:HyperLink>
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 108; LEFT: 552px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="60px" NavigateUrl="sign_up.aspx">Sign Up</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 109; LEFT: 624px; POSITION: absolute; TOP: 40px"
				runat="server" Height="8px" Width="60px" NavigateUrl="myfile.aspx">My File</asp:HyperLink>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 110; LEFT: 104px; POSITION: absolute; TOP: 160px"
				runat="server" Height="32px" Width="128px" ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\tab_videos_118x28.gif"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 111; LEFT: 240px; POSITION: absolute; TOP: 160px"
				runat="server" Height="32px" Width="112px" ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\tab_categories_118x28.gif"></asp:ImageButton>
			<asp:Label id="lblresult2" style="Z-INDEX: 112; LEFT: 184px; POSITION: absolute; TOP: 264px"
				runat="server" Height="8px" Width="128px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:Label>
		</form>
	</body>
</HTML>
