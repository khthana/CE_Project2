<%@ Page language="c#" Codebehind="admin_login2.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.admin_login" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Admin Login</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<table style="Z-INDEX: 101; LEFT: 104px; WIDTH: 344px; POSITION: absolute; TOP: 248px; HEIGHT: 163px"
				borderColor="black" border="1">
				<TR>
					<TD align="center"><FONT face="Microsoft Sans Serif" size="2"><b>��������´�ͧ��Ҫԡ</b></FONT>
						<asp:datagrid id="dg" runat="server" Width="718px" Height="120px" AutoGenerateColumns="False"
							Font-Size="X-Small" Font-Names="Microsoft Sans Serif" HorizontalAlign="Center">
							<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
							<HeaderStyle Font-Names="Microsoft Sans Serif" Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle"></HeaderStyle>
							<Columns>
								<asp:EditCommandColumn ButtonType="LinkButton" UpdateText="Update" CancelText="Cancel" EditText="Edit">
									<HeaderStyle Width="1.5cm"></HeaderStyle>
								</asp:EditCommandColumn>
								<asp:ButtonColumn Text="Delete" CommandName="Delete">
									<HeaderStyle Width="1.5cm"></HeaderStyle>
								</asp:ButtonColumn>
								<asp:BoundColumn DataField="Title" HeaderText="Title">
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn DataField="Decription" HeaderText="Decription">
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn DataField="Category" HeaderText="Category">
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn DataField="UploadBy" ReadOnly="True" HeaderText="UploadBy">
									<HeaderStyle Width="2cm"></HeaderStyle>
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn Visible="False" DataField="FileName"></asp:BoundColumn>
							</Columns>
						</asp:datagrid></TD>
				</TR>
			</table>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/adminlogin.swf">
				<PARAM NAME="Src" VALUE="img/adminlogin.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/adminlogin.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<asp:hyperlink id="HyperLink5" style="Z-INDEX: 111; LEFT: 104px; POSITION: absolute; TOP: 216px"
				runat="server" Width="64px" Height="8px" NavigateUrl="admin_login2.aspx">Detail File</asp:hyperlink><asp:hyperlink id="HyperLink6" style="Z-INDEX: 110; LEFT: 176px; POSITION: absolute; TOP: 216px"
				runat="server" Width="184px" Height="16px" NavigateUrl="cre_and_delete.aspx">Create admin and  Delete user</asp:hyperlink><asp:label id="lblLogin" style="Z-INDEX: 109; LEFT: 368px; POSITION: absolute; TOP: 160px"
				runat="server" Width="113px" Height="16px" Font-Bold="True"></asp:label><asp:hyperlink id="hylLogout" style="Z-INDEX: 108; LEFT: 784px; POSITION: absolute; TOP: 40px"
				runat="server" Width="54px" Height="16px" NavigateUrl="logout.aspx">Log out</asp:hyperlink>
			<HR style="Z-INDEX: 102; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 192px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<TABLE id="Table1" style="Z-INDEX: 103; LEFT: 576px; POSITION: absolute; TOP: 72px">
				<TR>
					<TD><asp:textbox id="txtSearch" runat="server" Width="192px"></asp:textbox></TD>
					<TD>&nbsp;
						<asp:button id="btSearch" runat="server" Width="56px" Height="24px" Text="Search"></asp:button></TD>
				</TR>
			</TABLE>
			<asp:hyperlink id="HyperLink3" style="Z-INDEX: 104; LEFT: 712px; POSITION: absolute; TOP: 40px"
				runat="server" Width="62px" Height="16px" NavigateUrl="insert.aspx">Insert File</asp:hyperlink><asp:hyperlink id="HyperLink2" style="Z-INDEX: 105; LEFT: 656px; POSITION: absolute; TOP: 40px"
				runat="server" Width="52px" Height="16px" NavigateUrl="admin_login2.aspx">My File</asp:hyperlink><asp:imagebutton id="ImageButton1" style="Z-INDEX: 106; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Width="128px" Height="32px"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 107; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Width="112px" Height="32px"></asp:imagebutton></form>
	</body>
</HTML>
