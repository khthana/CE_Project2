<%@ Page language="c#" Codebehind="insert2.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.insert2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>insert</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<table style="Z-INDEX: 101; LEFT: 104px; WIDTH: 448px; POSITION: absolute; TOP: 248px; HEIGHT: 351px"
				bgColor="#ccffff">
				<TR>
					<TD align="right" style="HEIGHT: 9px"><FONT face="Microsoft Sans Serif" size="2"><b>File:</b></FONT>
					</TD>
					<TD style="HEIGHT: 9px"><FONT face="Tahoma"><INPUT id="FileToUpload" title="Select File To Upload!" style="FONT-SIZE: 9pt; WIDTH: 304px; FONT-FAMILY: Arial; HEIGHT: 24px"
								type="file" maxLength="1000000000" size="31" name="FileToUpload" runat="server"></FONT></TD>
				</TR>
				<TR>
					<TD align="right" style="HEIGHT: 3px"><FONT face="Microsoft Sans Serif" size="2"><b>Title:</b></FONT>
					</TD>
					<TD style="HEIGHT: 3px">
						<asp:TextBox id="tb_title" runat="server" Width="240px" Height="24px"></asp:TextBox></TD>
				</TR>
				<TR>
					<TD align="right" style="HEIGHT: 111px" valign="top"><FONT face="Microsoft Sans Serif" size="2"><b>Decription:</b></FONT>
					</TD>
					<TD style="HEIGHT: 111px">
						<asp:TextBox id="tb_decription" runat="server" Width="240px" Height="106px" TextMode="MultiLine"></asp:TextBox></TD>
				</TR>
				<TR>
					<TD align="right" style="HEIGHT: 143px" valign="top"><FONT face="Microsoft Sans Serif" size="2"><b>Vedeo 
								Category:</b></FONT>
					</TD>
					<TD style="HEIGHT: 143px">
						<asp:RadioButtonList id="Category" runat="server" Width="288px" Height="130px" RepeatDirection="Horizontal"
							RepeatColumns="2" Font-Names="Microsoft Sans Serif" Font-Size="X-Small">
							<asp:ListItem Value="Autos&amp;Vehicles" Selected="True">Autos &amp; Vehicles</asp:ListItem>
							<asp:ListItem Value="Comedy">Comedy</asp:ListItem>
							<asp:ListItem Value="Music">Music</asp:ListItem>
							<asp:ListItem Value="People">People</asp:ListItem>
							<asp:ListItem Value="Sports">Sport</asp:ListItem>
							<asp:ListItem Value="News&amp;Bloge">News &amp; Bloge</asp:ListItem>
							<asp:ListItem Value="Entertainment">Entertainment</asp:ListItem>
							<asp:ListItem Value="Arts&amp;Animation">Arts &amp; Animation</asp:ListItem>
							<asp:ListItem Value="Science&amp;Technology">Science &amp; Technology</asp:ListItem>
							<asp:ListItem Value="Travel&amp;Places">Travel &amp; Places  </asp:ListItem>
							<asp:ListItem Value="Video Game">Video Game     </asp:ListItem>
							<asp:ListItem Value="Pets&amp;Animals  ">Pets &amp; Animals      </asp:ListItem>
						</asp:RadioButtonList></TD>
				</TR>
				<TR>
					<TD align="right"><FONT face="Microsoft Sans Serif" size="2"><b></b></FONT>
					</TD>
					<TD><FONT face="Tahoma">
							<asp:Button id="btnOk" runat="server" Width="80px" Height="32px" Text="OK"></asp:Button>&nbsp;&nbsp;&nbsp;
							<asp:Button id="Button1" runat="server" Width="144px" Height="32px" Text="��Ѻ��ѧ˹�Ҵ����"></asp:Button></FONT></TD>
				</TR>
			</table>
			<asp:Label id="lblLogin" style="Z-INDEX: 112; LEFT: 488px; POSITION: absolute; TOP: 40px" runat="server"
				Height="16px" Width="134px"></asp:Label>
			<asp:HyperLink id="hylLogout" style="Z-INDEX: 111; LEFT: 776px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="logout.aspx">Log out</asp:HyperLink>
			<TABLE id="Table1" style="Z-INDEX: 110; LEFT: 560px; POSITION: absolute; TOP: 72px">
				<TR>
					<TD>
						<asp:TextBox id="txtSearch" runat="server" Width="192px"></asp:TextBox></TD>
					<TD>&nbsp;
						<asp:Button id="btSearch" runat="server" Height="24px" Width="56px" Text="Search"></asp:Button></TD>
				</TR>
			</TABLE>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 102; LEFT: 704px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="62px" NavigateUrl="sign_up.aspx">Insert File</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 105; LEFT: 632px; POSITION: absolute; TOP: 40px"
				runat="server" Height="8px" Width="60px" NavigateUrl="myfile.aspx">My File</asp:HyperLink>
			<HR style="Z-INDEX: 106; LEFT: 104px; WIDTH: 58.7%; POSITION: absolute; TOP: 192px; HEIGHT: 2px"
				width="58.7%" SIZE="2">
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 107; LEFT: 104px; POSITION: absolute; TOP: 144px"
				runat="server" Height="32px" Width="128px"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 108; LEFT: 240px; POSITION: absolute; TOP: 144px"
				runat="server" Height="32px" Width="112px"></asp:ImageButton>
			<asp:Label id="Label2" style="Z-INDEX: 109; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				Height="16px" Width="72px">Insert File</asp:Label>
			<asp:Label id="lblresult" style="Z-INDEX: 113; LEFT: 584px; POSITION: absolute; TOP: 184px"
				runat="server" Height="24px" Width="216px"></asp:Label>
		</form>
	</body>
</HTML>
