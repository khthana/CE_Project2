using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for Categoriesofadmin.
	/// </summary>
	public class Categoriesofadmin : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblFrom1;
		protected System.Web.UI.WebControls.Label lblTitle2;
		protected System.Web.UI.WebControls.Label lblTitle1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox tb_name;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox tb_password;
		protected System.Web.UI.WebControls.Button bt_login;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Label lblFrom2;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Label lblFrom3;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Label lblFrom4;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Label Label16;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Label lblFrom5;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.Label lblFrom6;
		protected System.Web.UI.WebControls.Image Image6;
		protected System.Web.UI.WebControls.Label lblFrom7;
		protected System.Web.UI.WebControls.Image Image7;
		protected System.Web.UI.WebControls.Label lblFrom8;
		protected System.Web.UI.WebControls.Image Image8;
		protected System.Web.UI.WebControls.Label lblViews9;
		protected System.Web.UI.WebControls.Label lblFrom9;
		protected System.Web.UI.WebControls.Image Image9;
		protected System.Web.UI.WebControls.Label lblFrom10;
		protected System.Web.UI.WebControls.Image Image10;
		protected System.Web.UI.WebControls.Label lblFrom11;
		protected System.Web.UI.WebControls.Image Image11;
		protected System.Web.UI.WebControls.Label lblFrom12;
		protected System.Web.UI.WebControls.Image Image12;
		protected System.Web.UI.WebControls.Label lblTitle3;
		protected System.Web.UI.WebControls.Label lblTitle4;
		protected System.Web.UI.WebControls.Label lblTitle5;
		protected System.Web.UI.WebControls.Label lblTitle6;
		protected System.Web.UI.WebControls.Label lblTitle7;
		protected System.Web.UI.WebControls.Label lblTitle8;
		protected System.Web.UI.WebControls.Label lblTitle9;
		protected System.Web.UI.WebControls.Label lblTitle10;
		protected System.Web.UI.WebControls.Label lblTitle11;
		protected System.Web.UI.WebControls.Label lblTitle12;
		protected System.Web.UI.WebControls.Label lblViews1;
		protected System.Web.UI.WebControls.Label lblViews2;
		protected System.Web.UI.WebControls.Label lblViews3;
		protected System.Web.UI.WebControls.Label lblViews4;
		protected System.Web.UI.WebControls.Label lblViews5;
		protected System.Web.UI.WebControls.Label lblViews6;
		protected System.Web.UI.WebControls.Label lblViews7;
		protected System.Web.UI.WebControls.Label lblViews8;
		protected System.Web.UI.WebControls.Label lblViews10;
		protected System.Web.UI.WebControls.Label lblViews11;
		protected System.Web.UI.WebControls.Label lblViews12;
		protected System.Web.UI.WebControls.HyperLink HyperLink4;
		private string str1;
		

		public string ChangeString(string url)
		{
			if (url == "Arts&Animation")     
			{
				url = "Arts%26Animation";
				
				
			}
			else if(url=="Autos&Vehicles")
			{
				url = "Autos%26Vehicles";
			}
			else if(url=="News&Bloge")
			{
				url = "News%26Bloge";
			}
			else if(url=="Pets&Animals")
			{
				url = "Pets%26Animals";
			}
			else if(url=="Science&Technology")
			{
				url = "Science%26Technology";
			}
			else if(url=="Travel&Places")
			{
				url = "Travel%26Places";
			}
			else if(url=="Video")
			{
				url = "Video Game";
			}

			
			return url;
		}

		public string ChangeCategory(string url)
		{
			if (url == "Arts")     
			{
				url = "Arts&Animation";
				this.str1 ="http://161.246.5.86/WebApplication/img/2.jpg";
			}
			else if(url=="Autos")
			{
				url = "Autos&Vehicles";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(5).jpg";
			}
			else if(url=="News")
			{
				url = "News&Bloge";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(25).jpg";
			}
			else if(url=="Pets")
			{
				url = "Pets&Animals";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(36).jpg";
			}
			else if(url=="Science")
			{
				url = "Science&Technology";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(40).jpg";
			}
			else if(url=="Travel")
			{
				url = "Travel&Places";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(50).jpg";
			}
			else if(url=="Video")
			{
				url = "Video Game";
				this.str1 ="http://161.246.5.86/WebApplication/img/2(56).jpg";
			}
			else if(url=="Music")
			{
				this.str1 ="http://161.246.5.86/WebApplication/img/2(20).jpg";
			}
			else if(url=="Comedy")
			{
				this.str1 ="http://161.246.5.86/WebApplication/img/2(10).jpg";
			}
			else if(url=="Entertainment")
			{
				this.str1 ="http://161.246.5.86/WebApplication/img/2(15).jpg";
			}
			else if(url=="People")
			{
				this.str1 ="http://161.246.5.86/WebApplication/img/2(30).jpg";
			}
			else if(url=="Sports")
			{
				this.str1 ="http://161.246.5.86/WebApplication/img/2(42).jpg";
			}
			return url;
		}
	
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string category = Request.QueryString["categ"];
			category = ChangeCategory(category);
			int indexDeta = 0;
			int length=0;
			
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;
			


			string[] deta =null;

			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			deta = ws.category(category);
			length = (deta.Length) / 3;

			

			lblTitle1.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
			indexDeta++;
			lblViews1.Text = "Views : " + deta[indexDeta++];
			lblFrom1.Text = "From : " + deta[indexDeta++];
			Image1.Visible = true;
			Image1.ImageUrl = this.str1;

			length--;

			if(length > 0)
			{
				lblTitle2.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews2.Text = "Views : " + deta[indexDeta++];
				lblFrom2.Text = "From : " + deta[indexDeta++];
				Image2.Visible = true;
				Image2.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle3.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews3.Text = "Views : " + deta[indexDeta++];
				lblFrom3.Text = "From : " + deta[indexDeta++];
				Image3.Visible = true;
				Image3.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle4.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews4.Text = "Views : " + deta[indexDeta++];
				lblFrom4.Text = "From : " + deta[indexDeta++];
				Image4.Visible = true;
				Image4.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle5.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews5.Text = "Views : " + deta[indexDeta++];
				lblFrom5.Text = "From : " + deta[indexDeta++];
				Image5.Visible = true;
				Image5.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle6.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews6.Text = "Views : " + deta[indexDeta++];
				lblFrom6.Text = "From : " + deta[indexDeta++];
				Image6.Visible = true;
				Image6.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle7.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews7.Text = "Views : " + deta[indexDeta++];
				lblFrom7.Text = "From : " + deta[indexDeta++];
				Image7.Visible = true;
				Image7.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle8.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews8.Text = "Views : " + deta[indexDeta++];
				lblFrom8.Text = "From : " + deta[indexDeta++];
				Image8.Visible = true;
				Image8.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle9.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews9.Text = "Views : " + deta[indexDeta++];
				lblFrom9.Text = "From : " + deta[indexDeta++];
				Image9.Visible = true;
				Image9.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle10.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews10.Text = "Views : " + deta[indexDeta++];
				lblFrom10.Text = "From : " + deta[indexDeta++];
				Image10.Visible = true;
				Image10.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle11.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews11.Text = "Views : " + deta[indexDeta++];
				lblFrom11.Text = "From : " + deta[indexDeta++];
				Image11.Visible = true;
				Image11.ImageUrl = this.str1;
				length--;
			}

			if(length > 0)
			{
				lblTitle12.Text = "Title : <a href=Watch.aspx?Title=" + deta[indexDeta] +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(category)+ ">" + deta[indexDeta] + "</a>";
				indexDeta++;
				lblViews12.Text = "Views : " + deta[indexDeta++];
				lblFrom12.Text = "From : " + deta[indexDeta++];
				Image12.Visible = true;
				Image12.ImageUrl = this.str1;
				length--;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
