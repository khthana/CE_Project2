<%@ Page language="c#" Codebehind="sign_up.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.sign_up" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Sign Up</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<table style="Z-INDEX: 101; LEFT: 104px; WIDTH: 368px; POSITION: absolute; TOP: 296px; HEIGHT: 280px"
				bgColor="#dfd7d4">
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 23px" align="right"><FONT face="Microsoft Sans Serif" size="2"><b>Email 
								Address:</b></FONT>
					</TD>
					<td style="HEIGHT: 23px"><FONT face="Tahoma"><asp:textbox id="tbEmail" runat="server" Width="208px" Height="24px"></asp:textbox></FONT></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 8px" align="right"><FONT face="Microsoft Sans Serif" size="2"><b>User 
								Name:</b></FONT>
					</TD>
					<td style="HEIGHT: 8px"><FONT face="Tahoma"><asp:textbox id="tbUserName" runat="server" Width="160px" Height="24px"></asp:textbox></FONT></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 19px" align="right"><FONT face="Microsoft Sans Serif" size="2"><b>Password:</b></FONT>
					</TD>
					<td style="HEIGHT: 19px"><FONT face="Tahoma"><asp:textbox id="tbPassword" runat="server" Width="160px" Height="24px" TextMode="Password"></asp:textbox></FONT></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 20px" align="right"><FONT face="Microsoft Sans Serif" size="2"><b>Confirm 
								Password:</b></FONT>
					</TD>
					<td style="HEIGHT: 20px"><FONT face="Tahoma"><asp:textbox id="tbConfirm" runat="server" Width="160px" Height="24px" TextMode="Password"></asp:textbox></FONT></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 2px" align="right"><FONT face="Microsoft Sans Serif" size="2"><b>Country:</b></FONT>
					</TD>
					<td style="HEIGHT: 2px"><FONT face="Tahoma"><asp:dropdownlist id="CountryList" runat="server" Width="224px" Height="15px">
								<asp:ListItem Value="US" Selected="True">United States</asp:ListItem>
								<asp:ListItem value="AF">Afghanistan</asp:ListItem>
								<asp:ListItem value="AL">Albania</asp:ListItem>
								<asp:ListItem value="DZ">Algeria</asp:ListItem>
								<asp:ListItem value="AS">American Samoa</asp:ListItem>
								<asp:ListItem value="AD">Andorra</asp:ListItem>
								<asp:ListItem value="AO">Angola</asp:ListItem>
								<asp:ListItem value="AI">Anguilla</asp:ListItem>
								<asp:ListItem value="AG">Antigua and Barbuda</asp:ListItem>
								<asp:ListItem value="AR">Argentina</asp:ListItem>
								<asp:ListItem value="AM">Armenia</asp:ListItem>
								<asp:ListItem value="AW">Aruba</asp:ListItem>
								<asp:ListItem value="AU">Australia</asp:ListItem>
								<asp:ListItem value="AT">Austria</asp:ListItem>
								<asp:ListItem value="AZ">Azerbaijan</asp:ListItem>
								<asp:ListItem value="BS">Bahamas</asp:ListItem>
								<asp:ListItem value="BH">Bahrain</asp:ListItem>
								<asp:ListItem value="BD">Bangladesh</asp:ListItem>
								<asp:ListItem value="BB">Barbados</asp:ListItem>
								<asp:ListItem value="BY">Belarus</asp:ListItem>
								<asp:ListItem value="BE">Belgium</asp:ListItem>
								<asp:ListItem value="BZ">Belize</asp:ListItem>
								<asp:ListItem value="BJ">Benin</asp:ListItem>
								<asp:ListItem value="BM">Bermuda</asp:ListItem>
								<asp:ListItem value="BT">Bhutan</asp:ListItem>
								<asp:ListItem value="BO">Bolivia</asp:ListItem>
								<asp:ListItem value="BA">Bosnia and Herzegovina</asp:ListItem>
								<asp:ListItem value="BW">Botswana</asp:ListItem>
								<asp:ListItem value="BV">Bouvet Island</asp:ListItem>
								<asp:ListItem value="BR">Brazil</asp:ListItem>
								<asp:ListItem value="IO">British Indian Ocean Territory</asp:ListItem>
								<asp:ListItem value="VG">British Virgin Islands</asp:ListItem>
								<asp:ListItem value="BN">Brunei</asp:ListItem>
								<asp:ListItem value="BG">Bulgaria</asp:ListItem>
								<asp:ListItem value="BF">Burkina Faso</asp:ListItem>
								<asp:ListItem value="BI">Burundi</asp:ListItem>
								<asp:ListItem value="KH">Cambodia</asp:ListItem>
								<asp:ListItem value="CM">Cameroon</asp:ListItem>
								<asp:ListItem value="CA">Canada</asp:ListItem>
								<asp:ListItem value="CV">Cape Verde</asp:ListItem>
								<asp:ListItem value="KY">Cayman Islands</asp:ListItem>
								<asp:ListItem value="CF">Central African Republic</asp:ListItem>
								<asp:ListItem value="TD">Chad</asp:ListItem>
								<asp:ListItem value="CL">Chile</asp:ListItem>
								<asp:ListItem value="CN">China</asp:ListItem>
								<asp:ListItem value="CX">Christmas Island</asp:ListItem>
								<asp:ListItem value="CC">Cocos (Keeling) Islands</asp:ListItem>
								<asp:ListItem value="CO">Colombia</asp:ListItem>
								<asp:ListItem value="KM">Comoros</asp:ListItem>
								<asp:ListItem value="CG">Congo</asp:ListItem>
								<asp:ListItem value="CD">Congo - Democratic Republic of</asp:ListItem>
								<asp:ListItem value="CK">Cook Islands</asp:ListItem>
								<asp:ListItem value="CR">Costa Rica</asp:ListItem>
								<asp:ListItem value="CI">Cote d'Ivoire</asp:ListItem>
								<asp:ListItem value="HR">Croatia</asp:ListItem>
								<asp:ListItem value="CU">Cuba</asp:ListItem>
								<asp:ListItem value="CY">Cyprus</asp:ListItem>
								<asp:ListItem value="CZ">Czech Republic</asp:ListItem>
								<asp:ListItem value="DK">Denmark</asp:ListItem>
								<asp:ListItem value="DJ">Djibouti</asp:ListItem>
								<asp:ListItem value="DM">Dominica</asp:ListItem>
								<asp:ListItem value="DO">Dominican Republic</asp:ListItem>
								<asp:ListItem value="TP">East Timor</asp:ListItem>
								<asp:ListItem value="EC">Ecuador</asp:ListItem>
								<asp:ListItem value="EG">Egypt</asp:ListItem>
								<asp:ListItem value="SV">El Salvador</asp:ListItem>
								<asp:ListItem value="GQ">Equitorial Guinea</asp:ListItem>
								<asp:ListItem value="ER">Eritrea</asp:ListItem>
								<asp:ListItem value="EE">Estonia</asp:ListItem>
								<asp:ListItem value="ET">Ethiopia</asp:ListItem>
								<asp:ListItem value="FK">Falkland Islands (Islas Malvinas)</asp:ListItem>
								<asp:ListItem value="FO">Faroe Islands</asp:ListItem>
								<asp:ListItem value="FJ">Fiji</asp:ListItem>
								<asp:ListItem value="FI">Finland</asp:ListItem>
								<asp:ListItem value="FR">France</asp:ListItem>
								<asp:ListItem value="GF">French Guyana</asp:ListItem>
								<asp:ListItem value="PF">French Polynesia</asp:ListItem>
								<asp:ListItem value="TF">French Southern and Antarctic Lands</asp:ListItem>
								<asp:ListItem value="GA">Gabon</asp:ListItem>
								<asp:ListItem value="GM">Gambia</asp:ListItem>
								<asp:ListItem value="GZ">Gaza Strip</asp:ListItem>
								<asp:ListItem value="GE">Georgia</asp:ListItem>
								<asp:ListItem value="DE">Germany</asp:ListItem>
								<asp:ListItem value="GH">Ghana</asp:ListItem>
								<asp:ListItem value="GI">Gibraltar</asp:ListItem>
								<asp:ListItem value="GR">Greece</asp:ListItem>
								<asp:ListItem value="GL">Greenland</asp:ListItem>
								<asp:ListItem value="GD">Grenada</asp:ListItem>
								<asp:ListItem value="GP">Guadeloupe</asp:ListItem>
								<asp:ListItem value="GU">Guam</asp:ListItem>
								<asp:ListItem value="GT">Guatemala</asp:ListItem>
								<asp:ListItem value="GN">Guinea</asp:ListItem>
								<asp:ListItem value="GW">Guinea-Bissau</asp:ListItem>
								<asp:ListItem value="GY">Guyana</asp:ListItem>
								<asp:ListItem value="HT">Haiti</asp:ListItem>
								<asp:ListItem value="HM">Heard Island and McDonald Islands</asp:ListItem>
								<asp:ListItem value="VA">Holy See (Vatican City)</asp:ListItem>
								<asp:ListItem value="HN">Honduras</asp:ListItem>
								<asp:ListItem value="HK">Hong Kong</asp:ListItem>
								<asp:ListItem value="HU">Hungary</asp:ListItem>
								<asp:ListItem value="IS">Iceland</asp:ListItem>
								<asp:ListItem value="IN">India</asp:ListItem>
								<asp:ListItem value="ID">Indonesia</asp:ListItem>
								<asp:ListItem value="IR">Iran</asp:ListItem>
								<asp:ListItem value="IQ">Iraq</asp:ListItem>
								<asp:ListItem value="IE">Ireland</asp:ListItem>
								<asp:ListItem value="IL">Israel</asp:ListItem>
								<asp:ListItem value="IT">Italy</asp:ListItem>
								<asp:ListItem value="JM">Jamaica</asp:ListItem>
								<asp:ListItem value="JP">Japan</asp:ListItem>
								<asp:ListItem value="JO">Jordan</asp:ListItem>
								<asp:ListItem value="KZ">Kazakhstan</asp:ListItem>
								<asp:ListItem value="KE">Kenya</asp:ListItem>
								<asp:ListItem value="KI">Kiribati</asp:ListItem>
								<asp:ListItem value="KW">Kuwait</asp:ListItem>
								<asp:ListItem value="KG">Kyrgyzstan</asp:ListItem>
								<asp:ListItem value="LA">Laos</asp:ListItem>
								<asp:ListItem value="LV">Latvia</asp:ListItem>
								<asp:ListItem value="LB">Lebanon</asp:ListItem>
								<asp:ListItem value="LS">Lesotho</asp:ListItem>
								<asp:ListItem value="LR">Liberia</asp:ListItem>
								<asp:ListItem value="LY">Libya</asp:ListItem>
								<asp:ListItem value="LI">Liechtenstein</asp:ListItem>
								<asp:ListItem value="LT">Lithuania</asp:ListItem>
								<asp:ListItem value="LU">Luxembourg</asp:ListItem>
								<asp:ListItem value="MO">Macau</asp:ListItem>
								<asp:ListItem value="MK">Macedonia - The Former Yugoslav Republic of</asp:ListItem>
								<asp:ListItem value="MG">Madagascar</asp:ListItem>
								<asp:ListItem value="MW">Malawi</asp:ListItem>
								<asp:ListItem value="MY">Malaysia</asp:ListItem>
								<asp:ListItem value="MV">Maldives</asp:ListItem>
								<asp:ListItem value="ML">Mali</asp:ListItem>
								<asp:ListItem value="MT">Malta</asp:ListItem>
								<asp:ListItem value="MH">Marshall Islands</asp:ListItem>
								<asp:ListItem value="MQ">Martinique</asp:ListItem>
								<asp:ListItem value="MR">Mauritania</asp:ListItem>
								<asp:ListItem value="MU">Mauritius</asp:ListItem>
								<asp:ListItem value="YT">Mayotte</asp:ListItem>
								<asp:ListItem value="MX">Mexico</asp:ListItem>
								<asp:ListItem value="FM">Micronesia - Federated States of</asp:ListItem>
								<asp:ListItem value="MD">Moldova</asp:ListItem>
								<asp:ListItem value="MC">Monaco</asp:ListItem>
								<asp:ListItem value="MN">Mongolia</asp:ListItem>
								<asp:ListItem value="MS">Montserrat</asp:ListItem>
								<asp:ListItem value="MA">Morocco</asp:ListItem>
								<asp:ListItem value="MZ">Mozambique</asp:ListItem>
								<asp:ListItem value="MM">Myanmar</asp:ListItem>
								<asp:ListItem value="NA">Namibia</asp:ListItem>
								<asp:ListItem value="NR">Naura</asp:ListItem>
								<asp:ListItem value="NP">Nepal</asp:ListItem>
								<asp:ListItem value="NL">Netherlands</asp:ListItem>
								<asp:ListItem value="AN">Netherlands Antilles</asp:ListItem>
								<asp:ListItem value="NC">New Caledonia</asp:ListItem>
								<asp:ListItem value="NZ">New Zealand</asp:ListItem>
								<asp:ListItem value="NI">Nicaragua</asp:ListItem>
								<asp:ListItem value="NE">Niger</asp:ListItem>
								<asp:ListItem value="NG">Nigeria</asp:ListItem>
								<asp:ListItem value="NU">Niue</asp:ListItem>
								<asp:ListItem value="NF">Norfolk Island</asp:ListItem>
								<asp:ListItem value="KP">North Korea</asp:ListItem>
								<asp:ListItem value="MP">Northern Mariana Islands</asp:ListItem>
								<asp:ListItem value="NO">Norway</asp:ListItem>
								<asp:ListItem value="OM">Oman</asp:ListItem>
								<asp:ListItem value="PK">Pakistan</asp:ListItem>
								<asp:ListItem value="PW">Palau</asp:ListItem>
								<asp:ListItem value="PA">Panama</asp:ListItem>
								<asp:ListItem value="PG">Papua New Guinea</asp:ListItem>
								<asp:ListItem value="PY">Paraguay</asp:ListItem>
								<asp:ListItem value="PE">Peru</asp:ListItem>
								<asp:ListItem value="PH">Philippines</asp:ListItem>
								<asp:ListItem value="PN">Pitcairn Islands</asp:ListItem>
								<asp:ListItem value="PL">Poland</asp:ListItem>
								<asp:ListItem value="PT">Portugal</asp:ListItem>
								<asp:ListItem value="PR">Puerto Rico</asp:ListItem>
								<asp:ListItem value="QA">Qatar</asp:ListItem>
								<asp:ListItem value="RE">Reunion</asp:ListItem>
								<asp:ListItem value="RO">Romania</asp:ListItem>
								<asp:ListItem value="RU">Russia</asp:ListItem>
								<asp:ListItem value="RW">Rwanda</asp:ListItem>
								<asp:ListItem value="KN">Saint Kitts and Nevis</asp:ListItem>
								<asp:ListItem value="LC">Saint Lucia</asp:ListItem>
								<asp:ListItem value="VC">Saint Vincent and the Grenadines</asp:ListItem>
								<asp:ListItem value="WS">Samoa</asp:ListItem>
								<asp:ListItem value="SM">San Marino</asp:ListItem>
								<asp:ListItem value="ST">Sao Tome and Principe</asp:ListItem>
								<asp:ListItem value="SA">Saudi Arabia</asp:ListItem>
								<asp:ListItem value="SN">Senegal</asp:ListItem>
								<asp:ListItem value="CS">Serbia and Montenegro</asp:ListItem>
								<asp:ListItem value="SC">Seychelles</asp:ListItem>
								<asp:ListItem value="SL">Sierra Leone</asp:ListItem>
								<asp:ListItem value="SG">Singapore</asp:ListItem>
								<asp:ListItem value="SK">Slovakia</asp:ListItem>
								<asp:ListItem value="SI">Slovenia</asp:ListItem>
								<asp:ListItem value="SB">Solomon Islands</asp:ListItem>
								<asp:ListItem value="SO">Somalia</asp:ListItem>
								<asp:ListItem value="ZA">South Africa</asp:ListItem>
								<asp:ListItem value="GS">South Georgia and the South Sandwich Islands</asp:ListItem>
								<asp:ListItem value="KR">South Korea</asp:ListItem>
								<asp:ListItem value="ES">Spain</asp:ListItem>
								<asp:ListItem value="LK">Sri Lanka</asp:ListItem>
								<asp:ListItem value="SH">St. Helena</asp:ListItem>
								<asp:ListItem value="PM">St. Pierre and Miquelon</asp:ListItem>
								<asp:ListItem value="SD">Sudan</asp:ListItem>
								<asp:ListItem value="SR">Suriname</asp:ListItem>
								<asp:ListItem value="SJ">Svalbard</asp:ListItem>
								<asp:ListItem value="SZ">Swaziland</asp:ListItem>
								<asp:ListItem value="SE">Sweden</asp:ListItem>
								<asp:ListItem value="CH">Switzerland</asp:ListItem>
								<asp:ListItem value="SY">Syria</asp:ListItem>
								<asp:ListItem value="TW">Taiwan</asp:ListItem>
								<asp:ListItem value="TJ">Tajikistan</asp:ListItem>
								<asp:ListItem value="TZ">Tanzania</asp:ListItem>
								<asp:ListItem value="TH">Thailand</asp:ListItem>
								<asp:ListItem value="TG">Togo</asp:ListItem>
								<asp:ListItem value="TK">Tokelau</asp:ListItem>
								<asp:ListItem value="TO">Tonga</asp:ListItem>
								<asp:ListItem value="TT">Trinidad and Tobago</asp:ListItem>
								<asp:ListItem value="TN">Tunisia</asp:ListItem>
								<asp:ListItem value="TR">Turkey</asp:ListItem>
								<asp:ListItem value="TM">Turkmenistan</asp:ListItem>
								<asp:ListItem value="TC">Turks and Caicos Islands</asp:ListItem>
								<asp:ListItem value="TV">Tuvalu</asp:ListItem>
								<asp:ListItem value="UG">Uganda</asp:ListItem>
								<asp:ListItem value="UA">Ukraine</asp:ListItem>
								<asp:ListItem value="AE">United Arab Emirates</asp:ListItem>
								<asp:ListItem value="GB">United Kingdom</asp:ListItem>
								<asp:ListItem value="VI">United States Virgin Islands</asp:ListItem>
								<asp:ListItem value="UY">Uruguay</asp:ListItem>
								<asp:ListItem value="UZ">Uzbekistan</asp:ListItem>
								<asp:ListItem value="VU">Vanuatu</asp:ListItem>
								<asp:ListItem value="VE">Venezuela</asp:ListItem>
								<asp:ListItem value="VN">Vietnam</asp:ListItem>
								<asp:ListItem value="WF">Wallis and Futuna</asp:ListItem>
								<asp:ListItem value="PS">West Bank</asp:ListItem>
								<asp:ListItem value="EH">Western Sahara</asp:ListItem>
								<asp:ListItem value="YE">Yemen</asp:ListItem>
								<asp:ListItem value="ZM">Zambia</asp:ListItem>
								<asp:ListItem value="ZW">Zimbabwe</asp:ListItem>
							</asp:dropdownlist></FONT></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 14px" align="right"><FONT face="Microsoft Sans Serif" size="2" align="right"><b>Gender:</b></FONT>
					</TD>
					<td style="HEIGHT: 14px"><asp:radiobuttonlist id="Gender" runat="server" Width="168px" Height="8px" RepeatDirection="Horizontal"
							Font-Names="Microsoft Sans Serif" Font-Size="X-Small">
							<asp:ListItem Value="M" Selected="True">Male</asp:ListItem>
							<asp:ListItem Value="F">Female</asp:ListItem>
						</asp:radiobuttonlist></td>
				</TR>
				<TR>
					<TD style="WIDTH: 129px; HEIGHT: 7px" align="right"><FONT face="Microsoft Sans Serif" size="2" align="right"><b>Date 
								of Birth:</b></FONT>
					</TD>
					<td style="HEIGHT: 7px">
						<asp:DropDownList id="Day" runat="server" Width="64px" Height="16px">
							<asp:ListItem Value="1" Selected="True">1</asp:ListItem>
							<asp:ListItem Value="2">2</asp:ListItem>
							<asp:ListItem Value="3">3
</asp:ListItem>
							<asp:ListItem Value="4">4
</asp:ListItem>
							<asp:ListItem Value="5">5
</asp:ListItem>
							<asp:ListItem Value="6">6
</asp:ListItem>
							<asp:ListItem Value="7">7
</asp:ListItem>
							<asp:ListItem Value="8">8
</asp:ListItem>
							<asp:ListItem Value="9">9
</asp:ListItem>
							<asp:ListItem Value="10">10
</asp:ListItem>
							<asp:ListItem Value="11">11
</asp:ListItem>
							<asp:ListItem Value="12">12
</asp:ListItem>
							<asp:ListItem Value="13">13
</asp:ListItem>
							<asp:ListItem Value="14">14
</asp:ListItem>
							<asp:ListItem Value="15">15
</asp:ListItem>
							<asp:ListItem Value="16">16
</asp:ListItem>
							<asp:ListItem Value="17">17
</asp:ListItem>
							<asp:ListItem Value="18">18
</asp:ListItem>
							<asp:ListItem Value="19">19
</asp:ListItem>
							<asp:ListItem Value="20">20
</asp:ListItem>
							<asp:ListItem Value="21">21
</asp:ListItem>
							<asp:ListItem Value="22">22
</asp:ListItem>
							<asp:ListItem Value="23">23
</asp:ListItem>
							<asp:ListItem Value="24">24
</asp:ListItem>
							<asp:ListItem Value="25">25
</asp:ListItem>
							<asp:ListItem Value="26">26
</asp:ListItem>
							<asp:ListItem Value="27">27
</asp:ListItem>
							<asp:ListItem Value="28">28
</asp:ListItem>
							<asp:ListItem Value="29">29
</asp:ListItem>
							<asp:ListItem Value="30">30
</asp:ListItem>
							<asp:ListItem Value="231">31
</asp:ListItem>
						</asp:DropDownList>
						<asp:DropDownList id="Month" runat="server" Width="64px" Height="16px">
							<asp:ListItem Value="1" Selected="True">Jan</asp:ListItem>
							<asp:ListItem Value="2">Feb</asp:ListItem>
							<asp:ListItem value="3"> Mar  </asp:ListItem>
							<asp:ListItem value="4"> Apr  </asp:ListItem>
							<asp:ListItem value="5"> May  </asp:ListItem>
							<asp:ListItem value="6"> Jun  </asp:ListItem>
							<asp:ListItem value="7"> Jul  </asp:ListItem>
							<asp:ListItem value="8"> Aug  </asp:ListItem>
							<asp:ListItem value="9"> Sep  </asp:ListItem>
							<asp:ListItem value="10"> Oct  </asp:ListItem>
							<asp:ListItem value="11"> Nov  </asp:ListItem>
							<asp:ListItem value="12"> Dec  </asp:ListItem>
						</asp:DropDownList>
						<asp:DropDownList id="Year" runat="server" Width="64px" Height="16px">
							<asp:ListItem Value="1" Selected="True">2007</asp:ListItem>
							<asp:ListItem Value="2">2006</asp:ListItem>
							<asp:ListItem Value="3">2005</asp:ListItem>
							<asp:ListItem Value="4">2004</asp:ListItem>
							<asp:ListItem Value="5">2003</asp:ListItem>
							<asp:ListItem Value="6">2002</asp:ListItem>
							<asp:ListItem Value="7">2001</asp:ListItem>
							<asp:ListItem Value="8">2000</asp:ListItem>
							<asp:ListItem Value="9">1999</asp:ListItem>
							<asp:ListItem Value="10">1998</asp:ListItem>
							<asp:ListItem Value="11">1997</asp:ListItem>
							<asp:ListItem Value="12">1996</asp:ListItem>
							<asp:ListItem Value="13">1995</asp:ListItem>
							<asp:ListItem Value="14">1994</asp:ListItem>
							<asp:ListItem Value="15">1993</asp:ListItem>
							<asp:ListItem Value="16">1992</asp:ListItem>
							<asp:ListItem Value="17">1991</asp:ListItem>
							<asp:ListItem Value="18">1990</asp:ListItem>
							<asp:ListItem Value="19">1989</asp:ListItem>
							<asp:ListItem Value="20">1988</asp:ListItem>
							<asp:ListItem Value="21">1987</asp:ListItem>
							<asp:ListItem Value="22">1986</asp:ListItem>
							<asp:ListItem Value="23">1985</asp:ListItem>
							<asp:ListItem Value="24">2006</asp:ListItem>
							<asp:ListItem Value="25">1984</asp:ListItem>
							<asp:ListItem Value="26">1982</asp:ListItem>
							<asp:ListItem Value="27">1981</asp:ListItem>
							<asp:ListItem Value="28">1980</asp:ListItem>
							<asp:ListItem Value="29">1979</asp:ListItem>
							<asp:ListItem Value="30">1978</asp:ListItem>
						</asp:DropDownList></td>
				</TR>
				<tr>
					<td>
					</td>
					<td>
						<asp:Button id="btSign" runat="server" Width="96px" Text="Sign UP"></asp:Button>
					</td>
				</tr>
			</table>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/10media_3.swf">
				<PARAM NAME="Src" VALUE="img/10media_3.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<embed src="img/10media_3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<asp:Label id="lblLogin" style="Z-INDEX: 133; LEFT: 488px; POSITION: absolute; TOP: 40px" runat="server"
				Height="16px" Width="134px"></asp:Label>
			<asp:HyperLink id="hylLogout" style="Z-INDEX: 132; LEFT: 824px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="52px" NavigateUrl="logout.aspx">Log out</asp:HyperLink>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 109; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="128px"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 108; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="112px"></asp:ImageButton>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 104; LEFT: 760px; POSITION: absolute; TOP: 40px"
				runat="server" Height="24px" Width="60px" NavigateUrl="insert.aspx">Insert File</asp:HyperLink>
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 105; LEFT: 632px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="60px" NavigateUrl="sign_up.aspx">Sign Up</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 106; LEFT: 704px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="52px" NavigateUrl="admin_login2.aspx">My File</asp:HyperLink>
			<table style="Z-INDEX: 103; LEFT: 104px; WIDTH: 368px; POSITION: absolute; TOP: 208px; HEIGHT: 88px"
				bgColor="#dfd7d4">
				<TR>
					<TD style="WIDTH: 398px"><FONT face="Microsoft Sans Serif" size="2">
							<P><FONT face="Microsoft Sans Serif" size="3"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>��Ѥ���Ҫԡ</b></FONT>
							</P>
							<P>Join&nbsp;WebApplication &nbsp;It's free and easy. Just fill out the account 
								info below. (All fields required )<BR>
							</P>
						</FONT>
					</TD>
				</TR>
			</table>
			<HR style="Z-INDEX: 110; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 192px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
		</form>
	</body>
</HTML>
