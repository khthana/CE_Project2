<%@ Page language="c#" Codebehind="Watch.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.Watch" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD id="Head1">
		<title>Play streaming</title>
		<script runat="server">
        public string m1 = "mms://161.246.5.86/test9/Life For Rent/Dido - Life For Rent - 01 - White Flag.mp3";
        public string m2 = "False";        
        public string name = "aaa";
        public void AspFirstSong() 
        {           
            if (bool.Parse(Application["AutoPlay"].ToString()) == true)
            {
                m1 = Application["URL"].ToString();
                m2 = "True";
            }
                    
        }
        
		</script>
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<TABLE height="886" cellSpacing="0" cellPadding="0" width="538" border="0" ms_2d_layout="TRUE">
			<TR vAlign="top">
				<TD width="538" height="886">
					<form id="form1" runat="server" method="post" action="Watch.aspx">
						<TABLE height="521" cellSpacing="0" cellPadding="0" width="874" border="0" ms_2d_layout="TRUE">
							<TR>
								<TD width="10" height="0"></TD>
								<TD width="94" height="0"></TD>
								<TD width="136" height="0"></TD>
								<TD width="136" height="0"></TD>
								<TD width="8" height="0"></TD>
								<TD width="490" height="0"></TD>
							</TR>
							<TR vAlign="top">
								<TD colSpan="2" height="15"></TD>
								<TD colSpan="4" rowSpan="3">
									<OBJECT codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
										height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
										<PARAM NAME="_cx" VALUE="20346">
										<PARAM NAME="_cy" VALUE="3519">
										<PARAM NAME="FlashVars" VALUE="">
										<PARAM NAME="Movie" VALUE="img/10media_3.swf">
										<PARAM NAME="Src" VALUE="img/10media_3.swf">
										<PARAM NAME="WMode" VALUE="Window">
										<PARAM NAME="Play" VALUE="0">
										<PARAM NAME="Loop" VALUE="0">
										<PARAM NAME="Quality" VALUE="High">
										<PARAM NAME="SAlign" VALUE="">
										<PARAM NAME="Menu" VALUE="-1">
										<PARAM NAME="Base" VALUE="">
										<PARAM NAME="AllowScriptAccess" VALUE="always">
										<PARAM NAME="Scale" VALUE="ShowAll">
										<PARAM NAME="DeviceFont" VALUE="0">
										<PARAM NAME="EmbedMovie" VALUE="0">
										<PARAM NAME="BGColor" VALUE="">
										<PARAM NAME="SWRemote" VALUE="">
										<PARAM NAME="MovieData" VALUE="">
										<PARAM NAME="SeamlessTabbing" VALUE="1">
										<PARAM NAME="Profile" VALUE="0">
										<PARAM NAME="ProfileAddress" VALUE="">
										<PARAM NAME="ProfilePort" VALUE="0">
										<PARAM NAME="AllowNetworking" VALUE="all">
										<PARAM NAME="AllowFullScreen" VALUE="false">
										<embed src="img/10media_3.swf" width="769" height="133" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
											type="application/x-shockwave-flash"> </embed>
									</OBJECT>
								</TD>
							</TR>
							<TR vAlign="top">
								<TD height="19"></TD>
								<TD>
									<%AspFirstSong(); %>
								</TD>
							</TR>
							<TR vAlign="top">
								<TD height="118"></TD>
								<TD>
									<div><FONT face="Tahoma"></FONT>
									</div>
								</TD>
							</TR>
							<TR vAlign="top">
								<TD colSpan="2" height="64"></TD>
								<TD>
									<asp:imagebutton id="ImageButton1" runat="server" Height="32px" Width="128px"></asp:imagebutton></TD>
								<TD colSpan="3">
									<asp:imagebutton id="ImageButton2" runat="server" Height="32px" Width="120px"></asp:imagebutton></TD>
							</TR>
							<TR vAlign="top">
								<TD colSpan="4" height="248"></TD>
								<TD colSpan="2">
									<OBJECT class="Media_Player" id="Qplayer" height="236" width="240" classid="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6">
										<PARAM NAME="URL" VALUE="<% = m1 %>">
										<PARAM NAME="rate" VALUE="1">
										<PARAM NAME="balance" VALUE="0">
										<PARAM NAME="currentPosition" VALUE="0">
										<PARAM NAME="defaultFrame" VALUE="">
										<PARAM NAME="playCount" VALUE="1">
										<PARAM NAME="autoStart" VALUE="-1">
										<PARAM NAME="currentMarker" VALUE="0">
										<PARAM NAME="invokeURLs" VALUE="-1">
										<PARAM NAME="baseURL" VALUE="">
										<PARAM NAME="volume" VALUE="50">
										<PARAM NAME="mute" VALUE="0">
										<PARAM NAME="uiMode" VALUE="full">
										<PARAM NAME="stretchToFit" VALUE="0">
										<PARAM NAME="windowlessVideo" VALUE="0">
										<PARAM NAME="enabled" VALUE="-1">
										<PARAM NAME="enableContextMenu" VALUE="-1">
										<PARAM NAME="fullScreen" VALUE="0">
										<PARAM NAME="SAMIStyle" VALUE="">
										<PARAM NAME="SAMILang" VALUE="">
										<PARAM NAME="SAMIFilename" VALUE="">
										<PARAM NAME="captioningID" VALUE="">
										<PARAM NAME="enableErrorDialogs" VALUE="0">
										<PARAM NAME="_cx" VALUE="6350">
										<PARAM NAME="_cy" VALUE="6244">
									</OBJECT>
								</TD>
							</TR>
							<TR vAlign="top">
								<TD colSpan="5" height="57"></TD>
								<TD>
									<table height="56" width="232">
										<TR>
											<TD>
												<asp:Label id="lblTitle" runat="server" Width="216px" Height="16px" Font-Bold="True" Font-Names="Microsoft Sans Serif"
													Font-Size="X-Small"></asp:Label></TD>
										</TR>
										<TR>
											<TD>
												<asp:Label id="lblCategory" runat="server" Width="224px" Height="16px" Font-Bold="True" Font-Names="Microsoft Sans Serif"
													Font-Size="X-Small"></asp:Label></TD>
										</TR>
									</table>
								</TD>
							</TR>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</TABLE>
					</form>
				</TD>
			</TR>
		</TABLE>
	</body>
</HTML>
