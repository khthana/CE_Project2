<%@ Page language="c#" Codebehind="deleteFile2.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.deleteFile2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>deleteFile2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 288px; POSITION: absolute; TOP: 104px" runat="server"
					Width="136px" Height="32px">Label</asp:Label></FONT>
		</form>
	</body>
</HTML>
