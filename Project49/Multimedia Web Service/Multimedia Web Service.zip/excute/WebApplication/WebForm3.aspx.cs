using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;

namespace WebApplication
{
	/// <summary>
	/// Summary description for WebForm3.
	/// </summary>
	public class WebForm3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label UserNameLabel;
		protected System.Web.UI.WebControls.TextBox UserName;
		protected System.Web.UI.WebControls.Label PasswordLabel;
		protected System.Web.UI.WebControls.TextBox Password;
		protected System.Web.UI.WebControls.CheckBox RememberMe;
		protected System.Web.UI.WebControls.Button LoginButton;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.HtmlControls.HtmlGenericControl Login1;
		protected System.Web.UI.HtmlControls.HtmlTableCell LogIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl ShowUser;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			//string str = "komson";
			//Page.RegisterStartupScript("test","<script language=JavaScript>doucument.write(test(</script> <%@ Page language='c#'> string   <script language=JavaScript>));</script>");
			// Put user code to initialize the page here

			//System.Windows.Forms.MessageBox.Show("kkk","ddd",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Question);
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
