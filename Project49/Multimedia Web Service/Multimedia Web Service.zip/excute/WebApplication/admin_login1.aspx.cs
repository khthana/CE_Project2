using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for admin_login1.
	/// </summary>
	public class admin_login1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Button bt_login;
		protected System.Web.UI.WebControls.TextBox tb_password;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox tb_name;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		private string str1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			
			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			str1 = Request.QueryString["str1"];
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_login_Click(object sender, System.EventArgs e)
		{
			string name;
			string password;
			string status;
			string result;
			string user;

			name = tb_name.Text;
			password = tb_password.Text;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			result = ws.login(name,password);

			if((result=="Admin"))
			{
				Session["user"]= name;
				Session["password"]= password;
				Session["status"]= result;

				

				Session["status"] = result;
				
				if(this.str1==null)
				{
					Response.Redirect("indexofadmin.aspx",true);
				}
				else if(this.str1=="upload")
				{
					Response.Redirect("insert.aspx",true);
				}
				else if(this.str1=="myfile")
				{
					Response.Redirect("myfile.aspx",true);
				}

			}
			else
			{
				Response.Redirect("admin_login1.aspx",true);
				
			}			
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
	}
}
