<%@ Page language="c#" Codebehind="WebForm4.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.WebForm4" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm4</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:UpdatePanel ID="UpdatePanel1" runat="server">
				<CONTENTTEMPLATE>
					<asp:Panel id="Panel1" runat="server" BackColor="#8080FF" Width="296px" Height="128px">
						<DIV id="Login1" runat="server">
							<TABLE style="BORDER-COLLAPSE: collapse" cellSpacing="0" cellPadding="1" border="0">
								<TR>
									<TD>
										<TABLE cellPadding="0" border="0">
											<TR>
												<TD id="LogIn" style="HEIGHT: 16px" align="center" colSpan="2" runat="server">Log 
													In</TD>
											</TR>
											<TR>
												<TD align="right">
													<asp:Label id="UserNameLabel" runat="server" AssociatedControlID="UserName">User Name:</asp:Label></TD>
												<TD>
													<asp:TextBox id="UserName" runat="server"></asp:TextBox></TD>
											</TR>
											<TR>
												<TD align="right">
													<asp:Label id="PasswordLabel" runat="server" AssociatedControlID="Password">Password:</asp:Label></TD>
												<TD>
													<asp:TextBox id="Password" runat="server" TextMode="Password"></asp:TextBox></TD>
											</TR>
											<TR>
												<TD colSpan="2">
													<asp:CheckBox id="RememberMe" runat="server" Text="Remember me next time."></asp:CheckBox></TD>
											</TR>
											<TR>
											</TR>
											<TR>
												<TD align="right" colSpan="2">
													<asp:Button id="LoginButton" onclick="LoginButton_Click" runat="server" Text="Log In" ValidationGroup="Login1"
														CommandName="Login"></asp:Button></TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
							</TABLE>
						</DIV>
						<DIV id="ShowUser" runat="server" visible="false"></DIV>
					</asp:Panel>
					<QTOOLKIT:ROUNDEDCORNERSEXTENDER id="RoundedCornersExtender1" runat="server" BorderColor="black" TargetControlID="Panel1"
						Radius="10" Corners="All"></QTOOLKIT:ROUNDEDCORNERSEXTENDER>
				</CONTENTTEMPLATE>
			</asp:UpdatePanel>
		</form>
	</body>
</HTML>
