<%@ Page language="c#" Codebehind="WebForm3.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.WebForm3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm3</title>
		<script language="javascript">
		function confirm_delete()
		{ if (confirm("Are you sure you want to delete the custom search?")==true)��� 
			return true;
			else 
			return false;
		}
		function test(g)
		{ 
			return g;
			
		}
		</script>
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<TABLE height="77" cellSpacing="0" cellPadding="0" width="713" border="0" ms_2d_layout="TRUE">
			<TR vAlign="top">
				<TD width="10" height="15"></TD>
				<TD width="703"></TD>
			</TR>
			<TR vAlign="top">
				<TD height="38"></TD>
				<TD>
					<P><FONT face="Tahoma"></FONT>&nbsp;</P>
				</TD>
			</TR>
			<TR vAlign="top">
				<TD height="24"></TD>
				<TD>
					<asp:UpdatePanel ID="UpdatePanel1" runat="server">
						<CONTENTTEMPLATE>
							<asp:Panel id="Panel1" runat="server" BackColor="#8080FF" Width="296px" Height="128px">
								<DIV id="Login1" runat="server">
									<TABLE cellSpacing="0" cellPadding="1" border="0">
										<TR>
											<TD>
												<TABLE cellPadding="0" border="0">
													<TR>
														<TD id="LogIn" align="center" colSpan="2" height="16" runat="server">Log In</TD>
													</TR>
													<TR>
														<TD align="right">
															<asp:Label id="UserNameLabel" runat="server" AssociatedControlID="UserName">User Name:</asp:Label></TD>
														<TD>
															<asp:TextBox id="UserName" runat="server"></asp:TextBox></TD>
													</TR>
													<TR>
														<TD align="right">
															<asp:Label id="PasswordLabel" runat="server" AssociatedControlID="Password">Password:</asp:Label></TD>
														<TD>
															<asp:TextBox id="Password" runat="server" TextMode="Password"></asp:TextBox></TD>
													</TR>
													<TR>
														<TD colSpan="2">
															<asp:CheckBox id="RememberMe" runat="server" Text="Remember me next time."></asp:CheckBox></TD>
													</TR>
													<TR>
													</TR>
													<TR>
														<TD align="right" colSpan="2">
															<asp:Button id="LoginButton" onclick="LoginButton_Click" runat="server" Text="Log In" ValidationGroup="Login1"
																CommandName="Login"></asp:Button></TD>
													</TR>
												</TABLE>
											</TD>
										</TR>
									</TABLE>
								</DIV>
								<DIV id="ShowUser" runat="server" visible="false"></DIV>
							</asp:Panel>
							<QTOOLKIT:ROUNDEDCORNERSEXTENDER id="RoundedCornersExtender1" runat="server" BorderColor="black" TargetControlID="Panel1"
								Radius="10" Corners="All"></QTOOLKIT:ROUNDEDCORNERSEXTENDER>
						</CONTENTTEMPLATE>
					</asp:UpdatePanel></TD>
			</TR>
		</TABLE>
	</body>
</HTML>
