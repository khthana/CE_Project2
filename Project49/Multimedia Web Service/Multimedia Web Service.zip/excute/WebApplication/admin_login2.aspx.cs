using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;
using System.Windows.Forms;
using System.Xml;

namespace WebApplication
{
	/// <summary>
	/// Summary description for member.
	/// </summary>
	public class admin_login : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.HyperLink HyperLink6;
		protected System.Web.UI.WebControls.HyperLink HyperLink5;
		protected System.Web.UI.WebControls.DataGrid dg;
		
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			/*Session["filename"]=null;
			Session["title"] =null;
			Session["decription"] =null;
			Session["category"] =null;*/

			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			//Session["user"] = "vanlop";
			lblLogin.Text = "Wellcome :" + Session["user"].ToString();

			if(!IsPostBack)
			{

				this.LoadData();
				
				
			}
			//Label1.Text = (string)Session["status"];
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dg.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_CancelCommand);
			this.dg.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_EditCommand);
			this.dg.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_UpdateCommand);
			this.dg.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_DeleteCommand);
			this.dg.SelectedIndexChanged += new System.EventHandler(this.dg_SelectedIndexChanged);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("admin_login2.aspx",true);
		}

		
		private void LoadData()
		{
			//Session["status"] = "admin";
			//Session["user"] = "vanlop";
			
			DataSet dataSet = new DataSet();
			string xmlData;

			DataTable dataTable = new DataTable("row"); // row ��͵���觢����Ţͧ���Ъش
			
			dataTable.Columns.Add("Title", typeof(string));
			dataTable.Columns.Add("Decription", typeof(string));
			dataTable.Columns.Add("Category", typeof(string));
			
			dataTable.Columns.Add("UploadBy", typeof(string));
			dataTable.Columns.Add("FileName", typeof(string));
			
			
			dataSet.Tables.Add(dataTable);

			




			//string xmlData = "<XmlDS><table1><col1>Value1</col1></table1><table1><col1>Value2</col1></table1></XmlDS>";

			/*string xmlData = "<root>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<Title>Title1</Title>";
			xmlData = xmlData + "<Decription>Decription1</Decription>";
			xmlData = xmlData + "<Category>Music</Category>";
			xmlData = xmlData + "<UploadBy>UploadBy1</UploadBy>";
			xmlData = xmlData + "<FileName>01.mp3</FileName>";
				
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<Title>Title2</Title>";
			xmlData = xmlData + "<Decription>Decription2</Decription>";
			xmlData = xmlData + "<Category>Category</Category>";
			xmlData = xmlData + "<UploadBy>UploadBy2</UploadBy>";
			xmlData = xmlData + "<FileName>FileName2</FileName>";
				
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "</root>";*/

			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			xmlData = ws.showFileOfAdmin();



			try 
			{
				System.IO.StringReader xmlSR = new System.IO.StringReader(xmlData);
				dataSet.ReadXml(xmlSR, XmlReadMode.IgnoreSchema);
 
			} 
			catch (XmlException e) 
			{
				//output.Text = "An XML Exception occurred: " + e.Message;  
 
			} 
			catch (Exception e) 
			{
				//output.Text = "A General Exception occurred: " + e.ToString();
			} 

			dg.DataSource = dataSet;
			dg.DataBind();

			
		}
		private void dg_DeleteCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			
			string fileName = e.Item.Cells[6].Text;
			string title = e.Item.Cells[2].Text;
			string decription = e.Item.Cells[3].Text;
			string category = e.Item.Cells[4].Text;

			Session["filename"] = fileName;
			Session["title"] = title;
			Session["decription"] = decription;
			Session["category"] = category;

			Response.Redirect("deleteFile.aspx",true);



			/*string msg = "<script language='javascript'>" +
				"if(confirm('�س��ͧ���ź�������������')){location = 'http://161.246.5.86/webapplication/deleteFile.aspx';} " +
						
						
				"</script>";
			Response.Write(msg) ; */

			/*string msg = "<script language='javascript'>" +
				"if(confirm('�س��ͧ���ź�������������')){location = 'http://161.246.5.86/webapplication/deleteFile.aspx';} " +
						
						
				"</script>";*/
			/*if(this.test()) 
			{
				Label1.Text ="kkkk";
			}*/

			//string result;

			
			
			/*if(System.Windows.Forms.MessageBox.Show("kkk","ddd",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Question)==DialogResult.Yes)
			{
			}
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
			result = ws.deleteFile(fileName,title,decription,category);

			if(result=="deleted successfully")
			{
				this.LoadData();
			}*/
			
			

		

		}
		private void dg_EditCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			
			

			Session["Title"] = e.Item.Cells[2].Text;
			Session["Decription"] = e.Item.Cells[3].Text;
			Session["Category"] = e.Item.Cells[4].Text;
			
			
			Response.Redirect("updateofadmin.aspx",true);


			

		}
		private void dg_CancelCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			dg.EditItemIndex = -1;
			this.LoadData();
		

		}
		private void dg_UpdateCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			/*try
			{
				
				
				TextBox txtTitle = (TextBox)e.Item.Cells[2].Controls[0];
				TextBox txtDecription = (TextBox)e.Item.Cells[3].Controls[0];
				TextBox txtCategory = (TextBox)e.Item.Cells[4].Controls[0];
			
			

				string newTitle = txtTitle.Text;
				string newDecription = txtDecription.Text;
				string newCategory = txtCategory.Text;

				string oldTitle = (string)Session["Title"];
				string oldDecription = (string)Session["Decription"];
				string oldCategory = (string)Session["Category"];

			
				WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
				string result;

				if ( (newCategory =="Music Video")||(newCategory =="Comedy")||(newCategory =="Music")||(newCategory =="People")||
					(newCategory =="Sport")||(newCategory =="News")||(newCategory =="Entertainment")||(newCategory =="Animation")||
					(newCategory =="Science")||(newCategory =="Travel")||(newCategory =="Video Games")||(newCategory =="Pets & Animals"))
				{


					//result = ws.update(oldTitle,oldDecription,oldCategory,newTitle,newDecription,newCategory);
					//Label1.Text = oldTitle + ":" + oldDecription + ":" + oldCategory + ":" + newTitle + ":" + newDecription + ":" + newCategory;
					//Label1.Text = result;

			

					dg.EditItemIndex = -1;
				
					this.LoadData();
				}


			}
			catch (Exception ex)
			{
				//Label1.Text = ex.ToString();
			}*/
			
		}

		private void LinkButton2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("cre_and_delete.aspx",true);
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}

		private void dg_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private bool test()
		{
			string msg = "<script language='javascript'>" +
				"if(confirm('�س��ͧ���ź�������������')==true){return true;} " +
						
						
				"</script>";
			Response.Write(msg);
			return true;
		}



		
	}
}
