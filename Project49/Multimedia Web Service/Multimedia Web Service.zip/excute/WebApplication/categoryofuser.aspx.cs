using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for categoryofuser.
	/// </summary>
	public class categoryofuser : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Image Image05;
		protected System.Web.UI.WebControls.Image Image011;
		protected System.Web.UI.WebControls.Image Image09;
		protected System.Web.UI.WebControls.Image Image08;
		protected System.Web.UI.WebControls.Image Image03;
		protected System.Web.UI.WebControls.Image Image012;
		protected System.Web.UI.WebControls.Image Image04;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Image Image01;
		protected System.Web.UI.WebControls.LinkButton LinkButton32;
		protected System.Web.UI.WebControls.Image Image010;
		protected System.Web.UI.WebControls.LinkButton LinkButton31;
		protected System.Web.UI.WebControls.Image Image36;
		protected System.Web.UI.WebControls.LinkButton LinkButton30;
		protected System.Web.UI.WebControls.Image Image29;
		protected System.Web.UI.WebControls.Image Image06;
		protected System.Web.UI.WebControls.Image Image25;
		protected System.Web.UI.WebControls.Image Image02;
		protected System.Web.UI.WebControls.Image Image07;
		protected System.Web.UI.WebControls.Image Image17;
		protected System.Web.UI.WebControls.Image Image13;
		protected System.Web.UI.WebControls.LinkButton LinkButton9;
		protected System.Web.UI.WebControls.Image Image9;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.LinkButton LinkButton34;
		protected System.Web.UI.WebControls.LinkButton LinkButton35;
		protected System.Web.UI.WebControls.LinkButton LinkButton36;
		protected System.Web.UI.WebControls.LinkButton LinkButton37;
		protected System.Web.UI.WebControls.LinkButton LinkButton38;
		protected System.Web.UI.WebControls.LinkButton LinkButton39;
		protected System.Web.UI.WebControls.LinkButton LinkButton40;
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			string str1 = "http://161.246.5.86/WebApplication/img/2.jpg";
			string str2 = "http://161.246.5.86/WebApplication/img/2(5).jpg";
			string str3 = "http://161.246.5.86/WebApplication/img/2(10).jpg";
			string str4 = "http://161.246.5.86/WebApplication/img/2(15).jpg";
			string str5 = "http://161.246.5.86/WebApplication/img/2(20).jpg";
			string str6 = "http://161.246.5.86/WebApplication/img/2(25).jpg";
			string str7 = "http://161.246.5.86/WebApplication/img/2(30).jpg";
			string str8 = "http://161.246.5.86/WebApplication/img/2(36).jpg";
			string str9 = "http://161.246.5.86/WebApplication/img/2(40).jpg";
			string str10 = "http://161.246.5.86/WebApplication/img/2(42).jpg";
			string str11 = "http://161.246.5.86/WebApplication/img/2(50).jpg";
			string str12 = "http://161.246.5.86/WebApplication/img/2(56).jpg";
			
			
			
			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			Image01.ImageUrl = str1;
			Image02.ImageUrl = str2;
			Image03.ImageUrl = str3;
			Image04.ImageUrl = str4;
			Image05.ImageUrl = str5;
			Image06.ImageUrl = str6;
			Image07.ImageUrl = str7;
			Image08.ImageUrl = str8;
			Image09.ImageUrl = str9;
			Image010.ImageUrl = str10;
			Image011.ImageUrl = str11;
			Image012.ImageUrl = str12;

			
			hylLogout.Visible = true;
			lblLogin.Visible = true;
			lblLogin.Text = "Wellcome :" + Session["user"].ToString();

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.LinkButton32.Click += new System.EventHandler(this.LinkButton32_Click);
			this.LinkButton31.Click += new System.EventHandler(this.LinkButton31_Click);
			this.LinkButton30.Click += new System.EventHandler(this.LinkButton30_Click);
			this.LinkButton9.Click += new System.EventHandler(this.LinkButton9_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.LinkButton34.Click += new System.EventHandler(this.LinkButton34_Click);
			this.LinkButton35.Click += new System.EventHandler(this.LinkButton35_Click);
			this.LinkButton36.Click += new System.EventHandler(this.LinkButton36_Click);
			this.LinkButton37.Click += new System.EventHandler(this.LinkButton37_Click);
			this.LinkButton38.Click += new System.EventHandler(this.LinkButton38_Click);
			this.LinkButton39.Click += new System.EventHandler(this.LinkButton39_Click);
			this.LinkButton40.Click += new System.EventHandler(this.LinkButton40_Click);
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
		private void LinkButton30_Click(object sender, System.EventArgs e)
		{
			
			string url = "Autos&Vehicles";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton32_Click(object sender, System.EventArgs e)
		{
			string url = "Sports";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton34_Click(object sender, System.EventArgs e)
		{
			string url = "Arts&Animation";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton31_Click(object sender, System.EventArgs e)
		{
			string url = "News&Bloge";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton40_Click(object sender, System.EventArgs e)
		{
			string url = "Pets&Animals";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			string url = "Science&Technology";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton37_Click(object sender, System.EventArgs e)
		{
			string url = "Travel&Places";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton38_Click(object sender, System.EventArgs e)
		{
			string url = "Video";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton9_Click(object sender, System.EventArgs e)
		{
			string url = "People";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton35_Click(object sender, System.EventArgs e)
		{
			string url = "Comedy";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton39_Click(object sender, System.EventArgs e)
		{
			string url = "Entertainment";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}

		private void LinkButton36_Click(object sender, System.EventArgs e)
		{
			string url = "Music";
			Response.Redirect("Categoriesofuser.aspx?categ=" + url,true);
		}
	}
}
