<%@ Page language="c#" Codebehind="category.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.category" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Categories</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"></FONT>
			<HR style="Z-INDEX: 104; LEFT: 104px; WIDTH: 60.24%; POSITION: absolute; TOP: 200px; HEIGHT: 2px"
				width="60.24%" SIZE="2">
			<OBJECT style="Z-INDEX: 144; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/10media_3.swf">
				<PARAM NAME="Src" VALUE="img/10media_3.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/10media_3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<asp:Image id="Image05" style="Z-INDEX: 143; LEFT: 344px; POSITION: absolute; TOP: 440px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image011" style="Z-INDEX: 142; LEFT: 224px; POSITION: absolute; TOP: 440px"
				runat="server" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image09" style="Z-INDEX: 141; LEFT: 464px; POSITION: absolute; TOP: 440px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image08" style="Z-INDEX: 140; LEFT: 104px; POSITION: absolute; TOP: 440px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image03" style="Z-INDEX: 139; LEFT: 464px; POSITION: absolute; TOP: 328px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image012" style="Z-INDEX: 138; LEFT: 344px; POSITION: absolute; TOP: 328px"
				runat="server" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image04" style="Z-INDEX: 137; LEFT: 224px; POSITION: absolute; TOP: 328px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Label id="lblLogin" style="Z-INDEX: 136; LEFT: 464px; POSITION: absolute; TOP: 40px" runat="server"
				Height="16px" Width="134px" Font-Bold="True"></asp:Label>
			<asp:HyperLink id="hylLogout" style="Z-INDEX: 126; LEFT: 776px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="logout.aspx">Log out</asp:HyperLink>
			<TABLE id="Table2" style="Z-INDEX: 135; LEFT: 624px; WIDTH: 30px; POSITION: absolute; TOP: 200px; HEIGHT: 4px"
				width="30" border="1" borderColor="#000000" bgColor="#87ceeb">
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 29px"><SPAN class="tab"></SPAN><SPAN class="tab"><FONT face="Tahoma">
								<asp:label id="Label4" runat="server" Width="80px" Height="7px" Font-Names="Microsoft Sans Serif"
									Font-Size="9" Font-Bold="True">User Name :</asp:label></FONT></SPAN></TD>
					<TD style="HEIGHT: 29px">
						<asp:textbox id="tb_name" runat="server" Width="152px" Height="24px"></asp:textbox></TD>
				</TR>
				<TR>
					<TD style="WIDTH: 77px; HEIGHT: 30px">
						<asp:label id="Label5" runat="server" Width="56px" Height="16px" Font-Names="Microsoft Sans Serif"
							Font-Size="9" Font-Bold="True">Password :</asp:label></TD>
					<TD style="HEIGHT: 30px">
						<asp:textbox id="tb_password" runat="server" Width="152px" Height="24px" TextMode="Password"></asp:textbox></TD>
				</TR>
				<TR>
					<TD align="center" colSpan="2">
						<asp:button id="bt_login" runat="server" Width="88px" Text="Login" Font-Names="Microsoft Sans Serif"
							Font-Size="9"></asp:button>&nbsp;</TD>
				</TR>
			</TABLE>
			<asp:Label id="Label16" style="Z-INDEX: 125; LEFT: 712px; POSITION: absolute; TOP: 168px" runat="server"
				Width="110px" Height="16px" Font-Bold="True" Font-Size="X-Small" Font-Names="Microsoft Sans Serif">Member Login</asp:Label>
			<asp:Image id="Image01" style="Z-INDEX: 124; LEFT: 104px; POSITION: absolute; TOP: 328px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:LinkButton id="LinkButton32" style="Z-INDEX: 122; LEFT: 368px; POSITION: absolute; TOP: 288px"
				runat="server" Width="38px" Height="24px">Sport</asp:LinkButton>
			<asp:Image id="Image010" style="Z-INDEX: 118; LEFT: 344px; POSITION: absolute; TOP: 216px"
				runat="server" Width="80px" Height="64px"></asp:Image>
			<asp:LinkButton id="LinkButton31" style="Z-INDEX: 123; LEFT: 240px; POSITION: absolute; TOP: 288px"
				runat="server" Width="38px" Height="24px">News</asp:LinkButton>
			<asp:Image id="Image36" style="Z-INDEX: 115; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:LinkButton id="LinkButton30" style="Z-INDEX: 120; LEFT: 96px; POSITION: absolute; TOP: 288px"
				runat="server" Width="104px" Height="18px">Auto & Vehicles</asp:LinkButton>
			<asp:Image id="Image29" style="Z-INDEX: 112; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image06" style="Z-INDEX: 117; LEFT: 224px; POSITION: absolute; TOP: 216px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image25" style="Z-INDEX: 108; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image02" style="Z-INDEX: 116; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image07" style="Z-INDEX: 119; LEFT: 464px; POSITION: absolute; TOP: 216px" runat="server"
				Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image17" style="Z-INDEX: 110; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image13" style="Z-INDEX: 113; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:LinkButton id="LinkButton9" style="Z-INDEX: 121; LEFT: 480px; POSITION: absolute; TOP: 288px"
				runat="server" Width="46px" Height="24px">People</asp:LinkButton>
			<asp:Image id="Image9" style="Z-INDEX: 109; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:Image id="Image5" style="Z-INDEX: 114; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<TABLE id="Table1" style="Z-INDEX: 107; LEFT: 568px; POSITION: absolute; TOP: 72px">
				<TR>
					<TD>
						<asp:TextBox id="txtSearch" runat="server" Width="192px"></asp:TextBox></TD>
					<TD>&nbsp;
						<asp:Button id="btSearch" runat="server" Width="56px" Height="24px" Text="Search"></asp:Button></TD>
				</TR>
			</TABLE>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 101; LEFT: 696px; POSITION: absolute; TOP: 40px"
				runat="server" Width="66px" Height="16px" NavigateUrl="insert.aspx">Insert File</asp:HyperLink>
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 102; LEFT: 568px; POSITION: absolute; TOP: 40px"
				runat="server" Width="60px" Height="16px" Visible="False" EnableViewState="False">Sign Up</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 103; LEFT: 640px; POSITION: absolute; TOP: 40px"
				runat="server" Width="60px" Height="8px" NavigateUrl="myfile.aspx">My File</asp:HyperLink>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 105; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Width="128px" Height="32px"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 106; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Width="112px" Height="32px"></asp:ImageButton>
			<asp:Image id="Image1" style="Z-INDEX: 111; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				ImageUrl="file:///D:\Inetpub\wwwroot\WebApplication\img\a.jpg" Width="80px" Height="64px"></asp:Image>
			<asp:LinkButton id="LinkButton34" style="Z-INDEX: 127; LEFT: 112px; POSITION: absolute; TOP: 400px"
				runat="server" Width="62px" Height="26px">Animation</asp:LinkButton>
			<asp:LinkButton id="LinkButton35" style="Z-INDEX: 128; LEFT: 472px; POSITION: absolute; TOP: 400px"
				runat="server" Width="48px" Height="11px">Commedy</asp:LinkButton>
			<asp:LinkButton id="LinkButton36" style="Z-INDEX: 129; LEFT: 360px; POSITION: absolute; TOP: 512px"
				runat="server" Width="38px" Height="24px">Music</asp:LinkButton>
			<asp:LinkButton id="LinkButton37" style="Z-INDEX: 130; LEFT: 248px; POSITION: absolute; TOP: 512px"
				runat="server" Width="16px" Height="8px">Travel</asp:LinkButton>
			<asp:LinkButton id="LinkButton38" style="Z-INDEX: 131; LEFT: 344px; POSITION: absolute; TOP: 400px"
				runat="server" Width="86px" Height="24px">Video Game</asp:LinkButton>
			<asp:LinkButton id="LinkButton39" style="Z-INDEX: 132; LEFT: 224px; POSITION: absolute; TOP: 400px"
				runat="server" Width="48px" Height="8px">Entertainment</asp:LinkButton>
			<asp:LinkButton id="LinkButton40" style="Z-INDEX: 133; LEFT: 96px; POSITION: absolute; TOP: 512px"
				runat="server" Width="94px" Height="16px">Pets & Animals</asp:LinkButton>
			<asp:LinkButton id="LinkButton1" style="Z-INDEX: 134; LEFT: 432px; POSITION: absolute; TOP: 512px"
				runat="server" Width="150px" Height="8px">Science & Technology</asp:LinkButton>
		</form>
	</body>
</HTML>
