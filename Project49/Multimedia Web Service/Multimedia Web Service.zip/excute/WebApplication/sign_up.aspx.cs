using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for sign_up.
	/// </summary>
	public class sign_up : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList CountryList;
		protected System.Web.UI.WebControls.DropDownList Month;
		protected System.Web.UI.WebControls.DropDownList Year;
		protected System.Web.UI.WebControls.TextBox tbEmail;
		protected System.Web.UI.WebControls.TextBox tbUserName;
		protected System.Web.UI.WebControls.TextBox tbPassword;
		protected System.Web.UI.WebControls.TextBox tbConfirm;
		protected System.Web.UI.WebControls.Button btSign;
		protected System.Web.UI.WebControls.RadioButtonList Gender;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.DropDownList Day;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			if((string)Session["user"]== null)
			{
				hylLogout.Visible = false;
				lblLogin.Visible = false;
			}
			else
			{
				hylLogout.Visible = true;
				lblLogin.Visible = true;
				//lblLogin.Text = "Welcome :" + Session["user"].ToString();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btSign.Click += new System.EventHandler(this.btSign_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btSign_Click(object sender, System.EventArgs e)
		{
			bool result = true;
			
			string userName;
			string password;
			string confirm;
			string email;
			string country;
			
			string gender;
			string day;
			string month;
			string year;
			string str1;
			string str2;
			string msg;

			userName = tbUserName.Text;
			password = tbPassword.Text;
			confirm = tbConfirm.Text;
			email = tbEmail.Text;
			country = CountryList.SelectedItem.Value;
			
			gender = Gender.SelectedItem.Value;
			day = Day.SelectedItem.Value;
			month = Month.SelectedItem.Value;
			year = Year.SelectedItem.Value;

						
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
			if(password==confirm)
			{

			
			
				result = ws.register(userName,password,"User",email,country,gender,day,month,year);
				if(result)
				{
					str1 = "�ѹ�֡ username ���  password ŧ㹰ҹ���������º��������";
					msg = "��ѧ˹��˹���á";
					str2 = "success";
				
					Response.Redirect("result_1.aspx?str1=" + str1 + "&msg=" + msg + "&str2=" + str2,true);
				
				}
				else
				{
					str1 = "�����Ѥ���Ҫԡ�������ó�";
					msg = "��Ѻ��ѧ˹����Ѥ���Ҫԡ�ա����";
					str2 = "no success";
				
					Response.Redirect("result_1.aspx?str1=" + str1 + "&msg=" + msg + "&str2=" + str2,true);
				}
				

			}
			else
			{
				Response.Redirect("sign_up.aspx",true);

			}

			

			

			//Label13.Text = result;



		}

		/*private void bt_login_Click(object sender, System.EventArgs e)
		{
			string name;
			string password;
			string status;
			string result;
			string user;

			name = tb_name.Text;
			password = tb_password.Text;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			result = ws.login(name,password);

			if((result=="Admin")||(result=="User"))
			{
				Session["user"]= name;
				Session["password"]= password;
				Session["status"]= result;

				

				Session["status"] = result;
				Response.Redirect("sign_up.aspx",true);
				

			}
			else
			{
				Response.Redirect("index.aspx",true);
				
			}			
			
			
			
		}*/

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
	}
}
