using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for myfile.
	/// </summary>
	public class myfile : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			if((string)Session["user"]!= null)
			{
				if((string)Session["status"]=="Admin")
				{
					Response.Redirect("admin_login2.aspx",true);
				}
				else if((string)Session["status"]=="User")
				{
					Response.Redirect("user_login.aspx",true);
				}
				
			}
			
			if((string)Session["user"]== null)
			{
				string str1 = "myfile";
				Response.Redirect("login.aspx?str1=" + str1,true);
				
			}
				
				
			

			

			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
