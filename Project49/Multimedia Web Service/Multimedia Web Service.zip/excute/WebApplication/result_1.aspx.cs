using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for result_1.
	/// </summary>
	public class result_1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btBack;
		protected System.Web.UI.WebControls.Label lblresult;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.Label lblresult2;
		protected string str2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string str1 = Request.QueryString["str1"];
			this.str2 = Request.QueryString["str2"];
			string msg = Request.QueryString["msg"];
			lblresult.Text = str1;
			btBack.Text = msg;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btBack.Click += new System.EventHandler(this.btBack_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btBack_Click(object sender, System.EventArgs e)
		{
			if(this.str2=="success")
			{
				Response.Redirect("index.aspx",true);
			}
			else
			{
				Response.Redirect("sign_up.aspx",true);
			}

		
		}

		private void btSignUp_Click(object sender, System.EventArgs e)
		{
		
		}

		private void bt_login_Click(object sender, System.EventArgs e)
		{
			
				
					
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
	}
}
