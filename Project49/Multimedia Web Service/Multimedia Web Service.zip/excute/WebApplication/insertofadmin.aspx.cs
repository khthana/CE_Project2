using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for insertofaddmin.
	/// </summary>
	public class insertofaddmin : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox tb_title;
		protected System.Web.UI.WebControls.TextBox tb_decription;
		protected System.Web.UI.WebControls.RadioButtonList Category;
		protected System.Web.UI.WebControls.Button btnOk;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label lblresult;
		protected System.Web.UI.HtmlControls.HtmlInputFile FileToUpload;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;

			if(!IsPostBack)
			{

				if((string)Session["user"]== null)
				{
					string str1 = "upload";
					Response.Redirect("login.aspx?str1=" + str1,true);
				
				}
				else
				{
					hylLogout.Visible = true;
					lblLogin.Visible = true;
					lblLogin.Text = "Wellcome :" + Session["user"].ToString();

				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnOk_Click(object sender, System.EventArgs e)
		{
			string strBaseLocation = Server.MapPath("/upload/streamming/");
			string address = FileToUpload.Value.ToString();
			string fName = System.IO.Path.GetFileName(address);
			string fullPath = strBaseLocation + fName;
			string result;
			string title;
			string decription;
			string user;
			string status;
			string test;
			string password;
			string category;
			string hour = DateTime.Now.Hour.ToString();
			string min = DateTime.Now.Minute.ToString();
			string sec = DateTime.Now.Second.ToString();
			string insertTime = hour + ":" + min + ":" + sec;

			category = Category.SelectedItem.Value;
			


			
			user = (string)Session["user"];
			
			password = (string)Session["password"];

			title = tb_title.Text;
			decription = tb_decription.Text;
			try 
			{
				FileToUpload.PostedFile.SaveAs(fullPath);
				
				
				WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
				
				
				result = ws.insert(address,title,decription,user,category,insertTime);

				tb_title.Text = "";
				tb_decription.Text = "";
				if(result=="success")
				{
					
					if((string)Session["user"]!= null)
					{
						if((string)Session["status"]=="Admin")
						{
							Response.Redirect("admin_login2.aspx",true);
						}
						else if((string)Session["status"]=="User")
						{
							Response.Redirect("user_login.aspx",true);
						}
				
					}
				}
				else
				{
					lblresult.Text = "��� Insert file ���������ô Insert �ա����˹��";
				}

				lblresult.Text = result;

				

			}
			catch (Exception er) 
			{
				lblresult.Text = "��� Insert file ���������ô Insert �ա����˹��";
			}
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}

		
	}
}
