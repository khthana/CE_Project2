using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox tb_name;
		protected System.Web.UI.WebControls.TextBox tb_password;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Button btSearch;
		protected System.Web.UI.WebControls.TextBox txtSearch;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Label Label16;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Button btSignUp;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.Label lblFrom1;
		protected System.Web.UI.WebControls.Image Image6;
		protected System.Web.UI.WebControls.Image Image7;
		protected System.Web.UI.WebControls.Image Image8;
		protected System.Web.UI.WebControls.Image Image9;
		protected System.Web.UI.WebControls.Image Image10;
		protected System.Web.UI.WebControls.Image Image11;
		protected System.Web.UI.WebControls.Image Image12;
		protected System.Web.UI.WebControls.Label lblTitle1;
		protected System.Web.UI.WebControls.Label lblDecription1;
		protected System.Web.UI.WebControls.Label lblFrom2;
		protected System.Web.UI.WebControls.Label lblFrom3;
		protected System.Web.UI.WebControls.Label lblTitle2;
		protected System.Web.UI.WebControls.Label lblDecription2;
		protected System.Web.UI.WebControls.Label lblTitle3;
		protected System.Web.UI.WebControls.Label lblDecription3;
		protected System.Web.UI.WebControls.Label lblTitle4;
		protected System.Web.UI.WebControls.Label lblDecription4;
		protected System.Web.UI.WebControls.Label lblTitle5;
		protected System.Web.UI.WebControls.Label lblDecription5;
		protected System.Web.UI.WebControls.Label lblTitle6;
		protected System.Web.UI.WebControls.Label lblDecription6;
		protected System.Web.UI.WebControls.Label lblDecription7;
		protected System.Web.UI.WebControls.Label lblTitle8;
		protected System.Web.UI.WebControls.Label lblDecription8;
		protected System.Web.UI.WebControls.Label lblTitle9;
		protected System.Web.UI.WebControls.Label lblDecription9;
		protected System.Web.UI.WebControls.Label lblTitle10;
		protected System.Web.UI.WebControls.Label lblDecription10;
		protected System.Web.UI.WebControls.Label lblTitle11;
		protected System.Web.UI.WebControls.Label lblDecription11;
		protected System.Web.UI.WebControls.Label lblDecription12;
		protected System.Web.UI.WebControls.Label lblFrom4;
		protected System.Web.UI.WebControls.Label lblFrom5;
		protected System.Web.UI.WebControls.Label lblFrom6;
		protected System.Web.UI.WebControls.Label lblFrom7;
		protected System.Web.UI.WebControls.Label lblFrom8;
		protected System.Web.UI.WebControls.Label lblFrom9;
		protected System.Web.UI.WebControls.Label lblFrom10;
		protected System.Web.UI.WebControls.Label lblFrom11;
		protected System.Web.UI.WebControls.Label lblFrom12;
		protected System.Web.UI.WebControls.Label lblTitle12;
		protected System.Web.UI.WebControls.Label lblViews1;
		protected System.Web.UI.WebControls.Label lblViews2;
		protected System.Web.UI.WebControls.Label lblViews3;
		protected System.Web.UI.WebControls.Label lblViews4;
		protected System.Web.UI.WebControls.Label lblViews5;
		protected System.Web.UI.WebControls.Label lblViews6;
		protected System.Web.UI.WebControls.Label lblViews7;
		protected System.Web.UI.WebControls.Label lblViews8;
		protected System.Web.UI.WebControls.Label lblViews10;
		protected System.Web.UI.WebControls.Label lblViews9;
		protected System.Web.UI.WebControls.Label lblMore9;
		protected System.Web.UI.WebControls.Label lblMore1;
		protected System.Web.UI.WebControls.Label lblMore2;
		protected System.Web.UI.WebControls.Label lblMore3;
		protected System.Web.UI.WebControls.Label lblMore4;
		protected System.Web.UI.WebControls.Label lblMore5;
		protected System.Web.UI.WebControls.Label lblMore6;
		protected System.Web.UI.WebControls.Label lblMore7;
		protected System.Web.UI.WebControls.Label lblMore8;
		protected System.Web.UI.WebControls.Label lblMore10;
		protected System.Web.UI.WebControls.Label lblViews11;
		protected System.Web.UI.WebControls.Label lblMore11;
		protected System.Web.UI.WebControls.Label lblViews12;
		protected System.Web.UI.WebControls.Label lblMore12;
		protected System.Web.UI.WebControls.Label txtFrom1;
		protected System.Web.UI.WebControls.Label txtDecription2;
		protected System.Web.UI.WebControls.Label txtTitle2;
		protected System.Web.UI.WebControls.Label txtDecription1;
		protected System.Web.UI.WebControls.Label txtTitle1;
		protected System.Web.UI.WebControls.Label txtFrom2;
		protected System.Web.UI.WebControls.Label txtFrom3;
		protected System.Web.UI.WebControls.Label txtFrom4;
		protected System.Web.UI.WebControls.Label txtFrom5;
		protected System.Web.UI.WebControls.Label txtFrom6;
		protected System.Web.UI.WebControls.Label txtFrom7;
		protected System.Web.UI.WebControls.Label txtFrom8;
		protected System.Web.UI.WebControls.Label txtViews9;
		protected System.Web.UI.WebControls.Label txtMore9;
		protected System.Web.UI.WebControls.Label txtFrom9;
		protected System.Web.UI.WebControls.Label txtFrom10;
		protected System.Web.UI.WebControls.Label txtFrom11;
		protected System.Web.UI.WebControls.Label txtFrom12;
		protected System.Web.UI.WebControls.Label txtTitle3;
		protected System.Web.UI.WebControls.Label txtDecription3;
		protected System.Web.UI.WebControls.Label txtTitle4;
		protected System.Web.UI.WebControls.Label txtDecription4;
		protected System.Web.UI.WebControls.Label txtTitle5;
		protected System.Web.UI.WebControls.Label txtDecription5;
		protected System.Web.UI.WebControls.Label txtTitle6;
		protected System.Web.UI.WebControls.Label txtDecription6;
		protected System.Web.UI.WebControls.Label txtTitle17;
		protected System.Web.UI.WebControls.Label txtDecription7;
		protected System.Web.UI.WebControls.Label txtTitle8;
		protected System.Web.UI.WebControls.Label txtDecription8;
		protected System.Web.UI.WebControls.Label txtTitle9;
		protected System.Web.UI.WebControls.Label txtDecription9;
		protected System.Web.UI.WebControls.Label txtTitle10;
		protected System.Web.UI.WebControls.Label txtDecription10;
		protected System.Web.UI.WebControls.Label txtTitle11;
		protected System.Web.UI.WebControls.Label txtDecription11;
		protected System.Web.UI.WebControls.Label txtTitle12;
		protected System.Web.UI.WebControls.Label txtDecription12;
		protected System.Web.UI.WebControls.Label txtViews1;
		protected System.Web.UI.WebControls.Label txtMore1;
		protected System.Web.UI.WebControls.Label txtViews2;
		protected System.Web.UI.WebControls.Label txtMore2;
		protected System.Web.UI.WebControls.Label txtViews3;
		protected System.Web.UI.WebControls.Label txtMore3;
		protected System.Web.UI.WebControls.Label txtViews4;
		protected System.Web.UI.WebControls.Label txtMore4;
		protected System.Web.UI.WebControls.Label txtViews5;
		protected System.Web.UI.WebControls.Label txtMore5;
		protected System.Web.UI.WebControls.Label txtViews6;
		protected System.Web.UI.WebControls.Label txtMore6;
		protected System.Web.UI.WebControls.Label txtViews7;
		protected System.Web.UI.WebControls.Label txtMore7;
		protected System.Web.UI.WebControls.Label txtViews8;
		protected System.Web.UI.WebControls.Label txtMore8;
		protected System.Web.UI.WebControls.Label txtViews10;
		protected System.Web.UI.WebControls.Label txtMore10;
		protected System.Web.UI.WebControls.Label txtViews11;
		protected System.Web.UI.WebControls.Label txtMore11;
		protected System.Web.UI.WebControls.Label txtViews12;
		protected System.Web.UI.WebControls.Label txtMore12;
		protected System.Web.UI.WebControls.Label lblTitle7;
		protected System.Web.UI.WebControls.HyperLink HyperLink4;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button bt_login;


		public string ChangeString(string url)
		{
			if (url == "Arts&Animation")     
			{
				url = "Arts%26Animation";
			}
			else if(url=="Autos&Vehicles")
			{
				url = "Autos%26Vehicles";
			}
			else if(url=="News&Bloge")
			{
				url = "News%26Bloge";
			}
			else if(url=="Pets&Animals")
			{
				url = "Pets%26Animals";
			}
			else if(url=="Science&Technology")
			{
				url = "Science%26Technology";
			}
			else if(url=="Travel&Places")
			{
				url = "Travel%26Places";
			}
			else if(url=="Travel&Places")
			{
				url = "Travel%26Places";
			}
			else if(url=="Video Game")
			{
				url = url.Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			}
			return url;
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{

			//System.Windows.Forms.MessageBox msg = new System.Windows.Forms.MessageBox();

			//System.Windows.Forms.MessageBox.Show("test","tessss",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Question,System.Windows.Forms.MessageBoxDefaultButton.Button1);

			string scriptString = "<script language=JavaScript> function DoClick() {";
			scriptString += "showMessage2.innerHTML='<h4>Welcome to Microsoft .NET!</h4>'}";
			scriptString += "function Page_Load(){ showMessage1.innerHTML=";
			scriptString += "'<h4>RegisterStartupScript Example</h4>'}<";
			scriptString += "/";
			scriptString += "script>";

			if((string)Session["user"]!= null)
			{
				if((string)Session["status"]=="Admin")
				{
					Response.Redirect("indexofadmin.aspx",true);
				}
				else if((string)Session["status"]=="User")
				{
					Response.Redirect("indexofuser.aspx",true);
				}
			}
				

			string str1 = "http://161.246.5.86/WebApplication/img/2.jpg";
			string str2 = "http://161.246.5.86/WebApplication/img/2(5).jpg";
			string str3 = "http://161.246.5.86/WebApplication/img/2(10).jpg";
			string str4 = "http://161.246.5.86/WebApplication/img/2(15).jpg";
			string str5 = "http://161.246.5.86/WebApplication/img/2(20).jpg";
			string str6 = "http://161.246.5.86/WebApplication/img/2(25).jpg";
			string str7 = "http://161.246.5.86/WebApplication/img/2(30).jpg";
			string str8 = "http://161.246.5.86/WebApplication/img/2(36).jpg";
			string str9 = "http://161.246.5.86/WebApplication/img/2(40).jpg";
			string str10 = "http://161.246.5.86/WebApplication/img/2(42).jpg";
			string str11 = "http://161.246.5.86/WebApplication/img/2(50).jpg";
			string str12 = "http://161.246.5.86/WebApplication/img/2(56).jpg";

			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;


			
			Image1.ImageUrl = str1;
			Image2.ImageUrl = str2;
			Image3.ImageUrl = str3;
			Image4.ImageUrl = str4;
			Image5.ImageUrl = str5;
			Image6.ImageUrl = str6;
			Image7.ImageUrl = str7;
			Image8.ImageUrl = str8;
			Image9.ImageUrl = str9;
			Image10.ImageUrl = str10;
			Image11.ImageUrl = str11;
			Image12.ImageUrl = str12;
			
			int indexDeta = 0;


			string[] deta =null;

			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			//deta = ws.firstPage();
			deta = ws.firstPage2();
			foreach (string data in deta)
			{
				//data.
			}
			string title;
			
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			string test = System.Web.HttpUtility.UrlEncode(" ");
			lblTitle1.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription1.Text = "Decription : " + deta[indexDeta++];
			lblFrom1.Text = "From : " + deta[indexDeta++];
			lblViews1.Text = "Views : " + deta[indexDeta++];
			lblMore1.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle2.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription2.Text = "Decription : " + deta[indexDeta++];
			lblFrom2.Text = "From : " + deta[indexDeta++];
			lblViews2.Text = "Views : " + deta[indexDeta++];
			lblMore2.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle3.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription3.Text = "Decription : " + deta[indexDeta++];
			lblFrom3.Text = "From : " + deta[indexDeta++];
			lblViews3.Text = "Views : " + deta[indexDeta++];
			lblMore3.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle4.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription4.Text = "Decription : " + deta[indexDeta++];
			lblFrom4.Text = "From : " + deta[indexDeta++];
			lblViews4.Text = "Views : " + deta[indexDeta++];
			lblMore4.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle5.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription5.Text = "Decription : " + deta[indexDeta++];
			lblFrom5.Text = "From : " + deta[indexDeta++];
			lblViews5.Text = "Views : " + deta[indexDeta++];
			lblMore5.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle6.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription6.Text = "Decription : " + deta[indexDeta++];
			lblFrom6.Text = "From : " + deta[indexDeta++];
			lblViews6.Text = "Views : " + deta[indexDeta++];
			lblMore6.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle7.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription7.Text = "Decription : " + deta[indexDeta++];
			lblFrom7.Text = "From : " + deta[indexDeta++];
			lblViews7.Text = "Views : " + deta[indexDeta++];
			lblMore7.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle8.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription8.Text = "Decription : " + deta[indexDeta++];
			lblFrom8.Text = "From : " + deta[indexDeta++];
			lblViews8.Text = "Views : " + deta[indexDeta++];
			lblMore8.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle9.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription9.Text = "Decription : " + deta[indexDeta++];
			lblFrom9.Text = "From : " + deta[indexDeta++];
			lblViews9.Text = "Views : " + deta[indexDeta++];
			lblMore9.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle10.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription10.Text = "Decription : " + deta[indexDeta++];
			lblFrom10.Text = "From : " + deta[indexDeta++];
			lblViews10.Text = "Views : " + deta[indexDeta++];
			lblMore10.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle11.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription11.Text = "Decription : " + deta[indexDeta++];
			lblFrom11.Text = "From : " + deta[indexDeta++];
			lblViews11.Text = "Views : " + deta[indexDeta++];
			lblMore11.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			
			title = deta[indexDeta].Replace(" ",System.Web.HttpUtility.UrlEncode(" "));
			lblTitle12.Text = "Title : <a href=Watch.aspx?Title=" + title +"&From="+deta[indexDeta+2]+"&Categ="+ChangeString(deta[indexDeta+4])+ ">" + deta[indexDeta++] + "</a>";
			lblDecription12.Text = "Decription : " + deta[indexDeta++];
			lblFrom12.Text = "From : " + deta[indexDeta++];
			lblViews12.Text = "Views : " + deta[indexDeta++];
			lblMore12.Text = "More in <a href=Categories.aspx?categ=" + deta[indexDeta] + ">" + deta[indexDeta++] + "</a>";
			



			if(!IsPostBack)
			{

				if((string)Session["user"]== null)
				{
					hylLogout.Visible = false;
					lblLogin.Visible = false;
					HyperLink1.Visible = true;
					HyperLink4.Visible = true;
					HyperLink1.Text = "Sign Up";
					HyperLink1.NavigateUrl = "http://161.246.5.86/WebApplication/sign_up.aspx";
				
				}
				else
				{
					hylLogout.Visible = true;
					lblLogin.Visible = true;
					HyperLink1.Visible = false;
					HyperLink4.Visible = false;
					lblLogin.Text = "Welcome :" + Session["user"].ToString();
				
					//HyperLink1.Enabled = false;
					//HyperLink1.Text = "";
					//HyperLink1.NavigateUrl = "";
					if((string)Session["status"]=="Admin")
					{
						Response.Redirect("admin_login2.aspx",true);
					}
					else if((string)Session["status"]=="User")
					{
						Response.Redirect("user_login.aspx",true);
					}
				}
			}


			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_login_Click(object sender, System.EventArgs e)
		{
			string name;
			string password;
			string status;
			string result;
			string user;

			name = tb_name.Text;
			password = tb_password.Text;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			result = ws.login(name,password);

			if((result=="User"))
			{
				Session["user"]= name;
				Session["password"]= password;
				Session["status"]= result;

				tb_name.Text="";

				/*lblLogin.Visible = true;
				hylLogout.Visible = true;

				Session["status"] = result;
				lblLogin.Text = "Welcome :" + Session["user"].ToString();*/

				Response.Redirect("indexofuser.aspx",true);

			}
			else
			{
				Response.Redirect("index.aspx",true);
				
			}			
		}

		
		
		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			//Response.Write("<script>alert('Hello');</script>") ; 
			//Response.Write("<script>if(!confirm('kkk')){</script>") ; 
			//string msg = "<script language='javascript'>" +
						//"if(!confirm('kkk')){history.go(-1);} " +
						
						
					//"</script>";

			//Response.Write("<script>confirm('kkk')</script>") ; 
			//Label1.Text = "ffff";
			//Response.Write(msg) ; 
			this.PopUpMessege("hello");

			
		}

		private void PopUpMessege(string msg)
		{
			string popupScript = "<script language='javascript'>" +
				"window.alert(msg);</script>";
			Page.RegisterStartupScript("PopupScript", popupScript);
			
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			this.PopUpMessege("hello");
		}


		
		
	}
}
