using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for deleteFile2.
	/// </summary>
	public class deleteFile2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{
				string fileName = Request.QueryString["str1"];
				Label1.Text = fileName;
				
				/*string title = Request.QueryString["str1"];
				string decription = Request.QueryString["str1"];
				string category = Request.QueryString["str1"];
				string user = Request.QueryString["str1"];*/


				string result;

				
				/*string msg = "<script language='javascript'>" +
					"if(!confirm('�س��ͧ���ź�������������')){history.go(-1);} " +
					"else{history.go(-1);} " +
						
						
					"</script>";
				Response.Write(msg) ; */

				/*string msg = "<script language='javascript'>" +
					"if(!confirm('�س��ͧ���ź�������������')){Label1.Text = 'fffff';} " +
					"else{Label1.Text = 'gggggggggggg';} " +
						
						
					"</script>";
				Response.Write(msg) ;*/

				/*string msg2 = "<script language='javascript'>" +
					"else { " +
						
						
					"</script>";
				Response.Write(msg2) ; */

			
			
			
			
				/*WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
				result = ws.deleteFile(fileName,title,decription,category);

				if(result=="deleted successfully")
				{
					if((string)Session["user"]!= null)
					{
						if((string)Session["status"]=="Admin")
						{
							Response.Redirect("admin_login2.aspx",true);
						}
						else if((string)Session["status"]=="User")
						{
							Response.Redirect("user_login.aspx",true);
						}
				
					}
				}*/
			
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
