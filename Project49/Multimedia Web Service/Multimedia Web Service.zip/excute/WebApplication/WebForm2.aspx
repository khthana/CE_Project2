<%@ Page language="c#" Codebehind="WebForm2.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.WebForm2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD id="Head1">
		<title>Multimedia Web Service</title>
	</HEAD>
	<body>
		<form id="form1" runat="server">
			<FONT face="Tahoma"></FONT>
		</form>
	</body>
</HTML>
