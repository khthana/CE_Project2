using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for Watch.
	/// </summary>
	public class Watch : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblTitle;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.Label lblCategory;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			string str13 = "http://161.246.5.86/WebApplication/img/tab_videos_118x28.gif";
			string str14 = "http://161.246.5.86/WebApplication/img/tab_categories_118x28.gif";

			ImageButton1.ImageUrl = str13;
			ImageButton2.ImageUrl = str14;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();

			Application["Title"]=null;
			Application["From"]=null;
			Application["Category"] = null;
			Application["URL"] = null;
			Application["AutoPlay"] = false;
			///HttpServerUtility.UrlTokenEncode
			if (Request.QueryString.Count == 0)
			{
				Application["URL"] = false;

			}
			else if (Request.QueryString.Count == 3)
			{ 
				Application["Title"]=Request.QueryString[0];
				Application["From"] = Request.QueryString[1];
				Application["Category"] = Request.QueryString[2];
				Application["AutoPlay"] = true;

				Application["URL"] = ws.watch(Application[0].ToString(), Application[1].ToString(), Application[2].ToString());

				
				lblTitle.Text = "Title : " + Application[0].ToString();
				
				lblCategory.Text = "Category : " + Application[2].ToString();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ImageButton2.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton2_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("index.aspx",true);
		}

		private void ImageButton2_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("category.aspx",true);
		}
	}
}
