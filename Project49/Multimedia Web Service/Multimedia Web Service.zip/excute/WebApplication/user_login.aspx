<%@ Page language="c#" Codebehind="user_login.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.member" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>User Login</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<table style="Z-INDEX: 101; LEFT: 104px; WIDTH: 368px; POSITION: absolute; TOP: 224px; HEIGHT: 160px">
				<TR>
					<TD align="center"><font face="Microsoft Sans Serif" size="2"><b>��������´�ͧ��Ҫԡ</b></font>
						<asp:datagrid id="dg" runat="server" Width="686px" Height="120px" AutoGenerateColumns="False"
							Font-Names="Microsoft Sans Serif" Font-Size="X-Small" HorizontalAlign="Center">
							<HeaderStyle Font-Size="X-Small" Font-Names="MS Reference Sans Serif" Font-Bold="True" HorizontalAlign="Center"
								VerticalAlign="Middle"></HeaderStyle>
							<Columns>
								<asp:EditCommandColumn ButtonType="LinkButton" UpdateText="Update" CancelText="Cancel" EditText="Edit">
									<HeaderStyle Width="1.5cm"></HeaderStyle>
								</asp:EditCommandColumn>
								<asp:ButtonColumn Text="Delete" CommandName="Delete">
									<HeaderStyle Width="1.5cm"></HeaderStyle>
								</asp:ButtonColumn>
								<asp:BoundColumn DataField="Title" HeaderText="Title">
									<HeaderStyle HorizontalAlign="Center" VerticalAlign="Middle"></HeaderStyle>
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn DataField="Decription" HeaderText="Decription">
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn DataField="Category" HeaderText="Category">
									<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></ItemStyle>
								</asp:BoundColumn>
								<asp:BoundColumn Visible="False" DataField="FileName"></asp:BoundColumn>
							</Columns>
						</asp:datagrid></TD>
				</TR>
			</table>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/memberlogin.swf">
				<PARAM NAME="Src" VALUE="img/memberlogin.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/memberlogin.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<asp:Label id="lblLogin" style="Z-INDEX: 110; LEFT: 368px; POSITION: absolute; TOP: 160px"
				runat="server" Height="16px" Width="134px" Font-Bold="True"></asp:Label>
			<asp:HyperLink id="hylLogout" style="Z-INDEX: 109; LEFT: 784px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="logout.aspx">Log out</asp:HyperLink>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 103; LEFT: 712px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="62px" NavigateUrl="insert.aspx">Insert File</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 105; LEFT: 640px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="myfile.aspx">My File</asp:HyperLink>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 106; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="128px"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 107; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="112px"></asp:ImageButton>
			<HR style="Z-INDEX: 108; LEFT: 104px; WIDTH: 88.99%; POSITION: absolute; TOP: 200px; HEIGHT: 2px"
				width="88.99%" SIZE="2">
		</form>
	</body>
</HTML>
