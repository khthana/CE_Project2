using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebApplication
{
	/// <summary>
	/// Summary description for index2.
	/// </summary>
	public class index2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblFrom1;
		protected System.Web.UI.WebControls.Label lblDecription2;
		protected System.Web.UI.WebControls.Label lblTitle2;
		protected System.Web.UI.WebControls.Label lblDecription1;
		protected System.Web.UI.WebControls.Label lblTitle1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox tb_name;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox tb_password;
		protected System.Web.UI.WebControls.Button bt_login;
		protected System.Web.UI.WebControls.Button btSignUp;
		protected System.Web.UI.WebControls.HyperLink HyperLink3;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Label lblFrom2;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Label lblFrom3;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Label lblFrom4;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Label Label16;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.ImageButton ImageButton2;
		protected System.Web.UI.WebControls.Label lblLogin;
		protected System.Web.UI.WebControls.HyperLink hylLogout;
		protected System.Web.UI.WebControls.Label lblFrom5;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.Label lblFrom6;
		protected System.Web.UI.WebControls.Image Image6;
		protected System.Web.UI.WebControls.Label lblFrom7;
		protected System.Web.UI.WebControls.Image Image7;
		protected System.Web.UI.WebControls.Label lblFrom8;
		protected System.Web.UI.WebControls.Image Image8;
		protected System.Web.UI.WebControls.Label lblViews9;
		protected System.Web.UI.WebControls.Label lblMore9;
		protected System.Web.UI.WebControls.Label lblFrom9;
		protected System.Web.UI.WebControls.Image Image9;
		protected System.Web.UI.WebControls.Label lblFrom10;
		protected System.Web.UI.WebControls.Image Image10;
		protected System.Web.UI.WebControls.Label lblFrom11;
		protected System.Web.UI.WebControls.Image Image11;
		protected System.Web.UI.WebControls.Label lblFrom12;
		protected System.Web.UI.WebControls.Image Image12;
		protected System.Web.UI.WebControls.Label lblTitle3;
		protected System.Web.UI.WebControls.Label lblDecription3;
		protected System.Web.UI.WebControls.Label lblTitle4;
		protected System.Web.UI.WebControls.Label lblDecription4;
		protected System.Web.UI.WebControls.Label lblTitle5;
		protected System.Web.UI.WebControls.Label lblDecription5;
		protected System.Web.UI.WebControls.Label lblTitle6;
		protected System.Web.UI.WebControls.Label lblDecription6;
		protected System.Web.UI.WebControls.Label lblTitle7;
		protected System.Web.UI.WebControls.Label lblDecription7;
		protected System.Web.UI.WebControls.Label lblTitle8;
		protected System.Web.UI.WebControls.Label lblDecription8;
		protected System.Web.UI.WebControls.Label lblTitle9;
		protected System.Web.UI.WebControls.Label lblDecription9;
		protected System.Web.UI.WebControls.Label lblTitle10;
		protected System.Web.UI.WebControls.Label lblDecription10;
		protected System.Web.UI.WebControls.Label lblTitle11;
		protected System.Web.UI.WebControls.Label lblDecription11;
		protected System.Web.UI.WebControls.Label lblTitle12;
		protected System.Web.UI.WebControls.Label lblDecription12;
		protected System.Web.UI.WebControls.Label lblViews1;
		protected System.Web.UI.WebControls.Label lblMore1;
		protected System.Web.UI.WebControls.Label lblViews2;
		protected System.Web.UI.WebControls.Label lblMore2;
		protected System.Web.UI.WebControls.Label lblViews3;
		protected System.Web.UI.WebControls.Label lblMore3;
		protected System.Web.UI.WebControls.Label lblViews4;
		protected System.Web.UI.WebControls.Label lblMore4;
		protected System.Web.UI.WebControls.Label lblViews5;
		protected System.Web.UI.WebControls.Label lblMore5;
		protected System.Web.UI.WebControls.Label lblViews6;
		protected System.Web.UI.WebControls.Label lblMore6;
		protected System.Web.UI.WebControls.Label lblViews7;
		protected System.Web.UI.WebControls.Label lblMore7;
		protected System.Web.UI.WebControls.Label lblViews8;
		protected System.Web.UI.WebControls.Label lblMore8;
		protected System.Web.UI.WebControls.Label lblViews10;
		protected System.Web.UI.WebControls.Label lblMore10;
		protected System.Web.UI.WebControls.Label lblViews11;
		protected System.Web.UI.WebControls.Label lblMore11;
		protected System.Web.UI.WebControls.Label lblViews12;
		protected System.Web.UI.WebControls.Label lblMore12;
		protected System.Web.UI.WebControls.HyperLink HyperLink4;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_login_Click(object sender, System.EventArgs e)
		{
			string name;
			string password;
			string status;
			string result;
			string user;

			name = tb_name.Text;
			password = tb_password.Text;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			result = ws.login(name,password);

			if((result=="User"))
			{
				Session["user"]= name;
				Session["password"]= password;
				Session["status"]= result;

				//lblLogin.Visible = true;
				//hylLogout.Visible = true;

				Session["status"] = result;
				//lblLogin.Text = "Welcome :" + Session["user"].ToString();

			}
			else
			{
				Response.Redirect("index.aspx",true);
				
			}			
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
		
		}
	}
}
