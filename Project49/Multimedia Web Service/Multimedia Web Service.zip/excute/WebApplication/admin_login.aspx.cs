using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using WebApplication.WebReference;

namespace WebApplication
{
	/// <summary>
	/// Summary description for member.
	/// </summary>
	public class member : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.LinkButton LinkButton1;
		protected System.Web.UI.WebControls.LinkButton LinkButton2;
		protected System.Web.UI.WebControls.LinkButton LinkButton3;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid dg;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!IsPostBack)
			{

				this.LoadData();
				
				
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dg.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_CancelCommand);
			this.dg.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_EditCommand);
			this.dg.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_UpdateCommand);
			this.dg.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dg_DeleteCommand);
			this.LinkButton1.Click += new System.EventHandler(this.LinkButton1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
		
		}

		
		private void LoadData()
		{
			Session["status"] = "admin";
			
			DataSet dataSet = new DataSet();

			DataTable dataTable = new DataTable("row"); // row ��͵���觢����Ţͧ���Ъش
			
			dataTable.Columns.Add("Title", typeof(string));
			dataTable.Columns.Add("Decription", typeof(string));
			dataTable.Columns.Add("Category", typeof(string));
			dataTable.Columns.Add("FileName", typeof(string));
			dataTable.Columns.Add("UploadBy", typeof(string));
			
			
			dataSet.Tables.Add(dataTable);

			//string xmlData = "<XmlDS><table1><col1>Value1</col1></table1><table1><col1>Value2</col1></table1></XmlDS>";

			string xmlData = "<root>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<Title>Title1</Title>";
			xmlData = xmlData + "<Decription>Decription1</Decription>";
			xmlData = xmlData + "<Category>Category</Category>";
			xmlData = xmlData + "<UploadBy>UploadBy1</UploadBy>";
			xmlData = xmlData + "<FileName>01.mp3</FileName>";
				
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "<row>";
			xmlData = xmlData + "<Title>Title2</Title>";
			xmlData = xmlData + "<Decription>Decription2</Decription>";
			xmlData = xmlData + "<Category>Category</Category>";
			xmlData = xmlData + "<UploadBy>UploadBy2</UploadBy>";
			xmlData = xmlData + "<FileName>FileName2</FileName>";
				
			xmlData = xmlData + "</row>";
			xmlData = xmlData + "</root>";



			System.IO.StringReader xmlSR = new System.IO.StringReader(xmlData);

			dataSet.ReadXml(xmlSR, XmlReadMode.IgnoreSchema);

			dg.DataSource = dataSet;
			dg.DataBind();

			
		}
		private void dg_DeleteCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			string fileName = e.Item.Cells[6].Text;
			string result;
			
			WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
			result = ws.delete(fileName);

			Label1.Text = result;
			//Label1.Text = fileName;
			
			

		

		}
		private void dg_EditCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			dg.EditItemIndex = e.Item.ItemIndex;
			

			Session["Title"] = e.Item.Cells[2].Text;
			Session["Decription"] = e.Item.Cells[3].Text;
			Session["Category"] = e.Item.Cells[4].Text;
			
			Label1.Text = e.Item.Cells[2].Text;

			this.LoadData();
			

		}
		private void dg_CancelCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
			
			dg.EditItemIndex = -1;
			this.LoadData();
		

		}
		private void dg_UpdateCommand(object sender, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			try
			{
				
				
				TextBox txtTitle = (TextBox)e.Item.Cells[2].Controls[0];
				TextBox txtDecription = (TextBox)e.Item.Cells[3].Controls[0];
				TextBox txtCategory = (TextBox)e.Item.Cells[4].Controls[0];
			
			

				string newTitle = txtTitle.Text;
				string newDecription = txtDecription.Text;
				string newCategory = txtCategory.Text;

				string oldTitle = (string)Session["Title"];
				string oldDecription = (string)Session["Decription"];
				string oldCategory = (string)Session["Category"];

			
				WebApplication.WebReference.Service1 ws = new WebApplication.WebReference.Service1();
			
				string result;

				result = ws.update(oldTitle,oldDecription,oldCategory,newTitle,newDecription,newCategory);
				//Label1.Text = oldTitle + ":" + oldDecription + ":" + oldCategory + ":" + newTitle + ":" + newDecription + ":" + newCategory;
				Label1.Text = result;

			

				dg.EditItemIndex = -1;
				
				this.LoadData();


			}
			catch (Exception ex)
			{
				Label1.Text = ex.ToString();
			}
			
		}

		
	}
}
