<%@ Page language="c#" Codebehind="updateofadmin.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.updateofadmin" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Update file</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"></FONT>
			<asp:label id="lblLogin" style="Z-INDEX: 114; LEFT: 368px; POSITION: absolute; TOP: 160px"
				runat="server" Height="16px" Width="134px" Font-Bold="True"></asp:label>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/adminlogin.swf">
				<PARAM NAME="Src" VALUE="img/adminlogin.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="-1">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/adminlogin.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash" width="769" height="133"> </embed>
			</OBJECT>
			<TABLE id="Table2" style="Z-INDEX: 125; LEFT: 104px; WIDTH: 448px; POSITION: absolute; TOP: 248px; HEIGHT: 336px"
				bgColor="#ccffff">
				<TR>
					<TD style="HEIGHT: 3px" align="right"><FONT face="Microsoft Sans Serif" size="2"><B>Title:</B></FONT>
					</TD>
					<TD style="HEIGHT: 3px"><asp:textbox id="tb_title" runat="server" Height="24px" Width="240px"></asp:textbox></TD>
				</TR>
				<TR>
					<TD style="HEIGHT: 111px" vAlign="top" align="right"><FONT face="Microsoft Sans Serif" size="2"><B>Decription:</B></FONT>
					</TD>
					<TD style="HEIGHT: 111px"><asp:textbox id="tb_decription" runat="server" Height="106px" Width="240px" TextMode="MultiLine"></asp:textbox></TD>
				</TR>
				<TR>
					<TD style="HEIGHT: 143px" vAlign="top" align="right"><FONT face="Microsoft Sans Serif" size="2"><B>Vedeo 
								Category:</B></FONT>
					</TD>
					<TD style="HEIGHT: 143px"><asp:radiobuttonlist id="Category" runat="server" Height="130px" Width="288px" RepeatDirection="Horizontal"
							RepeatColumns="2" Font-Names="Microsoft Sans Serif" Font-Size="X-Small">
							<asp:ListItem Value="Autos&amp;Vehicles" Selected="True">Autos &amp; Vehicles</asp:ListItem>
							<asp:ListItem Value="Comedy">Comedy</asp:ListItem>
							<asp:ListItem Value="Music">Music</asp:ListItem>
							<asp:ListItem Value="People">People</asp:ListItem>
							<asp:ListItem Value="Sports">Sport</asp:ListItem>
							<asp:ListItem Value="News&amp;Bloge">News &amp; Bloge</asp:ListItem>
							<asp:ListItem Value="Entertainment">Entertainment</asp:ListItem>
							<asp:ListItem Value="Arts&amp;Animation">Arts &amp; Animation</asp:ListItem>
							<asp:ListItem Value="Science&amp;Technology">Science &amp; Technology</asp:ListItem>
							<asp:ListItem Value="Travel&amp;Places">Travel &amp; Places  </asp:ListItem>
							<asp:ListItem Value="Video Game">Video Game     </asp:ListItem>
							<asp:ListItem Value="Pets&amp;Animals">Pets &amp; Animals      </asp:ListItem>
						</asp:radiobuttonlist></TD>
				</TR>
				<TR>
					<TD align="right"><FONT face="Microsoft Sans Serif" size="2"><B></B></FONT></TD>
					<TD><FONT face="Tahoma">&nbsp;
							<asp:button id="btnOk" runat="server" Height="29px" Width="96px" Text="OK"></asp:button>&nbsp;&nbsp;</FONT></TD>
				</TR>
			</TABLE>
			<asp:hyperlink id="hylLogout" style="Z-INDEX: 115; LEFT: 768px; POSITION: absolute; TOP: 48px"
				runat="server" Height="16px" Width="54px" NavigateUrl="logout.aspx">Log out</asp:hyperlink>
			<TABLE id="Table1" style="Z-INDEX: 116; LEFT: 552px; POSITION: absolute; TOP: 80px">
				<TR>
					<TD><asp:textbox id="txtSearch" runat="server" Width="192px"></asp:textbox></TD>
					<TD>&nbsp;
						<asp:button id="btSearch" runat="server" Height="24px" Width="56px" Text="Search"></asp:button></TD>
				</TR>
			</TABLE>
			<asp:hyperlink id="HyperLink3" style="Z-INDEX: 117; LEFT: 696px; POSITION: absolute; TOP: 48px"
				runat="server" Height="16px" Width="62px" NavigateUrl="sign_up.aspx">Insert File</asp:hyperlink><asp:hyperlink id="HyperLink2" style="Z-INDEX: 119; LEFT: 624px; POSITION: absolute; TOP: 48px"
				runat="server" Height="8px" Width="60px" NavigateUrl="myfile.aspx">My File</asp:hyperlink>
			<HR style="Z-INDEX: 120; LEFT: 104px; WIDTH: 58.7%; POSITION: absolute; TOP: 200px; HEIGHT: 2px"
				width="58.7%" SIZE="2">
			<asp:imagebutton id="ImageButton1" style="Z-INDEX: 121; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="128px"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 122; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="112px"></asp:imagebutton><asp:label id="Label2" style="Z-INDEX: 123; LEFT: 104px; POSITION: absolute; TOP: 216px" runat="server"
				Height="16px" Width="80px" Font-Bold="True">Update File</asp:label><asp:label id="lblresult" style="Z-INDEX: 124; LEFT: 576px; POSITION: absolute; TOP: 192px"
				runat="server" Height="24px" Width="216px"></asp:label></form>
	</body>
</HTML>
