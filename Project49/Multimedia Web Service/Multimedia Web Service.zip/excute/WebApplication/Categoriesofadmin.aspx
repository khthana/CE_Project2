<%@ Page language="c#" Codebehind="Categoriesofadmin.aspx.cs" AutoEventWireup="false" Inherits="WebApplication.Categoriesofadmin" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Categories</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:label id="lblFrom1" style="Z-INDEX: 106; LEFT: 216px; POSITION: absolute; TOP: 280px"
				runat="server" Height="16px" Width="104px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle2" style="Z-INDEX: 149; LEFT: 216px; POSITION: absolute; TOP: 336px"
				runat="server" Height="22px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle1" style="Z-INDEX: 148; LEFT: 216px; POSITION: absolute; TOP: 216px"
				runat="server" Height="16px" Width="241" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label>
			<asp:hyperlink id="HyperLink3" style="Z-INDEX: 102; LEFT: 704px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="62px" NavigateUrl="insert.aspx">Insert File</asp:hyperlink><asp:hyperlink id="HyperLink1" style="Z-INDEX: 103; LEFT: 504px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="56px" Visible="False" EnableViewState="False">Sign Up</asp:hyperlink><asp:hyperlink id="HyperLink2" style="Z-INDEX: 104; LEFT: 648px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="myfile.aspx">My File</asp:hyperlink><asp:image id="Image1" style="Z-INDEX: 105; LEFT: 104px; POSITION: absolute; TOP: 208px" runat="server"
				Height="96px" Width="98px"></asp:image><asp:label id="lblFrom2" style="Z-INDEX: 107; LEFT: 216px; POSITION: absolute; TOP: 400px"
				runat="server" Height="19" Width="113" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image2" style="Z-INDEX: 108; LEFT: 104px; POSITION: absolute; TOP: 328px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom3" style="Z-INDEX: 109; LEFT: 216px; POSITION: absolute; TOP: 512px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image3" style="Z-INDEX: 110; LEFT: 104px; POSITION: absolute; TOP: 448px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom4" style="Z-INDEX: 112; LEFT: 216px; POSITION: absolute; TOP: 632px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image4" style="Z-INDEX: 113; LEFT: 104px; POSITION: absolute; TOP: 568px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image>
			<HR style="Z-INDEX: 114; LEFT: 104px; WIDTH: 43.94%; POSITION: absolute; TOP: 200px; HEIGHT: 2px"
				width="43.94%" SIZE="2">
			<asp:label id="Label16" style="Z-INDEX: 117; LEFT: 656px; POSITION: absolute; TOP: 96px" runat="server"
				Height="16px" Width="96px">Member Login</asp:label><asp:imagebutton id="ImageButton1" style="Z-INDEX: 118; LEFT: 104px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="128px"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 119; LEFT: 240px; POSITION: absolute; TOP: 152px"
				runat="server" Height="32px" Width="120px"></asp:imagebutton><asp:label id="lblLogin" style="Z-INDEX: 120; LEFT: 376px; POSITION: absolute; TOP: 160px"
				runat="server" Height="16px" Width="134px" Font-Bold="True"></asp:label><asp:hyperlink id="hylLogout" style="Z-INDEX: 121; LEFT: 776px; POSITION: absolute; TOP: 40px"
				runat="server" Height="16px" Width="54px" NavigateUrl="logout.aspx">Log out</asp:hyperlink><asp:label id="lblFrom5" style="Z-INDEX: 123; LEFT: 216px; POSITION: absolute; TOP: 752px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image5" style="Z-INDEX: 124; LEFT: 104px; POSITION: absolute; TOP: 688px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom6" style="Z-INDEX: 126; LEFT: 216px; POSITION: absolute; TOP: 880px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image6" style="Z-INDEX: 127; LEFT: 104px; POSITION: absolute; TOP: 808px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom7" style="Z-INDEX: 129; LEFT: 216px; POSITION: absolute; TOP: 1000px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image7" style="Z-INDEX: 130; LEFT: 104px; POSITION: absolute; TOP: 928px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom8" style="Z-INDEX: 132; LEFT: 216px; POSITION: absolute; TOP: 1112px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image8" style="Z-INDEX: 133; LEFT: 104px; POSITION: absolute; TOP: 1048px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblViews9" style="Z-INDEX: 135; LEFT: 216px; POSITION: absolute; TOP: 1208px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblFrom9" style="Z-INDEX: 137; LEFT: 216px; POSITION: absolute; TOP: 1240px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image9" style="Z-INDEX: 138; LEFT: 104px; POSITION: absolute; TOP: 1168px" runat="server"
				Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom10" style="Z-INDEX: 140; LEFT: 216px; POSITION: absolute; TOP: 1360px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image10" style="Z-INDEX: 141; LEFT: 104px; POSITION: absolute; TOP: 1288px"
				runat="server" Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom11" style="Z-INDEX: 143; LEFT: 216px; POSITION: absolute; TOP: 1480px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image11" style="Z-INDEX: 144; LEFT: 104px; POSITION: absolute; TOP: 1408px"
				runat="server" Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblFrom12" style="Z-INDEX: 146; LEFT: 216px; POSITION: absolute; TOP: 1600px"
				runat="server" Height="19px" Width="113px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:image id="Image12" style="Z-INDEX: 147; LEFT: 104px; POSITION: absolute; TOP: 1528px"
				runat="server" Height="96px" Width="98px" Visible="False"></asp:image><asp:label id="lblTitle3" style="Z-INDEX: 152; LEFT: 216px; POSITION: absolute; TOP: 456px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle4" style="Z-INDEX: 154; LEFT: 216px; POSITION: absolute; TOP: 576px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle5" style="Z-INDEX: 156; LEFT: 216px; POSITION: absolute; TOP: 696px"
				runat="server" Height="6px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle6" style="Z-INDEX: 158; LEFT: 216px; POSITION: absolute; TOP: 816px"
				runat="server" Height="24px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle7" style="Z-INDEX: 160; LEFT: 216px; POSITION: absolute; TOP: 936px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle8" style="Z-INDEX: 162; LEFT: 216px; POSITION: absolute; TOP: 1056px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle9" style="Z-INDEX: 164; LEFT: 216px; POSITION: absolute; TOP: 1184px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle10" style="Z-INDEX: 166; LEFT: 216px; POSITION: absolute; TOP: 1296px"
				runat="server" Height="12px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle11" style="Z-INDEX: 168; LEFT: 216px; POSITION: absolute; TOP: 1416px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblTitle12" style="Z-INDEX: 170; LEFT: 216px; POSITION: absolute; TOP: 1536px"
				runat="server" Height="16px" Width="241px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews1" style="Z-INDEX: 172; LEFT: 216px; POSITION: absolute; TOP: 248px"
				runat="server" Height="22px" Width="88px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews2" style="Z-INDEX: 174; LEFT: 216px; POSITION: absolute; TOP: 368px"
				runat="server" Height="22" Width="89" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews3" style="Z-INDEX: 176; LEFT: 216px; POSITION: absolute; TOP: 480px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews4" style="Z-INDEX: 178; LEFT: 216px; POSITION: absolute; TOP: 600px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews5" style="Z-INDEX: 180; LEFT: 216px; POSITION: absolute; TOP: 720px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews6" style="Z-INDEX: 182; LEFT: 216px; POSITION: absolute; TOP: 848px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews7" style="Z-INDEX: 184; LEFT: 216px; POSITION: absolute; TOP: 968px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews8" style="Z-INDEX: 186; LEFT: 216px; POSITION: absolute; TOP: 1080px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews10" style="Z-INDEX: 188; LEFT: 216px; POSITION: absolute; TOP: 1328px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews11" style="Z-INDEX: 190; LEFT: 216px; POSITION: absolute; TOP: 1448px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:label id="lblViews12" style="Z-INDEX: 192; LEFT: 216px; POSITION: absolute; TOP: 1568px"
				runat="server" Height="22px" Width="89px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif"></asp:label><asp:hyperlink id="HyperLink4" style="Z-INDEX: 194; LEFT: 560px; POSITION: absolute; TOP: 40px"
				runat="server" Height="8px" Width="78px" NavigateUrl="admin_login1.aspx" EnableViewState="False">Admin Login</asp:hyperlink>
			<table>
				<tr>
					<td></td>
				</tr>
			</table>
			<OBJECT style="Z-INDEX: 195; LEFT: 104px; POSITION: absolute; TOP: 8px" codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
				height="133" width="769" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" VIEWASTEXT>
				<PARAM NAME="_cx" VALUE="20346">
				<PARAM NAME="_cy" VALUE="3519">
				<PARAM NAME="FlashVars" VALUE="">
				<PARAM NAME="Movie" VALUE="img/adminlogin.swf">
				<PARAM NAME="Src" VALUE="img/adminlogin.swf">
				<PARAM NAME="WMode" VALUE="Window">
				<PARAM NAME="Play" VALUE="0">
				<PARAM NAME="Loop" VALUE="0">
				<PARAM NAME="Quality" VALUE="High">
				<PARAM NAME="SAlign" VALUE="">
				<PARAM NAME="Menu" VALUE="-1">
				<PARAM NAME="Base" VALUE="">
				<PARAM NAME="AllowScriptAccess" VALUE="always">
				<PARAM NAME="Scale" VALUE="ShowAll">
				<PARAM NAME="DeviceFont" VALUE="0">
				<PARAM NAME="EmbedMovie" VALUE="0">
				<PARAM NAME="BGColor" VALUE="">
				<PARAM NAME="SWRemote" VALUE="">
				<PARAM NAME="MovieData" VALUE="">
				<PARAM NAME="SeamlessTabbing" VALUE="1">
				<PARAM NAME="Profile" VALUE="0">
				<PARAM NAME="ProfileAddress" VALUE="">
				<PARAM NAME="ProfilePort" VALUE="0">
				<PARAM NAME="AllowNetworking" VALUE="all">
				<PARAM NAME="AllowFullScreen" VALUE="false">
				<embed src="img/adminlogin.swf" width="769" height="133" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"
					type="application/x-shockwave-flash"> </embed>
			</OBJECT>
		</form>
	</body>
</HTML>
