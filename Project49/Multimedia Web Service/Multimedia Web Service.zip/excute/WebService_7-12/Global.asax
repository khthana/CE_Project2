<%@ Application Codebehind="Global.asax.cs" Inherits="WebService_7_12.Global" %>
