using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.UI;
using System.Web.Services;
using System.Web.Hosting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;


using WebService_7_12.WebReference;

namespace WebService_7_12
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class Service1 : System.Web.Services.WebService 
	{
		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		private System.Web.Services.Protocols.HttpGetClientProtocol httpGetClientProtocol1;
		private System.Web.UI.HtmlControls.HtmlInputFile up;
		

		


		
			

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.httpGetClientProtocol1 = new System.Web.Services.Protocols.HttpGetClientProtocol();
			// 
			// httpGetClientProtocol1
			// 
			this.httpGetClientProtocol1.Credentials = null;
			this.httpGetClientProtocol1.PreAuthenticate = true;
			this.httpGetClientProtocol1.UnsafeAuthenticatedConnectionSharing = false;
			this.httpGetClientProtocol1.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; MS Web Services Client Protocol 1.1.4322.2300)" +
				"";

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5


		

		[WebMethod]
		public string insert(string address,string ftitle,string fdecription,string user,string category,string insertTime)
		{
			
			// fname,ftitle,fdecription,user,url ���  password  ������ѧ�����������ա���
			string url = "mms://161.246.5.86/multimedia/";
			string strBaseLocation = Server.MapPath("/upload/streamming/");
			
			string fName = System.IO.Path.GetFileName(address);
			bool result;
			

			try 
			{
				

				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				
				result = ws.InsertFile(fName,ftitle,fdecription,user,url,category,insertTime);
				
				if(result)
				{
					//File.Copy(address, strBaseLocation + fName);
					return "success";
				}
				else
				{
					return "no";
				}

				//return fName + ftitle + fdecription + user + url + category + insertTime;
				
			} 
			catch(Exception ex) 
			{
				
				return ex.ToString();
			}

		}

		[WebMethod]
		public string deleteFile(string fileName,string title,string decription,string category)
		{
			
			string strBaseLocation = Server.MapPath("/upload/streamming/");
			bool result;

			try 
			{
				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				result = ws.DeleteFile(title,decription,category);
				if(result)
				{


					System.IO.File.Delete(strBaseLocation+fileName);
					return("deleted successfully");
				}
				else
				{
				
					return("deleted no successfully");
				}
			} 
			catch (Exception ex) 
			{
				return ex.ToString();
			}

		}

		[WebMethod]
		public string delet(string title,string decription,string category)
		{
			
			string strBaseLocation = Server.MapPath("/upload/streamming/");
			bool result;

			try 
			{
				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				result = ws.DeleteFile(title,decription,category);
				if(result)
				{


					//System.IO.File.Delete(strBaseLocation+fileName);
					return("deleted successfully");
				}
				else
				{
				
					return("deleted no successfully");
				}
			} 
			catch (Exception ex) 
			{
				return ex.ToString();
			}

		}

		[WebMethod]
		public bool updateFile(string oldTitle,string oldDecription,string oldCategory,string newTitle,string newDecription,string newCategory)
		{
			bool result=false;
			

			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
			
			try 
			{
				result = ws.UpdateFile(oldTitle,newTitle,oldDecription,newDecription,oldCategory,newCategory);	
			}
			catch
			{
				
			}
			
			return result;
			
			

		}

		[WebMethod]
		public string createStatus(string UserName,string status)
		{
			
			try 
			{
				
				return UserName + ":" + status;
				
				
				
			} 
			catch (Exception ex) 
			{
				return ex.ToString();
			}

		}

		[WebMethod]
		public string[] category(string typecategory)
		{
			string[] resultservice=null;
			try 
			{
				
				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				resultservice = ws.CategoryPage(typecategory);
				
				
			} 
			catch (Exception ex) 
			{
				//return ex.ToString();
			}

			return resultservice;

		}

		[WebMethod]
		public string showFileOfAdmin()
		{
			string[] result=null;
			string str="<root>";
			int number;
			string strtemp;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				
			

			try 
			{
				
				result = ws.ShowFileForAdmin();
				number = result.Length;
				number = number/5;
				
				for(int i=0;i < number;i++)
				
				{
					str = str + "<row>";

					str = str + "<Title>" + result[i] + "</Title>";; 
					str = str + "<Decription>" + result[i + number] + "</Decription>";
					strtemp = result[i + (number * 2)];
					strtemp = strtemp.Replace("&","&amp;");
					str = str + "<Category>" + strtemp + "</Category>" ;
					str = str + "<UploadBy>" + result[i + (number * 3)] + "</UploadBy>";
					str = str + "<FileName>" + result[i + (number * 4)] + "</FileName>";
					
					str = str + "</row>";

				}
					
				
				return str;
				
			} 
			catch (Exception ee) 
			{
				return ee.ToString();
				
			}

		}

		[WebMethod]
		public string showFileOfUser(string username)
		{
			string[] result=null;
			string str="<root>";
			int number;
			string strtemp;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				
			

			try 
			{
				
				result = ws.ShowFileByUserName(username);
				number = result.Length;
				number = number/4;
				
				for(int i=0;i < number;i++)
				
				{
					str = str + "<row>";

					str = str + "<Title>" + result[i] + "</Title>";; 
					str = str + "<Decription>" + result[i + number] + "</Decription>";
					strtemp = result[i + (number * 2)];
					strtemp = strtemp.Replace("&","&amp;");
					str = str + "<Category>" + strtemp + "</Category>" ;
					str = str + "<FileName>" + result[i + (number * 3)] + "</FileName>";
					
					str = str + "</row>";

				}
					
				
				return str;
				
			} 
			catch (Exception ee) 
			{
				return ee.ToString();
				
			}

		}



		[WebMethod]
		public string login(string userName,string passWord)
		{
			
			string result;
			string status="";  // ���������¡ service
			try 
			{
				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				status = ws.Login(userName,passWord);
				
				return status;
			} 
			catch (Exception ex) 
			{
				return ex.ToString();
			}

		}



		
		[WebMethod]
		public bool register(string username,string password,string status,string email,string country,string gender,string day,string month,string year)
		{
			bool result=false;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
			

			try 
			{
				result = ws.InsertUser(email,username,password,country,gender,day,month,year,status);
				
				
				if(result) 
				{
					return true;
				}
				else 
				{
					return false;
				}
				//return  username + ":" +  password + ":" + status + ":" + email + ":" + country + ":" + gender + ":" + day + ":" + month + ":" + year;
			} 
			catch (Exception ex) 
			{
				return false;
				//return ex.ToString();
			}
		}

	
		[WebMethod]
		public string[] showFile()
		{
			string[] result=null;
			int number;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();

			try 
			{
				result = ws.ShowFileForAdmin();
				number = result.Length;
				number = number/4;
				
				for(int i=0;i < number;i++)
					//for(int i=0;i < 1;i++)
				{
					/*str = str + "<row>";

					str = str + "<Title>" + result[i] + "</Title>";; 
					str = str + "<Decription>" + result[i + number] + "</Decription>";
					str = str + "<Category>" + result[i + (number * 2)] + "</Category>" ;
					str = str + "<FileName>" + result[i + (number * 3)] + "</FileName>";
					
					str = str + "</row>";*/


					/*str = str + "<row>";
					str = str + "<Title>";
					
					str = str + result[i];
					str = str + "</Title>";
					
					str = str + "<Decription>";
					str = str + result[i + number];
					str = str + "</Decription>";
					
					str = str + "<Category>";
					str = str + result[i + number*2];
					str = str + "</Category>";
					str = str + "</row>";*/
					
					
				}

				
				
				//str = str + "</root>";
				
				
				//return str;
				return result;
			} 
			catch (Exception ee) 
			{
				//return ee.ToString();
				return result;
			}
		}

		[WebMethod]
		public string deleteuser(string username,string status)
		{
			bool result=false;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();

			try 
			{
				
				result = ws.DeleteUser(username,status);
				
				if(result) 
				{
					return "success";
				}
				else 
				{
					return "no success";
				}
			} 
			catch (Exception ee) 
			{
				return ee.ToString();
			}
		}

		[WebMethod]
		public string updateUser(string username)
		{
			bool result=false;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();

			try 
			{
				
				result = ws.UpdateUserToAdmin(username);
				
				if(result) 
				{
					return "success";
				}
				else 
				{
					return "no success";
				}
			} 
			catch (Exception ee) 
			{
				return ee.ToString();
			}
		}


		[WebMethod]
		public string testinsert()
		{
			string url = "mms://161.246.5.86/multimedia/";
			string strBaseLocation = Server.MapPath("/upload/streamming/");
			
			string fName = "filename";
			string ftitle = "title1";
			string fdecription = "decription";
			string user = "torrik";
			string category = "category";
			string insertTime = "20-01-50";


			bool result;
			

			try 
			{
				

				WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				
				result = ws.InsertFile(fName,ftitle,fdecription,user,url,category,insertTime);
				
				if(result)
				{
					
					return "success";
				}
				else
				{
					return "no";
				}
				
			} 
			catch(Exception ex) 
			{
				
				return ex.ToString();
			}
		}

		[WebMethod]
		public string[] firstPage()
		{
			string[] result=null;
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
			result = ws.FirstPageBeta();
			
			return result;
			
		}

		[WebMethod]
		public string[] firstPage2()
		{
			string[] result=null;
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
			result = ws.FirstPageBravo();
			
			return result;
			
		}
		
		[WebMethod]
		public string watch(string title,string from,string category)
		{
			string result=null;
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
			result = ws.WatchPage(title,from,category);;
			
			return result;
			
		}

		[WebMethod]
		public string showuser()
		{
			//string[] result={"komson","torrik","vanlop","user","user","admin"};
			string[] result;
			string str="<root>";
			int number;
			
			
			WebService_7_12.WebReference.Service1 ws = new WebService_7_12.WebReference.Service1();
				
			

			try 
			{
				
				result = ws.SelectUSER();
				number = result.Length;
				number = number/2;
				
				for(int i=0;i < number;i++)
				{
					str = str + "<row>";
					str = str + "<UserName>";
					
					str = str + result[i];
					str = str + "</UserName>";
					str = str + "<Status>";
					str = str + result[i + number];
					str = str + "</Status>";
					str = str + "</row>";
					
					
				}

				
				
				str = str + "</root>";
				
				
				return str;
			} 
			catch (Exception ee) 
			{
				return ee.ToString();
				//return result;
			}
		}
	}
}
