function newLecturer(){
	xajax.$('newlec').innerHTML=""+
	"<table border='1' width='765px' style='font-size:12px;'>"+
		"<tr ><td colspan='2' background='../images/td_tile.gif' style='padding:5px;'><b>ข้อมูลบุคลากรประจำภาควิชาวิศวกรรมคอมพิวเตอร์</b></td></tr>"+
		"<tr ><td><b>รูป</b></td><td>"+
			"<iframe src='./upload.php' scrolling='No' frameBorder='NO' height='260px'></iframe>"+
			
			"</td>"+
		"</tr>"+
		"<tr>"+
			"<td><b>ชื่อ-นามสกุล</b></td>"+
			"<td>"+
				"<select id='tcaption'>"+
				"<option value='ศ.' selected>ศ."+
				"<option value='รศ.ดร.' selected>รศ.ดร."+
				"<option value='รศ.'>รศ."+
				"<option value='ผศ.ดร.'>ผศ.ดร."+
				"<option value='ผศ.'>ผศ."+
				"<option value='ดร.'>ดร."+
				"<option value='อ.'>อ."+
				"<option value='นาย'>นาย"+
				"<option value='นาง'>นาง"+
				"<option value='นางสาว'>นางสาว"+
				"</select>"+
				" <b>ชื่อ</b> <input type='text' id='tname' style='width:200px;'> <b>นามสกุล</b> <input type='text' id='tsername' style='width:200px;'>"+
			"</td>"+
		"</tr>"+
		"<tr><td><b>อีเมล์</b></td><td><input type='text' id='temail' ></td></tr>"+
		"<tr><td><b>เบอร์โทรศัพท์</b></td><td><input type='text' id='tphone' ></td></tr>"+
		"<tr><td><b>เว็บไซด์</b></td><td><input type='text' id='tlink' ></td></tr>"+
		"<tr>"+
			"<td><b>ตำแหน่ง/หน้าที่</b></td>"+
			"<td>"+
				"<select id='tposition'>"+
					"<option value='หัวหน้าภาควิชา' selected>หัวหน้าภาควิชา"+
					"<option value='เลขานุการภาค'>เลขานุการภาค"+
					"<option value='คณาจารย์'>คณาจารย์"+
					"<option value='เจ้าหน้าที่'>เจ้าหน้าที่"+
				"</select>"+
			"</td>"+
		"</tr>"+
		"<tr><td><b>ประวัติการศึกษา</b></td><td><textarea id='teducational' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>สอนในระดับ</b></td>"+
		"<td><input type='checkbox' id='tteach1' style='width:20px;'>ปริญญาตรี"+
		"<input type='checkbox' id='tteach2' style='width:20px;'>ปริญญาโท"+
		"<input type='checkbox' id='tteach3' style='width:20px;'>ปริญญาเอก</td></tr>"+
		"<tr><td><b>ภาระงานสอน</b></td><td><textarea id='ttimetable' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>เวลาพบนักศึกษา</b></td><td><textarea id='tconsult' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>ประสบการณ์</b></td><td><textarea id='texperience' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>ที่อยู่</b></td><td><textarea id='taddress' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>งานวิจัย</b></td><td><textarea id='treserch' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td><b>ผลงานทางวิชาการ</b></td><td><textarea id='texpertise' rows='3' cols='80'></textarea></td></tr>"+
		"<tr><td colspan='2' background='../images/td_tile.gif' style='padding:5px;'><a href='javascript:submitNewLecturer();'><img src='../images/Button/submit.gif' border='0' alt=''></a></td></tr>"+
	"</table>";
}

function submitNewLecturer(){
	var strteach="";
	if(xajax.$('tteach1').checked)
		strteach+="ปริญญาตรี,";
	if(xajax.$('tteach2').checked)
		strteach+="ปริญญาโท,";
	if(xajax.$('tteach3').checked)
		strteach+="ปริญญาเอก";
	xajax_submitNewLecturer(xajax.$('tcaption').value,xajax.$('tname').value,xajax.$('tsername').value,xajax.$('temail').value,xajax.$('tphone').value,xajax.$('tlink').value,xajax.$('tposition').value,xajax.$('teducational').value,strteach,xajax.$('ttimetable').value,xajax.$('tconsult').value,xajax.$('texperience').value,xajax.$('taddress').value,xajax.$('treserch').value,xajax.$('texpertise').value);
		

}