<?php
	require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	require_once("../tool/xajax/xajax.inc.php");
	require_once("./checklogin.inc.php");
	//require_once("./newlecturer.inc.php");
	//สร้าง code สำหรับแบ่งหน้าในการแสดง
	
	function submitNewLecturer($caption,$name,$sername,$email,$phone,$link,$position,$educational,$teach,$timetable,$consult,$experience,$address,$reserch,$expertise){
		
		
		global $dbname,$tb_lecturer,$tb_useraccount;
		$objResponse = new xajaxResponse();
		
		$sql="INSERT INTO $tb_useraccount ";
		$sql.="(USER_NAME,PASSWORD,SALT) ";
		$sql.="VALUES (CONCAT('lecturer',(SELECT MAX(LECTURER_ID+1) FROM $tb_lecturer)),'lecturer','lecturer')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			
		}
		else
			$objResponse->addAlert(mysql_error());


		
		$sql="INSERT INTO $tb_lecturer ";
		$sql.="( `USER_ID` , `POSITION` , `NAME` , `SERNAME` , `CAPTION` ,  `PHONE_OFFICE` , ";
		$sql.="`EMAIL` , `CLASS` , `ADDRESS` , `EDUCATIONAL` , `TIMETABLE` , `CONSULT` , `EXPERIENCE` , `EXPERTISE` , ";
		$sql.="`LINK` , `RESEARCH` ) ";
		$sql.="VALUES ( (SELECT MAX(USER_ID) FROM $tb_useraccount), '$position', '$name', '$sername', '$caption', '$phone', '$email', '$teach', '$address', '$educational',";
		$sql.="'$timetable', '$consult', '$experience', '$expertise', '$link', '$reserch')";
		
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$objResponse->addRedirect("./");
		}
		else
			$objResponse->addAlert(mysql_error());
			
		return $objResponse;
	}
	
	
	function checkpage($allnum,$pagepernum,$to1,$to2){
		$return="";
		$count=1;
		while($allnum>0){
			$return.="<a href='$to1$count$to2'>$count</a> ";
			$allnum-=$pagepernum;
			$count++;
		}
		return $return;
	}
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");
	$xajax->registerFunction("submitNewLecturer");
	$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
	  <title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="index.css" rel="stylesheet" type="text/css">
		<script language="javascript" type="text/javascript" src="../tool/cookies.js"></script>
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="./newlecturer.js"></script>
		<?php $xajax->printJavascript('../tool/xajax/'); ?>
	</head>

	<body >
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="../images/logo.gif" ></p>
		<center>
			<div style='text-align:center;width:765px;'>
				<!-- menu -->
				<div class="menu" >
					<li id="six"><a href='../'>หน้าแรก</a></li>
					<li id="one"><a href='../subject/' target='_blank'>หลักสูตร</a></li>
					<li id="two"><a href='./' target='_blank'>บุคลากร</a></li>
					<li id="three"><a href='../laboratory/' target='_blank'>ห้องวิจัย</a></li>
					<li id="four"><a href='../webboard/' target='_blank'>เว็บบอร์ด</a></li>
					<li id="five"><a href='../alumni/' target='_blank'>ศิษย์เก่า</a></li>
					<li id="last"><a href='../user_management/showlist_member.php' target='_blank'>สมาชิก</a></li>
				</div>
				<div style="width:765px;">
					<!-- logo -->
					<div ><img  src="../images/CE.png" style='float:left;border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'>
					</div>
					<!-- login -->
					<div class='login'>
						<?php checkLogin();?>
					</div>
				</div>


				<div style="float:left;width:765px;text-align:left;">
					<font face="Angsana New" color="#0066FF" style="font-size: 16pt"><b>บุคลากรภาควิชาวิศวกรรมคอมพิวเตอร์</b></font><br>
					<div id='newlec' align='center'>
						<?php
						if($_SESSION['ss_Level']=='admin')
							echo "<a href='javascript:newLecturer();'><img src='../images/Button/add.gif' border='0' alt='เพิ่มอาจารย์หรือเจ้าหน้าที่'></a>";
						?>
					</div>
					<div>
						<table border='1' width='765px'>
						<tr >
							<td colspan="4" class='position'>หัวหน้าภาควิชา</td>
						</tr>
						<?php
						$sql="SELECT * FROM $tb_lecturer WHERE `POSITION` = 'หัวหน้าภาควิชา' LIMIT 1";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						if($dbquery=mysql_db_query($dbname,$sql)){
							while($result=mysql_fetch_array($dbquery)){
								echo "
									<tr >
										<td colspan='4'>
											<table>
											<tr class='positiondetail'>
												<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
												<td>
													<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
													<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
													<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
													<b>ที่อยู่ :</b> $result[ADDRESS]<br>
													<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
												</td>
											</tr>
											</table>
										</td>
									</tr>";
							}
						}
						?>
						<tr >
							<td colspan='4' class='position'>เลขานุการ</td>
						</tr>
						<?php
						$sql="SELECT * FROM $tb_lecturer WHERE `POSITION` = 'เลขานุการภาค' LIMIT 1";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						if($dbquery=mysql_db_query($dbname,$sql)){
							while($result=mysql_fetch_array($dbquery)){
								echo "
									<tr >
										<td colspan='4'>
											<table>
											<tr class='positiondetail' >
												<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
												<td>
													<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
													<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
													<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
													<b>ที่อยู่ :</b> $result[ADDRESS]<br>
													<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
												</td>
											</tr>
											</table>
										</td>
									</tr>";
							}
						}
						?>
						<tr >
							<td colspan='4' class='position'>คณาจารย์</td>
						</tr>
						<?php
						$sql="SELECT * FROM $tb_lecturer WHERE `POSITION` = 'คณาจารย์'";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						if($dbquery=mysql_db_query($dbname,$sql)){
							$countrow=0;
							while($result=mysql_fetch_array($dbquery)){
								if($countrow%2==0){
								echo "
									<tr class='positiondetail' >
									<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
									<td>
										<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
										<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
										<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
										<b>ที่อยู่ :</b> $result[ADDRESS]<br>
										<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
									</td>";
								}
								else{
									echo "
									<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
									<td >
										<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
										<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
										<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
										<b>ที่อยู่ :</b> $result[ADDRESS]<br>
										<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
									</td>
								</tr>";
									
								}
							$countrow++;
							}
						
						}
						?>
						<tr >
							<td colspan='4' class='position'>เจ้าหน้าที่</td>
						</tr>
						<?php
						$sql="SELECT * FROM $tb_lecturer WHERE `POSITION` = 'เจ้าหน้าที่'";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						if($dbquery=mysql_db_query($dbname,$sql)){
							$countrow=0;
							while($result=mysql_fetch_array($dbquery)){
								if($countrow%2==0){
								echo "
									<tr class='positiondetail' >
									<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
									<td >
										<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
										<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
										<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
										<b>ที่อยู่ :</b> $result[ADDRESS]<br>
										<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
									</td>";
								}
								else{
									echo "
									<td width='120px'>
													<a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>";
													if(is_file("./picture/lecturer$result[LECTURER_ID].gif"))
														echo "<img src='./picture/lecturer$result[LECTURER_ID].gif' border='0' width='120' height='160' alt=''>";
													else
														echo "<img src='./picture/nopic.gif' border='0' width='120' height='160' alt=''>";
										echo "</td>
									<td >
										<b>ชื่อ-นามสกุล : </b><a href='./lecturerdetail.php?lec_id=$result[LECTURER_ID]'>$result[CAPTION] $result[NAME] $result[SERNAME]</a><br>
										<b>อีเมล์ :</b> <a href='mailto:$result[EMAIL]'>$result[EMAIL]</a><br>
										<b>เว็บไซด์ :</b> <a href='http://$result[LINK]' target='_blank'>$result[LINK]</a><br>
										<b>ที่อยูู่๋ :</b> $result[ADDRESS]<br>
										<b>โทรศัพท์ :</b> $result[PHONE_OFFICE]<br>
									</td>
								</tr>";
									
								}
							$countrow++;
							}
						}
						?>
						</table><hr>
					</div>
				</div><br><br>
			</div>
			<div style="width:765px;float:left;" >
				<font color="#666666">Department of Computer Engineering Faculty of Engineering King Mongkut's 
					Institute of Technology<br>
					Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404<br>
					<span lang="th">ส่งคำติชม</span>
				</font><a href="mailto:webmaster@ce.kmitl.ac.th">webmaster@ce.kmitl.ac.th</a>
			</div>
		</center>
	</body>
</html>