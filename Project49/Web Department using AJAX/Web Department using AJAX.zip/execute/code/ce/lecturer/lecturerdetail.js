function editLecturerDetail(lec_id){
	xajax.$('lecpicture').innerHTML=""+
		"<iframe src='./upload.php?lec_id="+lec_id+"' frameBorder='NO' height='260px' scrolling='No'>"+
		"</iframe>";
	xajax.$('lemail').innerHTML="<input type='text' id='temail' value='"+xajax.$('lemail').firstChild.innerHTML+"'>";
	xajax.$('lphone').innerHTML="<input type='text'  id='tphone' value='"+xajax.$('lphone').innerHTML+"'>";
	xajax.$('llink').innerHTML="<input type='text' id='tlink' value='"+xajax.$('llink').firstChild.innerHTML+"'>";
	
	var tmpstr="<select id='tposition'>"+
						"<option value='หัวหน้าภาควิชา' selected>หัวหน้าภาควิชา"+
						"<option value='เลขานุการภาค' >เลขานุการภาค"+
						"<option value='คณาจารย์'>คณาจารย์"+
						"<option value='เจ้าหน้าที่'>เจ้าหน้าที่"+
					"</select>";
	var tmpselect=xajax.$('lposition').innerHTML;
	xajax.$('lposition').innerHTML=tmpstr;
	xajax.$('tposition').value=tmpselect;
	
	xajax.$('leducational').innerHTML="<textarea id='teducational' rows='3' cols='80'>"+xajax.$('leducational').innerText+"</textarea>";
	
	tmpstr="";
	var tmpteach=xajax.$('lteach').innerHTML;
	if(tmpteach.search(/ปริญญาตรี/)>=0)
		tmpstr=tmpstr+"<input style='width:20px' id='chte1' type='checkbox' checked>ปริญญาตรี";
	else
		tmpstr=tmpstr+"<input style='width:20px' id='chte1' type='checkbox' >ปริญญาตรี";
	if(tmpteach.search(/ปริญญาโท/)>=0)
		tmpstr=tmpstr+"<input style='width:20px' id='chte2' type='checkbox' checked>ปริญญาโท";
	else
		tmpstr=tmpstr+"<input style='width:20px' id='chte2' type='checkbox' >ปริญญาโท";
	if(tmpteach.search(/ปริญญาเอก/)>=0)
		tmpstr=tmpstr+"<input style='width:20px' id='chte3' type='checkbox' checked>ปริญญาเอก";
	else
		tmpstr=tmpstr+"<input style='width:20px' id='chte3' type='checkbox' >ปริญญาเอก";
	xajax.$('lteach').innerHTML=tmpstr;
	
	xajax.$('ltimetable').innerHTML="<textarea id='ttimetable' rows='3' cols='80'>"+xajax.$('ltimetable').innerText+"</textarea>";
	xajax.$('lconsult').innerHTML="<textarea id='tconsult' rows='3' cols='80'>"+xajax.$('lconsult').innerText+"</textarea>";
	xajax.$('lexperience').innerHTML="<textarea id='texperience' rows='3' cols='80'>"+xajax.$('lexperience').innerText+"</textarea>";
	xajax.$('laddress').innerHTML="<textarea id='taddress' rows='3' cols='80'>"+xajax.$('laddress').innerText+"</textarea>";
	xajax.$('lreserch').innerHTML="<textarea id='treserch' rows='3' cols='80'>"+xajax.$('lreserch').innerText+"</textarea>";
	xajax.$('lexpertise').innerHTML="<textarea id='texpertise' rows='3' cols='80'>"+xajax.$('lexpertise').innerText+"</textarea>";
	xajax.$('buttonaction').innerHTML="<a href='javascript:void submitEditLecturerDetail("+lec_id+");'><img src='../images/Button/submit.gif' border='0' alt=''></a>";
}

function submitEditLecturerDetail(lec_id){
	var tmpstr="";
	if(xajax.$('chte1').checked)
		tmpstr+="ปริญญาตรี";
	if(xajax.$('chte2').checked)
		tmpstr+=",ปริญญาโท";
	if(xajax.$('chte3').checked)
		tmpstr+=",ปริญญาเอก";

	xajax_submitEditLecturerDetail(lec_id,xajax.$('temail').value,xajax.$('tphone').value,xajax.$('tlink').value,xajax.$('tposition').value,xajax.$('teducational').value,tmpstr,xajax.$('ttimetable').value,xajax.$('tconsult').value,xajax.$('texperience').value,xajax.$('taddress').value,xajax.$('treserch').value,xajax.$('texpertise').value);
		

	
	xajax.$('lemail').innerHTML="<a href='mailto:"+xajax.$('temail').value+"'>"+xajax.$('temail').value+"</a>";
	xajax.$('lphone').innerHTML=xajax.$('tphone').value;
	var chlink=xajax.$('tlink').value;
	chlink=chlink.replace(/http:\/\//,"");
	xajax.$('llink').innerHTML="<a href='http://"+chlink+"'>"+chlink+"</a>";
	xajax.$('lposition').innerHTML=xajax.$('tposition').value;
	xajax.$('leducational').innerHTML="<pre>"+xajax.$('teducational').value+"</pre>";
	xajax.$('lteach').innerHTML=tmpstr;
	
	//xajax.$('llab').innerHTML=xajax.$('tlab').value;
	xajax.$('ltimetable').innerHTML="<pre>"+xajax.$('ttimetable').value+"</pre>";
	xajax.$('lconsult').innerHTML="<pre>"+xajax.$('tconsult').value+"</pre>";
	xajax.$('lexperience').innerHTML="<pre>"+xajax.$('texperience').value+"</pre>";
	xajax.$('laddress').innerHTML="<pre>"+xajax.$('taddress').value+"</pre>";
	xajax.$('lreserch').innerHTML="<pre>"+xajax.$('treserch').value+"</pre";
	xajax.$('lexpertise').innerHTML="<pre>"+xajax.$('texpertise').value+"</pre>";
	xajax.$('buttonaction').innerHTML="<a href='javascript:void editLecturerDetail("+lec_id+");'><img src='../images/Button/edit.gif' border='0' alt=''></a>";
	
}
