<?php
	function submitEditLecturerDetail($lec_id,$email,$phone,$link,$position,$educational,$teach,$timetable,$consult,$experience,$address,$reserch,$expertise){
		global $dbname,$tb_lecturer;
		$objResponse = new xajaxResponse();

		$sql="UPDATE $tb_lecturer SET `EMAIL` = '$email',`PHONE_OFFICE` = '$phone',`LINK` = '$link' ,";
		$sql.="`POSITION` = '$position' , `EDUCATIONAL` = '$educational' ,`TIMETABLE`= '$timetable', ";
		$sql.="`CONSULT` = '$consult' , `EXPERIENCE` = '$experience' ,`RESEARCH`='$reserch' ,";
		$sql.="`CLASS`='$teach',`EXPERTISE` = '$expertise' ,`ADDRESS` ='$address'  ";
		$sql.="WHERE `LECTURER_ID` ='$lec_id' LIMIT 1 ";
		
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$picfile="./picture/lecturer$lec_id.gif";
			if(is_file($picfile))
				$objResponse->addAssign("lecpicture","innerHTML","<img src='$picfile' border='1' width='120' height='160' alt=''>");
			else
				$objResponse->addAssign("lecpicture","innerHTML","<img src='./picture/nopic.gif' border='1' width='120' height='160' alt=''>");
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อยแล้ว");
		}
		else
			$objResponse->addAlert("ไม่สำเร็จ");
		return $objResponse;
	}

?>