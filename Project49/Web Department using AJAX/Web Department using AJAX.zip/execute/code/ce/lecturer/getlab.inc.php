﻿<?php
	function getLab($lab_id){
		global $dbname,$tb_laboratory;
		$objResponse = new xajaxResponse();
		$sql="SELECT LAB_ID,NAME FROM $tb_laboratory";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<select id='tlab'>";
			while($result=mysql_fetch_array($dbquery)){
				if($lab_id==$result['LAB_ID'])
					$return.="<option value='$result[LAB_ID]' selected>$result[NAME]";
				else
					$return.="<option value='$result[LAB_ID]'>$result[NAME]";
			}
			$return.="</select>";
			$objResponse->addAssign("llab","innerHTML",$return);
		}
		else
			$objResponse->addAlert($sql);
		return $objResponse;
	}
	
?>