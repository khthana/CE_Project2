<?php
	//require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	//require_once("../tool/xajax/xajax.inc.php");
	//require_once("../checklogin.inc.php");
	if(!isset($lec_id)){
		$sql="SELECT MAX(LECTURER_ID+1) AS MAXID FROM $tb_lecturer";
		$dbquery=mysql_db_query($dbname,$sql);
		$result=mysql_fetch_array($dbquery);
		$lec_id=$result['MAXID'];
	}

	if($_FILES){
				$tmpfile=$_FILES['gfile']['tmp_name'];
				$filename=$_FILES['gfile']['name'];
				$filesize=$_FILES['gfile']['size'];
				
				$fileinfo=pathinfo("./file/".$_FILES['gfile']['name']);
				
				//if($fileinfo['extension']=="xls"){
					if (copy($tmpfile,"./picture/lecturer$lec_id.gif")) {
						
						
					}
					else
						echo "failed copy $tmpfile to $filepath...\n";
			}
?>
<html>
	<head>
		<title>Upload Progress</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="./index.css" />
		<script type="text/javascript" src="../tool/cookies.js"></script>
	</head>
	<body class='site'>
		<form  enctype="multipart/form-data" method="post" action='upload.php?lec_id=<?php echo $lec_id;?>' >
			<div>
				<?php 
					if(is_file("./picture/lecturer$lec_id.gif"))
						echo"<img src='./picture/lecturer$lec_id.gif' border='1' width='120' height='160' alt=''>";
					else
						echo"<img src='./picture/nopic.gif' border='1' alt=''>";
					?>
				<fieldset >
					<legend>เปลี่ยนรูป</legend>
					<input id="filename" type="file" name="gfile" />
					<input type="submit" value="upload" />
				</fieldset>
			</div>
			<div id="fileprogress"><?php if($_FILES) echo "upload เรียบร้อยแล้ว";?></div>
			<pre style="font-weight: bold;">
			</pre>
		</form>
	</body>
</html>