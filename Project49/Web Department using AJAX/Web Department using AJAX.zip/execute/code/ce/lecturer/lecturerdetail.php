<?php
	require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	require_once("../tool/xajax/xajax.inc.php");
	require_once("./lecturerdetail.inc.php");
	require_once("./checklogin.inc.php");
	//require_once("./getlab.inc.php");
	
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");
	$xajax->registerFunction("submitEditLecturerDetail");
	//$xajax->registerFunction("getLab");
	//$xajax->registerFunction("refreshpicture");
	$xajax->processRequests();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		
		<script language="javascript" type="text/javascript" src="../tool/cookies.js"></script>
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="./lecturerdetail.js"></script>
		<?php $xajax->printJavascript('../tool/xajax/'); ?>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="index.css" rel="stylesheet" type="text/css">
		<title>Lecture Detail CE KMITL</title>
		
	</head>
	<body>
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="../images/logo.gif" ></p>
		<center>
			<!-- menu -->
			<div style='text-align:center;width:765px;'>
				<div class="menu" >
					<li id="six"><a href='../'>หน้าแรก</a></li>
					<li id="one"><a href='../subject/' target='_blank'>หลักสูตร</a></li>
					<li id="two"><a href='./index.php' target='_blank'>บุคลากร</a></li>
					<li id="three"><a href='../laboratory/' target='_blank'>ห้องวิจัย</a></li>
					<li id="four"><a href='../webboard/' target='_blank'>เว็บบอร์ด</a></li>
					<li id="five"><a href='../alumni/' target='_blank'>ศิษย์เก่า</a></li>
					<li id="last"><a href='../user_management/showlist_member.php' target='_blank'>สมาชิก</a></li>
				</div>
				<div style="width:765px;">
					<!-- logo -->
					<div ><img  src="../images/CE.png" style='float:left;border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'>
					</div>
					<!-- login -->
					<div class='login'>
						<?php checkLogin();?>
					</div>
				</div>
				<?php
					$sql="SELECT lc.*,lb.NAME AS LABNAME ,lb.LAB_ID ";
					$sql.="FROM $tb_lecturer lc,$tb_laboratory_member lm,$tb_laboratory lb ";
					$sql.="WHERE lc.LECTURER_ID='$lec_id' AND lc.USER_ID = lm.USER_ID AND lm.LAB_ID = lb.LAB_ID";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$lablink="";
						while($result=mysql_fetch_array($dbquery)){
							$lablink.="<a href='../laboratory/index.php?labid=$result[LAB_ID]'>$result[LABNAME]</a> <br>";
						}
						$lablink.="<a href='../laboratory/index.php?lecid=$lec_id'>หัวข้อโปรเจ็คที่ดูแล</a>";
					}
					
					$sql="SELECT * ";
					$sql.="FROM $tb_lecturer ";
					$sql.="WHERE LECTURER_ID='$lec_id' ";
					if($dbquery=mysql_db_query($dbname,$sql)){
						while($result=mysql_fetch_array($dbquery)){
				?>

				<div class='mainpage'>
					<div style="float:left;width:765px;text-align:left;">
						<table width="765px" border="1" style='text-align:left;background: url("../images/leftbg.gif");font-size:12px;' cellpadding='0' cellspacing='0'>
							<tr>
								<th colspan="2" scope="col" align='center' background='../images/td_tile.gif' style='padding:5px 0px 1px 20px;'>ข้อมูลบุคลากรประจำภาควิชาวิศวกรรมคอมพิวเตอร์</th>
							</tr>
							<tr>
								<th colspan="2"  id='lecpicture' align='center' style='padding:5px 0px 1px 20px;'>
								<?php
									if(is_file("./picture/lecturer$lec_id.gif"))
										echo "<img  src='./picture/lecturer$lec_id.gif' border='1' width='120' height='160' alt=''></th>";
									else
										echo "<img  src='./picture/nopic.gif' border='1' alt=''></th>";
								?>
								
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ชื่อ-นามสกุล</th><td class='rowdetail'><?php echo "$result[CAPTION] $result[NAME] $result[SERNAME]" ;?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>อีเมล์</th><td class='rowdetail' id='lemail'><?php echo "<a href='mailto:$result[EMAIL]'>$result[EMAIL]</a>";?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>เบอร์โทรศัพย์</th><td class='rowdetail' id='lphone'><?php echo $result['PHONE_OFFICE'];?></td>
							
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>โฮมเพจ</th><td class='rowdetail' id='llink'><?php echo "<a href='http://$result[LINK]'>$result[LINK]</a>";?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ตำแหน่ง/หน้าที่</th><td class='rowdetail' id='lposition'><?php echo $result['POSITION']?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ประวัติการศึกษา</th><td class='rowdetail' id='leducational'><pre ><?php echo $result['EDUCATIONAL'];?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>สอนในระดับ</th><td class='rowdetail' id='lteach'><?php echo $result['CLASS'];?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ห้องปฏิบัติการวิจัย</th><td class='rowdetail' id='llab'><?php echo $lablink;?></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ภาระงานสอน</th><td class='rowdetail' id='ltimetable'><pre ><?php echo $result['TIMETABLE'];?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>เวลาพบนักศึกษา</th><td class='rowdetail' id='lconsult'><pre><?php echo $result['CONSULT'];?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ประสบการณ์อื่นๆ</th><td class='rowdetail' id='lexperience'><pre ><?php echo $result['EXPERIENCE'];?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ที่อยู่ติดต่อ</th><td class='rowdetail' id='laddress'><pre ><?php echo $result['ADDRESS']; ?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>งานวิจัย</th><td class='rowdetail' id='lreserch'><pre ><?php echo $result['RESEARCH'];?></pre></td>
							</tr>
							<tr>
								<th scope="row" class='rowtitle'>ผลงานทางวิชาการ</th ><td class='rowdetail' id='lexpertise'><pre  ><?php echo $result['EXPERTISE'];?></pre></td>
							</tr>
							<tr>
								<th colspan="2" scope="col" align='center' style='padding:5px 0px 1px 20px;' id='buttonaction'>
									<?php 
										
										if($_SESSION['ss_Level']=="admin")
											echo "<a href='javascript:void editLecturerDetail($lec_id);'><img src='../images/Button/edit.gif' border='0' alt=''></a>";
										else if($_SESSION['ss_Level']='lecturer'){
											$sql="SELECT LECTURER_ID ";
											$sql.="FROM $tb_lecturer ";
											$sql.="WHERE USER_ID='".$_SESSION['ss_UserID']."' ";
											$sql.="AND LECTURER_ID= '$lec_id'";
											mysql_db_query($dbname,"SET NAMES 'UTF8'");
											if($dbquery=mysql_db_query($dbname,$sql))
												if(mysql_fetch_array($dbquery))
													echo "<a href='javascript:void editLecturerDetail($lec_id);'><img src='../images/Button/edit.gif' border='0' alt=''></a>";
										}
									?>
								</th>
							</tr>
						</table>
					</div><br><br>
				</div>
			
				<?php
					}
				}
				?>


			</div>
		</center>
	</body>
</html>


