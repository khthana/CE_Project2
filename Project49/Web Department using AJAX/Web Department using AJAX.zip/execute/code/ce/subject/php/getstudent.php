<?php

	function getSubjectStudent($subject_id,$choice=4,$sort=0,$sortop="ASC",$page=1){
		global $dbname,$tb_student,$tb_subject_student,$tb_useraccount;
		$objResponse = new xajaxResponse();
		$return="";
		//ตรวจสอบสิทธิในการลบไฟล
		if($_SESSION['ss_SubjectLevel'] !='admin' && $_SESSION['ss_SubjectLevel'] !='user'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$objResponse->addScript("xajax_createSubjectMenu($subject_id,4);");
		$sorta=array("ss.`STUDENT_ID`","st.`FIRST_NAME`","st.`USER_ID`","st.`USER_ID`","st.`USER_ID`");
		if($sortop=="DESC")
			$sortopnext="ASC";
		else
			$sortopnext="DESC";
		if(date("n",time())>5 && date("n",time())<10)
			$semeter=1;
		else if(date("n",time())>10 || date("n",time())<3)
			$semeter=2;
		else if(date("n",time())>2 && date("n",time())<6)
			$semeter=3;
		if(date("n",time())>0 && date("n",time())<3)
			$educated=date("Y",time())+543-1;
		else
			$educated=date("Y",time())+543;

		$sql="SELECT COUNT(*) AS NUMSTD ";
		$sql.="FROM $tb_subject_student ";
		$sql.="WHERE `SUBJECT_ID`='$subject_id' AND SEMETER='$semeter' AND EDUCATED ='$educated'";
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$numstd=$result['NUMSTD'];
			}
		}
		$sql="SELECT ss.`STUDENT_ID`, st.`FIRST_NAME` , st.`LAST_NAME` ,st.DEPARTMENT,st.SECTION,st.GENERATION ";
		$sql.="FROM $tb_subject_student ss ,$tb_student st ";
		$sql.="WHERE ss.`SUBJECT_ID`='$subject_id' AND st.`STUDENT_ID`=ss.`STUDENT_ID` ";
		$sql.="AND SEMETER='$semeter' AND EDUCATED ='$educated'";
		$sql.="ORDER BY $sorta[$sort] $sortopnext LIMIT ".(15*($page-1)).",15";
		
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<br><div style='width:765px;height:25px;background: url(\"../images/leftbg.gif\");border-bottom:2px solid #B0B0B0;'>";
				$return.="<div class='sbst1'><a href='javascript:void xajax_getSubjectStudent($subject_id,4,0,\"$sortopnext\");'>รหัส</a></div>";
				$return.="<div class='sbst2'><a href='javascript:void xajax_getSubjectStudent($subject_id,4,1,\"$sortopnext\");'>ชื่อ-นามสกุล</a></div>";
				$return.="<div class='sbst3'><a href='javascript:void xajax_getSubjectStudent($subject_id,4,2,\"$sortopnext\");'>ชั้นปี</a></div>";
				$return.="<div class='sbst4'><a href='javascript:void xajax_getSubjectStudent($subject_id,4,3,\"$sortopnext\");'>ห้อง</a></div>";
				$return.="<div class='sbst5'><a href='javascript:void xajax_getSubjectStudent($subject_id,4,4,\"$sortopnext\");'>ภาควิชา</a></div>";
			$return.="</div>";
			
			while($result=mysql_fetch_array($dbquery)){
				if(date('n',time())>3)
					$classyear=date('Y',time())-$result['GENERATION']+1+543;
				else
					$classyear=date('Y',time())-$result['GENERATION']+543;
				$return.="<div id='$result[STUDENT_ID]' style='width:765px;background: url(\"../images/leftbg.gif\");'>";
				$return.="<div class='sbst1'>$result[STUDENT_ID]</div>";
				$return.="<div class='sbst2'>$result[FIRST_NAME] $result[LAST_NAME] </div>";
				$return.="<div class='sbst3'>$classyear</div>";
				$return.="<div class='sbst4'>$result[SECTION]</div>";
				$return.="<div class='sbst5'>$result[DEPARTMENT]</div>";
				$return.="<div class='sbst6'></div>";
				$return.="</div>";
			}
			$return.="</div><div class='sbmultipage''>Page ".checkpage($numstd,$page,'15',"javascript:void xajax_getSubjectStudent($subject_id,4,$sort,\"$sortop\",",");'")."</div>
			
			

			<div id='newsubjectstudent' style='width:750px;text-align:center;float:left;padding:5px;border:1px solid;'>";
			if($_SESSION['ss_SubjectLevel'] =='admin')
				$return.="<iframe src='./excelreader/index.php?subject_id=$subject_id' style='width:500px;height:120px;' marginwidth='10' marginheight='10' frameborder='0' hspace='0' vspace='0' scrolling='no'>
								</iframe><br><br>
								</div>";
			else
				$return.="&nbsp;</div>";
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...$sql");
		$objResponse->addAssign("subjectdetail","innerHTML",$return);
		return $objResponse;
	}


	?>
