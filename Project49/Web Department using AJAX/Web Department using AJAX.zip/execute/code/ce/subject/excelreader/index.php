<?php
	require_once("../../_Sessionstart.php");
	require_once("../../connectdb.inc.php");
	require_once './reader.php';
?>
<html>
	<head>
		<title>Upload Progress</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="./index.css" />
		
		<script type="text/javascript" src="../tool/cookies.js"></script>

	</head>
	<body class='site'>
		<form  enctype="multipart/form-data" method="post" action='<?php echo "index.php?subject_id=$subject_id";?>' onsubmit="bUploaded.start('fileprogress'); ">
			<div>
				&nbsp;&nbsp;&nbsp;&nbsp;download รูปแบบไฟล์ตัวอย่าง <a href='./example.xls'>example.xls</a>
				<fieldset >
					<legend>Add a file</legend>
					<input id="filename" type="file" name="gfile" style='width:400px;'/><br>
					<input type="submit" value="upload" />
				</fieldset>
			</div>
			<div id="fileprogress"><?php if($_FILES) echo "Upload Complete...";?></div>
			<pre style="font-weight: bold;">
		<?php 
			if($_FILES){
				$tmpfile=$_FILES['gfile']['tmp_name'];
				$filename=$_FILES['gfile']['name'];
				$filesize=$_FILES['gfile']['size'];
				
				$fileinfo=pathinfo("./file/".$_FILES['gfile']['name']);
						
				if($fileinfo['extension']=="xls"){
					if (copy($tmpfile,"./file/studentinclass.xls")) {
						$data = new Spreadsheet_Excel_Reader();
						$data->setOutputEncoding('UTF-8');
						$data->read('./file/studentinclass.xls');

						error_reporting(E_ALL ^ E_NOTICE);
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						
						if(date("n",time())>5 && date("n",time())<10)
							$semeter=1;
						else if(date("n",time())>10 || date("n",time())<3)
							$semeter=2;
						else if(date("n",time())>2 && date("n",time())<6)
							$semeter=3;
						if(date("n",time())>0 && date("n",time())<3)
							$educated=date("Y",time())+543-1;
						else
							$educated=date("Y",time())+543;

						for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {
							//for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
								//echo $data->sheets[0]['cells'][$i][$j]." ";
							
								if($data->sheets[0]['cells'][$i][1]!=""){
									$sql_ss="INSERT INTO $tb_subject_student ";
									$sql_ss.="VALUES ('$subject_id','".$data->sheets[0][cells][$i][1]."',$semeter,$educated)";
									mysql_db_query($dbname,$sql_ss);
									
									$sql_ua="SELECT USER_ID ";
									$sql_ua="FROM $tb_useraccount ";
									$sql_ua="WHERE STUDENT_ID = '".$data->sheets[0][cells][$i][1]."'";
									if($dbquery=mysql_db_query($dbname,$sql_st))
										if($result=mysql_fetch_array($dbquery))
											$user_id=$result['USER_ID'];
										else
											$user_id=0;
									
									$inyear=(date('Y',time())+543)-$data->sheets[0][cells][$i][6];
									if(date('n',time())>3){
										$inyear++;
									}
									if(ereg("^[0-9]{8}$",$data->sheets[0][cells][$i][1])){
										$sql_st="INSERT INTO $tb_student VALUES ";
										$sql_st.="('".$data->sheets[0][cells][$i][1]."','".$data->sheets[0][cells][$i][2]."',";
										$sql_st.="'".$data->sheets[0][cells][$i][3]."','".$data->sheets[0][cells][$i][4]."',";
										$sql_st.="'".$data->sheets[0][cells][$i][5]."','".$inyear."',";
										$sql_st.="'$user_id')";
										mysql_db_query($dbname,$sql_st);
									}
								}
						}
					}
					else
						echo "failed copy $tmpfile to $filepath...\n";
				}
				else 
					echo "ไฟล์ไม่ถูกต้อง...";
			}
		?>
		</pre>
		</form>
	</body>
</html>