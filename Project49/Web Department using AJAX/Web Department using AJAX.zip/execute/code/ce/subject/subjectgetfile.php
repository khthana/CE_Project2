﻿<?php
	require_once("./connectdb.inc.php");

	echo "file: ".$_FILES['userfile']['name']."<br />";
	echo "type: ".$_FILES['userfile']['type']."<br />";
	echo "size: ".$_FILES['userfile']['size']."<br />";
	echo "tmp: ".$_FILES['userfile']['tmp_name']."<br />";
	switch ($_FILES['userfile']['error']){
		case 0:
			echo "file uploaded with success.";
			break;
		case 1:
			echo "this big file.";
			break;
		case 2:
			echo "this big file";
			break;
		case 3:
			echo "file was only partially uploaded.";
			break;
		case 4:
			echo "No file was uploaded.";
			break;
		case 6:
				echo "Missing a temporary folder.";
			break;
		case 7:
			echo "Failed to write file to disk.";
			break;
		case 8:
			echo "File upload stopped by extension.";
			break;
	}
$fileinfo=pathinfo($_FILES['userfile']['name']);
$fileext=$fileinfo['extension'];

if(strpos("_,jpg,jpeg,png,gif,bmp,tif,_",$fileext))
	$filetype="image";
else if(strpos("_,mp3,ogg,wmv,wma,wav,avi,rm,3gp,mpeg,mpg,_",$fileext))
	$filetype="sound";
else if(strpos("_,pdf,_",$fileext))
	$filetype="acrobat";
else if(strpos("_,doc,txt,_",$fileext))
	$filetype="document";
else if(strpos("_,ppt,_",$fileext))
	$filetype="powerpoint";
else if(strpos("_,zip,rar,tar,gz_",$fileext))
	$filetype="package";
else
	$filetype="notype";

$filesize=$_FILES['userfile']['size'];
$toEval=0;
$typesize = array( 'bytes', 'Kb', 'Mb', 'Gb', 'Tb', 'Zb' );
while($filesize > 1024 ) {
	echo $filesize;
	$filesize = $filesize / 1024;
}
$filesize1="$filesize $typesize[toEval]";
//$filesize=($filesize > 1073741824) ? round($filesize/1073741824,2)." Gb" :($filesize > 1048576) ? round($filesize/1048575)." Mb" : ($filesize > 1024) ? round($filesize/1024,2)." Kb" : $filesize." byte";

//echo $filesize1;
$uploaddir = './file/subject/'.$subject."/";
if(!is_dir($uploaddir)) 
	mkdir($uploaddir, 0757);
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
echo $uploadfile;
echo '<pre>';
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
	if(chmod($uploadfile, 0757)){
		$sql="INSERT INTO $tb_subject_mediabook ( `MEDIABOOK_ID` , `SUBJECT_ID` , `MEDIABOOK_NAME` , `MEDIABOOK_DETAIL` , `MEDIABOOK_TYPE` , `MEDIABOOK_PATH` , `MEDIABOOK_SIZE` , `MEDIABOOK_CREATE` , `MEDIABOOK_BY` ) VALUES (NULL , '$subject', '".$_FILES['userfile']['name']."', 'detail', '$filetype', '$uploaddir', '$filesize', NOW( ) , 'by')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			echo "File is valid, and was successfully uploaded.\n";
		}
	}
	else
		echo "File is Can't CHMOD.\n";
} else {
   echo "Possible file upload attack!\n";
}

print "</pre>";

?>

