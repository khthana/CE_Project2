<html>
	<head>
		<title>
		</title>
		<link rel="stylesheet" type="text/css" href="../style.css" />
		</head>
	<body style='background-color:#5FAEFE;'>
<?php
		if(isset($userfile)){
			require_once("./connectdb.inc.php");
			session_start();
			$fileinfo=pathinfo($_FILES['userfile']['name']);
			$fileext=$fileinfo['extension'];

			if(strpos("_,jpg,jpeg,png,gif,bmp,tif,_",$fileext))
				$filetype="image";
			else if(strpos("_,mp3,ogg,wmv,wma,wav,avi,rm,3gp,mpeg,mpg,_",$fileext))
				$filetype="sound";
			else if(strpos("_,pdf,_",$fileext))
				$filetype="acrobat";
			else if(strpos("_,doc,txt,_",$fileext))
				$filetype="document";
			else if(strpos("_,ppt,_",$fileext))
				$filetype="powerpoint";
			else if(strpos("_,zip,rar,tar,gz_",$fileext))
				$filetype="package";
			else
				$filetype="notype";

			$filesize=$_FILES['userfile']['size'];

			$filesize=($filesize > 1073741824) ? round($filesize/1073741824,2)." Gb" :($filesize > 1048576) ? round($filesize/1048575)." Mb" : ($filesize > 1024) ? round($filesize/1024,2)." Kb" : $filesize." byte";
			$uploaddir = "./file/subject/$subjectid/";
			$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

			if(!is_dir($uploaddir)) 
				mkdir($uploaddir, 0757);
			if(!is_file($uploadfile)){
				if(move_uploaded_file($_FILES['userfile']['tmp_name'],$uploadfile)){
					if(chmod($uploadfile, 0757)){
						$sql="INSERT INTO $tb_subject_mediabook ( `MEDIABOOK_ID` , `SUBJECT_ID` , `NAME` , `DETAIL` , `TYPE` , `PATH` , `SIZE` , `CREATE` , `BY` ) VALUES (NULL , '$subjectid', '".$_FILES['userfile']['name']."', 'detail', '$filetype', '$uploaddir', '$filesize', ".time()." , '$_SESSION[ss_UserName]')";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						
						if($dbquery=mysql_db_query($dbname,$sql)){
							?><script language='JavaScript' type='text/javascript'> <!--   
								alert("Upload Success... ! \nFilename:<?php echo $_FILES['userfile']['name'];?>  \nSize: <?php echo $filesize;?>");   //--> </script>
							<?php
						}
						else
							echo "<script language='JavaScript' type='text/javascript'> <!--   
								alert(\"DataBase Error !\");   //--> </script>";
					}
					else
						echo "<script language='JavaScript' type='text/javascript'> <!--   
								alert(\"File is Can't CHMOD. !\");   //--> </script>";
				}
				else
					echo "<script language='JavaScript' type='text/javascript'> <!--   
							alert(\"".iconv("tis-620","utf-8","�Դ�����Դ��Ҵ")."!\");   //--> </script>";
			}
			else
				echo "<script language='JavaScript' type='text/javascript'> <!--   
							alert(\"".iconv("tis-620","utf-8","�������ö�������͹���� ��س�����¹��������͹ ")."!\");   //--> </script>";
		}
?>

	
		<form style='font-family:verdana;font-size:10;color:#FFFFFF;' method='post' enctype="multipart/form-data" action='subjectupload.php?subjectid=<?php echo $subjectid;?>' >
			<?php echo iconv("tis-620","utf-8","��������´: ");?><textarea name="" rows="3" cols="35"></textarea><br />
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo iconv("tis-620","utf-8","���: ");?><input type='file' name='userfile' />
			<input type='submit' value='submit'/>
		</form>
	</body>
</html>