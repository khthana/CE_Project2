<?php
	
	require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	require_once("../tool/xajax/xajax.inc.php");
	require_once("./checklogin.inc.php");

	require_once("./php/getstudent.php");

	function getSubject($type){
		global $dbname,$tb_subject;
		$objResponse = new xajaxResponse();
		$sql="SELECT `SUBJECT_ID` , `NAME_TH` , `NAME_EN` FROM $tb_subject WHERE `TYPE` = '$type'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<select id='subjectselect' onchange=\"javascript:void xajax_createSubjectMenu(xajax.$('subjectselect').value);xajax_getSubjectDetail(xajax.$('subjectselect').value);\">
							<option value='เลือกรายวิชา'>เลือกรายวิชา</option>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<option value='$result[SUBJECT_ID]'>$result[SUBJECT_ID] $result[NAME_TH] $result[NAME_EN]</option>";
			}
			$return.="</select>";
		}
		$objResponse->addAssign("subjectlist","innerHTML",$return);
		return $objResponse;
	}
	function getAllSubject($selectsubject){
		global $dbname,$tb_subject;
		$objResponse = new xajaxResponse();
		$sql="SELECT `SUBJECT_ID` , `NAME_TH` FROM $tb_subject ORDER BY `SUBJECT_ID`";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			if($selectsubject=="ไม่มี")
				$return="<select id='sct'><option value='ไม่มี' selected>ไม่มี";
			else
				$return="<select id='sct'><option value='ไม่มี'>ไม่มี";
			while($result=mysql_fetch_array($dbquery)){
				if($selectsubject==$result['SUBJECT_ID'])
					$return.="<option value='$result[SUBJECT_ID]' selected>$result[SUBJECT_ID] $result[NAME_TH] ";
				else
					$return.="<option value='$result[SUBJECT_ID]'>$result[SUBJECT_ID] $result[NAME_TH] ";
			}
			$return.="</select>";
		}
		$objResponse->addAssign("sc","innerHTML",$return);
		//$objResponse->addAlert($selectsubject);
		return $objResponse;
	}
	function createSubjectMenu($subject_id,$choice=1){
		$objResponse = new xajaxResponse();
		if($subject_id=='เลือกรายวิชา'){
			$objResponse->addAssign("subjectmenu","innerHTML","");
			return $objResponse;
		}
		$return="<div class='submenu'>";
				if($choice==1)
					$return.="<a href='javascript:void xajax_getSubjectDetail($subject_id,1);'>&nbsp;&nbsp;[ ข้อมูลรายวิชา ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				else
					$return.="<a href='javascript:void xajax_getSubjectDetail($subject_id,1);'>&nbsp;&nbsp;ข้อมูลรายวิชา&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				if($choice==2)
					$return.="<a href='javascript:void xajax_getSubjectNotice($subject_id,2);'>&nbsp;&nbsp;[ ข่าวประกาศ ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				else
					$return.="<a href='javascript:void xajax_getSubjectNotice($subject_id,2);'>&nbsp;&nbsp;ข่าวประกาศ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				if($choice==3)
					$return.="<a href='javascript:void xajax_getSubjectBook($subject_id,3);'>&nbsp;&nbsp;[ สื่อประกอบการเรียน ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				else
					$return.="<a href='javascript:void xajax_getSubjectBook($subject_id,3);'>&nbsp;&nbsp;สื่อประกอบการเรียน&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				if($choice==4)
					$return.="<a href='javascript:void xajax_getSubjectStudent($subject_id,4);'>&nbsp;&nbsp;[ รายชื่อนักศึกษา ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				else
					$return.="<a href='javascript:void xajax_getSubjectStudent($subject_id,4);'>&nbsp;&nbsp;รายชื่อนักศึกษา&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				$return.="<br><br></div>";
				
		$objResponse->addAssign("subjectmenu","innerHTML",$return);
		return $objResponse;
	}
	function getSubjectDetail($subject_id,$choice=1){
		global $dbname,$tb_subject,$tb_subject_lecturer,$tb_lecturer,$tb_subject_student,$tb_student;
		$objResponse = new xajaxResponse();
		$objResponse->addScript("xajax_createSubjectMenu($subject_id,$choice);");
		$return="";
		if($subject_id=='เลือกรายวิชา'){
			$objResponse->addAssign("subjectdetail","innerHTML","");
			return $objResponse;
		}

		if($_SESSION['ss_Status']=="offline")
			$_SESSION['ss_SubjectLevel']="guest";
		else if($_SESSION['ss_Status']=="online" && $_SESSION['ss_Level']=="admin")
			$_SESSION['ss_SubjectLevel']="admin";
		else if($_SESSION['ss_Status']=="online" && $_SESSION['ss_Level']=="lecturer"){
			$sql="SELECT sle.`LECTURER_ID` FROM $tb_subject_lecturer sle,$tb_lecturer le WHERE '$_SESSION[ss_UserID]'=le.`USER_ID` AND le.`LECTURER_ID`= sle.`LECTURER_ID` AND sle.`SUBJECT_ID`='$subject_id'";
			if($dbquery=mysql_db_query($dbname,$sql)){
				if(mysql_fetch_array($dbquery))
					$_SESSION['ss_SubjectLevel']="admin";
				else
					$_SESSION['ss_SubjectLevel']="user";
			}
		}
		else if($_SESSION['ss_Status']=="online"){
			$sql="SELECT * FROM $tb_subject_student sst,$tb_student st WHERE '$_SESSION[ss_UserID]'=st.`USER_ID` AND st.`STUDENT_ID`= sst.`STUDENT_ID` AND sst.`SUBJECT_ID`='$subject_id'";
			if($dbquery=mysql_db_query($dbname,$sql)){
				if(mysql_fetch_array($dbquery))
					$_SESSION['ss_SubjectLevel']="user";
				else
					$_SESSION['ss_SubjectLevel']="guest";
			}
		}
		
		$sql="SELECT * FROM $tb_subject WHERE `SUBJECT_ID` = '$subject_id'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$return="<br><table width='100%' style='font-weight:normal;background-image:url(\"../images/leftbg.gif\");' cellpadding='0' cellspacing='0' >
				
				<tr><td class='shd' >หลักสูตร</td><td id='co' class='shl'> $result[COURSE]</td></tr>
				<tr><td class='shd' >รหัสวิชา</td><td id='su' class='shl'> $result[SUBJECT_ID]</td></tr>
				<tr><td class='shd' >ชื่อวิชาภาษาไทย</td><td id='nt' class='shl'> $result[NAME_TH]</td></tr>
				<tr><td class='shd' >ชื่อวิชาภาษาอังกฤษ</td><td id='ne' class='shl'> $result[NAME_EN]</td></tr>";
				$creadit=explode(",",$result['CREDIT']);
				$return.="<tr><td class='shd' >หน่วยกิต (ทฤษฎี-ปฏิบัติ)</td><td id='cr' class='shl'>$creadit[0] ( $creadit[1] - $creadit[2] ) </td></tr>
				<tr><td class='shd' >วิชาบังคับก่อน</td><td id='sc' class='shl'> $result[SUCCEED]</td></tr>
				<tr><td class='shd' valign='top'>เนื้อหารายวิชา</td><td class='shl'><span id='de'> $result[DETAIL]</span></td></tr>
				<tr><td class='shd' valign='top'>เวลาเรียน</td><td id='st' class='shl'> $result[STUDY_TIME]</td></tr>
				<tr><td class='shd' valign='top'>แนวการสอน</td><td id='gu' class='shl'> $result[GUIDE_LINE]</td></tr>
				<tr><td class='shd' valign='top'>ตำราเอกสาร</td><td id='bo' class='shl'> $result[BOOK]</td></tr>
				<tr><td class='shd' valign='top'>การประเมินผล</td><td id='po' class='shl'> $result[POINT]</td></tr>
				<tr><td class='shd' valign='top'>อาจารย์ผู้สอน</td><td id='le' class='shl'> ";
				
				$sql="SELECT * FROM $tb_subject_lecturer sl,$tb_lecturer lc WHERE sl.`SUBJECT_ID` = '$subject_id' AND sl.`LECTURER_ID`=lc.`LECTURER_ID` ";
				mysql_db_query($dbname,"SET NAMES 'UTF8'");
				if($dbquery=mysql_db_query($dbname,$sql)){
					while($result=mysql_fetch_array($dbquery)){
						$return.="<a href='../lecturer/lecturerdetail.php?lec_id=$result[LECTURER_ID]'> $result[CAPTION]$result[NAME] $result[SERNAME]<br></a>";
					}
				}
				$return.="
				</td></tr>
					<tr><td id='ed' colspan='2' style='padding:8px 4px;font-weight:bold;text-align:center;'>&nbsp;";

				if($_SESSION['ss_SubjectLevel'] =='admin')
					$return.="<hr width='600px'><a href='javascript:void editSubjectDetail();' ><img src='../images/Button/edit.gif' border='0' alt='edit'></a>";
				$return.="</td></tr>
				</table>";
			}
		}
		$objResponse->addAssign("subjectdetail","innerHTML",$return);
		return $objResponse;
	}
	function toEditSubjectDetail($subject_id,$course,$name_th,$name_en,$credit,$succeed,$detail,$study_time,$guide_line,$book,$point){
		global $dbname,$tb_subject;
		$objResponse = new xajaxResponse();
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามรถเข้าใช้งานส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="UPDATE $tb_subject SET `COURSE`= '$course',`NAME_TH`= '$name_th',`NAME_EN`= '$name_en',`CREDIT`= '$credit',`SUCCEED`= '$succeed',`DETAIL`= '$detail',`STUDY_TIME`= '$study_time',`GUIDE_LINE`= '$guide_line',`BOOK`= '$book',`POINT`= '$point' WHERE `SUBJECT_ID` ='$subject_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql))
			$objResponse->addAlert("บันทึกข้อมูลเรียบร้อยแล้ว...");
		else
			$objResponse->addAlert("เกิดความผิดพลาด...$sql");
		return $objResponse;
	}
	//แสดงประกาศของวิชานั้นทั้งหมด
	function getSubjectNotice($subject_id,$choice=2,$sort=1,$sortop="ASC",$page=1){
		$objResponse = new xajaxResponse();
		if($_SESSION['ss_SubjectLevel'] !='admin' && $_SESSION['ss_SubjectLevel'] !='user'){
			$objResponse->addAlert("คุณไม่สามรถเข้าใช้งานส่วนนี้ได้... ");
			return $objResponse;
		}
		$objResponse->addScript("xajax_createSubjectMenu($subject_id,$choice);");
		global $dbname,$tb_subject,$tb_subject_notice;
		$sorta=array("`TITLE`","`CREATE`","`BY`");
		if($sortop=="DESC")
			$sortopnext="ASC";
		else
			$sortopnext="DESC";
		
		
		$sql="SELECT COUNT(NOTICE_ID) AS NUMSTD FROM $tb_subject_notice WHERE `SUBJECT_ID`='$subject_id' AND `STATUS`='1'";
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$numstd=$result['NUMSTD'];
			}
		}

		$sql="SELECT * FROM $tb_subject_notice WHERE `SUBJECT_ID`='$subject_id' AND `STATUS`='1' ORDER BY $sorta[$sort] $sortopnext LIMIT ".(15*($page-1)).",15";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<br>";

			$return.="<div style='width:765px;height:25px;background-image:url(\"../images/leftbg.gif\");border-bottom:2px inset #C5C5C5;'>
			<div class='sbnotice1'><a href='javascript:void xajax_getSubjectNotice($subject_id,2,0,\"$sortopnext\");'>หัวข้อ</a></div>
			<div class='sbnotice2'><a href='javascript:void xajax_getSubjectNotice($subject_id,2,1,\"$sortopnext\");'>เมื่อ</a></div>
			<div class='sbnotice3'><a href='javascript:void xajax_getSubjectNotice($subject_id,2,2,\"$sortopnext\");'>โดย</a></div>
			<div class='sbnotice4'>admin</div>
			</div><div id='allsubjecttopic' style='background-image:url(\"../images/leftbg.gif\");'>";
			while($result=mysql_fetch_array($dbquery)){
				//แสดงหัวข้อของของประกาศ และรายละเอียด โดยรายละเอียดจะถูกซ่อนไว้ดว้ย style:display=none
				$return.="<div id='d$result[NOTICE_ID]' class='sbdetail' ><b>เรื่อง </b><span id='sbt$result[NOTICE_ID]'> $result[TITLE]</span> <b>ประกาศเมื่อ</b> ".date("j-n-y G:i น.",$result['CREATE'])." <br><br><span id='sbd$result[NOTICE_ID]'>$result[DETAIL] </span><br><br><b>ประกาศโดย</b> $result[BY] <br><span id='sbo$result[NOTICE_ID]'>";

				//ตรวจสอบสิทธิในการแก้ไขประกาศจองรายวิชา
				if($_SESSION['ss_SubjectLevel'] =='admin')
					$return.="<a href='javascript:void editSubjectNotice($result[NOTICE_ID]);'><img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> ";

				$return.="<a href='javascript:void hideSubjectDetail($result[NOTICE_ID]);'><img src='../images/Button/hide.gif' border='0' alt='ซ่อน'></a></span></div>";
				$return.="<div id='$result[NOTICE_ID]' style='width:765px;' ><div class='sbnotice1' id='tpp$result[NOTICE_ID]'><a href='javascript:void viewSubjectDetail($result[NOTICE_ID]);'>$result[TITLE]</a></div><div class='sbnotice2'>".date("j-n-y G:i น.",$result['CREATE'])."</div><div class='sbnotice3'>$result[BY]</div><div class='sbnotice4'>";
				//ตรวจสอบสิทธ์ในการลบ หรื่อว่าแก้ประกาศของรายวิชา
				if($_SESSION['ss_SubjectLevel'] =='admin')
					$return.="<a href='javascript:void editSubjectNotice($result[NOTICE_ID]);'><img src='../images/edit.gif'></a> <a href='javascript:void deleteSubjectNotice($result[NOTICE_ID]);'><img src='../images/delete.gif'></a></div>";
				else
					$return.="&nbsp;</div>";
				$return.="</div>";
			}
		}
		$return.="</div>
		<div class='sbmultipage''>Page ".checkpage($numstd,$page,'15',"javascript:void xajax_getSubjectNotice($subject_id,2,$sort,\"$sortop\",",");'")."</div>
		<div id='newsubjectnotice' style='width:765px;text-align:center;float:left;padding:5px;'>";
		if($_SESSION['ss_SubjectLevel'] =='admin')
			$return.="<a href='javascript:void addSubjectNotice();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a></div>";
		else
			$return.="&nbsp;</div>";
		$objResponse->addAssign("subjectdetail","innerHTML",$return);
		$objResponse->addScript("tmptopic=new Array();tmpdetail=new Array();");
		return $objResponse;
	}
	function deleteSubjectNotice($notice_id){
		global $dbname,$tb_subject,$tb_subject_notice;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการลบประกาศของรายวิชา
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="DELETE FROM $tb_subject_notice WHERE `NOTICE_ID` ='$notice_id'";
		if(mysql_db_query($dbname,$sql))
			$objResponse->addAlert("ลบข้อมูลเรียบร้อย...");
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function addSubjectNotice($subject_id,$subjecttopic,$subjectdetail){
		global $dbname,$tb_subject,$tb_subject_notice;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการเพิ่มประกาศของรายวิชา
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="INSERT INTO $tb_subject_notice (`SUBJECT_ID` , `TITLE` , `DETAIL` , `CREATE` , `BY` )VALUES ('$subject_id', '$subjecttopic', '$subjectdetail',".time().",'$_SESSION[ss_UserName]')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			if($dbquery=mysql_db_query($dbname,"SELECT MAX(NOTICE_ID) AS MAXID FROM $tb_subject_notice")){
				while($result=mysql_fetch_array($dbquery)){
					//แสดงหัวข้อของของประกาศ และรายละเอียด โดยรายละเอียดจะถูกซ่อนไว้ดว้ย style:display=none
					$return="<div id='d$result[MAXID]' class='sbdetail'><b>เรื่อง</b> <span id='sbt$result[MAXID]'> $subjecttopic</span> <b>ประกาศเมื่อ</b> ".date("j-n-y G:i น.",time())." <br><span id='sbd$result[MAXID]'>$subjectdetail </span><br><b>ประกาศโดย</b> $_SESSION[ss_UserName] <br><span id='sbo$result[MAXID]'>";
					if($_SESSION['ss_SubjectLevel']=='admin')
						$return.="<a href='javascript:void editSubjectNotice($result[MAXID]);'><img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> ";
					$return.="<a href='javascript:void hideSubjectDetail($result[MAXID]);'><img src='../images/Button/hide.gif' border='0' alt='ซ่อน'></a></span></div>";
					
					$return.="<div id='$result[MAXID]' style='width:765px;'><div class='sbnotice1' id='tpp$result[MAXID]'><a href='javascript:void viewSubjectDetail($result[MAXID]);'>$subjecttopic</a></div><div class='sbnotice2'>".date("j-n-y G:i น.",time())."</div><div class='sbnotice3'>$_SESSION[ss_UserName]</div><div class='sbnotice4'>";
					//ตรวจสอบสิทธิในการลบและแก้ไขประกาศรายวิชา
					if($_SESSION['ss_SubjectLevel'] =='admin')
						$return.="<a href='javascript:void editSubjectNotice($result[MAXID]);'><img src='../images/edit.gif'></a> <a href='javascript:void deleteSubjectNotice($result[MAXID]);'><img src='../images/delete.gif'></a></div>";
					else
						$return.="&nbsp;</div>";
					$return.="</div>";
				$objResponse->addScript("hideSubjectNotice();");
				$objResponse->addScript("if(document.getElementById('allsubjecttopic').childNodes.length==30){xajax.$('allsubjecttopic').removeChild(xajax.$('allsubjecttopic').lastChild);xajax.$('allsubjecttopic').removeChild(xajax.$('allsubjecttopic').lastChild);}");
				$objResponse->addPrepend("allsubjecttopic","innerHTML",$return);
				$objResponse->addAlert("เพิ่มข้อมูลเรียบร้อยแล้ว...");
				}
			}
			else
				$objResponse->addAlert("เกิดความผิดพลาด...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function submitNoticeEdit($subject_id,$topic,$detail){
		global $dbname,$tb_subject,$tb_subject_notice;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการแก้ไขประกาศของรายวิชา
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="UPDATE $tb_subject_notice SET `TITLE` = '$topic',`DETAIL` = '$detail' WHERE `NOTICE_ID` ='$subject_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อย...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function getSubjectBook($subject_id,$choice=3,$sort=0,$sortop="ASC",$page=1){
		global $dbname,$tb_subject,$tb_subject_book;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการเข้าใช้งานไฟล์ข้อมูลของรายวิชา
		if($_SESSION['ss_SubjectLevel'] !='admin' && $_SESSION['ss_SubjectLevel'] !='user' ){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$objResponse->addScript("xajax_createSubjectMenu($subject_id,$choice);");
		$sorta=array("`CREATE`","`TYPE`","`NAME`","`SIZE`","`BY`");
		if($sortop=="DESC")
			$sortopnext="ASC";
		else
			$sortopnext="DESC";
		
		$sql="SELECT COUNT(`BOOK_ID`) AS NUMSTD FROM $tb_subject_book WHERE `SUBJECT_ID`='$subject_id'";
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$numstd=$result['NUMSTD'];
			}
		}
		$sql="SELECT * FROM $tb_subject_book WHERE `SUBJECT_ID`='$subject_id' AND `STATUS`='1' ORDER BY $sorta[$sort] $sortopnext LIMIT ".(15*($page-1)).",15";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){

			$return="<br><div style='width:765px;height:25px;background: url(\"../images/leftbg.gif\");border-bottom:2px solid #B9B9B9;'>
			<div class='sbbook2'><a href='javascript:void xajax_getSubjectBook($subject_id,3,1,\"$sortopnext\");'>ชนิด</a></div>
			<div class='sbbook3'><a href='javascript:void xajax_getSubjectBook($subject_id,3,2,\"$sortopnext\");'>ชื่อ</a></div>
			<div class='sbbook4'><a href='javascript:void xajax_getSubjectBook($subject_id,3,3,\"$sortopnext\");'>ขนาด</a></div>
			<div class='sbbook5'><a href='javascript:void xajax_getSubjectBook($subject_id,3,0,\"$sortopnext\");'>เมื่อ</a></div>
			<div class='sbbook6'><a href='javascript:void xajax_getSubjectBook($subject_id,3,4,\"$sortopnext\");'>โดย</a></div>
			<div></div></div><div id='allsubjectbook' style='background: url(\"../images/leftbg.gif\");'>";
			while($result=mysql_fetch_array($dbquery)){
						$filesize=getfilesize($result['SIZE']);
				$return.="<div id='d$result[BOOK_ID]' class='sbbookdetail' ><b>รายละเอียด</b> <br><br>";
				$return.="<b>filename</b> : $result[NAME] <br>";
				$return.="<b>size</b> : $filesize <br>";
				$return.="<b>upload by</b> : $result[BY] <br><br>";
				$return.="<span  id='sbd$result[BOOK_ID]'>$result[DETAIL]</span><br><br><span id='sbo$result[BOOK_ID]'><a href='javascript:void downloadFile(\"$result[NAME]\");'><img src='../images/Button/download.gif' border='0' alt='download'></a> ";
				if($_SESSION['ss_SubjectLevel'] =='admin')
					$return.="<a href='javascript:void editSubjectBook($result[BOOK_ID],\"$result[NAME]\");'><img src='../images/Button/edit.gif' border='0' alt='edit'></a> ";
				$return.="<a href='javascript:void hideFileDetail($result[BOOK_ID]);'><img src='../images/Button/hide.gif' border='0' alt='hide'></a></span></div>";
				
				$return.="<div id='$result[BOOK_ID]' style='width:765px;'><div class='sbbook2'><img src='../images/$result[TYPE].jpg'></div><div class='sbbook3'><a href='javascript:void getFileDetail($result[BOOK_ID]);' >$result[NAME]</a></div><div class='sbbook4'>$filesize</div><div class='sbbook5'>".date("j-n-y G:i น.",$result['CREATE'])."</div><div class='sbbook6'>$result[BY]</div><div class='sbbook7'>";
				//ตรวจสอบสิทธิในการแก้ไขแล้วลบไฟล์
				if($_SESSION['ss_SubjectLevel']=='admin'){
					$return.="<a href='javascript:void getFileDetail($result[BOOK_ID]);editSubjectBook($result[BOOK_ID],\"$result[NAME]\");'><img src='../images/edit.gif'></a> <a href='javascript:void deleteSubjectBook($result[BOOK_ID]);'><img src='../images/delete.gif'></a></div>";
				}
				else
					$return.="&nbsp;</div>";
				$return.="</div>";
			}
			//แสดงการแบ่งหน้า
			$return.="</div><div class='sbmultipage'>Page ".checkpage($numstd,$page,'15',"javascript:void xajax_getSubjectBook($subject_id,3,$sort,\"$sortop\",",");'")."</div>";
			//ส่วนของการ upload file
			$return.="<div id='newsubjectbook' style='width:765px;text-align:center;float:left;padding:5px;'>";
			if($_SESSION['ss_SubjectLevel']=='admin')
				$return.="<a href='javascript:void newSubjectBook($subject_id);'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a></div>";
			else
				$return.="&nbsp;</div>";
		}
		$objResponse->addAssign("subjectdetail","innerHTML",$return);
		$objResponse->addScript("tmpdetail=new Array();");
		return $objResponse;
	}
	function submitEditBook($book_id,$detail){
		global $dbname,$tb_subject,$tb_subject_book;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการแก้ไขไฟล์
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="UPDATE $tb_subject_book SET `DETAIL` = '$detail' WHERE `BOOK_ID` ='$book_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function deleteSubjectBook($book_id){
		global $dbname,$tb_subject,$tb_subject_book;
		$objResponse = new xajaxResponse();
		//ตรวจสอบสิทธิในการลบไฟล
		if($_SESSION['ss_SubjectLevel'] !='admin'){
			$objResponse->addAlert("คุณไม่สามารถเข้าใช้งานในส่วนนี้ได้...");
			return $objResponse;
		}
		$sql="UPDATE $tb_subject_book SET `STATUS` = '0' WHERE `BOOK_ID` ='$book_id' LIMIT 1 ";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("ลบข้อมูลเรียนร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	
	//สร้าง code สำหรับแบ่งหน้าในการแสดง
	function checkpage($allnum,$page,$pagepernum,$to1,$to2){
		$return="";
		$count=1;
		while($allnum>0){
			if($page==$count)
				$return.="<font color='#FF0000'>[$count]</font> ";
			else
				$return.="<a href='$to1$count$to2'>$count</a> ";
			$allnum-=$pagepernum;
			$count++;
		}
		return $return;
	}
	function newSubjectBook($subject_id){
		global $dbname,$tb_subject,$tb_subject_book;
		$objResponse = new xajaxResponse();
		$sql="SELECT MAX(`BOOK_ID`) AS MAXID FROM $tb_subject_book ";
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="";
			$fileinfo=$_COOKIE['fileinfo'];
			$objResponse->addAlert($_COOKIE['fileinfo']);
			$fileinfo1=explode(',',$fileinfo);
			while($result=mysql_fetch_array($dbquery)){
				$return.="<div id='d$result[MAXID]' class='sbbookdetail' >รายละเอียด <br><span id='sbd$result[MAXID]' >detail</span><br><span id='sbo$result[MAXID]'><a href='javascript:void downloadFile();'>download</a> <a href='javascript:void editSubjectBook($result[MAXID]);'><img src='../images/Button/edit.gif' border='0' alt='edit'></a> <a href='javascript:void hideFileDetail($result[MAXID]);'>hide</a></span></div>";
			
				$return.="<div id='$result[MAXID]' style='width:765px;'><div class='sbbook2'><img src='../images/".$_COOKIE['fileinfo'].".jpg'></div><div class='sbbook3'><a href='javascript:void getFileDetail($result[MAXID]);' >filename</a></div><div class='sbbook4'>filesize</div><div class='sbbook5'>".date("j-n-y G:i น.",time())."</div><div class='sbbook6'>$_SESSION[ss_UserName]</div><div class='sbbook7'>";
				//ตรวจสอบสิทธิในการแก้ไขแล้วลบไฟล์
				if($_SESSION['ss_SubjectLevel'] =='admin')
					$return.="<a href='javascript:void getFileDetail($result[MAXID]);editSubjectBook($result[MAXID]);'><img src='../images/edit.gif'></a> <a href='javascript:void deleteSubjectBook($result[MAXID]);'><img src='../images/delete.gif'></a></div>";
				else
					$return.="&nbsp;</div>";
				$return.="</div>";
			}
			$objResponse->addScript("hideNewSubjectBook($subject_id)");
			$objResponse->addScript("if(document.getElementById('allsubjectbook').childNodes.length==30){xajax.$('allsubjectbook').removeChild(xajax.$('allsubjectbook').lastChild);xajax.$('allsubjectbook').removeChild(xajax.$('allsubjectbook').lastChild);}");
			$objResponse->addPrepend("allsubjectbook","innerHTML",$return);
			$objResponse->addAlert("Upload Compleate...");
		}
		
		return $objResponse;
	}
	function getfilesize($filesize){
		$toEval=0;
		$typesize = array( 'bytes', 'Kb', 'Mb', 'Gb', 'Tb', 'Zb' );
		while($filesize > 1024 ) {
			$filesize = round(($filesize / 1024),2);
			$toEval++;
		}
		return "$filesize $typesize[$toEval]";
	}
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");

	$xajax->registerFunction("getSubject");
	$xajax->registerFunction("createSubjectMenu");
	
	$xajax->registerFunction("getSubjectDetail");
	$xajax->registerFunction("toEditSubjectDetail");
	$xajax->registerFunction("getAllSubject");

	$xajax->registerFunction("getSubjectNotice");
	$xajax->registerFunction("deleteSubjectNotice");
	$xajax->registerFunction("addSubjectNotice");
	$xajax->registerFunction("submitNoticeEdit");

	$xajax->registerFunction("getSubjectBook");
	$xajax->registerFunction("submitEditBook");
	$xajax->registerFunction("deleteSubjectBook");
	$xajax->registerFunction("newSubjectBook");

	$xajax->registerFunction("getSubjectStudent");

	$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
	  <title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="index.css" rel="stylesheet" type="text/css">
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/fade.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/cookies.js"></script>
		<script language="javascript" type="text/javascript" src="./js/course.js"></script>

		<script langusge='JavaScript'>
		<!--
			function editSubjectDetail(){
				//xajax.$('co').innerHTML="<input type='text' id='cot' size='80' value='"+xajax.$('co').innerHTML+"'>";
				if(xajax.$('co').innerHTML=="ปริญญาตรี")
					xajax.$('co').innerHTML="<select id='cot'><option value='ปริญญาตรี' selected>ปริญญาตรี<option value='ปริญญาโท'>ปริญญาโท</select>";
				else
					xajax.$('co').innerHTML="<select id='cot'><option value='ปริญญาตรี' >ปริญญาตรี<option value='ปริญญาโท' selected>ปริญญาโท</select>";
				xajax.$('su').innerHTML=xajax.$('su').innerHTML;
				xajax.$('nt').innerHTML="<input style='width:580px' type='text' id='ntt' size='80' value='"+xajax.$('nt').innerHTML+"'>";
				xajax.$('ne').innerHTML="<input style='width:580px' type='text' id='net' size='80'  value='"+xajax.$('ne').innerHTML+"'>";
				var creadit=xajax.$('cr').innerHTML;
				xajax.$('cr').innerHTML="<input type='text' id='crt1' size='1' maxlength='1' value='"+creadit.substr(0,1)+"'><input type='text' id='crt2' size='1' maxlength='1' value='"+creadit.substr(4,1)+"'><input type='text' id='crt3' size='1' maxlength='1' value='"+creadit.substr(8,1)+"'>";
				xajax_getAllSubject(xajax.$('sc').innerHTML);
				xajax.$('de').innerHTML="<textarea id='det' rows='10' cols='70' style='width:580px'>"+xajax.$('de').innerHTML+"</textarea>";

				xajax.$('st').innerHTML="<textarea id='stt' rows='3' cols='70' style='width:580px'>"+xajax.$('st').innerHTML+"</textarea>";
				xajax.$('gu').innerHTML="<textarea id='gut' rows='5' cols='70' style='width:580px'>"+xajax.$('gu').innerHTML+"</textarea>";
				xajax.$('bo').innerHTML="<textarea id='bot' rows='5' cols='70' style='width:580px'>"+xajax.$('bo').innerHTML+"</textarea>";
				xajax.$('po').innerHTML="<textarea id='pot' rows='8' cols='70' style='width:580px'>"+xajax.$('po').innerHTML+"</textarea>";
				//xajax.$('le').innerHTML="<input type='text' id='let' size='80' value='"+xajax.$('le').innerHTML+"'>";
				xajax.$('ed').innerHTML="<hr width='600px'><a href='javascript:void compleatSubjectDetail();'><img src='../images/Button/submit.gif' border='0' alt='submit'></a>";
			}
			function compleatSubjectDetail(){
				if(confirm('คุณต้องการแก้ไขข้อมูลหรือไม่...')){
					xajax_toEditSubjectDetail(xajax.$('su').innerHTML,xajax.$('cot').value,xajax.$('ntt').value,xajax.$('net').value,xajax.$('crt1').value+","+xajax.$('crt2').value+","+xajax.$('crt3').value,xajax.$('sct').value,xajax.$('det').value,xajax.$('stt').value,xajax.$('gut').value,xajax.$('bot').value,xajax.$('pot').value);
					xajax.$('co').innerHTML=xajax.$('cot').value;
					//xajax.$('su').innerHTML=xajax.$('sut').value;
					xajax.$('nt').innerHTML=xajax.$('ntt').value;
					xajax.$('ne').innerHTML=xajax.$('net').value;
					xajax.$('cr').innerHTML=xajax.$('crt1').value+" ( "+xajax.$('crt2').value+" - "+xajax.$('crt3').value+" )";
					
					xajax.$('sc').innerHTML=xajax.$('sct').value;
					
					xajax.$('de').innerHTML=xajax.$('det').value;
					xajax.$('st').innerHTML=xajax.$('stt').value;
					xajax.$('gu').innerHTML=xajax.$('gut').value;
					xajax.$('bo').innerHTML=xajax.$('bot').value;
					xajax.$('po').innerHTML=xajax.$('pot').value;
					//xajax.$('le').innerHTML=xajax.$('let').value;
					xajax.$('ed').innerHTML="<a href='javascript:void editSubjectDetail();' ><img src='../images/Button/edit.gif' border='0' alt='edit'></a>";
				}
			}
			function deleteSubjectNotice(notice_id){
				if(confirm('คุณต้องการลบข้อมูลนี้หรือไม่...')){
					xajax.$('allsubjecttopic').removeChild(xajax.$(notice_id));
					xajax.$('allsubjecttopic').removeChild(xajax.$('d'+notice_id));
					//xajax.$(notice_id).innerHTML="";
					xajax_deleteSubjectNotice(notice_id);
				}
			}
			function addSubjectNotice(){
				xajax.$('newsubjectnotice').innerHTML=""+
					"หัวข้อ :<input type='text' id='subjecttopic' size='75' style='width:480px;'><br>รายละเอียด: <br>"+
					"<textarea id='txtsubjectdetail' rows='10' cols='60' style='width:700px;height:300px;'></textarea><br>"+
					"<a href='javascript:void xajax_addSubjectNotice(xajax.$(\"subjectselect\").value,xajax.$(\"subjecttopic\").value,tinyMCE.getContent(\"MCEControlID1\"));tinyMCE.removeMCEControl(\"MCEControlID1\");'><img src='../images/Button/submit.gif' border='0' alt='submit'></a> <a href='javascript:void tinyMCE.removeMCEControl(\"MCEControlID1\");hideSubjectNotice();'><img src='../images/Button/hide.gif' border='0' alt='hide'></a>";
				tinyMCE.addMCEControl(xajax.$('txtsubjectdetail'),'MCEControlID1');
				xajax.$('newsubjectnotice').style.border="1px solid";
				xajax.$('subjecttopic').focus();
			}
			function hideSubjectNotice(){
				xajax.$('newsubjectnotice').innerHTML="<a href='javascript:void addSubjectNotice();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a>";
				xajax.$('newsubjectnotice').style.border="none";
			}
			function viewSubjectDetail(notice_id){
				xajax.$(notice_id).style.display='none';
				xajax.$('d'+notice_id).style.display='block';
			}
			function hideSubjectDetail(notice_id){
				xajax.$('d'+notice_id).style.display='none';
				xajax.$(notice_id).style.display='block';
			}
			function editSubjectNotice(notice_id){
				tmptopic[notice_id]=xajax.$('sbt'+notice_id).innerHTML;
				tmpdetail[notice_id]=xajax.$('sbd'+notice_id).innerHTML;
				viewSubjectDetail(notice_id);
				xajax.$('sbt'+notice_id).innerHTML="<input type='text' id='sbtt"+notice_id+"' size='80' value='"+xajax.$('sbt'+notice_id).innerHTML+"'>";
				xajax.$('sbd'+notice_id).innerHTML="<textarea id='sbdt"+notice_id+"' rows='8' cols='80' style='width:700px;height:300px;'>"+xajax.$('sbd'+notice_id).innerHTML+"</textarea>";
				xajax.$('sbo'+notice_id).innerHTML="<a href='javascript:void submitNoticeEdit("+notice_id+");'><img src='../images/Button/submit.gif' border='0' alt='submit'></a> <a href='javascript:void cancleEdit("+notice_id+");'><img src='../images/Button/cancel.gif' border='0' alt='cancle'></a>";
				tinyMCE.addMCEControl(xajax.$('sbdt'+notice_id),'MCEControlID'+notice_id);
			}
			function submitNoticeEdit(notice_id){
				xajax.$('tpp'+notice_id).innerHTML="<a href='javascript:void viewSubjectDetail("+notice_id+");'>"+xajax.$('sbtt'+notice_id).value+"</a>";
				xajax.$('sbt'+notice_id).innerHTML=xajax.$('sbtt'+notice_id).value;
				var tmp=tinyMCE.getContent('MCEControlID'+notice_id);
				tinyMCE.removeMCEControl('MCEControlID'+notice_id);
				xajax.$('sbd'+notice_id).innerHTML=tmp;
				xajax.$('sbo'+notice_id).innerHTML="<a href='javascript:void editSubjectNotice("+notice_id+");'><img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> "+
				"<a href='javascript:void hideSubjectDetail("+notice_id+");'><img src='../images/Button/hide.gif' border='0' alt='ซ่อน'></a>";
				xajax_submitNoticeEdit(notice_id,xajax.$('sbt'+notice_id).innerHTML,xajax.$('sbd'+notice_id).innerHTML);
			}
			function cancleEdit(notice_id){
				tinyMCE.removeMCEControl('MCEControlID'+notice_id);
				xajax.$('sbt'+notice_id).innerHTML=tmptopic[notice_id];
				xajax.$('sbd'+notice_id).innerHTML=tmpdetail[notice_id];
				xajax.$('sbo'+notice_id).innerHTML="<a href='javascript:void editSubjectNotice("+notice_id+");'><img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> "+
				"<a href='javascript:void hideSubjectDetail("+notice_id+");'><img src='../images/Button/hide.gif' border='0' alt='ซ่อน'></a>";
				hideSubjectDetail(notice_id);
			}
			function getFileDetail(book_id){
				xajax.$(book_id).style.display='none';
				xajax.$('d'+book_id).style.display='block';
			}
			function hideFileDetail(book_id){
				xajax.$('d'+book_id).style.display='none';
				xajax.$(book_id).style.display='block';
			}

			function editSubjectBook(book_id,book_name){
				tmpdetail[book_id]=xajax.$('sbd'+book_id).innerHTML;
				xajax.$('sbd'+book_id).innerHTML="<textarea id='sbdt"+book_id+"' style='width:730px;' rows='3' cols='50'>"+xajax.$('sbd'+book_id).innerHTML+"</textarea>";
				xajax.$('sbo'+book_id).innerHTML="<a href='javascript:void submitEditBook("+book_id+",\""+book_name+"\")'>"+
					"<img src='../images/Button/submit.gif' border='0' alt='submit'></a>"+
					"<a href='javascript:void cancleEditBook("+book_id+",\""+book_name+"\")'>"+
					"<img src='../images/Button/cancel.gif' border='0' alt='cancle'></a>";
				//getFileDetail(book_id);
			}
			function submitEditBook(book_id,book_name){
				//xajax.$('sbd'+book_id).innerHTML="<a href='javascript:void getFileDetail("+book_id+");'>"+xajax.$('sbdt'+book_id).value+"</a>";
				xajax.$('sbd'+book_id).innerHTML=xajax.$('sbdt'+book_id).value;
				xajax.$('sbo'+book_id).innerHTML="<a href='javascript:void downloadFile(\""+book_name+"\");'>"+
					"<img src='../images/Button/download.gif' border='0' alt=''></a>"+
					"<a href='javascript:void editSubjectBook("+book_id+",\""+book_name+"\")'>"+
					"<img src='../images/Button/edit.gif' border='0' alt='edit'></a>"+
					"<a href='javascript:void hideFileDetail("+book_id+")'>"+
					"<img src='../images/Button/hide.gif' border='0' alt='hide'></a>";
				xajax_submitEditBook(book_id,xajax.$('sbd'+book_id).innerHTML);
			}
			function cancleEditBook(book_id,book_name){
				xajax.$('sbd'+book_id).innerHTML=tmpdetail[book_id];
				xajax.$('sbo'+book_id).innerHTML="<a href='javascript:void downloadFile(\""+book_name+"\");'>"+
					"<img src='../images/Button/download.gif' border='0' alt=''></a>"+
					"<a href='javascript:void editSubjectBook("+book_id+",\""+book_name+"\")'>"+
					"<img src='../images/Button/edit.gif' border='0' alt='edit'></a> "+
					"<a href='javascript:void hideFileDetail("+book_id+")'>"+
					"<img src='../images/Button/hide.gif' border='0' alt='hide'></a>";
				hideFileDetail(book_id);
			}
			function deleteSubjectBook(book_id){
				if(confirm("คุณแน่ใจหรือที่จะลบไฟล์นี้...")){
					xajax.$('allsubjectbook').removeChild(xajax.$(book_id));
					xajax.$('allsubjectbook').removeChild(xajax.$('d'+book_id));
					xajax_deleteSubjectBook(book_id);
				}
			}
			function newSubjectBook(subject_id){
				xajax.$('newsubjectbook').innerHTML="<iframe width='500px' height='250px'  src='./upload/index.php?path=./file/&subject_id="+subject_id+"'></iframe><br><a href='javascript:void hideNewSubjectBook("+subject_id+");'><img src='../images/Button/hide.gif' border='0' alt='Hide'></a><br>";
				xajax.$('newsubjectbook').style.border="1px solid";
				//Set_Cookie("subject",subject_id,3600);
				Set_Cookie("uploadstatus","uploading",3600);
				setTimeout("checkupload()",1000);
			}
			function hideNewSubjectBook(subject_id){
				xajax.$('newsubjectbook').innerHTML="<br><a href='javascript:void newSubjectBook("+subject_id+");'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a><br>";
				xajax.$('newsubjectbook').style.border="none";
			}
			function checkupload(){
				if(Get_Cookie("uploadstatus")=='uploading'){
					setTimeout("checkupload()",1000);
				}
				else if(Get_Cookie("uploadstatus")=="uploaded"){

					var tmpstr=Get_Cookie("fileinfo");
					
					var tmpstr=tmpstr.replace(/@/g," ");
					var tmpstr=tmpstr.split(",");
					var tmpimg="<a href='javascript:void getFileDetail("+tmpstr[0]+");editSubjectBook("+tmpstr[0]+");'><img src='../images/edit.gif'></a> <a href='javascript:void deleteSubjectBook("+tmpstr[0]+");'><img src='../images/delete.gif'></a>";

					var returnstr="<div id='d"+tmpstr[0]+"' class='sbbookdetail' >รายละเอียด <br><span id='sbd"+tmpstr[0]+"'>"+Get_Cookie("detail")+"</span><br><span id='sbo"+tmpstr[0]+"'><a href='javascript:void downloadFile();'>download</a> <a href='javascript:void editSubjectBook("+tmpstr[0]+");'><img src='../images/Button/edit.gif' border='0' alt='edit'></a> <a href='javascript:void hideFileDetail("+tmpstr[0]+");'>hide</a></span></div>";
					


					returnstr+="<div id='"+tmpstr[0]+"' style='width:765px;'><div class='sbbook2'><img src='../images/"+
						tmpstr[3]+".jpg'></div><div class='sbbook3'><a href='javascript:void getFileDetail("+tmpstr[0]+
						");' >"+tmpstr[1]+"</a></div><div class='sbbook4'>"+tmpstr[5]+"</div><div class='sbbook5'>"+
						tmpstr[6]+"น.</div><div class='sbbook6'>"+tmpstr[7]+"</div><div class='sbbook7'>"+tmpimg+"</div></div>";
					//alert(returnstr);
					xajax.$('allsubjectbook').innerHTML=returnstr+xajax.$('allsubjectbook').innerHTML;
				
					hideNewSubjectBook(Get_Cookie("subject"));
					Delete_Cookie("subject");
					Delete_Cookie("uploadstatus");
					Delete_Cookie("fileinfo");
				}
				else{

					Delete_Cookie("subject");
					Delete_Cookie("uploadstatus");
					alert("Upload error");
				}
			}
			function downloadFile(file_name){
			
				window.open("./upload/file/"+file_name);
			}
		//-->
		</script>
		<?php $xajax->printJavascript('../tool/xajax/'); ?>
	</head>
	
	<body class="site" >
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="../images/logo.gif" ></p>
		<center>
			<!-- menu -->
			<div style='text-align:center;width:765px;'>
				<div class="menu" >
					<li id="six"><a href='../'>หน้าแรก</a></li>
					<li id="one"><a href='../subject/'>หลักสูตร</a></li>
					<li id="two"><a href='../lecturer/'>บุคลากร</a></li>
					<li id="three"><a href='../laboratory/'>ห้องวิจัย</a></li>
					<li id="four"><a href='../webboard/'>เว็บบอร์ด</a></li>
					<li id="five"><a href='../alumni/'>ศิษย์เก่า</a></li>
					<li id="last"><a href='../user_management/showlist_member.php'>สมาชิก</a></li>
				</div>
				<div style="width:765px;">
					<!-- logo -->
					<div style='float:left;'><img src="../images/Books.png" style='border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'></div>
					<!-- login -->
					<div class='login'>
						<?php checklogin(); ?>
					</div>
				</div>
				<div style="float:left;width:765px;">
					<!-- หลักสูตร -->
					<div style="text-align:left;font-weight:bold;">
						<font face="Angsana New" color="#0066FF" style="font-size: 16pt">โครงสร้างหลักสูตรวิศวกรรมคอมพิวเตอร์</font><br>
						<div style='background: url(../images/bar_1.png) no-repeat;padding:5px;'><a href='javascript:void getCourse1();'>หลักสูตรปริญญาตรี</a> <a href='javascript:void getCourse2();'>หลักสูตรปริญญาโท</a></div>
						<font face="Angsana New" color="#0066FF" style="font-size: 16pt">รายวิชาวิศวกรรมคอมพิวเตอร์</font><br>
						<?php
							$sql="SELECT `TYPE` FROM `subject` GROUP BY `TYPE`";
							mysql_db_query($dbname,"SET NAMES 'UTF8'");
							if($dbquery=mysql_db_query($dbname,$sql)){
								echo "<select id='subjecttype' onChange='javascript:void xajax_getSubject(xajax.$(\"subjecttype\").value)'>
											<option>เลือกกลุ่มวิชา</option>";
								while($result=mysql_fetch_array($dbquery)){
									echo "<option value='$result[TYPE]'>".$result['TYPE']."</option>";
								}
								echo "</select>";
							}
						?>
						<span id='subjectlist'>
							<select >
								<option value='' selected>เลือกรายวิชา
							</select>
						</span><br><br>
						<div id="subjectmenu"></div>
						<div id="subjectdetail"></div>
						
						<script langusge='JavaScript'>
						<!--
							getCourse1();
						//-->
						</script>
						<?php
						if(isset($subject))
							echo "<script langusge='JavaScript'>xajax_getSubjectDetail(<?php echo $subject;?>);</script>";
						?>
			</div><br><br>
			<div style="width:800px;float:left;" >
				<font color="#666666">Department of Computer Engineering Faculty of Engineering King Mongkut's 
					Institute of Technology<br>
					Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404<br>
					<span lang="th">ส่งคำติชม</span>
				</font><a href="mailto:webmaster@ce.kmitl.ac.th">webmaster@ce.kmitl.ac.th</a>
			</div>
		</center>
	</body>
</html>