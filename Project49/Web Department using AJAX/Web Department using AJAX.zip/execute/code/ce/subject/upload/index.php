<?php
	require_once("../../_Sessionstart.php");
	require_once("../../connectdb.inc.php");
	//require_once("../tool/xajax/xajax.inc.php");
	//require_once("../checklogin.inc.php");
	/*if(!isset($notice_id)){
		$sql="SELECT MAX(`NOTICE_ID`) AS MAXID FROM main_notice";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$result=mysql_fetch_array($dbquery);
			$notice_id=$result['MAXID']+1;
		}
	}*/
?>
<html>
	<head>
		<title>Upload Progress</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="./index.css" />
		<script type="text/javascript" src="LoadVars.js"> <!--// http://www.devpro.it/javascript_id_92.html //--></script>
		<script type="text/javascript" src="BytesUploaded.js"><!--// http://www.devpro.it/javascript_id_96.html //--></script>
		<script type="text/javascript" src="../tool/cookies.js"></script>
		<script type="text/javascript">
			var bUploaded = new BytesUploaded('whileuploading.php');
		</script>
	</head>
	<body class='site'>
		<form  enctype="multipart/form-data" method="post" action='<?php echo "index.php?path=$path&subject_id=$subject_id";?>' onsubmit="bUploaded.start('fileprogress'); ">
			<div>
				<fieldset >
					<legend>Add a file</legend>
					<input id="filename" type="file" name="gfile" style='width:400px;'/>
					<textarea name='dfile' rows='' cols='' style='width:400px;height:100px;'></textarea><br>
					<input type="submit" value="upload" />
				</fieldset>
			</div>
			<div id="fileprogress"><?php if($_FILES) echo "Upload Complete...";?></div>
			<pre style="font-weight: bold;">
		<?php 
		
			if($_FILES){
				//echo "Upload Compleat...";
				$tmpfile=$_FILES['gfile']['tmp_name'];
				$filename=$_FILES['gfile']['name'];
				$filepath=$path;
				$filesize=$_FILES['gfile']['size'];
				if(!is_dir($filepath))
					mkdir($filepath, 0757);
				$count=0;
				while(is_file($filepath.$filename)){
					 if(eregi("(.*)\(([0-9]+)\)\.(.{2,4})",$filename, $regs)) 
						$filename=$regs[1]."(".($regs[2]+1).").$regs[3]";
					else if(eregi("(.+)\.(.{2,4})",$filename,$regs))
						$filename=$filename=$regs[1]."(1).$regs[2]";
				}
				if (copy($tmpfile,$filepath.$filename)) {
					$fileinfo=pathinfo($filepath.$filename);
					$fileext=$fileinfo['extension'];
					
					if(strpos("_,jpg,jpeg,png,gif,bmp,tif,_",$fileext))
						$filetype="image";
					else if(strpos("_,mp3,ogg,wmv,wma,wav,avi,rm,3gp,mpeg,mpg,_",$fileext))
						$filetype="sound";
					else if(strpos("_,pdf,_",$fileext))
						$filetype="acrobat";
					else if(strpos("_,doc,txt,_",$fileext))
						$filetype="document";
					else if(strpos("_,ppt,_",$fileext))
						$filetype="powerpoint";
					else if(strpos("_,zip,rar,tar,gz_",$fileext))
						$filetype="package";
					else
						$filetype="notype";

					$sql="INSERT INTO $tb_subject_book (`SUBJECT_ID` , `NAME` , `DETAIL` , `TYPE` , `PATH` , `SIZE` , `CREATE` , `BY`)VALUES ('$subject_id', '$filename', '$dfile', '$filetype', '$filepath', '$filesize', '".time()."', '$_SESSION[ss_UserName]')";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if(mysql_db_query($dbname,$sql)){
						$sql="SELECT MAX(`BOOK_ID`) AS MAXID FROM $tb_subject_book";
						mysql_db_query($dbname,"SET NAMES 'UTF8'");
						if($dbquery=mysql_db_query($dbname,$sql)){
							$result=mysql_fetch_array($dbquery);
							$book_id=$result['MAXID'];
						}
						$toEval=0;
						$typesize = array( 'bytes', 'Kb', 'Mb', 'Gb', 'Tb', 'Zb' );
						while($filesize > 1024 ) {
							$filesize = round(($filesize / 1024),2);
							$toEval++;
						}
						$filesize="$filesize $typesize[$toEval]";
						setcookie("uploadstatus","uploaded",time()+3600,"/ce/subject/");
						//$_COOKIE['uploadstatus']="uploaded";
						$thistime=date("j-n-y G:i ",time());
						setcookie("fileinfo",str_replace(" ","@","$book_id,$filename,$fileext,$filetype,$filepath,$filesize,$thistime,$_SESSION[ss_UserName]"),time()+3600,"/ce/");
						setcookie("detail",iconv("tis-620","UTF-8",$dfile),time()+3600,"/ce/subject/");
						setcookie("subject",$subject_id,time()+3600,"/ce/subject/");
					}
					else
						echo "ไม่สามารถเพิ่มข้อมูลได้..$sql";
				}
				else
					 echo "failed copy $tmpfile to $filepath...\n";
			}
		?>
		</pre>
		</form>
	</body>
</html>