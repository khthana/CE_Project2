<?php
	$dbhostname="localhost";
	$dbuser="root";
	$dbpassword="root";
	//$dbpassword="vkc0H8cvxr]bg8=yjo";
	$dbname="ce";
	

//
	$tb_profile="profile";
	$tb_topic="topic";
	$tb_content="personal_content";
	$tb_comment="comment";
	$tb_useraccount="useraccount";
	$tb_personnel="personnel";
//˹����ѡ
	$tb_main_notice="main_notice";
	$tb_main_fileupload="main_fileupload";

//�к�����Ԫ�
	$tb_subject="subject";
	$tb_subject_notice="subject_notice";
	$tb_subject_book="subject_book";
	$tb_subject_student="subject_student";
	$tb_subject_lecturer="subject_lecturer";
	$tb_student="student";
	$tb_lecturer="lecturer";

//�к���ͧ�ź
	$tb_laboratory="laboratory";
	$tb_laboratory_member="laboratory_member";
	$tb_group_project="group_project";
	$tb_group_project_advicor="group_project_advicor";
	$tb_group_project_member="group_project_member";
//�к��ؤ�ҡ�
	$tb_lecturer="lecturer";
//�к���������
	$tb_alumni="alumni";
	$tb_alumni_notice="alumni_notice";
//�к� Blog ����Ԫ�
	$tb_bgprofile="blog_profile";
	$tb_bgentry="blog_entry";
	$tb_bgcomment="blog_comment ";
	$tb_bgcategory="blog_category";
	$tb_bgfavourite="blog_favourite";
	$tb_bglink="blog_link";
	$tb_bgvote="blog_vote";
	mysql_connect($dbhostname,$dbuser,$dbpassword) or die( "�������ö�Դ server "+$dbhostname+ "��");
	mysql_select_db($dbname) or die("�������ö���͡�ҹ������ "+$dbname+" ��");
	//mysql_db_query($dbname,"SET NAMES 'tis620'");



	$rootpath="/ce/";
	$pathlogin="https://localhost/ce/user_management/showlogin.php";
?>
