<?php

	require_once("./_Sessionstart.php");
	require_once("./connectdb.inc.php");
	require_once("./tool/xajax/xajax.inc.php");
	require_once("./checklogin.inc.php");
	require_once("./notice.inc.php");
	require_once("./getnotice1.inc.php");
	require_once("./getnotice2.inc.php");
	//

	
	
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");
	$xajax->registerFunction("getMainNotice1");
	$xajax->registerFunction("getMainNotice2");
	$xajax->registerFunction("submitNewNotice");
	$xajax->registerFunction("deleteNotice");
	$xajax->registerFunction("submitEditNotice");
	$xajax->registerFunction("submitEditNotice");

	$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
	  <title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="index.css" rel="stylesheet" type="text/css">
		<style>
			.search a:link,.search a:visited{
				color:#000000;
				font-weight:bold;
			}
			.search a:hover{
				color:#B0B0B0;
			}
			.search input{
				width:150px;
				padding:0px;
				margin:0px;
			}
			.search{
				padding:0px 30px 0px 0px;
			}
		</style>
		<script langusge='JavaScript'>
		<!--
			
		//-->
		</script>
		<?php $xajax->printJavascript('./tool/xajax/'); ?>
		<script language="javascript" type="text/javascript" src="./tool/cookies.js"></script>
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="./cookies.js"></script>
		<script language="javascript" type="text/javascript" src="./mousepoint.js"></script>
		<script language="javascript" type="text/javascript" src="./tool/fade.js"></script>
		<!-- <script language="javascript" type="text/javascript" src="./tool/hidestatus.js"></script>  -->
		<script language="javascript" type="text/javascript" src="./notice.js"></script>

		<!-- tinyMCE -->
		<script language="javascript" type="text/javascript" src="./tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript" src="./tool/tinymce/jscripts/tiny_mce/tiny_mce_init1.js"></script>
		<!-- /tinyMCE -->
	</head>

	<body class="site" >
		
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="./images/logo.gif" ></p>
		<center>
			<!-- menu -->
			<div style='text-align:center;width:765px;'>
				<div class="menu" >
					<li id="six"><a href='./'>หน้าแรก</a></li>
					<li id="one"><a href='./subject/' target='_blank'>หลักสูตร</a></li>
					<li id="two"><a href='./lecturer/' target='_blank'>บุคลากร</a></li>
					<li id="three"><a href='./laboratory/' target='_blank'>ห้องวิจัย</a></li>
					<li id="four"><a href='./webboard/' target='_blank'>เว็บบอร์ด</a></li>
					<li id="five"><a href='./alumni/' target='_blank'>ศิษย์เก่า</a></li>
					<li id="last"><a href='./user_management/showlist_member.php' target='_blank'>สมาชิก</a></li>
				</div>
				<div style="width:765px;">
					<!-- logo -->
					<div ><img  src="./images/CE.png" style='float:left;border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'>
					</div>
					<!-- login -->
					<div class='login'>
						<?php checkLogin();?>
					</div>
				</div>
				<div style="width:765px;">
					<div style='width:584px;float:left;'>
						<div >
							<table cellpadding="0" cellspacing="0" border="0" width='100%' height='320px'>
								<tr><td  background="./images/submenu_2.png" height='23px'><span class='bar'>ประกาศข่าวทั่วไป</span></td></tr>
								<tr><td id='notice1' style='font-size:12px;text-align:left;vertical-align:top;height:250px;padding-top:10px;'></td></tr>
								<tr><td align='left' id='bt1'></td></tr>
							</table>
							<table cellpadding="0" cellspacing="0" border="0"  width='100%' height='320px'>
								<tr><td  background="./images/Submenu.png" height='23px'><span class='bar'>ประกาศทางวิชาการ</span></td></tr>
								<tr><td id='notice2' style='font-size:12px;text-align:left;vertical-align:top;height:250px;padding-top:10px;'></td></tr>
								<tr><td align='left' id='bt2'></td></tr>
							</table>
							<script langusge='JavaScript'>
							<!--
								xajax_getMainNotice1(1);
								xajax_getMainNotice2(1);
							//-->
							</script>
						</div>
					</div>
					<div style='width:178px;float:left;'>
						<div class='rightmenu' style='background-image:url(./images/submenu2.png);background-color:#DAE9FE;'>
						<span class='bar'>โฮมเพจภายใน</span><br>
						<span >
							<br><a href='http://www.kmitl.ac.th'><img src='./images/KMITL.png' border='0' alt='เว็บสถาบัน'></a>
							<a href='http://www.kmitl.ac.th/webboard/'><img src='images/webboard.png' border='0' alt='เว็บบอร์ดสถาบัน'></a>
							<a href='http://webmail.kmitl.ac.th/'><img src='images/webmail.png' border='0' alt='เว็บเมล์สถาบัน'></a>
							<a href='http://www.reg.kmitl.ac.th/index/index.php'><img src='images/register.png' border='0' alt='สำนักทะเบียน'></a>
							<a href='http://161.246.37.11/'><img src='images/libary.png' border='0' alt='หอสมุดกลาง'></a>
							<a href='./bce/'><img src='images/engineer.png' border='0' alt='คณะวิศวกรรมศาสตร์'></a>
						</span>
					</div>
						<div class='rightmenu' style='background-image:url(./images/submenu1.png);background-color:#E4FFCA;padding-top:10px;'><span class='bar'>ข่าวที่น่าสนใจ <img src='images/RSS.gif' border='0' alt=''></span>
							<br>
							<iframe src='getRSS.php' width='178px' height='300px' frameBorder='no' scrolling='no'></iframe>
							
						</div>
					</div>
				</div>
			<div class='contect'><hr>
				Department of Computer Engineering Faculty of Engineering King Mongkut's 
					Institute of Technology<br>
					Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404<br>
					<span lang="th">ส่งคำติชม</span>
				<a href="mailto:webmaster@ce.kmitl.ac.th" style='color:#000000;'>webmaster@ce.kmitl.ac.th</a>
			</div>
		</center>
	</body>
</html>

