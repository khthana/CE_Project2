
function submitNewNotice(type){
	if(tinyMCE.getContent('MCEControlID'+type)=="" || xajax.$('topicnotice'+type).value==""){
		alert("กรุณากรอกข้อมูลให้ครบ");
		return 0;
	}
	xajax_submitNewNotice(xajax.$('topicnotice'+type).value,tinyMCE.getContent('MCEControlID'+type),type);
	if(xajax.$('allnotice'+type).childNodes.length>=16)
		xajax.$('allnotice'+type).removeChild(xajax.$('allnotice'+type).childNodes[14]);
	tinyMCE.removeMCEControl('MCEControlID'+type);
	xajax.$('topicdetail'+type).value="";
	xajax.$('topicnotice'+type).value="";
	xajax.$('newnotice'+type).style.display='none';
}

function showNoticDetail(from,notice_id){
	
	xajax.$('noticedetail'+notice_id).style.display='block';
	
	if(from==1){
		xajax.$('noticedetail'+notice_id).style.border="1px solid #009700";
		fadeIn('noticedetail'+notice_id,'#D1FFC1','bg');
	}
	else{
		xajax.$('noticedetail'+notice_id).style.border="1px solid #0000FF";
		fadeIn('noticedetail'+notice_id,'#D7EBFF','bg');
	}
	xajax.$('noticedetail'+notice_id).style.display='block';
	
}
function hideNoticDetail(notice_id){
	xajax.$('noticedetail'+notice_id).style.display='none';
}

function editNotice(type,notice_id){
	this.tmptopic=xajax.$('nt'+notice_id).innerHTML;
	this.tmpdetail=xajax.$('nd'+notice_id).innerHTML;
	xajax.$('nt'+notice_id).innerHTML="<input style='width:400px;' type='text' id='ntt"+notice_id+"' value='"+xajax.$('nt'+notice_id).innerHTML+"'>";
	xajax.$('nd'+notice_id).innerHTML="<center><textarea id='ndt"+notice_id+"' rows='30' cols='70' style='width:725px;'>"+xajax.$('nd'+notice_id).innerHTML+"</textarea></center>";
	tinyMCE.addMCEControl(xajax.$('ndt'+notice_id),'MCEControlID'+notice_id);
	xajax.$('adminmode'+notice_id).innerHTML="<a href='javascript:void submitEditNotice("+type+","+notice_id+",xajax.$(\"ntt"+notice_id+"\").value,tinyMCE.getContent(\"MCEControlID"+notice_id+"\"));'><img src='./images/submit1.gif' border='0' alt='submit'></a>  <a href='javascript:void cancleEditNotce("+type+","+notice_id+");'><img src='./images/cancle1.gif' border='0' alt='cancle'></a>";
}

function deleteNotice(type,notice_id){
	if(confirm("คุณต้องการลบหัวข้อนี้หรือไม่...")){
		xajax_deleteNotice(notice_id);
		xajax.$('allnotice'+type).removeChild(xajax.$('notice'+type+notice_id));
		xajax.$('allnotice'+type).removeChild(xajax.$('noticedetail'+notice_id));
	}
}

function cancleEditNotce(type,notice_id){
	tinyMCE.removeMCEControl('MCEControlID'+notice_id);
	xajax.$('nt'+notice_id).innerHTML=tmptopic;
	xajax.$('nd'+notice_id).innerHTML=tmpdetail;
	xajax.$('adminmode'+notice_id).innerHTML="<a href='javascript:void editNotice("+type+","+notice_id+");'><img src='./images/edit1.gif' border='0' alt='edit'></a> <a href='javascript:void deleteNotice("+type+","+notice_id+");'><img src='./images/delete1.gif' border='0' alt='delete'></a>"
}

function submitEditNotice(type,notice_id,topic,detail){
	if(topic==""){
		alert("กรุณาใส่เรื่องที่จะประกาศ...");
		xajax.$('ntt'+notice_id).focus();
	}
	else if(detail==""){
		alert("กรุณาใส่ข้อมูล...");
	}
	else{
		xajax_submitEditNotice(notice_id,topic,detail);
		tinyMCE.removeMCEControl('MCEControlID'+notice_id);
		xajax.$('nt'+notice_id).innerHTML=topic;
		xajax.$('nd'+notice_id).innerHTML=detail;
		xajax.$('adminmode'+notice_id).innerHTML="<a href='javascript:void editNotice("+type+","+notice_id+");'><img src='./images/edit1.gif' border='0' alt='edit'></a> <a href='javascript:void deleteNotice("+type+","+notice_id+");'><img src='./images/delete1.gif' border='0' alt='delete'></a>"
	}
}

function canceladd(type){
	xajax.$('newnotice'+type).style.display='none';
	tinyMCE.removeMCEControl('MCEControlID'+type);
	xajax.$('topicdetail'+type).value='';
	xajax.$('topicnotice'+type).value='';
	xajax.$('if'+type).src='./upload/index.php?path=./file/';
	
	
}

function checkupload(){
	if(!Get_Cookie('uploadstatus')){
		//alert(Get_Cookie('uploadstatus'));
		window.setTimeout("checkupload()",2000);
	}
	else{
		alert("upload compleat");
	}
}
this.searchtime=3;
function viewsearch(id){
	if(this.searchtime>0){
		xajax.$('shsearch'+id).style.display='block';
		setTimeout('viewsearch('+id+')',1000);
		xajax.$('txsearch'+id).focus();
		this.searchtime--;
	}
	else{
		xajax.$('shsearch'+id).style.display='none';
		this.searchtime=3;
	}
}
function closesearch(id){
	xajax.$('shsearch'+id).style.display='none';
	this.searchtime=0;
}