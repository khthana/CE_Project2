﻿ns4 = (document.layers)? true:false 
ie4 = (document.all)? true:false 

//document.onmouseover = mouseMove;

function mouseMove(ev){
	ev = ev || window.event;
	this.mousePos = mouseCoords(ev);
}

function mouseCoords(ev){
	if(ev.pageX || ev.pageY){
		return {x:ev.pageX, y:ev.pageY};
	}
	return {
		x:ev.clientX+document.documentElement.scrollLeft,
		y:ev.clientY+document.documentElement.scrollTop
	};
}// - document.body.clientLeft+240- document.body.clientTop+240