function getLoginTime(){
	var e = new Date();
	var loginhour=Math.floor((e.getTime()-d.getTime())/3600000)%24;
	var loginmin=Math.floor((e.getTime()-d.getTime())/60000)%60;
	var loginsec=Math.floor((e.getTime()-d.getTime())/1000)%60;
	document.getElementById('logintime').innerHTML= loginhour+":"+loginmin+":"+loginsec+" ";
}

function logining(){
	if(Get_Cookie("login")!="ok"){
		window.setTimeout("logining()",1000);
	}
	else{
		var d=new Date();
		Delete_Cookie("login");
		xajax_isLogin(d.getTime());
		
	}
}
function islogout(){
	if(confirm("คุณต้องการที่จะออกจากระบบหรือไม่")){
		xajax_confirmLogout();
	}
}