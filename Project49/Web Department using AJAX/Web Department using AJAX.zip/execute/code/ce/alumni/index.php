<?php
	require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	require_once("../tool/xajax/xajax.inc.php");
	require_once("./checklogin.inc.php");

	function getAlumniNotice($sort=0,$sortop="ASC",$page=1){
		global $dbname,$tb_alumni,$tb_alumni_notice;
		$sorta=array("`CREATE`","`TOPIC`","`BY`");
		if($sortop=="DESC")
			$sortopnext="ASC";
		else
			$sortopnext="DESC";
		$objResponse = new xajaxResponse();
		$sql="SELECT COUNT(NOTICE_ID) AS NUMSTD FROM $tb_alumni_notice WHERE `STATUS`='1'";
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$numstd=$result['NUMSTD'];
			}
		}

		$sql="SELECT * FROM $tb_alumni_notice WHERE `STATUS`='1' ORDER BY $sorta[$sort] $sortopnext LIMIT ".(15*($page-1)).",15";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="
						<div style='width:765px;background:url(\"../images/leftbg.gif\");padding:3px 0px;'>
							<span style='padding-right:400px;padding-left:20px;'><a href='javascript:void xajax_getAlumniNotice(1,\"$sortopnext\",$page);'>หัวข้อ</a></span>
							<span style='padding-right:100px;'><a href='javascript:void xajax_getAlumniNotice(2,\"$sortopnext\",$page);'>โดย</a></span>
							<span style='padding-right:100px;'><a href='javascript:void xajax_getAlumniNotice(0,\"$sortopnext\",$page);'>เมื่อ</a></span><hr>
						</div>
				";
			$return.="<div id='alltopic' style='background:url(\"../images/leftbg.gif\")'>";
			while($result=mysql_fetch_array($dbquery)){
				//แสดงรายละเอียดของข่าวประชาสัมพันธ์
				
				$return.="<div class='topicdetail' id='d$result[NOTICE_ID]' style='font-weight:normal;border:1px solid;'>
									<div align='center'><b>เรื่อง</b> 
									<span id='dt$result[NOTICE_ID]'>$result[TOPIC]</span></div>
									<span  id='dd$result[NOTICE_ID]'>$result[DETAIL]</span>
									<div align='right'><b>ประกาศโดย</b> $result[BY]</div>
									<div id='dl$result[NOTICE_ID]'>
										<a href='javascript:void editTopicDetail($result[NOTICE_ID]);'>
											<img src='../images/Button/edit.gif' border='0' alt='แก้ไข'>
										</a> 
										<a href='javascript:void hideTopicDetail($result[NOTICE_ID]);'>
											<img src='../images/Button/cancel.gif' border='0' alt='ยกเลิก'>
										</a>
									</div><br>
								</div>";
				//แสดงหัวข้อของข่าวประชาสัมพันธ์
				$return.="<div class='topic' id='$result[NOTICE_ID]'>
									<div class='topic1' id='tp1$result[NOTICE_ID]'><a href='javascript:void viewTopicDetail($result[NOTICE_ID]);'>$result[TOPIC]</a></div>
									<div class='topic2'>$result[BY]</div>
									<div class='topic3'>".date("j-n-y G:i น.",$result['CREATE'])."</div>
									<div class='topic4'>
										<a href='javascript:void editTopicDetail($result[NOTICE_ID]);viewTopicDetail($result[NOTICE_ID]);'><img src='../images/edit.gif' alt='แก้ไขหัวข้อนี้'></a>
										<a href='javascript:void deleteTopicDetail($result[NOTICE_ID]);'><img src='../images/delete.gif' alt='ลบหัวข้อนี้'></a> ";
				if(!$result['STATUS'])
					$return.="<a href='javascript:void deleteTopicDetail($result[NOTICE_ID]);'>
										<img src='../images/isdel.gif' alt='หัวข้อนี้ถูกลบ คลิกเพื่อนำหัวข้อนี้กลับมา'></a>";
				$return.="		</div>
								</div>";
			}
			$return.="<hr></div>";
		}
		 $return.="<br><div id='newtopic' style='width:765px;text-align:center;float:left;'><a href='javascript:void newTopicDetail();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a>
			</div> ";
		$objResponse->addAssign("alumnidetail","innerHTML",$return);
		$objResponse->addScript("xajax.$(\"classselect\").selectedIndex=0;tmptopic=new Array();tmpdetail=new Array();");
		return $objResponse;
	}
	function submitTopicDetail($topic_id,$topic,$detail){
		global $dbname,$tb_alumni,$tb_alumni_notice;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_alumni_notice SET `TOPIC` = '$topic' ,`DETAIL` = '$detail' WHERE `NOTICE_ID` ='$topic_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function deleteTopicDetail($topic_id){
		global $dbname,$tb_alumni,$tb_alumni_notice;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_alumni_notice SET `STATUS` = '0' WHERE `NOTICE_ID` ='$topic_id' LIMIT 1 ";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("ลบข้อมูลเรียบร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function submitNewTopicDetail($topic,$detail){
		global $dbname,$tb_alumni,$tb_alumni_notice;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO $tb_alumni_notice (`TOPIC` , `DETAIL` , `CREATE` , `BY`)VALUES ('$topic', '$detail', '".time()."', '$_SESSION[ss_UserName]')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$sql="SELECT MAX(NOTICE_ID) AS MAXID FROM $tb_alumni_notice";
			if($dbquery=mysql_db_query($dbname,$sql)){
				while($result=mysql_fetch_array($dbquery)){
					$return="<div class='topicdetail' id='d$result[MAXID]'>
										<div align='center'><b>เรื่อง</b> <span id='dt$result[MAXID]'>$topic</span></div>
											<pre id='dd$result[MAXID]'>$detail</pre>
										<div align='right'><b>ประกาศโดย</b> $_SESSION[ss_UserName]</div>
										<div id='dl$result[MAXID]'>
											<a href='javascript:void editTopicDetail($result[MAXID]);'>
												<img src='../images/Button/edit.gif' border='0' alt='แ้ก้ไข'>
											</a> 
											<a href='javascript:void hideTopicDetail($result[MAXID]);'>
												<img src='../images/Button/cancel.gif' border='0' alt='ยกเลิก'>
											</a>
										</div><br>
								</div>";
									
						//แสดงหัวข้อของข่าวประชาสัมพันธ์
						
					$return.="<div class='topic' id='$result[MAXID]'>
										<div class='topic1' id='tp1$result[MAXID]'><a href='javascript:void viewTopicDetail($result[MAXID]);'>$topic</a></div>
										<div class='topic2'>$_SESSION[ss_UserName]</div>
										<div class='topic3'>".date("j-n-y G:i น.",time())."</div>
										<div class='topic4'>
											<a href='javascript:void editTopicDetail($result[MAXID]);viewTopicDetail($result[MAXID]);'><img src='../images/edit.gif' alt='แก้ไขหัวข้อนี้'></a>
											<a href='javascript:void deleteTopicDetail($result[MAXID]);'><img src='../images/delete.gif' alt='ลบหัวข้อนี้'></a>
										</div>
									</div>";
					$objResponse->addPrepend("alltopic","innerHTML",$return);
					$objResponse->addAlert("เพิ่มข้อมูลเรียบร้อยแล้ว...");
				}
			}
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...$sql");
		return $objResponse;
	}

	function getSelectClass($section){
		global $dbname,$tb_alumni;
		$objResponse = new xajaxResponse();
		$sql="SELECT `CLASS` FROM $tb_alumni WHERE `SECTION` = '$section' GROUP BY `CLASS`";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<select id='classselect' onchange=xajax_getAlumni(\"$section\",this.value);>
				<option value='sec' selected>เลือกรุ่น";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<option value='$result[CLASS]'>$result[CLASS]";
			}
			$return.="</select>";
		}
		else{
			$objResponse->addAlert("เกิดความผิดพลาด...");
			return $objResponse;
		}
		$objResponse->addAssign("classselectspan","innerHTML",$return);
		return $objResponse;
	}
	
	function getAlumni($section,$class){
		global $dbname,$tb_alumni;
		$objResponse = new xajaxResponse();
		$sql="SELECT * FROM $tb_alumni WHERE `SECTION` = '$section' AND `CLASS`= '$class'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="
						<div style='width:765px;background:url(\"../images/leftbg.gif\");padding:3px 0px;'>
							<span style='padding-right:50px;padding-left:20px;'><a href='javascript:void xajax_getAlumniNotice(1,\"sortopnext\",page);'>รหัสนักศึกษา</a></span>
							<span style='padding-right:120px;'><a href='javascript:void xajax_getAlumniNotice(2,\"sortopnext\",page);'>ชื่อ-นามสกุล</a></span>
							<span style='padding-right:70px;'><a href='javascript:void xajax_getAlumniNotice(0,\"sortopnext\",page);'>ชื่อเล่น</a></span>
							<span style='padding-right:100px;'>อีเมลล์</span><hr>
						</div> ";
			$return.="<div style='width:765px;background:url(\"../images/leftbg.gif\")'>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<div  id='$result[ALUMNI_ID]'>
									<div class='alumni1' id='tp1$result[ALUMNI_ID]'><a href='javascript:void viewTopicDetail($result[ALUMNI_ID]);'>$result[STUDENT_ID] </a></div>
									<div class='alumni2'>$result[FIRST_NAME] $result[LAST_NAME]</div>
									<div class='alumni3'>$result[NICK_NAME]</div>
									<div class='alumni4'>$result[EMAIL]</div>
									<div class='alumni5'>
										<a href='javascript:void editTopicDetail($result[ALUMNI_ID]);viewTopicDetail($result[ALUMNI_ID]);'><img src='../images/edit.gif' alt='แก้ไขหัวข้อนี้'></a>
											<a href='javascript:void deleteTopicDetail($result[ALUMNI_ID]);'><img src='../images/delete.gif' alt='ลบหัวข้อนี้'></a>
									</div>
								</div>";
			}
			$return.="<br><hr></div>";
			$return.="<div id='newalumni' style='width:765px;text-align:center;float:left;'><a href='javascript:void newTopicDetail();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a>
			</div>";
		}
		$objResponse->addAssign("alumnidetail","innerHTML",$return);
		return $objResponse;
	}

	function search($searchtext,$searchselect){
		global $dbname,$tb_alumni;
		$objResponse = new xajaxResponse();
		
		if($searchselect=="name"){
			//$tmpname=explode(" ",$searchtext);
			//if(count($tmpname)>1)
				$sql="SELECT * FROM $tb_alumni WHERE FIRST_NAME LIKE '%searchselect%' ";
			//else
			//	$sql="SELECT * FROM $tb_alumni WHERE FIRST_NAME LIKE '%$tmpname[0]%'";
		}
		else if($searchselect=="nick")
			$sql="SELECT * FROM $tb_alumni WHERE NICK_NAME LIKE '%$searchtext%'";
		else if($searchselect=="id")
			$sql="SELECT * FROM $tb_alumni WHERE STUDENT_ID LIKE '$searchtext%'";
		else
			$sql="SELECT * FROM $tb_alumni";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="
						<div style='width:765px;background:url(\"../images/leftbg.gif\");padding:3px 0px;'>
							<span style='padding-right:50px;padding-left:20px;'><a href='javascript:void xajax_getAlumniNotice(1,\"sortopnext\",page);'>รหัสนักศึกษา</a></span>
							<span style='padding-right:120px;'><a href='javascript:void xajax_getAlumniNotice(2,\"sortopnext\",page);'>ชื่อ-นามสกุล</a></span>
							<span style='padding-right:70px;'><a href='javascript:void xajax_getAlumniNotice(0,\"sortopnext\",page);'>ชื่อเล่น</a></span>
							<span style='padding-right:100px;'>อีเมลล์</span><hr>
						</div> ";
			$return.="<div style='width:765px;background:url(\"../images/leftbg.gif\")'>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<div class='topic' id='$result[ALUMNI_ID]'>
									<div class='alumni1' id='tp1$result[ALUMNI_ID]'><a href='javascript:void viewTopicDetail($result[ALUMNI_ID]);'>$result[STUDENT_ID] </a></div>
									<div class='alumni2'>$result[FIRST_NAME] $result[LAST_NAME]</div>
									<div class='alumni3'>$result[NICK_NAME]</div>
									<div class='alumni4'>$result[EMAIL]</div>
									<div class='alumni5'>
										<a href='javascript:void editTopicDetail($result[ALUMNI_ID]);viewTopicDetail($result[ALUMNI_ID]);'><img src='../images/edit.gif' alt='แก้ไขหัวข้อนี้'></a>
											<a href='javascript:void deleteTopicDetail($result[ALUMNI_ID]);'><img src='../images/delete.gif' alt='ลบหัวข้อนี้'></a>
									</div>
								</div>";
			}
			$return.="<br><hr></div>";
			$return.="<div id='newalumni' style='width:765px;text-align:center;float:left;'><a href='javascript:void newTopicDetail();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a>
			</div>";
		}
		else
			$objResponse->addAlert(mysql_error());
		$objResponse->addAssign("alumnidetail","innerHTML",$return);
		return $objResponse;
	}
	function checkIsStudent(){
		global $dbname,$tb_useraccount;
		$objResponse = new xajaxResponse();
		if($_SESSION['ss_Status']=="offline")
			$objResponse->addAlert("กรุณา login เข้าสู่ระบบก่อน");
		else{
			$sql="SELECT STUDENT_ID ";
			$sql.="FROM $tb_useraccount ";
			$sql.="WHERE USER_ID = $_SESSION[ss_UserID] ";
			mysql_db_query($dbname,"SET NAMES 'UTF8'");
			if($dbquery=mysql_db_query($dbname,$sql)){
				if($result=mysql_fetch_array($dbquery)){
					if(ereg("^[0-9]{8}$",$result['STUDENT_ID'])){
						$_SESSION['ss_StudentID']=$result['STUDENT_ID'];
						$objResponse->addScript("register();");
					}
					else
						$objResponse->addAlert("ไม่สามารถลงทะเบียนศิษย์เก่าได้");
				}
			}
		}
		return $objResponse;
	}
	function addAlumni($sec,$class,$name,$sername,$sex,$nickname,$birthday,$currentaddress,$homeaddress,$tel,$phone,$email,$company,$position,$officeaddress){
		global $dbname,$tb_alumni;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO $tb_alumni ";
		$sql.="VALUES('','".$_SESSION['ss_UserID']."','$sec','$class','".$_SESSION['ss_StudentID']."','$name','$sername',";
		$sql.="'$nickname','$sex','".strtotime($birthday)."','$currentaddress','$homeaddress','$tel','$phone','$email','$company',";
		$sql.="'$position','$officeaddress') ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$objResponse->addScript("successRegister();");
			unset($_SESSION['ss_StudentID']);
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด");
		
		return $objResponse;
	}
	//สร้าง code สำหรับแบ่งหน้าในการแสดง
	function checkpage($allnum,$page,$pagepernum,$to1,$to2){
		$return="";
		$count=1;
		while($allnum>0){
			if($page==$count)
				$return.="<font color='#FF0000'>[$count]</font> ";
			else
				$return.="<a href='$to1$count$to2'>$count</a> ";
			$allnum-=$pagepernum;
			$count++;
		}
		return $return;
	}
	
	
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");


	$xajax->registerFunction("getSubject");
	
	$xajax->registerFunction("getSelectClass");

	$xajax->registerFunction("getAlumniNotice");
	$xajax->registerFunction("submitTopicDetail");
	$xajax->registerFunction("deleteTopicDetail");
	$xajax->registerFunction("newTopicDetail");
	$xajax->registerFunction("submitNewTopicDetail");

	$xajax->registerFunction("getAlumni");
	$xajax->registerFunction("search");
	
	$xajax->registerFunction("addAlumni");
	$xajax->registerFunction("checkIsStudent");
	$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
	  <title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="index.css" rel="stylesheet" type="text/css">
		<!-- tinyMCE -->
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/cookies.js"></script>
		
		<!-- /tinyMCE -->
		<script langusge='JavaScript'>
		<!--
			function getLoginTime(){
				var e = new Date();
				var loginhour=Math.floor((e.getTime()-d.getTime())/3600000)%24;
				var loginmin=Math.floor((e.getTime()-d.getTime())/60000)%60;
				var loginsec=Math.floor((e.getTime()-d.getTime())/1000)%60;
				document.getElementById('logintime').innerHTML= loginhour+":"+loginmin+":"+loginsec;
			}
			function viewTopicDetail(topic_id){
				xajax.$(topic_id).style.display="none";
				xajax.$('d'+topic_id).style.display="block";
			}
			function hideTopicDetail(topic_id){
				xajax.$('d'+topic_id).style.display="none";
				xajax.$(topic_id).style.display="block";
			}
			function editTopicDetail(topic_id){
				tmptopic[topic_id]=xajax.$('dt'+topic_id).innerHTML;
				tmpdetail[topic_id]=xajax.$('dd'+topic_id).innerHTML;
				xajax.$('dt'+topic_id).innerHTML="<input type='text'size='100' id='dtt"+topic_id+"' value='"+xajax.$('dt'+topic_id).innerHTML+"' >";
				xajax.$('dd'+topic_id).innerHTML="<textarea id='ddt"+topic_id+"' rows='20' cols='85' style='width:700px;overflow:hidden;'>"+xajax.$('dd'+topic_id).innerHTML+"</textarea>";
				xajax.$('dl'+topic_id).innerHTML="<a href='javascript:void submitTopicDetail("+topic_id+");'> "+
					"<img src='../images/Button/submit.gif' border='0' alt='ตกลง'></a> "+
					"<a href='javascript:void cancleTopicDetail("+topic_id+");'>"+
					"<img src='../images/Button/cancel.gif' border='0' alt='ยกเลิก'></a>";
				tinyMCE.addMCEControl(xajax.$('ddt'+topic_id),'MCEControlID'+topic_id);
			}
			function submitTopicDetail(topic_id){
				if(confirm("คุณต้องการแก้ไขข้อมูลนี้หรือไม่...")){
					xajax_submitTopicDetail(topic_id,xajax.$('dtt'+topic_id).value,tinyMCE.getContent('MCEControlID'+topic_id));
					tinyMCE.removeMCEControl('MCEControlID'+topic_id);
					xajax.$('tp1'+topic_id).innerHTML="<a href='javascript:void viewTopicDetail("+topic_id+");'>"+xajax.$('dtt'+topic_id).value+"</a>";
					xajax.$('dt'+topic_id).innerHTML=xajax.$('dtt'+topic_id).value;
					xajax.$('dd'+topic_id).innerHTML=xajax.$('ddt'+topic_id).value;
					xajax.$('dl'+topic_id).innerHTML="<a href='javascript:void editTopicDetail("+topic_id+");'> "+
						"<img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> "+
						"<a href='javascript:void hideTopicDetail("+topic_id+");'>"+
						"<img src='../images/Button/cancel.gif' border='0' alt='ยกเลิก'></a>";
				}
			}
			function cancleTopicDetail(topic_id){
				tinyMCE.removeMCEControl('MCEControlID'+topic_id);
				xajax.$('dt'+topic_id).innerHTML=tmptopic[topic_id];
				xajax.$('dd'+topic_id).innerHTML=tmpdetail[topic_id];
				xajax.$('dl'+topic_id).innerHTML="<a href='javascript:void editTopicDetail("+topic_id+");'>"+
					"<img src='../images/Button/edit.gif' border='0' alt='แก้ไข'></a> "+
					"<a href='javascript:void hideTopicDetail("+topic_id+");'>"+
					"<img src='../images/Button/cancel.gif' border='0' alt='ยกเลิก'></a>";
				
			}
			function deleteTopicDetail(topic_id){
				if(confirm("คุณต้องการลบข้อมูลนี้หรือไม่...")){
					xajax.$('alltopic').removeChild(xajax.$(topic_id));
					xajax.$('alltopic').removeChild(xajax.$('d'+topic_id));
					xajax_deleteTopicDetail(topic_id);
				}
			}
			function newTopicDetail(){
				xajax.$('newtopic').style.border="1px solid";
				xajax.$('newtopic').innerHTML="<br>หัวข้อ <input type='text' size='100' id='dtt'><br>"+
						"<span style='text-align:left;'>รายละเอียด </span>"+
						"<textarea id='ddt' rows='20' cols='85' style='width:700px;overflow:hidden;'>"+
						"</textarea><br><a href='javascript:void submitNewTopicDetail();'>"+
						"<img src='../images/Button/submit.gif' border='0' alt='Submit'></a>"+
						"<a href='javascript:void cancleNewToppicDetail();'>"+
						"<img src='../images/Button/cancel.gif' border='0' alt='Cancle'></a><br><br>";
				tinyMCE.addMCEControl(xajax.$('ddt'),'MCEControlID');
			}
			function submitNewTopicDetail(){
				if(confirm("คุณต้องการเพิ่มข้อมูลนี้หรือไม่...")){
					xajax.$('newtopic').style.border="none";
					xajax_submitNewTopicDetail(xajax.$('dtt').value,tinyMCE.getContent('MCEControlID'));
					cancleNewToppicDetail();
				}
			}
			function cancleNewToppicDetail(){
				xajax.$('newtopic').style.border="none";
				tinyMCE.removeMCEControl('MCEControlID');
				xajax.$('newtopic').innerHTML="<a href='javascript:void newTopicDetail();'><img src='../images/Button/add.gif' border='0' alt='เพิ่ม'></a>";
				
			}
			function search(){
				xajax_search(xajax.$('st').value,xajax.$('ss').value);
			}
			function generate(option){
				if(option==1)
					var lastyear=1992;
				else
					var lastyear=1962;
				var d=new Date();
				var thisyear=d.getYear();
				var optionstr="<select id='class'>";
				while(thisyear>lastyear){
					optionstr+="<option value='รุ่น"+(thisyear-lastyear)+"'>รุ่น"+(thisyear-lastyear);
					thisyear--;
				}
				optionstr+="</select>";
				xajax.$('viewclass').innerHTML=optionstr;
				
			}
			function register(){
				xajax.$('alumnidetail').innerHTML=""+
				"<div align='center'>ลงทะเบียนศิษย์เก่า<br><br>"+
					"<table border='1' width='765px' style='text-align:left' cellpadding='5' cellSpacing='0'>"+
					"<tr>"+
						"<td >นักศึกษา </td><td><input type='radio' id='sec1' name='sec' checked onclick='generate(1);'>ภาคต่อเนื่อง <input type='radio' id='sec2' name='sec' onclick='generate(2);'>ภาคปกติ</td>"+
					"</tr>"+
					"<tr>"+
						"<td>รุ่นที่ </td><td><span id='viewclass'></span></td>"+
					"</tr>"+
					"<tr>"+
						"<td>ชื่อ-นามสกุล </td><td>ชื่อ <input type='text' id='name'> นามสกุล <input type='text' id='sername'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>เพศ </td><td><input type='radio' id='sex1' name='sex' checked>ชาย <input type='radio'  id='sex2' name='sex'>หญิง</td>"+
					"</tr>"+
					"<tr>"+
						"<td>ชื่อเล่น </td><td><input type='text' id='nickname'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>วันเกิด </td><td>"+
							" วัน <select id='day' >"+
								"<option>1 "+
								"<option>2 "+
								"<option>3 "+
								"<option>4 "+
								"<option>5 "+
								"<option>6 "+
								"<option>7 "+
								"<option>8 "+
								"<option>9 "+
								"<option>10 "+
								"<option>11 "+
								"<option>12 "+
								"<option>13 "+
								"<option>14 "+
								"<option>15 "+
								"<option>16 "+
								"<option>17 "+
								"<option>18 "+
								"<option>19 "+
								"<option>20 "+
								"<option>21 "+
								"<option>22 "+
								"<option>23 "+
								"<option>24 "+
								"<option>25 "+
								"<option>26 "+
								"<option>27 "+
								"<option>28 "+
								"<option>29 "+
								"<option>30 "+
								"<option>31 "+
							"</select>"+
							" เดือน <select id='mount'>"+
								"<option value='January'>มกราคม "+
								"<option value='February'>กุมภาพันธ์ "+
								"<option value='March'>มีนาคม "+
								"<option value='April'>เมษายน "+
								"<option value='May'>พฤษภาคม "+
								"<option value='June'>มิถุนายน "+
								"<option value='July'>กรกฏาคม "+
								"<option value='August'>สิงหาคม "+
								"<option value='September'>กันยายน "+
								"<option value='October'>ตุลาคม "+
								"<option value='November'>พฤศจิกายน "+
								"<option value='December'>ธันวาคม "+
								
							"</select>"+
							" ปี ค.ศ.<input type='text' id='year'>"+
						"</td>"+
					"</tr>"+
					"<tr>"+
						"<td>ที่อยู่ปัจจุบัน </td><td><textarea rows='3' cols='50' id='currentaddress'></textarea></td>"+
					"</tr>"+
					"<tr>"+
						"<td>ที่อยู่ในทะเบียนบ้าน </td><td><textarea rows='3' cols='50' id='homeaddress'></textarea></td>"+
					"</tr>"+
					"<tr>"+
						"<td>เบอร์โทรศัพท์ </td><td><input type='text' id='tel' ></td>"+
					"</tr>"+
					"<tr>"+
						"<td>เบอร์มือถือ </td><td><input type='text' id='phone'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>อีเมล์ </td><td><input type='text' id='email'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>บริษัทที่ทำงาน </td><td><input type='text' id='company'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>ตำแหน่ง </td><td><input type='text' id='position'></td>"+
					"</tr>"+
					"<tr>"+
						"<td>ที่ตั้งบริษัท</td><td><textarea rows='3' cols='50' id='office'></textarea></td>"+
					"</tr>"+
					"<tr>"+
						"<td colspan='2' align='center'><a href='javascript:void addAlumni();'><img src='../images/Button/submit.gif' border='0' alt='submit'></a></td>"+
					"</tr>"+
					"</table>"+
				"</div>";
				generate(1);
			}
		function addAlumni(){
			if(xajax.$('sec1').checked==true)
				var sec="ภาคต่อเนื่อง";
			else
				var sec="ภาคปกติ";
			if(xajax.$('sex1').checked==true)
				var sex="ชาย";
			else
				var sex="หญิง";
			var birthday=xajax.$('day').value+" "+xajax.$('mount').value+" "+xajax.$('year').value;
				xajax_addAlumni(sec,xajax.$('class').value,xajax.$('name').value,xajax.$('sername').value,sex,xajax.$('nickname').value,birthday,xajax.$('currentaddress').value,xajax.$('homeaddress').value,xajax.$('tel').value,xajax.$('phone').value,xajax.$('email').value,xajax.$('company').value,xajax.$('position').value,xajax.$('office').value);
		}
		function successRegister(){
			alert("เพิ่มข้อมูลเรียบร้อย");
			
			xajax.$('sec1').disabled=true;
			xajax.$('sec2').disabled=true;
			xajax.$('class').disabled=true;
			xajax.$('viewclass').disabled=true;
			xajax.$('name').disabled=true;
			xajax.$('sername').disabled=true;
			xajax.$('sex1').disabled=true;
			xajax.$('sex2').disabled=true;
			xajax.$('nickname').disabled=true;
			xajax.$('day').disabled=true;
			xajax.$('mount').disabled=true;
			xajax.$('year').disabled=true;
			xajax.$('currentaddress').disabled=true;
			xajax.$('homeaddress').disabled=true;
			xajax.$('tel').disabled=true;
			xajax.$('phone').disabled=true;
			xajax.$('email').disabled=true;
			xajax.$('company').disabled=true;
			xajax.$('position').disabled=true;
			xajax.$('office').disabled=true;
		}
		function editalumni(){
			register();
		}
		//-->
		</script>
		<?php $xajax->printJavascript('../tool/xajax/'); ?>
	</head>

	<body class="site" >
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="../images/logo.gif" ></p>
		<center>
			<!-- menu -->
			<div style='text-align:center;width:765px;'>
				<div class="menu">
					<li id="six"><font color="#0000FF"><a href='../'>หน้าแรก</a></font></li>
					<li id="one"><font color="#0000FF"><a href='../subject/'>หลักสูตร</a></font></li>
					<li id="two"><font color="#0000FF"><a href='../lecturer/'>บุคลากร</a></font></li>
					<li id="three"><font color="#0000FF"><a href=''>ห้องวิจัย</a></font></li>
					<li id="four"><font color="#0000FF"><a href='../webboard/'>Webboard</a></font></li>
					<li id="five"><font color="#0000FF"><a href='../alumni/'>ศิษย์เก่า</a></font></li>
					<li id="last"><font color="#0000FF"><a href='../user_management/showlist_member.php'>สมาชิก</a></font></li>
				</div>
				<div style="width:765px;">
					<!-- logo -->
					<div ><img  src="../images/show.jpg" style='float:left;border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'></div>
					<!-- login -->
					<div class='login'>
						<?php checklogin(); ?>
					</div>
				</div>
				<div style="float:left;width:765px;">
					<!-- หลักสูตร -->
					<div style="text-align:left;font-weight:bold;">
						<font face="Angsana New" color="#0066FF" style="font-size: 16pt">ศิษย์เก่าภาควิชาวิศวกรรมคอมพิวเตอร์</font><br>

						<div align='center'>
							<div style='width:765px;text-align:left;'>
								<fieldset style='width:360px;'>
									<legend>แสดงข้อมูล</legend>
									<div style='padding-right:15px;'>
										<select id='sectionselect' onchange='javascript:void xajax_getSelectClass(this.value)';>
											<option value='section' selected>เลือกsection
											<option value='ภาคต่อเนื่อง' >ภาคต่อเนื่อง
											<option value='ภาคปกติ'>ภาคปกติ
										</select>
										<span id='classselectspan'>
											<select id='classselect'>
												<option value='' selected>เลือกรุ่น
											</select>
										</span>
									</div>
								</fieldset>
								<fieldset style='width:360px;'>
									<legend>ค้นหารายชื่อ</legend>
									<div style='padding:0px;'>
										&nbsp;&nbsp;
										 <input type='text' id='st'>
										<select id='ss'>
											<option value='id' selected>รหัสนักศึกษา
											<option value='name'>ชื่อ นามสกุล
											<option value='nick'>ชื่อเล่น
										</select>
										<input type='submit' value='ค้นหา' onclick='search();'>
									</div>
								</fieldset>
							</div>
							<br>
							<div style='padding:4px 0px;background:url(../images/bar_1.png);width:300px;'>
								<span style='padding:0px 20px;border-right:1px solid;'><a href='javascript:void xajax_getAlumniNotice();'>ข่าวประกาศ</a></span>
								<span style='padding:0px 20px;'><a href='javascript:void xajax_checkIsStudent();'>ลงทะเบียน</a></span>
								
							</div> 
							
						</div>
						<br>
						
						<script langusge='JavaScript'>
						<!--
							xajax_getAlumniNotice();
						//-->
						</script>

						<div id="alumnidetail"></div>
						
				</div><br>
			</div>
			<div style="width:800px;float:left;" >
				<font color="#666666">Department of Computer Engineering Faculty of Engineering King Mongkut's 
					Institute of Technology<br>
					Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404<br>
					<span lang="th">ส่งคำติชม</span>
				</font><a href="mailto:webmaster@ce.kmitl.ac.th">webmaster@ce.kmitl.ac.th</a>
			</div>
		</center>
	</body>
</html>