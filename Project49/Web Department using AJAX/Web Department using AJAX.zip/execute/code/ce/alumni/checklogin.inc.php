<?php
	function checkLogin(){
	 echo "<b><span class='bar'>User Login</span></b><br><br>
				<div id='login' style='text-align:left;padding-left:10px;'>
					<b>User &nbsp;: </b><a href='../user_management/showPersonInfo.php'>$_SESSION[ss_UserName]</a>";
	if($_SESSION['ss_Level'] =='admin')
		echo "&nbsp;&nbsp;<a href='../user_management/admin_regis1.php'> invite</a>";
	echo"				<br><b>Level : </b>$_SESSION[ss_Level]<br>
							<b>Login : </b>$_SESSION[ss_Status]<br>
							<b>Time &nbsp;: </b><span id='logintime'>0:0:0 </span> s<br>";
			if(!isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online")
				echo "<center><a href='javascript:void window.open(\"http://localhost/ce/user_management/showlogin.php\",\"_blank\",\"left=200,top=314,width=480,height=150,resizable=no\");'><img src='../images/login.gif' onclick=window.setTimeout(\"logining()\",5000);></a></center>";
			else
				echo "<center><a href='javascript:void islogout();'><img src='../images/logout.gif' ></a></center>
				<script langusge='JavaScript'>
				<!--
					var d = new Date();
					d.setTime($_SESSION[ss_LoginTime]);
					var thisdate=d.getTime();
					tologintime=window.setInterval(\"getLoginTime()\",1000);
				//-->
				</script>
				";
			echo "</div>";
	}
	function isLogin($logintime){
		$objResponse = new xajaxResponse();
		$_SESSION['ss_LoginTime']=$logintime;
		setcookie ("login","ok",time()-4600,"/ce/");
		if(!isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']=="online"){
			$return="User : <a href='../user_management/showPersonInfo.php'>$_SESSION[ss_UserName]</a>";
			if($_SESSION['ss_Level'] =='admin')
				$return.="&nbsp;&nbsp;<a href='../user_management/admin_regis1.php'> invite</a>";
			$return.="
						<br>Level: $_SESSION[ss_Level]<br>
						Login: $_SESSION[ss_Status]<br>
						Time : <span id='logintime'>0:0:0 </span> s<br>
						<center><a href='javascript:void islogout();'><img src='../images/logout.gif' ></a></center>";
			$objResponse->addScript("d = new Date();thisdate=d.getTime(); tologintime=window.setInterval('getLoginTime()',1000);");
			$objResponse->addAssign("login","innerHTML",$return);
		}
		return $objResponse;
	}
	function logout(){
		$objResponse = new xajaxResponse();
		$objResponse->addConfirmCommands(1,"คุณต้องการที่จะออกจากระบบ ?");
		$objResponse->addScript("xajax_confirmLogout();");
		return $objResponse;
	}
	function confirmLogout(){
		$objResponse = new xajaxResponse();
		$_SESSION['ss_UserID']=0;
		$_SESSION['ss_UserName']="anonymous";
		$_SESSION['ss_Level']="guest";
		$_SESSION['ss_Status']="offline";
		$_SESSION['ss_LoginTime']=0;
		$_SESSION['ss_privcode']="A";
		$_SESSION['ss_point']=100;
		$_SESSION['ss_SubjectLevel']='guest';
		//setcookie("login",time()-3600);
		$return="User : <a href='../user_management/showPersonInfo.php'>$_SESSION[ss_UserName]</a><br>
		Level: $_SESSION[ss_Level]<br>
		Login: $_SESSION[ss_Status]<br>
		Time : <span id='logintime'>0:0:0 </span> s<br>
		<center><a href='javascript:void window.open(\"http://localhost/ce/user_management/showlogin.php\",\"_blank\",\"left=200,top=314,width=480,height=150,resizable=no\");'><img src='../images/login.gif' onclick='window.setTimeout(\"logining()\",5000);'></a></center>";
		$objResponse->addAssign("login","innerHTML",$return);
		$objResponse->addScript("window.clearInterval(tologintime);");
		return $objResponse;
	}