<?php 
	
	session_start();
	if(!isset ($_SESSION['ss_Status']) or  $_SESSION['ss_Status'] == "offline"){

		echo "<br/><h2><center>คุณไม่สามารถเข้าใช้งานส่วนนี้ได้</center>";
		return;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
  <frameset cols="140,*" frameborder="no" border="0" framespacing="0">
    <frame src="showPersonInfoMenu.php" name="leftFrame" scrolling="No" noresize="noresize" id="leftFrame" title="menu" />
    <frame src="showProfile.php" name="mainFrame" id="mainFrame" title="mainFrame" />
  </frameset>

<noframes><body>
</body>
</noframes></html>
