<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">


<title>Welcome to CE.KMITL </title>
<?php
		include("../_Sessionstart.php");
		if($_SESSION['ss_Status']=="offline" or $_SESSION['ss_Level'] !="admin"){
				echo "<center>Please log in to system <br/>";
				echo '<A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A></center>';
				return;
			}
?>
<style type="text/css">
<!--

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 12px;
}
#Layer1 .embedded .heading {
	font-size: 14px;
	color: #FF0000;
}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
	font-weight: bold;
}
.regisTable {
	font-size: 12px;
	color: #0000FF;
}
.style24 {color: #999999}
.style25 {color: #FF0000}
.detail {
	font-size: 12px;
	color: #333333;
}
-->
</style>
<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/admin_register_lecturer.js"></script>
<script type="text/javascript" >
<!--
var cp = new cpaint();
cp.set_response_type('XML');
var lecturerID="";
function sendInviteLecturer(){
	if (lecturerID ==""){
		alert("กรุณาเลือกคณาจาย์ที่จะเชิญเข้าลงทะเบียน");
		return false;
	}	
	if (document.getElementById("semail").value==""){
		alert("กรุณาระบุอีเมล์ที่จะส่งคำเชิญ");
	}
	//alert(document.getElementById("semail").value);
	cp.call('php/invite.php','inviteLecturer',responseInviteLecturer ,lecturerID,document.getElementById("semail").value);
	document.getElementById('responeinvite').innerHTML ='data transfer<br/><img src="pic/ajax-loader.gif" alt="now loading" />';
	//alert(lclasslecture);

	return true;
}
function responseInviteLecturer(result) {
				document.getElementById('responeinvite').innerHTML = result.getElementsByTagName("response")[0].firstChild.nodeValue;
}
//-->
</script>
</head>

<body>
<div id="Layer1" align="center">
    <table width="476" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
     
		
        <td width="476"><img src="../images/logo.gif" width="800" height="175" /></td>
      </tr>
  </table>
</div><div id="Layer1" align="center">
<table width="706" height="134" border="0">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td colspan="2" class="embedded"><h1 align="center" class="style16 style24"> Member Registeration by Admin</h1>      </td>
    </tr>
		   <tr>
		   	<td colspan="2" align="center"><table width="547" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif" class="regisTable">
  <tr valign="top">
    <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;คณา&#3592;&#3634;&#3619;&#3618;&#3660; </span></th>
    </tr>
  <tr>
    <td width="183" align="right"><span class="style25">ค้นหา</span></td>
    <td width="329" align="left"><select name="captionlecturer" id="caption">
      <option value="รศ.ดร.">รศ.ดร.</option>
      <option value="รศ.">รศ.</option>
      <option value="ผศ.ดร.">ผศ.ดร.</option>
      <option value="ผศ.">ผศ.</option>
      <option value="ดร.">ดร.</option>
      <option value="อ.">อ.</option>
      <option value="">ไม่ระบุ</option>
    </select>     <span class="style25">ชื่อ นามสกุล</span> 
    <input  id="searchName" name="nsearchName" type="text"  onkeyup="getlistLecturer()"/></td>
  </tr>
  <tr>
    <td width="183" align="right"><span class="style25">รายชื่อคณาจารย์ที่เชิญชวน</span></td>
    <td width="329" align="left"><select name="select" id="listLecturer">
      <option>รายชื่อคณาจารย์</option>
    </select> &nbsp;
    <input type="submit" name="Submit" value="เลือก" onclick="selectLecturer()"/></td>
  </tr>
  <tr>
    <td align="right">คำนำหน้า</td>
    <td align="left"><div id="captiontxt" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">ชื่อ</td>
    <td align="left"><div id="name" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">นามสกุล</td>
    <td align="left"><div id="sername" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">ตำแหน่ง/หน้าที่</td>
    <td align="left"><div id="position" class="detail">&nbsp;-</div></td>
  </tr><tr>
    <td align="right">&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3648;&#3614;&#3639;&#3656;&#3629;&#3605;&#3636;&#3604;&#3605;&#3656;&#3629;&#3591;&#3634;&#3609;&#3619;&#3634;&#3594;&#3585;&#3634;&#3619;</td>
    <td align="left"><div id="emailL" class="detail">&nbsp;-</div></td>
  </tr><tr>
    <td align="right">&#3648;&#3610;&#3629;&#3619;&#3660;&#3650;&#3607;&#3619;&#3624;&#3633;&#3614;&#3607;&#3660;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3605;&#3636;&#3604;&#3605;&#3656;&#3629;&#3591;&#3634;&#3609;&#3619;&#3634;&#3594;&#3585;&#3634;&#3619;</td>
    <td align="left"><div id="contactPhoneNo" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">&#3626;&#3635;&#3609;&#3633;&#3585;&#3591;&#3634;&#3609;</td>
    <td align="left"><div id="office" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">สอนในระดับ</td>
    <td align="left"><div id="teachLV" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">เว็ปไซด์ส่วนบุคคล</td>
    <td align="left"><div id="link" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">งานวิจัย</td>
    <td align="left"><div id="research" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td align="right">ชื่อที่ใช้งานในระบบ</td>
    <td align="left"><div id="username" class="detail">&nbsp;-</div></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><span class="style25">หมายเหตุ :</span> <span class="detail">หากมีชื่อที่ใช้งานในระบบอยู่แล้วจะการเปลี่ยนชื่อผู้ใช้งาน(username) </span></td>
    </tr>
</table></td>
		   </tr>
		   <tr>
		   <td width="14%" align="right">&nbsp;</td>
		   <td width="86%" align="left">&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3626;&#3656;&#3591;&#3588;&#3635;&#3648;&#3594;&#3636;&#3597;&#3594;&#3623;&#3609;&nbsp;
		     <input type="text" name="nSEmail"  id="semail"/>
		     &nbsp;<input name="send_email" type="button" id="send_email" value="&#3592;&#3633;&#3604;&#3626;&#3656;&#3591;&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;"  onclick="return sendInviteLecturer()"/></td>
		   </tr>
  </table>
		   </div><div id="responeinvite" align="center"></div>
</body>
</html>