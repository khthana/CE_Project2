<?php
	/**
	 * This file uploads a file in the back end, without refreshing the page
	 *  
	 */
	 $uploaddir='../uploaded/files/';
	 if(!is_dir($uploaddir)) {
				mkdir($uploaddir, 0757);
	 }
	$tempStr ='../uploaded/files/'.$_FILES[$_POST['id']]['tmp_name'];
	if (isset($_POST['id'])) {
		if (!copy($_FILES[$_POST['id']]['tmp_name'], $uploaddir.$_FILES[$_POST['id']]['name'])) {
			echo '<script> alert("Failed to upload file");</script>';
		}
	}
	else {
		echo $tempStr;
	}
?>