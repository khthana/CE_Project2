var http = createRequestObject();
var uploader = '';
var temp= ""
function createRequestObject() {
    var obj;
    var browser = navigator.appName;
    
    if(browser == "Microsoft Internet Explorer"){
        obj = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else{
        obj = new XMLHttpRequest();
    }
    return obj;    
}

function traceUpload(uploadDir) {
 		
   http.onreadystatechange = handleResponse;

   http.open("GET", 'ajaxfileuploader/imageupload.php?uploadDir='+uploadDir+'&uploader='+uploader); 
   http.send(null);   
}

function handleResponse() {
	/*if (temp =="")
	{
		temp =document.getElementById(uploaderId).innerHTML
	}*/
	if(http.readyState == 4){
		var filename = document.getElementById('id1').value;
		//alert(filename.indexOf("\/") );
		while (filename.indexOf("\\") >0)
		{
			filename = filename.substring(filename.indexOf("\\") + 1, filename.length);
		}
		
        document.getElementById('statusUpload').innerHTML ="File uploaded";
		document.getElementById('fFilename').value =filename;
        //window.location.reload(true);
    }
    else {
    	document.getElementById('statusUpload').innerHTML = '<img src="pic/ajax-loader.gif"  />';
    }
}

function uploadFile(obj) {
	var uploadDir = obj.value;
	uploaderId = 'uploader'+obj.name;
	uploader = obj.name;
	
	document.getElementById('formName'+obj.name).submit();
	traceUpload(uploadDir, obj.name);	
}