<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title></title>
<script  type="text/javascript" src="code script/alttxt.js"></script> 
<!--  <script  type="text/javascript" src="../webboard/js/alttxt.js"></script> -->
<style type="text/css">
<!--
#menu {
	margin-top: 200px;
}
#menu .line {
	padding-left: 10px;
}

.navtext {
	text-align:left; 
	font-family: "MS Sans Serif";
	font-size: 10px;
	font-weight:bold;
	color:black; 
	border-width:1px; 
	border-style:outset; 
	border-color:white; 
	background-color:tan; 
	layer-background-color:tan;
}

-->
</style>
<script>

function show_pm(para){

	string ="<table  border=\"0\" cellpadding=\"0\" cellspacing=\"0\" ><tr><td align=\"left\" valign=\"top\" class=\"line\" colspan=\"3\"><img src=\"pic/iconmenu/mainlineB.gif\" width=\"10\" height=\"10\" border=\"0\" /></td></tr><tr><td valign=\"top\" class=\"line\"><img src=\"pic/iconmenu/mainline.gif\" width=\"10\" height=\"40\" border=\"0\" /></td><td align=\"left\" valign=\"top\" ><img src=\"pic/iconmenu/subline_.gif\" border=\"0\" /></td><td valign=\"top\"><a href=\"../PM/index.php\" target=\"mainFrame\"><img src=\"../PM/pic/icon/message.gif\"  width=\"40\" height=\"40\" border=\"0\" onmouseover=\"writetxt('ข้อความ')\" onmouseout=\"writetxt(0)\"/></a></td></tr><tr><td align=\"right\" valign=\"top\" ><img src=\"pic/iconmenu/mainlineBT.gif\" width=\"10\" height=\"21\" border=\"0\" /></td><td align=\"left\" valign=\"top\" ><img src=\"pic/iconmenu/subline_.gif\" border=\"0\" /></td><td valign=\"bottom\"><a href=\"../PM/index_.php\" target=\"mainFrame\"><img src=\"../PM/pic/icon/relative.gif\" width=\"40\" height=\"40\" border=\"0\" onmouseover=\"writetxt('รายชื่อการติดต่อ')\" onmouseout=\"writetxt(0)\"/></a></td></tr></table>";

	if (para == 1)
		document.getElementById("pm_").innerHTML = string;
	else
		document.getElementById("pm_").innerHTML = "";

}

</script>
</head>

<body>
<div id="menu">
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><img src="pic/iconmenu/personal.gif" width="80" height="92" border="0" /></td>
  </tr>
  <tr>
  <td align="right" valign="top" class="line" ><img src="pic/iconmenu/mainlineB.gif" width="10" height="10" border="0" /></td>
  </tr>
  <tr>
  <td align="right" valign="top" class="line" ><img src="pic/iconmenu/mainline.gif" width="10" height="40" border="0" /></td>
 	<td align="right" valign="top"><img src="pic/iconmenu/subline.gif" border="0" /></td>
   <td align="left" valign="top"><a href="showProfile.php" target="mainFrame"><img src="pic/iconmenu/info.gif" onmouseover="writetxt('ข้อมูลส่วนตัว')" onclick="show_pm(0);" onmouseout="writetxt(0)"  width="40" height="40" border="0"/></a></td>
   
  </tr>
  <tr>
  	<td align="right" valign="top"><img src="pic/iconmenu/mainline.gif" width="10" height="40" border="0" /></td>
	<td align="right" valign="top"><img src="pic/iconmenu/subline.gif" border="0" /></td>
    <td colspan="2" align="left" valign="top"><a href="../webboard/showBookmark.php" target="mainFrame"><img src="pic/iconmenu/bookmark.gif" onclick="show_pm(0);" onmouseover="writetxt('สมุดบันทึกกระทู้')" onmouseout="writetxt(0)" width="40" height="40" border="0"/></a></td>
  </tr>
  <tr>
  	<td align="right" valign="top"><img src="pic/iconmenu/mainline.gif" width="10" height="40" border="0" /></td>
	<td align="right" valign="top"><img src="pic/iconmenu/subline.gif" border="0" /></td>
    <td colspan="2" align="left" valign="top"><a href="showLog_file.php" target="mainFrame"><img src="pic/iconmenu/logfile.gif" onclick="show_pm(0);" onmouseover="writetxt('บันทึกเวลาใช้งาน')" onmouseout="writetxt(0)" width="40" height="40" border="0"/></a></td>
  </tr>
  <tr>
  	<td align="right" valign="top"><img src="pic/iconmenu/mainlineBT.gif" width="10" height="21" border="0" /></td>
	<td align="right" valign="top"><img src="pic/iconmenu/subline.gif" border="0" /></td>
    <td colspan="2" align="left" valign="top"><a href="../PM/index.php" target="mainFrame"><img src="pic/iconmenu/pm.gif" onclick="show_pm(1);" onmouseover="writetxt('ข้อความส่วนตัว')" onmouseout="writetxt(0)" width="40" height="40" border="0"/></a><div id='pm_'></div>	
	</td>
  </tr>
</table>

</div>

<div id="navtxt" class="navtext" style="position:absolute; top:-100px; left:0px; visibility:hidden"></div>

</body>


</html>
