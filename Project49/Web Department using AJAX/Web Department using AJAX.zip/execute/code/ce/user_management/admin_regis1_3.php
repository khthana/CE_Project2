<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">


<title>Welcome to CE.KMITL </title>


<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="ajaxfileuploader/uploader.js" ></script>
<!--<script type="text/javascript" src="code script/readexcel.js"></script>-->
<script type="text/javascript" >
<!--
var cp = new cpaint();
cp.set_response_type('text');
function sendInvieGroup(){
	if (document.getElementById('department').value=="" ||document.getElementById('fGeneration').value=="" ||  document.getElementById('fSection').value=="" || document.getElementById('fFilename').value=="" )
	{
		alert("ท่านยังกรอกข้อมูลไม่ครบ กรุณาตรวจสอบข้อมูลอีกครั้ง");
		return false;
	}
	cp.call('php/invite.php','inviteGroupStudent',responseInviteGroup,document.getElementById('department').value ,document.getElementById('fGeneration').value, document.getElementById('fSection').value,document.getElementById('fFilename').value);
	return false;
}
function responseInviteGroup(result) {
				document.getElementById('responseInvalid').innerHTML = result;
}
//-->
</script>
<?php
			include("../_Sessionstart.php");
			if($_SESSION['ss_Status']=="offline" or $_SESSION['ss_Level'] !="admin"){
				echo "<center>Please log in to system <br/>";
				echo '<A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A></center>';
				return;
			}
			// This is the folder where file are uploaded
			$uploadrootDirectory = "./uploaded/";
			$uploadDirectory = "./uploaded/files/";
			if(!is_dir($uploadDirectory) and !is_dir($uploadDirectory)) {
				mkdir($uploadrootDirectory, 0757);
				mkdir($uploadDirectory, 0757);
			}
			require_once("ajaxfileuploader/AjaxFileUploader.inc.php");
			$ajaxFileUploader = new AjaxFileuploader($uploadDirectory);
?>
<style type="text/css">
<!--


body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;
}


.style22 {color: #666666}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
	font-weight: bold;
}
-->
</style>


</head>

<body>
<div id="Layer1" align="center">
    <table width="827" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
		
        <td width="476"><img src="../images/logo.gif" width="800" height="175" /></td>
      
	    <td width="123" class=embedded>
                    
        </td>
      </tr>
  </table>
</div>
<table width="706" border="0" align="center">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" colspan="3" class="embedded"><h1 align="center" class="style16 style22"> Member Registeration by Admin</h1>      </td>
    </tr>
	</table>
<div id="showform" align="center">
	<table width="706" height="134" border="0">
		   <tr>
		   	<td colspan="3" align="center"><table width="450" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
  <tr>
    <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;&#3585;&#3621;&#3640;&#3656;&#3617;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;  </span></th>
    </tr>
  <tr>
    <td width="30%" align="right">&#3616;&#3634;&#3588;&#3623;&#3636;&#3594;&#3634;</td>
    <td width="327" align="left">
      &nbsp;<input  id="department" name="textfield5" type="text" value="&#3623;&#3636;&#3624;&#3623;&#3585;&#3619;&#3619;&#3617;&#3588;&#3629;&#3617;&#3614;&#3636;&#3623;&#3648;&#3605;&#3629;&#3619;&#3660;"/>
       </td>
  </tr>
  <tr>
    <td width="30%" align="right">&#3619;&#3640;&#3656;&#3609;</td>
    <td width="374" align="left">
      &nbsp;<input name="fGen"   id="fGeneration" type="text"  />     </td>
  </tr>
  <tr>
    <td width="30%" align="right">&#3627;&#3657;&#3629;&#3591;</td>
    <td align="left">
      &nbsp;<select name="fSec" id="fSection">
        <option value="ภาคปกติ" selected="selected">ปกติ</option>
        <option value="ภาคต่อเนื่อง">ต่อเนื่อง</option>
      </select>  </td>
  </tr>
  <tr>
    <td width="30%" align="right">&#3652;&#3615;&#3621;&#3660;&#3648;&#3629;&#3585;&#3626;&#3634;&#3619;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3629;&#3657;&#3634;&#3591;&#3629;&#3636;&#3591;</td>
    <td align="left"><!--<input type="file" name="fFiles"  id="fFile"/>-->
        <?php echo $ajaxFileUploader->showFileUploader('id1');
	  ?><div id="statusUpload"></div></td>
  </tr>
</table></td>
		   </tr>
		   <tr>
		   <td align="center">
		   			<input name="create_account" type="button" id="create_account" value="จัดส่งอีเมล์" onclick="return sendInvieGroup()" /></td>
		   <td align="left"><input name="filename" id="fFilename" type="hidden" value="" /></td>
		   <td align="center"></td>
		   </tr>
  </table>
</div>
		   <div id="responseInvalid" align="center">
		   		</div>
</body>
</html>