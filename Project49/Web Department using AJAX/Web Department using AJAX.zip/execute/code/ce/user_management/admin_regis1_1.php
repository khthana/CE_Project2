<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">


<title>Welcome to CE.KMITL </title>
<?php
			include("../_Sessionstart.php");
			if($_SESSION['ss_Status']=="offline" or $_SESSION['ss_Level'] !="admin"){
				echo "<center>Please log in to system <br/>";
				echo '<A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A></center>';
				return;
			}
?>
<style type="text/css">
<!--

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 12px;
}


.style22 {color: #999999}
#Layer1 .embedded .heading {
	font-size: 14px;
	color: #FF0000;
}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
	font-weight: bold;
}
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" >
<!--
var cp = new cpaint();
cp.set_response_type('text');
function sendInviteStudent(){
	var sDepartment=document.getElementById("department").value;
	var sID=document.getElementById("studentid").value;
	var sGener=document.getElementById("gener").value;
	var sFName=document.getElementById("fname").value;
	var sLName=document.getElementById("lname").value;
	var sEmail=document.getElementById("email").value;
	var sSec =document.getElementById("sec").value;
	if (sDepartment=="" || sID=="" || sGener=="" || sFName=="" || sLName=="" ||sEmail=="")
	{
		alert("ท่านกรอกข้อมูลไม่ครบทุกช่อง กรุณาตรวจสอบใหม่อีกครั้ง");
		return false;
	}
	if (isNaN(Number(sID))){
		alert("กรุณากรอกข้อมูล 'รหัสนักศึกษา' ให้อยู่ในรูปตัวเลข");
		return false;
	}
	if (isNaN(Number(sGener))){
		alert("กรุณากรอกข้อมูล 'รุ่น' ให้อยู่ในรูปตัวเลข");
		return false;
	}
	if (document.getElementsByName('titleCk')[0].checked){
		var sTName=document.getElementById("tname").value;
	}else if(document.getElementsByName('titleCk')[1].checked && document.getElementById("otname").value!=""){
		var sTName=document.getElementById("otname").value;
	}else{
		alert("ท่านกรอกข้อมูลไม่ครบทุกช่อง กรุณาตรวจสอบใหม่อีกครั้ง");
		return false;
	}

	cp.call('php/invite.php','inviteStudent',responseInviteStudent ,sID, sGener,sTName,sFName, sLName,sSec,sEmail,sDepartment);
	document.getElementById('responeinvite').innerHTML ='data transfer<br/><img src="pic/ajax-loader.gif" alt="now loading" />';

	return true;
}
function responseInviteStudent(result) {
				document.getElementById('responeinvite').innerHTML = result;
}
function changeStatusTitleInput(){
	if (document.getElementsByName('titleCk')[0].checked){
		document.getElementById('tname').disabled=true;
		document.getElementById('otname').disabled=false;
	}else{
		document.getElementById('tname').disabled=false;
		document.getElementById('otname').disabled=true;
	}	
}
//-->
</script>
</head>

<body>
<div id="Layer1" align="center">
    <table width="599" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
        <td width="476" height="77"><img src="../images/logo.gif" width="800" height="175" /></td>
      
	    <td width="123" class=embedded>        </td>
      </tr>
  </table>
</div><div id="Layer1" align="center">
<table width="706" height="255" border="0">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td colspan="2" class="embedded"><h1 align="center" class="style16 style22"> Member Registeration by Admin</h1>      </td>
    </tr>
		   <tr>
		   	<td colspan="2" align="center"><table width="450" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
  <tr valign="top">
    <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;&#3619;&#3634;&#3618;&#3610;&#3640;&#3588;&#3588;&#3621; </span></th>
    </tr>
  
  
  <tr>
    <td align="right">&#3588;&#3635;&#3609;&#3635;&#3627;&#3609;&#3657;&#3634;</td>
    <td align="left">
      &nbsp;<input name="titleCk" type="radio" value="1" checked onclick="changeStatusTitleInput()"/>&nbsp;<select name="title name" id="tname">
        <option value="นาย" selected="selected">นาย</option>
        <option value="นางสาว">นางสาว</option>
        <option value="นาง">นาง</option>
      </select>&nbsp;
      <input name="titleCk" type="radio" value="2" onclick="changeStatusTitleInput()"/>
      อื่นๆ
      &nbsp;
      <input id="otname" name="titleTxt" type="text" disabled /></td>
  </tr>
  <tr>
    <td align="right">&#3594;&#3639;&#3656;&#3629;&#3605;&#3657;&#3609;</td>
    <td align="left">
&nbsp;      <input id="fname" name="textfield" type="text" /></td>
  </tr>
  <tr>
    <td align="right">&#3609;&#3634;&#3617;&#3626;&#3585;&#3640;&#3621;</td>
    <td align="left">
      &nbsp;&nbsp;<input id="lname" name="textfield3" type="text" />        </td>
  </tr>
  <tr>
    <td width="120" align="right">&#3616;&#3634;&#3588;&#3623;&#3636;&#3594;&#3634;</td>
    <td width="327" align="left">&nbsp;
      <input  id="department" name="textfield5" type="text" value="&#3623;&#3636;&#3624;&#3623;&#3585;&#3619;&#3619;&#3617;&#3588;&#3629;&#3617;&#3614;&#3636;&#3623;&#3648;&#3605;&#3629;&#3619;&#3660;"/>       </td>
  </tr>
  <tr>
    <td width="120" align="right">&#3619;&#3627;&#3633;&#3626;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;</td>
    <td width="327" align="left">&nbsp;
      <input  id="studentid" name="textfield5" type="text" />       </td>
  </tr>
  <tr>
    <td width="120" align="right">&#3619;&#3640;&#3656;&#3609;</td>
    <td align="left">&nbsp;
      <input id="gener" name="textfield4" type="text" />      </td>
  </tr>
  <tr>
    <td align="right">&#3627;&#3657;&#3629;&#3591;</td>
    <td align="left">&nbsp;
      <select name="select" id="sec">
        <option value="ภาคปกติ" selected="selected">ปกติ</option>
        <option value="ภาคต่อเนื่อง">ต่อเนื่อง</option>
      </select>      </td>
  </tr>
</table></td>
		   </tr>
		   <tr>
		   <td width="18%" height="34" align="right">&nbsp;</td>
		   <td width="82%" align="left">&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3626;&#3656;&#3591;&#3588;&#3635;&#3648;&#3594;&#3636;&#3597;&#3594;&#3623;&#3609;&nbsp; 
		     <input id="email" type="text" name="textfield6" /> <input name=" e-mail" type="button"  value="&#3592;&#3633;&#3604;&#3626;&#3656;&#3591;&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;" onclick="return sendInviteStudent()"/></td></tr>
  </table>
		   </div><div id="responeinvite" align="center"></div>
</body>
</html>