<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
include("getUnderLab.php");
$num_per_page=10;
$cp = new cpaint();
$cp->register('getListmember');
$cp->register('searchMember');
$cp->register('getInfomember');
$cp->register('checkLecturer');
$cp->start();
$cp->return_data();

function getListmember($page){
	//if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp,$num_per_page;
		connectdb();
		$number_per_page=$num_per_page;
		$begin=$number_per_page*($page-1);
		$comSQLSelectMember="SELECT T1.*,T2.USER_NAME FROM useraccount T1 LEFT JOIN useraccount T2 ON ( T1.INVITED_BY_ID = T2.USER_ID ) ";
	if (isset($_SESSION['ss_Level']) and $_SESSION['ss_Level'] !="admin" ){
			$comSQLSelectMember.=" WHERE T1.ACTIVE_STATUS=1";
		}
		$comSQLSelectMember.=" ORDER BY T1.USER_NAME  LIMIT ".$begin." ,".$number_per_page;
		$selectMemberresult=mysql_query($comSQLSelectMember);
		while ($userrow=mysql_fetch_array($selectMemberresult)){
			$memberNode =& $cp->add_node('member');
			$userIDNode =& $memberNode->add_node('userID');
			$userNameNode =& $memberNode->add_node('userName');
			$invitedByNode =& $memberNode->add_node('invitedBy');
			$lvNode =& $memberNode->add_node('lv');
		/*	$underLabNode =& $memberNode->add_node('underLab');
			$subLvNode =& $memberNode->add_node('subLv');*/
			$jointDateNode =& $memberNode->add_node('jointDate');


			if ($userrow["USER_ID"]=="") $userIDNode->set_data("-");else $userIDNode->set_data($userrow["USER_ID"]);
			if ($userrow[1]=="") $userNameNode->set_data("-");else $userNameNode->set_data($userrow[1]);
			if ($userrow["LEVEL"]=="") $lvNode->set_data("-");else $lvNode->set_data($userrow["LEVEL"]);
		/*	if ($userrow["UNDER_LAB"]=="") $underLabNode->set_data("-");else $underLabNode->set_data($userrow["UNDER_LAB"]);
			if ($userrow["SUB_LEVEL"]=="") $subLvNode->set_data("-");else $subLvNode->set_data($userrow["SUB_LEVEL"]);*/
			if ($userrow["JOIN_DATE"]=="") $jointDateNode->set_data("-");else $jointDateNode->set_data(date("d-m-Y H:i:s",$userrow["JOIN_DATE"]));
			if ($userrow["USER_NAME"]=="") $invitedByNode->set_data("-");else $invitedByNode->set_data($userrow["USER_NAME"]);
			if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){
				$activeStatusNode =& $memberNode->add_node('activeStatus');
				if ($userrow["ACTIVE_STATUS"]==1) $activeStatusNode->set_data("Active");else $activeStatusNode->set_data("Inactive");
			}
		}
		countPage($cp,$number_per_page,"");
	//}
}
function searchMember($page,$searchKey){
//	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp,$num_per_page;
		connectdb();
		$number_per_page=$num_per_page;
		$begin=$number_per_page*($page-1);
		$comSQLSearchMember="SELECT T1.*,T2.USER_NAME FROM useraccount T1 LEFT JOIN useraccount T2 ON ( T1.INVITED_BY_ID = T2.USER_ID )  WHERE T1.USER_NAME LIKE '%".$searchKey."%' ";
		if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']!="admin"){
			$comSQLSearchMember.="AND T1.ACTIVE_STATUS=1";
		}
		$comSQLSearchMember.=" ORDER BY T1.USER_NAME LIMIT ".$begin." ,".$number_per_page;
		$searchMemberresult=mysql_query($comSQLSearchMember);
		echo mysql_error();
		while ($userrow=mysql_fetch_array($searchMemberresult)){
			$memberNode =& $cp->add_node('member');
			$userIDNode =& $memberNode->add_node('userID');
			$userNameNode =& $memberNode->add_node('userName');
			$invitedByNode =& $memberNode->add_node('invitedBy');
			$lvNode =& $memberNode->add_node('lv');
			$underLabNode =& $memberNode->add_node('underLab');
			$subLvNode =& $memberNode->add_node('subLv');
			$jointDateNode =& $memberNode->add_node('jointDate');
			if ($userrow["USER_ID"]=="") $userIDNode->set_data("-");else $userIDNode->set_data($userrow["USER_ID"]);
			if ($userrow[1]=="") $userNameNode->set_data("-");else $userNameNode->set_data($userrow[1]);
			if ($userrow["LEVEL"]=="") $lvNode->set_data("-");else $lvNode->set_data($userrow["LEVEL"]);
			if ($userrow["UNDER_LAB"]=="") $underLabNode->set_data("-");else $underLabNode->set_data($userrow["UNDER_LAB"]);
			if ($userrow["SUB_LEVEL"]=="") $subLvNode->set_data("-");else $subLvNode->set_data($userrow["SUB_LEVEL"]);	
			if ($userrow["JOIN_DATE"]=="") $jointDateNode->set_data("-");else $jointDateNode->set_data(date("d-m-Y H:i:s",$userrow["JOIN_DATE"]));
			if ($userrow["USER_NAME"]=="") $invitedByNode->set_data("-");else $invitedByNode->set_data($userrow["USER_NAME"]);
			if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){
				$activeStatusNode =& $memberNode->add_node('activeStatus');
				if ($userrow["ACTIVE_STATUS"]==1) $activeStatusNode->set_data("Active");else $activeStatusNode->set_data("Inactive");
			}
		}
		$searchKeyNode =& $cp->add_node('searchKey');
		$searchKeyNode->set_data($searchKey);	
		countPage($cp,$number_per_page,$searchKey);
//	}
}

function getInfomember($userID){
//	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();	
		$comSQLSelectMember="SELECT T1.*,T2.USER_NAME FROM useraccount T1 LEFT JOIN useraccount T2 ON ( T1.INVITED_BY_ID = T2.USER_ID ) WHERE T1.USER_ID=".$userID;
		if (isset($_SESSION['ss_Level']) and $_SESSION['ss_Level'] !="admin" ){
			$comSQLSelectMember.=" AND T1.ACTIVE_STATUS=1";
		}
		$selectMemberresult=mysql_query($comSQLSelectMember);
		echo mysql_error();
		if ($userrow=mysql_fetch_array($selectMemberresult)){
			$memberNode =& $cp->add_node('member');
			$userIDNode =& $memberNode->add_node('userID');
			$userNameNode =& $memberNode->add_node('userName');
			$invitedByNode =& $memberNode->add_node('invitedBy');
			$lvNode =& $memberNode->add_node('lv');
			$underLabNode =& $memberNode->add_node('underLab');
			$jointDateNode =& $memberNode->add_node('jointDate');
			$EmailNode =& $memberNode->add_node('Email');
			$tTopicNode =& $memberNode->add_node('tTopic');
			$tOpinionNode =& $memberNode->add_node('tOpinion');
			$pointNode =& $memberNode->add_node('point');
			if ($userrow["USER_ID"]=="") $userIDNode->set_data("-");else $userIDNode->set_data($userrow["USER_ID"]);
			if ($userrow[1]=="") $userNameNode->set_data("-");else $userNameNode->set_data($userrow[1]);
			if ($userrow["LEVEL"]=="") $lvNode->set_data("-");else $lvNode->set_data($userrow["LEVEL"]);
			$underLab="";
			$underLab= getUnderLab($userrow["USER_ID"]);
			if ($underLab=="") $underLabNode->set_data("-");else $underLabNode->set_data($underLab);
			if ($userrow["JOIN_DATE"]=="") $jointDateNode->set_data("-");else $jointDateNode->set_data(date("d-m-Y H:i:s",$userrow["JOIN_DATE"]));

			if ($userrow["EMAIL"]=="") {
				$EmailNode->set_data("-");
			}else {	
				if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){
					$EmailNode->set_data($userrow["EMAIL"]);	
				}else if($userrow["FLAG_SHOW_EMAIL"]==1){
					$EmailNode->set_data($userrow["EMAIL"]);	
				}else {
					$EmailNode->set_data("-");	
				}
			}
			if ($userrow["TOTALTOPIC"]=="") $tTopicNode->set_data("-");else $tTopicNode->set_data($userrow["TOTALTOPIC"]);	
			if ($userrow["TOTALOPINION"]=="") $tOpinionNode->set_data("-");else $tOpinionNode->set_data($userrow["TOTALOPINION"]);	
			if ($userrow["POINT"]=="") $pointNode->set_data("-");else $pointNode->set_data($userrow["POINT"]);	
			if ($userrow["USER_NAME"]=="") $invitedByNode->set_data("-");else $invitedByNode->set_data($userrow["USER_NAME"]);
			if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){
						$tNameNode =& $memberNode->add_node('tName');
						$fNameNode =& $memberNode->add_node('fName');	
						$lNameNode =& $memberNode->add_node('lName');
						$nNameNode =& $memberNode->add_node('nName');
						$homeAddrNode =& $memberNode->add_node('homeAddr');
						$mobilePhoneNode =& $memberNode->add_node('mobilePhone');
						$homePhoneNode =& $memberNode->add_node('homePhone');
						$sIDNode =& $memberNode->add_node('sID');
						$departmentNode =& $memberNode->add_node('department');
						$generationNode =& $memberNode->add_node('generation');
						$sectionNode =& $memberNode->add_node('section');	
						$activeStatusNode =& $memberNode->add_node('activeStatus');
						$tBadpostNode =& $memberNode->add_node('tBadpost');

						if ($userrow["TITLE"]=="") $tNameNode->set_data("-");else $tNameNode->set_data($userrow["TITLE"]);
						if ($userrow["FIRST_NAME"]=="") $fNameNode->set_data("-");else $fNameNode->set_data($userrow["FIRST_NAME"]);
						if ($userrow["LAST_NAME"]=="") $lNameNode->set_data("-");else $lNameNode->set_data($userrow["LAST_NAME"]);
						if ($userrow["NICK_NAME"]=="") $nNameNode->set_data("-");else $nNameNode->set_data($userrow["NICK_NAME"]);
						if ($userrow["HOME_ADDRESS"]=="") $homeAddrNode->set_data("-");else $homeAddrNode->set_data($userrow["HOME_ADDRESS"]);
						if ($userrow["MOBILE_PHONE"]=="") $mobilePhoneNode->set_data("-");else $mobilePhoneNode->set_data($userrow["MOBILE_PHONE"]);
						if ($userrow["HOME_PHONE"]=="") $homePhoneNode->set_data("-");else $homePhoneNode->set_data($userrow["HOME_PHONE"]);
						if ($userrow["STUDENT_ID"]=="")
						{
							$sIDNode->set_data("-");
							$departmentNode->set_data("-");
							$generationNode->set_data("-");
							$sectionNode->set_data("-");
						}else{
							$sIDNode->set_data($userrow["STUDENT_ID"]);
							getStudentInfo($userrow["STUDENT_ID"],$departmentNode,$generationNode,$sectionNode);
						}
						if ($userrow["BADPOST"]=="") $tBadpostNode->set_data("-");else $tBadpostNode->set_data($userrow["BADPOST"]);
						if ($userrow["ACTIVE_STATUS"]==1) $activeStatusNode->set_data("Active");else $activeStatusNode->set_data("Inactive");
						$checkresult=checkLecturer($userrow["USER_ID"]);
						$lecIDNode =& $memberNode->add_node('lecID');
						if ($lecrow=mysql_fetch_array($checkresult)){
							 $lecIDNode->set_data($lecrow["LECTURER_ID"]);
						}else {
							$lecIDNode->set_data("-");
						}
			}
			addAdminRoomInfo($_SESSION['ss_UserID']);
		}
//	}
}
function getStudentInfo ($studentID,$departmentNode,$generationNode,$sectionNode ){
	$comSQLgetstudentInfo = "SELECT * FROM student WHERE STUDENT_ID=$studentID";
		if ($sturow=mysql_fetch_array(mysql_query($comSQLgetstudentInfo))){
				$departmentNode ->set_data($sturow["DEPARTMENT"]);
				$generationNode ->set_data($sturow["GENERATION"]);
				$sectionNode ->set_data($sturow["SECTION"]);
		}else{
				$departmentNode ->set_data("-");
				$generationNode ->set_data("-");
				$sectionNode ->set_data("-");
		}
		echo mysql_error();
}
function checkLecturer($userID){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		$comSQLcheckLectuer="SELECT * FROM lecturer  WHERE USER_ID=".$userID;
		$checkresult=mysql_query($comSQLcheckLectuer);
		echo mysql_error();
		return $checkresult;
	}
}

function addAdminRoomInfo($userID){
		global $cp;
		$labNodes = & $cp->add_node('labs');
		$comSQLgetUnderLab="SELECT * FROM laboratory_member T1,laboratory T2  WHERE T1.LAB_ID=T2.LAB_ID AND T1.LEVEL='admin' AND T1.USER_ID=".$userID;
		$getUnderLabresult=mysql_query($comSQLgetUnderLab);
		while($labrow=mysql_fetch_array($getUnderLabresult)){
			$labNode = & $labNodes->add_node('underLabID');
			$labNode->set_attribute('alias',$labrow["ALIAS"]);
			$labNode->set_data ($labrow["LAB_ID"]);
		}
		
}
function countPage($cpObject,$numPerPage,$searchKey){
		$comSQLcountMember="SELECT COUNT(*) FROM useraccount WHERE USER_NAME LIKE '%".$searchKey."%' ";
		if (isset($_SESSION['ss_Level']) and $_SESSION['ss_Level'] !="admin" ){
			$comSQLcountMember.=" AND ACTIVE_STATUS=1";
		}
		$countMemberresult=mysql_query($comSQLcountMember);
		$userrow=mysql_fetch_array($countMemberresult);
		$totalPageNode =& $cpObject->add_node('totalpage');
		$totalPage= ceil($userrow[0]/$numPerPage);
		$totalPageNode->set_data($totalPage);
}
?>