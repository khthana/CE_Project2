<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
require_once '../Excel/reader.php';
session_start();
$cp = new cpaint();
$cp->register('readexcel');
$cp->start();
$cp->return_data();
$pathFiles = "../uploaded/files/";
function readexcel($generation, $section,$filename) {
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$liststudentNode =& $cp->add_node('liststudent');

	$resultreadfile= readfileexcel($liststudentNode,$filename);
	if($resultreadfile){
			$permitionNode->set_data('permit');
	}else{
			$permitionNode->set_data('Can not read excelfile ,Please uploadfile again');
			}	
}

function readfileexcel($liststudentNode,$filename){
	global  $pathFiles;
	$pathFiles ="../uploaded/files/".$filename;
	$data = new Spreadsheet_Excel_Reader();
	$data->setOutputEncoding('UTF-8');
	$data->read($pathFiles);
	if (error_reporting(E_ALL ^ E_NOTICE))
	{
		for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {
			for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
				$liststudent .= $data->sheets[0]['cells'][$i][$j]." ";
			}
		$liststudent .= '<br>';
		}
		$liststudentNode->set_data($liststudent);
		return true;
	}else{
		return false;
	}
}
?>