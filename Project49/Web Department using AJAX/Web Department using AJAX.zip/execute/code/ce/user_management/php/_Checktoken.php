<?php
include("../_Connectdatabase.php");
	function checkToken($id,$token){
			connectdb();
			$comSQLcheckToken="SELECT * FROM token_invite WHERE USER_ID=".$id." AND TOKEN_INV='".$token."'";
			mysql_query("SET NAMES utf8"); 
			$checkTokenresult=mysql_query($comSQLcheckToken);
			echo mysql_error();
			if($userrow=mysql_fetch_array($checkTokenresult)  ){
				return true;
			}else return false;
	}
?>