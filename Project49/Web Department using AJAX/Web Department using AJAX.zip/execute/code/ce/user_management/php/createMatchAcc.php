<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
include("_CheckAuthen.php");
$cp = new cpaint();
$cp->register('createAcc');
$cp->register('matchAcc');
$cp->start();
$cp->return_data();
function createAcc($username,$password,$question,$answer){
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$redirectpageNode =& $cp->add_node('editProfilepage');
	if (!checkDuplicateUsername($username)){
			$comSQLselectToken="SELECT * FROM token_invite WHERE USER_ID=".$_SESSION['ss_uID']." AND TOKEN_INV='".$_SESSION['ss_token']."'";
			mysql_query("SET NAMES utf8"); 
			$selectTokenresult=mysql_query($comSQLselectToken);
			echo mysql_error();
			if($tokenrow=mysql_fetch_array($selectTokenresult)  ){
				$genStr=md5(rand(0,1000000000000));
				$salt= substr($genStr,-8);
				$salt="$1$".$salt."$";
				$password = crypt($password, $salt);
				$answer =crypt($answer, $salt);
				$id = "SELECT MAX( USER_ID )FROM useraccount ";
				$id = mysql_query($id);
				$id = mysql_fetch_array($id);
				$idG = $id[0] + 1;
				if($tokenrow["TYPE"]=="lecturer"){
					$level="lecturer";
					$point=1000000;
				}else{
					$level="user";
					$point=100;
				}
				$jointDate= time();
				$comSQLInsertUser="INSERT INTO useraccount  SET".
				" USER_ID=".$idG.
				",USER_NAME='".$username."'".
				",PASSWORD='".$password."'".
				",EMAIL='".$tokenrow["EMAIL_SEND"]."'".
				",JOIN_DATE=".$jointDate.
				",INVITED_BY_ID=".$tokenrow["USER_ID"].
				",LEVEL='".$level."'".
				",SALT='".$salt."'".
				",POINT=".$point.
				",TOTALTOPIC=0".
				",TOTALOPINION=0".
				",BADPOST=0".
				",SC_QUESTION='".$question."'".
				",SC_ANSWER='".$answer."'";
				if ($tokenrow["TYPE"]=="student"){
					$comSQLInsertUser.=",FIRST_NAME='".$tokenrow["FIRST_NAME"]."'".
					",TITLE='".$tokenrow["TITLE"]."'".
					",LAST_NAME='".$tokenrow["LAST_NAME"]."'".
					",STUDENT_ID=".$tokenrow["STUDENT_ID"];
				}
				mysql_query($comSQLInsertUser);
				echo mysql_error();
				if($tokenrow["TYPE"]=="lecturer"){
						updateLecturer($tokenrow,$idG);
				}else if ($tokenrow["TYPE"]=="student"){
						registerStudent($tokenrow,$idG);
				}
				echo mysql_error();
				if (!mysql_error()){
					eraseToken($_SESSION['ss_uID'],$_SESSION['ss_token']);
				}
				echo mysql_error();

				if (!mysql_error()){
					$_SESSION['ss_UserName']=$username;
					$_SESSION['ss_UserID']=$idG;
					$_SESSION['ss_Level']=$level;
					$_SESSION['ss_Status']="online";
				}
			}
		$permitionNode->set_data('permit');
		$redirectpageNode->set_data('showProfile.php');
	}else {
		$permitionNode->set_data('reject');
	}
}
function matchAcc($username,$password){
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$redirectpageNode =& $cp->add_node('editProfilepage');
	$checkAuthenresult= checkAuthen($username, $password);
	if($userrow=mysql_fetch_array($checkAuthenresult)  ){
			$comSQLselectToken="SELECT * FROM token_invite WHERE USER_ID=".$_SESSION['ss_uID']." AND TOKEN_INV='".$_SESSION['ss_token']."'";
			mysql_query("SET NAMES utf8"); 
			$selectTokenresult=mysql_query($comSQLselectToken);
			echo mysql_error();
			if($tokenrow=mysql_fetch_array($selectTokenresult)  ){
					if ($tokenrow["TYPE"]=="student"){
						if (!checkDuplicateStudent($userrow["STUDENT_ID"])){
								registerStudent($tokenrow,$userrow["USER_ID"]);
								echo mysql_error();
								$permitionNode->set_data('permit');
							}else {
								updateStudent($tokenrow ,$userrow["USER_ID"], $userrow["STUDENT_ID"]);
								$permitionNode->set_data('updateComplete');
							}
						$comSQLUpdateUser ="UPDATE useraccount SET ".
						" FIRST_NAME='".$tokenrow["FIRST_NAME"]."'".
						",TITLE='".$tokenrow["TITLE"]."'".
						",LAST_NAME='".$tokenrow["LAST_NAME"]."'".
						",STUDENT_ID='".$tokenrow["STUDENT_ID"]."'";
						$comSQLUpdateUser .=" WHERE USER_ID=".$userrow["USER_ID"];
						$level="user";
					}elseif ($tokenrow["TYPE"]=="lecturer"){
						$level="lecturer";
						$point=1000000;
						$comSQLUpdateUser ="UPDATE useraccount SET ".
							" LEVEL='".$level."'".
							",POINT=".$point;
						$comSQLUpdateUser .=" WHERE USER_ID=".$userrow["USER_ID"];
						updateLecturer($tokenrow,$userrow["USER_ID"]);
						$permitionNode->set_data('updateComplete');
					}
					if ($tokenrow["TYPE"]=="general"){
						$permitionNode->set_data('updateComplete');
					}
					echo mysql_error();
					if (!mysql_error()){
						eraseToken($_SESSION['ss_uID'],$_SESSION['ss_token']);
						echo mysql_error();
					}
					if (!mysql_error()){
						$_SESSION['ss_UserName']=$username;
						$_SESSION['ss_UserID']=$userrow["USER_ID"];
						$_SESSION['ss_Level']=$level;
						$_SESSION['ss_Status']="online";
						$redirectpageNode->set_data('showProfile.php');
					}
			}

		
		
		return true;
	}else {
		$permitionNode->set_data('rejectAuthen');
		return false;
	}
}
function checkDuplicateUsername($username){
	$comSQLcheckDuplicateUsername="SELECT * FROM useraccount WHERE USER_NAME='".$username."'";
	$DuplicateUsernameresult=mysql_query($comSQLcheckDuplicateUsername);
	if ($checktrow=mysql_fetch_array($DuplicateUsernameresult)){
		return true;
	}else return false;
}
function checkDuplicateLecturer($userID){
	$comSQLcheckDuplicateLecturer="SELECT * FROM lecturer  WHERE USER_ID=".$userID;
	$DuplicateLecturerresult=mysql_query($comSQLcheckDuplicateLecturer);
	if ($checktrow=mysql_fetch_array($DuplicateLecturerresult)){
		return true;
	}else return false;
}
function checkDuplicateStudent($studentID){
	$comSQLcheckDuplicateStudent="SELECT * FROM student  WHERE STUDENT_ID=".$studentID;
	$DuplicateStudentresult=mysql_query($comSQLcheckDuplicateStudent);
	if ($checktrow=mysql_fetch_array($DuplicateStudentresult)){
		return true;
	}else return false;
}
function registerStudent($token,$idG){
		if ($token["TYPE"]=="student"){
					$comSQLInsertUserStudent="INSERT INTO student    SET".
						" STUDENT_ID=".$token["STUDENT_ID"].
						",DEPARTMENT='".$token["DEPARTMENT"]."'".
						",SECTION='".$token["SECTION"]."'".
						",GENERATION=".$token["GENERATION"].
						",USER_ID=".$idG;
				mysql_query($comSQLInsertUserStudent);
				echo mysql_error();
			}
}


function eraseToken($iid,$token){
		$comSQLDeletetoken="DELETE FROM token_invite WHERE USER_ID=".$iid." AND TOKEN_INV='".$token."'";
		mysql_query($comSQLDeletetoken);
}
function updateStudent($token,$userID,$studentID){
	$comSQLUpdateUser ="UPDATE useraccount SET ".
							" STUDENT_ID=NULL";
	$comSQLUpdateUser .=" WHERE STUDENT_ID=".$studentID;
	mysql_query($comSQLUpdateUser);
	$comSQLUpdateUser ="UPDATE useraccount SET ".
							" STUDENT_ID=$studentID";
	$comSQLUpdateUser .=" WHERE USER_ID=".$userID;
	mysql_query($comSQLUpdateUser);
	$comSQLUpdateStudent ="UPDATE student  SET ".
							" USER_ID=$userID".
							",DEPARTMENT='".$token["DEPARTMENT"]."'".
							",SECTION='".$token["SECTION"]."'".
							",GENERATION=".$token["GENERATION"];
	$comSQLUpdateStudent .=" WHERE STUDENT_ID=".$studentID;
	mysql_query($comSQLUpdateStudent);
}
function updateLecturer($token,$userID){
		if (checkDuplicateLecturer($userID)){
				$comSQLUpdateLecturer ="UPDATE lecturer  SET ".
							" USER_ID=NULL";
				$comSQLUpdateLecturer .=" WHERE USER_ID=".$userID;
				mysql_query($comSQLUpdateLecturer);
				$comSQLUpdatemainAcc ="UPDATE useraccount   SET ".
							" LEVEL='user'".
							",POINT=100";
				$comSQLUpdatemainAcc .=" WHERE USER_ID=".$userID;
				mysql_query($comSQLUpdatemainAcc);
		}
		echo mysql_error();
		if (!mysql_error()){
					$comSQLUpdateLecturer="UPDATE lecturer  SET ".
										" USER_ID=".$userID;
					$comSQLUpdateLecturer .=" WHERE LECTURER_ID=".$token["LECTURER_ID"];
					mysql_query($comSQLUpdateLecturer);
		}
}
?>