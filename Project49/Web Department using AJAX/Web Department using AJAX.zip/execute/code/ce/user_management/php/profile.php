<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("_CheckAuthen.php");
include("../../_Sessionstart.php");
include("getUnderLab.php");
$cp = new cpaint();
$cp->register('getProfile');
$cp->register('editProfile');
$cp->start();
$cp->return_data();

function getProfile(){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		$userNameNode =& $cp->add_node('userName');
		$tNameNode =& $cp->add_node('tName');		
		$fNameNode =& $cp->add_node('fName');
		$lNameNode =& $cp->add_node('lName');
		$nNameNode =& $cp->add_node('nName');
		$homeAddrNode =& $cp->add_node('homeAddr');
		$EmailNode =& $cp->add_node('Email');
		$flagShowEmailNode =& $cp->add_node('flagShowEmail');
		$mobilePhoneNode =& $cp->add_node('mobilePhone');
		$homePhoneNode =& $cp->add_node('homePhone');
		$invitedByNode =& $cp->add_node('invitedBy');
		$lvNode =& $cp->add_node('lv');
		$underLabNode =& $cp->add_node('underLab');
		$sIDNode =& $cp->add_node('sID');
		$departmentNode =& $cp->add_node('department');
		$generationNode =& $cp->add_node('generation');
		$sectionNode =& $cp->add_node('section');
		$pointNode =& $cp->add_node('point');
		$tBadpostNode =& $cp->add_node('tBadpost');
		$tTopicNode =& $cp->add_node('tTopic');
		$tOpinionNode =& $cp->add_node('tOpinion');
		$jointDateNode =& $cp->add_node('jointDate');

		$comSQLSelectProfile="SELECT * FROM useraccount WHERE USER_ID=".$_SESSION['ss_UserID'];
		$selectProfileresult=mysql_query($comSQLSelectProfile);
		if ($userrow=mysql_fetch_array($selectProfileresult)){
			
			if ($userrow["USER_NAME"]=="") $userNameNode->set_data("-");else $userNameNode->set_data($userrow["USER_NAME"]);
			if ($userrow["FIRST_NAME"]=="") $fNameNode->set_data("-");else $fNameNode->set_data($userrow["FIRST_NAME"]);
			if ($userrow["TITLE"]=="") $tNameNode->set_data("-");else $tNameNode->set_data($userrow["TITLE"]);
			if ($userrow["LAST_NAME"]=="") $lNameNode->set_data("-");else $lNameNode->set_data($userrow["LAST_NAME"]);
			if ($userrow["NICK_NAME"]=="") $nNameNode->set_data("-");else $nNameNode->set_data($userrow["NICK_NAME"]);
			if ($userrow["HOME_ADDRESS"]=="") $homeAddrNode->set_data("-");else $homeAddrNode->set_data($userrow["HOME_ADDRESS"]);
			if ($userrow["EMAIL"]=="") $EmailNode->set_data("-");else $EmailNode->set_data($userrow["EMAIL"]);
			if ($userrow["FLAG_SHOW_EMAIL"]=="") $flagShowEmailNode->set_data("-");else $flagShowEmailNode->set_data($userrow["FLAG_SHOW_EMAIL"]);
			if ($userrow["MOBILE_PHONE"]=="") $mobilePhoneNode->set_data("-");else $mobilePhoneNode->set_data($userrow["MOBILE_PHONE"]);
			if ($userrow["HOME_PHONE"]=="") $homePhoneNode->set_data("-");else $homePhoneNode->set_data($userrow["HOME_PHONE"]);
			if ($userrow["LEVEL"]=="") $lvNode->set_data("-");else $lvNode->set_data($userrow["LEVEL"]);
		
			
			if ($userrow["POINT"]=="") $pointNode->set_data("-");else $pointNode->set_data($userrow["POINT"]);
			if ($userrow["BADPOST"]=="") $tBadpostNode->set_data("-");else $tBadpostNode->set_data($userrow["BADPOST"]);
			if ($userrow["TOTALTOPIC"]=="") $tTopicNode->set_data("-");else $tTopicNode->set_data($userrow["TOTALTOPIC"]);
			if ($userrow["TOTALOPINION"]=="") $tOpinionNode->set_data("-");else $tOpinionNode->set_data($userrow["TOTALOPINION"]);
			if ($userrow["JOIN_DATE"]=="") $jointDateNode->set_data("-");else $jointDateNode->set_data(date("d-m-Y H:i:s",$userrow["JOIN_DATE"]));

			if ($userrow["STUDENT_ID"]=="")
			{
				$sIDNode->set_data("-");
				$departmentNode->set_data("-");
				$generationNode->set_data("-");
				$sectionNode->set_data("-");
			}else{
				$sIDNode->set_data($userrow["STUDENT_ID"]);
				getStudentInfo($userrow["STUDENT_ID"],$departmentNode,$generationNode,$sectionNode);
			}
			$underLab=getUnderLab($_SESSION['ss_UserID']);
			if ($underLab=="") $underLabNode->set_data("-");else {
				$underLabNode->set_data($underLab);
			}

			$comSQLSelectInviter="SELECT USER_NAME FROM useraccount WHERE USER_ID=".$userrow["INVITED_BY_ID"];
			$Inviterresult=mysql_query($comSQLSelectInviter);
			$inviterrow=mysql_fetch_array($Inviterresult);
			$invitedByNode->set_data($inviterrow[0]);
		}

	}

}

function getStudentInfo ($studentID,$departmentNode,$generationNode,$sectionNode ){
	$comSQLgetstudentInfo = "SELECT * FROM student WHERE STUDENT_ID=$studentID";
		if ($sturow=mysql_fetch_array(mysql_query($comSQLgetstudentInfo))){
				$departmentNode ->set_data($sturow["DEPARTMENT"]);
				$generationNode ->set_data($sturow["GENERATION"]);
				$sectionNode ->set_data($sturow["SECTION"]);
		}else{
				$departmentNode ->set_data("-");
				$generationNode ->set_data("-");
				$sectionNode ->set_data("-");
		}
		echo mysql_error();
}

function editProfile($username,$password,$titleName,$firstName,$lastName,$nickName,$homeAddress,$email,$showEmail,$mobilePhone,$homePhone,$newPassword){
	global $cp;
	$responseNode =& $cp->add_node('response');
	connectdb();
	$checkAuthenresult= checkAuthen($username, $password);
	if($userrow=mysql_fetch_array($checkAuthenresult)  ){
		$comSQLeditProfile="UPDATE useraccount SET ".
						" FIRST_NAME='$firstName'".
						",TITLE='$titleName'".
						",LAST_NAME='$lastName'".
						",NICK_NAME='$nickName'".
						",MOBILE_PHONE='$mobilePhone'".
						",HOME_PHONE='$homePhone'".
						",HOME_ADDRESS='$homeAddress'".
						",EMAIL='$email'".
						",FLAG_SHOW_EMAIL='$showEmail'";
		if ($newPassword!=""){
			$newPasswordEncry=crypt($newPassword,$userrow["SALT"]);
			$comSQLeditProfile.=",PASSWORD='$newPasswordEncry'";
		}
		$comSQLeditProfile .=" WHERE USER_NAME='$username'";
		mysql_query($comSQLeditProfile);
		$responseNode->set_data("permit");
	}else {
		$responseNode->set_data("reject");
		//$responseNode->set_data(mysql_error());
	}
}

?>