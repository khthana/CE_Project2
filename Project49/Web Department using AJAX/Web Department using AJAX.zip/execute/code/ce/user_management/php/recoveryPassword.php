<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
session_start();
$cp = new cpaint();
$cp->register('recoveryForm');
$cp->register('recoveryPass');
$cp->start();
$cp->return_data();

function recoveryForm($Username) {
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$questionNode =& $cp->add_node('question');
	$userNameNode =& $cp->add_node('userName');
	$comSQLgetQuestion = "SELECT * FROM useraccount WHERE USER_NAME ='$Username'";
	$checkUserNameresult= mysql_query($comSQLgetQuestion);
	if($userrow=mysql_fetch_array($checkUserNameresult)  ){
			$permitionNode->set_data('permit');
			$questionNode->set_data($userrow["SC_QUESTION"]);
			$userNameNode->set_data($userrow["USER_NAME"]);
	}else{
			$permitionNode->set_data('reject');
			echo mysql_error();
	}
}
function recoveryPass($Username, $answer) {
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$newPassNode =& $cp->add_node('newPass');
	$checkAuthenresult= checkAnswer($Username, $answer);
	if($userrow=mysql_fetch_array($checkAuthenresult)  ){
			$genStr=md5(rand(0,1000000000000));
			$newpass= substr($genStr,-8);
			$newEncrypPass=crypt($newpass,$userrow["SALT"]);
			$comSQLRePassword="UPDATE useraccount SET PASSWORD='$newEncrypPass' WHERE  USER_ID=".$userrow["USER_ID"];
			mysql_query($comSQLRePassword);
			$_SESSION['ss_UserName']=$userrow["USER_NAME"];
			$_SESSION['ss_UserID']=$userrow["USER_ID"];
			$_SESSION['ss_Level']=$userrow["LEVEL"];
			$_SESSION['ss_privcode']=$userrow["USER_PRIV_CODE"];
			$_SESSION['ss_point']=$userrow["POINT"];
			$_SESSION['ss_LoginTime']=time();
			if($userrow["LEVEL"]!='guest'){
				$_SESSION['ss_Status']="online";
			}
			if (keepLog($userrow["USER_ID"])){
					$permitionNode->set_data('permit');
					$newPassNode->set_data($newpass);
			}else {
						$permitionNode->set_data(mysql_error());
			}
	}else {
			$permitionNode->set_data("reject");
	}
}

function keepLog($userID){
		$comSQLInsertLog="INSERT INTO log_login  SET".
			" USER_ID=".$userID.
			",TIME=".time();
		mysql_query($comSQLInsertLog);
		if( !mysql_error()){
			return true;
		}else return false;
}

function checkAnswer($Username, $answer){
	$comSQLcheckSalt="SELECT SALT FROM useraccount WHERE USER_NAME='".$Username."'";
	$saltresult=mysql_query($comSQLcheckSalt);
	$saltrow=mysql_fetch_array($saltresult);
	$answer=crypt($answer,$saltrow[0]);
	$comSQLcheckAuthen="SELECT * FROM useraccount WHERE USER_NAME='".$Username."'AND SC_ANSWER='".$answer."'";
	$Authenresult=mysql_query($comSQLcheckAuthen);
	return $Authenresult;
}
?>
