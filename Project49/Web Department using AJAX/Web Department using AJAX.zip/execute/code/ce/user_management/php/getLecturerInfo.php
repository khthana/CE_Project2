<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('getlistLecturer');
$cp->start();
$cp->return_data();
function getlistLecturer($caption,$fullname){
	global $cp;
	connectdb();
	$listLecturerNode =& $cp->add_node('listLecturer');
	$firstname="";
	$lastname="";
	if ($fullname=="") return ;
	if (strpos($fullname," ") > 0){
		list($firstname,$lastname) = explode(" ",$fullname);
	}else {
		$firstname=$fullname;
		$lastname="";
	}
	if ($lastname!=""){
		$comSQLgetlistLecturer ="SELECT * FROM lecturer WHERE CAPTION LIKE '%$caption%' AND NAME LIKE '%$firstname%' AND  SERNAME LIKE '%$lastname%'";
	}else{
		$comSQLgetlistLecturer= "SELECT * FROM lecturer WHERE CAPTION LIKE '%$caption%' AND NAME LIKE '%$firstname%' ";
	}
	$listLecturerresult= mysql_query($comSQLgetlistLecturer);
	while ($lecturer=mysql_fetch_array($listLecturerresult)){
		$lecturerNode =& $listLecturerNode->add_node('listLecturer');
		$lecturerIDNode =& $lecturerNode->add_node('lecturerID');
		$captionNode =& $lecturerNode->add_node('caption');
		$nameNode =& $lecturerNode->add_node('name');
		$sernameNode =& $lecturerNode->add_node('sername');
		$positionNode =& $lecturerNode->add_node('position');
		$emailLNode =& $lecturerNode->add_node('emailL');
		$contactPhoneNoNode =& $lecturerNode->add_node('contactPhoneNo');
		$officeNode =& $lecturerNode->add_node('office');
		$teachLVNode =& $lecturerNode->add_node('teachLV');
		$linkNode =& $lecturerNode->add_node('link');
		$researchNode =& $lecturerNode->add_node('research');
		$usernameNode =& $lecturerNode->add_node('username');
		$lecturerIDNode->set_data($lecturer["LECTURER_ID"]);
		if ($lecturer["CAPTION"]=="") $captionNode->set_data("-");else $captionNode->set_data($lecturer["CAPTION"]);
		if ($lecturer["NAME"]=="") $nameNode->set_data("-");else $nameNode->set_data($lecturer["NAME"]);
		if ($lecturer["SERNAME"]=="") $sernameNode->set_data("-");else $sernameNode->set_data($lecturer["SERNAME"]);
		if ($lecturer["POSITION"]=="") $positionNode->set_data("-");else $positionNode->set_data($lecturer["POSITION"]);
		if ($lecturer["EMAIL"]=="") $emailLNode->set_data("-");else $emailLNode->set_data($lecturer["EMAIL"]);
		if ($lecturer["OFFICE"]=="") $officeNode->set_data("-");else $officeNode->set_data($lecturer["OFFICE"]);
		if ($lecturer["CLASS"]=="") $teachLVNode->set_data("-");else $teachLVNode->set_data($lecturer["CLASS"]);
		if ($lecturer["PHONE_OFFICE"]=="") $contactPhoneNoNode->set_data("-");else $contactPhoneNoNode->set_data($lecturer["PHONE_OFFICE"]);
		if ($lecturer["LINK"]=="") $linkNode->set_data("-");else $linkNode->set_data($lecturer["LINK"]);
		if ($lecturer["RESEARCH"]=="") $researchNode->set_data("-");else $researchNode->set_data($lecturer["RESEARCH"]);
		if ($lecturer["USER_ID"]==""){
					$usernameNode->set_data("ไม่พบว่าเคยลงทะเบียนในระบบ");
		}else {
					$comSQLgetUsername= "SELECT USER_NAME FROM useraccount WHERE USER_ID=".$lecturer["USER_ID"];
					$getUsernameresult= mysql_query($comSQLgetUsername);
					if ($username=mysql_fetch_array($getUsernameresult)){
						$usernameNode->set_data($username[0]);
					}else {
						$usernameNode->set_data("ไม่พบว่าเคยลงทะเบียนในระบบ");
					}
		}
	}
}

?>