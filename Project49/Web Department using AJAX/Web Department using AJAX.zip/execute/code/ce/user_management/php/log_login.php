<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
//include("../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
$num_per_page=20;
$cp = new cpaint();
$cp->register('getLogFile');
$cp->start();
$cp->return_data();
function getLogFile($uID,$page){
	if ((isset($_SESSION['ss_Level'])) and ($_SESSION['ss_Level']=="admin" or $_SESSION['ss_UserID']==$uID)){
		global $cp,$num_per_page;
		connectdb();
		$number_per_page=$num_per_page;
		$begin=$number_per_page*($page-1);
		$comSQLGetusername="SELECT * FROM useraccount WHERE USER_ID=".$uID;
		$getusernameresult=mysql_query($comSQLGetusername);
		if ($userrow=mysql_fetch_array($getusernameresult)){
			$checkNode =& $cp->add_node('check');
			$checkNode->set_data(true);
			$userIDNode =& $cp->add_node('userID');
			//$userNameNode =& $cp->add_node('userName');
			$userIDNode->set_data($uID);
			//$userNameNode->set_data($userrow["USER_NAME"]);
			$timesNode =& $cp->add_node('times');

			$comSQLSelectLog="SELECT * FROM log_login ";
			$comSQLSelectLog.=" WHERE USER_ID=".$uID;
			$comSQLSelectLog.=" ORDER BY TIME DESC LIMIT ".$begin." ,".$number_per_page;
			$selectLogresult=mysql_query($comSQLSelectLog);		
			while ($userrow=mysql_fetch_array($selectLogresult)){
				$tmNode =& $timesNode->add_node('tm');
				$tmNode->set_data(date("d-m-Y H:i:s",$userrow["TIME"]));
			}
			countPage($cp,$number_per_page,$uID);
		}else {
			$checkNode =& $cp->add_node('check');
			$checkNode->set_data("not found");
		}
	}
}


function countPage($cpObject,$numPerPage,$uID){
		$comSQLcountMember="SELECT COUNT(*) FROM log_login WHERE USER_ID=".$uID;
		$countMemberresult=mysql_query($comSQLcountMember);
		$userrow=mysql_fetch_array($countMemberresult);
		$totalPageNode =& $cpObject->add_node('totalpage');
		$totalPage= ceil($userrow[0]/$numPerPage);
		$totalPageNode->set_data($totalPage);
}
?>