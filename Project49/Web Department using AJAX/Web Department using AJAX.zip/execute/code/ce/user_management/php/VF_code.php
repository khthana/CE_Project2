<?php
session_start();
header("content-type : image/gif");

$imgFileName="code".$_GET['id'].".gif";
$imgPathFile="../pic/VF_code/";
$imgFile=$imgPathFile.$imgFileName;
$img=imagecreatefromgif($imgFile);
imagegif($img);
imagedestroy($img);
?>