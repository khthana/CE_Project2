﻿<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("_CheckAuthen.php");
session_start();
$cp = new cpaint();
$cp->register('login');
$cp->start();
$cp->return_data();

function login($Username, $Password,$code) {
	global $cp;
	connectdb();
	$permitionNode =& $cp->add_node('permition');
	$pagebeforeNode =& $cp->add_node('pagebefore');
	$codeidNode =& $cp->add_node('codeId');
	$verifycoderesult = checkVFcode($code);
	//echo $_SESSION['ss_VF_code'];
	echo mysql_error();
	//echo $verifycoderesult;
	if ($verifycoderesult=="valid"){
		$checkAuthenresult= checkAuthen($Username, $Password);
		if($userrow=mysql_fetch_array($checkAuthenresult)  ){
			$_SESSION['ss_UserName']=$userrow["USER_NAME"];
			$_SESSION['ss_UserID']=$userrow["USER_ID"];
			$_SESSION['ss_Level']=$userrow["LEVEL"];
			$_SESSION['ss_privcode']=$userrow["USER_PRIV_CODE"];
			$_SESSION['ss_point']=$userrow["POINT"];
			if($userrow["LEVEL"]!='guest'){
				$_SESSION['ss_Status']="online";
				setcookie ("login","ok",time()+3600,"/ce/");
			}
			if (keepLog($userrow["USER_ID"])){
				$permitionNode->set_data('permit');
			//	$pagebeforeNode->set_data($_SESSION['ss_PageBefore']);
				$pagebeforeNode->set_data("../index.php");
			}else {
				$permitionNode->set_data(mysql_error());
			}
		}else{
			$permitionNode->set_data('rejectA');
			$_SESSION['ss_VF_code']=rand(0, 15);
			$codeidNode->set_data($_SESSION['ss_VF_code']);
			}
	}else{
		$permitionNode->set_data('rejectB');
		$_SESSION['ss_VF_code']=rand(0, 15);
		$codeidNode->set_data($_SESSION['ss_VF_code']);
	}
}

function checkVFcode($code){
	$comSQLcheckVFcode="SELECT * FROM verify_code  WHERE CODE_ID=".$_SESSION['ss_VF_code']." AND CODE='".$code."'";
	//echo $comSQLcheckVFcode;
	//echo mysql_error();
	if (mysql_fetch_array(mysql_query($comSQLcheckVFcode)))
	{
		return "valid";
	}else{
		return "invalid";
	}
}
function keepLog($userID){
		$comSQLInsertLog="INSERT INTO log_login  SET".
			" USER_ID=".$userID.
			",TIME=".time();
		mysql_query($comSQLInsertLog);
		if( !mysql_error()){
			return true;
		}else return false;
}
?>