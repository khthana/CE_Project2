<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
$cp = new cpaint();
$cp->register('adminEditInfo');
$cp->start();
$cp->return_data();
function adminEditInfo($userID,$newlv,$newstatus){
		if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){
			global $cp;
			connectdb();	
			$comSQLeditInfo="UPDATE useraccount SET ".
						" LEVEL='$newlv'".
						",ACTIVE_STATUS=$newstatus";
			if ($newlv=="admin") { getprivilegeAdmin($comSQLeditInfo);}else{getprivilege($comSQLeditInfo,$userID);}
			if ($newlv=="admin" or $newlv=="lecturer"){$comSQLeditInfo .=",POINT =100000000";}
			else if ($newlv=="senior" ){$comSQLeditInfo .=",POINT =1000";}
			else {$comSQLeditInfo .=",POINT =100";}
			$comSQLeditInfo .=" WHERE USER_ID=".$userID;
			mysql_query($comSQLeditInfo);
			if (!mysql_error()){
					$memberNode =& $cp->add_node('member');
					$lvNode =& $memberNode->add_node('lv');
					$activeStatusNode =& $memberNode->add_node('activeStatus');
					$lvNode->set_data($newlv);
					if ($newstatus==1) $activeStatusNode->set_data("Active");else $activeStatusNode->set_data("Inactive");
			}else{
					echo mysql_error();
			}
		}
}
function getprivilege(&$comSQLeditInfo,$userID){
	$priCode="AB";
	$comSQLgetAllCode= "SELECT T1.CODE_ROOM FROM laboratory T1,laboratory_member  T2 WHERE T1.LAB _ID=T2.LAB _ID AND T2.USER _ID=".$userID;
	$getAllCoderesult=mysql_query($comSQLgetAllCode);
	while ($coderow=mysql_fetch_array($getAllCoderesult)){
		$priCode.=$coderow["CODE_ROOM"];
	}
	$comSQLeditInfo.=",USER_PRIV_CODE='".$priCode."'";
}
function getprivilegeAdmin(&$comSQLeditInfo){
	$priCode="AB";
	$comSQLgetAllCode= "SELECT CODE_ROOM FROM laboratory ";
	$getAllCoderesult=mysql_query($comSQLgetAllCode);
	while ($coderow=mysql_fetch_array($getAllCoderesult)){
		$priCode.=$coderow[0];
		
	}
	$comSQLeditInfo.=",USER_PRIV_CODE='".$priCode."'";
}

?>