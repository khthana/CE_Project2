<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

require_once '../Excel/reader.php';
session_start();
$cp = new cpaint();
$cp->register('inviteGeneral');
$cp->register('inviteStudent');
$cp->register('inviteLecturer');
$cp->register('inviteGroupStudent');
$cp->start();
$cp->return_data();
$pathFiles = "../uploaded/files/";
function inviteGeneral($email){
	global $cp;
	connectdb();
	$responseNode =& $cp->add_node('response');
	if (!is_valid_email_address($sEmail)){
		$responseNode->set_data(iconv("tis-620","utf-8","���������ҹ��͡�Դ�ٻẺ,��سҵ�Ǩ�ͺ�����ա����"));
		return false;
	}
	$tokenStr = md5(rand(0,1000000000000));
	$comSQLInserttoken="INSERT INTO token_invite  SET".
		" USER_ID=".$_SESSION['ss_UserID'].
		",TOKEN_INV='".$tokenStr."'".
		",EMAIL_SEND='".$email."'".
		",TYPE='general'";
	mysql_query($comSQLInserttoken);
	if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$email,$tokenStr,0)){
				$responseNode->set_data(iconv("tis-620","utf-8","�ӡ�������������������ԭ���º��������"));
				return true;
			}else {
				$responseNode->set_data(iconv("tis-620","utf-8","�������ö����������(������һ��·ҧ�����)"));
				return false;
			}
	}else {
			$responseNode ->set_data(mysql_error());
			return false;
	}
}
function inviteStudent($sID,$sGeneration,$sTName,$sFName,$sLName,$sSection,$sEmail,$sDepartment){
	global $cp;
	$responseNode =& $cp->add_node('response');
	if (!is_valid_email_address($sEmail)){
		$responseNode->set_data(iconv("tis-620","utf-8","���������ҹ��͡�Դ�ٻẺ,��سҵ�Ǩ�ͺ�����ա����"));
		return false;
	}
	connectdb();
		$tokenStr = md5(rand(0,1000000000000));
		$comSQLInserttoken="INSERT INTO token_invite  SET".
		" USER_ID=".$_SESSION['ss_UserID'].
		",STUDENT_ID='".$sID."'".
		",TITLE='".$sTName."'".
		",FIRST_NAME='".$sFName."'".
		",LAST_NAME='".$sLName."'".
		",TOKEN_INV='".$tokenStr."'".
		",EMAIL_SEND='".$sEmail."'".
		",TYPE='student'".
		",SECTION='".$sSection."'".
		",DEPARTMENT='".$sDepartment."'".
		",GENERATION=".$sGeneration;
		mysql_query($comSQLInserttoken);
		if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$sEmail,$tokenStr,1)){
				$responseNode->set_data(iconv("tis-620","utf-8","�ӡ�������������������ԭ���º��������"));
				return true;
			}else {
				$responseNode->set_data(iconv("tis-620","utf-8","�������ö����������(������һ��·ҧ�����)"));
				return false;
			}
		}else {
			$cp->set_data(mysql_error());
			$cp->set_data($comSQLInserttoken);
			return false;
		}
}

function inviteLecturer($lLecturerID,$lSEmail){
	global $cp;
	connectdb();
	$responseNode =& $cp->add_node('response');
	if (!is_valid_email_address($lSEmail)){
		$responseNode->set_data(iconv("tis-620","utf-8","���������ҹ��͡�Դ�ٻẺ,��سҵ�Ǩ�ͺ�����ա����"));
		return false;
	}
	$tokenStr = md5(rand(0,1000000000000));
	$comSQLInserttoken="INSERT INTO token_invite  SET".
	" USER_ID=".$_SESSION['ss_UserID'].
	",TOKEN_INV='".$tokenStr."'".
	",EMAIL_SEND='".$lSEmail."'".
	",LECTURER_ID=".$lLecturerID.
	",TYPE='lecturer'";
	mysql_query($comSQLInserttoken);
	if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$lSEmail,$tokenStr,2)){
				$responseNode->set_data(iconv("tis-620","utf-8","�ӡ�������������������ԭ���º��������"));
				return true;
			}else {
				$responseNode->set_data(iconv("tis-620","utf-8","�������ö����������(������һ��·ҧ�����)"));
				return false;
			}
	}else {
		$responseNode->set_data(mysql_error());
		return false;
	}
	
}
function inviteGroupStudent($department,$generation, $section,$filename){
	global $cp;
	global  $pathFiles;
	$pathFiles ="../uploaded/files/".$filename;
	$data = new Spreadsheet_Excel_Reader();
	$data->setOutputEncoding('UTF-8');
	$data->read($pathFiles);
	if (error_reporting(E_ALL ^ E_NOTICE))
	{
		for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {
					if ($data->sheets[0]['cells'][$i][5]!=""and inviteStudent($data->sheets[0]['cells'][$i][1],$generation,$data->sheets[0]['cells'][$i][2],$data->sheets[0]['cells'][$i][3],$data->sheets[0]['cells'][$i][4],$section,$data->sheets[0]['cells'][$i][5],$department)==false){
					echo "Wrong input, ";
					break;
					}
		}
		return true;
	}else{
		return false;
	}
}


function sendEmail($invitorID,$sEmail,$token,$type){

	$to=$sEmail;
	$boundary=md5(uniqid(time()));
		if ($type==1){
		$subject=iconv("tis-620","utf-8","�Թ�յ�͹�Ѻ�ѡ�֡���������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
	}else if($type==2){
		$subject=iconv("tis-620","utf-8","���¹�ԭ�Ҩ����ŧ����¹�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
	}else{
		$subject=iconv("tis-620","utf-8","�Թ�յ�͹�Ѻ�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
	}
	$form="From: admin@network02.ce.kmitl.ac.th\r\n";
	$replyto="Reply-To: admin@network02.ce.kmitl.ac.th\r\n";

	$header=$form.$replyto;
	$header.="MIME-Version: 1.0\r\n";
	$header.="X-Priority: 3\r\n";
	$header.="X-Mailer: PHP/" . phpversion()."\r\n"; 
	$header.= "Content-Type: multipart/alternative;".
						"boundary=\"$boundary\"\r\n\r\n"; 
	$msg="--$boundary\r\n";
	$msg.="Content-Type: text/html; \r\n";
	$msg.=" charset=tis-620\r\n";
	$msg.="Content-Transfer-Encoding: 8bit\r\n\r\n";
	$msg.="��س��� link ���������㹡��ŧ����¹";
	$msg.='<A  href="http://161.246.5.92/ce/user_management/Welcome_newMember.php?uID='.$invitorID.'&tk='.$token.'" target="_blank">Register Member</A>';
	$msg.="\r\n";
	$msg.="--$boundary\r\n";
	$msg.="Content-Type: text/plain;\r\n";
	$msg.=" charset=tis-620\r\n";
	$msg.="Content-Transfer-Encoding: 8bit\r\n\r\n";
	$msg.="��س��� link ���������㹡��ŧ����¹";
	$msg.='http://161.246.5.92/ce/user_management/Welcome_newMember.php?uID='.$invitorID.'&tk='.$token;
	$msg.="\r\n";
	$msg.="--$boundary--\r\n\r\n";
	$subject=encodeHeaderBase64($subject,"utf-8");

	if(mail($to,$subject,$msg,$header)){
		return true;
	}
	else{
		return false;
	}
	return true;
}



function encodeHeaderBase64($string,$charset) {
    /**
     * Check mbstring function requirements.
     */
    if (! function_exists('mb_strlen') ||
        ! function_exists('mb_substr')) {
        // set E_USER_WARNING
        trigger_error('encodeHeaderBase64: Required mbstring functions are missing.',E_USER_WARNING);
        // return false
        return false;
    }

    // initial return array
    $aRet = array();

    /**
     * header length = 75 symbols max (same as in encodeHeader)
     * remove $charset length
     * remove =? ? ?= (5 chars)
     * remove 2 more chars (\r\n ?)
     */
    $iMaxLength = 300 - strlen($charset) - 7;

    // set first character position
    $iStartCharNum = 0;

    // loop through all characters. count characters and not bytes.
    for ($iCharNum=1; $iCharNum<=mb_strlen($string,$charset); $iCharNum++) {
        // encode string from starting character to current character.
        $encoded_string = base64_encode(mb_substr($string,$iStartCharNum,$iCharNum-$iStartCharNum,$charset));

        // Check encoded string length
        if(strlen($encoded_string)>$iMaxLength) {
            // if string exceeds max length, reduce number of encoded characters and add encoded string part to array
            $aRet[] = base64_encode(mb_substr($string,$iStartCharNum,$iCharNum-$iStartCharNum-1,$charset));

            // set new starting character
            $iStartCharNum = $iCharNum-1;

            // encode last char (in case it is last character in string)
            $encoded_string = base64_encode(mb_substr($string,$iStartCharNum,$iCharNum-$iStartCharNum,$charset));
        } // if string is shorter than max length - add next character
    }

    // add last encoded string to array
    $aRet[] = $encoded_string;

    // set initial return string
    $sRet = '';

    // loop through encoded strings
    foreach($aRet as $string) {
        // TODO: Do we want to control EOL (end-of-line) marker
        if ($sRet!='') $sRet.= " ";

        // add header tags and encoded string to return string
        $sRet.= '=?'.$charset.'?B?'.$string.'?=';
    }

    return $sRet;
}


 function is_valid_email_address($email){
        $no_ws_ctl    = "[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]";
        $alpha        = "[\\x41-\\x5a\\x61-\\x7a]";
        $digit        = "[\\x30-\\x39]";
        $cr        = "\\x0d";
        $lf        = "\\x0a";
        $crlf        = "($cr$lf)";

        $obs_char    = "[\\x00-\\x09\\x0b\\x0c\\x0e-\\x7f]";
        $obs_text    = "($lf*$cr*($obs_char$lf*$cr*)*)";
        $text        = "([\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f]|$obs_text)";
        $obs_qp        = "(\\x5c[\\x00-\\x7f])";
        $quoted_pair    = "(\\x5c$text|$obs_qp)";

        $wsp        = "[\\x20\\x09]";
        $obs_fws    = "($wsp+($crlf$wsp+)*)";
        $fws        = "((($wsp*$crlf)?$wsp+)|$obs_fws)";
        $ctext        = "($no_ws_ctl|[\\x21-\\x27\\x2A-\\x5b\\x5d-\\x7e])";
        $ccontent    = "($ctext|$quoted_pair)";
        $comment    = "(\\x28($fws?$ccontent)*$fws?\\x29)";
        $cfws        = "(($fws?$comment)*($fws?$comment|$fws))";
        $cfws        = "$fws*";

        $atext        = "($alpha|$digit|[\\x21\\x23-\\x27\\x2a\\x2b\\x2d\\x2e\\x3d\\x3f\\x5e\\x5f\\x60\\x7b-\\x7e])";
        $atom        = "($cfws?$atext+$cfws?)";

        $qtext        = "($no_ws_ctl|[\\x21\\x23-\\x5b\\x5d-\\x7e])";
        $qcontent    = "($qtext|$quoted_pair)";
        $quoted_string    = "($cfws?\\x22($fws?$qcontent)*$fws?\\x22$cfws?)";
        $word        = "($atom|$quoted_string)";


        $obs_local_part    = "($word(\\x2e$word)*)";
        $obs_domain    = "($atom(\\x2e$atom)*)";

        $dot_atom_text    = "($atext+(\\x2e$atext+)*)";
        $dot_atom    = "($cfws?$dot_atom_text$cfws?)";

        $dtext        = "($no_ws_ctl|[\\x21-\\x5a\\x5e-\\x7e])";
        $dcontent    = "($dtext|$quoted_pair)";
        $domain_literal    = "($cfws?\\x5b($fws?$dcontent)*$fws?\\x5d$cfws?)";

		$local_part    = "($dot_atom|$quoted_string|$obs_local_part)";
        $domain        = "($dot_atom|$domain_literal|$obs_domain)";
        $addr_spec    = "($local_part\\x40$domain)";

        $done = 0;
        while(!$done){
            $new = preg_replace("!$comment!", '', $email);
            if (strlen($new) == strlen($email)){
                $done = 1;
            }
            $email = $new;
        }
        return preg_match("!^$addr_spec$!", $email) ? 1 : 0;
    }


?>