<?php
function getUnderLab($userID){
		$underLab="";
		$comSQLgetUnderLab="SELECT * FROM laboratory_member T1,laboratory T2  WHERE T1.LAB_ID=T2.LAB_ID AND T1.USER_ID=".$userID;
		$getUnderLabresult=mysql_query($comSQLgetUnderLab);
		while($labrow=mysql_fetch_array($getUnderLabresult)){
			$underLab.=$labrow["ALIAS"]."(".$labrow["LEVEL"]."), ";
		}
		if (strlen($underLab)!=0) $underLab=substr($underLab, 0, strlen($underLab)-2);
		echo mysql_error();
		return $underLab;
}
?>