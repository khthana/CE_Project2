<?php
function checkAuthen($Username, $Password){
	$comSQLcheckSalt="SELECT SALT FROM useraccount WHERE USER_NAME='".$Username."'";
	$saltresult=mysql_query($comSQLcheckSalt);
	$saltrow=mysql_fetch_array($saltresult);
	$Password=crypt($Password,$saltrow[0]);
	$comSQLcheckAuthen="SELECT * FROM useraccount WHERE USER_NAME='".$Username."'AND PASSWORD='".$Password."'";
	#$comSQLchecklogin="SELECT User_Name FROM useraccount WHERE User_Name='Poji'";
	$Authenresult=mysql_query($comSQLcheckAuthen);
	return $Authenresult;
}
?>