<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">


<title>Welcome to  member registeration  </title>
<?php
		include("../_Sessionstart.php");
		include("php/_Checktoken.php");
?>
<style type="text/css">
<!--

#Layer10 {
	width:990px;		
}

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;
}


.style22 {color: #666666}
#Layer1 .embedded .heading {
	font-size: 14px;
	color: #FF0000;
}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
	font-weight: bold;
}
.style30 {color: #FF0000; font-size: 12px; }
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" >
<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		cp.set_debug(true);
//-->
</script>
<script type="text/javascript" src="code script/matchAcc.js"></script>
<script type="text/javascript" src="code script/createAcc.js"></script>

</head>

<body>
<div id="Layer1" align="center">
    <table width="827" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
        
        <td width="476"><img src="../images/logo.gif" width="800" height="175" /></td>
      
	    <td width="123" class=embedded>
        </td>
      </tr>
  </table>
</div><div id="Layer" align="center">
<?php
	
	if (checkToken($_GET['uID'],$_GET['tk'])){
			$_SESSION['ss_uID']=$_GET['uID'];
			$_SESSION['ss_token']=$_GET['tk'];
		
?>
<table width="706" height="134" border="0">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" class="embedded"><h1 align="center" class="style16 style22"> Welcome New Member </h1>      </td>
    </tr>
		   <tr>
		   	<td id="showform" align="center"><table width="80%" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
  <tr>
    <th colspan="3" background="../images/bg_subjectdetail.gif"><span class="style23">ลงทะเบียนผู้ใช้งาน</span></th>
    </tr>
  <tr>
    <th ><span class="style30">ผู้ใช้ใหม่</span></th>
    <th colspan="2"><span class="style30">ผู้ใช้ที่เป็นสมาชิกอยู่แล้ว(เพื่อกรณีอัพเดตข้อมูลส่วนบุคคล)</span></th>
  </tr>
  
  <tr>
    <td width="165" rowspan="3" align="center"><input name="create New account"  type="button" id="create New account" value="ลงทะเบียนผู้ใช้ใหม่" onclick="return getformCreateAcc()" /></td>
    <td align="right">
	ชื่อที่ใช้ในระบบ:	</td>
    <td width="135" align="left"><input name="username" type="text" id="musername" size="20"   /></td>
  </tr>
  <tr>
    <td align="right"> รหัสผ่าน:      </td>
    <td align="left"><input name="passwrd" type="password" id="mpassword" size="22" /></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input name="Accountname" type="button" id="Account" onclick="matchAccount()" value="ยืนยัน"  /></td>
  </tr>
  

  
</table></td>
		   </tr>
  </table><div id="showreponse"></div>
  <?php
			}else {
	?>
		</div>
		<script type="text/javascript">
		document.getElementById('Layer').innerHTML = '<B>&#3586;&#3629;&#3629;&#3616;&#3633;&#3618;&#3652;&#3617;&#3656;&#3648;&#3592;&#3629;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3585;&#3634;&#3619;&#3648;&#3594;&#3636;&#3597;&#3594;&#3623;&#3609;&#3586;&#3629;&#3591;&#3607;&#3656;&#3634;&#3609;</B><BR/><BR/><A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A>';
		</script>
<?php
			}
	?>
		   <div id="showreponse" ></div>
</body>
</html>