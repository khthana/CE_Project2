<!--
function sendInviteGeneral(){
	var email=document.getElementById("emailInvite").value;
	if (email==""){
		alert("Please, check your input.it's lack of some field");
		return false;
	}
	cp.call('php/invite.php','inviteGeneral',responseInviteGeneral,email);
	document.getElementById('responeinvite').innerHTML ='data transfer<br/><img src="pic/ajax-loader.gif" alt="now loading" />';
	return true;
}
function responseInviteGeneral(result) {
				document.getElementById('responeinvite').innerHTML =  result.getElementsByTagName( "response")[0].firstChild.nodeValue;
}
//-->