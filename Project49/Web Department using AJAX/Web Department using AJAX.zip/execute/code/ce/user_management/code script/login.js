
	<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		//cp.set_debug(true);
	
		function userlogin() {
			//document.getElementById('responselogin').innerHTML="aaaa";
			
			cp.call('php/login.php','login',response ,document.getElementById('Username').value, document.getElementById('Password').value,document.getElementById('vfcode').value);
			return false;
		}

		function response(result) {
			if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
				document.getElementById('responselogin').innerHTML = "Welcome to CE Website";
				var pagebefore=result.getElementsByTagName('pagebefore')[0].firstChild.nodeValue;
				window.close();
			}else{
				var selectImg ="php/VF_code.php?id="+result.getElementsByTagName('codeId')[0].firstChild.nodeValue;
				document.getElementById('VF_code').setAttribute("src",selectImg);
				document.getElementById('responselogin').innerHTML ="&#3588;&#3640;&#3603;&#3651;&#3626;&#3656;&#3594;&#3639;&#3656;&#3629;,&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;&#3627;&#3619;&#3639;&#3629;&#3619;&#3627;&#3633;&#3626;&#3605;&#3619;&#3623;&#3592;&#3626;&#3629;&#3610;&#3612;&#3636;&#3604;";
			}
		}
	//-->
