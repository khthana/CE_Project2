<!--
if (((document.location.search).split("?")[1])!=null){
	if (((document.location.search).split("?")[1]).split("=")[1]!=null){
		var uID = ((document.location.search).split("?")[1]).split("=")[1];
	}

}
	
var pagegl;
var searchKey;
var totalpagegl
function clearTable(){
	var numTableRow=document.getElementById('showList').rows.length;
	for (var j=1; j < numTableRow ;j++ ){

		document.getElementById("showList").deleteRow(1);
	}
}
var informationMember="";
var searchflag=false;
function searchMemberFn(page){
	pagegl=page;
	searchflag=true;
	if(document.getElementById('searchMembervalue').value==""){
		alert("ใส่ชื่อที่ต้องการค้นหา");
		return false;
	}
	
	cp.call('php/listmember.php','searchMember',responsegetListmember,page,document.getElementById('searchMembervalue').value);
	
}

function gotoPage(searchKey){		
	if (document.getElementById('pagelist').options.length !=0){
		for (i=0;i<document.getElementById('pagelist').options.length ; i++)	{
			if (document.getElementById('pagelist').options[i].selected){
					var page =document.getElementById('pagelist').options[i].value;
					break;
			}
		}
		
		if (searchflag){
				cp.call('php/listmember.php','searchMember',responsegetListmember,page,searchKey);
		}else {	
				cp.call('php/listmember.php','getListmember',responsegetListmember,page);
		}
		
		pagegl=parseInt(page);
	}
}
function getListmember(page){
	pagegl=page;
	searchflag=false;
	cp.call('php/listmember.php','getListmember',responsegetListmember,page);
	clearTable();
}

function responsegetListmember(result){
	clearTable();
	var a=Array(8);	
	if (document.getElementById('showList').rows[0].cells.length==4)
	{
		//var col = Array('userName','jointDate','lv','invitedBy','underLab','subLv','userID');
		var col = Array('userName','jointDate','lv','invitedBy','userID');
	}else {
		//var col = Array('userName','jointDate','lv','invitedBy','underLab','subLv','activeStatus','userID');
		var col = Array('userName','jointDate','lv','invitedBy','activeStatus','userID');
	}

	for (var j=(result.getElementsByTagName('member').length-1);j>=0;j-- )
	{
		var newRow = document.getElementById("showList").insertRow(1);
		
		newRow.onmouseover = new Function("","this.style.backgroundColor='#f1e0d7'");

		if (navigator.appName.indexOf("Microsoft")!=-1)
			newRow.style.cursor = "hand";
		else
			newRow.setAttribute("style","cursor:pointer;cursor:hand;");
		
		newRow.onmouseout = new Function("","this.style.backgroundColor='white'");

		var LastColumn=(col.length-1);
		string = "showdetailMember('" + result.getElementsByTagName( col [LastColumn])[j].firstChild.nodeValue + "')";
		
		newRow.onclick = new Function("",string);
		
		for (var i=0;i<LastColumn ;i++ )
		{
			
			 a[i]=newRow.insertCell(i);
			 a[i].innerHTML=result.getElementsByTagName( col [i])[j].firstChild.nodeValue;	
			
			 if (i ==0) {
				 a[i].className="tdA";
				
			 }else{
				 a[i].className="tdB";
				
			 }
			 
		}
	}
///////////////////////////////////////*********************************************************////////////////////////////////////////////
	//var newRow = document.getElementById("showList").insertRow(document.getElementById("showList").rows.length);
	var pageCell=document.getElementById("page");
	//pageCell.innerHTML='<img src=\'./pic/button/previous_page_0.gif\' border="0" onMouseOver="this.src=\'./pic/button/previous_page_1.gif\'" onMouseOut="this.src=\'./pic/button/previous_page_0.gif\'" onclick="prevPage()"/><img src=\'./pic/button/next_page_0.gif\' border="0" onMouseOver="this.src=\'./pic/button/next_page_1.gif\'" onMouseOut="this.src=\'./pic/button/next_page_0.gif\'" onclick="nextPage()"/>';
	//pageCell.colSpan="2";
	//pageCell=newRow.insertCell(1);
	//pageCell.align="right";
	
	if (result.getElementsByTagName('member').length!=0)
		totalpagegl=result.getElementsByTagName( "totalpage")[0].firstChild.nodeValue;
	pageCell.innerHTML ="หน้า "+ pagegl +" จาก "+ totalpagegl ;
	pageCell.innerHTML +="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:void prevPage()\"><< หน้าที่แล้ว</a>&nbsp;&nbsp;<a href = \"javascript:nextPage()\">หน้าต่อไป >></a>";
/*	var pageCell=newRow.insertCell(2);
	pageCell.align="right";
	createPagelist(pageCell,pagegl,totalpagegl);
	if (searchflag){
		if (result.getElementsByTagName('member').length!=0)searchKey=result.getElementsByTagName( "searchKey")[0].firstChild.nodeValue;
		var gotobutton=' <input type="submit" name="nGoPage " value="&#3652;&#3611;&#3618;&#3633;&#3591;&#3627;&#3609;&#3657;&#3634;" ';
		gotobutton +="onclick='return gotoPage(\""+searchKey+ "\")'/>";
	}else {	
		var gotobutton=' <input type="submit" name="nGoPage " value="&#3652;&#3611;&#3618;&#3633;&#3591;&#3627;&#3609;&#3657;&#3634; " onclick="return gotoPage(\'\')"/>';
	}
*/
	
	//pageCell.innerHTML+=gotobutton;
	//window.scrollTo(0,1024);
}

function showdetailMember(userID){
	cp.call('php/listmember.php','getInfomember',responsegetInfomember,userID);
}
function responsegetInfomember(result){
		
		if (result.getElementsByTagName("userName").length!=0)
		{
			informationMember=result;
			document.getElementById('showName').innerHTML="<font color='red'>" + informationMember.getElementsByTagName("userName")[0].firstChild.nodeValue + "</font>";  
			showGenInfo();
		}
		
}
function showGenInfo(){
	if (informationMember ){	
		document.getElementById("showDetail").innerHTML="";
		var getEle = document.getElementById("showDetail");
		var createNodetable =document.createElement("table");
		getEle.appendChild(createNodetable);
		createNodetable.setAttribute("id","detailTable");
		var a=Array(2);	
		var col = Array('Email','jointDate','lv','invitedBy','underLab','tTopic','tOpinion','point');	
		var colName =Array('อีเมล์ที่ใช้ในการติดต่อ ','วันที่ลงทะเบียน ','ระดับสิทธิ์ ','การเชื้อเชิญโดย ','สังกัดห้องวิจัย ','จำนวนกระทู้ที่ตั้ง '
		,'จำนวนความคิดเห็น ','คะแนนความน่าเชื่อถือ');
		
		
		if (document.getElementById('showList').rows[0].cells.length==5)//admin only
		{
			 col.push("tBadpost") ;
			 colName.push("จำนวนกระทู้ที่ถูกลบ ") ;
			 col.push("activeStatus") ;
			 colName.push("สถานะของผู้ใช้ ") ;
			//link viewLog
			var newRow = document.getElementById('detailTable').insertRow(0);
			var linkcell=newRow.insertCell(0);
			linkcell.align="center";
			linkcell.innerHTML="<a href='javascript:void window.open(\"log_fileview.php?uID="+informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue+"\",\"_blank\",\"\");'>เวลาเข้าใช้งานระบบ </a>";
			linkcell.colSpan="2";
		
		
		}

		var AdminUnderLabNode=informationMember.getElementsByTagName('underLabID');
		var numAdminUnderLab=informationMember.getElementsByTagName('underLabID').length;
		
		if (numAdminUnderLab!=0){ //for Lab admin 
			var arrayName= Array(numAdminUnderLab);
			var arrayValue= Array(numAdminUnderLab);
			for (i=0;i<numAdminUnderLab ; i++){
				arrayName[i]=AdminUnderLabNode[i].getAttribute('alias');
				arrayValue[i]=AdminUnderLabNode[i].firstChild.nodeValue;
			}
			var newRow = document.getElementById('detailTable').insertRow(0) ;
			var addMemberRoomcell=newRow.insertCell(0);
			addMemberRoomcell.align="right";
			addMemberRoomcell.innerHTML="เพิ่ม     <font color='red'>" + informationMember.getElementsByTagName("userName")[0].firstChild.nodeValue + "</font>     เป็นสมาชิกห้องวิจัย:";
			addMemberRoomcell=newRow.insertCell(1);
			createlistboxGeneral(addMemberRoomcell,arrayName,arrayValue);
			addMemberRoomcell.innerHTML+="&nbsp;&nbsp;<input type=\"submit\" name=\"nAddMem \" value=\"เพิ่ม \" onclick=\"return addMember()\"/>";
			addMemberRoomcell.align="left";
		}


		var LastColumn=col.length;
		var newRow = document.getElementById('detailTable').insertRow(0);
		var hrcell = document.getElementById('detailTable').insertRow(0).insertCell(0);
		hrcell.align="center";
		hrcell.style.width="300";
		hrcell.innerHTML="<hr/>";
		hrcell.colSpan="2";

		a[0]=newRow.insertCell(0);
		a[0].innerHTML = "ต้องการติดต่อกับ"+"      <font color='red'>" +  informationMember.getElementsByTagName("userName")[0].firstChild.nodeValue +"</font>:";  
		//a[0].innerHTML="<a href='javascript:addContact("+informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue+")'>add contact</a>";
		a[0].align="right";
		a[1]=newRow.insertCell(1);
		a[1].innerHTML="<a href='javascript:addContact("+informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue+")'>ต้องการ&nbsp;&nbsp;</a><a href='javascript:addBlock("+informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue+")'>ไม่ต้องการ</a>";	
		//a[1].innerHTML="<input name='contact' id='contact' type='radio' value='0'  onclick=\"addBlock(" + informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue + ")\"/>ต้องการ&nbsp;&nbsp;<input name='contact' id='contact' type='radio' value='1' onclick=\"addContact(" + informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue + ")\" />ไม่ต้องการ";
		a[1].align="left";


		for (var i=(LastColumn-1);i >= 0 ;i-- ){
			if(col[i] == 'underLab'){
				newRow = document.getElementById('detailTable').insertRow(0);
					a[0]=newRow.insertCell(0);
					a[0].innerHTML=colName[i]+" : ";
					a[0].align="right";
					a[1]=newRow.insertCell(1);
					temp = informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue;
					temp_ = temp.split(",");
					string ="";
					for(k=0;k < temp_.length;k++){
						string += temp_[k] + "<br/>";
					}
					
					a[1].innerHTML=	string;
					a[1].align="left";
					a[0].style.verticalAlign = "top";
			}
			else{
			
				newRow = document.getElementById('detailTable').insertRow(0);
					a[0]=newRow.insertCell(0);
					a[0].innerHTML=colName[i]+" : ";
					a[0].align="right";
					a[1]=newRow.insertCell(1);
					a[1].innerHTML=informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue;	
					a[1].align="left";
				
			}
		}

	}
	//alert("<a href='javascript:void window.open(\"https://161.246.5.92/ce/user_management/showlogin.php\",\"_blank\",\"left=200,top=314,width=480,height=150,resizable=no\");'>");
}

function showPersonalInfo(){
	if (informationMember ){	
		document.getElementById("showDetail").innerHTML="";
		var getEle = document.getElementById("showDetail");
		var createNodetable =document.createElement("table");
		getEle.appendChild(createNodetable);
		createNodetable.setAttribute("id","detailTable");
		var a=Array(2);	
		var col = Array('tName','fName','lName','nName','homeAddr','mobilePhone','homePhone');	
		var colName =Array('&#3588;&#3635;&#3609;&#3635;&#3627;&#3609;&#3657;&#3634;'
		,'&#3594;&#3639;&#3656;&#3629;'
		,'&#3609;&#3634;&#3617;&#3626;&#3585;&#3640;&#3621;'
		,'&#3594;&#3639;&#3656;&#3629;&#3648;&#3621;&#3656;&#3609;'
		,'&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;'
		,'&#3648;&#3610;&#3629;&#3619;&#3660;&#3650;&#3607;&#3619;&#3624;&#3661;&#3614;&#3607;&#3660;&#3617;&#3639;&#3629;&#3606;&#3639;&#3629;'
		,'&#3648;&#3610;&#3629;&#3619;&#3660;&#3650;&#3607;&#3619;&#3624;&#3633;&#3614;&#3607;&#3660;&#3610;&#3657;&#3634;&#3609;'
		);
		var LastColumn=col.length;
		for (var i=(LastColumn-1);i >= 0 ;i-- ){
			//alert("a");
				var newRow = document.getElementById('detailTable').insertRow(0);
					a[0]=newRow.insertCell(0);
					a[0].innerHTML=colName[i]+" : ";
					a[0].align="right";
					a[1]=newRow.insertCell(1);
					a[1].innerHTML=informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue;	
					a[1].align="left";
		}
	}
}

function showStudentInfo(){
	if (informationMember ){	
		document.getElementById("showDetail").innerHTML="";
		var getEle = document.getElementById("showDetail");
		var createNodetable =document.createElement("table");
		getEle.appendChild(createNodetable);
		createNodetable.setAttribute("id","detailTable");
		var a=Array(2);	
		var col = Array('sID','department','generation','section');	
		var colName =Array('&#3619;&#3627;&#3633;&#3626;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;'
		,'&#3616;&#3634;&#3588;&#3623;&#3636;&#3594;&#3634;'
		,'&#3619;&#3640;&#3656;&#3609;'
		,'&#3627;&#3657;&#3629;&#3591;');
		var LastColumn=col.length;
		for (var i=(LastColumn-1);i >= 0 ;i-- ){
			//alert("a");
				var newRow = document.getElementById('detailTable').insertRow(0);
					a[0]=newRow.insertCell(0);
					a[0].innerHTML=colName[i]+" : ";
					a[0].align="right";
					a[1]=newRow.insertCell(1);
					a[1].innerHTML=informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue;	
					a[1].align="left";
		}
	}
}
function editInfo(){
	if (informationMember ){	
		
		document.getElementById("showDetail").innerHTML="";
		var getEle = document.getElementById("showDetail");
		var createNodetable =document.createElement("table");
		getEle.appendChild(createNodetable);
		createNodetable.setAttribute("id","editTable");
		var a=Array(2);	
		var col = Array('lv','activeStatus');	
		var colName =Array('&#3619;&#3632;&#3604;&#3633;&#3610;&#3626;&#3636;&#3607;&#3608;&#3636;&#3660;'
		,'&#3626;&#3606;&#3634;&#3609;&#3632;&#3586;&#3629;&#3591;&#3612;&#3641;&#3657;&#3651;&#3594;&#3657;');
		var LastColumn=col.length;
		var newRow = document.getElementById('editTable').insertRow(0);
		a[0]=newRow.insertCell(0);
		a[0].align="center";
		a[0].innerHTML=' <input type="submit" name="nSearch " value="ยืนยัน " onclick="return adminEditInfo()"/>';
		a[0].colSpan="2";
		for (var i=(LastColumn-1);i >= 0 ;i-- ){
				newRow = document.getElementById('editTable').insertRow(0);
				a[0]=newRow.insertCell(0);
				a[0].innerHTML=colName[i]+" : ";
				a[0].align="right";
				a[1]=newRow.insertCell(1);
				a[1].align="left";
				if (i==0)
					{
						addNodeLevel(a[1],informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue);
					}else if (i==1){
						addNodeStatus(a[1],informationMember.getElementsByTagName( col [i])[0].firstChild.nodeValue);
					}
		}

	}
}

function adminEditInfo(){
		var newlv;
		var newstatus;
		for (i=0;i<document.getElementById('editLevel').options.length ; i++)	{
			if (document.getElementById('editLevel').options[i].selected){
					newlv=document.getElementById('editLevel').options[i].value;
			}
		}
		for (i=0;i<document.getElementById('editStaus').options.length ; i++)	{
			if (document.getElementById('editStaus').options[i].selected){
					newstatus=document.getElementById('editStaus').options[i].value;
			}
		}
		//alert(newlv);
		//alert(newstatus);
		cp.call('php/adminEditInfo.php','adminEditInfo',responseadminEditInfo,informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue,newlv,newstatus);
		return false;
}
function responseadminEditInfo(result){
		informationMember.getElementsByTagName('lv')[0].firstChild.nodeValue=result.getElementsByTagName('lv')[0].firstChild.nodeValue;
		informationMember.getElementsByTagName('activeStatus')[0].firstChild.nodeValue=result.getElementsByTagName('activeStatus')[0].firstChild.nodeValue;
		showGenInfo();
		clearTable();
		getListmember(1);
}
function addMember(){
	var lab;
	for (i=0;i<document.getElementById('addMemLab').options.length ; i++)	{
			if (document.getElementById('addMemLab').options[i].selected){
					lab=document.getElementById('addMemLab').options[i].value;
					break;
			}
	}
	cp.call('../laboratory/php/addMemberRoom.php','addMember',responseaddMember,informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue,lab);
}

function responseaddMember(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue=="sucess"){
		alert(result.getElementsByTagName('responseMsg')[0].firstChild.nodeValue);
		showdetailMember(informationMember.getElementsByTagName('userID')[0].firstChild.nodeValue);
	}else if (result.getElementsByTagName('response')[0].firstChild.nodeValue=="duplicate"){
		alert(result.getElementsByTagName('responseMsg')[0].firstChild.nodeValue);
	}else if (result.getElementsByTagName('response')[0].firstChild.nodeValue=="Not Authorize"){
		alert('ok');
		alert(result.getElementsByTagName('respondeMsg')[0].firstChild.nodeValue);
		
	}
}

function addNodeLevel(parentNode,levelUser){
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","editLevel");
		//alert(informationMember.getElementsByTagName( "lecID")[0].firstChild.nodeValue);
		if (informationMember.getElementsByTagName( "lecID")[0].firstChild.nodeValue=="-")
		{
				var level = Array('admin', 'senior', 'user');	
		}else{
			var level = Array('admin', 'lecturer');	
		}
		for (var i=0;i < level.length ;i++ ){
				var op=document.createElement('option');
				op.text=level[i];
				op.value=level[i];
				try {
					 createNodeselect.add(op,null);// standards compliant
				}
				 catch(ex){
					 createNodeselect.add(op); // IE only
			   }	
				if (levelUser==level[i]){
					createNodeselect.options[i].selected=true;
				}
		}
}
function addNodeStatus(parentNode,statusAcc){
		
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","editStaus");	
		
		var op1=document.createElement('option');
		op1.text='Active';
		op1.value=1;
		var op2=document.createElement('option');
		op2.text='Inactive';
		op2.value=0;
		try {
			 document.getElementById('editStaus').add(op1,null);// standards compliant
			 document.getElementById('editStaus').add(op2,null);
		}
		 catch(ex){
			document.getElementById('editStaus').add(op1); // IE only
			document.getElementById('editStaus').add(op2);
	   }		
		if (statusAcc=="Active"){
			document.getElementById('editStaus').options[0].selected=true;
		}else {
			document.getElementById('editStaus').options[1].selected=true;
		}
}
function createlistboxGeneral(parentNode,arrayName,arrayValue){
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","addMemLab");
		for (var i=0;i < arrayName.length ;i++ ){
				var op=document.createElement('option');
				op.text=arrayName[i];
				op.value=arrayValue[i];
				try {
					 createNodeselect.add(op,null);// standards compliant
				}
				 catch(ex){
					 createNodeselect.add(op); // IE only
			   }
			
		}
}
function createPagelist(parentNode,page,totalpage){
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","pagelist");
		for (var i=1;i <= totalpage ;i++ ){
			if (i!=page){
				var op=document.createElement('option');
				op.text="page "+i;
				op.value=i;
				try {
					 createNodeselect.add(op,null);// standards compliant
				}
				 catch(ex){
					 createNodeselect.add(op); // IE only
			   }
			}
		}
}
function prevPage(){
	if ((pagegl-1)>0){
		var page=pagegl-1;
		if (searchflag){
			cp.call('php/listmember.php','searchMember',responsegetListmember,page,document.getElementById("searchMembervalue").value);
		}else {	
			cp.call('php/listmember.php','getListmember',responsegetListmember,page);
		}
		pagegl=page;
	}
}
function	 nextPage(){
	if ( (pagegl+1)<=totalpagegl ){
		var page=pagegl+1;
		if (searchflag){
			
			cp.call('php/listmember.php','searchMember',responsegetListmember,page,document.getElementById("searchMembervalue").value);
		}else {	
			cp.call('php/listmember.php','getListmember',responsegetListmember,page);
		}
		pagegl=page;
	}
}


function viewmember(){
	if (uID!=null){
		showdetailMember(uID);
		
	}
}

//-->