		function matchAccount() {
			//alert("aaaa");
			cp.call('php/createMatchAcc.php','matchAcc',responseMatchAcc ,document.getElementById('musername').value, document.getElementById('mpassword').value);
			return false;
		}

		function responseMatchAcc(result) {
			if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
				document.getElementById('showreponse').innerHTML = "Welcome to CE Website";
				var editProfilepage=result.getElementsByTagName('editProfilepage')[0].firstChild.nodeValue;
				window.navigate(editProfilepage);
			}else if (result.getElementsByTagName('permition')[0].firstChild.nodeValue=="rejectAuthen"){
				document.getElementById('showreponse').innerHTML ="&#3586;&#3629;&#3629;&#3616;&#3633;&#3618; &#3652;&#3617;&#3656;&#3617;&#3637;username&#3609;&#3637;&#3657;&#3651;&#3609;&#3619;&#3632;&#3610;&#3610;&#3627;&#3619;&#3639;&#3629;&#3607;&#3656;&#3634;&#3609;&#3585;&#3619;&#3629;&#3585;password&#3652;&#3617;&#3656;&#3606;&#3641;&#3585;&#3605;&#3657;&#3629;&#3591;";
			}else if (result.getElementsByTagName('permition')[0].firstChild.nodeValue=="updateComplete"){
				alert("ข้อมูลได้ทำการอัพเดตเรียบร้อยแล้ว");
				window.navigate(result.getElementsByTagName('editProfilepage')[0].firstChild.nodeValue);
			}
		}
