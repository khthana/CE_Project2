startList = function() {
	if (document.all&&document.getElementById) {
		dropNode = document.getElementById("dropm");
		for (i=0; i<dropNode.childNodes.length; i++) {
			node = dropNode.childNodes[i];
			if (node.nodeName=="LI") {
				node.onmouseover=function() {
					this.className+=" over";
				}
				node.onmouseout=function() {
					this.className=this.className.replace(" over", "");
				}
			   }
		  }
	 }
}
window.onload=startList;
