<!--
var defaultparameter;
statusTitleInput=true;
function changeStatusTitleInput(){
	if (statusTitleInput){
		statusTitleInput=false;
		document.getElementById('tname').disabled=true;
		document.getElementById('otname').disabled=false;
	}else{
		statusTitleInput=true;
		document.getElementById('tname').disabled=false;
		document.getElementById('otname').disabled=true;
	}	
}
function getProfile(){
	cp.call('php/profile.php','getProfile',responsegetProfile);
}
function responsegetProfile(result){
	defaultparameter=result;
	document.getElementById('userName').innerHTML =defaultparameter.getElementsByTagName('userName')[0].firstChild.nodeValue;
	document.getElementById('fName').value =defaultparameter.getElementsByTagName('fName')[0].firstChild.nodeValue;

	document.getElementById('lName').value =defaultparameter.getElementsByTagName('lName')[0].firstChild.nodeValue;
	document.getElementById('nName').value =defaultparameter.getElementsByTagName('nName')[0].firstChild.nodeValue;
	document.getElementById('homeAddr').innerHTML =defaultparameter.getElementsByTagName('homeAddr')[0].firstChild.nodeValue;
	document.getElementById('Email').value =defaultparameter.getElementsByTagName('Email')[0].firstChild.nodeValue;
	if (defaultparameter.getElementsByTagName('flagShowEmail')[0].firstChild.nodeValue==1){
		document.getElementById('showEmail').checked = true;
		document.getElementById('hideEmail').checked =false;
	}else{
		document.getElementById('showEmail').checked =false;
		document.getElementById('hideEmail').checked =true;
	}
	document.getElementById('mobilePhone').value =defaultparameter.getElementsByTagName('mobilePhone')[0].firstChild.nodeValue;
	document.getElementById('homePhone').value =defaultparameter.getElementsByTagName('homePhone')[0].firstChild.nodeValue;
	document.getElementById('invitedBy').innerHTML=defaultparameter.getElementsByTagName('invitedBy')[0].firstChild.nodeValue;
	document.getElementById('lv').innerHTML =defaultparameter.getElementsByTagName('lv')[0].firstChild.nodeValue;
	document.getElementById('underLab').innerHTML =defaultparameter.getElementsByTagName('underLab')[0].firstChild.nodeValue;
	document.getElementById('department').innerHTML =defaultparameter.getElementsByTagName('department')[0].firstChild.nodeValue;
	document.getElementById('sID').innerHTML =defaultparameter.getElementsByTagName('sID')[0].firstChild.nodeValue;
	document.getElementById('generation').innerHTML =defaultparameter.getElementsByTagName('generation')[0].firstChild.nodeValue;
	document.getElementById('section').innerHTML =defaultparameter.getElementsByTagName('section')[0].firstChild.nodeValue;
	document.getElementById('point').innerHTML =defaultparameter.getElementsByTagName('point')[0].firstChild.nodeValue;
	document.getElementById('tBadpost').innerHTML =defaultparameter.getElementsByTagName('tBadpost')[0].firstChild.nodeValue;
	document.getElementById('tTopic').innerHTML =defaultparameter.getElementsByTagName('tTopic')[0].firstChild.nodeValue;
	document.getElementById('tOpinion').innerHTML =defaultparameter.getElementsByTagName('tOpinion')[0].firstChild.nodeValue;
	document.getElementById('jointDate').innerHTML =defaultparameter.getElementsByTagName('jointDate')[0].firstChild.nodeValue;
	document.getElementById('newPass').value ="";
	document.getElementById('retypeNewPass').value ="";
	document.getElementById('pass').value ="";
	document.getElementById('tName').value =defaultparameter.getElementsByTagName('tName')[0].firstChild.nodeValue;

};

function editProfile(){

		if (document.getElementById('showEmail').checked ){
			var showEmail =1;
		}else{
			var showEmail =0;
		}
		if (document.getElementById('newPass').value.length!=0){
				if (document.getElementById('newPass').value.length<6){
						alert("กรุณาตั้งรหัสผ่านเกิน6ตัวอักษร");
						return false;
				}
		}else {
			document.getElementById('newPass').value.length=document.getElementById('pass').value;
		}
		if (document.getElementById('newPass').value==document.getElementById('retypeNewPass').value){
				cp.call('php/profile.php','editProfile',responseeditProfile,document.getElementById('userName').innerHTML,document.getElementById('pass').value,document.getElementById('tName').value,document.getElementById('fName').value,document.getElementById('lName').value,document.getElementById('nName').value,document.getElementById('homeAddr').innerHTML,document.getElementById('Email').value,showEmail,document.getElementById('mobilePhone').value,document.getElementById('homePhone').value,document.getElementById('newPass').value);
			}else {
				alert("ท่านกรอกรหัสผ่านใหม่และยันยืนรหัสผ่านไม่ตรงกัน");
			}
}
function responseeditProfile(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue=="permit"){
		getProfile();
		alert("ข้อมูลได้รับการแก้ไขเรียบร้อยแล้ว");
	}else{
		alert(result.getElementsByTagName('response')[0].firstChild.nodeValue+":รหัสผ่านเพื่อเปลี่ยนข้อมูลไม่ถูกต้อง กรุณากรอกรหัสผ่านอีกครั้ง");
	}
}
//-->