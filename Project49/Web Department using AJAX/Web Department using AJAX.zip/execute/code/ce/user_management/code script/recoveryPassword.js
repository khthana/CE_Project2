function recoveryForm(){
	if (document.getElementById("Username").value==""){
		alert("กรุณากรอกชื่อผู้ใช้งาน");
		return false;
	}
	cp.call('php/recoveryPassword.php','recoveryForm',responserecoveryForm ,document.getElementById('Username').value);
}
function responserecoveryForm(result){
	if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
	document.getElementById("showLogin").innerHTML = '<TABLE width=480 border=0 cellPadding=0 cellSpacing=0 background="pic/horline_c600.jpg"><TBODY><TR><TD colSpan=2 height=1></TD></TR>        <TR bgColor=#f5f5f5><TD background=pic/horline_c600.jpg colSpan=2 height=5></TD></TR><TR>          <TD colSpan=2 height=1></TD></TR><TR><TD width=200 height=20 align=right vAlign=center           background=pic/horline_200r.jpg class="style29">คำถามส่วนตัว&nbsp;:</TD><TD vAlign=center align=left width=280 background=pic/horline_350.jpg bgColor=#eeeeee height=20>&nbsp;&nbsp;<span id="question" class="style29">'+result.getElementsByTagName("question")[0].firstChild.nodeValue+'</span></TD></TR><TR><TD width=200 height=20 align=right vAlign=center           background=pic/horline_200r.jpg class="style29">&nbsp;คำตอบ&nbsp;:</TD><TD vAlign=center align=left           background=pic/horline_350.jpg bgColor=#eeeeee           height=20>&nbsp;&nbsp;          <INPUT type=password maxLength=16 border=0 name="textfield2" id="answer"/></TD></TR><TR align=middle><TD           height=20 colSpan=2 align="center" vAlign=center background=pic/horline_c600.jpg class="style29"><INPUT onClick="return recoveryPass(\''+result.getElementsByTagName("userName")[0].firstChild.nodeValue+'\')" type=submit value="ยันยืน" name=recover>         &nbsp;         </TD></TR><TR><TD vAlign=center width=200           background=pic/horline_c600o.jpg colSpan=2           height=1 align="center"><div id="responserecovery" class="style18"></div></TD></TR><TR><TD height=1></TD></TR></TBODY></TABLE>';
	}else{
		alert("ไม่พบข้อมูลของผู้ใช้ชื่อนี้");
	}
}
function recoveryPass(uName){
	if (document.getElementById("answer").value==""){
		alert("กรุณากรอกคำตอบ");
		return false;
	}
	cp.call('php/recoveryPassword.php','recoveryPass',responserecoveryPass ,uName,document.getElementById("answer").value);
}
function responserecoveryPass(result){
	if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
		document.getElementById("responserecovery").innerHTML ='รหัสผ่านใหม่ : '+result.getElementsByTagName('newPass')[0].firstChild.nodeValue;
	}else{
		alert("คำตอบไม่ถูกต้อง กรุณากรอกใหม่อีกครั้ง");
	}
	
}