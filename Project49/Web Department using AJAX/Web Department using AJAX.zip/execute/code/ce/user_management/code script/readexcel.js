<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		cp.set_debug(true);
	
		function sendfileexcel() {
			//alert(document.getElementById('fFilename').value);
			cp.call('php/readexcel.php','readexcel',showlist ,document.getElementById('fGeneration').value, document.getElementById('fSection').value,document.getElementById('fFilename').value);
			return false;
		}

		function showlist(result) {
			if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
				var response = result.getElementsByTagName('liststudent')[0].firstChild.nodeValue;
				response =replacestring(response,"\\u003c","<");
				response =replacestring(response,"\\u003e",">");
				document.getElementById('showform').innerHTML = response;
				
			}else{
				document.getElementById('responseInvalid').innerHTML = result.getElementsByTagName('permition')[0].firstChild.nodeValue;
			}
		}
		function replacestring (inistring,word,substitute ){
			var newstring = inistring;
			var tempstr1 ="";
			var tempstr2 ="";
			while (newstring.indexOf(word) >0){
				tempstr1 = newstring.substring(0,newstring.indexOf(word) );
				tempstr2 = newstring.substring(newstring.indexOf(word) + word.length, newstring.length);
				newstring = tempstr1+substitute+tempstr2;
			}
			return newstring;
		}
	//-->