<!--
		function getformCreateAcc(){
		document.getElementById('showform').innerHTML ='<table width="450" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">              <tr>                <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3619;&#3640;&#3603;&#3634;&#3585;&#3619;&#3629;&#3585;username &#3649;&#3621;&#3632;password </span></th>             </tr>              <tr>                <td width="195" align="right">ชื่อที่ใช้ในระบบ</td>                <td width="246" align="left"><input name="username" type="text"  id="cusername" size="25" /></td>              </tr>			  <tr>                <td align="right">รหัสผ่าน</td>                <td width="246" align="left"><input name="textfield" type="password" id="cpassword" size="25" /></td>              </tr>              <tr>                <td align="right">ยืนยันรหัสผ่าน</td>                <td width="246" align="left"><input name="textfield2" type="password" id="cconfirm" size="25"  /></td>              </tr>              <tr>                <td align="right">&#3588;&#3635;&#3606;&#3634;&#3617;&#3626;&#3656;&#3623;&#3609;&#3605;&#3633;&#3623;(&#3651;&#3594;&#3657;&#3651;&#3609;&#3585;&#3619;&#3603;&#3637;&#3621;&#3639;&#3617;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;)</td>                <td align="left"><input name="question" type="text" id="cquestion" size="25" /></td>              </tr>              <tr>                <td align="right">&#3588;&#3635;&#3605;&#3629;&#3610;&#3586;&#3629;&#3591;&#3588;&#3635;&#3606;&#3634;&#3617;&#3626;&#3656;&#3623;&#3609;&#3605;&#3633;&#3623;</td>                <td align="left"><input name="answer" type="text" id="canswer" size="25" /></td>              </tr>                            <tr>                <td colspan="2" align="center"><input name="summit" type="button" value="ยืนยัน"  onclick="return crateAcc()"/></td>              </tr>            </table>';					
		}		
		function crateAcc() {
			if (document.getElementById('cpassword').value=="" || document.getElementById('cusername').value=="" || document.getElementById('cquestion').value=="" || document.getElementById('canswer').value==""){
				alert("กรุณากรอกให้ครบทุกช่อง");
				return false;
			}
			if (document.getElementById('cpassword').value.length<6){
				alert("กรุณาตั้งรหัสผ่านเกิน6ตัวอักษร");
				return false;
			}
			if (document.getElementById('cpassword').value==document.getElementById('cconfirm').value){
				cp.call('php/createMatchAcc.php','createAcc',responseCrateAcc,document.getElementById('cusername').value,document.getElementById('cpassword').value,document.getElementById('cquestion').value,document.getElementById('canswer').value);
			}else {
				alert("ท่านกรอก password และconfirm passwordไม่ตรงกัน");
			}
			return false;
		}

		function responseCrateAcc(result) {
			if(result.getElementsByTagName('permition')[0].firstChild.nodeValue=="permit"){
				document.getElementById('showreponse').innerHTML = "Welcome to CE Website";
				var editProfilepage=result.getElementsByTagName('editProfilepage')[0].firstChild.nodeValue;
				window.navigate(editProfilepage);
			}else{
				document.getElementById('showreponse').innerHTML ="username&#3595;&#3657;&#3635;&#3585;&#3633;&#3610;&#3607;&#3637;&#3656;&#3617;&#3637;&#3651;&#3609;&#3651;&#3609;&#3619;&#3632;&#3610;&#3610; &#3585;&#3619;&#3640;&#3603;&#3634;&#3585;&#3619;&#3629;&#3585;&#3651;&#3627;&#3617;&#3656;";
			}
		}
	//-->