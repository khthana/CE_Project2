var listLecturer="";
function getlistLecturer(){
	if (document.getElementById("searchName").value==""){
		return false;
	}else{
		//alert(document.getElementById("caption").value);
		cp.call('php/getLecturerInfo.php','getlistLecturer',responsegetlistLecturer,document.getElementById("caption").value,document.getElementById("searchName").value);
	}
}
function responsegetlistLecturer(result){
		listLecturer=result;
		addListBox();
}
function selectLecturer(){
	for (var i=listLecturer.getElementsByTagName("lecturerID").length-1 ;i>=0;i--){
		if (listLecturer.getElementsByTagName("lecturerID")[i].firstChild.nodeValue==document.getElementById("listLecturer").value){
			break;		
		}
	}
	if (i>=0){
		lecturerID=document.getElementById("listLecturer").value;
		document.getElementById('captiontxt').innerHTML=listLecturer.getElementsByTagName("caption")[i].firstChild.nodeValue;
		document.getElementById('name').innerHTML=listLecturer.getElementsByTagName("name")[i].firstChild.nodeValue;
		document.getElementById('sername').innerHTML=listLecturer.getElementsByTagName("sername")[i].firstChild.nodeValue;
		document.getElementById('position').innerHTML=listLecturer.getElementsByTagName("position")[i].firstChild.nodeValue;
		document.getElementById('emailL').innerHTML=listLecturer.getElementsByTagName("emailL")[i].firstChild.nodeValue;
		document.getElementById('contactPhoneNo').innerHTML=listLecturer.getElementsByTagName("contactPhoneNo")[i].firstChild.nodeValue;
		document.getElementById('office').innerHTML=listLecturer.getElementsByTagName("office")[i].firstChild.nodeValue;
		document.getElementById('teachLV').innerHTML=listLecturer.getElementsByTagName("teachLV")[i].firstChild.nodeValue;
		document.getElementById('link').innerHTML=listLecturer.getElementsByTagName("link")[i].firstChild.nodeValue;
		document.getElementById('research').innerHTML=listLecturer.getElementsByTagName("research")[i].firstChild.nodeValue;
		document.getElementById('username').innerHTML=listLecturer.getElementsByTagName("username")[i].firstChild.nodeValue;
	}
}
function addListBox(){
	for (var i=document.getElementById("listLecturer").options.length;i>=0;i--){
		document.getElementById("listLecturer").remove(i);
	}
	for (var i=0;i<listLecturer.getElementsByTagName("lecturerID").length;i++){
		var op=document.createElement('option');
		op.text=listLecturer.getElementsByTagName("caption")[i].firstChild.nodeValue+" "+listLecturer.getElementsByTagName("name")[i].firstChild.nodeValue+" "+listLecturer.getElementsByTagName("sername")[i].firstChild.nodeValue;
		op.value=listLecturer.getElementsByTagName("lecturerID")[i].firstChild.nodeValue;
		try{
			document.getElementById("listLecturer").add(op,null); // standards compliant
		}
		catch(ex){
			document.getElementById("listLecturer").add(op); // IE only
		}
	}
}