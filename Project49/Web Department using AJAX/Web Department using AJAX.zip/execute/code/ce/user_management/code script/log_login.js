<!--
var pagegl;
function getLogFile(uID,page){
	
	pagegl=page;
	cp.call('php/log_login.php','getLogFile',responsegetgetLogFile,uID,page);
}
function responsegetgetLogFile(result){
	var a;
	var check = result.getElementsByTagName( "check")[0].firstChild.nodeValue;
	if (check){
	
		
		pageCell = document.getElementById("page");
		//pageCell = newRow.insertCell(0);
		//pageCell.align="right";
		totalpagegl = result.getElementsByTagName( "totalpage")[0].firstChild.nodeValue;
		pageCell.innerHTML= pagegl+" จาก "+ totalpagegl +"    ";
		createPagelist(pageCell,pagegl,totalpagegl);
		gotobutton=' <input type="submit" name="nGoPage " value="ไปยัง" ';
		gotobutton +="onclick='return gotoPage(\""+result.getElementsByTagName( "userID")[0].firstChild.nodeValue+ "\")'/>";
		//gotobutton +="onclick='clearTable();'/>";
		pageCell.innerHTML+=gotobutton;
		
		for (var j=(result.getElementsByTagName('tm').length-1);j>=0;j-- ){
			var newRow = document.getElementById("viewlogTB").insertRow(0);
			a=newRow.insertCell(0);
			a.innerHTML=result.getElementsByTagName( "tm")[j].firstChild.nodeValue;	
			a.align="center";
			//a.bgColor="#1AD1FF";
		}

		document.getElementById("pagelist").value=pagegl;
	}else{
		alert(result.getElementsByTagName( "check")[0].firstChild.nodeValue);
	}

}

function createPagelist(parentNode,page,totalpage){
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","pagelist");
		for (var i=1;i <= totalpage ;i++ ){
			//if (i!=page){
				var op=document.createElement('option');
				op.text="page "+i;
				op.value=i;
				//op.onchange=alert("test");
				try {
					 createNodeselect.add(op,null);// standards compliant
				}
				 catch(ex){
					 createNodeselect.add(op); // IE only
			 //  }
			}
		}
}
function gotoPage(uID){		
	if (document.getElementById('pagelist').options.length !=0){
		for (i=0;i<document.getElementById('pagelist').options.length ; i++)	{
			if (document.getElementById('pagelist').options[i].selected){
					var page =document.getElementById('pagelist').options[i].value;
			}
		}
		cp.call('php/log_login.php','getLogFile',responsegetgetLogFile,uID,page);

		clearTable();
		pagegl=parseInt(page);
		
	}
}

function clearTable(){
	var numTableRow=document.getElementById('viewlogTB').rows.length;
	for (var j=1; j < numTableRow ;j++ ){
		document.getElementById("viewlogTB").deleteRow(1);
	}
	document.getElementById("viewlogTB").deleteRow(0);
}
//-->