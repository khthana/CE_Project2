<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<?php
			include("../_Sessionstart.php");
			if($_SESSION['ss_Status']=="offline"){
				echo "<center>Please log in to system <br/>";
				echo '<A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A></center>';
				return;
			}
?>
<style type="text/css">
<!--

#Layer10 {
	width:990px;		
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;

}

#Layer1 {
	margin-left: 30px;
}
.heading {
	font-size: 14px;
	color: #FF0000;
}
.warning {
	color: #333333;
	font-style: normal;
	font-weight: bolder;
}
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/profile.js"></script>
<script type="text/javascript" src="code script/generalInvite.js"></script>
<script type="text/javascript" >
<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		//cp.set_debug(true);
//-->
</script>

</head>

<body><br/>
<div align='center'><img src="../images/logo.gif" width="640" height="120" /></div>
<h1 style='text-align:center;color:#666666;font-family:Arial;font-size:24px;'>ข้อมูลส่วนตัว</h1>
<div id="Layer1">
<table width="770px"  border="0" align ='center'>
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" class="embedded">
	       
			
		 <table border="0" cellspacing="0" cellpadding="0" align="center" width="100%">
          <tr >
            <td width="100%" >
              <form method="post" action="">
                <table width="100%" border="1" cellpadding="5" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
                  <tr>
					<td align="right" valign="top"><span class="heading">ชื่อผู้ใช้งาน</span></td>
					<td align="left" valign="top" class="detail" id="userName">&nbsp;</td>
				</tr>
				<tr>
                    <td align="right" valign="top"><span class="heading">คำนำหน้า</span></td>
                    <td align=left valign="top" class="detail"><input id="tName" name="titleTxt" type="text" size=50/></td>
				</tr>
				  <tr>
                    <td  align="right" valign="top"><span class="heading">ชื่อต้น</span></td>
                    <td align=left valign="top" class="detail"><input id="fName" name=firstName size=50></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">นามสกุล </span></td>
                    <td align=left valign="top" class="detail"><input id="lName" name=lastname size=50></td>
                  </tr>
				  <tr>
                    <td align="right" valign="top"><span class="heading">ชื่อเล่น</span> </td>
                    <td align=left valign="top" class="detail"><input id="nName" name=nickName size=50></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">ที่อยู่</span> </td>
                    <td align=left valign="top" class="detail"><textarea id="homeAddr" name="Homeaddress" cols="35" rows="5"></textarea></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">อีเมล์</span></td>
                    <td align=left valign="top" class="detail"><input id="Email" type="text" /></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">แสดงอีเมล์นี้แก่สาธารณะหรือไม่</span></td>
                    <td align=left valign="top" class="detail"><input name=showemail type=radio id="showEmail" value=yes checked="checked">
              แสดง
                <input id="hideEmail" type=radio name=showemail value=no>
              ไม่แสดง</td>
                  </tr>
				  <tr>
                    <td align="right" valign="top"><span class="heading">หมายเลขโทรศัพท์มือถือ</span></td>
                    <td align=left valign="top" class="detail"><input id="mobilePhone" name="textfield" type="text" /></td>
                  </tr>
				  <tr>
                    <td align="right" valign="top"><span class="heading">หมายเลขโทรศัพท์บ้าน </span></td>
                    <td align=left valign="top" class="detail"><input id="homePhone" name="textfield2" type="text" /></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">ได้รับการเชื้อเชิญจาก</span></td>
                    <td align=left valign="top" class="detail" id="invitedBy">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">ระดับสิทธิ์</span></td>
                    <td align=left valign="top" class="detail" id="lv">&nbsp;</td>
                  </tr>
                 
                  <tr>
                    <td align="right" valign="top"><span class="heading">สังกัดห้องวิจัย</span> </td>
                    <td align=left valign="top" class="detail" id="underLab">&nbsp;</td>
                  </tr>
                  
				  <tr>
                    <td align="right" valign="top"><span class="heading">รหัสนักศึกษาที่ใช้อยู่ปัจจุบัน</span> </td>
                    <td align=left valign="top" class="detail" id="sID">&nbsp;</td>
				  </tr>
				  <tr>
                    <td align="right" valign="top"><span class="heading">ภาควิชา</span></td>
                    <td align=left valign="top" class="detail" id="department">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">รุ่น</span></td>
                    <td align=left valign="top" class="detail" id="generation">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">ห้อง</span></td>
                    <td align=left valign="top" class="detail" id="section">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">คะแนนความน่าเชื่อถือ</span></td>
                    <td align=left valign="top" class="detail" id="point">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">จำนวนกระทู้ที่ตั้งเสีย</span></td>
                    <td align=left valign="top" class="detail" id="tBadpost">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">จำนวนกระทู้ที่ตั้ง</span></td>
                    <td align=left valign="top" class="detail" id="tTopic">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">จำนวนความคิดเห็นที่แสดง</span></td>
                    <td align=left valign="top" class="detail" id="tOpinion">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">วันที่ลงทะเบียน</span></td>
                    <td align=left valign="top" class="detail" id="jointDate">&nbsp;</td>
                  </tr>
				   <!--<tr>
                    <td class="heading" valign="top" align="right">Last_Login</td>
                    <td valign="top" align=left id="lastLogin">25-08-2549 :19:40:43</td>
                  </tr>-->
                  <tr>
                    <td align="right" valign="top"><span class="heading">รหัสผ่านใหม่</span></td>
                    <td align=left valign="top" class="detail"><input type="password" id="newPass" name="chpassword" size="50" /></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">ยืนยันรหัสผ่านใหม่</span></td>
                    <td align=left valign="top" class="detail"><input type="password" id="retypeNewPass" name="passagain2" size="50" />                    </td>
                  </tr>
                  <tr>
                    <td colspan="2" align="center" valign="middle" ><span class="heading">หมายเหตุ :</span><span class="warning">&#3585;&#3619;&#3640;&#3603;&#3634;&#3651;&#3626;&#3656;รหัสผ่านปัจจุบัน&#3651;&#3609;&#3594;&#3656;&#3629;&#3591;&#3586;&#3657;&#3634;&#3591;&#3621;&#3656;&#3634;&#3591;&#3648;&#3617;&#3639;&#3656;&#3629;&#3605;&#3657;&#3629;&#3591;&#3585;&#3634;&#3619;&#3648;&#3611;&#3621;&#3637;&#3656;&#3618;&#3609;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;  </span></td>
                  </tr>
                  <tr>
                    <td align="right" valign="top"><span class="heading">รหัสผ่าน</span></td>
                    <td align=left valign="top" class="detail"><input type="password" id="pass" name="passagain" size="50" /></td>
                  </tr>
                  <tr>
                    <td colspan="2" align="center" class="detail"><input name="submit" type="button" style='height: 25px' value="แก้ไขข้อมูล" onclick="return editProfile()" />
                    <input name="reset" type="button" style='height: 25px' value="ข้อมูลเดิม" onclick="return responsegetProfile(defaultparameter)"></td>
                  </tr>
                  <tr>
                    <td colspan="2" align="center" >
                      <span class="heading">หมายเหตุ :</span>&#3585;&#3619;&#3640;&#3603;&#3634;&#3585;&#3619;&#3629;&#3585;&#3629;&#3637;&#3648;&#3617;&#3621;&#3660;&#3586;&#3629;&#3591;&#3612;&#3641;&#3657;&#3607;&#3637;&#3656;&#3607;&#3656;&#3634;&#3609;&#3605;&#3657;&#3629;&#3591;&#3585;&#3634;&#3619;&#3648;&#3594;&#3639;&#3657;&#3629;&#3648;&#3594;&#3636;&#3597;
                      <input type="text" id="emailInvite" name="mail" size="20" />&nbsp;
                   <input name="sedndmail" type="button" value="เชื้อเชิญ" onclick="return sendInviteGeneral()" /><div id="responeinvite"></div></td>
                  </tr>
                </table>
            </form></td>
          </tr>
        </table></td>
</tr>
</table>
<br/>
</div>

</body>

</html>
<script type="text/javascript" >
<!--

getProfile();
//-->
</script>