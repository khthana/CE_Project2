<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=utf-8">


<title>Welcome to CE.KMITL </title>
<?php
			include("../_Sessionstart.php");
			if($_SESSION['ss_Status']=="offline"){
				echo "<center>Please log in to system <br/>";
				echo '<A  href="http://www.ce.kmitl.ac.th/ " target="_self">Home page</A></center>';
				return;
			}
?>
<style type="text/css">
<!--
#Layer7 {
	height:700px;
	overflow:auto; scrolling:auto; scrollbar-face-color : white; scrollbar-highlight-color #c0c0c0; 
scrollbar-3dlight-color : #c0c0c0 ; scrollbar-shadow-color : white; 
scrollbar-darkshadow-color : #c0c0c0; scrollbar-track-color : white ; 
scrollbar-arrow-color : white ;
}
#Layer10 {
	width:990px;		
}

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;
}


#Layer1 .embedded .heading {
	font-size: 14px;
	color: #FF0000;
}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
	font-weight: bold;
}
.style24 {color: #B7B7B7}
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" >
<!--
function choosetype(){
	if (document.getElementById("type1").checked)
	{
		 window.location ="admin_regis1_1.php";
	}else if (document.getElementById("type2").checked)
	{
		 window.location ="admin_regis1_2.php";
	}else if (document.getElementById("type3").checked)
	{
		 window.location ="admin_regis1_3.php";
	}else return false;
}
//-->
</script>
</head>

<body>
<div id="Layer1" align="center">
    <table width="599" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
        <td width="476" height="77"><img src="../images/logo.gif" width="640" height="121" /></td>
      
	    <td width="123" class=embedded>        </td>
      </tr>
  </table>
</div><div id="Layer1" align="center">
<table width="706" height="134" border="0">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" class="embedded"><h1 align="center" class="style16 style24"> Member Registeration by Admin</h1>      </td>
    </tr>
		   <tr>
		   	<td align="center"><table width="450" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
  <tr>
    <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3619;&#3640;&#3603;&#3634;&#3648;&#3621;&#3639;&#3629;&#3585;&#3621;&#3633;&#3585;&#3625;&#3603;&#3632;&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;</span></th>
    </tr>
  
  <tr>
    <td width="73" rowspan="2">    </td>
    <td width="374" align="left"> <form  name="chooseForm" method="post" action="">
	<input  id="type1" name="radiobutton" type="radio" value="1" checked="checked" />
&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;&#3619;&#3634;&#3618;&#3610;&#3640;&#3588;&#3588;&#3621;
 <br />
    <input id="type2" name="radiobutton" type="radio" value="2" /> 
    &#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;&#3629;&#3634;&#3592;&#3634;&#3619;&#3618;&#3660; <br />
    <input id="type3" name="radiobutton" type="radio" value="3" />
    &#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;&#3648;&#3610;&#3637;&#3618;&#3609;&#3585;&#3621;&#3640;&#3656;&#3617;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;<br />
    </form>  </td>
  </tr>
  <tr>
    <td align="left"><input name="summit" type="button" value="ตกลง"  onclick="return choosetype()"/></td>
  </tr>
  

</table></td>
		   </tr>
  </table>
		   </div>
</body>
</html>