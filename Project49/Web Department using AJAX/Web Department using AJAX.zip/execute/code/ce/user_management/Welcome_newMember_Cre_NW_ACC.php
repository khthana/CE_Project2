<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv=Content-Type content="text/html; charset=tis-620">


<title>Welcome to CE.KMITL </title>
<?php
		include("../_Sessionstart.php");
?>
<style type="text/css">
<!--
#Layer7 {
	height:700px;
	overflow:auto; scrolling:auto; scrollbar-face-color : white; scrollbar-highlight-color #c0c0c0; 
scrollbar-3dlight-color : #c0c0c0 ; scrollbar-shadow-color : white; 
scrollbar-darkshadow-color : #c0c0c0; scrollbar-track-color : white ; 
scrollbar-arrow-color : white ;
}
#Layer10 {
	width:990px;		
}
#viewlog {
	height:300px;
	overflow:auto; scrolling:auto; scrollbar-face-color : white; scrollbar-highlight-color #c0c0c0; 
scrollbar-3dlight-color : #c0c0c0 ; scrollbar-shadow-color : white; 
scrollbar-darkshadow-color : #c0c0c0; scrollbar-track-color : white ; 
scrollbar-arrow-color : white ;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;
}

#dropm {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; LIST-STYLE-TYPE: none
}
#dropm UL {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; LIST-STYLE-TYPE: none}

#dropm LI {
	BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; FLOAT: left; BORDER-BOTTOM-WIDTH: 0px; WIDTH: 10em; CURSOR: pointer; POSITION: relative; TEXT-ALIGN: center; BORDER-RIGHT-WIDTH: 0px
}

#dropm LI UL {
	PADDING-RIGHT: 0px; DISPLAY: none; PADDING-LEFT: 0px; FONT-WEIGHT: normal; LEFT: 0px; PADDING-BOTTOM: 1em; PADDING-TOP: 0.5em; POSITION: absolute; TOP: 100%
}

#dropm LI LI {
	BORDER-TOP-WIDTH: 0px; DISPLAY: block; BORDER-LEFT-WIDTH: 0px; FLOAT: none; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px
}
#dropm LI:hover UL {
	DISPLAY: block
}
#dropm LI.over UL {
	DISPLAY: block
}
.style22 {color: #666666}
#Layer1 .embedded .heading {
	font-size: 14px;
	color: #FF0000;
}
.style23 {
	color: #FF0000;
	font-size: 18px;
	font-weight: bold;
}
-->
</style>
<SCRIPT src="code script/dropdown.js" type=text/javascript></SCRIPT>
<script type="text/javascript" src="cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/login.js"></script>
<script type="text/javascript" >
<!--
var m2924_btnCount = 3;
var m2924_staCount = 3;
var m2924_pressed = -1;
var m2924_btnImages = new Array();
for (i= 0; i< m2924_btnCount; i++)
{
	m2924_btnImages[i] = new Array();
	for (j= 0; j< m2924_staCount; j++)
	{
		m2924_btnImages[i][j] = new Image();
		m2924_btnImages[i][j].src = 'button/m2924_mbtn' + i + '_' + j + '.gif';
	}
}
function m2924_btnMouseOut(img)
{
	if (m2924_pressed == img)
		return;
	document.images[img].src = m2924_btnImages[img.substring(img.indexOf('_mbtn')+5,img.length)][0].src;
};
function m2924_btnMouseOver(img)
{
	if (m2924_pressed == img)
		return;
	document.images[img].src = m2924_btnImages[img.substring(img.indexOf('_mbtn')+5,img.length)][1].src;
};
function m2924_btnMouseDown(img)
{
	if (m2924_pressed == img)
		return;
	if (m2924_pressed != -1)
		document.images[m2924_pressed].src = m2924_btnImages[m2924_pressed.substring(m2924_pressed.indexOf('_mbtn')+5,m2924_pressed.length)][0].src;
	document.images[img].src = m2924_btnImages[img.substring(img.indexOf('_mbtn')+5,img.length)][2].src;
	m2924_pressed = img;
};
//-->
</script>
</head>

<body>
<div id="Layer1" align="center">
    <table width="827" height="80" border="0" cellpadding="0" cellspacing="0">
     
      <tr>
        <td width="228" height="77" bordercolor="#0033FF" >
		<div id="login">
		</div>
		</td>
		<?php 
			if($_SESSION['ss_Status']==online){
		?>	<script type="text/javascript">
		document.getElementById('login').innerHTML = "welcome to CE ";
		</script>
		<?php
		}
		?>
        <td width="476"><img src="../images/logo.gif" width="800" height="175" /></td>
      
	    <td width="123" class=embedded>
                      </td>
      </tr>
  </table>
</div><div id="Layer" align="center">
<table width="706" height="134" border="0">
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" class="embedded"><h1 align="center" class="style16 style22"> Welcome New Member </h1>      </td>
    </tr>
		   <tr>
		   	<td id="showform" align="center"><table width="450" border="1" cellpadding="0" cellspacing="1" bordercolor="#CCCCCC" background="../images/bg_subjectdetailhead.gif">
              <tr>
                <th colspan="2" background="../images/bg_subjectdetail.gif"><span class="style23">&#3585;&#3619;&#3640;&#3603;&#3634;&#3585;&#3619;&#3629;&#3585;username &#3649;&#3621;&#3632;password </span></th>
              </tr>
              <tr>
                <td width="195" align="right">���ͷ������к�</td>
                <td width="246" align="left"><input name="username" type="text"  id="cusername" size="25" /></td>
              </tr>
			  <tr>
                <td align="right">���ʼ�ҹ</td>
                <td width="246" align="left"><input name="textfield" type="password" id="cpassword" size="25" /></td>
              </tr>
              <tr>
                <td align="right">�׹�ѹ���ʼ�ҹ</td>
                <td width="246" align="left"><input name="textfield2" type="password" id="cconfirm" size="25"  /></td>
              </tr>
              <tr>
                <td align="right">&#3588;&#3635;&#3606;&#3634;&#3617;&#3626;&#3656;&#3623;&#3609;&#3605;&#3633;&#3623;(&#3651;&#3594;&#3657;&#3651;&#3609;&#3585;&#3619;&#3603;&#3637;&#3621;&#3639;&#3617;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;)</td>
                <td align="left"><input name="question" type="text" id="cquestion" size="25" /></td>
              </tr>
              <tr>
                <td align="right">&#3588;&#3635;&#3605;&#3629;&#3610;&#3586;&#3629;&#3591;&#3588;&#3635;&#3606;&#3634;&#3617;&#3626;&#3656;&#3623;&#3609;&#3605;&#3633;&#3623;</td>
                <td align="left"><input name="answer" type="text" id="canswer" size="25" /></td>
              </tr>
              
              <tr>
                <td colspan="2" align="center"><input name="summit" type="button" value="�׹�ѹ"  onclick="return crateAcc()"/></td>
              </tr>
            </table></td>
		   </tr>
  </table>
		   </div>
</body>
</html>