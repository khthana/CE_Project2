<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

.tdB {
	font-size: 14px;
	color: blue;
	text-align: center;
	padding-left:0px;
	
}
.tdA {
	font-size: 14px;
	color: blue;
	text-align:left;
	padding-left:20px;
	
}
.style13 {
	font-family: "MS Sans Serif", EucrosiaUPC, Thonburi, Krungthep;
	font-size: 16px;
	color: #FF0000;
	font-weight: bold;
}
#dropm {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; LIST-STYLE-TYPE: none
}
#dropm UL {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; LIST-STYLE-TYPE: none}

#dropm LI {
	BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; FLOAT: left; BORDER-BOTTOM-WIDTH: 0px; WIDTH: 10em; CURSOR: pointer; POSITION: relative; TEXT-ALIGN: center; BORDER-RIGHT-WIDTH: 0px
}

#dropm LI UL {
	PADDING-RIGHT: 0px; DISPLAY: none; PADDING-LEFT: 0px; FONT-WEIGHT: normal; LEFT: 0px; PADDING-BOTTOM: 1em; PADDING-TOP: 0.5em; POSITION: absolute; TOP: 100%
}

#dropm LI LI {
	BORDER-TOP-WIDTH: 0px; DISPLAY: block; BORDER-LEFT-WIDTH: 0px; FLOAT: none; BORDER-BOTTOM-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px
}
#dropm LI:hover UL {
	DISPLAY: block
}
#dropm LI.over UL {
	DISPLAY: block
}
.style32 {
	font-family: "MS Sans Serif", EucrosiaUPC, Thonburi, Krungthep;
	font-size: 14px;
	color: #000000;
}
.style34 {font-size: 9px; color: #FF0000; }
.style35 {color: #FF9900}
#showlist {
	text-align: center;
	
}

div.header table th{
	
	font-family: "MS Sans Serif";
	font-size:12px;
	background-Color:#E1E0DF;
	text-align: center;
	font-weight:bold;
    -moz-user-select:none;
	overflow:hidden;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #CCCCCC;
	margin: 0px;
	padding: 0px;
	height:25px;

}
a:link,a:visited,a:hover{

	text-decoration:none;
	color:blue;
}
div.tittle{

	font-family: "MS Sans Serif";
	font-size:12px;
	font-weight:bold;

}

span.footer{

	font-family: "MS Sans Serif";
	font-size:12px;
	text-align:right;
	font-weight:bold;
   
}
div.detail{

	font-family: "MS Sans Serif";
	font-size:16px;
	font-weight:normal;

}


-->
</style>
<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/showlist.js"></script>
<script type="text/javascript" src="../PM/js/showRelation.js"></script>
<?php
		ob_start() ;
		include("../_Sessionstart.php");
		ob_end_flush();
?>
<script type="text/javascript" >
<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		//cp.set_debug(true);
//-->
</script>
</head>

<body><br/>
<div id="Layer1" align="center">
    <table width="476" height="80" border="0" cellpadding="0" cellspacing="0">
      <tr>
         <td width="476"><img src="../images/logo.gif" width="640" height="121" /></td>
      </tr>
	</table>
  <br/>
</div>

<div id="search" align="center">
  <table width="700" border="0">
    <tr>
      <td>
		<div align="center" class='tittle'><span style='font-size:15px;color:red;'>ค้นหาสมาชิกชื่อ</span>
           <input type="text" name="searchMem" id="searchMembervalue" />&nbsp;
           <a href="javascript:void searchMemberFn(1)">ค้นหา</a>&nbsp;&nbsp;<a href = "javascript:getListmember(1)">แสดงทั้งหมด</a>
		</div>      
	  </td>
    </tr>
  </table>
</div>

<div align="center" class='header'>
  <table cellspacing="0" id="showList"  width="700" >
    <tr >
      <th width="175" >รายชื่อสมาชิก</th>
      <th width="200" >วันที่ลงทะเบียน</th>
      <th width="60" >ระดับ</th>
      <th width="175" >ได้รับการเชื้อเชิญโดย</th>
   	  <?php if (isset($_SESSION['ss_Level']) and $_SESSION['ss_Level']=="admin") {
		echo '<th width="90" >Active status </th>';
	  }
	  ?>
    </tr>
	
  </table>
  <br/>
  <hr width='400px'/>
  <span id='page' class='footer'></span>
 
</div>
<div id="showtable" align="center">
	 <br/>
		<table cellPadding='0' cellSpacing='0' border="0" width="720">
			<tr>
				<td ><img src='./pic/table_Frame/top_l.gif' width="25" height="14" /></td>
				<td style='background-image: url(./pic/table_Frame/top_c.gif);background-repeat: repeat-x;width:750px'></td>
				<td><img src='./pic/table_Frame/top_r.gif' /></td>
			</tr>
			<tr>
				<td style='background-image: url(./pic/table_Frame/margin_l.gif);background-repeat: repeat-y;'></td>
				<td>
					<center>
					
						<a href='javascript:showGenInfo()'><img src='./pic/button/InfoGen_0.gif' border="0" onMouseOver="this.src='./pic/button/InfoGen_1.gif'" onMouseOut="this.src='./pic/button/InfoGen_0.gif'"/></a>
						<?php if ((isset($_SESSION['ss_Level'])) and $_SESSION['ss_Level']=="admin"){?>
						<a href='javascript:showPersonalInfo()'><img src='pic/button/Infopersonal_0.gif' border="0"  onMouseOver="this.src='./pic/button/Infopersonal_1.gif'" onMouseOut="this.src='./pic/button/Infopersonal_0.gif'"/></a>
						<a href='javascript:showStudentInfo()'><img src='pic/button/InfoStudent_0.gif' border="0"  onMouseOver="this.src='./pic/button/InfoStudent_1.gif'" onMouseOut="this.src='./pic/button/InfoStudent_0.gif'"/></a>
						<a href='javascript:editInfo()'><img src='./pic/button/InfoEdit_0.gif' border="0"  onMouseOver="this.src='./pic/button/InfoEdit_1.gif'" onMouseOut="this.src='./pic/button/InfoEdit_0.gif'"/></a>
						<?php }?>
					</center>
					
					<center><img src='./pic/table_Frame/linetop.gif' /></center>
					<div id="showName" align="center" class="style32"></div>
					<center><img src='./pic/table_Frame/linetop.gif' /></center>
					<br/>
					<div id="showDetail" align="center" class='detail'></div>
									
				</td>
				<td style='background-image: url(./pic/table_Frame/margin_r.gif);background-repeat: repeat-y;'></td>
			</tr>
			<tr>
				<td><img src='./pic/table_Frame/buttom_l.gif' /></td>
			 	<td style='background-image: url(./pic/table_Frame/buttom_c.gif);background-repeat: repeat-x;'></td>
			 	<td><img src='./pic/table_Frame/buttom_r.gif'  /></td>
			</tr>
  </table>
  <br/>
</div>


</body>
<script type="text/javascript" >
<!--

	getListmember(1);
	viewmember();	
//-->
</script>
</html>
