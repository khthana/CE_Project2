<?php
		include("../_Sessionstart.php");
		//$_SESSION['ss_PageBefore']="showtopic.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Welcome to CE.KMITL</title>

<style type="text/css">
<!--


body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}



.style18 {
	font-family: "Courier New", Courier, monospace;
	font-size: 14px;
	font-weight: bold;
	color: #FF0000;
	text-align: center;
}
.style29 {
	font-family: "Courier New", Courier, monospace;
	font-size: 14px;
}
.style31 {font-family: "MS Sans Serif", EucrosiaUPC, Thonburi, Krungthep; font-size: 9px; color: #0033FF; }

-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/login.js"></script>
<script type="text/javascript" src="code script/recoveryPassword.js"></script>

</head>

<body>
<div  id="showLogin" align="center">
	<TABLE width=480 border=0 cellPadding=0 cellSpacing=0 background="pic/horline_c600.jpg">
        <TBODY>
        <TR>
          <TD colSpan=2 height=1></TD></TR>
        <TR bgColor=#f5f5f5>
          <TD background=pic/horline_c600.jpg colSpan=2 
          height=5></TD></TR>
        <TR>
          <TD colSpan=2 height=1></TD></TR>
        <TR>
          <TD width=200 
            height=20 align=right vAlign=center 
          background=pic/horline_200r.jpg class="style29">&#3612;&#3641;&#3657;&#3651;&#3594;&#3657;&#3591;&#3634;&#3609;&nbsp;:</TD>
          <TD vAlign=center align=left width=280 
          background=pic/horline_350.jpg bgColor=#eeeeee 
          height=20>&nbsp;&nbsp;
          <INPUT type="text" id="Username" maxLength=16 border=0 
        name=user_id/></TD></TR>
        
        
        
        <TR>
          <TD width=200 
            height=20 align=right vAlign=center 
          background=pic/horline_200r.jpg class="style29">&nbsp;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;&nbsp;:</TD>
          <TD vAlign=center align=left 
          background=pic/horline_350.jpg bgColor=#eeeeee 
          height=20>&nbsp;&nbsp;
          <INPUT type=password maxLength=16 border=0 
            name="textfield2" id="Password"/></TD>
        </TR>
        <TR bgColor=#f5f5f5>
          <TD background=www_reg_kmitl_ac_th_files/horline_c600.jpg colSpan=2 
          height=5></TD></TR>
        <TR>
          <TD width=200 
          height=20 align=right vAlign=center 
          background=pic/horline_200r.jpg class="style29">&nbsp;&#3619;&#3627;&#3633;&#3626;&#3605;&#3619;&#3623;&#3592;&#3626;&#3629;&#3610;&nbsp;:</TD>
          <TD vAlign=center align=left 
          background=pic/horline_350.jpg bgColor=#eeeeee 
          height=20>&nbsp;&nbsp;&nbsp;<IMG
            src=php/VF_code.php?id=<?php 
			$_SESSION['ss_VF_code']=rand(1,15);
			echo $_SESSION['ss_VF_code'];
			?>
			name="VF_code" id="VF_code" title="&#3619;&#3627;&#3633;&#3626;&#3605;&#3619;&#3623;&#3592;&#3626;&#3629;&#3610;&nbsp;"></TD>
        </TR>
        <TR>
          <TD colSpan=2 height=1></TD></TR>
        
        
        <TR>
          <TD width=200 
          height=20 align=right vAlign=center 
          background=pic/horline_200r.jpg bgColor=#ececec class="style29">&#3611;&#3657;&#3629;&#3609;&#3619;&#3627;&#3633;&#3626;&#3605;&#3619;&#3623;&#3592;&#3626;&#3629;&#3610;&nbsp;:</TD>
          <TD vAlign=center align=left 
          background=pic/horline_350.jpg bgColor=#eeeeee 
          height=20>&nbsp;&nbsp; <INPUT id=vfcode 
            title="&#3611;&#3657;&#3629;&#3609;&#3619;&#3627;&#3633;&#3626;&#3605;&#3619;&#3623;&#3592;&#3626;&#3629;&#3610;&nbsp;" maxLength=4 size=15 
            border=0 name=vfcode></TD></TR>
       <TR align=middle>
         <TD 
          height=20 colSpan=2 align="center" vAlign=center 
          background=pic/horline_c600.jpg class="style29"><INPUT onClick="return userlogin()" type=submit value="&#3621;&#3655;&#3629;&#3588;&#3629;&#3636;&#3609;" name=login>
         &nbsp;<INPUT name=forget type=submit onClick="recoveryForm()" value=&#3621;&#3639;&#3617;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;>
         </TD>
       </TR>
        
        <TR>
          <TD vAlign=center width=* 
          background=pic/horline_c600o.jpg colSpan=2 
          height=1><div id="responselogin" class="style18"></div></TD></TR>
        <TR>
  <TD height=1></TD></TR></TBODY></TABLE></TD></FORM></TR></TBODY></TABLE>
</div>
</body>
</html>
