<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title></title>
<?php
		include("../_Sessionstart.php");
			if($_SESSION['ss_Status']=="offline"){
				echo "<center>ยังไม่ได้ ล็อคอิน<br/>";
				return;
			}
?>
<style type="text/css">
<!--
#main {
	margin-left: 15px;	
}
#Layer10 {
	width:990px;		
}
#viewlog {
	height:300px;
	overflow:auto; scrolling:auto; scrollbar-face-color : white; scrollbar-highlight-color #c0c0c0; 
scrollbar-3dlight-color : #c0c0c0 ; scrollbar-shadow-color : white; 
scrollbar-darkshadow-color : #c0c0c0; scrollbar-track-color : white ; 
scrollbar-arrow-color : white ;
}
#viewlog td{
	border-bottom-color: #00B0DD;
	border-top-color: #00B0DD;
	border-right-color: #00B0DD;
	border-left-color: #00B0DD;
	background-image: url(pic/bgLog.jpg);
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 14px;
}

.Layer1 {
	font-size: 14px;
	color: #FF0000;
}
.name {
	color: #FF0000;
}
.style23 {
	color: #FFFFFF;
	font-size: 18px;
}
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="code script/log_login.js"></script>
<script type="text/javascript" >
<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		//cp.set_debug(true);
//-->
</script>

</head>

<body><br/>
<div align='center' ><img src="../images/logo.gif" width="640" height="120" /></div>

<table width="710"  border="0" align='center'>
<!--/////////////spacer///////////////-->
	
	<tr>
	  <td width="80%" class="embedded">
	       
		 <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" background="../images/bg_subjectdetailhead.gif" bgcolor="#62DFFF" >
		   <tr>
		  	<td width="100%" align="center" bordercolor="#53DDFF" background="../images/bg_subjectdetail.gif" ><span class="style23">เวลาเข้าใช้งานระบบ</span>
	  	     </td>
		  </tr>
          <tr >
            <td>
			<div id="viewlog" height="700px" align="center" overflow: scroll;>
              <table width="580" height="31px" border="0" id="viewlogTB" >
              </table>
			</div>          
			</td>
		  </tr>
		  <tr >
           <!--   <td background="../images/bg_subjectdetail.gif">&nbsp;</td>-->
		   <td id='page' align='right'></td>
          </tr>
		  <br/>
</table>
</div>
<?php echo '<input id="uID" name="uIDlog" type="hidden" value="'.$_GET['uID'].'" />';?>
</body>
<script type="text/javascript" >
<!--
//alert(document.getElementById("uID").value);

getLogFile(document.getElementById("uID").value,1);
//-->
</script>
</html>
