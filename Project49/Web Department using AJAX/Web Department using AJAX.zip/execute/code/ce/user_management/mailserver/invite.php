<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
require_once '../Excel/reader.php';
session_start();
$cp = new cpaint();
$cp->register('inviteGeneral');
$cp->register('inviteStudent');
$cp->register('inviteLecturer');
$cp->register('inviteGroupStudent');
$cp->start();
$cp->return_data();
$pathFiles = "../uploaded/files/";
function inviteGeneral($email){
	global $cp;
	connectdb();
	$responseNode =& $cp->add_node('response');
	mysql_query("SET NAMES utf8"); 
	$tokenStr = md5(rand(0,1000000000000));
	$comSQLInserttoken="INSERT INTO token_invite  SET".
		" USER_ID=".$_SESSION['ss_UserID'].
		",TOKEN_INV='".$tokenStr."'".
		",EMAIL_SEND='".$email."'".
		",TYPE='general'";
	mysql_query($comSQLInserttoken);
	if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$email,$tokenStr,0)){
				$responseNode ->set_data("Complete, E-mail has been send");
				return true;
			}else {
				$responseNode ->set_data("Incomplete ,can not send e-mail(can not find mail server)");
				return false;
			}
	}else {
			$responseNode ->set_data(mysql_error());
			return false;
	}
}
function inviteStudent($sID,$sGeneration,$sFName,$sMName,$sLName,$sSection,$sEmail){
	global $cp;
	connectdb();
	mysql_query("SET NAMES utf8"); 
	if (!checkDuplicateStuID($sID)){
		$tokenStr = md5(rand(0,1000000000000));
		$comSQLInserttoken="INSERT INTO token_invite  SET".
		" USER_ID=".$_SESSION['ss_UserID'].
		",STUDENT_ID='".$sID."'".
		",FIRST_NAME='".$sFName."'".
		",MID_NAME='".$sMName."'".
		",LAST_NAME='".$sLName."'".
		",TOKEN_INV='".$tokenStr."'".
		",EMAIL_SEND='".$sEmail."'".
		",TYPE='student'".
		",SECTION='".$sSection."'".
		",GENERATION=".$sGeneration;
		mysql_query($comSQLInserttoken);
		if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$sEmail,$tokenStr,1)){
				$cp->set_data("Complete, E-mail has been send");
				return true;
			}else {
				$cp->set_data("Incomplete ,can not send e-mail(can not find mail server)");
				return false;
			}
		}else {
			$cp->set_data(mysql_error());
			return false;
		}
	}else {
		$cp->set_data("Wrong input,student id is exited in databse");
		return false;
	}
}

function inviteLecturer($lFullname,$lSchedule,$lPosition,$lEmail,$lContactPhoneNo,$lHistory,$lQualification,$lContactAddr,$lSEmail){
	global $cp;
	connectdb();
	mysql_query("SET NAMES utf8"); 
	$tokenStr = md5(rand(0,1000000000000));
	$comSQLInserttoken="INSERT INTO token_invite  SET".
	" USER_ID=".$_SESSION['ss_UserID'].
	",FULL_NAME_L='".$lFullname."'".
	",LEC_SCHEDULE='".$lSchedule."'".
	",POSITION_L='".$lPosition."'".
	",EMAIL_L='".$lEmail."'".
	",PHONE_L='".$lContactPhoneNo."'".
	",HISTORY_L='".$lHistory."'".
	",QUALIFICATION_L='".$lQualification."'".
	",CONTACT_ADD_L='".$lContactAddr."'".
	",TOKEN_INV='".$tokenStr."'".
	",EMAIL_SEND='".$lSEmail."'".
	",TYPE='lecturer'";
	mysql_query($comSQLInserttoken);
	if( !mysql_error()){
			if (sendEmail($_SESSION['ss_UserID'],$lSEmail,$tokenStr,2)){
				$cp->set_data("Complete, E-mail has been send");
				return true;
			}else {
				$cp->set_data("Incomplete ,can not send e-mail(can not find mail server)");
				return false;
			}
	}else {
		$cp->set_data(mysql_error());
		return false;
	}
	
}
function inviteGroupStudent($generation, $section,$filename){
	global $cp;
	global  $pathFiles;
	$pathFiles ="../uploaded/files/".$filename;
	$data = new Spreadsheet_Excel_Reader();
	$data->setOutputEncoding('UTF-8');
	$data->read($pathFiles);
	if (error_reporting(E_ALL ^ E_NOTICE))
	{
		for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {
					if (inviteStudent($data->sheets[0]['cells'][$i][1],$generation,$data->sheets[0]['cells'][$i][3],$data->sheets[0]['cells'][$i][4],$data->sheets[0]['cells'][$i][5],$section,$data->sheets[0]['cells'][$i][6])==false){
					echo "Wrong input, ";
					break;
					}
		}
		return true;
	}else{
		return false;
	}
}

function checkDuplicateStuID($sID){
	$comsqlCheckDuplicateSID="SELECT * FROM useraccount WHERE STUDENT_ID='".$sID."'";
	$checkResult=mysql_query($comsqlCheckDuplicateSID);
	if ($userrow=mysql_fetch_array($checkResult)){
		return true;
	}else return false;
}
function sendEmail($invitorID,$sEmail,$token,$type){
	$to=$sEmail;
	$boundary=md5(uniqid(time()));
		if ($type==1){
		//$subject=iconv("tis-620","window-874","�Թ�յ͹�ѡ�֡���Ѻ�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
		$subject="�Թ�յ͹�ѡ�֡���Ѻ�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������";
	}else if($type==2){
		//$subject=iconv("tis-620","window-874","���¹�ԭ�Ҩ����ŧ����¹�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
		$subject="���¹�ԭ�Ҩ����ŧ����¹�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������";
	}else{
		//$subject=iconv("tis-620","window-874","�Թ�յ͹�Ѻ�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������");
		$subject="�Թ�յ͹�Ѻ�������Ҫԡ�ͧ�к�����Ҥ�Ԫ����ǡ�������������";
	}
	$form="From: admin@network02.ce.kmitl.ac.th\r\n";
	$replyto="Reply-To: admin@network02.ce.kmitl.ac.th\r\n";
	$header=$form.$replyto;
	$header.="MIME-Version: 1.0\r\n";
	$header.="X-Priority: 3\r\n";
	$header.="X-Mailer: PHP/" . phpversion()."\r\n"; 
	$header.= "Content-Type: multipart/alternative;".
						"boundary=\"$boundary\"\r\n\r\n"; 
	$msg="--$boundary\r\n";
	$msg.="Content-Type: text/html; \r\n";
	$msg.=" charset=tis-620\r\n";
	$msg.="Content-Transfer-Encoding: 8bit\r\n\r\n";
	$msg.="��س��� link ���������㹡��ŧ����¹";
	$msg.='<A  href="http://161.246.5.92/ce/user_management/Welcome_newMember.php?uID='.$invitorID.'&tk='.$token.'" target="_blank">Register Member</A>';
	$msg.="\r\n";
	$msg.="--$boundary\r\n";
		$msg.="Content-Type: text/plain;\r\n";
	$msg.=" charset=tis-620\r\n";
	$msg.="Content-Transfer-Encoding: 8bit\r\n\r\n";
	$msg.="��س��� link ���������㹡��ŧ����¹";
	$msg.='http://161.246.5.92/ce/user_management/Welcome_newMember.php?uID='.$invitorID.'&tk='.$token;
	$msg.="\r\n";
	$msg.="--$boundary--\r\n\r\n";
	if(mail($to,$subject,$msg,$header)){
		return true;
	}
	else{
		return false;
	}

}
?>