<?php
function submitNewNotice($topic,$detail,$type){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		if($type==1)
			$strtype="ทั่วไป";
		else
			$strtype="วิชาการ";
		$sql="INSERT INTO `main_notice` (`CREATED` ,`UPDATE`, `TOPIC` , `DETAIL` , `BY` , `TYPE`)VALUES ('".time()."','".time()."', '$topic', '$detail', '$_SESSION[ss_UserName]', '$strtype')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$sql="SELECT MAX(`NOTICE_ID`) AS MAXID FROM $tb_main_notice";
			if($dbquery=mysql_db_query($dbname,$sql)){
				while($result=mysql_fetch_array($dbquery)){
					$return="
						<div  id='notice$type$result[MAXID]' style='padding-left:10px;' onmouseover='this.style.backgroundColor=\"#D1FFC1\"' onmouseout='this.style.backgroundColor=\"#F9F9F9\"'><img src='./images/icon_$type.gif' border='0' > <a href='./viewnotice$type.php?id=$result[MAXID]' target='_blank'>$topic<img src='images/newnotice.gif' border='0' alt=''> </a></div>";
						$objResponse->addPrepend("allnotice$type","innerHTML",$return);
					}
			}
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function deleteNotice($notice_id){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql="DELETE FROM $tb_main_notice WHERE `NOTICE_ID` = $notice_id LIMIT 1";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("ลบขอ้มูลเรียบร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function submitEditNotice($notice_id,$topic,$detail){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql = "UPDATE $tb_main_notice SET `TOPIC` = '$topic' , `DETAIL` = '$detail' WHERE `NOTICE_ID` = '$notice_id' LIMIT 1";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อยแล้ว...");
		}
		else
			$objResponse->addAlert("เกิดความผิดพลาด...");
		return $objResponse;
	}
	function checkpage($allnum,$pagepernum,$thispage,$to1,$to2){
		$return="";
		$count=1;
		while($allnum>0){
			if($count==$thispage)
				$return.="<font color='#FF0000'><b>[$count]</b></font> ";
			else
				$return.="<a href='$to1$count$to2'>$count</a> ";
			$allnum-=$pagepernum;
			$count++;
		}
		return $return;
	}
	?>