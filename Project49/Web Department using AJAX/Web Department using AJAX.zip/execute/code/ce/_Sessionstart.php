﻿<?php 
	
		if(!isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online"){
			session_start();
			if( !isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online"){
				$_SESSION['ss_UserID']=0;
				$_SESSION['ss_UserName']="anonymous";
				$_SESSION['ss_Level']="guest";
				$_SESSION['ss_Status']="offline";
				$_SESSION['ss_privcode']="A";
				$_SESSION['ss_point']=100;
				$_SESSION['ss_LoginTime']=0;
			}
		}
?>