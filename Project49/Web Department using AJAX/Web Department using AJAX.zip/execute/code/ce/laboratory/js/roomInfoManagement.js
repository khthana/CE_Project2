function showFormEditRoomInfo(labID){
	if (!showFromCreateGroupflag){
			xajax_showFormEdit(labID);
			showFromCreateGroupflag=true;
	}
}
function editRoomInfo(labID){
	var formError=false;
	var showflagWeb= 0;
if (document.getElementById('labName').value=="" || document.getElementById('labAlias').value==""|| bodygl.innerHTML==""){
		formError="กรุณากรอกข้อมูลให้ครบทุกช่อง";
	}
	if (document.getElementsByName("uselinkflag")[0].checked){
		showflagWeb =document.getElementsByName("uselinkflag")[0].value;
	}else{
		showflagWeb =document.getElementsByName("uselinkflag")[1].value;
	}
	if (!formError){
		alert(formError);
		return false;
	}
	xajax_editRoomInfo(labID,document.getElementById("labName").value,document.getElementById("labAlias").value,document.getElementById("labLocation").value,bodygl.innerHTML,document.getElementById("weblink").value,showflagWeb);
}
function showFormAddRoom(){
	document.getElementById("laboratoryMenu").innerHTML="" ;
	document.getElementById("laboratoryMenuSearch").innerHTML="" ;
	document.getElementById("laboratoryDetail").innerHTML="" ;
	var form ="";
	form ="<table width='100%' border='1' bordercolor='#FFFFFF'  style='font-weight:normal;background: url(\"images/bglistMem.gif\");' cellpadding='0' cellspacing='1' >						<tr><td class='shd' >ชื่อห้องวิจัย</td><td > <input type='text' id ='labName' name='textfield' size='65' ></td></tr>						<tr><td class='shd' >ชื่อย่อห้องวิจัย</td><td > <input type='text' id ='labAlias' name='textfield' size='65' ></td></tr>						<tr><td class='shd' >ที่ตั้ง</td><td > <input type='text' id ='labLocation' name='textfield' size='65' ></td></tr>						<tr><td class='shdT'>จุดมุ่งหมายและรายละเอียด</td><td ><textarea id='labDetail' name='labaDetail' class='labDetailClass' cols='60' rows='10'></textarea></td></tr>";
	form +="<tr><td class='shdT'>ลิงค์ไปสู่เว็บไซด์ประจำห้อง</td><td> <input type='text' id ='weblink' name='textfield' size='65'></td></tr>						<tr><td class='shdT'>รูปแบบการแสดงข้อมูล</td><td>";
	form +="<input type='radio' name='uselinkflag' value='0' checked>  ใช้รูปแบบข้อมูลกลาง<input type='radio' name='uselinkflag' value='1'> ใช้เว็บไซด์ประจำห้อง";
	form +="</td></tr></table>";
	form +="<center><a href='javascript:void addRoom();' ><img src='images/add.gif' border='0' alt='add'></a></center>";

	document.getElementById("laboratory").innerHTML=form ;
	tinyMCE.addMCEControl(document.getElementById("labDetail"),"mce_topic");
	showFromCreateGroupflag=false;
}
function addRoom(){
	
	var formError=false;
	var showflagWeb= 0;
	if (document.getElementById('labName').value=="" || document.getElementById('labAlias').value==""|| bodygl.innerHTML==""){
		formError="กรุณากรอกข้อมูลให้ครบทุกช่อง";
		alert(formError);
		return false;
	}
	if (document.getElementsByName("uselinkflag")[0].checked){
		showflagWeb =document.getElementsByName("uselinkflag")[0].value;
	}else{
		showflagWeb =document.getElementsByName("uselinkflag")[1].value;
	}
	xajax_addRoom(document.getElementById("labName").value,document.getElementById("labAlias").value,document.getElementById("labLocation").value,bodygl.innerHTML,document.getElementById("weblink").value,showflagWeb);
}