var bodygl;
var messagegl="";

tinyMCE.init({
	mode : "none",
	theme : "advanced",
	plugins : "emotions,nonbreaking,preview,table",
	
	content_css : "css/mycontent.css",
	plugin_preview_width : "200",
	plugin_preview_height : "200",
	theme_advanced_buttons1 : "bold,italic,underline,separator,justifyleft,justifycenter,justifyright, justifyfull,indent,outdent,bullist,numlist,separator,hr,nonbreaking,link,unlink,image,forecolor,backcolor,separator",
	theme_advanced_buttons2 : "fontselect,fontsizeselect,charmap,emotions,newdocument,undo,redo,removeformat,preview",
	theme_advanced_buttons3 : "code,tablecontrols",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	setupcontent_callback : "myCustomSetupContent",
	theme_advanced_path_location : "bottom"
});


function myCustomSetupContent(editor_id, body, doc) {
	bodygl=body;
	if (body.innerHTML ==""){
		body.innerHTML = messagegl;
	}
	
}

