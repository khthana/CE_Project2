var showFromCreateGroupflag=false;
function showFromCreateGroup(labID){
		xajax_showFromCreateGroup(labID);
}
function addMemberGroupProject(labID){
	var memberIDs= Array ();
	for (var i=0;i< document.getElementsByName("selectedMem").length; i++){
		if (document.getElementsByName("selectedMem")[i].checked){
			memberIDs.push(document.getElementsByName("selectedMem")[i].value) 
		}
	}
	if (memberIDs.length==0){
		alert('กรุณาเลือกรายชื่อสมาชิก');
		return false;
	}else {
		if (!showFromCreateGroupflag){
			showFromCreateGroup(labID);
			showFromCreateGroupflag=true;
		}else{
			addlistGroup();
		}
	}
}
function addlistGroup(){
	var membersCheckBox= Array ();
	var membersName = Array();
	for (var i=0;i< document.getElementsByName("selectedMem").length; i++){
		if (document.getElementsByName("selectedMem")[i].checked){
			membersCheckBox.push(document.getElementsByName("selectedMem")[i]) ;
			membersName.push(document.getElementsByName("selectedMem")[i].nextSibling) ;
		}
	}

	for (var i = 0;i < membersCheckBox.length; i++){
			
			document.getElementById('memberGroup').innerHTML+='<br/><input type="checkbox" name="groupMember" value="' + membersCheckBox[i].value + '"/>';
			document.getElementById('memberGroup').appendChild(membersName[i].cloneNode(true));
			document.getElementById('memberGroup').innerHTML+='<span style="cursor:pointer;cursor:hand;color:blue" onclick="removeSelectMem()">&nbsp;&nbsp;&nbsp;&nbsp;[ลบ]</span>';
						
	}

	
}
function removeSelectMem(){
	
	var groupMembersCheckBox=Array();
	for (var i=0;i< document.getElementsByName("groupMember").length; i++){
		if (document.getElementsByName("groupMember")[i].checked){
			groupMembersCheckBox.push(document.getElementsByName("groupMember")[i]) ;
		}
	}
	for (var i=(groupMembersCheckBox.length-1);i>=0; i--){
			
			groupMembersCheckBox[i].parentNode.removeChild(groupMembersCheckBox[i].nextSibling.nextSibling);
			groupMembersCheckBox[i].parentNode.removeChild(groupMembersCheckBox[i].previousSibling);
			groupMembersCheckBox[i].parentNode.removeChild(groupMembersCheckBox[i].nextSibling);
			groupMembersCheckBox[i].parentNode.removeChild(groupMembersCheckBox[i]);
			
	}
}
function removeSelectAdviser(){
	var groupAdviserCheckBox=Array();
	for (var i=0;i< document.getElementsByName("groupAdviser").length; i++){
		if (document.getElementsByName("groupAdviser")[i].checked){
			groupAdviserCheckBox.push(document.getElementsByName("groupAdviser")[i]) ;
		}
	}
	for (var i=(groupAdviserCheckBox.length-1);i>=0; i--){
			
			
			groupAdviserCheckBox[i].parentNode.removeChild(groupAdviserCheckBox[i].nextSibling);
			groupAdviserCheckBox[i].parentNode.removeChild(groupAdviserCheckBox[i].nextSibling);
			groupAdviserCheckBox[i].parentNode.removeChild(groupAdviserCheckBox[i].previousSibling);
			groupAdviserCheckBox[i].parentNode.removeChild(groupAdviserCheckBox[i]);
			
	}
}
function addAdviser(){
	var adviserID= document.getElementById('adviserName').value;
	var adviserName = document.getElementById('adviserName').options[document.getElementById('adviserName').selectedIndex].text;
	document.getElementById('advicsor').innerHTML+='<br/><input type="checkbox" name="groupAdviser" value="'+adviserID+'">';
	document.getElementById('advicsor').innerHTML+=adviserName;		
	document.getElementById('advicsor').innerHTML+='<span style="cursor:pointer;cursor:hand;color:blue" onclick="removeSelectAdviser()">&nbsp;&nbsp;&nbsp;&nbsp;[ลบ]</span>';
}
function serchAdviserJS(){
	if (document.getElementById("keyName").value!=""){
		xajax_searchNameAddviser(document.getElementById("caption").value,document.getElementById("keyName").value);
	}
}
function createGroupProject(labID){
	var formError=false;
	var membersID=Array();
	var lectuerersID=Array();
	if (document.getElementById('abstractENG').value=="" || document.getElementById('abstractTH').value==""|| document.getElementById('titleENG').value==""||document.getElementById('titleTH').value==""|| document.getElementById('year').value==""){
		formError="กรุณากรอกข้อมูลให้ครบทุกช่อง";
	}
	if (isNaN(document.getElementById('year').value)){
		formError="กรุณากรอกข้อมูลปีการศึกษาให้อยู่ในรูปตัวเลข";
	}
	if ( document.getElementsByName("groupAdviser").length==0){
		formError="กรุณาระบุอาจารย์ที่ปรึกษา";
	}else{
		for (var i=0;i < document.getElementsByName("groupAdviser").length;i++ ){
			lectuerersID.push(document.getElementsByName("groupAdviser")[i].value) 
		}
	}
	if ( document.getElementsByName("groupMember").length==0){
		formError="กรุณาระบุสมาชิกกลุ่ม";
	}else{
		for (var i=0;i < document.getElementsByName("groupMember").length;i++ ){
			membersID.push(document.getElementsByName("groupMember")[i].value) ;
		}
	}
	if (formError){
		alert(formError);
		return false;
	}
	xajax_createGroup(membersID,document.getElementById('titleTH').value,document.getElementById('titleENG').value,document.getElementById('abstractTH').value,document.getElementById('abstractENG').value,document.getElementById('year').value,lectuerersID,labID)
	//xajax_createGroup(membersID,labID);
}