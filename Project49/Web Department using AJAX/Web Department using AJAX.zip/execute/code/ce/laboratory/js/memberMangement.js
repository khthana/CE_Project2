
function changePage(labID){
	xajax_getListMemberRoom(labID,document.getElementById("changeBox").value);
}
function changeLevel(userID,labID){
				if(confirm('คุณต้องการแก้ไขข้อมูลหรือไม่...')){
					xajax_changeLevel(userID,labID,xajax.$("lvMem"+userID).value);
				}
}
function removeMember(labID){
	var memberIDs= Array ();
	for (var i=0;i< document.getElementsByName("selectedMem").length; i++){
		//alert (document.getElementsByName("selectedMem")[i].value);
		if (document.getElementsByName("selectedMem")[i].checked){
			memberIDs.push(document.getElementsByName("selectedMem")[i].value) 
		}
	}
	if (memberIDs.length==0){
		alert('กรุณาเลือกรายชื่อสมาชิก');
		return false;
	}
	if(confirm('คุณต้องการย้ายสมาชิกที่เลือกไว้ออกหรือไม่..')){
					xajax_removeMember(labID,memberIDs);
	}
	
}
