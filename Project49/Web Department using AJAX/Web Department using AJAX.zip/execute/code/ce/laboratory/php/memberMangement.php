<?php
function changeLevel($userID,$labID,$level){
	$objResponse = new xajaxResponse();
	$comSQLUpdateLevel="UPDATE laboratory_member SET LEVEL='$level' WHERE LAB_ID=$labID AND USER_ID=$userID";
	mysql_query($comSQLUpdateLevel);
	if (!mysql_error()){
		$objResponse->addAlert(iconv("tis-620","utf-8","�������¹�дѺ�Է����������"));
	}else {
		$objResponse->addAlert(mysql_error().$comSQLUpdateLevel);
	}
	return $objResponse;
}
function removeMember($labID,$arrayMember){
	$objResponse = new xajaxResponse();
	$adminRoomFlag=false;
	$checkAdminresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
	if ($checkrow=mysql_fetch_array($checkAdminresult)){
				$adminRoomFlag=true;
	}else{
		$objResponse->addAlert(iconv("tis-620","utf-8","��ҹ������Է���㹡������¹�ŧ"));
		return $objResponse;
	}
	foreach ($arrayMember as $memberID){
		if (!(deleteMember($memberID,$labID) and changePriv($memberID,$labID))){
			$objResponse->addAlert(mysql_error());
			return $objResponse;
		}else {
		}
	}	$objResponse->addScript("alert('".iconv("tis-620","utf-8","�ӡ�����ª�����Ҫԡ�͡���º��������")."');xajax_getListMemberRoom($labID,1);");	
	return $objResponse;
}
function deleteMember($userID,$labID){
	$comSQLdeleteMemRoom = "DELETE FROM laboratory_member  WHERE USER_ID =$userID AND LAB_ID=$labID";
	mysql_query($comSQLdeleteMemRoom );
	if (!mysql_error()){
		return true;
	}else {
		return false;
	}	
}
function changePriv($userID,$labID){
	$comSQLgetRoomPrivCode = "SELECT CODE_ROOM FROM laboratory WHERE LAB_ID=$labID";
	$roomprivcode=mysql_fetch_array(mysql_query($comSQLgetRoomPrivCode));
	$comSQLgetUserPrivCode = "SELECT USER_PRIV_CODE,LEVEL FROM useraccount  WHERE USER_ID=$userID";
	$userprivcode=mysql_fetch_array(mysql_query($comSQLgetUserPrivCode));
	if ($userprivcode[1]=='admin') return true;
	$newPrivCode= str_replace($roomprivcode[0], "", $userprivcode[0]);
	$comSQLUpdatePrivCode="UPDATE useraccount SET USER_PRIV_CODE='".$newPrivCode."' WHERE USER_ID=$userID";
	mysql_query($comSQLUpdatePrivCode);
	if (!mysql_error()){
		return true;
	}else {
		return false;
	}	
}
?>