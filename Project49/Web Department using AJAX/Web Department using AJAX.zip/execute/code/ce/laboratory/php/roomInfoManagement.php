<?php
function showFormEdit($labID){
		$objResponse = new xajaxResponse();
		$checkAdminresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
	if ($checkrow=mysql_fetch_array($checkAdminresult)){
		$comSQLgetDefaultInfo="SELECT * FROM laboratory WHERE LAB_ID=".$labID;
		$getDefaultInforesult = mysql_query($comSQLgetDefaultInfo);
		if ($labrow=mysql_fetch_array($getDefaultInforesult)){
				$return="<table width='100%' style='font-weight:normal;background: url(\"images/leftbg.gif\");' cellpadding='0' cellspacing='0' >
						<tr><td class='shd' >".iconv("tis-620","utf-8","������ͧ�Ԩ��")."</td><td > <input type='text' id ='labName' name='textfield' size='65' value='".$labrow["NAME"]."'></td></tr>
						<tr><td class='shd' >".iconv("tis-620","utf-8","���������ͧ�Ԩ��")."</td><td > <input type='text' id ='labAlias' name='textfield' size='65' value='".$labrow["ALIAS"]."'></td></tr>
						<tr><td class='shd' >".iconv("tis-620","utf-8","�����")."</td><td > <input type='text' id ='labLocation' name='textfield' size='65' value='".$labrow["PLACE"]."'></td></tr>
						<tr><td class='shd'>".iconv("tis-620","utf-8","�ش������������������´")."</td><td ><textarea id='labDetail' name='labaDetail' class='labDetailClass' cols='65' rows='10'>".$labrow["DETAIL"]."</textarea></td></tr>";
				$return.="
						<tr><td class='shd'>".iconv("tis-620","utf-8","�ԧ���������䫴��Ш���ͧ")."</td><td> <input type='text' id ='weblink' name='textfield' size='65' value='".$labrow["LINK"]."'></td></tr>
						<tr><td class='shd'>".iconv("tis-620","utf-8","�ٻẺ����ʴ�������")."</td><td>";
				if ($labrow["SHOW_PRI_LINK"]==0){
					$return.="
						<input type='radio' name='uselinkflag' value='0' checked>  ".iconv("tis-620","utf-8"," ���ٻẺ�����š�ҧ ")."<input type='radio' name='uselinkflag' value='1'>".iconv("tis-620","utf-8"," �����䫴��Ш���ͧ ");
				}else {
					$return.="
						<input type='radio' name='uselinkflag' value='0'>  ".iconv("tis-620","utf-8"," ���ٻẺ�����š�ҧ ")."<input type='radio' name='uselinkflag' value='1' checked>".iconv("tis-620","utf-8"," �����䫴��Ш���ͧ ");
				}
				$return.="</td></tr>";
				$return.="<tr><td colspan='2' align='center'><hr width='400px' /><center><a href='javascript:void editRoomInfo(".$labID.");' ><img src='images/edit.gif' border='0' alt='edit'></a></center></td></tr></table>";
				$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
				$objResponse->addScript('tinyMCE.addMCEControl(document.getElementById("labDetail"),"mce_topic");');
			}
		}else {
			$objResponse->addAlert(iconv("tis-620","utf-8","��ҹ������Է���㹡����Ҷ֧"));
		}
		return $objResponse;
}
function editRoomInfo($labID,$labName,$labAlias,$labLocation,$labDetail,$weblink,$flagShowWeb){
	$objResponse = new xajaxResponse();
	if($labLocation=="") $labLocation="NULL";
	if($weblink=="") $weblink="NULL";
	$checkAdminresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
	if ($checkrow=mysql_fetch_array($checkAdminresult)){
			$comSQLupdateRoomInfo="UPDATE laboratory SET ".
																	" NAME='$labName'".
																	",ALIAS='$labAlias'".
																	",PLACE='$labLocation'".
																	",DETAIL='$labDetail'".
																	",SHOW_PRI_LINK=$flagShowWeb".	
																	",LINK='$weblink'";
			$comSQLupdateRoomInfo.="  WHERE LAB_ID=".$labID;
			mysql_query($comSQLupdateRoomInfo);
	}else {
			$objResponse->addAlert(iconv("tis-620","utf-8","��ҹ������Է���㹡�����"));
	}	
	if (!mysql_error()){
		$objResponse->addAlert(iconv("tis-620","utf-8","������º����"));
		$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
		$objResponse->addScript("showFromCreateGroupflag=false;");
	}else{
		$objResponse->addAlert(mysql_error());
	}
	return $objResponse;										
}
function addRoom($labName,$labAlias,$labLocation,$labDetail,$weblink,$flagShowWeb){
	$objResponse = new xajaxResponse();
	if ($_SESSION['ss_Level']!="admin") {
		$objResponse->addAlert(iconv("tis-620","utf-8","��ҹ������Է�����ҹ���ǹ���"));
		return $objResponse;	
	}

	$comSQLgetPrivCode="SELECT MAX(CODE_ROOM),MAX(LAB_ID ) FROM laboratory";
	$getPrivCoderesult = mysql_query($comSQLgetPrivCode);
	if ($raw=mysql_fetch_array($getPrivCoderesult)){
		$privCode=chr(ord($raw[0])+1);
		$labID=$raw[1]+1;
	}else{
		$privCode="C";
		$labID=1;
	}

	$comSQLInsertRoom="INSERT INTO laboratory  SET ".
			" LAB_ID=".$labID.
			", NAME='".$labName."'".
			", ALIAS='".$labAlias."'".
			", PLACE='".$labLocation."'".
			", DETAIL='".$labDetail."'".
			", LINK='".$weblink."'".
			", CODE_ROOM='".$privCode."'".
			", SHOW_PRI_LINK=".$flagShowWeb;
	mysql_query($comSQLInsertRoom);
	if (!mysql_error()){
		$comSQLInsertMember = "INSERT INTO laboratory_member SET ".
			" LAB_ID=".$labID.
			", USER_ID=".$_SESSION['ss_UserID'].
			", LEVEL='admin'";
		mysql_query($comSQLInsertMember);
		$adminprivcode ="AB";
		$comSQLgetPrivCode = "SELECT CODE_ROOM  FROM laboratory  ";
		$result=mysql_query($comSQLgetPrivCode);
		while ($allprivcode=mysql_fetch_array($result)){
				$adminprivcode.=$allprivcode[0];
		}
		$comSQLUpdateAdminPriCode="UPDATE useraccount SET USER_PRIV_CODE='".$adminprivcode."' WHERE LEVEL ='admin'";
		mysql_query($comSQLUpdateAdminPriCode);
	}else{
		$objResponse->addAlert(mysql_error());
		return $objResponse;	
	}
	$objResponse->addAlert(iconv("tis-620","utf-8","�ӡ��������������ͧ�Ԩ�����º��������"));
	return $objResponse;	
}
?>