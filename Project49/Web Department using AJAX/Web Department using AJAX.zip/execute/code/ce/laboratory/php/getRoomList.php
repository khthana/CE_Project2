<?php

function list_lab(){

	$objResponse = new xajaxResponse();
	$return ="<div  class='submenu' ><a href='javascript:void xajax_list_lab();'>&nbsp;&nbsp;&nbsp;&nbsp;หน้าหลัก&nbsp;&nbsp;&nbsp;</a><a href='javascript:void xajax_menu_search();'>&nbsp;&nbsp;หัวข้อโครงงาน&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
	if ($_SESSION['ss_Level']=="admin"){
			$return .="<a href='javascript:void showFormAddRoom();'>&nbsp;&nbsp;เพิ่มห้องวิจัย&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
	}
	$return .="<BR><BR></div>";
	$objResponse->addAssign("laboratorymain","innerHTML",$return);

	$comSQLgetRoomList="SELECT LAB_ID,NAME,LINK,SHOW_PRI_LINK FROM laboratory  ";
	if($getRoomListresult=mysql_query($comSQLgetRoomList)){
		$return ="<ol type='1' class='list'>";

		$sql="SELECT LAB_ID,LEVEL FROM laboratory_member WHERE USER_ID=".$_SESSION['ss_UserID'];
		$result=mysql_fetch_array(mysql_query($sql));

		while($labRow=mysql_fetch_array($getRoomListresult)){

				if ($result['LEVEL'] == 'admin' && $result['LAB_ID'] == $labRow['LAB_ID']){
				
					$return .= "<li><a href='javascript:void(0)' onclick=\"xajax_getLab(".$labRow['LAB_ID'].");\">".$labRow['NAME']."</a></li>";
				
				}
				else{

					if ($labRow['SHOW_PRI_LINK'] == 0){
				
						$return .= "<li><a href='javascript:void(0)' onclick=\"xajax_getLab(".$labRow['LAB_ID'].");\">".$labRow['NAME']."</a></li>";
					}
					else{
				
						$return .= "<li><a href='".$labRow['LINK']."' target='_blank'>".$labRow['NAME']."</a></li>";
				
					}
				}
				
		}

		$return .= "</ol>";
	}

	$objResponse->addAssign("laboratory","innerHTML",$return);
	$objResponse->addAssign("laboratoryMenu","innerHTML","");
	$objResponse->addAssign("laboratoryDetail","innerHTML","");
	$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
	$objResponse->addAssign("laboratoryMenuSearch","innerHTML","");
	$objResponse->addScript("showFromCreateGroupflag=false;");

	return $objResponse;
}

?>