<?php
function checkAuthenAdminRoom($userIDAdminRoom,$labID){
	$comSQLcheckAdminRoomr="SELECT * FROM laboratory_member   WHERE USER_ID=".$userIDAdminRoom." AND LAB_ID=".$labID." AND LEVEL='admin'";
	$checkresult=mysql_query($comSQLcheckAdminRoomr);
	return $checkresult;
}
?>