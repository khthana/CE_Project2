<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
include("checkAuthenAdmin.php");
$cp = new cpaint();
$cp->register('addMember');
$cp->start();
$cp->return_data();
function addMember($userID,$labID){
	global $cp;
	connectdb();
	$responseNode =&$cp->add_node('response');
	$responseMsgNode =&$cp->add_node('responseMsg');
	$checkAdminresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
	if ($memberrow=mysql_fetch_array($checkAdminresult)){
		$comSQLInsertMember = "INSERT INTO laboratory_member SET ".
			" LAB_ID=".$labID.
			", USER_ID=".$userID.
			", LEVEL='member'";
		mysql_query($comSQLInsertMember);
		
		if (! mysql_error()){
			$comSQLgetRoomPrivCode = "SELECT CODE_ROOM FROM laboratory WHERE LAB_ID=$labID";
			$roomprivcode=mysql_fetch_array(mysql_query($comSQLgetRoomPrivCode));
			$comSQLgetUserPrivCode = "SELECT USER_PRIV_CODE FROM useraccount  WHERE USER_ID=$userID";
			$userprivcode=mysql_fetch_array(mysql_query($comSQLgetUserPrivCode));
			$comSQLUpdatePrivCode="UPDATE useraccount SET USER_PRIV_CODE='".$userprivcode[0].$roomprivcode[0]."' WHERE USER_ID=$userID";
			mysql_query($comSQLUpdatePrivCode);
			$responseNode->set_data("sucess");
			$responseMsgNode->set_data("บันทึกการเพิ่มชื่อสมาชิกเสร็จสิ้นแล้ว");
		}else{
			$responseNode->set_data("duplicate");
			$responseMsgNode->set_data("สมาชิกท่านนี้อยู่ในสังกัดของท่านอยู่แล้ว");
		}
	}else {
		$responseNode->set_data("Not Authorize");
		$responseMsgNode->set_data("ขออภัย ท่านไม่มีสิทธิ์ในการเพิ่มรายชื่อ");
	}
}

?>