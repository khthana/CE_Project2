<?php
function showFromCreateGroup($labID){
		$objResponse = new xajaxResponse();
		$return="<br/><table width='100%' border='0' style='font-weight:normal;background: url(\"images/leftbg.gif\");' cellpadding='0' cellspacing='0' ><tr><td colspan='2' style='padding:8px 4px;font-weight:bold;text-align:center;border-bottom:1px solid #FFFFFF;'>สร้างกลุ่มและหัวข้อโครงงาน</td></tr><tr><td class='shd' valign='top' width='30%'>สมาชิกกลุ่ม</td><td id='memberGroup' ></td></tr><tr><td class='shd' valign='top'>ชื่อโครงงาน(ไทย)</td><td > <input type='text' id ='titleTH' name='textfield' size='65'></td></tr>	<tr><td class='shd' valign='top' >ชื่อโครงงาน(อังกฤษ)</td><td > <input type='text' id ='titleENG' name='textfield' size='65'></td></tr><tr><td class='shdT' valign='top'>บทคัดย่อ(ไทย)</td><td ><textarea id='abstractTH' name='abstractTH' cols='50' rows='10'></textarea></td></tr>";		
		
		$return.="<tr><td class='shdT' valign='top'>บทคัดย่อ(อังกฤษ)</td><td> <textarea id='abstractENG' name='abstractENG' cols='50' rows='10'></textarea></td></tr><tr><td class='shd' valign='top'>ปีการศึกษา</td><td><span ><input type='text' id='year' name='textfield' size='6'></span></td></tr><tr><td class='shd' valign='top'>รายชื่ออาจารย์ที่ปรึกษา</td ><td > <table width='100%' border='0' cellpadding='0' cellspacing='0' ><tr><td><select id='caption'><option value='รศ.ดร.'>รศ.ดร.</option><option value='รศ.'>รศ</option><option value='ผศ.ดร.'>ผศ.ดร.</option>		<option value='ผศ.'>ผศ.</option><option value='ดร.'>ดร.</option><option value='อ.'>อ.</option></select><input type='text' id='keyName' name='txtkeyword'  onKeyUp='serchAdviserJS()' size='10'><span id='searchResult'><select ><option>รายชื่อที่ปรึกษา</option></select></span></td></tr><tr><td id='advicsor' ></td></tr></table></td></tr><tr><td id='ed' colspan='2' style='padding:8px 4px;font-weight:bold;text-align:center;'><hr width='350px' />";

		$return.="<a href='javascript:void createGroupProject(".$labID.");' ><img src='images/submit.gif' border='0' alt='submit'></a></td></tr></table>";
		$objResponse->addAssign("laboratoryAddGroup","innerHTML",$return);
		$objResponse->addScript("addlistGroup();");

		return $objResponse;
}
function searchNameAddviser($caption,$fullname){
	//onKeyPress='xajax_searchNameAddviser(document.getElementById(\"caption\").value,document.getElementById(\"keyName\").value)'
	$objResponse = new xajaxResponse();
	$firstname="";
	$lastname="";
	if ($fullname=="") return $objResponse;
	if (strpos($fullname," ") > 0){
		list($firstname,$lastname) = explode(" ",$fullname);
	}else {
		$firstname=$fullname;
		$lastname="";
	}
	if ($lastname!=""){
		$comSQLgetlistAdviser= "SELECT * FROM lecturer WHERE CAPTION LIKE '%$caption%' AND NAME LIKE '%$firstname%' AND  SERNAME LIKE '%$lastname%'";
	}else{
		$comSQLgetlistAdviser= "SELECT * FROM lecturer WHERE CAPTION LIKE '%$caption%' AND NAME LIKE '%$firstname%' ";
	}
	$listAdviserresult= mysql_query($comSQLgetlistAdviser);
	$return="<select id=adviserName>";
	while($adviser=mysql_fetch_array($listAdviserresult)){
		$return.="<option value='".$adviser["LECTURER_ID"]."'>";
		$return.=$adviser["CAPTION"]." ".$adviser["NAME"]." ".$adviser["SERNAME"];
		$return.="</option>";
	}
	$return.="</select>";
	$return.="&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void addAdviser();' >เพิ่ม</a>";
	$objResponse->addAssign("searchResult","innerHTML",$return);
	
	return $objResponse;
}
function createGroup($membersID,$titleTH,$titleENG,$abstractTH,$abstractENG,$year,$lectuerersID,$labID){

	$objResponse = new xajaxResponse();
	$adminRoomFlag=false;
	$checkAdminresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
	if ($checkrow=mysql_fetch_array($checkAdminresult)){
				$adminRoomFlag=true;
	}else{
		$objResponse->addAlert("ท่านไม่มีสิทธิ์ในการเปลี่ยนแปลง");
		return $objResponse;
	}
	$comSQLgetMAXgroupID="SELECT MAX(GROUP_ID) FROM group_project  ";
	$maxIDresult= mysql_query($comSQLgetMAXgroupID);
	$maxGroupID=mysql_fetch_array($maxIDresult);
	$groupID=$maxGroupID[0]+1;
	$comSQLInsertGroup="INSERT INTO group_project  SET ".
			" GROUP_ID=".$groupID.
			", ABSTRACT_TH='".$abstractTH."'".
			", ABSTRACT_ENG='".$abstractENG."'".
			", TOPIC_NAME_TH='".$titleTH."'".
			", TOPIC_NAME_ENG='".$titleENG."'".
			", YEAR=".$year.
			", LAB_ID=".$labID;
	mysql_query($comSQLInsertGroup);
	if (!mysql_error()){
			for ($i=0;$i<count($membersID);$i++){
				$comSQLInsertGroupMember="INSERT INTO group_project_member   SET ".
			" GROUP_ID=".$groupID.
			",USER_ID=".$membersID[$i];
			mysql_query($comSQLInsertGroupMember);
			}
			
			for ($i=0;$i<count($lectuerersID);$i++){
				$comSQLInsertGroupAdviser="INSERT INTO group_project_advicor    SET ".
			" GROUP_ID=".$groupID.
			",LECTURER_ID=".$lectuerersID[$i];
			mysql_query($comSQLInsertGroupAdviser);
			}
			$objResponse->addAlert("ทำการสร้างกลุ่มโครงงานเสร็จเรียบร้อยแล้ว");
			$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
			$objResponse->addScript("showFromCreateGroupflag=false;");
	}else {
		$objResponse->addAlert("เกิดความผิดพลาดในการเก็บลงฐานข้อมูล");
		$objResponse->addAlert(mysql_error());
	}
	return $objResponse;
}
?>