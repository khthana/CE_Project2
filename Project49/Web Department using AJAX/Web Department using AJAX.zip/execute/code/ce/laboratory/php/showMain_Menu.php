<?php
function createLabMenu($lab_id){
		$objResponse = new xajaxResponse();

		$return="<div class='submenu'>
				<a href='javascript:void xajax_list_lab();'>&nbsp;&nbsp;&nbsp;&nbsp;หน้าหลัก&nbsp;&nbsp;&nbsp;</a>
				<a href='javascript:void xajax_getLab($lab_id);'>&nbsp;&nbsp;รายละเอียดห้องวิจัย&nbsp;&nbsp;&nbsp;</a>
				<a href='javascript:void xajax_getListMemberRoom($lab_id,1);'>&nbsp;&nbsp;รายชื่อสมาชิก&nbsp;&nbsp;&nbsp;</a>";
		$checkresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$lab_id);
			if ($checkrow=mysql_fetch_array($checkresult)){
				$return.="<a href='javascript:void showFormEditRoomInfo($lab_id);'>&nbsp;&nbsp;แก้ไขข้อมูลห้องวิจัย&nbsp;</a>";
		}
		$return.="<br><br></div>";
				
		$objResponse->addAssign("laboratoryMenu","innerHTML",$return);
		return $objResponse;
}

function getLab($labID){
	
	$objResponse = new xajaxResponse();


	$objResponse->addScript("xajax_createLabMenu($labID);");


	$sql="SELECT NAME,PLACE,DETAIL,LINK FROM laboratory WHERE LAB_ID =".$labID;
	$result=mysql_query($sql);
	if($temp = mysql_fetch_array($result)){
		
			$return = "<div class='lab'><p style='font-weight:bold;'>".$temp['NAME']."</p><p><strong>สถานที่&nbsp;&nbsp;</strong>".$temp['PLACE']."</p><p><strong>รายละเอียด&nbsp;&nbsp;</strong><br/><br/>".$temp['DETAIL']."</p><p><strong>Webห้องวิจัย&nbsp;&nbsp;</strong>"."<a href='".$temp['LINK']."'>".$temp['LINK']."</a></p></div>";
		
	}

	$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
	$objResponse->addAssign("laboratory","innerHTML","");
	$objResponse->addAssign("laboratorymain","innerHTML","");
	$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
	$objResponse->addAssign("laboratoryMenuSearch","innerHTML","");
	$objResponse->addScript("showFromCreateGroupflag=false;");
	return $objResponse;

}


function getProject($lecID,$page){

	$objResponse = new xajaxResponse();

	$start = (($page - 1) * 20);

	if($lecID == -1){
	
		$sql  ="SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID";

		$sql_ ="SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID";
	}
		
	else{
	
		$sql  ="SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE  t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";

		$sql_ ="SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE  t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";
	}
		
	$sql .=" ORDER BY YEAR DESC LIMIT ".$start.",20";

	$result=mysql_query($sql);

	$return = "<div class='project'><table>";

	while($temp = mysql_fetch_array($result)){

		$return .="<tbody><tr><td class='header'>ชื่อโครงงาน(ไทย)</td><td class='detail'><a href='javascript:void(0)' onclick=\"xajax_getData(".$temp['GROUP_ID'].",'all',".$lecID.",'','all',0,".$page.",1);\">".$temp['TOPIC_NAME_TH']."</a></td></tr><tr><td class='header'>ชื่อโครงงาน(อังกฤษ)</td><td class='detail'>".$temp['TOPIC_NAME_ENG']."</td></tr><tr><td class='header'>ปี</td><td class='detail'>".$temp['YEAR']."</td></tr><tr><td class='header'>ห้องวิจัย</td><td class='detail'>".$temp['NAME']."</td></tr><tr><td colspan='2'><hr/></td></tr></tbody>";

		
	}

	$return .="</table></div><div class='page'>";
	
	$result = mysql_fetch_array(mysql_query($sql_));

	$page_total = ceil($result[0]/20); 
	
	if ($page_total > 0){

		$return .= "หน้า&nbsp;&nbsp;&nbsp;&nbsp;";
			
		if ($page_total <= 7 and $page <= 7)				
			$return .= createpage(1,$page_total,$page,$lecID);
		else if ($page_total > 7 and $page <= 7)
			$return .= createpage(1,7,$page,$lecID);
		else if($page > 7 and $page < ($page_total - 2))
			$return .= createpage($page - 3,$page + 3,$page,$lecID);
		else 
			$return .= createpage($page_total - 2,$page_total,$page,$lecID);
	}

	$return .="</div>";

	$objResponse->addAssign("laboratory","innerHTML","");
	$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
	$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
	$objResponse->addScript("showFromCreateGroupflag=false;");
	return $objResponse;

}

function createpage($beginpage,$endpage,$page,$lecID){
		
		$string="";
		for($i = $beginpage;$i <= $endpage;$i++){
			if ($i == $page)
				$string = $string . "<span >[" . $i . "]</span>&nbsp;&nbsp;&nbsp;&nbsp;";
			else
				$string = $string . "<span style='cursor:pointer;cursor:hand;'  onclick=\"xajax_getProject($lecID," . $i . ");\">" . $i . "</span>&nbsp;&nbsp;&nbsp;&nbsp;";
		}
			
		return $string;
}

function getData($gpID,$labID,$lecID,$text,$year,$lang,$page,$type){

	$objResponse = new xajaxResponse();

	$string ="";
	
	if($labID =='all'){
		$sql="SELECT ABSTRACT_TH,ABSTRACT_ENG,TOPIC_NAME_TH,TOPIC_NAME_ENG,YEAR FROM group_project WHERE GROUP_ID =".$gpID;
	}
	else{
		$sql="SELECT ABSTRACT_TH,ABSTRACT_ENG,TOPIC_NAME_TH,TOPIC_NAME_ENG,YEAR FROM group_project WHERE LAB_ID =".$labID." AND GROUP_ID =".$gpID;
	}

	$result = mysql_query($sql);

	if($temp = mysql_fetch_array($result)){


		$string ="<table class='data' width='100%'><tbody><tr><td width='20%' valign='top'>หัวข้อโครงงาน</td><td style='font-weight:normal' >".$temp['TOPIC_NAME_TH']."<br/>".$temp['TOPIC_NAME_ENG']."</td></tr>";

		$sql="SELECT LECTURER_ID FROM group_project_advicor WHERE GROUP_ID =".$gpID;
		$result=mysql_query($sql);
		$string .=  "<tr><td valign='top'>อาจารย์ที่ปรึกษา</td><td style='font-weight:normal'>";
		while($temp_1 = mysql_fetch_array($result)){
		
			$sql="SELECT CAPTION,NAME,SERNAME FROM lecturer WHERE  LECTURER_ID=".$temp_1["LECTURER_ID"];
			$result_1=mysql_fetch_array(mysql_query($sql));
		
			$string .="<a href=\"../lecturer/lecturerdetail.php?lec_id=".$temp_1["LECTURER_ID"]."\" target='_blank'>".$result_1['CAPTION'].$result_1['NAME']."  ".$result_1['SERNAME']."</a><br/>";	
			
		}
		$string .= "</td></tr>";
		$sql="SELECT USER_ID FROM group_project_member WHERE GROUP_ID =".$gpID;
		$result = mysql_query($sql);
		$string .= "<tr><td valign='top'>รายชื่อนักศึกษา</td><td style='font-weight:normal'>";
		while($temp_1 = mysql_fetch_array($result)){
		
			$sql = "SELECT TITLE,FIRST_NAME,LAST_NAME FROM useraccount WHERE  USER_ID=".$temp_1["USER_ID"];
			$result_1 = mysql_fetch_array(mysql_query($sql));
		
			$string .= $result_1['TITLE'].$result_1['FIRST_NAME']."   ".$result_1['LAST_NAME']."<br/>";
			
		}

		
		$string .="</td></tr>";
		
		$string .="<tr><td valign='top'>บทคัดย่อ</td><td style='font-weight:normal'>".$temp['ABSTRACT_TH']."</td>";
		$string .="<tr><td valign='top'>abstract</td><td style='font-weight:normal'>".$temp['ABSTRACT_ENG']."</td>";
		$string .="</tbody></table><br/>";
	}

	if($type == 1)
		$string .="<div align='center'><a href='javascript:void xajax_getProject(".$lecID.",".$page.")'>กลับ</a></div>";
	else if($type == 0)
		$string .="<div align='center'><a href=\"javascript:void xajax_search_1('".$labID."','".$text."','".$year."',".$lang.",".$page.")\">กลับ</a></div>";
	else if($type == 2)
		$string .="<div align='center'><a href=\"javascript:void xajax_search_2('".$lecID."','".$year."',".$page.")\">กลับ</a></div>";

	$objResponse->addAssign("laboratoryDetail","innerHTML",$string);
	return $objResponse;
}

function search_1($labID,$text,$year,$lang,$page){

	$objResponse = new xajaxResponse();

	$start = (($page - 1) * 20);

	if($text != ""){
	
		if($labID =='all'){
			$sql  ="SELECT GROUP_ID,TOPIC_NAME_TH,TOPIC_NAME_ENG,YEAR FROM group_project WHERE 1 ";
			$sql_ ="SELECT COUNT(GROUP_ID) FROM group_project WHERE 1 ";
		}
		else{
			$sql  ="SELECT GROUP_ID,TOPIC_NAME_TH,TOPIC_NAME_ENG,YEAR FROM group_project WHERE LAB_ID=".$labID;
			$sql_ ="SELECT  COUNT(GROUP_ID) FROM group_project WHERE LAB_ID=".$labID;
		}

		if($year !='all'){
			$sql  .=" AND YEAR =".$year;
			$sql_ .=" AND YEAR =".$year;
		}

		if($lang == 0){
			$sql .=" AND TOPIC_NAME_TH LIKE '%".$text."%'";
			$sql_ .=" AND TOPIC_NAME_TH LIKE '%".$text."%'";
		}
		else{
			$sql .=" AND TOPIC_NAME_ENG LIKE '%".$text."%'";
			$sql_ .=" AND TOPIC_NAME_ENG LIKE '%".$text."%'";
		}
			

		$sql .=" LIMIT ".$start.",20";

		$result = mysql_query($sql);

		$return = "<div class='project'><table>";

		while($temp = mysql_fetch_array($result)){

			$return .="<tbody><tr><td class='header'>ชื่อโครงงาน(ไทย)</td><td class='detail'><a href='javascript:void(0)' onclick=\"xajax_getData(".$temp['GROUP_ID'].",'".$labID."',-1,'".$text."','".$year."',".$lang.",".$page.",0);\">".$temp['TOPIC_NAME_TH']."</a></td></tr><tr><td class='header'>ชื่อโครงงาน(อังกฤษ)</td><td class='detail'>".$temp['TOPIC_NAME_ENG']."</td></tr><tr><td class='header'>ปี</td><td class='detail'>".$temp['YEAR']."</td></tr><tr><td colspan='2'><hr/></td></tr></tbody>";

		
		}

		$return .="</table></div><div class='page'>";
		$result = mysql_fetch_array(mysql_query($sql_));

		$page_total = ceil($result[0]/20); 
	
		if ($page_total > 0){

			$return .= "หน้า&nbsp;&nbsp;&nbsp;&nbsp";

			if ($page_total <= 7 and $page <= 7)				
				$return .= createpage_search_1(1,$page_total,$page,$labID,$text,$year,$lang);
			else if ($page_total > 7 and $page <= 7)
				$return .= createpage_search_1(1,7,$page,$labID,$text,$year,$lang);
			else if($page > 7 and $page < ($page_total - 2))
				$return .= createpage_search_1($page - 3,$page + 3,$page,$labID,$text,$year,$lang);
			else 
				$return .= createpage_search_1($page_total - 2,$page_total,$page,$labID,$text,$year,$lang);
		}

		$return .="</div>";

		$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
		return $objResponse;
	}
	else{
	
		$objResponse->addAssign("laboratoryDetail","innerHTML","");
		return $objResponse;
	}

}

function createpage_search_1($beginpage,$endpage,$page,$labID,$text,$year,$lang){

		$string="";
		for($i = $beginpage;$i <= $endpage;$i++){
			if ($i == $page)
				$string = $string . "<span >[" . $i . "]</span>&nbsp;&nbsp;&nbsp;&nbsp;";
			else
				$string = $string . "<span style='cursor:pointer;cursor:hand;'  onclick=\"xajax_search_1('".$labID."','".$text."','".$year."',".$lang."," . $i . ");\">" . $i . "</span>&nbsp;&nbsp;&nbsp;&nbsp;";

		}

		return $string;
}

function search_2($lecID,$year,$page){

	$objResponse = new xajaxResponse();

	$start = (($page - 1) * 20);

	if($lecID =='all' && $year =='all'){

			$sql  ="SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE  t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor GROUP BY GROUP_ID)";

			$sql_ ="SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE  t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor GROUP BY GROUP_ID)";

	}
	else if($lecID !='all' && $year =='all'){
		
			$sql = "SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";

			$sql_ = "SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";
	}
	else if($lecID =='all' && $year !='all'){
		
			$sql = "SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE year=".$year." AND t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor GROUP BY GROUP_ID)";

			$sql_ = "SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE year=".$year." AND t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor GROUP BY GROUP_ID)";
	}
	else{
	
			$sql = "SELECT GROUP_ID, TOPIC_NAME_TH, TOPIC_NAME_ENG, YEAR,NAME FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE year=".$year." AND t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";

			$sql_ = "SELECT COUNT(GROUP_ID) FROM group_project AS t1 INNER JOIN laboratory AS t2 ON t1.LAB_ID = t2.LAB_ID WHERE year=".$year." AND t1.GROUP_ID = any(SELECT GROUP_ID FROM group_project_advicor WHERE LECTURER_ID=".$lecID." GROUP BY GROUP_ID)";
	}
		
	$sql .=" ORDER BY YEAR DESC LIMIT ".$start.",20";

		$result = mysql_query($sql);

		$return = "<div class='project'><table>";

		while($temp = mysql_fetch_array($result)){

			$return .="<tbody><tr><td class='header'>ชื่อโครงงาน(ไทย)</td><td class='detail'><a href='javascript:void(0)' onclick=\"xajax_getData(".$temp['GROUP_ID'].",'all','".$lecID."','','".$year."','',".$page.",2);\">".$temp['TOPIC_NAME_TH']."</a></td></tr><tr><td class='header'>ชื่อโครงงาน(อังกฤษ)</td><td class='detail'>".$temp['TOPIC_NAME_ENG']."</td></tr><tr><td class='header'>ปี</td><td class='detail'>".$temp['YEAR']."</td></tr><tr><td class='header'>ห้องวิจัย</td><td class='detail'>".$temp['NAME']."</td></tr><tr><td colspan='2'><hr/></td></tr></tbody>";

		
		}

		$return .="</table></div><div class='page'>";
		$result = mysql_fetch_array(mysql_query($sql_));

		$page_total = ceil($result[0]/20); 
	
		if ($page_total > 0){

			$return .= "หน้า&nbsp;&nbsp;&nbsp;&nbsp";

			if ($page_total <= 7 and $page <= 7)				
				$return .= createpage_search_2(1,$page_total,$lecID,$year,$page);
			else if ($page_total > 7 and $page <= 7)
				$return .= createpage_search_2(1,7,$page,$lecID,$year,$page);
			else if($page > 7 and $page < ($page_total - 2))
				$return .= createpage_search_2($page - 3,$page + 3,$page,$lecID,$year,$page);
			else 
				$return .= createpage_search_2($page_total - 2,$page_total,$lecID,$year,$page);
		}

		$return .="</div>";

		$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
		$objResponse->addScript("xajax.$('lec_search').value='$lecID';");
		
		return $objResponse;
	

}

function createpage_search_2($beginpage,$endpage,$lecID,$year,$page){

		$string="";
		for($i = $beginpage;$i <= $endpage;$i++){
			if ($i == $page)
				$string = $string . "<span >[" . $i . "]</span>&nbsp;&nbsp;&nbsp;&nbsp;";
			else
				$string = $string . "<span style='cursor:pointer;cursor:hand;'  onclick=\"xajax_search_2('".$lecID."','".$year."," . $i . ");\">" . $i . "</span>&nbsp;&nbsp;&nbsp;&nbsp;";

		}

		return $string;
}

function menu_search(){

	$objResponse = new xajaxResponse();

	$objResponse->addAssign("laboratory","innerHTML","");


	$string = "ค้นหาโดย&nbsp;&nbsp;<input name='search_by' id='search_by' type='radio' value='0' checked onclick=\"xajax_menu_search_select(this.value);\"/>หัวข้อโครงงาน&nbsp;&nbsp;<input name='search_by' id='search_by' type='radio' value='1' onclick=\"xajax_menu_search_select(this.value);\" />ชื่ออาจารย์<br/><br/>";

	
	$objResponse->addAssign("laboratoryMenu","innerHTML",$string);
	$objResponse->addScript("xajax_menu_search_select(0);");
	$objResponse->addScript("xajax_getProject(-1,1);");
	return $objResponse;

}

function menu_search_select($type){

	$objResponse = new xajaxResponse();

	if($type == 0){
		$string = menu_search_1();
	}
	else{
		$string = menu_search_2();
	}
	
	$objResponse->addAssign("laboratoryMenuSearch","innerHTML",$string);
	return $objResponse;

}
function menu_search_1(){

	$sql="SELECT YEAR FROM group_project GROUP BY YEAR";
	$result = mysql_query($sql);	
	
	$string ="<input id='text_search' type='text' value='' size='40'/></select><select  id='lang_search' ><option value='0' selected='selected'>ไทย</option><option value='1'>english</option></select><select  id='year_search' >";

	while($temp = mysql_fetch_array($result)){

			$string .= "<option value='".$temp["YEAR"]."'>".$temp['YEAR']."</option>";
	}
		
	$string .= "<option value='all' selected='selected'>ทุกปีการศึกษา</option></select><select  id='labid_search' >";
	
	$sql="SELECT LAB_ID,ALIAS FROM laboratory ";
	$result = mysql_query($sql);	

	while($temp = mysql_fetch_array($result)){

			$string .= "<option value='".$temp["LAB_ID"]."'>".$temp['ALIAS']."</option>";
	}

	
	$string .= "<option value='all' selected='selected'>ทุกห้องวิจัย</option></select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' value='ค้นหา' class='button' onclick=\"xajax_search_1(xajax.$('labid_search').value,xajax.$('text_search').value,xajax.$('year_search').value,xajax.$('lang_search').value,1);\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' value='หัวข้อโครงงานทั้งหมด' class='button' onclick=\"xajax_getProject(-1,1);xajax.$('text_search').value='';xajax.$('year_search').value='all';xajax.$('lang_search').value=0;xajax.$('labid_search').value='all';\" /><br/><br/><br/>";

	
	return $string;
}


function menu_search_2(){

	
	$sql="SELECT LECTURER_ID,CAPTION,NAME,SERNAME FROM lecturer";
	$result = mysql_query($sql);	

	$string ="<select id='lec_search'>";
	
	while($temp = mysql_fetch_array($result)){

			$string .= "<option value='".$temp["LECTURER_ID"]."'>".$temp['CAPTION'].$temp['NAME']."  ".$temp['SERNAME']."</option>";
	}
	
	$string .= "<option value='all' selected='selected'>เลือกอาจารย์</option></select><select  id='year_search'>";

	$sql="SELECT YEAR FROM group_project GROUP BY YEAR";
	$result = mysql_query($sql);	
	
	while($temp = mysql_fetch_array($result)){

			$string .= "<option value='".$temp["YEAR"]."'>".$temp['YEAR']."</option>";
	}
		
	$string .= "<option value='all' selected='selected'>ทุกปีการศึกษา</option></select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' value='ค้นหา' class='button' onclick=\"xajax_search_2(xajax.$('lec_search').value,xajax.$('year_search').value,1);\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' value='หัวข้อโครงงานทั้งหมด' class='button' onclick=\"xajax_getProject(-1,1);xajax.$('lec_search').value='all';xajax.$('year_search').value='all';\" /><br/><br/><br/>";

	
	return $string;

}


?>