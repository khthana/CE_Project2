<?php
function getListMemberRoom($labID,$page){
			$number_per_page=10 ;
			$objResponse = new xajaxResponse();
			$adminRoomFlag=false;
			$checkresult=checkAuthenAdminRoom($_SESSION['ss_UserID'],$labID);
			if ($checkrow=mysql_fetch_array($checkresult)){
				$adminRoomFlag=true;
			}
			
			$level="";	
			if ($adminRoomFlag) $colspan=4 ;else $colspan=3 ;
			$return="<table width='100%' style='font-weight:normal;background: url(\"images/leftbg.gif\");' cellpadding='0' cellspacing='0' ><tr >";
			
			$return.="<td class='padcell' style='border-bottom:1px solid #FFFFFF;'>&nbsp;</td>";
			$return.="	<td class='shd' style='border-bottom:1px solid #FFFFFF;'>ชื่อ-นามสกุล</td><td class='shd' style='border-bottom:1px solid #FFFFFF;'>ระดับ</td>";
			
			$return.="</tr>";
			$return.=printListAdviser($labID,$adminRoomFlag,$page,$number_per_page);
			$return.=printListMember($labID,$adminRoomFlag,$page,$number_per_page);
			
				
			$return.="<tr><td colspan='3' align='center' ><hr width='400px'/></td></tr><tr><td class='padcell' >&nbsp;</td><td >&nbsp;";

			if($adminRoomFlag)
					$return.="<a href='javascript:void removeMember(".$labID.");' ><img src='images/remove.gif' border='0' alt='remove'></a>&nbsp;&nbsp;&nbsp;<a href='javascript:void addMemberGroupProject(".$labID.");' ><img src='images/group.gif' border='0' alt='group project'></a>";
			$return.="</td><td align='right'>";
			$return.=printChangePage($page,$number_per_page,$labID);
			$return.="</td></tr></table>";
			$objResponse->addAssign("laboratoryDetail","innerHTML",$return);
			$objResponse->addAssign("laboratoryAddGroup","innerHTML","");
			$objResponse->addScript("showFromCreateGroupflag=false;");
			return $objResponse;
				
}
function printListAdviser($labID,$adminRoomFlag,$page,$number_per_page){
	$begin=$number_per_page*($page-1);
	$return="";
	$comSQLgetAdviserList="SELECT T1.*,T2.CAPTION,T2.NAME,T2.SERNAME FROM laboratory_member T1,lecturer  T2 WHERE  T1.USER_ID=T2.USER_ID AND  T1.LAB_ID=".$labID;
	$comSQLgetAdviserList.=" ORDER BY T2.NAME  LIMIT ".$begin." ,".$number_per_page;
	$getAdviserListresult=mysql_query($comSQLgetAdviserList);
	while ($result=mysql_fetch_array($getAdviserListresult)){
					if ($result[2]=="admin")	$level="ผู้ดูแลห้องวิจัย";
					else $level="สมาชิก";
					$return.="<tr>";
					$return.="<td class='padcell' >&nbsp;</td>";
					if ($adminRoomFlag)  $return .='<td  ><input type="checkbox" name="selectedMem" value="'.$result["USER_ID"].'">&nbsp;';
					else $return .='<td >&nbsp;';
					$return.=$result["CAPTION"]." ".$result["NAME"]." ".$result["SERNAME"]."</td><td id='su'>";
					if ($adminRoomFlag) {
						$return.="<select id='lvMem".$result["USER_ID"]."'> ";
						if ($result[2]=="admin")	{
							$return.="<option value='".$result["LEVEL"]."' selected>".$level."</option>";
							$return.="<option value='member' >สมาชิก</option>";
						}else {
							$return.="<option value='".$result["LEVEL"]."' selected>".$level."</option>";
							$return.="<option value='admin' >ผู้ดูแลห้องวิจัย</option>";
						}
						$return.="</select>";
						$return.="&nbsp; <a href='javascript:void changeLevel(".$result["USER_ID"].", ".$labID.");' ><img src='../images/edit.gif' border='0' alt='edit'></a>";

					}else $return.= "อาจารย์ที่ปรึกษาประจำห้อง";
					$return.="</td>";
				//	if ($adminRoomFlag) $return.="<td class='shd' >&nbsp;</td>";
					$return.="</tr>";
			}
		return $return;
}

function printListMember($labID,$adminRoomFlag,$page,$number_per_page){
	$return="";
	$begin=$number_per_page*($page-1);
	$comSQLgetAdviserList="SELECT COUNT(*) FROM laboratory_member T1,lecturer  T2 WHERE  T1.USER_ID=T2.USER_ID AND  T1.LAB_ID=".$labID;
	$comSQLgetAdviserList.=" ORDER BY T2.NAME  LIMIT ".$begin." ,".$number_per_page;
	$getAdviserListresult=mysql_query($comSQLgetAdviserList);
	$lecrPerPageresult=mysql_fetch_array($getAdviserListresult);
	$lecrPerPage=$lecrPerPageresult[0];
	$comSQLgetAdviserList="SELECT COUNT(*) FROM laboratory_member T1,lecturer  T2 WHERE  T1.USER_ID=T2.USER_ID AND  T1.LAB_ID=".$labID;
	$getAdviserListresult=mysql_query($comSQLgetAdviserList);
	$totalLecresult=mysql_fetch_array($getAdviserListresult);
	$totalLec=$totalLecresult[0];
	if ($totalLec ==0){
		$begin=$number_per_page*($page-1);
	}else if ($lecrPerPage ==$number_per_page ){
			return ;
	}else if ($lecrPerPage !=0){
			$begin=0;
			$number_per_page = $number_per_page-$lecrPerPage;
	}else {
			
			$begin=($page-ceil($totalLec/$number_per_page) )*$number_per_page -$totalLec%$number_per_page ;
	}
	

	$comSQLgetMemberList="SELECT T1.*,T2.FIRST_NAME,T2.TITLE,T2.LAST_NAME FROM laboratory_member T1,useraccount T2 WHERE  NOT EXISTS (SELECT * FROM  lecturer T3  WHERE T1.USER_ID=T3.USER_ID) AND T1.USER_ID=T2.USER_ID AND  T1.LAB_ID=".$labID;
	$comSQLgetMemberList.=" ORDER BY T2.FIRST_NAME  LIMIT ".$begin." ,".$number_per_page;
	$getMemberListresult=mysql_query($comSQLgetMemberList);
	while ($result=mysql_fetch_array($getMemberListresult)){
					if ($result[2]=="admin")	$level="ผู้ดูแลห้องวิจัย";
					else $level="สมาชิก";
					$return.="<tr>";
					$return.="<td class='padcell' >&nbsp;</td>";
					if ($adminRoomFlag)  $return .='<td><input type="checkbox" name="selectedMem" value="'.$result["USER_ID"].'">&nbsp;';
					else $return .='<td >&nbsp;';
					$return.=$result["TITLE"]." ".$result["FIRST_NAME"]." ".$result["LAST_NAME"]."</td><td id='su'>";
					if ($adminRoomFlag) {
						$return.="<select id='lvMem".$result["USER_ID"]."'> ";
						if ($result[2]=="admin")	{
							$return.="<option value='".$result["LEVEL"]."' selected>".$level."</option>";
							$return.="<option value='member' >สมาชิก</option>";
						}else {
							$return.="<option value='".$result["LEVEL"]."' selected>".$level."</option>";
							$return.="<option value='admin' >ผู้ดูแลห้องวิจัย</option>";
						}
						$return.="</select>";
						$return.="&nbsp; <a href='javascript:void changeLevel(".$result["USER_ID"].", ".$labID.");' ><img src='../images/edit.gif' border='0' alt='edit'></a>";

					}else $return.= $level;
					$return.="</td>";
				//	if ($adminRoomFlag) $return.="<td class='shd' >&nbsp;</td>";
					$return.="</tr>";
			}
			return $return;
}

function printChangePage($page,$numPerPage,$labID){
	$return  ="";
	$comSQLcountMember="SELECT COUNT(*) FROM laboratory_member  WHERE LAB_ID=".$labID;
	$countMemberresult=mysql_query($comSQLcountMember);
	$userrow=mysql_fetch_array($countMemberresult);
	$totalPage= ceil($userrow[0]/$numPerPage);
	$return  .=$page;
	$return  .=" จาก";
	$return  .=$totalPage;
	$return  .="&nbsp;";
	$return  .="<select name='select' onchange='changePage(".$labID.")' id='changeBox'>";
	for ($i=1;$i<=$totalPage;$i++ ){
		if ( $i != $page){
			$return .="<option value='".$i."'>หน้า".$i."</option>";
		}else {
			$return .="<option value='".$i."' selected>หน้า".$i."</option>";
		}
	}	
	$return  .="</select>";
	return $return;
}
?>