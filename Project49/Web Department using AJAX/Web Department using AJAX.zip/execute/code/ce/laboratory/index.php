<?php
	
	require_once("../_Sessionstart.php");
	require_once("../_Connectdatabase.php");
	require_once("../tool/xajax/xajax.inc.php");
	require_once("./checklogin.inc.php");
	require_once("php/checkAuthenAdmin.php");
	connectdb();
	require_once("php/showMain_Menu.php");
	require_once("php/showlistMemberRoom.php");
	require_once("php/memberMangement.php");
	require_once("php/groupMangement.php");
	require_once("php/roomInfoManagement.php");
	require_once("php/getRoomList.php");
	
	
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("createLabMenu");
	$xajax->registerFunction("getLab");
	$xajax->registerFunction("list_lab");
	//$xajax->registerFunction("list_lab_");
	$xajax->registerFunction("getLab");
	$xajax->registerFunction("getProject");
	$xajax->registerFunction("getData");
	$xajax->registerFunction("menu_search");
	$xajax->registerFunction("menu_search_select");
	$xajax->registerFunction("search_1");
	$xajax->registerFunction("search_2");
	$xajax->registerFunction("getListMemberRoom");
	$xajax->registerFunction("changeLevel");
	$xajax->registerFunction("removeMember");
	$xajax->registerFunction("showFromCreateGroup");
	$xajax->registerFunction("searchNameAddviser");
	$xajax->registerFunction("createGroup");
	$xajax->registerFunction("showFormEdit");
	$xajax->registerFunction("editRoomInfo");
	$xajax->registerFunction("addRoom");
	
	$xajax->registerFunction("isLogin");
	$xajax->registerFunction("logout");
	$xajax->registerFunction("confirmLogout");

	$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
	  <title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="css/index.css" rel="stylesheet" type="text/css">
		<link href="css/mycontent.css" rel="stylesheet" type="text/css">
		<script language="javascript" type="text/javascript" src="./checklogin.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/fade.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/cookies.js"></script>
		<script language="javascript" type="text/javascript" src="js/memberMangement.js"></script>
		<script language="javascript" type="text/javascript" src="js/groupMangement.js"></script>
		<script language="javascript" type="text/javascript" src="js/roomInfoManagement.js"></script>
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript" src="js/tiny_mce_initForLab.js"></script>
		
		<?php $xajax->printJavascript('../tool/xajax/'); ?>
	</head>
	
	<body class="site" >
		<p align="center">&nbsp;</p>
		<p align="center"><img border="0" src="../images/logo.gif" ></p>
		<center>
		<div style='text-align:center;width:765px;'>
			<div class="menu" >
					<li id="six"><a href='../'>หน้าแรก</a></li>
					<li id="one"><a href='../subject/' target='_blank'>หลักสูตร</a></li>
					<li id="two"><a href='../lecturer/' target='_blank'>บุคลากร</a></li>
					<li id="three"><a href='' target='_blank'>ห้องวิจัย</a></li>
					<li id="four"><a href='../webboard/' target='_blank'>เว็บบอร์ด</a></li>
					<li id="five"><a href='../alumni/' target='_blank'>ศิษย์เก่า</a></li>
					<li id="last"><a href='../user_management/showlist_member.php' target='_blank'>สมาชิก</a></li>
			</div>
			<div style="width:765px;">
					<!-- logo -->
					<div ><img  src="../images/show.jpg" style='float:left;border-top-style:solid; border-top-color:#FFBA00;border-bottom-style:solid; border-bottom-color:#FFD9B3;'>
					</div>
					<!-- login -->
					<div class='login'>
						<?php checkLogin();?>
					</div>
			</div>
			<div style="float:left;width:765px;">
	
					<div style="text-align:left;font-weight:bold;">
						<font face="Angsana New" color="#0066FF" style="font-size: 16pt">ห้องปฎิบัติและห้องวิจัยภาควิชาคอมพิวเตอร์</font><br/>
						<div id="laboratorymain"></div>
						<div id="laboratory"></div>
						<div id="laboratoryMenu"></div>
						<div id="laboratoryMenuSearch" class='lab_search'></div>
						<div id="laboratoryDetail"></div>
						<div id="laboratoryAddGroup"></div>
						
					</div><br><br>
		</div>
			<div style="width:800px;float:left;" >
				<font color="#666666">Department of Computer Engineering Faculty of Engineering King Mongkut's 
					Institute of Technology<br>
					Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404<br>
					<span lang="th">ส่งคำติชม</span>
				</font><a href="mailto:webmaster@ce.kmitl.ac.th">webmaster@ce.kmitl.ac.th</a>
			</div>
		</center>
	</body>
	<script langusge='JavaScript'>
		
		if(document.location.search != ""){

			
			para = ((document.location.search).split("?")[1]).split("=");

			if(para[0] == 'lecid' ){
			

				string ="<div  class='menu'><a href='javascript:void xajax_list_lab();'>&nbsp;&nbsp;&nbsp;&nbsp;หน้าหลัก&nbsp;&nbsp;&nbsp;</a><a href='javascript:void xajax_menu_search();'>&nbsp;&nbsp;หัวข้อโครงงาน&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a><br/>&nbsp</div>";

				document.getElementById("laboratorymain").innerHTML=string;

				string = "ค้นหาโดย&nbsp;&nbsp;<input name='search_by' id='search_by' type='radio' value='0'  onclick=\"xajax_menu_search_select(this.value);\"/>หัวข้อโครงงาน&nbsp;&nbsp;<input name='search_by' id='search_by' type='radio' value='1' onclick=\"xajax_menu_search_select(this.value);\" checked />ชื่ออาจารย์<br/><br/>";

				document.getElementById("laboratoryMenu").innerHTML=string;
				xajax_menu_search_select(1);
				
				xajax_search_2(para[1],'all',1);
				
			
			}
			else if(para[0] == 'labid'){
			
			
				xajax_getLab(para[1]);
			
			}
		}
		else
			xajax_list_lab();
		 
	</script>
				
</html>