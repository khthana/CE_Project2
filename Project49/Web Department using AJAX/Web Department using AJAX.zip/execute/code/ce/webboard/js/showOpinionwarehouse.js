
this.id = ((document.location.search).split("?")[1]).split("=")[1];
this.page_opinion_warehouse	 = 1;
this.page_total_warehouse = 0;
var cp = new cpaint();
cp.set_response_type('text');
//cp.set_debug(true);

	function init_page_warehouse(){
		
		var string_1 ="<table width='750' ><tr><td align='right'><span class='next_prev'><span id='page_warehouse'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=prev_warehouse() value='<< หน้าที่แล้ว' /><span id='link_page_warehouse'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=next_warehouse() value='หน้าต่อไป >>'/></span></td></tr></table>";
		
		document.getElementById("Layer3").innerHTML=string_1;
			
	}
	
	function opinionwarehouse(){
		cp.call('php/opinionwarehouse.php','opinionwarehouse',_opinionwarehouse,this.id,this.page_opinion_warehouse);
		return;
	}

	function _opinionwarehouse(result){
	
		if (result != 0){
			
			document.getElementById("Layer2").innerHTML=result;
			
		}
		else{
			document.getElementById("Layer3").innerHTML="";
			document.getElementById("Layer2").innerHTML="<h2>คุณไม่สามารถเข้ากระทู้นี้ได้";
		}
		
		pageNum_warehouse();
	}

	function pageNum_warehouse(){
	
		cp.call('php/opinionwarehouse.php','pageNum_warehouse',_pageNum_warehouse,this.id);
		return;
	}
		
	function _pageNum_warehouse(result){
			
		//alert(result)
		result = parseInt(result);
		this.page_total_warehouse = Math.ceil(result/20); 
		if (this.page_total_warehouse == 0 || isNaN(this.page_total_warehouse))
			this.page_total_warehouse = 1;
			
			
			if (this.page_total_warehouse <= 7 && this.page_opinion_warehouse <= 7)				
				createpage(1,this.page_total_warehouse);
			else if (this.page_total_warehouse > 7 && this.page_opinion_warehouse <= 7)
				createpage(1,7);
			else if(this.page_opinion_warehouse > 7 && this.page_opinion_warehouse < (this.page_total_warehouse - 2))
				createpage(this.page_opinion_warehouse - 3,this.page_opinion_warehouse + 3);
			else 
				createpage(this.page_total_warehouse - 2,this.page_total_warehouse);
			
		document.getElementById('page_warehouse').innerHTML="หน้า "+ this.page_opinion_warehouse +" จาก  "+ this.page_total_warehouse;
			
	}

	function next_warehouse(){
	
		if (this.page_opinion_warehouse == this.page_total_warehouse ){
			return;
		}
		else{
			this.page_opinion_warehouse += 1;
			opinionwarehouse();
		}
	}
	function prev_warehouse(){
	
		if (this.page_opinion_warehouse == 1){
			return;
		}
		else{
			this.page_opinion_warehouse -= 1;
			opinionwarehouse();
		}
	}
		
	function forward_view_warehouse(currentpage){
		this.page_opinion_warehouse = currentpage;
		opinionwarehouse();
		return;
	}
		
	function createpage(beginpage,endpage){
		string = "&nbsp;&nbsp;&nbsp;&nbsp;";
		for(i = beginpage;i <= endpage;i++){
			string = string + "<span style='cursor:pointer;cursor:hand;'  onclick='forward_view_warehouse(" + i + ")'>" + i + "</span>&nbsp;&nbsp;&nbsp;&nbsp;";
		}
			
		document.getElementById("link_page_warehouse").innerHTML=string;
		return;
	}
	
	