
var ShAddPoll =false;
var stickflag=false;
var sendingMsg =false;
var privateRoom = new Array ('network_room','ISAG_room','MML_room','MCL_room','hardware_room','ESL_room','ICT_room','GIG_room','OLALA_room','All_member');

var cp = new cpaint();
cp.set_response_type('text');
//cp.set_debug(true);
var pollquestion ;
var pollOptions ;
var runtime ;
var runtimeStick;
function getPollOption(){
	var arrayOp =new Array(document.getElementById("poll_option").getElementsByTagName("span").length);
	for (var i = 0; i < document.getElementById("poll_option").getElementsByTagName("span").length ; i++){
		arrayOp[i]=document.getElementById("poll_option").getElementsByTagName("span")[i].innerHTML;
	}
	return arrayOp;
}
function checkPollForm(){
		pollquestion = document.getElementById("pollqusetion").value;
		pollOptions = getPollOption();
		runtime = 0;//no limit for vote poll
			if (document.getElementById("runtime").value!="")
			{
					 if (parseInt(document.getElementById("runtime").value))
					{
						runtime=parseInt(document.getElementById("runtime").value);
					}else {
							alert( "ใส่ข้อมูลให้ถูกต้อง");
							return false;
					}
			}
		if (runtime < 0 || pollquestion ==""  || pollOptions==null)
		{
			alert( "ใ่ส่ข้อมูลไม่ครบ");
			return false;
		}
		return true;
}
function checkStickForm(){

		runtimeStick = 0;//no limit for Stick
		if (document.getElementById("stickDate").value!=""){
			if (parseInt(document.getElementById("stickDate").value)){
				runtimeStick=parseInt(document.getElementById("stickDate").value);
			}else {
				alert( "ใส่ข้อมูลให้ถูกต้อง");
				return false;
			}
		}
		if (runtimeStick < 0 ){
			alert( "ใ่ส่ข้อมูลไม่ครบ");
			return false;
		}
		return true;
}
function cPreviewPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	privateCode=calculatePrivatecode();

	if (privateCode=="")
	{
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (document.post.subject.value==""){
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	
	if (ShAddPoll ){
			if (!checkPollForm())
			{
				return;
			}
	}else {
			pollquestion =null ;
			pollOptions = null;
			runtime = null;
	}
	
	if (stickflag){
		if (!checkStickForm()){return;}
	}else{
		runtimeStick=null;
	}
	
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= "sending Message Please wait a minute";
		sendingMsg=true;
		cp.call('php/post.php','previewPost',responseview ,document.post.subject.value, document.post.author.value,document.post.Catagory.value, tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),privateCode,pollquestion,pollOptions,runtime,stickflag,runtimeStick);
		return true;
	}
}

function cPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	privateCode=calculatePrivatecode();
	if (privateCode=="")
	{
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (document.post.subject.value==""){
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใ่ส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	if (ShAddPoll ){
			if (!checkPollForm())
			{
				return;
			}
	}else {
			pollquestion =null ;
			pollOptions = null;
			runtime = null;
	}
	if (stickflag){
		if (!checkStickForm()){return;}
	}else{
		runtimeStick=null;
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= "sending Message Please wait a minute";
		sendingMsg=true;
		cp.call('php/post.php','post',responsePost ,document.post.subject.value, document.post.author.value,document.post.Catagory.value, tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),privateCode,pollquestion,pollOptions,runtime,stickflag,runtimeStick);
		return true;
	}
}

function responseview(result) {
	if (result =='false'){
		alert("คุณไม่สามารถตั้งกระทู้ได้");
		window.close();
	}
	else{
		document.getElementById('respone post').innerHTML = result;
		sendingMsg=false;
	}
}
function responsePost(result){
	if (result =='false'){
		alert("คุณไม่สามารถตั้งกระทู้ได้");
		window.close();
	}
	else{
		if (result=="Please,Choose private of topic"){
			document.getElementById('respone post').innerHTML = result;
			sendingMsg=false;
		}
		else	
			window.close();
	}
	
}