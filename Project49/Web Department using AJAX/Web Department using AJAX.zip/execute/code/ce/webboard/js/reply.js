
var sendingMsg =false;
var showReplyflag=false;
var replyarea;
var cp = new cpaint();
cp.set_response_type('text');

function cPreviewPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
		formErrors = "กำลังส่งข้อมูล";
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} 
	else {
		document.getElementById('respone post').innerHTML= 'sending Message Please wait a minute<br/><img src="imgs/ajax-loader2.gif" alt="now loading" />';
		sendingMsg=true;
		cp.call('php/replyTopic.php','previewReply',responseview, document.post.author.value,bodygl.innerHTML ,document.getElementById('tID').value);
		return true;
	}
}

function cPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
		formErrors = "กำลังส่งข้อมูล";
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= 'sending Message Please wait a minute<br/><img src="imgs/ajax-loader2.gif" alt="now loading" />';
		sendingMsg=true;
		cp.call('php/replyTopic.php','reply',responsePost, document.post.author.value, bodygl.innerHTML ,document.getElementById('tID').value);
		return true;
	}
}

function responseview(result) {
	if(result == 0){
		document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแสดงความคิดเห็นกระทู้นี้ได้</center>";
	}
	else{
		document.getElementById('respone post').innerHTML = result;
		sendingMsg=false;
	}
		
}
function responsePost(result){
	if(result == 0){
		document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแสดงความคิดเห็นกระทู้นี้ได้</center>";
	}
	else{
		if (result=="Please,Choose private of topic"){
			document.getElementById('respone post').innerHTML = result;
			sendingMsg=false;
		}
		else{
			Set_Cookie("reply","1",60);	
			window.close();
		}
			
	}
}
function showReply(){
	if (!showReplyflag){
		showReplyflag=true;
		document.getElementById('reply').innerHTML=replyarea;
	}
	else{
		showReplyflag=false;
		document.getElementById('reply').innerHTML="";
	}
}

//-->