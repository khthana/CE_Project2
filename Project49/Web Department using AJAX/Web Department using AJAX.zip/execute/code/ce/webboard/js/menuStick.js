function stickmode(){
	if (document.getElementById("stickDate").disabled){
		document.getElementById("stickDate").disabled=false;
		stickflag=true;
	}else{
		document.getElementById("stickDate").disabled=true;
		stickflag=false;
	}
}