<!--
var sendingMsg =false;
var showReplyflag=false;
var replyarea;
var cp = new cpaint();
cp.set_response_type('text');
//cp.set_debug(true);

function getData(tID,oID) {
	cp.call('php/edit_opinion.php','edit_opinion',_getData,tID,oID);
	return;
}

function _getData(result) {
	
	if (result == 0){
		document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแก้ไขหัวข้อกระทู้นี้ได้</center>";
	}
	else{
		this.data = result.split("&;#@");
		document.getElementById("posttime").innerHTML = "เมื่อ " + this.data[0];
		message=decodeSpecialChar(this.data[1]);
		document.getElementById("msg").innerHTML = "<textarea id=\"elm1\" name=\"message\" style=\"width: 100%\">"+message+"</textarea>";
		tinyMCE.addMCEControl(document.getElementById("elm1"),'mce_editopinion');
		showexample();
	}
}

function cPreviewPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= 'sending Message Please wait a minute<br/><img src="imgs/ajax-loader2.gif" alt="now loading" />';
		sendingMsg=true;
		cp.call('php/edit_opinion.php','previewReply',responseview, document.post.author.value,bodygl.innerHTML ,document.getElementById('tID').value,document.getElementById('oID').value);
		return true;
		
	}
}

function cPost() {
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (document.post.author.value==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= 'sending Message Please wait a minute<br/><img src="imgs/ajax-loader2.gif" alt="now loading" />';
		sendingMsg=true;
		cp.call('php/edit_opinion.php','reply',responsePost,document.post.author.value, bodygl.innerHTML ,document.getElementById('tID').value,document.getElementById('oID').value);
		return true;
	}
}

function responseview(result) {
		document.getElementById('respone post').innerHTML = result;
		document.getElementById("posttime_").innerHTML = ":: เมื่อ  "+ this.data[0] +"  ::" ;
		sendingMsg=false;
}
function responsePost(result){
	if (result=="Please,Choose private of topic"){
		document.getElementById('respone post').innerHTML = result;
		sendingMsg=false;
	}
	else{	
		Set_Cookie("opinion","1",60);	
		window.close();
	}
}
function showReply(){
	if (!showReplyflag){
		showReplyflag=true;
		document.getElementById('reply').innerHTML=replyarea;
	
	}else{
		showReplyflag=false;
		document.getElementById('reply').innerHTML="";
	}
}
