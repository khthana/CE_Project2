<!--
this.privatecode = "";
this.privatecode_ = "";



function pubCheck(){
		var checkboxs = new Array(document.post.network_room,
			document.post.ISAG_room,
			document.post.MML_room,
			document.post.MCL_room,
			document.post.hardware_room,
			document.post.ESL_room,
			document.post.ICT_room,
			document.post.GIG_room,
			document.post.OLALA_room,
			document.post.All_member);
		
		document.post.privateCk.checked =false;
		
		for (i=0;i<checkboxs.length ;i++ ){
			checkboxs[i].checked = false;
			checkboxs[i].disabled = false;
			//

		}
		this.privatecode = this.privatecode_;
}
function priSwitch(){
	document.post.privateCk.checked =true;
	document.post.publicCk.checked =false;
	
	set_room(document.post.privateCk.name);
	
}
function priCheck(name){
	document.post.privateCk.checked =true;
	document.post.publicCk.checked =false;
	document.post.All_member.checked =false;
	set_room(name);
	
}
function priSelectAll(){
	var checkboxs = new Array(document.post.network_room,
			document.post.ISAG_room,
			document.post.MML_room,
			document.post.MCL_room,
			document.post.hardware_room,
			document.post.ESL_room,
			document.post.ICT_room,
			document.post.GIG_room,
			document.post.OLALA_room);
	document.post.publicCk.checked =false;
	document.post.privateCk.checked =true;
	var check = document.post.All_member.checked;
	if (check == true){
		for (i=0;i<checkboxs.length ;i++ ){
			checkboxs[i].checked = true;
			checkboxs[i].disabled = false;
		}
	}
	else{
		for (i=0;i<checkboxs.length ;i++ ){
			//if (checkboxs[i].disabled == false)
			checkboxs[i].checked = false;
			checkboxs[i].disabled = false;
		}
		//set_room(document.post.privateCk.name);		
	}			
	this.privatecode = this.privatecode_;
	set_room(document.post.privateCk.name);
	
}
function calculatePrivatecode() {
	pr_Code="";
	var checkboxs = new Array(document.post.network_room,
			document.post.ISAG_room,
			document.post.MML_room,
			document.post.MCL_room,
			document.post.hardware_room,
			document.post.ESL_room,
			document.post.ICT_room,
			document.post.GIG_room,
			document.post.OLALA_room,
			document.post.All_member);
	if (document.post.privateCk != null ){
			if( document.post.privateCk.checked){
				for (i=0;i<checkboxs.length ;i++ )
				{
						if (checkboxs[i].checked)
						{
							pr_Code += checkboxs[i].value;
						}
				}
			}else pr_Code ="A";
	}
	else 
		pr_Code ="A";
	return pr_Code;
}

function pri_room(para){
	
	var checkboxs = new Array(document.post.network_room,document.post.ISAG_room,document.post.MML_room,document.post.MCL_room,document.post.hardware_room,document.post.ESL_room,document.post.ICT_room,document.post.GIG_room,document.post.OLALA_room);	
	
	for (i=0;i<checkboxs.length ;i++ ){
		
		if (checkboxs[i].checked == true)
			this.privatecode += checkboxs[i].name +":" ;
		
	}
	
		this.privatecode_ = this.privatecode;
	
}

function set_room(name){
	
	
	var temp = (this.privatecode).split(":");
	var loop = 0;
	var string = "";
	var bool = document.getElementById(name).checked;
	
	if (bool == true ){
		var pos = (this.privatecode_).indexOf(name);
		if(pos >= 0){
			var pos = (this.privatecode).indexOf(name);
			if(pos < 0){
				if ((temp.length - 1) == 1)
					document.getElementById(temp[0]).disabled = false;
				
				this.privatecode += name +":" ;
			}
			else{
				temp = (this.privatecode).split(":");
				while(loop < temp.length - 1){
						document.getElementById(temp[loop]).checked = true;
						loop++;
						
				}
			}
		}
		else{
			
			temp = (this.privatecode).split(":");
			while(loop < temp.length - 1){
				document.getElementById(temp[loop]).checked = true;
				loop++;
			}
			//return;
		}
	}
	else{
		var pos = (this.privatecode).indexOf(name);
		if(pos >= 0){
			
			while(loop < temp.length - 1){
				if (temp[loop] != name)
					string 	 += temp[loop] +":" ;
			loop++;
			}
			this.privatecode = string;
		}
		else
			return;
	}
	
	var temp = (this.privatecode).split(":");
	var num = temp.length - 1;
	if (num <= 1)
		document.getElementById(temp[0]).disabled = true;
	
	return;
}
