var sendcomplainFlag=false;
function complain(topicID,opinionID){
	if (!sendcomplainFlag){
		sendcomplainFlag=true;
		cp.call('php/complain.php','complain',responseComplain,topicID,opinionID);
	}
	
}
function responseComplain(result){ // remove use same function
	sendcomplainFlag=false;
	if (result!="Incompelete"){
		alert(result);
	}

}