<!--
		function selfbookmark(){
			var topicID=this.id;
			cp.call('php/bookmark.php','selfbookmark',responseSelfBookmark,topicID);
			
		}

		function responseSelfBookmark(result){
			alert(result);
		}

//-----------------------------------------------------------------

		this.page_1 = 1;
		this.page_2 = 1;
		this.pagesnum_1 = 1;
		this.pagesnum_2 = 1;
		
		var cp = new cpaint();
		cp.set_response_type('text');
		//cp.set_debug(true);
		
		function bookmark(currentpage,id){
			if (id == 1){
				this.page_1 = currentpage;
				bookmark_1();
			}
			else{
				this.page_2 = currentpage;
				bookmark_2();
			}
				
			return;
		}
		
		function createpage_bookmark(beginpage,endpage,id){
			
			string = "&nbsp;&nbsp;&nbsp;&nbsp;";
			for(i = beginpage;i <= endpage;i++){
				string = string + "<span style='cursor:pointer;cursor:hand;'  onclick='bookmark(" + i +"," + id + ")'>" + i + "</span>&nbsp;&nbsp;&nbsp;&nbsp;";
			}
			
			id_str = "bookmark_link_page_" + id;
			
			document.getElementById(id_str).innerHTML=string;
			return;
		}
		
//-----------------------------------------------------------------
		function bookmark_1(i){
			
			cp.call('php/bookmark.php','bookmark_1',_bookmark_1,this.page_1);
			return;
		}

		function _bookmark_1(result){

			mygrid_1.clearAll();
			mygrid_1.loadXMLString(result);
			pageNum_1();
		}
		
		function bookmark_next_1(){
			
			if (this.page_1 == this.pagesnum_1 ){
				return;
			}
			else{
				this.page_1 += 1;
				bookmark_1()
				window.scrollTo(0,0);
			}
		}
		function bookmark_prev_1(){
			
			if (this.page_1 == 1){
				return;
			}
			else{
				this.page_1 -= 1;
				bookmark_1()
				window.scrollTo(0,0);
			}
		}

		function pageNum_1(){
			
			cp.call('php/bookmark.php','pageNum_1',_pageNum_1);
			return;
		}
		function _pageNum_1(result){
			
			this.pagesnum_1 = Math.ceil(result/25);
			if (this.pagesnum_1 == 0 || isNaN(this.pagesnum_1))
				this.pagesnum_1 = 1;
				
			if (this.pagesnum_1 <= 7 && this.page_1 <= 7)				
				createpage_bookmark(1,this.pagesnum_1,1);
			else if (this.pagesnum_1 > 7 && this.page_1 <= 7)
				createpage_bookmark(1,7,1);
			else if(this.page_1 > 7 && this.page_1 < (this.pagesnum_1 - 2))
				createpage_bookmark(this.page_1 - 3,this.page_1 + 3,1);
			else 
				createpage_bookmark(this.pagesnum_1 - 2,this.pagesnum_1,1);
			
			document.getElementById('bookmark_page_1').innerHTML="หน้า "+this.page_1+" จาก  "+this.pagesnum_1;
			
		}
//--------------------------------------------------------------------------

		function bookmark_2(i){
			
			cp.call('php/bookmark.php','bookmark_2',_bookmark_2,this.page_2);
			return;
		}

		function _bookmark_2(result){

			mygrid_2.clearAll();
			mygrid_2.loadXMLString(result);
			pageNum_2();
		}
		
		function bookmark_next_2(){
			
			if (this.page_2 == this.pagesnum_2 ){
				return;
			}
			else{
				this.page_2 += 1;
				bookmark_2()
				window.scrollTo(0,0);
			}
		}
		function bookmark_prev_2(){
			
			if (this.page_2 == 1){
				return;
			}
			else{
				this.page_2 -= 1;
				bookmark_2()
				window.scrollTo(0,0);
			}
		}

		function pageNum_2(){
			
			cp.call('php/bookmark.php','pageNum_2',_pageNum_2);
			return;
		}
		function _pageNum_2(result){
			
			this.pagesnum_2 = Math.ceil(result/25);
			if (this.pagesnum_2 == 0 || isNaN(this.pagesnum_2))
				this.pagesnum_2 = 1;
				
			if (this.pagesnum_2 <= 7 && this.page_2 <= 7)				
				createpage_bookmark(1,this.pagesnum_2,2);
			else if (this.pagesnum_2 > 7 && this.page_2 <= 7)
				createpage_bookmark(1,7,2);
			else if(this.page_2 > 7 && this.page_2 < (this.pagesnum_2 - 2))
				createpage_bookmark(this.page_2 - 3,this.page_2 + 3,2);
			else 
				createpage_bookmark(this.pagesnum_2 - 2,this.pagesnum_2,2);
			
			document.getElementById('bookmark_page_2').innerHTML="หน้า "+this.page_2+" จาก  "+this.pagesnum_2;
			
		}
		
//-----------------------------------------------------------

function del_bookmark(id,type){

	this.type = type;
	
	var ret = confirm("คุณแน่ใจที่จะลบหัวข้อกระทู้นี้ออกจากสมุดบันทึก");
	if (ret == true){
		cp.call('php/bookmark.php','del_bookmark',_del_bookmark,id);
	}
	else{
		return;
	}


}

function _del_bookmark(result){

	if(result == 'true'){
		if(this.type == 1)
			bookmark_1();
		else if(this.type == 2)
			bookmark_2();

		alert("คุณได้กระทู้นี้แล้ว");
	}
	else{
		alert("ไม่สามารถลบกระทู้นี้ได้");
	}
		

}
//-->