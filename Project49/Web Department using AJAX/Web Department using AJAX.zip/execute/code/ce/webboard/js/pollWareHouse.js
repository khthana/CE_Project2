var autorefreshFlag=false;
var setTimeAuto;
var queryData;
function showPoll(){
	var topicID=this.id;
	cp2.call('php/showPollWareHouse.php','showPoll',responseshowPoll,topicID);
}
function responseshowPoll(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue !="No Poll"){
		createTable(result);
	}
	
}
function createTable(result){
	table='<table width="450"  border="0" cellpadding="0" cellspacing="0">';
	table+='<tr >';
	table+='  <td background="imgs/PollFrame/blueheader.png"><img src="imgs/PollFrame/blueheaderl.png"  /></td>';
	table+='  <td background="imgs/PollFrame/blueheader.png"width="100%"><div id="pollQuestion">';
	
	table+=result.getElementsByTagName('pollQuestion')[0].firstChild.nodeValue;
	if (result.getElementsByTagName('expireInDay')[0].firstChild.nodeValue!="-"){
		table+=" &#3611;&#3636;&#3604;&#3619;&#3633;&#3610;&#3650;&#3627;&#3623;&#3605;&#3651;&#3609;&#3623;&#3633;&#3609;&#3607;&#3637;&#3656; : "+result.getElementsByTagName('expireInDay')[0].firstChild.nodeValue;
	}
	table+='</div></td>';
	table+=' <td background="imgs/PollFrame/blueheader.png" align="right"><img src="imgs/PollFrame/blueheaderr.png"  /></td>';
	table+='  </tr>';
	table+='  <tr>';
	table+=' <td background="imgs/PollFrame/margin_l.gif" >&nbsp;</td>';
	table+=' <td width="100%"  ><div id="content">';
	table+="<span style='cursor:pointer;cursor:hand'><img id='iconAuto' src='imgs/autorefresh.gif'  border='0'  onclick=\"autorefresh()\"/></span><br/>";
	queryData=decodeSpecialChar(result.getElementsByTagName('resultPoll')[0].firstChild.nodeValue);
	table+='<img id="pieChart" src="php/piechart.php?'+queryData+'"/>';
	table+=' </div></td>';
	table+='  <td background="imgs/PollFrame/margin_r.gif">&nbsp;</td>';
	table+='  </tr>';
	table+=' <tr>';
	table+='  <td ><img src="imgs/PollFrame/buttom_l.gif"  /></td>';
	table+=' <td width="100%"  background="imgs/PollFrame/buttom_c.gif">&nbsp;</td>';
	table+='<td ><img src="imgs/PollFrame/buttom_r.gif"   /></td>';
	table+=' </tr>';
	table+='</table>';
	document.getElementById("pollArea").innerHTML= table;
}

function autorefresh(){
	if (autorefreshFlag){
		autorefreshFlag=false;
		clearInterval(setTimeAuto);
		document.getElementById('iconAuto').setAttribute("src","imgs/autorefresh.gif");
	}else{
		setTimeAuto=setInterval("updateChart()",7500);
		autorefreshFlag=true;
		document.getElementById('iconAuto').setAttribute("src","imgs/ajax-loader2.gif");
	}
}
function updateChart(){
	var topicID=this.id;
	cp2.call('php/showPollWareHouse.php','updateChart',responseupdateChart,topicID);
}
function responseupdateChart(result){
	var dataReturn=decodeSpecialChar(result.getElementsByTagName('resultPoll')[0].firstChild.nodeValue);
	if (dataReturn!=queryData){
		queryData=dataReturn;
		dataReturn="php/piechart.php?"+dataReturn;
		document.getElementById('pieChart').setAttribute("src",dataReturn);
	}
}