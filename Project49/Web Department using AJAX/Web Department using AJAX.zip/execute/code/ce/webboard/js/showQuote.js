<!--
var objectNodegl;
var oIDgl;
var tIDgl;
var bodygl;
var xmlDoc;
var cp2 = new cpaint();
cp2.set_response_type('XML');
//cp2.set_debug(true);
try{
	xmlDoc=document.implementation.createDocument("","",null);
	//alert("mozilla");
}catch(e1){
	try{
		xmlDoc=new ActiveXObject('Msxml2.XMLDOM');
		//alert("Msxml2");
		}catch(e){
			try{
				xmlDoc=new ActiveXObject('Microsoft.XMLDOM');
				//alert("Microsoft");
				}catch(oc){
					xmlDoc=null;
					//xmlDoc = new XMLHttpRequest();
					//alert("4");
				}
		}
}
var opNode=xmlDoc.createElement("opinions");
xmlDoc.appendChild(opNode);

function showquote(objectNode,oID,tID){
	objectNodegl=objectNode;
	oIDgl=oID;
	tIDgl=tID;
	var i =-1;
	var numberopinion=opNode.getElementsByTagName('opinion').length;
	for (j=0;j<numberopinion ; j++){
		if (opNode.getElementsByTagName('opinionID')[j].firstChild.nodeValue==oID){
			i=j;
			break;
		}
	}
if (opNode.hasChildNodes() && i!=-1)
	{
		showquoteMessage(opNode.getElementsByTagName('opinionID')[i].firstChild.nodeValue,opNode.getElementsByTagName('authorName')[i].firstChild.nodeValue,opNode.getElementsByTagName('postTime')[i].firstChild.nodeValue,opNode.getElementsByTagName('opinionMSG')[i].firstChild.nodeValue);
	}else{
		cp2.call('php/quote.php','showquote',responseShowquote, oID,tID);
	}
}

function showquoteMessage(oID,authorName,postDate,message){
	message=decodeHTML(message);
	//var quoteNode=document.getElementById('quote'+oID);
	var quoteNode=objectNodegl;
	var parentNode=quoteNode.parentNode;
	var nextNode =quoteNode.nextSibling;
	var AreaID="quoteArea"+oID;
	
	/*if (nextNode.nodeName == "DIV")
		{alert(nextNode.getAttribute("id"));}*/
	if(nextNode ==null || nextNode.nodeName != "DIV" || nextNode.getAttribute("id")!=AreaID){
		/*if (nextNode !=null )
		{alert(nextNode.nodeName);}*/		
		var quoteAreaNode=document.createElement("div");
		quoteAreaNode.setAttribute("id",AreaID);
		var tableNode =document.createElement("table");
		tableNode.cellSpacing="0";
		var newRow =tableNode.insertRow(0);
		var cellNode =newRow.insertCell(0);
		cellNode.align="left";
		cellNode.className="quoteheadLeft";
		cellNode.innerHTML="&#3629;&#3657;&#3634;&#3591;&#3629;&#3636;&#3591; : "+authorName;
		cellNode =newRow.insertCell(1);
		cellNode.align="right";
		cellNode.className="quoteheadRight";
		cellNode.innerHTML="&#3605;&#3629;&#3610;&#3648;&#3617;&#3639;&#3656;&#3629; "+postDate;
		cellNode =newRow.insertCell(0);//tab
		cellNode.width="5";//width of tab
		newRow =tableNode.insertRow(1);
		cellNode =newRow.insertCell(0);
		cellNode.className="quotemessage";
		cellNode.innerHTML=message;
		cellNode.colSpan="2";
		cellNode =newRow.insertCell(0);//tab
		cellNode.width="5";//width of tab
		quoteAreaNode.appendChild(tableNode);
		if (nextNode ==null ){
			parentNode.appendChild(quoteAreaNode);
		}else{
			parentNode.insertBefore(quoteAreaNode,nextNode);
		}
	}else{
		parentNode.removeChild(nextNode);
	}
}

function responseShowquote(result){

	var oID=result.getElementsByTagName('opinionID')[0].firstChild.nodeValue;
    var authorName=result.getElementsByTagName('authorName')[0].firstChild.nodeValue;
	var postDate=result.getElementsByTagName('postTime')[0].firstChild.nodeValue;
	var message=result.getElementsByTagName('opinionMSG')[0].firstChild.nodeValue;
	opNode.appendChild(result.getElementsByTagName('opinion')[0]);
	
	showquoteMessage(oID,authorName,postDate,message);
	
}
function decodeHTML(message){
	message=message.replace(/\\u003c/g, "<");
	message=message.replace(/\\u003e/g, ">");
	message=message.replace(/\\u0026/g, "&");
	return message;
}
//-->