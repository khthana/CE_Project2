		
		this.network = 1;
		this.hardware = 1;
		this.software = 1;
		this.security = 1;
		this.course = 1;
		this.etc = 1;
		this.stick_1 = 0;
		this.stick_2 = 0;
		this.page_1 = 1;
		this.page_2 = 1;
		this.page_3 = 1;
		this.pagesnum_1 = 1;
		this.pagesnum_2 = 1;
		this.pagesnum_3 = 1;

		this.search_current = "-*-คำที่ต้องการค้นหา-*-";
		this.search_warehouse_current = "-*-คำที่ต้องการค้นหา-*-";
		var cp = new cpaint();
		cp.set_response_type('text');
		//cp.set_debug(true);

		
		function call_1(){
			this.page_1 = 1;
			view();
		
		}

		function check(){
			
			if (document.getElementById("network").checked == true)
				this.network = 1;
			else
				this.network = 0;
			if (document.getElementById("hardware").checked == true)
				this.hardware = 1;
			else
				this.hardware = 0;
			if (document.getElementById("software").checked == true)
				this.software = 1;
			else
				this.software = 0;
			if (document.getElementById("security").checked == true)
				this.security = 1;
			else
				this.security = 0;
			if (document.getElementById("course").checked == true)
				this.course = 1;
			else
				this.course = 0;
			if (document.getElementById("etc").checked == true)
				this.etc = 1;
			else
				this.etc = 0;
				 
		
		}

		function view() {

			check();
			cp.call('php/view.php','view',_view,this.page_1,this.network,this.hardware,this.software,this.security,this.course,this.etc);
			return;
		}

		function _view(result) {
			mygrid_1.clearAll();
			mygrid_1.loadXMLString(result);
			pageNum_1();
		}
		

		function autorefresh_1() {
			
			cp.call('php/view.php','autorefresh_1',_autorefresh_1,this.network,this.hardware,this.software,this.security,this.course,this.etc);
			return;
		}

		function _autorefresh_1(result) {
			
			var temp = result.split(";");
			
			if (temp[0] == '0'){
				return;
			}
			else{
				var string = temp[1].split("<BR/>");
				var i = 0;var add_stick = 0;
				while (i < ((string.length) - 1)){
					
					var cols = string[i].split(",");
					if (cols[9] == "stick"){
						
						mygrid_1.addRow(cols[0],cols[1]+','+cols[2]+','+cols[3]+','+cols[4]+','+cols[5]+','+cols[6]+','+cols[7]+','+cols[8],0);
						this.stick_2++;
						add_stick++;
					}
					else{
						
						if (this.page_1 == 1)
							mygrid_1.addRow(cols[0],cols[1]+','+cols[2]+','+cols[3]+','+cols[4]+','+cols[5]+','+cols[6]+','+cols[7]+','+cols[8],(parseInt(this.stick_1) + parseInt(add_stick)));
						else
							mygrid_1.addRow(cols[0],cols[1]+','+cols[2]+','+cols[3]+','+cols[4]+','+cols[5]+','+cols[6]+','+cols[7]+','+cols[8],this.stick_2);
					}
					
					i++;
					
					
					if (mygrid_1.getRowsNum() > 25) //25
						mygrid_1.deleteRow(mygrid_1.getRowId(mygrid_1.getRowsNum() - 1));
				}
				pageNum_1();
				
				
			}
			add_stick = 0;
			return;
		}


		function pageNum_1(){
			check();
			cp.call('php/view.php','pageNum_1',_pageNum_1,this.network,this.hardware,this.software,this.security,this.course,this.etc);
			return;
		}
		function _pageNum_1(result){
			
			//alert(result);
			var temp = result.split("--");
			this.stick_1 = temp[1];
			//result = (parseInt(this.stick_2) + parseInt(temp[0]));
			//alert(this.stick_1);
			result = parseInt(temp[0]);
			this.pagesnum_1 = Math.ceil(result/25); //25
			if (this.pagesnum_1 == 0 || isNaN(this.pagesnum_1))
				this.pagesnum_1 = 1;
			//----
			
			if (this.pagesnum_1 <= 7 && this.page_1 <= 7)				
				createpage(1,this.pagesnum_1,1);
			else if (this.pagesnum_1 > 7 && this.page_1 <= 7)
				createpage(1,7,1);
			else if(this.page_1 > 7 && this.page_1 < (this.pagesnum_1 - 2))
				createpage(this.page_1 - 3,this.page_1 + 3,1);
			else 
				createpage(this.pagesnum_1 - 2,this.pagesnum_1,1);
			
			document.getElementById('page_1').innerHTML="หน้า "+this.page_1+" จาก  "+this.pagesnum_1;
			
		}

		function next(){
	
			this.stick_2 = 0 ;
			if (this.page_1 == this.pagesnum_1 ){
				return;
			}
			else{
				this.page_1 += 1;
				view()
				window.scrollTo(0,0);
				//document.getElementById('page_1').innerHTML="หน้า "+this.page_1+" จาก  "+this.pagesnum_1;
			}
		}
		function prev(){
	
			this.stick_2 = 0;
			if (this.page_1 == 1){
				return;
			}
			else{
				this.page_1 -= 1;
				view()
				window.scrollTo(0,0);
				//document.getElementById('page_1').innerHTML="หน้า "+this.page_1+" จาก  "+this.pagesnum_1;
			}
		}
		
		
//--------------------------------------------------
	 	function forward_view(currentpage,id){
			if (id == 1){
				this.page_1 = currentpage;
				view();
			}
			else if (id == 2){
				this.page_2 = currentpage;
				search_warehouse("-");
			}
				
			else if (id == 3){
				this.page_3 = currentpage;
				search_topic("-");
			}
				
			
			return;
		}
		
		function createpage(beginpage,endpage,id){
			string = "&nbsp;&nbsp;&nbsp;&nbsp;";
			for(i = beginpage;i <= endpage;i++){
				string = string + "<span style='cursor:pointer;cursor:hand;'  onclick='forward_view(" + i +"," + id + ")'>" + i + "</span>&nbsp;&nbsp;&nbsp;&nbsp;";
			}
			id_str = "link_page_" + id;
			document.getElementById(id_str).innerHTML=string;
			return;
		}

//---------------------------------------------------


		function search_topic(i){
			if (i != "-"){
				this.page_3 = 1;
				this.search_current = document.getElementById('search_keywords').value;
				if (this.search_current == ""){
					mygrid_3.clearAll();this.pagesnum_3 = 1;
					document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
					return;
				}
			}

			cp.call('php/view.php','search_topic',_search_topic,this.search_current,this.page_3);
			

			return;
		}

		function _search_topic(result){

			mygrid_3.clearAll();
			mygrid_3.loadXMLString(result);
			pageNum_3();
		}
		
		function search_next(){
			if (this.page_3 == this.pagesnum_3 ){
				return;
			}
			else{
				this.page_3 += 1;
				search_topic("-")
				window.scrollTo(0,0);
				//document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
			}
		}
		function search_prev(){
			if (this.page_3 == 1){
				return;
			}
			else{
				this.page_3 -= 1;
				search_topic("-")
				window.scrollTo(0,0);
				//document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
			}
		}

		function pageNum_3(){
			
			cp.call('php/view.php','pageNum_3',_pageNum_3,this.search_current);
			return;
		}
		function _pageNum_3(result){
			
			this.pagesnum_3 = Math.ceil(result/25);
			if (this.pagesnum_3 == 0 || isNaN(this.pagesnum_3))
				this.pagesnum_3 = 1;
				
			if (this.pagesnum_3 <= 7 && this.page_3 <= 7)				
				createpage(1,this.pagesnum_3,3);
			else if (this.pagesnum_3 > 7 && this.page_3 <= 7)
				createpage(1,7,3);
			else if(this.page_3 > 7 && this.page_3 < (this.pagesnum_3 - 2))
				createpage(this.page_3 - 3,this.page_3 + 3,3);
			else 
				createpage(this.pagesnum_3 - 2,this.pagesnum_3,3);
			
			document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
			
		}

//--------------------------------------------------------------------

		function search_warehouse(i){
			
			if (i != "-"){
				this.page_2 = 1;
				this.search_warehouse_current = document.getElementById('search_keywords_warehouse').value;
				if (this.search_warehouse_current == "" && i != "A"){
					mygrid_2.clearAll();this.pagesnum_2 = 1;
					document.getElementById('page_2').innerHTML="หน้า "+this.page_2+" จาก  "+this.pagesnum_2;
					return;
				}
				else{
					mygrid_2.clearAll();
				}
			}
			
			cp.call('php/view.php','search_warehouse',_search_warehouse,this.search_warehouse_current,this.page_2);
			return;
		}
		
		function search_warehouse_all(i){
			document.getElementById('search_keywords_warehouse').value = "";
			search_warehouse(i);
		}
		function _search_warehouse(result){

			mygrid_2.clearAll();
			mygrid_2.loadXMLString(result);
			pageNum_2();
		}
		
		function search_warehouse_next(){
			
			if (this.page_2 == this.pagesnum_2 ){
				return;
			}
			else{
				this.page_2 += 1;
				search_warehouse("-")
				window.scrollTo(0,0);
				//document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
			}
		}
		function search_warehouse_prev(){
			
			if (this.page_2 == 1){
				return;
			}
			else{
				this.page_2 -= 1;
				search_warehouse("-")
				window.scrollTo(0,0);
				//document.getElementById('page_3').innerHTML="หน้า "+this.page_3+" จาก  "+this.pagesnum_3;
			}
		}

		function pageNum_2(){
			
			cp.call('php/view.php','pageNum_2',_pageNum_2,this.search_warehouse_current);
			return;
		}
		function _pageNum_2(result){
			
			this.pagesnum_2 = Math.ceil(result/25);
			if (this.pagesnum_2 == 0 || isNaN(this.pagesnum_2))
				this.pagesnum_2 = 1;
				
			if (this.pagesnum_2 <= 7 && this.page_2 <= 7)				
				createpage(1,this.pagesnum_2,2);
			else if (this.pagesnum_2 > 7 && this.page_2 <= 7)
				createpage(1,7,2);
			else if(this.page_2 > 7 && this.page_2 < (this.pagesnum_2 - 2))
				createpage(this.page_2 - 3,this.page_2 + 3,2);
			else 
				createpage(this.pagesnum_2 - 2,this.pagesnum_2,2);
			
			document.getElementById('page_2').innerHTML="หน้า "+this.page_2+" จาก  "+this.pagesnum_2;
			
		}
	
//-----------------------------------------------------------------

/*
		function autorefresh_3() {
			cp.call('php/view.php','autorefresh_3',_autorefresh_3,this.search_current);

			return;
		}

		function _autorefresh_3(result) {
			
			var temp = result.split(";");
			
			if (temp[0] == '0'){
				
				return;
			}
			else{
				
				var string = temp[1].split("<BR/>");
				var i = 0;
				while (i < ((string.length) - 1)){
					

					var cols = string[i].split(",");
					mygrid_3.addRow(cols[0],cols[1]+','+cols[2]+','+cols[3]+','+cols[4]+','+cols[5]+','+cols[6]+','+cols[7]+','+cols[8],0);
					i++;
					
					if (mygrid_3.getRowsNum() > 4)
						mygrid_3.deleteRow(mygrid_3.getRowId(mygrid_3.getRowsNum() - 1));
				}
				pageNum_3();
				return;
				
			}
		
		}
		
*/		
	