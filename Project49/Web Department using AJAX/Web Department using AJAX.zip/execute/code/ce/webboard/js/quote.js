<!--
function showexample(){
	var topicID=document.getElementById('tID').value;
	var opID=-1;
	for (i=0;i<document.getElementById('selectOpinion').options.length ; i++)	{
			if (document.getElementById('selectOpinion').options[i].selected){
					opID=document.getElementById('selectOpinion').options[i].value;
					break;
			}
	}
	var k =-1;
	var numberopinion=opNode.getElementsByTagName('opinion').length;
	for (j=0;j < numberopinion ; j++){
		if (opNode.getElementsByTagName('opinionID')[j].firstChild.nodeValue==opID){
			k=j;
			break;
		}
	}
	if (opNode.hasChildNodes() && k!=-1)	{
			showexampleMessage(opNode.getElementsByTagName('authorName')[k].firstChild.nodeValue,opNode.getElementsByTagName('postTime')[k].firstChild.nodeValue,opNode.getElementsByTagName('opinionMSG')[k].firstChild.nodeValue);
	}else if (opID!=-1){
			cp2.call('php/quote.php','showquote',responseShowexample, opID,topicID);
	}
}

function showexampleMessage(authorName,postDate,message){
	//alert(authorName+postDate+message);
	document.getElementById('showAuthor').innerHTML="&#3629;&#3657;&#3634;&#3591;&#3629;&#3636;&#3591; : "+authorName;
	document.getElementById('date').innerHTML="&#3605;&#3629;&#3610;&#3648;&#3617;&#3639;&#3656;&#3629; "+postDate;
	message=decodeHTML(message);
	
	document.getElementById('showExampleMessage').innerHTML=message;

}
function responseShowexample(result){
	var authorName=result.getElementsByTagName('authorName')[0].firstChild.nodeValue;
	var postDate=result.getElementsByTagName('postTime')[0].firstChild.nodeValue;
	var message=result.getElementsByTagName('opinionMSG')[0].firstChild.nodeValue;
	opNode.appendChild(result.getElementsByTagName('opinion')[0]);
	showexampleMessage(authorName,postDate,message);
}
function quote(){
//	alert("aaaa");
//	var opNode=xmlDoc.createElement("op");
//	xmlDoc.appendChild(opNode);
//	alert(xmlDoc.xml);
//	bodygl.innerHTML +='<a onClick="return showquote('+oID+','+tID+',\''+userName+'\')"><img src="imgs/button/quote_0.gif" alt="Quote username='+userName+' Oid='+oID+'" onMouseOver="this.src=\'imgs/button/quote_1.gif\'" onMouseOut="this.src=\'imgs/button/quote_0.gif\'" onMouseDown="this.src=\'imgs/button/quote_2.gif\'" /></a>';
	var tID=document.getElementById('tID').value;
	var oID=-1;
	for (i=0;i<document.getElementById('selectOpinion').options.length ; i++)	{
			if (document.getElementById('selectOpinion').options[i].selected){
					oID=document.getElementById('selectOpinion').options[i].value;
					break;
			}
	}
	if (oID!=-1){
		bodygl.innerHTML +='<input class=quote onClick="showquote(this,'+oID+','+tID+')" type=button value="&#3588;&#3623;&#3634;&#3617;&#3588;&#3636;&#3604;&#3648;&#3627;&#3655;&#3609;&#3607;&#3637;&#3656;'+oID+'" name=quote id="quote'+oID+'"><br/>';
	}
}

//-->