var chooseChoice;
function vote(){
	var topicID=this.id;
	if (chooseChoice!="")
	{
		var opinionID=chooseChoice;
		cp2.call('php/votePoll.php','vote',responesVote,topicID,opinionID);
	}else {
		alert("��س����͡������͡");
	}
	
}
function responesVote(result){
	document.getElementById("content").innerHTML="<span style='cursor:pointer;cursor:hand'><img id='iconAuto' src='imgs/autorefresh.gif'  border='0'  onclick=\"autorefresh()\"/></span><br/>";
	queryData=decodeSpecialChar(result.getElementsByTagName('resultPoll')[0].firstChild.nodeValue);
	document.getElementById("content").innerHTML+='<img id="pieChart" src="php/piechart.php?'+queryData+'"/>';
	alert(result.getElementsByTagName('response')[0].firstChild.nodeValue);
	
	
}

function checkChoice(valueInfo){
	chooseChoice=valueInfo;
}