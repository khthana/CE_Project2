<!--

var amountOption =0;
function showadd_poll(){
	if(!ShAddPoll) {
		document.getElementById('shadd_poll').innerHTML=   "<table><tr><td class=headtopic colspan=2><div align='center'>&#3648;&#3614;&#3636;&#3656;&#3617;&#3585;&#3634;&#3619;&#3607;&#3635;&#3650;&#3614;&#3621;</div></td></tr><tr><td class=headinfo><b>&#3588;&#3635;&#3606;&#3634;&#3617;&#3586;&#3629;&#3591;&#3650;&#3614;&#3621;</b></td><td ><input id='pollqusetion'class=simpletext maxlength=255 size=50 name=poll_title></td></tr><tr><td class=headinfo><b>&#3605;&#3633;&#3623;&#3648;&#3621;&#3639;&#3629;&#3585;</b></td><td ><input id='pollOption' class=simpletext maxlength=255 size=50 name=add_poll_option_text>&nbsp;<input  class=mainoption onClick=cAddOption() type=button value='&#3648;&#3614;&#3636;&#3656;&#3617;&#3605;&#3633;&#3623;&#3648;&#3621;&#3639;&#3629;&#3585;' name=add_poll_option></td></tr> <tr><td class=headinfo><b>&#3592;&#3635;&#3609;&#3623;&#3609;&#3623;&#3633;&#3609;&#3607;&#3637;&#3656;&#3605;&#3657;&#3629;&#3591;&#3585;&#3634;&#3619;&#3651;&#3627;&#3657;&#3650;&#3627;&#3623;&#3605;</b></td><td class =simpletext><input  id=runtime maxlength=3 size=3 name=poll_length> &nbsp;<b>&#3623;&#3633;&#3609;</b> &nbsp;   [ &#3651;&#3626;&#3656; 0 &#3627;&#3619;&#3639;&#3629; &#3648;&#3623;&#3657;&#3609;&#3623;&#3656;&#3634;&#3591;&#3648;&#3629;&#3634;&#3652;&#3623;&#3657;&#3588;&#3639;&#3629;&#3652;&#3617;&#3656;&#3592;&#3635;&#3585;&#3633;&#3604;&#3648;&#3623;&#3621;&#3634;]</td> </tr></table>";  
	 
		  //document.getElementById('shadd_poll').innerHTML= "<td>Add a Poll</td>";
			  ShAddPoll =true;
		 }else { 
		 document.getElementById('shadd_poll').innerHTML= "";
		 document.getElementById("poll_option").innerHTML="";
		 ShAddPoll=false;
		 }
		 return;
}
function cAddOption(){
	addlistOption(document.getElementById("pollOption").value);
}
function addlistOption(pollOption){
	var duplicateOption = checkdup(pollOption);
	if (pollOption !="" &&  !duplicateOption)
	{
		amountOption +=1;
		var getEle = document.getElementById("poll_option");
		if (amountOption==1)
		{
			var createNodeB =document.createElement("I");
			var createtxtNodeB =document.createTextNode("Poll Option");
			getEle.appendChild(createNodeB);
			createNodeB.appendChild(createtxtNodeB);
			createNodeB.setAttribute("class","headtopic");
		}
		var createNodeli =document.createElement("li");
		var createNodeSpan =document.createElement("span");
		var createNodeA =document.createElement("a");
		var createNodeImg =document.createElement("img");
		var createtxtNode =document.createTextNode(pollOption);
		getEle.appendChild(createNodeli);
		createNodeli.appendChild(createNodeSpan);
		createNodeli.appendChild(createNodeA);
		createNodeA.appendChild(createNodeImg);
		createNodeSpan.appendChild(createtxtNode);
		var liId= "li"+ amountOption;
		var optionId= "Option"+ amountOption;
		createNodeli.setAttribute("id",liId);
		createNodeSpan.setAttribute("id",optionId);
		createNodeImg.setAttribute("src","imgs/158-7331.gif");
		createNodeImg.setAttribute("alt","delet option");
		createNodeImg.setAttribute("width","12");
		createNodeImg.setAttribute("height","12");
		createNodeImg.setAttribute("border","0");
		var funcDel = "javascript:cDelOption('"+liId+"')"
		createNodeA.setAttribute("href",funcDel);
		//alert(document.getElementById("poll_option").getElementsByTagName("li")[0].getElementsByTagName("span")[0].innerHTML);
		//alert(optionId);
		//alert(document.getElementById("poll_option").getElementsByTagName("li")[0].getAttribute("id"));
	}else {
		if (pollOption =="")
		{alert ("ใ่ส่ข้อมูลไม่ครบ");}	
	}
	return;
}
function checkdup(pollOption){
	var amountOption =document.getElementById("poll_option").getElementsByTagName("span").length;
	for (var i = 0; i < amountOption ; i++){
		if (pollOption == document.getElementById("poll_option").getElementsByTagName("span")[i].innerHTML)
		{
			alert ("ใ่ส่ข้อมูลไม่ถูกต้อง");
			return true;
		}
	}
	return false;
}
function cDelOption(tagetID){
	var getEle = document.getElementById("poll_option");
	var tagetEle =	document.getElementById(tagetID);
	getEle.removeChild(tagetEle);
	//alert("ss");
	return;
}
//-->
