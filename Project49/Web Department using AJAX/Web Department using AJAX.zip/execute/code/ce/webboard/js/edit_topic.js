
var ShAddPoll =false;
var stickflag=false;
var sendingMsg =false;
var privateRoom = new Array ('network_room','ISAG_room','MML_room','MCL_room','hardware_room','ESL_room','ICT_room','GIG_room','OLALA_room','All_member');
var pollquestion ;
var pollOptions ;
var runtime ;
var runtimeStick;
this.data = new Array(0);
this.topicID = 0;

var cp = new cpaint();
cp.set_response_type('text');
//cp.set_debug(true);

var cp2 = new cpaint();
cp2.set_response_type('XML');
//cp2.set_debug(true);

//-----------------------------------------

function getData(id) {
	this.topicID = id;
	cp.call('php/edit_topic.php','edit_topic',_getData,this.topicID);
	cp2.call('php/edit_topic.php','get_poll',responseGetPollData,this.topicID);
	return;
}
function _getData(result) {
	if (result == 0){
		document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแก้ไขหัวข้อกระทู้นี้ได้</center>";
	}
	else{
		this.data = result.split("&;#@");
		document.getElementById("head").innerHTML = this.data[1];
		document.getElementById("posttime").innerHTML = "เมื่อ " + this.data[5];
	
		if (this.data[0] =="network")
			document.post.Catagory.selectedIndex = 0;
		else if(this.data[0] =="security")
			document.post.Catagory.selectedIndex = 1;
		else if(this.data[0] =="hardware")
			document.post.Catagory.selectedIndex = 2;
		else if(this.data[0] =="software")
			document.post.Catagory.selectedIndex = 3;
		else if(this.data[0] =="course")
			document.post.Catagory.selectedIndex = 4;
		else
			document.post.Catagory.selectedIndex = 5;
	//----------------------------
		if (this.data[3] =="stick"){
			document.getElementById("stickTopic").checked = true;
			document.getElementById("stickDate").disabled = false;
			document.getElementById("stickDate").value = this.data[4];
			stickflag = true;
		}
	//----------------------------
		if(this.data[2].indexOf("A") != -1){
				document.post.publicCk.checked = true;
		}
		else if(this.data[2].indexOf("B") != -1){
				document.post.All_member.checked = true;
				priSelectAll()
				
		}
		else{
			if(this.data[2].indexOf("C") != -1)
				document.post.network_room.checked = true;
			if(this.data[2].indexOf("D") != -1)
				document.post.ISAG_room.checked = true;
			if(this.data[2].indexOf("E") != -1)
				document.post.MML_room.checked = true;
			if(this.data[2].indexOf("F") != -1)
				document.post.MCL_room.checked = true;
			if(this.data[2].indexOf("G") != -1)
				document.post.hardware_room.checked = true;
			if(this.data[2].indexOf("H") != -1)
				document.post.ESL_room.checked = true;
			if(this.data[2].indexOf("I") != -1)
				document.post.ICT_room.checked = true;
			if(this.data[2].indexOf("J") != -1)
				document.post.GIG_room.checked = true;
			if(this.data[2].indexOf("K") != -1)
				document.post.OLALA_room.checked = true;
		}
		
		this.privatecode = "";
		var inc = 0;
		var inc_ = 0;
		var checkboxs = new Array();
		var code = (this.privatecode_).split(":");
		for (j=0;j<code.length-1 ;j++ ){
				
				if(code[j] == 'network_room')
					checkboxs.push(document.post.network_room);
				else if (code[j] == 'ISAG_room')
					checkboxs.push(document.post.ISAG_room);
				else if (code[j] == 'hardware_room')
					checkboxs.push(document.post.hardware_room);
				else if (code[j] == 'ESL_room')
					checkboxs.push(document.post.ESL_room);
				else if (code[j] == 'ICT_room')
					checkboxs.push(document.post.ICT_room);
				else if (code[j] == 'GIG_room')
					checkboxs.push(document.post.GIG_room);
				else if (code[j] == 'OLALA_room')
					checkboxs.push(document.post.OLALA_room);
				else if (code[j] == 'MML_room')
					checkboxs.push(document.post.MML_room);
		}
		for (i=0;i<checkboxs.length ;i++ ){
			if (checkboxs[i].checked == true){
				this.privatecode += checkboxs[i].name +":" ;
				inc_ = i;inc++;
			}
		}
		if (inc <= 0){
			this.privatecode = this.privatecode_;
		}
		else if(inc == 1){
			checkboxs[inc_].disabled = true;
		}
		
		message=decodeSpecialChar(this.data[6]);
		document.getElementById("msg").innerHTML = "<textarea id=\"elm1\" name=\"message\" style=\"width: 100%\">"+message+"</textarea>";
		tinyMCE.addMCEControl(document.getElementById("elm1"),'mce_editpost');
	}
}
function responseGetPollData(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue!="No Poll")
	{
		showadd_poll();
		document.getElementById("buttonPoll").innerHTML="";
		document.getElementById("pollqusetion").value=result.getElementsByTagName('question')[0].firstChild.nodeValue;
		document.getElementById("pollqusetion").disabled=true;
		if (result.getElementsByTagName('runtime')[0].firstChild.nodeValue!="-"){
			document.getElementById("runtime").value=result.getElementsByTagName('runtime')[0].firstChild.nodeValue;
		}
		for (var i=0; i < result.getElementsByTagName('option').length ; i++){
			addlistOption(result.getElementsByTagName('option')[i].firstChild.nodeValue);
		}

	}
}

function getPollOption(){
	var arrayOp =new Array(document.getElementById("poll_option").getElementsByTagName("span").length);
	for (var i = 0; i < document.getElementById("poll_option").getElementsByTagName("span").length ; i++){
		arrayOp[i]=document.getElementById("poll_option").getElementsByTagName("span")[i].innerHTML;
	}
	return arrayOp;
}
function checkPollForm(){
		pollquestion = document.getElementById("pollqusetion").value;
		pollOptions = getPollOption();
		runtime = 0;//no limit for vote poll
			if (document.getElementById("runtime").value!="")
			{
					 if (parseInt(document.getElementById("runtime").value))
					{
						runtime=parseInt(document.getElementById("runtime").value);
					}else {
							alert( "ใส่ข้อมูลให้ถูกต้อง");
							return false;
					}
			}
		if (runtime < 0 || pollquestion ==""  || pollOptions==null)
		{
			alert( "ใส่ข้อมูลไม่ครบ");
			return false;
		}
		return true;
}


function checkStickForm(){

		runtimeStick = 0;//no limit for Stick
		if (document.getElementById("stickDate").value !=""){
			if (parseInt(document.getElementById("stickDate").value)){
				runtimeStick=parseInt(document.getElementById("stickDate").value);
				
			}else {
				alert( "ใส่ข้อมูลให้ถูกต้อง");
				return false;
			}
		}
		if (runtimeStick < 0 ){
			alert( "ใส่ข้อมูลไม่ครบ");
			return false;
		}
		return true;
}

function cPreviewPost() {
	formErrors = false;
	alert( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')));
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	privateCode=calculatePrivatecode();

	if (privateCode=="")
	{
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	
	if (document.post.author.value==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	
	if (ShAddPoll ){
			if (!checkPollForm())
			{
				return;
			}
	}else {
			pollquestion =null ;
			pollOptions = null;
			runtime = null;
	}
	
	if (stickflag){
		if (!checkStickForm()){return;}
	}else{
		runtimeStick=null;
	}
	
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		document.getElementById('respone post').innerHTML= "sending Message Please wait a minute";
		sendingMsg=true;
		cp.call('php/edit_topic.php','previewPost',responseview ,this.topicID,document.getElementById('head').innerHTML, document.post.author.value,document.post.Catagory.value, tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),privateCode,pollquestion,pollOptions,runtime,stickflag,runtimeStick);
		return true;
	}
}

function cPost() {
	
	formErrors = false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	privateCode=calculatePrivatecode();
	if (privateCode==""){
		formErrors = "ใส่ข้อมูลไม่ครบ";
	}
	
	if (sendingMsg){
	formErrors = "กำลังส่งข้อมูล";
	}
	if (ShAddPoll ){
		if (!checkPollForm()){
			return;
		}
	}
	else {
			pollquestion =null ;
			pollOptions = null;
			runtime = null;
	}
	
	if (stickflag){
		if (!checkStickForm()){return;}
	}
	else{
		runtimeStick=null;
	}
	
	if (formErrors) {
		alert(formErrors);
		return false;
	}
	else {
		
		document.getElementById('respone post').innerHTML= "sending Message Please wait a minute";
		sendingMsg=true;
		cp.call('php/edit_topic.php','edit_post',responsePost,this.topicID,document.post.Catagory.value, tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),privateCode,pollquestion,pollOptions,runtime,stickflag,runtimeStick);
		return true;
	}
}

function responseview(result) {
		
		if (result == 0){
			document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแก้ไขหัวข้อกระทู้นี้ได้</center>";
		}
		else{
			document.getElementById('respone post').innerHTML = result;
			document.getElementById("posttime_").innerHTML = ":: เมื่อ  "+ this.data[5] +"  ::" ;
			sendingMsg=false;
		}
}

function responsePost(result){
		
		if (result == 0){
			document.getElementById("Layer2").innerHTML ="<center><h2>คุณไม่สามารถแก้ไขหัวข้อกระทู้นี้ได้</center>";
		}
		else{
			if (result=="Please,Choose private of topic"){
				document.getElementById('respone post').innerHTML = result;
				sendingMsg=false;
			}
			else{
				Set_Cookie("topic","1",60);	
				window.close();
			}
		}
	
}
//-->