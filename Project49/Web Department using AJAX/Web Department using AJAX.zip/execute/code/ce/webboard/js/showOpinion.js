
this.id = ((document.location.search).split("?")[1]).split("=")[1];
this.page_opinion = 1;
this.page_total = 0;
var cp = new cpaint();
cp.set_response_type('text');
cp.set_debug(true);

	function opinion(){
		cp.call('php/opinion.php','opinion',_opinion,this.id,this.page_opinion);
		return;
	}

	function _opinion(result){
	
		if (result != 0){
			document.getElementById("Layer2").innerHTML=result;
			showPoll()
			draw_vote();
			pageNum();
		}
		else{
			document.getElementById("Layer1").innerHTML="";
			document.getElementById("Layer3").innerHTML="";
			document.getElementById("pollArea").innerHTML="";
			document.getElementById("Layer2").innerHTML="<h2>คุณไม่สามารถเข้ากระทู้นี้ได้";
		}
		
	}

	function draw_vote(){
		cp.call('php/opinion.php','draw_vote_del',_draw_vote_del,this.id);
		return;
	}
	
	function _draw_vote_del(result){
		
		var string = "<table class='vote'><tr><td colspan='2' align='center'>คุณเห็นด้วยกับกระทู้นี้&nbsp;&nbsp;หรือไม่</td></tr><tr><td colspan='2' align='left'>&nbsp;<img src='imgs/bar_left.gif' width='3' height='11' border='0' /><img src='imgs/bar_fill.gif' width='134' height='11' border='0'/><img src='imgs/bar_right.gif' width='3' height='11' border='0'/><br/><img src='imgs/bar_down.gif' width='146' height='5' hspace='0' vspace='0' border='0'/></td></tr><tr><td align='left' valign='middle' style='color:blue;'><span style='cursor:pointer;cursor:hand' onclick='vote_topic(0)'><img src='imgs/deny.gif' width='15' height='15' border='0'/>ไม่เห็นด้วย</span></td><td align='right' style='color:blue;'><span style='cursor:pointer;cursor:hand' onclick='vote_topic(1)'>เห็นด้วย<img src='imgs/accept.gif' width='15' height='15' border='0'/></span></td></tr></table>";
		
		var ref = Math.ceil((parseInt(result)*134)/1000);
		
		if (ref < 134){
		
			string = "<table class='vote'><tr><td colspan='2' align='center'>คุณเห็นด้วยกับกระทู้นี้&nbsp;&nbsp;หรือไม่</td></tr><tr><td colspan='2' align='left'>&nbsp;<img src='imgs/bar_left.gif' width='3' height='11' border='0' /><img src='imgs/bar_fill.gif' width='"+ref+"' height='11' border='0'/><img src='imgs/bar_right.gif' width='3' height='11' border='0'/><br/><img src='imgs/bar_down.gif' width='146' height='5' hspace='0' vspace='0' border='0'/></td></tr><tr><td align='left' valign='middle' style='color:blue;'><span style='cursor:pointer;cursor:hand' onclick='vote_topic(0)'><img src='imgs/deny.gif' width='15' height='15' border='0'/>ไม่เห็นด้วย</span></td><td align='right' style='color:blue;'><span style='cursor:pointer;cursor:hand' onclick='vote_topic(1)'>เห็นด้วย<img src='imgs/accept.gif' width='15' height='15' border='0'/></span></td></tr></table>";
			
		}
		document.getElementById("vote").innerHTML = string;
		
	}
	
	function vote_topic(para){
		cp.call('php/opinion.php','vote',_vote,this.id,para);
		return;
	}
	function _vote(result){
		
		if(result == 0){
			alert("คุณไม่สามารถโหวตกระทู้นี้ได้");
		}
		else if(result == 1){
			alert("คุณได้โหวตกระทู้นี้แล้ว");
		}
		else if(result == 2){
			alert("บันทึกการโหวตเรียบร้อยแล้ว");
			draw_vote();
		}
		else{
			alert("บันทึกการโหวตเรียบร้อยแล้วและกระทู้นี้ถูกลบแล้ว ");
			window.close();
		}
	}
	
	function pageNum(){
	
		cp.call('php/opinion.php','pageNum',_pageNum,this.id);
		return;
	}
		
	function _pageNum(result){
			
		//alert(result)
		result = parseInt(result);
		this.page_total = Math.ceil(result/20); 
		if (this.page_total == 0 || isNaN(this.page_total))
			this.page_total = 1;
			
			
			if (this.page_total <= 7 && this.page_opinion <= 7)				
				createpage(1,this.page_total);
			else if (this.page_total > 7 && this.page_opinion <= 7)
				createpage(1,7);
			else if(this.page_opinion > 7 && this.page_opinion < (this.page_total - 2))
				createpage(this.page_opinion - 3,this.page_opinion + 3);
			else 
				createpage(this.page_total - 2,this.page_total);
			
		document.getElementById('page').innerHTML="หน้า "+ this.page_opinion +" จาก  "+ this.page_total;
			
	}

	function next(){
	
		if (this.page_opinion == this.page_total ){
			return;
		}
		else{
			this.page_opinion += 1;
			opinion();
			window.scrollTo(0,0);
		}
	}
	function prev(){
	
		if (this.page_opinion == 1){
			return;
		}
		else{
			this.page_opinion -= 1;
			opinion();
			window.scrollTo(0,0);
		}
	}
		
	function forward_view(currentpage){
		this.page_opinion = currentpage;
		opinion();
		return;
	}
		
	function createpage(beginpage,endpage){
		string = "&nbsp;&nbsp;&nbsp;&nbsp;";
		for(i = beginpage;i <= endpage;i++){
			string = string + "<span style='cursor:pointer;cursor:hand;'  onclick='forward_view(" + i + ")'>" + i + "</span>&nbsp;&nbsp;&nbsp;&nbsp;";
		}
			
		document.getElementById("link_page").innerHTML=string;
		return;
	}
	
	function delete_opinion(tID,oID){
		var ret = confirm("คุณแน่ใจที่จะลบความคิดเห็นนี้หรือไม่");
		if (ret == true){
			cp.call('php/opinion.php','delete_opinion',_delete_opinion,tID,oID);
			this.oID = oID;
		}
		return;	
	}
		
	function _delete_opinion(result){
		if(result == "false"){
			alert("คุณไม่สามารถลบความคิดเห็นนี้ได้");
		}
		else if(result == "true"){
			string = "opinion_" + this.oID;
			var table = document.getElementById(string);
			table.parentNode.innerHTML="";
			alert("คุณได้ลบความคิดเห็นนี้แล้ว");
		}
	}
	
	//----------------
	function delete_topic(){
		var ret = confirm("คุณแน่ใจที่จะลบหัวข้อกระทู้นี้หรือไม่");
		if (ret == true)
			cp.call('php/opinion.php','delete_topic',_delete_topic,this.id);
		
		return;
	}
	
	function _delete_topic(result){
		if(result == "true"){
			alert("คุณได้ลบกระทู้นี้แล้ว");
			window.close();
		}
		else if(result == "false")
			alert("คุณไม่สามารถลบกระทู้นี้ได้");
	}
	
	function warehouse(){
		var ret = confirm("คุณแน่ใจที่จะเก็บกระทู้นี้ลงคลังกระทู้เก่าหรือไม่");
		if (ret == true)
			cp.call('php/opinion.php','warehouse',_warehouse,this.id);
		return;
	}
	
	function _warehouse(result){
		if(result == "true")
			alert("คุณได้เก็บกระทู้นี้ลงคลังกระทู้เก่าแล้ว");
		else if(result == "false")
			alert("คุณไม่สามารถเก็บกระทู้นี้ลงคลังกระทู้เก่าได้");
	}
	
	function reply_topic(){
		
		Set_Cookie("reply","0",500);
		setTimeout("check_reply()",1000);
		string = "post_newOpinion.php"+(document.location.search);
		window.open(string,'newwin');
		
	}
	
	function check_reply(){
		
		cookie = Get_Cookie('reply');
		
		if(cookie =='0'){
			setTimeout("check_reply()",1000);
		}
		else if(cookie == '1'){
			cp.call('php/opinion.php','check_reply',_check_reply,this.id,this.page_opinion);
		}
	}
	
	function _check_reply(result){
		document.getElementById("Layer2").innerHTML = document.getElementById("Layer2").innerHTML + result;
		pageNum();
	}
	
	function check_edit_topic(){
		
		Set_Cookie("topic","0",1500);
		setTimeout("check_edit_topic_()",1000);
		string = "showedit_topic.php?tID=" + this.id;
		window.open(string,'newwin');
		
	}
	
	function check_edit_topic_(){
		
		cookie = Get_Cookie('topic');
		
		if(cookie =='0'){
			setTimeout("check_edit_topic_()",1000);
		}
		else if(cookie == '1'){
			cp.call('php/opinion.php','check_edit_topic',_check_edit_topic,this.id);
		}
		
	}

	function _check_edit_topic(result){
		
		data = result.split("&;#@");
		if (result == 'false')
			return;
		else{
			
			var table = document.getElementById("Topic");
			var msg = table.getElementsByTagName("td").item(3);
			var edittime = table.getElementsByTagName("td").item(5);
			var ip = table.getElementsByTagName("td").item(6);
			msg.innerHTML = data[2];
			edittime.innerHTML =":: แก้ไขเมื่อ " + data[1] + " ::";
			ip.innerHTML = "IP::"+data[0];
		}
	}
	
	function check_edit_opinion(oID){
		
		this.oID = oID;
		Set_Cookie("opinion","0",1500);
		setTimeout("check_edit_opinion_()",1000);
		string = "showedit_opinion.php?tID="+ this.id + "&oID=" + this.oID;
		window.open(string,'newwin');
		
	}
	
	function check_edit_opinion_(){
		
		cookie = Get_Cookie('opinion');
		
		if(cookie =='0'){
			setTimeout("check_edit_opinion_()",1000);
		}
		else if(cookie == '1'){
			cp.call('php/opinion.php','check_edit_opinion',_check_edit_opinion,this.id,this.oID);
		}
	}
	
	function _check_edit_opinion(result){
		
		data = result.split("&;#@");
		string = "opinion_" + this.oID;
		if (result == 'false')
			return;
		else{
			
			var table = document.getElementById(string);
			var msg = table.getElementsByTagName("td").item(3);
			var edittime = table.getElementsByTagName("td").item(5);
			var ip = table.getElementsByTagName("td").item(6);
			msg.innerHTML = data[2];
			edittime.innerHTML =":: แก้ไขเมื่อ " + data[1] + " ::";
			ip.innerHTML = "IP::"+data[0];
		}
	}
	