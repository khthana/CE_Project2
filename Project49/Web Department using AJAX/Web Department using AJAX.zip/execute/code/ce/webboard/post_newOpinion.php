<?php
	include("../_Sessionstart.php");
	if(isset($_GET['tID']) and $_GET['tID']!=""){
		echo '<input id="tID" name="topicID" type="hidden" value="'.$_GET['tID'].'" />';
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<HTML ><HEAD><TITLE></TITLE>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link  href="css/quote.css" type=text/css rel=stylesheet >
<link rel="stylesheet" type="text/css" href="css/opinion.css"> 
<link rel="stylesheet" type="text/css" href="css/tiny.css">

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
<script type="text/javascript" src="js/reply.js"></script>
<script type="text/javascript" src="js/showQuote.js"></script>
<script type="text/javascript" src="js/quote.js"></script>
<script type="text/javascript" src="../tool/cookies.js"></script>
</HEAD>
<body >
<br/>
<div id="Layer1" align="center">
 	<table width="750" border="0" cellpadding="0" cellspacing="0">
			<tr>
        		<td align="center" ><img  border="0" src="../images/logo.gif" width="640" height="135"></td>
			</tr>
			<tr ><td   colspan="2" height="15"></td></tr>
    </table>
</div>
<div id="Layer2">
	<div id="reply">
 		<FORM name=post >
	  		<table width="750" border="0" align="center"  background="imgs/bg_Midtop.gif" bgcolor="#CCCCCC">
  		  		<tr>
    				<td class=simpletext> &#3612;&#3641;&#3657;&#3605;&#3629;&#3610;&#3585;&#3619;&#3632;&#3607;&#3641;&#3657; 
					<?php
						if($_SESSION['ss_Status']=="online"){
							print $_SESSION['ss_UserName'];
							echo "<input type='hidden' name='author' value='". $_SESSION['ss_UserName']."'>";
						}
							else echo "<input type='text' name='author'>";
					?></td>
	  	  		</tr>
          		<tr>
            		<td class=simpletext><b>&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;  </b></td>
          		</tr>
		        <tr>
            		<td>
			    		<textarea name="message" id="elm1" style="width:100%;"  ></textarea>
            	</td>
		  		</tr>
		 	</table>
	 	</FORM>
	</div>
  	<table  border="0" align="center">
   		<tr>
          <td   height=13  align="center">
				<input class="mainoption" onClick="cPost()" type="button" value="Submit" name="_post">
				<input class="mainoption" onClick="cPreviewPost()" type="button" value="View" name="example">
		  </td>
    	</tr>
		<tr>
			<td height=13 colspan="2" align="center" >
				<br/>
				<div id="respone post" align="center" class="opinion"></div>
			</td>
		</tr>
   	</table>
	<div id="selectQuoteArea" align="center">
		<hr align="center" width="750"/>
			<?php 
				include("php/selectquote.php");
			?>
		<br/>
	</div> 
</div>
</body>
</HTML>
<script type="text/javascript" >
		tinyMCE.addMCEControl(document.getElementById("elm1"),'mce_opinion');
		showexample();
		if (((document.location.search).split("oID")[1])!=null){
			if (((document.location.search).split("oID")[1]).split("=")[1]!=null){
				quote();
			}
		}
</script>