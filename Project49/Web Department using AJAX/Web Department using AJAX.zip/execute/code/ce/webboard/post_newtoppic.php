<?php
	include("../_Sessionstart.php");
	$_SESSION['ss_PageBefore']="";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML ><HEAD><TITLE></TITLE>


<META http-equiv=Content-Type content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/opinion.css"> 
<link rel="stylesheet" type="text/css" href="css/tiny.css">


<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
<script type="text/javascript" src="js/privilege_topic.js"></script>
<script type="text/javascript" src="js/en_decode_utf8.js"></script>
<script type="text/javascript" src="js/menuPoll.js"></script>
<script type="text/javascript" src="js/menuStick.js"></script>
<script type="text/javascript" src="js/post.js"></script>
</HEAD>
<body>
<br/>
<div id="Layer1" align="center">
    <table width="750" border="0" cellpadding="0" cellspacing="0">
			<tr>
        		<td align="center" ><img  border="0" src="../images/logo.gif" width="640" height="135"></td>
			</tr>
			<tr ><td   colspan="2" height="15"></td></tr>
    </table>
</div>
 <FORM name=post onSubmit="" >
	  <table width="750" border="0" align="center" background="imgs/bg_Midtop.gif" bgcolor="#CCCCCC">
  		<tr>
    		<td colspan="2" class=headtopic><strong>หัวข้อ</strong>
        		<input class=post  id="toppic" style="WIDTH: 450px" tabindex=2 maxlength=90 size=45 name=subject>
            </span></td>
        </tr>
  		<tr>
    		<td width="50%" class=simpletext> ผู้ตั้งกระทู้ &nbsp;&nbsp;
	<?php
		if($_SESSION['ss_Status']=="online"){
			print $_SESSION['ss_UserName'];
			echo "<input type='hidden' name='author' value='". $_SESSION['ss_UserName']."'>";
		}
		else echo "<input type='text' name='author' maxlength=20>";
	?>
			</td>
	  		<td width="50%" class=simpletext>กระทู้นี้อยู่ในหมวด 
	    	  <select name="Catagory" id="Catagory">
	      	<option value="network">network</option>
	      	<option value="security">computer security</option>
	     	<option value="hardware">hardware</option>
	      	<option value="software">sotfware</option>
	      	<option value="course">รายวิชา</option>
	      	<option value="etc" selected>อื่นๆ</option>
	    	</select>
  		  </td>
  		</tr>
        <tr>
            <td colspan="2" class=simpletext><b>ข้อความ  </b></td>
        </tr>
        <tr>
           <td colspan="2" valign=top class=row2>
			    <textarea name="message" id="elm1" style="width:100%;"  ></textarea>
            </td>
		  </tr>
		 </table>
<br/>
<?php
		//echo $_SESSION['ss_Status'];
		if($_SESSION['ss_Status']=="online"){
?>
<div id="pri_topic">
   <table width="750" border="0" align="center" background="imgs/bg_Midtop.gif" bgcolor="#FFBB77" class="simpletext">
   <?php
		//echo $_SESSION['ss_Status'];
		if($_SESSION['ss_Level']=="admin"){
?>

<tr>
      <td height=23 colspan="2"><p><span class="headtopic">ต้องการให้เป็นกระทู้ปักหมุด</span></p></td>
      <td height=23 colspan="4"><input name="stick" type="checkbox" id="stickTopic" value="1" onClick="stickmode()">        
         จำนวนวัน 
           <input id="stickDate" name="expStickDate" type="text" size="5" disabled="disabled"> วัน (ใส่ 0 หรือ เว้นว่างไว้ คือ ไม่จำกัดเวลา) </td>
      </tr>
	<?php
		}
	?>
    	<tr>
      		<td height=23 colspan=5 align="left" valign="top"><p><span class="headtopic">ต้องการแสดงกระทู้นี้กับผู้ใด</span> </p></td>
    	</tr>
    	<tr>
      		<td width="42"></td>
      		<td width="156">
        		<input onClick='pubCheck()' id="publicCk" name="publicCk" type="radio" value="public " checked>กระทู้สาธารณะ</td>
    	</tr>
    	<tr>
      		<td></td>
      		<td><input onClick='priSwitch()' id="privateCk" name="privateCk" type="radio" value="private">กระทู้ภายใน</td>
	    	<td height=2 ><div align="left" class="checkname"><a href="javascript:selectAllRoom()"></a>
              <input name="All_member" id="All_member" type="checkbox" onClick='priSelectAll()' value="B">
              All member </div>			</td>
    	</tr>
    	<tr>
			<td></td>
			<td></td>
      		<td width="135" height=2 ><div align="left" class="checkname">
	  	  	<?php
		  		 $c = strpos($_SESSION['ss_privcode'],'C');
				 if ($c == "")
				 	echo "<span><input name='network_room' id='network_room' type='checkbox' onClick='priCheck(this.name)' value='C' />   ";
				 else
					echo "<span class='pri'><input name='network_room' id='network_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='C' checked />";
						 	
		  ?>
        NETWORK room</span></div></td>
      		<td width="122" ><div align="left" class="checkname">
	  	  	<?php
				  $c = strpos($_SESSION['ss_privcode'],'D');
				  if ($c == "")
					echo "<span><input name='ISAG_room' id='ISAG_room' type='checkbox' onClick='priCheck(this.name)' value='D'  /> ";
				  else 
				 	echo "<span class='pri'><input name='ISAG_room' id='ISAG_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='D' checked/> ";
		  ?>
        ISAG room</span></div></td>
      		<td width="123" ><div align="left" class="checkname">
	   	  	<?php
		  		 $c = strpos($_SESSION['ss_privcode'],'E');
				  if ($c == "")
					echo "<span><input name='MML_room' id='MML_room' type='checkbox' onClick='priCheck(this.name)' value='E'  /> ";
				 else 
				 	echo "<span class='pri'><input name='MML_room' id='MML_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='E' checked/> ";
		  ?>
	  	 
        MML room</span></div></td>
		</tr>
		<tr>
	  		<td></td>
	  		<td></td>
      		<td width="135" ><div align="left" class="checkname">
	  
	  	  	 <?php
		  			$c = strpos($_SESSION['ss_privcode'],'F');
				  		if ($c == "")
							echo "<span><input name='MCL_room' id='MCL_room' type='checkbox' onClick='priCheck(this.name)' value='F'/> ";
				 		else 
				 			echo "<span class='pri'><input name='MCL_room' id='MCL_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='F'  checked/> ";
		  ?>
         
        MCL room </span></div></td>
      		<td width="122" height=2 ><div align="left" class="checkname">
	  		
		  	<?php
		  			$c = strpos($_SESSION['ss_privcode'],'G');
				  		if ($c == "")
				 			echo "<span><input name='hardware_room' id='hardware_room' type='checkbox' onClick='priCheck(this.name)' value='G' /> ";
				 		else 
				 			echo "<span class='pri'><input name='hardware_room' id='hardware_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='G'  checked /> ";
		  ?>
         
        HARDWARE room</span></div></td>
	  		<td width="123" height=2 ><div align="left" class="checkname">
	  
	  	  	 <?php
		  			$c = strpos($_SESSION['ss_privcode'],'H');
				  		if ($c == "")
							echo "<span><input name='ESL_room' id='ESL_room' type='checkbox' onClick='priCheck(this.name)' value='H' /> ";
				 		else 
				 			echo "<span class='pri'><input name='ESL_room' id='ESL_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='H'  checked/>";
		  ?>
          
        ESL room</span> </div></td>
    	</tr>
    	<tr>
      		<td></td>
	  		<td></td>
      		<td width="135" ><div align="left" class="checkname">
	      	<?php
		  			$c = strpos($_SESSION['ss_privcode'],'I');
				  		if ($c == "")
				 			echo "<span><input name='ICT_room' id='ICT_room' type='checkbox' onClick='priCheck(this.name)' value='I' /> ";
				        else 
				 	      	echo "<span class='pri'><input name='ICT_room' id='ICT_room' type='checkbox'  onClick='priCheck(this.name)' value='I' checked />";
		  ?>
         
        ICT room</span></div></td>
      		<td width="122" ><div align="left" class="checkname">
	  	  	 <?php
		  			$c = strpos($_SESSION['ss_privcode'],'J');
				  		if ($c == "")
				 			echo "<span><input name='GIG_room' id='GIG_room' type='checkbox' onClick='priCheck(this.name)' value='J'/> ";
				 		else 
				 			echo "<span class='pri'><input name='GIG_room' id='GIG_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='J' checked />";
		  ?>
          
        GIG room</span></div></td>
      		<td width="123" ><div align="left" class="checkname">
	  	   	 <?php
		   			$c = strpos($_SESSION['ss_privcode'],'K');
				  		if ($c == "")
				 			echo "<span><input name='OLALA_room' id='OLALA_room' type='checkbox' onClick='priCheck(this.name)' value='K'/> ";
				 		else 
				 			echo "<span class='pri'><input name='OLALA_room' id='OLALA_room' type='checkbox' class='pri' onClick='priCheck(this.name)' value='K' checked />";
		  ?>
          
        OLALA room</span></div></td>
    	</tr>
  	</table>
</div>

      <table width="750" border="0" align="center" background="imgs/bg_Midtop.gif" bgcolor="#FFB66C">
      		<tr>
		  	  <td  height=6 colspan=5 align=middle><div align="left"><a href="javascript:showadd_poll()"><img src="imgs/Add_poll.gif" width="60" height="18" border="0"></a></div></td>
			</tr>
			<tr>
				<td><div id="shadd_poll" ></div></td>
			</tr>
			<tr>
				<td><div id="poll_option" ></div></td>
			</tr>
	   </table> 
   <?php }	?>     
 </FORM>
 <table border="0" align="center">
   <tr>
       <td height=13 >
			<div align="center">
  				<input class=mainoption onClick=cPost() type=button value=Submit name=post>
  				<input class=mainoption onClick=cPreviewPost() type=button value=View name=exsample>
			</div>
	 </td>
   </tr>
		<tr>
			<td height=13 colspan="2" align="center" >
				<div id="respone post" align="center" class="opinion"></div>
			</td>
		</tr>
 </table>
  
 <script>
 		if (document.post.privateCk != null ){
			pri_room();
			pubCheck();
			
		}
		tinyMCE.addMCEControl(document.getElementById("elm1"),'mce_topic');
 </script>
</body>
</html>
