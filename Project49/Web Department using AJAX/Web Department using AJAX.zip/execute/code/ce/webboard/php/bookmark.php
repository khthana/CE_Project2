<?php

include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("_Bookmark.php");
session_start();
$cp = new cpaint();
$cp->register('selfbookmark');
$cp->register('bookmark_1');
$cp->register('bookmark_2');
$cp->register('pageNum_1');
$cp->register('pageNum_2');
$cp->register('del_bookmark');
$cp->start();
$cp->return_data();

function selfbookmark($topicID){
	global $cp;
	connectdb();
	if ($_SESSION['ss_UserID'] !=0 ){
		if (bookmark($_SESSION['ss_UserID'], $topicID,"selfbook")){
			$cp->set_data("บันทึกกระทู้เรียบร้อยแล้ว");
		}else{
			$cp->set_data("ท่านได้บันทึกกระทู้นี้แล้ว");
		}
	}else 
		$cp->set_data("กรุณาล็อคอินเข้าระบบ");

}
//-------------------------------------------------------

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "( t1.PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR t1.PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}

function bookmark_1($i){

	global $cp;
	connectdb();

	$page = 25;
	$start = ($i - 1) * $page;

	$sql = "SELECT t1.TOPIC_ID,CATEGORY,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME FROM main_topic AS t1 INNER JOIN book_mark AS t2 ON t1.TOPIC_ID = t2.TOPIC_ID WHERE t2.USER_ID ='".$_SESSION['ss_UserID']."' AND t2.TYPE !='selfbook' AND ";
	
	$sql = privatecode($sql);
	$sql = $sql." ORDER BY 1 DESC LIMIT ";
	$sql = $sql.$start.",".$page;

	$result = mysql_query($sql);

	$tempstring = "<rows>";

	while ( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicid        = $tempresult["TOPIC_ID"];
		$Tempcategory       = $tempresult["CATEGORY"];
		$Temptopicheader    = $tempresult["TOPIC_HEADER"];
		$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
		$updatetime			= $tempresult["UPDATE_TIME"];
		$Tempupdatetime	    = date("j-m-y G:i",$updatetime);		
		$tempstring=$tempstring."<row id='$Temptopicid'>";
		
		$tempstring=$tempstring."<cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ";
		
		if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
			
		 
		$tempstring=$tempstring." onmouseout='writetxt(0)'/>]]></cell><cell><![CDATA[<A href='showOpinion.php?tID=$Temptopicid' target=_blank>$Temptopicheader<A>";
		
		if(ceil((time() - $updatetime)/(60*60*24)) <= 1){
			
			$tempstring=$tempstring."  <img class='update' src='imgs/update.gif'/>";
		}

		$tempstring=$tempstring."]]></cell><cell>$Tempauthorname</cell><cell>$Tempupdatetime</cell><cell><![CDATA[<IMG src='imgs/junk.gif' onclick='del_bookmark($Temptopicid,1);' style='cursor:pointer;cursor:hand;' onmouseover=\"writetxt('ลบกระทู้นี้')\" onmouseout='writetxt(0)'/>]]></cell></row>";

		
	}

	$tempstring = $tempstring . "</rows>"; 

	$cp->set_data($tempstring);	
	echo mysql_error();
}

function pageNum_1($searchKey){

	global $cp;
	connectdb();
		
	$sql = "SELECT COUNT(*) FROM main_topic AS t1 INNER JOIN book_mark AS t2 ON t1.TOPIC_ID = t2.TOPIC_ID WHERE t2.USER_ID ='".$_SESSION['ss_UserID']."' AND t2.TYPE !='selfbook' AND ";
	
	$sql = privatecode($sql);
		
	$temprow = mysql_fetch_array(mysql_query($sql));
	$ret = (int)($temprow[0]);
	$cp->set_data($ret);	
	//$cp->set_data(500);	

}

//--------------------------------------------------------------------------------

function bookmark_2($i){

	global $cp;
	connectdb();

	$page = 25;
	$start = ($i - 1) * $page;

	$sql = "SELECT t1.TOPIC_ID,CATEGORY,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME FROM main_topic AS t1 INNER JOIN book_mark AS t2 ON t1.TOPIC_ID = t2.TOPIC_ID WHERE t2.USER_ID ='".$_SESSION['ss_UserID']."' AND t2.TYPE ='selfbook' AND ";
	
	$sql = privatecode($sql);
	$sql = $sql." ORDER BY 1 DESC LIMIT ";
	$sql = $sql.$start.",".$page;

	$result = mysql_query($sql);

	$tempstring = "<rows>";

	while ( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicid        = $tempresult["TOPIC_ID"];
		$Tempcategory       = $tempresult["CATEGORY"];
		$Temptopicheader    = $tempresult["TOPIC_HEADER"];
		$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
		$updatetime			= $tempresult["UPDATE_TIME"];
		$Tempupdatetime	    = date("j-m-y G:i",$updatetime);	
				
		$tempstring=$tempstring."<row id='$Temptopicid'>";
		
		$tempstring=$tempstring."<cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ";
		
		if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
			
		
		$tempstring=$tempstring." onmouseout='writetxt(0)'/>]]></cell><cell><![CDATA[<A href='showOpinion.php?tID=$Temptopicid' target=_blank>$Temptopicheader<A>";
		
		if(ceil((time() - $updatetime)/(60*60*24)) <= 1){
			
			$tempstring=$tempstring."  <img class='update' src='imgs/update.gif'/>";
		}

		$tempstring=$tempstring."]]></cell><cell>$Tempauthorname</cell><cell>$Tempupdatetime</cell><cell><![CDATA[<IMG src='imgs/junk.gif' onclick='del_bookmark($Temptopicid,2);' style='cursor:pointer;cursor:hand' onmouseover=\"writetxt('ลบกระทู้นี้')\" onmouseout='writetxt(0)'/>]]></cell></row>";

		
	}

	$tempstring = $tempstring . "</rows>"; 

	$cp->set_data($tempstring);	
	
}

function pageNum_2($searchKey){

	global $cp;
	connectdb();
		
	$sql = "SELECT COUNT(*) FROM main_topic AS t1 INNER JOIN book_mark AS t2 ON t1.TOPIC_ID = t2.TOPIC_ID WHERE t2.USER_ID ='".$_SESSION['ss_UserID']."' AND t2.TYPE ='selfbook' AND ";
	
	$sql = privatecode($sql);
		
	$temprow = mysql_fetch_array(mysql_query($sql));
	$ret = (int)($temprow[0]);
	$cp->set_data($ret);	
	//$cp->set_data(500);	

}


function del_bookmark($id){

	global $cp;
	connectdb();
	
	$sql="DELETE FROM book_mark WHERE TOPIC_ID =".$id." AND USER_ID =".$_SESSION['ss_UserID'];
	if(mysql_query($sql)){
		$cp->set_data("true");
	}
	else
		$cp->set_data("false");	

}

?>