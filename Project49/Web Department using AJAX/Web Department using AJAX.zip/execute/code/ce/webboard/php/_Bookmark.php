<?php
function bookmark($userID, $topicID,$type){
	if ($userID!=0){
		$comSQLbookmark="INSERT INTO book_mark SET".
			" USER_ID=".$userID.
			",TOPIC_ID=".$topicID.
			",TYPE='".$type."'";
		$bookmarkresult=mysql_query($comSQLbookmark);
		if (!mysql_error()){
			return true;
		}else{
			return false;
		}
	}else 
		return false;
}
?>