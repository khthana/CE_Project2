<?php


include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('view');
$cp->register('autorefresh_1');
//$cp->register('autorefresh_3');
$cp->register('pageNum_1');
$cp->register('pageNum_3');
$cp->register('search_topic');
$cp->register('search_warehouse');
$cp->register('pageNum_2');

$cp->start();
$cp->return_data();

function _check($_sql,$_network,$_hardware,$_software,$_security,$_course,$_etc){

	$check = 0;
	$temp ="";
	if ($_network == 1){
		$temp = $temp."CATEGORY ='network' ";
		$check = 1;
	}
	if ($_hardware == 1){
		if ($check == 1)
			$temp = $temp."OR CATEGORY ='hardware' ";
		else{
			$temp = $temp."CATEGORY ='hardware' ";
			$check = 1;
		}
	}
	if ($_software == 1){
		if ($check == 1)
			$temp = $temp."OR CATEGORY ='software' ";
		else{
			$temp = $temp."CATEGORY ='software' ";
			$check = 1;
		}
	}
	if ($_security == 1){
		if ($check == 1)
			$temp = $temp."OR CATEGORY ='security' ";
		else{
			$temp = $temp."CATEGORY ='security' ";
			$check = 1;
		}
	}
	if ($_course == 1){
		if ($check == 1)
			$temp = $temp."OR CATEGORY ='course' ";
		else{
			$temp = $temp."CATEGORY ='course' ";
			$check = 1;
		}
	}
	if ($_etc == 1){
		if ($check == 1)
			$temp = $temp."OR CATEGORY ='etc' ";
		else{
			$temp = $temp."CATEGORY ='etc' ";
			$check = 1;
		}
	}

	return $_sql.$temp;

}

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "( PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}


function view($i,$network,$hardware,$software,$security,$course,$etc){
	global $cp;
		
	connectdb();
	
	$sql ="update main_topic set TYPE ='normal' where STICK_EXPIRE_IN_DAY < ".time();
	mysql_fetch_array(mysql_query($sql)); 
	
	$row = 0;
	$row_page = 0;
	$string = "";
	$tempstring = "<rows>";
		
	$temprow = mysql_fetch_array(mysql_query("SELECT MAX(Topic_id) FROM main_topic"));
	
	
	if ($i == 1){
					
		$sql="SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM main_topic WHERE (";
		$sql =_check($sql,$network,$hardware,$software,$security,$course,$etc);
		
		//$sql = $sql.") AND (STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time();
		$sql = $sql.") AND TYPE ='stick' AND ";
		$sql = privatecode($sql);
		$sql = $sql." ORDER BY 1 DESC LIMIT 0,20";
		
		$result = mysql_query($sql);
		
		while ( $tempresult = mysql_fetch_array($result)){
		
			$Temptopicid        = $tempresult["TOPIC_ID"];
			$Temptype			= $tempresult["TYPE"];
			$Tempcategory       = $tempresult["CATEGORY"];
			$Temptopicheader    = $tempresult["TOPIC_HEADER"];
			$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
			$posttime			= $tempresult ["POST_TIME"];
			$Tempposttime	    = date("j-m-y G:i",$posttime);
			$updatetime			= $tempresult["UPDATE_TIME"];
			$Tempupdatetime	    = date("j-m-y G:i",$updatetime);
			$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
			$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
			$tempstring=$tempstring."<row id='$Temptopicid'><cell><![CDATA[<IMG src='imgs/$Temptype.gif' ";
			
			if($Temptype == 'normal'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ทั่วไป')\"";
			}
			else if($Temptype == 'poll'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้โพล')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ปักหมุด')\"";
			}
			
			$tempstring=$tempstring." onmouseout='writetxt(0)' />]]></cell><cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ";
			
			if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
			
			$tempstring=$tempstring." onmouseout='writetxt(0)'/>]]></cell><cell><![CDATA[<A href='showOpinion.php?tID=$Temptopicid' target='_blank'>$Temptopicheader</A>";
			
			if(ceil((time() - $posttime)/(60*60*24)) <= 1){
			
				$tempstring=$tempstring."  <img class='new' src='imgs/new.gif'/>";
			}
			else if(ceil((time() - $updatetime)/(60*60*24)) <= 1){
			
				$tempstring=$tempstring."  <img class='update' src='imgs/update.gif'/>";
			}
			
			$tempstring=$tempstring."]]></cell><cell>$Tempauthorname</cell><cell>$Tempposttime </cell><cell>$Tempupdatetime</cell><cell>$Tempviewtopic</cell><cell>$Tempreplytopic</cell></row>";

		  	$row_page++;
		}
		
		$page = 25 - $row_page; //25
		$start = 0;
	
		$_SESSION['ss_Topic_id_1'] =  $temprow[0].":".$row_page;
		
	}
	else{
			
		$sql ="SELECT COUNT(*) FROM main_topic WHERE (";
		$sql =_check($sql,$network,$hardware,$software,$security,$course,$etc);
		//$sql = $sql.") AND ( STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time();
		$sql = $sql.") AND TYPE ='stick' AND ";
		$sql = privatecode($sql);
		
		$result = mysql_fetch_array(mysql_query($sql));
		if ($result[0] > 20)
			$row_page = 20;
		else
			$row_page = $result[0];
		
		$page = 25 ;//25
		$start = ($i - 1) * 25  - $row_page ;	//25
		$autorefresh = explode(":",$_SESSION['ss_Topic_id_1'] );
		$_SESSION['ss_Topic_id_1'] =  $autorefresh[0].":".$row_page;
	}
	
	
	
	$sql="SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM main_topic WHERE (";
	$sql =_check($sql,$network,$hardware,$software,$security,$course,$etc);
	//$sql = $sql.") AND PRIV_CODE LIKE ";
	//$sql = $sql."'%".$_SESSION['ss_privcode']."%'";
	$sql = $sql.") AND POINT_DEL > 0 ";
	$sql = $sql." AND TYPE !='stick' AND ";
	$sql = privatecode($sql);
	$sql = $sql." ORDER BY 1 DESC LIMIT ";
	$sql = $sql.$start.",".$page;
	
	$result = mysql_query($sql);
		
	while ( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicid        = $tempresult["TOPIC_ID"];
		$Temptype			= $tempresult["TYPE"];
		$Tempcategory       = $tempresult["CATEGORY"];
		$Temptopicheader    = $tempresult["TOPIC_HEADER"];
		$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
		$posttime			= $tempresult ["POST_TIME"];
		$Tempposttime	    = date("j-m-y G:i",$posttime);
		$updatetime			= $tempresult["UPDATE_TIME"];
		$Tempupdatetime	    = date("j-m-y G:i",$updatetime);
		$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
		$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
		
		$tempstring=$tempstring."<row id='$Temptopicid'><cell><![CDATA[<IMG src='imgs/$Temptype.gif' ";
		
		if($Temptype == 'normal'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ทั่วไป')\"";
			}
			else if($Temptype == 'poll'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้โพล')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ปักหมุด')\"";
			}
			
		$tempstring=$tempstring." onmouseover='writetxt(this.alt)' onmouseout='writetxt(0)'/>]]></cell><cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ";
		
		if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
		
		$tempstring=$tempstring." onmouseover='writetxt(this.alt)' onmouseout='writetxt(0)'/>]]></cell><cell><![CDATA[<A href='showOpinion.php?tID=$Temptopicid' target='_blank'>$Temptopicheader</A>";

		if(ceil((time() - $posttime)/(60*60*24)) <= 1){
			
				$tempstring=$tempstring."  <img class='new' src='imgs/new.gif'/>";
		}
		else if(ceil((time() - $updatetime)/(60*60*24)) <= 1){
			
				$tempstring=$tempstring."  <img class='update' src='imgs/update.gif'/>";
		}
		
		$tempstring=$tempstring."]]></cell><cell>$Tempauthorname</cell><cell>$Tempposttime </cell><cell>$Tempupdatetime</cell><cell>$Tempviewtopic</cell><cell>$Tempreplytopic</cell></row>";
	}
	
	$tempstring = $tempstring . "</rows>"; 

	$cp->set_data($tempstring);	
		
}
	
function autorefresh_1($network,$hardware,$software,$security,$course,$etc){
	global $cp;
	connectdb();
	
	$rowold = explode(":",$_SESSION['ss_Topic_id_1']);
	$stick = 0;
	$temprow = mysql_fetch_array(mysql_query("SELECT MAX(TOPIC_ID) FROM main_topic"));
	$rownew =  $temprow[0];
	
	if((int)($rowold[0]) < $rownew ){
	
		$sql="SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM main_topic WHERE (";
		$sql = _check($sql,$network,$hardware,$software,$security,$course,$etc);
		$sql = $sql.") AND TOPIC_ID > ";
		$sql = $sql.(int)($rowold[0])." AND ";
		$sql = privatecode($sql);
	
			
		$result = mysql_query($sql);
		while ( $tempresult = mysql_fetch_array($result)){

			$Temptopicid        = $tempresult["TOPIC_ID"];
			$Temptype			= $tempresult["TYPE"];
			$Tempcategory       = $tempresult["CATEGORY"];
			$Temptopicheader    = $tempresult["TOPIC_HEADER"];
			$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
			$Tempposttime	    = date("j-m-y G:i",$tempresult ["POST_TIME"]);
			$Tempupdatetime	    = date("j-m-y G:i",$tempresult["UPDATE_TIME"]);
			$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
			$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
		
			$tempstring=$tempstring."$Temptopicid,<IMG src='imgs/$Temptype.gif' onmouseout='writetxt(0)' ";
			
			if($Temptype == 'normal'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ทั่วไป')\"";
			}
			else if($Temptype == 'poll'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้โพล')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ปักหมุด')\"";
			}
				
			$tempstring=$tempstring."/>,<IMG src='imgs/$Tempcategory.gif' onmouseout='writetxt(0)' ";
				
			if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
				
			$tempstring=$tempstring."/>,<A href='showOpinion.php?tID=$Temptopicid' target='_blank'>$Temptopicheader</A>  <img class='new' src='imgs/new.gif'/>,$Tempauthorname,$Tempposttime,$Tempupdatetime,$Tempviewtopic,$Tempreplytopic,$Temptype<BR/>";

			if ($Temptype == 'stick'){ $stick++;}
		}
		
		$stick = (int)$rowold[1] + $stick;
		$_SESSION['ss_Topic_id_1'] =  $rownew.":".$stick;
		$position = "1;".$tempstring;
			
	}
	
	else{
	
		$position = "0;";
		
	}
	
	$cp->set_data($position);
	
}

function pageNum_1($network,$hardware,$software,$security,$course,$etc){

	global $cp;
	connectdb();
	$sql="SELECT COUNT(*) FROM main_topic WHERE (";
	$sql = _check($sql,$network,$hardware,$software,$security,$course,$etc);
	$sql = $sql.") AND ";
	$sql = privatecode($sql);
	$sql = $sql." AND POINT_DEL > 0 ";
	$sql = $sql." AND TYPE !='stick'";
	$temprow = mysql_fetch_array(mysql_query($sql));
	
	$autorefresh = explode(":",$_SESSION['ss_Topic_id_1'] );
	
	$ret = (int)($temprow[0]) + (int)($autorefresh[1]);
	
	$cp->set_data($ret."--".$autorefresh[1]);	
	
}

//-------------------------------------------------------------

function search_topic($searchKey,$i){

	global $cp;
	connectdb();
/*
	$autorefresh = explode(":",$_SESSION['ss_Topic_id_3'] );
	if ($autorefresh[1] == '0'){
		$temprow = mysql_fetch_array(mysql_query("SELECT MAX(Topic_id) FROM main_topic"));
		$_SESSION['ss_Topic_id_3'] =  $temprow[0].":1";
		
	}
*/	
	$page = 25;
	$start = ($i - 1) * $page;

	$sql = "SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM main_topic WHERE  TOPIC_HEADER LIKE ";
	$sql = $sql."'%".$searchKey."%'";
	$sql = $sql." AND POINT_DEL > 0 ";
	//$sql = $sql." AND (STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time().") AND";
	$sql = $sql." AND ";
	$sql = privatecode($sql);
	$sql = $sql." ORDER BY 1 DESC LIMIT ";
	$sql = $sql.$start.",".$page;

	$result = mysql_query($sql);

	$tempstring = "<rows>";

	while ( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicid        = $tempresult["TOPIC_ID"];
		$Temptype			= $tempresult["TYPE"];
		$Tempcategory       = $tempresult["CATEGORY"];
		$Temptopicheader    = $tempresult["TOPIC_HEADER"];
		$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
		$Tempposttime	    = date("j-m-y G:i",$tempresult ["POST_TIME"]);
		$Tempupdatetime	    = date("j-m-y G:i",$tempresult["UPDATE_TIME"]);
		$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
		$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
		
		$tempstring=$tempstring."<row id='$Temptopicid'><cell><![CDATA[<IMG src='imgs/$Temptype.gif' ' onmouseout='writetxt(0)' ";
		
		if($Temptype == 'normal'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ทั่วไป')\"";
			}
			else if($Temptype == 'poll'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้โพล')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ปักหมุด')\"";
			}
			
		$tempstring=$tempstring."/>]]></cell><cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ' onmouseout='writetxt(0)' ";
		
		if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
			
		$tempstring=$tempstring."/>]]></cell><cell><![CDATA[<A href='showOpinion.php?tID=$Temptopicid' target='_blank'>$Temptopicheader</A>]]></cell><cell>$Tempauthorname</cell><cell>$Tempposttime </cell><cell>$Tempupdatetime</cell><cell>$Tempviewtopic</cell><cell>$Tempreplytopic</cell></row>";

		
	}

	$tempstring = $tempstring . "</rows>"; 

	$cp->set_data($tempstring);	

}

function pageNum_3($searchKey){

	global $cp;
	connectdb();
		
	$sql="SELECT COUNT(*) FROM main_topic WHERE TOPIC_HEADER LIKE ";
	$sql = $sql."'%".$searchKey."%'";
	$sql = $sql." AND POINT_DEL > 0 ";
	//$sql = $sql." AND (STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time().") AND";
	$sql = $sql." AND ";
	$sql = privatecode($sql);
	
	$temprow = mysql_fetch_array(mysql_query($sql));
	$ret = (int)($temprow[0]);
	$cp->set_data($ret);	
	
}

//-------------------------------------------------------------------

function search_warehouse($searchKey,$i){

	global $cp;
	connectdb();

	$page = 25;
	$start = ($i - 1) * $page;

	$sql = "SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM topic_warehouse WHERE  TOPIC_HEADER LIKE ";
	$sql = $sql."'%".$searchKey."%'";
	$sql = $sql." AND POINT_DEL > 0 ";
	//$sql = $sql." AND (STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time().") AND";
	$sql = $sql." AND ";
	$sql = privatecode($sql);
	$sql = $sql." ORDER BY 1 DESC LIMIT ";
	$sql = $sql.$start.",".$page;

	$result = mysql_query($sql);

	$tempstring = "<rows>";

	while ( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicid        = $tempresult["TOPIC_ID"];
		$Temptype			= $tempresult["TYPE"];
		$Tempcategory       = $tempresult["CATEGORY"];
		$Temptopicheader    = $tempresult["TOPIC_HEADER"];
		$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
		$Tempposttime	    = date("j-m-y G:i",$tempresult ["POST_TIME"]);
		$Tempupdatetime	    = date("j-m-y G:i",$tempresult["UPDATE_TIME"]);
		$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
		$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
		
		$tempstring=$tempstring."<row id='$Temptopicid'><cell><![CDATA[<IMG src='imgs/$Temptype.gif' ' onmouseout='writetxt(0)' ";
		
		if($Temptype == 'normal'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ทั่วไป')\"";
			}
			else if($Temptype == 'poll'){
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้โพล')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('กระทู้ปักหมุด')\"";
			}
		
		$tempstring=$tempstring."/>]]></cell><cell><![CDATA[<IMG src='imgs/$Tempcategory.gif' ' onmouseout='writetxt(0)' ";
		
		if($Tempcategory == 'network'){
				$tempstring=$tempstring."onmouseover=\"writetxt('เน็ตเวิร์ค')\"";
			}
			else if($Tempcategory == 'security'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ความปลอดภัย')\"";
			}
			else if($Tempcategory == 'hardware'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ฮาดแวร์')\"";
			}
			else if($Tempcategory == 'software'){
				$tempstring=$tempstring."onmouseover=\"writetxt('ซอฟแวร์')\"";
			}
			else if($Tempcategory == 'course'){
				$tempstring=$tempstring."onmouseover=\"writetxt('บทเรียน')\"";
			}
			else{
				$tempstring=$tempstring."onmouseover=\"writetxt('ทั่วไป')\"";
			}
		
		$tempstring=$tempstring."/>]]></cell><cell><![CDATA[<A href='showOpinionwarehouse.php?tID=$Temptopicid' 'target=_blank'>$Temptopicheader</A>]]></cell><cell>$Tempauthorname</cell><cell>$Tempposttime </cell><cell>$Tempupdatetime</cell><cell>$Tempviewtopic</cell><cell>$Tempreplytopic</cell></row>";

		
	}

	$tempstring = $tempstring . "</rows>"; 

	$cp->set_data($tempstring);	
	
}

function pageNum_2($searchKey){

	global $cp;
	connectdb();
		
	$sql="SELECT COUNT(*) FROM topic_warehouse WHERE TOPIC_HEADER LIKE ";
	$sql = $sql."'%".$searchKey."%'";
	$sql = $sql." AND POINT_DEL > 0 ";
	//$sql = $sql." AND (STICK_EXPIRE_IN_DAY IS NULL OR STICK_EXPIRE_IN_DAY > ".time().") AND";
	$sql = $sql." AND ";
	$sql = privatecode($sql);
	
	$temprow = mysql_fetch_array(mysql_query($sql));
	$ret = (int)($temprow[0]);
	$cp->set_data($ret);	
	//$cp->set_data(500);	

}

//-------------------------------------------------------------------
/*
function autorefresh_3($searchKey){
	global $cp;
	connectdb();
	

	$position = $_SESSION['ss_Topic_id_3'];
	$rowold = explode(":",$position);

	$temprow = mysql_fetch_array(mysql_query("SELECT MAX(TOPIC_ID) FROM main_topic"));
	$rownew =  $temprow[0];

	if((int)($rowold[0]) < $rownew ){
			
		$sql="SELECT TOPIC_ID,TYPE,CATEGORY,POST_TIME,TOPIC_HEADER,AUTHOR_NAME,UPDATE_TIME,VIEW_TOPIC,REPLY_TOPIC FROM main_topic WHERE TOPIC_ID > ";
		$sql = $sql.(int)($rowold[0]);
		$sql = $sql." AND TOPIC_HEADER LIKE ";
		$sql = $sql."'%".$searchKey."%'";
		$sql = $sql." AND PRIV_CODE LIKE ";
		$sql = $sql."'%".$_SESSION['ss_privcode']."%'";
		
		$result = mysql_query($sql);
		while ( $tempresult = mysql_fetch_array($result)){

			$Temptopicid        = $tempresult["TOPIC_ID"];
			$Temptype			= $tempresult["TYPE"];
			$Tempcategory       = $tempresult["CATEGORY"];
			$Temptopicheader    = $tempresult["TOPIC_HEADER"];
			$Tempauthorname   	= $tempresult["AUTHOR_NAME"];
			$Tempposttime	    = date("j-m-y G:i",$tempresult ["POST_TIME"]);
			$Tempupdatetime	    = date("j-m-y G:i",$tempresult["UPDATE_TIME"]);
			$Tempviewtopic   	= $tempresult["VIEW_TOPIC"];
			$Tempreplytopic   	= $tempresult["REPLY_TOPIC"];
		
		
			$tempstring=$tempstring."$Temptopicid,<IMG src='imgs/$Temptype.gif' alt='$Tempcategory'/>,<IMG src='imgs/$Tempcategory.gif' alt='$Tempcategory'/>,<A href='showOpinion.php?tID=$Temptopicid' onclick='' target=_blank>$Temptopicheader</A>,$Tempauthorname,$Tempposttime ,$Tempupdatetime,$Tempviewtopic,$Tempreplytopic<BR/>";

			
		}
		

		$_SESSION['ss_Topic_id_3'] =  $rownew.":1";
		$position = "1;".$tempstring;
			
	}
	
	else{
	
		$position = "0;";
		
	}
	
	$cp->set_data($position);
	
}
*/

//------------------------------------------------------------------------

?>


