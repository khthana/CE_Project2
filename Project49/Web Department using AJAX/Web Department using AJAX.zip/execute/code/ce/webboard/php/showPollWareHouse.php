<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('showPoll');
$cp->register('updateChart');
$cp->start();
$cp->return_data();


function showPoll($topicID){
	global $cp;
	connectdb();
	$responseNode=$cp->add_node('response');
	/*get header (poll question)*/
	$comSQLgetPollQuestion ="SELECT * FROM topic_warehouse   WHERE TOPIC_ID=".$topicID; 
	$getPollQuestionresult=mysql_query($comSQLgetPollQuestion);
	if ($question=mysql_fetch_array($getPollQuestionresult)){
		if ($question["POLL_QUESTION"]!=""){
			$pollQuestionNode=$cp->add_node('pollQuestion');
			$expireInDayNode=$cp->add_node('expireInDay');
			if ($question["POLL_EXPIRE_IN_DAY"]=="") $expireInDayNode->set_data("-");else $expireInDayNode->set_data( date("G:i:s D j M Y",$question["POLL_EXPIRE_IN_DAY"]));
			$pollQuestionNode->set_data($question["POLL_QUESTION"]);
		}else{
			$responseNode->set_data("No Poll");
			return false;
		}
	}else {
		$responseNode->set_data("No Poll");
		return false;
	}
	/* get content*/
		$responseNode->set_data("showResult");
		showPollResult($topicID);
		return true;

}
function updateChart($topicID){
	global $cp;
	connectdb();
	showPollResult($topicID);
}

function showOption($topicID){
	global $cp;
	$comSQLgetOption="SELECT * FROM poll_option_warehouse  WHERE TOPIC_ID=".$topicID;
	$optionresult=mysql_query($comSQLgetOption);
	$optionlistNode=$cp->add_node('optionlist');
	while ($options=mysql_fetch_array($optionresult)){
		$optionNode=$optionlistNode->add_node('option');
		$optionIDNode=$optionlistNode->add_node('optionID');
		$optionNode->set_data($options["POLLOPTION"]);
		$optionIDNode->set_data($options["OPTION_ID"]);
	}
	echo mysql_error();
}
function showPollResult($topicID){
	global $cp;
	$comSQLgetOption="SELECT * FROM poll_option_warehouse  WHERE TOPIC_ID=".$topicID;
	$optionresult=mysql_query($comSQLgetOption);
	$votePoint= Array();
	$pollOption= Array();
	$nonVoteflag=true;
	while ($options=mysql_fetch_array($optionresult)){
		if ($nonVoteflag and $options["VOTE_POINT"]>0) $nonVoteflag=false;
		array_push($votePoint, $options["VOTE_POINT"]);
		array_push($pollOption, $options["POLLOPTION"]);
	}
	$resultPollNode=$cp->add_node('resultPoll');
	$data="data=";//10*9*11*10*1*
	$label="&label=";
	for ($i = 0; $i < count($votePoint); $i++) {
		$data.=$votePoint[$i]."*";
		$label.=$pollOption[$i]."*";
	}
	if ($nonVoteflag) {
		$data.=iconv("tis-620","utf-8","1");
		$label.=iconv("tis-620","utf-8","�ѧ����ռ��ӡ����ǵ");
	}else{
			$data=substr($data, 0, strlen($data)-1);//10*9*11*10*1
			$label=substr($label, 0, strlen($label)-1);
		}
	$result=$data.$label;
	$resultPollNode->set_data($result);

}
		

?>

