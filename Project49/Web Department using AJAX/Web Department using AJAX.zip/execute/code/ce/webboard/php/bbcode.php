<?php
/** @defgroup bbcodegroup BB-Code-Class
    PHP-Class for parsing BB-Code to HTML syntax.
@{ */
/*!***********************************************************************
 *************************************************************************
 * \file            bbcode.php
 *
 * \author          copyright 1999-2005 <br>
 *                  Kai Klenovsek <br>
 *
 * \date            First Step: 2004-06-30 <br>
 *
 * \note <br>
 * \b LICENSE: <br>
 *      This library is free software; you can redistribute it and/or <br>
 *      modify it under the terms of the GNU Lesser General Public <br>
 *      License as published by the Free Software Foundation; either <br>
 *      version 2.1 of the License, or (at your option) any later version. <br>
 *
 *      This library is distributed in the hope that it will be useful, <br>
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of <br>
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU <br>
 *      Lesser General Public License for more details. <br>
 *
 *      You should have received a copy of the GNU Lesser General Public <br>
 *      License along with this library; if not, write to the Free Software <br>
 *      Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br>
 *
 * \b NOTES: <br>
 *
 * \todo 
 *               
 * \bug
 *
 * \b CHANGE \b HISTORY: <br>
 *
 *   <b>- Kai K. / 2005-07-13</b>   
 *           - Error log to error logfile implemented.
 *
 *   <b>- Kai K. / 2005-04-14</b>   
 *           - Error message handler implemented.
 *
 *   <b>- Kai K. / 2005-02-18</b>  
 *           - Some code optimization.
 *
 *   <b>- Kai K. / 2005-02-08</b>    
 *           - Class constructor has changed.
 *           - Error listing implemented.
 *
 *   <b>- Kai K. / 2004-12-21</b>   
 *           - Font colors implemented.
 *
 *   <b>- Kai K. / 2004-11-25</b>    
 *           - Bordertable bugfix.
 *  
 ***************************************************************************
 ***************************************************************************/
require("code script/msghandler.php");
require("code script/file.php");

if ( !defined("BBCODE") )
{
define("BBCODE", "bbcode");



/***********************************************************************
* 
* DEFINES
*  
***********************************************************************/

define("BBCODEMODULNAME", "[MODUL->BBCODE]:");



class bbcode
{
    /***********************************************************************
    * 
    * PRIVATE VARS
    *  
    ***********************************************************************/
    
    var $bbcode_bb2html;                      /*!< String for parsing */
    
    var $bbcode_db_smilie_file = 0;           /*!< Complete name and path to Smilie database file. */
        
    var $bbcode_error_hdl      = 0;           /*!< Error message handler */
        
    var $bbcode_smilie_url     = 0;           /*!< Complete URL to the smilie folder */
    
    

    /***********************************************************************
    *    
    * PUBLIC FUNCTIONS
    *
    ***********************************************************************/
     
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode( $string, $db_smilie_file="", $smilie_url="" )
     *  \brief Class constructor. If the path to the smilie database or 
     *         the URL to the smilie folder is not set, no smilies will be 
     *         parsed. 
     *  \param $string = ASCII String for parsing.
     *  \param $db_smilie_file = Smilie database file. Paramter MUST include 
     *                           the path to the file too !
     *  \param $smilie_url     = Complete URL to the smilie folder. */
    
    function bbcode( $string, $db_smilie_file="", $smilie_url="" )
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    {
        $this->bbcode_error_hdl = new msghandler();
        
        // Load class members
        $this->bbcode_bb2html        = $string;
        $this->bbcode_db_smilie_file = $db_smilie_file;
        $this->bbcode_smilie_url     = $smilie_url;
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function _bbcode( ) 
     *  \brief Class Destructor */
    
    function _bbcode( )
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    {
                    
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_bb2html( )
     *  \brief Converts a BB-Code ASCII string to HTML format.
     *  \return Converted string */
    
    function bbcode_bb2html( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        if ( empty($this->bbcode_bb2html) )
        {
            $error_msg = PHPLIBEX_PREFIX.MODULNAME." Nothing to parse in function bbcode->bb2html";
            $this->bbcode_error_hdl->msg_addfull( $error_msg, PHPLIBEX_ERROR_LOG );
                    
            return ( false );
        }
       
        $this->bbcode_error_hdl->msg_flushlist(); 
        
        // Convert string links to HTML links
        //$this->bbcode_link2html( );
		$this->bbcode_parse_hyperlink();        

        // Simple text format parser
        $this->bbcode_parse_textformat( );
        
        // Table parser
        $this->bbcode_parse_tables( );

        // List parser
        $this->bbcode_parse_list( );

        // Parse only smilies if both vars are set
        if ( $this->bbcode_db_smilie_file && $this->bbcode_smilie_url )
        {
            // Parse smilies
            $this->bbcode_parse_smilies( );   
        }         
        
        // Parse font colors
        $this->bbcode_parse_fontcolors( );
         // Parse font size
		$this-> bbcode_parse_fontsize( );
        // Parse images
        $this->bbcode_parse_images( );

        // Parse divisions
        $this->bbcode_parse_divisions( );
    
        // Parse special characters
        $this->bbcode_parse_special_chars( );
        
        return $this->bbcode_bb2html;
    }



    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_flush_errorlist( ) 
     *  \brief Empties the error string list.
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_flush_errorlist( )
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    {
        return( $this->bbcode_error_hdl->msg_flushlist() );            
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_get_errorlist( ) 
     *  \brief Return error string list.
     *  \return Error list */
    
    function bbcode_get_errorlist( )
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    {
        return( $this->bbcode_error_hdl->msg_getlist() );            
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_get_result( ) 
     *  \brief Return converted ASCII string.
     *  \return Converted ASCII string */
    
    function bbcode_get_result( )
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    {
        return $this->bbcode_bb2html;        
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_divisions( )
     *  \brief Division parser.
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_divisions( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        return $this->bbcode_bb2html = str_replace('[hr]', '<hr size=1 width="70%" align=center>', $this->bbcode_bb2html);
    }
    
    

    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_fontcolors( )
     *  \brief RGB font color parser for. 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_fontcolors( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        $this->bbcode_bb2html = preg_replace("#\[color=(.*?)\](.*?)\[/color\]#si", "<font color=\\1>\\2</font>", $this->bbcode_bb2html);
                
        return $this->bbcode_bb2html;
    }
    
	 function bbcode_parse_fontsize( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
      $this->bbcode_bb2html = preg_replace("#\[size=(.*?)\](.*?)\[/size\]#si","<span style='font-size: \\1px; line-height: normal'>\\2</span >", $this->bbcode_bb2html);
       return $this->bbcode_bb2html;
    }
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_images( )
     *  \brief Image parser. 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_images( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        $this->bbcode_bb2html = str_replace('[img]', '<img border="0" src="', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/img]', '" alt="Image">', $this->bbcode_bb2html);
                 
        return $this->bbcode_bb2html;
    }     
	
	 


    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_list( )
     *  \brief List parser 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_list( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
		$open_tag = array();
		/*// unordered..
		$open_tag[0] = "[list]";
		$this->bbcode_bb2html =  $this->bbcode_pardepda($this->bbcode_bb2html, $open_tag, "[/list]", "[/list:u]");
		// ordered.
		$open_tag[0] = "[list=1]";
		$open_tag[1] = "[list=a]";
		$this->bbcode_bb2html =  $this->bbcode_pardepda($this->bbcode_bb2html, $open_tag,  "[/list]", "[/list:o]");*/
		//$this->bbcode_bb2html = $this->bbcode_pda($this->bbcode_bb2html);
		$this->bbcode_bb2html = str_replace('[list]', '<ul>', $this->bbcode_bb2html);
		$this->bbcode_bb2html = str_replace('[/list]', '</ul>', $this->bbcode_bb2html);
		$this->bbcode_bb2html = str_replace('[list=1]', '<ol style="list-style-type: decimal">', $this->bbcode_bb2html);
		$this->bbcode_bb2html = str_replace('[list=a]', '<ol style="list-style-type: upper alpha">', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[*]', '<li>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[block]', '<blockquote>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/block]', '</blockquote>', $this->bbcode_bb2html);
        
        return $this->bbcode_bb2html;
    }
function bbcode_pda($text)
{
	$curr_posOp = strpos($text, "[list", 0);
	//$text=substr_replace($text,"U",$curr_posOp+(strlen("[/list")),0);
	$curr_posEd =  strpos($text, "[/list", 0);
	$numberOpentag =-1;
	print $curr_posOp;
	//while ($curr_posOp && ($curr_posOp < strlen($text)))
	for ($i = 0; $i < 10; $i++)
	{
		$curr_posOp = strpos($text, "[list",$curr_posOp);
		print $curr_posOp;

			// If not found, $curr_pos will be 0, and the loop will end.
		/*if ($curr_posOp)
		{
			$numberOpentag++;
			$ckAttribute=$curr_posOp+strlen("[list");
			if ($text[$ckAttribute]=="]")
				$opentag[$numberOpentag]="u";
			else
				$opentag[$numberOpentag]="o";
		}
		/*while ($curr_posOp>$curr_posEd && $curr_posEd!=0 &&$curr_posEd < strlen($text))
		{	
			$curr_posEd = strpos($text, "[/list", $curr_posEd);
			$InsertAttributeCur=$curr_posEd+1;
			$text=substr_replace($text,$opentag[$numberOpentag],$InsertAttributeCur,0);
			$numberOpentag--;
		}*/
	}
	return $text;
}
	/*function bbcode_pardepda($text, $open_tag, $close_tag, $close_tag_new)
	{
	if (is_array($open_tag)){
		
			if (0 == count($open_tag)){
				// No opening tags to match, so return.
				return $text;
			}
		$open_tag_count = count($open_tag);
		}
		else{
			// only one opening tag. make it into a 1-element array.
			$open_tag_temp = $open_tag;
			$open_tag = array();
			$open_tag[0] = $open_tag_temp;
			$open_tag_count = 1;
	}
	$curr_pos = 1;
	while ($curr_pos && ($curr_pos < strlen($text)))
	{
		$curr_pos = strpos($text, "[", $curr_pos);

		// If not found, $curr_pos will be 0, and the loop will end.
		if ($curr_pos)
		{
			// We found a [. It starts at $curr_pos.
			// check if it's a starting or ending tag.
			$found_start = false;
			$which_start_tag = "";
			$start_tag_index = -1;
		for ($i = 0; $i < $open_tag_count; $i++)
			{
					// Grab everything until the first "]"...
					$possible_start = substr($text, $curr_pos, strpos($text, ']', $curr_pos + 1) - $curr_pos + 1);
					//
					// We're going to try and catch usernames with "[' characters.
					//
					if( preg_match('#\[quote=\\\"#si', $possible_start, $match) && !preg_match('#\[quote=\\\"(.*?)\\\"\]#si', $possible_start) )
					{
						// OK we are in a quote tag that probably contains a ] bracket.
						// Grab a bit more of the string to hopefully get all of it..
						if ($close_pos = strpos($text, '"]', $curr_pos + 9)){
							if (strpos(substr($text, $curr_pos + 9, $close_pos - ($curr_pos + 9)), '[quote') === false){
								$possible_start = substr($text, $curr_pos, $close_pos - $curr_pos + 2);
							}
						 }
					 }
					 if (0 == strcasecmp($open_tag[$i], $possible_start))
						{
							$found_start = true;
							$which_start_tag = $open_tag[$i];
							$start_tag_index = $i;
							break;
						}
			}
			if ($found_start)
			{
				// We have an opening tag.
				// Push its position, the text we matched, and its index in the open_tag array on to the stack, and then keep going to the right.
				$match = array("pos" => $curr_pos, "tag" => $which_start_tag, "index" => $start_tag_index);
				$this->bbcode_array_push($stack, $match);
				//
				// Rather than just increment $curr_pos
				// Set it to the ending of the tag we just found
				// Keeps error in nested tag from breaking out
				// of table structure..
				//
				$curr_pos += strlen($possible_start);
			}
			else
			{
				// check for a closing tag..
				$possible_end = substr($text, $curr_pos, $close_tag_length);
				if (0 == strcasecmp($close_tag, $possible_end))
				{
					// We have an ending tag.
					// Check if we've already found a matching starting tag.
					if (sizeof($stack) > 0)
					{
						// There exists a starting tag.
						$curr_nesting_depth = sizeof($stack);
						// We need to do 2 replacements now.
						$match = $this->bbcode_array_pop($stack);
						$start_index = $match['pos'];
						$start_tag = $match['tag'];
						$start_length = strlen($start_tag);
						$start_tag_index = $match['index'];

						if ($open_is_regexp)
						{
							$start_tag = preg_replace($open_tag[$start_tag_index], $open_regexp_replace[$start_tag_index], $start_tag);
						}

						// everything before the opening tag.
						$before_start_tag = substr($text, 0, $start_index);

						// everything after the opening tag, but before the closing tag.
						$between_tags = substr($text, $start_index + $start_length, $curr_pos - $start_index - $start_length);

						// Run the given function on the text between the tags..
						if ($use_function_pointer)
						{
							$between_tags = $func($between_tags, $uid);
						}

						// everything after the closing tag.
						$after_end_tag = substr($text, $curr_pos + $close_tag_length);

						// Mark the lowest nesting level if needed.
						...
						$text .= $after_end_tag;

						// Now.. we've screwed up the indices by changing the length of the string.
						// So, if there's anything in the stack, we want to resume searching just after it.
						// otherwise, we go back to the start.
						if (sizeof($stack) > 0)
						{
							$match = $this->bbcode_array_pop($stack);
							$curr_pos = $match['pos'];
//							bbcode_array_push($stack, $match);
//							++$curr_pos;
						}
						else
						{
							$curr_pos = 1;
						}
					}
					else
					{
						// No matching start tag found. Increment pos, keep going.
						++$curr_pos;
					}
				}
				else
				{
					// No starting tag or ending tag.. Increment pos, keep looping.,
					++$curr_pos;
				}
			}
		}
	} // while
	return $text;
	}*/
 function bbcode_array_push(&$stack, $value)
{
   $stack[] = $value;
   return(sizeof($stack));
}

function bbcode_array_pop(&$stack)
{
   $arrSize = count($stack);
   $x = 1;

   while(list($key, $val) = each($stack))
   {
      if($x < count($stack))
      {
	 		$tmpArr[] = $val;
      }
      else
      {
	 		$return_val = $val;
      }
      $x++;
   }
   $stack = $tmpArr;

   return($return_val);
}
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_smilies( )
     *  \brief Smilie parser. For initialization look also into the class constructor.
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_smilies( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        $file = new file( );
                
        // Get data from smilie database file
        $rawdata = $file->file_getdata( $this->bbcode_db_smilie_file );
        
        if ( $rawdata )
        {
            // Parse smilie data
            for ( $loop=0; $loop <= sizeof($rawdata)-2; $loop++ )
            {
                $data = explode( "|", $rawdata[$loop] );                
                $this->bbcode_bb2html = str_replace($data[0], "<img alt='".$data[0]."' src='".$this->bbcode_smilie_url."/".$data[1]."'>", $this->bbcode_bb2html);           
            }
            
            return $this->bbcode_bb2html;
        }
        
        $error_msg = PHPLIBEX_PREFIX.BBCODEMODULNAME." Cant open smilie database file ".$this->bbcode_db_smilie_file." in function bbcode->parse_smilies.";
        $this->bbcode_error_hdl->msg_addfull( $error_msg, PHPLIBEX_ERROR_LOG );
                        
        return ( false );
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_special_chars( )
     *  \brief Special char parser. 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_special_chars( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        $source = str_replace('[sp]', '&nbsp;', $this->bbcode_bb2html);
        $source = str_replace('±', '&plusmn;', $this->bbcode_bb2html);
        $source = str_replace('™', '&trade;', $this->bbcode_bb2html);
        $source = str_replace('•', '&bull;', $this->bbcode_bb2html);
        $source = str_replace('°', '&deg;', $this->bbcode_bb2html);
        $source = str_replace('[<]', '&lt;', $this->bbcode_bb2html);
        $source = str_replace('[>]', '&gt;', $this->bbcode_bb2html);
        $source = str_replace('©', '&copy;', $this->bbcode_bb2html);
        $source = str_replace('®', '&reg;', $this->bbcode_bb2html);
        $source = str_replace('…', '&hellip;', $this->bbcode_bb2html);
                        
        return $this->bbcode_bb2html;
    }
    
    

    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_tables( )
     *  \brief Table parser 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_tables( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        // Tabel format
        $this->bbcode_bb2html = str_replace('[table]', '<table width="100%" border=0 cellspacing=0 cellpadding=0>', $this->bbcode_bb2html);   
        $this->bbcode_bb2html = str_replace('[/table]', '</table>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[bordertable]', '<table width="100%" border=1 cellspacing=0 cellpadding=3>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/bordertable]', '</table>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[cell]', '<td valign=top>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/cell]', '</td>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[row]', '<tr>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/row]', '</tr>', $this->bbcode_bb2html);
        
        return $this->bbcode_bb2html;
    }
    


    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_parse_textformat( )
     *  \brief Simple text format parser. 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_parse_textformat( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        // Simple text format parser
        $this->bbcode_bb2html = str_replace('[b]', '<b>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/b]', '</b>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[big]', '<big>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/big]', '</big>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[center]', '<center>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/center]', '</center>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[i]', '<i>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/i]', '</i>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[u]', '<u>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/u]', '</u>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace("\r",'<br>', $this->bbcode_bb2html);
		$this->bbcode_bb2html = str_replace('\r\n','<br>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[sm]', '<small>', $this->bbcode_bb2html);
        $this->bbcode_bb2html = str_replace('[/sm]', '</small>', $this->bbcode_bb2html);
        
       return $this->bbcode_bb2html;
    }
    
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_link2html( )
     *  \brief Converts an ASCCI string with links to HTML format. 
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_link2html( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        $this->bbcode_bb2html = " ".$this->bbcode_bb2html;

        $this->bbcode_bb2html = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\" target=\"_blank\">\\2</a>", $this->bbcode_bb2html);
        $this->bbcode_bb2html = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\" target=\"_blank\">\\2</a>", $this->bbcode_bb2html);
        $this->bbcode_bb2html = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>", $this->bbcode_bb2html);
        $this->bbcode_bb2html = substr($this->bbcode_bb2html, 1);
        
        return $this->bbcode_bb2html;         
    }

    function bbcode_parse_hyperlink()
	{
		$this->bbcode_bb2html = preg_replace("#\[url](.*?)\[/url\]#si","<a href=\"\\1\" target=\"_blank\">\\1</a>",$this->bbcode_bb2html);
		$this->bbcode_bb2html = preg_replace("#\[url=(.*?)\](.*?)\[/url\]#si","<a href=\"\\1\" target=\"_blank\">\\2</a>",$this->bbcode_bb2html);
	
	}
    
    
    // :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    /*! \fn function bbcode_html2text( )
     *  \brief Convert HTML tags into normal viewable text.
     *  \return Returns 'true' if everything has been all right else 'false'. */
    
    function bbcode_html2text( )
    
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
    {
        return ( $this->bbcode_bb2html = htmlentities( $this->bbcode_bb2html ) );
    }
  
} // END CLASS BBCODE
} // END IF BBCODE
/** @} */ 

?>
