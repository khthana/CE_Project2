<?php
if(isset($_GET['tID']) and $_GET['tID']!=""){
	include("../_Connectdatabase.php");
	connectdb();
	$comSQLselectQuote="SELECT OPINION_ID FROM opinion  WHERE TOPIC_ID=".$_GET['tID'];
	if(!isset($_GET['oID']) ){
		$_GET['oID']="";
	}
	
	$selectQuoteresult=mysql_query($comSQLselectQuote);
	$showQuoteform='<table width="750"  border="0" cellspacing="0" cellpadding="0" class="simpletext">';
	$showQuoteform.=' <tr>';
	 $showQuoteform.='<td width="110"  align="left"><select name="select" size="1" id="selectOpinion" onChange="showexample()">';
	  while($opinionrrow=mysql_fetch_array($selectQuoteresult)){
		  if($_SERVER['SCRIPT_NAME']!="/showedit_opinion.php"  and $opinionrrow["OPINION_ID"] != $_GET['oID']) {
					$showQuoteform.='<option value="'.$opinionrrow["OPINION_ID"].'"';
					if(isset($_GET['oID']) and $_GET['oID']!="" and $_GET['oID']==$opinionrrow["OPINION_ID"]){
						$showQuoteform.='selected="selected"';
					}
					$showQuoteform.='>&#3588;&#3623;&#3634;&#3617;&#3588;&#3636;&#3604;&#3648;&#3627;&#3655;&#3609;&#3607;&#3637;&#3656; '.$opinionrrow["OPINION_ID"].'</option>';
		  }
	  }
	 $showQuoteform.='</select></td>';
	 $showQuoteform.='<td width="640" align="right"><img src="imgs/button/quote_0.gif" alt="Quote" onMouseOver="this.src=\'imgs/button/quote_1.gif\'" onMouseOut="this.src=\'imgs/button/quote_0.gif\'" onMouseDown="this.src=\'imgs/button/quote_2.gif\'" onClick="return quote()"/></td></tr>';
	$showQuoteform.='<tr><td width="220" class="quoteheadLeft" align="left">';
	$showQuoteform.='<span id="showAuthor"></span></td>';
	$showQuoteform.='<td width="220" class="quoteheadRight" align="right">';
	$showQuoteform.='<span id="date"></span></td>';  
	$showQuoteform.='</tr>';
	$showQuoteform.='<tr>';
	$showQuoteform.='<td colspan="2" class="quotemessage" height="60"><div id="showExampleMessage"></div></td>';
	$showQuoteform.='</tr>';
	$showQuoteform.='</table>';
	
	
	
	
	
	echo $showQuoteform;
	
	
	/*
	
	$showQuoteform='<table width="600" border="0" cellspacing="0" cellpadding="0" class="simpletext">';
	$showQuoteform.=' <tr>';
	 $showQuoteform.='<td width="105" rowspan="2"  align="left"><select name="select" size="1" id="selectOpinion" onChange="showexample()">';
	  while($opinionrrow=mysql_fetch_array($selectQuoteresult)){
		$showQuoteform.='<option value="'.$opinionrrow["OPINION_ID"].'">&#3588;&#3623;&#3634;&#3617;&#3588;&#3636;&#3604;&#3648;&#3627;&#3655;&#3609;&#3607;&#3637;&#3656; '.$opinionrrow["OPINION_ID"].'</option>';
	  }
	   

	 $showQuoteform.='</select></td>';
	 $showQuoteform.='<td width="220" class="quoteheadLeft" align="left">';
	 $showQuoteform.='<span id="showAuthor"></span></td>';
	$showQuoteform.='<td width="220" class="quoteheadRight" align="right">';
	$showQuoteform.='<span id="date"></span></td>';
	 $showQuoteform.='<td width="50" rowspan="2" align="right"><img src="imgs/button/quote_0.gif" alt="Quote" onMouseOver="this.src=\'imgs/button/quote_1.gif\'" onMouseOut="this.src=\'imgs/button/quote_0.gif\'" onMouseDown="this.src=\'imgs/button/quote_2.gif\'" onClick="return quote()"/></td>';
	$showQuoteform.='</tr>';
	$showQuoteform.='<tr>';
	$showQuoteform.='<td colspan="2" class="quotemessage" ><div id="showExampleMessage"></div></td>';
	$showQuoteform.='</tr>';
	$showQuoteform.='</table>';
	
	*/
}
?>