<?php

include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("level.php");

session_start();
$cp = new cpaint();
$cp->register('opinion');
$cp->register('check_reply');
$cp->register('pageNum');
$cp->register('check_edit_topic');
$cp->register('check_edit_opinion');
$cp->register('delete_topic');
$cp->register('delete_opinion');
$cp->register('warehouse');
$cp->register('draw_vote_del');
$cp->register('vote');
$cp->start();
$cp->return_data();

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "( t1.PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR t1.PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}

function opinion($id,$i){
	
	global $cp;
	connectdb();
	
	$sql="SELECT TOPIC_HEADER,TOPIC_MSG,POST_TIME,EDIT_TIME,IP_AUTHOR,AUTHOR_NAME,LEVEL,POINT,USER_ID,AUTHOR_ID FROM main_topic AS t1 INNER JOIN useraccount AS t2 ON t1.AUTHOR_ID = t2.USER_ID WHERE t1.TOPIC_ID ='".$id."' AND POINT_DEL > 0 AND ";
	$sql = privatecode($sql);
	
	$result =mysql_query($sql);
	
	if( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicheader  = $tempresult["TOPIC_HEADER"];
		$Temptopicmsg  = $tempresult["TOPIC_MSG"];
		$Tempposttime	    = date("G:i:s D j M Y",$tempresult ["POST_TIME"]); 
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);            
		$Temptopicip   = $tempresult["IP_AUTHOR"];
		$Temptopicusername   = $tempresult["AUTHOR_NAME"];
		$Temptopiclevel   = $tempresult["LEVEL"];
		$Temptopicpoint   = $tempresult["POINT"];
		$Tempuserid       = $tempresult["USER_ID"];
		$Tempauthorid       = $tempresult["AUTHOR_ID"];
			
		$tempstring ="<table class='opinion_tb1' cellpadding='0' cellspacing='0'><tr ><td class='opinion_th_1'>หัวข้อ:: $Temptopicheader</td><td class='opinion_th_2'><span id='vote' ></span></td></tr><tr><td colspan='2'><br/><table  id='Topic' cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2'>$Temptopicmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		if ($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer'){
		  	if ( $Tempauthorid != 0){
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_topic()'><img src='imgs/edit.gif'  width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)' /></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif' width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;";
				}
			}
			$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='delete_topic()'><img src='imgs/delete.gif'  width='22' height='22' onmouseover=writetxt('ลบหัวข้อกระทู้') onmouseout='writetxt(0)' />&nbsp;";
		}
		else if ($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user'){ 
			if ( $Tempauthorid != 0){
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_topic()'><img src='imgs/edit.gif'  width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)' /></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif' width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;";
				}
			
			}
		}
		$tempstring .="<a href='../user_management/showlist_member.php?uID=$Tempuserid' target='_blank'><img src='imgs/personal_info.gif' width='22' height='22' onmouseover=writetxt('ดูรายละเอียด') onmouseout='writetxt(0)' /></a></td><td class='opinion_td_editdate'>";
			
		if ($date != 0) {
		
			$tempstring .=":: แก้ไขเมื่อ $Tempedittime ::";
		}
		
			$tempstring .="</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></td></tr></table>";	
	
	//-----------------------------------------------------------
	$page = 20;
	$start = (($i - 1) * $page);
	
	$sql="SELECT OPINION_ID,OPINION_MSG,IP_POSTER,POST_TIME,EDIT_TIME,AUTHOR_NAME,LEVEL,POINT,t1.USER_ID FROM opinion AS t1 INNER JOIN useraccount AS t2 ON t1.USER_ID = t2.USER_ID WHERE t1.TOPIC_ID ='".$id."' "; //AND ";
	
	//$sql = privatecode($sql);
	$sql .= " ORDER BY 1 ASC LIMIT ".$start.",".$page;
	
	$result = mysql_query($sql);
	
	while( $tempresult = mysql_fetch_array($result)){
		
		$Tempopinionid  = $tempresult["OPINION_ID"];
		$Tempopinionmsg  = $tempresult["OPINION_MSG"];
		$Tempposttime	    = date("G:i:s D j M Y",$tempresult ["POST_TIME"]);
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);
		$Temptopicip   = $tempresult["IP_POSTER"];
		$Temptopicusername   = $tempresult["AUTHOR_NAME"];
		$Temptopiclevel   = $tempresult["LEVEL"];
		$Temptopicpoint   = $tempresult["POINT"];
		$Tempuserid       = $tempresult["USER_ID"];
		
		
		$tempstring .="<span><br/><table id='opinion_$Tempopinionid' cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'><a href='post_newOpinion.php?tID=".$id."&oID=$Tempopinionid' target='_blank'>อ้างอิง::ความคิดเห็นที่ $Tempopinionid</a></td></tr><tr><td class='opinion_td_msg' colspan='2' >$Tempopinionmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		
		if ($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer'){
			if ( $Tempuserid != 0){
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_opinion($Tempopinionid)'><img src='imgs/edit.gif' width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)' /></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif'  width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;";
				}
			}
			$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='delete_opinion(".$id.",$Tempopinionid)'><img src='imgs/delete.gif' width='22' height='22' onmouseover=writetxt('ลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
			
			
		}
		else if ($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user'){ 
			if ( $Tempuserid != 0){
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_opinion()'><img src='imgs/edit.gif' width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)'/></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif' width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;<span style='cursor:pointer;cursor:hand' onclick='delete_opinion(".$id.",$Tempopinionid)'><img src='imgs/delete.gif' width='22' height='22' onmouseover=writetxt('ลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
				}
				else
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='complain(".$id.",$Tempopinionid);'><img src='imgs/complain.gif' width='22' height='22' onmouseover=writetxt('แจ้งลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
			}
			else
				$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='complain(".$id.",$Tempopinionid);'><img src='imgs/complain.gif' width='22' height='22' onmouseover=writetxt('แจ้งลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
		}
		
		$tempstring .="<a href='../user_management/showlist_member.php?uID=$Tempuserid' target='_blank'><img src='imgs/personal_info.gif' width='22' height='22' onmouseover=writetxt('ดูรายละเอียด') onmouseout='writetxt(0)' /></a></td><td class='opinion_td_editdate'>";
				
		if ($date != 0) {
		
			$tempstring .=":: แก้ไขเมื่อ $Tempedittime ::";
		}
		
			$tempstring .="</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></span>";		
	
		}
	
	$sql = "SELECT VIEW_TOPIC FROM main_topic WHERE TOPIC_ID =".$id;
	$result = mysql_fetch_array(mysql_query($sql));
	$inc = (int)($result[0]) + 1;
	$sql = "UPDATE main_topic  SET  VIEW_TOPIC=$inc WHERE TOPIC_ID=".$id;
	mysql_query($sql);
	
	
	$cp->set_data($tempstring);	
	}
	else{
		$cp->set_data(0);	
		return;
	}	
	
}

function check_reply($id,$i){

	global $cp;
	connectdb();
	$ref = (($i - 1) * 20) + 20;
	
	$sql="SELECT COUNT(*) FROM opinion WHERE TOPIC_ID =".$id;
	$count =  mysql_fetch_array(mysql_query($sql));
	
	$sql="SELECT OPINION_ID,OPINION_MSG,IP_POSTER,POST_TIME,EDIT_TIME,AUTHOR_NAME,LEVEL,POINT,t1.USER_ID FROM opinion AS t1 INNER JOIN useraccount AS t2 ON t1.USER_ID = t2.USER_ID WHERE t1.TOPIC_ID ='".$id."' "; 
	
	$sql .= " ORDER BY 1 DESC  LIMIT 0,1";
	
	$result = mysql_query($sql);
	
	if( $tempresult = mysql_fetch_array($result)){
		
		$Tempopinionid  = $tempresult["OPINION_ID"];
		$Tempopinionmsg  = $tempresult["OPINION_MSG"];
		$Tempposttime	    = date("G:i:s D j M Y",$tempresult ["POST_TIME"]);
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);
		$Temptopicip   = $tempresult["IP_POSTER"];
		$Temptopicusername   = $tempresult["AUTHOR_NAME"];
		$Temptopiclevel   = $tempresult["LEVEL"];
		$Temptopicpoint   = $tempresult["POINT"];
		$Tempuserid       = $tempresult["USER_ID"];
		
		if ($count[0] <= $ref){
		
			$tempstring .="<span><br/><table id='opinion_$Tempopinionid' cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'><a href='post_newOpinion.php?tID=".$id."&oID=$Tempopinionid' target='_blank'>อ้างอิง::ความคิดเห็นที่ $Tempopinionid</a></td></tr><tr><td class='opinion_td_msg' colspan='2' >$Tempopinionmsg</td></tr><tr><td class='opinion_td_button2'>";
			
			
			if ($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer'){
				if ( $Tempuserid != 0){
					if ($Temptopicusername == $_SESSION['ss_UserName']){
				
						$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_opinion()'><img src='imgs/edit.gif' width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)' /></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif'  width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;";
					}
				}
				$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='delete_opinion(".$id.",$Tempopinionid)'><img src='imgs/delete.gif' width='22' height='22' onmouseover=writetxt('ลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
				
				
			}
			else if ($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user'){ 
				if ( $Tempuserid != 0){
					if ($Temptopicusername == $_SESSION['ss_UserName']){
				
						$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='check_edit_opinion()'><img src='imgs/edit.gif' width='22' height='22' onmouseover=writetxt('แก้ไขข้อความ') onmouseout='writetxt(0)' /></span>&nbsp;<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif' width='22' height='22' onmouseover=writetxt('ข้อความส่วนตัว') onmouseout='writetxt(0)' /></a>&nbsp;<span style='cursor:pointer;cursor:hand' onclick='delete_opinion(".$id.",$Tempopinionid)'><img src='imgs/delete.gif' width='22' height='22' onmouseover=writetxt('ลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
					}
					else
						$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='complain(".$id.",$Tempopinionid);'><img src='imgs/complain.gif' width='22' height='22' onmouseover=writetxt('แจ้งลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
				}
				else
					$tempstring .="<span style='cursor:pointer;cursor:hand' onclick='complain(".$id.",$Tempopinionid);'><img src='imgs/complain.gif' width='22' height='22' onmouseover=writetxt('แจ้งลบความคิดเห็น') onmouseout='writetxt(0)' /></span>&nbsp;";
			}
			
			$tempstring .="<a href='../user_management/showlist_member.php?uID=$Tempuserid' target='_blank'><img src='imgs/personal_info.gif' width='22' height='22' onmouseover=writetxt('ดูรายละเอียด') onmouseout='writetxt(0)'/></a></td><td class='opinion_td_editdate'>";
					
			if ($date != 0) {
			
				$tempstring .=":: แก้ไขเมื่อ $Tempedittime ::";
			}
			
			$tempstring .="</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></span>";	
					
			$cp->set_data($tempstring);	
		}
		else
			$cp->set_data("");	
	}
	else	
		$cp->set_data("");	
}

function pageNum($id){

	global $cp;
	connectdb();
	$sql="SELECT COUNT(*) FROM opinion WHERE TOPIC_ID =".$id;
	$result = mysql_fetch_array(mysql_query($sql));
	
	$cp->set_data($result[0]);	
	
}

function check_edit_topic($id){

	global $cp;
	connectdb();
		
	$sql="SELECT IP_AUTHOR,EDIT_TIME,TOPIC_MSG FROM main_topic WHERE TOPIC_ID =".$id; 
	
	$result = mysql_query($sql);
	
	if( $tempresult = mysql_fetch_array($result)){
		
		
		$Temptopicip   = $tempresult["IP_AUTHOR"];
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);
		$Tempopinionmsg  = $tempresult["TOPIC_MSG"];
				
		$tempstring = $Temptopicip."&;#@".$Tempedittime."&;#@".$Tempopinionmsg;
					
		$cp->set_data($tempstring);	
	}
	else
		$cp->set_data("false");	
		
}
function check_edit_opinion($id,$oid){

	global $cp;
	connectdb();
		
	$sql="SELECT IP_POSTER,EDIT_TIME,OPINION_MSG FROM opinion WHERE TOPIC_ID =".$id." AND OPINION_ID =".$oid; 
	
	$result = mysql_query($sql);
	
	if( $tempresult = mysql_fetch_array($result)){
		
		
		$Temptopicip   = $tempresult["IP_POSTER"];
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);
		$Tempopinionmsg  = $tempresult["OPINION_MSG"];
				
		$tempstring = $Temptopicip."&;#@".$Tempedittime."&;#@".$Tempopinionmsg;
					
		$cp->set_data($tempstring);	
	}
	else
		$cp->set_data("false");	
		
}

function delete_opinion($tID,$oID){

	global $cp;
	connectdb();
	
	$sql="SELECT USER_ID FROM opinion WHERE TOPIC_ID =".$tID." AND OPINION_ID =".$oID;
	$uID = mysql_fetch_array(mysql_query($sql));
		
	$sql="DELETE FROM opinion WHERE TOPIC_ID =".$tID." AND OPINION_ID =".$oID;
	if(mysql_query($sql)){
		reply_dec($uID[0]);
		$cp->set_data("true");
	}
	else
		$cp->set_data("false");	
	
	
}

function delete_topic($tID){

	global $cp;
	connectdb();
	if ($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer'){
		
		$sql="UPDATE main_topic SET POINT_DEL = 0 WHERE TOPIC_ID=".$tID;
		if(mysql_query($sql)){
			post_dec($tID);
			$cp->set_data("true");	
		}
		else
			$cp->set_data("false");	
	}
	else
		$cp->set_data("false");	
	
}
function warehouse($topicID){

	global $cp;
	connectdb();
	if ($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer' || $_SESSION['ss_Level'] =='senior'){
	
		$comSQLgetTopicInfo="SELECT * FROM main_topic ";
		$comSQLgetTopicInfo.=" WHERE TOPIC_ID =".$topicID;
		$getTopicInforesult=mysql_query($comSQLgetTopicInfo);
		if ($topicInforrow=mysql_fetch_array($getTopicInforesult)){
				if ($topicInforrow["EDIT_TIME"]==null){$edittime="NULL";}else {$edittime=$topicInforrow["EDIT_TIME"];}
				if ($topicInforrow["STICK_EXPIRE_IN_DAY"]==null){$stickExpire="NULL";}else {$stickExpire=$topicInforrow["STICK_EXPIRE_IN_DAY"];}
				if ($topicInforrow["POLL_QUESTION"]==null){$pollQuestion="NULL";}else {$pollQuestion="\'".$topicInforrow["POLL_QUESTION"]."\'";}
				if ($topicInforrow["POLL_EXPIRE_IN_DAY"]==null){$pollExpire="NULL";}else {$pollExpire=$topicInforrow["POLL_EXPIRE_IN_DAY"];}
				
				$comSQLInsertToWareHouse="INSERT INTO topic_warehouse   SET".
					" TOPIC_ID=".$topicInforrow["TOPIC_ID"].
					",TOPIC_HEADER='".$topicInforrow["TOPIC_HEADER"]."'".
					",TOPIC_MSG='".$topicInforrow["TOPIC_MSG"]."'".
					",POST_TIME=".$topicInforrow["POST_TIME"].
					",UPDATE_TIME=".$topicInforrow["UPDATE_TIME"].
					",EDIT_TIME=".$edittime.
					",CATEGORY='".$topicInforrow["CATEGORY"]."'".
					",PRIV_CODE='".$topicInforrow["PRIV_CODE"]."'".
					",VIEW_TOPIC=".$topicInforrow["VIEW_TOPIC"].
					",AUTHOR_ID=".$topicInforrow["AUTHOR_ID"].
					",AUTHOR_NAME='".$topicInforrow["AUTHOR_NAME"]."'".
					",IP_AUTHOR='".$topicInforrow["IP_AUTHOR"]."'".
					",REPLY_TOPIC=".$topicInforrow["REPLY_TOPIC"].
					",POINT_DEL=".$topicInforrow["POINT_DEL"].
					",TYPE='".$topicInforrow["TYPE"]."'".
					",STICK_EXPIRE_IN_DAY=".$stickExpire.
					",POLL_QUESTION=".$pollQuestion.
					",POLL_EXPIRE_IN_DAY=".$pollExpire.
					",KEEP_BY_USERID=".$_SESSION['ss_UserID']; 
					
				mysql_query($comSQLInsertToWareHouse);
				if (!mysql_error()){
						$comSQLgetOpinionInfo="SELECT * FROM opinion   WHERE TOPIC_ID=".$topicID;
						$getOpinionInforesult=mysql_query($comSQLgetOpinionInfo);
						while ($opinionInforrow=mysql_fetch_array($getOpinionInforesult)){
						if ($opinionInforrow["EDIT_TIME"]==null){$edittime="NULL";}else {$edittime=$opinionInforrow["EDIT_TIME"];}
							$comSQLInsertOpinion="INSERT INTO opinion_warehouse  SET".
								" OPINION_ID=".$opinionInforrow["OPINION_ID"].
								",TOPIC_ID=".$opinionInforrow["TOPIC_ID"].
								",USER_ID=".$opinionInforrow["USER_ID"].
								",OPINION_MSG='".$opinionInforrow["OPINION_MSG"]."'".
								",POST_TIME=".$opinionInforrow["POST_TIME"].
								",EDIT_TIME=".$edittime.
								",AUTHOR_NAME='".$opinionInforrow["AUTHOR_NAME"]."'".
								",IP_POSTER='".$opinionInforrow["IP_POSTER"]."'";
							mysql_query($comSQLInsertOpinion);
						}
						if (!mysql_error()){
							$comSQLgetPollOptionInfo.="SELECT * FROM poll_option   WHERE TOPIC_ID=".$topicID;
							$getPollOptionInforesult=mysql_query($comSQLgetPollOptionInfo);
							while ($pollOptionInforow=mysql_fetch_array($getPollOptionInforesult)){
								$comandsqlsaveOption ="INSERT INTO poll_option_warehouse  SET".
								" POLLOPTION='".$pollOptionInforow["POLLOPTION"]."'".
								",TOPIC_ID=".$pollOptionInforow["TOPIC_ID"].
								",VOTE_POINT=".$pollOptionInforow["VOTE_POINT"];
								mysql_query($comandsqlsaveOption);
							}
						}
						else{
							$cp->set_data("false");	
							return;
						}
							
				}
				else{
					$cp->set_data("false");
					return;	
				}
					
			$cp->set_data("true");
		}
		else{
			$cp->set_data("false");	
		}
	}
	else{
		$cp->set_data("false");	
	}
	echo mysql_error();
}

function draw_vote_del($id){

	global $cp;
	connectdb();
	$sql="SELECT POINT_DEL FROM main_topic WHERE TOPIC_ID =".$id;
	$result = mysql_fetch_array(mysql_query($sql));
	
	$cp->set_data($result[0]);	

}

function check_vote($id){

	$sql ="SELECT COUNT(*) FROM vote_del_topic WHERE TOPIC_ID =".$id." AND USER_ID =".$_SESSION['ss_UserID'];
	$result = mysql_fetch_array(mysql_query($sql));
	
	return $result[0];
		
}
function vote($id,$para){

	global $cp;
	connectdb();
	
	if ($_SESSION['ss_Level'] !='guest'){
		if (check_vote($id) == 0){
			
			$sql = "INSERT INTO vote_del_topic  SET TOPIC_ID =".$id.",USER_ID =".$_SESSION['ss_UserID'].",VOTE_TIME =".time();
			mysql_query($sql);
			
			$sql="SELECT POINT FROM useraccount WHERE USER_ID =".$_SESSION['ss_UserID'];
			$uID = mysql_fetch_array(mysql_query($sql));
			
			if ($uID["POINT"] > 0){
				if ($para == 0){
				
					$sql="SELECT POINT_DEL FROM main_topic WHERE TOPIC_ID =".$id;
					$result = mysql_fetch_array(mysql_query($sql));
					$dec = $result[0] - $uID["POINT"];
					$sql="UPDATE main_topic SET POINT_DEL =".$dec." WHERE TOPIC_ID=".$id;
					mysql_query($sql);
					if ($dec < 0){
						post_dec($id);
						$cp->set_data(3);	
						return;
					}
				}
				else{
				
					$sql="SELECT POINT_DEL FROM main_topic WHERE TOPIC_ID =".$id;
					$result = mysql_fetch_array(mysql_query($sql));
					$dec = $result[0] + $uID["POINT"];
					$sql="UPDATE main_topic SET POINT_DEL =".$dec." WHERE TOPIC_ID=".$id;
					mysql_query($sql);
				
				}
				
				$cp->set_data(2);
			}
			else
				$cp->set_data(0);
		}
		else{
			$cp->set_data(1);
		}
	}
	else{
		$cp->set_data(0);
	}	
	
}

?>
