<?php

include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('opinionwarehouse');
$cp->register('pageNum_warehouse');
$cp->start();
$cp->return_data();

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "( t1.PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR t1.PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}

function opinionwarehouse($id,$i){
global $cp;
	
	connectdb();
	
	$sql="SELECT TOPIC_HEADER,TOPIC_MSG,POST_TIME,EDIT_TIME,IP_AUTHOR,AUTHOR_NAME,LEVEL,POINT,USER_ID,AUTHOR_ID FROM topic_warehouse AS t1 INNER JOIN useraccount AS t2 ON t1.AUTHOR_ID = t2.USER_ID WHERE t1.TOPIC_ID ='".$id."' AND POINT_DEL > 0 AND ";
	$sql = privatecode($sql);
	
	$result =mysql_query($sql);
	
	if( $tempresult = mysql_fetch_array($result)){
		
		$Temptopicheader  = $tempresult["TOPIC_HEADER"];
		$Temptopicmsg  = $tempresult["TOPIC_MSG"];
		$Tempposttime	    = date("G:i:s D j M Y",$tempresult ["POST_TIME"]); 
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);            
		$Temptopicip   = $tempresult["IP_AUTHOR"];
		$Temptopicusername   = $tempresult["AUTHOR_NAME"];
		$Temptopiclevel   = $tempresult["LEVEL"];
		$Temptopicpoint   = $tempresult["POINT"];
		$Tempuserid       = $tempresult["USER_ID"];
		$Tempauthorid       = $tempresult["AUTHOR_ID"];
			
		$tempstring ="<table  class='opinion_tb1'><tr><td class='opinion_th_1'>หัวข้อ:: $Temptopicheader</td></tr><tr><td ><br/><table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2'>$Temptopicmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		if (($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer' || $_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] =='guest'){
		  	if ($Temptopicusername == $_SESSION['ss_UserName']){
				$tempstring .="<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/></a>&nbsp;";
			}
		}
		$tempstring .="<a href='../user_management/showlist_member.php?uID=$Tempuserid' target='_blank'><img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></a></td><td class='opinion_td_editdate'>";
			
		if ($date != 0) {
		
			$tempstring .=":: แก้ไขเมื่อ $Tempedittime ::";
		}
		
			$tempstring .="</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></td></tr></table>";	
	
	//-----------------------------------------------------------
	$page = 20;
	$start = ($i - 1) * $page;
	
	$sql="SELECT OPINION_ID,OPINION_MSG,IP_POSTER,POST_TIME,EDIT_TIME,AUTHOR_NAME,LEVEL,POINT,t1.USER_ID FROM opinion_warehouse AS t1 INNER JOIN useraccount AS t2 ON t1.USER_ID = t2.USER_ID WHERE t1.TOPIC_ID ='".$id."' "; //AND ";
	
	//$sql = privatecode($sql);
	$sql .= " ORDER BY 1 ASC LIMIT ".$start.",".$page;
	
	$result = mysql_query($sql);
	
	while( $tempresult = mysql_fetch_array($result)){
		
		$Tempopinionid  = $tempresult["OPINION_ID"];
		$Tempopinionmsg  = $tempresult["OPINION_MSG"];
		$Tempposttime	    = date("G:i:s D j M Y",$tempresult ["POST_TIME"]);
		$date = $tempresult ["EDIT_TIME"];
		$Tempedittime	    = date("G:i:s D j M Y",$date);
		$Temptopicip   = $tempresult["IP_POSTER"];
		$Temptopicusername   = $tempresult["AUTHOR_NAME"];
		$Temptopiclevel   = $tempresult["LEVEL"];
		$Temptopicpoint   = $tempresult["POINT"];
		$Tempuserid       = $tempresult["USER_ID"];
		
		
		$tempstring .="<br/><table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'><a href='post_newOpinion.php?tID=".$id."&oID=$Tempopinionid' target='_blank'>อ้างอิง::ความคิดเห็นที่ $Tempopinionid</a></td></tr><tr><td class='opinion_td_msg' colspan='2' >$Tempopinionmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		
		if (($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer' || $_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] =='guest'){
			if ($Temptopicusername == $_SESSION['ss_UserName']){
				$tempstring .="<a href='../PM/index.php' target='_blank'><img src='imgs/comPM.gif'  width='22' height='22' alt='ข้อความส่วนตัว'/></a>&nbsp;";
			}
		}
		$tempstring .="<a href='../user_management/showlist_member.php?uID=$Tempuserid' target='_blank'><img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></a></td><td class='opinion_td_editdate'>";
				
		if ($date != 0) {
		
			$tempstring .=":: แก้ไขเมื่อ $Tempedittime ::";
		}
		
		$tempstring .="</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table>";		
	
	}
	
	$cp->set_data($tempstring);	
	
}
else{
	$cp->set_data(0);	
	return;
}	
	
}

function pageNum_warehouse($id){

	global $cp;
	connectdb();
	$sql="SELECT COUNT(*) FROM opinion_warehouse WHERE TOPIC_ID =".$id;
	$result = mysql_fetch_array(mysql_query($sql));
	
	$cp->set_data($result[0]);	
	
}

?>
