<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('vote');
$cp->start();
$cp->return_data();


function vote($topicID,$optionID){
	if (!isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online"){
			$responseNode->set_data(iconv("tis-620","utf-8","��س���͡�Թ����к�"));
			return false;
	}
	global $cp;
	connectdb();
	$responseNode=$cp->add_node('response');
	/*get header (poll question)*/
	$comSQLgetPollQuestion ="SELECT * FROM main_topic  WHERE TOPIC_ID=".$topicID; 
	$getPollQuestionresult=mysql_query($comSQLgetPollQuestion);
	if ($question=mysql_fetch_array($getPollQuestionresult)){
		if ($question["POLL_QUESTION"]!="" and ($question["POLL_EXPIRE_IN_DAY"]=="" or $question["POLL_EXPIRE_IN_DAY"] > time())){
			if (checkVote($topicID,$_SESSION['ss_UserID'])){//detect duplicated vote
				$comSQLgetPoint ="SELECT VOTE_POINT FROM poll_option  WHERE TOPIC_ID=".$topicID." AND OPTION_ID=".$optionID; 
				$getPointresult=mysql_query($comSQLgetPoint);
				if ($point=mysql_fetch_array($getPointresult)){
						$comandsqlIncreasePoint = "UPDATE poll_option  SET VOTE_POINT=".($point[0]+1);
						$comandsqlIncreasePoint .= " WHERE TOPIC_ID=".$topicID." AND OPTION_ID=".$optionID;
						mysql_query($comandsqlIncreasePoint);
						$comSQLvotePoll="INSERT INTO vote_poll  SET".
						" TOPIC_ID=".$topicID.
						",OPTION_ID=".$optionID.
						",USER_ID=".$_SESSION['ss_UserID'].
						",VOTE_TIME=".time();
						mysql_query($comSQLvotePoll);
				}
				if( !mysql_error()){
						$responseNode->set_data(iconv("tis-620","utf-8","�ӡ����ǵ�������"));
						showPollResult($topicID);
				}else{
						$responseNode->set_data(iconv("tis-620","utf-8","�������ö��ǵ��"));
						showPollResult($topicID);
				}
			}else {
				$responseNode->set_data(iconv("tis-620","utf-8","�������ö��ǵ��"));
				showPollResult($topicID);

			}
		}else{
			$responseNode->set_data(iconv("tis-620","utf-8","��з��������ա�÷���"));
			showPollResult($topicID);
			return false;
		}
	}else {
		$responseNode->set_data(iconv("tis-620","utf-8","��з��������ա�÷���"));
		showPollResult($topicID);
		return false;
	}
	
}

function checkVote($topicID,$userID){
		$comSQLcheckVote ="SELECT * FROM vote_poll WHERE TOPIC_ID=".$topicID." AND USER_ID=".$userID; 
		$checkresult=mysql_query($comSQLcheckVote);
		if ($check=mysql_fetch_array($checkresult)){
			return false;
		}else return true;
}

function showPollResult($topicID){
	global $cp;
	$comSQLgetOption="SELECT * FROM poll_option  WHERE TOPIC_ID=".$topicID;
	$optionresult=mysql_query($comSQLgetOption);
	$votePoint= Array();
	$pollOption= Array();
	$nonVoteflag=true;
	while ($options=mysql_fetch_array($optionresult)){
		if ($nonVoteflag and $options["VOTE_POINT"]>0) $nonVoteflag=false;
		array_push($votePoint, $options["VOTE_POINT"]);
		array_push($pollOption, $options["POLLOPTION"]);
	}
	$resultPollNode=$cp->add_node('resultPoll');
	$data="data=";//10*9*11*10*1*
	$label="&label=";
	for ($i = 0; $i < count($votePoint); $i++) {
		$data.=$votePoint[$i]."*";
		$label.=$pollOption[$i]."*";
	}
	if ($nonVoteflag) {
		$data.=iconv("tis-620","utf-8","1");
		$label.=iconv("tis-620","utf-8","�ѧ����ռ��ӡ����ǵ");
	}else{
			$data=substr($data, 0, strlen($data)-1);//10*9*11*10*1
			$label=substr($label, 0, strlen($label)-1);
		}
	$result=$data.$label;
	$resultPollNode->set_data($result);

}
		

?>

