<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../tool/censorVulgar.php");
include("../../_Connectdatabase.php");
include("_Bookmark.php");
include("level.php");
require("check_ip.php");

session_start();
$cp = new cpaint();
$cp->register('post');
$cp->register('previewPost');
$cp->start();
$cp->return_data();

function previewPost($TopicHeader, $authorName,$Catagory,$message,$privateCode,$pollQuestion,$pollOption,$runtime,$stickflag,$runtimeStick) {
	global $cp;
	connectdb(); 
	$sql="SELECT POINT FROM useraccount WHERE USER_ID =".$_SESSION['ss_UserID'];
	$result = mysql_fetch_array(mysql_query($sql));
	if ($result["POINT"] > 0){
		$TopicHeader=censorVulgar($TopicHeader);
		$authorName=censorVulgar($authorName);
		$message=censorVulgar($message);
		$message=str_replace('\r\n','',$message);
		$message=str_replace('\n','',$message);
		$thistime=time();
		$Temptopicmsg  = $message;
		$Tempposttime	    = date("G:i:s D j M Y",$thistime);
		$Temptopicip   = getIp();
		$Temptopicusername   = $authorName;
		$Temptopiclevel   = $_SESSION['ss_Level'];
		$tempstring ="<table  class='opinion_tb1'><tr><td class='opinion_th_1'>หัวข้อ:: $TopicHeader</td></tr><tr><td ><br/><table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2'>$Temptopicmsg</td></tr><tr><td class='opinion_td_button2'>";
			
		if(($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer') && $_SESSION['ss_Level'] !='guest'){
				if ($Temptopicusername == $_SESSION['ss_UserName']){
				
					$tempstring .="<img src='imgs/edit.gif'  width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
					$tempstring .="<img src='imgs/delete.gif'  width='22' height='22' alt='ลบหัวข้อกระทู้'/>&nbsp;";
		}
		else if(($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] !='guest'){ 
				if ($Temptopicusername == $_SESSION['ss_UserName']){
				
					$tempstring .="<img src='imgs/edit.gif'  width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
		}
			
		$tempstring .="<img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></td><td class='opinion_td_editdate'>&nbsp;</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></td></tr></table>";
			
		if ($privateCode==""){  
			$cp->set_data("Please,Choose private of topic");
		}else 
			$cp->set_data($tempstring);
	}
	else
		$cp->set_data("false");
	
}
function post($topicHeader, $authorName,$catagory,$message,$privateCode,$pollQuestion,$pollOption,$runtime,$stickflag,$runtimeStick) {
	global $cp;
	connectdb(); 
	if ($_SESSION['ss_privcode'] =="A" || $_SESSION['ss_Status'] == "offline"){
		$c = strpos($privateCode,'A');
			if ($c < 0)
				$privateCode = $privateCode."A";
	}		
				
	if ($privateCode==""){
		$cp->set_data("Please,Choose private of topic");
		return ;
	}
	$TopicHeader=censorVulgar($TopicHeader);
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	$message=str_replace('\r\n','',$message);
	$message=str_replace('\n','',$message);
	$comandsqlcount = "SELECT MAX(TOPIC_ID) FROM main_topic";
	$idresult=mysql_query($comandsqlcount);
	$id=mysql_fetch_array($idresult);
	$postTime=time();// save in form microtime
	$ipAuthon=getIp();
	if ($stickflag){
		$type="stick";
		if ($runtimeStick!=0 and $runtimeStick!=null){$runtimeStick=time()+($runtimeStick*60*60*24);}
		else{$runtimeStick="NULL";}
	}else if(count($pollOption)!=0){
		$type="poll";	
		$runtimeStick="NULL";
	}else{
		$type="normal";
		$runtimeStick="NULL";
	}
	
	$sql="SELECT POINT FROM useraccount WHERE USER_ID =".$_SESSION['ss_UserID'];
	$result = mysql_fetch_array(mysql_query($sql));
	if ($result["POINT"] > 0){
		$comSQLInserttopic="INSERT INTO main_topic SET".
			" TOPIC_ID=".($id[0]+1).
			",TOPIC_HEADER='".$topicHeader."'".
			",TOPIC_MSG='".$message."'".
			",POST_TIME=".$postTime.
			",UPDATE_TIME=".$postTime.
			",CATEGORY='".$catagory."'".
			",PRIV_CODE='".$privateCode."'".
			",AUTHOR_ID=".$_SESSION['ss_UserID'].
			",AUTHOR_NAME='".$authorName."'".
			",VIEW_TOPIC=0".
			",IP_AUTHOR='".$ipAuthon."'".
			",REPLY_TOPIC=0".
			",POINT_DEL=".$_SESSION['ss_point'] * 10 .
			",TYPE='".$type."'".
			",STICK_EXPIRE_IN_DAY=".$runtimeStick;
	
		mysql_query($comSQLInserttopic);
		
		if (count($pollOption)!=0){
			createPoll(($id[0]+1),$pollQuestion,$pollOption,$runtime);
		}
		if( !mysql_error()){
		 	bookmark($_SESSION['ss_UserID'], ($id[0]+1),"post");
		 	post_inc($_SESSION['ss_UserID']);
			$cp->set_data($_SESSION['ss_PageBefore']);
		}else 
			$cp->set_data(mysql_error());
	}
	else
		$cp->set_data("false");
}
function createPoll($topicID,$pollQuestion,$pollOption,$runtime){
	//echo $runTime;
	$pollQuestion=censorVulgar($pollQuestion);
	if ($runtime!= 0){
		$exp=time()+($runtime*60*60*24);
		$comandsqlsavePoll = "UPDATE main_topic SET POLL_QUESTION='".$pollQuestion."', POLL_EXPIRE_IN_DAY=".$exp;
	}
	else{
		$comandsqlsavePoll = "UPDATE main_topic SET POLL_QUESTION='".$pollQuestion."'";
	}
	$comandsqlsavePoll .= " WHERE TOPIC_ID=".$topicID;
	mysql_query($comandsqlsavePoll);
	$amountOption = count($pollOption);
	for ($i=0; $i<$amountOption ; $i++){
		$pollOption[$i]=censorVulgar($pollOption[$i]);
		$comandsqlsaveOption ="INSERT INTO poll_option SET".
		" POLLOPTION='".$pollOption[$i]."'".
		",TOPIC_ID=".$topicID.
		",OPTION_ID=".$i.
		",VOTE_POINT=0";
		mysql_query($comandsqlsaveOption);
	}
	
}
?>