<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('showquote');
$cp->start();
$cp->return_data();

function showquote($oID,$tID) {
	global $cp;
	connectdb();
	mysql_query("SET NAMES utf8"); 

	$comSQLSelectOpinion="SELECT  *  FROM opinion WHERE ".
		" OPINION_ID=".$oID.
		" AND TOPIC_ID=".$tID;
	$selectOpinionresult=mysql_query($comSQLSelectOpinion);
	if( !mysql_error()){
		if ($oprow=mysql_fetch_array($selectOpinionresult)){
			$opinionNode=$cp->add_node('opinion');
			$opinionIDNode =& $opinionNode->add_node('opinionID');
			$topicIDNode =& $opinionNode->add_node('topicID');
			$authorNameNode =& $opinionNode->add_node('authorName');
			$opinionMSGNode =& $opinionNode->add_node('opinionMSG');
			$postTimeNode =& $opinionNode->add_node('postTime');

			$opinionIDNode->set_data ($oprow["OPINION_ID"]);
			$topicIDNode->set_data($oprow["TOPIC_ID"]);
			$authorNameNode->set_data($oprow["AUTHOR_NAME"]);
			$opinionMSGNode->set_data($oprow["OPINION_MSG"]);
			$postTimeNode->set_data(date("G:i:s D j M Y",$oprow["POST_TIME"]));
			
		}
	}else $cp->set_data(mysql_error());
}




?>