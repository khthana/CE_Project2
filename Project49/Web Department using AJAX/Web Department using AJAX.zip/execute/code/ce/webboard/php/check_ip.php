<?php
//List of the private ips described in the RFC. You can easily add the 
//127.0.0.0/8 to this if you need it.

$ip_private_list=array(
                       "10.0.0.0/8",
                       "172.16.0.0/12",
                       "192.168.0.0/16"
);

//Determine if an ip is in a net.
//E.G. 120.120.120.120 in 120.120.0.0/16
//I saw this in another post in this site but don't remember where :P

function isIPInNet($ip,$net,$mask) {
  $lnet=ip2long($net);
  $lip=ip2long($ip);
  $binnet=str_pad( decbin($lnet),32,"0","STR_PAD_LEFT" );
  $firstpart=substr($binnet,0,$mask);
  $binip=str_pad( decbin($lip),32,"0","STR_PAD_LEFT" );
  $firstip=substr($binip,0,$mask);
                                                                               
  return(strcmp($firstpart,$firstip)==0);
}

//This function check if a ip is in an array of nets (ip and mask)

function isIpInNetArray($theip,$thearray)
{
  $exit_c=false;
  #print_r($thearray);
  foreach ( $thearray as $subnet ) {
   list($net,$mask)=split("/",$subnet);
   if(isIPInNet($theip,$net,$mask)){
     $exit_c=true;
     break;
   }
  }
  return($exit_c);
}

//Building the ip array with the HTTP_X_FORWARDED_FOR and 
//REMOTE_ADDR HTTP vars.
//With this function we get an array where first are the ip's listed in 
//HTTP_X_FORWARDED_FOR and the last ip is the REMOTE_ADDR.
//This is inspired (copied and modified) in the function from daniel_dll.

function GetIpArray()
{
 $cad="";                                                                        
 if  (isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND  $_SERVER['HTTP_X_FORWARDED_FOR']!=""){
                 $cad=$_SERVER['HTTP_X_FORWARDED_FOR'];      
}                                                   
 if(isset($_SERVER['REMOTE_ADDR']) AND  $_SERVER['REMOTE_ADDR']!=""){
                 $cad=$cad.",".$_SERVER['REMOTE_ADDR'];                                                                          
 }                                                                               
 $arr=  explode(',',$cad);
                                                                               
 return $arr;
}

//We check each ip in the array and we returns the first that is not a
//private ip.

function getIp()
{
  global $ip_private_list;
   $ip = "unknown";
   $ip_array=getIpArray();
   foreach ( $ip_array as $ip_s ) {                                                        
     if( $ip_s!="" AND !isIPInNetArray($ip_s,$ip_private_list)){
       $ip=$ip_s;
       break;
     }
   }                                                                                                                                           
  return($ip);
} 

function getIP_0() { 
	$ip; 

	if (getenv("HTTP_CLIENT_IP")) $ip = getenv("HTTP_CLIENT_IP"); 
	else if(getenv("HTTP_X_FORWARDED_FOR")) $ip = getenv("HTTP_X_FORWARDED_FOR"); 
	else if(getenv("REMOTE_ADDR")) $ip = getenv("REMOTE_ADDR"); 
	else $ip = "UNKNOWN"; 

	return $ip; 

} 

?>