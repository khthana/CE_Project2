<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../tool/censorVulgar.php");
include("_Bookmark.php");
require("check_ip.php");

session_start();
$cp = new cpaint();
$cp->register('reply');
$cp->register('previewReply');
$cp->register('edit_opinion');
$cp->start();
$cp->return_data();

function edit_opinion($tID,$oID){
	global $cp;
	connectdb();
	if  ($_SESSION['ss_Level'] == "guest")
		$cp->set_data(0);
	else{
		$sql="SELECT POST_TIME,OPINION_MSG FROM opinion WHERE TOPIC_ID ='".$tID."' AND OPINION_ID ='".$oID."' AND AUTHOR_NAME ='".$_SESSION['ss_UserName']."' AND USER_ID != 0";
		$result = mysql_query($sql);
		if( $temprow = mysql_fetch_array($result)){
			$temprow[0] = date("G:i:s D j M Y",$temprow[0]); 
			$string = $temprow[0]."&;#@".$temprow[1];
			$cp->set_data($string);
		}
		else
			$cp->set_data(0);
	
	}
}


function previewReply( $authorName,$message,$topicID,$opinionID) {
	global $cp;
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	$message=str_replace('\r\n','',$message);
	$message=str_replace('\n','',$message);
	$thistime=time();
	$Tempopinionmsg  = $message;
	$Tempedittime	= date("G:i:s D j M Y",$thistime);
	$Temptopicip   = getIp();
	$Temptopicusername   = $authorName;
	$Temptopiclevel   = $_SESSION['ss_Level'];
	$tempstring ="<table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' ><span id='posttime_' ></span></td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2' >$Tempopinionmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		
		if(($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer') && $_SESSION['ss_Level'] !='guest'){
			
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif' width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif'  width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
				$tempstring .="<img src='imgs/delete.gif' width='22' height='22' alt='ลบความคิดเห็น'/>&nbsp;";
		}
		else if(($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] !='guest'){
			
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif' width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;<img src='imgs/delete.gif' width='22' height='22' alt='ลบความคิดเห็น'/>&nbsp;";
				}
				else
					$tempstring .="<img src='imgs/complain.gif'  alt='แจ้งลบความคิดเห็น'/>&nbsp;";
		}
		
		$tempstring .="<img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></a></td><td class='opinion_td_editdate'>:: แก้ไขเมื่อ $Tempedittime ::</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table>";
				
	if ($message==""){  
		$cp->set_data("Please,Enter your message");
	}
	else 
		$cp->set_data($tempstring);
}

function reply($authorName,$message,$topicID,$opinionID) {
	global $cp;
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	connectdb();
	if ($message==""){
		$cp->set_data("Please,Enter your message");
		return ;
	}
	$message=str_replace('\r\n','',$message);
	$message=str_replace('\n','',$message);
	$editTime=time();
	$ipAuthon=getIp();
	$comSQLInsertOpinion="UPDATE opinion  SET".
		" OPINION_MSG='".$message."'".
		",EDIT_TIME=".$editTime.
		",IP_POSTER='".$ipAuthon."' WHERE TOPIC_ID=".$topicID." AND OPINION_ID=".$opinionID." AND AUTHOR_NAME ='".$_SESSION['ss_UserName']."' AND USER_ID != 0";
	mysql_query($comSQLInsertOpinion);
	
	if( !mysql_error()){
		$comSQLUpdateTopic="UPDATE main_topic  SET ".
							" UPDATE_TIME=$editTime WHERE TOPIC_ID=".$topicID;
		mysql_query($comSQLUpdateTopic);
	}else{
		echo mysql_error();
	}
	
	if( !mysql_error()){
		$cp->set_data("Completed Process");
	}else $cp->set_data(mysql_error());
}
?>