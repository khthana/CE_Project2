<?php


include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../tool/censorVulgar.php");
include("../../_Connectdatabase.php");
require("check_ip.php");
session_start();
$cp = new cpaint();
$cp->register('edit_topic');
$cp->register('get_poll');
$cp->register('edit_post');
$cp->register('previewPost');
//$cp->register('createPoll');

$cp->start();
$cp->return_data();

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "( PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}

function authen($id){
	connectdb(); 
	$sql="SELECT COUNT(*) FROM main_topic WHERE TOPIC_ID =".$id." AND AUTHOR_ID != 0 AND AUTHOR_NAME ='".$_SESSION['ss_UserName']."' AND POINT_DEL > 0 AND ";
	$sql = privatecode($sql);
	$tempresult = mysql_fetch_array(mysql_query($sql));
	return $tempresult[0];

}

function edit_topic($id){
	global $cp;
	
	if  ($_SESSION['ss_Level'] == "guest")
		$cp->set_data(0);
	else{
		connectdb();
		$sql = "SELECT CATEGORY,TOPIC_HEADER,PRIV_CODE,TYPE,STICK_EXPIRE_IN_DAY,POST_TIME,TOPIC_MSG FROM main_topic WHERE TOPIC_ID =".$id." AND AUTHOR_NAME = '".$_SESSION['ss_UserName']."' AND AUTHOR_ID != 0 AND POINT_DEL > 0 AND ";
		$sql = privatecode($sql);
		$result = mysql_query($sql);
		if( $temprow = mysql_fetch_array($result)){
			if ($temprow[4] == 0 || $temprow[4] == null)
				$temprow[4] ="";
			else
				$temprow[4] = ceil(($temprow[4] - time())/(60*60*24));
			$temprow[5] = date("G:i:s D j M Y",$temprow[4]); 
			$string = $temprow[0]."&;#@".$temprow[1]."&;#@".$temprow[2]."&;#@".$temprow[3]."&;#@".$temprow[4]."&;#@".$temprow[5]."&;#@".$temprow[6];
			$cp->set_data($string);
		}
		else
			$cp->set_data(0);
	
	}
}

function get_poll($topicID){
		global $cp;
		$responseNode=$cp->add_node('response');
		if  ($_SESSION['ss_Level'] == "guest"){
			$responseNode->set_data("No Poll");
			return false;
		}
		connectdb(); 
		$sql = "SELECT POLL_QUESTION,POLL_EXPIRE_IN_DAY FROM main_topic WHERE TOPIC_ID =".$topicID." AND AUTHOR_ID = ".$_SESSION['ss_UserID']." AND AUTHOR_ID != 0 AND POINT_DEL > 0 ";
		$result = mysql_query($sql);
		if( $topicrow = mysql_fetch_array($result)){
			if ($topicrow["POLL_QUESTION"]!=""){
				$questionNode=$cp->add_node('question');
				$runtimeNode=$cp->add_node('runtime');
				$questionNode->set_data($topicrow["POLL_QUESTION"]);
				if ($topicrow["POLL_EXPIRE_IN_DAY"] !="")$runtimeNode->set_data(ceil(($topicrow["POLL_EXPIRE_IN_DAY"] - time())/(60*60*24)));
				else 	$runtimeNode->set_data("-");

				$optionlistNode=$cp->add_node('optionlist');
				$comSQLgetOption="SELECT * FROM poll_option  WHERE TOPIC_ID=".$topicID;
				$optionresult=mysql_query($comSQLgetOption);
				while ($options=mysql_fetch_array($optionresult)){
						$optionNode=$optionlistNode->add_node('option');
						$optionNode->set_data($options["POLLOPTION"]);
				}
				$responseNode->set_data("Has Poll");
				return true;
			}
		}
		$responseNode->set_data("No Poll");
		return false;

}

function previewPost($id,$TopicHeader, $authorName,$Catagory,$message,$privateCode,$pollQuestion,$pollOption,$runtime,$stickflag,$runtimeStick) {
	global $cp;
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	if(authen($id) != 0){
		$message=str_replace('\r\n','',$message);
		$message=str_replace('\n','',$message);
		$thistime=time();
		$Temptopicmsg  = $message;
		$Tempedittime	    = date("G:i:s D j M Y",$thistime);
		$Temptopicip   = getIp();
		$Temptopicusername   = $authorName;
		$Temptopiclevel   = $_SESSION['ss_Level'];
	
		$tempstring ="<table  class='opinion_tb1'><tr><td class='opinion_th_1'>หัวข้อ:: $TopicHeader</td></tr><tr><td ><br/><table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' ><span id='posttime_' ></span></td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2'>$Temptopicmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		if(($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer') && $_SESSION['ss_Level'] !='guest'){
		  		if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif'  width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
				$tempstring .="<img src='imgs/delete.gif'  width='22' height='22' alt='ลบหัวข้อกระทู้'/>&nbsp;";
		}
		else if(($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] !='guest'){ 
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif'  width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
		}
		
		$tempstring .="<img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></td><td class='opinion_td_editdate'>:: แก้ไขเมื่อ $Tempedittime ::</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table></td></tr></table>";
				
			
    	if ($privateCode=="")      {  
			$cp->set_data("Please,Choose private of topic");
		}
		else 
			$cp->set_data($tempstring);
	}
	else
		$cp->set_data(0);
}

function edit_post($id,$catagory,$message,$privateCode,$pollQuestion,$pollOption,$runtime,$stickflag,$runtimeStick){
	global $cp;
	connectdb();
	
	if(authen($id) != 0){
	
		if ($_SESSION['ss_privcode'] =="A" || $_SESSION['ss_Status'] == "offline"){
				$c = strpos($privateCode,'A');
				if ($c < 0)
					$privateCode = $privateCode."A";
		}
		if ($privateCode==""){
			$cp->set_data("Please,Choose private of topic");
			return ;
		}
		
		$message=censorVulgar($message);
		$message=str_replace('\r\n','',$message);
		$message=str_replace('\n','',$message);
		$ipAuthon=getIp();
		if ($stickflag){
			$type="stick";
			if ($runtimeStick!=0 and $runtimeStick!=null){
				$runtimeStick=time()+($runtimeStick*60*60*24);
			}
			else{
				$runtimeStick="NULL";
			}
		}
		else if(count($pollOption)!=0){
			$type="poll";	
			$runtimeStick="NULL";
		}
		else{
			$type="normal";
			$runtimeStick="NULL";
		}
		$comSQLInserttopic="UPDATE main_topic SET".
							" TOPIC_MSG='".$message."'".
							",EDIT_TIME=".time().
							",CATEGORY='".$catagory."'".
							",PRIV_CODE='".$privateCode."'".
							",IP_AUTHOR='".$ipAuthon."'".
							",TYPE='".$type."'".			
							",STICK_EXPIRE_IN_DAY=".$runtimeStick ." WHERE TOPIC_ID=".$id;
	
		mysql_query($comSQLInserttopic);
	
		echo mysql_error();
		if ($pollQuestion!=""){
			editPoll($id,$pollQuestion,$pollOption,$runtime);
		}
		if( !mysql_error()){
			$cp->set_data(1);
		}
		else 
			$cp->set_data(mysql_error());
	}
	
	else
		$cp->set_data(0);
}

function editPoll($topicID,$pollQuestion,$pollOption,$runtime){
	//echo $runTime;
	$numOldOption=0;
	$pollQuestion=censorVulgar($pollQuestion);
	if ($runtime!= 0){
		$exp=time()+($runtime*60*60*24);
		$comandsqlsavePoll = "UPDATE main_topic SET POLL_EXPIRE_IN_DAY=".$exp;
	}else{
		$comandsqlsavePoll = "UPDATE main_topic SET POLL_EXPIRE_IN_DAY=NULL";
	}
	$comandsqlsavePoll .= " WHERE TOPIC_ID=".$topicID;
	mysql_query($comandsqlsavePoll);
	$oldPresentArray = array();
	$inDBArray = array();
	$comSQLgetOption="SELECT * FROM poll_option  WHERE TOPIC_ID=".$topicID;
	$optionresult=mysql_query($comSQLgetOption);
	while ($options=mysql_fetch_array($optionresult)){
		$key=-1;
		array_push($inDBArray, $options["POLLOPTION"]);
		 $key=array_search($options["POLLOPTION"], $pollOption); 
		if ($key >-1){
			array_push($oldPresentArray,$options["POLLOPTION"]);
			}
		$numOldOption++;
	}
	if ($numOldOption==0)$newArray=$pollOption;
	print_r($inDBArray);
	print_r($oldPresentArray);
	for ($i=0; $i<count($inDBArray) ; $i++){
		$key=-1;
		$key=array_search($inDBArray[$i], $oldPresentArray); 
		echo " *is_int :".is_int($key);
		if (!is_int($key) ){
			$comSQLgetOptionID="SELECT OPTION_ID FROM poll_option  WHERE TOPIC_ID=".$topicID." AND POLLOPTION = '".$inDBArray[$i]."'";
			$optionIDresult=mysql_query($comSQLgetOptionID);
			if ($optionID=mysql_fetch_array($optionIDresult)){
					$comSQLdeleteOption="DELETE FROM  poll_option  WHERE OPTION_ID = ".$optionID[0]." AND TOPIC_ID=".$topicID;
					mysql_query($comSQLdeleteOption);
					$comSQLdeletelogVote="DELETE FROM   vote_poll   WHERE OPTION_ID = ".$optionID[0]." AND TOPIC_ID=".$topicID;
					mysql_query($comSQLdeletelogVote);
			}
		}
	}
	$comSQLMaxOptionID="SELECT MAX(OPTION_ID) FROM poll_option  WHERE TOPIC_ID=".$topicID;
	$optionMaxIDresult=mysql_query($comSQLMaxOptionID);
	$maxoptionID=mysql_fetch_array($optionMaxIDresult);
	$numMaxID=$maxoptionID[0];
/*	print_r($pollOption);
	print_r($oldPresentArray);*/
	for ($i=0; $i<count($pollOption); $i++){
		$key=-1;
		$key=array_search($pollOption[$i], $oldPresentArray); 
	//	echo " *key :".$key."  *pollOption:".$pollOption[$i];
		if (!is_int($key)){
			$pollOption[$i]=censorVulgar($pollOption[$i]);
			$comandsqlsaveOption ="INSERT INTO poll_option SET".
			" POLLOPTION='".$pollOption[$i]."'".
			",TOPIC_ID=".$topicID.
			",OPTION_ID=".($numMaxID+$i).
			",VOTE_POINT=0";
			mysql_query($comandsqlsaveOption);
		}
	}
	
}

?>


