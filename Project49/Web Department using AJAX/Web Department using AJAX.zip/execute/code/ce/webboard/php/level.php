<?php
function post_inc($uID){
	
	if ($_SESSION['ss_Level'] =='user' || $_SESSION['ss_Level'] =='senior'){
		$sql="SELECT POINT FROM useraccount WHERE USER_ID =".$uID;
		$result = mysql_fetch_array(mysql_query($sql));
		$inc = $result[0] + 10;
		$sql="UPDATE useraccount SET POINT =".$inc." WHERE USER_ID=".$uID;
		mysql_query($sql);
		if ($inc > 500)
			level_up_down(1,$uID);
			
		
	}
}
function post_dec($tID){
	
		$sql ="SELECT POINT,LEVEL,USER_ID FROM useraccount INNER JOIN main_topic ON USER_ID = AUTHOR_ID WHERE TOPIC_ID =".$tID; 
		$result = mysql_fetch_array(mysql_query($sql));
		if ($result["LEVEL"] =='user' || $result["LEVEL"] =='senior'){
			$dec = $result[0] - 15;
			$sql="UPDATE useraccount SET POINT =".$dec." WHERE USER_ID=".$result["USER_ID"];
			mysql_query($sql);
			if ($dec < 500)
				level_up_down(0,$result["USER_ID"]);
				
			
		}
}
function reply_inc($uID){
	
	if ($_SESSION['ss_Level'] =='user' || $_SESSION['ss_Level'] =='senior'){
		$sql="SELECT POINT FROM useraccount WHERE USER_ID =".$uID;
		$result = mysql_fetch_array(mysql_query($sql));
		$inc = $result[0] + 1;
		$sql="UPDATE useraccount SET POINT =".$inc." WHERE USER_ID=".$uID;
		mysql_query($sql);
		if ($inc > 500)
			level_up_down(1,$uID);
			
		
	}
}
function reply_dec($uID){
	
	$sql="SELECT POINT,LEVEL FROM useraccount WHERE USER_ID =".$uID;
	$result = mysql_fetch_array(mysql_query($sql));
	if ($result["LEVEL"] =='user' || $result["LEVEL"] =='senior'){
		$dec = $result[0] - 5;
		$sql="UPDATE useraccount SET POINT =".$dec." WHERE USER_ID=".$uID;
		mysql_query($sql);
		if ($dec < 500)
			level_up_down(0,$uID);
			
		
	}
}
function level_up_down($para,$uID){

	if($para == 0){
	
		$sql="UPDATE useraccount SET LEVEL ='user' WHERE USER_ID=".$uID;
		mysql_query($sql);
	}
	else{
	
		$sql="UPDATE useraccount SET LEVEL ='senior' WHERE USER_ID=".$uID;
		mysql_query($sql);
	}
}

?>