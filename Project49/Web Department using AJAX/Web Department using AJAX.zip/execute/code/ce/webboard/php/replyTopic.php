<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../tool/censorVulgar.php");
include("../../_Connectdatabase.php");
include("_Bookmark.php");
include("level.php");
require("check_ip.php");

session_start();
$cp = new cpaint();
$cp->register('reply');
$cp->register('previewReply');
$cp->start();
$cp->return_data();

function privatecode($sql){

	$array = str_split($_SESSION['ss_privcode']);
	foreach ($array as $value){
	
		if ($value == "A")
			$sql .= "(PRIV_CODE LIKE '%".$value."%'";
		else
			$sql .= " OR PRIV_CODE LIKE '%".$value."%'";
				
	}
	$sql .= " )";
	
	return $sql;
}

function authen($id){
	connectdb(); 
	$sql="SELECT COUNT(*) FROM main_topic WHERE TOPIC_ID ='".$id."' AND POINT_DEL > 0 AND ";
	$sql = privatecode($sql);
	$tempresult = mysql_fetch_array(mysql_query($sql));
	return $tempresult[0];
}

function previewReply( $authorName,$message,$topicID) {
	global $cp;
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	if(authen($topicID) != 0){
		$message=str_replace('\r\n','',$message);
		$message=str_replace('\n','',$message);
		$thistime=time();
		$Tempopinionmsg  = $message;
		$Tempposttime	    = date("G:i:s D j M Y",$thistime);
		$Temptopicip   = getIp();
		$Temptopicusername   = $authorName;
		$Temptopiclevel   = $_SESSION['ss_Level'];
		$tempstring ="<table cellpadding='0' cellspacing='0' class='opinion_tb2'><tr><td class='opinion_td_name' rowspan='2'>$Temptopicusername<br/>สถานะ :: $Temptopiclevel</td><td class='opinion_td_postdate' >:: เมื่อ $Tempposttime ::</td><td class='opinion_td_button1'>&nbsp;</td></tr><tr><td class='opinion_td_msg' colspan='2' >$Tempopinionmsg</td></tr><tr><td class='opinion_td_button2'>";
		
		
		if(($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level'] =='lecturer') && $_SESSION['ss_Level'] !='guest'){
			
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif' width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif'  width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;";
				}
				$tempstring .="<img src='imgs/delete.gif' width='22' height='22' alt='ลบความคิดเห็น'/>&nbsp;";
		}
		else if(($_SESSION['ss_Level'] =='senior' || $_SESSION['ss_Level'] =='user') && $_SESSION['ss_Level'] !='guest'){
			
				if ($Temptopicusername == $_SESSION['ss_UserName']){
			
					$tempstring .="<img src='imgs/edit.gif' width='22' height='22' alt='แก้ไขข้อความ'/>&nbsp;<img src='imgs/comPM.gif' width='22' height='22' alt='ข้อความส่วนตัว'/>&nbsp;<img src='imgs/delete.gif' width='22' height='22' alt='ลบความคิดเห็น'/>&nbsp;";
				}
				else
					$tempstring .="<img src='imgs/complain.gif'  alt='แจ้งลบความคิดเห็น'/>&nbsp;";
		}
		
		$tempstring .="<img src='imgs/personal_info.gif' width='22' height='22' alt='ดูรายละเอียด'/></a></td><td class='opinion_td_editdate'>&nbsp;</td><td class='opinion_td_ip' >IP::$Temptopicip</td></tr></table>";
				
		if ($message==""){  
			$cp->set_data("Please,Enter your message");
		}
		else 
			$cp->set_data($tempstring);
	}
	else
			$cp->set_data(0);
}

function reply($authorName,$message,$topicID){
	global $cp;
	connectdb(); 
	$authorName=censorVulgar($authorName);
	$message=censorVulgar($message);
	if(authen($topicID) != 0){
		if ($message==""){
			$cp->set_data("Please,Enter your message");
			return ;
		}
		$message=str_replace('\r\n','',$message);
		$message=str_replace('\n','',$message);
		$comandsqlcount = "SELECT MAX(OPINION_ID) FROM  opinion WHERE TOPIC_ID=".$topicID;
		$idresult=mysql_query($comandsqlcount);
		$id=mysql_fetch_array($idresult);
		$postTime=time();// save in form microtime
		$ipAuthon=getIp();
		$comSQLInsertOpinion="INSERT INTO opinion  SET".
			" OPINION_ID=".($id[0]+1).
			",TOPIC_ID=".$topicID.
			",USER_ID=".$_SESSION['ss_UserID'].
			",OPINION_MSG='".$message."'".
			",POST_TIME=".$postTime.
			",AUTHOR_NAME='".$authorName."'".
			",IP_POSTER='".$ipAuthon."'";
		mysql_query($comSQLInsertOpinion);
		if( !mysql_error()){
			$comandsqlcount = "SELECT COUNT(*) FROM opinion WHERE TOPIC_ID=$topicID";
			$countresult=mysql_query($comandsqlcount);
			$numReplyArray=mysql_fetch_array($countresult);
			$numReply=$numReplyArray[0];
			$comSQLUpdateTopic="UPDATE main_topic  SET ".
								" UPDATE_TIME=$postTime".
								",REPLY_TOPIC=$numReply";
			$comSQLUpdateTopic .=" WHERE TOPIC_ID=$topicID";
		}
		else{
				echo mysql_error();
		}
		mysql_query($comSQLUpdateTopic);
		if( !mysql_error()){
			bookmark($_SESSION['ss_UserID'], $topicID,"reply");
			reply_inc($_SESSION['ss_UserID']);
			$cp->set_data("Completed Process");
		}
		else 
			$cp->set_data(mysql_error());
	}
	else
		$cp->set_data(0);
}
?>