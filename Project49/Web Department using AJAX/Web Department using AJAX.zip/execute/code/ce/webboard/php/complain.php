<?php

include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");

session_start();
$cp = new cpaint();
$cp->register('complain');

$cp->start();
$cp->return_data();

function complain($topicID,$opinionID){
	if ($_SESSION['ss_UserID'] !=0 ){
		global $cp;
		connectdb();
		if (sendmessage($_SESSION['ss_UserID'], $_SESSION['ss_UserName'],$topicID,$opinionID)){
				$cp->set_data("ได้ทำการร้องเรียนแล้ว");
		}else $cp->set_data("ระบบขัดข้องกรุณาส่งอีกครั้ง");
	}else $cp->set_data("Incompelete");
}

function sendmessage($senderID,$senderName,$topicID,$opinionID){
	$comSQLgetMessage="SELECT * FROM opinion WHERE TOPIC_ID=".$topicID." AND OPINION_ID=".$opinionID;
	$getMessageresult=mysql_query($comSQLgetMessage);
	if ($messagerrow=mysql_fetch_array($getMessageresult)){
		$message="คำร้องเรียนการแจ้งลบความคิดเห็นจาก ".$senderName;
		$message.="<br/><hr/>";
		$message.=$messagerrow['OPINION_MSG'];
		$message.="<br/><hr/>";
		$message.="<a href=\'../webboard/showOpinion.php?tID=".$topicID."\' target=\"_blank\">ตามลิงค์นี้</a>";
		$comandsqlgetRecevierID="SELECT USER_ID FROM useraccount  WHERE LEVEL='admin'";
		$recevierIDresult=mysql_query($comandsqlgetRecevierID);
		while ($recevierID=mysql_fetch_array($recevierIDresult)){
					$comandsqlcount = "SELECT MAX(PM_ID) FROM private_message ";
					$idresult=mysql_query($comandsqlcount);
					$id=mysql_fetch_array($idresult);
					$comSQLInsertmessage="INSERT INTO private_message  SET".
							" PM_ID=".($id[0]+1).
							",MESSAGE='".$message."'".
							",TIME=".time().
							",SENDER_ID=".$_SESSION['ss_UserID'].
							",RECEIVER_ID=".$recevierID[0].
							",TYPE='complain'".
							",STATUS_FLAG='unread'";
					mysql_query($comSQLInsertmessage);
		}
		echo mysql_error();
		if(!mysql_error()){
			return true;
		}else return false;
	}else return false;
}
?>