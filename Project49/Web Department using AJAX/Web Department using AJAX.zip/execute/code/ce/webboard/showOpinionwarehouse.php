<?php
		include("../_Sessionstart.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="../tool/decodeSpecialChar.js"></script>
<script type="text/javascript" src="js/showOpinionwarehouse.js"></script>
<script type="text/javascript" src="js/showQuote.js"></script>
<script type="text/javascript" src="js/pollWareHouse.js"></script>
<link rel="stylesheet" type="text/css" href="css/opinion.css"> 
<link type=text/css rel=stylesheet href="css/quote.css">

</head>
<body >
<br/>
<div align="center">
    <table width="800" border="0" cellpadding="0" cellspacing="0">
			<tr>
        		<td align="center" ><img  border="0" src="../images/logo.gif" width="640" height="135"></td>
			</tr>
			<tr >
			<td colspan="2" height="20"></td></tr>
    </table>
</div>
<div id="Layer2" class="opinion" align="center"></div><br/>
<div id="Layer3" align="center"></div>
<script>
		showPoll();
		init_page_warehouse();
		opinionwarehouse();
		
</script>
</body>
</html>

