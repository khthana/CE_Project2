<?php
		include("../_Sessionstart.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="../tool/decodeSpecialChar.js"></script>
<script type="text/javascript" src="js/showOpinion.js"></script>
<script type="text/javascript" src="js/showQuote.js"></script>
<script type="text/javascript" src="js/complain.js"></script>
<script type="text/javascript" src="js/bookmark.js"></script>
<script type="text/javascript" src="js/poll.js"></script>
<script type="text/javascript" src="js/votePoll.js"></script>
<script type="text/javascript" src="js/alttxt.js"></script>
<script type="text/javascript" src="../tool/cookies.js"></script>
<link rel="stylesheet" type="text/css" href="css/opinion.css"> 
<link type=text/css rel=stylesheet href="css/quote.css">

</head>
<body >
<br/>
<div align="center">
    <table width="800" border="0" cellpadding="0" cellspacing="0">
			<tr>
        		<td align="center" ><img  border="0" src="../images/logo.gif" width="640" height="135"></td>
			</tr>
			<tr >
			<td colspan="2" height="20"></td></tr>
    </table>
</div>
<div id="pollArea" align="center"></div><br/>
<div id="Layer1" align="center" >
	<table width='750' >
		<tr>
			<td align='left'>
				<input type='button' class='button' style='cursor:pointer;cursor:hand' onclick='reply_topic()' value='ตอบ' />
			</td>
			<td align='right'>
				<input type='button' class='button' style='cursor:pointer;cursor:hand' onclick='warehouse()' value='เก็บลงคลังกระทู้เก่า' />
				<input type='button' class='button' style='cursor:pointer;cursor:hand' onclick='selfbookmark()' value='บันทึกการเข้า' />
			</td>
		</tr>
	</table>
</div>
<div id="Layer2" class="opinion" align="center"></div><br/>
<div id="Layer3" align="center" >
	<table width='750' >
		<tr>
			<td align='left'>
				<input type='button' class='button' style='cursor:pointer;cursor:hand' onclick='reply_topic()' value='ตอบ' />
			</td>
			<td align='right'>
				<span class='next_prev'>
						<span id='page'></span>&nbsp;&nbsp;&nbsp;
						<input type='button' style='cursor:pointer;cursor:hand' onclick='prev()' value='<< หน้าที่แล้ว'/>
						<span id='link_page'></span>
						<input type='button' style='cursor:pointer;cursor:hand' onclick='next()' value='หน้าต่อไป >>'/>
				</span>
			</td>
		</tr>
	</table>
</div>
<div id="navtxt" class="navtext" style="position:absolute; top:-100px; left:0px; visibility:hidden"></div>
<script>
		opinion();
		
</script>
</body>
</html>

