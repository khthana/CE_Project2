<?php
		include("../_Sessionstart.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>

<link rel="stylesheet" type="text/css" href="css/dhtmlXGrid.css">
<link rel="stylesheet" type="text/css" href="css/dhtmlXTabbar.css">
<script type="text/javascript" src="js/dhtmlXTabbar.js"></script> 
<script type="text/javascript" src="js/dhtmlXTabbar_start.js"></script>
<script  type="text/javascript" src="js/dhtmlXCommon.js"></script>
<script  type="text/javascript" src="js/grid.js"></script>    
<script  type="text/javascript" src="js/dhtmlXGridCell.js"></script>
<script  type="text/javascript" src="js/bookmark.js"></script> 
<script  type="text/javascript" src="js/alttxt.js"></script> 

</head>
<body ><br/>
<div align='center' ><img src="../images/logo.gif" width="640" height="120" /></div>
<h1 style='text-align:center;color:#666666;font-family:Arial;font-size:24px;'>ข้อมูลส่วนตัว</h1>
<div id="Layer2">
	<table align="center" border="0" cellpadding="0" cellspacing="0" >
		<tr>
			<td><div id="b_tabbar" width="820"  height="950"> </div></td>
		</tr>
	</table>
</div>

<div id="navtxt" class="navtext" style="position:absolute; top:-100px; left:0px; visibility:hidden"></div>

<script>
			//------------------------------
			tabbar=new dhtmlXTabBar("b_tabbar","top");
			tabbar.setImagePath("imgs/");
			tabbar.setOffset("10");
			tabbar.addTab("b1","บันทึกการเข้าโดยระบบ","150px");
			tabbar.addTab("b2","บันทึกการเข้าโดยตัวเอง","150px");
			tabbar.setTabActive("b1");
			tabbar.setContentHTML("b1","<DIV id='bookmark_1'></DIV><BR/><DIV class='next_prev'><span id='bookmark_page_1'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=bookmark_prev_1() value='<< หน้าที่แล้ว' /><span id='bookmark_link_page_1'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=bookmark_next_1() value='หน้าต่อไป >>'/></DIV>");
			
			tabbar.setContentHTML("b2","<DIV id='bookmark_2'></DIV><BR/><DIV class='next_prev'><span id='bookmark_page_2'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=bookmark_prev_2() value='<< หน้าที่แล้ว' /><span id='bookmark_link_page_2'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=bookmark_next_2() value='หน้าต่อไป >>'/></DIV>");
			
			

			
			//--------------------------------

			mygrid_1 = new dhtmlXGridObject("bookmark_1");
			mygrid_1.setImagePath("imgs/");
			mygrid_1.setInitWidths("65,445,170,110,25");
			mygrid_1.setHeader("ประเภท,หัวข้อกระทู้,โดย,แก้ไขครั้งล่าสุด,img:[imgs/color.png]");
			mygrid_1.setColAlign("center,left,center,center,center");
			mygrid_1.setColSorting("str,str,str,date,");
			mygrid_1.enableAutoHeigth(true);
			mygrid_1.enableLightMouseNavigation(true);
			mygrid_1.init();	
//			bookmark_1();
		
			mygrid_2 = new dhtmlXGridObject("bookmark_2");
			mygrid_2.setImagePath("imgs/");
			mygrid_2.setInitWidths("65,445,170,110,25");
			mygrid_2.setHeader("ประเภท,หัวข้อกระทู้,โดย,แก้ไขครั้งล่าสุด,img:[imgs/color.png]");
			mygrid_2.setColAlign("center,left,center,center,center");
			mygrid_2.setColSorting("str,str,str,date,");
			mygrid_2.enableAutoHeigth(true);
			mygrid_2.enableLightMouseNavigation(true);
			mygrid_2.init();
//			bookmark_2();
		
			
</script>
			 
</body>
</html>

<!--  <td  width="27"><div id="log_1" align="center"><a href="javascript:void window.open('https://161.246.5.92/ce/user_management/showlogin.php','_blank','left=200,top=314,width=480,height=160,resizable=no')";><img align="middle" border="0" src="imgs/login_link.jpg" width="18" height="18" alt="Login" /></a></div></td>-->