<?php
		include("../_Sessionstart.php");
		$_SESSION['ss_Topic_id_1']="0:0";
		
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>

<link rel="stylesheet" type="text/css" href="css/dhtmlXGrid.css">
<link rel="stylesheet" type="text/css" href="css/dhtmlXTabbar.css">
<script type="text/javascript" src="js/dhtmlXTabbar.js"></script> 
<script type="text/javascript" src="js/dhtmlXTabbar_start.js"></script>
<script  type="text/javascript" src="js/dhtmlXCommon.js"></script>
<script  type="text/javascript" src="js/grid.js"></script>    
<script  type="text/javascript" src="js/dhtmlXGridCell.js"></script>
<script  type="text/javascript" src="js/view.js"></script> 
<script  type="text/javascript" src="js/alttxt.js"></script> 

</head>
<body >
<br/>
<div id="Layer1" align="center">
    <table width="800" border="0" cellpadding="0" cellspacing="0">
			<tr>
        		<td align="center" ><img  border="0" src="../images/logo.gif" width="640" height="135"></td>
			</tr>
			<tr ><td   colspan="2" height="15"></td></tr>
    </table>
	<br/>
</div>	

<div id="Layer2">
	<table align="center" border="0" cellpadding="0" cellspacing="0" >
		<tr>
			<td><div id="a_tabbar" width="1000"  height="950"> </div></td>
		</tr>
	</table>
</div>

<div id="navtxt" class="navtext" style="position:absolute; top:-100px; left:0px; visibility:hidden"></div>

<script>
			//------------------------------
			tabbar=new dhtmlXTabBar("a_tabbar","top");
			tabbar.setImagePath("imgs/");
			tabbar.setOffset("10");
			tabbar.addTab("a1","หัวข้อกระทู้","100px");
			tabbar.addTab("a3","ค้นหากระทู้","100px");
			tabbar.addTab("a2","คลังกระทู้เก่า","100px");
			tabbar.setTabActive("a1");
						
			tabbar.setContentHTML("a1","<DIV class='main' ><TABLE width='980'><TR><TD width='40'><input id='network' type='checkbox' checked='checked' onclick='call_1()'><img src='imgs/network.gif' onmouseover=\"writetxt('เน็ตเวิร์ค')\" onmouseout='writetxt(0)'/></TD><TD width='40'><input id='hardware' type='checkbox'   checked='checked' onclick='call_1()'><img src='imgs/hardware.gif' onmouseover=\"writetxt('ฮาดแวร์')\" onmouseout='writetxt(0)'/></TD><TD width='40'><input id='software' type='checkbox'   checked='checked' onclick='call_1()'><img src='imgs/software.gif' onmouseover=\"writetxt('ซอฟแวร์')\" onmouseout='writetxt(0)'/></TD><TD width='40'><input id='security' type='checkbox'   checked='checked' onclick='call_1()'><img src='imgs/security.gif' onmouseover=\"writetxt('ความปลอดภัย')\" onmouseout='writetxt(0)'/></TD><TD width='40'><input id='course' type='checkbox'   checked='checked' onclick='call_1()'><img src='imgs/course.gif' onmouseover=\"writetxt('บทเรียน')\" onmouseout='writetxt(0)'/></TD><TD width='40'><input id='etc' type='checkbox'  checked='checked'  onclick='call_1()'><img src='imgs/etc.gif' onmouseover=\"writetxt('ทั่วไป')\" onmouseout='writetxt(0)'/></TD><TD width='610'></TD><TD width='70'><a href='post_newtoppic.php' target='_blank'><img  src='imgs/button/NewTopic_1.gif' /></a></TD><TD width='20'><a href='../user_management/showProfile.php' target='_blank'><img  src='imgs/editprofile.gif' onmouseover=\"writetxt('ข้อมูลส่วนตัว')\" onmouseout='writetxt(0)'/></a></TD><TD width='20'><img src='imgs/help.gif' onmouseover=\"writetxt('ช่วยเหลือ')\" onmouseout='writetxt(0)'/></TD></TR></TABLE></DIV><DIV id='gridbox1'></DIV><BR/><DIV class='next_prev'><span id='page_1'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=prev() value='<< หน้าที่แล้ว' /><span id='link_page_1'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=next() value='หน้าต่อไป >>'/></DIV>");
			
			tabbar.setContentHTML("a2","<DIV class='search' ><input type='text' id='search_keywords_warehouse' class='t_search'  size='16' style='border-color: #000000;border-width:2;border-style:solid;'/>&nbsp;&nbsp;<input type='button' class='b_search' style='cursor:pointer;cursor:hand' onclick=search_warehouse() value='ค้นหา' />&nbsp;&nbsp;<input type='button' class='b_search' style='cursor:pointer;cursor:hand' onclick=search_warehouse_all('A') value='กระทู้ทั้งหมด' /></DIV><DIV id='gridbox2'></DIV><BR/><DIV class='next_prev'><span id='page_2'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=search_warehouse_prev() value='<< หน้าที่แล้ว' /><span id='link_page_2'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=search_warehouse_next() value='หน้าต่อไป >>'/></DIV>");
			
			tabbar.setContentHTML("a3","<DIV class='search' ><input type='text' id='search_keywords' class='t_search'  size='16' style='border-color: #000000;border-width:2;border-style:solid;'/>&nbsp;&nbsp;<input type='button' class='b_search' style='cursor:pointer;cursor:hand' onclick=search_topic() value='ค้นหา' /></DIV><DIV id='gridbox3'></DIV><BR/><DIV class='next_prev'><span id='page_3'></span>&nbsp;&nbsp;&nbsp;<input type='button' style='cursor:pointer;cursor:hand' onclick=search_prev() value='<< หน้าที่แล้ว' /><span id='link_page_3'></span><input type='button' style='cursor:pointer;cursor:hand' onclick=search_next() value='หน้าต่อไป >>'/></DIV>");

			
			//--------------------------------

			mygrid_1 = new dhtmlXGridObject("gridbox1");
			mygrid_1.setImagePath("imgs/");
			mygrid_1.setInitWidths("25,65,445,170,85,110,50,50");
			mygrid_1.setHeader("img:[imgs/color.png],ประเภท,หัวข้อกระทู้,โดย,วันที่สร้าง,แก้ไขครั้งล่าสุด,อ่าน,ตอบ");
			//mygrid_1.setColTypes("ro,ro,ro,link,ro,ro,ro,ro");
			mygrid_1.setColAlign("right,center,left,center,center,center,center,center");
			mygrid_1.setColSorting(",str,str,str,date,date,int,int");
			mygrid_1.enableAutoHeigth(true);
			mygrid_1.enableLightMouseNavigation(true);
			mygrid_1.init();	
			view();
		
			mygrid_2 = new dhtmlXGridObject("gridbox2");
			mygrid_2.setImagePath("imgs/");
			mygrid_2.setInitWidths("25,65,445,170,85,110,50,50");
			mygrid_2.setHeader("img:[imgs/color.png],ประเภท,หัวข้อกระทู้,โดย,วันที่สร้าง,แก้ไขครั้งล่าสุด,อ่าน,ตอบ");
			mygrid_2.setColAlign("right,center,left,center,center,center,center,center");
			mygrid_2.setColSorting(",str,str,str,date,date,int,int");
			mygrid_2.enableAutoHeigth(true);
			mygrid_2.enableLightMouseNavigation(true);
			mygrid_2.init();
			pageNum_2();
		
			mygrid_3 = new dhtmlXGridObject("gridbox3");
			mygrid_3.setImagePath("imgs/");
			mygrid_3.setInitWidths("25,65,445,170,85,110,50,50");
			mygrid_3.setHeader("img:[imgs/color.png],ประเภท,หัวข้อกระทู้,โดย,วันที่สร้าง,แก้ไขครั้งล่าสุด,อ่าน,ตอบ");
			mygrid_3.setColAlign("right,center,left,center,center,center,center,center");
			mygrid_3.setColSorting(",str,str,str,date,date,int,int");
			mygrid_3.enableAutoHeigth(true);
			mygrid_3.enableLightMouseNavigation(true);
			mygrid_3.init();
			pageNum_3();
</script>
			 
</body>
</html>
