<?php
	include("./rsslink.inc.php");
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style>
	body{
			font-size:13px;
			font-family:'MS Sans Serif','Trebuchet MS','Tahoma';
			background-color:#E4FFCA;
	}
	a:link,a:visited{
		text-decoration:none;
	}
	a:hover{
		color:#8BBEFC;
	}
	hr{
		border:1px groove  ;
		color:#000000;
	}
	</style>
	<script langusge='JavaScript'>
	<!--
		function changenew(){
			
		}
	//-->
	</script>
</head>
<body>
<MARQUEE onmouseover="this.stop()" onmouseout="this.start()" scrollAmount="1" scrollDelay="0" direction="up" height="300px">
<?
require_once("RSSParser.class.php");

function getRSS($file){
	global $rss,$RSSpersite;
	$counttopic=0;
	$thaimount= array("ม.ค.","ก.พ.","มี.ค.","เม.ษ.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
	$rss = new rss_parser();
	$rss->file =$file ;
	$rss->parse() or die($rss->error);
	if ($rss->error) print $rss->error;
	else{
		foreach($rss->channel as $site_attribute => $site_data)
			if(is_array($site_data)){
				foreach($site_data as $item_attribute => $item){
					if($site_attribute=="ITEM"){
						if($counttopic<$RSSpersite){
							$return.="<a href='$item[LINK]' target='_blank'>$item[TITLE] <br>";
							$return.=date("j ",strtotime($item['PUBDATE']));
							//$return.=date("n",strtotime($item['PUBDATE']));
							$return.=$thaimount[date("n",strtotime($item['PUBDATE']))-1];
							$return.=(date("y",strtotime($item['PUBDATE']))+43)."</a><hr>";
							$counttopic++;
						}
					}
				}
			}
			else{
				if($site_attribute=="TITLE")
					$return="<center><b><u>$site_data</u></b><hr></center>";
				}
		echo $return;
	}
}
	foreach($RSSsite as $thisRSS)
		getRSS($thisRSS);
?>
</MARQUEE>
</body>
</html>