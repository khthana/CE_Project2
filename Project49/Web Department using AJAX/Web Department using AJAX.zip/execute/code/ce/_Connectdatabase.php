﻿<?php
	function connectdb(){
	$link=mysql_pconnect("localhost","root","");
	//$link=mysql_pconnect("localhost","root","vkc0H8cvxr]bg8=yjo");
	//mysql_select_db("ce_information_system",$link);
	mysql_select_db("ce",$link);
	mysql_query("SET NAMES utf8"); 
	}
?>