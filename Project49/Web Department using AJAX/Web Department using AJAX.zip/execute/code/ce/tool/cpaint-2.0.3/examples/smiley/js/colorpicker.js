/**
* CPAINT (Cross-Platform Asynchronous INterface Toolkit) - Version 2
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
*
* @package    CPAINT
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005-2006 Paul Sullivan, Dominique Stender - http://sf.net/projects/cpaint
*/
  var selectedColor = 0;
  var colors            = new Array();
  
  function selectColor(id) {
    var tmpDisplay    = false;

    if (document.getElementById('color' + id)) {
      selectedColor = id;

      for (var i = 0; i < 10; i++) {
        tmpDisplay = document.getElementById('color' + i);

        if (tmpDisplay && i == selectedColor) {
          tmpDisplay.style.borderStyle = 'dashed';
        
        } else if (tmpDisplay && i != selectedColor) {
          tmpDisplay.style.borderStyle = 'solid';
        }
      }
    }
  }
  
  function getColor(e) {
    var offsetX = mouseX;
    var offsetY = mouseY;
    
    // calculate offset
    if (document.all) {
      offsetX = window.event.offsetX;
      offsetY = window.event.offsetY;
    
    } else {
      offsetX -= document.getElementById('palette').offsetLeft;
      offsetY -= document.getElementById('palette').offsetTop;
    }

    cp.call('cpaint/colorpicker.php', 'pickColor', displayColor, offsetX, offsetY, displayColor);
  }
  
  function displayColor(result) {
    if (result != null) {
      var colorInfo    = result.ajaxResponse[0].color[0];
  
      colors[selectedColor]                                                   = colorInfo.hex[0].data;
      document.getElementById('color' + selectedColor).style.backgroundColor  = colorInfo.hex[0].data;
      get_bbcode(false);
    }
  }
