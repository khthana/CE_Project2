<?php
/**
* generates a gzipped / BASE64 encoded string from parameters
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/

//---- includes ----------------------------------------------------------------
  /**
  * @include cpaint library
  */
  require_once('../../../cpaint2.inc.php');
  
//---- functions ---------------------------------------------------------------
  /**
  * generates a gzipped / BASE64 encoded string from parameters
  *
  * @access public
  * @param  boolean   $create_permanently         whether or not to create the smiley permanently
  * @param  string    $s_smiley                   name of the smiley icon to use
  * @param  string    $s_message                  message to put on the sign
  * @param  string    $s_background_color         hex code for the background color
  * @param  boolean   $background_transparent     whether or not the image background is transparent
  * @param  string    $s_sign_border_color        hex code for the border color of the sign
  * @param  string    $s_sign_background_color    hex code for the background color of the sign
  * @param  string    $s_font_color               hex code for the font color on the sign
  * @param  string    $s_font_name                name of the fontfile to use
  * @param  integer   $n_font_size                font size in pixel
  * @return void
  */
  function compress_param($create_permanently, $s_smiley, $s_message, $s_background_color, $background_transparent, $s_sign_border_color, $s_sign_background_color, $s_font_color, $s_font_name, $n_font_size) {
    global $o_cp;

    // generate code
    $s_code = base64_encode(gzcompress('create_perm=' . urlencode((integer) $create_permanently)
                                        . '&smiley=' . urlencode($s_smiley)
                                        . '&msg=' . urlencode(stripslashes($s_message))
                                        . '&bgcol=' . urlencode(sprintf('%06s', $s_background_color))
                                        . '&bgtransp=' . urlencode((integer) $background_transparent)
                                        . '&bordercol=' . urlencode(sprintf('%06s', $s_sign_border_color))
                                        . '&signbgcol=' . urlencode(sprintf('%06s', $s_sign_background_color))
                                        . '&fontcol=' . urlencode(sprintf('%06s', $s_font_color))
                                        . '&fontfile=' . urlencode(sprintf('%s', $s_font_name))
                                        . '&fontsize=' . urlencode((integer) $n_font_size)
                                      ));
    
    // generate cpaint response
    $o_base64 =& $o_cp->add_node('base64');
    $o_base64->set_data($s_code);
    
    $o_sha1 =& $o_cp->add_node('hash');

    if ($create_permanently == '1') {
      $o_sha1->set_data(sha1(urldecode($s_code)));
    }
  }
  
//---- variables ---------------------------------------------------------------
  $o_cp = new cpaint();

//---- logic -------------------------------------------------------------------
  $o_cp->register('compress_param');
  $o_cp->start();
  
//---- clean up ----------------------------------------------------------------
//---- content -----------------------------------------------------------------
  $o_cp->return_data();

?>