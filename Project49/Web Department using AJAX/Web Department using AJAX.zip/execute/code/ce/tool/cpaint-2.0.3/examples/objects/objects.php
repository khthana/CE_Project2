<?php
/**
* server part of the CPAINT objects test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

  class cpainttest {
    
    function dynamic() {
      global $cp;
      
      $cp->set_data('dynamically called method says hello');
    }  
    
    function statc() {
      global $cp;
      
      $cp->set_data('statically called class function says hello');
    }
  }
  
	function func() {
		global $cp;

    $cp->set_data('standalone function says hello');
	}

	$obj = new cpainttest();
  
  $cp = new cpaint();
  $cp->register('func');
  $cp->register(array('cpainttest', 'statc'));
  $cp->register(array(&$obj, 'dynamic'));
	$cp->start();
	$cp->return_data();
?>
