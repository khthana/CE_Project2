<?php
/**
* server part of the CPAINT ping test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

	function ping($data) {
		global $cp;
	
		// create result node - both arguments can be assigned as seen fit
		// ATTENTION: local variable must by assigned as reference 
		//	that means assigning via =& in PHP4!
		$result_node	=& $cp->add_node('ajaxResult', 'pong');

		// fill node with data
    if (get_magic_quotes_gpc() == true) {
      $data = stripslashes($data);
    } // end: if
    
		$result_node->set_data('You said: ' . $data);
	
		// we're done here
	}

	$cp = new cpaint();
  $cp->register('ping');
	$cp->start();
	$cp->return_data();
?>
