<?php
/**
* a custom-sign bearing smiley
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/

//---- includes ----------------------------------------------------------------
//---- functions ---------------------------------------------------------------
  /**
  * parses a GET color value and returns either the red, green or blue value
  *
  * @access public
  * @param  string      $s_color      GET color
  * @param  string      $s_aspect     whether to return the red, green or blue aspect (r|g|b)
  * @return integer
  */
  function get_color($s_color, $s_aspect) {
    $retval   = 0;
    $s_color  = (string) $s_color;
    $s_aspect = strtolower((string) $s_aspect);
    
    if (preg_match('/^#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})$/', $s_color, $a_matches)) {
      
      switch ($s_aspect) {
        case 'r': 
          $retval = hexdec($a_matches[1]);
          break;

        case 'g': 
          $retval = hexdec($a_matches[2]);
          break;

        case 'b': 
          $retval = hexdec($a_matches[3]);
          break;

        default:
      } // end: switch
    } // end: if
  
    return $retval;
  }
  
  /**
  * calculates the TTF bounding box for rotated texts
  * 
  * @access   private
  * @param    integer   $n_size   font size
  * @param    integer   $n_angle  font angle
  * @param    string    $s_font   font file
  * @param    string    $s_text   text to calculate bbox for
  */
  function imagettfbbox_fix($n_size, $n_angle, $s_font, $s_text) {
    // compute size with a zero angle
    $coords = imageTTFBBox($n_size, 0, $s_font, $s_text);
  
    // convert angle to radians
    $a = $n_angle * M_PI / 180;
  
    // compute some usefull values
    $ca = cos($a);
    $sa = sin($a);
    $ret = array();
  
    // perform transformations
    for ($i = 0; $i < 7; $i += 2) {
     $ret[$i]   = round($coords[$i] * $ca + $coords[$i+1] * $sa);
     $ret[$i+1] = round($coords[$i+1] * $ca - $coords[$i] * $sa);
    }

    return $ret;
  }

  /**
  * draws the stake of the sign
  *
  * @access public
  * @return void
  */
  function draw_stake() {
    global $canvas, $wood_color, $light_wood, $n_angle;
    global $a_text_dims, $n_sign_padding;
    global $n_message_x, $n_message_y, $n_message_height, $a_smiley_dims;
    
    // set angle of the stake
    $n_stake_angle = -1 * $n_angle + 90;

    // find length of tiangle sides 
    $n_sign_len_x = $a_text_dims[2] - $a_text_dims[0];
    $n_sign_len_y = $a_text_dims[3] - $a_text_dims[1];
    
    // find canvas height
    $n_canvas_height = $n_message_height + $a_smiley_dims[1] + 30;
    
    // find point to start from
    for ($i = -2; $i < 3; $i++) {
      $n_len_x      = ($n_sign_len_x / 2) * cos(deg2rad($n_angle));
      $n_len_y      = ($n_sign_len_y / 2) * cos(deg2rad($n_angle));
      $n_start_x    = ceil($a_text_dims[0] + $i + $n_len_x + $n_message_x - $n_sign_padding);
      $n_start_y    = ceil($a_text_dims[1] + $n_len_y + $n_message_y + $n_sign_padding);
      
      // find end point
      $n_len_x      = $n_canvas_height * cos(deg2rad($n_stake_angle));
      $n_len_y      = $n_canvas_height * sin(deg2rad($n_stake_angle));
      $n_end_x      = $n_start_x + $n_len_x;
      $n_end_y      = $n_start_y + $n_len_y;
      
      // draw stake
      if (abs($i) < 2) {
        $color = $light_wood;
      
      } else {
        $color = $wood_color;
      }
      
      ImageLine($canvas,  $n_start_x, $n_start_y, $n_end_x, $n_end_y, $color);
    } // end: for
  }
  

//---- variables ---------------------------------------------------------------
  $s_smiley_id    = 'cache/' . sha1($_GET['bbcode']) . '.gif';
  parse_str(gzuncompress(base64_decode($_GET['bbcode'])), $_GET);
  
  $n_ttl          = 3600;
  
  $s_message      = stripslashes(urldecode($_GET['msg']));
  $s_font         = '../fonts/' . $_GET['fontfile'] . '.ttf';
  $s_smiley       = '../gfx/' . urldecode($_GET['smiley']) . '.gif';
  $n_fontsize     = $_GET['fontsize'];
  $n_angle        = round(mt_rand(-10, 10));
  
  $n_sign_padding = 4;
  
  $a_text_dims      = imageTTFBBox_fix($n_fontsize, $n_angle, $s_font, $s_message);
  $n_message_left   = min($a_text_dims[0], $a_text_dims[6]);
  $n_message_right  = max($a_text_dims[2], $a_text_dims[4]);
  $n_message_top    = min($a_text_dims[5], $a_text_dims[7]);
  $n_message_bottom = max($a_text_dims[1], $a_text_dims[3]);

  $n_message_width  = $n_message_right - $n_message_left;
  $n_message_height = $n_message_bottom - $n_message_top;

  $n_message_x    = abs($n_message_left) + $n_sign_padding;
  $n_message_y    = abs($n_message_top) + $n_sign_padding;
  $smiley         = ImageCreateFromGif($s_smiley);
  $a_smiley_dims  = GetImageSize($s_smiley);
  
  $canvas         = ImageCreate($n_message_width + 20, $n_message_height + $a_smiley_dims[1] + 30);

  $background     = ImageColorAllocate($canvas, get_color($_GET['bgcol'], 'r'), get_color($_GET['bgcol'], 'g'), get_color($_GET['bgcol'], 'b'));
  $color          = ImageColorAllocate($canvas, get_color($_GET['fontcol'], 'r'), get_color($_GET['fontcol'], 'g'), get_color($_GET['fontcol'], 'b'));
  $sign_border    = ImageColorAllocate($canvas, get_color($_GET['bordercol'], 'r'), get_color($_GET['bordercol'], 'g'), get_color($_GET['bordercol'], 'b'));
  $sign_bg        = ImageColorAllocate($canvas, get_color($_GET['signbgcol'], 'r'), get_color($_GET['signbgcol'], 'g'), get_color($_GET['signbgcol'], 'b'));
  $wood_color     = ImageColorAllocate($canvas, 0x9d, 0x85, 0x57);
  $light_wood     = ImageColorAllocate($canvas, 0xbd, 0xa5, 0x77);
  
//---- logic -------------------------------------------------------------------
  
  if (!is_file($s_smiley_id)) {
    // no cache
    ImageFill($canvas, 0, 0, $background);
    
    if ($_GET['bgtransp'] == '1') {
      ImageColorTransparent($canvas, $background);
    }
    
    // draw stick
    draw_stake();
    
    // sign border
    ImageLine($canvas,  $a_text_dims[0] + $n_message_x - $n_sign_padding, 
                        $a_text_dims[1] + $n_message_y + $n_sign_padding, 
                        $a_text_dims[2] + $n_message_x + $n_sign_padding, 
                        $a_text_dims[3] + $n_message_y + $n_sign_padding, 
                        $sign_border);
    ImageLine($canvas,  $a_text_dims[2] + $n_message_x + $n_sign_padding, 
                        $a_text_dims[3] + $n_message_y + $n_sign_padding, 
                        $a_text_dims[4] + $n_message_x + $n_sign_padding, 
                        $a_text_dims[5] + $n_message_y - $n_sign_padding, 
                        $sign_border);
    ImageLine($canvas,  $a_text_dims[4] + $n_message_x + $n_sign_padding, 
                        $a_text_dims[5] + $n_message_y - $n_sign_padding, 
                        $a_text_dims[6] + $n_message_x - $n_sign_padding, 
                        $a_text_dims[7] + $n_message_y - $n_sign_padding, 
                        $sign_border);
    ImageLine($canvas,  $a_text_dims[6] + $n_message_x - $n_sign_padding, 
                        $a_text_dims[7] + $n_message_y - $n_sign_padding, 
                        $a_text_dims[0] + $n_message_x - $n_sign_padding, 
                        $a_text_dims[1] + $n_message_y + $n_sign_padding, 
                        $sign_border);
  
    //sign background
    ImageFill($canvas,  $a_text_dims[6] + $n_message_x + $n_sign_padding, 
                        $a_text_dims[7] + $n_message_y + $n_sign_padding, 
                        $sign_bg);
    
    // write message
    ImageTTFText($canvas, $n_fontsize, $n_angle, $n_message_x, $n_message_y, $color, $s_font, $s_message);
    
    // place smiley
    imageCopyMerge( $canvas, 
                    $smiley, 
                    (($n_message_right - $n_message_left) / 2) + ($a_smiley_dims[0] / 2), 
                    $n_message_height + 30,
                    0, 0, 
                    $a_smiley_dims[0], $a_smiley_dims[1], 
                    100);

    // save image
    if ($_GET['create_perm'] == '1') {
      ImageGIF($canvas, $s_smiley_id);
    
    } else {
      ImageGIF($canvas);
    } // end: if
  } // end: if

//---- content -----------------------------------------------------------------
  header('Content-type: image/gif');
  
  if ($_GET['create_perm'] == '1' && is_file($s_smiley_id)) {
    echo file_get_contents($s_smiley_id);
  } // end: if
  
//---- clean up ----------------------------------------------------------------
?>