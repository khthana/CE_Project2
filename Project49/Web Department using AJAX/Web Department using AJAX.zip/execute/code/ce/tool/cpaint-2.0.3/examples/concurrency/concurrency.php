<?php
/**
* server part of the CPAINT concurrency test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

	function get_time() {
		global $cp;
	
		// create result node - both arguments can be assigned as seen fit
		// ATTENTION: local variable must by assigned as reference 
		//	that means assigning via =& in PHP4!
		$result_node	=& $cp->add_node('time');

		// fill node with data
		$result_node->set_data(date('r'));
	
		// delay everything a little bit
    sleep(round(mt_rand(1, 8)));
	}

	$cp = new cpaint();
  $cp->register('get_time');
	$cp->start();
	$cp->return_data();
?>
