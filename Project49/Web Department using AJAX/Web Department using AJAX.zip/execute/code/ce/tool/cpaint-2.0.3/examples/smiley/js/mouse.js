/**
* CPAINT (Cross-Platform Asynchronous INterface Toolkit) - Version 2
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
*
* @package    CPAINT
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005-2006 Paul Sullivan, Dominique Stender - http://sf.net/projects/cpaint
*/
  var mouseX       = 0;
  var mouseY       = 0;
  
  function getMouseXY(e) {
    mouseX = (document.all) ? window.event.x + document.body.scrollLeft : e.pageX;
    mouseY = (document.all) ? window.event.y + document.body.scrollTop  : e.pageY;
  }
