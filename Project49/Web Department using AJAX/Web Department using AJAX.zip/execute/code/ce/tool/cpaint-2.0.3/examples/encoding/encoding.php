<?php
/**
* server part of the CPAINT encoding test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/

//---- includes ----------------------------------------------------------------
  /**
  * @include CPAINT backend
  */
  require_once('../../cpaint2.inc.php');
  
//---- functions ---------------------------------------------------------------  
  /**
  * wrapper for the various character sets
  *
  * @access public
  * @return void
  */
  function encode($type) {
    global $cp;
    
    switch ($type) {
      case 'ascii':
        ascii();
        break;
  
      case 'nonprintable':
        nonprintable();
        break;
  
      case 'problematic':
        problematic();
        break;
  
      case 'german':
        german();
        break;
  
      case 'swedish':
        swedish();
        break;
  
      case 'arabic':
        arabic();
        break;
  
      case 'russian':
        russian();
        break;
  
      case 'greek':
        greek();
        break;
  
      case 'hebrew':
        hebrew();
        break;
  
      case 'japanese':
        japanese();
        break;

      case 'chinese':
        chinese();
        break;
    }
  }
  
  function ascii() {
    global $cp;
  
    $alnum =& $cp->add_node('charset', 'alphanumeric');
    $alnum->set_data(chr(0x61) . chr(0x20)
                   . chr(0x62) . chr(0x20)
                   . chr(0x63) . chr(0x20)
                   . chr(0x64) . chr(0x20)
                   . chr(0x65) . chr(0x20)
                   . chr(0x66) . chr(0x20)
                   . chr(0x67) . chr(0x20)
                   . chr(0x68) . chr(0x20)
                   . chr(0x69) . chr(0x20)
                   . chr(0x6A) . chr(0x20)
                   . chr(0x41) . chr(0x20)
                   . chr(0x42) . chr(0x20)
                   . chr(0x43) . chr(0x20)
                   . chr(0x44) . chr(0x20)
                   . chr(0x45) . chr(0x20)
                   . chr(0x46) . chr(0x20)
                   . chr(0x47) . chr(0x20)
                   . chr(0x48) . chr(0x20)
                   . chr(0x49) . chr(0x20)
                   . chr(0x4A) . chr(0x20)
                   . chr(0x30) . chr(0x20)
                   . chr(0x31) . chr(0x20)
                   . chr(0x32) . chr(0x20)
                   . chr(0x33) . chr(0x20)
                   . chr(0x34) . chr(0x20)
                   . chr(0x35) . chr(0x20)
                   . chr(0x36) . chr(0x20)
                   . chr(0x37) . chr(0x20)
                   . chr(0x38) . chr(0x20)
                   . chr(0x39) . chr(0x20)
    );
  }
  
  function nonprintable() {
    global $cp;

    $nonprintable =& $cp->add_node('charset', 'non-printable');
    $nonprintable->set_data(chr(0x00) . chr(0x0a) . chr(0x0d) . chr(0x1b) . chr(0x20));
  }
  
  function problematic() {
    global $cp;

    $commons =& $cp->add_node('charset', 'commons');
    $commons->set_data('"!$%/()\=.,;:#+*<&>�\''); 
  }
  
  function german() {
    global $cp;
  
    $german =& $cp->add_node('charset', 'german');
    $german->set_data(chr(0xE4) . chr(0x20)
                    . chr(0xF6) . chr(0x20)
                    . chr(0xFC) . chr(0x20)
                    . chr(0xC4) . chr(0x20)
                    . chr(0xD6) . chr(0x20)
                    . chr(0xDC) . chr(0x20)
                    . chr(0xDF) . chr(0x20)
                    . chr(0x80)
    );
  }
  
  function swedish() {
    global $cp;

    $swedish =& $cp->add_node('charset', 'swedish');
    $swedish->set_data(chr(0xE5) . chr(0x20)
                     . chr(0xE6) . chr(0x20)
                     . chr(0xF8) . chr(0x20)
                     . chr(0xC5) . chr(0x20)
                     . chr(0xC6) . chr(0x20)
                     . chr(0xD8)
    );
  }
  
  function arabic() {
    global $cp;

    $arabic =& $cp->add_node('charset', 'arabic');
    $arabic->set_data(chr(0xC1) . chr(0x20)
                    . chr(0xC2) . chr(0x20)
                    . chr(0xC3) . chr(0x20)
                    . chr(0xC4) . chr(0x20)
                    . chr(0xC5) . chr(0x20)
                    . chr(0xC6) . chr(0x20)
                    . chr(0xC7) . chr(0x20)
                    . chr(0xC8) . chr(0x20)
                    . chr(0xC9) . chr(0x20)
                    . chr(0xCA) . chr(0x20)
                    . chr(0xCB) . chr(0x20)
                    . chr(0xCC) . chr(0x20)
                    . chr(0xCD) . chr(0x20)
                    . chr(0xCE) . chr(0x20)
                    . chr(0xCF)
    );
  }
  
  function russian() {
    global $cp;

    $russian =& $cp->add_node('charset', 'russian');
    $russian->set_data(chr(0xD0) . chr(0x20)
                     . chr(0xD1) . chr(0x20)
                     . chr(0xD2) . chr(0x20)
                     . chr(0xD3) . chr(0x20)
                     . chr(0xD4) . chr(0x20)
                     . chr(0xD5) . chr(0x20)
                     . chr(0xD6) . chr(0x20)
                     . chr(0xD7) . chr(0x20)
                     . chr(0xD8) . chr(0x20)
                     . chr(0xD9) . chr(0x20)
                     . chr(0xDA) . chr(0x20)
                     . chr(0xDB) . chr(0x20)
                     . chr(0xDC) . chr(0x20)
                     . chr(0xDD) . chr(0x20)
                     . chr(0xDE) . chr(0x20)
                     . chr(0xDF)
    );
  }
  
  function greek() {
    global $cp;

    $greek =& $cp->add_node('charset', 'greek');
    $greek->set_data(chr(0xE1) . chr(0x20)
                   . chr(0xE2) . chr(0x20)
                   . chr(0xE3) . chr(0x20)
                   . chr(0xE4) . chr(0x20)
                   . chr(0xE5) . chr(0x20)
                   . chr(0xE6) . chr(0x20)
                   . chr(0xE7) . chr(0x20)
                   . chr(0xE8) . chr(0x20)
                   . chr(0xE9) . chr(0x20)
                   . chr(0xEA) . chr(0x20)
                   . chr(0xEB) . chr(0x20)
                   . chr(0xEC) . chr(0x20)
                   . chr(0xED) . chr(0x20)
                   . chr(0xEE) . chr(0x20)
                   . chr(0xEF)
    );
  }
  
  function hebrew() {
    global $cp;

    $hebrew =& $cp->add_node('charset', 'hebrew');
    $hebrew->set_data(chr(0xE0) . chr(0x20)
                    . chr(0xE1) . chr(0x20)
                    . chr(0xE2) . chr(0x20)
                    . chr(0xE3) . chr(0x20)
                    . chr(0xE4) . chr(0x20)
                    . chr(0xE5) . chr(0x20)
                    . chr(0xE6) . chr(0x20)
                    . chr(0xE7) . chr(0x20)
                    . chr(0xE8) . chr(0x20)
                    . chr(0xE9) . chr(0x20)
                    . chr(0xEA) . chr(0x20)
                    . chr(0xEB) . chr(0x20)
                    . chr(0xEC) . chr(0x20)
                    . chr(0xED) . chr(0x20)
                    . chr(0xEE) . chr(0x20)
                    . chr(0xEF)
    );
  }
  
  function japanese() {
    global $cp;

    $japanese =& $cp->add_node('charset', 'japanese');
    $japanese->set_data(chr(0xA5) . chr(0xA1) . chr(0x20)
                      . chr(0xA5) . chr(0xA2) . chr(0x20)
                      . chr(0xA5) . chr(0xA3) . chr(0x20)
                      . chr(0xA5) . chr(0xA4) . chr(0x20)
                      . chr(0xA5) . chr(0xA5) . chr(0x20)
                      . chr(0xA5) . chr(0xA6) . chr(0x20)
                      . chr(0xA5) . chr(0xA7) . chr(0x20)
                      . chr(0xA5) . chr(0xA8) . chr(0x20)
                      . chr(0xA5) . chr(0xA9) . chr(0x20)
                      . chr(0xA5) . chr(0xAA) . chr(0x20)
                      . chr(0xA5) . chr(0xAB) . chr(0x20)
                      . chr(0xA5) . chr(0xAC) . chr(0x20)
                      . chr(0xA5) . chr(0xAD) . chr(0x20)
                      . chr(0xA5) . chr(0xAE) . chr(0x20)
                      . chr(0xA5) . chr(0xAF)
    );
  }  
  
  function chinese() {
    global $cp;
  
    $chinese =& $cp->add_node('charset', 'chinese');
    $chinese->set_data(chr(0xA4) . chr(0x40) . chr(0x20)
                     . chr(0xA4) . chr(0x41) . chr(0x20)
                     . chr(0xA4) . chr(0x42) . chr(0x20)
                     . chr(0xA4) . chr(0x43) . chr(0x20)
                     . chr(0xA4) . chr(0x44) . chr(0x20)
                     . chr(0xA4) . chr(0x45) . chr(0x20)
                     . chr(0xA4) . chr(0x46) . chr(0x20)
                     . chr(0xA4) . chr(0x47) . chr(0x20)
                     . chr(0xA4) . chr(0x48) . chr(0x20)
                     . chr(0xA4) . chr(0x49) . chr(0x20)
                     . chr(0xA4) . chr(0x40) . chr(0x20)
                     . chr(0xA4) . chr(0x4A) . chr(0x20)
                     . chr(0xA4) . chr(0x4B) . chr(0x20)
                     . chr(0xA4) . chr(0x4C) . chr(0x20)
                     . chr(0xA4) . chr(0x4D) . chr(0x20)
                     . chr(0xA4) . chr(0x4E) . chr(0x20)
                     . chr(0xA4) . chr(0x4F)
    );
  }
//---- variables ---------------------------------------------------------------
  $encoding   = $_GET['cpaint_argument'][0];
  $encodings  = array(
    'ascii'        => 'ISO-8859-1',
    'nonprintable' => 'ISO-8859-1',
    'problematic'  => 'ISO-8859-1',
    'german'       => 'CP1252',
    'swedish'      => 'CP1252',
    'arabic'       => 'ISO-8859-6',
    'russian'      => 'ISO-8859-5',
    'greek'        => 'ISO-8859-7',
    'hebrew'       => 'ISO-8859-8',
    'japanese'     => 'EUC-JP',
    'chinese'      => 'Big5',
  );

  $cp = new cpaint();
//---- logic -------------------------------------------------------------------
  
  if (get_magic_quotes_gpc()) {
    $encoding = stripslashes($encoding);
  } // end: if

  $encoding = str_replace('"', '', $encoding);
  
  $cp->set_name('encoding');
  $cp->register('encode');
  $cp->start($encodings[$encoding]);
  
//---- clean up ----------------------------------------------------------------
//---- content -----------------------------------------------------------------
  $cp->return_data();
?>