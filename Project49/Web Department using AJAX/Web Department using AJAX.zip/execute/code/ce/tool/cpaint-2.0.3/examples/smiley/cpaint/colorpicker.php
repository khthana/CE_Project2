<?php
/**
* server part of the CPAINT colorpicker 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/

//---- includes ----------------------------------------------------------------
	/**	
	* @include cpaint ajax library
	*/
	require_once('../../../cpaint2.inc.php');

//---- functions ---------------------------------------------------------------
	
	/**
	* looks up the color definition of a given pixel within an image
	* and converts the index information to RGB values.
	* 
	* After that it returns the information as cpaint AJAX XML stream
	* 
	* @param	integer			$x		x position within the image
	* @param	integer			$y		y position within the image
	* @access	public
	* @return	string
	*/
	function pickColor($x, $y) {
		global $cp;
	
		// load palette image, initialize everything
		$image	= ImageCreateFromPNG('../gfx/palette.png');
		$red	= 0;
		$green	= 0;
		$blue	= 0;
		$x	= (integer) $x;
		$y	= (integer) $y;
		$valid	= false;
		
		if ($image) {
			$valid	= true;
			// determine RGB values of given coordinates in pixel
			$color	= ImageColorAt($image, $x, $y);
			$red	= ($color >> 16) & 0xFF;
			$green	= ($color >> 8) & 0xFF;
			$blue	= $color & 0xFF;
		} /* end: if */
		
		// create result node for color information
		$color_node	=& $cp->add_node('color');
		// create submodes that actually hold the color information(s)
		$hex_node	=& $color_node->add_node('hex');
		$red_node	=& $color_node->add_node('red');
		$green_node	=& $color_node->add_node('green');
		$blue_node	=& $color_node->add_node('blue');

		// create a new result node containing success information and the initial coordinates
		$response_node	=& $cp->add_node('response', 'valid');
		// ...subnodes
		$validity_node	=& $response_node->add_node('isValid');
		$x_node		=& $response_node->add_node('offset', 'X');
		$y_node		=& $response_node->add_node('offset', 'Y');

		// now assign values
		$hex_node->set_data(sprintf('#%02x%02x%02x', $red, $green, $blue));
		$red_node->set_data($red);
		$green_node->set_data($green);
		$blue_node->set_data($blue);
		$validity_node->set_data($valid);
		$x_node->set_data($x);
		$y_node->set_data($y);
	}
	
//---- variables ---------------------------------------------------------------
	$cp = new cpaint();

//---- logic -------------------------------------------------------------------
  $cp->register('pickColor');
	$cp->start();
	$cp->return_data();

?>
