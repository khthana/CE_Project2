<?php
/**
* server part of the CPAINT response type test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');
  
  /**
  * generates an array with 10 entries
  *
  * @access public
  * @return void
  */
  function multitype() {
    global $cp;
    
    $list =& $cp->add_node('list');
    
    for ($i = 0; $i < 10; $i++) {
      $item =& $list->add_node('item');
      $item->set_data($i);
    } // end: for
  }
  
  $cp = new cpaint();
  $cp->register('multitype');
	$cp->start();
	$cp->return_data();
?>
