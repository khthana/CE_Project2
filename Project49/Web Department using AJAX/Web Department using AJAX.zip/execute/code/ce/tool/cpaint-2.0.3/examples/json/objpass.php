<?php
/**
* server part of the CPAINT JSON test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

	function print_var($data) {
		global $cp;
//echo ': <pre>' . var_export($data, true) . "</pre><br />\n";
	
		$cp->set_data(var_export($data, true));
	
		// we're done here
	}

	$cp = new cpaint();
  $cp->register('print_var');
	$cp->start();
	$cp->return_data();
?>
