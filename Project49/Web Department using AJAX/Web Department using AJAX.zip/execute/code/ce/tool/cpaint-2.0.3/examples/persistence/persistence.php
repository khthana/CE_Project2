<?php
/**
* server part of the CPAINT persistance test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

	function reply($num) {
		global $cp;
	
		$cp->set_data($num);
	}

	$cp = new cpaint();
  $cp->register('reply');
	$cp->start();
	$cp->return_data();
?>
