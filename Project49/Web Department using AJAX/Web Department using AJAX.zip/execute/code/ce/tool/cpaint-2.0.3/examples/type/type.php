<?php
/**
* server part of the CPAINT type test 
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  2005 (Dominique Stender); All rights reserved
*/
	require_once('../../cpaint2.inc.php');

	function ping($data) {
		global $cp;
	
		$cp->set_data($data);
	}

	$cp = new cpaint();
	$cp->set_name('type');
	$cp->register('ping');
	$cp->start();
	$cp->return_data();
?>
