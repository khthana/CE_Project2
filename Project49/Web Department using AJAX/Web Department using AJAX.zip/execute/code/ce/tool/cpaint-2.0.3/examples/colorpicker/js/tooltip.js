/**
* CPAINT (Cross-Platform Asynchronous INterface Toolkit) - Version 2
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
*
* @package    CPAINT
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005-2006 Paul Sullivan, Dominique Stender - http://sf.net/projects/cpaint
*/
	var mouseX 			= 0;
	var mouseY 			= 0;
	var tooltip 		= null;
	
	function getMouseXY(e) {
		mouseX = (document.all) ? window.event.x + document.body.scrollLeft : e.pageX;
		mouseY = (document.all) ? window.event.y + document.body.scrollTop  : e.pageY;
	}
	
	function updateTooltip(x, y) {
		if (tooltip != null) {
			tooltip.style.left	= (x + 20);
			tooltip.style.top 	= (y + 20);
		}
	}

	function showTooltip(id) {
		tooltip = document.getElementById(id);

		if (tooltip.innerHTML != '') {
			tooltip.style.display 		= 'block';
			tooltip.style.visibility	= 'visible';
		}
	}
	
	function hideTooltip() {
		tooltip.style.display 		= 'none';
		tooltip.style.visibility	= 'hidden';
	}
