/**
* CPAINT (Cross-Platform Asynchronous INterface Toolkit) - Version 2
*
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
*
* @package    CPAINT
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005-2006 Paul Sullivan, Dominique Stender - http://sf.net/projects/cpaint
*/
  var s_smiley_name   = 'biggrin';
  var cp              = new cpaint();
  var create_perm     = '0';
  cp.set_transfer_mode('post');
  
  function get_bbcode(create_permanently) {
    var checked = '0';
    
    if (bg_transp.checked) {
      checked = '1';
    }

    if (create_permanently == true) {
      create_perm = '1';
    }
    
    cp.call('cpaint/bbcode.php', 'compress_param', update_smiley, create_perm, s_smiley_name, message.value, colors[2], checked, colors[1], colors[0], colors[3], font_name.options[font_name.selectedIndex].value, font_size.value);
    
    return false;
  }
  
  function set_smiley_name(name) {
    s_smiley_name = name;
  }
  
  function update_smiley(result) {
    var script_path = document.location.href.replace(/index.html$/, '');
    smiley.src      = 'gfx/smiley.php?bbcode=' + result.ajaxResponse[0].base64[0].data + '&rnd=' + Math.random();
    create_perm     = '0';
  }
