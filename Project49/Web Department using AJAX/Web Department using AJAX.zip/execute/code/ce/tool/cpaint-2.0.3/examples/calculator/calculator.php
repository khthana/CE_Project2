<?php
/**
* http://sf.net/projects/cpaint
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005-2006 Paul Sullivan, Dominique Stender - http://sf.net/projects/cpaint
*/
include("../../cpaint2.inc.php");
include("../../cpaint2.backend-debugger.php");

$cp = new cpaint();
$cp->register('add');
$cp->register('subtract');
$cp->start();
$cp->return_data();

function add($num1, $num2) {
	global $cp;
	$cp->set_id("response");
	$cp->set_data($num1 + $num2);
	return;
	}
function subtract($num1, $num2) {
	global $cp;
	$cp->set_id("response");
	$cp->set_data($num1 - $num2);
	return;
	}
?>