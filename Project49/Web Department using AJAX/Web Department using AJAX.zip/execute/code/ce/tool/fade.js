﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////	
//RGB HLS Color transforms

	var RANGE = 240;
	var HLSMAX = RANGE;/* H,L, and S vary over 0-HLSMAX */
   	var RGBMAX  = 255;   /* R,G, and B vary over 0-RGBMAX */
                           /* HLSMAX BEST IF DIVISIBLE BY 6 */
                           /* RGBMAX, HLSMAX must each fit in a byte. */

   /* Hue is undefined if Saturation is 0 (grey-scale) */
   /* This value determines where the Hue scrollbar is */
   /* initially set for achromatic colors */
   var UNDEFINED  = HLSMAX*2/3;

   function  RGBtoHLS(R,G,B)
   {
      cMax = Math.max( Math.max(R,G), B);
      cMin = Math.min( Math.min(R,G), B);

      L = Math.floor(( ((cMax+cMin)*HLSMAX) + RGBMAX )/(2*RGBMAX));

      if (cMax == cMin) {           /* r=g=b --> achromatic case */
         S = 0;                     /* saturation */
         H = UNDEFINED;             /* hue */
      }
      else {                        /* chromatic case */
         /* saturation */
         if (L <= (HLSMAX/2))
            S = Math.floor( ( ((cMax-cMin)*HLSMAX) + ((cMax+cMin)/2) ) / (cMax+cMin) );
         else
            S = Math.floor( ( ((cMax-cMin)*HLSMAX) + ((2*RGBMAX-cMax-cMin)/2) )/ (2*RGBMAX-cMax-cMin) );

         /* hue */
      Rdelta = Math.floor( ( ((cMax-R)*(HLSMAX/6)) + ((cMax-cMin)/2) ) / (cMax-cMin) );
      Gdelta = Math.floor( ( ((cMax-G)*(HLSMAX/6)) + ((cMax-cMin)/2) ) / (cMax-cMin) );
      Bdelta = Math.floor( ( ((cMax-B)*(HLSMAX/6)) + ((cMax-cMin)/2) ) / (cMax-cMin) );

         if (R == cMax)
            H = Bdelta - Gdelta;
         else if (G == cMax)
            H = (HLSMAX/3) + Rdelta - Bdelta;
         else /* B == cMax */
            H = ((2*HLSMAX)/3) + Gdelta - Rdelta;

         if (H < 0)
            H += HLSMAX;
         if (H > HLSMAX)
            H -= HLSMAX;
      }
	  
	  res = new Array();
	  res[0] = Math.floor(H);
	  res[1] = Math.floor(L);
	  res[2] = Math.floor(S);
	  
	  return res;
   }
   /* utility routine for HLStoRGB */
   
   function  HueToRGB(n1,n2,hue)
   {
	   
		n1 = Math.floor(n1);
		n2 = Math.floor(n2);
		hue = Math.floor(hue);
      /* range check: note values passed add/subtract thirds of range */
      if (hue < 0)
         hue += HLSMAX;

      if (hue > HLSMAX)
         hue -= HLSMAX;

      /* return r,g, or b value from this tridrant */
      if (hue < (HLSMAX/6))
          return Math.floor( n1 + Math.floor((((n2-n1)*hue+(HLSMAX/12))/(HLSMAX/6))) );
      if (hue < (HLSMAX/2))
         return ( n2 );
      if (hue < ((HLSMAX*2)/3))
         return Math.floor( n1 +    Math.floor( (((n2-n1)*(((HLSMAX*2)/3)-hue)+(HLSMAX/12)) / (HLSMAX/6)) ) );
      else
         return Math.floor( n1 );
   }

   function HLStoRGB(hue,lum,sat)
    {

      if (sat == 0) {            /* achromatic case */
         R=G=B=(lum*RGBMAX)/HLSMAX;
         if (hue != UNDEFINED) {
            /* ERROR */
          }
       }
      else  {                    /* chromatic case */
         /* set up magic numbers */
         if (lum <= (HLSMAX/2))
            Magic2 = Math.floor(	(lum*(HLSMAX + sat) + (HLSMAX/2)) / HLSMAX	);
         else
            Magic2 = (lum + sat - Math.floor( ((lum*sat) + (HLSMAX/2))/HLSMAX) );
			
         Magic1 = 2*lum-Magic2;

         /* get RGB, change units from HLSMAX to RGBMAX */
         R = (HueToRGB(Magic1,Magic2,hue+(HLSMAX/3))*RGBMAX + (HLSMAX/2))/HLSMAX;
         G = (HueToRGB(Magic1,Magic2,hue)*RGBMAX + (HLSMAX/2)) / HLSMAX;
         B = (HueToRGB(Magic1,Magic2,hue-(HLSMAX/3))*RGBMAX +  (HLSMAX/2))/HLSMAX;
      }
	  
  
	  res = new Array();
	  res[0] = Math.floor(R);
	  res[1] = Math.floor(G);
	  res[2] = Math.floor(B);
	  
	  return res;

    }
function getHex(num){
   hexStr = "0123456789ABCDEF";
   hex="";
   if (num>=16) {
      hex = hexStr.substr(parseInt(num/16),1);
      num = num%16;
   }
   hex += hexStr.substr(num,1);

   if(hex.length == 1)
		hex = "0" +  hex;
   
   return hex;
}

function getNum(hex){
	if(hex.length !=2 )	
		return 0;
	hexStr = "0123456789ABCDEFabcdef";

	for(i = 0 ; i < hex.length; i++){
	   if(hexStr.indexOf(hex.substring(i,1))<0)
			return 0;
	}

	return parseInt(hex,16);
}
/////////////////////////////////////////////////////////////////

function fadetocolor(){
	if(option){
		lum-=5;
		var hls=RGBtoHLS(Rcolor,Gcolor,Bcolor);
		var rgb=HLStoRGB(hls[0],lum,hls[2]);
		if(mode=='bg')
			document.getElementById(fadeid).style.backgroundColor="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";
		else if(mode=='font')
			document.getElementById(fadeid).style.color="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";
		if(lum>hls[1])
			setTimeout('fadetocolor()',50);
	}
	else{
		lum+=5;
		var hls=RGBtoHLS(Rcolor,Gcolor,Bcolor);
		var rgb=HLStoRGB(hls[0],lum,hls[2]);
		if(mode=='bg')
			document.getElementById(fadeid).style.backgroundColor="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";
		else if(mode=='font')
			document.getElementById(fadeid).style.color="rgb("+rgb[0]+","+rgb[1]+","+rgb[2]+")";
		if(lum<240)
			setTimeout('fadetocolor()',50);
		
	}
}
function fadeIn(id,color,m){
	this.fadeid=id;
	this.lum=240;
	this.Rcolor=getNum(color.substr(1,2));
	this.Gcolor=getNum(color.substr(3,2));
	this.Bcolor=getNum(color.substr(5,2));
	this.option=1;
	this.mode=m;
	fadetocolor();
}
function fadeOut(id,color,m){
	this.fadeid=id;
	this.Rcolor=getNum(color.substr(1,2));
	this.Gcolor=getNum(color.substr(3,2));
	this.Bcolor=getNum(color.substr(5,2));
	var tmplum=RGBtoHLS(Rcolor,Gcolor,Bcolor);
	this.lum=tmplum[1];
	this.option=0;
	this.mode=m;
	fadetocolor();
}