﻿/////////////////////////////////////////////////////////////////////////////////
//Coockies
function Get_Cookie(name){ 
   var start = document.cookie.indexOf(name+"="); 
   var len = start+name.length+1; 
   if ((!start) && (name != document.cookie.substring(0,name.length))) return null; 
   if (start == -1) return null; 
   var end = document.cookie.indexOf(";",len); 
   if (end == -1) end = document.cookie.length; 
   return unescape(document.cookie.substring(len,end)); 
} 

function Set_Cookie(name,value,expires,path,domain,secure) { 
	var nextdate=new Date();
	//expires is sec
	if(expires){
		if(expires>31104000){
			nextdate.setFullYear(nextdate.getFullYear()+(expires/31104000));
			expires=expires % 31104000;
		}
		if(expires>2592000){
			nextdate.setMonth(nextdate.getMonth()+(expires/2592000));
			expires=expires % 2592000;
		}
		if(expires>86400){
			nextdate.setDate(nextdate.getDate()+(expires/86400));
			expires=expires % 86400;
		}
		if(expires>3600){
			nextdate.setHours()(nextdate.getHours()+(expires/3600));
			expires=expires % 3600;
		}
		if(expires>60){
			nextdate.setMinutes(nextdate.getMinutes()+(expires/60));
			expires=expires % 60;
		}
		if(expires>0){
			nextdate.setSeconds(nextdate.getSeconds()+expires);
		}
	}
	
    var cookieString = name + "=" +escape(value) + 
       ( (nextdate) ? ";expires=" + nextdate.toGMTString() : "") + 
       ( (path) ? ";path=" + path : "") + 
       ( (domain) ? ";domain=" + domain : "") + 
       ( (secure) ? ";secure" : ""); 
    document.cookie = cookieString; 
} 

function Delete_Cookie(name,path,domain) { 
   if (Get_Cookie(name)) 
	   document.cookie = name + "=" + 
      ( (path) ? ";path=" + path : "") + 
      ( (domain) ? ";domain=" + domain : "") + 
      ";expires=Sun, 01-Jan-70 00:00:01 GMT"; 
} 
