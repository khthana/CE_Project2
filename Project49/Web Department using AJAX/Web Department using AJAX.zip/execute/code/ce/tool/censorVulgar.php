<?php
$replaceWord=iconv("tis-620","utf-8","~@#�@~");
$vulgars=array(" fuck ",
	" suck ",
	" shit ",
	iconv("tis-620","utf-8","��"),
	iconv("tis-620","utf-8","�֧"),
	iconv("tis-620","utf-8","�մ͡"),
	iconv("tis-620","utf-8","���"),
	iconv("tis-620","utf-8","�����"),
	iconv("tis-620","utf-8","�Ѵ"),
	iconv("tis-620","utf-8","���"));
function censorVulgar($message){
	global $vulgars,$replaceWord;
	foreach ($vulgars as $vulgar){
		$message=str_replace($vulgar,$replaceWord,$message);
	}
	return $message;
}
?>