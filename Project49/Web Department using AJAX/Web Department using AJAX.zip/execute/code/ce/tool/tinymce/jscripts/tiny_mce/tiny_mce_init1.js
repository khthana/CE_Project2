﻿var bodygl;
var messagegl="";

tinyMCE.init({
	mode : "none",
	theme : "advanced",
	plugins : "emotions,nonbreaking,preview,table",	
	
	content_css : "/ce/tool/tinymce/jscripts/tiny_mce/css/mycontent.css",
	plugin_preview_width : "800",
	plugin_preview_height : "500",
	theme_advanced_buttons1 : "bold,italic,underline,separator,justifyleft,justifycenter,justifyright, justifyfull,indent,outdent,bullist,numlist,separator,hr,nonbreaking,link,unlink,image,forecolor,backcolor,separator,charmap,emotions,newdocument",
	theme_advanced_buttons2 : "fontselect,fontsizeselect,undo,redo,removeformat,preview,code",
	theme_advanced_buttons3 : "tablecontrols",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	setupcontent_callback : "myCustomSetupContent",
	theme_advanced_path_location : "bottom"
});


function myCustomSetupContent(editor_id, body, doc) {
	bodygl=body;
	if (body.innerHTML ==""){
		body.innerHTML = messagegl;
	}
	
}

