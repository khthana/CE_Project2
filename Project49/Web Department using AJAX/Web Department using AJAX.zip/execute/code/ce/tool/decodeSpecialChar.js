function decodeSpecialChar(message){
	var intdexSp=message.indexOf("\\u00");
	while(intdexSp>=0){
			var enString=message.substr(intdexSp+4,2);
			var spChar="%"+enString;
			enString="\\u00"+enString;
			message=message.replace(enString,unescape(spChar));
			 intdexSp=message.indexOf("\\u00");
	}
	return message;
}