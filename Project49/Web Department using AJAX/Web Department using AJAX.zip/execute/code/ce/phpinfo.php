﻿<?php
phpinfo();
?>