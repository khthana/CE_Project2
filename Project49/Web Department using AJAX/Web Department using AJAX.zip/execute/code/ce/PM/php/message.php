<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
$cp = new cpaint();
$cp->register('getsendMessage');
$cp->register('getreceiveMessage');
$cp->register('sendMessage');
$cp->register('deleteReceivermessage');
$cp->register('deleteSendermessage');
$cp->start();
$cp->return_data();

function getsendMessage(){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		$comSQLgetsendMessage="SELECT T1.*,T2.USER_NAME,T3.USER_NAME FROM private_message  T1 LEFT JOIN useraccount T2 ON ( T1.SENDER_ID = T2.USER_ID ) LEFT JOIN useraccount T3 ON ( T1.RECEIVER_ID = T3.USER_ID )";
		$comSQLgetsendMessage.=" WHERE T1.SENDER_ID=".$_SESSION['ss_UserID']." AND T1.SENDER_DELETE_FLAG =0";
		$comSQLgetsendMessage.=" ORDER BY T1.PM_ID";//LIMIT ".$begin." ,".$number_per_page;
		$getsendMessageresult=mysql_query($comSQLgetsendMessage);
		echo mysql_error();
		while ($messagerrow=mysql_fetch_array($getsendMessageresult)){
			$pmmessageNode =& $cp->add_node('pmmessage');
			$pmIDNode =& $pmmessageNode->add_node('pm_ID');
			$messageNode =& $pmmessageNode->add_node('message');
			$timeNode =& $pmmessageNode->add_node('time');
			$senderNameNode =& $pmmessageNode->add_node('sendername');
			$receiveIDNode =& $pmmessageNode->add_node('receiveID');
			$receiveNameNode =& $pmmessageNode->add_node('receivename');
			$statusNode =& $pmmessageNode->add_node('status');

			if ($messagerrow["PM_ID"]=="") $pmIDNode->set_data("-");else $pmIDNode->set_data($messagerrow["PM_ID"]);
			if ($messagerrow["MESSAGE"]=="") $messageNode->set_data("-");else $messageNode->set_data($messagerrow["MESSAGE"]);
			if ($messagerrow["TIME"]=="") $timeNode->set_data("-");else $timeNode->set_data(date("d-m-Y H:i:s",$messagerrow["TIME"]));
		//	if ($messagerrow["SENDER_ID"]=="") $senderIDNode->set_data("-");else $senderIDNode->set_data($messagerrow["SENDER_ID"]);
			if ($messagerrow["RECEIVER_ID"]=="") $receiveIDNode->set_data("-");else $receiveIDNode->set_data($messagerrow["RECEIVER_ID"]);
			if ($messagerrow["STATUS_FLAG"]=="") $statusNode->set_data("-");else $statusNode->set_data($messagerrow["STATUS_FLAG"]);
			if ($messagerrow[9]=="") $senderNameNode->set_data("-");else $senderNameNode->set_data($messagerrow[9]);
			if ($messagerrow[10]=="") $receiveNameNode->set_data("-");else $receiveNameNode->set_data($messagerrow[10]);
		}
	
	}
}
function getreceiveMessage(){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		$hasmessage=false;
		$comSQLgetsendMessage="SELECT T1.*,T2.USER_NAME,T3.USER_NAME FROM private_message  T1 LEFT JOIN useraccount T2 ON ( T1.SENDER_ID = T2.USER_ID ) LEFT JOIN useraccount T3 ON ( T1.RECEIVER_ID = T3.USER_ID )";
		$comSQLgetsendMessage.=" WHERE T1.RECEIVER_ID=".$_SESSION['ss_UserID']." AND T1.RECEIVER_DELETE_FLAG =0";
		$comSQLgetsendMessage.=" ORDER BY T1.PM_ID";//LIMIT ".$begin." ,".$number_per_page;
		$getsendMessageresult=mysql_query($comSQLgetsendMessage);
		while ($messagerrow=mysql_fetch_array($getsendMessageresult)){
			$pmmessageNode =& $cp->add_node('pmmessage');
			$pmIDNode =& $pmmessageNode->add_node('pm_ID');
			$messageNode =& $pmmessageNode->add_node('message');
			$timeNode =& $pmmessageNode->add_node('time');
			$senderIDNode =& $pmmessageNode->add_node('senderID');
			$senderNameNode =& $pmmessageNode->add_node('sendername');
			$receiveIDNode =& $pmmessageNode->add_node('receiveID');
			$receiveNameNode =& $pmmessageNode->add_node('receivename');
			$statusNode =& $pmmessageNode->add_node('status');

			if ($messagerrow["PM_ID"]=="") $pmIDNode->set_data("-");else $pmIDNode->set_data($messagerrow["PM_ID"]);
			if ($messagerrow["MESSAGE"]=="") $messageNode->set_data("-");else $messageNode->set_data($messagerrow["MESSAGE"]);
			if ($messagerrow["TIME"]=="") $timeNode->set_data("-");else $timeNode->set_data(date("d-m-Y H:i:s",$messagerrow["TIME"]));
			if ($messagerrow["SENDER_ID"]=="") $senderIDNode->set_data("-");else $senderIDNode->set_data($messagerrow["SENDER_ID"]);
			if ($messagerrow["RECEIVER_ID"]=="") $receiveIDNode->set_data("-");else $receiveIDNode->set_data($messagerrow["RECEIVER_ID"]);
			if ($messagerrow["STATUS_FLAG"]=="") $statusNode->set_data("-");else $statusNode->set_data($messagerrow["STATUS_FLAG"]);
			if ($messagerrow[9]=="") $senderNameNode->set_data("-");else $senderNameNode->set_data($messagerrow[9]);
			if ($messagerrow[10]=="") $receiveNameNode->set_data("-");else $receiveNameNode->set_data($messagerrow[10]);
			$hasmessage=true;
		}
		if ($hasmessage){
				$comSQLUpdateStatus="UPDATE private_message  SET ".
						" STATUS_FLAG='read'";	
				$comSQLUpdateStatus .=" WHERE RECEIVER_ID=".$_SESSION['ss_UserID'];
				mysql_query($comSQLUpdateStatus);
		}
		echo mysql_error();
	}
}

function sendMessage($receiverName,$message){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		mysql_query("SET NAMES utf8"); 
		$recevierID=findUserID($receiverName);
		$responseNode =& $cp->add_node('responseflag');
		$responsemessageNode =& $cp->add_node('responsemessage');
		if (is_numeric ($recevierID)){
				$comandsqlcount = "SELECT MAX(PM_ID) FROM private_message ";
				$idresult=mysql_query($comandsqlcount);
				$id=mysql_fetch_array($idresult);
				$comSQLInsertmessage="INSERT INTO private_message  SET".
				" PM_ID=".($id[0]+1).
				",MESSAGE='".$message."'".
				",TIME=".time().
				",SENDER_ID=".$_SESSION['ss_UserID'].
				",RECEIVER_ID=".$recevierID.
				",STATUS_FLAG='unread'";
				mysql_query($comSQLInsertmessage);
					
				$responseNode->set_data("sucess");
				$responsemessageNode->set_data(iconv("tis-620","utf-8","��ͤ�����١�����º��������"));
		}else {
				$responseNode->set_data("fail");
				$responsemessageNode->set_data(iconv("tis-620","utf-8","��辺���ͧ͢����Ѻ��سҡ�͡���ͼ���Ѻ����"));
		}

	}
}
function findUserID($username){//check block use this function
			$comSQLSelectuserID="SELECT USER_ID FROM useraccount WHERE USER_NAME='".$username."'";
			$selectuserIDresult=mysql_query($comSQLSelectuserID);
			if ($userrow=mysql_fetch_array($selectuserIDresult)){
				if ($_SESSION['ss_Level'] =="admin"){
					return $userrow[0];
				}
				$comSQLcheckBlock="SELECT COUNT(*) FROM block_friend  WHERE USER_ID=".$userrow[0]." AND RELATIVE_ID=".$_SESSION['ss_UserID']." AND RELATIONSHIP='block'";
				$checkBlockresult=mysql_query($comSQLcheckBlock);
				echo mysql_error();
				if ($blockrow=mysql_fetch_array($checkBlockresult)){
					if ($blockrow[0]==0){
						return $userrow[0];
					}else {
						return "Block";
					}
				}else {
					return "Block";
				}
			}else{
				return "Not found";
			}
}
function deleteSendermessage($messageID){
	global $cp;
	connectdb();
	$responseNode =& $cp->add_node('response');
	$comSQLdeleteMessage="UPDATE private_message  SET ".
						" SENDER_DELETE_FLAG=1";	
	$comSQLdeleteMessage .=" WHERE PM_ID=".$messageID." AND SENDER_ID=".$_SESSION['ss_UserID'];
	mysql_query($comSQLdeleteMessage);
	removeMessageFromTable();
	if (!mysql_error()){
		$responseNode->set_data("deleted");
		$messageIDNode =& $cp->add_node('messageID');
		$messageIDNode->set_data($messageID);
	}else $responseNode->set_data(mysql_error());
}
function deleteReceivermessage($messageID){
	global $cp;
	connectdb();
	$comSQLdeleteMessage="UPDATE private_message  SET ".
						" RECEIVER_DELETE_FLAG=1";	
	$comSQLdeleteMessage .=" WHERE PM_ID=".$messageID." AND RECEIVER_ID=".$_SESSION['ss_UserID'];
	mysql_query($comSQLdeleteMessage);
	$responseNode =& $cp->add_node('response');
	removeMessageFromTable();
	if (!mysql_error()){
		$responseNode->set_data("deleted");
		$messageIDNode =& $cp->add_node('messageID');
		$messageIDNode->set_data($messageID);
	}else $responseNode->set_data(mysql_error());
}
 function removeMessageFromTable(){
	 $comSQLdeleteMessagefromTable="DELETE FROM private_message  WHERE TYPE = 'complain' AND SENDER_DELETE_FLAG=1 AND RECEIVER_DELETE_FLAG=1";
	mysql_query($comSQLdeleteMessagefromTable);
 }
?>