<?php
include("../../tool/cpaint-2.0.3/cpaint2.inc.php");
include("../../tool/cpaint-2.0.3/cpaint2.backend-debugger.php");
include("../../_Connectdatabase.php");
include("../../_Sessionstart.php");
$cp = new cpaint();
$cp->register('getContact');
$cp->register('getBlock');
$cp->register('addContact');
$cp->register('addBlock');
$cp->register('removeContact');
$cp->start();
$cp->return_data();

function getContact(){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		$comSQLgetContact="SELECT T1.*,T2.USER_NAME FROM block_friend   T1 LEFT JOIN useraccount T2 ON ( T1.RELATIVE_ID = T2.USER_ID ) ";
		$comSQLgetContact.=" WHERE T1.USER_ID=".$_SESSION['ss_UserID']." AND T1.RELATIONSHIP ='contact'";
		$comSQLgetContact.=" ORDER BY T2.USER_NAME";
		$getContactresult=mysql_query($comSQLgetContact);
		echo mysql_error();
		$memberListNode =& $cp->add_node('memberList');
		while ($memberrow=mysql_fetch_array($getContactresult)){
			$memberNode =& $memberListNode->add_node('member');
			$memberIDNode =& $memberNode->add_node('memberID');
			$memberNameNode =& $memberNode->add_node('memberName');

			if ($memberrow["RELATIVE_ID"]=="") $memberIDNode->set_data("-");else $memberIDNode->set_data($memberrow["RELATIVE_ID"]);
			if ($memberrow["USER_NAME"]=="") $memberNameNode->set_data("-");else $memberNameNode->set_data($memberrow["USER_NAME"]);
		}
	
	}
}
function getBlock(){
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		global $cp;
		connectdb();
		$comSQLgetBlock="SELECT T1.*,T2.USER_NAME FROM block_friend   T1 LEFT JOIN useraccount T2 ON ( T1.RELATIVE_ID = T2.USER_ID ) ";
		$comSQLgetBlock.=" WHERE T1.USER_ID=".$_SESSION['ss_UserID']." AND T1.RELATIONSHIP ='block'";
		$comSQLgetBlock.=" ORDER BY T2.USER_NAME";
		$getBlockresult=mysql_query($comSQLgetBlock);
		echo mysql_error();
		$memberListNode =& $cp->add_node('memberList');
		while ($memberrow=mysql_fetch_array($getBlockresult)){
			$memberNode =& $memberListNode->add_node('member');
			$memberIDNode =& $memberNode->add_node('memberID');
			$memberNameNode =& $memberNode->add_node('memberName');

			if ($memberrow["RELATIVE_ID"]=="") $memberIDNode->set_data("-");else $memberIDNode->set_data($memberrow["RELATIVE_ID"]);
			if ($memberrow["USER_NAME"]=="") $memberNameNode->set_data("-");else $memberNameNode->set_data($memberrow["USER_NAME"]);
		}
	}
}

function addContact($memberID){
	global $cp;
	$responseNode =& $cp->add_node('response');
	$responseMessageNode =& $cp->add_node('responseMessage');
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		connectdb();
		$comSQLaddContact="INSERT INTO block_friend   SET".
						" USER_ID=".$_SESSION['ss_UserID'].
						" ,RELATIVE_ID=".$memberID.
						",RELATIONSHIP='contact'";	
		mysql_query($comSQLaddContact);
		if (!mysql_error()){
			$responseNode->set_data("complete");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","�ѹ�֡���º����"));
		}else {
			$responseNode->set_data("incomplete");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","�������ö����������Ҫԡ������㹡�õԴ����� ��سҵ�Ǩ�ͺ������Ҫԡ������ի�����ª��͡�õԴ������͡�ûԴ�Ѻ��ͤ����ͧ��ҹ�������"));
		}
	}else {
			$responseNode->set_data("nonLogin");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","��س���ͤ�Թ����к�"));
	}
}
function addBlock($memberID){
	global $cp;
	$responseNode =& $cp->add_node('response');
	$responseMessageNode =& $cp->add_node('responseMessage');
	if(isset($_SESSION['ss_Status']) and $_SESSION['ss_Status']=="online"){
		connectdb();
		$comSQLaddBlock="INSERT INTO block_friend   SET".
						" USER_ID=".$_SESSION['ss_UserID'].
						" ,RELATIVE_ID=".$memberID.
						",RELATIONSHIP='block'";	
		mysql_query($comSQLaddBlock);
		if (!mysql_error()){
			$responseNode->set_data("complete");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","�ѹ�֡���º����"));
		}else {
			$responseNode->set_data("incomplete");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","�������ö����������Ҫԡ������㹡�õԴ����� ��سҵ�Ǩ�ͺ������Ҫԡ������ի�����ª��͡�õԴ������͡�ûԴ�Ѻ��ͤ����ͧ��ҹ�������"));
		}
	} else {
			$responseNode->set_data("nonLogin");
			$responseMessageNode->set_data(iconv("tis-620","utf-8","��س���ͤ�Թ����к�"));
	}
}
function removeContact($memberID){ //removeBlock use this same function  
	global $cp;
	connectdb();
	$responseNode =& $cp->add_node('response');
	$comSQLremoveContact="DELETE FROM block_friend   WHERE ".
						" USER_ID=".$_SESSION['ss_UserID']." AND RELATIVE_ID=".$memberID;	
	mysql_query($comSQLremoveContact);
	if (!mysql_error()){
		$responseNode->set_data("deleted");
		$memberIDNode =& $cp->add_node('memberID');
		$memberIDNode->set_data($memberID);
	}else $responseNode->set_data(mysql_error());
}

?>