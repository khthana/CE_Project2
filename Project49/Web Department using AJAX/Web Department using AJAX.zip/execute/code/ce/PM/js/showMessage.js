<!--

var showEditTextflag=false;
var sendingMsg=false;
var showmessageMode;
var allMessageXML;




function showMessage(){

	if (showMeun!=1){
		document.getElementById("showmessage").innerHTML="";
		document.getElementById("icon1").innerHTML=iconReceive;
		document.getElementById("icon2").innerHTML=iconSend;
		showMeun=1;
		showmessageMode="showReceive";
	}
}
function showReceivemessage(){
	cp.call('php/message.php','getreceiveMessage',responseshowReceivemessage);
}
function responseshowReceivemessage(result){
	showmessageMode="showReceive";
	allMessageXML=result;
	var getEle = document.getElementById("showmessage");
	getEle.innerHTML="";
	getEle.innerHTML="<img src='../PM/pic/icon/inbox.gif' border=\"0\" alt=\"IN BOX\"/>";
	for (var i =(result.getElementsByTagName('pmmessage').length - 1); i >= 0 ;i-- ){
		getEle.innerHTML+="<br/>";
		addtable(getEle,result.getElementsByTagName('pm_ID')[i].firstChild.nodeValue, result.getElementsByTagName('senderID')[i].firstChild.nodeValue, result.getElementsByTagName('sendername')[i].firstChild.nodeValue, result.getElementsByTagName('receivename')[i].firstChild.nodeValue, result.getElementsByTagName('time')[i].firstChild.nodeValue, result.getElementsByTagName('message')[i].firstChild.nodeValue,result.getElementsByTagName('status')[i].firstChild.nodeValue);
	}
}
function showSendmessage(){
	cp.call('php/message.php','getsendMessage',responseshowSendmessage);
}

function responseshowSendmessage(result){
	showmessageMode="showsend";
	var getEle = document.getElementById("showmessage");
	getEle.innerHTML="";
	getEle.innerHTML="<img src='../PM/pic/icon/outbox.gif' border=\"0\" alt=\"OUT BOX\"/>";
	for (var i =(result.getElementsByTagName('pmmessage').length - 1); i >= 0 ;i-- ){
		getEle.innerHTML+="<br/>";
		addtable(getEle,result.getElementsByTagName('pm_ID')[i].firstChild.nodeValue, null, result.getElementsByTagName('sendername')[i].firstChild.nodeValue, result.getElementsByTagName('receivename')[i].firstChild.nodeValue, result.getElementsByTagName('time')[i].firstChild.nodeValue, result.getElementsByTagName('message')[i].firstChild.nodeValue,result.getElementsByTagName('status')[i].firstChild.nodeValue);
	}
}



function getEditmessage(){
	messagegl="";
	getEle =document.getElementById("compose");
	if (showEditTextflag){
		getEle.innerHTML="";
		//document.getElementById("responseSend").innerHTML="";
		showEditTextflag=false;
	}else{
		getEle.innerHTML=editArea;
		tinyMCE.addMCEControl(document.getElementById("edittext"),'MCEControlID');
		showEditTextflag=true;
	}
}

function sendmessage(){
	var formErrors=false;
	if ( tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')).length < 2) {
		formErrors = "You must enter a message when sending.";
	}
	if (document.getElementById("receiverName").value==""){
		formErrors = "Missing reciver";
	}
	if (sendingMsg){
		formErrors = "Please wait. Message is sending";
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
	sendingMsg=true;
	//document.getElementById('responseSend').innerHTML= 'กำลังส่งข้อมูล<br/><img src="../webboard/imgs/ajax-loader2.gif" />';
	cp.call('php/message.php','sendMessage',responsesendmessage,document.getElementById("receiverName").value,tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')));
	}
}
function responsesendmessage(result){
	sendingMsg=false;
	//document.getElementById('responseSend').innerHTML=result.getElementsByTagName('responsemessage')[0].firstChild.nodeValue;
	alert(result.getElementsByTagName('responsemessage')[0].firstChild.nodeValue);
	showmessageMode="showsend";
	if (result.getElementsByTagName('responseflag')[0].firstChild.nodeValue=="sucess" && showmessageMode=="showsend"){
		showSendmessage();
		getEditmessage();
	}
	
}
function deleteReceivermessage(messageID){
	cp.call('php/message.php','deleteReceivermessage',responseDelete,messageID);
}
function deleteSendermessage(messageID){
	cp.call('php/message.php','deleteSendermessage',responseDelete,messageID);
}
function responseDelete(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue!= "deleted"){
		alert(result.getElementsByTagName('response')[0].firstChild.nodeValue );
	}else {

		var getNode=document.getElementById('messageID'+result.getElementsByTagName('messageID')[0].firstChild.nodeValue);
		var parentNode=getNode.parentNode;
		parentNode.removeChild(getNode);
	}
}
function	 replymessage(messageID){
	for (var i=(allMessageXML.getElementsByTagName('pm_ID').length - 1); i >= 0;i-- ){
		if (allMessageXML.getElementsByTagName('pm_ID')[i].firstChild.nodeValue==messageID){	
			break;
		}
	}
	if (i>= 0){
		var message=decodeSpecialChar(allMessageXML.getElementsByTagName('message')[i].firstChild.nodeValue);
		if (!showEditTextflag){
			showEditTextflag=true;
			messagegl="Reply : <br/>";
			messagegl+=message;
			messagegl+="<hr/>";
			document.getElementById("compose").innerHTML=editArea;
			tinyMCE.addMCEControl(document.getElementById("edittext"),'MCEControlID');
		}else{
			bodygl.innerHTML="Reply : <br/>";
			bodygl.innerHTML+=message;
			bodygl.innerHTML+="<hr/>";
		}
		document.getElementById("receiverName").value=allMessageXML.getElementsByTagName('sendername')[i].firstChild.nodeValue;
		document.getElementById("responseSend").innerHTML="";
	}
}
function addtable(parentObj,messageID,senderID,senderName,receiverName,sendtime,message,status){
	message=decodeSpecialChar(message);
	var createNodetable =document.createElement("table");
	parentObj.appendChild(createNodetable);
	createNodetable.setAttribute("id","messageID"+messageID);
	createNodetable.cellSpacing="0";
	createNodetable.cellPadding="0";
	var newRow=createNodetable.insertRow(0);
	var newCell=newRow.insertCell(0);
	newCell.innerHTML="<img src='../PM/pic/table_Frame/top_l.gif'  />";
	newCell=newRow.insertCell(1);
	newCell.align="left";
	newCell.className="topframe";
	newCell=newRow.insertCell(2);
	newCell.innerHTML="<img src='../PM/pic/table_Frame/top_r.gif' />";

	newRow=createNodetable.insertRow(1);
	newCell=newRow.insertCell(0);
	newCell.rowSpan="3";
	newCell.className="leftframe";
	newCell=newRow.insertCell(1);
	newCell.align="center";
	if (status=="unread"){
		newCell.innerHTML="<img src='../PM/pic/icon/newmessage.gif' border=\"0\" alt=\"Unread message\"/>";
	}else{
		newCell.innerHTML="<img src='../PM/pic/icon/read.gif' border=\"0\" alt=\"Old message\"/>";
	}

	newCell.innerHTML+="&#3612;&#3641;&#3657;&#3626;&#3656;&#3591; : "+senderName+" &#3612;&#3641;&#3657;&#3619;&#3633;&#3610; : "+receiverName+"		&#3648;&#3623;&#3621;&#3634;&#3607;&#3637;&#3656;&#3626;&#3656;&#3591; : "+sendtime;
	newCell.innerHTML+="<br/><img src='../PM/pic/table_Frame/linetop.gif' />";
	newCell=newRow.insertCell(2);
	newCell.rowSpan="3";
	newCell.className="rigthframe";
	newRow=createNodetable.insertRow(2);
	newCell=newRow.insertCell(0);
	newCell.align="left";
	newCell.innerHTML=message;
	newCell.innerHTML+="<br/><center><img src='../PM/pic/table_Frame/linetop.gif' /></center>";
	newRow=createNodetable.insertRow(3);
	newCell=newRow.insertCell(0);
	newCell.align="left";
	
	if (senderID!= null){
		//receiver
		newCell.innerHTML+="<a href=\"javascript:deleteReceivermessage("+messageID+")\"><img src='../PM/pic/icon/delete.gif' border=\"0\" alt=\"Delete\"/></a>";
		newCell.innerHTML+="<a href=\"javascript:replymessage("+messageID+")\"><img src='../PM/pic/icon/reply.gif' border=\"0\" alt=\"Reply\"/></a>";//Relpy message
		newCell.innerHTML+="<a href=\"javascript:addContact("+senderID+")\"><img src='../PM/pic/icon/add.gif' border=\"0\" alt=\"Reply\"/></a>";//add contact
		newCell.innerHTML+="<a href=\"javascript:addBlock("+senderID+")\"><img src='../PM/pic/icon/block.gif' border=\"0\" alt=\"Reply\"/></a>";//block contact
	}else{
		newCell.innerHTML+="<a href=\"javascript:deleteSendermessage("+messageID+")\"><img src='../PM/pic/icon/delete.gif' border=\"0\" alt=\"Delete\"/></a>";
	}
	newRow=createNodetable.insertRow(4);
	newCell=newRow.insertCell(0);
	newCell.innerHTML="<img src='../PM/pic/table_Frame/buttom_l.gif'  />";
	newCell=newRow.insertCell(1);
	newCell.className="buttomframe";
	newCell=newRow.insertCell(2);
	newCell.innerHTML="<img src='../PM/pic/table_Frame/buttom_r.gif'  />";

}



//-->