var membersPerPage=10;
var pagegl=1;
var totalpagegl=0;
function addbuttonMovePage(trNode,page,totalpage){
	var newCell=trNode.insertCell(0);
	newCell.className="left";
	newCell=trNode.insertCell(1);
	newCell.className="slidePageL";
	newCell.innerHTML='<img src=\'./pic/icon/prevPage_0.gif\' border="0" alt=\"&#3627;&#3609;&#3657;&#3634;&#3607;&#3637;&#3656;&#3649;&#3621;&#3657;&#3623;\" onMouseOver="this.src=\'./pic/icon/prevPage_1.gif\'" onMouseOut="this.src=\'./pic/icon/prevPage_0.gif\'" onclick="prevPage()"/><img src=\'./pic/icon/nextPage_0.gif\' border="0" alt=\"&#3627;&#3609;&#3657;&#3634;&#3606;&#3633;&#3604;&#3652;&#3611;\" onMouseOver="this.src=\'./pic/icon/nextPage_1.gif\'" onMouseOut="this.src=\'./pic/icon/nextPage_0.gif\'" height="25" onclick="nextPage()"/>';
	newCell=trNode.insertCell(2);
	newCell.className="slidePageR";
	createPagelist(newCell,page,totalpage);
	newCell=trNode.insertCell(3);
	newCell.className="slidePageL";
	newCell.innerHTML=' <input type="submit" name="nGoPage " value="goto " onclick="return gotoPage()"/>';
	newCell=trNode.insertCell(4);
	newCell.className="rigth";
}
function createPagelist(parentNode,page,totalpage){
		var createNodeselect =document.createElement("select");
		parentNode.appendChild(createNodeselect);
		createNodeselect.setAttribute("id","pagelist");
		for (var i=1;i <= totalpage ;i++ ){
			if (i!=page){
				var op=document.createElement('option');
				op.text="page "+i;
				op.value=i;
				try {
					 createNodeselect.add(op,null);// standards compliant
				}
				 catch(ex){
					 createNodeselect.add(op); // IE only
			   }
			}
		}
}
function prevPage(){
	if ((pagegl-1)>0){
		pagegl=pagegl-1;
		movepage(pagegl);
	}
}
function	 nextPage(){
	if ( (pagegl+1)<=totalpagegl ){
		pagegl=pagegl+1;
		movepage(pagegl);
	}
}
function gotoPage(){		
	
	if (document.getElementById('pagelist').options.length !=0){
		for (i=0;i<document.getElementById('pagelist').options.length ; i++)	{
			if (document.getElementById('pagelist').options[i].selected){
					var page =document.getElementById('pagelist').options[i].value;
					break;
			}
		}
		pagegl=parseInt(page);
		movepage(pagegl);
		
	}
}
function movepage(page){
	
	var getNode=document.getElementById("memberList");
	lastIndex=(membersPerPage*page)-1;
	beginIndex=(page-1)*membersPerPage;
	numMaxRow=membersPerPage;
	lastmember=getNode.rows.length-3; //last frame and button
	if (lastIndex > (allMemberXML.getElementsByTagName('member').length - 1)){
		var leftovers=lastIndex-(allMemberXML.getElementsByTagName('member').length - 1);
		lastIndex=(allMemberXML.getElementsByTagName('member').length - 1);
		for (var k =0;k<leftovers ;k++ ){
				getNode.deleteRow(lastmember);//remove leftoversNode
				lastmember=getNode.rows.length-3; 
		}	
		numMaxRow=numMaxRow-leftovers;
		//last frame and button
	}
	
	for (var i =lastIndex; i >= beginIndex ;i-- ){
		if (numMaxRow<=(getNode.rows.length-3)){
			getNode.deleteRow(lastmember);
		}
		if (showRelationMode=="showContact"){
			addRowContactMem(getNode,allMemberXML.getElementsByTagName('memberID')[i].firstChild.nodeValue,allMemberXML.getElementsByTagName('memberName')[i].firstChild.nodeValue);
		}else{
			addRowBlockMem(getNode,allMemberXML.getElementsByTagName('memberID')[i].firstChild.nodeValue,allMemberXML.getElementsByTagName('memberName')[i].firstChild.nodeValue);
		}
	}
	var oldPagelist= document.getElementById("pagelist");
	var parentListNode =oldPagelist.parentNode;
	parentListNode.removeChild(oldPagelist);
	createPagelist(parentListNode,page,totalpagegl);
}
function calculateNumPage(xmlDoc,numPerPage){
	totalmember=xmlDoc.getElementsByTagName('member').length;
	return Math.ceil(totalmember/numPerPage);
}