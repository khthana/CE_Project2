<!--
showRelationMode="showContact";

var allMemberXML;
function showRelation(){
	if (showMeun!=2){
		document.getElementById("showmessage").innerHTML="";
		document.getElementById("icon1").innerHTML="<a href='javascript:showContact()'><img src='pic/button/contact_0.gif' alt=\"Show Contact\"  border=\"0\" onmouseover=\"this.src='pic/button/contact_1.gif'\" onmouseout=\"this.src='pic/button/contact_0.gif'\"/></a>";
		document.getElementById("icon2").innerHTML="<a href='javascript:showBlock()'><img src='pic/button/block_0.gif' alt=\"Show Block\"  border=\"0\" onmouseover=\"this.src='pic/button/block_1.gif'\" onmouseout=\"this.src='pic/button/block_0.gif'\"/></a>";
		showMeun=2;
		//showRelationMode="showContact";
	}
}

function showContact(){
	cp.call('php/relation.php','getContact',responseshowContactList);
}
function showBlock(){
	cp.call('php/relation.php','getBlock',responseshowBlockList);
}

function responseshowContactList(result){
	showRelationMode="showContact";
	pagegl=1;
	allMemberXML=result;

	var getEle = document.getElementById("showmessage");
	getEle.innerHTML="";
	getEle.innerHTML="<img src='../PM/pic/icon/contact_Member.gif' border=\"0\" alt=\"Contact Member\"/>";
	var createNodetable =document.createElement("table");
	getEle.appendChild(createNodetable);
	createNodetable.setAttribute("id","memberList");
	createNodetable.cellSpacing="0";
	createNodetable.cellPadding="0";
	createNodetable.align="center";
	setFrameTable(createNodetable);
	//headTable
	var newRow=createNodetable.rows[0];
	var newCell=newRow.insertCell(1);
	newCell.className="headTable";
	newCell.innerHTML="&nbsp;&#3626;&#3656;&#3591;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;&nbsp;";
	newCell=newRow.insertCell(2);
	newCell.className="headTable";
	newCell.innerHTML="&nbsp;&#3594;&#3639;&#3656;&#3629;&#3626;&#3617;&#3634;&#3594;&#3636;&#3585;&nbsp;";
	newCell=newRow.insertCell(3);
	newCell.className="headTable";
	newCell.innerHTML="&#3621;&#3610;&#3629;&#3629;&#3585;&#3592;&#3634;&#3585;&#3619;&#3634;&#3618;&#3585;&#3634;&#3619;";
	//bottom table
	newRow=createNodetable.rows[1];
	newCell=newRow.insertCell(1);
	newCell.className="bottom";
	newCell.colSpan="3";

	
	totalpagegl=calculateNumPage(result,membersPerPage);
	newRow=createNodetable.insertRow(1);
	addbuttonMovePage(newRow,pagegl,totalpagegl);
	lastIndex=(membersPerPage*pagegl)-1;
	if (lastIndex > (result.getElementsByTagName('member').length - 1)){
		lastIndex=(result.getElementsByTagName('member').length - 1);
	}
	for (var i =lastIndex; i >= 0 ;i-- ){
		addRowContactMem(createNodetable,result.getElementsByTagName('memberID')[i].firstChild.nodeValue,result.getElementsByTagName('memberName')[i].firstChild.nodeValue);
	}

}
function responseshowBlockList(result){
	showRelationMode="showBlock";
	pagegl=1;
	allMemberXML=result;
		
	var getEle = document.getElementById("showmessage");
	getEle.innerHTML="";
	getEle.innerHTML="<img src='../PM/pic/icon/block_Member.gif' border=\"0\" alt=\"Block Member\"/>";
	var createNodetable =document.createElement("table");
	getEle.appendChild(createNodetable);
	createNodetable.setAttribute("id","memberList");
	createNodetable.cellSpacing="0";
	createNodetable.cellPadding="0";
	createNodetable.align="center";
	setFrameTable(createNodetable);
	//headTable
	var newRow=createNodetable.rows[0];
	var newCell=newRow.insertCell(1);
	newCell.className="headTable";
	newCell.innerHTML="&nbsp;&#3626;&#3656;&#3591;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;&nbsp;";
	newCell=newRow.insertCell(2);
	newCell.className="headTable";
	newCell.innerHTML="&nbsp;&#3594;&#3639;&#3656;&#3629;&#3626;&#3617;&#3634;&#3594;&#3636;&#3585;&nbsp;";
	newCell=newRow.insertCell(3);
	newCell.className="headTable";
	newCell.innerHTML="&#3621;&#3610;&#3629;&#3629;&#3585;&#3592;&#3634;&#3585;&#3619;&#3634;&#3618;&#3585;&#3634;&#3619;";
	//bottom table
	newRow=createNodetable.rows[1];
	newCell=newRow.insertCell(1);
	newCell.className="bottom";
	newCell.colSpan="3";

	totalpagegl=calculateNumPage(result,membersPerPage);
	newRow=createNodetable.insertRow(1);
	addbuttonMovePage(newRow,pagegl,totalpagegl);
	lastIndex=(membersPerPage*pagegl)-1;
	if (lastIndex > (result.getElementsByTagName('member').length - 1)){
		lastIndex=(result.getElementsByTagName('member').length - 1);
	}
	for (var i =lastIndex; i >= 0 ;i-- ){
		addRowContactMem(createNodetable,result.getElementsByTagName('memberID')[i].firstChild.nodeValue,result.getElementsByTagName('memberName')[i].firstChild.nodeValue);
	}
	
}

function removeContact(memberID){
	var r=confirm("ท่านต้องการลบออกจากรายชื่อหรือไม่?");
  if (r==true){
		cp.call('php/relation.php','removeContact',responseRemove,memberID);
    }
 

	
}
function responseRemove(result){
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue!= "deleted"){
		alert(result.getElementsByTagName('response')[0].firstChild.nodeValue );
	}else {

		/*var getNode=document.getElementById('memberID'+result.getElementsByTagName('memberID')[0].firstChild.nodeValue);
		var parentNode=getNode.parentNode;
		parentNode.removeChild(getNode);*/
		for (var j=(allMemberXML.getElementsByTagName('member').length-1);j>=0;j-- ){
			if (allMemberXML.getElementsByTagName('memberID')[j].firstChild.nodeValue == result.getElementsByTagName('memberID')[0].firstChild.nodeValue){			
				parentNode=allMemberXML.getElementsByTagName('member')[j].parentNode;
				parentNode.removeChild(allMemberXML.getElementsByTagName('member')[j]);
			}
		}
	totalpagegl=calculateNumPage(allMemberXML,membersPerPage);
	movepage(pagegl);
	}
}
function addContact(memberID){
	cp.call('../PM/php/relation.php','addContact',responseaddContact,memberID);
}
function addBlock(memberID){
	cp.call('../PM/php/relation.php','addBlock',responseaddContact,memberID);
}
function responseaddContact(result){ // remove use same function
	alert(result.getElementsByTagName('responseMessage')[0].firstChild.nodeValue);
	//alert(result.getElementsByTagName('response')[0].firstChild.nodeValue);
	if (result.getElementsByTagName('response')[0].firstChild.nodeValue== "incomplete"){
		if (document.location.pathname !="/PM/index.php"){
			var r=confirm("ท่านต้องการเปิดหน้าข้อความภายในหรือไม่หรือไม่?");
			 if (r==true){
				window.open("../PM/index.php");
			}
		}
	}
	
}
/////
function	 addRowContactMem(objParent,memerID,memberName){
	var newRow=objParent.insertRow(1);
	newRow.setAttribute("id","memberID"+memerID);
	newRow.className="content";
	newRow.bgColor="#E9E9E6";
/*	newRow.setAttribute("onMouseover","this.bgColor='#F4F4F4'");
	newRow.setAttribute("onMouseout","this.bgColor='#DEDEDB'");*/
	var newCell=newRow.insertCell(0);
	newCell.className="left";

	newCell=newRow.insertCell(1);
	newCell.innerHTML="&nbsp;<a href='javascript:composePM(\""+memberName+"\")'><img src='pic/icon/composePM_0.gif' alt=\"&#3626;&#3619;&#3657;&#3634;&#3591;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;\"  border=\"0\" onmouseover=\"this.src='pic/icon/composePM_1.gif'\" onmouseout=\"this.src='pic/icon/composePM_0.gif'\"/></a>&nbsp;";
	newCell=newRow.insertCell(2);
	newCell.innerHTML="&nbsp;<a href='../user_management/showlist_member.php?uID="+memerID+"' target='_blank'>"+memberName+"</a>&nbsp;";
	newCell=newRow.insertCell(3);
	newCell.innerHTML="&nbsp;<a href='javascript:removeContact("+memerID+")'><img src='pic/icon/remove_0.gif' alt=\"&#3621;&#3610;&#3619;&#3634;&#3618;&#3594;&#3639;&#3656;&#3629;\"  border=\"0\" onmouseover=\"this.src='pic/icon/remove_1.gif'\" onmouseout=\"this.src='pic/icon/remove_0.gif'\"/></a>&nbsp;";
	newCell=newRow.insertCell(4);
	newCell.className="rigth";
}
function addRowBlockMem(objParent,memerID,memberName){
	var newRow=objParent.insertRow(1);
	newRow.setAttribute("id","memberID"+memerID);
	newRow.className="content";
	newRow.bgColor="#E9E9E6";
	/*newRow.setAttribute("onMouseover","this.bgColor='#F4F4F4'");
	newRow.setAttribute("onMouseout","this.bgColor='#DEDEDB'");*/
	var newCell=newRow.insertCell(0);
	newCell.className="left";

	newCell=newRow.insertCell(1);
	newCell.innerHTML="&nbsp;<a href='javascript:composePM(\""+memberName+"\")'><img src='pic/icon/composePM_0.gif' alt=\"&#3626;&#3619;&#3657;&#3634;&#3591;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;\"  border=\"0\" onmouseover=\"this.src='pic/icon/composePM_1.gif'\" onmouseout=\"this.src='pic/icon/composePM_0.gif'\"/></a>&nbsp;";
	newCell=newRow.insertCell(2);
	newCell.innerHTML="&nbsp;<a href='../user_management/showlist_member.php?uID="+memerID+"' target='_blank'>"+memberName+"</a>&nbsp;";
	newCell=newRow.insertCell(3);
	newCell.innerHTML="&nbsp;<a href='javascript:removeContact("+memerID+")'><img src='pic/icon/remove_0.gif' alt=\"&#3621;&#3610;&#3619;&#3634;&#3618;&#3594;&#3639;&#3656;&#3629;\"  border=\"0\" onmouseover=\"this.src='pic/icon/remove_1.gif'\" onmouseout=\"this.src='pic/icon/remove_0.gif'\"/></a>&nbsp;";

	newCell=newRow.insertCell(4);
	newCell.className="rigth";
}
function setFrameTable(tableObj){
	var newRow=tableObj.insertRow(0);
	var newCell=newRow.insertCell(0);
	newCell.innerHTML="<img src='../PM/pic/table_List/left_t.gif'  />";
	newCell=newRow.insertCell(1);
	newCell.innerHTML="<img src='../PM/pic/table_List/rigth_t.gif'  />";
	newRow=tableObj.insertRow(1);
	newCell=newRow.insertCell(0);
	newCell.innerHTML="<img src='../PM/pic/table_List/left_b.gif'  />";
	newCell=newRow.insertCell(1);
	newCell.innerHTML="<img src='../PM/pic/table_List/rigth_b.gif'  />";
}

function composePM(memberName){
	if (!showEditTextflag){
			showEditTextflag=true;
			document.getElementById("compose").innerHTML=editArea;
			document.getElementById("receiverName").value=memberName;
			tinyMCE.addMCEControl(document.getElementById("edittext"),'MCEControlID');
		}else{
			document.getElementById("receiverName").value=memberName;
		}
}


//-->
