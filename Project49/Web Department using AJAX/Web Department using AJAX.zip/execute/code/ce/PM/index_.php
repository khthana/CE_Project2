<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="css/relation.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.tdB {font-size: 14px;
	color: #FF0000;
	background-color: #82C0FF;
	background-position: center center;
}
.tdA {
	font-size: 14px;
	color: #FF0000;
	background-color: #3399FF;
	background-position: center center;
}
INPUT.mainoption {
	FONT-WEIGHT: bold;
	background-image: url(../webboard/imgs/buttonsummit.gif);
}
#showlist {
	background-position: center center;
	text-align: center;
	display: table;
	border-top-width: 0.5px;
	border-right-width: 0.5px;
	border-bottom-width: 0.5px;
	border-left-width: 0.5px;
}
.topframe {
	background-image: url(../PM/pic/table_Frame/top_c.gif);
	background-repeat: repeat-x;
}
.leftframe {
	background-image: url(../PM/pic/table_Frame/margin_l.gif);
	background-repeat: repeat-y;
}
.rigthframe {
	background-image: url(../PM/pic/table_Frame/margin_r.gif);
	background-repeat: repeat-y;
}
.buttomframe {
	background-image: url(../PM/pic/table_Frame/buttom_c.gif);
	background-repeat: repeat-x;
}
-->
</style>

<script type="text/javascript" src="../tool/cpaint-2.0.3/cpaint2.inc.compressed.js"></script>
<script type="text/javascript" src="../tool/decodeSpecialChar.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
<script type="text/javascript" src="js/showMessage.js"></script>
<script type="text/javascript" src="js/showRelation.js"></script>
<script type="text/javascript" src="js/sildePage.js"></script>

<?php
		ob_start() ;
		include("../_Sessionstart.php");
		ob_end_flush();
?>
<script type="text/javascript" >
<!--
		var cp = new cpaint();
		cp.set_transfer_mode ('POST');
		cp.set_response_type('XML');
		//cp.set_debug(true);
		
var showMeun=1;

//-->
</script>
</head>

<body><br/>
<div align='center' ><img src="../images/logo.gif" width="640" height="120" /></div>
<h1 style='text-align:center;color:#666666;font-family:Arial;font-size:24px;'>ข้อมูลส่วนตัว</h1><div id="main">

<div id="main" align="center">
  <table width="800" border="0" cellpadding="0" cellspacing="0">
	<tr>
		
		<td colspan="3"  align="center" width="100%">

			<div id="compose">
				<table width="600" border="0" align="center" >
  					<tr>
    					<td class=simpletext align="left">&#3594;&#3639;&#3656;&#3629;&#3612;&#3641;&#3657;&#3619;&#3633;&#3610;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;<input type="text" name="textfield" id="receiverName"/>
						</td>
	  				</tr>
					<tr>
						<td class=simpletext align="left"><b>&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;</b></td>
					</tr>
					<tr>
						<td>
							<textarea name="message" id="edittext" style="width:100%;"  ></textarea>
						</td>
					</tr>
				</table>
				<input class="mainoption" onClick="sendmessage()" type="button" value="&#3626;&#3656;&#3591;&#3586;&#3657;&#3629;&#3588;&#3623;&#3634;&#3617;" name="_post"></div><div id="responseSend">
			</div>
			<br/>
		</td>
    </tr>
    <tr>
		<td  align="right" id="icon1"><a href='javascript:showReceivemessage()'><img src='pic/button/showinmessage_0.gif' alt="Show send message" width="100" height="38" border="0" onmouseover="this.src='pic/button/showinmessage_1.gif'" onmouseout="this.src='pic/button/showinmessage_0.gif'"/></a>
		</td>
		<td  align="center">&nbsp;</td>
		<td  align="left" id="icon2"><a href='javascript:showSendmessage()'><img src='pic/button/showoutmessage_0.gif' border="0" onmouseover="this.src='pic/button/showoutmessage_1.gif'" onmouseout="this.src='pic/button/showoutmessage_0.gif'"/></a>
		</td>
    </tr>
    <tr>
		<td colspan="3"  align="center">&nbsp;</td>
    </tr>
    <tr>
		<td colspan="3"  align="center"><div id="showmessage"></div></td>
    </tr>
	<br/>
  </table>
</div>
</div>






</body>
<script type="text/javascript" >
<!--

	var editArea=document.getElementById("compose").innerHTML;
	document.getElementById("compose").innerHTML="";	
	var iconSend=document.getElementById("icon2").innerHTML;
	var iconReceive=document.getElementById("icon1").innerHTML;
	showRelation();
//-->
</script>
</html>
