<?php
	$RSSpersite=3;   //กำหนดการแสดงจำนวนข่าวจากแต่ละแหล่งข่าว
	//แหล่งข่าว RSS
	$RSSsite=array("http://www.manager.co.th/RSS/Cyberbiz/Cyberbiz.xml","http://www.rssthai.com/rss/it.xml","http://www.arip.co.th/rss/rss_news.xml","http://www.rssthai.com/rss/local.xml");

?>