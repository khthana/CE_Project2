<?php
	function getMainNotice2($page=1,$search=""){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql="SELECT COUNT(*) AS NUMROWS FROM $tb_main_notice WHERE (`TOPIC` LIKE '%$search%' OR `DETAIL` LIKE '%$search%') AND `TYPE` ='วิชาการ' AND STATUS='1'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			if($result=mysql_fetch_array($dbquery))
				$num_rows=$result['NUMROWS'];
		}else{$objResponse->addAlert("เกิดความผิดพลาด...$sql");return $objResponse;}
		$sql="SELECT * FROM $tb_main_notice WHERE (`TOPIC` LIKE '%$search%' OR `DETAIL` LIKE '%$search%') AND `TYPE`='วิชาการ' AND STATUS='1'  ORDER BY `CREATED`DESC LIMIT ".($page*15-15).",15";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<div id='allnotice2'>";
			while($result=mysql_fetch_array($dbquery)){
				$optionnew="";
				$optionupdate="";
				if($result['CREATED']>time()-172800)
					$optionnew="<img src='images/newnotice.gif' border='0' alt='กระทู้ใหม่'> ";
				if($result['CREATED']!=$result['UPDATE'] && $result['UPDATE']>time()-172800)
					$optionupdate="<img src='images/newnotice.gif' border='0' alt='กระทู้ถูกแก้ไข'> ";
				$return.="
					<div id='notice2$result[NOTICE_ID]' style='padding-left:10px;' onmouseover='this.style.backgroundColor=\"#D7EBFF\"' onmouseout='this.style.backgroundColor=\"#F9F9F9\"'><img src='images/icon_2.gif' border='0' > <a href='./viewnotice2.php?id=$result[NOTICE_ID]' target='_blank'>$result[TOPIC] $optionnew$optionupdate</a></div>";
			}
			$return.="<div style='text-align:right;color:#6633FF;padding-right:20px;' >Page ".checkpage($num_rows,15,$page,"javascript:void xajax_getMainNotice2(",");")." </div></div>
			<div id='newnotice2' style='border:1px solid;background-color:#D7EBFF;position:absolute;top:350px;width:584px;height:600px;text-align:center;display:none;' >
				<br>หัวข้อ: <input type='text' id='topicnotice2' style='width:500px;'><br>
				เนื้อหา:<center><textarea id='topicdetail2' rows='20' cols='10' style='width:500px;height:400px;'></textarea></center><br>
				<iframe id='if2' style='width:500px;height:100px;' src='./upload/index.php?path=./file/' marginwidth='0' marginheight='0' frameborder='0' hspace='0' vspace='0' scrolling='yes'>
					
				</iframe><br>
				<a href='javascript:void submitNewNotice(2);'>
				<img src='images/Button/submit.gif' border='0' alt=''></a>
				<a href='javascript:void canceladd(2);'>
				<img src='images/Button/cancel.gif' border='0' alt=''></a>
			</div>";
			$returnsearch="<div>
				<a href='javascript:void viewsearch(2);'><img src='images/Button/search2.gif' border='0' alt=''></a>";
			if($_SESSION['ss_Status']=='online' && ($_SESSION['ss_Level']=='admin' || $_SESSION['ss_Level']=='lecturer'))
				$returnsearch.="
				<a href='javascript:void (xajax.$(\"newnotice2\").style.display=\"block\");xajax.$(\"if2\").src=\"./upload/index.php?path=./file/\";tinyMCE.addMCEControl(xajax.$(\"topicdetail2\"),\"MCEControlID2\");xajax.$(\"topicnotice2\").focus();'>
			<img src='images/Button/add.gif' border='0' alt=''></a>";
			$returnsearch.="</div><div id='shsearch2' style='border:1px solid;background-color:#9FCFFF;left:150px;top:800px;width:200px;height:100px;position:absolute;z-index:0;display:none;' onmouseover='searchtime=100' onmouseout='searchtime=0'>
				<center><br>ค้นหา<input type='text' class='search' id='txsearch2' value=''>
				<a href='javascript:void xajax_getMainNotice2(1,xajax.$(\"txsearch2\").value);'><img src='images/Button/search.gif' border='0' alt=''></a></center>";
			$return.="</div>";
			$objResponse->addAssign("bt2","innerHTML",$returnsearch);
			$objResponse->addAssign("notice2","innerHTML",$return);
		}
		else 
			$objResponse->addAlert("เกิดความผิดพลาด...$sql");
		return $objResponse;
	}
?>