<?php
function getMainNotice1($page=1,$search=""){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql="SELECT COUNT(*) AS NUMROWS FROM $tb_main_notice WHERE (`TOPIC` LIKE '%$search%' OR `DETAIL` LIKE '%$search%') AND `TYPE` ='ทั่วไป' AND STATUS='1'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			if($result=mysql_fetch_array($dbquery))
				$num_rows=$result['NUMROWS'];
		}else{$objResponse->addAlert("เกิดความผิดพลาด...$sql");return $objResponse;}
		$sql="SELECT * FROM `$tb_main_notice` WHERE (`TOPIC` LIKE '%$search%' OR `DETAIL` LIKE '%$search%') AND `TYPE`='ทั่วไป' AND `STATUS`='1' ORDER BY `CREATED`DESC LIMIT ".($page*15-15).",15";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<div id='allnotice1'>";
			while($result=mysql_fetch_array($dbquery)){
				$optionnew="";
				$optionupdate="";
				if($result['CREATED']>time()-172800)
					$optionnew="<img src='images/newnotice.gif' border='0' alt='กระทู้ใหม่'> ";
				if($result['CREATED']!=$result['UPDATE'] && $result['UPDATE']>time()-172800)
					$optionupdate=" <img src='images/update.gif' border='0' alt='กระทู้ถูกแก้ไข'>";
				$return.="<div  id='notice1$result[NOTICE_ID]' style='padding-left:10px;'><img src='images/icon_1.gif' border='0' > <a href='./viewnotice1.php?id=$result[NOTICE_ID]' target='_blank'>$result[TOPIC]$optionnew$optionupdate </a></div>
				";
			}
			// onmouseover='this.style.backgroundColor=\"#D1FFC1\"' onmouseout='this.style.backgroundColor=\"#F9F9F9\"'

			$return.="<div style='text-align:right;color:#669900;padding-right:20px;'>Page ".checkpage($num_rows,15,$page,"javascript:void xajax_getMainNotice1(",");")."</div></div>
			<div id='newnotice1' style='border:1px solid;background-color:#D1FFC1;position:absolute;top:350px;width:584px;height:600px;text-align:center;display:none;' >
				<br>หัวข้อ: <input type='text' id='topicnotice1' style='width:500px;'><br>
				เนื้อหา:<center><textarea id='topicdetail1' rows='20' cols='10' style='width:500px;height:400px;'></textarea></center><br>
				<iframe id='if1' style='width:500px;height:100px;' src='./upload/index.php?path=./file/' marginwidth='0' marginheight='0' frameborder='0' hspace='0' vspace='0' scrolling='yes'>
					
				</iframe><br>

				<a href='javascript:void submitNewNotice(1);'>
				<img src='images/Button/submit.gif' border='0' alt=''></a>
				<a href='javascript:void canceladd(1);'>
				<img src='images/Button/cancel.gif' border='0' alt=''></a>
			</div>";
			$returnsearch="<div>
				<a href='javascript:void viewsearch(1);'><img src='images/Button/search2.gif' border='0' alt='' ></a> ";
				//onclick='xajax.$(\"shsearch1\").style.top=mousePos.y-80+\"px\";xajax.$(\"shsearch1\").style.display=\"block\";xajax.$(\"txsearch1\").focus();' onmouseout='xajax.$(\"shsearch1\").style.display=\"none\";'
			if($_SESSION['ss_Status']=='online' && ($_SESSION['ss_Level']=='admin' || $_SESSION['ss_Level']=='lecturer')){
				$returnsearch.="<a href='javascript:void (xajax.$(\"newnotice1\").style.display=\"block\");xajax.$(\"if1\").src=\"./upload/index.php?path=./file/\";tinyMCE.addMCEControl(xajax.$(\"topicdetail1\"),\"MCEControlID1\");xajax.$(\"topicnotice1\").focus();'><img src='images/Button/add.gif' border='0' alt='' ></a>";
			}
			$returnsearch.="</div><div id='shsearch1' style='border:1px solid;background-color:#DDFFCA;left:150px;top:480px;width:200px;height:100px;position:absolute;z-index:0;display:none;' onmouseover='searchtime=100' onmouseout='searchtime=0'>
				<center><br>ค้นหา<input type='text' class='search' id='txsearch1'>
				<a href='javascript:void xajax_getMainNotice1(1,xajax.$(\"txsearch1\").value);'><img src='images/Button/search2.gif' border='0' alt=''></a></center>";
			$return.="</div>";


			$objResponse->addAssign("bt1","innerHTML",$returnsearch);
			$objResponse->addAssign("notice1","innerHTML",$return);
		}
		else $objResponse->addAlert("เกิดความผิดพลาด...$sql");
		return $objResponse;
	}

	?>