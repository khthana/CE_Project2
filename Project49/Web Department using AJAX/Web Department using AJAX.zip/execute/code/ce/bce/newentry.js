// JavaScript Document
function newEntry(){
	var tmpstr="<div>"+
					"<br>ชื่อเรื่อง  <input id='' type='text' style='width:300px'> หัวข้องาน <span id='spcate'></span><br><br>"+
					"<span></span>";
					"<textarea id='tdetail' rows='5' cols='80' style='width:700px;height:350px;'></textarea><br>"+
					"<input type='checkbox' value=''>รับคอมเมนต์ "+
					"<input type='checkbox' value=''>แสดงคอมเมนต์ <br><br>"+
					"<input type='submit' value='Submit' onclick='javascript:addEntry(\"add\");'></input> "+
					"<input type='submit' value='Draft' onclick='javascript:addEntry(\"draft\");'></input> "+
					"<input type='submit' value='View' onclick=\"tinyMCE.execInstanceCommand('MCEControlID','mcePreview');\"></input>"+
				"</div>";
	xajax.$('mainview').innerHTML=tmpstr;
	tinyMCE.addMCEControl(xajax.$('tdetail'),'MCEControlID');
	xajax_getCategory();
}
function addEntry(op){
	if(op=='add')
		alert(op);
	else
		alert(op);
	
}
