<?php
	require_once("../_Sessionstart.php");
	require_once("../connectdb.inc.php");
	require_once("../tool/xajax/xajax.inc.php");
	//*****************************************************************************************
	function getCategory(){
		global $dbname,$tb_bgcategory;
		$objResponse = new xajaxResponse();
		$sql="SELECT CATEGORY ";
		$sql.="FROM $tb_bgcategory ";
		//$sql.="WHERE PROFILE_NAME ='' ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<select id='tcategory'>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<option value='$result[CATEGORY]'>$result[CATEGORY]";
			}
			$return.="</select>";
			$objResponse->addAssign("spcate","innerHTML",$return);
		}
		else 
			$objResponse->addAlert(mysql_error());
		
		return $objResponse;
	}
	//*****************************************************************************************
	function addEntry(){
		global $dbname,$tb_bgentry;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO tb_bgentry ";
		$sql.="VALUES() ";
		return $objResponse;
	}
	//*****************************************************************************************
	function manageEntry(){
		global $dbname,$tb_bgentry,$tb_useraccount,$tb_student,$blog;
		$thaimount=array("ม.ค.","ก.พ.","มี.ค.","เม.ษ.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$objResponse = new xajaxResponse();
		$sql="SELECT en.ENTRY_ID,en.PROFILE_NAME,en.CATEGORY,en.CREATED,en.TITLE,en.IS_RECOMMEND,";
		$sql.="en.IS_DRAFT,en.COMMENT_ACCEPT,en.STATUS,st.STUDENT_ID,st.FIRST_NAME,st.LAST_NAME,st.DEPARTMENT ";
		$sql.="FROM $tb_bgentry en,$tb_useraccount ua,$tb_student st ";
		$sql.="WHERE en.PROFILE_NAME='$blog'";
		$sql.="AND en.USER_ID = ua.USER_ID ";
		$sql.="AND ua.STUDENT_ID = st.STUDENT_ID ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<div style='border:1px solid;'>
						<table width='100%'  border='0' cellspacing='0' cellpadding='0' align='left'>
						  <tr bgcolor='#B5D1EE' align='left'>
							<th scope='col'>&nbsp;&nbsp;สร้าง</th>
							<th scope='col'>เรื่อง</th>
							<th scope='col'>โดย</th>
							<th scope='col'>กลุ่มหัวข้อ</th>
							<th scope='col'>หัวข้อแนะนำ</th>
							<th scope='col'>สถานะ</th>
							<th scope='col'>ลบ</th>
						  </tr>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="
						  <tr bgcolor='#E6F2F2' align='left' >
							<td class='style1'>&nbsp;&nbsp;".date("d ",strtotime($result['CREATED'])).
							$thaimount[date("n",strtotime($result['CREATED']))]." ".
							(date("Y",strtotime($result['CREATED']))+543).
							"</td>
							<td class='style1'><a href='#'>$result[TITLE]</a></td>
							<td class='style1'><a title='$result[FIRST_NAME] $result[LAST_NAME] '>$result[STUDENT_ID]</a></td>
							<td class='style1'>$result[CATEGORY]</td>
							<td class='style1' id='re$result[ENTRY_ID]'>";
							if(!$result['IS_RECOMMEND'])
								$return.="<a href='javascript:void isRecommend(\"$result[ENTRY_ID]\");'><img src='images/recommend_off.gif'></a>";
							else
								$return.="<a href='javascript:void isNotRecommend(\"$result[ENTRY_ID]\");'><img src='images/recommend_on.gif'></a>";
							$return.="</td>
							<td class='style1' id='dr$result[ENTRY_ID]'>";
							if($result['IS_DRAFT'])
								$return.="<a href='javascript:void isNotDraft(\"$result[ENTRY_ID]\");'><img src='images/isdraft.gif'></a>";
							else
								$return.="<a href='javascript:void isDraft(\"$result[ENTRY_ID]\");'><img src='images/notdraft.gif'></a>";
							$return.="</td>
							<td class='style1' id='de$result[ENTRY_ID]'>";
							if($result['STATUS'])
								$return.="<a href='javascript:void isDelete(\"$result[ENTRY_ID]\");'><img src='images/delete1.gif'></a>";
							else
								$return.="<a href='javascript:void isNotdelete(\"$result[ENTRY_ID]\");'><img src='images/deleted.gif'></a>";
							"</td>
						 </tr>
						";
			}
			$return.="
						</table>
					</div>
			";
			$objResponse->addAssign("mainview","innerHTML",$return);
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		return $objResponse;
	}
	function changeRecommend($entry_id,$status){
		global $dbname,$tb_bgentry;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgentry ";
		$sql.="SET IS_RECOMMEND = '$status' ";
		$sql.="WHERE ENTRY_ID = '$entry_id' ";
		$sql.="LIMIT 1 ";
		if(!mysql_db_query($dbname,$sql)){
			$objResponse->addAlert(mysql_error());
		}
		return $objResponse;
	}
	function changeStatus($entry_id,$status){
		global $dbname,$tb_bgentry;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgentry ";
		$sql.="SET IS_DRAFT = '$status' ";
		$sql.="WHERE ENTRY_ID = '$entry_id' ";
		$sql.="LIMIT 1 ";
		if(!mysql_db_query($dbname,$sql)){
			$objResponse->addAlert(mysql_error());
		}
		return $objResponse;
	}
	function changeDel($entry_id,$status){
		global $dbname,$tb_bgentry;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgentry ";
		$sql.="SET STATUS = '$status' ";
		$sql.="WHERE ENTRY_ID = '$entry_id' ";
		$sql.="LIMIT 1 ";
		if(!mysql_db_query($dbname,$sql)){
			$objResponse->addAlert(mysql_error());
		}
		return $objResponse;
	}
	//*****************************************************************************************
	function manageBlog(){
		global $dbname,$tb_bgprofile,$tb_bgentry,$tb_bgcategory,$tb_bgfavourite,$tb_bglink,$tb_useraccount,$tb_student,$blog;
		$objResponse = new xajaxResponse();
		$sql="SELECT * ";
		$sql.="FROM $tb_bgcategory ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		$return="
			<table width='95%'  border='0' cellspacing='0' cellpadding='5'>
			  <tr bgcolor='#B5D1EE'>
				<th scope='col' align='center'>จัดการ กลุ่มหัวข้อ</th>
			  </tr>";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$return.="
				  <tr align='left' bgcolor='#E6F2F2'>
					<td class='style1'>&nbsp;&nbsp;<a href='#'>$result[CATEGORY]</a></td>
				  </tr>";
			}
		}
		else
			$objResponse->addAlert(mysql_error());
		$return.="
			  <tr bgcolor='#B5D1EE'>
				<td align='center' id='addcat'><strong><a href='javascript:void addCategory();' >เพิ่ม</a></strong></td>
			  </tr>
			</table>
			<br>
			";
			
		$sql="SELECT PROFILE_STATUS,ARCHIVE_STATUS,CATEGORY_STATUS,RECOMMEND_STATUS,FAVOURITES_STATUS,LINK_STATUS ";
		$sql.="FROM $tb_bgprofile ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		if($dbquery=mysql_db_query($dbname,$sql)){
			if($result=mysql_fetch_array($dbquery)){
				$return.="
					<table width='95%'  border='0' cellspacing='0' cellpadding='5'>
					  <tr bgcolor='#B5D1EE'>
						<th scope='col'>ตั้งค่าการแสดงผล</th>
					  </tr>
					  <tr align='left' bgcolor='#E6F2F2'>
						<td class='style1'>";
						if($result['PROFILE_STATUS'])
							$return.="<input type='checkbox' id='PROFILE_STATUS' checked onclick='javascript:void changeManage(\"PROFILE_STATUS\");'>แสดง ข้อมูลส่วนตัว<br>";
						else
							$return.="<input type='checkbox' id='PROFILE_STATUS' onclick='javascript:void changeManage(\"PROFILE_STATUS\");'>แสดง ข้อมูลส่วนตัว<br>";
						
						if($result['ARCHIVE_STATUS'])
							$return.="<input type='checkbox' id='ARCHIVE_STATUS' checked onclick='javascript:void changeManage(\"ARCHIVE_STATUS\");'>แสดง ประวัติ<br>";
						else
							$return.="<input type='checkbox' id='ARCHIVE_STATUS' onclick='javascript:void changeManage(\"ARCHIVE_STATUS\");'>แสดง ประวัติ<br>";
						
						if($result['CATEGORY_STATUS'])
							$return.="<input type='checkbox' id='CATEGORY_STATUS' checked onclick='javascript:void changeManage(\"CATEGORY_STATUS\");'>แสดง กลุ่มหัวข้อ<br>";
						else
							$return.="<input type='checkbox' id='CATEGORY_STATUS' onclick='javascript:void changeManage(\"CATEGORY_STATUS\");'>แสดง กลุ่มหัวข้อ<br>";
						
						if($result['RECOMMEND_STATUS'])
							$return.="<input type='checkbox' id='RECOMMEND_STATUS' checked onclick='javascript:void changeManage(\"RECOMMEND_STATUS\");'>แสดง หัวข้อแนะนำ<br>";
						else
							$return.="<input type='checkbox' id='RECOMMEND_STATUS' onclick='javascript:void changeManage(\"RECOMMEND_STATUS\");'>แสดง หัวข้อแนะนำ<br>";
						
						if($result['FAVOURITES_STATUS'])
							$return.="<input type='checkbox' id='FAVOURITES_STATUS' checked onclick='javascript:void changeManage(\"FAVOURITES_STATUS\");'>แสดง หัวข้อโปรด<br>";
						else
							$return.="<input type='checkbox' id='FAVOURITES_STATUS' onclick='javascript:void changeManage(\"FAVOURITES_STATUS\");'>แสดง หัวข้อโปรด<br>";
						
						if($result['LINK_STATUS'])
							$return.="<input type='checkbox' id='LINK_STATUS' checked onclick='javascript:void changeManage(\"LINK_STATUS\");'>แสดง แนะนำ link<br>";
						else
							$return.="<input type='checkbox' id='LINK_STATUS' onclick='javascript:void changeManage(\"LINK_STATUS\");'>แสดง แนะนำ link<br>";
			}
			$return.="</td>
				  </tr>
				  <tr bgcolor='#B5D1EE'>
					<td>&nbsp;</td>
				  </tr>
				</table>
			";
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		$sql="SELECT * ";
		$sql.="FROM $tb_bgfavourite ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return.="
				<br>
				<table width='95%'  border='0' cellspacing='0' cellpadding='5'>
				  <tr bgcolor='#B5D1EE'>
					<th scope='col'>ตั้งค่าบทความโปรด</th>
				  </tr>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="
				  <tr align='left' bgcolor='#E6F2F2'>
					<td class='style1'>
						<a href='$result[LINK]'>$result[DETAIL]</a>
					</td>
				  </tr>";
			}
			$return.="
				 <tr bgcolor='#B5D1EE'>
					<td id='addfav'><strong><a href='javascript:void addFavourite();' >เพิ่ม</a></strong></td>
				  </tr>
				</table>";
		}
		else
			$objResponse->addAlert(mysql_error());
		$objResponse->addAssign("mainview","innerHTML",$return);
		return $objResponse;
	}
	//*****************************************************************************************
	function changeManage($option,$value){
		global $dbname,$tb_bgprofile,$blog;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgprofile ";
		$sql.="SET $option = '$value' ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		$sql.="LIMIT 1 ";
		if(!mysql_db_query($dbname,$sql))
			$objResponse->addAlert(mysql_error());
		return $objResponse;
	}
	//*****************************************************************************************
	function submitCategory($category,$detail){
		global $dbname,$tb_bgcategory,$blog;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO $tb_bgcategory ";
		$sql.="VALUES('$category','$blog','$detail') ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(!mysql_db_query($dbname,$sql))
			$objResponse->addAlert(mysql_error());
		
		return $objResponse;
	}
	//*****************************************************************************************
	$xajax = new xajax();
	$xajax->registerFunction("getCategory");
	$xajax->registerFunction("manageEntry");
	$xajax->registerFunction("changeRecommend");
	$xajax->registerFunction("changeStatus");
	$xajax->registerFunction("changeDel");
	$xajax->registerFunction("manageBlog");
	$xajax->registerFunction("changeManage");
	$xajax->registerFunction("submitCategory");
	$xajax->processRequests();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>CE Manage Blog</title>
<link href="style.css" rel="stylesheet" type="text/css">
<?php $xajax->printJavascript('../tool/xajax/'); ?>
<!-- tinyMCE -->
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
<script language="javascript" type="text/javascript" src="./newentry.js"></script>
<script language="javascript" type="text/javascript" src="./manage.js"></script>
<!-- /tinyMCE -->
<style type="text/css">
<!--
.style1 {
	border-bottom:2px solid;
}
-->
</style>
</head>

<body class='site' onLoad="xajax_manageEntry();">
<center>
  <div>
		<img border="0" src="./BG/Logo_blog.png" >
		<table cellpadding='0' cellspacing="0" >
		<tr>
			<td height='40px' colspan="3" background="BG/top.jpg" style="border-bottom:1px solid;" align="center">
			<a href="javascript:void xajax_manageEntry();"><strong>จัดการบทความ</strong></a> 
			<a href="javascript:void xajax_manageBlog();"><strong>ตั้งค่าฺฺBlog</strong></a>
			<a href="./view.php?blog=<?php echo $blog?>"><strong>แสดงBlog</strong></a>
			</td>
		</tr>
		<tr >
			<td width='11px' background="BG/shadow-left.gif" >&nbsp;</td>
			<td width="748px">
				<div id="mainview" align="center">
				</div>
			</td>
			<td width='7px' background="BG/shadow-right.gif">&nbsp;</td>
		</tr>
		<tr >
			<td height='40px' colspan="3" background="BG/bot.jpg">&nbsp;</td>
		</tr>
	  </table>
	    

  </div>
</center>

</body>
</html>
