<?php
	require ('../tool/xajax/xajax.inc.php');
	require('./connectdb.inc.php');
	$id = $_GET['blog'];
	// ############# �ʴ���ª��ͧ͢ blog ���������������� #############�
	function getNewBlog($id){
		global $dbname;
		$objResponse = new xajaxResponse();

		$return="blog new:<hr />";
		$sql="SELECT * FROM blog_entry WHERE ENTRY_ID= '$id' ";  
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{
			while($result=mysql_fetch_array($dbquery))
				$return.="$result[DETAIL]<br />";
		}
		$objResponse->addAssign("newblog","innerHTML",$return);
		return $objResponse;
	}

		$xajax = new xajax();
    	$xajax->decodeUTF8InputOn();
		//$xajax->debugOn();
	   //register function �����¹������ xajax ���ѡ
	   $xajax->registerFunction("getNewBlog");
	   $xajax->processRequests();
	?>

	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv='content-type' content='text/html; charset=UTF-8' />
		<meta http-equiv='content-language' content='en' />
		<link rel='stylesheet' href='./default.css' type='text/css' />
		<title>Simple example</title>
		<!-- �ӡ�����ҧ function �ͧ javascript -->
		<?php $xajax->printJavascript('../tool/xajax/');?>
	</head>
	<body >
		<!-- <div  onload='xajax_getNewBlog();'> -->
		<? echo"
		<script langusge='JavaScript'>
							<!--
								xajax_getNewBlog('$id');
							-->
							</script>";
							?>
			<!-- <div id='login'></div> -->
			<div id='newblog'>newblog</div>
			
			<!-- <div id='blogvote'>blogvote</div> -->
		</div>
	</body>
</html>