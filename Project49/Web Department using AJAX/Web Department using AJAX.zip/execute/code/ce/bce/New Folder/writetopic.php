<?php
	require ('../tool/xajax/xajax.inc.php');
	require('./connectdb.inc.php');
	function inserttopic($title,$deteil,$comment){
		//session_start();
		global $dbname,$tb_topic;
		$sql="INSERT INTO blog_entry  ( `ENTRY_ID` , `CATEGORY` , `CREATED` , `TITLE` , `DETAIL` , `BY`, `IS_RECOMMEND`,`IS_DRAFT` ,`COMMENT_ACCEPT`  )VALUES('','','".date("Y-m-d H:i:s",time())."', '$title', '$deteil' ,'','', '0', '$comment')";
		//$return=$return.$sql."<br/>";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		mysql_db_query($dbname,$sql);
		$objResponse = new xajaxResponse();
		$objResponse->addScript("window.location('./entrylist.php');");
		return $objResponse;
	}

	$xajax = new xajax();
	//$xajax->debugOn();

	$xajax->registerFunction("inserttopic");
	$xajax->processRequests();
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8" />
<title>Simple example</title>
<?php $xajax->printJavascript('../tool/xajax/');?>
<!-- tinyMCE -->
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "emotions,nonbreaking,preview,table",
		
		plugin_preview_width : "700",
		plugin_preview_height : "600",
		theme_advanced_buttons1 : "bold,italic,underline,separator,justifyleft,justifycenter,justifyright, justifyfull,indent,outdent,bullist,numlist,separator,hr,nonbreaking,link,unlink,image,forecolor,backcolor,separator,fontselect,fontsizeselect,charmap,emotions",
		theme_advanced_buttons2 : "newdocument,undo,redo,removeformat,preview,code,tablecontrols",
		theme_advanced_buttons3 : "",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom"
	});
/*	function viewdata(){
		alert(tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')));
		tinyMCE.setContent("");
	}*/
</script>

</head>
<body>
	<div align='center'>
		<div id='all' style='width:710px;border:1px solid;'>
			<div style='border-bottom:1px solid #6600FF;background-color:#99CCFF;'>
				<br /><a style='margin:80px;'><?php echo iconv("tis-620","utf-8","<b>��������ͧ : </b>");?><input type='text' id='topic_title' size='40'/></a><br /><br />
			</div>
			<textarea id='topic_detail' name='elm1' rows='20' cols='85'></textarea> 
			<div style='border-top:1px solid #6600FF;background-color:#99CCFF;'>
				<b>comment :</b> <select id='comment_option'>
					<option value='0'>all user</option>
					<option value='1'>user only</option>
					<option value='2'>not comment</option>
				</select>
			</div>
			<div style='border-top:1px solid #6600FF;background-color:#99CCFF;'>
				<br />
				<input type='submit' value='Publish'  onclick="xajax_inserttopic(document.getElementById('topic_title').value,tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),document.getElementById('comment_option').value);"/> 
				
				<input type='submit' value='Save as Draft' 	onclick="xajax_inserttopic(document.getElementById('topic_title').value,tinyMCE.getContent(tinyMCE.getWindowArg('editor_id')),document.getElementById('comment_option').value);"/> 
				
			</div>
		</div>
	<div>
</body>
</html>