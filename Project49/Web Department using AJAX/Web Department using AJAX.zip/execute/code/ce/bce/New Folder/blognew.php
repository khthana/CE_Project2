﻿<?php
	require ('../tool/xajax/xajax.inc.php');
	require('./connectdb.inc.php');
	
	// ############# แสดงรายชื่อของ blog ที่เพิ่มเข้ามาใหม่ #############่
	function getNewBlog(){
		global $dbname;
		$objResponse = new xajaxResponse();
		$return="blog new:<hr />";
		$sql="SELECT * FROM blog_entry ORDER BY `TITLE`";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{
			while($result=mysql_fetch_array($dbquery))
				$return=$return.
				"<a href='./showdetail.php?blog=$result[ENTRY_ID]'>$result[TITLE]</a><br />";
		}
		$objResponse->addAssign("newblog","innerHTML",$return);
		return $objResponse;
	}

		$xajax = new xajax();
    	$xajax->decodeUTF8InputOn();
		//$xajax->debugOn();
	   //register function ที่เขียนไว้ให้ xajax รู้จัก
	   $xajax->registerFunction("getNewBlog");
	   $xajax->processRequests();
	?>

	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv='content-type' content='text/html; charset=UTF8' />
		<meta http-equiv='content-language' content='en' />
		<link rel='stylesheet' href='./default.css' type='text/css' />
		<title>Simple example</title>
		<!-- ทำการสร้าง function ของ javascript -->
		<?php $xajax->printJavascript('../tool/xajax/');?>
	</head>
	<body >
		<!-- <div  onload='xajax_getNewBlog();'> -->
		<script langusge='JavaScript'>
							<!--
								xajax_getNewBlog();
							-->
							</script>
			<!-- <div id='login'></div> -->
			<div id='newblog'>newblog</div>
			<!-- <div id='blogvote'>blogvote</div> -->
		</div>
	</body>
</html>