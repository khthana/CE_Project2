<?php
	require_once("./tool/xajax/xajax.inc.php");
	require_once("./_Sessionstart.php");
	require_once("./connectdb.inc.php");

	function update($notice_id,$detail){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_main_notice SET `DETAIL` = '$detail' , `UPDATE`='".time()."' WHERE `NOTICE_ID` ='$notice_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("แก้ไขข้อมูลเรียบร้อยแล้ว");
		}else $objResponse->addAlert("เกิดความผิดพลาด");
		return $objResponse;
	}
	function deleteNotice($notice_id){
		global $dbname,$tb_main_notice;
		$objResponse = new xajaxResponse();
		$sql="UPDATE `main_fileupload` SET `STATUS` = '0' WHERE `NOTICE_ID` ='$notice_id'";
		mysql_db_query($dbname,$sql);
		$sql="UPDATE `main_notice` SET `STATUS` = '0' WHERE `NOTICE_ID` ='$notice_id' LIMIT 1 ";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("ลบข้อมูลเรียบร้อยแล้ว หน้าต่างนี้จะถูกปิดทันที");
			$objResponse->addScript("window.close();");
		}else $objResponse->addAlert("เกิดความผิดพลาด");
		
		return $objResponse;
	}
	function deletefile($file_id){
		global $dbname,$tb_main_fileupload;
		$objResponse = new xajaxResponse();
		$sql="UPDATE `$tb_main_fileupload` SET `STATUS` = '0' WHERE `FILE_ID` ='$file_id' LIMIT 1";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addRemove('file'.$file_id);
		}
		return $objResponse;
	}
	$xajax = new xajax();
	//$xajax->debugOn();
	$xajax->registerFunction("update");
	$xajax->registerFunction("deleteNotice");
	$xajax->registerFunction("deletefile");
	$xajax->processRequests();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>
		<?php $xajax->printJavascript('./tool/xajax/'); ?>
		<script langusge='JavaScript'>
		<!--
			function edit(id){
				var tmp=xajax.$('detail').innerHTML;
				xajax.$('detail').innerHTML="<textarea id='textdetail' rows='25' cols='80' style='width:800px;'>"+xajax.$('detail').innerHTML+"</textarea>";
				tinyMCE.addMCEControl(xajax.$('textdetail'),'MCEControlID');
				xajax.$('button').innerHTML="<a href='javascript:void submitEdit("+id+");'><img src='./images/Button/submit.gif' border='0' alt='ส่ง'></a>"+
				"<a href='javascript:void cancel("+id+",\""+tmp+"\")'><img src='./images/Button/cancel.gif' border='0' alt='ยกเลิก'></a> ";
			}
			function cancel(id,olddetail){
				tinyMCE.removeMCEControl('MCEControlID');
				xajax.$('detail').innerHTML=olddetail;
				xajax.$('button').innerHTML="<a href='javascript:void edit("+id+");'><img src='./images/Button/edit.gif' border='0' alt='แก้ไข'></a>"+ 
				"<a href='javascript:void deleteNotice("+id+");'><img src='./images/Button/delete.gif' border='0' alt='ลบ'></a> ";
			}
			function submitEdit(id){
				if(confirm("คุณต้องการแก้ไขข้อมูลหรือไม่")){
					var tmp=tinyMCE.getContent('MCEControlID');
						tinyMCE.removeMCEControl('MCEControlID');
					xajax_update(id,tmp);
					xajax.$('detail').innerHTML=tmp;
					delete tmp;
					xajax.$('button').innerHTML="<a href='javascript:void edit("+id+");'><img src='./images/Button/edit.gif' border='0' alt='แก้ไข'></a>"+ 
								 "<a href='javascript:void deleteNotice("+id+");'><img src='./images/Button/delete.gif' border='0' alt='ลบ'></a> ";
				}
			}
			function deleteNotice(id){
				if(confirm("คุณต้องการลบข้อมูลหรือไม่")){
					xajax_deleteNotice(id);
				}
			}
		//-->
		</script>
		<script language="javascript" type="text/javascript" src="./tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript" src="./tool/tinymce/jscripts/tiny_mce/tiny_mce_init.js"></script>
		<title>ภาควิชาวิศวกรรมคอมพิวเตอร์</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style>
			body{
				font-size:13px;
				color:#000000;
			}
			a:link,a:visited{
				color:#000000;
				text-decoration:none;
			}
			a:hover{
				color:#B5B5B5;
				font-weight:bold;
			}
		</style>
		<?php $xajax->printJavascript('./tool/xajax/'); ?>
	</head>
	<body >
		<div align='center'>
			<?php
				$sql="SELECT * FROM $tb_main_fileupload WHERE NOTICE_ID='$id' AND STATUS='1'";
				mysql_db_query($dbname,"SET NAMES 'UTF8'");
				if($dbquery=mysql_db_query($dbname,$sql)){
					$typesize = array( 'bytes', 'Kb', 'Mb', 'Gb', 'Tb', 'Zb' );
					$strupload="เอกสารประกอบ<br>";
					while($result=mysql_fetch_array($dbquery)){
						$toEval=0;
						$filesize=$result['SIZE'];
						while($filesize > 1024 ) {
							$filesize = round(($filesize / 1024),2);
							$toEval++;
						}
						$filesize="$filesize $typesize[$toEval]";
						
						$strupload.="<div id='file$result[FILE_ID]'><a href='./upload/file/$result[NAME]'><img src='./images/$result[TYPE].jpg' border='0' alt=''> $result[NAME] $filesize </a> ";
						if($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level']=='lecturer')
							$strupload.="<a href='javascript:void xajax_deletefile($result[FILE_ID]);'><img src='images/delete.jpg' border='0' alt='ลบไฟล์'></a>";
						$strupload.="</div>";
					}
				}
				$sql="SELECT * FROM $tb_main_notice WHERE NOTICE_ID='$id' LIMIT 1";
				mysql_db_query($dbname,"SET NAMES 'UTF8'");
				if($dbquery=mysql_db_query($dbname,$sql)){
					while($result=mysql_fetch_array($dbquery)){
			?>
			<table border='0' cellpadding="0" cellspacing="0" width='850px' >
				<tr>
					<td  height="31" width='9px'>
					<img border="0" src="./images/blueheaderl.png"  height="31"></td>
					<td height="31" width='832px' background="./images/blueheader.png" align='center'>
						
						<?php echo "<b>เรื่อง $result[TOPIC]</b>";?>
					</td>
					<td height="31" width="9px"><img border="0" src="./images/blueheaderr.png" height="31"></td>
					
				</tr>
				<tr>
					<td  background='./images/contentboxl.png'></td>
					<td align='left' valign='top' style='padding:0px 30px;'><br><br>	
					<?php
						echo "<span id='detail'>$result[DETAIL]</span><br>";
						echo "<div align='right'>ประกาศเมื่อ ".date('j-n-Y  H:i น.',$result['CREATED'])." โดย $result[BY]</div><br><hr>";
						echo "$strupload<br>";
						if($_SESSION['ss_Level'] =='admin' || $_SESSION['ss_Level']=='lecturer')
							echo "<span id='button'><a href='javascript:void edit($id);'><img src='./images/Button/edit.gif' border='0' alt='แก้ไข'></a> 
			<a href='javascript:void deleteNotice($id);'><img src='./images/Button/delete.gif' border='0' alt='ลบ'></a> </span>";
					?>
					</td>
					<td height="31" background='./images/contentboxr.png'>&nbsp;</td>
				</tr>
				<tr>
					<td  >
					<img border="0" src="./images/contentboxbl.png"  ></td>
					<td  width='832px' background="./images/contentboxb.png" align='center'>
						
					</td>
					<td  ><img border="0" src="./images/contentboxbr.png" ></td>
				</tr>
			</table>
			<?php
					}
				}
			?>
		</div>
	</body>
	</html>

