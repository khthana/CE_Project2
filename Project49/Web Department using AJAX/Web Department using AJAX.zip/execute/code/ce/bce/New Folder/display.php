<?
	require_once('../tool/xajax/xajax.inc.php');
	require_once('./connectdb.inc.php');
	$id = $_GET['blog'];
		function getDisplayBlog($id){
		global $dbname;
		$objResponse = new xajaxResponse();

		$return="blog new:<hr />";
		$sql="SELECT * FROM blog_entry WHERE ENTRY_ID= '$id' ";  
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{
			while($result=mysql_fetch_array($dbquery))
				$return.="$result[DETAIL]<br />";
		}
		$objResponse->addAssign("newblog","innerHTML",$return);
		return $objResponse;
	}
		$xajax = new xajax();
    	$xajax->decodeUTF8InputOn();
	   $xajax->registerFunction("getDisplayBlog");
	   $xajax->processRequests();
?>


<html>
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="index.css" rel="stylesheet" type="text/css">
<title>New Page 1</title>
<?php $xajax->printJavascript('../tool/xajax/');?>
</head>

<body>

<table width="818" height="514" cellpadding="0" cellspacing="0">
	<tr>
		<td width="9" height="31" >
		<img border="0" src="./BG/blueheaderl.png" width="9" height="31"></td>
		<td width="800" height="31" background=".BG/contentboxbg.png">
		<img border="0" src="./BG/blueheader.png" width="800" height="31"></td>
		<td width="10" height="31">
		<img border="0" src="./BG/blueheaderr.png" width="9" height="31"></td>
	</tr>
	<tr>
		<td width="9" height="470">
		<img border="0" src="./BG/contentboxl.png" width="9" height="316"></td>
		<td height="470" valign="top">
		<? echo"
		<script langusge='JavaScript'>
							<!--
								xajax_getDisplayBlog('$id');
							-->
							</script>";
							?>
			<!-- <div id='login'></div> -->
			<div id='newblog'>newblog</div>
	  </td>
		<td width="10" height="470">
		<img border="0" src="./BG/contentboxr.png" width="9" height="316"></td>
	</tr>
	<tr>
		<td width="9" height="11" >
		<img border="0" src="./BG/contentboxbl.png" width="9" height="11"></td>
		<td height="11">
		<img border="0" src="./BG/contentboxb.png" width="800" height="3"></td>
		<td width="10" height="11">
		<img border="0" src="./BG/contentboxbr.png" width="9" height="11"></td>
	</tr>
</table>

<table cellpadding="0" cellspacing="0">
	<tr>
		<td width="9" height="31" >
		<img border="0" src="./BG/greenheaderl.png" width="9" height="31"></td>
		<td height="31">
		<img border="0" src="./BG/greenheader.png" width="481" height="31"></td>
		<td width="4" height="31">
		<img border="0" src="./BG/greenheaderr.png" width="9" height="31"></td>
	</tr>
	<tr>
		<td width="9">
		<img border="0" src="./BG/contentboxl.png" width="9" height="316"></td>
		<td>&nbsp;</td>
		<td width="4">
		<img border="0" src="./BG/contentboxr.png" width="9" height="316"></td>
	</tr>
	<tr>
		<td width="9" height="11" >
		<img border="0" src="./BG/contentboxbl.png" width="9" height="11"></td>
		<td height="11">
		<img border="0" src="./BG/contentboxb.png" width="479" height="3"></td>
		<td width="4" height="11">
		<img border="0" src="./BG/contentboxbr.png" width="9" height="11"></td>
	</tr>
</table>

</body>

</html>