<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>&#3619;&#3632;&#3610;&#3610;&#3592;&#3633;&#3604;&#3585;&#3634;&#3619;&#3610;&#3621;&#3629;&#3588;</title>
<style type="text/css">
<!--
body {
	margin-left: 1px;
	margin-top: 1px;
	margin-right: 1px;
	margin-bottom: 1px;
}
-->
</style></head>

<body>
<table width="100%" height="800" border="0" cellpadding="0"> 
  <tr>
    <td align="center" valign="top"><table width="60%" height="562" border="1" cellpadding="0" cellspacing="0" bordercolor="#CCCCCC">
      <tr>
        <td height="403" align="center" valign="top"><div align="center">
          <table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td height="94" align="center" valign="top"><div align="center"><img src="./picture/logo.jpg" width="600" height="100" /></div></td>
            </tr>
          </table>
          <table width="75%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td height="38"><a href="writetopic.php" target="showblog"><img src="./picture/new_entry3.jpg" width="100" height="33" border="0"/></a></td>
              <td><a href="entrylist.php" target="showblog"><img src="./picture/manage_entries3.jpg" width="100" height="33" border="0" /></td>
              <td><img src="./picture/preferences3.jpg" width="100" height="33" border="0" /></td>
              <td><img src="./picture/themes3.jpg" width="100" height="33" border="0" /></td>
              <td><img src="./picture/manage_file3.jpg" width="100" height="33" border="0" /></td>
              <td><img src="./picture/exit3.jpg" width="100" height="33" border="0" /></td>
            </tr>
          </table>
          <table width="90%" height="505" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td height="501" valign="top"><iframe name="showblog" src="writetopic.php"   scrolling="no" frameborder="no"  width="740" height="800" align="center"></iframe></td>
            </tr>
          </table>
        </div></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
