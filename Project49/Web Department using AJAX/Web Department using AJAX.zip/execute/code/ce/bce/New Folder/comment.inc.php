 <?
// �ʴ� comment �ѧ����ͧ ��Ǣ�͹��
	function getComment($entry_id,$comment_option){
		//session_start();
		global $dbname;
		$objResponse = new xajaxResponse();
		$commentdetail="<hr />";
		$sql="SELECT * FROM blog_comment WHERE ENTRY_ID='$entry_id'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
			while($result=mysql_fetch_array($dbquery)){
				$commentdetail.="
					<div id='comment$result[COMMENT_ID]'>
						<a id='commentdetail$result[COMMENT_ID]' style='background-color:#DFFDFD;'>".
							nl2br($result['DETAIL'])."
						</a> <br />
						by:<a href='./index.php?blog=$result[BY]'>$result[BY]</a> 
						at:$result[CREATED]";
				$commentdetail.="<hr /></div>";
			} 
		return $objResponse;
	}
	//########��͹ comment ���  ################################
	function hideComment($entry_id,$comment_option){
		$objResponse = new xajaxResponse();
		$objResponse->addAssign("showhide$entry_id","href","javascript:void xajax_getComment($entry_id,$comment_option);");
		$objResponse->addAssign("showhide$entry_id","innerHTML","show");
		$objResponse->addAssign("allcomment$entry_id","innerHTML","");
		$objResponse->addAssign("formcomment$entry_id","innerHTML","");
		return $objResponse;
	}
	//#######���� comment ###################################
	function addComment($entry_id,$commentdetail){
		//session_start();
		global $dbname;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO blog_comment  ( `COMMENT_ID` , `ENTRY_ID` , `DETAIL` ,  `CREATED` , `BY` ,`STATUS` )VALUES ('', '$entry_id', '$commentdetail', NOW( ) , '')";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		$dbquery=mysql_db_query($dbname,$sql);
		$sql="SELECT MAX(COMMENT_ID) FROM blog_comment ";
		$result=mysql_fetch_array(mysql_db_query($dbname,$sql));
		$commentdetail=nl2br($commentdetail);
		$return="
			<div id='comment$result[0]'>
				<a id='commentdetail$result[0]' style='background-color:#DFFDFD;'>
					$commentdetail
				</a> <br />
				<hr />
			</div>";
		$objResponse->addScript("var countcomment=document.getElementById(\"number_comment$entry_id\");countcomment.innerHTML=Number(countcomment.innerHTML)+1;");
		$objResponse->addAssign("txtcomment$entry_id","value","");
		$objResponse->addAppend("allcomment$entry_id","innerHTML",$return);
		return $objResponse;
	}
 ?>