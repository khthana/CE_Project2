<?php
	require_once("../tool/xajax/xajax.inc.php");
	require_once('./connectdb.inc.php');
	

	function getNewBlog(){
		global $dbname;
		$objResponse = new xajaxResponse();
		$return="<table  width='100%' border='1' cellpadding='0' cellspacing='0'> <tr bgcolor='#D0E0F9'>
						<td  width='25%'><b>Y-M-D/H:I:S</b></td >
						<td  width='45%'><b>Title</b></td >
						<td  width='20%'><b>category</b></td >
						<td  width='20%'></td>
						</tr></table>";     
		$sql="SELECT * FROM blog_entry ORDER BY `CREATED` ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{ 
			while($result=mysql_fetch_array($dbquery))
			{
					$return.="<div class='topicdetail' id='d$result[ENTRY_ID]'>
											<div align='center'><font size='3' color='#FF0000'>Title </font>
											<span id='dt$result[ENTRY_ID]'>$result[TITLE]</span></div>
											<pre id='dd$result[ENTRY_ID]'>$result[DETAIL]</pre>
											<div id='dl$result[ENTRY_ID]'>
											<a href='javascript:void editTopicDetail($result[ENTRY_ID]);'>edit</a> 
											<a href='javascript:void hideTopicDetail($result[ENTRY_ID]);'>close</a>
											</div><br></div>";
						$return.=" <div class='topic' id='$result[ENTRY_ID]'>	 
											<span class='topic2'>$result[CREATED]</span> 
											<div class='topic4' id='tp1$result[ENTRY_ID]' ></div>	
											<a href='./displays.php?blog=$result[ENTRY_ID]' target='parent'>$result[TITLE]</a> 
											<span class='topic3'><a href='javascript:void calldeleteTopic($result[ENTRY_ID]);'>
											<img src='./images/pubtrue.gif' border='0'></a></span>
											<span class='topic4'  >
											<a href='javascript:void  editTopicDetail($result[ENTRY_ID]);viewTopicDetail($result[ENTRY_ID]);''>
											<img src='./images/edit.jpg' border='0' alt='แก้ไขหัวข้อนี้'></a>
											<a href='javascript:void calldeleteTopic($result[ENTRY_ID]);'>
											<img src='./images/delete.jpg' border='0' alt='ลบหัวข้อนี้'></a></span>
											<a href='javascript:void hideSubjectDetail($result[ENTRY_ID]);'></a></span></div></div>";	 
			}	   
		}		
		$objResponse->addAssign("alltopic","innerHTML",$return);
		$objResponse->addScript("TempTopic=new Array();TempDetail=new Array();");
		return $objResponse;
	}	
		function calldeleteTopic($entry_id){
		global $dbname;
		$objResponse = new xajaxResponse();
		$sql="DELETE FROM blog_entry WHERE `ENTRY_ID` = $entry_id ";
		if(mysql_db_query($dbname,$sql)){
				$objResponse->addAlert("compless...");
		}
		else
				$objResponse->addAlert("error...");
		return $objResponse;
	} 
		function submitTopicDetail($entry_id,$title,$detail){
		global $dbname;
		$objResponse = new xajaxResponse();
		$sql="UPDATE blog_entry  SET `TITLE` = '$title' ,`DETAIL` = '$detail' WHERE `ENTRY_ID` ='$entry_id' LIMIT 1 ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(mysql_db_query($dbname,$sql)){
				$objResponse->addAlert("complate...");
		}
		else
				$objResponse->addAlert("error...");
		return $objResponse;
	}
		$xajax = new xajax();
		$xajax->decodeUTF8InputOn();
		$xajax->registerFunction("getNewBlog");
		 $xajax->registerFunction("calldeleteTopic");
		$xajax->registerFunction("submitTopicDetail");
		$xajax->processRequests();
	?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>��ͤ</title>
<link href="index.css" rel="stylesheet" type="text/css">
<?php $xajax->printJavascript('../tool/xajax/');?>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 00px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>
  <!-- tinyMCE -->
		<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
		<script language="javascript" type="text/javascript">
			tinyMCE.init({
				mode : "none",
				theme : "advanced",
				plugins : "emotions,nonbreaking,preview,table",
				
				plugin_preview_width : "800",
				plugin_preview_height : "600",
				theme_advanced_buttons1 : "bold,italic,underline,separator,justifyleft,justifycenter,justifyright, justifyfull,indent,outdent,bullist,numlist,separator,hr,nonbreaking,link,unlink,image,forecolor,backcolor,separator,fontselect,fontsizeselect,charmap,emotions",
				theme_advanced_buttons2 : "newdocument,undo,redo,removeformat,preview,code,tablecontrols",
				theme_advanced_buttons3 : "",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_path_location : "bottom"
			});
		</script>
		<!-- /tinyMCE -->
		
		<script langusge='JavaScript'>
		<!--
		function calldeleteTopic(entry_id){
										if(confirm('Want Delete...'))	{
											xajax.$('alltopic').removeChild(xajax.$(entry_id));
											xajax.$('alltopic').removeChild(xajax.$('d'+entry_id));
											xajax_calldeleteTopic(entry_id);
										}	
								}	   
								function editTopicDetail(entry_id){
										TempTopic[entry_id]=xajax.$('dt'+entry_id).innerHTML;
										TempDetail[entry_id]=xajax.$('dd'+entry_id).innerHTML;
										xajax.$('dt'+entry_id).innerHTML="<input type='text'size='100' id='dtt"+entry_id+"' value='"+xajax.$('dt'+entry_id).innerHTML+"' >";
										xajax.$('dd'+entry_id).innerHTML="<textarea id='ddt"+entry_id+"' rows='15' cols='85' style='width:680px;overflow:hidden;'>"+xajax.$('dd'+entry_id).innerHTML+"</textarea>";
										xajax.$('dl'+entry_id).innerHTML="<a href='javascript:void submitTopicDetail("+entry_id+");'> <center>Save as Draft</center></a> <a href='javascript:void cancleTopicDetail("+entry_id+");'><center>cancle</center></a>";
										tinyMCE.addMCEControl(xajax.$('ddt'+entry_id),'MCEControlID'+entry_id);
								}
								
									function submitTopicDetail(entry_id){
										if(confirm("want save...")){
											xajax_submitTopicDetail(entry_id,xajax.$('dtt'+entry_id).value,tinyMCE.getContent('MCEControlID'+entry_id));
											tinyMCE.removeMCEControl('MCEControlID'+entry_id);
											xajax.$('tp1'+entry_id).innerHTML="<a href='javascript:void viewTopicDetail("+entry_id+");'>"+xajax.$('dtt'+entry_id).value+"</a>";
										    xajax.$('dt'+entry_id).innerHTML=xajax.$('dtt'+entry_id).value;
											xajax.$('dd'+entry_id).innerHTML=xajax.$('ddt'+entry_id).value;
											xajax.$('dl'+entry_id).innerHTML="<a href='javascript:void editTopicDetail("+entry_id+");'> edit </a> <a href='javascript:void hideTopicDetail("+entry_id+");'>close</a>";	 
											}
										}
											function viewTopicDetail(entry_id){
												xajax.$(entry_id).style.display="none";
												xajax.$('d'+entry_id).style.display="block";
											}	
											function hideTopicDetail(entry_id){
												xajax.$('d'+entry_id).style.display="none";
												xajax.$(entry_id).style.display="block";
											}
									function cancleTopicDetail(entry_id){
												tinyMCE.removeMCEControl('MCEControlID'+entry_id);
												xajax.$('dt'+entry_id).innerHTML=TempTopic[entry_id];
												xajax.$('dd'+entry_id).innerHTML=TempDetail[entry_id];
												xajax.$('dl'+entry_id).innerHTML="<a href='javascript:void editTopicDetail("+entry_id+");'> edit</a> <a href='javascript:void hideTopicDetail("+entry_id+");'>close</a>";		
											}	
							-->
				</script>

<body>
<table width="100%" height="600" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" valign="top"><table width="100%" height="301" border="1" cellpadding="0" cellspacing="0">
      <tr>
        <td width="26%" height="299" valign="top" background="images/image002.gif"><!-- <table width="100%" border="1" cellpadding="0" cellspacing="0">
          <tr>
            <td height="111">&nbsp;1</td>
          </tr>
        </table> -->
          <!-- <table width="100%" border="1" cellpadding="0" cellspacing="0">
            <tr>
              <td height="91">&nbsp;2</td>
            </tr>
          </table></td> -->
        <td width="74%" valign="top">
          <table width="100%" height="262" border="0" cellpadding="0" cellspacing="1">
            <tr>
              <td align="left" valign="top"><script langusge='JavaScript'>
							<!--
								xajax_getNewBlog();
								
							-->
							</script>
							
							<div id='alltopic'></div> 
						
							
	            <p>&nbsp;</p></td>
							
            </tr>
          </table>
          </td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
