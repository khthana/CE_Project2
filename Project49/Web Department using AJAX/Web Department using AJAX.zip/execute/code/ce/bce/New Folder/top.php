<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
		<link href="style.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="javafunction.js"></script>
		<title>top page
		</title>
	</head>
	<body>
		<div align="center">
			<IMG SRC="picture/logo.jpg" WIDTH="600" HEIGHT="100" BORDER="0" ALT="">
		</div>
		<div align="center" style="cursor:hand">
			<IMG id="img1" SRC="picture/new_entry1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img1','picture/new_entry1.jpg')"  onmouseover="changepic('img1','picture/new_entry2.jpg')"  onmouseup="changepic('img1','picture/new_entry2.jpg')" onmousedown="changepic('img1','picture/new_entry3.jpg')" >

			<IMG id="img2" SRC="picture/manage_entries1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img2','picture/manage_entries1.jpg')"  onmouseover="changepic('img2','picture/manage_entries2.jpg')"  onmouseup="changepic('img2','picture/manage_entries2.jpg')" onmousedown="changepic('img2','picture/manage_entries3.jpg')" >

			<IMG id="img3" SRC="picture/preferences1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img3','picture/preferences1.jpg')"  onmouseover="changepic('img3','picture/preferences2.jpg')"  onmouseup="changepic('img3','picture/preferences2.jpg')" onmousedown="changepic('img3','picture/preferences3.jpg')" >

			<IMG id="img4" SRC="picture/themes1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img4','picture/themes1.jpg')"  onmouseover="changepic('img4','picture/themes2.jpg')"  onmouseup="changepic('img4','picture/themes2.jpg')" onmousedown="changepic('img4','picture/themes3.jpg')" >

			<IMG id="img5" SRC="picture/manage_file1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img5','picture/manage_file1.jpg')"  onmouseover="changepic('img5','picture/manage_file2.jpg')"  onmouseup="changepic('img5','picture/manage_file2.jpg')" onmousedown="changepic('img5','picture/manage_file3.jpg')" >

			<IMG id="img6" SRC="picture/exit1.jpg" WIDTH="100" HEIGHT="33" BORDER="0" ALT="" onmouseout="changepic('img6','picture/exit1.jpg')"  onmouseover="changepic('img6','picture/exit2.jpg')"  onmouseup="changepic('img6','picture/exit2.jpg')" onmousedown="changepic('img6','picture/exit3.jpg')" >
		</div>
	</body>
</html>