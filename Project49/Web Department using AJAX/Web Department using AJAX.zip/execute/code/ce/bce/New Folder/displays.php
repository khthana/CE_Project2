<?
	require_once('../tool/xajax/xajax.inc.php');
	require_once('./connectdb.inc.php');
	$blog = $_GET['blog'];
	function getDisplayBlog($blog){
		global $dbname;
		$returndata="";
		$objResponse = new xajaxResponse();
		$sql="SELECT * FROM blog_entry WHERE ENTRY_ID='$blog'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
			while($result=mysql_fetch_array($dbquery))
				{
					$sql1="SELECT COUNT(*) FROM blog_comment  WHERE ENTRY_ID='$result[ENTRY_ID]'";
					$dbquery1=mysql_db_query($dbname,$sql1);
					$result1=mysql_fetch_array($dbquery1);
					$returndata.="
						<a class='topictitle' href=''>$result[TITLE]</a><br>
						<div class='topicdetail'>$result[DETAIL]<hr /></div>
						<a class='topiccreate'>Create at: ".date('d_m_',$result['CREATE']).(date('Y ',$result['CREATE'])+543).date(' G:i:s',$result['CREATE'])."</a>
						comment(<a id='number_comment$result[ENTRY_ID]'>$result1[0]</a>)";
					if($result['COMMENT_ACCEPT']<2 ){
							$returndata.="
								<a id='showhide$result[ENTRY_ID]' class='commentlink' href='javascript:void xajax_getComment($result[ENTRY_ID],$result[COMMENT_ACCEPT]);'>comment</a>
								<div id='allcomment$result[ENTRY_ID]'></div>
								<div id='formcomment$result[ENTRY_ID]' align='center'></div>
								";	
								}
					//$returndata.="<hr />";
				}
		$objResponse->addAssign("bodyleft","innerHTML",$returndata);
		return $objResponse;
	}
	function getComment($entry_id,$comment_option){
		//session_start();
		global $dbname;
		$objResponse = new xajaxResponse();
		$commentdetail="<hr />";
		$sql="SELECT * FROM blog_comment WHERE ENTRY_ID='$entry_id'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
			while($result=mysql_fetch_array($dbquery)){
				$commentdetail.="
					<div id='comment$result[COMMENT_ID]'>
						<a id='commentdetail$result[COMMENT_ID]' >".
							nl2br($result['DETAIL'])."
						</a> <br />
						by:<a href='./index.php?blog=$result[BY]'>$result[BY]</a> 
						at:$result[CREATED]";
				$commentdetail.="<hr /></div>";
			}
			$formcomment="
				<textarea id='txtcomment$entry_id' rows='10' cols='50'></textarea></br>
				<a id='linksubmitcomment$entry_id' href='javascript:void
				  	 xajax_addComment($entry_id,document.getElementById(\"txtcomment$entry_id\").value);'>
					<img id='submitcomment$entry_id' src='./images/submit.jpg' border=0 />
				</a>
			";
				//xajax_addComment($entry_id,document.getElementById(\"txtcomment$entry_id\").value);'>
				//xajax.$('dtt'+entry_id).value	
			$objResponse->addAssign("Comment","innerHTML",$commentdetail);
			$objResponse->addAssign("formcomment$entry_id","innerHTML",$formcomment);
			$objResponse->addAssign("showhide$entry_id","href","javascript:void xajax_hideComment($entry_id,$comment_option)");
		   $objResponse->addAssign("showhide$entry_id","innerHTML","hide");
		   return $objResponse;	
	}
	function hideComment($entry_id,$comment_option){
		$objResponse = new xajaxResponse();
		$objResponse->addAssign("showhide$entry_id","href","javascript:void xajax_getComment($entry_id,$comment_option);");
		$objResponse->addAssign("showhide$entry_id","innerHTML","comment");
		$objResponse->addAssign("allcomment$entry_id","innerHTML","");
		$objResponse->addAssign("formcomment$entry_id","innerHTML","");
		return $objResponse;
	}
	function addComment($entry_id,$commentdetail)	 {
		   global $dbname;
		   $objResponse = new xajaxResponse();
		   $sql="INSERT INTO blog_comment  ( `COMMENT_ID` , `ENTRY_ID` , `DETAIL` ,`CREATED`,`BY`,`LINK`,`STATUS` )VALUES ('', '$entry_id', '$commentdetail', NOW( ) , '', '', '')";
		   mysql_db_query($dbname,"SET NAMES 'UTF8'");
		   $dbquery=mysql_db_query($dbname,$sql);	  
		   $sql="SELECT MAX(COMMENT_ID) FROM blog_comment";
	 	   $result=mysql_fetch_array(mysql_db_query($dbname,$sql));
		   $commentdetail=nl2br($commentdetail);
		   $return="
			<div id='comment$result[0]'>
				<a id='commentdetail$result[0]' style='background-color:#DFFDFD;'>
					$commentdetail</a><br />";
		   $objResponse->addScript("var countcomment=document.getElementById(\"number_comment$entry_id\");countcomment.innerHTML=Number(countcomment.innerHTML)+1;");
		$objResponse->addAssign("txtcomment$entry_id","value","");
		$objResponse->addAppend("allcomment$entry_id","innerHTML",$return);
		return $objResponse;
	}
	function  getCategory(){
		global $dbname;
		$objResponse = new xajaxResponse();
		$return="Category:<hr />";
		$sql="SELECT * FROM blog_category  ORDER BY   `CATEGORY` DESC  ";  
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{
			while($result=mysql_fetch_array($dbquery))
				$return.="<a href='javascript:void show($result[CATEGORY]);'> $result[CATEGORY]</a><br />";	
		}
	
		$return.="<hr />Comment Alert:<hr />";
		$objResponse->addAssign("category","innerHTML",$return);
		return $objResponse;
	}	  
		$xajax = new xajax();
    	$xajax->decodeUTF8InputOn();
		//$xajax->debugOn();
	   $xajax->registerFunction("getDisplayBlog");
	    $xajax->registerFunction("getCategory");
		$xajax->registerFunction("getComment");
		$xajax->registerFunction("addComment");
		 $xajax->registerFunction("hideComment");
	   $xajax->processRequests();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- <link rel='stylesheet' href='./default.css' type='text/css' /> -->
<title>Display blog</title>
<?php $xajax->printJavascript('../tool/xajax/');?>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image: url();
}
#Layer1 {
	position:absolute;
	left:209px;
	top:23px;
	width:721px;
	height:600px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	left:37px;
	top:76px;
	width:113px;
	height:262px;
	z-index:2;
}
#Layer3 {
	position:absolute;
	left:173px;
	top:6px;
	width:734px;
	height:708px;
	z-index:1;
}
#Layer4 {
	position:absolute;
	left:26px;
	top:61px;
	width:100px;
	height:203px;
	z-index:2;
}
-->
</style>
<script language="javascript" type="text/javascript">
<!--
	/*function getComment(entry_id,comment_option){
		 xajax_getComment(entry_id,comment_option);
}	
	function hideComment(entry_id,comment_option){
		xajax_hideComment(entry_id,comment_option);
	}	  */
//-->
</script>
</head>

<body>
<div id="Layer3">
  <table width="100%" height="450" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td height="450" align="right" valign="top"><table width="100%" height="100" border="1" cellpadding="0" cellspacing="0" bordercolor="#666666">
        <tr>
          <td align="left" background="BG/bgsteel2.jpg"><img src="BG/show.jpg" alt="" /></td>
        </tr>
      </table>
        <table width="100%" height="350" border="1" cellpadding="0" cellspacing="0" bordercolor="#666666">
          <tr>
            <td width="76%" height="348" align="left" valign="top">
			<? echo"
		      <script langusge='JavaScript'>
							<!--
								xajax_getDisplayBlog('$blog');
							-->
							</script>";
							?>
			<div id='bodyleft'>bodyleft</div>
			<div id='Comment'></div></td> 
            <td width="24%" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="285" align="left" valign="top">
				 <script langusge='JavaScript'>
						<!--
							xajax_getCategory();
						-->
						</script>
						<div id='category'></div></td>
				</td>
              </tr>
            </table></td>
          </tr>
      </table></td>
    </tr>
  </table>
</div>
<div id="Layer4">
  <table width="100%" height="202" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td height="202" background="./BG/tab_on_bck.gif">&nbsp;</td>
    </tr>
  </table>
</div>
</body>
</html>
