// JavaScript Document
function isRecommend (entry_id){
	xajax_changeRecommend(entry_id,1);
	xajax.$('re'+entry_id).innerHTML="<a href='javascript:void isNotRecommend(\""+entry_id+"\");'><img src='images/recommend_on.gif'></a>";
}
function isNotRecommend (entry_id){
	xajax_changeRecommend(entry_id,0);
	xajax.$('re'+entry_id).innerHTML="<a href='javascript:void isRecommend(\""+entry_id+"\");'><img src='images/recommend_off.gif'></a>";
}
function isDraft(entry_id){
	xajax_changeStatus(entry_id,1);
	xajax.$('dr'+entry_id).innerHTML="<a href='javascript:void isNotDraft(\""+entry_id+"\");'><img src='images/isDraft.gif'></a>";
}
function isNotDraft(entry_id){
	xajax_changeStatus(entry_id,0);
	xajax.$('dr'+entry_id).innerHTML="<a href='javascript:void isDraft(\""+entry_id+"\");'><img src='images/notDraft.gif'></a>";
}
function isDelete(entry_id){
	xajax_changeDel(entry_id,0);
	xajax.$('de'+entry_id).innerHTML="<a href='javascript:void isNotdelete(\""+entry_id+"\");'><img src='images/deleted.gif'></a>";
}
function isNotdelete(entry_id){
	xajax_changeDel(entry_id,1);
	xajax.$('de'+entry_id).innerHTML="<a href='javascript:void isDelete(\""+entry_id+"\");'><img src='images/delete1.gif'></a>";
}
function changeManage(option){
	if(xajax.$(option).checked)
		xajax_changeManage(option,1)
	else
		xajax_changeManage(option,0)
}
function addCategory(){
	xajax.$('addcat').innerHTML="<div align='left' valign='top'>หัวข้องาน&nbsp;&nbsp; <input type='text' id='ttitle' size='90'><br>"+
								"รายละเอียด<textarea id='tdetail' cols='70' rows='10' ></textarea><br>"+
								"<center><input type='submit' value='Submit' onclick='submitCategory();'> "+
								"<input type='submit' value='Cancel' onclick='cancleCategory();'></center></div>";
}
function submitCategory(){
	if(xajax.$('ttitle').value==''){
		alert("กรุณากรอหข้อมูลให้ครบ");
		xajax.$('ttitle').focus();	
	}
	else if(xajax.$('tdetail').value==''){
		alert("กรุณากรอหข้อมูลให้ครบ");
		xajax.$('tdetail').focus();
	}
	else{
		xajax_submitCategory(xajax.$('ttitle').value,xajax.$('tdetail').value);
		cancleCategory();
	}
}
function cancleCategory(){
	xajax.$('addcat').innerHTML="<strong><a href='javascript:void addCategory();' >เพิ่ม</a></strong>";
}
function addFavourite(){
	xajax.$('addfav').innerHTML="<div align='left' valign='top'>link <input type='text' id='ttitle' size='50' value='http://'><br>"+
								"รายละเอียด<input id='tdetail' size='50' ><br>"+
								"<center><input type='submit' value='Submit' onclick='submitFavourite();'> "+
								"<input type='submit' value='Cancel' onclick='cancleFavourite();'></center></div>";
}
function submitFavourite(){
	cancleFavourite();
}
function cancleFavourite(){
	xajax.$('addfav').innerHTML="<strong><a href='javascript:void addFavourite();' >เพิ่ม</a></strong>";
}