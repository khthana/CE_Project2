// JavaScript Document
function showComment(entry_id){
	xajax.$('comment'+entry_id).style.display='block';
	xajax.$('c'+entry_id).innerHTML="<br><strong><a href='javascript:void hideComment("+entry_id+");'>ซ่อนคอมเม้นท์</a></strong>"
}
function hideComment(entry_id){
	xajax.$('comment'+entry_id).style.display='none';
	xajax.$('c'+entry_id).innerHTML="<br><strong><a href='javascript:void showComment("+entry_id+");'>แสดงคอมเม้นท์</a></strong>"
}
function addComment(entry_id){
	var d = new Date();
	var tmpstr="<br id='commentidb"+entry_id+"'><div id='commentid"+entry_id+"' style='width:550px;border:1px solid;padding-left:20px;'>"+
				xajax.$('cdetail'+entry_id).value+"<br>"+
				"โดย "+xajax.$('cname'+entry_id).value+" เมื่อ "+
				d.getYear()+"-"+d.getMonth()+"-"+d.getDate()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+"<br>"+
			"</div>";
	xajax.$('allcomment'+entry_id).innerHTML=tmpstr+xajax.$('allcomment'+entry_id).innerHTML;
	xajax.$('cname'+entry_id).value="";
	xajax.$('cdetail'+entry_id).value="";
}	