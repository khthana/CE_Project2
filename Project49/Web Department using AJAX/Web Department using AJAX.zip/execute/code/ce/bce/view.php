<?php
	if(!isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online"){
		session_start();
		if( !isset($_SESSION['ss_Status']) or $_SESSION['ss_Status']!="online"){
			$_SESSION['ss_UserID']=0;
			$_SESSION['ss_UserName']="anonymous";
			$_SESSION['ss_Level']="guest";
			$_SESSION['ss_Status']="offline";
			$_SESSION['ss_privcode']="A";
			$_SESSION['ss_point']=100;
			$_SESSION['ss_LoginTime']=0;
		}
	}
	require_once('../tool/xajax/xajax.inc.php');
	require_once('../connectdb.inc.php');
	//**********************************************************************************************************
	function init(){
		global $dbname,$tb_bgprofile,$tb_bgentry,$tb_bgcategory,$tb_bgfavourite,$tb_bglink,$tb_lecturer,$tb_subject_lecturer,$blog;
		global $tb_student,$tb_subject_student,$tb_subject;
		$objResponse = new xajaxResponse();
		$sql="SELECT * ";
		$sql.="FROM $tb_bgprofile ";
		$sql.="WHERE PROFILE_NAME='$blog' ";
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="";
			if($result=mysql_fetch_array($dbquery)){
				$_SESSION['NEW_ENTRY']=$result['NEW_ENTRY'];
				$_SESSION['PROFILE']=$result['PROFILE_STATUS'];
				$_SESSION['ARCHIVE']=$result['ARCHIVE_STATUS'];
				$_SESSION['CATEGORY']=$result['CATEGORY_STATUS'];
				$_SESSION['RECOMMEND']=$result['RECOMMEND_STATUS'];
				$_SESSION['FAVOURITES']=$result['FAVOURITES_STATUS'];
				$_SESSION['LINK']=$result['LINK_STATUS'];
				$_SESSION['THEME']=$result['THEME'];
				
				$return.="<div class='menuright'>";
				
				if($_SESSION['ss_Status']=="online" && $_SESSION['ss_Level']=='lecturer'){
					$sql="SELECT lc.CAPTION,lc.NAME,lc.SERNAME ";
					$sql.="FROM $tb_lecturer lc,$tb_subject_lecturer sl ";
					$sql.="WHERE lc.USER_ID = '$_SESSION[ss_UserID]' ";
					$sql.="AND lc.LECTURER_ID = sl.LECTURER_ID ";
					$sql.="AND sl.SUBJECT_ID = '$blog' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					
					if($dbquery=mysql_db_query($dbname,$sql)){
						
						if($result=mysql_fetch_array($dbquery)){
							$return.="<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
										<tr bgcolor='#B5D1EE'>
											<th scope='col' align='center'>เมนู</th>
										</tr>
										<tr bgcolor='#E6F2F2'>
											<td class='style1'><a href='./manage.php'>เขียนBlog</a></td>
								  		</tr>
										<tr bgcolor='#E6F2F2'>
											<td class='style1'><a href='./manage.php?blog=$blog'>ปรับแต่งBlog</a></td>
								  		</tr>
										<tr bgcolor='#E6F2F2'>
											<td class='style1'><a href='./manage.php'>สร้างหัวข้อ</a></td>
								  		</tr>
									</table>";
							
							$_SESSION['bg_Level']='lecturer';
							$_SESSION['bg_Name']="$result[CAPTION] $result[NAME] $result[SERNAME]";
						}
					}
					else
						$objResponse->addAlert(mysql_error());
					
				}
				else if($_SESSION['ss_Status']=="online"){
					$sql="SELECT FIRST_NAME,LAST_NAME,st.STUDENT_ID ";
					$sql.="FROM $tb_student st,$tb_subject_student ss ";
					$sql.="WHERE st.USER_ID = '$_SESSION[ss_UserID]' ";
					$sql.="AND st.STUDENT_ID = ss.STUDENT_ID ";
					$sql.="AND ss.SUBJECT_ID = '$blog' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						if($result=mysql_fetch_array($dbquery)){
							$return.="
								<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
								  <tr bgcolor='#B5D1EE'>
									<th scope='col' align='center'>เมนู</th>
								  </tr>
								  <tr bgcolor='#E6F2F2'>
									<td class='style1'>$_SESSION[ss_UserName]</td>
								  </tr>
								  <tr bgcolor='#E6F2F2'>
									<td class='style1'><a href=''>Logout</a></td>
								  </tr>
								</table>
							";
							$_SESSION['bg_Level']='student';
							$_SESSION['bg_Name']="$result[STUDENT_ID] $result[FIRST_NAME] $result[LAST_NAME] ";
						}
						else{
							$_SESSION['bg_Level']='user';
						}
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				else{
					$return.="<a href='javascript:void window.open(\"http://localhost/ce/user_management/showlogin.php\",\"_blank\",\"left=200,top=314,width=480,height=150,resizable=no\");'>Login</a>";
					$_SESSION['bg_Level']='user';
				}
				$return.="</div>";
				//#####################################
				$sql="SELECT * ";
				$sql.="FROM $tb_bgentry ";
				$sql.="WHERE PROFILE_NAME = '$blog' ";
				$sql.="AND USER_ID = '$_SESSION[ss_UserID]' ";
				$sql.="AND IS_DRAFT = '1' ";
				mysql_db_query($dbname,"SET NAMES 'UTF8'");
				if($dbquery=mysql_db_query($dbname,$sql)){
					if(mysql_num_rows($dbquery)){
						$return.="<div class='menuright'>
						<table width='100%'  border='0' cellspacing='0' cellpadding='0' >
						  <tr bgcolor='#B5D1EE'>
							<th scope='col' align='center' >ข้อความร่าง</th>
						  </tr>
								";
					
						while($result=mysql_fetch_array($dbquery)){
							$return.="<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href=''>$result[TITLE]</a></td>
						  			</tr>
									";
						}
						$return.="</table></div>";
					}
				}
				else
					$objResponse->addAlert(mysql_error());
				
				
				//#####################################
				if($_SESSION['PROFILE']){
					$sql="SELECT SUBJECT_ID,NAME_TH,NAME_EN,CREDIT ";
					$sql.="FROM subject ";
					$sql.="WHERE SUBJECT_ID = '$blog' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						if($result=mysql_fetch_array($dbquery)){
						$return.="
							<div class='menuright'>
							<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
							  <tr bgcolor='#B5D1EE'>
								<th scope='col' align='center' colspan='2'>ข้อมูลส่วนตัว</th>
							  </tr>
							  <tr bgcolor='#E6F2F2'>
								<th scope='row'>วิชา</th>
								<td><a href='../subject/index.php?subject=$result[SUBJECT_ID]' target='_blank'>$result[NAME_TH]</a></td>
							  </tr>
							  <tr bgcolor='#E6F2F2'>
								<th scope='row' class='style1'>&nbsp;</th>
								<td class='style1'><a href='../subject/index.php?subject=$result[SUBJECT_ID]' target='_blank'>$result[NAME_EN]</a></td>
							  </tr>
							  <tr bgcolor='#E6F2F2'>
								<th scope='row'>หน่วยกิต</th>
								<td> ($result[CREDIT])</td>
							  </tr>
								";
						$sql="SELECT lc.LECTURER_ID,lc.CAPTION,lc.NAME,lc.SERNAME ";
						$sql.="FROM $tb_lecturer lc,$tb_subject_lecturer sl ";
						$sql.="WHERE sl.SUBJECT_ID = '$blog'";
						$sql.="AND lc.LECTURER_ID = sl.LECTURER_ID ";
						
						if($dbquerylc=mysql_db_query($dbname,$sql)){
							$return.="<tr bgcolor='#B5D1EE'>
											<th scope='row'>ผู้สอน</th>
											<td>&nbsp;</td>
							  			</tr>";
							while($resultlc=mysql_fetch_array($dbquerylc)){
								$return.="<tr bgcolor='#E6F2F2'>
											<th scope='row' class='style1'>&nbsp;</th>
											<td class='style1'><a href='../lecturer/lecturerdetail.php?lec_id=$resultlc[LECTURER_ID]' target='_blank'>$resultlc[CAPTION] $resultlc[NAME] $resultlc[SERNAME]</a></td>
							  			</tr>";
							}
						}
						else
							$objResponse->addAlert(mysql_error());
						
						$return.="</table></div>";
						}
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				//#####################################
				
				if($_SESSION['ARCHIVE']){
					$sql="SELECT DATE_FORMAT(CREATED,'%M %Y') AS ARCHIVE ,DATE_FORMAT(CREATED,'%m %Y') AS MOUNT ";
					$sql.="FROM $tb_bgentry ";
					$sql.="WHERE PROFILE_NAME = '$blog' "; 
					$sql.="AND IS_DRAFT = '0' ";
					$sql.="AND STATUS = '1' ";
					$sql.="GROUP BY ARCHIVE ";
					$sql.="ORDER BY MOUNT ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$return.="<div class='menuright'>
									<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
									  <tr bgcolor='#B5D1EE'>
										<th scope='col' align='center'>ประวัติ</th>
									  </tr>";
						while($result=mysql_fetch_array($dbquery)){
							$return.="
									<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href='javascript:void xajax_viewTitleEntry(\"\",\"$result[ARCHIVE]\");'> $result[ARCHIVE]</a></td>
									</tr>";
						}
						$return.="</table></div>";
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				//#####################################
				if($_SESSION['CATEGORY']){
					$sql="SELECT CATEGORY ";
					$sql.="FROM $tb_bgcategory ";
					$sql.="WHERE PROFILE_NAME='$blog'";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$return.="<div class='menuright'>
									<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
									  <tr bgcolor='#B5D1EE'>
										<th scope='col' align='center'>กลุ่มหัวข้อ</th>
									  </tr>";
						while($result=mysql_fetch_array($dbquery)){
							$return.="
									<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href='javascript:void xajax_viewTitleEntry(\"$result[CATEGORY]\");'> $result[CATEGORY]</a></td>
									</tr>";
						}
						$return.="</table></div>";
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				//#####################################
				if($_SESSION['RECOMMEND']){
					$sql="SELECT TITLE,ENTRY_ID ";
					$sql.="FROM $tb_bgentry ";
					$sql.="WHERE PROFILE_NAME='$blog'";
					$sql.="AND IS_DRAFT = '0' ";
					$sql.="AND STATUS = '1' ";
					$sql.="AND IS_RECOMMEND='1' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$return.="<div class='menuright'>
									<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
									  <tr bgcolor='#B5D1EE'>
										<th scope='col' align='center'>หัวข้อแนะนำ</th>
									  </tr>";
						while($result=mysql_fetch_array($dbquery)){
							$return.="
									<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href='javascript:void xajax_viewEntry($result[ENTRY_ID]);'> $result[TITLE]</a></td>
									</tr>";
						}
						$return.="</table></div>";
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				//#####################################
				if($_SESSION['FAVOURITES']){
					$sql="SELECT DETAIL,LINK ";
					$sql.="FROM $tb_bgfavourite ";
					$sql.="WHERE PROFILE_NAME='$blog' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$return.="<div class='menuright'>
									<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
									  <tr bgcolor='#B5D1EE'>
										<th scope='col' align='center'>หัวข้อโปรด</th>
									  </tr>";
						while($result=mysql_fetch_array($dbquery)){
							$return.="
									<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href='./view.php?blog=$result[LINK]'> $result[DETAIL]</a></td>
									</tr>";
						}
						$return.="</table></div>";
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				//#####################################
				if($_SESSION['LINK']){
					$sql="SELECT LINK,DETAIL ";
					$sql.="FROM $tb_bglink ";
					$sql.="WHERE PROFILE_NAME='$blog' ";
					mysql_db_query($dbname,"SET NAMES 'UTF8'");
					if($dbquery=mysql_db_query($dbname,$sql)){
						$return.="<div class='menuright'>
									<table width='100%'  border='0' cellspacing='0' cellpadding='0'>
									  <tr bgcolor='#B5D1EE'>
										<th scope='col' align='center'>link แนะนำ </th>
									  </tr>";
						while($result=mysql_fetch_array($dbquery)){
							$return.="
									<tr bgcolor='#E6F2F2'>
										<td class='style1'><a href='$result[LINK]'> $result[DETAIL]</a></td>
									</tr>";
						}
						$return.="</table></div>";
					}
					else
						$objResponse->addAlert(mysql_error());
				}
				
				$objResponse->addAssign("rightmenu","innerHTML",$return);
			}
		}
		else
			$objResponse->addAlert(mysql_error());
		return $objResponse;
	}
	//**********************************************************************************************************
	function getCategory(){
		global $dbname,$tb_bgcategory,$blog;
		$objResponse = new xajaxResponse();
		$sql="SELECT * ";
		$sql.="FROM $tb_bgcategory ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="<pre>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="<a href='javascript:void xajax_viewTitleEntry(\"$result[CATEGORY]\");'>$result[CATEGORY]</a><hr width='100px'>$result[DESCRIPION]<br><hr>";
			}
			$return.="</pre>";
			$objResponse->addAssign("allentry","innerHTML",$return);
		}
		else
			$objResponse->addAlert(mysql_error());
		return $objResponse;
	}
	//**********************************************************************************************************
	function viewTitleEntry($category='',$archive=''){
		global $dbname,$tb_bgprofile,$tb_bgentry,$tb_bgcategory,$tb_useraccount,$tb_student,$blog;
		$thaimount=array("ม.ค.","ก.พ.","มี.ค.","เม.ษ.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$objResponse = new xajaxResponse();
		$return="<b>$category$archive</b><hr>";
		if(strlen($category)){	
			$sql="SELECT * ";
			$sql.="FROM $tb_bgcategory ";
			$sql.="WHERE PROFILE_NAME= '$blog' ";
			$sql.="AND CATEGORY = '$category' ";
			mysql_db_query($dbname,"SET NAMES 'UTF8'");
			if($dbquery=mysql_db_query($dbname,$sql)){
				if($result=mysql_fetch_array($dbquery)){
					$return.="<pre class='cate_desc'>$result[DESCRIPION]<br><center><hr width='450px'></center></pre>";
					//if($_SESSION['bg_Level']=='lecturer' && $_SESSION['bg_Level']=='student')
					$return.="<div id='newentry' align='center'><a href='javascript:void xajax_addNewBlog(\"$category\");'><strong>เขียนBlogใหม่</strong></a><br></div>";
				}
			}
		}
		$sql="SELECT be.TITLE,be.CREATED,be.USER_ID,be.CATEGORY,be.ENTRY_ID,ua.STUDENT_ID,st.FIRST_NAME,st.LAST_NAME,st.DEPARTMENT ";
		$sql.="FROM $tb_bgentry be,$tb_useraccount ua,$tb_student st ";
		$sql.="WHERE PROFILE_NAME = '$blog' ";
		$sq.="AND be.USER_ID = ua.USER_ID ";
		$sql.="AND ua.STUDENT_ID = st.STUDENT_ID ";
		$sql.="AND IS_DRAFT = '0' ";
		$sql.="AND STATUS = '1' ";
		if(strlen($category))
			$sql.="AND be.CATEGORY = '$category' ";
		else
			$sql.="AND DATE_FORMAT(be.CREATED,'%M %Y') = '$archive'";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			while($result=mysql_fetch_array($dbquery)){
				$return.="<br>+ <a href='javascript:void xajax_viewEntry($result[ENTRY_ID]);'><strong>$result[TITLE]</strong></a> ";
				$return.="<span class='post'> โดย  $result[FIRST_NAME] $result[LAST_NAME] $result[STUDENT_ID] $result[DEPARTMENT] ";
				$return.="เมื่อ  ".date("j ",strtotime($result['CREATED'])).$thaimount[date("n",strtotime($result['CREATED']))-1]." ".(date("Y",strtotime($result['CREATED']))+543)."</span>";
			}
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		$objResponse->addAssign("allentry","innerHTML",$return);
		return $objResponse;
	}
	//**********************************************************************************************************
	function addNewBlog($category){
		$objResponse = new xajaxResponse();
		$return="<div style='width:650px;border:1px solid;'>";
			$return.="<br>ชื่อ <input id='tname' type='text' disabled='true' value='$_SESSION[bg_Name]' size='40'> 
					กลุ่มหัวข้อ <input id='tcategory' type='text' disabled='true' value='$category' size='30'> <br>
					เรื่อง <input type='text' id='ttitle' style='width:545px'><br><br>
					<textarea id='tnewentry' cols='50' rows='5' style='width:650px;height:500px;'></textarea>
					<input type='button' value='บันทึก' onclick='xajax_submitNewBlog(xajax.$(\"ttitle\").value,\"$category\",tinyMCE.getContent(\"MCEControlID\"),0);'> 
					<input type='button' value='ข้อความร่าง' onclick='xajax_submitNewBlog(xajax.$(\"ttitle\").value,\"$category\",tinyMCE.getContent(\"MCEControlID\"),1);'>
					<input type='button' value='ดูตัวอย่าง' onclick=\"tinyMCE.execInstanceCommand('MCEControlID','mcePreview');\">
				</div>";
		$objResponse->addAssign("newentry","innerHTML",$return);
		$objResponse->addScript("tinyMCE.addMCEControl(xajax.$('tnewentry'),'MCEControlID');");
		return $objResponse;
	}
	//**********************************************************************************************************
	function submitNewBlog($title,$category,$detail,$draft){
		global $dbname,$tb_bgentry,$tb_bgvote,$blog;
		$objResponse = new xajaxResponse();
		$sql="INSERT INTO $tb_bgentry ";
		$sql.="VALUES('','$blog','$category','".date("Y-m-d H:i:s",time())."','$title','$detail','".$_SESSION['ss_UserID']."','0','$draft','0','0','1') ";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if(!mysql_db_query($dbname,$sql))
			$objResponse->addAlert(mysql_error().$sql);
		$return="<a href='javascript:void xajax_addNewBlog(\"$category\");'><strong>เขียนBlogใหม่</strong></a><br>";
		$objResponse->addAssign("newentry","innerHTML",$return);
		$objResponse->addAlert("เพิ่มข้อมูลเรียบร้อย");
		return $objResponse;
	}
	//**********************************************************************************************************
	function viewEntry($entry_id=''){
		global $dbname,$tb_bgprofile,$tb_bgentry,$tb_useraccount,$tb_student,$tb_bgvote,$blog;
		$thaimount=array("ม.ค.","ก.พ.","มี.ค.","เม.ษ.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$objResponse = new xajaxResponse();
		$sql="SELECT be.ENTRY_ID,be.CREATED,be.TITLE,be.DETAIL,st.STUDENT_ID,st.FIRST_NAME,st.LAST_NAME,st.DEPARTMENT ";
		$sql.="FROM $tb_bgentry be,$tb_useraccount ua,$tb_student st ";
		$sql.="WHERE be.PROFILE_NAME='$blog' ";
		$sql.="AND be.USER_ID = ua.USER_ID ";
		$sql.="AND ua.STUDENT_ID = st.STUDENT_ID ";
		if(strlen($entry_id))
			$sql.="AND be.ENTRY_ID = '$entry_id' ";
		
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return="";
			while($result=mysql_fetch_array($dbquery)){
				$sql="SELECT ";
				$return.="
				<div id='entry$result[ENTRY_ID]'>
				  <div align='left'>
					<span class='title'>$result[TITLE]</span> <span class='date'>";
				$return.=date("j ",strtotime($result['CREATED'])).$thaimount[date("n",strtotime($result['CREATED']))-1]." ".(date("Y",strtotime($result['CREATED']))+543);
				$return.="</span><hr width='200px'>
					$result[DETAIL]<hr width='300px'>
					<span class='post'>โดย  $result[FIRST_NAME] $result[LAST_NAME] $result[STUDENT_ID] $result[DEPARTMENT] ";
				$return.="เมื่อ ".date("j ",strtotime($result['CREATED'])).$thaimount[date("n",strtotime($result['CREATED']))-1]." ".(date("Y",strtotime($result['CREATED']))+543);
				$return.=date(" H:i:s ",strtotime($result['CREATED']));
				$return.="</span>";
				
				
				$sql="SELECT * ";
				$sql.="FROM $tb_bgvote ";
				$sql.="WHERE ENTRY_ID = $result[ENTRY_ID] ";
				$sql.="AND USER_ID = $_SESSION[ss_UserID] ";
				if($dbqueryvote=mysql_db_query($dbname,$sql)){
					if(mysql_fetch_array($dbqueryvote)){
						$return.="<span id='vo$result[ENTRY_ID]'><br></span>";
					}
					else{
						$return.="<span id='vo$result[ENTRY_ID]'>
									<br><font color='#FF0000'><strong>vote</strong></font>
									<a href='javascript:void voteClick($result[ENTRY_ID],1);'><img src='images/vote_off.gif' id='pv1$result[ENTRY_ID]' onmouseover='voteOver($result[ENTRY_ID],1);' onmouseout='voteOut($result[ENTRY_ID],1);'></a>
									<a href='javascript:void voteClick($result[ENTRY_ID],2);'><img src='images/vote_off.gif' id='pv2$result[ENTRY_ID]' onmouseover='voteOver($result[ENTRY_ID],2);' onmouseout='voteOut($result[ENTRY_ID],2);'></a>
									<a href='javascript:void voteClick($result[ENTRY_ID],3);'><img src='images/vote_off.gif' id='pv3$result[ENTRY_ID]' onmouseover='voteOver($result[ENTRY_ID],3);' onmouseout='voteOut($result[ENTRY_ID],3);'></a>
									<a href='javascript:void voteClick($result[ENTRY_ID],4);'><img src='images/vote_off.gif' id='pv4$result[ENTRY_ID]' onmouseover='voteOver($result[ENTRY_ID],4);' onmouseout='voteOut($result[ENTRY_ID],4);'></a>
									<a href='javascript:void voteClick($result[ENTRY_ID],5);'><img src='images/vote_off.gif' id='pv5$result[ENTRY_ID]' onmouseover='voteOver($result[ENTRY_ID],5);' onmouseout='voteOut($result[ENTRY_ID],5);'></a>
								  </span>";
					}
				}
				else
					$objResponse->addAlert(mysql_error().$sql);
				$return.="<span id='c$result[ENTRY_ID]'>
						<br><a href='javascript:void showComment($result[ENTRY_ID]);'><strong>แสดงคอมเม้นท์</strong></a>
					</span>
					<div id='comment$result[ENTRY_ID]' style='display:none;'>"
					;
				getComment($result[ENTRY_ID],&$return);
				$return.="
					</div>	
					<hr>
				  </div>
				</div>
				";
			}
			$objResponse->addAssign("allentry","innerHTML",$return);
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		
		return $objResponse;
		
	}
	//**********************************************************************************************************
	function getComment($entry_id,$return){
		global $dbname,$tb_bgcomment,$blog;
		$thaimount=array("ม.ค.","ก.พ.","มี.ค.","เม.ษ.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$sql="SELECT * ";
		$sql.="FROM $tb_bgcomment ";
		$sql.="WHERE ENTRY_ID='$entry_id' ";
		$sql.="AND STATUS='1' ";
		$sql.="ORDER BY CREATED ";
		$return.="
			<hr width='300px'><div style='width:550px;border:1px solid;padding-left:20px;'><br>
				ชื่อ :<input id='cname$entry_id' type='text' size='20' style='width:480px;'><br>
				<textarea id='cdetail$entry_id' rows='3' cols='20' style='width:500px;'></textarea><br>
				<input type='button' value='submit' onclick='xajax_addComment($entry_id,xajax.$(\"cname$entry_id\").value,xajax.$(\"cdetail$entry_id\").value);'>
			</div>";
		if($dbquery=mysql_db_query($dbname,$sql)){
			$return.="<div id='allcomment$entry_id'>";
			while($result=mysql_fetch_array($dbquery)){
				$return.="
					<br id='commentidb$result[COMMENT_ID]'><div id='commentid$result[COMMENT_ID]' style='width:550px;border:1px solid;padding-left:20px;'>
						$result[DETAIL]<br>
						<span class='post'>โดย $result[BY] ";
				$return.="เมื่อ ".date("j ",strtotime($result['CREATED'])).$thaimount[date("n",strtotime($result['CREATED']))-1]." ".(date("Y",strtotime($result['CREATED']))+543);
				$return.=date(" H:i:s ",strtotime($result['CREATED']));
				$return.="<br>	
						</span>";
				if($_SESSION['bg_Level']=='lecturer')
					$return.="<a href='javascript:void xajax_deleteComment(\"$result[COMMENT_ID]\");'>delete</a>";
				$return.="	</div>";
			}
			$return.="</div>";
		}
	}
	//**********************************************************************************************************
	function addVote($entry_id,$point){
		global $dbname,$tb_bgentry,$tb_bgvote,$blog;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgentry ";
		$sql.="SET POINT = POINT+'$point' ";
		$sql.="WHERE ENTRY_ID = '$entry_id' ";
		$sql.="Limit 1 ";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addAlert("vote สำเร็จแล้ว");
		}
		else
			$objResponse->addAlert(mysql_error());
		$sql="INSERT INTO $tb_bgvote ";
		$sql.="VALUES('$entry_id','$_SESSION[ss_UserID]') ";
		if(!mysql_db_query($dbname,$sql)){
			$objResponse->addAlert(mysql_error());
		}
		
		return $objResponse;
	}
	//**********************************************************************************************************
	function addComment($entry_id,$name,$detail){
		global $dbname,$tb_bgcomment;
		$objResponse = new xajaxResponse();
			$sql="INSERT INTO $tb_bgcomment ";
			$sql.="VALUES('','$entry_id','$detail','".date('Y-m-d H:i:s',time())."','$name','1') ";
			mysql_db_query($dbname,"SET NAMES 'UTF8'");
			if(mysql_db_query($dbname,$sql)){
				$objResponse->addScript("addComment($entry_id);");
				$objResponse->addAlert('เพิ่มข้อมูลเรียบร้อยแล้ว');
			}
			else
				$objResponse->addAlert(mysql_error());
		return $objResponse;
	}
	//**********************************************************************************************************
	function deleteComment($comment_id){
		global $dbname,$tb_bgcomment;
		$objResponse = new xajaxResponse();
		$sql="UPDATE $tb_bgcomment ";
		$sql.="SET STATUS = '0' ";
		$sql.="WHERE COMMENT_ID = '$comment_id' ";
		$sql.="LIMIT 1 ";
		if(mysql_db_query($dbname,$sql)){
			$objResponse->addRemove("commentidb$comment_id");
			$objResponse->addRemove("commentid$comment_id");
		}
		return $objResponse;
	}
	//**********************************************************************************************************
	$xajax = new xajax();
	//$xajax->decodeUTF8InputOn();
	$xajax->registerFunction("init");
	$xajax->registerFunction("getCategory");
	$xajax->registerFunction("viewEntry");
	$xajax->registerFunction("viewTitleEntry");
	$xajax->registerFunction("addVote");
	$xajax->registerFunction("addNewBlog");
	$xajax->registerFunction("submitNewBlog");
	$xajax->registerFunction("getComment");
	$xajax->registerFunction("addComment");
	$xajax->registerFunction("deleteComment");
	$xajax->processRequests();
	//**********************************************************************************************************
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>CE Blog</title>
<link href="style.css" rel="stylesheet" type="text/css">
<?php $xajax->printJavascript('../tool/xajax/');?>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="../tool/tinymce/jscripts/tiny_mce/tiny_mce_init1.js"></script>
<script language="javascript" type="text/javascript" src="./comment.js"></script>
<script language="javascript" type="text/javascript" src="./vote.js"></script>
<style type="text/css">
<!--
.style1 {
	border-bottom:2px solid;
}
-->
</style>
</head>

<body onLoad="xajax_init();" class="site">
<center>
	<div>
	  <div align="center">
		<table width="900px"  border="1" cellspacing="0" cellpadding="0">
		  <tr>
			<td colspan="2"><img border='0px' src="BG/Logo_blog.png"></td>
		  </tr>
		  <tr>
			<td id="allentry" width="700px" align="left" valign="top">
			
			</td>
			<td id="rightmenu" width="200px" align="left" valign="top">
				
			</td>
		  </tr>
		</table>

	</div>

	<?php
	if(isset($entry))
		echo "<script language='JavaScript' type='text/JavaScript'>xajax_viewEntry($entry);</script>";
	else
		echo "<script language='JavaScript' type='text/JavaScript'>xajax_getCategory();</script>";
	?>
		
	

</body>
</html>
