// JavaScript Document
function voteOver(entry_id,point){
	for(var i=1;i<=point;i++){
		xajax.$('pv'+i+entry_id).src="images/vote_on.gif";
	}
}
function voteClick(entry_id,point){
	xajax.$('vo'+entry_id).innerHTML="<br>";
	xajax_addVote(entry_id,point);
}
function voteOut(entry_id,point){
	for(var i=1;i<=point;i++){
		xajax.$('pv'+i+entry_id).src="images/vote_off.gif";
	}
}