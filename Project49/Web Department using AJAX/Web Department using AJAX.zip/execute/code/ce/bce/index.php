<?php
    require_once('../tool/xajax/xajax.inc.php');
	require_once('../connectdb.inc.php');
	function ShowSubjectBlog(){
		global $dbname,$tb_bgprofile,$tb_subject;
		$objResponse = new xajaxResponse();
		$return.="<table  width=245 border='0' cellpadding='0' cellspacing='0'>";
		$sql="SELECT PROFILE_NAME,NAME_TH ";
		$sql.="FROM $tb_bgprofile bp,$tb_subject sb ";
		$sql.="WHERE bp.PROFILE_NAME = sb.SUBJECT_ID ";
		$sql.="ORDER BY `PROFILE_NAME` ASC ";
		$sql.="LIMIT 20";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{  $loop=0;
			while($result=mysql_fetch_array($dbquery))
			{
				if (($loop%2)==0)
				$return.="<div>
				<tr  bgcolor='#CAF4E4' height='25'><div><td >+
				<a href='./view.php?blog=$result[PROFILE_NAME]'> $result[PROFILE_NAME] $result[NAME_TH]</a></td></div> </td></tr>";
				else
				$return.=" <div>
				<tr  bgcolor='#EAFDFD' height='25'><div ><td >+
				<a href='./view.php?blog=$result[PROFILE_NAME]'> $result[PROFILE_NAME] $result[NAME_TH]</a></td></div> </td></tr>";
				 $loop++;
			}
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		$return.="</table>";		
		$objResponse->addAssign("subject","innerHTML",$return);
		return $objResponse;
	}
       function ShowNewBlog(){
		global $dbname,$tb_bgentry;
		$objResponse = new xajaxResponse();
		$return.="<table  width=248 border='0' cellpadding='0' cellspacing='0'>";
		$sql="SELECT ENTRY_ID,TITLE,PROFILE_NAME,CREATED ";
		$sql.="FROM $tb_bgentry ";
		$sql.="ORDER BY `CREATED` DESC ";
		$sql.="LIMIT 20";
		mysql_db_query($dbname,"SET NAMES 'UTF8'");
		if($dbquery=mysql_db_query($dbname,$sql))
		{  $loop=0;
			while($result=mysql_fetch_array($dbquery))
			{
				if (($loop%2)==0)
				$return.="<div>
				<tr  bgcolor='#CAF4E4' height='25'><div><td >+
				<a href='./view.php?blog=$result[PROFILE_NAME]&entry=$result[ENTRY_ID]'> $result[TITLE]</a></td></div> </td></tr>";
				else
				$return.=" <div>
				<tr  bgcolor='#EAFDFD' height='25'><div ><td >+
				<a href='./view.php?blog=$result[PROFILE_NAME]&entry=$result[ENTRY_ID]'> $result[TITLE]</a></td></div> </td></tr>";
				 $loop++;
			}
		}
		else
			$objResponse->addAlert(mysql_error().$sql);
		$return.="</table>";		
		$objResponse->addAssign("new","innerHTML",$return);
		return $objResponse;
	}
		function RankBlog(){
				global $dbname,$tb_bgentry;
				$objResponse = new xajaxResponse();
				
				$sql="SELECT ENTRY_ID,TITLE,PROFILE_NAME,POINT ";
				$sql.="FROM $tb_bgentry ";
				$sql.="ORDER BY POINT DESC ";
				$sql.="LIMIT 20";
				mysql_db_query($dbname,"SET NAMES 'UTF8'");
				if($dbquery=mysql_db_query($dbname,$sql)){  
					$return.="<table  width=250 border='0' cellpadding='0' cellspacing='0'>";	
					$loop=0;
					while($result=mysql_fetch_array($dbquery)){
						if (($loop%2)==0){
						$return.=" <div  id='$result[PROFILE_NAME]'>	 
						<tr  bgcolor='#FCEAD1' height='25'><div ><td >+
						<a href='./view.php?blog=$result[PROFILE_NAME]&entry=$result[ENTRY_ID]'> $result[TITLE]</a> <span class='post' style='font-size:9px;'>คะแนน $result[POINT]</span></td></div> </td></tr>";
						}
						else{
						$return.=" <div  id='$result[PROFILE_NAME]'>	 
						<tr  bgcolor='#FEFBF5' height='25'><div ><td >+
						<a href='./view.php?blog=$result[PROFILE_NAME]&entry=$result[ENTRY_ID]'> $result[TITLE]</a> <span class='post' style='font-size:9px;'>คะแนน $result[POINT]</span></td></div> </td></tr>";
						}
						 $loop++;
					}
					$return.="</table>";
					$objResponse->addAssign("rank","innerHTML",$return);
				}
				else
					$objResponse->addAlert(mysql_error());
			return $objResponse;
		}



        $xajax = new xajax();
		$xajax->decodeUTF8InputOn();
		$xajax->registerFunction("ShowSubjectBlog");
		$xajax->registerFunction("ShowNewBlog");
	    $xajax->registerFunction("RankBlog");
	    $xajax->processRequests(); 		
				
	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
	"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head >
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>New Page 1</title>
    <link href="./style.css" rel="stylesheet" type="text/css">
	<?php $xajax->printJavascript('../tool/xajax/');?>

</head>
<body class='site'>
	<center>
	<div>
		<img border="0" src="./BG/Logo_blog.png" >
		<table cellpadding='0' cellspacing="0" >
		<tr>
			<td height='40px' colspan="3" background="BG/top.jpg">&nbsp;</td>
			
		</tr>
		<tr >
			<td width='11px' background="BG/shadow-left.gif" >&nbsp;</td>
			<td width="748px">
				<div style='border-right:1px inset ;width:245px;float:left;background-image:url(./BG/Bar.jpg);background-repeat:no-repeat;text-align:left;'>
					<center><b>Blog รายวิชา</b></center>
					<br>
					<script langusge='JavaScript'>
						<!--
							xajax_ShowSubjectBlog();
						//-->
					</script>
					<div id="subject"></div>
				</div>
				<div style='border-right:1px inset ;width:245px;float:left;background-image:url(./BG/bar_r.gif);background-repeat:no-repeat;text-align:left;'>
					<center><b>บทความใหม่ล่าสุด</b></center>
					<br>
					<script langusge='JavaScript'>
						<!--
							xajax_ShowNewBlog();
						//-->
					</script>
					<div id="new"></div>
				</div>
				<div style='width:245px;float:left;background-image:url(./BG/bar_l.gif);background-repeat:no-repeat;text-align:left;'>
					<center><b>บทความยอดนิยม</b></center>
					<br>
					<script langusge='JavaScript'>
						<!--
						xajax_RankBlog();
						//-->
					</script>
					<div id="rank"></div>	  
				</div>
			</td>
			<td width='7px' background="BG/shadow-right.gif">&nbsp;</td>
		</tr>
		<tr >
			<td height='40px' colspan="3" background="BG/bot.jpg">&nbsp;</td>
		</tr>
	  </table>
	</div>
	<center>
</body>

</html>