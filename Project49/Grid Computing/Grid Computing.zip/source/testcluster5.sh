#!/bin/sh
#PBS -W stagein=/home/nodeB/slicegrid22.avi@test2:/home/nodeB/gridmethod/slicegrid22.avi
#PBS -W stageout=/home/nodeB/mpeg4_slicegrid22.avi@test2:/home/nodeB/gridmethod/output/mpeg4_slicegrid22.avi

/usr/bin/mencoder slicegrid22.avi -vf harddup -ovc lavc -oac lavc -lavcopts vcodec=mpeg4:vqmax=4:acodec=ac3:abitrate=128 -of avi -o /home/nodeB/mpeg4_slicegrid22.avi
