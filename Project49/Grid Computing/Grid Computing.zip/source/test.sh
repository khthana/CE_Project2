#! /bin/ksh
com=1
comjobID1=0
comjobID3=0
goal=6
no=0
queue=0
queue1="Current job state: Done"
np=1
allcom=4
comrun=1
filecount=1
finish="Current job state: Done"
#ns=2
while [ -f "slicegrid$filecount.avi" ]
do
	filecount=$(($filecount + 1))
done
	filecount=$(($filecount - 1))
while [ $no -lt 3 ]
do	
	no=$(($no + 1))
	if [ -f "slice$no.epr" ]
	then
		remove=`rm slice$no.epr`
	fi
	if [ $com -eq 2 ]
	then
		script=encode
	else
		script=encodean
		if [ $com -eq 1 ]
		then
			comjobID1=$no
		else 
			comjobID3=$no
		fi
	fi
	if [ $no -eq 1 ]
	then
		
		script=$script
	else 
		buff=_buff
		script=$script$buff
		cat encode1.rsl | sed s/grid1/grid$no/g > encode_buff$no.rsl
		cat encodean1.rsl | sed s/grid1/grid$no/g > encodean_buff$no.rsl
	fi
	globusrun-ws -submit -batch -o slice$no.epr -S -F https://test$no.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$no.rsl&	
	echo "run at com = $com"
	com=$(($com + 1))
	if [ $com -eq $allcom ]
	then 
		com=1;
	fi
done

echo ==================================
while [ $no -lt $goal ]
do
	if [ -f "slice$com.epr" ]
	then
		if [ $com -eq 2 ]
		then
			queue=$finish
		else
			queue=`globusrun-ws -status -job-epr-file slice$com.epr`
		fi
	else 
		queue=0
	fi	
	if [ "$queue" = "$finish" ]
	then		
		echo com $com state : $queue
		no=$(($no + 1))
		if [ $com -eq 1 ]
		then 
			echo 1111 $comjobID1
			if [ -f "mpeg4_slicegrid$comjobID1.avi" ]
			then
				echo "run at com = 1"
				com=1
				comjobID1=$no
			elif [ -f "mpeg4_slicegrid$comjobID3.avi" ]
			then
				echo "run at com = 3"
				com=3
				comjobID3=$no			
			else 
				echo "run at com = 2"
				com=2
			fi
		fi
		if [ $com -eq 3 ]
		then 
			echo 3333
			if [ -f "mpeg4_slicegrid$comjobID3.avi" ]
			then
				echo "run at com = 3"
				com=3
				comjobID3=$no
			elif [ -f "mpeg4_slicegrid$comjobID1.avi" ]
			then
				echo "run at com = 1"
				com=1
				comjobID1=$no			
			else 
				echo "run at com = 2"
				com=2
			fi
		fi
		if [ $com -eq 2 ]
		then 
			if [ $no -lt $goal ] 
			then 
				echo "run at com = 2"
			fi			
		fi

		if [ $com -eq 2 ]
		then
			script=encode
		else
			script=encodean			
		fi
		
		if [ $no -eq 1 ]
		then
			
			script=$script
		else 
			buff=_buff
			script=$script$buff
			cat encode1.rsl | sed s/grid1/grid$no/g > encode_buff$no.rsl
			cat encodean1.rsl | sed s/grid1/grid$no/g > encodean_buff$no.rsl
		fi
		globusrun-ws -submit -batch -o slice$com.epr -S -F https://test$com.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$no.rsl&
		echo "$script";
		echo "Process ID : $no";
		echo "Com : $com"; 

	fi
	com=$(($com + 1))
	if [ $com -eq $allcom ]
	then 
		com=1;
	fi
done


#while [ $complete -lt $goal ]
#do
#	check=1
#	while [ check -le $goal ]
#	do
#		if [ -f "slice$check.epr" ]
#		then 
#			$complete=$(($complete + 1))
#			
#		fi
#		$check=$(($check + 1))
#	done
#done
