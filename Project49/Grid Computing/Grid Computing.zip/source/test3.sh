filecount=1
file=2
touch output/mpeg4_slicegrid.avi
while [ $file -le 6 ]
do
	cat output/mpeg4_slicegrid1.avi output/mpeg4_slicegrid$file.avi > output/tmpfile.avi
	mencoder -o output/mpeg4_slicegrid1.avi -noidx -oac copy -ovc copy output/tmpfile.avi
	file=$(($file + 1))
	echo "=======================  $file  ========================"
done
while [ -f "output/mpeg4_slicegrid$filecount.avi" ]
do
	filecount=$(($filecount + 1))
done
	filecount=$(($filecount - 1))
	echo $filecount
