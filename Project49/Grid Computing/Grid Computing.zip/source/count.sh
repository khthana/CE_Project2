#! /bin/ksh
filecount=1
while [ -f "output/mpeg4_slicegrid$filecount.avi" ]
do
	filecount=$(($filecount + 1))
done

filecount=$(($filecount - 1))
echo $filecount
