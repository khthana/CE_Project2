#! /bin/ksh
com=1
comjobID1=0
comjobID2=0
comjobID3=0
comjobID4=0
comjobID5=0
goal=$1
JobID=0
queue=0
queue1="Current job state: Done"
np=1
allcom=$2
comrun=1
filecount=1
complete=1
othercomplete=$goal
finish="Current job state: Done"
#ns=2
while [ -f "slicegrid$filecount.avi" ]
do
	filecount=$(($filecount + 1))
done
	filecount=$(($filecount - 1))

while [ $JobID -lt $allcom ]
do	
	JobID=$(($JobID + 1))
	if [ -f "slice$JobID.epr" ]
	then
		remove=`rm slice$JobID.epr`
	fi
	if [ $com -eq 2 ]
	then
		script=encode
		comjobID2=$JobID
	else
		script=encodean
		if [ $com -eq 1 ]
		then
			comjobID1=$JobID
		fi		
		if [ $com -eq 3 ] 
		then
			comjobID3=$JobID
		fi
		if [ $com -eq 4 ] 
		then
			comjobID4=$JobID
		fi
		if [ $com -eq 5 ] 
		then
			comjobID5=$JobID
		fi
	fi
	if [ $JobID -le 1 ]
	then
		script=$script
	else
		if [ $JobID -le 3 ]
		then
			buff=_buff
			script=$script$buff
			cat encode1.rsl | sed s/grid1/grid$com/g > encode_buff$com.rsl
			cat encodean1.rsl | sed s/grid1/grid$com/g > encodean_buff$com.rsl
		else
			cat "testclusterbck.sh" | sed s/grid1/grid$com/g > "testcluster$com.sh"
		fi
	fi
	if [ $com -gt 3 ]
	then
		/opt/pbs/bin/qsub -l nodes=test$com.kmitl.ac.th testcluster$com.sh	
		echo run pbs at com $com
	else
		globusrun-ws -submit -batch -o slice$com.epr -S -F https://test$com.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$com.rsl&	
		echo globusrun at com $com
	fi	
	
	echo "run at com = $com"
	com=$(($com + 1))
	if [ $com -gt $allcom ]
	then 
		com=1;
	fi
done

echo ==================================
while [ $JobID -lt $goal ]
do
	if [ -f "slice$com.epr" ]
	then
		if [ $com -eq 2 ]
		then
			queue=$finish
		else
			queue=`globusrun-ws -status -job-epr-file slice$com.epr`

		fi
	else 
		queue=0
	fi	
	
	if [ "$queue" == "$finish" ]
	then								
		if [ $com -eq 1 ]
		then 
			if [ -f "output/mpeg4_slicegrid$comjobID1.avi" ]
			then
				
				if [ $JobID -le $goal ]
				then
					comgrid=`./checkloadgrid.sh`
					
					echo "Complete at com = 1   JobID = $comjobID1"	
					if [ $comgrid -eq 1 ]
					then
						JobID=$(($JobID + 1))
						comjobID1=$JobID
					fi
				fi				

			fi			
		fi
		if [ $com -eq 3 ]
		then 
			if [ -f "output/mpeg4_slicegrid$comjobID3.avi" ]
			then
				
				if [ $JobID -le $goal ]
				then
					comgrid=`./checkloadgrid.sh`
					
					echo "Complete at com = 3   JobID = $comjobID3"	
					if [ $comgrid -eq 3 ]
					then
						JobID=$(($JobID + 1))
						comjobID3=$JobID
					fi
				fi
			fi			
		fi
		
		if [ $com -eq 2 ]
		then 
			if [ $JobID -le $goal ]
			then
				JobID=$(($JobID + 1))
				echo "Complete at com = 2"
				
			fi	
				
		fi

		if [ $com -eq 2 ]
		then
			script=encode
		else
			script=encodean			
		fi
		
		if [ $JobID -eq 1 ]
		then
			
			script=$script
		else 
			buff=_buff
			script=$script$buff
			cat encode1.rsl | sed s/grid1/grid$JobID/g > encode_buff$JobID.rsl
			cat encodean1.rsl | sed s/grid1/grid$JobID/g > encodean_buff$JobID.rsl
		fi
		if [ $JobID -le $goal ]
		then
			globusrun-ws -submit -batch -o slice$com.epr -S -F https://test$com.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$JobID.rsl&
			echo "Send Process ID : $JobID to Com : $com"; 
		fi
	else
		if [ $com -gt 3 ]
		then
			comPBS=`./checkload.sh`

			if [ -f "output/mpeg4_slicegrid$comjobID4.avi" ]
			then
				if [ $JobID -le $goal ]
				then
					
					echo "Complete at com = 4   JobID = $comjobID4"
					if [ $comPBS -eq 4 ]
					then
						JobID=$(($JobID + 1))
						comjobID4=$JobID
						cat "testclusterbck.sh" | sed s/grid1/grid$JobID/g > "testcluster$comPBS.sh"
						/opt/pbs/bin/qsub -l nodes=test$comPBS.kmitl.ac.th "testcluster$comPBS.sh"
						echo "Send Job ID : $JobID to Com : $comPBS";
					fi
					 
				fi
			fi
			if [ -f "output/mpeg4_slicegrid$comjobID5.avi" ]
			then
				
				if [ $JobID -le $goal ]
				then					
					echo "Complete at com = 5   JobID = $comjobID5"
					if [ $comPBS -eq 5 ]
					then
						JobID=$(($JobID + 1))
						comjobID5=$JobID
						cat "testclusterbck.sh" | sed s/grid1/grid$JobID/g > "testcluster$comPBS.sh"
						/opt/pbs/bin/qsub -l nodes=test$comPBS.kmitl.ac.th "testcluster$comPBS.sh"
						echo "Send Job ID : $JobID to Com : $comPBS";
					fi
					 
				fi
			fi
		fi
	fi
	com=$(($com + 1))
	if [ $com -gt $allcom ]
	then 
		com=1;
	fi
done
file=1
echo "---------------------All Send complete------------------"
#touch output/mpeg4_slicegrid.avi
#while [ $file -le 6 ]
#do
#	echo "=======================  $file  ========================"
#	cat output/mpeg4_slicegrid.avi output/mpeg4_slicegrid$file.avi > output/tmpfile.avi
#	mencoder -o output/mpeg4_slicegrid.avi -noidx -oac copy -ovc copy output/tmpfile.avi
#	file=$(($file + 1))	
#done
