#! /bin/ksh
wsrf-query -s https://test2.kmitl.ac.th:8443/wsrf/services/DefaultIndexService "//*[local-name()='GLUECE']/glue:Cluster/glue:SubCluster/glue:Host/glue:ProcessorLoad" > loadgrid.txt
load1=`java checkloadgrid 1`
#echo $load1
load3=`java checkloadgrid 3`
#echo $load3
if [ $load1 -gt $load3 ]
then
	echo 3
else
	echo 1
fi


	
