#! /bin/ksh
com=1
type=1
alltype=2
comjobID1=0
comjobID2=0
comjobID3=0
comjobID4=0
comjobID5=0
goal=18
JobID=0
queue=0
#np=1
allcom=3
#comrun=1
filecount=1
complete=1
#othercomplete=$goal
finish="Current job state: Done"
#ns=2
while [ -f "slicegrid$filecount.avi" ]
do
	filecount=$(($filecount + 1))
done
	filecount=$(($filecount - 1))

while [ $JobID -lt $allcom ]
do	
	JobID=$(($JobID + 1))
	if [ -f "slice$JobID.epr" ]
	then
		remove=`rm slice$JobID.epr`
	fi
	if [ $com -eq 2 ]
	then
		script=encode
		comjobID2=$JobID
	else
		script=encodean
		if [ $com -eq 1 ]
		then
			comjobID1=$JobID
		fi		
		if [ $com -eq 3 ] 
		then
			comjobID3=$JobID
		fi
		if [ $com -eq 4 ] 
		then
			comjobID4=$JobID
		fi
		if [ $com -eq 5 ] 
		then
			comjobID5=$JobID
		fi
	fi
	if [ $JobID -le 1 ]
	then
		script=$script
	else
		if [ $JobID -le 3 ]
		then
			buff=_buff
			script=$script$buff
			cat encode1.rsl | sed s/grid1/grid$com/g > encode_buff$com.rsl
			cat encodean1.rsl | sed s/grid1/grid$com/g > encodean_buff$com.rsl
		else
			cat "testclusterbck.sh" | sed s/grid1/grid$com/g > "testcluster$com.sh"
		fi
	fi
	if [ $com -gt 3 ]
	then
		/opt/pbs/bin/qsub -l nodes=test$com.kmitl.ac.th testcluster$com.sh	
		echo run pbs at com $com
	else
		globusrun-ws -submit -batch -o slice$com.epr -S -F https://test$com.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$com.rsl&	
		echo globusrun at com $com
	fi	
	
	com=$(($com + 1))
	if [ $com -gt $allcom ]
	then 
		com=1;
	fi
done

echo ==================================
while [ $JobID -lt $goal ]
do
	if [ -f "slice$com.epr" ]
	then
		if [ $type -eq 2 ]
		then
			queue=$finish
		else
			queue=`globusrun-ws -status -job-epr-file slice$com.epr`

		fi
	else 
		queue=0
	fi	
	submit=0
	if [ "$queue" == "$finish" ]
	then						
		#echo com $com state : $queue
		
		if [ $type -eq 1 ]
		then 
			if [ -f "output/mpeg4_slicegrid$comjobID1.avi" ]
			then
				if [ -f "output/mpeg4_slicegrid$comjobID3.avi" ]
				then
					comgrid=`./checkloadgrid.sh`
					if [ $JobID -le $goal ]
					then		
								
						com=$comgrid
						JobID=$(($JobID + 1))
						if [ $com -eq 1 ]
						then
							echo "Complete at com = $com   JobID = $comjobID1"
							comjobID1=$JobID
						else
							echo "Complete at com = $com   JobID = $comjobID3"
							comjobID3=$JobID
						fi
						submit=1
						complete=$(($complete + 1))
				
					
					fi
				else 
				if [ $JobID -le $goal ]
				then		
						JobID=$(($JobID + 1))
						echo "Complete at com = 1   JobID = $comjobID1"
						comjobID1=$JobID
						com=1
						#echo "complete $complete files"
						submit=1
						complete=$(($complete + 1))
				fi
				fi
			else 
			if [ -f "output/mpeg4_slicegrid$comjobID3.avi" ]
			then
				if [ $JobID -le $goal ]
				then		
								
						com=3
						JobID=$(($JobID + 1))
						echo "Complete at com = 3   JobID = $comjobID3"
						comjobID3=$JobID
						#echo "complete $complete files"
						submit=1
						complete=$(($complete + 1))
				fi
			fi
			fi					
		fi
		
		if [ $type -eq 2 ]
		then 
			#load2=`java checkloadgrid 2`
			if [ $JobID -le $goal ]
			then
				#if [ $load2 -lt 300 ]
				#then
					com=2
					JobID=$(($JobID + 1))
					echo "Complete at com = 2"
					complete=$(($complete + 1))
					submit=1
					#echo "complete $complete files"
				#fi
			fi	
				
		fi

		
		if [ $JobID -le $goal ]
		then
			if [ $type -eq 2 ]
			then
				script=encode
			else
				script=encodean			
			fi
		
			if [ $JobID -eq 1 ]
			then
			
				script=$script
			else 
				buff=_buff
				script=$script$buff
			fi
			if [ $submit -eq 1 ]
			then
				cat encode1.rsl | sed s/grid1/grid$JobID/g > encode_buff$JobID.rsl
				cat encodean1.rsl | sed s/grid1/grid$JobID/g > encodean_buff$JobID.rsl
				submit=0
				globusrun-ws -submit -batch -o slice$com.epr -S -F https://test$com.kmitl.ac.th:8443/wsrf/services/ManagedJobFactoryService -f $script$JobID.rsl&
				echo "Send Process ID : $JobID ";
				echo "Com : $com"; 
			fi
		fi
	else
		if [ $type -eq 3 ]
		then
			comPBS=`./checkload.sh`

			if [ -f "output/mpeg4_slicegrid$comjobID4.avi" ]
			then
				if [ $JobID -le $goal ]
				then
					JobID=$(($JobID + 1))
					echo "Complete at com = 4   JobID = $comjobID4"
					if [ $comPBS -eq 4 ]
					then
						comjobID4=$JobID
					fi
				
					#echo "complete $complete files"
					complete=$(($complete + 1))
					cat "testclusterbck.sh" | sed s/grid1/grid$JobID/g > "testcluster$comPBS.sh"
					/opt/pbs/bin/qsub -l nodes=test$comPBS.kmitl.ac.th "testcluster$comPBS.sh"
					echo "Send Job ID : $JobID";
					echo "to Com : $comPBS"; 
				fi
			fi
			else if [ -f "output/mpeg4_slicegrid$comjobID5.avi" ]
			then
				
				if [ $JobID -le $goal ]
				then
					JobID=$(($JobID + 1))
					echo "Complete at com = 5   JobID = $comjobID5"
					if [ $comPBS -eq 5 ]
					then
						comjobID5=$JobID
					fi
				
					#echo "complete $complete files"

					complete=$(($complete + 1))
					cat "testclusterbck.sh" | sed s/grid1/grid$JobID/g > "testcluster$comPBS.sh"
					/opt/pbs/bin/qsub -l nodes=test$comPBS.kmitl.ac.th "testcluster$comPBS.sh"
					echo "Send Job ID : $JobID";
					echo "to Com : $comPBS"; 
				fi
			fi
		fi
	fi
	type=$(($type + 1))
	if [ $type -gt $alltype ]
	then 
		type=1;
	fi
done
file=1
echo "---------------------All complete------------------"
filecount=1
checkjob=0
while [ $checkjob -eq 0 ]
do
	while [ -f "output/mpeg4_slicegrid$filecount.avi" ]
	do
		filecount=$(($filecount + 1))
	done

	filecount=$(($filecount - 1))
	if [ $filecount -eq $goal ]
	then
		echo "All Job Complete"
		checkjob=1
	fi
done
#touch output/mpeg4_slicegrid.avi
#while [ $file -le 6 ]
#do
#	echo "=======================  $file  ========================"
#	cat output/mpeg4_slicegrid.avi output/mpeg4_slicegrid$file.avi > output/tmpfile.avi
#	mencoder -o output/mpeg4_slicegrid.avi -noidx -oac copy -ovc copy output/tmpfile.avi
#	file=$(($file + 1))	
#done

