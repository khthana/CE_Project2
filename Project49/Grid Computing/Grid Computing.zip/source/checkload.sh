#! /bin/ksh
/opt/pbs/bin/pbsnodes -a | grep test4.kmitl.ac.th > load.txt
load1=`java checkload`

/opt/pbs/bin/pbsnodes -a | grep test5.kmitl.ac.th > load.txt
load2=`java checkload`

if [ $load1 -gt $load2 ]
then
	echo 5
else
	echo 4
fi


	
