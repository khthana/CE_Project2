#! /bin/ksh

/opt/pbs/bin/pbsnodes -a | grep test4.kmitl.ac.th > test.txt
load1=`java checkload`
job1=`java checkjob`
#echo test1 $load1
/opt/pbs/bin/pbsnodes -a | grep test5.kmitl.ac.th > test.txt
load2=`java checkload`
job2=`java checkjob`
#echo test2 $load2
if [ $load2 -gt $load1 ]
then
	if [ $job1 == "free" ]
	then
		echo 4
	else 
		echo 0
	fi
else
	if [ $job2 == "free" ]
	then
		echo 5
	else
		echo 0
	fi
fi



	
