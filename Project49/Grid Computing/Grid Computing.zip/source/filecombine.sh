#! /bin/ksh
file=1
while [ $file -le 6 ]
do
	echo "=======================  $file  ========================"
	cat output/mpeg4_slicegrid.avi output/mpeg4_slicegrid$file.avi > output/tmpfile.avi
	mencoder -o output/mpeg4_slicegrid.avi -noidx -oac copy -ovc copy output/tmpfile.avi
	file=$(($file + 1))	
done
