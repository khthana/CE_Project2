#!/bin/sh
#PBS -W stagein=/home/nodeB/slicegrid8.avi@test2:/home/nodeB/gridmethod/slicegrid8.avi
#PBS -W stageout=/home/nodeB/mpeg4_slicegrid8.avi@test2:/home/nodeB/gridmethod/output/mpeg4_slicegrid8.avi

/usr/bin/mencoder slicegrid8.avi -vf harddup -ovc lavc -oac lavc -lavcopts vcodec=mpeg4:vqmax=4:acodec=ac3:abitrate=128 -of avi -o /home/nodeB/mpeg4_slicegrid8.avi
