Imports System.IO

Public Class Form1
    Private Declare Function SetCursorPos Lib "user32" Alias "SetCursorPos" (ByVal x As Integer, ByVal y As Integer) As Long
    Private Declare Function GetCursorPos Lib "user32.dll" (ByRef lpPoint As POINTAPI) As Long
    Declare Auto Sub mouse_event Lib "user32.dll" (ByVal dwFlags As Int32, ByVal dx As Int32, ByVal dy As Int32, ByVal cButtons As Int32, ByVal dwExtraInfo As IntPtr)
    Public Const MOUSEEVENTF_LEFTDOWN = &H2
    Public Const MOUSEEVENTF_LEFTUP = &H4
    Public Const MOUSEEVENTF_RIGHTDOWN = &H8
    Public Const MOUSEEVENTF_RIGHTUP = &H10

    Public Structure POINTAPI
        Public x As Integer
        Public y As Integer
    End Structure

    Private filename1 As String = Windows.Forms.Application.StartupPath + "\wav\test1.wav"
    Private filename2 As String = Windows.Forms.Application.StartupPath + "\wav\test2.wav"
    Private path As String = Windows.Forms.Application.StartupPath
    Public r_Image As Integer
    Public m_Image As Integer
    Public Threshold_value As Short = 80
    Public get_point As Boolean
    Public radius As Integer = 5
    Public CenterX As Integer
    Public CenterY As Integer
    Public RectangleLeft As Integer
    Public RectangleRight As Integer
    Public RectangleTop As Integer
    Public RectangleButtom As Integer
    Public im As Image
    Public rec As Rectangle

    Public Sub LeftDown()
        Call mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    End Sub

    Public Sub LeftUp()
        Call mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    End Sub

    Public Sub RightDown()
        Call mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
    End Sub

    Public Sub RightUp()
        Call mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
    End Sub

    Private Sub init_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles init.Click
        VideoOCX1.SetErrorMessages((False))
        If Not VideoOCX1.Init Then
            MsgBox(VideoOCX1.GetLastErrorString)
        Else
            r_Image = VideoOCX1.GetGrayImageHandle
            VideoOCX1.Start()
            CamTimer.Enabled = True
            get_point = False
        End If
    End Sub

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        CamTimer.Enabled = False
        WavTimer1.Enabled = False
        WavTimer2.Enabled = False
        Form2.Close()
        VideoOCX1.Stop()
        VideoOCX1.Close()
    End Sub

    Private Sub CamTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CamTimer.Tick
        'Capture image
        VideoOCX1.Capture(r_Image)
        VideoOCXTools1.Threshold(r_Image, Threshold_value, r_Image)
        If get_point Then
            Dim i As Integer = movemouse()
            Dim mouse As POINTAPI
            GetCursorPos(mouse)
            Select Case i
                Case 1
                    SetCursorPos(mouse.x - 20, mouse.y)
                Case 2
                    SetCursorPos(mouse.x + 20, mouse.y)
                Case 3
                    SetCursorPos(mouse.x, mouse.y - 15)
                Case 4
                    SetCursorPos(mouse.x, mouse.y + 15)
            End Select
            VideoOCXTools1.DrawCircle(r_Image, CenterX, CenterY, radius, 255, 255, 0)
            VideoOCXTools1.DrawRectangle(r_Image, RectangleLeft, RectangleTop, RectangleRight, RectangleButtom, 255, 255, 0)
        End If
        VideoOCX1.Show(r_Image)
        VideoOCXTools1.Crop(r_Image, rec.Left, rec.Top, rec.Right, rec.Bottom, m_Image)
        im = VideoOCX1.ToPicture(m_Image)
        Form2.PictureBox1.Image = im
        If Form2.Width <> Form2.PictureBox1.Width + 10 Then
            Form2.Width = Form2.PictureBox1.Width + 10
        End If
    End Sub

    Private Function movemouse() As Integer
        Dim matrix As Object
        Dim x As Integer
        Dim y As Integer

        matrix = VideoOCX1.GetMatrix(r_Image)

        While matrix(CenterX - radius, CenterY) = 0
            If CenterX - radius < RectangleLeft Then
                Return 1
            End If
            CenterX -= 1
        End While
        x = CenterX

        While matrix(CenterX + radius, CenterY) = 0
            If CenterX + radius > RectangleRight Then
                Return 2
            End If
            CenterX += 1
        End While
        CenterX = x + ((CenterX - x) / 2)

        While matrix(CenterX, CenterY - radius) = 0
            If CenterY - radius < RectangleTop Then
                Return 3
            End If
            CenterY -= 1
        End While
        y = CenterY

        While matrix(CenterX, CenterY + radius) = 0
            If CenterY + radius > RectangleButtom Then
                Return 4
            End If
            CenterY = CenterY + 1
        End While
        CenterY = y + ((CenterY - y) / 2)
        Return 0
    End Function

    Private Sub Select_Point(ByVal sender As System.Object, ByVal e As AxVIDEOOCXLib._DVideoOCXEvents_MouseDownEvent) Handles VideoOCX1.MouseDownEvent
        Dim matrix As Object
        Dim x1 As Integer
        Dim y1 As Integer
        Dim x2 As Integer
        Dim y2 As Integer
        Dim r As Integer

        If Not get_point Then
            VideoOCX1.Capture(r_Image)
            VideoOCXTools1.Threshold(r_Image, Threshold_value, r_Image)
            matrix = VideoOCX1.GetMatrix(r_Image)
            x1 = e.x
            y1 = e.y
            If matrix(x1, y1) = 0 Then
                While matrix(x1, y1) = 0 And x1 > 0
                    x1 = x1 - 1
                End While
                x2 = x1 + 1
                While matrix(x2, y1) = 0 And x2 < 300
                    x2 = x2 + 1
                End While
                CenterX = x1 + ((x2 - x1) / 2)
                r = (x2 - x1) / 2

                While matrix(CenterX, y1) = 0 And y1 > 0
                    y1 = y1 - 1
                End While
                y2 = y1 + 1
                While matrix(CenterX, y2) = 0 And y2 < 220
                    y2 = y2 + 1
                End While
                CenterY = y1 + ((y2 - y1) / 2)
                If r > ((y2 - y1) / 2) Then
                    r = (y2 - y1) / 2
                End If
                If r < 40 Then
                    radius = r
                End If

                VideoOCXTools1.DrawCircle(r_Image, CenterX, CenterY, radius, 255, 255, 0)

                If CenterX - radius > 10 And CenterX + radius < 310 Then
                    RectangleLeft = CenterX - radius - 10
                    RectangleRight = CenterX + radius + 10
                ElseIf CenterX - radius < 10 Then
                    RectangleLeft = 0
                    RectangleRight = (radius * 2) + 20
                ElseIf CenterX + radius > 310 Then
                    RectangleLeft = 300 - (radius * 2)
                    RectangleRight = 320
                End If

                If CenterY - radius > 10 And CenterY + radius < 230 Then
                    RectangleTop = CenterY - radius - 10
                    RectangleButtom = CenterY + radius + 10
                ElseIf CenterY - radius < 10 Then
                    RectangleTop = 0
                    RectangleButtom = (radius * 2) + 20
                ElseIf CenterY + radius > 230 Then
                    RectangleTop = 220 - (radius * 2)
                    RectangleButtom = 240
                End If

                VideoOCXTools1.DrawRectangle(r_Image, RectangleLeft, RectangleTop, RectangleRight, RectangleButtom, 255, 255, 0)
                VideoOCX1.Show(r_Image)
                get_point = True

                Dim p As Point
                p.X = Screen.PrimaryScreen.Bounds.Width - Form2.Width
                p.Y = 0
                Form2.Location = p
                Form2.Show()

                m_Image = VideoOCX1.CreateGrayImageHandle(100, 100)
                rec.Size = Form2.PictureBox1.Size
                If CenterX > 50 And CenterX < 270 Then
                    rec.X = CenterX - 50
                ElseIf CenterX < 50 Then
                    rec.X = 0
                ElseIf CenterX > 270 Then
                    rec.X = 220
                End If

                If CenterY > 50 And CenterY < 190 Then
                    rec.Y = CenterY - 50
                ElseIf CenterY < 50 Then
                    rec.Y = 0
                ElseIf CenterY > 190 Then
                    rec.Y = 140
                End If
                VideoOCXTools1.Crop(r_Image, rec.Left, rec.Top, rec.Right, rec.Bottom, m_Image)
                im = VideoOCX1.ToPicture(m_Image)
                Form2.PictureBox1.Image = im

                WaveExCtrl1.Record(filename1) 'Start Recording
                WavTimer1.Start()
            End If
        End If
    End Sub

    Private Sub WavTimer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WavTimer1.Tick
        WavTimer1.Stop()
        Try
            WaveExCtrl1.RecordStop() 'Stop Recording
            recog(True)
            WaveExCtrl1.Record(filename2) 'Start Recording
        Catch er As Exception
        Finally
        End Try
        WavTimer2.Start()
    End Sub

    Private Sub WavTimer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WavTimer2.Tick
        WavTimer2.Stop()
        Try
            WaveExCtrl1.RecordStop() 'Stop Recording
            recog(False)
            WaveExCtrl1.Record(filename1) 'Start Recording
        Catch er As Exception
        Finally
        End Try
        WavTimer1.Start()
    End Sub

    Private Sub recog(ByVal file As Boolean)
        Dim s1, s2 As String
        If file Then
            s1 = path + "\recogfile1.bat"
            s2 = path + "\output1.mlf"
        Else
            s1 = path + "\recogfile2.bat"
            s2 = path + "\output2.mlf"
        End If
        Shell(s1, AppWinStyle.Hide)
        readfile(s2)
    End Sub

    Private Sub readfile(ByVal file As String)
        Dim s As String
        Dim arr() As String
        Label1.Text = "ngiiap2"
        Try
            Dim myfile As New FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read)
            Dim reader As New StreamReader(myfile)
            reader.ReadLine()
            reader.ReadLine()
            s = reader.ReadLine()
            If s <> Nothing Then
                arr = s.Split(" ")
                While Not arr(0).Equals(".")
                    If arr(2).Equals("ngiiap2") Then
                        s = reader.ReadLine()
                        arr = s.Split(" ")
                    Else
                        Label1.Text = arr(2)
                        arr(0) = "."
                        mouse(arr(2))
                    End If
                End While
            End If
            reader.Close()
            myfile.Close()
        Catch er1 As FileNotFoundException
        Catch er2 As Exception
        Finally
        End Try
    End Sub

    Private Sub mouse(ByVal command As String)
        If command.Equals("kot1") Then
            LeftDown()
            LeftUp()
        ElseIf command.Equals("dap1") Then
            LeftDown()
            LeftUp()
            LeftDown()
            LeftUp()
        ElseIf command.Equals("khwaa4") Then
            RightDown()
            RightUp()
        ElseIf command.Equals("laak2") Then
            LeftDown()
        ElseIf command.Equals("pl@@j1") Then
            LeftUp()
        End If
    End Sub

End Class
