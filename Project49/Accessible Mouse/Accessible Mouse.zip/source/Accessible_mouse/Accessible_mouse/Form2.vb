Public Class Form2
    Private switch As Boolean = False
    Private origin As Point

    Private Sub Form2_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.MouseEnter
        switch = Not switch
        origin.Y = 0
        If switch Then
            origin.X = 0
        Else
            origin.X = Screen.PrimaryScreen.Bounds.Width - Me.Width
        End If
        Me.Location = origin
    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseEnter
        switch = Not switch
        origin.Y = 0
        If switch Then
            origin.X = 0
        Else
            origin.X = Screen.PrimaryScreen.Bounds.Width - Me.Width
        End If
        Me.Location = origin
    End Sub
End Class