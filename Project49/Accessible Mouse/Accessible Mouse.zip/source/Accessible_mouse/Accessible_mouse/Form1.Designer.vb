<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.VideoOCX1 = New AxVIDEOOCXLib.AxVideoOCX
        Me.VideoOCXTools1 = New AxVIDEOOCXTOOLSLib.AxVideoOCXTools
        Me.WaveExCtrl1 = New AxWAVEEXCONTROLLib.AxWaveExCtrl
        Me.init = New System.Windows.Forms.Button
        Me.CloseButton = New System.Windows.Forms.Button
        Me.CamTimer = New System.Windows.Forms.Timer(Me.components)
        Me.WavTimer1 = New System.Windows.Forms.Timer(Me.components)
        Me.WavTimer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        CType(Me.VideoOCX1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VideoOCXTools1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WaveExCtrl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VideoOCX1
        '
        Me.VideoOCX1.Enabled = True
        Me.VideoOCX1.Location = New System.Drawing.Point(3, 12)
        Me.VideoOCX1.Name = "VideoOCX1"
        Me.VideoOCX1.OcxState = CType(resources.GetObject("VideoOCX1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.VideoOCX1.Size = New System.Drawing.Size(320, 240)
        Me.VideoOCX1.TabIndex = 0
        '
        'VideoOCXTools1
        '
        Me.VideoOCXTools1.Enabled = True
        Me.VideoOCXTools1.Location = New System.Drawing.Point(245, 258)
        Me.VideoOCXTools1.Name = "VideoOCXTools1"
        Me.VideoOCXTools1.OcxState = CType(resources.GetObject("VideoOCXTools1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.VideoOCXTools1.Size = New System.Drawing.Size(32, 32)
        Me.VideoOCXTools1.TabIndex = 1
        '
        'WaveExCtrl1
        '
        Me.WaveExCtrl1.Enabled = True
        Me.WaveExCtrl1.Location = New System.Drawing.Point(283, 258)
        Me.WaveExCtrl1.Name = "WaveExCtrl1"
        Me.WaveExCtrl1.OcxState = CType(resources.GetObject("WaveExCtrl1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.WaveExCtrl1.Size = New System.Drawing.Size(32, 32)
        Me.WaveExCtrl1.TabIndex = 2
        Me.WaveExCtrl1.Visible = False
        '
        'init
        '
        Me.init.Location = New System.Drawing.Point(12, 267)
        Me.init.Name = "init"
        Me.init.Size = New System.Drawing.Size(75, 23)
        Me.init.TabIndex = 3
        Me.init.Text = "init"
        Me.init.UseVisualStyleBackColor = False
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(102, 267)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(75, 23)
        Me.CloseButton.TabIndex = 4
        Me.CloseButton.Text = "close"
        Me.CloseButton.UseVisualStyleBackColor = False
        '
        'CamTimer
        '
        Me.CamTimer.Interval = 250
        '
        'WavTimer1
        '
        Me.WavTimer1.Interval = 600
        '
        'WavTimer2
        '
        Me.WavTimer2.Interval = 600
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(200, 272)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 13)
        Me.Label1.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 305)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.init)
        Me.Controls.Add(Me.WaveExCtrl1)
        Me.Controls.Add(Me.VideoOCXTools1)
        Me.Controls.Add(Me.VideoOCX1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Accessible Mouse"
        CType(Me.VideoOCX1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VideoOCXTools1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WaveExCtrl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents VideoOCX1 As AxVIDEOOCXLib.AxVideoOCX
    Friend WithEvents VideoOCXTools1 As AxVIDEOOCXTOOLSLib.AxVideoOCXTools
    Friend WithEvents init As System.Windows.Forms.Button
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents CamTimer As System.Windows.Forms.Timer
    Friend WithEvents WavTimer1 As System.Windows.Forms.Timer
    Friend WithEvents WavTimer2 As System.Windows.Forms.Timer
    Public WithEvents WaveExCtrl1 As AxWAVEEXCONTROLLib.AxWaveExCtrl
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
