#ifndef __MOCOMP_H__
#define __MOCOMP_H__

#include "common.h"
#include "mode_pred.h"

//void MotionCompensateTB(frame *this, frame *ref, int org_x, int org_y,
//                        int mvx, int mvy);

//void MotionCompensateMB(frame *this, frame *ref, mode_pred_info *mpi,
//                        int org_x, int org_y);

void MotionCompensateTB(frame *this_, frame *ref, int org_x, int org_y,
                        int mvx, int mvy);

void MotionCompensateMB(frame *this_, frame *ref, mode_pred_info *mpi,
                        int org_x, int org_y);
typedef struct __luma_stack{
	unsigned char ls[4][3]; 

}luma_stack;

#endif /*__MOCOMP_H__*/
