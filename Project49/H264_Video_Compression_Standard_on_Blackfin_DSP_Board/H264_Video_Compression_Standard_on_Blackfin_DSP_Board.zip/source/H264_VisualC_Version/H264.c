// H264.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
//#include <stdio.h>
//#include <sys/types.h>
#include <time.h>

#include "common.h"
#include "input.h"
#include "coretrans.h"
#include "nal.h"

//#include "perf.h"
#include "params.h"
#include "mbmodes.h"
#include "slice.h"
#include "main.h"
//#include "iostream"
//#include "windows.h"

int main(int argc, char* argv[])
{
	//frame * f;
	
	// Test common files;

	/*f = alloc_frame(640,480); 
	printf("Address Pointer = %X Hex\n",&f );
	
	printf("Width = %d Dec\n",f->Lwidth);
	printf("High = %d Dec\n",f->Lheight);

	printf("Width = %d Dec\n",f->Cwidth);
	printf("High = %d Dec\n",f->Cheight);

	printf("char * L = %X Hex\n",f->L);

	printf("char * C[0] = %X Hex\n",f->C[0]);
	printf("char * C[1] = %X Hex\n",f->C[1]);
	free_frame(f);
		
	
	// Test Fise input.cpp
	
	printf("Peek Bit Count = %d\n",input_peek_bits(40)); 

	printf("input_get_bit = %d\n",input_get_bits(400)); */

	// Test files common.cpp
  /*
  int i;
	core_block data = {{100,50,69,34,57,34,21,13,47,37,48,32,34,57,58,77}};
	core_block result_matrix,inverse_data;
	
	result_matrix = forward_core_transform(data);

	
	printf("\nForward Core Transform\n");

	for(i=0 ; i < 16 ;++i) printf("%d ", result_matrix.items[i]);
	printf("\n");
	

	inverse_data =  inverse_core_transform_slow(result_matrix);
	printf("\nInverse Core Transform\n"); 
	
	for(i = 0 ; i < 16 ;++i) printf("%d ", inverse_data.items[i]);
	printf("\n");
	*/
	int a;
	/*time_t t1,t2;
	(void) time(&t1);*/
	//printf("");
	//a = _test_coretrans();
	
	//printf("\n");
	//a = _test_nal();
	
	//printf("\n");
	//a = _test_params(); 
	
	//printf("\n");
	//a = _test_mbmodes();
	
	//printf("\n");
	a = _test_main(25); 
	
	/*(void) time(&t2);

	printf("\nTime before run = %d seconds\n", (int) t1);	
	printf("\nTime after run = %d seconds\n", (int) t2);
	printf("\nTime to run H.264 Size 640x480 amount 30 frame = %d seconds\n", (int) t2-t1);*/

	return 0;
}

