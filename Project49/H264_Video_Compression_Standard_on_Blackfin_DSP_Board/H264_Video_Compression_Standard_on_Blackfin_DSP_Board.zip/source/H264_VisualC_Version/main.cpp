//----------------------------------------------------------------------------
//
// Purpose: To demonstrate how to use PerformanceCounter class
// Author: Ekaphol Anantapornkit
// NB: This code is for CE KMITL Data Structure Lab. (1P) class.
//
//----------------------------------------------------------------------------

#include "PerformanceCounter.hpp"

#include <iostream>

#include <windows.h>

int main()
{
    using namespace std;

    PerformanceCounter timer;
    double startTime = timer.getTime();

    ::Sleep(100);

    double finishTime = timer.getTime();
    cout << "Elapsed Time: " << finishTime - startTime << " secs" << endl;
	return 0;
}
