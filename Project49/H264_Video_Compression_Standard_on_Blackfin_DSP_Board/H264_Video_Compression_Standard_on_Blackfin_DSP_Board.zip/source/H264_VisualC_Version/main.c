

//#include "stdafx.h"

#include "common.h"
#include "input.h"
#include "nal.h"
#include "cavlc.h"
#include "params.h"
#include "slicehdr.h"
#include "slice.h"
#include "residual.h"
#include "mode_pred.h" 
#include "main.h"

#ifdef _COMMON_
  #include <unistd.h>
  #include <signal.h>
  #include <string.h>
  #include <fcntl.h>
  #include <sys/types.h>
  #include <sys/wait.h>
  #include <sys/ipc.h>
  #include <sys/stat.h>
  #include <sys/mman.h>
  #include <sys/ioctl.h> 
  #include <stdlib.h>
  #include <time.h>
  #include <sys/timeb.h>

  #define DEVICE_NODE			"/dev/sdram"
  #define IOC_SET_BASEADDR	_IO('k', 1)
#endif  

#ifdef _OUT2LCD_ 

  #define Y_ADDR		0x08000000
  #define U_ADDR		0x08100000
  #define V_ADDR		0x08200000
  
#endif
 
#ifdef _HW_

  #define HW_SIZE				    0x4B000
  
  #define BASE0x9004_ADDR       0x90040000
  //IDCT4x4
  extern volatile short         *IDCT4x4CoefFill;
  extern volatile unsigned char *IDCT4x4BusyFlag;
  extern volatile short         *IDCT4x4CoefReturn;

  #define Cof4x4_OFFSET		        0x28
  #define returnCof4x4_OFFSET	    0x38
  #define Busy4x4_OFFSET		      0x48

  //***************************************************
  #define BASE0x9005_ADDR       0x90050000

  extern volatile unsigned char *InterLPel;
  extern volatile unsigned char *InterLFrac;
  extern volatile unsigned char *InterLStart;
  extern volatile unsigned char *InterLReturn;
  extern volatile unsigned char *InterLFinish;

  extern volatile unsigned char *InterChromaPel;
  extern volatile unsigned char *InterChromaFrac;
  extern volatile unsigned char *InterChromaStart;
  extern volatile unsigned char *InterChromaReturn;
  extern volatile unsigned char *InterChromaFinish;

  #define INTERLPEL             0x00
  #define INTERLFRAC            0x08
  #define INTERLSTART           0x10
  #define INTERLRETURN          0x18
  #define INTERLFINISH          0x20

  #define INTERCHROMAPEL        0x28
  #define INTERCHROMAFRAC       0x30
  #define INTERCHROMASTART      0x38
  #define INTERCHROMARETURN     0x40
  #define INTERCHROMAFINISH     0x48

  //***************************************************
  #define BASE0x9006_ADDR       0x90060000

  extern volatile unsigned char *IntraL4x4PredPel;
  extern volatile unsigned char *IntraL4x4PredMode;
  extern volatile unsigned char *IntraL4x4PredStart;
  extern volatile unsigned char *IntraL4x4PredReturn;
  extern volatile unsigned char *IntraL4x4PredFinish;
    
  extern volatile unsigned char *IntraPredAvail;

  extern volatile unsigned char *IntraL16x16PredPel;
  extern volatile unsigned char *IntraL16x16PredMode;
  extern volatile unsigned char *IntraL16x16PredStart;
  extern volatile unsigned char *IntraL16x16PredReturn;
  extern volatile unsigned char *IntraL16x16PredFinish;

  extern volatile unsigned char *IntraChromaPredPel;
  extern volatile unsigned char *IntraChromaPredMode;
  extern volatile unsigned char *IntraChromaPredStart;
  extern volatile unsigned char *IntraChromaPredReturn;
  extern volatile unsigned char *IntraChromaPredFinish;

  #define INTRAL4x4PREDPEL_ADDR       0x00
  #define INTRAL4x4PREDMODE_ADDR      0x08
  #define INTRAPREDAVAIL_ADDR         0x10
  #define INTRAL4x4PREDSTART_ADDR     0x18
  #define INTRAL4x4PREDRETURN_ADDR    0x20
  #define INTRAL4x4PREDFINISH_ADDR    0x28

  #define INTRAL16x16PREDPEL_ADDR       0x58
  #define INTRAL16x16PREDMODE_ADDR      0x60
  #define INTRAL16x16PREDSTART_ADDR     0x68
  #define INTRAL16x16PREDRETURN_ADDR    0x70
  #define INTRAL16x16PREDFINISH_ADDR    0x78

  #define INTRACHROMAPREDPEL_ADDR     0x80
  #define INTRACHROMAPREDMODE_ADDR    0x88
  #define INTRACHROMAPREDSTART_ADDR   0x90
  #define INTRACHROMAPREDRETURN_ADDR  0x98
  #define INTRACHROMAPREDFINISH_ADDR  0xA0

#endif


frame *this_ = NULL, *ref = NULL;
mode_pred_info *mpi=NULL;
int frame_no;
nal_unit nalu;
seq_parameter_set sps;
pic_parameter_set pps;
slice_header sh;

#ifdef _COMMON_
  
/* global data. */
  int	iProt = PROT_READ | PROT_WRITE;
  int iFlags = MAP_SHARED;

  int MapMemory (int fd,int BaseAddress,int BaseSize,volatile unsigned char **MapAddress){
	  if(-1==ioctl(fd, IOC_SET_BASEADDR, &BaseAddress)) {

		  return 0;
	  }
	  *MapAddress = (volatile unsigned char*)mmap((void *)0, BaseSize, iProt, iFlags, fd, 0);
	  if( -1 == (int)MapAddress){

		  close(fd);
		  return 0;
	  }

	  return 1;
  }
#endif

#ifdef _OUT2LCD_ 

  void ToLCD(volatile unsigned char* dstBase,volatile unsigned char* srcBase,int hSize,int vSize,unsigned char Lumaflag)
  {
    int HSize = 640;
    int VSize = 480;
    int i;
    int j;
    if(!Lumaflag)
    {
      HSize >>= 1;
      VSize >>= 1;
    }
    //Fill & pad rigth.
    for(j=0;j<vSize;j++)
      for(i=0;i<HSize;i++)
      {
        if(i>=hSize)
        {
          if(Lumaflag)
            *dstBase++ = 16;
          else
            *dstBase++ = 128;
        } else

        if(i<hSize)
          *dstBase++ = *srcBase++;
      }

    //Pad bottom.
    for(j=vSize;j<VSize;j++)
      for(i=0;i<HSize;i++)
      {
        if(Lumaflag)
          *dstBase++ = 16;
        else
          *dstBase++ = 128;
      }      
  }
#endif

int h264_open(char *filename) 
{
  int have_sps=0,have_pps=0;
  if(!input_open(filename)) 
  {
    fprintf(stderr,"H.264 Error: Cannot open input file!\n");
    return 0;
  }
  
  init_code_tables();
  frame_no=0;
  while(get_next_nal_unit(&nalu)) {
    switch(nalu.nal_unit_type) {
      case 7:  // sequence parameter set //
        if(have_sps)
          fprintf(stderr,"H.264 Warning: Duplicate sequence parameter set, skipping!\n");
        else {
          decode_seq_parameter_set(&sps);
          have_sps=1;
        }
        break;
      case 8:  // picture parameter set //
        if(!have_sps)
          fprintf(stderr,"H.264 Warning: Picture parameter set without sequence parameter set, skipping!\n");
        else if(have_pps)
          fprintf(stderr,"H.264 Warning: Duplicate picture parameter set, skipping!\n");
        else {
          decode_pic_parameter_set(&pps);
          have_pps=1;
          if(check_unsupported_features(&sps,&pps)) {   //<< KrisMT comment
            fprintf(stderr,"H.264 Error: Unsupported features found in headers!\n");
            input_close();
            return 0;
          }
          this_= alloc_frame(sps.PicWidthInSamples,sps.FrameHeightInSamples);
          ref=alloc_frame(sps.PicWidthInSamples,sps.FrameHeightInSamples);
          mpi=alloc_mode_pred_info(sps.PicWidthInSamples,sps.FrameHeightInSamples);
          return (sps.FrameHeightInSamples<<16)|sps.PicWidthInSamples;
        }
        break;
      case 1: case 5:  // coded slice of a picture //
        fprintf(stderr,"H.264 Warning: Pictures sent before headers!\n");
        break;
      default:  // unsupported NAL unit type //
        fprintf(stderr,"H.264 Warning: NAL unit with unsupported type, skipping!\n");
    }
  }
  fprintf(stderr,"H.264 Error: Unexpected end of file!\n");
  return 0;
}



frame *h264_decode_frame(int verbose) {
  while(get_next_nal_unit(&nalu))
    if(nalu.nal_unit_type==1 || nalu.nal_unit_type==5) {
      perf_enter("slice decoding");
      ++frame_no;
      decode_slice_header(&sh,&sps,&pps,&nalu);
      if(verbose)
        printf("Frame%4d: %s",frame_no,_str_slice_type(sh.slice_type));
      if(sh.slice_type!=I_SLICE && sh.slice_type!=P_SLICE)
        fprintf(stderr,"H.264 Warning: Unsupported slice type (%s), skipping!\n",
                       _str_slice_type(sh.slice_type));
      else {
        frame *temp;
        decode_slice_data(&sh,&sps,&pps,&nalu,this_,ref,mpi);
        temp = this_; this_ = ref; ref=temp;
        return temp;
      }
    } else if(nalu.nal_unit_type!=7 && nalu.nal_unit_type!=8)
      fprintf(stderr,"H.264 Warning: unexpected or unsupported NAL unit type!\n");
  return NULL;
}

void h264_rewind() {
  input_rewind();
  frame_no=0;
}

void h264_close() 
{
  free_frame(this_);
  free_frame(ref);
  //free_mode_pred_info(mpi);
  input_close();
}


int h264_frame_no() {
  return frame_no;
}


///////////////////////////////////////////////////////////////////////////////

//#ifdef BUILD_TESTS

//int _test_main(int argc, char *argv[]) 

int _test_main(int num_frame) 

{
	FILE *out;
	frame *f;
	int info;
#ifdef _COMMON_
  int fd;
#endif

#ifdef _TIME_
  struct timeb KrisMTtstruct_start;
  struct timeb KrisMTtstruct_end;
  int me_tmp_time = 0;
  int KrisMTtotaltime = 0;
#endif

#ifdef _HW_
  volatile unsigned char* Add0x9004Ptr;
  volatile unsigned char* Add0x9005Ptr;
  volatile unsigned char* Add0x9006Ptr;
#endif

#ifdef _OUT2LCD_

  volatile unsigned char* YPtr;
  volatile unsigned char* UPtr;
  volatile unsigned char* VPtr;
  

  fd = open(DEVICE_NODE,O_RDWR);
  if(fd == 0)
  {
    printf("Can not open mmap device\n");
    exit(1);
  }

	/* Initial Y U V plane pointer. */
	if(!MapMemory(fd,Y_ADDR,HW_SIZE,&YPtr))
	{
		printf("Cannot map memory\n");
		exit(1);
	}

  if(!MapMemory(fd,U_ADDR,HW_SIZE,&UPtr))
	{
		printf("Cannot map memory\n");
		exit(1);
	}	

	if(!MapMemory(fd,V_ADDR,HW_SIZE,&VPtr))
	{
		printf("Cannot map memory\n");
		exit(1);
	}
#endif

#ifdef _HW_  
  if(!MapMemory(fd,BASE0x9004_ADDR,HW_SIZE,&Add0x9004Ptr))
  {
    printf("Cannot map memory 0x%08X\n",BASE0x9004_ADDR);
    exit(1);
  }

  if(!MapMemory(fd,BASE0x9005_ADDR,HW_SIZE,&Add0x9005Ptr))
  {
    printf("Cannot map memory 0x%08X\n",BASE0x9005_ADDR);
    exit(1);
  }

  if(!MapMemory(fd,BASE0x9006_ADDR,HW_SIZE,&Add0x9006Ptr))
  {
    printf("Cannot map memory 0x%08X\n",BASE0x9006_ADDR);
    exit(1);
  }
  //************************ 0x9004 Location *********************************
  IDCT4x4CoefFill   = (volatile         short*)(((unsigned char*)Add0x9004Ptr) + Cof4x4_OFFSET);
  IDCT4x4BusyFlag   = (volatile unsigned char*)(((unsigned char*)Add0x9004Ptr) + Busy4x4_OFFSET);
  IDCT4x4CoefReturn = (volatile         short*)(((unsigned char*)Add0x9004Ptr) + returnCof4x4_OFFSET);

  //************************ 0x9005 Location *********************************
  InterLPel     = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERLPEL);
  InterLFrac    = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERLFRAC);
  InterLStart   = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERLSTART);
  InterLReturn  = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERLRETURN);
  InterLFinish  = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERLFINISH);

  InterChromaPel      = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERCHROMAPEL);
  InterChromaFrac     = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERCHROMAFRAC);
  InterChromaStart    = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERCHROMASTART);
  InterChromaReturn   = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERCHROMARETURN);
  InterChromaFinish   = (volatile unsigned char*)(((unsigned char*)Add0x9005Ptr) + INTERCHROMAFINISH);

  ///************************ 0x9006 Location ********************************
  IntraL4x4PredPel      = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL4x4PREDPEL_ADDR);
  IntraL4x4PredMode     = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL4x4PREDMODE_ADDR);
  IntraL4x4PredStart    = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL4x4PREDSTART_ADDR);
  IntraL4x4PredReturn   = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL4x4PREDRETURN_ADDR);
  IntraL4x4PredFinish   = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL4x4PREDFINISH_ADDR);
  IntraPredAvail        = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAPREDAVAIL_ADDR);

  IntraL16x16PredPel    = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL16x16PREDPEL_ADDR);
  IntraL16x16PredMode   = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL16x16PREDMODE_ADDR);
  IntraL16x16PredStart  = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL16x16PREDSTART_ADDR);
  IntraL16x16PredReturn = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL16x16PREDRETURN_ADDR);
  IntraL16x16PredFinish = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRAL16x16PREDFINISH_ADDR);


  IntraChromaPredPel    = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRACHROMAPREDPEL_ADDR);
  IntraChromaPredMode   = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRACHROMAPREDMODE_ADDR);
  IntraChromaPredStart  = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRACHROMAPREDSTART_ADDR);
  IntraChromaPredReturn = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRACHROMAPREDRETURN_ADDR);
  IntraChromaPredFinish = (volatile unsigned char*)(((unsigned char*)Add0x9006Ptr) + INTRACHROMAPREDFINISH_ADDR);

#endif
  info = h264_open ("test.264") ;
	
	if(!info) return 1;

	if(!(out=fopen("out.yuv","wb"))) 
	{
		fprintf(stderr,"Error: Cannot open output file!\n");
		return 1;
	}

	printf("H.264 stream, %dx%d pixels\n",H264_WIDTH(info),H264_HEIGHT(info));
	
	
	while(1) 
	{
#ifdef _TIME_
    ftime (&(KrisMTtstruct_start));
#endif

    f = h264_decode_frame(1);

		printf("\n");
#ifdef _OUT2LCD_
    ToLCD(YPtr,f->L,f->Lpitch,f->Lheight,1);
    ToLCD(UPtr,f->C[0],f->Cpitch,f->Cheight,0);
    ToLCD(VPtr,f->C[1],f->Cpitch,f->Cheight,0);
#else
		fwrite(f->L,f->Lpitch,f->Lheight,out);
		fwrite(f->C[0],f->Cpitch,f->Cheight,out);
		fwrite(f->C[1],f->Cpitch,f->Cheight,out);
#endif		

#ifdef _TIME_
    ftime (&(KrisMTtstruct_end));               // stop time ms
    me_tmp_time=(KrisMTtstruct_end.time*1000+KrisMTtstruct_end.millitm) - (KrisMTtstruct_start.time*1000+KrisMTtstruct_start.millitm); 
		KrisMTtotaltime += me_tmp_time;
		printf("Now Diff  time = %d\n",me_tmp_time);
		printf("Now total time = %d\n",KrisMTtotaltime);
#endif

		if(frame_no >= num_frame) break;
		
	}

#ifdef _OUT2LCD_
  close(fd);
#endif
  
	fclose(out);
	h264_close(); 
	
	return 0;
}

//#endif
