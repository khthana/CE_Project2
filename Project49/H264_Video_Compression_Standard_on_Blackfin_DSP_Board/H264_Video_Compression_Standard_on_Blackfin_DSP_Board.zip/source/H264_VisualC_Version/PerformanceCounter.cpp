#include "PerformanceCounter.hpp"

#include <windows.h>

double PerformanceCounter::getTime() const
{
    const long count = getTimeCount();
    const double sec = double(count / freq_);
    return sec + (double(count % freq_) / freq_);
}

long PerformanceCounter::getTimeCount() const
{
    LARGE_INTEGER count;
    ::QueryPerformanceCounter(&count);
    return count.QuadPart;
}

PerformanceCounter::PerformanceCounter(): freq_(0)
{
    LARGE_INTEGER freq;
    ::QueryPerformanceFrequency(&freq);
    freq_ = freq.QuadPart;
}
