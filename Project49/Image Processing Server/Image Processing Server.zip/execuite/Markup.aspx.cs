using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace ImageMarkup
{
	/// <summary>
	/// Summary description for Markup.
	/// </summary>
	public partial class Markup : System.Web.UI.Page
	{
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			string desc = HttpUtility.HtmlDecode(Request.Params["desc"]);
			if (desc==null)
			{
				desc = string.Empty;
			}
			MarkupImage("image.jpg", desc);
		}
        
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		private void MarkupImage(string image, string desc)
		{
			Bitmap bitmap = new Bitmap(Server.MapPath(image));
			MemoryStream memStream = new MemoryStream();

			Graphics g = Graphics.FromImage(bitmap);
			g.SmoothingMode = SmoothingMode.AntiAlias;
		
			// Draw each annotation object of MarkableType, ; separated
			if (desc.IndexOf(";")>0)
			{
				int width = bitmap.Width;
				int height = bitmap.Height;

				string[] xys = desc.Split(';');
				Point[] points = new Point[xys.Length];
				ArrayList marks = new ArrayList(xys.Length);
				
				int i=0;
				foreach (string xy in xys)
				{
					// Internally comma separated
					string[] tmp = xy.Split(',');

					if (tmp.Length <=2)
					{
						// skip if incomplete pair
						continue;
					}

					// Get x, y
					int x = int.Parse(tmp[0]);
					int y = int.Parse(tmp[1]);
					points[i++] = new Point(x, y);

					// Get type
					string typeid = tmp[2];
				
					// Get the rest as the arguments
					string param = string.Empty;
					if (tmp.Length == 4)
					{
						param = tmp[3];
					}
					else if (tmp.Length > 4)
					{
						string[] rest = new string[tmp.Length-3];
						for (int j=3; j<tmp.Length; j++)
						{
							rest[j-3]=tmp[j];
						}
						param = string.Join(",", rest);
					}

					// Create MarkableType oject from its string form
					MarkableType mark = MarkManager.CreateByID(typeid);
					if (param.Length > 0)
					{
						mark.LoadFromString(param);
					}
					marks.Add(mark);
				}
                
				// The number of marks is i
                SolidBrush brush = new SolidBrush(Color.White);
				for(int j=0; j<i; j++)
				{
					string familyName = "Tahoma";

					Font font;
					font = new Font(familyName, 0.1F, FontStyle.Bold);

					StringFormat format = new StringFormat();
					format.Alignment = StringAlignment.Center;
					format.LineAlignment = StringAlignment.Center;

					// Draw an identifier
					g.DrawString(j.ToString(), font, brush, 
						new Point(points[j].X+12, points[j].Y), format);

					// Draw the annotation itself
					MarkManager.Draw(g, points[j].X, points[j].Y, (MarkableType)marks[j]);
				
              
                }
				brush.Dispose();
			}
			
			// Set the content type
			Response.Clear();
			Response.ContentType="image/jpeg";
            
			// Send the bitmap to the output stream
			bitmap.Save(memStream, ImageFormat.Jpeg);
            
			memStream.WriteTo(Response.OutputStream);

			// Cleanup
			g.Dispose();
			bitmap.Dispose();
		}
	}
}
