using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Drawing.Drawing2D;//
using System.Web.SessionState;//
using System.ComponentModel;//

using System.Windows.Forms;


public partial class UploadImage : System.Web.UI.Page
    {
        public const string ImageFolder = "upload";
       
        protected void Page_Load(object sender, EventArgs e)
        {
            string NewPicName = "image.jpg";
            string UploadPath = Request.PhysicalApplicationPath + @"\Upload\";
            string Imgname = UploadPath + NewPicName;
           
        }
        protected void Submit1_ServerClick(object sender, EventArgs e)
        {
            {
                if (Picture.PostedFile != null)
                {
                    string PicType = Picture.PostedFile.ContentType.ToString();
                    if (PicType == "image/jpeg" || PicType == "image/jpg" || PicType == "image/pjpeg")
                    {
                        try
                        { string PicName = Picture.PostedFile.FileName;
                            string NewPicName = "image.jpg";
                            string UploadPath = Request.PhysicalApplicationPath + @"\Upload\";
                            Picture.PostedFile.SaveAs(UploadPath + NewPicName);
                            Picture.PostedFile.SaveAs(Server.MapPath("~/image.jpg"));
                            Picture.PostedFile.SaveAs(Server.MapPath("~/original/image.jpg"));
                            Message.Text = "<span style=\"color:green;\">Picture successfully uploaded to server!</span>";
                           // UploadedPic.AlternateText = "Uploaded picture...";
                            //BetterImage1.AlternateText = "Uploaded picture...";
                           // Image1.AlternateText = "Uploaded picture...";


                            //      string  Imgname = UploadPath + NewPicName;
                            //      UploadedPic.ImageUrl = Imgname;
                            //      UploadedPic.Visible = true; 

                            Response.Redirect("Default01.aspx"); 

                        }
                        catch (Exception exc)
                        {
                            Message.Text = exc.ToString();
                        }
                    }
                    else
                        Message.Text = "<span style=\"color:red;\">File format not supported!</span>";

                }
            }
        }
        

        protected void Button4_Click(object sender, EventArgs e)
        {
            // Bitmap objImage = new Bitmap(MapPath(ImageFolder + "/" + "image.jpg"));

            //string FileToResize =  Server.MapPath(ImageFolder + "/" + "image.jpg");

            string FileToResize = Server.MapPath("~/image.jpg");
            using (Bitmap originalBitmap = Bitmap.FromFile(FileToResize, true) as Bitmap, newbmp = new Bitmap(100, 100))
            {
                double WidthVsHeightRatio = (float)originalBitmap.Width / (float)originalBitmap.Height;

                using (Graphics newg = Graphics.FromImage(newbmp))
                {
                    newg.Clear(Color.White); newg.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    if (WidthVsHeightRatio == 1d)
                    {
                        newg.DrawImage(originalBitmap, 0, 0, 100, 100);
                        newg.Save();
                    }

                    else if (WidthVsHeightRatio < 1d) //Image is taller than wider
                    {

                        newg.DrawImage(originalBitmap, 0, 0, 100, 100);
                        // newg.DrawImage(originalBitmap, new RectangleF(new PointF((float)(50 - ((100 * WidthVsHeightRatio) / 2)), 0), new SizeF((float)(100 * WidthVsHeightRatio), 100f)));
                        newg.Save();
                    }

                    else //Image is wider than taller
                    {
                        double inverse = Math.Pow(WidthVsHeightRatio, -1);
                        newg.DrawImage(originalBitmap, new RectangleF(new PointF(0, (float)(50 - ((100 * inverse) / 2))), new SizeF(100f, (float)(100 * inverse))));
                        newg.Save();
                    }
                }

                newbmp.Save(Server.MapPath("~/Upload/image.jpg"), System.Drawing.Imaging.ImageFormat.Jpeg);

            }


        }

     protected void Button5_Click(object sender, EventArgs e)
    {
       Response.Redirect("Default01.aspx"); 
    }
}




