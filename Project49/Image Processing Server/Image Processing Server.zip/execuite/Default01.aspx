<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<%@ import namespace="Microsoft.VisualBasic" %>
<%@ import namespace="System" %>
<%@ import namespace="System.Threading" %>
<%@ import namespace="System.io" %>
<%@ import namespace="System.Drawing" %>
<%@ import namespace="System.Drawing.Drawing2D" %>
<%@ import namespace="System.Drawing.Imaging" %>
<%@ import namespace="System.Drawing.Text" %>
<%@ Page %>

<HTML>
	<HEAD>
		<title>::Image Edit Online::</title> 
		<!-- #include file="vicdefs.aspx"  -->
		<!-- #include file="vicread.aspx"  -->
		<META content="document" name="resource-type">
		<META content="Image Processing online"
			name="keywords">
<style>
body {font: 78%/1.5 arial, helvetica, serif; width: 780px}
a:link, a:visited, a:active {color:blue; text-decoration: none;}
a:hover {color:red;}
h3 {margin-bottom: 0px}
pre {font: 100% courier; margin-left: 3em}
ul.nobutton {margin-left: 0px; list-style-type: none}
ul.nobutton li {margin-left: 3em}
.clearfloats {clear: both; font-size: 0.1em}
.caption {font-style: italic; width: 300px; padding-left: 1em; padding-right: 1em;}
.parenthetical {color: #888; font-style: italic}
.figure {padding-right: 1em; padding-left: 1em; padding-bottom: 1em; margin-left: 5em; width: 33em; padding-top: 1em; background-color: #eeeeee}
.comment {color: #009900;}
.testbutton {width: 8em;}
.foot {margin: auto; text-align: center;}
.left {text-align: left; }
.google_ad {text-align: center}
.google_ad hr {color: #ef8473; height: 1px}
#form1 {float: left; margin: auto; width: 350px; text-align: center}
#explanation {float: left; margin: 2em; width: 380px}
.style3 {font-size: xx-small}
</style>

<script runat="server">
dim myimage as imgdes   ' Global image descriptor
'
'
sub Page_Load (s as Object, e as Eventargs)
dim ver as short
dim rcode as integer
dim defaultimage as string




	defaultimage = "http://localhost/Upload/image.jpg" 

	
	If (Session("adgimage_val1") = 1) Then
		myimage = Session("adgimage_img")
		if Page.IsPostBack then   ' Event raised, will automatically go directly to event handler, process, and display the image
			' do nothing
		else 
			
			process(s, e) 		
		end if
	
	else										 ' No image in memory, load default image
		ver = Victorversion()
		rcode = NO_ERROR
		rcode = loadimagefromurl(defaultimage, myimage)      
		If (rcode = NO_ERROR) Then
			Session("adgimage_img") = myimage
			Session("adgimage_val1") = 1           ' Flag that image is ready to view
			flipimage(myimage, myimage)				' Correct orientation for asp bitmap
			
			process(s, e) 		
		else
			errormsg.text = "Unable to load default image"
		end if
	end if   
end sub
'
Sub Upload_Click(s as Object, e as Eventargs ) ' User is uploading an image

end sub

function displayimage_dtnt(byref imagecontrol as object, byref srcimg_bm as Bitmap, byval width as integer, length as integer)
dim count as integer
	Session("vic_bitmap") = srcimg_bm' image.aspx will get the bitmap from the session variable
	count = Session("adgimage_count")
	Session("adgimage_count") = count + 1
	imagecontrol.style("width") = width
	imagecontrol.style("height") = length
    imagecontrol.imageurl= "image.aspx?count=" & count 'Add the count variable so browser thinks it's 'a new image each time

end function




Sub process (s as Object, e as Eventargs )' .NET objects
dim bm as bitmap

dim g1 as graphics
dim bitmapbuff as system.intptr
dim format as pixelformat

dim tempimg as imgdes ' Conventional variables
dim rcode as integer
dim width as integer
dim length as integer
dim bpp as integer
dim bmh as  BITMAPINFOHEADER
dim action_requested as string
dim ival as integer





    getbmhfromimage(bmh, myimage)
	
	width = bmh.biWidth
	length =  bmh.biHeight
	bpp = bmh.biBitCount

	bitmapbuff = IntPtr.op_Explicit(myimage.ibuff)

	' Create a bitmap inside a Victor image	
	select case bpp 
		case "1" 
			format = pixelformat.Format1bppIndexed
		exit select
		case "8"
			format = pixelformat.Format8bppIndexed
		exit select
		case "24"
			format = pixelformat.Format24bppRgb
		exit select
		case "32"
		format = PixelFormat.Format32bppARGB
		exit select
	end select      
	bm = New bitmap(width, length, myimage.buffwidth, format,bitmapbuff)
	g1 = graphics.fromimage(bm)


	
	action_requested = mid(s.id, 3)
	if(action_requested <> "") then ' Add a graphic or do some processing 
		select case action_requested 
		
			' Add .NET graphic element
			case "rectangle" 
			'---------------------------
			
			
			  g1.drawrectangle(pens.black, 0, 0, width-1, length-1)
			  g1.drawrectangle(pens.black, 1, 1, width-2, length-2)
              g1.drawrectangle(pens.black, 2, 2, width-4, length-4)      
              g1.drawrectangle(pens.black, 3, 3, width-6, length-6)
			  g1.drawrectangle(pens.black, 4, 4, width-8, length-8)
              g1.drawrectangle(pens.black, 5, 5, width-10, length-10)      
              g1.drawrectangle(pens.black, 6, 6, width-12, length-12)
			  g1.drawrectangle(pens.black, 7, 7, width-14, length-14)
			  g1.drawrectangle(pens.black, 8, 8, width-16, length-16)
              g1.drawrectangle(pens.black, 9, 9, width-18, length-18)      
              g1.drawrectangle(pens.black, 10, 10, width-20, length-20)
			exit select
			'case "block"
			'	g1.fillrectangle(brushes.blue, 270, 200, 40, 30)
			'exit select
			case "textup"
'Dim value As Brush
'dim col as string
'value = Brushes.black
			 '"brushes.red  co.Value "
				'g1.drawstring(text01.Text, drawfont,New SolidBrush(Color.White),(width)/3, 25)

reload2(myimage)

Response.Redirect("Defaulttxt.aspx")
			exit select
			
			' Victor Image Processing
			case "blur"
				blur(myimage, myimage)

			exit select
			case "brighnet"
				gammabrighten(0.8, myimage, myimage)
			exit select
			case "sharpen"
				sharpen(myimage, myimage)
			exit select
			
			' Reload original image
			case "reload"
				reload(myimage)
			exit select
			
            case "contrast"
				expandcontrast(20, 240,myimage, myimage)
			exit select
			
			case "negative"
				negative(myimage, myimage)
			exit select
			case "flipv"
				flipimage(myimage, myimage)
			exit select
			
			case "fliph"
				mirrorimage(myimage, myimage)
			exit select
			case "removenoise"
				removenoise(myimage, myimage)
			exit select
			case "grayscale"
			
                rcode = allocimage (tempimg, 2000, 2000, 8)
               ' rcode = allocimage (tempimg, 160, 120, 8) ' Allocate new 8-bit image to hold grayscale
                if(rcode = NO_ERROR) then
                    rcode = colortogray(myimage, tempimg) ' Create 8-bit grayscale version of image
                    if(rcode = NO_ERROR) then
                        rcode = convertpaltorgb(tempimg, myimage)  ' Convert grayscale back to 24-bit image
                    end if
                    freeimage(tempimg)  ' Free the temporary 8-bit image
                 end if
              exit select 
            case "kodalith"
				removenoise(myimage, myimage)
				sharpen(myimage, myimage)
				kodalith(120,myimage, myimage)
				blur(myimage, myimage)
				expandcontrast(20, 240,myimage, myimage)
				expandcontrast(20, 240,myimage, myimage)
			exit select
			 case "watercolor"
				gammabrighten(0.7, myimage, myimage)
				removenoise(myimage, myimage)
				removenoise(myimage, myimage)
				removenoise(myimage, myimage)
				removenoise(myimage, myimage)
				sharpen(myimage, myimage)
			 exit select

			case "mos"
				pixellize(text02.Text,myimage, myimage)
				sharpen(myimage, myimage)
				' negative(myimage, myimage)
				' wtaverage(50,myimage, myimage)
			 exit select
	
			 case "outline"
				rcode = allocimage (tempimg, 2000, 2000, 8)
               ' rcode = allocimage (tempimg, 160, 120, 8) ' Allocate new 8-bit image to hold 		 grayscale
                if(rcode = NO_ERROR) then
                    rcode = colortogray(myimage, tempimg) ' Create 8-bit grayscale version of image
                    if(rcode = NO_ERROR) then
                        rcode = convertpaltorgb(tempimg, myimage)  ' Convert grayscale back to 24-bit image
                    end if
                    freeimage(tempimg)  ' Free the temporary 8-bit image
                 end if
				outline(myimage, myimage)
			 gammabrighten(0.8, myimage, myimage)
			 gammabrighten(0.8, myimage, myimage)
			 gammabrighten(0.8, myimage, myimage)
			 gammabrighten(0.8, myimage, myimage)
			 exit select
			 case "medianfilter"
				sharpen(myimage,myimage)


			 exit select
			 case "01"
				
			 g1.drawrectangle(pens.White, 0, 0, width, length)
			  g1.drawrectangle(pens.White, 1, 1, width-2, length-2)
              g1.drawrectangle(pens.White, 2, 2, width-4, length-4)      
              g1.drawrectangle(pens.White, 3, 3, width-6, length-6)
			  g1.drawrectangle(pens.White, 4, 4, width-8, length-8)
              g1.drawrectangle(pens.White, 5, 5, width-10, length-10)      
              g1.drawrectangle(pens.White, 6, 6, width-12, length-12)
			  g1.drawrectangle(pens.White, 7, 7, width-14, length-14)
			  g1.drawrectangle(pens.White, 8, 8, width-16, length-16)
              g1.drawrectangle(pens.White, 9, 9, width-18, length-18)      
              g1.drawrectangle(pens.White, 10, 10, width-20, length-20)
              
			 exit select
			 case "resize"
'------------------------
resize00(myimage)

'-------------------------
			 exit select
			 case "refresh"


			 exit select	
		
		end select
	end if


	


	ival = CLng(zoom.Value)
                ' Create copy of source image, release source image, process the copy, result becomes new src 
                ' First create a new temp image to hold copy of src
                getbmhfromimage(bmh, myimage)  		
                rcode = allocimage (tempimg, bmh.biWidth, bmh.biHeight, bmh.biBitcount)
                
				if(rcode = NO_ERROR) then
                    'copyimage (myimage, tempimg) ' 'Copy src into the temp image buffer
				copyimgdes(tempimg, myimage)
                    if(rcode = NO_ERROR) then
                        freeimage (myimage)            ' Release original image

                        ' Create result image, do image processing, result becomes new source image
                        width =  INT(bmh.biWidth * ival / 100)
                        length = INT(bmh.biHeight * ival / 100) 
                        rcode = allocimage (myimage, width, length, bmh.biBitcount) ' Allocate new size image                     
                        if(rcode = NO_ERROR) then
                           ' rcode = resizeex(tempimg, myimage, 1) ' Resize from temp into new source
                            else
                                ' Failure, couldn''t create new image, restore previous image
                               ' copyimgdes(tempimg, myimage)
                      ' copyimage (myimage, tempimg)
						end if
                    end if
                end if	  

	
	
		
	
	' Display the modified Victor image
	displayimage_dtnt(image1, bm, width, length)	
end sub
'-------------
Sub Select_Change(Sender As Object, E As EventArgs)
  	
End Sub



'--------------
sub reload(byref tsrcimg as imgdes)
dim defaultimage as string
dim rcode as integer
dim width as integer
dim length as integer
dim bmh as  BITMAPINFOHEADER

	getbmhfromimage(bmh, myimage)
	width = bmh.biWidth
	length =  bmh.biHeight



	defaultimage = "http://localhost/original/image.jpg" 

	freeimage(tsrcimg)
	rcode = loadimagefromurl(defaultimage, tsrcimg)      
	If (rcode = NO_ERROR) Then
		Session("adgimage_img") = tsrcimg
		Session("adgimage_val1") = 1            ' Flag that image is ready to view
		flipimage(tsrcimg, tsrcimg)				' Correct orientation for asp bitmap
	
 
	 imageLabel.text = "Dimensions:" & bmh.biWidth & " x " & bmh.biHeight
	
	end if	
end sub

sub reload2(byref tsrcimg as imgdes)
dim defaultimage as string
dim rcode as integer
dim width as integer
dim length as integer
dim bmh as  BITMAPINFOHEADER

	getbmhfromimage(bmh, myimage)
	width = bmh.biWidth
	length =  bmh.biHeight

rcode = savejpg("c:\www\image1.jpg",tsrcimg, 100)

	defaultimage = "http://localhost/image1.jpg" 

	freeimage(tsrcimg)
	rcode = loadimagefromurl(defaultimage, tsrcimg)      
	If (rcode = NO_ERROR) Then
		Session("adgimage_img") = tsrcimg
		Session("adgimage_val1") = 1            ' Flag that image is ready to view
		flipimage(tsrcimg, tsrcimg)				' Correct orientation for asp bitmap
	
	rcode = savejpg("c:\www\image.jpg",tsrcimg, 100)
 rcode = savejpg("c:\www\Upload\image.jpg",tsrcimg, 100)
	 
	
	end if	
end sub




Sub restart_Click (s as Object, e as Eventargs)   ' Go back to get a fresh image
   if (Session("var1") = 1) then   ' If an image is already in memory, free it
     ' sipstartimg = Session("sipstartimg")
    '  freeimage(sipstartimg)
      'srcimg = Session("srcimg")	
      'freeimage(srcimg)     ' Free the image buffer
      Session("var1") = 0
   end if
   reset()
end sub

Sub resize00(byref tsrcimg as imgdes)
dim bm as bitmap

dim g1 as graphics
dim bitmapbuff as system.intptr
dim format as pixelformat

dim tempimg as imgdes ' Conventional variables
dim rcode as integer
dim width as integer
dim length as integer
dim bpp as integer
dim bmh as  BITMAPINFOHEADER
dim action_requested as string
dim ival as integer



ival = CLng(res.Value)
                ' Create copy of source image, release source image, process the copy, result becomes new src 
                ' First create a new temp image to hold copy of src
                getbmhfromimage(bmh, myimage)  		
                rcode = allocimage (tempimg, bmh.biWidth, bmh.biHeight, bmh.biBitcount)
                
				if(rcode = NO_ERROR) then
                    'copyimage (myimage, tempimg) ' 'Copy src into the temp image buffer
				copyimgdes(tempimg, myimage)
                    if(rcode = NO_ERROR) then
                        freeimage (myimage)            ' Release original image

                        ' Create result image, do image processing, result becomes new source image
                        width =  INT(bmh.biWidth * ival / 100)
                        length = INT(bmh.biHeight * ival / 100) 
                        rcode = allocimage (myimage, width, length, bmh.biBitcount) ' Allocate new size image                     
                        if(rcode = NO_ERROR) then
                            rcode = resizeex(myimage,tempimg, 1) ' Resize from temp into new source
                            else
                                ' Failure, couldn''t create new image, restore previous image
                                copyimgdes(tempimg, myimage)
                      ' copyimage (myimage, tempimg)
						end if
                    end if
                end if		  

imageLabel.text = "Dimensions:" & Width & " x " & length


end sub



		</script>
	</HEAD>
	
		<form id="Form1"    encType="multipart/form-data" runat="server" style="width: 400px; height: 100px">
		  <table width="921" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
            
            <tr>
              <td height="10" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
              <td bordercolor="#FFFFFF" bgcolor="#FFFFFF"><hr /><asp:Button class="testbutton" ID="b_blur"           OnClick="process" runat="server" Text="Blur" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_contrast"      OnClick="process" runat="server" Text="Contrast" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_sharpen"        OnClick="process" runat="server" Text="Sharpen" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_brighnet"       OnClick="process" runat="server" Text="Brightness" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_negative"       OnClick="process" runat="server" Text="Negative" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_removenoise"    OnClick="process" runat="server" Text="Removenoise" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_grayscale"      OnClick="process" runat="server" Text="Grayscale"              type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_kodalith"       OnClick="process" runat="server" Text="Kodalith"              type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_fliph"		     OnClick="process" runat="server" Text="Flip Horizontal" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_flipv"		     OnClick="process" runat="server" Text="Flip Vertical"       type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_watercolor"           OnClick="process" runat="server" Text="Watercolor"              type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_outline"        OnClick="process" runat="server" Text="Outline" type="submit"></asp:Button>
                <asp:Button class="testbutton" ID="b_rectangle"      OnClick="process" runat="server" Text="Frame Black" type="submit"></asp:Button>
<asp:Button class="testbutton" ID="b_01"        OnClick="process" runat="server" Text="Frame White" type="submit"></asp:Button>
<asp:TextBox  ID="text02" runat="server" Text="6"  Width="18"/>                
<asp:Button  ID="b_mos"        OnClick="process" runat="server" Text="MosaicEffect" Width="85" type="submit"></asp:Button>
<asp:Button class="testbutton" ID="b_reload"   OnClick="process" runat="server" Text="Undo" type="submit" ForeColor="#FF0000"></asp:Button><br></td>
              <td bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
            </tr>
            <tr>
              <td width="3" bordercolor="#FFFFFF" bgcolor="#FFFFFF"><p></td>
              <td width="893" bordercolor="#CCCCCC" bgcolor="#FFFFFF"><hr /><asp:Button class="testbutton" ID="b_textup"        OnClick="process" runat="server" Text="text" type="submit"></asp:Button>
              <select name="select2"  id="res" runat="server" onserverchange="Select_Change">
                <option value="100" selected>selected</option>
                <option value="90">90%</option>
                <option value="80" runat="server">80%</option>
                <option value="70" runat="server">70%</option>
                <option value="50" runat="server">50%</option>
                <option value="60" runat="server">60%</option>
                <option value="40" runat="server">40%</option>
                <option value="30" runat="server">30%</option>
                <option value="20" runat="server">20%</option>
                <option value="10" runat="server">10%</option>
              </select>
              <asp:Button class="testbutton" ID="b_resize"         OnClick="process" runat="server" Text="Resize" type="submit"></asp:Button></td>
              <td width="11" bordercolor="#CCCCCC" bgcolor="#FFFFFF">&nbsp;</td>
            </tr>
            <tr>
              <td height="47" bordercolor="#FFFFFF" bgcolor="#FFFFFF">&nbsp;</td>
              <td bordercolor="#CCCCCC" bgcolor="#FFFFFF"><p>
                <select name="select"  id="zoom" runat="server" onserverchange="Select_Change">
                    <option value="400" runat="server">400%</option>
					<option value="300" runat="server">300%</option>
                    <option value="200" runat="server">200%</option>
                    <option value="150" runat="server">150%</option>
                    <option value="100" selected>100%</option>					
                    <option value="90" runat="server">90%</option>
                    <option value="80" runat="server">80%</option>
                    <option value="75" runat="server">75%</option>
                    <option value="70" runat="server">70%</option>
                    <option value="60" runat="server">60%</option>
					<option value="50" runat="server">50%</option>
                    <option value="40" runat="server">40%</option>
                    <option value="30" runat="server">30%</option>
                    <option value="20" runat="server">20%</option>
                    <option value="10" runat="server">10%</option>
                </select>
                <asp:Button  ID="b_refresh"         OnClick="process" runat="server" Text="Zoom" type="submit"></asp:Button>
                  <asp:Label  ID="imageLabel" runat="server" Text=" "></asp:Label>
            <asp:Label ID="errormsg" runat="server"></asp:Label><hr /></tr>
          </table>
		</form>
        <table width="101" border="0" align="center">
          <tr>
            <td width="95" height="20" bgcolor="#333333"><div align="center"><asp:Image ID="image1"  Width="100" runat="server"></asp:Image></div></td>
          </tr>
    </table>
	</body>
</HTML>




	