<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="UploadImage" %>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>::Image Edit Online::</title>
<script runat="server">
   
  
</script>
<style type="text/css">
<!--
.style2 {font-size: larger}
.style4 {font-weight: bold; font-size: 25px;}
-->
</style>
</head>
<body>
    <form id="form1" runat="server">
    <div>
	<span class="style2"><strong>&nbsp;&nbsp;	</strong> </span>
	<div align="center" class="style4"> Image Edit Online.</div>
	<hr />
	<hr />
        <div align="center">
        <table>
            <tr>
                <td style="height: 24px">
                    Image:</td>
                <td style="width: 37px; height: 24px;">
                    <input id="Picture" runat="server" type="file" /></td>
            </tr>
        </table>
        <p>
          <input id="Submit1" runat="server"  type="submit" value="Upload " onserverclick="Submit1_ServerClick" style="width: 100px" />
          </p>
        <p>
          <asp:Label ID="Message" runat="server"></asp:Label>
        </p>
        </div>
        <hr />
        
        <hr />
    </div>
         
       
         
    </form>
</body>
</html>
