<%@ Page language="c#" Inherits="ImageMarkup.WebForm1" CodeFile="Defaulttxt.aspx.cs" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body>
		<form id="Form1" method="post" runat="server">
			
			<P>Type :
				<asp:DropDownList id="listType" runat="server"></asp:DropDownList>&nbsp;Param :
				<asp:TextBox id="txtParam" runat="server" Width="300px"></asp:TextBox>&nbsp;
				<asp:Button id="btnRemove" runat="server" Text="Remove" onclick="btnRemove_Click"></asp:Button>&nbsp;
				<asp:TextBox id="txtRemove" runat="server" Width="16px" Visible="False">0</asp:TextBox><BR>
				Param Example :
				<asp:Label id="lblExample" EnableViewState="true" runat="server"></asp:Label>
			</P>
			<table width="42" border="1" align="center">
              <tr>
                <td width="32"><asp:ImageButton ID="MarkupImage" runat="server" ImageUrl="Markup.aspx?desc="></asp:ImageButton>
                </td>
              </tr>
            </table>
			<P>&nbsp;</P>
		</form>
	</body>
</HTML>
