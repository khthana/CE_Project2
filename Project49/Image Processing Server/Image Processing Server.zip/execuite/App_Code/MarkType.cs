using System;
using System.Drawing;

namespace ImageMarkup
{
	/// <summary>
	/// Summary description for MarkType.
	/// </summary>
	public interface MarkableType
	{
		void LoadFromString(string str);
		string SaveAsString();
	}

	public class CircleMark : MarkableType
	{
		private int _radius;
		
		public int Radius
		{
			get { return _radius; }
		}

		public CircleMark(int radius)
		{
			_radius = radius;
		}

		public void LoadFromString(string str)
		{
			try
			{
				_radius = int.Parse(str);
			}
			catch
			{
				_radius = 3;
			}
		}

		public string SaveAsString()
		{
			return _radius.ToString();
		}
	}

	public class RectangleMark : MarkableType
	{
		private int _width;
		private int _height;
		
		public int Width
		{
			get { return _width; }
		}

		public int Height
		{
			get { return _height; }
		}

		public RectangleMark(int width, int height)
		{
			_width = width;
			_height = height;
		}

		public void LoadFromString(string str)
		{
			string[] tmp = str.Split(',');
			try
			{
				_width = int.Parse(tmp[0]);
				_height = int.Parse(tmp[1]);
			}
			catch
			{
				_width = 3;
				_height = 3;
			}
		}

		public string SaveAsString()
		{
			return _width.ToString() + "," + _height.ToString();
		}
	}

	public class ImageMark : MarkableType
	{
		private string _fspath;
		
		public Bitmap Image
		{
			get {
					string path = System.Web.HttpContext.Current.Server.MapPath(_fspath);

					if (System.IO.File.Exists(path))
					{
						return new Bitmap(path);
					}
					else
					{
						return null;
					}
				}
		}

		public ImageMark(string path)
		{
			_fspath = path;
		}

		public void LoadFromString(string str)
		{
			_fspath = str;
		}

		public string SaveAsString()
		{
			return _fspath;
		}
	}

	public class TextMark : MarkableType
	{
		private string _text;

		public string Text
		{
			get { return _text; }
		}
		
		public TextMark(string text)
		{
			_text = text;
		}

		public void LoadFromString(string str)
		{
			_text = str;
		}

		public string SaveAsString()
		{
			return _text;
		}
	}

	public class MarkManager
	{
		public static MarkableType CreateByID(string typeid)
		{
			switch(typeid)
			{
				case "0":
					return new RectangleMark(8, 8);
				case "1":
					return new CircleMark(3);
				case "2":
					return new TextMark("TEXT");
				case "3":
					return new ImageMark("plus.bmp");
				default:
					return null;
			}
		}

		public static void Draw(Graphics g, int x, int y, MarkableType mark)
		{
			if (mark is RectangleMark)
			{
				Draw(g, x, y, (RectangleMark) mark);
			}
			else if (mark is CircleMark)
			{
				Draw(g, x, y, (CircleMark) mark);
			}
			else if (mark is TextMark)
			{
				Draw(g, x, y, (TextMark) mark);
			}
			else if (mark is ImageMark)
			{
				Draw(g, x, y, (ImageMark) mark);
			}
		}

		public static void Draw(Graphics g, int x, int y, RectangleMark rect)
		{
			Pen pen = new Pen(Color.Red, 1.5f);
			g.DrawRectangle(pen, x, y, rect.Width, rect.Height);
		}

		public static void Draw(Graphics g, int x, int y, CircleMark circle)
		{
			
			SolidBrush brush = new SolidBrush(Color.Red);
			g.FillEllipse(brush, x, y, circle.Radius*2, circle.Radius*2);
		}

		public static void Draw(Graphics g, int x, int y, TextMark text)
		{
            SolidBrush brush = new SolidBrush(Color.Black);

			string familyName = "Tahoma";

			Font font;
			font = new Font(familyName, 12F, FontStyle.Bold);

			StringFormat format = new StringFormat();
			format.Alignment = StringAlignment.Center;
			format.LineAlignment = StringAlignment.Center;

			g.DrawString(text.Text, font, brush, 
				x, y, format);
		}

		public static void Draw(Graphics g, int x, int y, ImageMark image)
		{
			if (image.Image != null)
			{
				g.DrawImage(image.Image, x, y);
			}
		}
	}
}
