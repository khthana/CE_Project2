<script runat="server">

    ' vicdefs.aspx -- Visual Basic .Net version of VICDEFS.H, prototypes, definitions, and error codes for
	'   Victor Image Processing Library for Windows
	
	'----------------------------------------------------------
    ' Necessary data structures for Windows
	
	Structure BITMAPINFOHEADER
		Dim biSize As Integer
		Dim biWidth As Integer
		Dim biHeight As Integer
		Dim biPlanes As Short
		Dim biBitCount As Short
		Dim biCompression As Integer
		Dim biSizeImage As Integer
		Dim biXPelsPerMeter As Integer
		Dim biYPelsPerMeter As Integer
		Dim biClrUsed As Integer
		Dim biClrImportant As Integer
	End Structure
	
	Structure RGBQUAD
		Dim rgbBlue As Byte
		Dim rgbGreen As Byte
		Dim rgbRed As Byte
		Dim rgbReserved As Byte
	End Structure
	
	Structure RECT
        Dim left As Integer
        Dim top As Integer
        Dim right As Integer
        Dim bottom As Integer
	End Structure
	
	'----------------------------------------------------------
	' Image descriptor
	Structure imgdes
		Dim ibuff As Integer
		Dim stx As Integer
		Dim sty As Integer
		Dim endx As Integer
		Dim endy As Integer
		Dim buffwidth As Integer
		Dim palette As Integer
		Dim colors As Integer
		Dim imgtype As Integer
		Dim bmh As Integer
		Dim hBitmap As Integer
	End Structure
	
	Structure TiffData
		Dim ByteOrder As Integer
		Dim width As Integer
		Dim length As Integer
		Dim BitsPSample As Integer
		Dim comp As Integer
		Dim SamplesPPixel As Integer
		Dim PhotoInt As Integer
		Dim PlanarCfg As Integer
		Dim vbitcount As Integer
	End Structure
	
	Structure TiffDataEx
		Dim ByteOrder As Integer
		Dim width As Integer
		Dim length As Integer
		Dim BitsPSample As Integer
		Dim comp As Integer
		Dim SamplesPPixel As Integer
		Dim PhotoInt As Integer
		Dim PlanarCfg As Integer
		Dim vbitcount As Integer
		Dim xres As Integer
		Dim yres As Integer
		Dim resunit As Integer
		Dim fillorder As Integer
		Dim rowsperstrip As Integer
		Dim orientation As Integer
		Dim IFDofs As Integer
		Dim page As Integer
	End Structure

	Structure PcxData
		Dim PCXvers As Integer
		Dim width As Integer
		Dim length As Integer
		Dim BPPixel As Integer
		Dim Nplanes As Integer
		Dim BytesPerLine As Integer
		Dim PalInt As Integer
		Dim vbitcount As Integer
	End Structure
	
	Structure GifData
		Dim width As Integer
		Dim length As Integer
		Dim BitsColRes As Integer
		Dim BitsPPixel As Integer
		Dim BckCol As Integer
		Dim Laceflag As Integer
		Dim codesize As Integer
		Dim GIFvers As Integer
		Dim vbitcount As Integer
	End Structure
	
	Structure GifGlobalSaveData
		Dim scrwidth As Integer
		Dim scrlength As Integer
		Dim hasColorMap As Integer
		Dim bckColor As Integer
        Dim looop As Integer
    End Structure

    Structure GifGlobalData
        Dim saveData As GifGlobalSaveData
        Dim BitsPPixel As Integer
        Dim colorRes As Integer
        Dim pixelAspectRatio As Integer
        Dim commentOffset As Integer
        Dim colors As Integer
        Dim colorMapOffset As Integer
    End Structure

    Structure GifFrameSaveData
        Dim startx As Integer
        Dim starty As Integer
        Dim hasColorMap As Integer
        Dim delay As Integer ' 100ths of a second to display frame
        Dim transColor As Integer ' Transparent color index, -1 => none
        Dim removeBy As Integer ' How graphic is to be treated after display
        Dim waitForUserInput As Integer 'If true, expect user input
    End Structure

    Structure GifFrameData
        Dim saveData As GifFrameSaveData
        Dim vbitcount As Integer
        Dim width As Integer
        Dim length As Integer
        Dim frame As Integer
        Dim interlace As Integer
        Dim codesize As Integer
        Dim colors As Integer
        Dim colorMapOffset As Integer
        Dim rasterDataOffset As Integer
    End Structure

    Structure PNGSIGBITS
        Dim sb_long As Integer
    End Structure

    'Transparency or background color data
    Structure PNGTRANSINFO
        Dim isPresent As Integer
        Dim data0 As Byte
        Dim data1 As Byte
        Dim data2 As Byte
        Dim data3 As Byte
        Dim data4 As Byte
        Dim byteCount As Integer
    End Structure

    ' PNG file format info structure definition (used by pnginfo)
    Structure PngData
        Dim width As Integer
        Dim length As Integer
        Dim bitDepth As Integer
        Dim vbitcount As Integer
        Dim colorType As Integer
        Dim interlaced As Integer
        Dim imageId As Integer
        Dim channels As Integer
        Dim pixelDepth As Integer
        Dim rowBytes As Integer
        Dim transData As PNGTRANSINFO
        Dim backData As PNGTRANSINFO
        Dim igamma As Integer
        Dim physXres As Integer
        Dim physYres As Integer
        Dim physUnits As Integer
        Dim sigBit As PNGSIGBITS
        Dim offsXoffset As Integer
        Dim offsYoffset As Integer
        Dim offsUnits As Integer
    End Structure

   ' Used by savepngex()
    Structure Png_Data
         Dim transcolor as integer
         Dim reserved1 as integer
         Dim reserved2 as integer
         Dim reserved3 as integer
    End Structure

    Structure TgaData
        Dim IDfieldchars As Integer
        Dim width As Integer
        Dim length As Integer
        Dim ColorMapType As Integer
        Dim ImageType As Integer
        Dim ColorMapEntryBits As Integer
        Dim Xorigin As Integer
        Dim Yorigin As Integer
        Dim BPerPix As Integer
        Dim ABPerPix As Integer
        Dim ScreenOrigin As Integer
        Dim Interleave As Integer
        Dim vbitcount As Integer
    End Structure

    Structure JpegData
        Dim ftype As Integer
        Dim width As Integer
        Dim length As Integer
        Dim comps As Integer
        Dim precision As Integer
        Dim sampfac0 As Integer
        Dim sampfac1 As Integer
        Dim sampfac2 As Integer
        Dim sampfac3 As Integer
        Dim vbitcount As Integer
    End Structure

    Public Const THUMB_CODE_JPEG As Short = 16 '0x10  JPEG-coded Thumbnail
    Public Const THUMB_CODE_PAL As Short = 17  '0x11  Palette-coded Thumbnail
    Public Const THUMB_CODE_RGB As Short = 19  '0x13  RGB-coded Thumbnail

    Structure JPEG_THUMB_DATA
        Dim hasThumbNail As Integer
        Dim width As Byte
        Dim length As Byte
        Dim bitcount As Byte
        Dim coding As Byte
    End Structure

    Structure JpegDataEx
        Dim ftype As Integer
        Dim width As Integer
        Dim length As Integer
        Dim comps As Integer
        Dim precision As Integer
        Dim sampfac0 As Integer
        Dim sampfac1 As Integer
        Dim sampfac2 As Integer
        Dim sampfac3 As Integer
        Dim vbitcount As Integer
        Dim xres As Integer
        Dim yres As Integer
        Dim resunit As Integer
        Dim thumbNail As JPEG_THUMB_DATA
    End Structure

    Structure HSVTRIPLE
        Dim hue As Byte
        Dim saturation As Byte
        Dim value As Byte
    End Structure

    ' Victor version struct
    Structure VIC_VERSION_INFO
        Dim version As Short
        Dim flags As Short
    End Structure

    ' OS version info struct
    Structure MYVERSIONINFO
        Dim version As Integer
        Dim platformID As Integer
    End Structure


    ' Used by calcminmax()
    Structure MINMAX
         dim min as integer
         dim max as integer
         dim res1 as integer
         dim res2 as integer
    End Structure

    ' For sort routine
    Structure COORD_VAL
         dim val as integer
         dim x as integer
         dim y as integer
    End Structure

    ' ..........................................................
    ' For Victor Library TWAIN support module

    Structure TW_STR32
        Dim items0 As Byte
        Dim items1 As Byte
        Dim items2 As Byte
        Dim items3 As Byte
        Dim items4 As Byte
        Dim items5 As Byte
        Dim items6 As Byte
        Dim items7 As Byte
        Dim items8 As Byte
        Dim items9 As Byte
        Dim items10 As Byte
        Dim items11 As Byte
        Dim items12 As Byte
        Dim items13 As Byte
        Dim items14 As Byte
        Dim items15 As Byte
        Dim items16 As Byte
        Dim items17 As Byte
        Dim items18 As Byte
        Dim items19 As Byte
        Dim items20 As Byte
        Dim items21 As Byte
        Dim items22 As Byte
        Dim items23 As Byte
    End Structure

    ' Data for Twain ONEVALUE-type container
    Structure TWAIN_ONEVALUE
        Dim val As Short ' the value
    End Structure

    ' Data for Twain ENUM-type container
    Structure TWAIN_ENUMTYPE
        Dim tarray0 As Short
        Dim tarray1 As Short
        Dim tarray2 As Short
        Dim tarray3 As Short
        Dim tarray4 As Short
        Dim tarray5 As Short
        Dim tarray6 As Short
        Dim tarray7 As Short
        Dim tarray8 As Short
        Dim tarray9 As Short
        Dim tarray10 As Short
        Dim tarray11 As Short
        Dim tarray12 As Short
        Dim tarray13 As Short
        Dim tarray14 As Short
        Dim tarray15 As Short
        Dim tarray16 As Short
        Dim tarray17 As Short
        Dim nelems As Short ' Number of valid elements in array()
        Dim currentIndex As Short ' Index to the value that is currently in effect
        Dim defaultIndex As Short ' Power-up value
    End Structure

    ' Data for Twain RANGE-type container
    Structure TWAIN_RANGE
        Dim min As Short ' Starting value in the range
        Dim max As Short ' Final value in the range
        Dim stepSize As Short ' Increment from min to max
        Dim currentVal As Short ' The value that is currently in effect
        Dim defaultVal As Short ' Power-up value
    End Structure

    ' Capability get/set struct
    Structure TWAIN_CAP_DATA
        Dim conType As Short '  Container type, TWON_ONEVALUE, TWON_ENUMERATION, or TWON_RANGE,
        Dim oneValue As TWAIN_ONEVALUE ' Data if using ONEVALUE-type container
        Dim enumType As TWAIN_ENUMTYPE ' Data if using ENUM-type container
        Dim range As TWAIN_RANGE ' Data if using RANGE-type container
    End Structure
    ' ..........................................................

    'Function declarations for Victor Image Processing Library
    Declare Function addimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    'Declare Function addtexture Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function allocDIB Lib "VIC32.DLL" (ByRef image As imgdes, ByVal wid As Integer, ByVal leng As Integer, ByVal BPPixel As Integer) As Integer
    Declare Function allocimage Lib "VIC32.DLL" (ByRef image As imgdes, ByVal wid As Integer, ByVal leng As Integer, ByVal BPPixel As Integer) As Integer
    Declare Function andimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function bleach Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function blur Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function blurthresh Lib "VIC32.DLL" (ByVal thres As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function bmpinfo Lib "VIC32.DLL" (ByVal filename As String, ByRef bdat As BITMAPINFOHEADER) As Integer
    Declare Function bmpinfofrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef bminfo As BITMAPINFOHEADER) As Integer
    Declare Function brightenmidrange Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function calcavglevel Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef redavg As Integer, ByRef grnavg As Integer, ByRef bluavg As Integer) As Integer
    Declare Function calcavglevelfloat Lib "VICSTATS.DLL" (ByRef srcimg As imgdes, ByRef redavg As Double, ByRef grnavg As Double, ByRef bluavg As Double) As Integer
    Declare Function calchisto Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef redtab As Integer, ByRef grntab As Integer, ByRef blutab As Integer) As Integer
    Declare Function calchistorgb Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef redtab As Integer, ByRef grntab As Integer, ByRef blutab As Integer, ByVal mode As Integer) As Integer
    Declare Function calcminmax Lib "vic32.dll" (ByRef srcimg As imgdes, ByRef redMinmax As minmax, ByRef grnMinmax As minmax, ByRef bluMinmax As minmax) As Integer
    Declare Function changebright Lib "VIC32.DLL" (ByVal amt As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function clienttoimage Lib "VIC32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes) As Integer
    Declare Function colordither Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal colormode As Integer) As Integer
    Declare Function colorscatter Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal colormode As Integer) As Integer
    Declare Function colortogray Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convert1bitto8bit Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convert1bitto8bitsmooth Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convert8bitto1bit Lib "VIC32.DLL" (ByVal mode As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convertgray8to16 Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convertgray16to8 Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convertpaltorgb Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convertrgbtopal Lib "VIC32.DLL" (ByVal palcolors As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function convertrgbtopalex Lib "VIC32.DLL" (ByVal palcolors As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Function copyimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function copyimagebits Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Sub copyimagepalette Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes)
    Declare Sub copyimgdes Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes)
    Declare Function correlateimages Lib "VICSTATS.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function correlationcoef Lib "VICSTATS.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef coefficient As Double) As Integer
    Declare Function correlationcoefRGB Lib "VICSTATS.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef redcoefficient As Double, ByRef grncoefficient As Double, ByRef blucoefficient As Double) As Integer
    Declare Function cover Lib "VIC32.DLL" (ByVal thres As Integer, ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function coverclear Lib "VIC32.DLL" (ByVal transColor As Integer, ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function darker Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function ddbtoimage Lib "VIC32.DLL" (ByVal hBitmap As Integer, ByVal hPal As Integer, ByRef resimg As imgdes) As Integer
    Declare Function defaultpalette Lib "VIC32.DLL" (ByRef image As imgdes) As Integer
    Declare Function dibsecttoimage Lib "VIC32.DLL" (ByVal hBitmap As Integer, ByRef image As imgdes) As Integer
    Declare Function dibtobitmap Lib "VIC32.DLL" (ByVal hdc As Integer, ByVal dib As Integer, ByRef hBitmap As Integer) As Integer
    Declare Function dibtoimage Lib "VIC32.DLL" (ByVal dib As Integer, ByRef resimg As imgdes) As Integer
    Declare Function difference Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function differenceabs Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function divideimage Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function dilate Lib "VIC32.DLL" (ByVal amount As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function divide Lib "VIC32.DLL" (ByVal divsr As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function drawhisto Lib "VIC32.DLL" (ByVal hdc As Integer, ByRef RECT As RECT, ByVal BPPixel As Integer, ByRef redtab As Integer, ByRef grntab As Integer, ByRef blutab As Integer) As Integer
    Declare Function erode Lib "VIC32.DLL" (ByVal amount As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function exchangelevel Lib "VIC32.DLL" (ByVal min As Integer, ByVal max As Integer, ByVal newval As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function expandcontrast Lib "VIC32.DLL" (ByVal min As Integer, ByVal max As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function flipimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Sub freeimage Lib "VIC32.DLL" (ByRef image As imgdes)
    Declare Function gammabrighten Lib "VIC32.DLL" (ByVal amt As Double, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function getgifcomment Lib "VIC32.DLL" (ByVal filename As String, ByVal buff As String, ByVal maxbuff As Integer) As Integer
    Declare Function getpixelcolor Lib "VIC32.DLL" (ByRef image As imgdes, ByVal xcoord As Integer, ByVal ycoord As Integer) As Integer
    Declare Function getpngcomment Lib "VIC32.DLL" (ByVal filename As String, ByVal commenttype As String, ByVal buffer As String, ByVal buffermax As Integer) As Integer
    Declare Function gifframecount Lib "VIC32.DLL" (ByVal filename As String, ByRef totalFrames As Integer) As Integer
    Declare Function gifframecountfrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef totalFrames As Integer) As Integer
    Declare Function gifinfo Lib "VIC32.DLL" (ByVal filename As String, ByRef gdat As GifData) As Integer
    Declare Function gifinfoallframes Lib "VIC32.DLL" (ByVal filename As String, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData, ByVal frameElem As Integer) As Integer
    Declare Function gifinfoallframesfrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData, ByVal frameElem As Integer) As Integer
    Declare Function gifinfoframe Lib "VIC32.DLL" (ByVal filename As String, ByRef ginfo As GifData, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData, ByVal frameTarget As Integer) As Integer
    Declare Function gifinfoframefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef ginfo As GifData, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData, ByVal frameTarget As Integer) As Integer
    Declare Function gifinfofrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef gdat As GifData) As Integer
    Declare Function histobrighten Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function histoequalize Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Sub hsv2rgb Lib "VIC32.DLL" (ByRef hsvtab As HSVTRIPLE, ByRef rgbtab As RGBQUAD, ByVal colors As Integer)
    Declare Sub imageareatorect Lib "VIC32.DLL" (ByRef image As imgdes, ByRef RECT As RECT)
    Declare Function imagetodib Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef dib As Integer) As Integer
    Declare Function isgrayscaleimage Lib "VIC32.DLL" (ByRef image As imgdes) As Integer
    Declare Function isolate Lib "VIC32.DLL" Alias "addimage"(ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function jpeggeterror Lib "VIC32.DLL" () As Integer
    Declare Function jpeginfo Lib "VIC32.DLL" (ByVal filename As String, ByRef jdat As JpegData) As Integer
    Declare Function jpeginfoex Lib "VIC32.DLL" (ByVal filename As String, ByRef jdat As JpegDataEx) As Integer
    Declare Function jpeginfofrombuffer Lib "VIC32.DLL" (ByVal buffaddr As Integer, ByRef jdat As JpegData) As Integer
    Declare Function jpeginfofrombufferex Lib "VIC32.DLL" (ByVal buffaddr As Integer, ByRef jdat As JpegDataEx) As Integer
    Declare Sub jpegsetxyresolution Lib "VIC32.DLL" (ByVal xres As Integer, ByVal yres As Integer, ByVal resunit As Integer)
    Declare Function jpegsetthumbnailsize Lib "VIC32.DLL" (ByVal longEdge As Integer) As Integer
    Declare Function kodalith Lib "VIC32.DLL" (ByVal thres As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function lighter Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function limitlevel Lib "VIC32.DLL" (ByVal thres As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function loadbif Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadbmp Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadbmpfrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef resimg As imgdes) As Integer
    Declare Function loadbmppalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadbmppalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadgif Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadgifframe Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData) As Integer
    Declare Function loadgifframefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef resimg As imgdes, ByRef gdata As GifGlobalData, ByRef fdata As GifFrameData) As Integer
    Declare Function loadgifframepalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD, ByVal frame As Integer) As Integer
    Declare Function loadgifframepalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD, ByVal frame As Integer) As Integer
    Declare Function loadgiffrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef resimg As imgdes) As Integer
    Declare Function loadgifglobalpalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadgifglobalpalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadgifpalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadgifpalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadjpg Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadjpgex Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Function loadjpgfrombuffer Lib "VIC32.DLL" (ByVal buffaddr As Integer, ByRef resimg As imgdes) As Integer
    Declare Function loadjpgfrombufferex Lib "VIC32.DLL" (ByVal buffaddr As Integer, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Function loadjpgthumbnail Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByVal createThumbNail As Integer) As Integer
    Declare Function loadjpgthumbnailfrombuffer Lib "VIC32.DLL" (ByVal buffaddr As Integer, ByRef resimg As imgdes, ByVal createThumbNail As Integer) As Integer
    Declare Function loadpcx Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadpcxpalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadpng Lib "VIC32.DLL" (ByVal filename As String, ByRef image As imgdes) As Integer
    Declare Function loadpngfrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef resimg As imgdes) As Integer
    Declare Function loadpngpalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadpngpalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadtga Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadtgapalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadtgawithalpha Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByRef alphaimage As imgdes) As Integer
    Declare Function loadtif Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes) As Integer
    Declare Function loadtiffrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef resimg As imgdes) As Integer
    Declare Function loadtifpage Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByVal page As Integer) As Integer
    Declare Function loadtifpagebyindex Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByVal pageIndex As Integer) As Integer
    Declare Function loadtifpagebyindexfrombuffer Lib "VIC32.DLL" (ByVal buffer As integer, ByRef resimg As imgdes, ByVal pageIndex As integer) As integer
    Declare Function loadtifpagebyindexfrombufferwithalpha Lib "VIC32.DLL" (ByVal buffer As integer, ByRef resimg As imgdes, ByVal pageIndex As integer, ByRef alphaimg as imgdes) As integer
    Declare Function loadtifpalette Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadtifpalettefrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef paltab As RGBQUAD) As Integer
    Declare Function loadtifpalettepage Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD, ByVal page As Integer) As Integer
    Declare Function loadtifpalettepagebyindex Lib "VIC32.DLL" (ByVal filename As String, ByRef paltab As RGBQUAD, ByVal pageIndex As Integer) As Integer
    Declare Function loadtifwithalpha Lib "VIC32.DLL" (ByVal filename As String, ByRef resimg As imgdes, ByRef alphaimage As imgdes) As Integer
    Declare Function matchcolorimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function matchcolorimageex Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Function matrixconv Lib "VIC32.DLL" (ByRef kernel As Byte, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function matrixconvex Lib "VIC32.DLL" (ByVal ksize As Integer, ByRef firstelement As Byte, ByVal divsr As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function medianfilter Lib "VIC32.DLL" (ByVal ksize As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function mirrorimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function multiply Lib "VIC32.DLL" (ByVal multr As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function multiplyex Lib "vic32.dll" (ByVal multiplier As Double, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function multiplyimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function multiplynegative Lib "VICFX.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function negative Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function orimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function outline Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function pcxinfo Lib "VIC32.DLL" (ByVal filename As String, ByRef pdata As PcxData) As Integer
    Declare Function pixelcount Lib "VIC32.DLL" (ByVal min As Integer, ByVal max As Integer, ByRef redct As Integer, ByRef grnct As Integer, ByRef bluct As Integer, ByRef srcimg As imgdes) As Integer
    Declare Function pixellize Lib "VIC32.DLL" (ByVal factr As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function pnggeterror Lib "VIC32.DLL" () As Integer
    Declare Function pnggetxyresolution Lib "VIC32.DLL" (ByVal filename As String, ByRef xres As Integer, ByRef yres As Integer, ByRef resunit As Integer) As Integer
    Declare Sub pngsetxyresolution Lib "VIC32.DLL" (ByVal xres As Integer, ByVal yres As Integer, ByVal resunit As Integer)
    Declare Function pnginfo Lib "VIC32.DLL" (ByVal filename As String, ByRef pinfo As PngData) As Integer
    Declare Function pnginfofrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef pdat As PngData) As Integer
    Declare Function printimage Lib "VIC32.DLL" (ByVal hWnd As Integer, ByVal hdcprn As Integer, ByVal mode As Integer, ByRef image As imgdes, ByRef pRect As RECT, ByVal boxsiz As Integer, ByVal dspfct As Integer) As Integer
    Declare Sub printimageenddoc Lib "VIC32.DLL" (ByVal hdcprn As Integer, ByVal ejectPage As Integer)
    Declare Function printimagenoeject Lib "VIC32.DLL" (ByVal hWnd As Integer, ByVal hdcprn As Integer, ByVal mode As Integer, ByRef image As imgdes, ByRef pRect As RECT, ByVal boxsiz As Integer, ByVal dspfct As Integer) As Integer
    Declare Function printimagestartdoc Lib "VIC32.DLL" (ByVal hdcprn As Integer, ByVal docname As String) As Integer
    Declare Function rainbowpalette Lib "VIC32.DLL" (ByRef image As imgdes) As Integer
    Declare Sub recttoimagearea Lib "VIC32.DLL" (ByRef RECT As RECT, ByRef image As imgdes)
    Declare Function reduceimagecolors Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function removenoise Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function resize Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function resizeex Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Sub rgb2hsv Lib "VIC32.DLL" (ByRef rgbtab As RGBQUAD, ByRef hsvtab As HSVTRIPLE, ByVal colors As Integer)
    Declare Function rotate Lib "VIC32.DLL" (ByVal angle As Double, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function rotateex Lib "VIC32.DLL" (ByVal angle As Double, ByRef srcimg As imgdes, ByRef resimg As imgdes, ByVal mode As Integer) As Integer
    Declare Function rotate90 Lib "VIC32.DLL" (ByVal direction As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function savebif Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes) As Integer
    Declare Function savebmp Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal cmp As Integer) As Integer
    Declare Function savebmptobuffer Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal comp As Integer) As Integer
    Declare Function saveeps Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes) As Integer
    Declare Function savegif Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes) As Integer
    Declare Function savegifex Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal mode As Integer, ByVal transColor As Integer) As Integer
    Declare Function savegifframe Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByRef gsdata As GifGlobalSaveData, ByRef fsdata As GifFrameSaveData, ByVal mode As Integer) As Integer
    Declare Function savegifmultiframetobuffer Lib "VIC32.DLL" (ByRef buffer As Integer, ByRef srcimgarray As imgdes, ByRef gsdata As GifGlobalSaveData, ByRef fsdataarray As GifFrameSaveData, ByVal mode As Integer, ByVal nelem As Integer) As Integer
    Declare Function savegiftobufferex Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal mode As Integer, ByVal transColor As Integer) As Integer
    Declare Function savejpg Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal quality As Integer) As Integer
    Declare Function savejpgex Lib "VIC32.DLL" (ByVal filename As String, ByRef image As imgdes, ByVal quality As Integer, ByVal mode As Integer) As Integer
    Declare Function savejpgtobuffer Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal quality As Integer) As Integer
    Declare Function savejpgtobufferex Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal quality As Integer, ByVal mode As Integer) As Integer
    Declare Function savepcx Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes) As Integer
    Declare Function savepng Lib "VIC32.DLL" (ByVal filename As String, ByRef image As imgdes, ByVal comp As Integer) As Integer
    Declare Function savepngex Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal comp As Integer, ByVal mode As Integer, ByRef savedata as PNG_DATA) As Integer
    Declare Function savepngtobufferex Lib "VIC32.DLL" (ByRef buffer As Integer, ByRef srcimg As imgdes, ByVal comp As Integer, ByVal mode As Integer, ByRef savedata as PNG_DATA) As Integer
    Declare Function savepngtobuffer Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal comp As Integer) As Integer
    Declare Function savetga Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal cmp As Integer) As Integer
    Declare Function savetif Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal cmp As Integer) As Integer
    Declare Function savetifpage Lib "VIC32.DLL" (ByVal filename As String, ByRef srcimg As imgdes, ByVal cmp As Integer, ByVal page As Integer) As Integer
    Declare Function savetiftobuffer Lib "VIC32.DLL" (ByRef buffaddr As Integer, ByRef srcimg As imgdes, ByVal comp As Integer) As Integer
    Declare Sub setgifcomment Lib "VIC32.DLL" (ByVal version As Integer, ByVal gifcomment As String)
    Declare Sub setimagearea Lib "VIC32.DLL" (ByRef image As imgdes, ByVal stx As Integer, ByVal sty As Integer, ByVal endx As Integer, ByVal endy As Integer)
    Declare Function setpixelcolor Lib "VIC32.DLL" (ByRef image As imgdes, ByVal xcoord As Integer, ByVal ycoord As Integer, ByVal level As Integer) As Integer
    Declare Function setupimgdes Lib "VIC32.DLL" (ByVal dib As Integer, ByRef image As imgdes) As Integer
    Declare Function sharpen Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function sharpengentle Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function sortpixelsbyval Lib "VICSTATS.DLL" (ByRef resimg As imgdes, ByRef coordinatearray As COORD_VAL, ByVal nelem As integer) As Integer
    Declare Function subimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function tgainfo Lib "VIC32.DLL" (ByVal filename As String, ByRef tdat As TgaData) As Integer
    Declare Function threshold Lib "VIC32.DLL" (ByVal thres As Integer, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function tiffgeterror Lib "VIC32.DLL" () As Integer
    Declare Function tiffgetpageinfo Lib "VIC32.DLL" (ByVal filename As String, ByRef totalpages As Integer, ByRef pagearray As Integer, ByVal arrayelems As Integer) As Integer
    Declare Function tiffgetpageinfofrombuffer Lib "VIC32.DLL" (ByVal buffer As Integer, ByRef totalpages As Integer, ByRef pageArray As Integer, ByVal arrayelems As Integer) As Integer
    Declare Function tiffgetSOIofspagebyindex Lib "VIC32.DLL" (ByVal filename As String, soiOfs As Integer, ByVal pageIndex As Integer) As Integer
    Declare Function tiffgetSOIofspagebyindexfrombuffer Lib "VIC32.DLL" (ByVal buffer As Integer, soiOfs As Integer, ByVal pageIndex As Integer) As Integer
    Declare Function tiffgetxyresolution Lib "VIC32.DLL" (ByVal filename As String, ByRef xres As Integer, ByRef yres As Integer, ByRef resunit As Integer) As Integer
    Declare Function tiffinfo Lib "VIC32.DLL" (ByVal filename As String, ByRef tdat As TiffData) As Integer
    Declare Function tiffinfofrombuffer Lib "VIC32.DLL" (ByVal buff As Integer, ByRef tdat As TiffData) As Integer
    Declare Function tiffinfopage Lib "VIC32.DLL" (ByVal filename As String, ByRef tdat As TiffData, ByVal page As Integer) As Integer
    Declare Function tiffinfopagebyindex Lib "VIC32.DLL" (ByVal filename As String, ByRef tdat As TiffData, ByVal pageIndex As Integer) As Integer
   Declare Function tiffinfopagebyindexex Lib "VIC32.DLL" (ByVal filename As String, ByRef tinfo As TiffDataEx, ByVal pageIndex As Integer) As Integer
   Declare Function tiffinfopagebyindexfrombuffer Lib "VIC32.DLL" (ByVal buffer As Integer, ByRef tinfo As TiffData, ByVal pageIndex As Integer) As Integer
   Declare Function tiffinfopagebyindexfrombufferex Lib "VIC32.DLL" (ByVal buffer As Integer, ByRef tinfo As TiffDataEx, ByVal pageIndex As Integer) As Integer
    Declare Function tiffgetxyresolutionpagebyindex Lib "VIC32.DLL" (ByVal filename As String, ByRef xres As Integer, ByRef yres As Integer, ByRef resunit As Integer, ByVal targetpage As Integer) As Integer
    Declare Sub tiffsetxyresolution Lib "VIC32.DLL" (ByVal xres As Integer, ByVal yres As Integer, ByVal resunit As Integer)
    Declare Sub unlockLZW Lib "VIC32.DLL" (ByVal key As Integer)
    Declare Function updatebitmapcolortable Lib "VIC32.DLL" (ByRef image As imgdes) As Integer
    Declare Function usetable Lib "VIC32.DLL" (ByRef redtab As Byte, ByRef grntab As Byte, ByRef blutab As Byte, ByRef srcimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function vicSJversion Lib "VICSJ32.DLL" () As Integer
   ' Declare Function Victorversion Lib "VIC32.DLL" () As Short   '' Define in vicread.aspx to define the path to vic32.dll on your server
    Declare Function Victorversionex Lib "VIC32.DLL" (ByRef vicVerInfo As VIC_VERSION_INFO) As Short
    Declare Function victowinpal Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef hPal As Integer) As Integer
    Declare Function viewimage Lib "VIC32.DLL" (ByVal hWnd As Integer, ByVal hdc As Integer, ByRef hPal As Integer, ByVal xpos As Integer, ByVal ypos As Integer, ByRef image As imgdes) As Integer
    Declare Function viewimageex Lib "VIC32.DLL" (ByVal hWnd As Integer, ByVal hdc As Integer, ByRef hPal As Integer, ByVal xpos As Integer, ByVal ypos As Integer, ByRef image As imgdes, ByVal scrx As Integer, ByVal scry As Integer, ByVal colRedMode As Integer) As Integer
    Declare Function windowtoimage Lib "VIC32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes) As Integer
    Declare Function wintovicpal Lib "VIC32.DLL" (ByVal hPal As Integer, ByRef resimg As imgdes) As Integer
    Declare Function wtaverage Lib "VIC32.DLL" (ByVal prct As Integer, ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function xorimage Lib "VIC32.DLL" (ByRef srcimg As imgdes, ByRef oprimg As imgdes, ByRef resimg As imgdes) As Integer
    Declare Function zeroimage Lib "VIC32.DLL" (ByVal level As Integer, ByRef image As imgdes) As Integer
    Declare Sub zeroimgdes Lib "VIC32.DLL" (ByRef image As imgdes)

    Declare Sub TWclose Lib "VICTW32.DLL" ()
    Declare Function TWdetecttwain Lib "VICTW32.DLL" (ByVal hWnd As Integer) As Integer
    Declare Function TWgetbrightness Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef brightness As TWAIN_CAP_DATA) As Integer
    Declare Function TWgetcontrast Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef contrast As TWAIN_CAP_DATA) As Integer
    Declare Function TWgeterror Lib "VICTW32.DLL" () As Integer
    Declare Function TWgetfeeder Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef feederIsEnabled As Integer, ByRef feederHasPaper As Integer) As Integer
    Declare Function TWgetmeasureunit Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef typeUnit As TWAIN_CAP_DATA) As Integer
    Declare Function TWgetpendingxfers Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef count As Integer) As Integer
    Declare Function TWgetphysicalsize Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
    Declare Function TWgetpixeltype Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef pixelType As TWAIN_CAP_DATA) As Integer
    Declare Function TWgetsourcenames Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef namelist As TW_STR32, ByRef nameCount As Integer) As Integer
    Declare Function TWgetsourcencount Lib "VICTW32.DLL" Alias "TWgetsourcenames" (ByVal hWnd As Integer, ByVal nullval As Integer, ByRef nameCount As Integer) As Integer
    Declare Function TWgetxresolution Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef xres As TWAIN_CAP_DATA) As Integer
    Declare Function TWgetyresolution Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef yres As TWAIN_CAP_DATA) As Integer
    Declare Function TWopen Lib "VICTW32.DLL" (ByVal hWnd As Integer) As Integer


    Public Delegate Function SCNFCT(ByRef resimg As imgdes) As Integer
    Declare Function TWscancountimages Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes, ByRef pRect As RECT, ByVal showIU As Integer, ByVal maxPages As Integer, ByVal saveScan As SCNFCT) As Integer
    Declare Function TWscanimage Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes) As Integer
    Declare Function TWscanimageex Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes, ByRef pRect As RECT, ByVal showIU As Integer) As Integer
    Declare Function TWscanmultipleimages Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes, ByVal saveScan As SCNFCT) As Integer
    Declare Function TWscanmultipleimagesex Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef resimg As imgdes, ByRef pRect As RECT, ByVal showIU As Integer, ByVal saveScan As SCNFCT) As Integer
    Declare Function TWselectsource Lib "VICTW32.DLL" (ByVal hWnd As Integer) As Integer
    Declare Function TWselectsourcebyname Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByVal dsname As String) As Integer
    Declare Function TWsetbrightness Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef brightness As TWAIN_CAP_DATA) As Integer
    Declare Function TWsetcontrast Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef contrast As TWAIN_CAP_DATA) As Integer
    Declare Function TWsetduplex Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByVal enableDuplex As Integer) As Integer
    Declare Function TWsetfeeder Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByVal enableFeeder As Integer) As Integer
    Declare Function TWsetmeasureunit Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef typeUnit As TWAIN_CAP_DATA) As Integer
    Declare Function TWsetpagesize Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByVal pageConst As Integer) As Integer
    Declare Function TWsetpixeltype Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef pixelType As TWAIN_CAP_DATA) As Integer
    Declare Function TWsetxresolution Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef xres As TWAIN_CAP_DATA) As Integer
    Declare Function TWsetyresolution Lib "VICTW32.DLL" (ByVal hWnd As Integer, ByRef yres As TWAIN_CAP_DATA) As Integer
    Declare Sub TWsetproductname Lib "VICTW32.DLL" (ByVal prodName As String)
    Declare Function TWvicversion Lib "VICTW32.DLL" () As Short

    ' Error codes for Victor Image Processing  Library for Windows
    Public Const NO_ERROR As Integer = 0 ' No error
    Public Const BAD_RANGE As Integer = -1 ' Range error
    Public Const NO_DIG As Integer = -2 ' Digitizer board not detected
    Public Const BAD_DSK As Integer = -3 ' Disk full, fill not written
    Public Const BAD_OPN As Integer = -4 ' Filename not found
    Public Const BAD_FAC As Integer = -5 ' Non= -dimensional variable out of range
    Public Const BAD_TIFF As Integer = -6 ' Unreadable TIF format
    Public Const BAD_BPS As Integer = -8 ' TIF bits per sample not supported
    Public Const BAD_CMP As Integer = -9 ' Unreadable compression scheme
    Public Const BAD_CRT As Integer = -10 ' Cannot create file
    Public Const BAD_FTPE As Integer = -11 ' Unknown file format
    Public Const BAD_DIB As Integer = -12 ' Device independent bitmap is compressed
    Public Const BAD_MEM As Integer = -14 ' Insufficient memory for function
    Public Const BAD_PIW As Integer = -15 ' Not PIW format
    Public Const BAD_PCX As Integer = -16 ' Unreadable PCX format
    Public Const BAD_GIF As Integer = -17 ' Unreadable GIF format
    Public Const PRT_ERR As Integer = -18 ' Print error
    Public Const SCAN_ERR As Integer = -19 ' Scanner error
    Public Const BAD_TGA As Integer = -25 ' Unreadable TGA format
    Public Const BAD_BPP As Integer = -26 ' Bits per pixel not supported
    Public Const BAD_BMP As Integer = -27 ' Unreadable BMP format
    Public Const NO_DEV_DATA As Integer = -33 ' No data from device
    Public Const TIMEOUT As Integer = -34 ' Function timed out
    Public Const BAD_LOCK As Integer = -40 ' Could not lock memory
    Public Const PRT_BUSY As Integer = -41 ' Print function already executing
    Public Const BAD_IBUF As Integer = -42 ' Invalid image buffer address
    Public Const BAD_JPEG As Integer = -43 ' Unreadable JPEG format
    Public Const TOO_CPLX As Integer = -44 ' Image is too complex to complete operation
    Public Const SCAN_UNLOAD As Integer = -45 ' paper could not be unloaded from ADF
    Public Const SCAN_LIDUP As Integer = -46 ' ADF lid was opened
    Public Const SCAN_NOPAPER As Integer = -47 ' ADF bin is empty
    Public Const SCAN_NOADF As Integer = -48 ' ADF is not connected
    Public Const SCAN_NOTREADY As Integer = -49 ' ADF is connected but not ready
    Public Const NOT_AVAIL As Integer = -50 ' Function not available due to missing module
    Public Const TIFF_NOPAGE As Integer = -51 ' TIF page not found
    Public Const BAD_PTR As Integer = -52 ' Pointer does not point at readable/writable memory
    Public Const LZW_DISABLED As Integer = -53 ' LZW functionality disabled
    Public Const TWAIN_NOWND As Integer = -54 ' Could not create Twain parent window
    Public Const TWAIN_NODSM As Integer = -55 ' Could not open Twain Source Manager
    Public Const TWAIN_NODS As Integer = -56 ' Could not open Twain Data Source
    Public Const TWAIN_ERR As Integer = -57 ' Twain image acquisition error
    Public Const TWAIN_NOMATCH As Integer = -58 ' None of the elements in two lists were equal
    Public Const TWAIN_BAD_DATATYPE As Integer = -59 ' Data type mismatch
    Public Const TWAIN_SCAN_CANCEL As Integer = -60 ' User cancelled scan
    Public Const TWAIN_BUSY As Integer = -61 ' Twain function is busy
    Public Const TWAIN_NO_PAPER As Integer = -66 ' Auto feeder is empty
    Public Const TWAIN_STOP_SCAN As Integer = -67 ' Stop scanning images
    Public Const TIFF_MOTYPE As Integer = -69 ' Motorola byte order

    ' Printimage() print modes
    Public Const PRTDEFAULT As Integer = 0
    Public Const PRTHALFTONE As Integer = 1
    Public Const PRTSCATTER As Integer = 2

    ' Colordither, colorscatter modes
    Public Const COLORSCATTER16 As Integer = 0
    Public Const COLORSCATTER256 As Integer = 1
    Public Const COLORDITHER16 As Integer = 0
    Public Const COLORDITHER256 As Integer = 1

    ' convertrgbtopalmode() modes
    Public Const CR_OCTREENODIFF As Integer = 0 ' Use octree color method without error diffusion
    Public Const CR_OCTREEDIFF As Integer = 1 ' Use octree color method with error diffusion
    Public Const CR_TSDNODIFF As Integer = 2 ' Use TSD color method without error diffusion
    Public Const CR_TSDDIFF As Integer = 3 ' Use TSD color method with error diffusion

    Public Const CR_LOW As Integer = 0 'CR_OCTREENODIFF
    Public Const CR_HIGH As Integer = 3 'CR_TSDDIFF

    ' 24-bit RGB display methods (viewimageex())
    Public Const VIEWOPTPAL As Integer = 0
    Public Const VIEWDITHER As Integer = 1
    Public Const VIEWSCATTER As Integer = 2

    ' calchistorgb modes
    Public Const PALETTEIMAGEASGRAY As Integer = 0
    Public Const PALETTEIMAGEASRGB As Integer = 1

    ' Resize modes
    Public Const RESIZEFAST As Integer = 0
    Public Const RESIZEBILINEAR As Integer = 1

    ' File save defines
    Public Const TIFUNC As Integer = 0
    Public Const TIFLZW As Integer = 1
    Public Const TIFPB As Integer = 2
    Public Const TIFG3 As Integer = 3
    Public Const TIFG4 As Integer = 4
    Public Const BMPUNC As Integer = 0
    Public Const BMPRKE As Integer = 1
    Public Const TGAUNC As Integer = 0
    Public Const TGARLE As Integer = 1
    Public Const PIWUNC As Integer = 0
    Public Const PIWRLE As Integer = 1
    Public Const PNGINTERLACE As Integer = 1
    Public Const PNGALLFILTER As Integer = 0
    Public Const PNGNOFILTER As Integer = 2
    Public Const PNGSUBFILTER As Integer = 4
    Public Const PNGUPFILTER As Integer = 6
    Public Const PNGAVGFILTER As Integer = 8
    Public Const PNGPAETHFILTER As Integer = 10
    Public Const PNGALLFILTERS As Integer = 0 'PNGALLFILTER

    ' Savejpgex modes
    Public Const JPGSEQ As Integer = 0
    Public Const JPGPROG As Integer = 1
    Public Const JPGSEQOPT As Integer = 2

    ' Savegifex mode flags
    Public Const GIFLZWCOMP As Integer = 0
    Public Const GIFINTERLACE As Integer = 1
    Public Const GIFTRANSPARENT As Integer = 2
    Public Const GIFWRITE4BIT As Integer = 4
    Public Const GIFNOCOMP As Integer = 8

    ' Vicversionex flags
    Public Const VIC_VS_STATIC_RTL As Integer = 1
    Public Const VIC_VS_THREAD_SAFE As Integer = 2
    Public Const VIC_VS_RELEASE As Integer = 4
    Public Const VIC_VS_EVAL_LIB As Integer = 8

    Public Const VER_PLATFORM_WIN32s As Integer = 0
    Public Const VER_PLATFORM_WIN32_WINDOWS As Integer = 1
    Public Const VER_PLATFORM_WIN32_NT As Integer = 2

    ' Png extended error codes (available when rcode == BAD_PNG)
    Public Const PNG_ERR_UNK_CRIT_CHK As Integer = -100 'Unknown critical chunk
    Public Const PNG_ERR_TOO_FEW_IDATS As Integer = -101 'Not enough IDATs for image
    Public Const PNG_ERR_INV_IHDR_CHK As Integer = -102 'Invalid IHDR chunk
    Public Const PNG_ERR_INV_BITDEPTH As Integer = -103 'Invalid bit depth in IHDR
    Public Const PNG_ERR_INV_COLORTYPE As Integer = -104 'Invalid color type in IHDR
    Public Const PNG_ERR_INV_BITCOL As Integer = -105 'Invalid color type/bit depth combo in IHDR
    Public Const PNG_ERR_INV_INTERLACE As Integer = -106 'Invalid interlace method in IHDR
    Public Const PNG_ERR_INV_COMP As Integer = -107 'Invalid compression method in IHDR
    Public Const PNG_ERR_INV_FILTER As Integer = -108 'Invalid filter method in IHDR
    Public Const PNG_ERR_IMAGE_SIZE As Integer = -109 'Invalid image size in IHDR
    Public Const PNG_ERR_BAD_SIG As Integer = -110 'Bad PNG signature
    Public Const PNG_ERR_BAD_CRC As Integer = -111 'Bad CRC value
    Public Const PNG_ERR_TOO_MUCH_DATA As Integer = -112 'Extra data at end of file
    Public Const PNG_ERR_EARLY_EOF As Integer = -113 'Unexpected End Of File
    Public Const PNG_ERR_MEM_ERR As Integer = -114 'Memory error
    Public Const PNG_ERR_DECOMPRESSION As Integer = -115 'Decompression error
    Public Const PNG_ERR_COMPRESSION As Integer = -116 'Compression error
    Public Const PNG_ERR_NO_DISK_SPACE As Integer = -117 'Out of disk space

    ' Jpeg extended error codes (available when rcode == BAD_JPEG)
    Public Const JPG_BAD_PRECISION As Integer = -100 'Sample precision is not 8
    Public Const JPG_BAD_EOF As Integer = -101 'Unexpected End Of File
    Public Const JPG_BAD_RESTART As Integer = -102 'Reset marker could not be found
    Public Const JPG_INVALID_MARKER As Integer = -103 'Invalid marker found in the image data
    Public Const JPG_READ_ERR As Integer = -104 'Error reading data from the file
    Public Const JPG_INVALID_DATA As Integer = -105 'Invalid data found in JPEG file
    Public Const JPG_BAD_COMPINFO As Integer = -106 'Component info out of bounds
    Public Const JPG_BAD_BLOCKNO As Integer = -107 'Blocks in an MCU is > 10
    Public Const JPG_BAD_BPPIXEL As Integer = -108 'Bits per sample is not 8
    Public Const JPG_BAD_COMPNO As Integer = -109 'Invalid number of components
    Public Const JPG_BAD_FTYPE As Integer = -110 'File type not SOF0 or SOF1
    Public Const JPG_BAD_EOI As Integer = -111 'Unexpected End Of Image
    Public Const JPG_BAD_JFIF As Integer = -112 'File is not JPEG JFIF
    Public Const JPG_BAD_SCAN_PARAM As Integer = -113 'Bad progressive JPEG scan parameter
    Public Const JPG_BAD_MEM As Integer = -114 'Out of memory
    Public Const JPG_NO_DISK_SPACE As Integer = -115 'Out of disk space

    ' TIFF extended error codes (available when rcode == BAD_TIFF)
    Public Const TIF_INVALID_DATA As Integer = -100 'Invalid data found in TIF file
    Public Const TIF_READ_ERR As Integer = -101 'Error reading data from the file
    Public Const TIF_BAD_EOF As Integer = -102 'Unexpected End Of File
    Public Const TIF_G4_COMPLEX As Integer = -103 'Trans point arrays not large enough

    ' TWAIN function constants
    ' Container constants (4)
    Public Const TWON_ARRAY As Integer = 3
    Public Const TWON_ENUMERATION As Integer = 4
    Public Const TWON_ONEVALUE As Integer = 5
    Public Const TWON_RANGE As Integer = 6

    ' Pixel type constants (9)
    Public Const TWPT_BW As Integer = 0
    Public Const TWPT_GRAY As Integer = 1
    Public Const TWPT_RGB As Integer = 2
    Public Const TWPT_PALETTE As Integer = 3
    Public Const TWPT_CMY As Integer = 4
    Public Const TWPT_CMYK As Integer = 5
    Public Const TWPT_YUV As Integer = 6
    Public Const TWPT_YUVK As Integer = 7
    Public Const TWPT_CIEXYZ As Integer = 8

    ' Units constants (6)
    Public Const TWUN_INCHES As Integer = 0
    Public Const TWUN_CENTIMETERS As Integer = 1
    Public Const TWUN_PICAS As Integer = 2
    Public Const TWUN_POINTS As Integer = 3
    Public Const TWUN_TWIPS As Integer = 4
    Public Const TWUN_PIXELS As Integer = 5

    Public Const TW_DONTCARE As Integer = 65535

    Declare Sub RtlMoveMemory Lib "kernel32" (ByVal des As Integer, ByVal src As Integer, ByVal cnt As Integer)
    Declare Sub Copybmh Lib "kernel32" Alias "RtlMoveMemory" (ByRef des As BITMAPINFOHEADER, ByVal src As Integer, ByVal cnt As Integer)
    Declare Sub CopyDatatbufftoBytearray Lib "kernel32" Alias "RtlMoveMemory" (ByRef des As byte, ByVal src As Integer, ByVal cnt As Integer)
    Declare Sub CopyBytearraytoDatabuff Lib "kernel32" Alias "RtlMoveMemory" (ByVal des As Integer, ByRef src As byte, ByVal cnt As Integer)
    Declare Function GlobalAlloc Lib "kernel32" (ByVal flags As Integer, ByVal dwbytes as Integer) As Integer
    Declare Function GlobalFree Lib "kernel32" (ByVal hmem As Integer) As Integer
    Declare Function GlobalHandle Lib "kernel32" (ByVal Addr As Integer) As Integer
    Declare Function GlobalSize Lib "kernel32" (ByVal hmem As Integer) As Integer

    Public Function buffertobytearray(ByVal buffaddr As Integer)
    dim barray As Byte()
    dim buffhandle as integer
    dim buffsize as integer
   
      buffhandle = GlobalHandle(buffaddr)
      buffsize = GlobalSize(buffhandle)
      redim barray(buffsize)
      CopyDatatbufftoBytearray(barray(0), buffaddr, buffsize)
      GlobalFree(buffhandle)
      buffertobytearray = barray
    End Function

    Public Function bytearraytobuffer(ByRef barray as Byte())
    dim buffsize as integer
    dim buffaddr as integer
   
      buffsize = barray.length         
      buffaddr = GlobalAlloc(0, buffsize)
      if(buffaddr <> 0) then
         CopyBytearraytoDatabuff(buffaddr, barray(0), buffsize)
      end if
      redim barray(1)
      bytearraytobuffer = buffaddr
    End Function

    ' Get BITMAPINFOHEADER from an image descriptor
    Public Sub getbmhfromimage(ByRef newBmh As BITMAPINFOHEADER, ByRef image As imgdes)
        Copybmh(newBmh, image.bmh, 40) ' 40=size of BITMAPINFOHEADER
    End Sub


</script>