<%@ import namespace="system.io" %>
<%@ import namespace="system.net" %>
<%@ import namespace= "system.math" %>

 

<script runat="server">
   ' vicread.aspx -- 
	
	'----------------------------------------------------------

Private Declare Function Victorversion lib "c:\www\bin\vic32.dll" () as short

'Private Declare Function Victorversion lib "D:\www\bin\vic32.dll" () as short



function loadimagedata(byval imageurl as string)
   dim wc as WebClient
   wc = New WebClient
   dim count as integer
   Dim imagedata As Byte()
   
   redim imagedata(0)
   count = 0
   while (count < 5 and imagedata.length < 2)
      imagedata = wc.DownloadData(imageurl)
      count = count + 1
   end while   
   
   if(imagedata.length > 1)

   else 
      redim imagedata(0)  
   end if

   loadimagedata = imagedata
            
end function



public function loadimagefrombytearray(bytearray as byte(), uploaded_ftype as string , byref srcimg as imgdes) as integer
dim inbuff as integer
dim rcode as integer
dim ver as short

      ver = Victorversion()

      inbuff = bytearraytobuffer(bytearray)
      rcode = BAD_FAC
      
	   select case uploaded_ftype
		   case "bmp" 
			   dim binfo as BITMAPINFOHEADER
			   rcode = bmpinfofrombuffer(inbuff, binfo)
			   if(rcode = NO_ERROR) then
				   rcode = allocimage(srcimg, binfo.biWidth, binfo.biHeight, binfo.biBitcount)
				   if(rcode = NO_ERROR) then
					   rcode = loadbmpfrombuffer(inbuff, srcimg)
				   end if
			   end if
      	
		   case "gif" 
			   dim ginfo as GifData
			   rcode = gifinfofrombuffer(inbuff, ginfo)
			   if(rcode = NO_ERROR) then
				   rcode = allocimage(srcimg, ginfo.width, ginfo.length, ginfo.vbitcount)
				   if(rcode = NO_ERROR) then
					   rcode = loadgiffrombuffer(inbuff, srcimg)
				   end if
			   end if
		   case "jpg" 
			   dim jinfo as JpegData
			   rcode = jpeginfofrombuffer(inbuff, jinfo)
			   if(rcode = NO_ERROR) then
				   rcode = allocimage(srcimg, jinfo.width, jinfo.length, jinfo.vbitcount)
				   if(rcode = NO_ERROR) then
					   rcode = loadjpgfrombuffer(inbuff, srcimg)
				   end if
			   end if
		   case "png" 
			   dim pinfo as PngData
			   rcode = pnginfofrombuffer(inbuff, pinfo)
			   if(rcode = NO_ERROR) then
				   rcode = allocimage(srcimg, pinfo.width, pinfo.length, pinfo.vbitcount)
				   if(rcode = NO_ERROR) then
					   rcode = loadpngfrombuffer(inbuff, srcimg)
				   end if
			   end if
		   case "tif" 
			   dim tinfo as TiffData
			   rcode = tiffinfofrombuffer(inbuff, tinfo)
			   if(rcode = NO_ERROR) then
				   rcode = allocimage(srcimg, tinfo.width, tinfo.length, tinfo.vbitcount)
				   if(rcode = NO_ERROR) then
					   rcode = loadtiffrombuffer(inbuff, srcimg)
					   
					   ' 16-bit images have to be converted to 8-bit for viewing
					   if(rcode = NO_ERROR and tinfo.vbitcount = 16) then
					      dim tempimg as imgdes
					      ' Allocate a temp image buffer
					      rcode = allocimage(tempimg, tinfo.width, tinfo.length, 8) 
					      if(rcode = NO_ERROR)
					         dim mm as MINMAX
					         ' Convert the 16-bit image to 8-bit and replace the original 16-bit with the 8-bit
                        rcode = convertgray16to8(srcimg, tempimg)
                        freeimage(srcimg)
                        copyimgdes(tempimg, srcimg)
                        
                        ' If it was only a 10-bit image, it may be too dark to view, brighten
                        calcminmax(srcimg, mm, mm, mm)
                        if(mm.max < 160) then
                           expandcontrast(0, mm.max, srcimg, srcimg)                        
                        end if
					      end if
					   end if
				   end if
			   end if
	   end select

	   if(rcode <> NO_ERROR) then
	      freeimage (srcimg)      ' Release image buffer
      end if

      loadimagefrombytearray = rcode

end function


Public Function loadimagefromfile(byval fname as string, ByRef srcimg as imgdes)
dim flen as integer
dim uploaded_data()  as byte     ' Data received
dim inbuff as integer
dim rcode as integer
dim uploaded_ftype as string
dim ver as short
redim uploaded_data(4)

      ver = Victorversion()

      flen = Len(fname)
      uploaded_ftype = LCase(Mid(fname, flen-2, 3))

   '''  uploaded_data = loadimagedata("http://catenarysystems.com/demos/simple/" & fname(0))
      uploaded_data = loadimagedata("http://localhost/webapplication2/" & fname)
      
      rcode = loadimagefrombytearray(uploaded_data, uploaded_ftype, srcimg)
   loadimagefromfile = rcode
End Function

Public Function loadimagefromurl(byval fname as string, ByRef srcimg as imgdes)
dim flen as integer
dim uploaded_data()  as byte     ' Data received
dim inbuff as integer
dim rcode as integer
dim uploaded_ftype as string
dim ver as short
redim uploaded_data(4)

      ver = Victorversion()

      flen = Len(fname)
      uploaded_ftype = LCase(Mid(fname, flen-2, 3))

   '''  uploaded_data = loadimagedata("http://catenarysystems.com/demos/simple/" & fname(0))
      'uploaded_data = loadimagedata("http://localhost/webapplication2/" & fname)
      
      uploaded_data = loadimagedata(fname)
      rcode = loadimagefrombytearray(uploaded_data, uploaded_ftype, srcimg)
   loadimagefromurl = rcode
End Function



</script>