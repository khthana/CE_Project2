<Script Runat="server">

    Declare Sub freeimage Lib "c:\www\bin\vic32.dll" (ByVal image As integer) ' Note difference!!!


Sub Session_Start()
   Session("adgimage_img") = 0           ' addingdotnetgraphics.aspx
   Session("adgimage_val1") = 0
End Sub

Sub Session_OnEnd()

	if Session("adgimage_val1") = 1 then
		freeimage(Session("adgimage_img"))
		Session("adgimage_img") = 0           ' addingdotnetgraphics.aspx
		Session("adgimage_val1") = 0
	end if

End Sub

</script>