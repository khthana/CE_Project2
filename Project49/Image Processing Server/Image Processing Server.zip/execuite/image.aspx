<%@ Page %>
<%@ import namespace="system.drawing" %>
<%@ import namespace="system.drawing.imaging" %>

<script runat="server">

sub Page_Load
dim objbitmap as bitmap

	Response.ContentType = "image/jpeg"
	objbitmap = Session("vic_bitmap")
	objbitmap.save(response.outputstream, imageformat.jpeg)
	
end sub

</script>
