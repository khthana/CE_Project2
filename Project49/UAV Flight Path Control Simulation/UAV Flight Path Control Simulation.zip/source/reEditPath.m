function path = reEditPath(bestRoute, matrix, R)
    path = bestRoute;
    i = 1;
    while path(i+1) ~= 0
        if matrix(path(i), path(i+1)) < R
            path(i+1) = [];
        else
            i = i+1;
        end
    end