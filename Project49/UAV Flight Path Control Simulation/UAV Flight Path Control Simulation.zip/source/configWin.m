function varargout = configWin(varargin)
% CONFIGWIN M-file for configWin.fig
%      CONFIGWIN, by itself, creates a new CONFIGWIN or raises the existing
%      singleton*.
%
%      H = CONFIGWIN returns the handle to a new CONFIGWIN or the handle to
%      the existing singleton*.
%
%      CONFIGWIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIGWIN.M with the given input arguments.
%
%      CONFIGWIN('Property','Value',...) creates a new CONFIGWIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before configWin_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to configWin_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help configWin

% Last Modified by GUIDE v2.5 04-Mar-2007 20:16:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @configWin_OpeningFcn, ...
                   'gui_OutputFcn',  @configWin_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before configWin is made visible.
function configWin_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to configWin (see VARARGIN)

% Choose default command line output for configWin
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes configWin wait for user response (see UIRESUME)
% uiwait(handles.figure1);

hMainGui = getappdata(0, 'hMainGui');

setappdata(0, 'hConfigGui', gcf);

v = getappdata(hMainGui, 'velocity');
setappdata(hMainGui, 'velocity', v);
c = getappdata(hMainGui, 'head_rate');
setappdata(hMainGui, 'head_rate', c);
k = getappdata(hMainGui, 'k');
setappdata(hMainGui, 'k', k);

strTemp = num2str(v, '% 8.2f');
set(handles.veloBox, 'String', strTemp);
strTemp = num2str(c, '% 8.2f');
set(handles.headBox, 'String', strTemp);
strTemp = num2str(k, '% 8.2f');
set(handles.kBox, 'String', strTemp);


% --- Outputs from this function are returned to the command line.
function varargout = configWin_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function veloBox_Callback(hObject, eventdata, handles)
% hObject    handle to veloBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of veloBox as text
%        str2double(get(hObject,'String')) returns contents of veloBox as a double
hMainGui = getappdata(0, 'hMainGui');
v = str2double(get(handles.veloBox, 'String'));
setappdata(hMainGui, 'velocity', v);

% --- Executes during object creation, after setting all properties.
function veloBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to veloBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function headBox_Callback(hObject, eventdata, handles)
% hObject    handle to headBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of headBox as text
%        str2double(get(hObject,'String')) returns contents of headBox as a double
hMainGui = getappdata(0, 'hMainGui');
c = str2double(get(handles.headBox, 'String'));
setappdata(hMainGui, 'head_rate', c);

% --- Executes during object creation, after setting all properties.
function headBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to headBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function kBox_Callback(hObject, eventdata, handles)
% hObject    handle to kBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kBox as text
%        str2double(get(hObject,'String')) returns contents of kBox as a double
hMainGui = getappdata(0, 'hMainGui');
k = str2double(get(handles.kBox, 'String'));
setappdata(hMainGui, 'k', k);

% --- Executes during object creation, after setting all properties.
function kBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
setappdata(0, 'hConfigGui', 0);
delete(hObject);


