function bestRoute = GeneticSearch(start, dest, linkMatrix)
%GAs start!!!
noOfPop = 50;
chromoList = [];
Pc = 0.5;

% Randomly generate an initial population
while size(chromoList,1) < noOfPop
    chromoList = [chromoList; genPopulation(start, dest, linkMatrix)];
end

bestFitness = inf;
notImprove = 0;
bestRoute = [];
newRoute = [];
iter = 1;
while iter < 500 %termination criterion
    iter = iter+1;
    %calculate the fitness of each chromosome
    fitness = inf;
    fitList = [1,noOfPop];
    for i = (1:noOfPop)
        fitList(i) = calFitness(chromoList(i,:), linkMatrix);
        if fitList(i) < fitness
            fitness = fitList(i);
            newRoute = chromoList(i,:);
        end
    end
    
    %calculate the fitList from 0.0 - 1.0
    for i = (1:noOfPop)
        fitList(i) = fitness/fitList(i);
    end
    
    if  fitness < bestFitness
        notImprove = 0;
        bestFitness = fitness;
        bestRoute = newRoute;
    else
        notImprove = notImprove + 1;
    end
    
    %Is the termination criterion satisfied?
    if notImprove >= 15
        break;
    end
    
    %create new poppulation
    newChromoList = [];
    while size(newChromoList,1) < noOfPop
        %select a pair of chromosomes for mating
        prob = 0;
        while prob < (1.0-Pc)
            select = round(rand*(noOfPop-1)) + 1;
            prob = fitList(select)*rand;
        end
        chromoM = chromoList(select,:);
        
        prob = 0;
        while prob < Pc
            select = round(rand*(noOfPop-1)) + 1;
            prob = fitList(select)*rand;
        end
        chromoF = chromoList(select,:);
        
        %crossover to create 2 offspring
        [osA osB] = crossover(chromoM, chromoF);
        
        %mutation
        
        %place the resulting chromosomes in the new population
        newChromoList = [newChromoList; osA; osB];
    end
    
    %replace the current chromosome population with the new population
    chromoList = newChromoList;
end

%--------------------------------------------------------------------------

function chromo = genPopulation(start, goal, matrix)
noOfNodes = size(matrix,1);
visited = zeros(1,noOfNodes);
chromo = zeros(1,noOfNodes);

chromo(1) = start;
visited(start) = 1;
i = 1;
while visited(goal) == 0
    linklist = [];
    for n = (1:noOfNodes)
        if (matrix(chromo(i),n) ~= inf) & (visited(n) ~= 1)
            linklist = [linklist n];
        end
    end
    
    numLink = numel(linklist);
    if numLink ~= 0
        i = i+1;
        select = round(rand*(numLink-1)) + 1;
        chromo(i) = linklist(select);
        visited(linklist(select)) = 1;
    else
        chromo = [];
        return
    end
end

%--------------------------------------------------------------------------

function [osA osB] = crossover(chromoM, chromoF)
numM = find(chromoM == 0, 1, 'first') - 1;
numF = find(chromoF == 0, 1, 'first') - 1;
chrmLen = numel(chromoM);

%find common-node
commonList = [];
for i = (3:numM-2) %not use first or last 1 node
    if ~isempty(find(chromoF == chromoM(i)))
        commonList = [commonList chromoM(i)];
    end
end

numCommon = numel(commonList);
if numCommon ~= 0
    select = round(rand*(numCommon-1)) + 1;
    common = commonList(select);
    
    crossM = find(chromoM == common, 1, 'first');
    crossF = find(chromoF == common, 1, 'first');
    
    osA = [chromoM(1:crossM) chromoF(crossF+1:numF)];
    osA = padding(osA, chrmLen);
    
    osB = [chromoF(1:crossF) chromoM(crossM+1:numM)];
    osB = padding(osB, chrmLen);
    
else
    osA = [];
    osB = [];
    return
end


function new = padding(old, len)
oldLen = numel(old);
if oldLen <= len
    new = [old zeros(1, len-oldLen)];
else
    new = [];
end

%--------------------------------------------------------------------------
