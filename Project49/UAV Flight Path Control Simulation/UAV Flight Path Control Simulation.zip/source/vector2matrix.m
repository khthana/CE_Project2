function [noOfNodes, matrix, netXloc, netYloc] = vector2matrix(vx, vy, start, goal)

    %list node and get noOfNodes
    netXloc = [start(1) goal(1)];
    netYloc = [start(2) goal(2)];
    noOfVectors = size(vx,2);
    for i = 1:noOfVectors
        sx = find(netXloc == vx(1,i));
        sy = find(netYloc == vy(1,i));
        if isempty(sx)||isempty(sy)
            netXloc = [netXloc vx(1,i)];
            netYloc = [netYloc vy(1,i)];
        end
        dx = find(netXloc == vx(2,i));
        dy = find(netYloc == vy(2,i));
        if isempty(dx)||isempty(dy)
            netXloc = [netXloc vx(2,i)];
            netYloc = [netYloc vy(2,i)];
        end
    end
    noOfNodes = size(netXloc,2);
    
    %create matrix of link
    matrix = ones(noOfNodes)*inf;
    for i = 1:noOfNodes
        sx = find(vx(1,:) == netXloc(i));
        sy = find(vy(1,:) == netYloc(i));
        sxy = intersect(sx,sy);
        for j = 1:noOfNodes
            dx = find(vx(2,:) == netXloc(j));
            dy = find(vy(2,:) == netYloc(j));
            dxy = intersect(dx,dy);
            if ~isempty(intersect(sxy,dxy)) % there is a link;
                matrix(i, j) = distance(netXloc(i),netYloc(i),netXloc(j),netYloc(j)); 
                matrix(j, i) = distance(netXloc(i),netYloc(i),netXloc(j),netYloc(j)); 
            else
                
            end
        end
    end
    %start link
    for i = 3:noOfNodes
        x1 = [start(1) netXloc(i)];
        y1 = [start(2) netYloc(i)];
        for j = 1:noOfVectors
            x2 = [vx(1,j) vx(2,j)];
            y2 = [vy(1,j) vy(2,j)];
            [x y] = curveintersect(x1,y1,x2,y2);
            if isempty(x) || (abs(x-netXloc(i))<0.1 && abs(y-netYloc(i))<0.1)
                continue
            else
                j = 0;
                break
            end
        end
        if j ~= 0
            matrix(1, i) = distance(start(1),start(2),netXloc(i),netYloc(i)); 
            matrix(i, 1) = distance(start(1),start(2),netXloc(i),netYloc(i));
        end
    end
    
    %goal link
    for i = 3:noOfNodes
        x1 = [goal(1) netXloc(i)];
        y1 = [goal(2) netYloc(i)];
        for j = 1:noOfVectors
            x2 = [vx(1,j) vx(2,j)];
            y2 = [vy(1,j) vy(2,j)];
            [x y] = curveintersect(x1,y1,x2,y2);
            if isempty(x) || (abs(x-netXloc(i))<0.1 && abs(y-netYloc(i))<0.1)
                continue
            else
                j = 0;
                break
            end
        end
        if j ~= 0
            matrix(2, i) = distance(goal(1),goal(2),netXloc(i),netYloc(i));
            matrix(i, 2) = distance(goal(1),goal(2),netXloc(i),netYloc(i));
        end
    end

%--------------------------------------------------------------------------

function dist = distance(x1,y1,x2,y2)
    dist = sqrt(abs(x1-x2)^2 + abs(y1-y2)^2);
