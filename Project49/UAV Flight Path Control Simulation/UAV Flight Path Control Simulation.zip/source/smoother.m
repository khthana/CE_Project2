function psp = smoother(w0,w1,w2,v,c,k)
    R    = v/c;
    posi = w0;
    head = arcangle(w0,w1);
    
    Cpk  = Circle_Pk(w0,w1,w2,k,R);
    CL   = Circle_L(posi,R,head);
    CR   = Circle_R(posi,R,head);
    q1   = uvector(w0,w1);
    q2   = uvector(w1,w2);
    q    = uvector(q1,q2);
    
    ts   = 0.1;
    vs   = ts*v;
    c    = ts*c;
    psp  = [posi];
    
    if psi(q1,q2) > 0
        %switching time t2
        while myDistance(CL,Cpk) > 2*R
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CL   = Circle_L(posi,R,head);
        end
        t2 = posi;
        
        %switching time t3
        CR = Circle_R(posi,R,head);
        while psi(CR-CL,uvector(CL,Cpk)) < 0
            head = adjangle(head + c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CR   = Circle_R(posi,R,head);
        end
        t3 = posi;
        
        %switching time t4
        hq   = [1-2*(q(2)^2) 2*q(1)*q(2) ;...
                2*q(1)*q(2)  1-2*(q(1)^2)];
        CLt4 = w1 + (hq*(CL-w1)')';
        %1st transition from S1->S2
        while psi(CL-w1,q) < 0
            head = adjangle(head - c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CL   = Circle_L(posi,R,head);
        end
        %2nd transition from S3->S4
        while psi(CL-CLt4,uvector(CLt4,Cpk)) < 0
            head = adjangle(head - c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CL   = Circle_L(posi,R,head);
        end
        t4 = posi;
        
        %switching time t5
        R90 = [cos(pi/2) -sin(pi/2);...
               sin(pi/2)  cos(pi/2)];
        while psi(CR-CL,-(R90*q2')') < 0
            head = adjangle(head + c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CR   = Circle_R(posi,R,head);
        end
        t5 = posi;
        
    elseif psi(q1,q2) < 0
        %switching time t2
        while myDistance(CR,Cpk) > 2*R
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CR   = Circle_R(posi,R,head);
        end
        t2 = posi;
        
        %switching time t3
        CL = Circle_L(posi,R,head);
        while psi(CL-CR,uvector(CR,Cpk)) > 0
            head = adjangle(head - c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CL   = Circle_L(posi,R,head);
        end
        t3 = posi;
        
        %switching time t4
        hq   = [1-2*(q(2)^2) 2*q(1)*q(2) ;...
                2*q(1)*q(2)  1-2*(q(1)^2)];
        CRt4 = w1 + (hq*(CR-w1)')';
        %1st transition from S1->S2
        while psi(CR-w1,q) > 0
            head = adjangle(head + c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CR   = Circle_R(posi,R,head);
        end
        %2nd transition from S3->S4
        while psi(CR-CRt4,uvector(CRt4,Cpk)) > 0
            head = adjangle(head + c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CR   = Circle_R(posi,R,head);
        end
        t4 = posi;
        
        %switching time t5
        R90 = [cos(pi/2) -sin(pi/2);...
               sin(pi/2)  cos(pi/2)];
        while psi(CL-CR,(R90*q2')') > 0
            head = adjangle(head - c);
            posi = posi + [inerx(vs,head) inery(vs,head)];
            psp  = [psp; posi];
            CL   = Circle_L(posi,R,head);
        end
        t5 = posi;
    end
end
    
%--------------------------------------------------------------------------

function w = arcangle(a, b)
dx = b(1) - a(1);
dy = b(2) - a(2);
w = atan(abs(dy/dx));
    if dx >= 0 & dy >= 0    %Q1
        w = 0 + w;
    elseif dx < 0 & dy >= 0 %Q2
        w = pi - w;
    elseif dx < 0 & dy < 0  %Q3
        w = pi + w;
    elseif dx >= 0 & dy < 0 %Q4
        w = 2*pi - w;
    end
end

function angle = adjangle(angle)
    if angle < 0
        angle = angle + 2*pi;
    elseif angle > 2*pi
        angle = angle - 2*pi;
    end
end

%--------------------------------------------------------------------------

function pk = Circle_Pk(w0,w1,w2,k,R)
    q1 = uvector(w0,w1);
    q2 = uvector(w1,w2);
    
    B  = acos(-q1*q2');         %angle between q1 and a2
    q  = uvector(q1,q2);        %bisector of angle B
    k  = k*R*((1/(sin(B/2)))-1);
    pk = w1 + (R + k)*q;
end
    
function c = Circle_L(z,R,h)
    x = z(1) + R*(-sin(h));
    y = z(2) + R*(cos(h));
    c = [x y];
end
    
function c = Circle_R(z,R,h)
    x = z(1) + R*(sin(h));
    y = z(2) + R*(-cos(h));
    c = [x y];
end

%--------------------------------------------------------------------------

function v = uvector(w0,w1)
    v = w1-w0;
    v = v/abs(complex(v(1),v(2)));
end

function x = psi(a,b)
    x = sign(a(2)*b(1) - b(2)*a(1));
end

function x = inerx(v, w)
    x = v*cos(w);
end

function y = inery(v, w)
    y = v*sin(w);
end
    
function s = myDistance(p1,p2)
     s = p2-p1;
     s = abs(complex(s(1),s(2)));
end
