function varargout = mainWin(varargin)
% MAINWIN M-file for mainWin.fig
%      MAINWIN, by itself, creates a new MAINWIN or raises the existing
%      singleton*.
%
%      H = MAINWIN returns the handle to a new MAINWIN or the handle to
%      the existing singleton*.
%
%      MAINWIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAINWIN.M with the given input arguments.
%
%      MAINWIN('Property','Value',...) creates a new MAINWIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mainWin_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mainWin_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help mainWin

% Last Modified by GUIDE v2.5 04-Mar-2007 19:55:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mainWin_OpeningFcn, ...
                   'gui_OutputFcn',  @mainWin_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mainWin is made visible.
function mainWin_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mainWin (see VARARGIN)

% Choose default command line output for mainWin
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mainWin wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%Define application data
setappdata(0, 'hMainGui', gcf);

setappdata(hObject, 'arrayX', []);
setappdata(hObject, 'arrayY', []);
setappdata(hObject, 'strPos', []);

setappdata(hObject, 'trajectory', []);

setappdata(hObject,  'velocity', 20);
setappdata(hObject, 'head_rate', 0.2);
setappdata(hObject,         'k', 0);

%Open configWin
configWin

% --- Outputs from this function are returned to the command line.
function varargout = mainWin_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function posX_Callback(hObject, eventdata, handles)
% hObject    handle to posX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of posX as text
%        str2double(get(hObject,'String')) returns contents of posX as a double


% --- Executes during object creation, after setting all properties.
function posX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to posX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function posY_Callback(hObject, eventdata, handles)
% hObject    handle to posY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of posY as text
%        str2double(get(hObject,'String')) returns contents of posY as a double


% --- Executes during object creation, after setting all properties.
function posY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to posY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



% --- Executes on button press in runButton.
function runButton_Callback(hObject, eventdata, handles)
% hObject    handle to runButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1)
cla
hold on

start = [str2double(get(handles.startX, 'String')) str2double(get(handles.startY, 'String'))];
goal  = [ str2double(get(handles.goalX, 'String'))  str2double(get(handles.goalY, 'String'))];

x = getappdata(handles.figure1, 'arrayX');
setappdata(handles.figure1, 'arrayX', x);
y = getappdata(handles.figure1, 'arrayY');
setappdata(handles.figure1, 'arrayY', y);

v = getappdata(handles.figure1, 'velocity');
setappdata(handles.figure1, 'velocity', v);
c = getappdata(handles.figure1, 'head_rate');
setappdata(handles.figure1, 'head_rate', c);
k = getappdata(handles.figure1, 'k');
setappdata(handles.figure1, 'k', k);

[vx, vy] = voronoi([x start(1) goal(1)],[y start(2) goal(2)]);
plot(x,y,'r+')

[noOfNodes, matrix, netXloc, netYloc] = vector2matrix(vx, vy, start, goal);
for i = 1:noOfNodes
    plot(netXloc(i), netYloc(i), '.');
    %if i > 2
    %    text(netXloc(i), netYloc(i), num2str(i));
    %end
    for j = i:noOfNodes
        if matrix(i, j) ~= inf
            line([netXloc(i) netXloc(j)], [netYloc(i) netYloc(j)], 'LineStyle', ':', 'Color', 'G');
        end
    end
end
text(start(1), start(2), 'S');
text( goal(1),  goal(2), 'G');

bestRoute = GeneticSearch(1, 2, matrix);
numBR = find(bestRoute == 0, 1, 'first') - 1;
waypoint = [];
for i = 1:numBR
    waypoint = [waypoint; netXloc(bestRoute(i)) netYloc(bestRoute(i))];
end
waypoint
    
if ~isempty(bestRoute)
    numBR = find(bestRoute == 0, 1, 'first') - 1;
    plot(netXloc(bestRoute(1:numBR)), netYloc(bestRoute(1:numBR)), 'b.-', 'LineWidth', 1.0)
    
    distance = num2str(calFitness(bestRoute, matrix), '% 8.2f')   
    
    R = v/c;
    bestRoute = reEditPath(bestRoute, matrix, 1.0*R);
    numBR = find(bestRoute == 0, 1, 'first') - 1;
    smoothPath = [netXloc(bestRoute(1)) netYloc(bestRoute(1))];
    for i = 1:numBR-2
        pointA = smoothPath(end,:);
        pointB = [netXloc(bestRoute(i+1)) netYloc(bestRoute(i+1))];
        pointC = [netXloc(bestRoute(i+2)) netYloc(bestRoute(i+2))];
       smoothPath = [smoothPath; smoother(pointA, pointB, pointC, v, c, k)];
    end
    plot(smoothPath(:,1), smoothPath(:,2), 'r-', 'LineWidth', 1.0)
    
    setappdata(handles.figure1, 'trajectory', smoothPath);
end

axis equal
hold off


% --- Executes on button press in addPos.
function addPos_Callback(hObject, eventdata, handles)
% hObject    handle to addPos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

inputX = str2double(get(handles.posX,'String'));
inputY = str2double(get(handles.posY,'String'));

set(handles.posX,'String','');
set(handles.posY,'String','');

if isnan(inputX) || isnan(inputY)
    errordlg('You must enter a numeric value','Bad Input','modal')
    return
end

arrayX = getappdata(handles.figure1, 'arrayX');
arrayX = [arrayX inputX];
setappdata(handles.figure1, 'arrayX', arrayX);

arrayY = getappdata(handles.figure1, 'arrayY');
arrayY = [arrayY inputY];
setappdata(handles.figure1, 'arrayY', arrayY);

axes(handles.axes1)
cla
hold on
plot(arrayX,arrayY,'r+')
axis equal
hold off

strPos = getappdata(handles.figure1, 'strPos');
if size(strPos,1) ~= 0
    strPos(size(strPos,1),:) = [];
end
inPos = [num2str(inputX, '%08.2f'),'   ',num2str(inputY, '%08.2f')];
strPos = [strPos; inPos; '                   '];
set(handles.listbox1, 'String', strPos);
setappdata(handles.figure1, 'strPos', strPos);


function startBox_Callback(hObject, eventdata, handles)
% hObject    handle to startBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startBox as text
%        str2double(get(hObject,'String')) returns contents of startBox as a double


% --- Executes during object creation, after setting all properties.
function startBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function startY_Callback(hObject, eventdata, handles)
% hObject    handle to startY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startY as text
%        str2double(get(hObject,'String')) returns contents of startY as a double


% --- Executes during object creation, after setting all properties.
function startY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function goalX_Callback(hObject, eventdata, handles)
% hObject    handle to goalX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of goalX as text
%        str2double(get(hObject,'String')) returns contents of goalX as a double


% --- Executes during object creation, after setting all properties.
function goalX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to goalX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function goalY_Callback(hObject, eventdata, handles)
% hObject    handle to goalY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of goalY as text
%        str2double(get(hObject,'String')) returns contents of goalY as a double


% --- Executes during object creation, after setting all properties.
function goalY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to goalY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in delPos.
function delPos_Callback(hObject, eventdata, handles)
% hObject    handle to delPos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ind_selected = get(handles.listbox1,'Value');

arrayX = getappdata(handles.figure1, 'arrayX');
arrayY = getappdata(handles.figure1, 'arrayY');

if ind_selected > numel(arrayX)
    return
end

arrayX(ind_selected) = [];
setappdata(handles.figure1, 'arrayX', arrayX);

arrayY(ind_selected) = [];
setappdata(handles.figure1, 'arrayY', arrayY);

axes(handles.axes1)
cla
hold on
plot(arrayX,arrayY,'r+')
axis equal
hold off

strPos = getappdata(handles.figure1, 'strPos');
strPos(ind_selected,:) = [];
setappdata(handles.figure1, 'strPos', strPos);
set(handles.listbox1, 'String', strPos);



function noRand_Callback(hObject, eventdata, handles)
% hObject    handle to noRand (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of noRand as text
%        str2double(get(hObject,'String')) returns contents of noRand as a double


% --- Executes during object creation, after setting all properties.
function noRand_CreateFcn(hObject, eventdata, handles)
% hObject    handle to noRand (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in ranPos.
function ranPos_Callback(hObject, eventdata, handles)
% hObject    handle to ranPos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Get start & goal from GUI
startX = str2double(get(handles.startX, 'String'));
startY = str2double(get(handles.startY, 'String'));
goalX = str2double(get(handles.goalX, 'String'));
goalY = str2double(get(handles.goalY, 'String'));

area = 80;
minX = min(startX, goalX) - area;
maxX = max(startX, goalX) + area;
minY = min(startY, goalY) - area;
maxY = max(startY, goalY) + area;

randX = rand*(maxX-minX) + minX; 
randY = rand*(maxY-minY) + minY; 

arrayX = getappdata(handles.figure1, 'arrayX');
arrayX = [arrayX randX];
setappdata(handles.figure1, 'arrayX', arrayX);

arrayY = getappdata(handles.figure1, 'arrayY');
arrayY = [arrayY randY];
setappdata(handles.figure1, 'arrayY', arrayY);

axes(handles.axes1)
cla
hold on
plot(arrayX,arrayY,'r+')
axis equal
hold off

strPos = getappdata(handles.figure1, 'strPos');
if size(strPos,1) ~= 0
    strPos(size(strPos,1),:) = [];
end
inPos = [num2str(randX, '%08.2f'),'   ',num2str(randY, '%08.2f')];
strPos = [strPos; inPos; '                   '];
set(handles.listbox1, 'String', strPos);
setappdata(handles.figure1, 'strPos', strPos);


% --- Executes on button press in showButton.
function showButton_Callback(hObject, eventdata, handles)
% hObject    handle to showButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes1)
cla
hold on

start = [str2double(get(handles.startX, 'String')) str2double(get(handles.startY, 'String'))];
goal  = [ str2double(get(handles.goalX, 'String'))  str2double(get(handles.goalY, 'String'))];

x = getappdata(handles.figure1, 'arrayX');
setappdata(handles.figure1, 'arrayX', x);
y = getappdata(handles.figure1, 'arrayY');
setappdata(handles.figure1, 'arrayY', y);

[vx, vy] = voronoi([x start(1) goal(1)],[y start(2) goal(2)]);
plot(x,y,'r+')

[noOfNodes, matrix, netXloc, netYloc] = vector2matrix(vx, vy, start, goal);
for i = 1:noOfNodes
    plot(netXloc(i), netYloc(i), '.');
    %if i > 2
    %    text(netXloc(i), netYloc(i), num2str(i));
    %end
    for j = i:noOfNodes
        if matrix(i, j) ~= inf
            line([netXloc(i) netXloc(j)], [netYloc(i) netYloc(j)], 'LineStyle', ':', 'Color', 'G');
        end
    end
end
text(start(1), start(2), 'S');
text( goal(1),  goal(2), 'G');

axis equal
hold off


% --------------------------------------------------------------------
function open_threats_Callback(hObject, eventdata, handles)
% hObject    handle to open_threats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename,pathname] = uigetfile({'*.mat';'*.*'},'Open Threats');
if isequal([filename,pathname],[0,0])
    return
else
    % Construct the full path and load
    File = fullfile(pathname,filename);
    load(File,'start','goal','x','y','strPos')
    
    set(handles.startX, 'String', num2str(start(1)))
    set(handles.startY, 'String', num2str(start(2)))
    set(handles.goalX, 'String', num2str(goal(1)))
    set(handles.goalY, 'String', num2str(goal(2)))

    setappdata(handles.figure1, 'arrayX', x);
    setappdata(handles.figure1, 'arrayY', y);

    setappdata(handles.figure1, 'strPos', strPos);
    set(handles.listbox1, 'String', strPos);
end

% --------------------------------------------------------------------
function save_threats_Callback(hObject, eventdata, handles)
% hObject    handle to save_threats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
start = [str2double(get(handles.startX, 'String')) str2double(get(handles.startY, 'String'))];
goal  = [ str2double(get(handles.goalX, 'String'))  str2double(get(handles.goalY, 'String'))];

x = getappdata(handles.figure1, 'arrayX');
setappdata(handles.figure1, 'arrayX', x);
y = getappdata(handles.figure1, 'arrayY');
setappdata(handles.figure1, 'arrayY', y);

strPos = getappdata(handles.figure1, 'strPos');
setappdata(handles.figure1, 'strPos', strPos);

[filename,pathname] = uiputfile({'*.mat';'*.*'},'Save Threats','treats.mat');
if isequal([filename,pathname],[0,0])
    return
else
    % Construct the full path and save
    File = fullfile(pathname,filename);
    save(File,'start','goal','x','y','strPos')
end


% --------------------------------------------------------------------
function save_trajectory_Callback(hObject, eventdata, handles)
% hObject    handle to save_trajectory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
trajectory = getappdata(handles.figure1, 'trajectory');
setappdata(handles.figure1, 'trajectory', trajectory);

[filename,pathname] = uiputfile({'*.mat';'*.*'},'Save Trajectory','trajectory.mat');
if isequal([filename,pathname],[0,0])
    return
else
    % Construct the full path and save
    File = fullfile(pathname,filename);
    save(File,'trajectory')
end

% --------------------------------------------------------------------
function File_Callback(hObject, eventdata, handles)
% hObject    handle to File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function conf_Win_Callback(hObject, eventdata, handles)
% hObject    handle to conf_Win (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
configWin

% --------------------------------------------------------------------
function View_Callback(hObject, eventdata, handles)
% hObject    handle to View (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on mouse press over axes background.
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[x,y] = gpos(hObject);
set(handles.posX, 'String', num2str(x,'% 8.2f'))
set(handles.posY, 'String', num2str(y,'% 8.2f'))

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
hConfigGui = getappdata(0, 'hConfigGui');
if hConfigGui ~= 0
    delete(hConfigGui);
end

delete(hObject);




% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1
button_state = get(hObject,'Value');
if button_state == get(hObject,'Max')
    % toggle button is pressed
    zoom on
elseif button_state == get(hObject,'Min')
    % toggle button is not pressed
    zoom off
end


