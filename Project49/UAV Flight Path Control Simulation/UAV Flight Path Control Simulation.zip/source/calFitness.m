function fitness = calFitness(chromo, matrix)
fitness = 0;
now = 1;
while chromo(now+1) ~= 0
    dist = matrix(chromo(now),chromo(now+1));
    fitness = fitness + dist;
    now = now+1;
    if now >= numel(chromo)
        return
    end
end