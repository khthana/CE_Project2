unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TForm2 = class(TForm)
    Memo1: TMemo;
    Memo2: TMemo;
    Memo3: TMemo;
    Add_Text: TButton;
    Label1: TLabel;
    Com: TButton;
    LoadFile: TButton;
    Num_Char: TLabel;
    Num_Code: TLabel;
    Num_Head: TLabel;
    SaveFile: TButton;
    GetText2: TButton;
    Label2: TLabel;
    procedure Add_TextClick(Sender: TObject);
    procedure ComClick(Sender: TObject);
    procedure LoadFileClick(Sender: TObject);
    procedure SaveFileClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure GetText2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;
  i,Max : integer;
  STR : string;

implementation

uses Unit1, Unit3;

{$R *.DFM}

procedure TForm2.Add_TextClick(Sender: TObject);
var j,k : integer;
begin
k:=1;
for j:=0 to StrtoInt(Num_Char.Caption) do
   begin
   if (Form3.Edit1.Text = Memo1.Lines[j]) and (Memo2.Lines[j] = Form1.Code.Caption) and (Memo3.Lines[j] = Form1.Head_1.Caption+Form1.Head_2.Caption+Form1.Head_3.Caption+Form1.Head_4.Caption+Form1.Head_5.Caption+Form1.Head_6.Caption) then
      begin
      k:=0;
      end;
   end;

if k = 1 then
   begin
   Memo1.Lines[i]:=Form3.Edit1.Text+#13#10;
   Memo2.Lines[i]:=Form1.Code.Caption+#13#10;
   Memo3.Lines[i]:=Form1.Head_1.Caption+Form1.Head_2.Caption+Form1.Head_3.Caption+Form1.Head_4.Caption+Form1.Head_5.Caption+Form1.Head_6.Caption+#13#10;
   Max:=Memo1.Lines.Count;
   Form3.Edit1.Clear;
   i:=i+1;
   end;

   //if k = 1 then Form3.Label1.Caption:='New in Base'
   //else Form3.Label1.Caption:='Old in Base';
end;

procedure TForm2.ComClick(Sender: TObject);
begin
STR :=Form1.Head_1.Caption+Form1.Head_2.Caption+Form1.Head_3.Caption+Form1.Head_4.Caption+Form1.Head_5.Caption+Form1.Head_6.Caption;
label1.Caption:=Form1.Code.Caption;
Label2.Caption:=STR;

Num_Char.Caption:=InttoStr(Memo1.Lines.Count);
Num_Code.Caption:=InttoStr(Memo2.Lines.Count);
Num_Head.Caption:=InttoStr(Memo3.Lines.Count);
end;

procedure TForm2.LoadFileClick(Sender: TObject);
var f    : textfile;
    line : String;
begin
Memo1.Clear;
AssignFile(f,'Base\Char.txt');
Reset(f);
Try
Memo1.Lines.BeginUpdate;
while not Eof (f) do
begin
Readln (f,line);
Memo1.Lines.Add(Line);
end;
finally
CloseFile(f);
Memo1.Lines.EndUpdate;
end;

Memo2.Clear;
AssignFile(f,'Base\Code.txt');
Reset(f);
Try
Memo2.Lines.BeginUpdate;
while not Eof (f) do
begin
Readln (f,line);
Memo2.Lines.Add(Line);
end;
finally
CloseFile(f);
Memo2.Lines.EndUpdate;
end;

Memo3.Clear;
AssignFile(f,'Base\Head.txt');
Reset(f);
Try
Memo3.Lines.BeginUpdate;
while not Eof (f) do
begin
Readln (f,line);
Memo3.Lines.Add(Line);
end;
finally
CloseFile(f);
Memo3.Lines.EndUpdate;
end;

Num_Char.Caption:=InttoStr(Memo1.Lines.Count);
Num_Code.Caption:=InttoStr(Memo2.Lines.Count);
Num_Head.Caption:=InttoStr(Memo3.Lines.Count);

i:=StrtoInt(Num_Head.Caption);
end;

procedure TForm2.SaveFileClick(Sender: TObject);
begin
Memo1.Lines.SaveToFile('Base\Char.txt');
Memo2.Lines.SaveToFile('Base\Code.txt');
Memo3.Lines.SaveToFile('Base\Head.txt');
end;

procedure TForm2.FormShow(Sender: TObject);
begin
LoadFile.Click;
end;

procedure TForm2.GetText2Click(Sender: TObject);
var  code_chk : String;
     Head_chk : String;
     i : integer;
begin
For i:=0 to StrtoInt(Num_Char.Caption) do
   begin
   code_chk := Memo2.Lines[i];
   Head_chk := Memo3.Lines[i];
   if (code_chk = label1.Caption) and (Head_chk = label2.Caption) then Form1.Memo1.Text := Memo1.Lines[i];
   end;
end;

end.
