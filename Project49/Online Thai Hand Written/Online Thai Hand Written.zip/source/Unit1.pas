unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, jpeg, StdCtrls, Grids;

type
  TForm1 = class(TForm)
    Button1: TButton;
    Move_x: TLabel;
    Move_y: TLabel;
    Label1: TLabel;
    Label2: TLabel;
    Status_pen: TLabel;
    Label3: TLabel;
    StringGrid1: TStringGrid;
    Label4: TLabel;
    Label5: TLabel;
    ST_x: TLabel;
    ST_y: TLabel;
    Timer1: TTimer;
    Timer2: TTimer;
    Button2: TButton;
    Label6: TLabel;
    Num: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    En_x: TLabel;
    En_y: TLabel;
    Button3: TButton;
    Button4: TButton;
    Label9: TLabel;
    Get_Num: TLabel;
    Code: TLabel;
    Memo1: TMemo;
    Timer3: TTimer;
    Timer5: TTimer;
    Panel1: TPanel;
    Button5: TButton;
    Panel2: TPanel;
    Button6: TButton;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Hei_Type: TLabel;
    Button7: TButton;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label18: TLabel;
    Head_1: TLabel;
    Button8: TButton;
    Label19: TLabel;
    Label20: TLabel;
    Head_2: TLabel;
    Head_3: TLabel;
    Head_4: TLabel;
    Head_5: TLabel;
    Head_6: TLabel;
    Wid_type: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    R_L: TRadioButton;
    R_N: TRadioButton;
    Bevel1: TBevel;
    Bevel2: TBevel;
    Bevel3: TBevel;
    procedure Button1Click(Sender: TObject);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure FormMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Timer1Timer(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Timer3Timer(Sender: TObject);
    procedure Timer5Timer(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure R_LClick(Sender: TObject);
    procedure R_NClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  End;

Var
  Form1: TForm1;
  Max_X,Max_Y,Min_X,Min_Y,Start_X,Start_Y:Integer;
  i,k1,k2,Num1,Sh : Integer;
  H1,H2,H3,H4,H5,H6 : Integer;

implementation

uses Unit2, Unit3;

{$R *.DFM}

procedure TForm1.Button1Click(Sender: TObject);
Var j:Integer;
Begin
Form1.Canvas.Rectangle(0,0,150,210);
Form1.Canvas.MoveTo(0,70);Form1.Canvas.LineTo(150,70);
Form1.Canvas.MoveTo(0,140);Form1.Canvas.LineTo(150,140);
Form1.Canvas.MoveTo(75,0);Form1.Canvas.LineTo(75,210);

Stringgrid1.Cells[0,0]:='Num';
Stringgrid1.Cells[1,0]:='Pos x';
Stringgrid1.Cells[2,0]:='Pos y';
Stringgrid1.Cells[3,0]:='Pos 6';
Stringgrid1.Cells[4,0]:='Code';
Stringgrid1.Cells[5,0]:='Vec_X';
Stringgrid1.Cells[6,0]:='Vec_Y';
Stringgrid1.Cells[7,0]:='Vector';
Stringgrid1.Cells[8,0]:='Head 1';
Stringgrid1.Cells[9,0]:='Head 2';
Stringgrid1.Cells[10,0]:='Head 3';
Stringgrid1.Cells[11,0]:='Head 4';
Stringgrid1.Cells[12,0]:='Head 5';
Stringgrid1.Cells[13,0]:='Head 6';


For j:=1 to 500 do
Begin
Stringgrid1.Cells[1,j]:='0';
Stringgrid1.Cells[2,j]:='0';
Stringgrid1.Cells[3,j]:='0';
Stringgrid1.Cells[4,j]:='0';
Stringgrid1.Cells[5,j]:='';
Stringgrid1.Cells[6,j]:='';
Stringgrid1.Cells[7,j]:='';
Stringgrid1.Cells[8,j]:='';
Stringgrid1.Cells[9,j]:='';
Stringgrid1.Cells[10,j]:='';
Stringgrid1.Cells[11,j]:='';
Stringgrid1.Cells[12,j]:='';
Stringgrid1.Cells[13,j]:='';
End;

Memo1.Text:='';

ST_x.Caption:='0';
ST_y.Caption:='0';
En_x.Caption:='0';
En_y.Caption:='0';
Num.Caption:='0';
Get_Num.Caption:='0';
Code.Caption:='Code';
Hei_Type.Caption:='Hei_Type';
Wid_Type.Caption:='Wid_Type';
Head_1.Caption:='Null';
Head_2.Caption:='Null';
Head_3.Caption:='Null';
Head_4.Caption:='Null';
Head_5.Caption:='Null';
Head_6.Caption:='Null';

i:=0;
k1:=0;
k2:=0;

Max_X := 0;
Max_Y := 0;
Min_X := 150;
Min_Y := 210;

Label14.Caption:='0';
Label21.Caption:='0';
End;

procedure TForm1.FormMouseMove(Sender: TObject; Shift: TShiftState; X,Y: Integer);
Begin
Move_x.Caption :=InttoStr(x);
Move_y.Caption :=InttoStr(y);

IF Status_pen.Caption = '0' Then
   Begin
   Form1.Canvas.MoveTo(x,y);
   End;

IF Status_pen.Caption = '1' Then
   Begin
   IF (x>=0) and (x<=150) and (y>=0) and (y<=210) Then
      Begin
      Start_X:=x;
      Start_Y:=y;
      Form1.Canvas.LineTo(x,y);

      IF Min_X >= Start_X then Min_X:=Start_X;
      Label10.Caption:='Min X '+Inttostr(Min_X);

      IF Min_Y >= Start_Y then Min_Y:=Start_Y;
      Label11.Caption:='Min Y '+Inttostr(Min_Y);

      IF Max_X <= Start_X then Max_X:=Start_X;
      Label12.Caption:='Max X '+Inttostr(Max_X);

      IF Max_Y <= Start_Y then Max_Y:=Start_Y;
      Label13.Caption:='Max Y '+Inttostr(Max_Y);

      Timer3.Enabled:=True;
      End
   Else
      Begin
      Form1.Canvas.MoveTo(x,y);
      Status_pen.Caption:= '0';
      End;
   End;
End;

procedure TForm1.FormMouseDown(Sender: TObject; Button: TMouseButton;Shift: TShiftState; X, Y: Integer);
Begin
IF (x>=0) and (x<=150) and (y>=0) and (y<=210) Then
   Begin
   Status_pen.Caption:='1';
   Start_X:=x;
   Start_Y:=y;
   ST_x.Caption:=InttoStr(x);
   ST_y.Caption:=InttoStr(y);
   End;
End;

procedure TForm1.FormMouseUp(Sender: TObject; Button: TMouseButton;Shift: TShiftState; X, Y: Integer);
Begin
Status_pen.Caption:='0';
End;

procedure TForm1.Timer1Timer(Sender: TObject);
Begin
IF Status_pen.Caption = '1' Then Timer2.Enabled:=True;
IF Status_pen.Caption = '0' Then Timer2.Enabled:=False;
End;

procedure TForm1.Timer2Timer(Sender: TObject);
Begin
i:=i+1;
Stringgrid1.Cells[0,i]:=InttoStr(i);
Stringgrid1.Cells[1,i]:=InttoStr(Start_X);
Stringgrid1.Cells[2,i]:=InttoStr(Start_Y);

IF (Start_X>=0) and (Start_X<=74) and (Start_Y>=140) and (Start_Y<=210) Then Stringgrid1.Cells[3,i]:='1';
IF (Start_X>=0) and (Start_X<=74) and (Start_Y>=70) and (Start_Y<=139) Then Stringgrid1.Cells[3,i]:='2';
IF (Start_X>=0) and (Start_X<=74) and (Start_Y>=0) and (Start_Y<=69) Then Stringgrid1.Cells[3,i]:='3';

IF (Start_X>=75) and (Start_X<=150) and (Start_Y>=0) and (Start_Y<=69) Then Stringgrid1.Cells[3,i]:='4';
IF (Start_X>=75) and (Start_X<=150) and (Start_Y>=70) and (Start_Y<=139) Then Stringgrid1.Cells[3,i]:='5';
IF (Start_X>=75) and (Start_X<=150) and (Start_Y>=140) and (Start_Y<=210) Then Stringgrid1.Cells[3,i]:='6';


Num.Caption:=InttoStr(i);
Num1:=i;
End;

procedure TForm1.Button2Click(Sender: TObject);
Var a,b,j : Integer;
Begin

//Form1.Canvas.MoveTo(600,70);Form1.Canvas.LineTo(750,70);
//Form1.Canvas.MoveTo(600,140);Form1.Canvas.LineTo(750,140);
//Form1.Canvas.MoveTo(675,0);Form1.Canvas.LineTo(675,210);

Num1:=StrtoInt(Num.Caption);

For j:=1 to Num1 do
Begin
A:=StrtoInt(Stringgrid1.Cells[1,j]);
B:=StrtoInt(Stringgrid1.Cells[2,j]);
//Form1.Canvas.MoveTo(A+600,B);
//Form1.Canvas.LineTo(A+601,B);
Form1.Canvas.Rectangle(A-3,B-3,A+3,B+3);
Form1.Canvas.Rectangle(A-2,B-2,A+2,B+2);
Form1.Canvas.Rectangle(A-1,B-1,A+1,B+1);
//Form1.Canvas.Rectangle(A,B,A+2,B+2);
//Form1.Canvas.Rectangle(A,B,A+1,B+1);
End;
End;

procedure TForm1.Button3Click(Sender: TObject);
Var a,b,j : Integer;
Begin
En_x.Caption:=Stringgrid1.Cells[1,i];
En_y.Caption:=Stringgrid1.Cells[2,i];

For j:=1 to Num1 do
   Begin
   a:=StrtoInt(Stringgrid1.Cells[3,j]);
   b:=StrtoInt(Stringgrid1.Cells[3,j+1]);
   IF a <> b Then
      Begin
      k1:=k1+1;
      Get_Num.Caption:=InttoStr(k1);
      Stringgrid1.Cells[4,k1]:=InttoStr(a);
      End;
   End;
k1:=0;
End;

procedure TForm1.Button4Click(Sender: TObject);
Var Get_Num1,j : Integer;
Begin
//if sh = 1 then Button2.Click;
Button2.Click;
Get_num1 := StrtoInt(Get_Num.Caption);
Code.Caption := '';
For j:=1 to Get_Num1 do
Begin
Code.Caption:=Code.Caption+Stringgrid1.Cells[4,j];
End;

IF (Code.Caption = '123456')                                  then Memo1.Text:='�';
IF (Code.Caption = '123456') and (Head_1.Caption = 'Right')   then Memo1.Text:='�';
IF (Code.Caption = '123456') and (Head_1.Caption = 'Left')    then Memo1.Text:='�';
IF (Code.Caption = '2123456') and (Head_2.Caption = 'Right')and (Head_3.Caption = 'RURD') then Memo1.Text:='�';
IF (Code.Caption = '2123456') and (Head_2.Caption = 'Right') and (Head_3.Caption = 'Left_2')   then Memo1.Text:='�';
IF (Code.Caption = '2123456') and (Head_2.Caption = 'Left')   then Memo1.Text:='�';
IF (Code.Caption = '2123456') and (Head_2.Caption = 'Left')  and (Head_3.Caption = 'Left_2')   then Memo1.Text:='�';
IF (Code.Caption = '2123456') and (Head_2.Caption = 'Left')  and (Head_3.Caption = ' ')   then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Left')    then Memo1.Text:='�';
IF ((Code.Caption = '321654') and (Head_3.Caption = 'Left')) and (Head_2.Caption = 'Left_2')  then Memo1.Text:='�';
IF ((Code.Caption = '32125654') or (Code.Caption = '3212345654') or (Code.Caption = '321235654') or (Code.Caption = '32121654') or (Code.Caption = '3212654'))and (Head_3.Caption = 'Right') then Memo1.Text:='�';
IF ((Code.Caption = '32125654') or (Code.Caption = '3212345654') or (Code.Caption = '321235654')) and (Hei_Type.Caption = 'Type_2') then Memo1.Text:='�';
//IF ((Code.Caption = '32125654') or (Code.Caption = '3212345654') or (Code.Caption = '321235654')) and (Head_4.Caption = 'Left') then Memo1.Text:='�';
IF ((Code.Caption = '32125654') or (Code.Caption = '3212345654') or (Code.Caption = '321235654') or (Code.Caption = '32121654') or (Code.Caption = '3212654'))and ((Head_3.Caption = 'Right') and (Head_4.Caption = 'Left')) then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Hei_Type.Caption = 'Type_1') and (Wid_Type.Caption = 'Type_2')   then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Hei_Type.Caption = 'Type_2') and (Wid_Type.Caption = 'Type_2')   then Memo1.Text:='�';
IF (Code.Caption = '32123456') and (H3 < 15)  then Memo1.Text:='�';
IF (Code.Caption = '32123456') and (H3 > 15)  then Memo1.Text:='�';
IF ((Code.Caption = '32165434') and (H3 < 15)and (Head_4.Caption = 'OH4') and (Wid_Type.Caption = 'Type_1')) or ((Code.Caption = '321654') and (H3 < 15) and (Head_4.Caption = 'OH4') and (Wid_Type.Caption = 'Type_1'))  then Memo1.Text:='�';
IF ((Code.Caption = '321654') and (H3 > 15) and (Head_4.Caption = 'OH4')) or ((Code.Caption = '32165434') and (H3 > 15)) then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Wid_Type.Caption = 'Type_1') and (H3 < 15) and (Head_4.Caption <> 'OH4') then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Wid_Type.Caption = 'Type_1') and (H3 > 15) then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Head_1.Caption = 'Right') and (H3 < 15) then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right') and (Head_1.Caption = 'Right') and (H3 > 15) then Memo1.Text:='�';


//IF (Code.Caption = '1234561') and (H6 < 25) then Memo1.Text:='�';
IF (Code.Caption = '234561') and (Head_2.Caption = 'Left') and (Head_1.Caption = 'Left')  then Memo1.Text:='�';

//IF (Code.Caption = '1234561') and (H6 > 25) then Memo1.Text:='�';
IF (Code.Caption = '234561') and (Head_2.Caption = 'Left') and (Head_1.Caption = 'Left') and (Head_6.Caption = 'OP5') then Memo1.Text:='�';
IF (Code.Caption = '234561') and (Head_2.Caption = 'Left') and (Head_1.Caption = 'Left') and (Head_6.Caption = 'OP5') then Memo1.Text:='�';


IF (Code.Caption = '12345654') and (Head_6.Caption = 'Left') then Memo1.Text:='�';
IF (Code.Caption = '12345654') and (Head_6.Caption = 'Left_2') then Memo1.Text:='�';

IF (Code.Caption = '216543') and (Head_2.Caption = 'Left')    then Memo1.Text:='�';
IF ((Code.Caption = '216543') and (Head_2.Caption = 'Right')) or ((Code.Caption = '256543') and (Head_2.Caption = 'Right')) or ((Code.Caption = '21543') and (Head_2.Caption = 'Right')) or ((Code.Caption = '26543') and (Head_2.Caption = 'Right')) then Memo1.Text:='�';
IF (Code.Caption = '216543') and (Head_2.Caption = 'Right') and (Head_6.Caption = 'Right')  then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Left')  and (Hei_Type.Caption = 'Type_2') then Memo1.Text:='�';
IF (Code.Caption = '321654') and (Head_3.Caption = 'Right' )and (Head_6.Caption = 'Right')   then Memo1.Text:='�';
IF ((Code.Caption = '45652') or (Code.Caption = '45612') or  (Code.Caption = '4562')) and (Head_4.Caption = 'Right') then Memo1.Text:='�';
IF Code.Caption = '123456546' then Memo1.Text:='�';
IF Code.Caption = '212345654' then Memo1.Text:='�';
IF Code.Caption = '12565434' then Memo1.Text:='�';
IF Code.Caption = '21234564' then Memo1.Text:='�';
IF (Code.Caption = '2165234') or (Code.Caption = '2165434') then Memo1.Text:='�';
//IF (Code.Caption = '216523461') or (Code.Caption = '256523461') then Memo1.Text:='�';
IF ((Code.Caption = '216543461') and (Head_2.Caption = 'Right')) or ((Code.Caption = '256543461') and (Head_2.Caption = 'Right')) or ((Code.Caption = '21543461') and (Head_2.Caption = 'Right')) or ((Code.Caption = '26543461') and (Head_2.Caption = 'Right')) then Memo1.Text:='�';
IF (Code.Caption = '2165434') and (Head_2.Caption = 'Left') then Memo1.Text:='�';
IF Code.Caption = '3216545' then Memo1.Text:='�';
IF (Code.Caption = '6165234') or (Code.Caption = '1234') or (Code.Caption = '65234') or (Code.Caption = '6165434') or (Code.Caption = '616534')  then Memo1.Text:='�';
IF Code.Caption = '1256543' then Memo1.Text:='�';
IF (Code.Caption = '616543')  or ((Code.Caption = '6543')  and (Head_6.Caption = 'LULDRD') )   then Memo1.Text:='�';
IF ((Code.Caption = '32125456') and (Head_3.Caption = 'Right') and (Head_4.Caption = 'Left' )) or ((Code.Caption = '3212456') and (Head_3.Caption = 'Right') and (Head_4.Caption = 'Left' )) or ((Code.Caption = '3215456') and (Head_3.Caption = 'Right') and (Head_4.Caption = 'Left' )) or ((Code.Caption = '32125456') and (Head_3.Caption = 'Right') and (Head_4.Caption = 'Left' )) then Memo1.Text:='�';


if (Memo1.Text ='') and (R_L.Checked = True) then Form3.Show;

//if (Memo1.Text ='') and (R_N.Checked = True) then
//   begin
   Form2.Com.Click;
   Form2.GetText2.Click;
//   end;
End;

procedure TForm1.Timer3Timer(Sender: TObject);
Begin
button3.Click;
Button6.Click;
Button7.Click;
Button8.Click;
button4.Click;
Timer3.Enabled:=False;
End;

procedure TForm1.Timer5Timer(Sender: TObject);
Begin
Button1.Click;

Form1.Height:=300;
Sh:=0;
Timer5.Enabled:=False;
Form2.Visible:=False;
End;

procedure TForm1.Button5Click(Sender: TObject);
Begin
//Button5.Caption:=Inttostr(Show);
IF Sh = 0 then
Begin
Sh:=1;
Stringgrid1.Visible:=True;
Button5.Caption:= 'Hide';
Form1.Height:=580;
End

Else IF Sh = 1 then
Begin
Sh:=0;
Stringgrid1.Visible:=False;
Button5.Caption:= 'Show';
Form1.Height:=300;
End;

End;

procedure TForm1.Button6Click(Sender: TObject);
Var i,Buff1,Min1,Dive1,Dive2 : Integer;
Begin
Min1 := 210;
For i:=1 to Num1 do
   Begin
   IF StringGrid1.Cells[3,i] = '3' then
      Begin
      Buff1 :=StrtoInt(StringGrid1.Cells[2,i]);
      IF Buff1 < Min1 then Min1 := Buff1;
      End;
   End;
Dive1:=(Min_Y-Min1);
IF Dive1 > -10 Then Hei_Type.Caption:='Type_1';  //S
IF Dive1 < -10 Then Hei_Type.Caption:='Type_2';  //L

Dive2:=(Max_X-Min_X);
IF Dive2 < 80 Then Wid_type.Caption:='Type_1';  //N
IF Dive2 > 80 Then Wid_type.Caption:='Type_2';  //W

Label14.Caption:=InttoStr(Dive1);
Label21.Caption:=InttoStr(Dive2);
End;

procedure TForm1.Button7Click(Sender: TObject);
Var i,j,V1,V2,V3,V4 : Integer;
Begin
For j:=1 to 6 do
Begin
For i:=1 to Num1 do
   Begin
   IF StringGrid1.Cells[3,i] = InttoStr(j) then
      Begin
      V1:=StrtoInt(StringGrid1.Cells[1,i]);
      V2:=StrtoInt(StringGrid1.Cells[1,i+1]);
      IF V1 > V2 Then StringGrid1.Cells[5,i+1]:='L';
      IF V1 < V2 Then StringGrid1.Cells[5,i+1]:='R';
      IF V1 = V2 Then StringGrid1.Cells[5,i+1]:='Null';

      V3:=StrtoInt(StringGrid1.Cells[2,i]);
      V4:=StrtoInt(StringGrid1.Cells[2,i+1]);
      IF V3 > V4 Then StringGrid1.Cells[6,i+1]:='U';
      IF V3 < V4 Then StringGrid1.Cells[6,i+1]:='D';
      IF V3 = V4 Then StringGrid1.Cells[6,i+1]:='Null';

      StringGrid1.Cells[7,i+1]:=StringGrid1.Cells[5,i+1]+StringGrid1.Cells[6,i+1];
      End;
   End;
End;
StringGrid1.Cells[5,Num1+1]:='';
StringGrid1.Cells[6,Num1+1]:='';
StringGrid1.Cells[7,Num1+1]:='';

H3:=0;
For i:=1 to Num1 do
   Begin
   IF StringGrid1.Cells[3,i] = '3' then H3:=H3+1;
   Label22.Caption := InttoStr(H3);
   End;

H6:=0;
For i:=1 to Num1 do
   Begin
   IF StringGrid1.Cells[3,i] = '1' then H6:=H6+1;
   Label23.Caption := InttoStr(H6);
   End;
End;

procedure TForm1.Button8Click(Sender: TObject);
Var k,j :integer;
    c,d :String;
begin
H1:=8;
For k:=1 to 6 do
Begin
For j:=2 to Num1 do
   Begin
   IF StringGrid1.Cells[3,j] = InttoStr(k) then
      Begin
      c:=Stringgrid1.Cells[7,j];
      d:=Stringgrid1.Cells[7,j+1];
      IF (c <> d) and (Stringgrid1.Cells[5,j] <> 'Null') and (Stringgrid1.Cells[6,j] <> 'Null') Then
         Begin
         K2:=K2+1;
         Stringgrid1.Cells[H1,K2]:=c;
         End;
      End;
   End;
K2:=0;
H1:=H1+1;
End;

Head_1.Caption:=Stringgrid1.Cells[8,1]+Stringgrid1.Cells[8,2]+Stringgrid1.Cells[8,3]+Stringgrid1.Cells[8,4];
Head_2.Caption:=Stringgrid1.Cells[9,1]+Stringgrid1.Cells[9,2]+Stringgrid1.Cells[9,3]+Stringgrid1.Cells[9,4];
Head_3.Caption:=Stringgrid1.Cells[10,1]+Stringgrid1.Cells[10,2]+Stringgrid1.Cells[10,3]+Stringgrid1.Cells[10,4];
Head_4.Caption:=Stringgrid1.Cells[11,1]+Stringgrid1.Cells[11,2]+Stringgrid1.Cells[11,3]+Stringgrid1.Cells[11,4];
Head_5.Caption:=Stringgrid1.Cells[12,1]+Stringgrid1.Cells[12,2]+Stringgrid1.Cells[12,3]+Stringgrid1.Cells[12,4];
Head_6.Caption:=Stringgrid1.Cells[13,1]+Stringgrid1.Cells[13,2]+Stringgrid1.Cells[13,3]+Stringgrid1.Cells[13,4];
 /////////////////////////////////////////////////////
       // R H1
If Head_1.Caption = 'RURDLDLU' Then Head_1.Caption:='Right';
If Head_1.Caption = 'RDLDLURU' Then Head_1.Caption:='Right';
If Head_1.Caption = 'LDLURURD' Then Head_1.Caption:='Right';
If Head_1.Caption = 'LURURDLD' Then Head_1.Caption:='Right';

If Head_1.Caption = 'LDLURD' Then Head_1.Caption:='Right';
If Head_1.Caption = 'LURULD' Then Head_1.Caption:='Right';
If Head_1.Caption = 'RURDLU' Then Head_1.Caption:='Right';
If Head_1.Caption = 'RDLDRU' Then Head_1.Caption:='Right';

If Head_1.Caption = 'LDRURD' Then Head_1.Caption:='Right';
If Head_1.Caption = 'LURDLD' Then Head_1.Caption:='Right';
If Head_1.Caption = 'RULDLU' Then Head_1.Caption:='Right';
If Head_1.Caption = 'RDLURU' Then Head_1.Caption:='Right';

//If Head_1.Caption = 'RDLDLU' Then Head_1.Caption:='Right';
If Head_1.Caption = 'LDLU' Then Head_1.Caption:='Right';
       // L H1
If Head_1.Caption = 'LULDRDRU' Then Head_1.Caption:='Left';
If Head_1.Caption = 'LDRDRU' Then Head_1.Caption:='Left';
//If Head_1.Caption = 'LDRD' Then Head_1.Caption:='Left';
If Head_1.Caption = 'LDRDRULU' Then Head_1.Caption:='Left';
//If Head_1.Caption = 'LDRU' Then Head_1.Caption:='Left';
//If Head_1.Caption = 'RDRU' Then Head_1.Caption:='Left';
If Head_1.Caption = 'RDLDLURU' Then Head_1.Caption:='Left';
If Head_1.Caption = 'LDLURU'   Then Head_1.Caption:='Right'; //book �

 ////////////////////////////////////////////////////////////////////

  //    22222222222222222222222222222222222222222222222222
 //////////////////////////////////////////////////////////////////
//If Head_2.Caption = 'LDLURURD' Then Head_2.Caption:='Right';
//If Head_2.Caption = 'LURURD' Then Head_2.Caption:='Right';
//If Head_2.Caption = 'LDLURU' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RURDLDLU' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RDLDLURU' Then Head_2.Caption:='Right';
If Head_2.Caption = 'LDLURURD' Then Head_2.Caption:='Right';
If Head_2.Caption = 'LURURDLD' Then Head_2.Caption:='Right';

If Head_2.Caption = 'LDLURD' Then Head_2.Caption:='Right';
If Head_2.Caption = 'LURULD' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RURDLU' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RDLDRU' Then Head_2.Caption:='Right';

If Head_2.Caption = 'LDRURD' Then Head_2.Caption:='Right';
If Head_2.Caption = 'LURDLD' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RULDLU' Then Head_2.Caption:='Right';
If Head_2.Caption = 'RDLURU' Then Head_2.Caption:='Right';

If Head_2.Caption = 'RDRULULD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'RDRULULU' Then Head_2.Caption:='Left'; //book
If Head_2.Caption = 'RULULDRD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'LULDRDRU' Then Head_2.Caption:='Left';
If Head_2.Caption = 'LDRDRULU' Then Head_2.Caption:='Left';

If Head_2.Caption = 'LDRULU' Then Head_2.Caption:='Left';
If Head_2.Caption = 'RDLULD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'RULDRD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'LDRDRU' Then Head_2.Caption:='Left';

If Head_2.Caption = 'LDRDLU' Then Head_2.Caption:='Left';
If Head_2.Caption = 'RDRULD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'RULURD' Then Head_2.Caption:='Left';
If Head_2.Caption = 'LULDRU' Then Head_2.Caption:='Left';


If Head_2.Caption = 'RDLD' Then Head_2.Caption:='Left_2';
If Head_2.Caption = 'LDRD' Then Head_2.Caption:='Left_2';
If Head_2.Caption = 'LDRDLD' Then Head_2.Caption:='Left_2';
//If Head_2.Caption = 'LDRDLU' Then Head_2.Caption:='Left_2';
//If Head_2.Caption = 'LDRDRU' Then Head_2.Caption:='Left_2';
////////////////////////////////////////////////////////////

 // 3333333333333333
 //////////////////////////////////////////////////////////


 If Head_3.Caption = 'RURDLDLU' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RDLDLURU' Then Head_3.Caption:='Right';
If Head_3.Caption = 'LDLURURD' Then Head_3.Caption:='Right';
If Head_3.Caption = 'LURURDLD' Then Head_3.Caption:='Right';

If Head_3.Caption = 'LDLURD' Then Head_3.Caption:='Right';
If Head_3.Caption = 'LURULD' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RURDLU' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RDLDRU' Then Head_3.Caption:='Right';

If Head_3.Caption = 'LDRURD' Then Head_3.Caption:='Right';
If Head_3.Caption = 'LURDLD' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RULDLU' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RDLURU' Then Head_3.Caption:='Right';
//If Head_3.Caption = 'LDLURURD' Then Head_3.Caption:='Right';
//If Head_3.Caption = 'RDLDLURU' Then Head_3.Caption:='Right';
If Head_3.Caption = 'RDRULULD' Then Head_3.Caption:='Left';
If Head_3.Caption = 'RULU' Then Head_3.Caption:='Left';
If Head_3.Caption = 'RDRULU' Then Head_3.Caption:='Left';
If Head_3.Caption = 'RULULD' Then Head_3.Caption:='Left';
If Head_3.Caption = 'RU' Then Head_3.Caption:='Left_2';
If Head_3.Caption = '' Then Head_3.Caption:=' ';
If Head_3.Caption = 'RURD' Then Head_3.Caption:='RURD';
 /////////////////////////////////////////////////////////
 // 444444444444444444444444444444
 /////////////////////////////////////////////////////////
If Head_4.Caption = 'LULDRDRU' Then Head_4.Caption:='Left';
If Head_4.Caption = 'RULULDRD' Then Head_4.Caption:='Left';
If Head_4.Caption = 'RULULD' Then Head_4.Caption:='Left';
If Head_4.Caption = 'LURU' Then Head_4.Caption:='OH4';
If Head_4.Caption = 'RULURU' Then Head_4.Caption:='OH4';

If Head_4.Caption = 'RURDLDLU' Then Head_4.Caption:='Right';
If Head_4.Caption = 'RDLDLURU' Then Head_4.Caption:='Right';
If Head_4.Caption = 'LDLURURD' Then Head_4.Caption:='Right';
If Head_4.Caption = 'LURURDLD' Then Head_4.Caption:='Right';

If Head_4.Caption = 'LDLURD' Then Head_4.Caption:='Right';
If Head_4.Caption = 'LURULD' Then Head_4.Caption:='Right';
If Head_4.Caption = 'RURDLU' Then Head_4.Caption:='Right';
If Head_4.Caption = 'RDLDRU' Then Head_4.Caption:='Right';

If Head_4.Caption = 'LDRURD' Then Head_4.Caption:='Right';
If Head_4.Caption = 'LURDLD' Then Head_4.Caption:='Right';
If Head_4.Caption = 'RULDLU' Then Head_4.Caption:='Right';
If Head_4.Caption = 'RDLURU' Then Head_4.Caption:='Right';

  ////////////////////////////////////////////////////
  // 6666666666666666666666666
  //////////////////////////////////////////////////////
If Head_6.Caption = 'RURDLDLU'  Then Head_6.Caption:='Right';
If Head_6.Caption = 'RURDLD'    Then Head_6.Caption:='Left';
If Head_6.Caption = 'RDLDRURU'    Then Head_6.Caption:='Left';
If Head_6.Caption = 'RDRURDLD'    Then Head_6.Caption:='Left';
If Head_6.Caption = 'RURDLU'    Then Head_6.Caption:='Right';
If Head_6.Caption = 'LDLURURD'    Then Head_6.Caption:='Left_2';
If Head_6.Caption = 'RDLULD'    Then Head_6.Caption:='OP5';
If Head_6.Caption = 'LULD'    Then Head_6.Caption:='OP5';
If Head_6.Caption = 'LULDRD'    Then Head_6.Caption:='OP5';
If Head_6.Caption = 'RDLULDLU'    Then Head_6.Caption:='OP5';







End;

procedure TForm1.R_LClick(Sender: TObject);
begin
Form3.Show;
end;

procedure TForm1.R_NClick(Sender: TObject);
begin
Form3.Edit1.Clear;
Form3.Edit1.Enabled:=True;
Form3.Close;
end;

End.
