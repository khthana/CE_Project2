unit Unit3;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

type
  TForm3 = class(TForm)
    Edit1: TEdit;
    Button1: TButton;
    Button2: TButton;
    Bevel1: TBevel;
    Button3: TButton;
    Label1: TLabel;
    procedure Button2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Edit1KeyPress(Sender: TObject; var Key: Char);
    procedure Button3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form3: TForm3;

implementation

uses Unit2, Unit1;

{$R *.DFM}
procedure TForm3.FormShow(Sender: TObject);
begin
Label1.Caption:='In put Character';
Form2.LoadFile.Click;
Edit1.Enabled:=True;
end;

procedure TForm3.Edit1KeyPress(Sender: TObject; var Key: Char);
begin
if Length(Edit1.Text) = 0 then Edit1.Enabled:=False;
end;

procedure TForm3.Button1Click(Sender: TObject);
begin
If Edit1.Text <> '' then
   begin
   Form2.Add_Text.Click;
   Form2.SaveFile.Click;
   Edit1.Clear;
   Form3.Close;
   Form1.Button1.Click;
   end
Else Label1.Caption:='Error! Chk Character';
end;


procedure TForm3.Button2Click(Sender: TObject);
begin
Edit1.Clear;
Edit1.Enabled:=True;
Edit1.SetFocus;
end;


procedure TForm3.Button3Click(Sender: TObject);
begin
Edit1.Clear;
Edit1.Enabled:=True;
Form3.Close;
end;

end.
