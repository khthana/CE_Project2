object Form2: TForm2
  Left = 197
  Top = 403
  BorderIcons = []
  BorderStyle = bsSingle
  Caption = 'Base'
  ClientHeight = 190
  ClientWidth = 741
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Visible = True
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 104
    Top = 168
    Width = 3
    Height = 13
  end
  object Num_Char: TLabel
    Left = 8
    Top = 136
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Num_Code: TLabel
    Left = 104
    Top = 136
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Num_Head: TLabel
    Left = 280
    Top = 136
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label2: TLabel
    Left = 280
    Top = 168
    Width = 3
    Height = 13
  end
  object Memo1: TMemo
    Left = 8
    Top = 8
    Width = 89
    Height = 121
    ScrollBars = ssVertical
    TabOrder = 0
  end
  object Memo2: TMemo
    Left = 104
    Top = 8
    Width = 169
    Height = 121
    ScrollBars = ssVertical
    TabOrder = 1
  end
  object Memo3: TMemo
    Left = 280
    Top = 8
    Width = 329
    Height = 121
    ScrollBars = ssVertical
    TabOrder = 2
  end
  object Add_Text: TButton
    Left = 624
    Top = 8
    Width = 75
    Height = 25
    Caption = 'Add_Text'
    TabOrder = 3
    OnClick = Add_TextClick
  end
  object Com: TButton
    Left = 624
    Top = 32
    Width = 75
    Height = 25
    Caption = 'Com'
    TabOrder = 4
    OnClick = ComClick
  end
  object LoadFile: TButton
    Left = 624
    Top = 56
    Width = 75
    Height = 25
    Caption = 'LoadFile'
    TabOrder = 5
    OnClick = LoadFileClick
  end
  object SaveFile: TButton
    Left = 624
    Top = 80
    Width = 75
    Height = 25
    Caption = 'SaveFile'
    TabOrder = 6
    OnClick = SaveFileClick
  end
  object GetText2: TButton
    Left = 624
    Top = 104
    Width = 75
    Height = 25
    Caption = 'GetText2'
    TabOrder = 7
    OnClick = GetText2Click
  end
end
