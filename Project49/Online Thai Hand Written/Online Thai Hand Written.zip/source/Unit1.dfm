object Form1: TForm1
  Left = 309
  Top = 124
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Online Thai Handwriting Character Recognition CE'
  ClientHeight = 553
  ClientWidth = 741
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnMouseDown = FormMouseDown
  OnMouseMove = FormMouseMove
  OnMouseUp = FormMouseUp
  PixelsPerInch = 96
  TextHeight = 13
  object Move_x: TLabel
    Left = 384
    Top = 10
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Move_y: TLabel
    Left = 384
    Top = 30
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label1: TLabel
    Left = 320
    Top = 10
    Width = 47
    Height = 13
    Caption = 'Position X'
  end
  object Label2: TLabel
    Left = 320
    Top = 30
    Width = 47
    Height = 13
    Caption = 'Position Y'
  end
  object Status_pen: TLabel
    Left = 384
    Top = 50
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label3: TLabel
    Left = 320
    Top = 50
    Width = 30
    Height = 13
    Caption = 'Status'
  end
  object Label4: TLabel
    Left = 320
    Top = 70
    Width = 32
    Height = 13
    Caption = 'Start X'
  end
  object Label5: TLabel
    Left = 320
    Top = 90
    Width = 32
    Height = 13
    Caption = 'Start Y'
  end
  object ST_x: TLabel
    Left = 384
    Top = 70
    Width = 6
    Height = 13
    Caption = '0'
  end
  object ST_y: TLabel
    Left = 384
    Top = 90
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label6: TLabel
    Left = 320
    Top = 150
    Width = 22
    Height = 13
    Caption = 'Num'
  end
  object Num: TLabel
    Left = 384
    Top = 150
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label7: TLabel
    Left = 320
    Top = 110
    Width = 29
    Height = 13
    Caption = 'End X'
  end
  object Label8: TLabel
    Left = 320
    Top = 130
    Width = 29
    Height = 13
    Caption = 'End Y'
  end
  object En_x: TLabel
    Left = 384
    Top = 110
    Width = 6
    Height = 13
    Caption = '0'
  end
  object En_y: TLabel
    Left = 384
    Top = 130
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label9: TLabel
    Left = 320
    Top = 170
    Width = 42
    Height = 13
    Caption = 'Get Num'
  end
  object Get_Num: TLabel
    Left = 384
    Top = 170
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Code: TLabel
    Left = 320
    Top = 190
    Width = 25
    Height = 13
    Caption = 'Code'
  end
  object Label10: TLabel
    Left = 424
    Top = 130
    Width = 27
    Height = 13
    Caption = 'Min X'
  end
  object Label11: TLabel
    Left = 424
    Top = 150
    Width = 27
    Height = 13
    Caption = 'Min Y'
  end
  object Label12: TLabel
    Left = 424
    Top = 170
    Width = 30
    Height = 13
    Caption = 'Max X'
  end
  object Label13: TLabel
    Left = 424
    Top = 190
    Width = 30
    Height = 13
    Caption = 'Max Y'
  end
  object Label14: TLabel
    Left = 384
    Top = 210
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Hei_Type: TLabel
    Left = 320
    Top = 210
    Width = 46
    Height = 13
    Caption = 'Hei_Type'
  end
  object Label15: TLabel
    Left = 424
    Top = 10
    Width = 34
    Height = 13
    Caption = 'Head 1'
  end
  object Label16: TLabel
    Left = 424
    Top = 30
    Width = 35
    Height = 13
    Caption = 'Head 2'
  end
  object Label17: TLabel
    Left = 424
    Top = 50
    Width = 35
    Height = 13
    Caption = 'Head 3'
  end
  object Label18: TLabel
    Left = 424
    Top = 70
    Width = 35
    Height = 13
    Caption = 'Head 4'
  end
  object Head_1: TLabel
    Left = 480
    Top = 10
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Label19: TLabel
    Left = 424
    Top = 90
    Width = 35
    Height = 13
    Caption = 'Head 5'
  end
  object Label20: TLabel
    Left = 424
    Top = 110
    Width = 35
    Height = 13
    Caption = 'Head 6'
  end
  object Head_2: TLabel
    Left = 480
    Top = 30
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Head_3: TLabel
    Left = 480
    Top = 50
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Head_4: TLabel
    Left = 480
    Top = 70
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Head_5: TLabel
    Left = 480
    Top = 90
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Head_6: TLabel
    Left = 480
    Top = 110
    Width = 18
    Height = 13
    Caption = 'Null'
  end
  object Wid_type: TLabel
    Left = 320
    Top = 230
    Width = 49
    Height = 13
    Caption = 'Wid_Type'
  end
  object Label21: TLabel
    Left = 384
    Top = 230
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label22: TLabel
    Left = 424
    Top = 210
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Label23: TLabel
    Left = 424
    Top = 230
    Width = 6
    Height = 13
    Caption = '0'
  end
  object Bevel1: TBevel
    Left = 310
    Top = 3
    Width = 249
    Height = 254
  end
  object Bevel2: TBevel
    Left = 152
    Top = 212
    Width = 150
    Height = 45
  end
  object Bevel3: TBevel
    Left = 584
    Top = 3
    Width = 153
    Height = 254
  end
  object Button1: TButton
    Left = 592
    Top = 224
    Width = 140
    Height = 25
    Caption = 'Set Data'
    TabOrder = 0
    OnClick = Button1Click
  end
  object StringGrid1: TStringGrid
    Left = 0
    Top = 296
    Width = 737
    Height = 249
    ColCount = 14
    DefaultColWidth = 50
    RowCount = 500
    TabOrder = 1
    Visible = False
  end
  object Button2: TButton
    Left = 592
    Top = 112
    Width = 140
    Height = 25
    Caption = 'Cursor_Point'
    TabOrder = 2
    Visible = False
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 592
    Top = 8
    Width = 140
    Height = 25
    Caption = 'Process'
    TabOrder = 3
    Visible = False
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 592
    Top = 136
    Width = 140
    Height = 25
    Caption = 'Get Text'
    TabOrder = 4
    Visible = False
    OnClick = Button4Click
  end
  object Memo1: TMemo
    Left = 152
    Top = 0
    Width = 150
    Height = 210
    Font.Charset = THAI_CHARSET
    Font.Color = clWindowText
    Font.Height = -96
    Font.Name = 'Angsana New'
    Font.Style = []
    Lines.Strings = (
      'Me'
      'mo1')
    ParentFont = False
    TabOrder = 5
  end
  object Panel1: TPanel
    Left = 0
    Top = 264
    Width = 737
    Height = 9
    Color = clHighlight
    TabOrder = 6
  end
  object Button5: TButton
    Left = 592
    Top = 160
    Width = 140
    Height = 25
    Caption = 'Show'
    TabOrder = 7
    OnClick = Button5Click
  end
  object Panel2: TPanel
    Left = 568
    Top = 0
    Width = 9
    Height = 265
    Caption = 'Panel2'
    Color = clHighlight
    TabOrder = 8
  end
  object Button6: TButton
    Left = 592
    Top = 32
    Width = 140
    Height = 25
    Caption = 'Level 2'
    TabOrder = 9
    Visible = False
    OnClick = Button6Click
  end
  object Button7: TButton
    Left = 592
    Top = 56
    Width = 140
    Height = 25
    Caption = 'Level3'
    TabOrder = 10
    Visible = False
    OnClick = Button7Click
  end
  object Button8: TButton
    Left = 592
    Top = 80
    Width = 140
    Height = 25
    Caption = 'Level4'
    TabOrder = 11
    Visible = False
    OnClick = Button8Click
  end
  object R_L: TRadioButton
    Left = 160
    Top = 235
    Width = 113
    Height = 17
    Caption = 'Learning Mode'
    TabOrder = 12
    OnClick = R_LClick
  end
  object R_N: TRadioButton
    Left = 160
    Top = 216
    Width = 113
    Height = 17
    Caption = 'Normal Mode'
    Checked = True
    TabOrder = 13
    TabStop = True
    OnClick = R_NClick
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 440
    Top = 209
  end
  object Timer2: TTimer
    Enabled = False
    Interval = 100
    OnTimer = Timer2Timer
    Left = 472
    Top = 209
  end
  object Timer3: TTimer
    Enabled = False
    Interval = 2000
    OnTimer = Timer3Timer
    Left = 504
    Top = 209
  end
  object Timer5: TTimer
    Interval = 1
    OnTimer = Timer5Timer
    Left = 536
    Top = 209
  end
end
