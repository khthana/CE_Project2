object Form3: TForm3
  Left = 197
  Top = 404
  BorderIcons = []
  BorderStyle = bsSingle
  Caption = 'Learning Box'
  ClientHeight = 133
  ClientWidth = 226
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Bevel1: TBevel
    Left = 64
    Top = 8
    Width = 153
    Height = 97
  end
  object Label1: TLabel
    Left = 8
    Top = 112
    Width = 77
    Height = 13
    Caption = 'In Put Character'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Edit1: TEdit
    Left = 8
    Top = 8
    Width = 49
    Height = 94
    Font.Charset = THAI_CHARSET
    Font.Color = clWindowText
    Font.Height = -64
    Font.Name = 'Angsana New'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    OnKeyPress = Edit1KeyPress
  end
  object Button1: TButton
    Left = 80
    Top = 16
    Width = 121
    Height = 25
    Caption = 'Set text to Base'
    TabOrder = 1
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 80
    Top = 40
    Width = 121
    Height = 25
    Caption = 'Clear Text in Box'
    TabOrder = 2
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 80
    Top = 72
    Width = 121
    Height = 25
    Caption = 'Cancel'
    TabOrder = 3
    OnClick = Button3Click
  end
end
