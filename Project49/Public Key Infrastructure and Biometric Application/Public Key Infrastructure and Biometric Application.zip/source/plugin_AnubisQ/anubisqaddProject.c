#include "internal.h"
#include "plugin.h"
#include "notify.h"
#include "util.h"
#include "version.h"
#include "debug.h"
#include "gtkutils.h"
#include "gtkplugin.h"
#include "gtkimhtml.h"
#include "gtkdialogs.h"

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>
#include <scanner.h>
#include <VFinger.h>
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "ldapValue.h"


#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  g_object_set_data_full (G_OBJECT (component), name, \
  gtk_widget_ref (widget), (GDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  g_object_set_data (G_OBJECT (component), name, widget)

GaimPlugin *plugin_handle = NULL;
GtkWidget *anubisq_window = NULL;
GtkWidget *anubisq_verify = NULL;
GtkWidget *anubisq_delete = NULL;
GtkWidget *anubisq_signin = NULL;
GtkWidget *password_window = NULL;

char *account_name = NULL;
const char *fingerprint_status = NULL;
int fingerprint_total = NULL;
int fingerprint_result = 0;

char* filename=NULL; //pwd rotected

char *currently_selected_name = NULL;
char *currently_selected_status = NULL;

// Declare function 
static void show_add_window();
void *show_signin_window();
static void show_delete_window();
void scan_finger_cb(GtkWidget *widget, gpointer data);
void *verify_finger_cb();
static void delete_finger();
static void get_pkcs12_file();
void popup_error();
void enter_master_password();
void extract_cert_and_key_from_pkcs12(GtkWidget *widget,GtkWidget *entry );
void cancel_password_window();

// LDAP section
static void free_mods( LDAPMod **mods );
int ldap_get_from_server(char *email_name,int mode);
#define	NMODS	4

// Thread function
void *thread_verify_finger( void *ptr );
void *thread_show_window( void *ptr );

// convert function
#define CHEX        "\\x%02x"
#define BYTESLINE   256
#define INSZ    65536
#define FMT     "%02hhx"
#ifndef WIN32
    #define strnicmp    strncasecmp
#endif

// BASE 64 functione
static void base64_init(void);

static int base64_initialized = 0;
#define BASE64_VALUE_SZ 256
#define BASE64_RESULT_SZ 8192
int base64_value[BASE64_VALUE_SZ];
const char base64_code[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";


// ------------------- Window Destroyer Function ------------------- 
static void window_destroy_cb(GtkWidget *widget, gpointer data)
{
     anubisq_window = NULL;
}

static void verify_destroy_cb(GtkWidget *widget, gpointer data)
{
     anubisq_verify = NULL;
}

static void delete_destroy_cb(GtkWidget *widget, gpointer data)
{
     anubisq_delete = NULL;
}

static void signin_destroy_cb(GtkWidget *widget, gpointer data)
{
     anubisq_signin = NULL;
}
// ------------------ End Window Destroyer Function ------------------------------- 

// ------------ Convert byte into hex string format and vice versa ----------------
void std_err(void) {
    perror("\nError");
    exit(1);
}

static void byte2hex(char* inputfile,char* outputfile) {

    FILE            *fd    = stdin,
                    *fdo   = stdout;
    int             i,
                    len,
                    bs     = 0,
                    line   = BYTESLINE;
    unsigned char   *buff,
                    *p;
    char            *hexf  = CHEX,
                    *ifile,
                    *ofile = NULL;


    setbuf(stdout, NULL);

   
    ofile = outputfile;
    line = 256; 

    ifile = inputfile;
    if(strcmp(ifile, "-")) {
        fprintf(stderr, "- open input file  %s\n", ifile);
        fd = fopen(ifile, "rb");
        if(!fd) std_err();
    }

    if(ofile) {
        fprintf(stderr, "- open output file %s\n", ofile);
        fdo = fopen(ofile, "wb");
        if(!fdo) std_err();
    }

    buff = malloc(line);
    if(!buff) std_err();

    while((len = fread(buff, 1, line, fd))) {
        if(hexf == CHEX) fputc('\"', fdo);

        for(p = buff, i = 0; i < len; i++, p++) {
            fprintf(fdo, hexf, *p);
        }

        if(hexf == CHEX) fputc('\"', fdo);

        if(bs && (len == line)) fputs(" \\", fdo);
        fputc('\n', fdo);
    }

    if(fd != stdin) fclose(fd);
    if(fdo != stdout) fclose(fdo);
    free(buff);
    
}

static void hex2byte(char* inputfile,char* outputfile) {
    struct stat xstat;
    FILE            *fd    = stdin,
                    *fdo   = stdout;
    unsigned int    len    = INSZ;
    int             i,
                    tmp,
                    chr,
                    verify_len;
    unsigned char   *buff,
                    *in,
                    *out;
    char            *verify,
                    *format,
                    *fmt   = FMT,
                    *ifile,
                    *ofile = NULL;


    setbuf(stdout, NULL);

    ofile = outputfile;
  
    ifile = inputfile;
    if(strcmp(ifile, "-")) {
        fprintf(stderr, "- open input file  %s\n", ifile);
        fd = fopen(ifile, "rb");
        if(!fd) std_err();
        fstat(fileno(fd), &xstat);
        len = xstat.st_size;
    }

    if(ofile) {
        fprintf(stderr, "- open output file %s\n", ofile);
        fdo = fopen(ofile, "wb");
        if(!fdo) std_err();
    }

    buff = malloc(len + 1);
    if(!buff) std_err();

    tmp = snprintf(buff, len, fmt, 0xff);
    if((tmp <= 0) || (tmp > len)) tmp = 32; // not very important
    verify = malloc(tmp + 1);
    if(!verify) std_err();

    format = malloc(strlen(fmt) + 3);
    if(!format) std_err();
    sprintf(format, "%s%%n", fmt);

    len = fread(buff, 1, len, fd);
    fprintf(stderr, "- input size:      %u   (0x%08x)\n", len, len);
    buff[len] = 0;

    in = out = buff;
    while(len > 0) {
        if(sscanf(in, format, &chr, &tmp) > 0) {
            verify_len = sprintf(verify, fmt, chr & 0xff);
            if(!strnicmp(verify, in, verify_len)) {
                len -= tmp;
                in += tmp;
                *out++ = chr;
                continue;
            }
        }
        len--;
        in++;
    }

    len = out - buff;
    fwrite(buff, len, 1, fdo);

    if(fdo == stdout) fputc('\n', stdout);
    fprintf(stderr, "- output size:     %u   (0x%08x)\n", len, len);

    if(fd != stdin) fclose(fd);
    if(fdo != stdout) fclose(fdo);
    free(buff);
    free(format);
    free(verify);
}

static void base64_init(void)
{
    int i;

    for (i = 0; i < BASE64_VALUE_SZ; i++)
	base64_value[i] = -1;

    for (i = 0; i < 64; i++)
	base64_value[(int) base64_code[i]] = i;
    base64_value['='] = 0;

    base64_initialized = 1;
}

char * base64_decode(const char *p)
{
    static char result[BASE64_RESULT_SZ];
    int j;
    int c;
    long val;
    if (!p)
	return NULL;
    if (!base64_initialized)
	base64_init();
    val = c = 0;
    for (j = 0; *p && j + 4 < BASE64_RESULT_SZ; p++) {
	unsigned int k = ((unsigned char) *p) % BASE64_VALUE_SZ;
	if (base64_value[k] < 0)
	    continue;
	val <<= 6;
	val += base64_value[k];
	if (++c < 4)
	    continue;
	/* One quantum of four encoding characters/24 bit */
	result[j++] = val >> 16;	/* High 8 bits */
	result[j++] = (val >> 8) & 0xff;	/* Mid 8 bits */
	result[j++] = val & 0xff;	/* Low 8 bits */
	val = c = 0;
    }
    result[j] = 0;
    return result;
}

/* adopted from http://ftp.sunet.se/pub2/gnu/vm/base64-encode.c with adjustments */
const char * base64_encode(const char *decoded_str)
{
    static char result[BASE64_RESULT_SZ];
    int bits = 0;
    int char_count = 0;
    int out_cnt = 0;
    int c;

    if (!decoded_str)
	return decoded_str;

    if (!base64_initialized)
	base64_init();

    while ((c = (unsigned char) *decoded_str++) && out_cnt < sizeof(result) - 5) {
	bits += c;
	char_count++;
	if (char_count == 3) {
	    result[out_cnt++] = base64_code[bits >> 18];
	    result[out_cnt++] = base64_code[(bits >> 12) & 0x3f];
	    result[out_cnt++] = base64_code[(bits >> 6) & 0x3f];
	    result[out_cnt++] = base64_code[bits & 0x3f];
	    bits = 0;
	    char_count = 0;
	} else {
	    bits <<= 8;
	}
    }
    if (char_count != 0) {
	bits <<= 16 - (8 * char_count);
	result[out_cnt++] = base64_code[bits >> 18];
	result[out_cnt++] = base64_code[(bits >> 12) & 0x3f];
	if (char_count == 1) {
	    result[out_cnt++] = '=';
	    result[out_cnt++] = '=';
	} else {
	    result[out_cnt++] = base64_code[(bits >> 6) & 0x3f];
	    result[out_cnt++] = '=';
	}
    }
    result[out_cnt] = '\0';	/* terminate */
    return result;
}
// ----------------------- End converting function --------------------------------

/*----------------------------- BEGIN LDAP SECTION --------------------------------*/

int ldap_add_into_server(char* email_name) {
   
    char	    	*dn;
  
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","**//**//** %s\n",email_name);
    char *imageFromFile1,*imageFromFile2,*imageFromFile3;
    char *fdata1,*fdata2,*fdata3;
    char filename1[256]="/etc/anubisq/";
    char filename2[256]="/etc/anubisq/";
    char filename3[256]="/etc/anubisq/";

    //char file_suffix1[20]="_1_hex";
    char file_suffix1[20]="_1";
    char file_suffix2[20]="_2";
    char file_suffix3[20]="_3";

    strcat(filename1,email_name);
    strcat(filename1,file_suffix1);
    get_file(filename1,&imageFromFile1);

    strcat(filename2,email_name);
    strcat(filename2,file_suffix2);
    get_file(filename2,&imageFromFile2);

    strcat(filename3,email_name);
    strcat(filename3,file_suffix3);
    get_file(filename3,&imageFromFile3);
 
    char dn_name[256] = "cn=";
    char mgr_dn[50] = ",o=AnubisQ";

    // Specify the DN we're adding 
    strcat(dn_name,email_name);
    strcat(dn_name,mgr_dn);
   
    dn = dn_name;
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","+++++ %s\n",dn_name);
 
/* 
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","file 1*:: %s\n",base64_encode(imageFromFile1));
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","file 2*:: %s\n",base64_encode(imageFromFile2));
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","file 3*:: %s\n",base64_encode(imageFromFile3));
*/	
    unsigned char cmd[200000];
    unsigned char tmp[165536];
	
    sprintf(tmp,"ldapadd -ZZ -D \'cn=admin,o=AnubisQ\' -w \"secret\" -x <<EOF\ndn: %s\nobjectClass:    top\nobjectClass:    inetOrgPerson\ncn: %s\nfno: 3\nfingerprintData: %s\n",dn,email_name,base64_encode(imageFromFile1));
    
    strcat(cmd,tmp);
    sprintf(tmp,"fingerprintData: %s\n",base64_encode(imageFromFile2));
    strcat(cmd,tmp);
    sprintf(tmp,"fingerprintData: %s\n",base64_encode(imageFromFile3));
    strcat(cmd,tmp);
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "+++++%s\n",cmd);
    
    system(cmd);
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "End\n");
}

int ldap_get_from_server(char *email_name,int mode) {
    
    LDAP		*ld;
    LDAPMessage		*result, *e;
    char		**vals, *attrs[ 5 ];
    int			i,ldap_vers = LDAP_VERSION3;
    
    char dn_name[256] = "cn=";
    char mgr_dn[50] = ",o=AnubisQ";
    char filename[256]="/etc/anubisq/";
    char tmpfile[5];
    char *imageFromServer[3];

    strcat(filename,email_name);
    strcat(dn_name,email_name);
    strcat(dn_name,mgr_dn);
    
    
    /* get a handle to an LDAP connection */
    if ( (ld = ldap_init( MY_HOST, MY_PORT )) == NULL ) {
	perror( "ldap_init" );
	return( 1 );
    }

    ldap_set_option(ld,LDAP_OPT_PROTOCOL_VERSION,&ldap_vers); // ldap_vers = LDAP_VERSION3
    ldap_start_tls_s(ld, NULL, NULL);

    attrs[0] = "cn";			/* Get canonical name(s) (full name) */
    attrs[1] = "fno";	
    attrs[2] = "fingerprintData";
    attrs[3] = NULL;
    
    if ( ldap_search_s( ld, dn_name, LDAP_SCOPE_BASE,
	    "(objectclass=*)", attrs, 0, &result ) != LDAP_SUCCESS ) {
	ldap_perror( ld, "ldap_search_s" );
	
	return( 1 );
    }
    
    if (( e = ldap_first_entry( ld, result )) != NULL ) {
	if (( vals = ldap_get_values( ld, e, "cn" )) != NULL ) {
	    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Full name:\n" );
	    for ( i = 0; vals[i] != NULL; i++ ) {
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","\t%s\n", vals[i] );
	    }
	    ldap_value_free( vals );
	}
	
	if (( vals = ldap_get_values( ld, e, "fno" )) != NULL ) {
	    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","fingerprint no.:\n" );
	    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","\t%s\n", vals[0] );
	    fingerprint_total = atoi(vals[0]);
	    ldap_value_free( vals );
	} else {
	    fingerprint_total = 0;
	}

	if (mode){
	   if (( vals = ldap_get_values( ld, e, "fingerprintData" )) != NULL ) {
	    		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","fingerprintData::\n" );
	    		for ( i = 0; vals[i] != NULL; i++ ) {
				//gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","\t%s\n", vals[i] );

				sprintf(tmpfile,"_+%d",i+1);
				strcat(filename,tmpfile);
				imageFromServer[i] = vals[i];
				gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","\t%s\n", base64_decode(imageFromServer[i]));
				
				save_file(filename,base64_decode(imageFromServer[i]));
				sprintf(filename,"/etc/anubisq/");
				strcat(filename,email_name);
	    	}
	    ldap_value_free( vals );
	}


	}
    }

    ldap_msgfree( result );
    ldap_unbind( ld );
    return( 0 );
}

int ldap_delete_from_server(char* email_name)
{
    LDAP	    *ld;
    LDAPMessage	*result;
    char	    *dn;
    int		   	rc;
    int			msgid;
    int			finished;
    struct timeval	zerotime;

    zerotime.tv_sec = zerotime.tv_usec = 0L;

    /* Specify the DN we're deleting */
    char dn_name[256] = "cn=";
    char mgr_dn[50] = ",o=AnubisQ";

    // Specify the DN we're adding 
    strcat(dn_name,email_name);
    strcat(dn_name,mgr_dn);
   
    dn = dn_name;
    //dn="cn=vipassu559@hotmail.com,o=AnubisQ";

    /* get a handle to an LDAP connection */
    if ( (ld = ldap_init( MY_HOST, MY_PORT )) == NULL ) {
	perror( "ldap_init" );
	return( 1 );
    }
    /* authenticate to the directory as the Directory Manager */
    if ( ldap_simple_bind_s( ld, MGR_DN, MGR_PW ) != LDAP_SUCCESS ) {
	ldap_perror( ld, "ldap_simple_bind_s" );
	return( 1 );
    }
    /* Initiate the delete operation */
    if (( msgid = ldap_delete( ld, dn )) < 0 ) {
	ldap_perror( ld, "ldap_delete" );
	return( 1 );
    }

    /* Poll for the result */
    finished = 0;
    while ( !finished ) {
	rc = ldap_result( ld, msgid, LDAP_MSG_ONE, &zerotime, &result );
	switch ( rc ) {
	case -1:
	    /* some error occurred */
	    ldap_perror( ld, "ldap_result" );
	    return( 1 );
	case 0:
	    /* Timeout was exceeded.  No entries are ready for retrieval */
	    break;
	default:
	    /* Should be finished here */
	    finished = 1;
	    if (( rc = ldap_result2error( ld, result, 0 )) == LDAP_SUCCESS ) {
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Entry deleted successfully.\n");
	    } else {
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Error while deleting entry: %s\n",
			ldap_err2string( rc ));
	    }
	    ldap_msgfree( result );
	}
    }
    ldap_unbind( ld );
    return 0;
}

static void free_mods( LDAPMod **mods )
{
    int i;

    for ( i = 0; i < NMODS; i++ ) {
	free( mods[ i ] );
    }
    free( mods );
}

/*----------------------------- END LDAP SECTION --------------------------------*/

/*--------------------- Password Protected -----------------------------*/

static void get_pkcs12_file()
{
	GtkWidget *dialog;
	//char *filename;
	dialog = gtk_file_chooser_dialog_new ("Open File",
				      NULL,
				      GTK_FILE_CHOOSER_ACTION_OPEN,
				      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
				      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
				      NULL);

	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
  	{
	    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
	    //g_print(filename);
	    gtk_widget_destroy (dialog);
	    enter_master_password();	    	    
	}
	//gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "gfreefilename");
}

void enter_master_password()
{
  //GtkWidget *window2;
  GtkWidget *fixed2;
  GtkWidget *entry2;
  GtkWidget *label2;
  GtkWidget *button3;
  GtkWidget *button2;

  //if (password_window != NULL) return;

  password_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (password_window), _("Enter Master Password"));

  fixed2 = gtk_fixed_new ();
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (password_window), fixed2);

  entry2 = gtk_entry_new ();
  gtk_widget_show (entry2);
  gtk_fixed_put (GTK_FIXED (fixed2), entry2, 8, 56);
  gtk_widget_set_size_request (entry2, 312, 24);
  gtk_entry_set_visibility (GTK_ENTRY (entry2), FALSE);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry2), 8226);

  label2 = gtk_label_new (_("Enter master password ( same as backup password )"));
  gtk_widget_show (label2);
  gtk_fixed_put (GTK_FIXED (fixed2), label2, 0, 24);
  gtk_widget_set_size_request (label2, 328, 16);

  button3 = gtk_button_new_from_stock ("gtk-cancel");
  gtk_widget_show (button3);
  gtk_fixed_put (GTK_FIXED (fixed2), button3, 240, 96);
  gtk_widget_set_size_request (button3, 79, 32);

  button2 = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (button2);
  gtk_fixed_put (GTK_FIXED (fixed2), button2, 160, 96);
  gtk_widget_set_size_request (button2, 63, 32);

  //event listener
  g_signal_connect(G_OBJECT(button2), "clicked",
	GTK_SIGNAL_FUNC(extract_cert_and_key_from_pkcs12),(gpointer) entry2); 
  g_signal_connect(G_OBJECT(button3), "clicked",
	GTK_SIGNAL_FUNC(cancel_password_window),NULL);  

  gtk_widget_show_all(password_window);
}

void extract_cert_and_key_from_pkcs12(GtkWidget *widget,GtkWidget *entry )
{
	FILE *fp;
	const gchar *entry_text;
	char cmdExtractCert[255],cmdGetEmail[255];
	char cert_file_tmp[255],tmp_file[255],email[50]="email";
	char strTestCert[]="strTestCert",strFromCert[]="strTestCert";
  	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	//extract cert file
	sprintf(cert_file_tmp,"%s/cert/[CE]temp.pem",gaim_user_dir());
	//buddy_cert_file(email,cert_file_tmp,3);
	sprintf(cmdExtractCert,"openssl pkcs12 -in %s -clcerts -nokeys -out %s -passin pass:%s",filename,cert_file_tmp,entry_text);
	system(cmdExtractCert);
	

	//test cert file ->extract complete or not
	if(!(fp = fopen(cert_file_tmp,"r")))
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "could not open cert file\n");
	fgets(strFromCert, sizeof(strFromCert), fp);
	fclose(fp);

	//get email from cert file
	sprintf(tmp_file,"%s/cert/tmp.txt",gaim_user_dir());	
	sprintf(cmdGetEmail,"openssl x509 -noout -email -in %s > %s",cert_file_tmp,tmp_file);
	system(cmdGetEmail);	
	if(!(fp = fopen(tmp_file,"r")))
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "could not open tmp.txt");
	fgets(email, sizeof(email), fp);
	fclose(fp);
	email[strlen(email)-1]='\0';
	account_name = currently_selected_name;

	//gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "email:%s account_name:%s\n",email,account_name);
	//gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "%d %d %d\n",!strcmp(strTestCert,strFromCert),!strcmp(account_name,email),!strcmp(strTestCert,strFromCert) || strcmp(account_name,email));

	if((!strcmp(strTestCert,strFromCert)) || (strcmp(account_name,email))){
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "user choose Certificate File incorrectly or password is incorrect.\n");
		popup_error();
		cancel_password_window();
		return;	
	} else {
		char filename1[256]="";
    		sprintf(filename1,"%s/cert/\[CE\]email.pem",gaim_user_dir());
		remove(filename1);
		cancel_password_window();
		show_add_window();
	}
}

void popup_error()
{
  GtkWidget *window3;
  GtkWidget *fixed3;
  GtkWidget *image1;
  GtkWidget *label6;
  GtkWidget *button4;

  window3 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window3), _("window3"));

  fixed3 = gtk_fixed_new ();
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (window3), fixed3);

  image1 = gtk_image_new_from_stock ("gtk-dialog-error", GTK_ICON_SIZE_DIALOG);
  gtk_widget_show (image1);
  gtk_fixed_put (GTK_FIXED (fixed3), image1, 8, 16);
  gtk_widget_set_size_request (image1, 48, 48);

  label6 = gtk_label_new (_("Certificate File or password is incorrect."));
  gtk_widget_show (label6);
  gtk_fixed_put (GTK_FIXED (fixed3), label6, 72, 16);
  gtk_widget_set_size_request (label6, 256, 48);

  button4 = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (button4);
  gtk_fixed_put (GTK_FIXED (fixed3), button4, 136, 72);
  gtk_widget_set_size_request (button4, 55, 29);

  //event listener
  g_signal_connect_swapped(G_OBJECT(button4), "clicked",
	GTK_SIGNAL_FUNC(gtk_widget_destroy),window3);

  gtk_widget_show_all(window3);	
}

void cancel_password_window()
{
	if (password_window)
		gtk_widget_destroy(password_window);
	password_window = NULL;
}

/*--------------------- End Password Protected -----------------------------*/

// ---------------------- Fingerprint Function ---------------------- 

struct scanner_info* scanner = &scanner_AFS4000;
int do_extraction (unsigned char *image, BYTE* features,int w , int h, int dpi)
{
	DWORD features_size = 0;
	int ret = 0;
	ret = VFExtract (w, h, (BYTE *) image, dpi, features, &features_size, 0);
	if (ret != VFE_OK)
	{
		if (ret == VFE_LOW_QUALITY_IMAGE)
			{
				fprintf (stdout,"WARNING: Image1 is low quality.\n");
			}
			else
			{
				fprintf (stderr,"An error1 occured. Exiting %d.\n",ret);
				exit (1);
			}
		return -1;
	}
	else
	{

		//printf("G: %d, size: %d byetes, minutiae count: %d\n",VFFeatGetG(features),features_size,VFFeatGetMinutiaCount(features));
		return 0;
	}
}
	
int save_file(char *name, unsigned char *image)
{
	int ret = 0;
	FILE *file = NULL;
	file = fopen (name, "wb");
	if (file == NULL)
	{
		ret = -1;
		return ret;
	}
	int len = 96*96;
	fwrite((BYTE *)image,1,len,file);
	fclose (file);
	return ret;

}

int save_file_extra(char *name, unsigned char *image)
{
	int ret = 0;
	FILE *file = NULL;
	file = fopen (name, "wb");
	if (file == NULL)
	{
		ret = -1;
		return ret;
	}
	fputs(image,file);
	fclose (file);
	return ret;

}

int get_file(char *name,char **image)
{
	FILE *file = NULL;
	char *buffer;
	long Lsize;
	file = fopen(name,"rb");
	
	if(file==NULL)
		return 1;

	fseek(file,0,SEEK_END);
	Lsize = ftell(file);
	//printf("Lsize = %d\n",Lsize);
	rewind(file);	
	buffer = (char*)malloc(Lsize);
	if(buffer == NULL)
		exit(2);	
	fread(buffer,1,Lsize,file);
	*image = buffer;
	fclose(file);
	return 0;
}

int check_file_exist(char *name){
	FILE *file = NULL;
	if((file = fopen (name, "r"))== NULL) 
		return -1;

	return 0;
}
	
static void find_account_name_cb(GaimConnection *gc)
{
	account_name = gaim_account_get_username(gaim_connection_get_account(gc));
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ-X", "%s\n",account_name);
}

static void signing_in_cb(GaimConnection *gc)
{
	char in_filename[256]="/etc/anubisq/retrieve_from_ldap.txt";
	char out_filename[256]="/etc/anubisq/";
	char file_suffix[5];
	find_account_name_cb(gc);
		
	 
	pthread_t showing_thread,ui_thread;
	int res;
	void *thread_result,*thread_result2;

	if (gaim_prefs_get_bool("/plugins/gtk/anubisq/using_fingerprint")){	
		res = pthread_create(&ui_thread,NULL,show_signin_window,NULL);
		pthread_join(ui_thread,&thread_result);
		
		//show_signin_window();

		ldap_get_from_server(account_name,1);
		
		//sprintf(file_suffix,"_1");
		//strcat(out_filename,account_name);
		//strcat(out_filename,file_suffix);

		//hex2byte(in_filename,out_filename);
		
		res = pthread_create(&showing_thread,NULL,verify_finger_cb,NULL);
		pthread_join(showing_thread,&thread_result2);

		//verify_finger_cb();
		if(!fingerprint_result){
			gaim_connection_destroy(gc);
		} else {
			gaim_account_connect(gaim_connection_get_account(gc));
			fingerprint_result=0;
		}
		
		//delete_finger();

	} else {
		;;
	}

}

static void acc_signing_in_cb(GaimAccount *account)
{
    account_name = gaim_account_get_username(account);
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "***********%s from account-connecting. *********\n", account_name);
    
}

static void modifying_authorization_check_cb(){
	account_name = currently_selected_name;
	show_signin_window();
	ldap_get_from_server(account_name,1);
	verify_finger_cb();
	if (fingerprint_result){
		delete_finger();
		show_add_window();
	}
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "Modifying...Done\n");
}

static void deleting_authorization_check_cb(){
	account_name = currently_selected_name;
	show_signin_window();
	ldap_get_from_server(account_name,1);
	verify_finger_cb();
	if (fingerprint_result){
		show_delete_window();
	}
    gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "Deleting...Done\n");
}

static void find_fingerprint_file(const char* name){
	/*
	char tmpfile[25];
	char filename[256]="/etc/anubisq/";
	char tmpfilename[256];
	int c=1,status,total=0;
        gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "passed in name is %s\n",name);
	strcat(filename,name);
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "filename is %s\n",filename);
	strcpy(tmpfilename,filename);

	while (c<4){
	  sprintf(tmpfile,"_%d",c++);
	  strcat(filename,tmpfile);
	  if ((status=check_file_exist(filename))!=-1)
		total = total+1;
	  gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "filename in while loop is %s\n",filename);
	  strcpy(filename,tmpfilename);
	}
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "total count is %d\n",total);
        fingerprint_total = total;
	if (total==3)
		fingerprint_status = "Yes";
	else 
		fingerprint_status = "No";
	
	*/

	// call ldap_get_from_server with mode 0 to specify not to retrieve fingerprintData
	ldap_get_from_server(name,0);
    	if (fingerprint_total==3)
		fingerprint_status = "Yes";
	else 
		fingerprint_status = "No";
	
}

void scan_finger_control_cb(GtkWidget *widget, gpointer data)
{
	scan_finger_cb(widget,data);
	ldap_add_into_server(currently_selected_name);
	//delete_finger();
}

void scan_finger_cb(GtkWidget *widget, gpointer data)
{

	// declare variable for GTK+ TextView
	gchar *msg[15];
	msg[7] = "Connecting to scanner...";
  	msg[0] = "Cannot initialize scanner!\nPlease try again\n";
	msg[1] = "[ OK ]\nPlease scan your finger...\n";
  	msg[2] = "Received 1 of 3\n";
	msg[3] = "Received 2 of 3\n";
	msg[4] = "Received 3 of 3\n";
	msg[5] = "Scan completed\n";
	msg[6] = "Sorry, The fingerprint's quality is not suitable.\nPlease scan your finger again!!\n";

  	gtk_text_buffer_set_text (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data)), _(msg[7]), -1);
  	
	BYTE featuresFromScanner[VF_MAX_FEATURES_SIZE];
	BYTE gen_features [VF_MAX_FEATURES_SIZE];
	static BYTE features [VF_GENERALIZE_COUNT] [VF_MAX_FEATURES_SIZE];
	const BYTE *features_p [VF_GENERALIZE_COUNT] = {features[0], features[1], features[2]};
	
	DWORD features_size = 0;
	int result = 1;
	int c=1, ret = 0;
	result = VFInitialize();
	
	if (result != VFE_OK){
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","VFInitialize error");
		gtk_text_buffer_set_text (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data)), _(msg[0]), -1);
		return 1;
	}

	sleep(1);
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Please scan your finger \n");
	gtk_text_buffer_insert_at_cursor(gtk_text_view_get_buffer (GTK_TEXT_VIEW (data)),_(msg[1]), -1);
	
	while(c<4)
	{		
		// initial value 
		int i = scanner -> init();
		int dpi = scanner -> dpi;
		char *name = scanner -> name;
		char *imageFromScanner;
		int w1,h1;
		char tmpfile[5];
		char tmpfile2[5];
		char filename[256]="/etc/anubisq/";
		char filename2[256]="/etc/anubisq/";

		do {
			imageFromScanner = scanner -> read(&w1, &h1);
					
		} while(imageFromScanner == NULL);
		
		// save image file and the filename is /etc/anubisq/AFData
		strcat(filename,currently_selected_name);
		strcat(filename2,currently_selected_name);
		sprintf(tmpfile,"_%d",c);
		sprintf(tmpfile2,"_hex");
		strcat(filename,tmpfile);
		strcat(filename2,tmpfile);
		strcat(filename2,tmpfile2);
		
		save_file(filename,imageFromScanner);
		//byte2hex(filename,filename2);

		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "Got Image %d from 3\n",c);
		gtk_text_buffer_insert_at_cursor(gtk_text_view_get_buffer (GTK_TEXT_VIEW (data)),_(msg[c+1]), -1);

		// get image from file and some detail 
		get_file(filename,&imageFromScanner);
		ret = do_extraction (imageFromScanner, features[c-1],w1 ,h1,dpi);
		free(imageFromScanner);
				
		if (c == VF_GENERALIZE_COUNT){
			features_size = 0;
			result = VFGeneralize (VF_GENERALIZE_COUNT, features_p, gen_features, &features_size, 0);
					
			if(result<0){
				gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Sorry, The fingerprint's quality is not suitable.\nPlease scan your finger again!!\n");
				sleep(2);
				c=0;
			} else {
				gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Done.\n");
			}
		}
		
		if( ret == 0){
			c++;
		}
		
		// close scanner 
		scanner -> close();	
				
	}
	VFFinalize();
	//ldap_add_into_server(currently_selected_name);
	gtk_text_buffer_insert_at_cursor(gtk_text_view_get_buffer (GTK_TEXT_VIEW (data)),_(msg[5]), -1);
	
}

void *verify_finger_cb()
{
	//gtk_entry_set_text (GTK_ENTRY (data), "Processing...");
	
	int ret;
	int i = scanner -> init();
	int dpi = scanner -> dpi;
	int w1,h1;
	int result = 0;		
	char *name = scanner -> name;
	char *imageFromFile , *imageFromScanner;
	char filename1[256]="";
	char filename2[256]="";
	char filename3[256]="";
	
	BYTE featuresFromFile[VF_MAX_FEATURES_SIZE];
	static BYTE featuresFromFiles[VF_GENERALIZE_COUNT] [VF_MAX_FEATURES_SIZE];
	BYTE featuresFromScanner[VF_MAX_FEATURES_SIZE];
	const BYTE *feats[VF_GENERALIZE_COUNT] = {featuresFromFiles[0],featuresFromFiles[1],featuresFromFiles[2]};
	
	VFMatchDetails md;
	md.Size = sizeof(md);
	
	strcat(filename1,"/etc/anubisq/");
	strcat(filename1,account_name);
	strcat(filename1,"_1");
	strcat(filename2,"/etc/anubisq/");
	strcat(filename2,account_name);
	strcat(filename2,"_2");
	strcat(filename3,"/etc/anubisq/");
	strcat(filename3,account_name);
	strcat(filename3,"_3");
	
	// initialize and set value for Verifinger Linux SDK  
	ret = VFInitialize();
	if (ret != VFE_OK){
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","VFInitialize error");
		return;
	}
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","... Step 1 : VFInitialize OK ...\n");
	
	int rotation = 180;
	ret = VFSetParameter(VFP_MAXIMAL_ROTATION, (INT)rotation, NULL);
	if (ret != VFE_OK){
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","VFSetParameter error");
		return;
	}
	
	if(get_file(filename1,&imageFromFile)==0)
	{
		do_extraction (imageFromFile, featuresFromFiles[0], 96, 96, 250);
		free(imageFromFile);
	}
	if(get_file(filename2,&imageFromFile)==0)
	{
		do_extraction (imageFromFile, featuresFromFiles[1], 96, 96, 250);
		free(imageFromFile);
	}
	
	if(get_file(filename3,&imageFromFile)==0)
	{
		do_extraction (imageFromFile, featuresFromFiles[2], 96, 96, 250);
		free(imageFromFile);
	}
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","... Step 2 : Get File OK ...\n");
	
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Please scan your finger \n");

	do
	{
		imageFromScanner = scanner -> read(&w1, &h1);
	} while (imageFromScanner == NULL);
	
	do_extraction (imageFromScanner, featuresFromScanner, w1, h1, dpi);

	scanner -> close();
	
	// Generalization 
	DWORD size;
	size = 0;
	result = VFGeneralize (VF_GENERALIZE_COUNT,feats, featuresFromFile, &size,0);

	if(result<0)
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Generalization failed: %d\n",result);
	else
		gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Generalization succeeded: %d\n",result);

	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "... Step 3 : Generalization Done ...\n");

	// Verification of image between file and scanner 
	result = VFVerify(featuresFromFile, featuresFromScanner, &md, 0);
	switch (result)
	{
		case VFE_OK:
			gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Fingerprint matched \n");
			//gtk_entry_set_text (GTK_ENTRY (data), "Matched");
			fingerprint_result = 1;	
			VFFinalize();
			break;
		case VFE_FAILED:
			gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","Fingerprint mismatched \n");
			//gtk_entry_set_text (GTK_ENTRY (data), "Mismatched");
			fingerprint_result = 0;
			VFFinalize();
			break;
		default:
			VFFinalize();
			break;		
	}
	VFFinalize();
    //pthread_exit("Showing successes");
}

 //  ------------------ End Fingerprint Part ------------------ 

static void delete_finger_cb(GtkWidget *widget,gpointer data)
{
	char filename1[256]="";
	char filename2[256]="";
	char filename3[256]="";

    	strcat(filename1,"/etc/anubisq/");
	strcat(filename1,currently_selected_name);
	strcat(filename1,"_1");
	strcat(filename2,"/etc/anubisq/");
	strcat(filename2,currently_selected_name);
	strcat(filename2,"_2");
	strcat(filename3,"/etc/anubisq/");
	strcat(filename3,currently_selected_name);
	strcat(filename3,"_3");
	//execlp("rm","rm",filename1,filename2,filename3,0);
	remove(filename1);
	remove(filename2);
	remove(filename3);
	ldap_delete_from_server(currently_selected_name);

	gtk_entry_set_text (GTK_ENTRY (data), "Done");
	
}

static void delete_finger()
{
	char filename1[256]="";
	char filename2[256]="";
	char filename3[256]="";

    	strcat(filename1,"/etc/anubisq/");
	strcat(filename1,currently_selected_name);
	strcat(filename1,"_1");
	strcat(filename2,"/etc/anubisq/");
	strcat(filename2,currently_selected_name);
	strcat(filename2,"_2");
	strcat(filename3,"/etc/anubisq/");
	strcat(filename3,currently_selected_name);
	strcat(filename3,"_3");
	//execlp("rm","rm",filename1,filename2,filename3,0);
	remove(filename1);
	remove(filename2);
	remove(filename3);
	ldap_delete_from_server(currently_selected_name);
}

static void show_add_window(){
  
  GtkWidget *fixed1;
  GtkWidget *textview1;
  GtkWidget *scan_btn;
  GtkWidget *alignment1;
  GtkWidget *hbox1;
  GtkWidget *image1;
  GtkWidget *label1;
  GtkWidget *close_btn;
  GtkWidget *hseparator3;
  GtkWidget *label7;
  GtkWidget *txtShowUserName;
  GtkWidget *hseparator4;
  GtkTooltips *tooltips;

  if (anubisq_window != NULL) {
       gtk_window_present(GTK_WINDOW(anubisq_window));
       return;
  }

  tooltips = gtk_tooltips_new ();

  anubisq_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (anubisq_window, "anubisq_window");
  gtk_widget_set_size_request (anubisq_window, 288, 311);
  gtk_window_set_title (GTK_WINDOW (anubisq_window), _("[ AnubisQ ] : Add User"));
  gtk_window_set_modal (GTK_WINDOW (anubisq_window), TRUE);
  //gtk_window_set_position (GTK_WINDOW (anubisq_window), GTK_WIN_POS_CENTER_ON_PARENT);

  fixed1 = gtk_fixed_new ();
  gtk_widget_set_name (fixed1, "fixed1");
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (anubisq_window), fixed1);
  gtk_widget_set_size_request (fixed1, 280, 304);

  textview1 = gtk_text_view_new ();
  gtk_widget_set_name (textview1, "textview1");
  gtk_widget_show (textview1);
  gtk_fixed_put (GTK_FIXED (fixed1), textview1, 8, 96);
  gtk_widget_set_size_request (textview1, 272, 208);
  gtk_container_set_border_width (GTK_CONTAINER (textview1), 1);
  gtk_text_view_set_editable (GTK_TEXT_VIEW (textview1), FALSE);
  gtk_text_view_set_accepts_tab (GTK_TEXT_VIEW (textview1), FALSE);
  gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW (textview1), GTK_WRAP_WORD);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview1), FALSE);
  gtk_text_view_set_pixels_above_lines (GTK_TEXT_VIEW (textview1), 4);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (textview1), 4);
  gtk_text_buffer_set_text (gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1)), _("This will show an output of scanning process..."), -1);

  scan_btn = gtk_button_new ();
  gtk_widget_set_name (scan_btn, "scan_btn");
  gtk_widget_show (scan_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), scan_btn, 8, 8);
  gtk_widget_set_size_request (scan_btn, 184, 32);
  gtk_tooltips_set_tip (tooltips, scan_btn, _("Press this button when you're ready \nto scan your fingerprint."), NULL);

  alignment1 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment1, "alignment1");
  gtk_widget_show (alignment1);
  gtk_container_add (GTK_CONTAINER (scan_btn), alignment1);

  hbox1 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox1, "hbox1");
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (alignment1), hbox1);

  image1 = gtk_image_new_from_stock ("gtk-index", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image1, "image1");
  gtk_widget_show (image1);
  gtk_box_pack_start (GTK_BOX (hbox1), image1, FALSE, FALSE, 0);

  label1 = gtk_label_new_with_mnemonic (_("Scan Fingerprint Now !"));
  gtk_widget_set_name (label1, "label1");
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (hbox1), label1, FALSE, FALSE, 0);

  close_btn = gtk_button_new_from_stock ("gtk-close");
  gtk_widget_set_name (close_btn, "close_btn");
  gtk_widget_show (close_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), close_btn, 200, 8);
  gtk_widget_set_size_request (close_btn, 80, 32);

  hseparator3 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator3, "hseparator3");
  gtk_widget_show (hseparator3);
  gtk_fixed_put (GTK_FIXED (fixed1), hseparator3, 8, 40);
  gtk_widget_set_size_request (hseparator3, 272, 16);

  label7 = gtk_label_new (_("Current User : "));
  gtk_widget_set_name (label7, "label7");
  gtk_widget_show (label7);
  gtk_fixed_put (GTK_FIXED (fixed1), label7, 24, 56);
  gtk_widget_set_size_request (label7, 96, 24);
  gtk_label_set_justify (GTK_LABEL (label7), GTK_JUSTIFY_RIGHT);

  gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","***%s*** \n",currently_selected_name);

  txtShowUserName = gtk_label_new (_(currently_selected_name));
  gtk_widget_set_name (txtShowUserName, "txtShowUserName");
  gtk_widget_show (txtShowUserName);
  gtk_fixed_put (GTK_FIXED (fixed1), txtShowUserName, 112, 56);
  gtk_widget_set_size_request (txtShowUserName, 152, 25);

  hseparator4 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator4, "hseparator4");
  gtk_widget_show (hseparator4);
  gtk_fixed_put (GTK_FIXED (fixed1), hseparator4, 8, 80);
  gtk_widget_set_size_request (hseparator4, 272, 16);

  // Event listener
  g_signal_connect(G_OBJECT(anubisq_window), "destroy", G_CALLBACK(window_destroy_cb), NULL);
  g_signal_connect_swapped(G_OBJECT(close_btn), "clicked", G_CALLBACK(gtk_widget_destroy), anubisq_window);
  gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", " **** %s" ,currently_selected_status);
  //if (currently_selected_status = "No"){	
  	g_signal_connect(G_OBJECT(scan_btn), "clicked", G_CALLBACK(scan_finger_control_cb), textview1);
  //}

  gtk_widget_show_all(anubisq_window);
  
}

static void show_verify_window(){

  GtkWidget *fixed3;
  GtkWidget *verify_btn;
  GtkWidget *alignment2;
  GtkWidget *hbox2;
  GtkWidget *image2;
  GtkWidget *label2;
  GtkWidget *close2_btn;
  GtkWidget *txtShowStatusFinger;
  GtkWidget *hseparator1;
  GtkWidget *hseparator2;
  GtkWidget *label3;
  GtkWidget *txtShowUserName2;
  GtkWidget *label4;
  GtkWidget *txtShowResult;
  GtkWidget *label9;
  GtkTooltips *tooltips;
  
  if (anubisq_verify != NULL) {
       gtk_window_present(GTK_WINDOW(anubisq_verify));
       return;
  }
  
  tooltips = gtk_tooltips_new ();

  anubisq_verify = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (anubisq_verify, "anubisq_verify");
  gtk_widget_set_size_request (anubisq_verify, 288, 152);
  gtk_window_set_title (GTK_WINDOW (anubisq_verify), _("[ AnubisQ ] : Verify User"));
  gtk_window_set_modal (GTK_WINDOW (anubisq_verify), TRUE);
  gtk_window_set_position (GTK_WINDOW (anubisq_verify), GTK_WIN_POS_CENTER_ON_PARENT);

  fixed3 = gtk_fixed_new ();
  gtk_widget_set_name (fixed3, "fixed3");
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (anubisq_verify), fixed3);
  gtk_widget_set_size_request (fixed3, 280, 147);

  verify_btn = gtk_button_new ();
  gtk_widget_set_name (verify_btn, "verify_btn");
  gtk_widget_show (verify_btn);
  gtk_fixed_put (GTK_FIXED (fixed3), verify_btn, 8, 8);
  gtk_widget_set_size_request (verify_btn, 184, 32);
  gtk_tooltips_set_tip (tooltips, verify_btn, _("Press this button if you want to verify your fingerprint's data."), NULL);

  alignment2 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment2, "alignment2");
  gtk_widget_show (alignment2);
  gtk_container_add (GTK_CONTAINER (verify_btn), alignment2);

  hbox2 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox2, "hbox2");
  gtk_widget_show (hbox2);
  gtk_container_add (GTK_CONTAINER (alignment2), hbox2);

  image2 = gtk_image_new_from_stock ("gtk-zoom-100", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image2, "image2");
  gtk_widget_show (image2);
  gtk_box_pack_start (GTK_BOX (hbox2), image2, FALSE, FALSE, 0);

  label2 = gtk_label_new_with_mnemonic (_("Verify Current User"));
  gtk_widget_set_name (label2, "label2");
  gtk_widget_show (label2);
  gtk_box_pack_start (GTK_BOX (hbox2), label2, FALSE, FALSE, 0);

  close2_btn = gtk_button_new_from_stock ("gtk-close");
  gtk_widget_set_name (close2_btn, "close2_btn");
  gtk_widget_show (close2_btn);
  gtk_fixed_put (GTK_FIXED (fixed3), close2_btn, 200, 8);
  gtk_widget_set_size_request (close2_btn, 80, 32);

  txtShowStatusFinger = gtk_label_new (_(fingerprint_status));
  gtk_widget_set_name (txtShowStatusFinger, "txtShowStatusFinger");
  gtk_widget_show (txtShowStatusFinger);
  gtk_fixed_put (GTK_FIXED (fixed3), txtShowStatusFinger, 120, 80);
  gtk_widget_set_size_request (txtShowStatusFinger, 80, 25);
  gtk_misc_set_alignment (GTK_MISC (txtShowStatusFinger), 0, 0.5);


  hseparator1 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator1, "hseparator1");
  gtk_widget_show (hseparator1);
  gtk_fixed_put (GTK_FIXED (fixed3), hseparator1, 8, 104);
  gtk_widget_set_size_request (hseparator1, 272, 16);

  hseparator2 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator2, "hseparator2");
  gtk_widget_show (hseparator2);
  gtk_fixed_put (GTK_FIXED (fixed3), hseparator2, 8, 40);
  gtk_widget_set_size_request (hseparator2, 272, 16);

  label3 = gtk_label_new (_("Current User : "));
  gtk_widget_set_name (label3, "label3");
  gtk_widget_show (label3);
  gtk_fixed_put (GTK_FIXED (fixed3), label3, 24, 56);
  gtk_widget_set_size_request (label3, 96, 24);
  gtk_label_set_justify (GTK_LABEL (label3), GTK_JUSTIFY_RIGHT);

  txtShowUserName2 = gtk_label_new (_(account_name));
  gtk_widget_set_name (txtShowUserName2, "txtShowUserName2");
  gtk_widget_show (txtShowUserName2);
  gtk_fixed_put (GTK_FIXED (fixed3), txtShowUserName2, 120, 56);
  gtk_widget_set_size_request (txtShowUserName2, 152, 25);
  gtk_misc_set_alignment (GTK_MISC (txtShowUserName2), 0, 0.5);

  label4 = gtk_label_new (_("Has Fingerprint :"));
  gtk_widget_set_name (label4, "label4");
  gtk_widget_show (label4);
  gtk_fixed_put (GTK_FIXED (fixed3), label4, 8, 80);
  gtk_widget_set_size_request (label4, 112, 25);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_RIGHT);

  txtShowResult = gtk_entry_new ();
  gtk_widget_set_name (txtShowResult, "txtShowResult");
  gtk_widget_show (txtShowResult);
  gtk_fixed_put (GTK_FIXED (fixed3), txtShowResult, 120, 120);
  gtk_widget_set_size_request (txtShowResult, 160, 27);
  gtk_editable_set_editable (GTK_EDITABLE (txtShowResult), FALSE);
  gtk_entry_set_invisible_char (GTK_ENTRY (txtShowResult), 8226);

  label9 = gtk_label_new (_("Result :"));
  gtk_widget_set_name (label9, "label9");
  gtk_widget_show (label9);
  gtk_fixed_put (GTK_FIXED (fixed3), label9, 56, 120);
  gtk_widget_set_size_request (label9, 64, 25);

  // Event listener
  g_signal_connect(G_OBJECT(anubisq_verify), "destroy", G_CALLBACK(verify_destroy_cb), NULL);
  g_signal_connect_swapped(G_OBJECT(close2_btn), "clicked", G_CALLBACK(gtk_widget_destroy), anubisq_verify);	
  g_signal_connect(G_OBJECT(verify_btn), "clicked", G_CALLBACK(verify_finger_cb), txtShowResult);

  gtk_widget_show_all(anubisq_verify);

}

static void show_delete_window(){

  GtkWidget *fixed4;
  GtkWidget *close3_btn;
  GtkWidget *delete_btn;
  GtkWidget *alignment4;
  GtkWidget *hbox3;
  GtkWidget *image3;
  GtkWidget *label10;
  GtkWidget *hseparator5;
  GtkWidget *label11;
  GtkWidget *txtShowUserName3;
  GtkWidget *label13;
  GtkWidget *txtaShowStatusFinger2;
  GtkWidget *hseparator6;
  GtkWidget *txtShowResult2;
  GtkWidget *label15;
  GtkTooltips *tooltips;
  
  if (anubisq_delete != NULL) {
       gtk_window_present(GTK_WINDOW(anubisq_delete));
       return;
  }
  tooltips = gtk_tooltips_new ();
  
  anubisq_delete = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (anubisq_delete, "anubisq_delete");
  gtk_widget_set_size_request (anubisq_delete, 288, 152);
  gtk_window_set_title (GTK_WINDOW (anubisq_delete), _("[ AnubisQ ] : Delete User"));
  gtk_window_set_modal (GTK_WINDOW (anubisq_delete), TRUE);
  //gtk_window_set_position (GTK_WINDOW (anubisq_delete), GTK_WIN_POS_CENTER_ON_PARENT);

  fixed4 = gtk_fixed_new ();
  gtk_widget_set_name (fixed4, "fixed4");
  gtk_widget_show (fixed4);
  gtk_container_add (GTK_CONTAINER (anubisq_delete), fixed4);
  gtk_widget_set_size_request (fixed4, 280, 147);

  close3_btn = gtk_button_new_from_stock ("gtk-close");
  gtk_widget_set_name (close3_btn, "close3_btn");
  gtk_widget_show (close3_btn);
  gtk_fixed_put (GTK_FIXED (fixed4), close3_btn, 200, 8);
  gtk_widget_set_size_request (close3_btn, 80, 32);

  delete_btn = gtk_button_new ();
  gtk_widget_set_name (delete_btn, "delete_btn");
  gtk_widget_show (delete_btn);
  gtk_fixed_put (GTK_FIXED (fixed4), delete_btn, 8, 8);
  gtk_widget_set_size_request (delete_btn, 184, 32);
  gtk_tooltips_set_tip (tooltips, delete_btn, _("Press this button if you want to delete your fingerprint's data."), NULL);

  alignment4 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment4, "alignment4");
  gtk_widget_show (alignment4);
  gtk_container_add (GTK_CONTAINER (delete_btn), alignment4);

  hbox3 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox3, "hbox3");
  gtk_widget_show (hbox3);
  gtk_container_add (GTK_CONTAINER (alignment4), hbox3);

  image3 = gtk_image_new_from_stock ("gtk-delete", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image3, "image3");
  gtk_widget_show (image3);
  gtk_box_pack_start (GTK_BOX (hbox3), image3, FALSE, FALSE, 0);

  label10 = gtk_label_new_with_mnemonic (_("Delete"));
  gtk_widget_set_name (label10, "label10");
  gtk_widget_show (label10);
  gtk_box_pack_start (GTK_BOX (hbox3), label10, FALSE, FALSE, 0);

  hseparator5 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator5, "hseparator5");
  gtk_widget_show (hseparator5);
  gtk_fixed_put (GTK_FIXED (fixed4), hseparator5, 8, 40);
  gtk_widget_set_size_request (hseparator5, 272, 16);

  label11 = gtk_label_new (_("Current User : "));
  gtk_widget_set_name (label11, "label11");
  gtk_widget_show (label11);
  gtk_fixed_put (GTK_FIXED (fixed4), label11, 24, 56);
  gtk_widget_set_size_request (label11, 96, 24);
  gtk_label_set_justify (GTK_LABEL (label11), GTK_JUSTIFY_RIGHT);

  txtShowUserName3 = gtk_label_new (_(currently_selected_name));
  gtk_widget_set_name (txtShowUserName3, "txtShowUserName3");
  gtk_widget_show (txtShowUserName3);
  gtk_fixed_put (GTK_FIXED (fixed4), txtShowUserName3, 120, 56);
  gtk_widget_set_size_request (txtShowUserName3, 152, 25);
  gtk_misc_set_alignment (GTK_MISC (txtShowUserName3), 0, 0.5);

  label13 = gtk_label_new (_("Has Fingerprint :"));
  gtk_widget_set_name (label13, "label13");
  gtk_widget_show (label13);
  gtk_fixed_put (GTK_FIXED (fixed4), label13, 8, 80);
  gtk_widget_set_size_request (label13, 112, 25);
  gtk_label_set_justify (GTK_LABEL (label13), GTK_JUSTIFY_RIGHT);

  txtaShowStatusFinger2 = gtk_label_new (_(currently_selected_status));
  gtk_widget_set_name (txtaShowStatusFinger2, "txtaShowStatusFinger2");
  gtk_widget_show (txtaShowStatusFinger2);
  gtk_fixed_put (GTK_FIXED (fixed4), txtaShowStatusFinger2, 120, 80);
  gtk_widget_set_size_request (txtaShowStatusFinger2, 80, 25);
  gtk_misc_set_alignment (GTK_MISC (txtaShowStatusFinger2), 0, 0.5);

  hseparator6 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator6, "hseparator6");
  gtk_widget_show (hseparator6);
  gtk_fixed_put (GTK_FIXED (fixed4), hseparator6, 8, 104);
  gtk_widget_set_size_request (hseparator6, 272, 16);

  txtShowResult2 = gtk_entry_new ();
  gtk_widget_set_name (txtShowResult2, "txtShowResult2");
  gtk_widget_show (txtShowResult2);
  gtk_fixed_put (GTK_FIXED (fixed4), txtShowResult2, 120, 120);
  gtk_widget_set_size_request (txtShowResult2, 160, 27);
  gtk_editable_set_editable (GTK_EDITABLE (txtShowResult2), FALSE);
  gtk_entry_set_invisible_char (GTK_ENTRY (txtShowResult2), 8226);

  label15 = gtk_label_new (_("Result :"));
  gtk_widget_set_name (label15, "label15");
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed4), label15, 56, 120);
  gtk_widget_set_size_request (label15, 64, 25);

  // Event listener
  g_signal_connect(G_OBJECT(anubisq_delete), "destroy", G_CALLBACK(delete_destroy_cb), NULL);
  g_signal_connect_swapped(G_OBJECT(close3_btn), "clicked", G_CALLBACK(gtk_widget_destroy), anubisq_delete);	
  g_signal_connect(G_OBJECT(delete_btn), "clicked", G_CALLBACK(delete_finger_cb), txtShowResult2);

  gtk_widget_show_all(anubisq_delete);

}

void* show_signin_window() {

  GtkWidget *fixed5;
  GtkWidget *txtShowResult3;
  GtkWidget *label21;
  GtkWidget *label22;
  GtkWidget *hseparator8;
  
  if (anubisq_signin != NULL) {
       gtk_window_present(GTK_WINDOW(anubisq_signin));
       return;
  }

  anubisq_signin = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (anubisq_signin, "anubisq_signin");
  gtk_window_set_title (GTK_WINDOW (anubisq_signin), _("[ AnubisQ ] : Authorization Required"));
  gtk_widget_set_size_request (anubisq_signin, 345, 71);
  gtk_window_set_position (GTK_WINDOW (anubisq_signin), GTK_WIN_POS_CENTER_ON_PARENT);
  //gtk_window_set_modal (GTK_WINDOW (anubisq_signin), TRUE);
  gtk_window_set_icon_name (GTK_WINDOW (anubisq_signin), "gtk-index");
  gtk_window_set_skip_taskbar_hint (GTK_WINDOW (anubisq_signin), TRUE);
  gtk_window_set_skip_pager_hint (GTK_WINDOW (anubisq_signin), TRUE);
  gtk_window_set_type_hint (GTK_WINDOW (anubisq_signin), GDK_WINDOW_TYPE_HINT_DIALOG);

   fixed5 = gtk_fixed_new ();
  gtk_widget_set_name (fixed5, "fixed5");
  gtk_widget_show (fixed5);
  gtk_container_add (GTK_CONTAINER (anubisq_signin), fixed5);

  txtShowResult3 = gtk_entry_new ();
  gtk_widget_set_name (txtShowResult3, "txtShowResult3");
  gtk_widget_show (txtShowResult3);
  gtk_fixed_put (GTK_FIXED (fixed5), txtShowResult3, 64, 40);
  gtk_widget_set_size_request (txtShowResult3, 160, 27);
  GTK_WIDGET_UNSET_FLAGS (txtShowResult3, GTK_CAN_FOCUS);
  gtk_editable_set_editable (GTK_EDITABLE (txtShowResult3), FALSE);
  gtk_entry_set_invisible_char (GTK_ENTRY (txtShowResult3), 8226);

  label21 = gtk_label_new (_("Please scan your finger..."));
  gtk_widget_set_name (label21, "label21");
  gtk_widget_show (label21);
  gtk_fixed_put (GTK_FIXED (fixed5), label21, 8, 8);
  gtk_widget_set_size_request (label21, 152, 21);

  hseparator8 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator8, "hseparator8");
  gtk_widget_show (hseparator8);
  gtk_fixed_put (GTK_FIXED (fixed5), hseparator8, 8, 24);
  gtk_widget_set_size_request (hseparator8, 330, 16);

  label22 = gtk_label_new (_("Result :"));
  gtk_widget_set_name (label22, "label22");
  gtk_widget_show (label22);
  gtk_fixed_put (GTK_FIXED (fixed5), label22, 0, 40);
  gtk_widget_set_size_request (label22, 64, 25);

  //g_signal_connect(G_OBJECT(anubisq_signin), "show", G_CALLBACK(verify_finger_cb), NULL);
  g_signal_connect(G_OBJECT(anubisq_signin), "destroy", G_CALLBACK(signin_destroy_cb), NULL);
  gtk_widget_show_all(anubisq_signin);
  
}
//------------------------ Preference UI -------------------------

enum
{
  COL_SCREEN_NAME = 0,
  COL_PROTOCOL_NAME,
  COL_HAS_FINGERPRINT,
  COL_NO_OF_FINGERPRINT_DATA,
  NUM_COLS
} ;

static GtkTreeModel *
create_and_fill_model (void)
{
  /*GtkTreeStore  *treestore;
  GtkTreeIter    toplevel, child;

  treestore = gtk_tree_store_new(NUM_COLS,
                                 G_TYPE_STRING,
                                 G_TYPE_STRING,
                                 G_TYPE_STRING);*/
  GtkListStore  *liststore;
  GtkTreeIter    iter;

  liststore = gtk_list_store_new(NUM_COLS,
                                 G_TYPE_STRING,
                                 G_TYPE_STRING,
                                 G_TYPE_STRING,
                                 G_TYPE_UINT);

/*
  // Append a top level row and leave it empty 
  gtk_tree_store_append(treestore, &toplevel, NULL);
  gtk_tree_store_set(treestore, &toplevel,
                     COL_SCREEN_NAME, account_name,
                     COL_HAS_FINGERPRINT, "No",
                     -1);

  // Append a second top level row, and fill it with some data 
  gtk_tree_store_append(treestore, &toplevel, NULL);
  gtk_tree_store_set(treestore, &toplevel,
                     COL_SCREEN_NAME, "yyyy@hotmail.com",
                     COL_HAS_FINGERPRINT, "Yes",
                     COL_NO_OF_FINGERPRINT_DATA,"3 of 3",
                     -1);
*/
    GList * l;
    GaimAccount *account = NULL;
    const char *acc_name,*proto_name; 

    for (l = gaim_accounts_get_all(); l != NULL; l = l->next) {
		account = (GaimAccount *)l->data;
        acc_name = gaim_account_get_username(account);
        proto_name = gaim_account_get_protocol_name(account);
	gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","++++ Current account name is %s\n",acc_name);
	fingerprint_total=0;
        find_fingerprint_file(acc_name);
        gtk_list_store_append(liststore, &iter);
        gtk_list_store_set(liststore, &iter,
                     COL_SCREEN_NAME, acc_name ,
                     COL_PROTOCOL_NAME, proto_name,
                     COL_HAS_FINGERPRINT, fingerprint_status,
                     COL_NO_OF_FINGERPRINT_DATA,fingerprint_total,
                     -1);
	}

  /* Append a child to the second top level row, and fill in some data */
  /*gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,
                     COL_FIRST_NAME, "Janinita",
                     COL_LAST_NAME, "Average",
                     COL_YEAR_BORN, (guint) 1985,
                     -1);
  */
  return GTK_TREE_MODEL(liststore);
}

gboolean view_selection_func (GtkTreeSelection *selection,
                       GtkTreeModel     *model,
                       GtkTreePath      *path,
                       gboolean          path_currently_selected,
                       gpointer          userdata)
  {
    GtkTreeIter iter;
  
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
      char *name,*status;

      gtk_tree_model_get(model, &iter, COL_SCREEN_NAME, &name, -1);
      if (!path_currently_selected)
      {
        currently_selected_name = name;
        //gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","***%s*** \n",currently_selected_name);
      }

      gtk_tree_model_get(model, &iter, COL_HAS_FINGERPRINT, &status, -1);
      if (!path_currently_selected)
      {
        currently_selected_status = status;
        //gaim_debug(GAIM_DEBUG_INFO, "AnubisQ","+++%s+++ \n",currently_selected_status);
      }
    }

    return TRUE; /* allow selection state to change */
}

static GtkWidget *create_view_and_model (void) {
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkWidget           *view;
  GtkTreeModel        *model;
  GtkTreeSelection    *selection;

  view = gtk_tree_view_new();

  /* --- Column #1 --- */

  col = gtk_tree_view_column_new();
  gtk_tree_view_column_set_title(col, "Screen Name");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);
  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  /* connect 'text' property of the cell renderer to
   *  model column that contains the first name */
  gtk_tree_view_column_add_attribute(col, renderer, "text", COL_SCREEN_NAME);

  /* --- Column #2 --- */

  col = gtk_tree_view_column_new();
  gtk_tree_view_column_set_title(col, "Protocol");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);
  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  /* connect 'text' property of the cell renderer to
   *  model column that contains the first name */
  gtk_tree_view_column_add_attribute(col, renderer, "text", COL_PROTOCOL_NAME);

  /* --- Column #3 --- */

  col = gtk_tree_view_column_new();
  gtk_tree_view_column_set_title(col, "Has fingerprint?");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);
  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  /* connect 'text' property of the cell renderer to
   *  model column that contains the last name */
  gtk_tree_view_column_add_attribute(col, renderer, "text", COL_HAS_FINGERPRINT);

  /* set 'weight' property of the cell renderer to bold print */
  g_object_set(renderer,"weight", PANGO_WEIGHT_BOLD,"weight-set",TRUE,NULL);


  /* --- Column #4 --- */

  col = gtk_tree_view_column_new();
  gtk_tree_view_column_set_title(col, "No. of fingerprint data");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);
  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  /* connect a cell data function */
  gtk_tree_view_column_add_attribute(col, renderer, "text", COL_NO_OF_FINGERPRINT_DATA);
  g_object_set(renderer, "foreground", "Red", "foreground-set", TRUE, NULL);


  model = create_and_fill_model();
  gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);

  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(view));
  gtk_tree_selection_set_select_function(selection, view_selection_func, NULL, NULL);

  g_object_unref(model); /* destroy model automatically with view */

  /*gtk_tree_selection_set_mode(gtk_tree_view_get_selection(GTK_TREE_VIEW(view)),
                              GTK_SELECTION_BROWSE);*/
  
  return view;
}

// ------------------ GTK and Callback of Gaim's preference section ----------------------
void check_button_cb (GtkWidget *widget, gpointer data)
{
    if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (widget))) 
    {
        //gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "Checked\n");
        gaim_prefs_set_bool("/plugins/gtk/anubisq/using_fingerprint", TRUE);
    } else {
        //gaim_debug(GAIM_DEBUG_INFO, "AnubisQ", "Unchecked\n");
        gaim_prefs_set_bool("/plugins/gtk/anubisq/using_fingerprint", FALSE);
    }
}

static GtkWidget* get_config_frame (GaimPlugin *plugin)
{

  GtkWidget *window1;
  GtkWidget *fixed1;
  GtkWidget *add_btn;
  GtkWidget *alignment3;
  GtkWidget *hbox3;
  GtkWidget *image3;
  GtkWidget *label3;
  GtkWidget *mod_btn;
  GtkWidget *alignment1;
  GtkWidget *hbox1;
  GtkWidget *image1;
  GtkWidget *label1;
  GtkWidget *del_btn;
  GtkWidget *alignment2;
  GtkWidget *hbox2;
  GtkWidget *image2;
  GtkWidget *label2;
  GtkWidget *hseparator1;
  GtkWidget *scrolledwindow1;
  GtkWidget *view1;
  GtkWidget *label5;
  GtkWidget *label4;
  GtkWidget *usefinger_check_btn;
  GtkWidget *alignment4;
  GtkWidget *hbox4;
  GtkWidget *image4;
  GtkWidget *label6;
  GtkTooltips *tooltips;

  tooltips = gtk_tooltips_new ();

  window1 = gtk_fixed_new();


  fixed1 = gtk_fixed_new ();
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (window1), fixed1);

  add_btn = gtk_button_new ();
  gtk_widget_show (add_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), add_btn, 104, 344);
  gtk_widget_set_size_request (add_btn, 88, 32);
  gtk_tooltips_set_tip (tooltips, add_btn, _("Add a new user's fingerprint data"), NULL);

  alignment3 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment3);
  gtk_container_add (GTK_CONTAINER (add_btn), alignment3);

  hbox3 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox3);
  gtk_container_add (GTK_CONTAINER (alignment3), hbox3);

  image3 = gtk_image_new_from_stock ("gtk-add", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image3);
  gtk_box_pack_start (GTK_BOX (hbox3), image3, FALSE, FALSE, 0);

  label3 = gtk_label_new_with_mnemonic (_("Add"));
  gtk_widget_show (label3);
  gtk_box_pack_start (GTK_BOX (hbox3), label3, FALSE, FALSE, 0);

  mod_btn = gtk_button_new ();
  gtk_widget_show (mod_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), mod_btn, 200, 344);
  gtk_widget_set_size_request (mod_btn, 88, 32);
  gtk_tooltips_set_tip (tooltips, mod_btn, _("Modify a current selected user's fingerprint data."), NULL);

  alignment1 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment1);
  gtk_container_add (GTK_CONTAINER (mod_btn), alignment1);

  hbox1 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (alignment1), hbox1);

  image1 = gtk_image_new_from_stock ("gtk-edit", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image1);
  gtk_box_pack_start (GTK_BOX (hbox1), image1, FALSE, FALSE, 0);

  label1 = gtk_label_new_with_mnemonic (_("Modify"));
  gtk_widget_show (label1);
  gtk_box_pack_start (GTK_BOX (hbox1), label1, FALSE, FALSE, 0);

  del_btn = gtk_button_new ();
  gtk_widget_show (del_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), del_btn, 296, 344);
  gtk_widget_set_size_request (del_btn, 88, 32);
  gtk_tooltips_set_tip (tooltips, del_btn, _("Delete the current selected user's fingerprint data.\nYou must have a permission to do this action."), NULL);

  alignment2 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment2);
  gtk_container_add (GTK_CONTAINER (del_btn), alignment2);

  hbox2 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox2);
  gtk_container_add (GTK_CONTAINER (alignment2), hbox2);

  image2 = gtk_image_new_from_stock ("gtk-delete", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image2);
  gtk_box_pack_start (GTK_BOX (hbox2), image2, FALSE, FALSE, 0);

  label2 = gtk_label_new_with_mnemonic (_("Delete"));
  gtk_widget_show (label2);
  gtk_box_pack_start (GTK_BOX (hbox2), label2, FALSE, FALSE, 0);

  hseparator1 = gtk_hseparator_new ();
  gtk_widget_show (hseparator1);
  gtk_fixed_put (GTK_FIXED (fixed1), hseparator1, 16, 328);
  gtk_widget_set_size_request (hseparator1, 448, 16);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_show (scrolledwindow1);
  gtk_fixed_put (GTK_FIXED (fixed1), scrolledwindow1, 16, 112);
  gtk_widget_set_size_request (scrolledwindow1, 448, 208);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
  gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_SHADOW_ETCHED_OUT);

  /* GtkTreeView section */
  view1 = create_view_and_model();
  gtk_container_add(GTK_CONTAINER(scrolledwindow1), view1);
  gtk_widget_set_size_request (view1, 300, 200);
  /* ------------------- */

  label5 = gtk_label_new (_("Sign-in"));
  gtk_widget_show (label5);
  gtk_fixed_put (GTK_FIXED (fixed1), label5, 8, 16);
  gtk_widget_set_size_request (label5, 56, 16);

  label4 = gtk_label_new (_("Fingerprint data's list"));
  gtk_widget_show (label4);
  gtk_fixed_put (GTK_FIXED (fixed1), label4, 16, 80);
  gtk_widget_set_size_request (label4, 128, 25);
  gtk_label_set_single_line_mode (GTK_LABEL (label4), TRUE);

  usefinger_check_btn = gtk_check_button_new ();
  gtk_widget_show (usefinger_check_btn);
  gtk_fixed_put (GTK_FIXED (fixed1), usefinger_check_btn, 32, 40);
  gtk_widget_set_size_request (usefinger_check_btn, 265, 22);
  gtk_toggle_button_set_active(usefinger_check_btn,gaim_prefs_get_bool("/plugins/gtk/anubisq/using_fingerprint"));

  alignment4 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_show (alignment4);
  gtk_container_add (GTK_CONTAINER (usefinger_check_btn), alignment4);

  hbox4 = gtk_hbox_new (FALSE, 2);
  gtk_widget_show (hbox4);
  gtk_container_add (GTK_CONTAINER (alignment4), hbox4);

  image4 = gtk_image_new_from_stock ("gtk-index", GTK_ICON_SIZE_BUTTON);
  gtk_widget_show (image4);
  gtk_box_pack_start (GTK_BOX (hbox4), image4, FALSE, FALSE, 0);

  label6 = gtk_label_new_with_mnemonic (_("Sign-in with fingerprint authentication"));
  gtk_widget_show (label6);
  gtk_box_pack_start (GTK_BOX (hbox4), label6, FALSE, FALSE, 0);
  
  // Event listener
	
  //g_signal_connect(G_OBJECT(add_btn), "clicked", G_CALLBACK(show_add_window), NULL);
  g_signal_connect(G_OBJECT(add_btn), "clicked", G_CALLBACK(get_pkcs12_file), NULL);
  //g_signal_connect(G_OBJECT(add_btn), "clicked", G_CALLBACK(ldap_add_into_server), NULL);
  g_signal_connect(G_OBJECT(mod_btn), "clicked", G_CALLBACK(modifying_authorization_check_cb), NULL);
  //g_signal_connect(G_OBJECT(mod_btn), "clicked", G_CALLBACK(ldap_get_from_server), NULL);
  g_signal_connect(G_OBJECT(del_btn), "clicked", G_CALLBACK(deleting_authorization_check_cb), NULL);
  //g_signal_connect(G_OBJECT(del_btn), "clicked", G_CALLBACK(ldap_delete_from_server), NULL);
  g_signal_connect (G_OBJECT(usefinger_check_btn), 
                    "toggled",G_CALLBACK (check_button_cb), NULL);

  gtk_widget_show_all(window1);

  return window1;
}

static GaimGtkPluginUiInfo ui_info = 
{
	get_config_frame
};

static GList *actions(GaimPlugin *plugin, gpointer context){
     /*GList *l = NULL;
     GaimPluginAction *act = NULL;
     GaimPluginAction *act2 = NULL;
	 GaimPluginAction *act3 = NULL;
     act = gaim_plugin_action_new("Add user's fingerprint",show_add_window);
     act2 = gaim_plugin_action_new("Verify user's fingerprint",show_verify_window);
	 act3 = gaim_plugin_action_new("Delete user's fingerprint",show_delete_window);
     l = g_list_append(l, act);
     l = g_list_append(l, act2);
	 l = g_list_append(l, act3);
     return l;*/
}

plugin_load(GaimPlugin *plugin) {
	void *handle = gaim_connections_get_handle();
    	void *handle2 = gaim_accounts_get_handle();
     	plugin_handle = plugin;
      
        gaim_signal_connect(handle2, "account-connecting", plugin, 
		GAIM_CALLBACK(acc_signing_in_cb), NULL);

        gaim_signal_connect(handle, "signing-on", plugin, 
		GAIM_CALLBACK(signing_in_cb), NULL);

   	return TRUE;
}

static GaimPluginInfo info =
{
    GAIM_PLUGIN_MAGIC,
	GAIM_MAJOR_VERSION,
	GAIM_MINOR_VERSION,
	GAIM_PLUGIN_STANDARD,
    GAIM_GTK_PLUGIN_TYPE,
      	0,
      	NULL,
      	GAIM_PRIORITY_DEFAULT,
      	"anubisq",
      	"AnubisQ",
      	"0.72",
      	"Biometric authentication by fingerprint.",
      	N_("Use your password combine with your fingerprint to sign-in.\n"
	   "Sponsored by NECTEC (NSC2007)"),
      	"[ CAN ] <vipassu@hotmail.com>",
      	"http://webserv.kmitl.ac.th/~sapiv/",
      	plugin_load,
      	NULL,
      	NULL,

      	&ui_info,
      	NULL,
      	NULL,
      	NULL//actions
};

static void init_plugin(GaimPlugin *plugin)
{	
   gaim_prefs_add_none("/plugins/gtk");
   gaim_prefs_add_none("/plugins/gtk/anubisq");
   gaim_prefs_add_bool("/plugins/gtk/anubisq/using_fingerprint", TRUE);

}

GAIM_INIT_PLUGIN(anubisq, init_plugin, info)
