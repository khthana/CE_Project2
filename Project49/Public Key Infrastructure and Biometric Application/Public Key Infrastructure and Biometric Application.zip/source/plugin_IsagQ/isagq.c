/*dersaac
 
s
 */

#define GAIM_PLUGINS
#include "gaim.h"
#include "util.c"
#include "conversation.h"
#include "debug.h"
#include "prefs.h"
#include "signals.h"
#include "version.h"
#include "notify.h"
#include "gtkimhtml.h"
#include "gtkplugin.h"
#include "gtkutils.h"
#include "gtkdialogs.h"
#include "prpl.h"
//improve
#include "blist.h"

#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include <time.h>
//#include <gmp.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#include <openssl/pkcs12.h>


#include "common.c"
#include "rsa_key.c"
#include "certutil.c"

#include "ssl_connect.c"

//#include "test.c"

#define CH 1	//certificate header



G_MODULE_IMPORT GSList *gaim_accounts;
G_MODULE_IMPORT guint im_options;
#define PROJECT_PLUGIN_ID "project"
GaimPlugin *isagq_plugin_handle;
char selected_name[255];

static GtkWidget *key_size_entry, *proto_combo;
static GtkWidget *regen_window = NULL;
static GtkWidget *request_window = NULL;

//declare functionnn
char* filename_isagq=NULL;
RSA *priv_key;
GaimBlistNode *node_buddy_list = NULL;//improve

int number_buddy_conv=0;//improve
unsigned char* ciphertext;
const char *username = NULL;
static GtkWidget *password_window_isagq = NULL;
void get_pkcs12_file_isagq();
void enter_master_password_isagq();
void extract_cert_and_key_from_pkcs12_isagq(GtkWidget *widget,GtkWidget *entry );
void cancel_password_window_isagq();

static /*unsigned char  **/ void send_encrypt( const char *name,GaimAccount *acct,char *message,GaimConversation *conversation){
		RSA *pub_key;
		FILE *fp;
		unsigned char  *cipher_msg;//use ,*ciphertext;
		unsigned char  *cipher_str;
		unsigned char directory[255];
		unsigned char pubkey_cmd[255];
		unsigned char pubkey_file[255];
		int ciphersize,len;
		buddy_cert_file(name,directory,3);
		buddy_cert_file(name,pubkey_file,0);
		sprintf(pubkey_cmd,"openssl x509 -pubkey -noout -in %s > %s",directory,pubkey_file);
		system(pubkey_cmd);
		//if(!(fp=fopen("/root/.gaim/cert/isagmq@hotmail.com.pub","r")))
		if(!(fp=fopen(pubkey_file,"r")))
			gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open dir");

		if(!(pub_key=PEM_read_RSA_PUBKEY(fp, NULL, NULL, NULL)))
		{
			gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not read key");
			exit;
		}

		int size = RSA_size(pub_key);
		ciphertext=g_malloc(size);

		ciphersize=RSA_public_encrypt(strlen(message),message,	ciphertext,pub_key,RSA_PKCS1_OAEP_PADDING);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "str_ciphertext is %d \n",strlen(ciphertext));
		fclose(fp);
		/*					cipher_str=g_malloc(ciphersize); //with header
		//cipher_msg=g_malloc(ciphersize+4);
		len=bytes_to_str(cipher_str,ciphertext,ciphersize);
		cipher_msg=g_malloc(len+4);
		sprintf(cipher_msg,":EM:%s",cipher_str);
		serv_send_im(acct->gc, name,cipher_msg,GAIM_MESSAGE_AUTO_RESP);

		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "cipher msg is %s \n",cipher_msg);
		g_free(cipher_str);
		g_free(cipher_msg);*/
		cipher_str=g_malloc(ciphersize*2+1);		// no header
		len=bytes_to_str(cipher_str,ciphertext,ciphersize);			
		//cipher_str[len]=0;
		cipher_msg=g_malloc(len+5);

		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "msg length  before header = %d\n",len);
		sprintf(cipher_msg,":EM:%s",cipher_str);

		serv_send_im(acct->gc, name,cipher_msg,GAIM_MESSAGE_AUTO_RESP);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "cipher msg is %s \n",cipher_msg);

		gaim_conv_im_write(GAIM_CONV_IM(conversation), NULL,message,GAIM_MESSAGE_SEND, time((time_t)NULL));		
		gaim_conv_im_write(GAIM_CONV_IM(conversation), NULL,cipher_msg,GAIM_MESSAGE_SEND, time((time_t)NULL));		

		g_free(cipher_str);
		g_free(ciphertext);
		g_free(cipher_msg);

}
static void key_file(char key[255]){
		sprintf( key,"%s/cert/client.pem",gaim_user_dir());
}
static void ca_file(char ca[255]){
		sprintf(ca,"%s/cert/rootcert.pem",gaim_user_dir());
}
static void ca_dir(char dir[255]){
		sprintf( dir,"%s/cert/",gaim_user_dir());
}
static void crl_file(char crl[255]){
		//sprintf( key,"/root/Desktop/gaim-1.5.0/plugins/client.pem");
		sprintf(crl,"%s/cert/crl",gaim_user_dir());
}
static void check_state( const char *name,GaimAccount *acct){
		serv_send_im(acct->gc, name,":PC:",GAIM_MESSAGE_SEND );
}
static void cert_req( const char *name,GaimAccount *acct){
		serv_send_im(acct->gc, name,":CR:",GAIM_MESSAGE_SYSTEM );
}
static void send_cert( const char *name,GaimAccount *acct){
		char *msg;
		GaimConversation *conv;
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "send_key: %s\n", acct->username);

		conv = gaim_find_conversation_with_account(name, acct);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "send_key: %s, %p, %s\n", name, conv, acct->username);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "Gaim directory is %s\n", gaim_user_dir());
		msg = alloca(1000);
		char cert_file[255];

		//			int i;
		unsigned char buf[255];
		sprintf(cert_file,"%s",gaim_user_dir());
		strcat(cert_file,"/cert/");
		chdir(cert_file);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "Gaim absolute directory is %s\n", cert_file);
		sprintf(cert_file,"[CE]%s",acct->username);
		strcat(cert_file,".pem");
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "Gaim absolute directory is %s\n", cert_file);

		msg = alloca(1000);
		FILE *fp;				
		if (!(fp = g_fopen(cert_file, "r+")))
			gaim_debug(GAIM_DEBUG_INFO, "Isagq", "directory open error\n");
		while (fgets(buf, sizeof(buf), fp)>0) 
		{
			sprintf(msg,":CE:%s",buf);
			serv_send_im(acct->gc, name, msg,GAIM_MESSAGE_AUTO_RESP);
		};

			/*gaim_debug(GAIM_DEBUG_INFO, "Isagq","Error1\n");
		serv_send_im(acct->gc, name, msg,GAIM_MESSAGE_AUTO_RESP);*/
		*msg=0;
}

static void save_cert(GaimAccount *account,char *who,char **message){
		char *tmp;
		char cert_file[255];
		tmp = *message;		
		FILE *fp;
		int valid;
		buddy_cert_file(who,cert_file,3);
		valid = check_cert(who);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "cert_file is %s",cert_file);
		if (!(fp =fopen(cert_file,"a+")))
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "error open file");
		else
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", " open file ok dumb file is %s\n",*message);
				//gaim_markup_strip_html(*message);
				memcpy(tmp,gaim_markup_strip_html(*message)+4,strlen(*message)-4);
				
				fputs(tmp,fp);
				fputs("\n",fp);
		};
		fclose(fp);	
		return;
}

int check_header(char *message){
		char tag[4];
		int  tagnum = 0;

		memcpy(tag,message,4);

		/* try finding the tag */
		if(!strncmp(":PC:",tag,4))tagnum = 1;	//certificate request
		if(!strncmp(":CR:",tag,4))tagnum = 2;	//encrypt message
		if(!strncmp(":CE:",tag,4))tagnum = 3;	//plugin check
		if(!strncmp(":EM:",tag,4))tagnum = 4;  
		/* if theres a tag remove it.. if not. then leave it alone */
		if(tagnum > 0) 
				memmove(message,message+4,strlen(message)-4);
		return tagnum;
}

int cstr_to_bytes(unsigned char *bytes, unsigned char *cstr, int num){
		int bytes_cursor, str_cursor = 0;
		unsigned char minibuf[3] = "00";

		for (bytes_cursor = 0; bytes_cursor < num; ++bytes_cursor) 
		{
			  minibuf[0] = cstr[str_cursor++];
			  if (minibuf[0] == 0) return bytes_cursor;
			  minibuf[1] = cstr[str_cursor++];
			  if (minibuf[1] == 0) return -1;      
			  bytes[bytes_cursor] = (unsigned char) strtoul(minibuf, 0, 16);
		}
		return bytes_cursor;
}

static unsigned char *msg_decrypt(GaimAccount *acct,char **name,char *message,GaimConversation *conversation){
//msg_decrypt(account,who,*message);
		//RSA *priv_key;
		FILE *fp;
		unsigned char *cipher_str_decode,*plain_text;
		//unsigned char buf[500];
		unsigned char *buf;
		
		unsigned char *pure_msg,*tmp_msg;
		int i,length,error; 
	/*	char cert_file[255];
		char pvkey_cmd[255];*/
		char pvkey_file[255];		
	//	char *username;
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","error 1\n");	
		//gaim_debug(GAIM_DEBUG_INFO, "Isagq","pure message is %s\n",message);	
		//pure_msg=gaim_markup_strip_html(message);
		
		buf=g_malloc(500);
		sprintf(buf,"%s",gaim_markup_strip_html(message));
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","buf = %s\n",buf);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","length buf = %d\n",strlen(buf));
		/*pure_msg=g_malloc(strlen(buf));
		sprintf(pure_msg,"%s",buf);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","pure msg = %s\n",pure_msg);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","pure msg length= %d\n",strlen(pure_msg));*/
		length = strlen(buf)-4;
	
		unsigned char *token;
		//token = g_malloc(length);	
		token = strtok(buf,":");
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","buf = %d\n",buf);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","token = %d\n",token);
		//tmp_msg = g_malloc(length);
		for( i=0;i<2;i++)
		{
				if(i==1) tmp_msg=token;
				token = strtok(NULL,":");
		};

		gaim_debug(GAIM_DEBUG_INFO, "Isagq","message  after token %s\n",tmp_msg);	

		cipher_str_decode = g_malloc(length);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "error5\n");
		int len = cstr_to_bytes(cipher_str_decode,tmp_msg,length);

		gaim_debug(GAIM_DEBUG_INFO, "Isagq","error 1\n");
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "error1\n");
		//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "cipher_str_decode = %s ",cipher_str_decode);

		name=acct->username;
		buddy_cert_file(name,pvkey_file,1);
/*
		if(!(fp=fopen(pvkey_file,"r")))
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open dir");
		
		if(!(priv_key=PEM_read_RSAPrivateKey(fp, NULL, NULL, NULL)))
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not read key\n");	 
*/		
		int text_len = RSA_size(priv_key);
		
		plain_text=g_malloc(text_len); 
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "text_len is %d\n",text_len);
		error=RSA_private_decrypt(len,cipher_str_decode,plain_text,priv_key,RSA_PKCS1_OAEP_PADDING);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", " decrypted length %d\n",error);	
		
			
		
		if(error==-1)
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "decrypt error");
				//sprintf(show_msg,"%s","no message");				
		}
		else
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "out of decrypted function is %s \n",plain_text);
				
				/*strncpy(show_msg,plain_text,error);
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "show_msg is %s \n",show_msg);*/
		}
		/*unsigned char decrypt_msg[error];
		sprintf(decrypt_msg,"%s",plain_text);
		decrypt_msg[error]='\0';*/
		plain_text[error]='\0';
		//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "strlen(decrypt_msg) is %d\n",strlen(decrypt_msg));
		//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "decrypt_msg is %d\n",decrypt_msg);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "strlen(decrypt_msg) is %d\n",strlen(plain_text));
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "decrypt_msg is %s\n",plain_text);
		gaim_conv_im_write(GAIM_CONV_IM(conversation),name,plain_text,GAIM_MESSAGE_RECV,time((time_t)NULL));		
		//fclose(fp);

		g_free(plain_text);

		g_free(cipher_str_decode);
		//g_free(tmp_msg);		
		//g_free(token);		
		//g_free(pure_msg);
		g_free(buf);
		/*unsigned char *decrypt_msg;
		decrypt_msg=g_malloc(error);
		strncpy(decrypt_msg,plain_text,error);*/
		//return decrypt_msg;
		//return plain_text;
}
	
static void recv_msg_cb(GaimAccount *account,char **who,char **message){
		int type;
		
		unsigned char *pure_msg;
		unsigned char *decrypt_msg;	
 		pure_msg=gaim_markup_strip_html(*message);
		type = check_header(pure_msg);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","message type %d\n",type);
		int valid;
		valid = check_cert(*who);
		GaimConversation *conv;
		conv = gaim_find_conversation_with_account(*who,account);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq","who is %s\n",*who);
		char encrypt_pref[255];
		sprintf(encrypt_pref,"/plugins/gtk/isagq/%s",*who);
		fprintf(stderr,"*************************************receive start here\n");
		if(conv == NULL)
		{
				conv=gaim_conversation_new(GAIM_CONV_IM,account,*who);
		};
	node_buddy_list = (GaimBlistNode*)gaim_find_buddy(conv->account, conv->name);//improve
		if(type==1)
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq"," recieve plugin check \n");
				gaim_debug(GAIM_DEBUG_INFO, "Isagq","gaim_prefs_get_int(encrypt_pref):%d\n",gaim_prefs_get_int(encrypt_pref));
				//improveif(gaim_prefs_get_int(encrypt_pref)==0)
				if((gaim_blist_node_get_int (node_buddy_list, "isagq_state"))==0)//improve			
				{
						serv_send_im(account->gc,*who,":PC:",GAIM_MESSAGE_SEND );	
						if(valid==0)
						cert_req(*who,account);	
						//improvegaim_prefs_set_int(encrypt_pref,2);
			gaim_blist_node_set_int(node_buddy_list, "isagq_state", 2);//improve 
						gaim_debug(GAIM_DEBUG_INFO, "Isagq"," send check state \n");
				}
		}
		else if(type==2)
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq","receive cert_req \n");			
				send_cert(*who,account);
				if(valid==0)
				cert_req(*who,account);
		}
		else if(type==3)
		{
				gaim_debug(GAIM_DEBUG_INFO, "Isagq","receive save cert \n");										
				save_cert(account,*who,message);
				//improvegaim_prefs_set_int(encrypt_pref,2); 
			gaim_blist_node_set_int(node_buddy_list, "isagq_state", 2);//improve
		}
		else if(type==4)
		{
				/*gaim_debug(GAIM_DEBUG_INFO, "Isagq","recieve encrypted message \n");
				decrypt_msg=g_malloc(500);
				decrypt_msg=msg_decrypt(account,who,*message);
				gaim_debug(GAIM_DEBUG_INFO, "Isagq","decryptmsg:%s \n",decrypt_msg);
				gaim_conv_im_write(GAIM_CONV_IM(conv),*who,decrypt_msg,GAIM_MESSAGE_RECV,time((time_t)NULL));		
				g_free(decrypt_msg);*/
				msg_decrypt(account,*who,*message,conv);
		}
		else
		{													
				gaim_debug(GAIM_DEBUG_INFO, "Isagq","recieve normal message\n");				
				gaim_conv_im_write(GAIM_CONV_IM(conv),*who,*message,GAIM_MESSAGE_RECV,time((time_t)NULL));
				**message=0;						
		}
		fprintf(stderr,"*************************************receive end here\n");
}

static void send_msg_cb(GaimAccount *account,char *who,char **message){
		int valid;
		int state;
		state=0;
		unsigned char *encrypt_message;	
		char encrypt_pref[255];	
		fprintf(stderr,"*************************************function start here\n");
		gaim_debug(GAIM_DEBUG_MISC, "Isagq", "gaim home direcory: %s\n", gaim_home_dir());
		gaim_debug(GAIM_DEBUG_MISC, "Isagq", "gaim user direcory: %s\n", gaim_user_dir());
		const char *accountname = gaim_account_get_username(account);
		const char *protocol = gaim_account_get_protocol_id(account);

		//perror(accountname);
		//perror(protocol);
		//perror(who);

		GaimConversation *conv;
		gaim_debug(GAIM_DEBUG_MISC, "Isagq", "send_msg: %s\n", who);
		conv = gaim_find_conversation_with_account(who,account);
		if (conv == NULL) 
		{
				conv = gaim_conversation_new(GAIM_CONV_IM, account, who);
		}
		//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "requesting certificate\n");
		/* gaim_conversation_write(conv, 0, _("Requesting certificate..."),
					  GAIM_MESSAGE_SYSTEM, time((time_t)NULL));*/

		/**b = gaim_find_buddy(gaim_connection_get_account(d->gc), d->who);
		if (b)
			gaim_blist_node_set_int((GaimBlistNode*)b, YAHOO_ICON_CHECKSUM_KEY, d->checksum);
**/
//improveGaimBlistNode *node_buddy_list = NULL;
	node_buddy_list = (GaimBlistNode*)gaim_find_buddy(conv->account, conv->name);
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 0);
//gaim_blist_node_remove_setting(node_buddy_list,"irssi::layout");
/*useGaimBuddyList* blist=gaim_get_blist();
node_buddy_list=blist->root;
//node_buddy_list=node_buddy_list->child;
while(node_buddy_list!=NULL)
{

//node_buddy_list=node_buddy_list->next;

/*node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->parent;
node_buddy_list=node_buddy_list->next;
node_buddy_list=node_buddy_list->child;*/
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 3);
/*usewhile(node_buddy_list->child!=NULL){
	node_buddy_list=node_buddy_list->child;
	gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 1);
}
//else{
	node_buddy_list=node_buddy_list->parent;
//}
if(node_buddy_list->next!=NULL){
	node_buddy_list=node_buddy_list->next;
	gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 2);
}

else{
	node_buddy_list=node_buddy_list->parent;
	node_buddy_list=node_buddy_list->next;
}
}use*/

/*
node_buddy_list=node_buddy_list->next;
node_buddy_list=node_buddy_list->child;*/
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 3);
//			gaim_blist_node_remove_setting(node_buddy_list,"irssi::layout");
	 
/*		node_buddy_list = gaim_blist_get_root();
node_buddy_list = gaim_blist_node_next(node_buddy_list, TRUE);
 		for (; node_buddy_list; node_buddy_list = gaim_blist_node_next(node_buddy_list, TRUE))
			gaim_blist_node_remove_setting(node_buddy_list,"irssi::layout");	
*/
//improve		sprintf(encrypt_pref,"/plugins/gtk/isagq/%s",who);
		valid = check_cert(who);
//improve		state=gaim_prefs_get_int(encrypt_pref);
		state=gaim_blist_node_get_int (node_buddy_list, "isagq_state");//improve
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "state = %d \n",state);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "valid = %d \n",valid);

		if(state==0)
		{
			gaim_blist_node_set_int(node_buddy_list, "isagq_state", 0);//improve
				gaim_debug(GAIM_DEBUG_INFO, "Isagq", "check plugin \n");
				check_state(who,account);	
			gaim_blist_node_set_int(node_buddy_list, "isagq_state", 1);//improve
				//improvegaim_prefs_set_int(encrypt_pref,1);
		}
		else if(state==2)
		{
				if(valid==0)
						cert_req(who,account);
				else 
				{
						/*encrypt_message=g_malloc(500);
						encrypt_message=send_encrypt(who,account,*message);
						gaim_debug(GAIM_DEBUG_INFO, "Isagq", "encrypt message is %s\n",encrypt_message);
						gaim_conv_im_write(GAIM_CONV_IM(conv), NULL,encrypt_message,GAIM_MESSAGE_SEND, time((time_t)NULL));		
						gaim_conv_im_write(GAIM_CONV_IM(conv), NULL,*message,GAIM_MESSAGE_SEND, time((time_t)NULL));
						**message=0;
						g_free(encrypt_message);*/										
						send_encrypt(who,account,*message,conv);
						**message=0;
				}
		}
		fprintf(stderr,"*************************************function end here\n");
}


/*void on_comboboxentry1_add(){
}*/
static void config_cancel_regen() {
		if (regen_window) 
		{
				gtk_widget_destroy(regen_window);
		}
		regen_window = NULL;
}

void	do_regen(){
		FILE *fp;
		char dir[255],tmp1[255],tmp2[255];
		char key_size[255];
		char *file_pt;
		char *name_pt;
		int size;
		sprintf(dir,"%s/cert/tmp.txt",gaim_user_dir());	
		fp = fopen(dir,"w");
		fprintf(fp,"%s",selected_name);
		fclose(fp);
		file_pt = selected_name;
		unsigned char *token,*tmp_msg;
		int i;

		token = strtok(selected_name,"]");
		for( i=0;i<2;i++)
		{
				if(i==0) tmp_msg=token;
				token = strtok(NULL,"]");
		};
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "intoken 1 is %s\n",tmp_msg);
		//	 sprintf(tmp1,"%s",tmp_msg);
		//		strncpy(tmp2,tmp1,strlen(tmp1)-4);

		name_pt = tmp_msg;

		//	gaim_debug(GAIM_DEBUG_INFO, "Isagq", "intoken 2 is %s\n",tmp2);
		//	get_name_from_cert(name_pt,file_pt);

		const gchar* key_string = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(proto_combo)->entry)); 

		sprintf(key_size,"%s",key_string);
		size=atoi(key_size);

		//strncpy(name_pt,tmp_msg,strlen(tmp_msg)-4);
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "intoken is %s\n",name_pt);
		if (size==1024)
		{
				create_req(name_pt,1024);
				ssl_con1(name_pt);
		}
		else if(size==2048)
		{
				create_req(name_pt,2048);
				ssl_con1(name_pt);				
		}
		else if (size==4096)
		{
				create_req(name_pt,4096);
				ssl_con1(name_pt);			
		}
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "last row");
		config_cancel_regen();
}

static void cancel_request_window(){
		if (request_window)
		{
				gtk_widget_destroy(request_window);
		}
		request_window = NULL;
}

static	void show_request_window(){
		GtkWidget *vbox1;
		GtkWidget *label1;
		GtkWidget *button1;   
				if (request_window != NULL) return;

		GAIM_DIALOG(request_window);
		gtk_window_set_modal (GTK_WINDOW (request_window), TRUE);
		gtk_window_set_keep_above(GTK_WINDOW (request_window), TRUE);	
		gtk_widget_set_size_request(request_window, 200, 100);
		//gtk_window_set_title(GTK_WINDOW(regen_window), _("Requesting Certificate"));		
		vbox1 = gtk_vbox_new (FALSE, 0);
		gtk_widget_show (vbox1);
		gtk_container_add (GTK_CONTAINER (request_window), vbox1);

		label1 = gtk_label_new (_("\nRequesting Certifiacte...\n\n"));
		gtk_widget_show (label1);
		gtk_box_pack_start (GTK_BOX (vbox1), label1, FALSE, FALSE, 0);

		button1 = gtk_button_new_with_mnemonic (_("Cancel"));
		g_signal_connect(G_OBJECT(button1), "clicked",
				GTK_SIGNAL_FUNC(cancel_request_window),NULL);
		gtk_widget_show (button1);
		gtk_box_pack_start (GTK_BOX (vbox1), button1, 0, 0, 0);
		gtk_widget_show (request_window);
}
	
static void config_regen_key() {
		//GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(key_list_view));

		GtkWidget *vbox, *hbox, *label, *table, *button;//*regen_err_label
		GList *proto_list = NULL;

		proto_list = g_list_append(proto_list,"1024");
		proto_list = g_list_append(proto_list,"2048");
		proto_list = g_list_append(proto_list,"4096");

		if (regen_window != NULL) return;

		GAIM_DIALOG(regen_window);
		gtk_widget_set_size_request(regen_window, 300, 150);
		gtk_window_set_title(GTK_WINDOW(regen_window), _("Generate Certificate"));
		/* g_signal_connect(G_OBJECT(regen_window), "destroy", 
				GTK_SIGNAL_FUNC(config_cancel_regen), NULL);*/

		vbox = gtk_vbox_new(0, 2);
		gtk_container_set_border_width(GTK_CONTAINER(vbox), 4);
		gtk_container_add(GTK_CONTAINER(regen_window), vbox);
		gtk_widget_show (vbox);

		/*  if (!gtk_tree_selection_get_selected(selection, NULL, NULL)) {
		label = gtk_label_new(_("No key selected to re-generate!"));
		gtk_box_pack_start(GTK_BOX(vbox), label, 0, 0, 0);
		gtk_widget_show(label);

		hbox = gtk_hbox_new(FALSE, 2);
		gtk_box_pack_end(GTK_BOX(vbox), hbox, 0, 0, 0);
		gtk_widget_show(hbox);

		button = gtk_button_new_with_label(_("OK"));
		g_signal_connect(G_OBJECT(button), "clicked",
					 GTK_SIGNAL_FUNC(config_cancel_regen), NULL);
		gtk_box_pack_end(GTK_BOX(hbox), button, 0, 0, 0);
		gtk_widget_set_size_request(button, 100, -1);
		gtk_widget_show(button);
		gtk_widget_show(regen_window);
		return;
		}
		*/
		/* Start 2 x 2 table */
		table = gtk_table_new(2, 2, FALSE);
		gtk_box_pack_start(GTK_BOX(vbox), table, 0, 0, 0);
		gtk_widget_show(table);

		/* First column */
		label = gtk_label_new(_("Key size:"));
		gtk_widget_set_size_request(label, 150, -1);
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
		gtk_table_attach(GTK_TABLE(table), label, 0, 1, 0, 1,
				0, 0, 0, 0);
		gtk_widget_show(label);

		/*  label = gtk_label_new(_("Key size:"));
		gtk_widget_set_size_request(label, 150, -1);
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
		gtk_table_attach(GTK_TABLE(table), label, 0, 1, 1, 2,
				0, 0, 0, 0);
		gtk_widget_show(label);*/

		/* Second column: */
		proto_combo = gtk_combo_new();
		/*  gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(proto_combo)->entry), 
				  ((crypt_proto*)crypt_proto_list->data)->name);*/
		gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(proto_combo)->entry),"test1");
		gtk_editable_set_editable(GTK_EDITABLE(GTK_COMBO(proto_combo)->entry),
				FALSE);
		/*   for( iter = crypt_proto_list; iter != NULL; iter = iter->next ) {
		proto_list = g_list_append(proto_list,
							 ((crypt_proto *)iter->data)->name);
		}*/
		gtk_combo_set_popdown_strings(GTK_COMBO (proto_combo), proto_list);
		g_list_free(proto_list);
		gtk_table_attach(GTK_TABLE(table), proto_combo, 1, 2, 0, 1,
				0, 0, 0, 0);

		gtk_widget_set_size_request(proto_combo, 85, -1);
		gtk_widget_show(proto_combo);

		key_size_entry = gtk_entry_new();
		gtk_entry_set_max_length(GTK_ENTRY(key_size_entry), 5);
		gtk_entry_set_text(GTK_ENTRY(key_size_entry), "1024");
		gtk_table_attach(GTK_TABLE(table), key_size_entry, 1, 2, 1, 2,
				0, 0, 0, 0);
		gtk_widget_set_size_request(key_size_entry, 85, -1);
		//gtk_widget_show(key_size_entry);
		/* End of 2x2 table */


		hbox = gtk_hbox_new(FALSE, 2);
		gtk_box_pack_end(GTK_BOX(vbox), hbox, 0, 0, 0);
		gtk_widget_show(hbox);

		button = gtk_button_new_with_label(_("Ok"));
		g_signal_connect(G_OBJECT(button), "clicked",
				GTK_SIGNAL_FUNC(do_regen),NULL);
		gtk_box_pack_start(GTK_BOX(hbox), button, 0, 0, 0);
		gtk_widget_set_size_request(button, 100, -1);
		gtk_widget_show(button);

		button = gtk_button_new_with_label(_("Cancel"));
		g_signal_connect(G_OBJECT(button), "clicked",
				GTK_SIGNAL_FUNC(config_cancel_regen), NULL);
		gtk_box_pack_start(GTK_BOX(hbox), button, 0, 0, 0);
		gtk_widget_set_size_request(button, 100, -1);
		gtk_widget_show(button);
		gtk_widget_show(regen_window);
}
void selection_made( GtkWidget      *clist,
                     gint            row,
                     gint            column,
                     GdkEventButton *event,
                     gpointer        data )
{
		gchar *text;
		/* Get the text that is stored in the selected row and column
		 * which was clicked in. We will receive it as a pointer in the
		 * argument text.
		 */
		gtk_clist_get_text(GTK_CLIST(clist), row, column, &text);

		/* Just prints some information about the selected row */
		g_print("You selected row %d. More specifically you clicked in "
				"column %d, and the text in this cell is %s\n\n",
				row, column, text);
					
		sprintf(selected_name,"%s",text);
		return;
}

void get_pkcs12_file_isagq()
{
	//delete info about cert in blist.xml
	GaimBuddyList* blist=gaim_get_blist();
node_buddy_list=blist->root;
int i,j,k,l,m,n,o,p,q,r;
i=j=k=l=m=n=o=p=q=r=0;
//node_buddy_list=node_buddy_list->child;
while(node_buddy_list!=NULL)
{
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "helloooo%d\n",i++);
//node_buddy_list=node_buddy_list->next;

/*node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->parent;
node_buddy_list=node_buddy_list->next;
node_buddy_list=node_buddy_list->child;*/
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", i);
while(node_buddy_list->child!=NULL){
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "j%d\n",j++);
	node_buddy_list=node_buddy_list->child;
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "k%d\n",k++);
	//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 1);
	//gaim_blist_node_remove_setting(node_buddy_list,"isagq_state");
}
//else{
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "l%d\n",l++);
	if(node_buddy_list->parent!=NULL)
		node_buddy_list=node_buddy_list->parent;
	else if(node_buddy_list->next!=NULL)
		node_buddy_list=node_buddy_list->next;
	else 
		break;
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "m%d\n",m++);
//}
if(node_buddy_list->next!=NULL){
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "n%d\n",n++);
	node_buddy_list=node_buddy_list->next;
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "o%d\n",o++);
}

else{
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "p%d\n",p++);
	node_buddy_list=node_buddy_list->parent;
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "q%d\n",q++);
	node_buddy_list=node_buddy_list->next;
	//gaim_debug(GAIM_DEBUG_MISC, "Isagq", "r%d\n",r++);
}
}
//improve


	GtkWidget *dialog_isagq;
	//char *filename;
	dialog_isagq = gtk_file_chooser_dialog_new ("Select Backup Certificate File..",
				      NULL,
				      GTK_FILE_CHOOSER_ACTION_OPEN,
				      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
				      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
				      NULL);
	gtk_window_set_modal (GTK_WINDOW (dialog_isagq), TRUE);
	if (gtk_dialog_run (GTK_DIALOG (dialog_isagq)) == GTK_RESPONSE_ACCEPT)
  	{
	    filename_isagq = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog_isagq));
	    //g_print(filename);
	    gtk_widget_destroy (dialog_isagq);
	    enter_master_password_isagq();	    	    
	}
	//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "gfreefilename");
}

void enter_master_password_isagq()
{
  //GtkWidget *window2;
  GtkWidget *fixed2;
  GtkWidget *entry2;
  GtkWidget *label2;
  GtkWidget *button3;
  GtkWidget *button2;

  //if (password_window != NULL) return;

  password_window_isagq = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (password_window_isagq), _("Enter Master Password"));

  fixed2 = gtk_fixed_new ();
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (password_window_isagq), fixed2);

  entry2 = gtk_entry_new ();
  gtk_widget_show (entry2);
  gtk_fixed_put (GTK_FIXED (fixed2), entry2, 8, 56);
  gtk_widget_set_size_request (entry2, 312, 24);
  gtk_entry_set_visibility (GTK_ENTRY (entry2), FALSE);
  gtk_entry_set_invisible_char (GTK_ENTRY (entry2), 8226);

  label2 = gtk_label_new (_("Enter master password ( same as backup password )"));
  gtk_widget_show (label2);
  gtk_fixed_put (GTK_FIXED (fixed2), label2, 0, 24);
  gtk_widget_set_size_request (label2, 328, 16);

  button3 = gtk_button_new_from_stock ("gtk-cancel");
  gtk_widget_show (button3);
  gtk_fixed_put (GTK_FIXED (fixed2), button3, 240, 96);
  gtk_widget_set_size_request (button3, 79, 32);

  button2 = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (button2);
  gtk_fixed_put (GTK_FIXED (fixed2), button2, 160, 96);
  gtk_widget_set_size_request (button2, 63, 32);

  //event listener
  g_signal_connect(G_OBJECT(button2), "clicked",
	GTK_SIGNAL_FUNC(extract_cert_and_key_from_pkcs12_isagq),(gpointer) entry2); 
  g_signal_connect(G_OBJECT(button3), "clicked",
	GTK_SIGNAL_FUNC(cancel_password_window_isagq),NULL);  

  gtk_widget_show_all(password_window_isagq);
}

//test
void test(){
char *message="heello";
      FILE *fp;
RSA* pub_key;
/*		unsigned char directory[255];
		unsigned char pubkey_cmd[255];
		unsigned char pubkey_file[255];
		int ciphersize,len;
		buddy_cert_file("isagmq@hotmail.com",directory,3);
		buddy_cert_file("isagmq@hotmail.com",pubkey_file,0);
		sprintf(pubkey_cmd,"openssl x509 -pubkey -noout -in %s > %s",directory,pubkey_file);
		system(pubkey_cmd)*/
		if(!(fp=fopen("/root/Desktop/certIsagmq.pem","r")))
			gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open dir");

		if(!(pub_key=PEM_read_RSA_PUBKEY(fp, NULL, NULL, NULL)))
		{
			gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not read key");
			exit;
		}
		int size = RSA_size(pub_key);
unsigned char  *ciphertext=malloc(size);
int ciphersize=RSA_public_encrypt(strlen(message),message,ciphertext,pub_key,RSA_PKCS1_OAEP_PADDING);
gaim_debug(GAIM_DEBUG_INFO, "Isagq", "ciphersize:%d\n",ciphersize);

		char* plain_text;
		int error=RSA_private_decrypt(128,ciphertext,plain_text,priv_key,RSA_PKCS1_OAEP_PADDING);
gaim_debug(GAIM_DEBUG_INFO, "Isagq", "plain_text:%s\n",plain_text);
//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "plain_text:\n");
}
//end test

void extract_cert_and_key_from_pkcs12_isagq(GtkWidget *widget,GtkWidget *entry )
{
/*	const gchar *entry_text;
//	char strFromCert[]="strTestCert";,*message="hello";
	FILE *f;
	PKCS12 *p12;
	EVP_PKEY *evp_pri=NULL;
	X509 *x509=NULL;

  	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
  	OpenSSL_add_all_algorithms ();
	ERR_load_crypto_strings ();
	SSL_load_error_strings();

	f = fopen(filename_isagq,"rb");
	if (!f) {
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open PKCS12 file '%s'\n",filename_isagq);
        //failf(data, "could not open PKCS12 file '%s'", cert_file);
        //return 0;
	}
	p12 = d2i_PKCS12_fp(f, NULL);
	if (p12 == NULL) {
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not make p12 structure\n");
        //return NULL;
	}
	fclose(f);
	if (!PKCS12_parse(p12, entry_text, &evp_pri, &x509, NULL)) {
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not parse PKCS12 file,please check password.\n");
		ERR_print_errors_fp(stderr);
        //failf(data,"could not parse PKCS12 file, check password, OpenSSL error %s",
              //ERR_error_string(ERR_get_error(), NULL) );
//printf("could not parse PKCS12 file, check password, OpenSSL error %s",
  //            ERR_error_string(ERR_get_error(), NULL) );
		EVP_cleanup();
        //return 0;
      }
      PKCS12_free(p12);

/* write the certificate to file*/
/*char CERT_FILE[]="/root/Desktop/cert.pem";
  if (!(f = fopen (CERT_FILE, "w")))
    printf("Error writing to certificate file");
  if (PEM_write_X509 (f, x509) != 1)
    printf("Error while writing certificate");
  fclose (f);
*/
	FILE *fp;
	const gchar *entry_text;
	char cmdGetEmail[255],cmdExtractCert[255],cmdExtractPVkey[255],cmdRenameCertFile[255];
	char cert_file_tmp[255],cert_file[255],pvKey_file[255],tmp_file[255],email[50]="email";
	char strTestCert[]="strTestCert",strFromCert[]="strTestCert";
  	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

	//extract cert file
	buddy_cert_file(email,cert_file_tmp,3);
	sprintf(cmdExtractCert,"openssl pkcs12 -in %s -clcerts -nokeys -out %s -passin pass:%s",filename_isagq,cert_file_tmp,entry_text);
	system(cmdExtractCert);

	//test cert file ->extract complete or not
	if(!(fp = fopen(cert_file_tmp,"r")))
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open cert file\n");
	fgets(strFromCert, sizeof(strFromCert), fp);
	fclose(fp);

	if(!strcmp(strTestCert,strFromCert)){
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "cannot extract cert file\n");
		popup_error();
		cancel_password_window_isagq();
		return;	
	}
//gaim_debug(GAIM_DEBUG_INFO, "Isagq", "%s,%d\n",strFromCert,strlen(strFromCert));	
	//get email from cert file
	sprintf(tmp_file,"%s/cert/tmp.txt",gaim_user_dir());	
	sprintf(cmdGetEmail,"openssl x509 -noout -email -in %s > %s",cert_file_tmp,tmp_file);
	system(cmdGetEmail);	
	if(!(fp = fopen(tmp_file,"r")))
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open tmp.txt");
	fgets(email, sizeof(email), fp);
	fclose(fp);
	email[strlen(email)-1]='\0';

	//check email(in cert) with username
	gaim_debug(GAIM_DEBUG_INFO, "Isagq", "email:%s username:%s\n",email,username);
	if(strcmp(username,email)){
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "email in cert is different from username\n");
		popup_error();
		cancel_password_window_isagq();
		return;			
	}

	//rename cert file	
	buddy_cert_file(email,cert_file,3);
	sprintf(cmdRenameCertFile,"mv %s %s",cert_file_tmp,cert_file);
	system(cmdRenameCertFile);	

	//extract private key file
	buddy_cert_file(email,pvKey_file,1);
	sprintf(cmdExtractPVkey,"openssl pkcs12 -in %s -nocerts -nodes -out %s -passin pass:%s",filename_isagq,pvKey_file,entry_text);
	system(cmdExtractPVkey);

	//read private key file to variable
	if(!(fp=fopen(pvKey_file,"r")))
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not open dir");
		
	if(!(priv_key=PEM_read_RSAPrivateKey(fp, NULL, NULL, NULL)))
		gaim_debug(GAIM_DEBUG_INFO, "Isagq", "could not read key\n");	
	
	//delete private key file
	remove(pvKey_file);
	
	fclose(fp);	
//test();
	g_free (filename_isagq);
	cancel_password_window_isagq();
}

void popup_error()
{
  GtkWidget *window3;
  GtkWidget *fixed3;
  GtkWidget *image1;
  GtkWidget *button4;
  GtkWidget *label6;

  window3 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window3), _("Error"));

  fixed3 = gtk_fixed_new ();
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (window3), fixed3);

  image1 = gtk_image_new_from_stock ("gtk-dialog-error", GTK_ICON_SIZE_DIALOG);
  gtk_widget_show (image1);
  gtk_fixed_put (GTK_FIXED (fixed3), image1, 8, 16);
  gtk_widget_set_size_request (image1, 48, 48);

  button4 = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (button4);
  gtk_fixed_put (GTK_FIXED (fixed3), button4, 128, 120);
  gtk_widget_set_size_request (button4, 55, 29);

  label6 = gtk_label_new (_("IsagQ cannot extract Certificate File\n\nbecause file or password is incorrect.\n\nSo you send message in normal text."));
  gtk_widget_show (label6);
  gtk_fixed_put (GTK_FIXED (fixed3), label6, 72, 16);
  gtk_widget_set_size_request (label6, 224, 88);

  //event listener
  g_signal_connect_swapped(G_OBJECT(button4), "clicked",
	GTK_SIGNAL_FUNC(gtk_widget_destroy),window3);

  gtk_widget_show_all(window3);	
}

void cancel_password_window_isagq()
{
	if (password_window_isagq)
		gtk_widget_destroy(password_window_isagq);
	password_window_isagq = NULL;
}
/*
static GtkWidget* pref_frame(GaimPlugin *plugin)
{
  GtkWidget *window1;
  GtkWidget *fixed1;
  GtkWidget *label1;
  GtkWidget *button1;

  window1 = gtk_fixed_new ();
// editable
  fixed1 = gtk_fixed_new ();
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (window1), fixed1);

  label1 = gtk_label_new (_("Select Backup Certificate File.."));
  gtk_widget_show (label1);
  gtk_fixed_put (GTK_FIXED (fixed1), label1, 24, 32);
  gtk_widget_set_size_request (label1, 184, 16);

  button1 = gtk_button_new_with_mnemonic (_("Browse"));
  gtk_widget_show (button1);
  gtk_fixed_put (GTK_FIXED (fixed1), button1, 232, 32);
  gtk_widget_set_size_request (button1, 56, 32);
// end editable
 
  //event listener  
  g_signal_connect(G_OBJECT(button1), "clicked",
	GTK_SIGNAL_FUNC(get_pkcs12_file),NULL);
//  g_signal_connect(G_OBJECT(button2), "clicked",
//	GTK_SIGNAL_FUNC(extract_cert_and_key_from_pkcs12),(gpointer) entry2);
 
  gtk_widget_show_all(window1);
	
  return window1;	
}*/

static void signed_on_cb(GaimConnection *gc)
{
	gaim_debug(GAIM_DEBUG_MISC, "Isagq", "helloooo\n");
	GaimBuddyList* blist=gaim_get_blist();
node_buddy_list=blist->root;
//node_buddy_list=node_buddy_list->child;
while(node_buddy_list!=NULL)
{
	gaim_debug(GAIM_DEBUG_MISC, "Isagq", "helloooo1\n");
//node_buddy_list=node_buddy_list->next;

/*node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->parent;
node_buddy_list=node_buddy_list->next;
node_buddy_list=node_buddy_list->child;*/
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 3);
while(node_buddy_list->child!=NULL){
	node_buddy_list=node_buddy_list->child;
	//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 1);
	gaim_blist_node_remove_setting(node_buddy_list,"isagq_state");
}
//else{
	node_buddy_list=node_buddy_list->parent;
//}
if(node_buddy_list->next!=NULL){
	node_buddy_list=node_buddy_list->next;
	//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 2);
	gaim_blist_node_remove_setting(node_buddy_list,"isagq_state");
}

else{
	node_buddy_list=node_buddy_list->parent;
	node_buddy_list=node_buddy_list->next;
}
}
//improve	
}

static void new_conv_cb(GaimAccount *account,char *who){
		GaimConversation *conv;
		gaim_debug(GAIM_DEBUG_MISC, "Isagq", "send_msg: %s\n", who);
		conv = gaim_find_conversation_with_account(who,account);
		if (conv == NULL) 
		{
				conv = gaim_conversation_new(GAIM_CONV_IM, account, who);
		}

		//show_request_window();
}

static void find_username_cb(GaimConnection *gc)
{
	username = gaim_account_get_username(gaim_connection_get_account(gc));
	gaim_debug(GAIM_DEBUG_INFO, "Isagq", "%s has been signing on\n",username);
}

static void init_pref(){
	   gaim_prefs_add_none("/plugins/gtk");
	   gaim_prefs_add_none("/plugins/gtk/isagq");
	   
	   //gaim_prefs_add_bool("/plugins/gtk/encrypt/accept_unknown_key", FALSE);
}

static gboolean
plugin_load(GaimPlugin *handle)
{		
		init_pref();
		//init_cert();
		//ssl_con1();
		void *conv_handle = gaim_conversations_get_handle();
		void *conn_handle = gaim_connections_get_handle();
		/*  void *blist_handle = gaim_blist_get_handle();
		void *core_handle = gaim_get_core();*/	
		isagq_plugin_handle = handle;
		
		gaim_signal_connect(conv_handle, "sending-im-msg", isagq_plugin_handle,
				GAIM_CALLBACK(send_msg_cb), NULL);
		gaim_signal_connect(conv_handle, "receiving-im-msg", isagq_plugin_handle,
				GAIM_CALLBACK(recv_msg_cb), NULL);
		gaim_signal_connect(conv_handle, "conversation-created", isagq_plugin_handle,
				GAIM_CALLBACK(new_conv_cb), NULL);
		gaim_signal_connect(conn_handle, "signing-on", isagq_plugin_handle, 
				GAIM_CALLBACK(find_username_cb), NULL);
		gaim_signal_connect(conn_handle, "signed-on", isagq_plugin_handle,
				GAIM_CALLBACK(get_pkcs12_file_isagq), NULL);
//improve
//use		gaim_signal_connect(conn_handle, "signed-on", isagq_plugin_handle, 
//				GAIM_CALLBACK(signed_on_cb), NULL);
		return TRUE;
}

static gboolean
plugin_unload(GaimPlugin *plugin)
{//improve
/*useGaimBuddyList* blist=gaim_get_blist();
node_buddy_list=blist->root;
//node_buddy_list=node_buddy_list->child;
while(node_buddy_list!=NULL)
{

//node_buddy_list=node_buddy_list->next;

/*node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->child;
node_buddy_list=node_buddy_list->parent;
node_buddy_list=node_buddy_list->next;
node_buddy_list=node_buddy_list->child;*/
//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 3);
/*while(node_buddy_list->child!=NULL){
	node_buddy_list=node_buddy_list->child;
	//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 1);
	gaim_blist_node_remove_setting(node_buddy_list,"isagq_state");
}
//else{
	node_buddy_list=node_buddy_list->parent;
//}
if(node_buddy_list->next!=NULL){
	node_buddy_list=node_buddy_list->next;
	//gaim_blist_node_set_int(node_buddy_list, "irssi::layout", 2);
	gaim_blist_node_remove_setting(node_buddy_list,"isagq_state");
}

else{
	node_buddy_list=node_buddy_list->parent;
	node_buddy_list=node_buddy_list->next;
}
}
//improve*/
		//improvegaim_prefs_remove("/plugins/gtk/isagq/");
		/*gaim_signal_disconnect(conv_handle, "conversation-created",
						plugin, GAIM_CALLBACK(timestamp_new_convo));
		gaim_signal_disconnect(conv_handle, "receiving-im-msg",
						plugin, GAIM_CALLBACK(timestamp_receiving_msg));
		gaim_signal_disconnect(conv_handle, "displaying-im-msg",
						plugin, GAIM_CALLBACK(timestamp_displaying_conv_msg));
		
		destroy_timer_list();*/
		return TRUE;
}
/*
static GaimGtkPluginUiInfo ui_info =
{
	pref_frame
};*/

static GaimPluginInfo info =
{
		GAIM_PLUGIN_MAGIC,
		GAIM_MAJOR_VERSION,
		GAIM_MINOR_VERSION,
		GAIM_PLUGIN_STANDARD,                             /**< type           */
		GAIM_GTK_PLUGIN_TYPE,                             /**< ui_requirement */
		0,                                                /**< flags          */
		NULL,                                             /**< dependencies   */
		GAIM_PRIORITY_DEFAULT,                            /**< priority       */

		PROJECT_PLUGIN_ID,                              /**< id             */
		N_("IsagQ"),                                  /**< name           */
		VERSION,                                          /**< version        */
														  /**  summary        */
		N_("gaim with isagq."),
														  /**  description    */
		N_("gaim with isagq."),
		"rachod <evangelion99@hotmail.com>",             /**< author         */
		GAIM_WEBSITE,                                     /**< homepage       */

		plugin_load,                                      /**< load           */
		plugin_unload,                                    /**< unload         */
		NULL,                                             /**< destroy        */

		/*&ui_info*/NULL,                                         /**< ui_info        */
		NULL,                                             /**< extra_info     */
		NULL,	
		NULL
};

static void
init_plugin(GaimPlugin *plugin)
{
/*	 gaim_debug(GAIM_DEBUG_INFO, "project", "requesting key\n");
	gaim_prefs_add_none("/plugins/project");
	gaim_prefs_add_int("/plugins/project/interval", interval);*/
}

GAIM_INIT_PLUGIN(project, init_plugin, info)
