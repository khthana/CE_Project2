package tinyapp;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.Vector;
import java.util.*;	
import javax.microedition.rms.*;
import java.lang.*;
import net.dclausen.microfloat.*;
import henson.midp.*;

import com.tinyline.tiny2d.*;
import com.tinyline.svg.*;

public class Viewer extends MIDlet implements CommandListener
{

    // The Main screen
    int[] buspoint = {01,02,03,04,05};    
    long[] myX = {692270,692271,262271};
    long[] myY = {-1518176,-1518176,-1518177};
        Display display;
    // The SVG canvas
    ViewerCanvas canvas;
    //////Float
    Calendar  calendar;
    long a,b;  
    
   
    AddAppointment addApp;       
    

    // Commands
    Command linkCommand,
    panCommand, zoomCommand, addCommand,
    helpCommand, exitCommand,menugetpath,getbusstop,myposition;
    List menu;
    private Command  backCmd = new Command("Back",Command.BACK,1);

    // Help screen
    Form outputForm;
    
    Command helpBackCommand;
    
  // The red color
    TinyColor redColor    =  new TinyColor(0xFFFF0000);
    // The yellow color
    TinyColor yellowColor =  new TinyColor(0xFFFFFF00);
    // The navy color
    TinyColor navyColor   =  new TinyColor(0xFF000080);
    
    //Thread
   // AlertThread alertthread;
	private boolean Checkalert,getbus ;
	
	//schedul
	 private Vector  apps;
	 private List  appList = null;
	 private List  appList1 = null;
	 private ScheduleDB  scheduleDB;
	 
	 int count = 0;
	 StringItem response;
	 String response1;
	String busstop;
	
	private String[] option = {"Add Reminder","List Reminder"};
    /**
     * Construct a new Viewer MIDlet and initialize the base options
     * and SVG canvas to be used when the MIDlet is started.
     */
    public Viewer()
    {    	
    	
    a = 692472;
    b = -1517999;	   
	display = Display.getDisplay(this);
	// Create the Main screen.
	canvas = new ViewerCanvas(display);
	calendar = Calendar.getInstance();
	// Load incons
	canvas.init();

	
	panCommand       = new Command("Pan", Command.SCREEN, 1);
	zoomCommand      = new Command("Zoom", Command.SCREEN, 1);
	addCommand  =     new Command("Reminder", Command.SCREEN, 1);    
	exitCommand      = new Command("Exit", Command.EXIT, 2);
	appList = new List("Appointments", List.IMPLICIT);
	appList1 = new List("Appointments", List.IMPLICIT);
	menugetpath      = new Command("Getpath", Command.SCREEN, 1);
	getbusstop      = new Command("Getbusstop", Command.SCREEN, 1);
	myposition      = new Command("Getdistance", Command.SCREEN, 1);
	menu = new List("appointment",List.IMPLICIT,option,null);
	menu.addCommand(exitCommand);
	menu.setCommandListener(this);
				
                appList.addCommand(backCmd);

				
                appList.setCommandListener(this);
                response = new StringItem(null,null);
                outputForm = new Form("output");
	outputForm.append(response);
	outputForm.addCommand(exitCommand);
	outputForm.setCommandListener(this); 
 	canvas.addCommand(panCommand);
 	canvas.addCommand(zoomCommand);
 	canvas.addCommand(addCommand); 
 	canvas.addCommand(exitCommand);
 	canvas.addCommand(menugetpath);
 	canvas.addCommand(getbusstop);
 	canvas.addCommand(myposition);
 	
    canvas.setCommandListener(this);
       
        
        scheduleDB = new ScheduleDB();
        Checkalert = true ;
        getbus = false;
        AlertThread alertthread;
        alertthread = new AlertThread(this);
        alertthread.start();
    }

    /**
     * Start up the MIDlet by setting the canvas
     * and loading the default SVG font and the splash SVGT image.
     */
    public void startApp() throws MIDletStateChangeException
    {
       try
       {
          display.setCurrent(canvas);
          canvas.repaint();
	  // Loads the default SVG font
	  // This is faster then to load the font from the svg file
          // TinyFont font = HelveticaFont.getFont();
          SVGDocument doc =  canvas.loadSVG("/tinyline/helvetica.svg");
          SVGFontElem font = SVGDocument.getFont(doc,SVG.VAL_DEFAULT_FONTFAMILY);
          SVGDocument.defaultFont = font;
	  // Loads the SVGT image
          canvas.goURL("/svg/map.svg");
       }
       catch( Exception e)
       {
       }
    }

    /** Pause the MIDlet. */
    public void pauseApp()
    {
    }

    /**
     * Destroy the MIDlet.
     * @param unconditional Unconditional flag.
     */
    public void destroyApp(boolean unconditional)
    {
    }

    /**
     * Respond to commands. Commands are added to each screen as
     * they are created.  Each screen uses the TinyLine MIDlet as the
     * CommandListener.
     * @param c the command that triggered this callback
     * @param s the screen that contained the command
     */
    public void commandAction(Command c, Displayable s)
    {
///System.out.println("Command " +c);
       if(c == linkCommand)
       {
	  canvas.type = ViewerCanvas.TYPE_LINK;
       }
       else if(c == panCommand)
       {
          canvas.type = ViewerCanvas.TYPE_PAN;
       }
       else if(c == zoomCommand)
       {
          canvas.type = ViewerCanvas.TYPE_ZOOM;
       }
       else if(c == addCommand)
       {
       		display.setCurrent(menu);
          
       }
      else if(c == List.SELECT_COMMAND && s == menu)
      {
      	switch(menu.getSelectedIndex())
      	
      	{
      		case 0:
      		addApp = new AddAppointment(display,menu,scheduleDB);
          addApp.setAppointment(new j3pAppointment(calendar.getTime()));

			
			display.setCurrent(addApp);
			break;
			
			case 1:				  
				
                appList = new List("Appointments", List.IMPLICIT);

			
                appList.addCommand(backCmd);

			
                appList.setCommandListener(this);

				
                apps= scheduleDB.ShowAllInfo();
				

                for(int i=0; i<apps.size(); i++) 
				{
                    j3pAppointment app= (j3pAppointment) apps.elementAt(i);
                    StringBuffer sb = new StringBuffer();
                    sb.append(app.getTimeString()).append(" ").append(app.getSubject()).append(" ").append(app.getx()).append(" ").append(app.gety());
                    System.out.println(app.gety());
                    appList.append(sb.toString(),null);
                }
				
				display.setCurrent(appList);
				break;    

		  
          
	      default:
			}
			}
       else if(c == exitCommand)
       {
       
          destroyApp(true);
	  notifyDestroyed();
	  
       }
      
        else if (c == menugetpath)
       {
	 //  Circle();
       }
       else if (c == getbusstop)
       {
	   //getbusstop();
		getbus = true;
	   
       }
        else if(s == appList) 
	  {
			
            if(c == List.SELECT_COMMAND) 
			{
                
            }
			
            else if(c == backCmd) 
			{	
				appList = new List("Reminder", List.IMPLICIT);

			
                appList.addCommand(backCmd);

			
                appList.setCommandListener(this);
                display.setCurrent(canvas);
                //Checkalert = true;
            }        
        }
         else if(s == appList1) 
	  {
			
            if(c == List.SELECT_COMMAND) 
			{
                // ���ҧ���������Ѻ���Ѻ�Թ�ص�ҡ�����
                //addApp = new AddAppointment(display, menu, scheduleDB);
                // ��˹���ùѴ���·�������Թ�صŧ����п�Ŵ캹�����
			//	addApp.setAppointment((j3pAppointment) apps.elementAt(appList.getSelectedIndex()));
				// �ʴ����������Ѻ��ùѴ���¹��
			//	display.setCurrent(addApp);
            }
			// ��Ǩ�ͺ��ä�ԡ����觢ͧ Back
            else if(c == backCmd) 
			{	// �ʴ���¡���������٢ͧ��˹���õ�ҧ � 
				
               appList = new List("Reminder", List.IMPLICIT);

				// ��������� BACK �����¡��
                appList.addCommand(backCmd);

				// ��˹�����Ѻ�ѧ����� BACK ���¡��
                appList.setCommandListener(this);
                display.setCurrent(canvas);
                Checkalert = true;
            }        
        }
          else if(c == exitCommand && s == menu) 
	  {
            destroyApp(true);			 // ���������»Ŵ����·�Ѿ�ҡ�
			notifyDestroyed();	// ���ͺ͡��� AMS ��Һ����;���पѹ
							// �ͧ MIDlet �����ʶҹ� Destroyed
      }
	  
     
   }
 
      
    void findplace()
    {
    }

   class AlertThread extends Thread
   {
   	MIDlet mid;
   	int i = 0;
   	public AlertThread(MIDlet mid)
   	{ this.mid = mid; }
   	public void run()
   	{
   		
   		while(Checkalert)
   		{
   			
   		//	a = myX[i] ;
   		//	b = myY[i] ;
   		 	b += 5;
			System.out.println("myposition "+a+" "+b);
   			int[] myposition ;// = getmyposition(count);
   			count++;
   			//checklistplace(myposition[0],myposition[1]);
   			
   		try{
   			
   			 // 5mins 
   			if (getbus) {
   			
   			
   			 busstop = getbusstop();
   			//busstop = new StringItem(null,null);
   			busstop = busstop.substring(1,busstop.length()-1);
			System.out.println("a"+"b");	
   			System.out.println(busstop);
   			getbus = false;
			checkbusstop();
   		
   			}
   			sleep((long)60*1000);
   		
   		}catch (InterruptedException e ){}	
   		
   		}
   		
   	}
   	public String getbusstop()
   	{
   		 HttpConnection cnHttp = null;    

	 
      InputStream is = null;

	 
      OutputStream os = null;
      byte[] receivedData = null;
      try {
	
        String url = "http://localhost:8080/j3pJ2ME/servlet/LoginServlet";
	
		cnHttp = (HttpConnection)Connector.open(url);    
		
	
        cnHttp.setRequestMethod(HttpConnection.POST);

	
        cnHttp.setRequestProperty("User-Agent", "Profile/MIDP-2.0 Configuration/CLDC-1.0");

	   
        cnHttp.setRequestProperty("Content-type", "application/x-www-form-urlencoded");

		
        byte[] sendMsg = sendPostMessage();

		
        os = cnHttp.openOutputStream();

		
        os.write(sendMsg);

		
        is = cnHttp.openInputStream();
  
		  
          receivedData = new byte[1024];
          int ch;
          int len = 0;

		  
          while ((ch = is.read()) != -1) 
		  {
			
            receivedData[len++] = (byte)ch;
          }

	
        response1 = new String(receivedData, 0, len);
		System.out.println(response1.length());
		
      //  display.setCurrent(outputForm);
       // return response1;
      // System.out.println(response);
      }
	 
      catch (IOException ioEx) 
	  {

        System.out.println(ioEx.getMessage());
        ioEx.printStackTrace();
      }
	  
      finally 
	  {
        try {
		  
          if (is != null) 
		  {
			
            is.close();
          }
		 
          if (os != null) 
		  {
		
            os.close();
          }
		 
          if (cnHttp != null) 
		  {
		
            cnHttp.close();
          }
           
        }
        catch (IOException ioEx) { }
        return response1;
      }
   	}
   	 public byte[] sendPostMessage() 
	{
	  
      StringBuffer strBuffer = new StringBuffer();

	 
      strBuffer.append("myX");
	  
	 /* String tmp;
	  Float ftmp;
	  ftmp = new Float(a);
	  tmp = ftmp.toString();*/
      strBuffer.append(a);


      strBuffer.append("&myY=");
	  
	 // tmp = tmp.valueOf(b);
      strBuffer.append(a);


      System.out.println("strBuffer = <" + strBuffer.toString() + ">");

	 
      return strBuffer.toString().getBytes();
    }

    
                }
        
   
    public void checkbusstop()
    {
        
        // Get the raster
        SVGRaster   raster   = canvas.raster;
        // Get the SVGT document
        SVGDocument document = raster.getSVGDocument();
        // Get the root of the SVGT document
        SVGSVGElem root = (SVGSVGElem)document.root;

	// If there is a node with id 'mycircle' then remove it.
	// Otherwise create and add it.
	SVGNode node = SVGNode.getNodeById(root, new TinyString("mycircle".toCharArray()));
	if(node != null)
	{
	   // 3. Fire the update event
	   SVGNode parent = node.parent;
	   int index = parent.children.indexOf(node,0);
           parent.removeChild(index);
           // Repaint the raster.
	   raster.setDevClip(node.getDevBounds(raster));
           raster.paint();
           raster.sendPixels();
            System.out.println("circlenode!=null");
         //  return;
        }

        // Create a new circle element
        SVGEllipseElem circle =
          (SVGEllipseElem)document.createElement(SVG.ELEM_CIRCLE);
        // Add the circle element AFTER the whiteboard element
	node = SVGNode.getNodeById(root, new TinyString("10007".toCharArray()));
	if(node != null)
	{
		System.out.println("node!=null");
	   SVGNode parent = node.parent;
	   int index = parent.children.indexOf(node,0);
           parent.addChild(circle, index + 1);
	}
	
		SVGNode node1 = SVGNode.getNodeById(root, new TinyString("kaset".toCharArray()));
	if(node1 != null)
	{
	   // 3. Fire the update event
	  //  SVGEllipseElem circle1 = node1;
	  // System.out.println("kaset");
	   
		
		//TinyNumber cx1 = circle1.getAttribute(SVG.ATT_CX);  
       // TinyNumber cy1 = node1.getAttribute(2);  
          
        }
        // Use the DOM-like API to change properties
        TinyNumber cx = new TinyNumber(692542<<TinyUtil.FIX_BITS);
        TinyNumber cy = new TinyNumber((-1518220)<<TinyUtil.FIX_BITS);
        TinyNumber r = new TinyNumber(10<<TinyUtil.FIX_BITS);
        TinyNumber stroke_width = new TinyNumber(5<<TinyUtil.FIX_BITS);
        TinyColor fillColor = redColor;
        TinyColor strokeColor = yellowColor;
        try
        {
	   circle.setAttribute(SVG.ATT_ID, new TinyString("mycircle".toCharArray()));
	   circle.setAttribute(SVG.ATT_CX,node1.getAttribute(SVG.ATT_CX));
	   circle.setAttribute(SVG.ATT_CY,node1.getAttribute(SVG.ATT_CY));
	   circle.setAttribute(SVG.ATT_R,r);
	   circle.setAttribute(SVG.ATT_FILL,fillColor);
	   circle.setAttribute(SVG.ATT_STROKE,strokeColor);
	   circle.setAttribute(SVG.ATT_STROKE_WIDTH,stroke_width);
	   // System.out.println(circle.getAttribute(SVG.ATT_CX));
           // Init the element.
           circle.createOutline();
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
	
   // 3. Fire the update event
		  
	           // Repaint the raster.
		   raster.setDevClip(node.getDevBounds(raster));
	       raster.update();
	       raster.sendPixels();
	       System.out.println("circle");
	           

    }
   }

