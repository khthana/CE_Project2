/*
 * PositionMidlet.java
 *
 * Created on 1 ����Ҿѹ�� 2550, 2:58 �.
 */
package tinyapp;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.Vector;
import javax.microedition.rms.*;

import com.tinyline.tiny2d.*;
import com.tinyline.svg.*;


/**
 *
 * @author den
 */
public class PositionMidlet extends MIDlet implements Runnable {
    
    /** Creates a new instance of PositionMidlet */
    public PositionMidlet() {
        initialize();
    }
    
    
    private static final int _ASYNC_NOTHING = 0;
    private int _asyncMethod = _ASYNC_NOTHING;
    private Object[] _asyncParameters = new Object[2];
    
    
// WARNING - "Generate Threaded Command Listeners" document property is deprecated - use WaitScreen components instead.
// It will NOT be possible to open/import this file in the future.
    
    /** This method is run in another thread and communicates with event handlers and provides ability for event processing in different thread.
     **/
    public void run() {
        int asyncMethod;
        Object firstParameter;
        Object secondParameter;
        
        for (;;) {
            // wait and get request for event processing
            synchronized (_asyncParameters) {
                _asyncMethod = _ASYNC_NOTHING;
                _asyncParameters[0] = null;
                _asyncParameters[1] = null;
                try {
                    _asyncParameters.wait();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                asyncMethod = _asyncMethod;
                firstParameter = _asyncParameters[0];
                secondParameter = _asyncParameters[1];
            }
            
        }
    }

    /** This method initializes UI of the application.
     */
    private void initialize() {
        // Insert pre-init code here
        new java.lang.Thread(this).start();
        // Insert post-init code here
    }
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {                         
        return Display.getDisplay(this);
    }                        
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {                         
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }                        
    
    public void startApp() {
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
}
