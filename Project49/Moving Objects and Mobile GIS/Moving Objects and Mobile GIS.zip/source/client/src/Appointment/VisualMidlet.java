/*
 * VisualMidlet.java
 *
 * Created on 13 ����Ҿѹ�� 2550, 4:04 �.
 */

package Appointment;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 *
 * @author den
 */
public class VisualMidlet extends MIDlet implements CommandListener {
    
    /** Creates a new instance of VisualMidlet */
    public VisualMidlet() {
        initialize();
    }
    
    private Command okCommand1;//GEN-BEGIN:MVDFields
    private Form form1;
    private Command exitCommand1;
    private TextField textField1;
    private TextField textField2;//GEN-END:MVDFields
    
//GEN-LINE:MVDMethods

    /** Called by the system to indicate that a command has been invoked on a particular displayable.//GEN-BEGIN:MVDCABegin
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {//GEN-END:MVDCABegin
    // Insert global pre-action code here
//GEN-LINE:MVDCABody
    // Insert global post-action code here
}//GEN-LINE:MVDCAEnd

    /** This method initializes UI of the application.//GEN-BEGIN:MVDInitBegin
     */
    private void initialize() {//GEN-END:MVDInitBegin
        // Insert pre-init code here
        getDisplay().setCurrent(get_form1());//GEN-LINE:MVDInitInit
        // Insert post-init code here
    }//GEN-LINE:MVDInitEnd
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {//GEN-FIRST:MVDGetDisplay
        return Display.getDisplay(this);
    }//GEN-LAST:MVDGetDisplay
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {//GEN-FIRST:MVDExitMidlet
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }//GEN-LAST:MVDExitMidlet
      /** This method returns instance for okCommand1 component and should be called instead of accessing okCommand1 field directly.//GEN-BEGIN:MVDGetBegin5
     * @return Instance for okCommand1 component
     */
    public Command get_okCommand1() {
        if (okCommand1 == null) {//GEN-END:MVDGetBegin5
            // Insert pre-init code here
            okCommand1 = new Command("Ok", Command.OK, 1);//GEN-LINE:MVDGetInit5
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd5
        return okCommand1;
    }//GEN-END:MVDGetEnd5
  
    /** This method returns instance for form1 component and should be called instead of accessing form1 field directly.//GEN-BEGIN:MVDGetBegin9
     * @return Instance for form1 component
     */
    public Form get_form1() {
        if (form1 == null) {//GEN-END:MVDGetBegin9
            // Insert pre-init code here
            form1 = new Form("ChooseTimeLength", new Item[] {//GEN-BEGIN:MVDGetInit9
                get_textField1(),
                get_textField2()
            });//GEN-END:MVDGetInit9
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd9
        return form1;
    }//GEN-END:MVDGetEnd9

    /** This method returns instance for exitCommand1 component and should be called instead of accessing exitCommand1 field directly.//GEN-BEGIN:MVDGetBegin12
     * @return Instance for exitCommand1 component
     */
    public Command get_exitCommand1() {
        if (exitCommand1 == null) {//GEN-END:MVDGetBegin12
            // Insert pre-init code here
            exitCommand1 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit12
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd12
        return exitCommand1;
    }//GEN-END:MVDGetEnd12

    /** This method returns instance for textField1 component and should be called instead of accessing textField1 field directly.//GEN-BEGIN:MVDGetBegin15
     * @return Instance for textField1 component
     */
    public TextField get_textField1() {
        if (textField1 == null) {//GEN-END:MVDGetBegin15
            // Insert pre-init code here
            textField1 = new TextField("timestart", "2007-02-01 08:00:00", 120, TextField.ANY);//GEN-LINE:MVDGetInit15
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd15
        return textField1;
    }//GEN-END:MVDGetEnd15

    /** This method returns instance for textField2 component and should be called instead of accessing textField2 field directly.//GEN-BEGIN:MVDGetBegin16
     * @return Instance for textField2 component
     */
    public TextField get_textField2() {
        if (textField2 == null) {//GEN-END:MVDGetBegin16
            // Insert pre-init code here
            textField2 = new TextField("timeend", "2007-02-01 10:00:00", 120, TextField.ANY);//GEN-LINE:MVDGetInit16
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd16
        return textField2;
    }//GEN-END:MVDGetEnd16
    
    public void startApp() {
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
}
