<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>
<html>
<body>


<%
Class.forName("com.mysql.jdbc.Driver");

Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/project?user=root&password=");

Statement stmt = mycon.createStatement();

%>

</body>
</html>

