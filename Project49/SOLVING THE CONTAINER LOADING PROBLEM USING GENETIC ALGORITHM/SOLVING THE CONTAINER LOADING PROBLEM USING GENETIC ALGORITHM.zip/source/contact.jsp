<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style7 {
	color: #FF0000;
	font-weight: bold;
	font-size: 16px;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#0000ff; text-decoration:none }
a:visited {color: #990066; text-decoration:none}
a:hover { color:#ff0000; text-decoration:none }

.style8 {color: #0000CC}
.style11 {color: #339933}
.style13 {
	color: #990000;
	font-weight: bold;
}
.style15 {color: #990000}

-->
</STYLE>

<script>
<!--

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

</head>

<body onLoad="MM_preloadImages('images/home1.jpg','images/about1.jpg','images/service1.jpg','images/contact1.jpg')">
<table width="770" height="420" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="39" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back_03.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="110" height="39">&nbsp;</td>
        <td width="123" valign="top"><a href="index.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','images/home1.jpg',1)"><img src="images/home.jpg" alt="˹���á" name="home" width="123" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="124" valign="top"><a href="about.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('aboutus','','images/about1.jpg',1)"><img src="images/about.jpg" alt="����ǡѺ���" name="aboutus" width="124" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="121" valign="top"><a href="service.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('service','','images/service1.jpg',1)"><img src="images/service.jpg" alt="��ԡ�âͧ���" name="service" width="121" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="118" valign="top"><a href="contact.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('contact','','images/contact1.jpg',1)"><img src="images/contact.jpg" alt="�Դ������" name="contact" width="119" height="39" border="0"></a></td>
        <td width="133">&nbsp;</td>
      </tr>
    </table>    </td>
    <td width="1"></td>
  </tr>
  <tr>
    <td height="35" colspan="5" valign="top"><img src="images/back_05.jpg" width="770" height="35"></td>
    <td></td>
  </tr>
  <tr>
    <td width="170" height="1"></td>
    <td colspan="4" rowspan="2" valign="top"><img src="images/back1_05.jpg" width="600" height="142"></td>
    <td></td>
  </tr>
  <tr>
    <td rowspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="345" valign="top" bgcolor="#FFFFFF"><img src="images/back_02.jpg" width="169" height="345" /></td>
    </tr>
    </table>    </td>
    <td height="142"></td>
  </tr>
  <tr>
    <td width="18" height="23"></td>
    <td width="13">&nbsp;</td>
    <td width="575">&nbsp;</td>
    <td width="15"></td>
    <td></td>
  </tr>
  <tr>
    <td height="20"></td>
    <td></td>
    <td valign="top" bgcolor="#FFFF00"><div align="center"><span class="style7 style11">�Դ������</span></div></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="29"></td>
    <td></td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  
  
  
  
  
  
  
  
  
  
  <tr>
    <td height="131">&nbsp;</td>
    <td colspan="2" rowspan="2" valign="top"><p class="style7"><img src="images/box1.jpg" width="200" height="149" hspace="10" vspace="5" align="right"></p>
      <p class="style15">�ҡ��ҹ���������ͧ��������բ��ʧ��� ���͵�ͧ������ҧ��һ�Ѻ��ا��С��� ����ö�Դ������������ Email ������ </p>
      <p class="style8"> <strong><a href="mailto:jingjok13@hotmail.com" class="style13">---&gt; jingjok13@hotmail.com (���)</a> <br>
        <a href="mailto:peet_3@hotmail.com">---&gt; peet_3@hotmail.com (�շ)</a> </strong><br> 
      </p></td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  
  
  
  

  
  
  
  
  <tr>
    <td rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="194" valign="top" bgcolor="#FFFFFF"><img src="images/left_02.jpg" width="170" height="194" /></td>
        </tr>
      
      
      
    </table></td>
    <td height="184"></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="10"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
  
  

  <tr>
    <td height="16" colspan="5" valign="top" bgcolor="#FF6600"><div align="right" class="style2"><strong>&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
    <td></td>
  </tr>
</table>
</body>
</html>
