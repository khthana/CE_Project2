<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style4 {
	color: #FFFFFF;
	font-size: 16px;
}
.style7 {
	color: #FF0000;
	font-weight: bold;
	font-size: 16px;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#0000ff; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#ff0000; text-decoration:none }
-->
</STYLE>

<script>
<!--
function validate() {
	
		if(f.user.value == ""){
				alert("��سҡ�͡ username")
				f.user.select();
				return false;
		}
	
		
		if (f.pwd.value == "") {
			alert ("��سҡ�͡ password");
			f.pwd.select();
			return false;
		}
		
	} //end function

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

</head>

<body onLoad="MM_preloadImages('images/home1.jpg','images/about1.jpg','images/service1.jpg','images/contact1.jpg')">
<table width="770" height="420" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="39" colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back_03.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="110" height="39">&nbsp;</td>
        <td width="123" valign="top"><a href="index.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','images/home1.jpg',1)"><img src="images/home.jpg" alt="˹���á" name="home" width="123" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="124" valign="top"><a href="about.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('aboutus','','images/about1.jpg',1)"><img src="images/about.jpg" alt="����ǡѺ���" name="aboutus" width="124" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="121" valign="top"><a href="service.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('service','','images/service1.jpg',1)"><img src="images/service.jpg" alt="��ԡ�âͧ���" name="service" width="121" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="118" valign="top"><a href="contact.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('contact','','images/contact1.jpg',1)"><img src="images/contact.jpg" alt="�Դ������" name="contact" width="119" height="39" border="0"></a></td>
        <td width="133">&nbsp;</td>
      </tr>
    </table>
    </td>
    <td width="1"></td>
  </tr>
  <tr>
    <td height="35" colspan="2" valign="top"><img src="images/back_05.jpg" width="770" height="35"></td>
    <td></td>
  </tr>
  <tr>
    <td width="170" height="1"></td>
    <td width="600" rowspan="2" valign="top"><img src="images/back_04.jpg" width="600" height="143" /></td>
    <td></td>
  </tr>
  <tr>
    <td rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="345" valign="top" bgcolor="#FFFFFF"><img src="images/back_02.jpg" width="169" height="345" /></td>
    </tr>
    </table>    </td>
    <td height="142"></td>
  </tr>
  <tr>
    <td height="31">&nbsp;</td>
    <td></td>
  </tr>
  
  
  <tr>
    <td rowspan="2" align="center" valign="middle"><form id="f" name="f" method="post" action="chkUser.jsp" onSubmit="return validate()">
      <table width="325" height="201" border="0" align="center" cellpadding="5" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#CC0000">
        <!--DWLayoutTable-->
        <tr>
          <td height="41" colspan="2" class="style2"><div align="center" class="style4">�������к� </div></td>
          </tr>
        <tr>
          <td width="128" class="style2">Username</td>
            <td width="177"><input name="user" type="text" id="user" /></td>
          </tr>
        <tr>
          <td class="style2">Password</td>
            <td><input name="pwd" type="password" id="pwd" maxlength="16" /></td>
          </tr>
        <tr>
          <td height="47" colspan="2"><div align="center">
            <input type="submit" name="Submit" value="Log in" />
            &nbsp;&nbsp;&nbsp;
            <input type="reset" name="Submit2" value="Reset" />
            </div></td>
          </tr>
        <tr>
          <td height="19"></td>
            <td></td>
          </tr>
        <tr>
          <td height="30" colspan="2"  bgcolor="#FFFF00"><div align="center" class="style7">
            <div align="center" class="style7"><a href="frmRegist.jsp">--&gt; ��Ѥ���Ҫԡ���� &lt;--</a></div>
          </div></td>
          </tr>
        <tr>
          <td height="30" colspan="2"  bgcolor="#FFFF66" class="style7"><div align="center"><a href="intro.jsp" target="_blank">--&gt; �йӡ����ҹ�к� &lt;--</a> </div></td>
        </tr>
        </table>
    </form></td>
    <td height="172"></td>
  </tr>
  
  
  
  
  
  <tr>
    <td rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="194" valign="top" bgcolor="#FFFFFF"><img src="images/left_02.jpg" width="170" height="194" /></td>
        </tr>
      
      
      
    </table></td>
    <td height="141"></td>
  </tr>
  <tr>
    <td height="53"></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="16" colspan="2" valign="top" bgcolor="#FF6600"><div align="right" class="style2"><strong>&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
    <td></td>
  </tr>
</table>
</body>
</html>
