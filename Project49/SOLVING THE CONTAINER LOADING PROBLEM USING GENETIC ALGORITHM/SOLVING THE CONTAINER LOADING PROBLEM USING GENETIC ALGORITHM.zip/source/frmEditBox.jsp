<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}
//-----------get memid-------------------------

String mem_id = request.getParameter("memid");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//-----------get boxid-------------------------

String box_id = request.getParameter("boxid");

if(box_id == ""){

	response.sendRedirect("mainMember.jsp");
}

//-----------�֧�����š��ͧ���ʴ�---------------------

String sql = "select * from box where mem_id = '"+mem_id+"' and box_id = '"+box_id+"'";

ResultSet rs = stmt.executeQuery(sql);

%>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>��䢢����š��ͧ</title>
<style type="text/css">
<!--
.style2 {	color: #FFFF00;
	font-weight: bold;
}
.style21 {color: #CC0000}
.style22 {	color: #FFFFFF;
	font-weight: bold;
}
.style26 {font-size: 16px}
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	background-color: #CCCCCC;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#cc0033; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#0066cc; text-decoration:none }

.style23 {color: #0033FF}
.style24 {
	color: #000066;
	font-weight: bold;
	font-size: 16px;
}
.style26 {font-size: 16px}
.style28 {color: #FF0066}
-->
</STYLE>

<script>

	function validate() {
	
		if(form1.boxName.value == "") {
				alert("��سҡ�͡���͡��ͧ���ͪ����Թ���")
				form1.boxName.select();
				return false;
		}
	
		if(form1.width.value == "" ||
			isNaN( form1.width.value ) ||
			form1.width.value.indexOf(" ") >= 0 ||
			form1.width.value == 0 ) {
				alert("��سҡ�͡�������ҧ���١��ͧ")
				form1.width.select();
				return false;
		}
		
		if(form1.length.value == "" ||
			isNaN( form1.length.value ) ||
			form1.length.value.indexOf(" ") >= 0 ||
			form1.length.value == 0){
				alert("��سҡ�͡����������١��ͧ")
				form1.length.select();
				return false;
		}
		
		if(form1.depth.value == "" ||
			isNaN( form1.depth.value ) ||
			form1.depth.value.indexOf(" ") >= 0 ||
			form1.depth.value == 0){
				alert("��سҡ�͡�����֡���١��ͧ")
				form1.depth.select();
				return false;
		}
		
		if(form1.weight.value == "" ||
			isNaN( form1.weight.value ) ||
			form1.weight.value.indexOf(" ") >= 0 ||
			form1.weight.value == 0){
				alert("��سҡ�͡���˹ѡ���١��ͧ")
				form1.weight.select();
				return false;
		}
		
		if(form1.numbox.value == "" ||
			isNaN( form1.numbox.value ) ||
			form1.numbox.value.indexOf(" ") >= 0 ||
			form1.numbox.value == 0){
				alert("��سҡ�͡�ӹǹ���ͧ���١��ͧ")
				form1.numbox.select();
				return false;
		}
	
		
			
	} //end function
	
</script>

</head>

<body>

<table width="770" height="630" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
<tr>
<td height="159" colspan="3"><img src="images/back2.jpg" width="770" height="178"></td>
</tr>
<tr>
  <td width="161" height="40">&nbsp;</td>
  <td width="448">&nbsp;</td>
  <td width="161">&nbsp;</td>
</tr>
<tr>
  <td height="300" colspan="3" valign="top">
    <form id="form1" name="form1" method="post" action="updateBox.jsp?memid=<%=mem_id%>&boxid=<%=box_id%>" onSubmit="return validate()">
      <table width="450" height="298" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#CC9900">
        
        <%  
 while(rs.next()) { 
 
 		String boxname = rs.getString("box_name");
		String boxname2 = new String(boxname.getBytes("ISO8859_1"),"TIS-620");%> 
        
        <tr>
          <td height="41" colspan="2" bgcolor="#993300"><div align="center" class="style22 style26">��䢢����š��ͧ </div></td>
          </tr>
        <tr>
          <td width="189" class="style2">���͡��ͧ/�����Թ���</td>
            <td width="221" class="style2"><input name="boxName" type="text" id="boxName" value="<%= boxname2%>" size="30"></td>
          </tr>
        <tr>
          <td class="style2">�������ҧ</td>
            <td class="style2"><input name="width" type="text" id="width" value="<%= rs.getString("box_width")%>" size="10" maxlength="7" />
(cm.) </td>
          </tr>
        <tr>
          <td class="style2">�����٧</td>
            <td class="style2"><input name="length" type="text" id="length" value="<%= rs.getString("box_length")%>" size="10" maxlength="7" />
(cm.) </td>
          </tr>
        <tr>
          <td class="style2">�����֡</td>
            <td class="style2"><input name="depth" type="text" id="depth" value="<%= rs.getString("box_depth")%>" size="10" maxlength="7" />
(cm.) </td>
          </tr>
        <tr>
          <td class="style2">���˹ѡ</td>
            <td class="style2"><input name="weight" type="text" id="weight" value="<%= rs.getString("box_weight")%>" size="10" maxlength="7" />
(kg.) </td>
          </tr>
        <tr>
          <td height="32"><span class="style2">�ӹǹ���ͧ</span></td>
          <td height="32"><span class="style2">
            <input name="numbox" type="text" id="numbox" value="<%= rs.getString("box_num")%>" size="10" maxlength="5" />
          </span></td>
        </tr>
        <tr>
          <td height="65" colspan="2"><div align="center">
            <input name="edit" type="submit" class="style21" id="edit" value="��䢢�����" />
          </div></td>
        </tr>
        
        <% } // end loop %> 	
        </table>
    </form></td>
</tr>
<tr>
  <td height="25">&nbsp;</td>
  <td valign="top" bgcolor="#FFFF00" class="style26"><div align="center"><strong><a href="mainMember.jsp?id=<%=mem_id%>">----&gt; ��Ѻ�˹����ѡ &lt;----</a> </strong></div></td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="51">&nbsp;</td>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td height="16" colspan="3" valign="top" bgcolor="#FF6600"><div align="right"><strong class="style2">&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
</tr>
</table>
</body>
</html>

<%
rs.close();
stmt.close();
mycon.close();
%>
