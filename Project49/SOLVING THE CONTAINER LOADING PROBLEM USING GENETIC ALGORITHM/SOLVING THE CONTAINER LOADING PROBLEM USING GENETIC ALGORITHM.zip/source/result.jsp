<%@ page contentType="text/html; charset=windows-874" language="java" 
import="java.sql.*" 
import ="java.io.*"
import ="java.util.*"
import ="java.util.Vector"
import ="java.util.Arrays"
errorPage="" %>

<%!
	
	int totalnumbox = 0;
	String color[] = {"#00ffff" , "#00ff00" , "#ffff00" , "#ff00ff" , "#ff0000" ,"#0000ff","#666666","#cccccc","#ffffff","#000066"};
	Vector bname = new Vector();
%>
<%@ include file = "connect.jsp" %>


<%//----------------create bean ------------------------%>

<jsp:useBean id="ga" class="projectbean.GAContainer" />
<jsp:useBean id="call" class="projectbean.Call3D" />



		
<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}
//-----------get memid-------------------------

String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
	
}

//-----------get r_NO ��� �ӹǹ���駷��ӹǳ -------------------------

String r_NO = request.getParameter("r_NO");

if(r_NO == ""){

	response.sendRedirect("mainMember.jsp");
	
}

//--------------�Ѻ��ҡ�����͡�ӹǳ�������� bear -------------------------

String bear = request.getParameter("bear");

if(bear == ""){

	response.sendRedirect("mainMember.jsp");
	
}

%>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>���Ѿ���äӹǳ</title>
<style type="text/css">
<!--
.style2 {	color: #FFFF00;
	font-weight: bold;
}
.style26 {font-size: 16px}
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	background-color: #CCCCCC;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#cc0033; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#0066cc; text-decoration:none }

.style26 {font-size: 16px}
.style34 {color: #FF6600; font-weight: bold; }
.style35 {color: #0000FF}
.style36 {font-size: 16px; color: #CC0000; }
.style37 {color: #CC0000}
.style38 {color: #0000FF; font-weight: bold; }
-->
</STYLE>

</head>

<body>

<table width="770" height="630" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="178" colspan="3" valign="top"><img src="images/back2.jpg" width="770" height="178"></td>
  </tr>
  <tr>
    <td width="86" height="35">&nbsp;</td>
    <td width="600">&nbsp;</td>
    <td width="85">&nbsp;</td>
  </tr>
  <tr>
    <td height="89">&nbsp;</td>
    <td valign="top"><table width="600" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#0099FF" bgcolor="#FFFFFF">
      <!--DWLayoutTable-->
      <tr>
        <td height="27" colspan="7" bgcolor="#00CC99" class="style2 style26"><div align="center">�����š��ͧ㹡�äӹǳ���駷�� <%=r_NO%> </div></td>
      </tr>
      <tr>
        <td width="31" height="31"><div align="center"><span class="style34">Box NO. </span></div></td>
        <td width="135" class="style34"><div align="center">���͡��ͧ/�����Թ���</div></td>
        <td width="76"><div align="center"><span class="style34">�������ҧ</span></div></td>
        <td width="64"><div align="center"><span class="style34">�����٧</span></div></td>
        <td width="63"><div align="center"><span class="style34">�����֡</span></div></td>
        <td width="58"><div align="center"><span class="style34">���˹ѡ</span></div></td>
        <td width="87"><div align="center"><span class="style34">�ӹǹ���ͧ</span></div></td>
      </tr>
      <%
	  
	  	//-----------------------�֧�����š��ͧ���ʴ�---------------------

		String sql = "select * from result where mem_id = '"+mem_id+"' and r_NO = '"+r_NO+"'order by r_NO desc ";
		
		ResultSet rs = stmt.executeQuery(sql);

		int x = 1;
		while(rs.next()) { 
			
					
		String r_boxname = rs.getString("r_box_name");
		String r_boxname2 = new String(r_boxname.getBytes("ISO8859_1"),"TIS-620");
		
		
		
		//-------------------------------------------------------
	%>
      <tr>
        <td height="28" class="style35"><div align="center"><span class="style35"></span><%= x++%></div></td>
        <td class="style35"><div align="left"><%= r_boxname2%></div></td>
        <td class="style35"><div align="center"><span class="style35"></span><%= rs.getString("r_box_width")%></div></td>
        <td class="style35"><div align="center"><span class="style35"></span><%= rs.getString("r_box_length")%></div></td>
        <td class="style35"><div align="center"><span class="style35"></span><%= rs.getString("r_box_depth")%></div></td>
        <td class="style35"><div align="center"><span class="style35"></span><%= rs.getString("r_box_weight")%></div></td>
        <td class="style35"><div align="center"><span class="style35"></span><%= rs.getString("r_box_num")%></div></td>
      </tr>
      <% } //end loop%>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="21"></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
  
  <td height="153"></td>
  <td valign="top">
  
    
  <table width="600" border="1" cellpadding="5" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#66FFFF">
    <!--DWLayoutTable-->
    <tr>
      <td height="30" colspan="4" bgcolor="#0000CC" class="style2 style26"><div align="center">���Ѿ���äӹǳ</div></td>
      </tr>
    <tr>
      <td width="129" height="28" class="style38"><div align="center">����ҵõ��͹�ù����</div></td>
      <td width="161" class="style38"><div align="center">����ҵá��ͧ������������§��</div></td>
      <td width="107" class="style38"><div align="center">�ӹǹ���ͧ������</div></td>
      <td width="153" class="style38"><div align="center">�ӹǹ���ͧ������<br>
        ������§��</div></td>
    </tr>


<% 

String sql5 = "select r_box_name,sum(r_box_num) from result where mem_id = '"+mem_id+"' and r_NO = '"+r_NO+"' group by r_box_name ";
		
	ResultSet rs5 = stmt.executeQuery(sql5);
	
	totalnumbox = 0;
	Vector bname = new Vector();
	while(rs5.next()){
		
		String total = rs5.getString("sum(r_box_num)");
		
		totalnumbox = totalnumbox + Integer.parseInt(total);
		bname.add(rs5.getString("r_box_name"));
		
		
	}	
	
	

	String sql3 = "select * from total where mem_id = '"+mem_id+"' and r_NO = '"+r_NO+"'order by total_id";
		
	ResultSet rs3 = stmt.executeQuery(sql3);
		
	//------------ ����բ����ż��Ѿ���äӹǳ����㹵��ҧ total ���� ��� �¤ӹǳ������ ------------	
	if(rs3.next()){
	
	
		//-----------------------�ʴ���§ҹ���Ѿ���èѴ���§���ͧ---------------------

			String sql2 = "select * from total where mem_id = '"+mem_id+"' and r_NO = '"+r_NO+"'order by total_id";
			
			ResultSet rs2 = stmt.executeQuery(sql2);
	
			
			while(rs2.next()) { 
			
		
		%> 
			
		
		
    <tr>
      <td height="26" class="style37"><div align="center"><%=233*220*587%></div></td>
  
      <td class="style37"><div align="center"><%=rs2.getString("total_vol")%></div></td>
      <td class="style37"><div align="center"><%=totalnumbox%></div></td>
  <td class="style37"><div align="center"><%=rs2.getString("total_numbox")%></div></td>
    </tr>
  
  <% } // end while loop
			rs2.close();
			
			int memid = Integer.parseInt(mem_id);
			int rNO = Integer.parseInt(r_NO);
			call.callPic3D(memid , rNO, bname);
			
	} // end if
	
	
	//--------����ѧ����¤ӹǳ��èѴ���§���ͧ��� ������¡��������ͤӹǳ ��� redirect ��Ѻ�ҷ��˹�ҹ���ա���������ʴ����Ѿ��	---------
	else {
	
		
		int memid = Integer.parseInt(mem_id);
		int rNO = Integer.parseInt(r_NO);
		int bear1 = Integer.parseInt(bear);
		
			
		//********* call java bean *********//
		ga.doGA(memid , rNO , bear1);
		//**********************************//
				
		response.sendRedirect("result.jsp?id="+mem_id+"&r_NO="+r_NO+"&bear="+bear+"");	
		
	} // end else
		
		
	%>
</table>


<table width="600" height="96" border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFF66">
<tr>
  <td height="31" colspan="3" bgcolor="#FF9900"><div align="center" class="style2">�ʴ���������´�ͧ���ͧ������§��</div></td>
  <tr>
  <td width="172" height="28" class="style38"><div align="center">���͡��ͧ/�����Թ���</div></td>
  <td width="182" class="style38"><div align="center">�ӹǹ���ͧ������§��</div></td>
  <td width="200" class="style38"><div align="center">�բͧ���ͧ</div></td>
  
 <% String sql4 = "select bname , count(*) from pic3D where mem_id = '"+mem_id+"' and r_NO = '"+r_NO+"'group by bname";
		
	ResultSet rs4 = stmt.executeQuery(sql4);
		
	//------------ ����բ����ż��Ѿ���äӹǳ����㹵��ҧ pic3D ���� ��� �¤ӹǳ������ ------------	
	int i = 0;
	while(rs4.next()){
	
	String boxname = rs4.getString("bname");
	String boxname2 = new String(boxname.getBytes("ISO8859_1"),"TIS-620");
	
	 
%>
	
	
<tr>
  <td height="27" class="style37"><div align="center"><%=boxname2%></div></td>
  <td class="style37"><div align="center"><%=rs4.getString("count(*)")%></div></td>
  <td bgcolor="<%=color[i]%>" class="style37"><div align="center"></div></td>
  
	
	
<% i++;

	} //end loop while%> 
 
</table>
</td>
<td></td>
</tr>
<tr>
  <td height="50"></td>
  <td>&nbsp;</td>
  <td></td>
</tr>
<tr>
  <td height="21"></td>
  <td valign="top" bgcolor="#FFFF00" class="style36"><div align="center"><strong><a href="mainMember.jsp?id=<%=mem_id%>">----&gt; ��Ѻ�˹����ѡ &lt;----</a> </strong> </div></td>
  <td></td>
</tr>
<tr>
  <td height="62"></td>
  <td>&nbsp;</td>
  <td></td>
</tr>
<tr>
  <td height="21" colspan="3" valign="top" bgcolor="#FF6600"><div align="right"><strong class="style2">&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
</tr>
</table>


<%
rs4.close();
rs.close();
rs3.close();
stmt.close();
mycon.close();
%>
</body>
</html>