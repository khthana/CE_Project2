package projectbean;
import java.io.*;
import java.util.*;

class Point3D{
	
	public double pos_x0, pos_y0, pos_z0;
	public double pos_x1, pos_y1, pos_z1;
	public double pos_x2, pos_y2, pos_z2;
	public double pos_x3, pos_y3, pos_z3;
	public double pos_x4, pos_y4, pos_z4;
	public double pos_x5, pos_y5, pos_z5;
	public double pos_x6, pos_y6, pos_z6;
	public double pos_x7, pos_y7, pos_z7;
	

	
	
	//--------------- set point------------------------
		
	public void setPoint0(double x, double y, double z){
		
		pos_x0 = x;
		pos_y0 = y;
		pos_z0 = z;
		
		
	}
	
	public void setPoint1(double x, double y, double z){
		
		pos_x1 = x;
		pos_y1 = y;
		pos_z1 = z;
		
		
	}
	
	public void setPoint2(double x, double y, double z){
		
		pos_x2 = x;
		pos_y2 = y;
		pos_z2 = z;
		
		
	}
	
	public void setPoint3(double x, double y, double z){
		
		pos_x3 = x;
		pos_y3 = y;
		pos_z3 = z;
		
		
	}
	
	public void setPoint4(double x, double y, double z){
		
		pos_x4 = x;
		pos_y4 = y;
		pos_z4 = z;
		
		
	}
	
	public void setPoint5(double x, double y, double z){
		
		pos_x5 = x;
		pos_y5 = y;
		pos_z5 = z;
		
		
	}
	
	public void setPoint6(double x, double y, double z){
		
		pos_x6 = x;
		pos_y6 = y;
		pos_z6 = z;
		
		
	}
	
	public void setPoint7(double x, double y, double z){
		
		pos_x7 = x;
		pos_y7 = y;
		pos_z7 = z;
		
		
	}
	
	//---------------------- get point pos_0 -----------------------
	
	public double getPoint_x0(){
		
		return pos_x0;
	}
	
	public double getPoint_y0(){
		
		return pos_y0;
	}
	
	public double getPoint_z0(){
		
		return pos_z0;
	}
	
	//---------------------- get point pos_1 -----------------------
	
	public double getPoint_x1(){
		
		return pos_x1;
	}
	
	public double getPoint_y1(){
		
		return pos_y1;
	}
	
	public double getPoint_z1(){
		
		return pos_z1;
	}
	
	//---------------------- get point pos_2 -----------------------
	
	public double getPoint_x2(){
		
		return pos_x2;
	}
	
	public double getPoint_y2(){
		
		return pos_y2;
	}
	
	public double getPoint_z2(){
		
		return pos_z2;
	}

	//---------------------- get point pos_3 -----------------------
	
	public double getPoint_x3(){
		
		return pos_x3;
	}
	
	public double getPoint_y3(){
		
		return pos_y3;
	}
	
	public double getPoint_z3(){
		
		return pos_z3;
	}

	//---------------------- get point pos_4 -----------------------
	
	public double getPoint_x4(){
		
		return pos_x4;
	}
	
	public double getPoint_y4(){
		
		return pos_y4;
	}
	
	public double getPoint_z4(){
		
		return pos_z4;
	}

	
	//---------------------- get point pos_5 -----------------------
	
	public double getPoint_x5(){
		
		return pos_x5;
	}
	
	public double getPoint_y5(){
		
		return pos_y5;
	}
	
	public double getPoint_z5(){
		
		return pos_z5;
	}


	//---------------------- get point pos_6 -----------------------
	
	public double getPoint_x6(){
		
		return pos_x6;
	}
	
	public double getPoint_y6(){
		
		return pos_y6;
	}
	
	public double getPoint_z6(){
		
		return pos_z6;
	}

	
	//---------------------- get point pos_7 -----------------------
	
	public double getPoint_x7(){
		
		return pos_x7;
	}
	
	public double getPoint_y7(){
		
		return pos_y7;
	}
	
	public double getPoint_z7(){
		
		return pos_z7;
	}

	
	public void showPoint(){
		
//	System.out.println("*********** show point 3D ************");
		
		System.out.println("point x0 = " + getPoint_x0());
		System.out.println("point y0 = " + getPoint_y0());
		System.out.println("point z0 = " + getPoint_z0());
		System.out.println();
		
		System.out.println("point x1 = " + getPoint_x1());
		System.out.println("point y1 = " + getPoint_y1());
		System.out.println("point z1 = " + getPoint_z1());
		System.out.println();
		
		System.out.println("point x2 = " + getPoint_x2());
		System.out.println("point y2 = " + getPoint_y2());
		System.out.println("point z2 = " + getPoint_z2());
		System.out.println();
		
		System.out.println("point x3 = " + getPoint_x3());
		System.out.println("point y3 = " + getPoint_y3());
		System.out.println("point z3 = " + getPoint_z3());
		System.out.println();
		
		System.out.println("point x4 = " + getPoint_x4());
		System.out.println("point y4 = " + getPoint_y4());
		System.out.println("point z4 = " + getPoint_z4());
		System.out.println();
		
		System.out.println("point x5 = " + getPoint_x5());
		System.out.println("point y5 = " + getPoint_y5());
		System.out.println("point z5 = " + getPoint_z5());
		System.out.println();
		
		System.out.println("point x6 = " + getPoint_x6());
		System.out.println("point y6 = " + getPoint_y6());
		System.out.println("point z6 = " + getPoint_z6());
		System.out.println();
		
		System.out.println("point x7 = " + getPoint_x7());
		System.out.println("point y7 = " + getPoint_y7());
		System.out.println("point z7 = " + getPoint_z7());
		System.out.println();
	}
	
		public static void main(String[] args) throws Exception, StackOverflowError {
			
			ChromosomeTowerSet c = new ChromosomeTowerSet();
			System.out.println("sol = " + c.sol);
			for (int j = 0; j < c.sol.size(); j++){
				
				Tower t = (Tower)c.sol.get(j);
				System.out.println("sol = " + c.sol);
				
			}

	}
}