package projectbean;
import java.io.*;
import java.util.*;

class Corner {
	private double cornerx;
	private double cornery;
	private double cwidth;
	
	
	public void setCorner(double x, double y, double c){
		cornerx = x;
		cornery = y;
		cwidth = c;
	}
	
	public void setCwidth(double c){
		cwidth = c;
	}
	
	public void setCornery(double y){
		cornery = y;
	}
	
	
	
	public double getCornerx(){
		
		return cornerx;
	}
	
	public double getCornery(){
		
		return cornery;
	}
	
	public double getCwidth(){
		
		return cwidth;
	}
	
	public void showCorner(){
		
		System.out.print("   corner x = " + getCornerx());
		System.out.print("   corner y = " + getCornery());
		System.out.print("   reswidth = " + getCwidth());
		System.out.println();
	}
}