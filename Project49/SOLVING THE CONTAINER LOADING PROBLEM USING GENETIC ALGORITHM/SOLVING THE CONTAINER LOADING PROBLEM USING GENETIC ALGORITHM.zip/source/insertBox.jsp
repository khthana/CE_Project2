<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<html>
<body>

<%
String boxName = request.getParameter("boxName");
String width = request.getParameter("width");
String length = request.getParameter("length");
String depth = request.getParameter("depth");
String weight = request.getParameter("weight");
String numbox = request.getParameter("numbox");
String mem_id = request.getParameter("id");

//----------get mem_id---------------------
if(mem_id == ""){

	response.sendRedirect("mainMember.jsp");
}

//----------insert data box in database ----------------
String sql = "insert into box(box_id ,box_name ,box_width ,box_length ,box_depth ,box_weight ,box_num ,mem_id) values('','"+boxName+"','"+width+"','"+length+"','"+depth+"','"+weight+"','"+numbox+"','"+mem_id+"')";

int myresult = stmt.executeUpdate(sql);

if(myresult != 0){
		
			out.println("<script>alert('���������š��ͧ���º��������');</script>");
						
		}	
		else{
		
			out.println("<script>alert('���������š��ͧ��������');history.back();</script>");
			
		}
		

stmt.close();
mycon.close();


%>

<script>
	
	window.location = "mainMember.jsp?id=<%=mem_id%>";

</script>

</body>
</html>
