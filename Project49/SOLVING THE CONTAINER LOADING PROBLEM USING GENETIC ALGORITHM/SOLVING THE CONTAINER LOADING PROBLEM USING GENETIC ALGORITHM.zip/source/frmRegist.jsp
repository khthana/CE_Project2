<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style12 {color: #006600; font-weight: bold; }
.style13 {color: #FF0000}
.style16 {color: #FFFF00; font-weight: bold; font-size: 16px; }
.style19 {color: #FF0000; font-weight: bold; }
.style20 {color: #000000; font-weight: bold; }
.style21 {font-weight: bold}
.style22 {font-weight: bold}
-->
</style>

<script>
<!--
function validate() {
	
		if(f.user.value == ""){
				alert("��سҡ�͡ username")
				f.user.select();
				return false;
		}
	
		
		if (	f.pwd.value.length < 8 || 
				f.pwd.value.length > 16) {
			alert ("��سҡ�͡ password 8-16 ���");
			f.pwd.select();
			return false;
		}
		
		if (	f.conf_pwd.value.length < 8 || 
				f.conf_pwd.value.length > 16) {
			alert ("��سҡ�͡ confirm password 8-16 ���");
			f.conf_pwd.select();
			return false;
		}
		
		if (	f.pwd.value != f.conf_pwd.value) {
			alert ("��سҡ�͡ confirm password ���ç�Ѻ password ���¨��");
			f.conf_pwd.select();
			return false;
		}
		
		if(f.fname.value == ""){
				alert("��سҡ�͡ ����")
				f.fname.select();
				return false;
		}
		
		if(f.lname.value == ""){
				alert("��سҡ�͡ ���ʡ��")
				f.lname.select();
				return false;
		}
		
		// if( �������¡��� 8 || ��ͧ����� @ 㹵��˹觷����¡��� 4 ||...)
		if(	f.email.value.length < 8 ||
				f.email.value.indexOf("@") < 3  ||
				f.email.value.indexOf(".") < 1||
				f.email.value.indexOf("@.") >= 0 ||
				f.email.value.indexOf(" ") >= 0) {
			alert("��سҡ�͡ email ���١��ͧ���¨��"); // show alert box
			f.email.select(); //hilight text in the box
			return false; //��ش��÷ӧҹ
		} //end if
		
		if (isNaN( f.tel.value ) ) {
			alert ("��سҡ�͡�������Ѿ��ͧ��ҹ���١��ͧ") ;
			f.tel.select();
			return false;
		}
	
	} //end function

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>


</head>

<body onLoad="MM_preloadImages('images/about1.jpg','images/home1.jpg','images/service1.jpg','images/contact1.jpg')">
<table width="770" height="759" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="39" colspan="6" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back_03.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="110" height="39">&nbsp;</td>
        <td width="123" valign="top"><a href="index.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','images/home1.jpg',1)"><img src="images/home.jpg" alt="˹���á" name="home" width="123" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="124" valign="top"><a href="about.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('aboutus','','images/about1.jpg',1)"><img src="images/about.jpg" alt="����ǡѺ���" name="aboutus" width="124" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="121" valign="top"><a href="service.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('service','','images/service1.jpg',1)"><img src="images/service.jpg" alt="��ԡ�âͧ���" name="service" width="121" height="39" border="0"></a></td>
        <td width="13">&nbsp;</td>
        <td width="118" valign="top"><a href="contact.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('contact','','images/contact1.jpg',1)"><img src="images/contact.jpg" alt="�Դ������" name="contact" width="119" height="39" border="0"></a></td>
        <td width="133">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1"></td>
  </tr>
  <tr>
    <td height="35" colspan="6" valign="top"><img src="images/back_05.jpg" width="770" height="35"></td>
    <td></td>
  </tr>
  <tr>
    <td width="170" height="1"></td>
    <td colspan="5" rowspan="2" valign="top"><img src="images/back1_05.jpg" width="600" height="142"></td>
  <td></td>
  </tr>
  
  <tr>
    <td rowspan="6" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="345" valign="top"><img src="images/back_02.jpg" width="170" height="345" /></td>
        </tr>
      
      
    </table></td>
    <td height="142"></td>
  </tr>
  <tr>
    <td width="49" height="38">&nbsp;</td>
    <td width="10"></td>
    <td width="470"></td>
    <td width="20"></td>
    <td width="51">&nbsp;</td>
    <td></td>
  </tr>
  
  
  <tr>
    <td height="97">&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top" bgcolor="#FFFF33"><div align="center"><span class="style19"><br />
      ��سҡ�͡���������ú��ǹ���ͷӡ����Ѥ���Ҫԡ�ͧ�к� <br />
      �ҡ��鹷�ҹ������ö�����ҹ�к���èѴ���§���ͧ㹵��͹�ù������ <br />
    �·ҧ��Ҩ����ѡ�Ң����Ţͧ��ҹ��������ҧ�� </span></div></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="47"></td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="20"></td>
    <td colspan="3" valign="top" bgcolor="#006600"><div align="center"><span class="style16">��Ѥ���Ҫԡ����</span></div></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="1"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  <tr>
    <td height="351" colspan="6" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="169" rowspan="2" valign="top" bgcolor="#FFFFFF"><img src="images/left_02.jpg" width="170" height="236" /></td>
    <td width="601" height="331" valign="top"><form id="f" name="f" method="post" action="insertMem.jsp" onSubmit="return validate()">
      <table width="500" height="325" align="center" cellpadding="4" cellspacing="0" bgcolor="#99CC00">
        <!--DWLayoutTable-->
        
        
        <tr>
          <td width="152" height="26" class="style12">Username</td>
              <td width="332"><input name="user" type="text" id="user" maxlength="25" /> 
                <span class="style13">*</span> </td>
            </tr>
        <tr>
          <td height="32" class="style12">Password</td>
              <td><input name="pwd" type="password" id="pwd" maxlength="16" />
                <span class="style13">* (8-16 ���) </span></td>
            </tr>
        <tr>
          <td height="30" class="style12">Confirm Password </td>
              <td><input name="conf_pwd" type="password" id="conf_pwd" maxlength="16" />
                <span class="style13">* (8-16 ���) </span></td>
            </tr>
        <tr>
          <td height="28" class="style12">����</td>
              <td><input name="fname" type="text" id="fname" maxlength="50" />
                <span class="style13">*</span></td>
            </tr>
        <tr>
          <td height="31" class="style12">���ʡ��</td>
              <td><input name="lname" type="text" id="lname" maxlength="50" />
                <span class="style13">*</span></td>
            </tr>
        <tr>
          <td height="26" class="style12">Email</td>
              <td><input name="email" type="text" id="email" size="30" maxlength="50" />
                <span class="style13">*</span></td>
            </tr>
        <tr>
          <td height="26" class="style12">�������</td>
              <td><textarea name="address" cols="40" id="address"></textarea></td>
            </tr>
        <tr>
          <td height="26" class="style12">������</td>
              <td><input name="tel" type="text" id="tel" size="10" maxlength="10" /></td>
            </tr>
        <tr>
          <td height="30" class="style2"><span class="style12">���ͺ���ѷ</span></td>
            <td height="30" class="style2"><input name="company" type="text" id="company" size="30" /></td>
        </tr>
        <tr>
          <td height="39" colspan="2" class="style2"><div align="center" class="style20">
  <input name="Submit" type="submit" class="style19" value="Submit" />
  &nbsp;&nbsp;
  <input name="Submit2" type="reset" class="style22" value="Reset" />
          </div></td>
        </tr>
        </table>
    </form></td>
    </tr>
      
      <tr>
        <td height="20"></td>
        </tr>
    </table>    </td>
    <td></td>
  </tr>
  
  
  <tr>
    <td height="16" colspan="6" valign="top" bgcolor="#FF6600"><div align="right"><span class="style2"><strong>&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></span></div>
    <a href="about.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('about','','images/about1.jpg',1)"></a></td>
    <td></td>
  </tr>
</table>
</body>
</html>
