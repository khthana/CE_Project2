<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//----------get mem_id---------------------
String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//---------�֧�����š��ͧ�ҡ�ҹ���������ʴ�-----------------

String sql = "select * from member where mem_id = '"+mem_id+"' ";

ResultSet rs = stmt.executeQuery(sql);

%>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style21 {color: #CC0000}
.style22 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#cc0033; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#0066cc; text-decoration:none }

.style23 {color: #0033FF}
.style28 {color: #FF0066}
.style32 {font-size: 16px}
.style12 {color: #006600; font-weight: bold; }
.style13 {color: #FF0000}
.style19 {color: #FF0000; font-weight: bold; }
.style20 {color: #000000; font-weight: bold; }
.style34 {font-weight: bold}
.style16 {color: #FFFF00; font-weight: bold; font-size: 16px; }
-->
</STYLE>

<script>

	function validate() {
	
		if(f.fname.value == ""){
				alert("��سҡ�͡ ����")
				f.fname.select();
				return false;
		}
		
		if(f.lname.value == ""){
				alert("��سҡ�͡ ���ʡ��")
				f.lname.select();
				return false;
		}
		
		// if( �������¡��� 8 || ��ͧ����� @ 㹵��˹觷����¡��� 4 ||...)
		if(	f.email.value.length < 8 ||
				f.email.value.indexOf("@") < 3  ||
				f.email.value.indexOf(".") < 1||
				f.email.value.indexOf("@.") >= 0 ||
				f.email.value.indexOf(" ") >= 0) {
			alert("��سҡ�͡ email ���١��ͧ���¨��"); // show alert box
			f.email.select(); //hilight text in the box
			return false; //��ش��÷ӧҹ
		} //end if
		
		if (isNaN( f.tel.value ) ) {
			alert ("��سҡ�͡�������Ѿ��ͧ��ҹ���١��ͧ") ;
			f.tel.select();
			return false;
		}
	
	} //end function
</script>
</head>

<body>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="35" colspan="6" valign="top"><img src="images/back1_02.jpg" width="770" height="35"></td>
  </tr>
  <tr>
    <td width="170" rowspan="4" valign="top"><table width="169" border="0" cellpadding="0" cellspacing="0" background="images/back_02.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="8" height="83">&nbsp;</td>
          <td width="138">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="23">&nbsp;</td>
        </tr>
      <tr>
        <td height="86"></td>
          <td colspan="2" valign="top"><p align="left" class="style22 style23">��ǹ�����ҹ�����</p>          <p class="style21"> <a href="mainMember.jsp?id=<%=mem_id%>">--&gt; ��ҹ�����</a> <br>
           <a href="resultHis.jsp?id=<%=mem_id%>">--&gt; �ټ��Ѿ��</a></p></td>
          <td>&nbsp;</td>
        </tr>
      <tr>
        <td height="16"></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      <tr>
        <td height="95"></td>
          <td valign="top"><p class="style21"><span class="style22 style28">��ǹ�����Ţͧ user</span></p>          <p class="style21"><strong>--&gt; ��䢢�������ǹ���</strong><br>
              <a href="frmChangePwd.jsp?id=<%=mem_id%>">--&gt; ����¹ password</a><br>
          <a href="logout.jsp">--&gt; Log out</a></p></td>
          <td></td>
          <td></td>
        </tr>
      <tr>
        <td height="63"></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      
      
      
      
      
      
      
      
      
      
    </table></td>
    <td height="142" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back1_05.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="12" height="116">&nbsp;</td>
        <td width="573">&nbsp;</td>
        <td width="15">&nbsp;</td>
      </tr>
      <tr>
        <td height="26">&nbsp;</td>
        <td valign="top"><span class="style22 style32">User : <%= session.getAttribute("sess_user")%> </span></td>
      <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td width="22" height="25"></td>
    <td width="27"></td>
    <td width="500">&nbsp;</td>
    <td width="27"></td>
    <td width="24"></td>
  </tr>
  <tr>
    <td height="20"></td>
    <td></td>
    <td valign="top" bgcolor="#006600"><div align="center"><span class="style16">��䢢�������ǹ���</span></div></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  <tr>
    <td height="156"></td>
    <td colspan="3" rowspan="2" valign="top"><form action="updateMember.jsp?id=<%=mem_id%>" method="post" name="f" id="f" onSubmit="return validate()">
      <table width="500" height="208" align="center" cellpadding="4" cellspacing="0" bgcolor="#99CC00">
        <!--DWLayoutTable-->

<%  
 while(rs.next()) { 
 
 	String fname = rs.getString("mem_fname");
	String fname2 = new String(fname.getBytes("ISO8859_1"),"TIS-620");
	
	String lname = rs.getString("mem_lname");
	String lname2 = new String(lname.getBytes("ISO8859_1"),"TIS-620");
	
	String address = rs.getString("mem_address");
	String address2 = new String(address.getBytes("ISO8859_1"),"TIS-620");
	
	String com = rs.getString("mem_com");
	String com2 = new String(com.getBytes("ISO8859_1"),"TIS-620");
	%>

        <tr>
          <td width="152" height="28" class="style12">����</td>
          <td width="332"><input name="fname" type="text" id="fname" value="<%= fname2%>" maxlength="50" /></td>
        </tr>
        <tr>
          <td height="31" class="style12">���ʡ��</td>
          <td><input name="lname" type="text" id="lname" value="<%= lname2%>" maxlength="50" /></td>
        </tr>
        <tr>
          <td height="26" class="style12">Email</td>
          <td><input name="email" type="text" id="email" value="<%= rs.getString("mem_email")%>" size="30" maxlength="50" /></td>
        </tr>
        <tr>
          <td height="26" class="style12">�������</td>
          <td><textarea name="address" cols="40" id="address"><%= address2%>
</textarea></td>
        </tr>
        <tr>
          <td height="26" class="style12">������</td>
          <td><input name="tel" type="text" id="tel" value="<%= rs.getString("mem_tel")%>" size="10" maxlength="10" /></td>
        </tr>
        <tr>
          <td height="30" class="style2"><span class="style12">���ͺ���ѷ</span></td>
          <td height="30" class="style2"><input name="company" type="text" id="company" value="<%= com2%>" size="30" /></td>
        </tr>
        <tr>
          <td height="39" colspan="2" class="style2"><div align="center" class="style20">
              <input name="Submit" type="submit" class="style19" value="Submit" />
          </div></td>
        </tr>
		
<% } // end loop %> 
      </table>
        </form>    </td>
    <td></td>
  </tr>
  
  
  <tr>
    <td rowspan="2" valign="top"><table width="169" border="0" cellpadding="0" cellspacing="0" background="images/left_02.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="234">&nbsp;</td>
        </tr>
    </table></td>
    <td height="219"></td>
    <td></td>
  </tr>
  <tr>
    <td height="15"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  
  
  
  
  
  <tr>
    <td height="18" colspan="6" valign="top" bgcolor="#FF6600"><div align="right"><strong class="style2">&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
  </tr>
</table>
</body>
</html>
<%
rs.close();
stmt.close();
mycon.close();
%>