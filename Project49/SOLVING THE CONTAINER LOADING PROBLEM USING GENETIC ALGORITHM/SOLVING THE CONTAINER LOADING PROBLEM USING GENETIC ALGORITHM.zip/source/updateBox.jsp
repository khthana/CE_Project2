<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<html>
<body>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//-----------get memid-------------------------

String mem_id = request.getParameter("memid");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//-----------get boxid-------------------------

String box_id = request.getParameter("boxid");

if(box_id == ""){

	response.sendRedirect("mainMember.jsp");
}

//-----------------�Ѻ��ҨҡẺ�����-----------------
String boxName = request.getParameter("boxName");
String width = request.getParameter("width");
String length = request.getParameter("length");
String depth = request.getParameter("depth");
String weight = request.getParameter("weight");
String numbox = request.getParameter("numbox");

//------------------update  box ------------------

String sql = "update box set box_name = '"+boxName+"' ,box_width = '"+width+"' , box_length = '"+length+"' ,box_depth = '"+depth+"', box_weight = '"+weight+"', box_num = '"+numbox+"' where mem_id = '"+mem_id+"' and box_id = '"+box_id+"'";

int myresult = stmt.executeUpdate(sql);

if(myresult != 0){
		
			out.println("<script>alert('��䢢����š��ͧ���º��������');</script>");
						
		}	
		else{
		
			out.println("<script>alert('��䢢����š��ͧ��������');history.back();</script>");
			
		}
		
stmt.close();
mycon.close();

%>

<script>
	
	window.location = "mainMember.jsp?id=<%=mem_id%>";

</script>


</body>
</html>
