<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<html>
<body>
<%


String user = request.getParameter("user");
String pwd = request.getParameter("pwd");
String fname = request.getParameter("fname");
String lname = request.getParameter("lname");
String email = request.getParameter("email");
String address = request.getParameter("address");
String tel = request.getParameter("tel");
String company = request.getParameter("company");

//-------- check user ��ҫ�ӡѺ㹰ҹ��������� ------------------

String sql = "select count(*) as num from member where mem_user = '"+user+"' ";
				
ResultSet rs = stmt.executeQuery(sql);

while(rs.next()){
	
	//��� user ��ӡѹ
	if(rs.getInt("num") == 1){
		out.println("<script>alert ('username ����դ����������');history.back();	</script>");
					
	
	}
	
	else{
	
		sql = "	insert into member values('','"+user+"','"+pwd+"','"+fname+"','"+lname+"','"+email+"','"+address+"','"+tel+"','"+company+"')";
				
		int myresult = stmt.executeUpdate(sql);
		
		if(myresult != 0){
		
			out.println("<script>alert('��Ѥ���Ҫԡ���º��������');</script>");
						
		}	
		else{
		
			out.println("<script>alert('��Ѥ���Ҫԡ��������');</script>");
			
		}
	}

}

rs.close();
stmt.close();
mycon.close();



%>

<script>
	
	window.location = "index.jsp";

</script>

</body>
</html>