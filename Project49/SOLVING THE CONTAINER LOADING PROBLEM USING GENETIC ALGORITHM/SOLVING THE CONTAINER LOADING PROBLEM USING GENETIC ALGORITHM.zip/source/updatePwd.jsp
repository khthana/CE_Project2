<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<html>
<body>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//----------get mem_id---------------------
String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//-----------------�Ѻ��ҨҡẺ�����-----------------

String old_pwd = request.getParameter("old_pwd");
String new_pwd = request.getParameter("new_pwd");

//----------------------------------------------

String sql = "select * from member where mem_id = '"+mem_id+"' and mem_pwd = '"+old_pwd+"'";

ResultSet rs = stmt.executeQuery(sql);

if(rs.next()){

	//------------------update  password ------------------

	String sql2 = "update member set mem_pwd = '"+new_pwd+"' where mem_id = '"+mem_id+"' ";

	int myresult = stmt.executeUpdate(sql2);
	
	if(myresult != 0){
		
			out.println("<script>alert('��� password ���º��������');</script>");
						
	}	
	else{
		
			out.println("<script>alert('��� password ��������');history.back();</script>");
			
	}



}

else{

	out.println("<script>alert('password �Դ');history.back();</script>");
}


rs.close();
stmt.close();
mycon.close();

%>

<script>
	
	window.location = "mainMember.jsp?id=<%=mem_id%>";

</script>

</body>
</html>
