package projectbean;
import java.io.*;
import java.util.*;

class CreateTower {
	
		
	Boxes tspace = new Boxes();				//tower space
	Boxes newbmax = null;					//placed box
	Tower t;

	
	private double xstack, ystack, zstack; 	//size of Tower space stack
	
	
	Stack Tstack = new Stack();				//Tower space stack
	
	
	public boolean doCreateTower(Boxes newbox, Boxes bbasis, Vector v, Tower t , int bear) {
		

		double cx = 233, cy = 220, cz = 587; 	//size of container
		double cornx = 0,corny = 0,cornz = 0;	//coordinate of tspace
		
	/*	System.out.println("b width = " + b.bdimx);
		System.out.println("b height = " + b.bdimy);
		System.out.println("b depth = " + b.bdimz);
		
		System.out.println("b cornx = " + b.bcornx);
		System.out.println("b corny = " + b.bcorny);
		System.out.println("b cornz = " + b.bcornz);
	*/	
	
		t.tboxes.add(newbox);
		v.remove(bbasis);
		
	
		
	//	System.out.println("box in Tower = " + t.tboxes);
		
		
		for(int i = 0 ; i < t.tboxes.size() ; i++){
			
			Boxes b = (Boxes)t.tboxes.get(i);
			
			System.out.println("Vol box = " + b.volBox());
		}
				
		xstack = newbox.getBdimx();
		ystack = cy - newbox.getBdimy();
		zstack = newbox.getBdimz();
		
		corny = newbox.getBdimy();
		
		
		tspace.setBoxes(xstack, ystack, zstack);
		tspace.setCoordinate(cornx, corny, cornz);
		
		Tstack.push(tspace);
		
		
		
		
		while (Tstack.empty() == false ) {
			tspace = (Boxes)Tstack.pop();
			
//				System.out.println("tspace width = " + tspace.getBdimx());
//				System.out.println("tspace height = " + tspace.getBdimy());
//				System.out.println("tspace depth = " + tspace.getBdimz());
			
			Boxes bmax = detbmax(v);
			
			if(bear == 1){
				
				bmax = checkBear(bmax , t);	
//				System.out.println("bmax already check bear = " + bmax);
				
			}
			
			
						
			if (bmax != null) {
				
				Boxes newbmax = new Boxes();
				
				newbmax.setBoxes(bmax.getBdimx(), bmax.getBdimy(), bmax.getBdimz());
				
				newbmax.setWeight(bmax.getWeight());
				newbmax.setMemid(bmax.getMemid());
				newbmax.setRid(bmax.getRid());
				newbmax.setRno(bmax.getRno());
				newbmax.setBoxname(bmax.getBoxname());
				
				newbmax = rotbest(newbmax);
				newbmax.setCoordinate(tspace.getBcornx(), tspace.getBcorny(), tspace.getBcornz());
				
			
/*				System.out.println("newbmax width = " + newbmax.getBdimx());
				System.out.println("newbmax height = " + newbmax.getBdimy());
				System.out.println("newbmax depth = " + newbmax.getBdimz());
				
				System.out.println("newbmax cornx = " + newbmax.getBcornx());
				System.out.println("newbmax corny = " + newbmax.getBcorny());
				System.out.println("newbmax cornz = " + newbmax.getBcornz());
				System.out.println();
*/			
				t.tboxes.add(newbmax);
				
				System.out.println("box bmax in Tower = " + t.tboxes);
								
				detnewtspace(newbmax);
				
				
				v.remove(bmax);
				
						
				completetower(t);
				
				
				
//				System.out.println("V = " + v);
			}
			
		}
		
		if(t.tboxes.size() == 1){
			
			completetower(t);
		}
		
		
//		System.out.println("all box in tower = " + t.tboxes);
		
		return true;
	}
	
	
public Boxes checkBear(Boxes b_placed , Tower t){
		
	double bearbbasis = 0 , beartotalbmax = 0 ;
	double wbbasis = 0 ,total_wbmax = 0 ;
	double areabmax = 0, areab_placed = 0 , areabbasis = 0;
	
	Vector tempT = new Vector();
	
	if(b_placed == null){
		
		return null;
	}
	
	for(int i =0 ; i<t.tboxes.size() ; i++){
		
		Boxes b = (Boxes)t.tboxes.get(i);
		tempT.add(b);
		
//		System.out.println("tempT = " + tempT);
	}
	
	while(tempT.size() != 0){		
		
		
		for(int i =0 ; i<tempT.size() ; i++){
			
			Boxes b = (Boxes)tempT.get(i);
			
			if(i == 0){
				
				wbbasis = b.getWeight();
				areabbasis = b.areaBox();
				
				bearbbasis = wbbasis / areabbasis;
			}
			
			if(i == 1){
				
				areabmax = b.areaBox();
				
			}
			
					
			if(i > 0){
				
				
				total_wbmax = total_wbmax + b.getWeight();
				
							
			}
		}
			
					
			double weight = total_wbmax + b_placed.getWeight();
			
			if(tempT.size() == 1){
				
				areab_placed = b_placed.areaBox();
						
				beartotalbmax = weight / areab_placed;
			}
			
			else{
				
				beartotalbmax = weight / areabmax;
			}
			
			
			if(beartotalbmax <= bearbbasis){
				
				Boxes bbasis = (Boxes)tempT.get(0);
				
				tempT.remove(bbasis);	
								
				
			}
			
			else{
				
				return null;
			}
		
		
	}	
	
	return b_placed;	
}
	
	
	
	public Boxes detbmax(Vector v){
		
	
			for (int i=0; i < v.size(); i++){
				
				Boxes b = (Boxes)v.get(i);
				
									
				if (
				
					b.getBdimx() <= tspace.getBdimx() &&
					b.getBdimy() <= tspace.getBdimy() &&
					b.getBdimz() <= tspace.getBdimz() 
				
					){
						
				
						
//					System.out.println("!!!! Bmax !!!! " + b.volBox());					
					return b;
					
				}
				
//				System.out.println("!!!! not Bmax !!!! " + b.volBox());	
				
			}
			return null;
		
	}
	
	
	public Boxes rotbest(Boxes b){
		
		if (b.getBdimx() == tspace.getBdimx() ||
			b.getBdimz() == tspace.getBdimz()){
			return b;
			}
			
		if (b.getBdimx() == tspace.getBdimz() ||
			b.getBdimz() == tspace.getBdimx()){
			b.setBoxes(b.getBdimy(), b.getBdimx(), b.getBdimz());
			return b;	
			}
			
		return b;
	}
	
	public void detnewtspace(Boxes newbmax){
		
		Boxes tfront = new Boxes();
		Boxes tbeside = new Boxes();
		Boxes tabove = new Boxes();
		double spacecornx, spacecorny, spacecornz;	//temp coordinate of tspace
	
		
		//find tower space front
		xstack = tspace.getBdimx();
		ystack = tspace.getBdimy();
		zstack = tspace.getBdimz() - newbmax.getBdimz();
		
		spacecornx = tspace.getBcornx();
		spacecorny = tspace.getBcorny();
		spacecornz = tspace.getBcornz() + newbmax.getBdimz();
		
		tfront.setBoxes(xstack, ystack, zstack);
		tfront.setCoordinate(spacecornx, spacecorny, spacecornz);
		
//		System.out.println("box tfront = " + tfront.volBox());
		
		Tstack.push(tfront);
					
		//find tower space beside
		xstack = tspace.getBdimx() - newbmax.getBdimx();
		ystack = tspace.getBdimy();
		zstack = newbmax.getBdimz();
		
		spacecornx = tspace.getBcornx() + newbmax.getBdimx();
		spacecorny = tspace.getBcorny();
		spacecornz = tspace.getBcornz();

		tbeside.setBoxes(xstack, ystack, zstack);
		tbeside.setCoordinate(spacecornx, spacecorny, spacecornz);
		Tstack.push(tbeside);
					
		//find tower space above
		xstack = newbmax.getBdimx();
		ystack = tspace.getBdimy() - newbmax.getBdimy();
		zstack = newbmax.getBdimz();
		
		spacecornx = tspace.getBcornx();
		spacecorny = tspace.getBcorny() + newbmax.getBdimy();
		spacecornz = tspace.getBcornz();
		
		tabove.setBoxes(xstack, ystack, zstack);
		tabove.setCoordinate(spacecornx, spacecorny, spacecornz);
		Tstack.push(tabove);
	}
	
	public void completetower(Tower t){
		
		double tempvalue = 0, tempArea = 0;
		double temptloss = 0;
		double xstack,ystack,zstack;
		double cy = 220;
		
//		System.out.println("tower t in completetower = " + t.tboxes);
		
		Boxes base = (Boxes)t.tboxes.get(0);
		
		t.setTdim(base.getBdimz() , base.getBdimx());
			
		for (int i=0; i<t.tboxes.size(); i++){
			
			Boxes b = (Boxes)t.tboxes.get(i);
			
			
			tempvalue = tempvalue + b.volBox();
		
		}
		
		Boxes bbasis = (Boxes)t.tboxes.get(0);
		xstack = bbasis.getBdimx();
		zstack = bbasis.getBdimz();
		ystack = cy - bbasis.getBdimy();
		Boxes tspace = new Boxes();
		tspace.setBoxes(xstack,ystack,zstack);
		temptloss = tspace.volBox()-(tempvalue - bbasis.volBox());
		t.setLossTower(temptloss);
		
		t.setValueTower(tempvalue);
		
		t.setAreaTower(bbasis.areaBox());
		
	}
	
	
		
}