package projectbean;
import com.sun.j3d.utils.applet.MainFrame;
import java.util.*;

public class Call3D{
	
	public void callPic3D(int memid , int rNO, Vector bname){
		
	
		
		MainFrame obj = new MainFrame(new Pic3D(memid , rNO, bname), 750, 550);
	}
	
	
}