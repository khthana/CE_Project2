package projectbean;
import java.io.*;
import java.util.*;
import java.sql.*;
import com.sun.j3d.utils.applet.MainFrame;
import java.text.DecimalFormat;

public class GAContainer {
	
	DecimalFormat decfitness = new DecimalFormat("0.0000");
		
	private int yc = 233;
	
	private int POPULATIONS_SIZE = 50;

	private Vector populations;
	
	public void doGA(int memid, int rNO , int bear) throws Exception, StackOverflowError {
		
		
		int count = 0;
		double bestfitness = 0;
		
		
		initPopulations(memid , rNO , bear);
		 
		evaluate();
		sortPopulations(populations);
		
		while (count<1000) {
			
		//	System.out.print("[count = " + count + "]");
		//	printPopulations(0);
			
			ChromosomeTowerSet c = (ChromosomeTowerSet)populations.get(0);
			if (c.getFitness() == bestfitness){
				count++;
			}
				bestfitness = c.getFitness();
				
				int random = (int) (Math.random() * 10);
				if (random>4){
					crossover();
				} else {
					mutation();
				}
			evaluate();
			elitism();
			sortPopulations(populations);
		}
			
		//	printChromosome();
		
			
		do3D(memid , rNO);
	}
	
	//**************************** initPopulations ***********************//
	
	public void initPopulations(int memid, int rNO , int bear) throws Exception , StackOverflowError {
		populations = new Vector(); 
	
		CreateTowerSet c = new CreateTowerSet();
		c.doCreateTowerSet(memid , rNO , bear);
		
		Vector test = new Vector();

		for (int i = 0; i < c.tset.size(); i++){
			((Tower)c.tset.get(i)).setID(i);
		}
		
		for (int i = 0; i < POPULATIONS_SIZE; i++) {
		populations.add(initChormosomeTowerSet(c.tset));
		}

	}
	
	public ChromosomeTowerSet initChormosomeTowerSet(Vector v) {
		ChromosomeTowerSet ct = new ChromosomeTowerSet();
		Vector temptset = new Vector(v);
		int RANDOM;
		int RANDOM_TROT;
		double totalspace = 0;
		
		while (temptset.size()!=0 /*&& totalspace < 136771*/){
			int TEMP_SIZE = temptset.size();
			RANDOM = (int) (Math.random() * TEMP_SIZE);

			Tower t = new Tower((Tower)temptset.remove(RANDOM));
			RANDOM_TROT = (int) (Math.random() * 2);
			t.setTrot(RANDOM_TROT);
			totalspace = totalspace + t.getTarea();
			//System.out.println(t.tboxes);////////////////////
			ct.chromosome.add(t);

		}
		return ct;
	}
	
//**************************** evaluate ***********************//

	public void evaluate(){
		for (int i=0; i<populations.size(); i++){
			ChromosomeTowerSet c = (ChromosomeTowerSet)populations.get(i);
	
			Vector cset = new Vector();
			Vector tempsol = new Vector();
			double value = 0,towerarea = 0;
			Corner corner = new Corner();
			corner.setCorner(0,0,yc);
			cset.add(corner);
			int index = 0;
			
			while(index<c.chromosome.size()){
				if (cset.size() == 0){
					break;
				}
				
		//		for(int j = 0 ; j<cset.size() ;j++){
					
		//			Corner cor = (Corner)cset.get(j);
		//			System.out.println("all corner in cset = " + cor.getCornerx() + " " + cor.getCornery());
		//		}
				
				Corner firstcorn = (Corner)cset.get(0);
				
		//		firstcorn.showCorner();				
				//Tower t = (Tower)c.chromosome.get(index);////////////
				Tower tsol = new Tower((Tower)c.chromosome.get(index));
				
		//		System.out.println("tx = " + tsol.getTdimx() + "ty = " + tsol.getTdimy());

				double reswidth = detReswidth(firstcorn, tsol);
				if (reswidth>=0){
					if((firstcorn.getCornerx()+tsol.getTdimx())<=587){
						tsol.setTcorn(firstcorn.getCornerx(), firstcorn.getCornery());
						tsol.rotateTower();
						tempsol.add(tsol);
						value = value + tsol.getTvalue();
						towerarea = towerarea + tsol.getTarea();
						detCorner(firstcorn,tsol,cset);
						
						
						
						sortCorner(cset);
						index++;
					} else {
						cset.remove(firstcorn);
					}
					
				}else{
					cset.remove(0);
					
				}
			}
			String text = decfitness.format((value)/(587*233*220));
			double tempfitness = Double.parseDouble(text);
			c.setFitness(tempfitness);
			c.sol = new Vector(tempsol);
		}
				
	}
	

	
/*	public double detReswidth(Corner corn, Tower t){
		double tempreswidth = 0;
		tempreswidth = corn.getCwidth() - t.getTdimy();
		if (tempreswidth >= 0){
			return tempreswidth;
		} else {
			t.swap();
			tempreswidth = corn.getCwidth() - t.getTdimy();
			return tempreswidth;
		}
	}*/
	
	public double detReswidth(Corner corn, Tower t){
		double tempreswidth = 0;
		if(t.getTrot()==0){
		tempreswidth = corn.getCwidth() - t.getTdimy();
		} else {
			t.swap();
			tempreswidth = corn.getCwidth() - t.getTdimy();
		}
		if (tempreswidth >= 0){
			return tempreswidth;
		} else {
			if(t.getTrot()==0){
				t.setTrot(1);
			} else {
				t.setTrot(0) ;
			}
			t.swap();
			tempreswidth = corn.getCwidth() - t.getTdimy();
			return tempreswidth;
		}
	}
	
	public void detCorner(Corner corn,Tower tsol,Vector cset){

		double tempcornx1,tempcorny1,tempcwidth1;
		double tempcornx2,tempcorny2,tempcwidth2;
		cset.remove(corn);
		Vector tempcset = new Vector(cset);
		
		Corner topcorn = new Corner();
		tempcornx1 = corn.getCornerx();
		tempcorny1 = corn.getCornery() + tsol.getTdimy();
		tempcwidth1 = corn.getCwidth() - tsol.getTdimy();
		topcorn.setCorner(tempcornx1, tempcorny1, tempcwidth1);
		//cset.add(topcorn);
		
		Corner downcorn = new Corner();
		tempcornx2 = corn.getCornerx() + tsol.getTdimx();
		tempcorny2 = corn.getCornery();
		tempcwidth2 = corn.getCwidth();
		downcorn.setCorner(tempcornx2, tempcorny2, tempcwidth2);

		for(int i=0; i<tempcset.size(); i++){					///loop design corner
			Corner testcorn = (Corner)cset.get(i);
			if(downcorn.getCornerx() > testcorn.getCornerx()){
		//		if(downcorn.getCornery() >= testcorn.getCornery() ){
					
					downcorn.setCornery(testcorn.getCornery());
					downcorn.setCwidth(testcorn.getCwidth());
					testcorn.setCwidth(corn.getCornery() - testcorn.getCornery());
		//		}
			
			}
			if(downcorn.getCornerx() == testcorn.getCornerx()){
				downcorn.setCorner(testcorn.getCornerx(),testcorn.getCornery(),testcorn.getCwidth());
			}
		}
		
		cset.add(topcorn);
		cset.add(downcorn);


	}
	
//*********************** crossover *******************************//

public void crossover(){
		ChromosomeTowerSet p1 = (ChromosomeTowerSet)populations.get(0);
		ChromosomeTowerSet p2 = (ChromosomeTowerSet)populations.get(getRandomPopulation());
		Vector tail_p1 = new Vector();	//tail from parent1
		Vector tail_p2 = new Vector();	//tail from parent2
		ChromosomeTowerSet c1 = new ChromosomeTowerSet();
		ChromosomeTowerSet c2 = new ChromosomeTowerSet();
		
		if (p1.chromosome.size()>p2.chromosome.size()){
			ChromosomeTowerSet p3 = p1;
			p1 = p2;
			p2 = p3;
		}
		int sizep1 = p1.chromosome.size();
		int sizep2 = p2.chromosome.size();
		int posp1[] = new int[sizep1];
		int posp2[] = new int[sizep2];
		
		for (int ind=0; ind<sizep1; ind++){
			int index = (int) (Math.random() * 2);
			posp1[ind] = index;
			posp2[ind] = index;
		}
		
		for (int i=0; i<sizep1; i++){
			if (posp1[i] == 1){
				Tower t1 = (Tower)p1.chromosome.get(i);
				tail_p1.add(t1);
			}
		}
		
		for (int j=0; j<sizep2; j++){
			if (posp2[j] == 1){
				Tower t2 = (Tower)p2.chromosome.get(j);
				tail_p2.add(t2);
			}
		}
		
		for (int k=0; k<p1.chromosome.size(); k++){
			if (posp1[k] == 1){
				c1.chromosome.add(p2.chromosome.get(k));
			} else {
				c1.chromosome.add(pmx((Tower)p1.chromosome.get(k),tail_p2,tail_p1));
			}
		}
		
		for (int l=0; l<p2.chromosome.size(); l++){
			if (posp2[l] == 1){
				c2.chromosome.add(p1.chromosome.get(l));
			} else {
				c2.chromosome.add(pmx((Tower)p2.chromosome.get(l),tail_p1,tail_p2));
			}
		}
		populations.add(c1);
		populations.add(c2);
		
	}
	
	public Tower pmx(Tower t1,Vector v1,Vector v2){
		Tower t2 = new Tower();
		for(int i=0; i < v1.size(); i++){
			t2 = (Tower)v1.get(i);
			if (t1.getID() == t2.getID()){
				//System.out.println("same box");
				return pmx((Tower)v2.get(i),v1,v2);
			}	
		}
		return t1;
	}
	
	//**************************** mutation ***********************//
	
	public void mutation(){
		ChromosomeTowerSet p = (ChromosomeTowerSet)populations.get(getRandomPopulation());
		ChromosomeTowerSet c = new ChromosomeTowerSet();
		Vector vecmut1 = new Vector();
		Vector vecmut2 = new Vector();
		int position[] = new int[p.chromosome.size()];
		
		int positionmutation = (int) (Math.random() * p.chromosome.size());
		int tempsize = p.chromosome.size() - positionmutation;
		int sizemutation = (int) (Math.random() * tempsize);
		
		for (int i=positionmutation; i<(positionmutation+sizemutation); i++){
			position[i] = 1;
		}
		
		for (int j=0; j<sizemutation; j++){
			vecmut1.add((Tower)p.chromosome.get(positionmutation));
			positionmutation++;
		}
		
		for (int k=(vecmut1.size()-1); k>=0; k--){
			vecmut2.add((Tower)vecmut1.get(k));
		}
		
		int index=0;
		for (int m=0; m<p.chromosome.size(); m++){
			if(position[m]==1){
				c.chromosome.add((Tower)vecmut2.get(index));
				index++;
			}else{
				c.chromosome.add((Tower)p.chromosome.get(m));
			}
		}
		
		populations.add(c);
	}
	
	
	public int getRandomPopulation() { 
		return (int) (Math.random() * POPULATIONS_SIZE); 
	}
	
	//**************************** printChromosome ***********************//
	
	public void printChromosome() {
		System.out.println("printChromosome");
		for (int i = 0; i < populations.size(); i++){
			ChromosomeTowerSet c = (ChromosomeTowerSet) populations.get(i);
			System.out.print("["+ i + "]");
			for (int j = 0; j < c.sol.size(); j++){
				Tower t = (Tower)c.sol.get(j);
				System.out.print(t.getID()+" ");
			}
			System.out.print("[" + c.getFitness() + "]");
			System.out.println("chromosome");
		}
		System.out.println();
	}
	
	//**************************** sortCorner ***********************//
	
	public void sortCorner(Vector cset){
	
			
		int index, indexOfNextMin;
		int size = cset.size();
		
		for(index = 0 ; index < size - 1 ; index++){
			
			indexOfNextMin = indexOfNextMin(index , cset);
			
			interchange(index, indexOfNextMin ,cset);
		}	
		
			
	}


	private int indexOfNextMin(int startIndex , Vector v){
		
		double min = 0, num = 0;
		int index;
		
		Corner c = (Corner)v.elementAt(startIndex);
		min = c.getCornerx();
		
		int indexOfMin = startIndex;
		int size = v.size();
		
		for(index = startIndex + 1 ; index < size ; index++){
			
			Corner tempCorner = (Corner)v.elementAt(index);
			
			num = tempCorner.getCornerx();
		
		
			if(num < min){
				
				min = num;
				indexOfMin = index;
				
			}
			
			if(num == min){
				
				min = c.getCornery();
				
				num = tempCorner.getCornery();
				
				if(num < min){
					
					min = num;
					indexOfMin = index;
					
				}
				
			}
			
		}
		
		return indexOfMin;
	}

	private void interchange(int i, int j , Vector v){
	
		Corner temp1 = (Corner)v.elementAt(i);
		Corner temp2 = (Corner)v.elementAt(j);
		
		v.setElementAt(temp1,j);
		v.setElementAt(temp2,i);
	
	}
	
	//************************* sortPopulations ***********************//
	
	public void sortPopulations(Vector populations){
	
			
		int index, indexOfNextMin;
		int size = populations.size();
		
		for(index = 0 ; index < size - 1 ; index++){
			
			indexOfNextMin = indexOfNextMinFitness(index , populations);
			
			interchangeFitness(index, indexOfNextMin ,populations);
		}	
	
		
	}


	private int indexOfNextMinFitness(int startIndex , Vector v){
		
		double min = 0, num = 0;
		int index;
		
		ChromosomeTowerSet c = (ChromosomeTowerSet)v.elementAt(startIndex);
		min = c.getFitness();
		
		int indexOfMin = startIndex;
		int size = v.size();
		
		for(index = startIndex + 1 ; index < size ; index++){
			
			ChromosomeTowerSet tempchromosome = (ChromosomeTowerSet)v.elementAt(index);
			
			num = tempchromosome.getFitness();
		
		
			if(num > min){
				
				min = num;
				indexOfMin = index;
				
			}
			
		}
		
		return indexOfMin;
	}

	private void interchangeFitness(int i, int j , Vector v){
	
		ChromosomeTowerSet temp1 = (ChromosomeTowerSet)v.elementAt(i);
		ChromosomeTowerSet temp2 = (ChromosomeTowerSet)v.elementAt(j);
		
		v.setElementAt(temp1,j);
		v.setElementAt(temp2,i);
	
	}
	
	//************************ elitism *********************//
	
		public void elitism(){
		Vector temppop = new Vector();
		Vector temp = new Vector();
		for(int i=POPULATIONS_SIZE; i<populations.size(); i++){
			ChromosomeTowerSet ct1 = (ChromosomeTowerSet)populations.get(i);
			for(int j=0; j<POPULATIONS_SIZE; j++){
				ChromosomeTowerSet ct2 = (ChromosomeTowerSet)populations.get(j);
				if (ct1.getFitness() == ct2.getFitness()){
					temppop.add(ct1);
				}
			}
		}
		
		for(int k=0; k<temppop.size(); k++){
			ChromosomeTowerSet ct3 = (ChromosomeTowerSet)temppop.get(k);
			populations.remove(ct3);
		}
		sortPopulations(populations);
		
		for(int m=POPULATIONS_SIZE; m<populations.size(); m++){
			temp.add((ChromosomeTowerSet)populations.get(m));
		}
		for(int n=0; n<temp.size(); n++){
			ChromosomeTowerSet ct4 = (ChromosomeTowerSet)temp.get(n);
			populations.remove(ct4);
		}
	}
	
	//***************** printPopulations *********************//
	
	public void printPopulations(int position){
		ChromosomeTowerSet c = (ChromosomeTowerSet)populations.get(position);
		for (int j = 0; j < c.sol.size(); j++){
				Tower t = (Tower)c.sol.get(j);
				System.out.print(t.getID()+" ");
			}
			System.out.print("[" + c.getFitness() + "]");
			System.out.println("chromosome");
	}
	
/*	public void evaluate(){
		
		double total_tloss = 0 , total_tvalue = 0;
		
		
		for (int i = 0; i < populations.size(); i++){
			
			total_tvalue = 0;
			total_tloss = 0;
			
			ChromosomeTowerSet c = (ChromosomeTowerSet)populations.get(i);
			
			;
		
			for(int j = 0 ; j<c.sol.size() ; j++){
				
				Tower t = (Tower)c.sol.get(j);
				
				
				total_tvalue = total_tvalue + t.gettvalue();
				
				total_tloss = total_tloss + t.gettloss();
				
			//	System.out.println("tvalue = " + total_tvalue);
			//	System.out.println("tloss = " + total_tloss);
			}
		
			
				
				System.out.println("************ " + i + "*********");
				double fitness = total_tvalue / (233 * 220 * 587);
				
			//	System.out.println("total tvalue = " + total_tvalue);
			//	System.out.println("total tloss = " + total_tloss);
		
				System.out.println("fitness = " + fitness);
				
				c.setFitness(fitness);
					
		}	
		
	}


public void decode(){
		
		
	for (int a = 0; a < populations.size(); a++){
			
					
		ChromosomeTowerSet ch = (ChromosomeTowerSet)populations.get(a);
		
		Vector cSet = new Vector();
		
		Corner corner = new Corner();
		corner.setCornerSet(0,0,yc);
		
		cSet.add(corner);
		
		double value = 0;
		double reswidth = yc;
		double tempcor = 1 , tempbwidth = 0;
		int same = 0;
		
		int i = 0;
		while(i < ntowers){
			
			if(cSet.size() == 0){
				
				break;
			}
			
			corner = (Corner)cSet.get(0);
			
			
			System.out.println("************* select corner ***********");			
			corner.showCorner();
			System.out.println("*************************************");
			
			//	System.out.println("chro = " + chro);
			//	System.out.println("chro size = " + chro.size());
				
		//		System.out.println("reswidth  before = " + reswidth);
				
				Tower t1 = (Tower)chro.get(i);
				
				Boxes b = (Boxes)t1.TBoxes.get(0);
				
							
				if(reswidth - b.getBdimx() > 0){
					
					reswidth = reswidth - b.getBdimx();
				}
				
				else{
					
					reswidth = corner.getCwidth();
					//tempcor = 1;
					
					System.out.println("reswidth new  = " + reswidth);
					reswidth = reswidth - b.getBdimx();
				}
				
				
				System.out.println("x = " + b.getBdimz());
				System.out.println("y = " + b.getBdimx());
				System.out.println("reswidth = " + reswidth);
				
				if(reswidth >= 0){
					
					Tower t2 = new Tower();
					t2.setId(t1.getId());
					t2.setTrot(t1.getTrot());
					t2.setTcorn(corner.getCornerx(), corner.getCornery());
					t2.setvaluetower(t1.gettvalue());
					t2.setlosstower(t1.gettloss());
					
					for(int x = 0 ; x < t1.TBoxes.size() ; x++){
						
					//	System.out.println("TBoxes size = " + t1.TBoxes.size());
					//	System.out.println("b old = " + b.getBdimx());
						
						Boxes b_old = (Boxes)t1.TBoxes.get(x);
						
						
						Boxes bnew = new Boxes();
						
						bnew.setBoxes(b_old.getBdimx(), b_old.getBdimy(), b_old.getBdimz());
				
						bnew.setWeight(b_old.getWeight());
						bnew.setMemid(b_old.getMemid());
						bnew.setRid(b_old.getRid());
						bnew.setRno(b_old.getRno());
						bnew.setBoxname(b_old.getBoxname());
						
						bnew.setCoordinate(b_old.getBcornx(), b_old.getBcorny(), b_old.getBcornz());
						
						t2.TBoxes.add(bnew);
					}
					
					value = value + t2.gettvalue();
					
					
					
						
						ch.sol.add(t2);
					
			
					
					
					
					double corx = 0;
					
					if(corner.getCornerx() > 0){
						
						corx = corner.getCornerx();
					}	
					
					
					
					Corner corner1 = new Corner();
					corner1.setCornerSet(corx , corner.getCornery() + b.getBdimx() , reswidth);
					cSet.add(corner1);
					
					Corner corner2 = new Corner();
					double cory = 0;
					
					if(corner.getCornerx() + b.getBdimz() < tempcor){
						
						same = 0;
						System.out.println("in if");
						
						System.out.println(b.getBdimz() + " " + tempcor );
											
						cory = corner.getCornery();
					//	System.out.println("cory = " + cory);
						
						corner2.setCornerSet(corner.getCornerx() + b.getBdimz() , cory, reswidth + b.getBdimx());
						
					//	System.out.println(reswidth + " " + b.getBdimx() );
						
						
						cSet.add(corner2);
						
						
					 
					}
					else if (corner.getCornerx() + b.getBdimz() > tempcor){
						
						System.out.println("in else");
						
					//	System.out.println(corner.getCornerx()+b.getBdimz() + " " + tempcor );
						
						corner2.setCornerSet(corner.getCornerx() + b.getBdimz() , cory, yc);
						
						for(int k = 0 ; k < cSet.size() ; k++){
							
							Corner c = (Corner)cSet.get(k);
							
					//		System.out.println("c.getCornerx = " + c.getCornerx() + " " + c.getCornery() + 
					//			" " + c.getCwidth());
							
							if(c.getCornerx() == tempcor && c.getCornery() == 0 && c.getCwidth() == 233
								&& same != 1){
								
								System.out.println("tempcor = " + tempcor);
															
								Corner newcor = new Corner();
								newcor.setCornerSet(c.getCornerx() , c.getCornery() , tempbwidth);
								
								cSet.remove(c);
								cSet.add(newcor);
								
								same = 0;
								
							}
						}
						
						tempbwidth = b.getBdimx();
						
						cSet.add(corner2);
						
						
						if(corner.getCornery() == 0){
								
		
								tempcor = corner.getCornerx() + b.getBdimz();
								
								System.out.println("new tempcor = " + tempcor);
						}
						
							
					
												
					}
					
					else if (corner.getCornerx() + b.getBdimz() == tempcor){
						
						same = 1;
						System.out.println("same");
					//	System.out.println(b.getBdimz() + " " + tempcor );
					}
					
					
						cSet.remove(corner);
					//	System.out.println("cSet after remove 1 loop = " + cSet);
					
					//	System.out.println("cSet before = " + cSet);
						cSet = sortCorner(cSet);
						
					//	System.out.println("cSet = " + cSet);
						
				
					
				}else{
					
					t1.swapTower();
					
					if(reswidth - b.getBdimx() > 0){
					
						System.out.println("swap");
						reswidth = reswidth - b.getBdimx();
					}
					
					else{
																
						cSet.remove(corner);
						System.out.println("else");
					}
				
				}
				
					//----------------- remove corner unuse -------------//
						int count = 0;
						double min = 9999999;
						for(int k = 0 ; k < cSet.size() ; k++){
							
							Corner c = (Corner)cSet.get(k);
							
							if(c.getCornery() == 0 && c.getCwidth() == 233){
								
								count++;
																
								if(c.getCornerx() < min){
									
									min = c.getCornerx();
									
								}
													
								
								
							}
							
							
						}
						
				//		System.out.println("min x = " + min + "count = " + count);
					
						for(int k = 0 ; k < cSet.size() ; k++){
							
							Corner c = (Corner)cSet.get(k);
							
							if(c.getCornery() == 0 && c.getCwidth() == 233 && count > 1){
								
								if(c.getCornerx() == min){
									
									cSet.remove(c);
									
									System.out.println("-------remove corner unuse-----");
									c.showCorner();
								}
							}
						}
						
						//------------------------------------------//
					
				
						for(int k = 0 ; k < cSet.size() ; k++){
							
							Corner c = (Corner)cSet.get(k);
							
							if(c.getCornery() == 0){
								
								if(c.getCornerx() < tempcor){
									
									cSet.remove(c);
									System.out.println("-------- remove wrong corner -------");
									c.showCorner();
									
								}
							}
							
						}
				
				
				for(int j = 0 ; j < cSet.size() ; j ++){
					
					System.out.println("************ show corner ********* " + j);
					Corner c = (Corner)cSet.get(j);
					c.showCorner();
					System.out.println("********************************* ");
				}
				
			i++;
		}
		
		//showTower(value);
	}
}	
	
public void showTower(double value){
	
	double containerValue = 233 * 220 * 587;
	System.out.println("*********** show Corner of Tower ************");
	
	
	for (int k = 0; k < populations.size(); k++){
			
		ChromosomeTowerSet c = (ChromosomeTowerSet)populations.get(k);

		System.out.println("****** show sol *****" + " sol size = " + c.sol.size());
		for(int i = 0 ; i<c.sol.size() ;i++){
			
			Tower t = (Tower)c.sol.get(i);
			
			
			System.out.print("x = " + t.getTcx() + " y = " + t.getTcy() + " value = " + t.gettvalue());
			
			System.out.println();
		}
		
		System.out.println("***********");
	}
	
	System.out.println("total value = " + value);
	
	System.out.println("total value container = " + containerValue);
}


	//----------------- sort corner --------------//
	
public Vector sortCorner(Vector cSet){
	
	Vector v = new Vector(cSet);
		
	int index, indexOfNextMin;
	int size = v.size();
	
	for(index = 0 ; index < size - 1 ; index++){
		
		indexOfNextMin = indexOfNextMin(index , v);
		
		interchange(index, indexOfNextMin ,v);
	}	
	
		
	return v;
	
	
}


private int indexOfNextMin(int startIndex , Vector v){
	
	double min = 0, num = 0;
	int index;
	
	Corner c = (Corner)v.elementAt(startIndex);
	min = c.getCornerx();
	
	int indexOfMin = startIndex;
	int size = v.size();
	
	for(index = startIndex + 1 ; index < size ; index++){
		
		Corner tempCorner = (Corner)v.elementAt(index);
		
		num = tempCorner.getCornerx();
	
	
		if(num < min){
			
			min = num;
			indexOfMin = index;
			
		}
		
		if(num == min){
			
			min = c.getCornery();
			
			num = tempCorner.getCornery();
			
			if(num < min){
				
				min = num;
				indexOfMin = index;
				
			}
			
		}
		
	}
	
	return indexOfMin;
}

private void interchange(int i, int j , Vector v){
	
	Corner temp1 = (Corner)v.elementAt(i);
	Corner temp2 = (Corner)v.elementAt(j);
	
	v.setElementAt(temp1,j);
	v.setElementAt(temp2,i);
	
}*/
	
	//********************** Sort sortPopulations *****************//
	
/*public Vector sortPopulations(Vector v){
	
	int index, indexOfNextMax;
	int size = v.size();
	
	for(index = 0 ; index < size - 1 ; index++){
		
		indexOfNextMax = indexOfNextMaxTNew(index, v);
		
		interchangeTNew(index, indexOfNextMax, v);
	}	
	
	System.out.println("************ show sort fitness ***********" );
	
	for (int i = 0; i < v.size(); i++){
			
		ChromosomeTowerSet c = (ChromosomeTowerSet)v.get(i);
	
		System.out.println("fitness = " + c.getFitness());	
	}
	
	return v;
	
	
	
}


private int indexOfNextMaxTNew(int startIndex, Vector v){
	
	double max = 0, num = 0;
	int index;
	
	ChromosomeTowerSet c = (ChromosomeTowerSet)v.elementAt(startIndex);
	
	max = c.getFitness();
	
	int indexOfMax = startIndex;
	int size = v.size();
	
	for(index = startIndex + 1 ; index < size ; index++){
		
		ChromosomeTowerSet tempC = (ChromosomeTowerSet)v.elementAt(index);
		
		num = tempC.getFitness();
	
	
		if(num > max){
			
			max = num;
			indexOfMax = index;
			
		}
		
	}
	
	return indexOfMax;
}

private void interchangeTNew(int i, int j, Vector v){
	
	ChromosomeTowerSet temp1 = (ChromosomeTowerSet)v.elementAt(i);
	ChromosomeTowerSet temp2 = (ChromosomeTowerSet)v.elementAt(j);
	
	v.setElementAt(temp1,j);
	v.setElementAt(temp2,i);
	
}*/

// ********************** cross over ***************************//

/*	public void crossover(){
		ChromosomeTowerSet p1 = (ChromosomeTowerSet)populations.get(0);
		ChromosomeTowerSet p2 = (ChromosomeTowerSet)populations.get(getRandomPopulation());
		Vector tail_p1 = new Vector();	//tail from parent1
		Vector tail_p2 = new Vector();	//tail from parent2
		ChromosomeTowerSet c1 = new ChromosomeTowerSet();
		ChromosomeTowerSet c2 = new ChromosomeTowerSet();
		
		if (p1.chromosome.size()>p2.chromosome.size()){
			ChromosomeTowerSet p3 = p1;
			p1 = p2;
			p2 = p3;
		}
		int sizep1 = p1.chromosome.size();
		int sizep2 = p2.chromosome.size();
		int posp1[] = new int[sizep1];
		int posp2[] = new int[sizep2];
		
		for (int i=0; i<sizep1; i++){
			int index = (int) (Math.random() * 2);
			posp1[i] = index;
			posp2[i] = index;
			
			
		}System.out.println("loop 1");
		
		for (int j=0; j<sizep1; j++){
			if (posp1[j] == 1){
				Tower t1 = (Tower)p1.chromosome.get(j);
				tail_p1.add(t1);
			}
		}System.out.println("loop 2");
		
		for (int j=0; j<sizep2; j++){
			if (posp2[j] == 1){
				Tower t2 = (Tower)p2.chromosome.get(j);
				tail_p2.add(t2);
				
			}
		}System.out.println("loop 3");
		
		for (int k=0; k<p1.chromosome.size(); k++){
			if (posp1[k] == 1){
				c1.chromosome.add(p2.chromosome.get(k));
			} else {
				c1.chromosome.add(pmx((Tower)p1.chromosome.get(k),tail_p2,tail_p1));
			}
		}System.out.println("loop 4");
		
		for (int l=0; l<p2.chromosome.size(); l++){
			
			
			
			if (posp2[l] == 1){
				
				c2.chromosome.add(p1.chromosome.get(l));
			} else {
				
				c2.chromosome.add(pmx((Tower)p2.chromosome.get(l),tail_p1,tail_p2));
			}
		}System.out.println("loop 5");
		
		for (int m=0; m<p1.chromosome.size(); m++){	///test crossover p1 and c1
			Tower t = (Tower)p1.chromosome.get(m);
			System.out.print(t.getId()+" ");
		}
		System.out.println();
		for (int n=0; n<c1.chromosome.size(); n++){
			Tower t = (Tower)c1.chromosome.get(n);
			System.out.print(t.getId() + " ");
		}
		System.out.println();
	
		for (int p=0; p<p2.chromosome.size(); p++){	///test crossover p2 and c2
			Tower t = (Tower)p2.chromosome.get(p);
			System.out.print(t.getId()+" ");
		}
		System.out.println();
		for (int q=0; q<c2.chromosome.size(); q++){
			Tower t = (Tower)c2.chromosome.get(q);
			System.out.print(t.getId() + " ");
		}
		System.out.println();
		
	}*/
	
	// ******************** mutation ***********************//
	
/*	public void mutation(){
			
		ChromosomeTowerSet p = (ChromosomeTowerSet)populations.get(getRandomPopulation());
		ChromosomeTowerSet c = new ChromosomeTowerSet();
		Vector vecmut1 = new Vector();
		Vector vecmut2 = new Vector();
		int position[] = new int[p.chromosome.size()];
		
		int positionmutation = (int) (Math.random() * p.chromosome.size());
		int tempsize = p.chromosome.size() - positionmutation;
		int sizemutation = (int) (Math.random() * tempsize);
		
		for (int i=positionmutation; i<(positionmutation+(sizemutation)); i++){
			position[i] = 1;
		}
		
		for (int j=0; j<sizemutation; j++){
			vecmut1.add((Tower)p.chromosome.get(positionmutation));
			positionmutation++;
		}
		
		for (int k=(vecmut1.size()-1); k>=0; k--){
			vecmut2.add((Tower)vecmut1.get(k));
		}
		int index=0;
		for (int m=0; m<p.chromosome.size(); m++){
			
			
			if(position[m]==1){
				
				c.chromosome.add((Tower)vecmut2.get(index));
				index++;
			}
			
			else{
				c.chromosome.add((Tower)p.chromosome.get(m));
			}
		}
		
		for (int j = 0; j < position.length ; j++){
			
			System.out.println("position = " + position[j]);
		
				
		}
		
		
		System.out.println("sizemutation = " + sizemutation);
		System.out.println("vecmut2 = " + vecmut2);
		
		System.out.println("vecmut2 size = " + vecmut2.size());
		
		System.out.println("---------- print id vecmut chromosome ------------");
		for (int j = 0; j < vecmut2.size(); j++){
				
				Tower t = (Tower)vecmut2.get(j);
				
				
				System.out.print(t.getId()+" ");
		}
		
			System.out.println();
		
		System.out.println("---------- print id p chromosome ------------");
		for (int j = 0; j < p.chromosome.size(); j++){
				
				Tower t = (Tower)p.chromosome.get(j);
				
				
				System.out.print(t.getId()+" ");
		}
		
		System.out.println();
		System.out.println("---------- print id c chromosome ------------");
		for (int j = 0; j < c.chromosome.size(); j++){
				
				Tower t = (Tower)c.chromosome.get(j);
				
				System.out.print(t.getId()+" ");
				
		}
		
		System.out.println();
		
	}
	
	
	public int getRandomPopulation() { 
		return (int) (Math.random() * POPULATIONS_SIZE); 
	}
	
	public Tower pmx(Tower t1,Vector v1,Vector v2){
		Tower t2 = new Tower();
		for(int i=0; i < v1.size(); i++){
			t2 = (Tower)v1.get(i);
			if (t1.getId() == t2.getId()){
				//System.out.println("same box");
				return pmx((Tower)v2.get(i),v1,v2);
			}	
		}
		return t1;
	}
	
	public void printChromosome() {
		
		System.out.println("*********** printChromosome ************");
		
		for (int i = 0; i < populations.size(); i++){
			
			ChromosomeTowerSet c = (ChromosomeTowerSet) populations.get(i);
			
			System.out.println("*********** populations ************");
			System.out.println("["+ i + "]");
			
			for (int j = 0; j < c.sol.size(); j++){
				
				Tower t = (Tower)c.sol.get(j);
				
				
				System.out.print(t.getId()+" ");
			}
			
			System.out.println("*********** fitness ************");
			
			System.out.println("[" + c.getFitness() + "]");
			System.out.println("chromosome");
		}	
	}*/
	
	
	//************************* do3D ***********************//
	
	public void do3D(int memid , int rNO)throws Exception {
		
			String name;
			double valuetotal = 0;
			double numboxtotal = 0;
			
			ChromosomeTowerSet c = (ChromosomeTowerSet) populations.get(0);
			
						
			for (int j = 0; j < c.sol.size(); j++){
				
				Tower t = (Tower)c.sol.get(j);
							
				valuetotal = valuetotal + t.getTvalue();
				
							
				numboxtotal = numboxtotal + t.tboxes.size();
				
				
			}
			
			System.out.println("***************");
			
			
				//---------------------insert data to table total in database-------------------------
		
			Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/Project?user=root&password=", "", "");
			
				PreparedStatement p = con.prepareStatement(
					
"INSERT INTO total VALUES ('', '"+valuetotal+"', '"+numboxtotal+"', '"+memid+"', '"+rNO+"') ");
				
				
			
				p.executeUpdate();
				
			
				
				p.close(); 
				con.close();
				
			//MainFrame obj = new MainFrame(new Pic3D(c.sol), 800, 600);
			
			
				//---------------------insert data to table pic3D in database-------------------------
			System.out.println("fit = " + c.getFitness());	
				
			for (int j = 0; j < c.sol.size(); j++){
				
				
				
				Tower t = (Tower)c.sol.get(j);
				
				System.out.println("********* tower = " + j + " **********" );
				System.out.println("tx = " + t.getTcornx() + " ty = " + t.getTcorny());
				
								
				for(int k = 0 ; k < t.tboxes.size() ; k++){
					
					Boxes b = (Boxes)t.tboxes.get(k);
				
						System.out.println("-------- box = " + k + " ---------");
System.out.println("bx = " + b.getBcornx() + " by = " + b.getBcorny() + " bz = " + b.getBcornz() + " bwidth = " + b.getBdimx() + " bheight = " + b.getBdimy() + " bdepth = " + b.getBdimz() );	
		
			Class.forName("com.mysql.jdbc.Driver");
				Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/Project?user=root&password=", "", "");
			
				PreparedStatement p1 = con1.prepareStatement(
					
"INSERT INTO pic3D VALUES ('', '"+t.getID()+"', '"+t.getTcornx()+"', '"+t.getTcorny()+"', '"+b.getBoxname()+"' , '"+b.getBcornx()+"' , '"+b.getBcorny()+"' , '"+b.getBcornz()+"', '"+b.getBdimx()+"', '"+b.getBdimy()+"' , '"+b.getBdimz()+"' , '"+memid+"', '"+rNO+"') ");
				
				
			
					p1.executeUpdate();
					
					p1.close(); 
					con1.close();
				}
				
			
			}	
				
				
		
	}
	

	public static void main(String[] args) throws Exception, StackOverflowError {

		GAContainer obj = new GAContainer();
		obj.doGA(2,21,0);
	
	}
}