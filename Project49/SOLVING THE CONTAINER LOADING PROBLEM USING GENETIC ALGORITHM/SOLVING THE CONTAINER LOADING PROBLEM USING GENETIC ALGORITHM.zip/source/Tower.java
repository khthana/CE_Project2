package projectbean;
import java.io.*;
import java.util.*;


class Tower {
	Vector tboxes = new Vector();
	
	private double tarea; 			
	
	private int id;					// index of tower base
	private double trot;			// index of rotation variant 0 = y is larger than x
	private double tvalue; 			// total valume of the boxes in tower
	private double tloss;  			// spare space related to the tower
	private double tcornx, tcorny;  // position of the tower base
	private double tdimx, tdimy;	// dimension of the tower base
	
	public Tower(){
		id = 0;
		trot = 0;
		tvalue = 0;
		tloss = 0;
		tcornx = 0;
		tcorny = 0;
		tdimx = 0;
		tdimy = 0;
	}
	
	public Tower(Tower t){
		this.tboxes = t.tboxes;
		this.id = t.getID();
		this.trot = t.getTrot();
		this.tvalue = t.getTvalue();
		this.tloss = t.getTloss();
		this.tcornx = t.getTcornx();
		this.tcorny = t.getTcorny();
		this.tdimx = t.getTdimx();
		this.tdimy = t.getTdimy();
	}
	
	
	public void setValueTower(double value){
		tvalue = value;
	}
	
	public void setAreaTower(double area){
		tarea = area;
	}
	
	public void setLossTower(double loss){
		tloss = loss;
	}
	
	public void setID(int num){
		id = num;
	}
	
	public void setTrot(double rot){
		trot = rot;
	}
	
	public void setTdim(double x, double y){
		tdimx = x;
		tdimy = y;
	}
	
	public void setTcorn(double x, double y){
		tcornx = x;
		tcorny = y;
	}
	
	public void setTcornx(double x){
		tcornx = x;
	}
	
	public void setTcorny(double y){
		tcorny = y;
	}
	
	public double getTvalue(){
		return tvalue;
	}
	
	public double getTloss(){
		return tloss;
	}
	
	public double getTrot(){
		return trot;
	}
	
	public int getID(){
		return id;
	}
	
	public double getTcornx(){
		return tcornx;
	}
	
	public double getTcorny(){
		return tcorny;
	}
	
	public double getTdimx(){
		return tdimx;
	}
	
	public double getTdimy(){
		return tdimy;
	}
	
	public double getTarea(){
		return tdimx * tdimy;
	}
	
	public double getArea(){
		return tarea;
	}
	
	public void swap(){
		double tempx = tdimx;
		tdimx = tdimy;
		tdimy = tempx;
	}
	
	public void rotateTower(){
		if(trot != 0){
			for(int i=0; i<tboxes.size(); i++){
				Boxes b = (Boxes)tboxes.get(i) ;
				b.rotateBox();
			}
		}
	}
	


}