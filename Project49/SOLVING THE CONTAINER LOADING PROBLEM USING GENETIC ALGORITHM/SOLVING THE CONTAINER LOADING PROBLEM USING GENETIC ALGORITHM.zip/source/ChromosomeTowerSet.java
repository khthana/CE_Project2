package projectbean;
import java.io.*;
import java.util.*;

class ChromosomeTowerSet{
	
	Vector chromosome = new Vector();
	Vector sol = new Vector();
	
	private double fitness;
	
	public void setFitness(double fit){
		
		fitness = fit;
	}
	
	public double getFitness(){
		
		return fitness;
	}
	
	public ChromosomeTowerSet(){
		fitness = 0;
	}
	
	public ChromosomeTowerSet(ChromosomeTowerSet c){
		this.chromosome = new Vector(c.chromosome);
	}
}