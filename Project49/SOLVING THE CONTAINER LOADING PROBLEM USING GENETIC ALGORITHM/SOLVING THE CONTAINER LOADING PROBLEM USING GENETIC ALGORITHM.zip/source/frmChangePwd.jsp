<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>


<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//----------get mem_id---------------------
String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}


%>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style21 {color: #CC0000}
.style22 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#cc0033; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#0066cc; text-decoration:none }

.style23 {color: #0033FF}
.style28 {color: #FF0066}
.style32 {font-size: 16px}
.style12 {color: #006600; font-weight: bold; }
.style19 {color: #FF0000; font-weight: bold; }
.style20 {color: #000000; font-weight: bold; }
.style16 {color: #FFFF00; font-weight: bold; font-size: 16px; }
-->
</STYLE>

<script>

	function validate() {
	
		if (	f.old_pwd.value.length < 8 || 
				f.old_pwd.value.length > 16) {
			alert ("��سҡ�͡ old password");
			f.old_pwd.select();
			return false;
		}
			
		if (	f.new_pwd.value.length < 8 || 
				f.new_pwd.value.length > 16) {
			alert ("��سҡ�͡ password 8-16 ���");
			f.new_pwd.select();
			return false;
		}
		
		if (	f.confirm_pwd.value.length < 8 || 
				f.confirm_pwd.value.length > 16) {
			alert ("��سҡ�͡ confirm password 8-16 ���");
			f.confirm_pwd.select();
			return false;
		}
		
		if (	f.new_pwd.value != f.confirm_pwd.value) {
			alert ("��سҡ�͡ confirm password ���ç�Ѻ password ���¹�");
			f.confirm_pwd.select();
			return false;
		}
		
			
	} //end function
</script>
</head>

<body>
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="35" colspan="6" valign="top"><img src="images/back1_02.jpg" width="770" height="35"></td>
  </tr>
  <tr>
    <td width="170" rowspan="4" valign="top"><table width="169" border="0" cellpadding="0" cellspacing="0" background="images/back_02.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="8" height="83">&nbsp;</td>
          <td width="138">&nbsp;</td>
          <td width="4">&nbsp;</td>
          <td width="23">&nbsp;</td>
        </tr>
      <tr>
        <td height="86"></td>
          <td colspan="2" valign="top"><p align="left" class="style22 style23">��ǹ�����ҹ�����</p>          <p class="style21"> <a href="mainMember.jsp?id=<%=mem_id%>">--&gt; ��ҹ�����</a> <br>
           <a href="resultHis.jsp?id=<%=mem_id%>">--&gt; �ټ��Ѿ��</a></p></td>
          <td>&nbsp;</td>
        </tr>
      <tr>
        <td height="16"></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      <tr>
        <td height="95"></td>
          <td valign="top"><p class="style21"><span class="style22 style28">��ǹ�����Ţͧ user</span></p>          <p class="style21"><strong> </strong><a href="frmEditProfile.jsp?id=<%=mem_id%>">--&gt; ��䢢�������ǹ���</a><br>
              --&gt; <strong>����¹ password</strong><br>
           <a href="logout.jsp">--&gt; Log out</a></p></td>
          <td></td>
          <td></td>
        </tr>
      <tr>
        <td height="57"></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      
      
      
      
      
      
      
      
      
      
    </table></td>
    <td height="142" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back1_05.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="12" height="116">&nbsp;</td>
        <td width="573">&nbsp;</td>
        <td width="15">&nbsp;</td>
      </tr>
      <tr>
        <td height="26">&nbsp;</td>
        <td valign="top"><span class="style22 style32">User : <%= session.getAttribute("sess_user")%> </span></td>
      <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td width="22" height="25"></td>
    <td width="27"></td>
    <td width="500">&nbsp;</td>
    <td width="27"></td>
    <td width="24"></td>
  </tr>
  <tr>
    <td height="20"></td>
    <td></td>
    <td valign="top" bgcolor="#0000FF"><div align="center"><span class="style16">����¹ Password </span></div></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  <tr>
    <td height="150"></td>
    <td colspan="3" rowspan="2" valign="top"><form action="updatePwd.jsp?id=<%=mem_id%>" method="post" name="f" id="f" onSubmit="return validate()">
      <table width="500" height="126" align="center" cellpadding="4" cellspacing="0" bgcolor="#33CCFF">
        <!--DWLayoutTable-->


        <tr>
          <td width="152" height="28" class="style22">Old Password </td>
          <td width="332"><input name="old_pwd" type="password" id="old_pwd" maxlength="16" /></td>
        </tr>
        <tr>
          <td height="31" class="style22">New Password </td>
          <td><input name="new_pwd" type="password" id="new_pwd" maxlength="16" /></td>
        </tr>
        <tr>
          <td height="26" class="style22">Confirm Password </td>
          <td><input name="confirm_pwd" type="password" id="confirm_pwd" maxlength="16" /></td>
        </tr>
        <tr>
          <td height="39" colspan="2" class="style2"><div align="center" class="style20">
              <input name="Submit" type="submit" class="style19" value="Submit" />
          </div></td>
        </tr>
      </table>
        </form>    </td>
    <td></td>
  </tr>
  <tr>
    <td rowspan="2" valign="top"><table width="169" border="0" cellpadding="0" cellspacing="0" background="images/left_02.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="170" height="240">&nbsp;</td>
        </tr>
    </table></td>
    <td height="225"></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="15"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
  
  
  
  
  
  
  
  <tr>
    <td height="18" colspan="6" valign="top" bgcolor="#FF6600"><div align="right"><strong class="style2">&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></div></td>
  </tr>
</table>
</body>
</html>
