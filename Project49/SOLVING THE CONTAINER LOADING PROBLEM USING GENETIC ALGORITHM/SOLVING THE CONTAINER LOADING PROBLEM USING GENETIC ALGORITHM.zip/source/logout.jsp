<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<html>
<body>

<%

session.removeAttribute("sess_user");

%>

<script>
	alert ("�͡�ҡ�к�");
	window.location = "index.jsp";
</script>

</body>
</html>
