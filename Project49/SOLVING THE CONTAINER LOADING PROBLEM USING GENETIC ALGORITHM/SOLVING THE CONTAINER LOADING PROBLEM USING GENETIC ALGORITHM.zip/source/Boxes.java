package projectbean;
import java.io.*;
import java.util.*;

class Boxes {
	
	private int id;
	private double bdimx, bdimy, bdimz;		//dimensions of the box
	private double bcornx, bcorny, bcornz;	//coordinates of the corner of the box
	private int mem_id, r_id, r_no;
	private String bname;
	private double bweight;

	public Boxes(){
		bdimx = 0;
		bdimy = 0;
		bdimz = 0;
		bcornx = 0;
		bcorny = 0;
		bcornz = 0;
	}
	
	public Boxes(Boxes b){
		this.id = b.id;
		this.bdimx = b.bdimx;
		this.bdimy = b.bdimy;
		this.bdimz = b.bdimz;
		this.bcornx = b.bcornx;
		this.bcorny = b.bcorny;
		this.bcornz = b.bcornz;
	}
	
	public void setID (int i){
		id = i;
	}
	
	public void setBoxes (double x, double y, double z){
		
		bdimx = x;
		bdimy = y;
		bdimz = z;	
	}
	
	public void setCoordinate (double x, double y, double z){
		
		bcornx = x;
		bcorny = y;
		bcornz = z;
	}
	
	public void setWeight(double w){
		
		bweight = w;

	}
	
	//------- get width, height,depth -------
	
	public double getBdimx(){
		return bdimx;
	}
	
	public double getBdimy(){
		return bdimy;
	}
	
	public double getBdimz(){
		return bdimz;
	}
	
	//-------- get Coordinate x, y, z ---------
	 
	public double getBcornx(){
		return bcornx;
	}
	
	public double getBcorny(){
		return bcorny;
	}
	
	public double getBcornz(){
		return bcornz;
	}
	
	//---------get Weight----------------------
	
	public double getWeight(){
		return bweight;
	}
	
	//-------------- area & volume -------------
	
	public double areaBox(){
		double area = bdimx*bdimz;
		return area;
	}
	
	public double volBox(){
		double vol = bdimx*bdimy*bdimz;
		return vol;
	}
	
	//---------------- mem_id----------------
	
	public void setMemid(int memid){
		
		mem_id = memid;
		
	}
	
	public int getMemid(){
		
		return 	mem_id;
	}
	
	//----------------------------------------
	
	//----------------r_id------------------
	
	public void setRid(int rid){
		
		r_id = rid;
		
	}
	
	public int getRid(){
		
		return 	r_id;
	}
	
	//--------------------------------------
	
	//----------------r_NO------------------
	
	public void setRno(int rno){
		
		r_no = rno;
		
	}
	
	public int getRno(){
		
		return 	r_no;
	}
	
	//--------------------------------------
	
	//----------------boxname------------------
	
	public void setBoxname(String boxname){
		
		bname = boxname;
		
	}
	
	public String getBoxname(){
		
		return 	bname;
	}
	
	//--------------------------------------
	
	public void rotateBox(){
		double tempbdimx = bdimx;
		bdimx = bdimz;
		bdimz = tempbdimx;
	}
	
	public void showDetail(){
		
		System.out.println("width = " + getBdimx());
		System.out.println("height = " + getBdimy());
		System.out.println("depth = " + getBdimz());
		System.out.println("Volumn Box = " + volBox());
		System.out.println();
	
	}
}