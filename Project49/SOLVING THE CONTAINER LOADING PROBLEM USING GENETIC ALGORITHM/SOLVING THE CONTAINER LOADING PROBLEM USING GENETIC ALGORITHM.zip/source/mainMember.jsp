<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//----------get mem_id---------------------
String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//---------�֧�����š��ͧ�ҡ�ҹ���������ʴ�-----------------

String sql = "select * from box where mem_id = '"+mem_id+"' order by box_id";

ResultSet rs = stmt.executeQuery(sql);

%>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<title>:: SmartContainer ::</title>
<style type="text/css">
<!--
body,td,th {
	font-family: MS Sans Serif, serif, sans-serif, Tahoma, Verdana;
	font-size: 14px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #CCCCCC;
}
.style2 {
	color: #FFFF00;
	font-weight: bold;
}
.style21 {color: #CC0000}
.style22 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>

<STYLE TYPE='text/css'>
<!-- TextRollover-1 -->
<!--

a:link { color:#cc0033; text-decoration:none }
a:visited {color: #990000; text-decoration:none}
a:hover { color:#0066cc; text-decoration:none }

.style23 {color: #0033FF}
.style24 {
	color: #000066;
	font-weight: bold;
	font-size: 16px;
}
.style26 {font-size: 16px}
.style28 {color: #FF0066}
.style29 {color: #996600}
.style30 {color: #FF3300}
.style32 {color: #0033FF; font-weight: bold; }
-->
</STYLE>

<script>

	function validate() {
	
		if(form1.boxName.value == "") {
				alert("��سҡ�͡���͡��ͧ���ͪ����Թ���")
				form1.boxName.select();
				return false;
		}
	
		if(form1.width.value == "" ||
			isNaN( form1.width.value ) ||
			form1.width.value.indexOf(" ") >= 0 ||
			form1.width.value == 0 ||
			form1.width.value > 235) {
				alert("��سҡ�͡�������ҧ���١��ͧ")
				form1.width.select();
				return false;
		}
		
		if(form1.length.value == "" ||
			isNaN( form1.length.value ) ||
			form1.length.value.indexOf(" ") >= 0 ||
			form1.length.value == 0 ||
			form1.length.value > 239){
				alert("��سҡ�͡�����٧���١��ͧ")
				form1.length.select();
				return false;
		}
		
		if(form1.depth.value == "" ||
			isNaN( form1.depth.value ) ||
			form1.depth.value.indexOf(" ") >= 0 ||
			form1.depth.value == 0 ||
			form1.depth.value > 589.8){
				alert("��سҡ�͡�����֡���١��ͧ")
				form1.depth.select();
				return false;
		}
		
		if(form1.weight.value == "" ||
			isNaN( form1.weight.value ) ||
			form1.weight.value.indexOf(" ") >= 0 ||
			form1.weight.value == 0){
				alert("��سҡ�͡���˹ѡ���١��ͧ")
				form1.weight.select();
				return false;
		}
		
		if(form1.numbox.value == "" ||
			isNaN( form1.numbox.value ) ||
			form1.numbox.value.indexOf(" ") >= 0 ||
			form1.numbox.value == 0){
				alert("��سҡ�͡�ӹǹ���ͧ���١��ͧ")
				form1.numbox.select();
				return false;
		}
	
		
			
	} //end function
	
</script>

</head>

<body>
<table width="770" height="1060" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFCC33">
  <!--DWLayoutTable-->
  <tr>
    <td height="35" colspan="4" valign="top"><img src="images/back1_02.jpg" width="770" height="35"></td>
  </tr>
  <tr>
    <td width="170" rowspan="4" valign="top"><table width="169" border="0" cellpadding="0" cellspacing="0" background="images/back_02.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="4" height="83">&nbsp;</td>
          <td width="156">&nbsp;</td>
          <td width="13">&nbsp;</td>
        </tr>
      <tr>
        <td height="95"></td>
          <td valign="top">
            <p align="left" class="style22 style23">&nbsp;��ǹ�����ҹ�����</p>              <p class="style21"><strong>--&gt; ��ҹ����� </strong><br>
               <a href="resultHis.jsp?id=<%=mem_id%>">--&gt; �ټ��Ѿ��</a><br>
              </p></td>
          <td></td>
        </tr>
      <tr>
        <td height="10"></td>
          <td></td>
          <td></td>
        </tr>
      
      
      
      <tr>
        <td height="88"></td>
          <td valign="top"><p class="style21"><span class="style22 style28">&nbsp;��ǹ�����Ţͧ user</span></p>          
            <p class="style21"> <a href="frmEditProfile.jsp?id=<%=mem_id%>">--&gt; ��䢢�������ǹ���</a><br>
               <a href="frmChangePwd.jsp?id=<%=mem_id%>">--&gt; ����¹ password</a><br>
           <a href="logout.jsp">--&gt; Log out</a></p></td>
          <td></td>
        </tr>
      <tr>
        <td height="63"></td>
          <td>&nbsp;</td>
          <td></td>
        </tr>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    </table></td>
    <td height="142" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/back1_05.jpg">
      <!--DWLayoutTable-->
      <tr>
        <td width="11" height="116">&nbsp;</td>
        <td width="576">&nbsp;</td>
        <td width="13">&nbsp;</td>
      </tr>
      <tr>
        <td height="26">&nbsp;</td>
        <td valign="top"><span class="style22 style26">User :
            <%= session.getAttribute("sess_user")%>
        </span></td>
      <td>&nbsp;</td>
      </tr>
      
      
    </table>    </td>
  </tr>
  <tr>
    <td width="51" height="25">&nbsp;</td>
    <td width="497">&nbsp;</td>
    <td width="52">&nbsp;</td>
  </tr>
  
  <tr>
    <td height="130">&nbsp;</td>
    <td valign="top" bgcolor="#FFFF33"><div align="center"><span class="style24"><br>
          <span class="style30">�������èѴ���§���ͧ㹵��͹�ù����          </span></span>    </div>      
      <p align="center" class="style29">��Ҫԡ����ö��ҹ��������»�͹�Թ�ص�����Ţͧ���ͧ���й��ҨѴ���§  <br>
        �ҡ��鹡����� Add Box  �����Ţͧ���ͧ��ж١�Ѵ�����㹰ҹ�����Ţͧ�к� <br>
    ����ͻ�͹�����Ţͧ���ͧ�ú����  �硴���� Calculate �������зӡ�äӹǳ��èѴ���§���ͧ���</p></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="42">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
  
  
  
  <tr>
    <td height="300" valign="top" bgcolor="#FFFFFF"><img src="images/left_02.jpg" width="169" height="203"></td>
    <td></td>
    <td valign="top"><form name="form1" method="post" action="insertBox.jsp?id=<%=mem_id%>" onSubmit="return validate()">
      <table width="450" height="302" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#CC9900">
        <tr>
          <td height="43" colspan="2" bgcolor="#993300"><div align="center" class="style22 style26">�������š��ͧ</div></td>
          </tr>
        <tr>
          <td width="165" class="style2">���͡��ͧ/�����Թ���</td>
          <td width="265" class="style2"><input name="boxName" type="text" id="boxName" size="30"></td>
        </tr>
        <tr>
          <td class="style2">�������ҧ</td>
          <td class="style2"><input name="width" type="text" id="width" size="10" maxlength="7">
(cm.) </td>
        </tr>
        <tr>
          <td class="style2">�����٧</td>
          <td class="style2"><input name="length" type="text" id="length" size="10" maxlength="7">
(cm.) </td>
        </tr>
        <tr>
          <td class="style2">�����֡</td>
          <td class="style2"><input name="depth" type="text" id="depth" size="10" maxlength="7">
(cm.) </td>
        </tr>
        <tr>
          <td class="style2">���˹ѡ</td>
          <td class="style2"><input name="weight" type="text" id="weight" size="10" maxlength="7">
(kg.) </td>
        </tr>
        <tr>
          <td height="34"><span class="style2">�ӹǹ���ͧ</span></td>
          <td height="34"><span class="style2">
            <input name="numbox" type="text" id="numbox" size="10" maxlength="5">
          </span></td>
        </tr>
        <tr>
          <td height="65" colspan="2"><div align="center" class="style32">
            <input name="Addbox" type="submit" class="style21" value="Add box">
  &nbsp;&nbsp;
  <input name="Submit2" type="reset" class="style23" value="Reset">
          </div></td>
        </tr>
      </table>
        </form>    </td>
   
    <td>&nbsp;</td>
  </tr>
 
      <td height="38" colspan="4" bgcolor="#CC3300" class="style22"><div align="center" class="style22 style26">---------------&gt; �ʴ������š��ͧ�������㹰ҹ������ &lt;---------------- </div></td>
  
  <tr>
    <td height="464" colspan="4" valign="top" bgcolor="#FFCC33"><form action="callProgram.jsp?id=<%=mem_id%>" method="post" name="form2">
      <br>
      <table border="1" align="center" cellpadding="5" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FF6600">
        <!--DWLayoutTable-->
        <tr>
          <td width="32" height="34" bgcolor="#CC0000" class="style2"><div align="center">Box NO.</div></td>
            <td width="106" bgcolor="#CC0000" class="style2"><div align="center">���͡��ͧ/�����Թ���</div></td>
            <td width="56" bgcolor="#CC0000" class="style2"><div align="center">�������ҧ</div></td>
            <td width="50" bgcolor="#CC0000" class="style2"><div align="center">�����٧</div></td>
            <td width="50" bgcolor="#CC0000" class="style2"><div align="center">�����֡</div></td>
            <td width="50" bgcolor="#CC0000" class="style2"><div align="center">���˹ѡ</div></td>
            <td width="64" bgcolor="#CC0000" class="style2"><div align="center">�ӹǹ���ͧ</div></td>
            <td width="29" bgcolor="#CC0000" class="style2"><div align="center">���</div></td>
            <td width="53" bgcolor="#CC0000" class="style2"><div align="center">���͡���ͧ</div></td>
        </tr>
        <tr>
          
          <%
		int x = 1;
		while(rs.next()) { 
		
			String boxname = rs.getString("box_name");
			String boxname2 = new String(boxname.getBytes("ISO8859_1"),"TIS-620");%> 
          
          <td class="style2"><div align="center"><%= x++ %></div></td>
            <td class="style2"><div align="left"><%= boxname2%></div></td>
            <td class="style2"><div align="center"><%= rs.getString("box_width")%></div></td>
            <td class="style2"><div align="center"><%= rs.getString("box_length")%></div></td>
            <td class="style2"><div align="center"><%= rs.getString("box_depth")%></div></td>
            <td class="style2"><div align="center"><%= rs.getString("box_weight")%></div></td>
            <td class="style2"><div align="center"><%= rs.getString("box_num")%></div></td>
            <td bgcolor="#FFFF00" class="style23"><div align="center"> <a href="frmEditBox.jsp?memid=<%=mem_id%>&boxid=<%=rs.getString("box_id")%>">Edit</a></div></td>
            <td bgcolor="#FFFF00" class="style23"><div align="center">
                <input name="chkbox" type="checkbox" id="chkbox" value="<%=rs.getString("box_id")%>">
            </div></td>
        </tr>
        
        <% } //end loop%> 
        <tr>
          <td height="29" colspan="9" bgcolor="#FF6600"><input name="bear" type="checkbox" id="bear" value="1">
            <span class="style22">�ӹǳ��������ͧ���ͧ (load bearing ability) </span></td>
          </tr>
        <tr>
          <td height="29" colspan="9" bgcolor="#99CC00"><div align="center">
            <input name="Submit3" type="submit" class="style24" value="---&gt; Calculate &lt;---" >
          </div></td>
        </tr>
        </table>
    </form></td>
  </tr>
  
  <tr>
  
    <td height="16" colspan="4" valign="top" bgcolor="#FF6600"><div align="right"><span class="style2"><strong>&copy;&nbsp;Copyright 2006-2007. Smart Containter All rights reserved.</strong></span></div></td>
  </tr>
</table>
</body>
</html>
<%
rs.close();
stmt.close();
mycon.close();
%>