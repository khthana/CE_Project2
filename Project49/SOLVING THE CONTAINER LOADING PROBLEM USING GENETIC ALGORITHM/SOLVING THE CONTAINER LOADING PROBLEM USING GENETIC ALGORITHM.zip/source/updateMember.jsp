<%@ page contentType="text/html; charset=windows-874" language="java" import="java.sql.*" errorPage="" %>

<%@ include file = "connect.jsp" %>

<html>
<body>

<%
//����ѧ����� session ����Ѻ�˹�� index
if(session.getAttribute("sess_user") == null){

	response.sendRedirect("index.jsp");
	
}

//-----------get memid-------------------------

String mem_id = request.getParameter("id");

if(mem_id == ""){

	response.sendRedirect("index.jsp");
}

//-----------------�Ѻ��ҨҡẺ�����-----------------

String fname = request.getParameter("fname");
String lname = request.getParameter("lname");
String email = request.getParameter("email");
String address = request.getParameter("address");
String tel = request.getParameter("tel");
String company = request.getParameter("company");

//------------------update  member ------------------

String sql = "update member set mem_fname = '"+fname+"' , mem_lname = '"+lname+"' ,mem_email = '"+email+"', mem_address = '"+address+"', mem_tel = '"+tel+"' , mem_com = '"+company+"' where mem_id = '"+mem_id+"' ";

int myresult = stmt.executeUpdate(sql);

if(myresult != 0){
		
			out.println("<script>alert('��䢢�������Ҫԡ���º��������');</script>");
						
		}	
		else{
		
			out.println("<script>alert('��䢢�������Ҫԡ��������');history.back();</script>");
			
		}
		
stmt.close();
mycon.close();


%>

<script>
	
	window.location = "mainMember.jsp?id=<%=mem_id%>";

</script>


</body>
</html>
