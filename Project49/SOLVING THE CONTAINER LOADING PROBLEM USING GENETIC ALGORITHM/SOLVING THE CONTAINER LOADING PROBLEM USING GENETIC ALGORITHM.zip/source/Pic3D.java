package projectbean;
import com.sun.j3d.utils.picking.behaviors.*;
import com.sun.j3d.utils.picking.*;
import com.sun.j3d.utils.geometry.ColorCube;
import com.sun.j3d.utils.behaviors.vp.*;
import java.io.*;
import java.util.*;
import java.sql.*;

import java.awt.*;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.event.*;
import java.awt.Component;
import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.universe.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import java.awt.Point;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.JOptionPane;


class Pic3D extends Applet implements ActionListener{
	
	private View view = null;
	private SimpleUniverse u = null;
	JButton rotateB = new JButton("Rotate");
	RotationInterpolator rotator;

	JButton bn ;
	
	private Morph morph;

	private PickRotateBehavior behavior1;
	private PickZoomBehavior   behavior2;
	private PickTranslateBehavior behavior3;
	

	Vector TPoint;
	Vector ConPoint;
	Vector vBoxname;
	BranchGroup group;
	
	String col[] = {"cyan" , "green", "yellow", "magenta", "red", "blue","gray","light gray" ,"white", "dark blue"};
	
	private static int memid , rNO;
	
		
	public BranchGroup createSceneGraph(Canvas3D canvas) throws Exception {

		
	    // Create the root of the branch graph
	    BranchGroup objRoot = new BranchGroup();
	    
	
		
	    // Create a Transformgroup to scale all objects so they
	    // appear in the scene.
	    
	    TransformGroup objScale = new TransformGroup();
	    Transform3D t3d = new Transform3D();
	    t3d.setScale(0.5);
	    objScale.setTransform(t3d);
	   
	    objRoot.addChild(objScale);
	    
	   
	    // Create a bunch of objects with a behavior and add them
	    // into the scene graph.
	    
	    // ******************************* select data from table pic3D ***********************//
	    
	    double cx = (233 / 100 - 3) * (0.45) + 0.05 ;
	    double cy = (220 / 100 - 3) * (0.45) + 0.05 ;
	    double cz = (587 / 100 - 3) * (0.45) + 0.05 ;
	   

	    Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/Project?user=root&password=", "", "");
		Statement s = c.createStatement();
		
		ResultSet r = s.executeQuery("SELECT * FROM pic3D where mem_id = '"+memid+"' and r_NO = '"+rNO+"'");
		
		
		while (r.next()) {

		

			
			double xpos = (r.getDouble(4) / 100 - 3) * (0.45) + 0.05 ;
			double ypos = (r.getDouble(7) / 100 - 2) * (0.45) + 0.05;
			double zpos = (r.getDouble(3) / 100 - 3) * (0.45) + 0.05 ;
			
			String bname = r.getString(5);
			
			objScale.addChild(createObject(0.12,  xpos, ypos, zpos ,r.getDouble(6) , r.getDouble(8) , r.getDouble(9) ,r.getDouble(10), r.getDouble(11) ,bname ));
		
	
		}
		
	    s.close();
		c.close();
		
		

		
		BoundingSphere bounds =
	      new BoundingSphere(new Point3d(0.0,0.0,0.0), 100.0);
	
	    // Add a light.
	    Color3f lColor = new Color3f(1.0f, 1.0f, 1.0f) ;
	    Vector3f lDir  = new Vector3f(0.0f, 0.0f, -1.0f) ;
	
	    DirectionalLight lgt = new DirectionalLight(lColor, lDir) ;
	    lgt.setInfluencingBounds(bounds) ;
	   	objRoot.addChild(lgt) ;
	   	
	    
	   
		    
	     // Let Java 3D perform optimizations on this scene graph.
   		 objRoot.compile();
 
   		 return objRoot;
		
	}
	

	
	//*****************************************************//
	
	 private Group createObject(double scale, double xpos, double ypos, double zpos , double bx , double bz, double bw , double bh , double bd , String bname){
    
    
//    System.out.println("******** in method createObject *********** ");
    
    
	    Shape3D shape = null;
	    Geometry geom = null;
	     
	    // Create a transform group node to scale and position the object.
	    Transform3D t = new Transform3D();
	    t.set(scale, new Vector3d(xpos, ypos, zpos));
	    TransformGroup objTrans = new TransformGroup(t);
	    objTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	    objTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	    objTrans.setCapability(TransformGroup.ENABLE_PICK_REPORTING);
	    
	    // Create a second transform group node and initialize it to the
	    // identity.  Enable the TRANSFORM_WRITE capability so that
	    // our behavior code can modify it at runtime.
	    TransformGroup spinTg = new TransformGroup();
	    spinTg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
	    spinTg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
	    spinTg.setCapability(TransformGroup.ENABLE_PICK_REPORTING);
	 
	    Appearance appearance = new Appearance();
	    
	    
	     //---------------- set point of box in tower ----------------//
	    
	    double x,y,z , w,h,d;
	    
	    x = bx;
	    y = ypos;
	    z = bz;
	    w = bw;
	    h = bh;
	    d = bd;
	    
	    
	
				//************** define data Point ***************// 
				
						
					Point3D p = new Point3D();
					
					p.setPoint7(x+w, y, z);		// right-bottom-back	(1, -1, -1)
					p.setPoint6(x, y, z);		// left-bottom-back		(-1, -1, -1)
					p.setPoint5(x, y+h, z); 	// left-above-back		(-1, 1, -1)
					p.setPoint4(x+w, y+h, z); 	// right-above-back		(1, 1, -1)
					
					p.setPoint3(x+w, y, z+d); 	// right-bottom-front	(1, -1, 1)
					p.setPoint2(x, y, z+d);		// left-bottom-front	(-1, -1, 1)
					p.setPoint1(x, y+h, z+d);	// left-above-front		(-1, 1, 1)
					p.setPoint0(x+w, y+h, z+d); // right-above-front	(1, 1, 1)
						
					
					TPoint = new Vector();
					TPoint.add(p);
					
					geom = new Cube3D(TPoint , bname , vBoxname);
					
	
			
			
			
			shape = new Shape3D(geom,appearance);
			shape.setCapability(Shape3D.ALLOW_APPEARANCE_READ);
			shape.setCapability(Shape3D.ALLOW_APPEARANCE_WRITE);
			shape.setCapability(Shape3D.ENABLE_PICK_REPORTING);
			PickTool.setCapabilities(shape, PickTool.INTERSECT_FULL);
			spinTg.addChild(shape);
	
	

	//******************************************************//
			
			// add it to the scene graph. 
		    objTrans.addChild(spinTg);    
		    
		  
		    return objTrans;
			
			
	    
	}
	
	private void setupGUI(JPanel panel) {
     

		panel.setLayout(new FlowLayout());
		panel.setBorder(new BevelBorder(BevelBorder.RAISED));

		bn = new JButton("Show Data Boxes and color");
		panel.add(bn);
		
		bn.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e) {
      if(e.getSource() == bn){
      	
      	String boxall = new String();
      	
      	for(int i = 0 ; i < vBoxname.size() ; i++){
			
			String box = (String)vBoxname.get(i);
			
			
      		boxall = boxall + "\n" + box + "    :   " + col[i] ;
      	
      	}
      	
      	
      	JOptionPane.showMessageDialog(null,boxall,
				"Show Data Boxes", JOptionPane.INFORMATION_MESSAGE);
	
		
      }
      
    }
	
	//******************************************************//
	
	public Pic3D (int mem_id , int r_NO, Vector bname) {
		
		memid = mem_id;
		rNO = r_NO;
		vBoxname = new Vector(bname);
		

		
		System.out.println("vBoxname = " + vBoxname);
  	}
  	
  	public void init() {
  		System.out.println("******** init *********** ");
		setLayout(new BorderLayout());
		Canvas3D c = new Canvas3D(SimpleUniverse.getPreferredConfiguration());
		add("Center", c);
		
		JPanel guiPanel = new JPanel();
		setupGUI(guiPanel);
		add(guiPanel, BorderLayout.NORTH);
	
		// Create a scene and attach it to the virtual universe
		
		try{
		
			BranchGroup scene = createSceneGraph(c);
			
		
			u = new SimpleUniverse(c);
			
			// add mouse behaviors to the viewingPlatform
			ViewingPlatform viewingPlatform = u.getViewingPlatform();
			
			// This will move the ViewPlatform back a bit so the
			// objects in the scene can be viewed.
			viewingPlatform.setNominalViewingTransform();
			
			OrbitBehavior orbit = new OrbitBehavior(c,
						OrbitBehavior.REVERSE_ALL);
						
	BoundingSphere bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0),
						   100.0);
	orbit.setSchedulingBounds(bounds);
	viewingPlatform.setViewPlatformBehavior(orbit);
	
	
			u.addBranchGraph(scene);
		
		}
		
		catch(Exception e){
			
			
	
		}
    }

    public void destroy() {
		u.removeAllLocales();
    }
  
  
}