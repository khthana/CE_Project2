package projectbean;
import javax.media.j3d.*;
import javax.vecmath.*;
import java.util.*;

class Cube3D extends IndexedQuadArray {
	

	private float pos_x0, pos_y0, pos_z0;
	private float pos_x1, pos_y1, pos_z1;
	private float pos_x2, pos_y2, pos_z2;
	private float pos_x3, pos_y3, pos_z3;
	private float pos_x4, pos_y4, pos_z4;
	private float pos_x5, pos_y5, pos_z5;
	private float pos_x6, pos_y6, pos_z6;
	private float pos_x7, pos_y7, pos_z7;
	
	private float colx, coly , colz;
	
	float col_x[] = {0.0f,0.0f,1.0f,1.0f,1.0f,0.0f,0.2f,0.6f,1.0f,0.05f};
	float col_y[] = {1.0f,1.0f,1.0f,0.0f,0.0f,0.0f,0.2f,0.6f,1.0f,0.05f};
	float col_z[] = {1.0f,0.0f,0.0f,1.0f,0.0f,1.0f,0.2f,0.6f,1.0f,0.2f};
	

	public Cube3D(Vector TPoint , String bname , Vector vBoxname)  {
    	
    	
			
		super(8, GeometryArray.COORDINATES | GeometryArray.COLOR_3, 24);
	
//		System.out.println("******** in method cube3D *********** " );
		
		Point3f verts[] = new Point3f[8];
		Color3f colors[] = new Color3f[8];
	
	//************************************//
	
		for(int i = 0 ; i < TPoint.size() ; i ++ ){
					
			Point3D p = (Point3D)TPoint.get(i);
					
					
			//	System.out.println("********** show point ***********" + p.showPoint());
				
				pos_x0 = (float)p.getPoint_x0() / 28;
				pos_y0 = (float)p.getPoint_y0() / 28;
				pos_z0 = (float)p.getPoint_z0() / 28;
				
				pos_x1 = (float)p.getPoint_x1() / 28;
				pos_y1 = (float)p.getPoint_y1() / 28;
				pos_z1 = (float)p.getPoint_z1() / 28;
				
				pos_x2 = (float)p.getPoint_x2() / 28;
				pos_y2 = (float)p.getPoint_y2() / 28;
				pos_z2 = (float)p.getPoint_z2() / 28;
				
				
				pos_x3 = (float)p.getPoint_x3() / 28;
				pos_y3 = (float)p.getPoint_y3() / 28;
				pos_z3 = (float)p.getPoint_z3() / 28;
				
				pos_x4 = (float)p.getPoint_x4() / 28;
				pos_y4 = (float)p.getPoint_y4() / 28;
				pos_z4 = (float)p.getPoint_z4() / 28;
				
				pos_x5 = (float)p.getPoint_x5() / 28;
				pos_y5 = (float)p.getPoint_y5() / 28;
				pos_z5 = (float)p.getPoint_z5() / 28;
				
				pos_x6 = (float)p.getPoint_x6() / 28;
				pos_y6 = (float)p.getPoint_y6() / 28;
				pos_z6 = (float)p.getPoint_z6() / 28;
				
				pos_x7 = (float)p.getPoint_x7() / 28;
				pos_y7 = (float)p.getPoint_y7() / 28;
				pos_z7 = (float)p.getPoint_z7() / 28;
				
		}
		
		for(int i = 0 ; i < vBoxname.size() ; i++){
			
			String bn = (String)vBoxname.get(i);
			
		//	System.out.println("box name = " + bname + " vBoxname = " + bn);
			
			if(bname.equals(bn) == true){
				
				colx = col_x[i];
				coly = col_y[i];
				colz = col_z[i];
				
			//		System.out.println("colx = " + colx + " coly = " + coly + " colz = " + colz);
				
			}
		}
		
	/*	System.out.println("x0 = " + pos_x0);
		System.out.println("y0 = " + pos_y0);
		System.out.println("z0 = " + pos_z0);
	*/

	verts[0] = new Point3f(pos_x0, pos_y0, pos_z0);
	verts[1] = new Point3f(pos_x1, pos_y1, pos_z1);
	verts[2] = new Point3f(pos_x2, pos_y2, pos_z2);
	verts[3] = new Point3f(pos_x3, pos_y3, pos_z3);
	verts[4] = new Point3f(pos_x4, pos_y4, pos_z4);
	verts[5] = new Point3f(pos_x5, pos_y5, pos_z5);
	verts[6] = new Point3f(pos_x6, pos_y6, pos_z6);
	verts[7] = new Point3f(pos_x7, pos_y7, pos_z7);
	
	colors[0] = new Color3f(colx, coly, colz);
	colors[1] = new Color3f(colx, coly, colz);
	colors[2] = new Color3f(colx, coly, colz);
	colors[3] = new Color3f(colx, coly, colz);
	colors[4] = new Color3f(1.0f, 1.0f, 1.0f);
	colors[5] = new Color3f(0.05f, 0.05f, 0.2f);
	colors[6] = new Color3f(colx, coly, colz);
	colors[7] = new Color3f(colx, coly, colz);
	
	int pntsIndex[] = new int[24];
	int clrsIndex[] = new int[24];
	
	pntsIndex[0] = 0;
	clrsIndex[0] = 0;
	pntsIndex[1] = 3;
	clrsIndex[1] = 0;
	pntsIndex[2] = 7;
	clrsIndex[2] = 0;
	pntsIndex[3] = 4;
	clrsIndex[3] = 0;

	pntsIndex[4] = 1;
	clrsIndex[4] = 1;
	pntsIndex[5] = 5;
	clrsIndex[5] = 1;
	pntsIndex[6] = 6;
	clrsIndex[6] = 1;
	pntsIndex[7] = 2;
	clrsIndex[7] = 1;

	pntsIndex[8]  = 0;
	clrsIndex[8]  = 2;
	pntsIndex[9]  = 4;
	clrsIndex[9]  = 2;
	pntsIndex[10] = 5;
	clrsIndex[10] = 2;
	pntsIndex[11] = 1;
	clrsIndex[11] = 2;

	pntsIndex[12] = 3;
	clrsIndex[12] = 3;
	pntsIndex[13] = 2;
	clrsIndex[13] = 3;
	pntsIndex[14] = 6;
	clrsIndex[14] = 3;
	pntsIndex[15] = 7;
	clrsIndex[15] = 3;

	pntsIndex[16] = 0;
	clrsIndex[16] = 4;
	pntsIndex[17] = 1;
	clrsIndex[17] = 4;
	pntsIndex[18] = 2;
	clrsIndex[18] = 4;
	pntsIndex[19] = 3;
	clrsIndex[19] = 4;

	pntsIndex[20] = 7;
	clrsIndex[20] = 5;
	pntsIndex[21] = 6;
	clrsIndex[21] = 5;
	pntsIndex[22] = 5;
	clrsIndex[22] = 5;
	pntsIndex[23] = 4;
	clrsIndex[23] = 5;

	setCoordinates(0, verts);
	setCoordinateIndices(0, pntsIndex);
	setColors(0, colors);
	setColorIndices(0, clrsIndex);
    }
}
