package projectbean;
import java.io.*;
import java.util.*;
import java.util.Vector;
import java.sql.*;

public class ReadData{
	Vector v = new Vector();
	Vector vSort = new Vector();
	

	
public void doReadData(int memid, int rNO) throws Exception , StackOverflowError {
		double x,y,z;
		
		System.out.println("----------------- Read Data all Box -----------------");
		
		//---------------------select data from database-------------------------
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/Project?user=root&password=", "", "");
		Statement s = c.createStatement();
		
		ResultSet rs = s.executeQuery("select * from result where mem_id = '"+memid+"' and r_NO = '"+rNO+"' order by r_NO desc");
		
		int i = 0;
		while (rs.next()){
			
			//---------------select num Box ----------------
			String numBox = rs.getString("r_box_num");
			int numbox = Integer.parseInt(numBox);
			
			for(int j = 0 ; j<numbox ;j++){
				
			
				Boxes b = new Boxes();
				
				//---------------select mem_id----------------
				String mem_id = rs.getString("mem_id");
				int mem = Integer.parseInt(mem_id);
			
				//---------------select r_id-----------------
				String r_id = rs.getString("r_id");
				int r = Integer.parseInt(r_id);
				
				//---------------select r_no-----------------
				String r_no = rs.getString("r_NO");
				int r_NO = Integer.parseInt(r_no);
				
				//---------------select box_name-----------------
				String boxname = rs.getString("r_box_name");
			
				
				//---------------select weight -----------------
				String weight = rs.getString("r_box_weight");
				double w = Double.parseDouble(weight);
				
				
				//----------------select width , height , depth ------------------
			
				String width = rs.getString("r_box_width");
				x = Double.parseDouble(width);
				
				String height = rs.getString("r_box_length");
				y = Double.parseDouble(height);
				
				String depth = rs.getString("r_box_depth");
				z = Double.parseDouble(depth);
					
													
						b = new Boxes();
						
						b.setBoxes(x,y,z);
						//b.setCoordinate(0,0,0);
						b.setWeight(w);
						
						//-----set mem_id & r_id & r_NO & boxname-------
						b.setMemid(mem);
						b.setRid(r);
						b.setRno(r_NO);
						b.setBoxname(boxname);
						
						//-----------------------------
						
						
						v.add(i,b);
	
									
						++i;
			}
		}
				
				s.close();
				c.close();
			
	
		

}
	
public void sortBox(){
	
	int index, indexOfNextMax;
	int size = v.size();
	
	for(index = 0 ; index < size - 1 ; index++){
		
		indexOfNextMax = indexOfNextMax(index);
		
		interchange(index, indexOfNextMax);
	}	
	
	
	
}


private int indexOfNextMax(int startIndex){
	
	double max = 0, num = 0;
	int index;
	
	Boxes box = (Boxes)v.elementAt(startIndex);
	max = box.volBox();
	
	int indexOfMax = startIndex;
	int size = v.size();
	
	for(index = startIndex + 1 ; index < size ; index++){
		
		Boxes tempbox = (Boxes)v.elementAt(index);
		
		num = tempbox.volBox();
	
	
		if(num > max){
			
			max = num;
			indexOfMax = index;
			
		}
		
	}
	
	return indexOfMax;
}

private void interchange(int i, int j){
	
	Boxes temp1 = (Boxes)v.elementAt(i);
	Boxes temp2 = (Boxes)v.elementAt(j);
	
	v.setElementAt(temp1,j);
	v.setElementAt(temp2,i);
	
}
	
	
	public Vector returnReadData(){
		
		for(int i = 0 ; i < v.size() ; i++){
			
			Boxes b = (Boxes)v.get(i);
			
			System.out.println("box sort bSort = " + b.volBox());
		}
		
	
		return v;
	}
	

}