package projectbean;
import java.io.*;
import java.util.*;
import java.sql.*;

public class CreateTowerSet {
	
	
	Vector tset = new Vector();
	Vector BFree = new Vector();

	Vector BFreeNotPacked = new Vector();
	
	
	private int nsteps = 5;
	
	
	public void doCreateTowerSet(int memid, int rNO , int bear) throws Exception , StackOverflowError{
		
		
	
		ReadData r = new ReadData();
		r.doReadData(memid, rNO);
		r.sortBox();
			
		
		
		for(int istep=1; istep<=nsteps; istep++){
			
			Vector TNew = new Vector();
					
			if(istep == 1){
				
				BFree = new Vector(r.returnReadData());
				
	//			System.out.println("BFree First = " + BFree);
				
			}
			
			if(istep > 1 && istep <= nsteps){
				
				BFree = BFreeNotPacked;
	//			System.out.println("BFreeNotPacked = " + BFree);
				
				if(BFree.size() == 0){
					
					break;
				}
			}
		
			//**************** for all box in BFree **************//
			
			for(int i = 0; i < BFree.size(); i++){
				
				
				Boxes bbasis = (Boxes)BFree.get(i);
				
	//			System.out.println("Vol bbasis = " + bbasis.volBox());
				
				Boxes newbox = new Boxes();
				newbox.setBoxes(bbasis.getBdimx(), bbasis.getBdimy(), bbasis.getBdimz());
				newbox.setCoordinate(0,0,0);
				newbox.setWeight(bbasis.getWeight());
				newbox.setMemid(bbasis.getMemid());
				newbox.setRid(bbasis.getRid());
				newbox.setRno(bbasis.getRno());
				newbox.setBoxname(bbasis.getBoxname());
				
				
				//BFree.remove(bbasis);
				
				Tower t = new Tower();
				
				CreateTower obj = new CreateTower();
				boolean result = obj.doCreateTower(newbox, bbasis , BFree , t, bear);
				
						
				if(result == true){
					
					
					TNew.add(t);	
					
	//				System.out.println("++++++++ Create Tower Success +++++++++");
	//				System.out.println("TNew = " + TNew);
				}
			
				
				if(istep == nsteps){
						
					removeBFree(t);
				
				}
				
			}
			
				
			
			if(istep < nsteps){
				
	//			System.out.println("*************** Sort Tnew ***************");
	//			System.out.println("TNew = " + TNew);
				
				TNew = sortTNew(TNew);
				
	//			System.out.println("*************** remove tower in Tnew ***************");
			//	TNew = removeSameBox(TNew);
	//			System.out.println("TNew = " + TNew);
				
			}
			
			
			
			BFreeNotPacked = returnBFreeNotPacked(TNew);
	//		System.out.println("BFreeNotPacked = " + BFreeNotPacked);
				
			tset = addTset(TNew,tset);
	//		System.out.println("tset = " + tset);
			
			
		
		}
		
		tset = sortTset(tset);
		

	}
	
	
	public Vector removeSameBox(Vector tempTNew){
		
			
		Vector tempTBoxPacked = new Vector();
		
	
			//------------ tower first ----------------//
			
		for(int x = 0 ; x<tempTNew.size() ; x++){
			
			System.out.println("-------------------- size tempTNew --------------- = " + tempTNew.size());
			
			Tower t_first = (Tower)tempTNew.get(x);
			System.out.println("t first  = " + t_first);
			
			for(int j = 0; j<t_first.tboxes.size(); j++){
				
				
					Boxes b_packed = (Boxes)t_first.tboxes.get(j);
					tempTBoxPacked.add(b_packed);	
						
				
						
			}
	//			System.out.println("tempTBox packed = " + tempTBoxPacked);
			
			//------------- tower other --------------//	
			
			for(int k = 0 ; k<tempTBoxPacked.size() ; k++){
				
				Boxes b_packed = (Boxes)tempTBoxPacked.get(k);
				
				for(int i = 1 ; i<tempTNew.size() ; i++){
					
					Tower t = (Tower)tempTNew.get(i);
					System.out.println("t in TNew  = " + t);
					
					
					for(int j = 0; j<t.tboxes.size(); j++){			
												
						Boxes b = (Boxes)t.tboxes.get(j);
						
				//compare box , if box in other TNew = box in first TNew then remove that other TNew//
							
							if(b_packed == b){
								
		//						System.out.println("++++++++++++ TNew before +++++++++ = " + tempTNew);
		//						System.out.println();
								
								tempTNew.remove(t);
								
		//						System.out.println("+++++++++++ TNew after ++++++++++ = " + tempTNew);
		//						System.out.println();
							}
						
							
					}
				}
			}
		}
			
		
		return tempTNew;
	}
	
	public Vector returnBFreeNotPacked(Vector tempTNew){
		
	//	System.out.println("********************* BFree = " + BFree);
		
				
		for(int i = 0 ; i<tempTNew.size() ; i++){
			Tower t = (Tower)tempTNew.get(i);			
			
			for(int j = 0; j<t.tboxes.size(); j++){			
										
				Boxes b_packed = (Boxes)t.tboxes.get(j);
				
				for(int k = 0 ; k<BFree.size(); k++){
					
					Boxes bfree = (Boxes)BFree.get(k);
					
					if(b_packed == bfree){
						
						BFree.remove(b_packed);
						
					}
				}
			}
			
		}
		
		
				
		return BFree;
		
	}
	

		
	public Vector addTset(Vector vTNew , Vector vtset){
	
		Vector temp = new Vector();
		
	//	System.out.println("************* add tset *************");
			
		if(vtset.size() == 0){
			
			for(int k=0; k < vTNew.size(); k++){
				
				Tower t = (Tower)vTNew.get(k);
				temp.add(t);
			
				
			}
		
		}
		
		else {
			
			for(int i = 0 ; i < vTNew.size() ; i++){
				
				for(int j = 0 ; j < vtset.size() ; j++){
					
					Tower tnew = (Tower)vTNew.get(i);
					Tower tset = (Tower)vtset.get(j);
					
					if(tset.tboxes.equals(tnew.tboxes) == true){
						
						vTNew.remove(tnew);
					}
				}
				
				
				
			}
			
		
			for(int l = 0; l < vtset.size(); l++){
				
				temp.add((Tower)vtset.get(l));
		
			}
			
			for(int m = 0; m < vTNew.size(); m++){
				
				temp.add((Tower)vTNew.get(m));
			
			}
		}
		
		
		return temp;
	}
	
//********************** Sort TNew *****************//
	
public Vector sortTNew(Vector v){
	
	int index, indexOfNextMax;
	int size = v.size();
	
	for(index = 0 ; index < size - 1 ; index++){
		
		indexOfNextMax = indexOfNextMaxTNew(index, v);
		
		interchangeTNew(index, indexOfNextMax, v);
	}	
	
	return v;
	
	
	
}


private int indexOfNextMaxTNew(int startIndex, Vector v){
	
	double max = 0, num = 0;
	int index;
	
	Tower t = (Tower)v.elementAt(startIndex);
	max = t.getTvalue();
	
	int indexOfMax = startIndex;
	int size = v.size();
	
	for(index = startIndex + 1 ; index < size ; index++){
		
		Tower tempT = (Tower)v.elementAt(index);
		
		num = tempT.getTvalue();
	
	
		if(num > max){
			
			max = num;
			indexOfMax = index;
			
		}
		
	}
	
	return indexOfMax;
}

private void interchangeTNew(int i, int j, Vector v){
	
	Tower temp1 = (Tower)v.elementAt(i);
	Tower temp2 = (Tower)v.elementAt(j);
	
	v.setElementAt(temp1,j);
	v.setElementAt(temp2,i);
	
}

//********************** Sort tset *****************//

public Vector sortTset(Vector v){
	
	int index, indexOfNextMax;
	int size = v.size();
	
	for(index = 0 ; index < size - 1 ; index++){
		
		indexOfNextMax = indexOfNextMaxTset(index, v);
		
		interchangeTset(index, indexOfNextMax, v);
	}	
	
	return v;
	
	
	
}


private int indexOfNextMaxTset(int startIndex, Vector v){
	
	double max = 0, num = 0;
	int index;
	
	Tower t = (Tower)v.elementAt(startIndex);
	max = t.getTarea();
	
	int indexOfMax = startIndex;
	int size = v.size();
	
	for(index = startIndex + 1 ; index < size ; index++){
		
		Tower tempT = (Tower)v.elementAt(index);
		
		num = tempT.getTarea();
	
	
		if(num > max){
			
			max = num;
			indexOfMax = index;
			
		}
		
	}
	
	return indexOfMax;
}

private void interchangeTset(int i, int j, Vector v){
	
	Tower temp1 = (Tower)v.elementAt(i);
	Tower temp2 = (Tower)v.elementAt(j);
	
	v.setElementAt(temp1,j);
	v.setElementAt(temp2,i);
	
}

	public void removeBFree(Tower t){
		for(int i = 0; i<t.tboxes.size(); i++){
			Boxes b = (Boxes)t.tboxes.get(i);
			int position = BFree.indexOf(t.tboxes.get(i));
			
			System.out.println("b = " + b);
			
			System.out.println("position = " + position);
			if (position != -1){
				BFree.remove(position);
				
				System.out.println("BFree remove position = " + BFree);
			}
		}
	}
	


}