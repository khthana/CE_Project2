# MySQL-Front 3.0  (Build 30.1)


# Host: demo    Database: project
# ------------------------------------------------------
# Server version 4.0.16-max-debug

USE `project`;

#
# Table structure for table box
#

CREATE TABLE `box` (
  `box_id` int(11) NOT NULL auto_increment,
  `box_name` varchar(100) NOT NULL default '',
  `box_width` double(7,2) NOT NULL default '0.00',
  `box_length` double(7,2) NOT NULL default '0.00',
  `box_depth` double(7,2) NOT NULL default '0.00',
  `box_weight` double(7,2) NOT NULL default '0.00',
  `box_num` int(5) NOT NULL default '0',
  `mem_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`box_id`)
) TYPE=MyISAM;


#
# Dumping data for table box
#

INSERT INTO `box` VALUES (1,'',12,34,45,24,100,1);
INSERT INTO `box` VALUES (2,'',12,22,233,44,10000,1);
INSERT INTO `box` VALUES (7,'monkey',45,50,67,80,90,3);
INSERT INTO `box` VALUES (5,'',123,2312,123,23,12,1);
INSERT INTO `box` VALUES (6,'',20,55,60,78,100,1);
INSERT INTO `box` VALUES (21,'panda',89,89,786,68,88,3);
INSERT INTO `box` VALUES (18,'orange bear',10,10,10,200,504,3);
INSERT INTO `box` VALUES (25,'jingjok',12,44,55,66,77,3);
INSERT INTO `box` VALUES (23,'',111,234,456,666,44444,1);
INSERT INTO `box` VALUES (26,'',12,34,3423,34,55555,1);
INSERT INTO `box` VALUES (27,'',445,33,56,78,90,1);
INSERT INTO `box` VALUES (28,'',33,12,46,56,23,1);
INSERT INTO `box` VALUES (29,'',111,222,333,44.5,500,1);
INSERT INTO `box` VALUES (30,'',456,1,6067.99,565.7,1,1);
INSERT INTO `box` VALUES (31,'',100,100,250.7,56.8,2000,1);
INSERT INTO `box` VALUES (32,'',25,50.6,45.68,45,500,1);
INSERT INTO `box` VALUES (33,'',23.98,56.76,56.89,54.9,657,1);
INSERT INTO `box` VALUES (43,'',34.78,3434,345.79,5.76,1000,1);
INSERT INTO `box` VALUES (36,'TV',45.9,67.8,45.7,56.79,10000,3);
INSERT INTO `box` VALUES (38,'table',9,2,3,999,5,3);
INSERT INTO `box` VALUES (45,'',34.5,67.48,60,90.66,150,26);
INSERT INTO `box` VALUES (42,'bed',2,2,2,2,299,3);
INSERT INTO `box` VALUES (74,'',1,12,34,2,23,25);
INSERT INTO `box` VALUES (73,'',10,15.5,30,34,342,2);
INSERT INTO `box` VALUES (72,'',50,56,40,456.77,10000,2);
INSERT INTO `box` VALUES (70,'',501,343,234,234,155,26);
INSERT INTO `box` VALUES (69,'',2,2,2,243,34,26);
INSERT INTO `box` VALUES (94,'�÷�ȹ�',25,50,36,50,2,27);
INSERT INTO `box` VALUES (95,'˹ѧ���',36,36.8,40,30,3,27);
INSERT INTO `box` VALUES (96,'case computer',40,46.57,43,60,5,27);
INSERT INTO `box` VALUES (97,'',5,5,78,567,56,25);
INSERT INTO `box` VALUES (98,'',99,99,99,99,999,25);
INSERT INTO `box` VALUES (99,'',25.6,34.5,35,20,60,2);
INSERT INTO `box` VALUES (100,'',36.2,72.5,80,100,100,2);
INSERT INTO `box` VALUES (101,'',20,60.5,50,200,90,2);
INSERT INTO `box` VALUES (102,'',40,40,40,90,978,2);
INSERT INTO `box` VALUES (103,'',35,35,35,80,80,2);
INSERT INTO `box` VALUES (104,'',40,50,50,80,80,2);
INSERT INTO `box` VALUES (105,'',35,45,50,60,60,2);
INSERT INTO `box` VALUES (106,'',70,70,40,60,60,2);
INSERT INTO `box` VALUES (107,'',50,60,70,50,789,2);
INSERT INTO `box` VALUES (108,'',40,50,50,600,78,2);
INSERT INTO `box` VALUES (110,'',1,12,22,43,34,1);
INSERT INTO `box` VALUES (111,'',20,40,10,5,10,1);
INSERT INTO `box` VALUES (112,'',34,324,23,34,23,26);
INSERT INTO `box` VALUES (113,'',50,69,67,67,456,26);
INSERT INTO `box` VALUES (114,'monitor LCD 17 ����',50,56,40,34,4,27);
INSERT INTO `box` VALUES (115,'�����',10,15.5,30,60,5,27);
INSERT INTO `box` VALUES (116,'shirt',25.6,34.5,35,45,6,27);
INSERT INTO `box` VALUES (117,'keyboard',36.2,72.5,80,50,8,27);
INSERT INTO `box` VALUES (118,'mouse',20,60.5,50,69,10,27);
INSERT INTO `box` VALUES (119,'ups',40,40,40,50,5,27);
INSERT INTO `box` VALUES (120,'card electronic',50,60,70,67,8,27);
INSERT INTO `box` VALUES (121,'notebook',45,50,60,80,100,27);
INSERT INTO `box` VALUES (122,'computer',4,4,4,4,4,3);
INSERT INTO `box` VALUES (123,'������',55.5,70,40.8,20,2,27);

