# MySQL-Front 3.0  (Build 30.1)


# Host: demo    Database: project
# ------------------------------------------------------
# Server version 4.0.16-max-debug

#
# Table structure for table total
#

CREATE TABLE `total` (
  `total_id` int(11) NOT NULL auto_increment,
  `total_vol` double(10,2) NOT NULL default '0.00',
  `total_numbox` int(10) NOT NULL default '0',
  `mem_id` int(11) NOT NULL default '0',
  `r_NO` int(11) NOT NULL default '0',
  PRIMARY KEY  (`total_id`)
) TYPE=MyISAM;


#
# Dumping data for table total
#

INSERT INTO `total` VALUES (1,28790390,616,0,0);
INSERT INTO `total` VALUES (2,28505190,107,0,0);
INSERT INTO `total` VALUES (3,28790390,104,2,21);
INSERT INTO `total` VALUES (4,28505190,107,2,28);
INSERT INTO `total` VALUES (5,28505190,107,26,5);
INSERT INTO `total` VALUES (6,25803120,96,2,29);
INSERT INTO `total` VALUES (7,26211360,95,2,30);
INSERT INTO `total` VALUES (8,26329610,96,2,31);
INSERT INTO `total` VALUES (9,26781510,100,2,21);

