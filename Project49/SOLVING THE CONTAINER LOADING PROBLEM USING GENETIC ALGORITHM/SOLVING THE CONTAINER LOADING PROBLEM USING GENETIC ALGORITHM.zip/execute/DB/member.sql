# MySQL-Front 3.0  (Build 30.1)


# Host: demo    Database: project
# ------------------------------------------------------
# Server version 4.0.16-max-debug

USE `project`;

#
# Table structure for table member
#

CREATE TABLE `member` (
  `mem_id` int(11) NOT NULL auto_increment,
  `mem_user` varchar(25) NOT NULL default '',
  `mem_pwd` varchar(16) NOT NULL default '',
  `mem_fname` varchar(50) NOT NULL default '',
  `mem_lname` varchar(50) NOT NULL default '',
  `mem_email` varchar(50) NOT NULL default '',
  `mem_address` varchar(255) NOT NULL default '',
  `mem_tel` varchar(10) NOT NULL default '0',
  `mem_com` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`mem_id`)
) TYPE=MyISAM;


#
# Dumping data for table member
#

INSERT INTO `member` VALUES (1,'jingjok','12345678','ae','doy','jingjok13@hotmail.com','eiei hahahahaha\r\n\r\n\r\n\r\n','093423234','jingjok company');
INSERT INTO `member` VALUES (2,'ae','12345678','jingjokDoy','eieiei','dekdoy@hotmail.com','','12323213','');
INSERT INTO `member` VALUES (3,'chaiya','77777777','546','kug','utg@hotmail.com','hahahahaha\r\n\r\n\r\n\r\n','87','eiei');
INSERT INTO `member` VALUES (27,'test','12345678','���ͺ','test','test@test.com','���͡\r\n','','���ͺ�к�');
INSERT INTO `member` VALUES (25,'jingjokjingjok','12345678','jingjokDoy','eieieiei','art_badge@yahoo.com','','','fddsd');
INSERT INTO `member` VALUES (26,'ae_kmitl','12345678','Rachadaporn','Mongkolnit','jingjok13@hotmail.com','Bangkok','','');
INSERT INTO `member` VALUES (28,'���','12345678','�Ѫ�Ҿ�','���ŹԵ��','jingjok13@hotmail.com','��ا෾','','');

