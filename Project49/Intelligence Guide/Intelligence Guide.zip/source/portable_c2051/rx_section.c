 #include <reg51.h>

sbit CS = P3^2;
sbit CE = P3^3;
sbit DAT = P3^4;
sbit CLK = P3^5;
sbit DR1 = P3^7;

sbit latch = P3^0;


#define MODE_TX 0
#define MODE_RX 1

void Wait(unsigned char n)
{
	while (n--) ;
}

void Init_TRW24G(void)
{
	CE  = 0;
	CS  = 0;
	CLK = 0;
	DAT = 0;
	DR1 = 0;
	Wait(1);
}

void CLK_TRW24(void)
{
	CLK = 0;
	CLK = 1;
}

void Write_TRW24(unsigned char Data)
{
	unsigned char i;
	bit Out;
	for (i=0;i<8;i++)
	{
		Out = Data & 0x80;
		DAT = Out;
		CLK_TRW24();
		Data = Data << 1;
	}
}
unsigned char Read_TRW24(void)
{
	unsigned char i,Temp;
	bit Out;
	DAT = 1;
	for (i=0;i<8;i++)
	{
		Temp = Temp << 1;
		CLK = 1; Wait(1);
		Out = DAT;
		if (Out) { Temp = Temp + 0x01;}
		CLK = 0; Wait(1);
	}
	return(Temp);
}
void SetMode_TRW24( unsigned char Mode)
{
	Wait(1);
	CE = 0;
	CS = 1;
	Write_TRW24(0x8E); /* Reserved for testing */
	Write_TRW24(0x08); /* Reserved for testing */
	Write_TRW24(0x1C); /* Reserved for testing */

	Write_TRW24(0x08); /* Length of Bit Ch 2 */
	Write_TRW24(0x08); /* Length of Bit Ch 1 */

	Write_TRW24(0xD1); /* Address 5 Byte Ch 2 */
	Write_TRW24(0xAA);
	Write_TRW24(0x55);
	Write_TRW24(0xAA);
	Write_TRW24(0x55);

	Write_TRW24(0xB5); /* Address 5 Byte Ch 1 */
	Write_TRW24(0x55);
	Write_TRW24(0xAA);
	Write_TRW24(0x55);
	Write_TRW24(0xAA);

	Write_TRW24(0xA3); /* Number of Address bit + CRC */
	Write_TRW24(0x4F); /* RF Programming */
	Write_TRW24(0x0A+Mode);

	DAT = Mode;
	DR1 = Mode;
	CE = Mode;

	CS = 0;
	Wait(1);
}

void Send_TRW24(unsigned char Data)
{
	Wait(1);
	CS = 0;
	CE = 1;
	Write_TRW24(0xB5); /* Address 5 Byte Ch 1 */
	Write_TRW24(0x55);
	Write_TRW24(0xAA);
	Write_TRW24(0x55);
	Write_TRW24(0xAA);

	Write_TRW24(Data); /* Data 8 bit */
	Wait(1);
	CLK = 0;
	CE = 0;
	Wait(1);
}

void delay(unsigned char tick)
{
	unsigned char i,j;
	for(i=0;i<tick;i++)
	for(j=0;j<1000;j++);
}

void main()
{
	unsigned char point = 0x00;
	unsigned char store_point = 0xFF;
	unsigned char show_point = 0xFF;
	unsigned char count_times = 0;
	int count_delay = 30000;
	int count2 = 10;
	latch = 1;
	Init_TRW24G();
	SetMode_TRW24(MODE_RX);	
   	while (1) {
		count_delay = 30000;
		count2 = 10;
		while (!DR1 && count2 > 0){
			count_delay--;
			if(count_delay == 0){
				count_delay = 30000;
				count2--;
			}
		}
		if(count2 > 0){
	  		point = Read_TRW24();
		}else{
			point = 0xFF;
		}
		
		if(store_point == point){
			count_times++;
		}else{
			count_times = 0;
	  		store_point = point;
		}
		if(count_times > 5){
			count_times = 0;
			show_point = point;
		}
		P1 = show_point;
	}

}


 
 

