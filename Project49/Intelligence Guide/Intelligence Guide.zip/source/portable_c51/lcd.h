#define LCD_PORT P0
sbit e = P3^4;  //Edit to E-pin
sbit rs = P3^5; //Edit to RS-pin

void delayLcd(int tick)
{
	unsigned int i,j;
	for(i=0;i<tick;i++)
	for(j=0;j<250;j++);
}

void lcd_command(unsigned char comm)
{
	rs = 0;
	e = 1;
	LCD_PORT = comm;
	delayLcd(10);
	e = 0;
	delayLcd(10);
}

void lcd_text(unsigned char text)
{
	rs = 1;
	e = 1;
	LCD_PORT = text;
	delayLcd(10);
	e = 0;
	delayLcd(10);
} 

void lcd_select_addr(unsigned char addr)
{
	unsigned char real;
	real = 0x80 + addr;
	lcd_command(real);	
}

void lcd_clear(void)
{
	lcd_command(0x01);
}

void lcd_origin(void)
{
	lcd_command(0x02);
}

void lcd_init(void)
{
	delayLcd(250); //not 500 because char = 1 byte 0-255
	delayLcd(250);
	lcd_command(0x38);
	lcd_command(0x0C);
	lcd_command(0x01);
}

