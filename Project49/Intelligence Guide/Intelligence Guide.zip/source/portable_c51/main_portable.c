#include <reg51.h>
#include <lcd.h>
#include <sound.h>
#define IN_RF P1
code unsigned char first_line[] = "I-Guide";
code unsigned char volume_line[] = "Volume";
code unsigned char station[] = "Station : ";
code unsigned char no_signal[] = "No Signal";
code unsigned char sound_addr[] = {
	0x00, 	/*0 Station*/
	0x03,	/*1*/
	0x05,	/*2*/
	0x07,	/*3*/
	0x09,	/*4*/
	0x0B,	/*5*/
	0x0D,	/*6*/
	0x0F,	/*7*/
	0x20,	/*8*/
	0x22,	/*9*/
	0x24,	/*10*/
	0x26,	/*11 100*/
	0x28,	/*12 2-*/
	0x2A,	/*13 -1*/
	0x2C};	/*14 No Station*/

sbit sw_up =P3^0;
sbit sw_down =P3^1;
sbit sw_pp =P3^2;
sbit sw_stop =P3^3;
bit update = 1;
unsigned char addr = 0; 
unsigned char addr_sh = 0; 
unsigned char vol_level = 5;
unsigned char input_rf=0;

void sendNum2LCD(unsigned char num){
	unsigned char x = 0;
	x = num/100;
	lcd_text(0x30 | x);
	x = (num%100)/10;
	lcd_text(0x30 | x);
	x = num%10;
	lcd_text(0x30 | x);
}



void sendNum2Sound(unsigned char num){
	unsigned char x;
	unsigned char y;
	unsigned char z;
	bit have = 0;
	play_addr(sound_addr[0]);
	delay(1200);
	x = num/100;
	if(x>0){
		play_addr(sound_addr[x]);
		delay(500);
		play_addr(sound_addr[11]);
		delay(500);
		have = 1;
	}
	y = (num%100)/10;
	if(y>0){
		if(y>2){
			play_addr(sound_addr[y]);
			delay(750);
		}else if(y>1){
			play_addr(sound_addr[12]);
			delay(750);
		}
		play_addr(sound_addr[10]);
		delay(500);
		have = 1;
	}
	z = num%10;
	if(z>0){
		if(z==1 && have)
			play_addr(sound_addr[13]);
		else
			play_addr(sound_addr[z]);
		delay(500);
	}
}

void main(){
	unsigned char i = 0;
	unsigned char temp = 0;
	unsigned char index_sound = 0;
	lcd_init();
	sound_init();
	lcd_select_addr(0x00);
	for(i=0;i<7;i++) lcd_text(first_line[i]);
	while(1){
		input_rf = IN_RF;
		temp = input_rf&0xC0;
		if(temp == 0x80){
			input_rf = input_rf&0x3F;
		}else{
			input_rf = 0x00;
		}
		if(addr != input_rf){
			addr = input_rf;
			update = 1;
		}
		if(update){
			lcd_clear();
			lcd_select_addr(0x00);
			for(i=0;i<7;i++) lcd_text(first_line[i]);
			if(addr == 0x00){
				lcd_select_addr(0x40);	
				for(i=0;i<9;i++) lcd_text(no_signal[i]);
				play_addr(sound_addr[14]);
				delay(100);
			}else{
				lcd_select_addr(0x40);	
				for(i=0;i<7;i++) lcd_text(station[i]);
				lcd_select_addr(0x48);
				sendNum2LCD(addr);
				sendNum2Sound(addr);
			}
			update = 0;
		}
		if(sw_up==0){
			lcd_clear();
			if(vol_level<10) vol_level++;
			lcd_select_addr(0x00);	
			for(i=0;i<6;i++) lcd_text(volume_line[i]);
			lcd_select_addr(0x40);
			for(i=0;i<vol_level;i++) lcd_text('#');
			while(sw_up==0);
			update = 1;
		}
		if(sw_down==0){
			lcd_clear();
			if(vol_level>0) vol_level--;
			lcd_select_addr(0x00);	
			for(i=0;i<6;i++) lcd_text(volume_line[i]);
			lcd_select_addr(0x40);
			for(i=0;i<vol_level;i++) lcd_text('#');
			while(sw_down==0);
			update = 1;
		}
		/*if(sw_pp==0){
				addr++;
				update = 1;
			while(sw_pp==0);
		}
		if(sw_stop==0){
				addr--;
				update = 1;
			while(sw_stop==0);
		}*/


	}
}