#define SOUND_ADDR P2
void delay(int tick)
{
	unsigned int i,j;
	for(i=0;i<tick;i++)
	for(j=0;j<250;j++);
}
sbit SOUND_CE = P3^7;
/*void sound_delay(){
	unsigned char i,j;
	for(i=0;i<100;i++){
		for(j=0;j<255;j++);
	}
}*/

void sound_init(){
	SOUND_CE = 1;
	SOUND_ADDR = 0x00;
}

void play_addr(unsigned char addr){
	SOUND_ADDR = addr;
	SOUND_CE = 0;
	//sound_delay();
	SOUND_CE = 1;
}

