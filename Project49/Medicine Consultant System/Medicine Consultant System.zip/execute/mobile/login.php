<? 
		require("../web/config.inc.php");
		 mysql_connect($dbhost,$dbuser,$dbpass) or die("connect mysql �����");
		mysql_select_db($dbname);  
		$sql = "SELECT user, passwd,lastlog From tbuser WHERE user='$user' ";
		$dbquery = mysql_query($sql);
		$result = mysql_fetch_array($dbquery);
		 if (!$result) {	
			print "no";

	   }
	   if (md5(trim($password)) == trim($result['passwd']))
	   {	   
			echo "yes";
			
	   }

?> 