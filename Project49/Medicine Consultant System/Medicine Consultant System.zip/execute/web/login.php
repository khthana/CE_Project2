  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<?php
require("config.inc.php");
$username= $_REQUEST['username'];
$password= $_REQUEST['password'];

	 if (isset($_REQUEST[$cook_nm] ) ) {		
		$svusr = 'checked' ;	
		$focus="document.a.password.focus();";
	} 
	else {
	$focus="document.a.username.focus();";
		}

	if ((!empty($username)) And (!empty($password) )) {
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);

		mysql_connect($dbhost,$dbuser,$dbpass) or 
		die("connect mysql �����");
		mysql_select_db($dbname);  
		 $sql = "SELECT user, passwd,lastlog From tbuser WHERE user='$username' ";
		 $dbquery = mysql_query($sql);
		$result = mysql_fetch_array($dbquery);
		if (!$result) {	
				echo "<center><br><img src=img/stop.jpg><br>������ Login �Դ!! ";
   				echo "&nbsp;<a href=./>Login ����</a>";
				exit; 
				}
		if (md5(trim($password)) == trim($result['passwd'])) {
			$_SESSION['ses_user'] = $username; 
			$_SESSION['last_log'] = $result['lastlog'];
			if ($_REQUEST['saveuser']=="on")
				{
					setcookie($cook_nm,$username,time()+$cook_time); 
					}  
		else {
			 	setcookie($cook_nm,"",time()); 
				}
		if ($_REQUEST['savepwd']=="on") {	
			setcookie($cook_pw,md5($password),time()+$cook_time); 
		} 
		else {
	   	setcookie($cook_pw,"",time()); 
		}
		mysql_query("UPDATE tbuser SET lastlog= dtnow
		 WHERE user='$username' ");
		mysql_query("UPDATE tbuser SET dtnow='$now'
		 WHERE user='$username' ");
		 if($username=="admin"|$username=="root")
			{
		?>
		<html>
		<title> Login</title>
		<meta Http-equiv="content-type" Content="text/html; Charset=windows-874">
		<meta Http-equiv="refresh" Content="0; Url=./admin.php">
		<center><br><br>
		<b>Welcome:  ���ѡ����  ���ѧ�������к�..</b></center>
		</html>
			<?
		exit; 
			}
			else{
				?>
				<title> Login</title>
		<meta Http-equiv="content-type" Content="text/html; Charset=windows-874">
		<meta Http-equiv="refresh" Content="0; Url=./">
		<center><br><br>
		<b>Welcome:  ���ѡ����  ���ѧ�������к�..</b></center>
		</html>
<?
			}

  } else {	
	 $ip = $REMOTE_ADDR . " @ ". $now ;
	  mysql_query("UPDATE tbuser SET hacker='$ip'  WHERE user='$username'");
	   echo "<center><br><img src=./img/STOP.gif><br>������ Login �Դ!! ";
   	   echo "&nbsp;<a href=./login.php>Login ����</a>";
     exit;
	}
	} 
?>
	
<html>
<head>i
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function Login(){
var done=0;
var username1=document.a.username.value;
//username=username.toLowerCase();
var password1=document.a.password.value;
//password=password.toLowerCase();
if (username1=="" && password1=="") {alert("��������  username ��� password"); }
else if  (username1=="") { alert("��������  username "); }
else if ( password1=="") { alert("��������   password"); }
else {  window.location="signup.php"}

}
// End -->
</SCRIPT>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"></div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
    
      <td valign="top" class="content" width="1000">
	  	
		
	


<!-- <Body  onload=<?=$focus?>> -->
						<Form action="login.php" method=post name=a>
						<center><br><br>
						<TABLE border=1 cellpadding=0 cellspacing=0 bordercolor=white>
							<tr><td bordercolor=#660066>
								<Table border=0 cellspacing=1 cellpadding=2 bgcolor=#ffccff>
									<tr> 
										<td colspan=2 bgcolor=#cc66cc>&nbsp; <b> Login</b></td>
									</tr>
									<tr> 
									<td rowspan="3" align=right>&nbsp;&nbsp; </td>
									<td align="right">User ID
									<input type="text" name="username" size=25 value='<?=$_REQUEST[$cook_nm]?>'></td></tr>
									<tr> 
										<td align="right">Password
										<input type="password" name="password" size=25></td>
									</tr>
									<tr> 
										<td><br>&nbsp;&nbsp;<input type="checkbox" name="saveuser" <?=$svusr?>>
										�� User ��������ͧ &nbsp;<br>
										&nbsp;&nbsp;<input type="checkbox" name="savepwd">
										�����ʼ�ҹ��������ͧ &nbsp;<BR>
										<br><font color=red size=-1>������������ͧ��ǹ��� ������������ʼ�ҹ</font>
										</td>
									</tr>
									<tr> 
										<td colspan=2 align=right>
										<input type="submit" value=' Login ' onClick="Login()">&nbsp;&nbsp;</td></tr>
								</Table>
							</td></tr>
						</TABLE>
						</form>
				 <a href=forgotpw.php>������ʼ�ҹ</a>| <a href=signupform.php>��Ѥ���Ҫԡ����</a>

	  </td>
    </tr>
  </table>
</div>
</body>
</html>
