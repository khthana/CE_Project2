  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?
require("func.inc.php");
require("config.inc.php");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"></div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
  
      <td valign="top" class="content" width="1000">
	  <?php

					if(!empty($username)){
							$username = trim($_POST['username']);
							mysql_connect($dbhost,$dbuser,$dbpass) or die("connect mysql �����");
							mysql_select_db($dbname);
							mysql_query("set NAMES tis620 ");

							$sql = "SELECT user,email From tbuser WHERE user='$username' ";
							$dbquery = mysql_query($sql);
							$result = mysql_fetch_array($dbquery);
							if(!$result){
							#header("Location: ./file.php ");
									echo "login ID �Դ �������ö�� password ��!";
									exit;
								}

							$to = $result['email'];
							$newpw = passwdgen(6);
							$encpwd = md5($newpw);

							$sql = "UPDATE tbuser SET passwd = '$encpwd' WHERE user = '$username' ";
							$result = mysql_db_query($dbname, $sql);
							if(!$result){
								echo("Error in SQL ".mysql_error() );
							}
							else{
								$subj="�����ʼ�ҹ����Ѻ��Ҫԡ";
								$from = "�к��ѵ��ѵ� myweb.com <system@myweb.com>";
								$msg = "���¹ $username \n\n".
									"���������ҡ�к������ʼ�ҹ�ѵ��ѵ� \n���ʼ�ҹ�ͧ��ҹ��й���� $newpw".
									"\n\n�ͺ��Фس ������ԡ��\nwww.myweb.com";

									$header = "Return-Path: $from\r\n";
								$header .= "X-Sender: $from\n";
								$header .= "Form: $from\n";
								$header .= "X-Mailer:PHP 5.1 \n";
								$header .= "MIME-Version: 1.0 \n";

							if(mail($to, $subj, $msg, $header)) {
								echo "�����ʼ�ҹ����ҹ���� ��� $to   \n".
									"***�ҡ������Ѻ �ͧ������㹡��ͧ Junk ���� Bulk***" ;
							print  "<hr><a href=./ >index</a>";
							}else { echo " �����ʼ�ҹ����� ";}
						}

					}
					else
					{echo  "��س������ͼ�������";
					print  "<hr><a href=./forgotpw.php >forgotpw</a>";}
					?>
    
					
	  </td>
	  
    </tr>
  </table>
</div>
</body>
</html>
