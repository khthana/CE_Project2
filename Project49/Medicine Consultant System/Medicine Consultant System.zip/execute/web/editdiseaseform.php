  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?  require("config.admin.inc.php");
    require("auth.inc.php");
	?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  :: Edit disease</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function check(){

var name=document.a.name.value;
var thname=document.a.thname.value;
var charac=document.a.charac.value;

var sign=document.a.sign.value;
var maintain=document.a.maintain.value;
// `` , `` , ,  ,  ,  ,  , ,
var temp="";

if (name=="" )
	{temp+="������������ä (�ѧ���)  "; }
if (thname=="" )
	{temp+="������������ä ( �� )   "; }
if (charac=="" )
	{temp+="���������ѡɳз���� "; }

if (sign=="" )
	{temp+="���������ҡ��  "; }
if (maintain=="" )
	{temp+="�����������ѡ��  "; }

 if  (temp!="") { alert(temp); 
   return false;}
else {  if(confirm("��ͧ��úѹ�֡�����ŧ㹰ҹ��������������� ?"))
				{      return true;}
			else
				{     return false; }
	}

}
// End -->
</SCRIPT>

<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="1024" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
		<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>

<div id="hnavigation">

</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
			<center>		  <TABLE border=1 cellpadding=0 cellspacing=0 bordercolor=white width=60%>
						<tr><td bordercolor=#660066>
							  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor=#CCFFFF >
		<form name="form1" method="get" action="editdiseaseform.php">
			<tr> <td><span class="style4">�����ä����ͧ������ </span></td><td>
	       <input name="search" type="text" value="<?echo $search ?>" maxlength="50">
              <input type="Submit" name="Submit" value="&#3588;&#3657;&#3609;&#3627;&#3634;">
			  </td>	 </tr>
        </form> 

  	<? if(! empty($search)|! empty($id))
				{mysql_connect($dbhost,$dbuser,$dbpass) or  die("connect mysql �����");
							 mysql_select_db($dbname);  
							 mysql_query("set NAMES tis620 ");
							 if($search!="")
							$query = "SELECT  * FROM tb_disease WHERE `thname` LIKE '$search%'";
							else 
							 $query = "SELECT  *  FROM tb_disease WHERE `id` LIKE '$id'";
							$result = mysql_query($query) or die('Query failed: ' . mysql_error());
							$Num_Rows = mysql_num_rows($result);

							//$dbquery = mysql_query($sql);
							

						if($Num_Rows==0)
						{ if($search!="")
							$query = "SELECT  *  FROM tb_disease WHERE `name` LIKE '$search%'";
						 else 
							 $query = "SELECT  *  FROM tb_disease WHERE `id` LIKE '$id'";
							$result = mysql_query($query) or die('Query failed: ' . mysql_error());
							$Num_Rows = mysql_num_rows($result);    }
						
						 if ($Num_Rows==0)
							   {
								echo "<h4>��辺��ª����ä   $search  ���  </h4>";
							}
						else if($Num_Rows==1)
						{  $result = mysql_fetch_array($result);
							
							?> 

							<Form action="editdisease.php" method=post name="a">
						
							
								<tr><td>		
								<!-- '$name','thname','charac', 'cause','sign', 'maintain', 'guide' -->
								<INPUT TYPE="hidden" name="thnameold" value="<?=$result['name'];?>">
								<INPUT TYPE="hidden" name="id">
							<tr><td colspan=2 bgcolor=#00CCFF><b>  ::Edit Disease</b></td></tr>
							<tr><td align=right> �����ä (�ѧ���) :</td>							
							<td><input type="text" name="name" size=49 value="<?=$result['name'];?>"></td></tr>

							<tr><td  align=right>  �����ä (��) :</td>
							<td><input type="text" name="thname" size=49 value="<?=$result['thname'];?>"></td></tr>

							<tr><td  align=right>�ѡɳз���� :</td>
							<td><textarea name='charac' cols=50 rows=4><?=$result['charac'];?></textarea></td></tr>

							<tr><td align=right> ���˵� :</td>
							<td><textarea name='cause' cols=50 rows=4><?=$result['cause']?></textarea></td></tr>

							<tr><td  align=right> �ҡ�� :</td>
							<td><textarea name='sign' cols=50 rows=4><?=$result['sign']?></textarea></td></tr>

							<tr><td  align=right> ����ѡ�� :</td>
							<td><textarea name= 'maintain'  cols=50 rows=4><?=$result['maintain']?></textarea></td></tr>
							<tr><td  align=right> ���й�������� :</td>
							<td><textarea name='guide' cols=50 rows=4><?=$result['guide']?></textarea></td></tr>

							<tr><td colspan=2 align=right><br>
							  <input type="submit" name="Submit" value="  OK  "  onClick="return check();">  &nbsp;</td>

							</tr>
							</form>
							<? }
							else { 
									echo"<table width=\"100%\" border=\"0\" ><tr><td><div align=\"center\">��ª����ä</div></td></tr>";
									$index=0;
									while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
									$col_value=$line['thname'] ;$link=$line['id'];
									 {	
											if(($index% 2)==0)
											echo"<tr bgcolor=\"#A2C4E6\"><td><A HREF=\"editdiseaseform.php?id=$link\"  target='_blank' ><span class=\"style9\">$col_value</span></A> </td></tr>";
											else if(($index% 2)==1)
											print "<tr bgcolor=\"#FFFFFF\"> <td><A HREF=\"editdiseaseform.php?id=$link\" target='_blank' ><span class=\"style9\">$col_value</span></A></td> </tr>";
											$index++;
								 }}
							}
				}
							?>
  </table>
   </td></tr></TABLE> 

</div>
</body>
</html>
