<?php
function checklist($search)
{	
			$fs="../web/list.txt";

			$fp=fopen($fs,"r") or die ("�������ö�Դ�����");

			while(!feof($fp))
			{
							$char.=fgets($fp,1024);
							//print $char;
			}
			fclose($fp);
			
			$list=split("\n",$char);
			
		

		foreach ($list as $string)
		{
				if(ereg(">>",$string))
					{ $tt=split(">>",$string);
						if((ereg( trim($tt[0]),$search))&(!ereg( trim($tt[0]),$newlist)))
						{
							$newlist= $newlist.trim($tt[1])." ";
						}
					}
				else
					{if((ereg( trim($string),$search))&(!ereg( trim($string),$newlist)))
							$newlist= $newlist.trim($string)." ";
							
					}
		}
	
		return $newlist;
}

?>