<?php 
session_start();
header("Content-type: image/png");
$im = @imagecreate(110,36) or die("Cannot Initialize the GD image..");
$bg_color = imagecolorallocate($im,230,230,230);
$text_color = imagecolorallocate($im, 14, 14, 14);
$text_color = imagecolorallocate($im, 255, 00, 00);
$text_color =  imagecolorallocate($im,155,00,33);
$border_color =  imagecolorallocate($im,255,00,00);
$grid_color =  imagecolorallocate($im,210,190,210);

imageline($im,0,9,109,9,$grid_color);
imageline($im,0,18,109,18,$grid_color);
imageline($im,0,27,109,27,$grid_color);

imageline($im,0,0,110,0,$grid_color);
imageline($im,109,35,109,0,$grid_color);
imageline($im,0,0,0,35,$grid_color);
imageline($im,0,35,109,35,$grid_color);

$font = 'desh___.ttf';
//imageTTFText($im,30,0,15,25,$text_color,$font,$_SESSION["ses_code"]);
imageString($im,5,30,10,$_SESSION["ses_code"],$text_color);
imagepng($im);
imagedestroy($im);
?>