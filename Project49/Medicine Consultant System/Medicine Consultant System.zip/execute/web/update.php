  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"></div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
  
      <td valign="top" class="content" width="1000">
	  <?php	// update.php
			require("auth.inc.php");
			require("config.inc.php");
			$passwd1 = trim($_POST['passwd1']);
			$passwd2 = trim($_POST['passwd2']);
			$email = trim($_POST['email']);
			$msg = trim($_POST['msg']);
			$day =  $_POST['day'];
			$month =  $_POST['month'];
			$year =  $_POST['year'];
			$sex = trim($_POST['sex']);
			$status = trim($_POST['status']);
			$allergic = trim($_POST['allergic']);
			$disease = trim($_POST['disease']); 
			$birthday = ereg_replace(" ","",$year)."-".ereg_replace(" ","",$month)."-".ereg_replace(" ","",$day); 
			if ((strlen($passwd1) > 0) and   strlen($passwd1) < 4 ) {
				echo "<b>passwd ��ͧ 4 �ѡ��Т���!</b>";
				exit;
			  }
			  if ( $passwd1 != $passwd2 ) {
				echo "<b>���ʼ�ҹ 2 ��ͧ�������͹�ѹ!</b>";
				exit;
			  }
			$username = $_SESSION['ses_user'] ;
			mysql_connect($dbhost,$dbuser,$dbpass) or  die("connect mysql �����");
			mysql_select_db($dbname);  
			mysql_query("set NAMES tis620 ");
			if($sex=="0")  {
					$sex = "���";
				}
				else   {
					$sex = "˭ԧ";
				}
				if($status=="0")    {
					$status = "�ʴ";
				}
				elseif($status=="1")  {
					$status = "����";
				}
				elseif($status=="2")  {
					$status = "������ҧ";
				}
			if (!empty($passwd1)) {
				$encpwd = md5($passwd1);
				$sql = "UPDATE tbuser Set email='$email' ,passwd='$encpwd' , msg='$msg' , birthday='$birthday' , sex='$sex' , status='$status' 
				, allergic='$allergic' , disease ='$disease'
				  WHERE user='$username' ";
			  } else {
				$sql = "UPDATE tbuser Set email='$email' , msg='$msg' , birthday='$birthday' , sex='$sex' , status='$status' 
				, allergic='$allergic' , disease ='$disease' WHERE user='$username' ";
			  }
			   $result = mysql_query($sql);
				if ($result) {	
					 echo "<center>���º�������� $username , $email  ";
					 if($username=="root"|$username=="admin")
					{
						echo "<hr><a href=./admin.php>Main menu</b>";	
					}
					else
					{echo "<hr><a href=./>Main menu</b>";	
					}
				   } else {
						echo mysql_error();
				} 
?>
	  
      </td>
	  
    </tr>
  </table>
</div>
</body>
</html>
