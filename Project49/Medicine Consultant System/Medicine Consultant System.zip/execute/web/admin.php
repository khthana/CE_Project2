<?require("config.admin.inc.php");
    require("auth.inc.php");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>::�к����ӻ�֡�ҷҧ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 171px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 428px;
	left: 20px;
	top: 180px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 14px;
	color: #0099FF;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style3 {color: #0000FF}
.style10 {font-size: 12pt}
.style11 {font-size: 10pt}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="100%" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
	<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>


<div id="hnavigation"> 
  <script Webstyle4>document.write('<scr'+'ipt src="elements_page1_files/xaramenu.js">'+'</scr'+'ipt>');document.write('<scr'+'ipt src="elements_page1_files/elements_page1_hnavbar.js">'+'</scr'+'ipt>');/*img src="elements_page1_files/elements_page1_hnavbar.gif" moduleid="Default (Project)\elements_page1_hnavbar_off.xws"*/</script>
</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top">
	   
        <p>&nbsp;</p>        <p align="center">
     
         
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
      </p></td>
      <td valign="top" class="content"> 
         <div align="center"> <H3><b>UserName : <? print $_SESSION['ses_user'] ;?>   </b></H3>
        </div>
					<h2 class="style10"> ��������ǹ���</h2>	    <UL>
                 	<img src="img/icon_1.gif" ><A HREF="updateform.php" class="style3 style10">��䢢�������ǹ���</A><br/>
				 </UL><br/>				  <h2 class="style10">��������</h2>
				<UL>
					<img src="img/icon_1.gif" ><A HREF="adddrugform.php" class="style10">������ª�����</A><br/>
					<img src="img/icon_1.gif" ><A HREF="editdrugform.php" class="style10">�����������´��</A><br/>
					<img src="img/icon_1.gif" ><A HREF="deldrugform.php" class="style10">ź��ª�����</A><br/>
				</UL><br/>
				<h2 class="style10">�������ä</h2>
				<UL>
					<img src="img/icon_1.gif" ><A HREF="adddiseaseform.php" class="style10">������ª����ä</A><br/>
					<img src="img/icon_1.gif" ><A HREF="editdiseaseform.php" class="style10">�����������´�ä</A><br/>
					<img src="img/icon_1.gif" ><A HREF="deldiseaseform.php" class="style10">ź��ª����ä</A><br/>
				</UL>
			
       
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>        <p>&nbsp;</p>

		 <table width="836" border="1" bgcolor="#CCCCCC">
          <tr>
            <td width="836" bgcolor="#0099FF"><div align="center"><FONT size=2> <strong>&#3619;&#3632;&#3610;&#3610;&#3651;&#3627;&#3657;&#3588;&#3635;&#3611;&#3619;&#3638;&#3585;&#3625;&#3634;&#3607;&#3634;&#3591;&#3618;&#3634;</strong> :: Powered by &#3609;&#3634;&#3618;&#3594;&#3633;&#3618;&#3624;&#3633;&#3585;&#3604;&#3636;&#3660; &#3623;&#3633;&#3602;&#3609;&#3623;&#3636;&#3648;&#3594;&#3637;&#3618;&#3619; &#3649;&#3621;&#3632; &#3609;&#3634;&#3618;&#3648;&#3629;&#3585;&#3623;&#3633;&#3602;&#3609;&#3660; &#3627;&#3591;&#3626;&#3660;&#3609;&#3633;&#3609;&#3607;&#3585;&#3640;&#3621; :: 2006 All rights reserved. </FONT> </div></td>
          </tr>
        </table>        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
  </table>

</body>
</html>
