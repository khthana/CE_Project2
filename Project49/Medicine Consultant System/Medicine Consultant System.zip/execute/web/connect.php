<?php 
$host="localhost";
$user="user";
$pw="iydc,jot";
$dbname="drug";
$c = mysql_connect($host,$user,$pw);
if(!$c){
    echo "<h3>ERROR : �������ö�Դ��Ͱҹ��������</h3>";
    exit();
}

$cs1 = "SET character_set_results=tis620"; 
mysql_query($cs1) or die('Error query: ' . mysql_error()); 

$cs2 = "SET character_set_client = tis620"; 
mysql_query($cs2) or die('Error query: ' . mysql_error()); 

$cs3 = "SET character_set_connection = tis620"; 
mysql_query($cs3) or die('Error query: ' . mysql_error()); 
?>
