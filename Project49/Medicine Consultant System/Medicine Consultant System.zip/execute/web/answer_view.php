  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    <?require("config.inc.php");
	 include "function.php" ;
mysql_query("set NAMES tis620 ");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function click1(){

  if(confirm("��ͧ���ź ��Ǣ�͡�з�� �͡�ҹ��������������� ?"))
				{      return true;}
			else
				{     return false; }
}
function click2(){

  if(confirm("��ͧ���ź �ӵͺ�ͧ��з�� �͡�ҹ��������������� ?"))
				{      return true;}
			else
				{     return false; }
}

// End -->
</SCRIPT>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"></div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
  
      <td valign="top" class="content" width="1000">
	
        <p>&nbsp;</p>
		<?php
// require "config.inc.php";

 
 $id_ques=$_GET[id_ques];
 
 $sql="select * from  tb_question where id_ques='$id_ques' ";
 $result=mysql_db_query($dbname,$sql);
 $record=mysql_fetch_array($result);
 $id_ques=$record[id_ques];
 $title_ques=$record[title_ques];
 $detail_ques=$record[detail_ques];
 $name_ques=$record[name_ques];
 $email_ques=$record[email_ques];
 $date_ques=$record[date_ques];
 
 $title_ques=htmlspecialchars($title_ques);
 $detail_ques=nl2br(htmlspecialchars($detail_ques));
 $name_ques=htmlspecialchars($name_ques);
 $email_ques=htmlspecialchars($email_ques);
 $date_ques=displaydate($date_ques);
 
 echo "
 <h2>$title_ques</h2>
 <table width='65%' border='1'>
 <tr>
    <td bgcolor='#D2E9FF'>
    <font size='2' face='MS Sans Serif'>$detail_ques
    <p><b>�� :</b>  $name_ques
    <b>����� :</b>  $email_ques
        <b>����� :</b> $date_ques";
	if (isset($_SESSION['ses_user'] )) {
		$user=$_SESSION['ses_user'];
		if(($user=="root")|($user=="admin"))
         echo "<a href='question_del.php?id_ques=$id_ques' onClick=\"return click1();\">[Delete] </a>";
	} echo"</p></font></td> </tr> </table><BR>";
 
 $sql="select * from tb_answer where ref_id='$id_ques' order  by id_ans";
 $result=mysql_db_query($dbname,$sql);
 while($record=mysql_fetch_array($result)){
     $id_ans=$record[id_ans];
     $detail_ans=$record[detail_ans];
     $name_ans=$record[name_ans];
     $email_ans=$record[email_ans];
     $date_ans=$record[date_ans];
     $ref_id=$record[ref_id];
      //print nl2br(htmlspecialchars($detail_ans));
     $detail_ans=nl2br(htmlspecialchars($detail_ans));
	
     $name_ans=htmlspecialchars($name_ans);
     $email_ans=htmlspecialchars($email_ans);
     $date_ans=displaydate($date_ans);
     
 echo "
	 <table width='65%' border='1'>
	 <tr>
    <td bgcolor='#FFFFFF'><font size='2' face='MS Sans Serif'>
    $detail_ans</font></td>
 </tr>
 <tr>
    <td bgcolor='#D2E9FF'><font size='2' face='MS Sans Serif'>
    <b>�� : </b> $name_ans
    <b>����� : </b> $email_ans 
	<b>����� : </b> $date_ans ";
	   
	
	 
	if (isset($_SESSION['ses_user'] )) 
	 {$user=$_SESSION['ses_user'];
		if(($user=="root")|($user=="admin"))
			echo "<a href='answer_del.php?id_ques=$id_ques&id_ans=$id_ans'  onClick=\"return click2();\"> [Delete] </a>";
	 }
	 echo"</font></td> </tr> </table><BR>";
 
 }
// mysql_close();
      
?>
 <h3> �����ͺ�Ӷ��</h3>
 <form method="POST" action="answer_save.php">
 <table bgcolor="#D2E9FF" border="0">
 <tr>
    <td>��������´ : </td>
    <td><textarea name="detail_ans" rows="10" cols="50"></textarea> *</td>
 </tr>
 <tr>

	<?if (!isset($_SESSION['ses_user'] )) 
{
?>
    <td>���ͼ��ͺ : </td>
    <td><input name="name_ans" type="text" size="50" maxlength="40" ></td>
</tr>
<tr>
    <td>E-mail : </td>
    <td><input name="email_ans" type="text" size="50" maxlength="40" ></td>
	<?
}
else
{
$user=$_SESSION['ses_user'];
 print  "<td>���ͼ��ͺ : $user   </td>   <INPUT TYPE=\"hidden\" name=\"name_ans\" value=$user >";
$sql = "SELECT * From tbuser WHERE user='$user' ";
//print "$sql,$dbname,$sql";
//$dbquery = mysql_query($sql) or die('Error query: ' . mysql_error()); 
$result=mysql_db_query($dbname,$sql)or die('Error query: ' . mysql_error());

$result = mysql_fetch_array($result)or die('Error query: ' . mysql_error());
$em=$result['email'];

print  "<INPUT TYPE=\"hidden\"   name='email_ans' value=$em >";

mysql_close();

}?>
 </tr>
 </table><br>
 <input type="hidden" name="ref_id"
 value="<? echo $id_ques;?>">
 <input type="submit" value="Submit">
 <input type="reset" value="Reset">
 </form>
		
    
	
      </td>
	  
    </tr>
  </table>
</div>
</body>
</html>
