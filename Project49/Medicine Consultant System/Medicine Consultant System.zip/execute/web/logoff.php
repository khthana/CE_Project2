<?php
	require("config.inc.php");
   	setcookie($cook_nm,"",time()); 
   	setcookie($cook_pw,"",time()); 
	session_destroy ();
?>
		<html>
		<head>
		<title> Login</title>
		<meta Http-equiv="content-type" Content="text/html; Charset=windows-874">
		<meta Http-equiv="refresh" Content="2; Url=./index.php">
	   </head>
	   <body>
	   <center><br>
     �͡�ҡ�к�����<hr size=1 noshade width=40%>
    <a href=./>Login �������к�</a>
	</body>


