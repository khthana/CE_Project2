  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>

<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #000000;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"> 
 
</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top" width="85">
        <p align="center">
        <p align="center">   <p>&nbsp;</p>                 
          <p align="center">
        
       
      </p></td>
      <td valign="top" class="content" width="981">
	   <form name="form1" method="get" action="search_disease.php">
	       <span class="style4">�����ä
	       </span>
	       <input name="search" type="text" value="<?echo $search ?>" maxlength="50">
              <input type="Submit" name="Submit" value="&#3588;&#3657;&#3609;&#3627;&#3634;">
        </form> 
	    <? 
			                   if(!empty($search ))
								
							   		 aa($search);
	?>
	  </td>
    </tr>
  </table>
</div>
</body>
</html>
<?
		
	function aa($search1)
{ include("connectsql.php");
   connectMysqlRoot(); 
// Connecting, selecting database

// Performing SQL query
$query = "SELECT   `thname`,`name`,`charac`, `cause`,`sign`, `maintain`, `guide` FROM tb_disease WHERE `thname` LIKE '$search1%'";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());
$Num_Rows = mysql_num_rows($result);

if($Num_Rows==0)
{
	$query = "SELECT  `thname`, `name`,`charac`, `cause`,`sign`, `maintain`, `guide` FROM tb_disease WHERE `name` LIKE '$search1%'";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());
$Num_Rows = mysql_num_rows($result);    }
	//<!-- '$name','thname','charac', 'cause','sign', 'maintain', 'guide' -->
 if ($Num_Rows==0)
	       {
		echo "<h4>��辺��ª�����   $search1  ���  </h4>";}
else{
// Printing results in HTML
$namedrug[0] ="�����ä (��)";
$namedrug[1] ="�����ä (�ѧ���)  ";
$namedrug[2] ="�ѡɳз����";
$namedrug[3] ="���˵�";
$namedrug[4] ="�ҡ��";
$namedrug[5] ="����ѡ�� ";
$namedrug[6] ="���й�������� ";


$color[0]="#8CB3E1";
$color[1]="#A7C5E9";
$color[2]="#B7CFEC";
$color[3]="#C7DAF1";
$color[4]="#DCE8F5";
$color[5]="#F0F5FB";
$color[6]="#FCFDFE";

$find=false;
echo "<table width = \"857\">";
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
   echo "<tr>";
   $index=0;
   $cou=0;

   foreach ($line as $col_value) {
	   if(!(($col_value=="")|($col_value==" ")|($col_value=="-")))
		   {
	   $string= nl2br(htmlspecialchars($col_value));echo "<tr bgcolor=$color[$cou]>";
       echo"<td width = 150><span class=\"style5\">$namedrug[$index]</span></td>";
	   echo "<td width =700><span class=\"style5\">$string</span></td>";  
	  echo "</tr>";	 
	  $cou++;
	   }
	  $index++;
	   
     }
   echo "</tr>";

	}}
	echo "</table>\n";
// Free resultset
mysql_free_result($result);

// Closing connection
}
?>
