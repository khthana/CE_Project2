<?require("config.inc.php");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>::�к����ӻ�֡�ҷҧ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function check(){

var search=document.a.search.value;
// `` , `` , ,  ,  ,  ,  , ,
if (search!="" )
				{      return true;}
			else
				{     return false; }
	}

}
// End -->
</SCRIPT>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 171px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 428px;
	left: 20px;
	top: 180px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h5 {
	font-size: 16px;
	color: ##FF6666;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style3 {color: #0000FF}
.style8 {color: #CC9966}
.style9 {color: ##0066FF}
a:link {
	text-decoration: none;
	color: #0066FF;
}
a:visited {
	text-decoration: none;
	color: #0066FF;
}
a:hover {
	text-decoration: underline;
	color: #0066FF;
}
a:active {
	text-decoration: none;
	color: #0066FF;
}
a {
	font-family: Arial, Helvetica, sans-serif;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="100%" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
	<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>


<div id="hnavigation"> 
  <script Webstyle4>document.write('<scr'+'ipt src="elements_page1_files/xaramenu.js">'+'</scr'+'ipt>');document.write('<scr'+'ipt src="elements_page1_files/elements_page1_hnavbar.js">'+'</scr'+'ipt>');/*img src="elements_page1_files/elements_page1_hnavbar.gif" moduleid="Default (Project)\elements_page1_hnavbar_off.xws"*/</script>
</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top">
	   <?if (!isset($_SESSION['ses_user'] )) 
		{
		  print "<table width=\"140\" height=\"100\" border=\"1\" bordercolor=\"#0099ff\" >   <tr> <td height=\"90\" bordercolor=\"#66CCFF\" bgcolor=\"#66CCFF\">";
		  
		  print "<form method=\"post\" action=\"login.php\"> <div align=\"center\"><b>UserName:</b>    <br>
                <input name=\"username\" type=\"text\" id=\"username\" size=\"15\">   
                <b>PassWord:</b> 
                <input name=\"password\" type=\"password\" id=\"password\" size=\"15\">

              </div>
				
						<div align=\"right\"><input type=\"submit\" value=\"Login\"></div>
						<a href=\"forgotpw.php\" class=\"style9\"  target='_blank'>������ʼ�ҹ</a> | 
						<a href=\"signupform.php\" class=\"style9\"  target='_blank'>��Ѥ���Ҫԡ</a>
						
                </form>
				</td>
        </tr>
      </table>";
					}
				else
				{?>
              <table width="140" height="100" border="1" bordercolor="#0099ff" >
        <tr>
          <td height="116" bordercolor="#66CCFF" bgcolor="#66CCFF">
		    <div align="center"> <b>UserName : <? print $_SESSION['ses_user'] ;?>   </b>
              </div>
		
                   <br/>
						 <? $user=$_SESSION['ses_user'];
						  if  ( $user=='root' | $user=='admin')
							print "	<a href=\"admin.php\">��䢢������к�</a><br/>";
				    else
					{print "<a href=\"updateform.php\">��䢢�������ǹ���</a><br/>";
					}
					   ?>
						<a href="logoff.php" class="style9">�͡�ҡ�к�</a>
				 </td>
        </tr>
      </table>
			<?	}
			
				?>        
        <p>&nbsp;</p>        <p align="center">
        <script Webstyle4>document.write('<scr'+'ipt src="elements_page1_files/xaramenu.js">'+'</scr'+'ipt>');document.write('<scr'+'ipt src="elements_page1_files/elements_page1_vnavbar.js">'+'</scr'+'ipt>');/*img src="elements_page1_files/elements_page1_vnavbar.gif" moduleid="Default (Project)\elements_page1_vnavbar_off.xws"*/</script>
         
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
      </p></td>

           <td valign="top" class="content" width="877"><form name="form1" method="get" action="search_drug.php">
        <span class="style4">&#3588;&#3657;&#3609;&#3627;&#3634;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3618;&#3634;</span>         
        <input name="search" type="text" value="<? $search ?>" maxlength="50">
        <input type="Submit" name="Submit" value="&#3588;&#3657;&#3609;&#3627;&#3634;" onClick ="return check();" >
        </form>
	  <? 
//include("connectsql.php");
//connectMysqlRoot();
// Performing SQL query
$query ="SELECT `thname` FROM `drug_not`  ORDER BY `thname` ";
//$result = mysql_query($query) or die('Query failed: ' . mysql_error());
$result=mysql_db_query($dbname,$query);
$Per_Page =30; // �ʴ�˹����30
if(!$Page)
$Page=1;

$Prev_Page = $Page-1;
$Next_Page = $Page+1;
$Page_start = ($Per_Page*$Page)-$Per_Page;
$Num_Rows = mysql_num_rows($result);

if($Num_Rows<=$Per_Page)
$Num_Pages =1;
else if(($Num_Rows % $Per_Page)==0)
$Num_Pages =($Num_Rows/$Per_Page) ;
else 
$Num_Pages =($Num_Rows/$Per_Page) +1;

$Num_Pages = (int)$Num_Pages;

if(($Page>$Num_Pages) || ($Page<0))
print "<center><b>�ӹǹ $Page �ҡ���� $Num_Pages �ѧ����բ�ͤ���<b></center>";
$sql = "SELECT `thname` FROM `drug_not`  ORDER BY `thname` ASC  LIMIT $Page_start , $Per_Page";
//��ǹ�ʴ���
$result = mysql_query($sql);

echo"<table width=\"100%\" border=\"0\" ><tr><td><div align=\"center\">��ª�����</div></td></tr>";


	$index=0;
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
   foreach ($line as $col_value) 
	   {	
			if(($index% 2)==0)
			echo"<tr bgcolor=\"#A2C4E6\"><td><A HREF=\"search_drug.php?search=$col_value\"  target='_blank' ><span class=\"style9\">$col_value</span></A> </td></tr>";
			else if(($index% 2)==1)
			print "<tr bgcolor=\"#FFFFFF\"> <td><A HREF=\"search_drug.php?search=$col_value\" target='_blank' ><span class=\"style9\">$col_value</span></A></td> </tr>";
			$index++;
	 }}

echo"</table><br>��������<b>  $Num_Rows</b> ��¡�� ��������� : <b> $Num_Pages</b> ˹�� :"; 

if($Prev_Page) 
echo " <a href='$PHP_SELF?Page=$Prev_Page'><< ��͹��Ѻ </a>";
for($i=1; $i<$Num_Pages; $i++){
if($i != $Page)
echo "[<a href='$PHP_SELF?Page=$i'>$i</a>]";
else 
echo "<b> $i </b>";
}
/*���ҧ�����Թ˹�� */
if($Page!=$Num_Pages)
echo "<a href ='$PHP_SELF?Page=$Next_Page&keyword=$keyword'> ˹�ҶѴ�>> </a>";


				?>
      
        <p align="center">&nbsp;</p>
        <h2>&nbsp;</h2>
        <p>&nbsp;</p>

        
		 <table width="836" border="1" bgcolor="#CCCCCC">
          <tr>
            <td width="811" bgcolor="#0099FF"><div align="center"><FONT size=2> <strong>&#3619;&#3632;&#3610;&#3610;&#3651;&#3627;&#3657;&#3588;&#3635;&#3611;&#3619;&#3638;&#3585;&#3625;&#3634;&#3607;&#3634;&#3591;&#3618;&#3634;</strong> :: Powered by &#3609;&#3634;&#3618;&#3594;&#3633;&#3618;&#3624;&#3633;&#3585;&#3604;&#3636;&#3660; &#3623;&#3633;&#3602;&#3609;&#3623;&#3636;&#3648;&#3594;&#3637;&#3618;&#3619; &#3649;&#3621;&#3632; &#3609;&#3634;&#3618;&#3648;&#3629;&#3585;&#3623;&#3633;&#3602;&#3609;&#3660; &#3627;&#3591;&#3626;&#3660;&#3609;&#3633;&#3609;&#3607;&#3585;&#3640;&#3621; :: 2006 All rights reserved. </FONT> </div></td>
          </tr>
        </table>        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
  </table>

</body>
</html>
