  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?  require("config.admin.inc.php");
    require("auth.inc.php");
	?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function check(){

var name=document.a.name.value;
var thname=document.a.thname.value;
var charac=document.a.charac.value;

var sign=document.a.sign.value;
var maintain=document.a.maintain.value;
// `` , `` , ,  ,  ,  ,  , ,
var temp="";

if (name=="" )
	{temp+="������������ä (�ѧ���)  "; }
if (thname=="" )
	{temp+="������������ä ( �� )   "; }
if (charac=="" )
	{temp+="���������ѡɳз���� "; }

if (sign=="" )
	{temp+="���������ҡ��  "; }
if (maintain=="" )
	{temp+="�����������ѡ��  "; }

 if  (temp!="") { alert(temp); 
   return false;}
else {  if(confirm("��ͧ��úѹ�֡�����ŧ㹰ҹ��������������� ?"))
				{      return true;}
			else
				{     return false; }
	}

}
// End -->
</SCRIPT>

<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="1024" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
		<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>

<div id="hnavigation">

</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
<Form action="adddisease.php" method=post name="a">
<center><br><br>
<TABLE border=1 cellpadding=0 cellspacing=0 bordercolor=white width=60%>
<tr><td bordercolor=#660066>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor=#CCFFFF >

<tr><td colspan=2 bgcolor=#00CCFF><b>  :: Add Disease</b></td></tr>
<tr><td align=right> �����ä (�ѧ���) :</td>
<td><input type="text" name="name" size=49></td></tr>
<tr><td  align=right>  �����ä (��) :</td>
<td><input type="text" name=`thname`  size=49></textarea></td></tr>
<tr><td  align=right>�ѡɳз���� :</td>
<td><textarea name=`charac` cols=50 rows=4></textarea></td></tr>

<tr><td align=right> ���˵� :</td>
<td><textarea name=`cause` cols=50 rows=4></textarea></td></tr>

<tr><td  align=right> �ҡ�� :</td>
<td><textarea name=`sign` cols=50 rows=4></textarea></td></tr>

<tr><td  align=right> ����ѡ�� :</td>
<td><textarea name= `maintain`  cols=50 rows=4></textarea></td></tr>
<tr><td  align=right> ���й�������� :</td>
<td><textarea name= `guide` cols=50 rows=4></textarea></td></tr>

<tr><td colspan=2 align=right><br>
  <input type="submit" name="Submit" value="  OK  "  onClick="return check();">  &nbsp;</td>
</tr>
  </table>
   </td></tr></TABLE> 
</form>
</div>
</body>
</html>
