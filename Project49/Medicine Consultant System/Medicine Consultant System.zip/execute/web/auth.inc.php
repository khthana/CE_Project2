<?
require("config.inc.php");
if (!isset($_SESSION['ses_user'] )) {		
	  if (!isset($_REQUEST[$cook_nm] ) ) {		
		header("Location: login.php");
		exit;
		}
	  else {	
		mysql_connect($dbhost,$dbuser,$dbpass) or
			die("�������� MySQL �����!!! ");
		mysql_select_db($dbname);  
		$dbquery = mysql_query("SELECT user, passwd, lastlog from tbuser
		   WHERE user='$_COOKIE[$cook_nm]'");
		$result = mysql_fetch_array($dbquery);
		if (!$result) {	
			header("Location: login.php");
			exit;
		} 
		if ($_COOKIE[$cook_pw] != $result['passwd']) {  
				header("Location: login.php");
				exit;
			} 

		$_SESSION['ses_user'] = $_COOKIE[$cook_nm];
		$_SESSION['last_log'] = $result['lastlog'];
	} 
} 
?>