<? 
function passwdgen( $len ) {
	$code = "abcdefghijkmnpqrstuvwxyz123456789";   
        srand((double)microtime()*1000000); 
        for($i=0 ; $i < $len ; $i++)  { 
                $password .= $code[rand()%strlen($code)]; 
        } 
        return $password;
}
?>
