<?require("config.inc.php");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>::�к����ӻ�֡�ҷҧ��::Webboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 171px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 428px;
	left: 56px;
	top: 183px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style3 {color: #0000FF}
.style8 {color: #CC9966}
.style9 {color: #FFCC33}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="1000" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
	<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>


<div id="hnavigation"> 
  <script Webstyle4>document.write('<scr'+'ipt src="elements_page1_files/xaramenu.js">'+'</scr'+'ipt>');document.write('<scr'+'ipt src="elements_page1_files/elements_page1_hnavbar.js">'+'</scr'+'ipt>');/*img src="elements_page1_files/elements_page1_hnavbar.gif" moduleid="Default (Project)\elements_page1_hnavbar_off.xws"*/</script>
</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top">
	   
        <p>&nbsp;</p>        <p align="center">
     
         
</div>
      </p></td>
         <td valign="top" class="content" width="1000">

		<?php
  //require "connect.php";
  include "function.php";
  $sql = "select * from tb_question order by id_ques desc";
  $result=mysql_db_query($dbname,$sql);
  // ///////////////////////////////////
				  $Per_Page =30; // �ʴ�˹����30
				if(!$Page)
				$Page=1;
				$Prev_Page = $Page-1;
				$Next_Page = $Page+1;
				$Page_start = ($Per_Page*$Page)-$Per_Page;
				$Num_Rows = mysql_num_rows($result);

				if($Num_Rows<=$Per_Page)
				$Num_Pages =1;
				else if(($Num_Rows % $Per_Page)==0)
				$Num_Pages =($Num_Rows/$Per_Page) ;
				else 
				$Num_Pages =($Num_Rows/$Per_Page) +1;

				$Num_Pages = (int)$Num_Pages;

				if(($Page>$Num_Pages) || ($Page<0))
				{print "<center><b>�ӹǹ $Page �ҡ���� $Num_Pages �ѧ����բ�ͤ���<b></center>";
				exit; }
				$sql = "select * from tb_question order by id_ques desc  LIMIT $Page_start , $Per_Page";
//��ǹ�ʴ���
$result = mysql_query($sql);

  echo "
  <h3> Webboard ��з�� ���-�ͺ</h3>
  <a href='question_form.php'  TARGET='_blank' ><img src=\"./img/NewTopic_1.gif\" border=\"0\" /></a><p>
  <table width='100%' border='0'>
    <tr bgcolor='#619FDE'>
        <td width='8%'><b><center><font size='2' face='MS
            Sans Serif'>����</font></b></center></td>
        <td width='61%'><b><center><font size='2' face='MS
            Sans Serif'>��Ǣ�ͤӶ��</font></b></center></td>
        <td width='15%'><b><center><font size='2' face='MS
            Sans Serif'>����駤Ӷ��</font></b></center></td>
        <td width='16%'><b><center><font size='2' face='MS
            Sans Serif'>���������ѹ���</font></b></center></td>
    </tr>";
	$index=1;
  while($record=mysql_fetch_array($result)){
      $id_ques=$record[id_ques];
      $title_ques=$record[title_ques];
      $detail_ques=$record[detail_ques];
      $name_ques=$record[name_ques];
      $email_ques=$record[email_ques];
      $date_ques=$record[date_ques];
      
      $title_ques=htmlspecialchars($title_ques);
      $name_ques=htmlspecialchars($name_ques);
      
      $detail_ques=nl2br(htmlspecialchars($detail_ques));
      $date_ques=displaydate($date_ques);
	  if(($index%2)==1)
      echo "      <tr bgcolor='#F0FFFD'> <td width='8%'><center><font size='2'  face='MS Sans Serif'>$id_ques</font></center>                </td>            <td width='61%'><font size='2' face='MS Sans Serif'>                <a href='answer_view.php?id_ques=$id_ques' TARGET='_blank'>                $title_ques</a></font></td>            <td width='15%'><center><font size='2'                face='MS Sans Serif'>$name_ques</font></center>                </td>            <td width='15%'><center><font size='2'                face='MS Sans Serif'>$date_ques</font></center>                </td>      </tr>";
   else
	    echo "      <tr bgcolor='#9BECEC'> <td width='8%'><center><font size='2'  face='MS Sans Serif'>$id_ques</font></center>                </td>            <td width='61%'><font size='2' face='MS Sans Serif'>                <a href='answer_view.php?id_ques=$id_ques' TARGET='_blank'>                $title_ques</a></font></td>            <td width='15%'><center><font size='2'                face='MS Sans Serif'>$name_ques</font></center>                </td>            <td width='15%'><center><font size='2'                face='MS Sans Serif'>$date_ques</font></center>                </td>      </tr>";
 $index++;
  
  
  }
  echo"<tr><td  colspan=\"4\" align=\"right\">��������� : <b> $Num_Pages</b> ˹�� :"; 

if($Prev_Page) 
echo " <a href='$PHP_SELF?Page=$Prev_Page'><< ��͹��Ѻ </a>";
for($i=1; $i<$Num_Pages; $i++){
if($i != $Page)
echo "[<a href='$PHP_SELF?Page=$i'>$i</a>]";
else 
echo "<b> $i </b>";
}
/*���ҧ�����Թ˹�� */
if($Page!=$Num_Pages)
echo "<a href ='$PHP_SELF?Page=$Next_Page&keyword=$keyword'> ˹�ҶѴ�>> </a></td></tr></tabel>";
?>


		 <table width="836" border="0" bgcolor="#3EB1F7">
          <tr>
            <td width="836" bgcolor="#15A8FF"><div align="center"><FONT size=2> <strong>&#3619;&#3632;&#3610;&#3610;&#3651;&#3627;&#3657;&#3588;&#3635;&#3611;&#3619;&#3638;&#3585;&#3625;&#3634;&#3607;&#3634;&#3591;&#3618;&#3634;</strong> :: Powered by &#3609;&#3634;&#3618;&#3594;&#3633;&#3618;&#3624;&#3633;&#3585;&#3604;&#3636;&#3660; &#3623;&#3633;&#3602;&#3609;&#3623;&#3636;&#3648;&#3594;&#3637;&#3618;&#3619; &#3649;&#3621;&#3632; &#3609;&#3634;&#3618;&#3648;&#3629;&#3585;&#3623;&#3633;&#3602;&#3609;&#3660; &#3627;&#3591;&#3626;&#3660;&#3609;&#3633;&#3609;&#3607;&#3585;&#3640;&#3621; :: 2006 All rights reserved. </FONT> </div></td>
          </tr>
        </table>        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
  </table>

</body>
</html>
