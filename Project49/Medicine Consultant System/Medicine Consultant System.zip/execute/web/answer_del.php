  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
  <?  
    require("auth.inc.php");
	require("config.admin.inc.php");
?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function click2(){
  window.close();

}
// End -->
</SCRIPT>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">

  <table width="1024" cellspacing="0" cellpadding="0">
    <div id="header">
	<tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
		<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr></div>
  </table>

<div id="hnavigation">

</div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
<!--  thname , indication , type , howto , interaction , sideeffect , beware , other , adrug -->
<?		$user=$_SESSION['ses_user'];
			mysql_connect($dbhost,$dbuser,$dbpass) or  die("connect mysql �����");
							   mysql_select_db($dbname);  
							   mysql_query("set NAMES tis620 ");	
		  if($user=="root"|$user=="admin")
		  {	if(isset($id_ans))
				{				 $sql ="DELETE FROM `tb_answer`  WHERE  id_ans='$id_ans' ";
								 //CONVERT(`thname` USING utf8) = 'q ' LIMIT 1;
								$result = mysql_db_query($dbname, $sql);
								if (!$result) { 
										echo("Error in SQL  ".mysql_error() ); 
									}
								else
								{echo "<CENTER>��Ң����� �͡�ҡ�ҹ���������º�������� </CENTER>";
										echo "<CENTER><hr><a href=./admin.php onClick=\"return click2();\">��Ѻ���˹����ѡ</b></CENTER>";
								}
				}
		  }
	 else
	 {  echo "<CENTER>�س������Է��ź������ </CENTER>";
		 echo "<CENTER><hr><a href=./admin.php onClick=\"return click2();\">��Ѻ���˹����ѡ</b></CENTER>";
	 }
		
?>
</div>
</body>
</html>
