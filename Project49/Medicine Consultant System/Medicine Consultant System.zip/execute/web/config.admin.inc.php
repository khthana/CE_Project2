<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
$cook_nm = 'login_26br';	
$cook_pw = 'log_65pw';	
$cook_time = 3600 * 24 * 1; 
$dbhost = "localhost";			// Database server
$dbname = "drug";		
$dbuser = "admin";	
$dbpass = "gvd;y<oN";		  //  �͡�Ѳ�� ���ʼ�ҹ
$bkk= mktime(gmdate("H")+7,gmdate("i")+0,gmdate("s"),
		gmdate("m")  ,gmdate("d"),gmdate("Y"));
$datetimeformat="j/m/y - H:i";
$now = date($datetimeformat,$bkk) ;
$c = mysql_connect($host,$dbuser,$dbpass);
if(!$c){
    echo "<h3>ERROR : �������ö�Դ��Ͱҹ��������</h3>";
    exit();
}

$cs1 = "SET character_set_results=tis620"; 
mysql_query($cs1) or die('Error query: ' . mysql_error()); 

$cs2 = "SET character_set_client = tis620"; 
mysql_query($cs2) or die('Error query: ' . mysql_error()); 

$cs3 = "SET character_set_connection = tis620"; 
mysql_query($cs3) or die('Error query: ' . mysql_error()); 
?>