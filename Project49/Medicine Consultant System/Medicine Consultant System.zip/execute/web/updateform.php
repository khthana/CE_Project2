  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
  <?	// updateform.php
require("auth.inc.php");
require("config.inc.php");

mysql_connect($dbhost,$dbuser,$dbpass) or die("????????? MySQL ??????!!! ");
mysql_select_db($dbname);  
mysql_query("set NAMES tis620 ");
$username = $_SESSION['ses_user'] ;
$sql = "SELECT * From tbuser WHERE user='$username' ";
$dbquery = mysql_query($sql);
$result = mysql_fetch_array($dbquery);

if (!$result) {		
	echo "no user";
	exit;
} 

?>
<html>
<head>
<!-- Information generated and read by Xara Webstyle. Do not edit this line. [Elements (Theme);Default;Theme Colour 1;16227132;themecolour1;Bullet highlight;3276544;themecolour2;Sub-Heading Text;10635008;themecolour5;Background Color;16777215;themecolour6;Button Text(over);0;themecolour7;Button Text;0;themecolour8;Heading & Logo Text;0;themecolour9] -->
<!-- Template design (c) Xara Ltd 2003 -->
<title>:: �к����ӻ�֡�ҷҧ��  ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<meta name="generator" content="Xara Webstyle 4. See  xara.com/webstyle"/>
<style type="text/css">
<!--
table {
	font: 9pt "trebuchet ms", arial, sans-serif
}
body {
	color: #000000;/*themecolour6%0;*/
	background-color: #ffffff;/*themecolour6;*/
	background-image:   url(index_files/index_topstrip.gif);
	background-repeat: repeat-x;
	font-family: "trebuchet ms", Arial, sans-serif;
	font-size: 9pt;
}
p {
	margin-top: 0px;
	margin-bottom: 0px;
	}
	
#content ul {
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 0px;
	list-style-image: url(index_files/index_bullet.gif);
}
	
#content blockquote {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
	margin-right: 0px;
}

#content ol {
	margin-top: 0px;
	margin-bottom: 0px;
	color: #333333
}
#header {
	position: absolute;
	height: auto;
	width: auto;
	left: 0px;
	top: 0px;
	visibility: visible;
}

#logo {
	position: absolute;
	height: auto;
	width: auto;
	left: 10px;
	top: 165px;
}

#hnavigation {
	position: absolute;
	height: auto;
	left: 20px;
	top: 129px;
	z-index: 5;
	background-color: #3c9bf7;/*themecolour1;*/
}

#vnavigation {
	position: absolute;
	height: auto;
	width: auto;
	left: 20px;
	top: 320px;
}

.imageborder {
	border-left-width: 1px;
	border-left-style: solid;
	border-left-color: #FFFFFF;
}

#imagebar {
	position: absolute;
	height: auto;
	width: auto;
	right: 60px;
	top: 25px;
	z-index: 6;
}
.imagebox {
	border: 1px solid #FFFFFF;
}

#content {
	position: absolute;
	height: auto;
	width: 1024;
	left: 0px;
	top: 179px;
	right: 60px;
}

h1 {
	font-size: 16px;
	color: #0047a2;/*themecolour5;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
h2 {
	font-size: 16px;
	color: #000000;/*themecolour6%0;*/
	margin-top: 0px;
	margin-bottom: 3px;
}
#content a:link {
	color: #0047a2;/*themecolour5;*/
}
#content a:visited {
	color: #999999;
}
#content a:link:hover {
	color: #3c9bf7;/*themecolour1;*/
}

.content {
	padding-left: 20px;
}
.style4 {
	color: #3300FF;
	font-size: 12pt;
}
.style5 {
	color: #003399;
	font-size: 12pt;
}
-->
</style>
</head>

<body leftmargin="0" topmargin="0">
<div id="header">
  <table width="1024" cellspacing="0" cellpadding="0">
    <tr>
      <td width="520" valign="top"><img src="index_files/index_heading.jpg" border="0" /></td>
      <td width="100%" align="center">
<table cellspacing="3" cellpadding="0">
          <tr>
            <td  valign="top"><img src="index_files/elements_page1_image1.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image2.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/elements_page1_image3.gif" border="0" /></td>
            <td  valign="top"><img src="index_files/index_image4.jpg" border="0" /></td>
          </tr>
        </table> </td>
    </tr>
  </table>
</div>
<div id="hnavigation"></div>
<div id="image"></div>
<div id="image2"></div>
<div id="image3"></div>

<div id="content"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
  
      <td valign="top" class="content" width="1000">
	  <Form action="update.php" method=post name=a>
	  <Table cellspacing=1  bgcolor=#CCFFFF width=100%>
					<tr><td colspan=2 bgcolor=#00CCFF><b> <img src=img/icon14.gif> :: Update</b></td></tr>
					<tr><td align=right> Username:</td>
					<td><b><?=$result['user'];?></b></td></tr>

					<tr><td  align=right> ���ʼ�ҹ:</td>
					<td><br><input type="password" name="passwd1" size=25 value=""></td></tr>
					<tr><td  align=right>�׹�ѹ ���ʼ�ҹ:</td>
					<td><input type="password" name="passwd2" size=25 value=""></td></tr>

					<tr><td align=right> Email:</td>
					<td><input type="text" name="email" size=25 value="<?=$result['email'];?>"></td></tr>

					<tr><td  align=right> �������<br>comment:</td>
					<td><textarea name="msg" cols=50 rows=4  ><?=$result['msg'];?></textarea></td></tr>
					<tr><td  align=right> �ѹ�Դ:<br></td>
					<td>�ѹ���<select name="day">
					  <?    $temp=$result['birthday'];
							   $dd= split("-",$temp);
								for($i=1 ;$i<32;$i++)
								 if($dd[2]==$i)
									print  " <option value= \"$i\" selected >$i</option>";
								else
									print  " <option value= \"$i\"  >$i</option>";

						?>
						</select>
						��͹<select name="month">
						 <? 
							$value[1]="���Ҥ�";
						   $value[2]="����Ҿѹ��";
						   $value[3]="�չҤ�";
						  $value[4]="����¹";
							$value[5]="����Ҥ�";
							$value[6]="�Զع�¹";
							$value[7]="�á�Ҥ�";
							$value[8]="�ԧ�Ҥ�";
							$value[9]="�ѹ��¹";
							$value[10]="���Ҥ�";
							$value[11]="��Ȩԡ�¹";
							$value[12]="�ѹ�Ҥ�";
							for($i=1 ;$i<13;$i++)
								  if($dd[1]==$i)
									print  " <option value= \"$i \"selected >$value[$i]</option>";
									else
									print  " <option value=\"$i\" >$value[$i]</option>";
						 ?>   
						</select>
						�� �.�<select name="year">
							 <?  for($i=2450 ;$i<2550;$i++)
							 if($dd[0]==$i)
							print  " <option value= \"$i\" selected >$i</option>";
							else
							print  " <option value= \"$i\"  >$i</option>";
						  ?>
						</select></td></tr>
						
					<tr><td align=right> ��:</td>

					<td>
					  <?
					   if($result['sex'] =="���")
							 $dd1="checked";
					  else
							$dd2="checked";
						print "<input type=\"radio\" name=\"sex\" value=\"0\" $dd1>���    <input type=\"radio\" name=\"sex\"value=\"1\"$dd2>˭ԧ</td></tr>";
						?>
					<tr><td align=right> ʶҹ��Ҿ:</td>
					<td>
					<?    if($result['status'] =="�ʴ")
							 $dd1="checked";
					  else  if($result['status'] =="����")
							$dd2="checked";
					  else
						   $dd3="checked";
					?>
						<input type="radio" name="status" value="0" <?=  $dd1?> >�ʴ
						<input type="radio" name="status" value="1"<?=  $dd2?> >����
						<input type="radio" name="status" value="2"<?=  $dd3?> >������ҧ</td></tr>

					<tr><td  align=right> ����<br>comment:</td>
					<td><textarea name="allergic" cols=50 rows=4><?=$result['allergic'];?></textarea></td></tr>

					<tr><td  align=right> �ä��Шӵ��<br>comment:</td>
					<td><textarea name="disease" cols=50 rows=4><?=$result['disease'];?></textarea></td></tr>

					<tr><td></td><td colspan=1 align=left><br>					<input name="image" type="image" src="img/ok.gif">					  &nbsp;</td>
					</tr>
					</Table>
					</form>
      </td>
	  
    </tr>
  </table>
</div>
</body>
</html>
