/*
 * drug.java
 *
 * Created on January 3, 2007, 10:14 PM
 */

import com.sun.midp.io.j2me.storage.File;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import java.lang.*;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

/**
 *
 * @author lex
 */
public class drug extends MIDlet implements CommandListener, ItemStateListener {
    
    /** Creates a new instance of drug */
    public drug() {
        initialize();
    }
    
    private Form Login;//GEN-BEGIN:MVDFields
    private Command exitCommand1;
    private TextField textField1;
    private TextField textField2;
    private Command screenCommand1;
    private Command screenCommand2;
    private Command exitCommand2;
    private Command okCommand1;
    private Command okCommand2;
    private Form Menu;
    private Image image1;
    private ImageItem imageItem1;
    private Command backCommand1;
    private Form List;
    private Command okCommand3;
    private Ticker ticker1;
    private Font font1;
    private Font font2;
    private Form Result;
    private Command okCommand4;
    private ChoiceGroup choiceGroup1;
    private StringItem stringItem1;
    private TextField textField3;
    private ChoiceGroup choice1;
    private ChoiceGroup choice2;
    private ChoiceGroup choice3;
    private ChoiceGroup choice4;
    private ChoiceGroup choice5;
    private ChoiceGroup choice6;
    private ChoiceGroup choice7;
    private ChoiceGroup choice8;
    private Command screenCommand3;
    private Form SaveFile;
    private Command screenCommand4;
    private Command screenCommand5;
    private Command screenCommand6;
    private TextField textField4;
    private Form ReadFile;
    private Command screenCommand7;
    private Command screenCommand8;
    private Command exitCommand3;
    private TextField textField5;
    private Command screenCommand9;
    private StringItem stringItem2;
    private Command screenCommand10;
    private Command backCommand2;
    private Command backCommand3;
    private Command screenCommand11;
    private Command screenCommand12;
    private Command screenCommand13;
    private Command screenCommand14;
    private Command screenCommand15;
    private Command screenCommand16;//GEN-END:MVDFields
    private static String defaultURL = "http://127.0.0.1/mobile/";
    private static String dbname="drug_record";
    String download;
    String oldname="";
    String requeststring;
    String resultstring;
    String resultdata;
    String search_d="search_d=";
    String req;
    String user="username=";
    String reqdrug;
    String temp_search="";
    int ti=0;
  //  microedition.encoding=UTF-8 ;


    //String encoding1 = System.getProperty("microedition.encoding");
   // String localeStr = System.getProperty("microedition.locale");
    //boolean t=false;
    
//GEN-LINE:MVDMethods

    /** Called by the system to indicate that a command has been invoked on a particular displayable.//GEN-BEGIN:MVDCABegin
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {//GEN-END:MVDCABegin
    // Insert global pre-action code here
        if (displayable == Login) {//GEN-BEGIN:MVDCABody
            if (command == screenCommand1) {//GEN-END:MVDCABody
                // Insert pre-action code her
                // Do nothing//GEN-LINE:MVDCAAction9
                // Insert post-action code here
             

 
                 req="user=";
                 req+=textField1.getString();
                 user+=textField1.getString();
                 req+="&password=";
                 req+=textField2.getString();
                //System.out.println(req);
                 Thread t = new Thread(){
		 public void run(){
			 sendPostRequest();//getViaHttpConnection(); <- ????????????????????????????????????????????? server ??????????????
                            }
		 };
               
                 t.start();
               // String resultstring  =sendPostRequest(req);
                
                /*
getDisplay ().setCurrent (get_form2());
                // Insert post-action code here
                textField3.setString(resultstring);*/
               
                
                    
            } else if (command == exitCommand1) {//GEN-LINE:MVDCACase9
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction4
                // Insert post-action code here
            } else if (command == screenCommand2) {//GEN-LINE:MVDCACase4
                // Insert pre-action code here
                  textField2.setString("");
                  textField1.setString("");
                
                /*
getDisplay ().setCurrent (get_List());//GEN-LINE:MVDCAAction13
                // Insert post-action code here
                textField3.setString(resultstring);*/
            } else if (command == screenCommand16) {//GEN-LINE:MVDCACase13
                // Insert pre-action code here
                getDisplay().setCurrent(get_Menu());//GEN-LINE:MVDCAAction161
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase161
        } else if (displayable == List) {
            if (command == backCommand1) {//GEN-END:MVDCACase161
                // Insert pre-action code here
                getDisplay().setCurrent(get_Login());//GEN-LINE:MVDCAAction45
                // Insert post-action code here
            } else if (command == screenCommand1) {//GEN-LINE:MVDCACase45
                // Insert pre-action code here
                // Do nothing//GEN-LINE:MVDCAAction59
                // Insert post-action code here
            } else if (command == okCommand3) {//GEN-LINE:MVDCACase59
                // Insert pre-action code here
                /*
                 *
getDisplay ().setCurrent (get_Result());//GEN-LINE:MVDCAAction61
                // Insert post-action code here*/
               // String search_d="search_d=";
                
                search_d="search_d=";
                temp_search="";
                boolean selected1[] = new boolean[choice1.size()];
                choice1.getSelectedFlags(selected1);
                for (int i = 0; i < choice1.size(); i++)
                {  if(selected1[i])
                   {temp_search+=choice1.getString(i)+" ";
                   }
                }
                boolean selected2[] = new boolean[choice2.size()];
                choice2.getSelectedFlags(selected2);
                for (int i = 0; i < choice2.size(); i++)
                {  if(selected2[i])
                   {temp_search+=choice2.getString(i)+" ";
                   }
                }
                boolean selected3[] = new boolean[choice3.size()];
                choice3.getSelectedFlags(selected3);
                for (int i = 0; i < choice3.size(); i++)
                {  if(selected3[i])
                   {temp_search+=choice3.getString(i)+" ";
                   }
                }
                boolean selected4[] = new boolean[choice4.size()];
                choice4.getSelectedFlags(selected4);
                for (int i = 0; i < choice4.size(); i++)
                {  if(selected4[i])
                   {temp_search+=choice4.getString(i)+" ";
                   }
                }
                boolean selected5[] = new boolean[choice5.size()];
                choice5.getSelectedFlags(selected5);
                for (int i = 0; i < choice5.size(); i++)
                {  if(selected5[i])
                   {temp_search+=choice5.getString(i)+" ";
                   }
                }
                boolean selected6[] = new boolean[choice6.size()];
                choice6.getSelectedFlags(selected6);
                for (int i = 0; i < choice6.size(); i++)
                {  if(selected6[i])
                   {temp_search+=choice6.getString(i)+" ";
                   }
                }
                boolean selected7[] = new boolean[choice7.size()];
                choice7.getSelectedFlags(selected7);
                for (int i = 0; i < choice7.size(); i++)
                {  if(selected7[i])
                   {temp_search+=choice7.getString(i)+" ";
                   }
                }
                 boolean selected8[] = new boolean[choice8.size()];
                choice8.getSelectedFlags(selected8);
                for (int i = 0; i < choice8.size(); i++)
                {  if(selected8[i])
                   {temp_search+=choice8.getString(i)+" ";
                   }
                }
                temp_search+=textField3.getString();
                
                search_d+=temp_search;
                reqdrug=user+"&"+search_d;
                
               // kk=defaultURL+"test.php";
                Thread t = new Thread(){
		 public void run(){
			 sendPostRequest1();//getViaHttpConnection(); <- ????????????????????????????????????????????? server ??????????????
                            }
		 };
               
                 t.start();
                
            }//GEN-BEGIN:MVDCACase61
        } else if (displayable == Menu) {
            if (command == screenCommand7) {//GEN-END:MVDCACase61
                // Insert pre-action code here
                getDisplay().setCurrent(get_ReadFile());//GEN-LINE:MVDCAAction136
                // Insert post-action code here
                    stringItem2.setLabel(decodethai("")); 
                      stringItem2.setText("");
                      textField5.setString("");
            } else if (command == screenCommand10) {//GEN-LINE:MVDCACase136
                // Insert pre-action code here
                getDisplay().setCurrent(get_Login());//GEN-LINE:MVDCAAction146
                // Insert post-action code here
            } else if (command == screenCommand14) {//GEN-LINE:MVDCACase146
                // Insert pre-action code here
                Thread t = new Thread(){
		 public void run(){
			 sendPostRequest2();//getViaHttpConnection(); <- ????????????????????????????????????????????? server ??????????????
                            }
		 };
               
                 t.start();
                 // Do nothing//GEN-LINE:MVDCAAction156
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase156
        } else if (displayable == Result) {
            if (command == backCommand1) {//GEN-END:MVDCACase156
                // Insert pre-action code here
                getDisplay().setCurrent(get_List());//GEN-LINE:MVDCAAction70
                // Insert post-action code here
            } else if (command == exitCommand1) {//GEN-LINE:MVDCACase70
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction69
                // Insert post-action code here
            } else if (command == screenCommand4) {//GEN-LINE:MVDCACase69
                // Insert pre-action code here
                getDisplay().setCurrent(get_SaveFile());//GEN-LINE:MVDCAAction128
                // Insert post-action code here
            } else if (command == screenCommand15) {//GEN-LINE:MVDCACase128
                // Insert pre-action code here
                getDisplay().setCurrent(get_ReadFile());//GEN-LINE:MVDCAAction159
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase159
        } else if (displayable == SaveFile) {
            if (command == screenCommand5) {//GEN-END:MVDCACase159
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction130
                // Insert post-action code here
            } else if (command == screenCommand6) {//GEN-LINE:MVDCACase130
                // Insert pre-action code here
               
               RecordStore rs;
                if(resultdata=="")
                { Alert alert = new Alert("WARNING", "no data.", null, AlertType.WARNING);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                        getDisplay().setCurrent(get_List());
                }
              // resultdata=encodethai(resultdata.toString());
                byte[] data = getBytesfromUTFString(resultdata.toString());
                if(!textField4.getString().equals("")){       
                try{
                    rs=RecordStore.openRecordStore(textField4.getString(),true);
                    
                    rs.addRecord(data,0,data.length);
                    rs.closeRecordStore();
                    resultdata="";
                    textField4.setString("");
                    Alert alert = new Alert("Confirm",decodethai("�ѹ�֡���º������������") , null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                       
                        getDisplay().setCurrent(get_Result());
                    
                }catch(RecordStoreException e){
                    System.out.print(e);
                }
                }else
                {Alert alert = new Alert("Confirm",decodethai("�ѧ��������������") , null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                       
                }
                // Do nothing//GEN-LINE:MVDCAAction132
                // Insert post-action code here
            } else if (command == backCommand3) {//GEN-LINE:MVDCACase132
                // Insert pre-action code here
                getDisplay().setCurrent(get_Result());//GEN-LINE:MVDCAAction149
                // Insert post-action code here
            } else if (command == screenCommand12) {//GEN-LINE:MVDCACase149
                // Insert pre-action code here
                getDisplay().setCurrent(get_ReadFile());//GEN-LINE:MVDCAAction153
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase153
        } else if (displayable == ReadFile) {
            if (command == exitCommand3) {//GEN-END:MVDCACase153
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction140
                // Insert post-action code here
            } else if (command == screenCommand8) {//GEN-LINE:MVDCACase140
                // Insert pre-action code here
                getDisplay().setCurrent(get_Menu());//GEN-LINE:MVDCAAction138
                // Insert post-action code here
            } else if (command == screenCommand9) {//GEN-LINE:MVDCACase138
                // Insert pre-action code here
                RecordStore rs;
                 StringBuffer messagebuffer = new StringBuffer();

                    try{
                      
                    
                    rs=RecordStore.openRecordStore(textField5.getString(),true);
                    {
                    int lastRec=rs.getNumRecords();
                    //int size=rs.getRecordSize(lastRec);
                    if(lastRec>0)
                    {
                        byte []  kk=rs.getRecord(lastRec);  
                        String te=getUTFString(kk,0,kk.length); 
                        stringItem2.setLabel(decodethai("�����Ť�������ش")); 
                        stringItem2.setText(te.toString());
                    }
                    else
                    {stringItem2.setLabel(decodethai("��辺������")); 
                     rs.deleteRecordStore(textField5.getString());
                     textField5.setString("");
                    }
                    rs.closeRecordStore();
                    }
                    
                }catch(RecordStoreException e){
                    System.out.print(e);
                }
                
                                   
                
                 // Do nothing//GEN-LINE:MVDCAAction143
                // Insert post-action code here
            } else if (command == screenCommand11) {//GEN-LINE:MVDCACase143
                // Insert pre-action code here
                try {
			RecordStore.deleteRecordStore( textField5.getString());
                        stringItem2.setText("");
                        stringItem2.setLabel(decodethai("ź���º��������"));
                    } catch ( RecordStoreException e) {
                     System.out.println( e);
                     }
                // Do nothing//GEN-LINE:MVDCAAction151
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase151
        }//GEN-END:MVDCACase151
    // Insert global post-action code here
}//GEN-LINE:MVDCAEnd

    /** This method initializes UI of the application.//GEN-BEGIN:MVDInitBegin
     */
    private void initialize() {//GEN-END:MVDInitBegin
        // Insert pre-init code here
        getDisplay().setCurrent(get_Menu());//GEN-LINE:MVDInitInit
        // Insert post-init code here
    }//GEN-LINE:MVDInitEnd
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {//GEN-FIRST:MVDGetDisplay
        return Display.getDisplay(this);
    }//GEN-LAST:MVDGetDisplay
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {//GEN-FIRST:MVDExitMidlet
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }//GEN-LAST:MVDExitMidlet

    /** This method returns instance for Login component and should be called instead of accessing Login field directly.//GEN-BEGIN:MVDGetBegin2
     * @return Instance for Login component
     */
    public Form get_Login() {
        if (Login == null) {//GEN-END:MVDGetBegin2
            // Insert pre-init code here
            Login = new Form("login", new Item[] {//GEN-BEGIN:MVDGetInit2
                get_textField1(),
                get_textField2()
            });
            Login.addCommand(get_exitCommand1());
            Login.addCommand(get_screenCommand1());
            Login.addCommand(get_screenCommand2());
            Login.addCommand(get_screenCommand16());
            Login.setCommandListener(this);//GEN-END:MVDGetInit2
            // Insert post-init code here
           // System.out.println("gsdg"+encoding1+"sdfgd"+localeStr);
        }//GEN-BEGIN:MVDGetEnd2
        return Login;
    }//GEN-END:MVDGetEnd2

    /** This method returns instance for exitCommand1 component and should be called instead of accessing exitCommand1 field directly.//GEN-BEGIN:MVDGetBegin3
     * @return Instance for exitCommand1 component
     */
    public Command get_exitCommand1() {
        if (exitCommand1 == null) {//GEN-END:MVDGetBegin3
            // Insert pre-init code here
            exitCommand1 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit3
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd3
        return exitCommand1;
    }//GEN-END:MVDGetEnd3

    /** This method returns instance for textField1 component and should be called instead of accessing textField1 field directly.//GEN-BEGIN:MVDGetBegin5
     * @return Instance for textField1 component
     */
    public TextField get_textField1() {
        if (textField1 == null) {//GEN-END:MVDGetBegin5
            // Insert pre-init code here
            textField1 = new TextField("\u0E0A\u0E37\u0E48\u0E2D\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49", null, 120, TextField.ANY);//GEN-LINE:MVDGetInit5
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd5
        return textField1;
    }//GEN-END:MVDGetEnd5

    /** This method returns instance for textField2 component and should be called instead of accessing textField2 field directly.//GEN-BEGIN:MVDGetBegin6
     * @return Instance for textField2 component
     */
    public TextField get_textField2() {
        if (textField2 == null) {//GEN-END:MVDGetBegin6
            // Insert pre-init code here
            textField2 = new TextField("\u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E48\u0E32\u0E19", null, 120, TextField.ANY | TextField.PASSWORD);//GEN-LINE:MVDGetInit6
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd6
        return textField2;
    }//GEN-END:MVDGetEnd6
    /** This method returns instance for screenCommand1 component and should be called instead of accessing screenCommand1 field directly.//GEN-BEGIN:MVDGetBegin8
     * @return Instance for screenCommand1 component
     */
    public Command get_screenCommand1() {
        if (screenCommand1 == null) {//GEN-END:MVDGetBegin8
            // Insert pre-init code here
            screenCommand1 = new Command("\u0E40\u0E02\u0E49\u0E32\u0E2A\u0E39\u0E48\u0E23\u0E30\u0E1A\u0E1A", Command.SCREEN, 1);//GEN-LINE:MVDGetInit8
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd8
        return screenCommand1;
    }//GEN-END:MVDGetEnd8
 
    /** This method returns instance for screenCommand2 component and should be called instead of accessing screenCommand2 field directly.//GEN-BEGIN:MVDGetBegin12
     * @return Instance for screenCommand2 component
     */
    public Command get_screenCommand2() {
        if (screenCommand2 == null) {//GEN-END:MVDGetBegin12
            // Insert pre-init code here
            screenCommand2 = new Command("\u0E25\u0E1A", Command.SCREEN, 1);//GEN-LINE:MVDGetInit12
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd12
        return screenCommand2;
    }//GEN-END:MVDGetEnd12

    /** This method returns instance for List component and should be called instead of accessing List field directly.//GEN-BEGIN:MVDGetBegin14
     * @return Instance for List component
     */
    public Form get_List() {
        if (List == null) {//GEN-END:MVDGetBegin14
            // Insert pre-init code here
            //Item kk=new Item[] {get_textField3()};
            List = new Form("\u0E23\u0E30\u0E1A\u0E38\u0E2D\u0E32\u0E01\u0E32\u0E23\u0E17\u0E35\u0E48\u0E40\u0E1B\u0E47\u0E19", new Item[] {//GEN-BEGIN:MVDGetInit14
                get_choice1(),
                get_choice2(),
                get_choice3(),
                get_choice4(),
                get_choice5(),
                get_choice6(),
                get_choice7(),
                get_choice8(),
                get_textField3()
            });
            List.addCommand(get_backCommand1());
            List.addCommand(get_okCommand3());
            List.setCommandListener(this);//GEN-END:MVDGetInit14
            // Insert post-init code here
            ///read file list.txt
           // String ss=getStringResource("./list.txt");
            RecordStore rs;
            String ss=null;
                
            try{
                    rs=RecordStore.openRecordStore("list111111_waw",true);
                    
                    int lastRec=rs.getNumRecords();
                    //int size=rs.getRecordSize(lastRec);
                    byte []  kk=rs.getRecord(lastRec);  
                    String te=getUTFString(kk,0,kk.length); 

                    ss=te.toString();
                    rs.closeRecordStore();
                    
                }catch(RecordStoreException e){
                    System.out.print(e);
                }
                //System.out.println( ss);
            byte[] st= getBytesfromUTFString("***");
           String tt1 []=splitData(getUTFString(st,0,st.length),ss); 
           st= getBytesfromUTFString("+++");
           String tt2 []=splitData(getUTFString(st,0,st.length),tt1[1]);
          // String tt3 []=splitData(decodethai("///"),tt1[1]);
          // 
          
           //String t0 [];
           //choice1.setLabel("fdsg");
           for (int i=0;i<tt2.length;i++)
           {   // 
                    if(i==0)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]);   
                    choice1.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);         
                    for (int j=0 ;j<t0.length;j++)
                   
                    choice1.append(decodethai(t0[j]),null);
                    }
                   else if(i==1)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]);  
                    choice2.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice2.append(decodethai(t0[j]),null);
                    }
                   else if(i==2)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]);  
                    choice3.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice3.append(decodethai(t0[j]),null);
                    }
                   else if(i==3)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]); 
                    choice4.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice4.append(decodethai(t0[j]),null);
                    }
                    else if(i==4)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]);  
                    choice5.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice5.append(decodethai(t0[j]),null);
                    }
                    else if(i==5)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]); 
                    choice6.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice6.append(decodethai(t0[j]),null);
                    }
                   else if(i==6)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]); 
                    choice7.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice7.append(decodethai(t0[j]),null);
                    }
                    else if(i==7)
                   {st= getBytesfromUTFString(">>>");
                    String head []=splitData(getUTFString(st,0,st.length),tt2[i]);   
                    choice8.setLabel(head[0]);
                    st= getBytesfromUTFString(",");                    
                    String t0 []= splitData(getUTFString(st,0,st.length),head[1]);
                    for (int j=0 ;j<t0.length;j++)
                    choice8.append(decodethai(t0[j]),null);
                    }
           }
            List.setItemStateListener(this);
        }//GEN-BEGIN:MVDGetEnd14
        return List;
    }//GEN-END:MVDGetEnd14
 
    /** This method returns instance for exitCommand2 component and should be called instead of accessing exitCommand2 field directly.//GEN-BEGIN:MVDGetBegin18
     * @return Instance for exitCommand2 component
     */
    public Command get_exitCommand2() {
        if (exitCommand2 == null) {//GEN-END:MVDGetBegin18
            // Insert pre-init code here
            exitCommand2 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit18
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd18
        return exitCommand2;
    }//GEN-END:MVDGetEnd18

    /** This method returns instance for okCommand1 component and should be called instead of accessing okCommand1 field directly.//GEN-BEGIN:MVDGetBegin21
     * @return Instance for okCommand1 component
     */
    public Command get_okCommand1() {
        if (okCommand1 == null) {//GEN-END:MVDGetBegin21
            // Insert pre-init code here
            okCommand1 = new Command("Command", Command.OK, 1);//GEN-LINE:MVDGetInit21
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd21
        return okCommand1;
    }//GEN-END:MVDGetEnd21
    /** This method returns instance for Menu component and should be called instead of accessing Menu field directly.//GEN-BEGIN:MVDGetBegin32
     * @return Instance for Menu component
     */
    public Form get_Menu() {
        if (Menu == null) {//GEN-END:MVDGetBegin32
            // Insert pre-init code here
            Menu = new Form("\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E2B\u0E49\u0E04\u0E33\u0E1B\u0E23\u0E36\u0E01\u0E29\u0E32\u0E17\u0E32\u0E07\u0E22\u0E32", new Item[] {get_imageItem1()});//GEN-BEGIN:MVDGetInit32
            Menu.addCommand(get_screenCommand10());
            Menu.addCommand(get_screenCommand7());
            Menu.addCommand(get_screenCommand14());
            Menu.setCommandListener(this);//GEN-END:MVDGetInit32
            // Insert post-init code here
           
        }//GEN-BEGIN:MVDGetEnd32
        return Menu;
    }//GEN-END:MVDGetEnd32
    /** This method returns instance for okCommand2 component and should be called instead of accessing okCommand2 field directly.//GEN-BEGIN:MVDGetBegin35
     * @return Instance for okCommand2 component
     */
    public Command get_okCommand2() {
        if (okCommand2 == null) {//GEN-END:MVDGetBegin35
            // Insert pre-init code here
            okCommand2 = new Command("Ok", Command.OK, 1);//GEN-LINE:MVDGetInit35
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd35
        return okCommand2;
    }//GEN-END:MVDGetEnd35

    /** This method returns instance for image1 component and should be called instead of accessing image1 field directly.//GEN-BEGIN:MVDGetBegin41
     * @return Instance for image1 component
     */
    public Image get_image1() {
        if (image1 == null) {//GEN-END:MVDGetBegin41
            // Insert pre-init code here
            try {//GEN-BEGIN:MVDGetInit41
                image1 = Image.createImage("/otc1.jpg");
            } catch (java.io.IOException exception) {
            }//GEN-END:MVDGetInit41
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd41
        return image1;
    }//GEN-END:MVDGetEnd41

    /** This method returns instance for imageItem1 component and should be called instead of accessing imageItem1 field directly.//GEN-BEGIN:MVDGetBegin42
     * @return Instance for imageItem1 component
     */
    public ImageItem get_imageItem1() {
        if (imageItem1 == null) {//GEN-END:MVDGetBegin42
            // Insert pre-init code here
            imageItem1 = new ImageItem("", get_image1(), Item.LAYOUT_DEFAULT, null);//GEN-LINE:MVDGetInit42
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd42
        return imageItem1;
    }//GEN-END:MVDGetEnd42

    /** This method returns instance for backCommand1 component and should be called instead of accessing backCommand1 field directly.//GEN-BEGIN:MVDGetBegin44
     * @return Instance for backCommand1 component
     */
    public Command get_backCommand1() {
        if (backCommand1 == null) {//GEN-END:MVDGetBegin44
            // Insert pre-init code here
            backCommand1 = new Command("Back", Command.BACK, 1);//GEN-LINE:MVDGetInit44
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd44
        return backCommand1;
    }//GEN-END:MVDGetEnd44

    /** This method returns instance for okCommand3 component and should be called instead of accessing okCommand3 field directly.//GEN-BEGIN:MVDGetBegin60
     * @return Instance for okCommand3 component
     */
    public Command get_okCommand3() {
        if (okCommand3 == null) {//GEN-END:MVDGetBegin60
            // Insert pre-init code here
            okCommand3 = new Command("send", Command.OK, 1);//GEN-LINE:MVDGetInit60
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd60
        return okCommand3;
    }//GEN-END:MVDGetEnd60
    /** This method returns instance for ticker1 component and should be called instead of accessing ticker1 field directly.//GEN-BEGIN:MVDGetBegin64
     * @return Instance for ticker1 component
     */
    public Ticker get_ticker1() {
        if (ticker1 == null) {//GEN-END:MVDGetBegin64
            // Insert pre-init code here
            ticker1 = new Ticker("\u0E23\u0E30\u0E1A\u0E1A\u0E43\u0E2B\u0E49\u0E04\u0E33\u0E1B\u0E23\u0E36\u0E01\u0E29\u0E32\u0E17\u0E32\u0E07\u0E22\u0E32");//GEN-LINE:MVDGetInit64
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd64
        return ticker1;
    }//GEN-END:MVDGetEnd64

    /** This method returns instance for font1 component and should be called instead of accessing font1 field directly.//GEN-BEGIN:MVDGetBegin65
     * @return Instance for font1 component
     */
    public Font get_font1() {
        if (font1 == null) {//GEN-END:MVDGetBegin65
            // Insert pre-init code here
            font1 = Font.getFont(Font.FONT_INPUT_TEXT);//GEN-LINE:MVDGetInit65
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd65
        return font1;
    }//GEN-END:MVDGetEnd65
  

    /** This method returns instance for font2 component and should be called instead of accessing font2 field directly.//GEN-BEGIN:MVDGetBegin73
     * @return Instance for font2 component
     */
    public Font get_font2() {
        if (font2 == null) {//GEN-END:MVDGetBegin73
            // Insert pre-init code here
            font2 = Font.getDefaultFont();//GEN-LINE:MVDGetInit73
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd73
        return font2;
    }//GEN-END:MVDGetEnd73
  
    /** This method returns instance for okCommand4 component and should be called instead of accessing okCommand4 field directly.//GEN-BEGIN:MVDGetBegin82
     * @return Instance for okCommand4 component
     */
    public Command get_okCommand4() {
        if (okCommand4 == null) {//GEN-END:MVDGetBegin82
            // Insert pre-init code here
            okCommand4 = new Command("Ok", Command.OK, 1);//GEN-LINE:MVDGetInit82
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd82
        return okCommand4;
    }//GEN-END:MVDGetEnd82

    /** This method returns instance for choiceGroup1 component and should be called instead of accessing choiceGroup1 field directly.//GEN-BEGIN:MVDGetBegin84
     * @return Instance for choiceGroup1 component
     */
    public ChoiceGroup get_choiceGroup1() {
        if (choiceGroup1 == null) {//GEN-END:MVDGetBegin84
            // Insert pre-init code here
            choiceGroup1 = new ChoiceGroup("", Choice.POPUP, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit84
            choiceGroup1.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit84
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd84
        return choiceGroup1;
    }//GEN-END:MVDGetEnd84
 

    /** This method returns instance for textField3 component and should be called instead of accessing textField3 field directly.//GEN-BEGIN:MVDGetBegin26
     * @return Instance for textField3 component
     */
    public TextField get_textField3() {
        if (textField3 == null) {//GEN-END:MVDGetBegin26
            // Insert pre-init code here
            textField3 = new TextField("\u0E2D\u0E32\u0E01\u0E32\u0E23\u0E2D\u0E37\u0E48\u0E19\u0E46", "", 100000, TextField.ANY);//GEN-LINE:MVDGetInit26
            // Insert post-init code here
            //textField3.setItemCommandListener(this);
            
        }//GEN-BEGIN:MVDGetEnd26
        return textField3;
    }//GEN-END:MVDGetEnd26

    /** This method returns instance for choice1 component and should be called instead of accessing choice1 field directly.//GEN-BEGIN:MVDGetBegin89
     * @return Instance for choice1 component
     */
    public ChoiceGroup get_choice1() {
        if (choice1 == null) {//GEN-END:MVDGetBegin89
            // Insert pre-init code here
            choice1 = new ChoiceGroup("\u0E1B\u0E27\u0E14", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit89
            choice1.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit89
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd89
        return choice1;
    }//GEN-END:MVDGetEnd89

    /** This method returns instance for choice2 component and should be called instead of accessing choice2 field directly.//GEN-BEGIN:MVDGetBegin114
     * @return Instance for choice2 component
     */
    public ChoiceGroup get_choice2() {
        if (choice2 == null) {//GEN-END:MVDGetBegin114
            // Insert pre-init code here
            choice2 = new ChoiceGroup("\u0E41\u0E1C\u0E25", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit114
            choice2.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit114
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd114
        return choice2;
    }//GEN-END:MVDGetEnd114

    /** This method returns instance for choice3 component and should be called instead of accessing choice3 field directly.//GEN-BEGIN:MVDGetBegin115
     * @return Instance for choice3 component
     */
    public ChoiceGroup get_choice3() {
        if (choice3 == null) {//GEN-END:MVDGetBegin115
            // Insert pre-init code here
            choice3 = new ChoiceGroup("\u0E44\u0E2D", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit115
            choice3.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit115
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd115
        return choice3;
    }//GEN-END:MVDGetEnd115

    /** This method returns instance for choice4 component and should be called instead of accessing choice4 field directly.//GEN-BEGIN:MVDGetBegin116
     * @return Instance for choice4 component
     */
    public ChoiceGroup get_choice4() {
        if (choice4 == null) {//GEN-END:MVDGetBegin116
            // Insert pre-init code here
            choice4 = new ChoiceGroup("\u0E15\u0E32", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit116
            choice4.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit116
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd116
        return choice4;
    }//GEN-END:MVDGetEnd116

    /** This method returns instance for choice5 component and should be called instead of accessing choice5 field directly.//GEN-BEGIN:MVDGetBegin117
     * @return Instance for choice5 component
     */
    public ChoiceGroup get_choice5() {
        if (choice5 == null) {//GEN-END:MVDGetBegin117
            // Insert pre-init code here
            choice5 = new ChoiceGroup("\u0E1B\u0E32\u0E01", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit117
            choice5.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit117
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd117
        return choice5;
    }//GEN-END:MVDGetEnd117

    /** This method returns instance for choice6 component and should be called instead of accessing choice6 field directly.//GEN-BEGIN:MVDGetBegin118
     * @return Instance for choice6 component
     */
    public ChoiceGroup get_choice6() {
        if (choice6 == null) {//GEN-END:MVDGetBegin118
            // Insert pre-init code here
            choice6 = new ChoiceGroup("\u0E17\u0E49\u0E2D\u0E07", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit118
            choice6.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit118
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd118
        return choice6;
    }//GEN-END:MVDGetEnd118

    /** This method returns instance for choice7 component and should be called instead of accessing choice7 field directly.//GEN-BEGIN:MVDGetBegin119
     * @return Instance for choice7 component
     */
    public ChoiceGroup get_choice7() {
        if (choice7 == null) {//GEN-END:MVDGetBegin119
            // Insert pre-init code here
            choice7 = new ChoiceGroup("\u0E1C\u0E34\u0E27\u0E2B\u0E19\u0E31\u0E07", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit119
            choice7.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit119
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd119
        return choice7;
    }//GEN-END:MVDGetEnd119

    /** This method returns instance for choice8 component and should be called instead of accessing choice8 field directly.//GEN-BEGIN:MVDGetBegin120
     * @return Instance for choice8 component
     */
    public ChoiceGroup get_choice8() {
        if (choice8 == null) {//GEN-END:MVDGetBegin120
            // Insert pre-init code here
            choice8 = new ChoiceGroup("\u0E44\u0E02\u0E49\u0E2B\u0E27\u0E31\u0E14", Choice.MULTIPLE, new String[0], new Image[0]);//GEN-BEGIN:MVDGetInit120
            choice8.setSelectedFlags(new boolean[0]);//GEN-END:MVDGetInit120
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd120
        return choice8;
    }//GEN-END:MVDGetEnd120
    /** This method returns instance for Result component and should be called instead of accessing Result field directly.//GEN-BEGIN:MVDGetBegin67
     * @return Instance for Result component
     */
    public Form get_Result() {
        if (Result == null) {//GEN-END:MVDGetBegin67
            // Insert pre-init code here
            Result = new Form(null, new Item[] {//GEN-BEGIN:MVDGetInit67
                get_choiceGroup1(),
                get_stringItem1()
            });
            Result.addCommand(get_exitCommand1());
            Result.addCommand(get_backCommand1());
            Result.addCommand(get_screenCommand4());
            Result.addCommand(get_screenCommand15());
            Result.setCommandListener(this);//GEN-END:MVDGetInit67
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd67
        return Result;
    }//GEN-END:MVDGetEnd67

    /** This method returns instance for stringItem1 component and should be called instead of accessing stringItem1 field directly.//GEN-BEGIN:MVDGetBegin87
     * @return Instance for stringItem1 component
     */
    public StringItem get_stringItem1() {
        if (stringItem1 == null) {//GEN-END:MVDGetBegin87
            // Insert pre-init code here
            stringItem1 = new StringItem("\u0E1C\u0E25\u0E01\u0E32\u0E23\u0E04\u0E49\u0E19\u0E2B\u0E32\u0E14\u0E49\u0E27\u0E22 GAs", "");//GEN-BEGIN:MVDGetInit87
            stringItem1.setLayout(Item.LAYOUT_DEFAULT | Item.LAYOUT_NEWLINE_BEFORE);//GEN-END:MVDGetInit87
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd87
        return stringItem1;
    }//GEN-END:MVDGetEnd87

    /** This method returns instance for screenCommand3 component and should be called instead of accessing screenCommand3 field directly.//GEN-BEGIN:MVDGetBegin124
     * @return Instance for screenCommand3 component
     */
    public Command get_screenCommand3() {
        if (screenCommand3 == null) {//GEN-END:MVDGetBegin124
            // Insert pre-init code here
            screenCommand3 = new Command("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01", Command.SCREEN, 1);//GEN-LINE:MVDGetInit124
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd124
        return screenCommand3;
    }//GEN-END:MVDGetEnd124

    /** This method returns instance for SaveFile component and should be called instead of accessing SaveFile field directly.//GEN-BEGIN:MVDGetBegin126
     * @return Instance for SaveFile component
     */
    public Form get_SaveFile() {
        if (SaveFile == null) {//GEN-END:MVDGetBegin126
            // Insert pre-init code here
            SaveFile = new Form(null, new Item[] {get_textField4()});//GEN-BEGIN:MVDGetInit126
            SaveFile.addCommand(get_screenCommand6());
            SaveFile.addCommand(get_screenCommand12());
            SaveFile.addCommand(get_screenCommand5());
            SaveFile.addCommand(get_backCommand3());
            SaveFile.setCommandListener(this);//GEN-END:MVDGetInit126
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd126
        return SaveFile;
    }//GEN-END:MVDGetEnd126

    /** This method returns instance for screenCommand4 component and should be called instead of accessing screenCommand4 field directly.//GEN-BEGIN:MVDGetBegin127
     * @return Instance for screenCommand4 component
     */
    public Command get_screenCommand4() {
        if (screenCommand4 == null) {//GEN-END:MVDGetBegin127
            // Insert pre-init code here
            screenCommand4 = new Command("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01", Command.SCREEN, 1);//GEN-LINE:MVDGetInit127
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd127
        return screenCommand4;
    }//GEN-END:MVDGetEnd127

    /** This method returns instance for screenCommand5 component and should be called instead of accessing screenCommand5 field directly.//GEN-BEGIN:MVDGetBegin129
     * @return Instance for screenCommand5 component
     */
    public Command get_screenCommand5() {
        if (screenCommand5 == null) {//GEN-END:MVDGetBegin129
            // Insert pre-init code here
            screenCommand5 = new Command("\u0E2D\u0E2D\u0E01", Command.SCREEN, 1);//GEN-LINE:MVDGetInit129
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd129
        return screenCommand5;
    }//GEN-END:MVDGetEnd129

    /** This method returns instance for screenCommand6 component and should be called instead of accessing screenCommand6 field directly.//GEN-BEGIN:MVDGetBegin131
     * @return Instance for screenCommand6 component
     */
    public Command get_screenCommand6() {
        if (screenCommand6 == null) {//GEN-END:MVDGetBegin131
            // Insert pre-init code here
            screenCommand6 = new Command("\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01", Command.SCREEN, 1);//GEN-LINE:MVDGetInit131
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd131
        return screenCommand6;
    }//GEN-END:MVDGetEnd131

    /** This method returns instance for textField4 component and should be called instead of accessing textField4 field directly.//GEN-BEGIN:MVDGetBegin133
     * @return Instance for textField4 component
     */
    public TextField get_textField4() {
        if (textField4 == null) {//GEN-END:MVDGetBegin133
            // Insert pre-init code here
            textField4 = new TextField("\u0E0A\u0E37\u0E48\u0E2D\u0E44\u0E1F\u0E25\u0E4C", null, 120, TextField.ANY);//GEN-LINE:MVDGetInit133
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd133
        return textField4;
    }//GEN-END:MVDGetEnd133

    /** This method returns instance for ReadFile component and should be called instead of accessing ReadFile field directly.//GEN-BEGIN:MVDGetBegin134
     * @return Instance for ReadFile component
     */
    public Form get_ReadFile() {
        if (ReadFile == null) {//GEN-END:MVDGetBegin134
            // Insert pre-init code here
            ReadFile = new Form(null, new Item[] {//GEN-BEGIN:MVDGetInit134
                get_textField5(),
                get_stringItem2()
            });
            ReadFile.addCommand(get_screenCommand9());
            ReadFile.addCommand(get_screenCommand11());
            ReadFile.addCommand(get_screenCommand8());
            ReadFile.addCommand(get_exitCommand3());
            ReadFile.setCommandListener(this);//GEN-END:MVDGetInit134
            // Insert post-init code here
           
            
        }//GEN-BEGIN:MVDGetEnd134
        return ReadFile;
    }//GEN-END:MVDGetEnd134

    /** This method returns instance for screenCommand7 component and should be called instead of accessing screenCommand7 field directly.//GEN-BEGIN:MVDGetBegin135
     * @return Instance for screenCommand7 component
     */
    public Command get_screenCommand7() {
        if (screenCommand7 == null) {//GEN-END:MVDGetBegin135
            // Insert pre-init code here
            screenCommand7 = new Command("\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C", Command.SCREEN, 1);//GEN-LINE:MVDGetInit135
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd135
        return screenCommand7;
    }//GEN-END:MVDGetEnd135

    /** This method returns instance for screenCommand8 component and should be called instead of accessing screenCommand8 field directly.//GEN-BEGIN:MVDGetBegin137
     * @return Instance for screenCommand8 component
     */
    public Command get_screenCommand8() {
        if (screenCommand8 == null) {//GEN-END:MVDGetBegin137
            // Insert pre-init code here
            screenCommand8 = new Command("\u0E01\u0E25\u0E31\u0E1A", Command.SCREEN, 1);//GEN-LINE:MVDGetInit137
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd137
        return screenCommand8;
    }//GEN-END:MVDGetEnd137

    /** This method returns instance for exitCommand3 component and should be called instead of accessing exitCommand3 field directly.//GEN-BEGIN:MVDGetBegin139
     * @return Instance for exitCommand3 component
     */
    public Command get_exitCommand3() {
        if (exitCommand3 == null) {//GEN-END:MVDGetBegin139
            // Insert pre-init code here
            exitCommand3 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit139
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd139
        return exitCommand3;
    }//GEN-END:MVDGetEnd139

    /** This method returns instance for textField5 component and should be called instead of accessing textField5 field directly.//GEN-BEGIN:MVDGetBegin141
     * @return Instance for textField5 component
     */
    public TextField get_textField5() {
        if (textField5 == null) {//GEN-END:MVDGetBegin141
            // Insert pre-init code here
            textField5 = new TextField("\u0E0A\u0E37\u0E48\u0E2D\u0E44\u0E1F\u0E25\u0E4C", null, 120, TextField.ANY);//GEN-LINE:MVDGetInit141
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd141
        return textField5;
    }//GEN-END:MVDGetEnd141

    /** This method returns instance for screenCommand9 component and should be called instead of accessing screenCommand9 field directly.//GEN-BEGIN:MVDGetBegin142
     * @return Instance for screenCommand9 component
     */
    public Command get_screenCommand9() {
        if (screenCommand9 == null) {//GEN-END:MVDGetBegin142
            // Insert pre-init code here
            screenCommand9 = new Command("\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E48\u0E32\u0E19", Command.SCREEN, 1);//GEN-LINE:MVDGetInit142
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd142
        return screenCommand9;
    }//GEN-END:MVDGetEnd142

    /** This method returns instance for stringItem2 component and should be called instead of accessing stringItem2 field directly.//GEN-BEGIN:MVDGetBegin144
     * @return Instance for stringItem2 component
     */
    public StringItem get_stringItem2() {
        if (stringItem2 == null) {//GEN-END:MVDGetBegin144
            // Insert pre-init code here
            stringItem2 = new StringItem("", "");//GEN-LINE:MVDGetInit144
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd144
        return stringItem2;
    }//GEN-END:MVDGetEnd144

    /** This method returns instance for screenCommand10 component and should be called instead of accessing screenCommand10 field directly.//GEN-BEGIN:MVDGetBegin145
     * @return Instance for screenCommand10 component
     */
    public Command get_screenCommand10() {
        if (screenCommand10 == null) {//GEN-END:MVDGetBegin145
            // Insert pre-init code here
            screenCommand10 = new Command("\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D Internet", Command.SCREEN, 1);//GEN-LINE:MVDGetInit145
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd145
        return screenCommand10;
    }//GEN-END:MVDGetEnd145

    /** This method returns instance for backCommand2 component and should be called instead of accessing backCommand2 field directly.//GEN-BEGIN:MVDGetBegin147
     * @return Instance for backCommand2 component
     */
    public Command get_backCommand2() {
        if (backCommand2 == null) {//GEN-END:MVDGetBegin147
            // Insert pre-init code here
            backCommand2 = new Command("Back", Command.BACK, 1);//GEN-LINE:MVDGetInit147
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd147
        return backCommand2;
    }//GEN-END:MVDGetEnd147

    /** This method returns instance for backCommand3 component and should be called instead of accessing backCommand3 field directly.//GEN-BEGIN:MVDGetBegin148
     * @return Instance for backCommand3 component
     */
    public Command get_backCommand3() {
        if (backCommand3 == null) {//GEN-END:MVDGetBegin148
            // Insert pre-init code here
            backCommand3 = new Command("\u0E01\u0E25\u0E31\u0E1A", Command.BACK, 1);//GEN-LINE:MVDGetInit148
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd148
        return backCommand3;
    }//GEN-END:MVDGetEnd148

    /** This method returns instance for screenCommand11 component and should be called instead of accessing screenCommand11 field directly.//GEN-BEGIN:MVDGetBegin150
     * @return Instance for screenCommand11 component
     */
    public Command get_screenCommand11() {
        if (screenCommand11 == null) {//GEN-END:MVDGetBegin150
            // Insert pre-init code here
            screenCommand11 = new Command("\u0E25\u0E1A\u0E44\u0E1F\u0E25\u0E4C", Command.SCREEN, 1);//GEN-LINE:MVDGetInit150
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd150
        return screenCommand11;
    }//GEN-END:MVDGetEnd150

    /** This method returns instance for screenCommand12 component and should be called instead of accessing screenCommand12 field directly.//GEN-BEGIN:MVDGetBegin152
     * @return Instance for screenCommand12 component
     */
    public Command get_screenCommand12() {
        if (screenCommand12 == null) {//GEN-END:MVDGetBegin152
            // Insert pre-init code here
            screenCommand12 = new Command("\u0E40\u0E1B\u0E34\u0E14\u0E44\u0E1F\u0E25\u0E4C", Command.SCREEN, 1);//GEN-LINE:MVDGetInit152
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd152
        return screenCommand12;
    }//GEN-END:MVDGetEnd152

    /** This method returns instance for screenCommand13 component and should be called instead of accessing screenCommand13 field directly.//GEN-BEGIN:MVDGetBegin154
     * @return Instance for screenCommand13 component
     */
    public Command get_screenCommand13() {
        if (screenCommand13 == null) {//GEN-END:MVDGetBegin154
            // Insert pre-init code here
            screenCommand13 = new Command("Screen", Command.SCREEN, 1);//GEN-LINE:MVDGetInit154
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd154
        return screenCommand13;
    }//GEN-END:MVDGetEnd154

    /** This method returns instance for screenCommand14 component and should be called instead of accessing screenCommand14 field directly.//GEN-BEGIN:MVDGetBegin155
     * @return Instance for screenCommand14 component
     */
    public Command get_screenCommand14() {
        if (screenCommand14 == null) {//GEN-END:MVDGetBegin155
            // Insert pre-init code here
            screenCommand14 = new Command("\u0E1B\u0E23\u0E31\u0E1A\u0E1B\u0E23\u0E38\u0E07 list", Command.SCREEN, 1);//GEN-LINE:MVDGetInit155
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd155
        return screenCommand14;
    }//GEN-END:MVDGetEnd155

    /** This method returns instance for screenCommand15 component and should be called instead of accessing screenCommand15 field directly.//GEN-BEGIN:MVDGetBegin158
     * @return Instance for screenCommand15 component
     */
    public Command get_screenCommand15() {
        if (screenCommand15 == null) {//GEN-END:MVDGetBegin158
            // Insert pre-init code here
            screenCommand15 = new Command("\u0E40\u0E1B\u0E34\u0E14\u0E2D\u0E48\u0E32\u0E19\u0E44\u0E1F\u0E25\u0E4C", Command.SCREEN, 1);//GEN-LINE:MVDGetInit158
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd158
        return screenCommand15;
    }//GEN-END:MVDGetEnd158

    /** This method returns instance for screenCommand16 component and should be called instead of accessing screenCommand16 field directly.//GEN-BEGIN:MVDGetBegin160
     * @return Instance for screenCommand16 component
     */
    public Command get_screenCommand16() {
        if (screenCommand16 == null) {//GEN-END:MVDGetBegin160
            // Insert pre-init code here
            screenCommand16 = new Command("\u0E01\u0E25\u0E31\u0E1A", Command.SCREEN, 1);//GEN-LINE:MVDGetInit160
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd160
        return screenCommand16;
    }//GEN-END:MVDGetEnd160
      
    public void startApp() {
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    public void itemStateChanged(Item item)
    {  /*System.out.println("dffvsdfs");
        if(item== get_form2().get(0))
        {System.out.println("dffvsdfs"+ item));
        }*/
        /// System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrr");
        try {
            String t=(((TextField)item).getString());
           // get_form2().append(new Item[] )
                          
             
          //   String temp11="�ѡ���"; 
         //    System.out.println(decodethai(temp11));
             
         //   System.out.println(t+"==" +decodethai(temp11));
            
         //   if(t.equals(decodethai(temp11)))
         //       System.out.println("nonononoononono");
        } catch (NumberFormatException nfe) {
         //  System.out.println("qqqqqqqqqqqqqqqqqqqqqqqq");
        }

        
    }
    public void sendPostRequest() {
        HttpConnection hc = null;
	DataInputStream dis = null;
	DataOutputStream dos = null;
        SocketConnection cs= null;
        String tt=null;
        StringBuffer messagebuffer = new StringBuffer();
        try {
                // Open up a http connection with the Web server
		// for both send and receive operations

                hc = (HttpConnection)Connector.open(defaultURL+"login.php",Connector.READ_WRITE);
		// Set the request method to POST
		hc.setRequestMethod(HttpConnection.POST);
                hc.setRequestProperty("User-Agent","Profile/MIDP-2.0 Confirguration/CLDC-1.1");
                hc.setRequestProperty("Content-Language","UTF-8");
                hc.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
               // hc.setRequestProperty( "Content-Length","" + req.length() + "");
                String req_temp=encodethai(req);
                hc.setRequestProperty("Content-Length", Integer.toString(req_temp.length()));
              
		// Send the string entered by user byte by byte
		dos = hc.openDataOutputStream();              
		//byte[] request_body = req.getBytes();
               // System.out.println(request_body.length);
                dos.write(req_temp.getBytes());
		dos.flush();
		dos.close();
                int rc;                 
                rc = hc.getResponseCode();
                if (rc != HttpConnection.HTTP_OK) {
                               throw new IOException("HTTP response code: " + rc);
                }
                else{
                        Alert alert = new Alert("Confirm", "The data has been uploaded.", null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                }

		// Retrieve the response back from the servlet
		dis = new DataInputStream(hc.openInputStream());
		int ch;
		// Check the Content-Length first
		long len = hc.getLength(); 
                //System.out.println(len);
		if(len!=-1) {
			for(int i = 0;i<len-1;i++)
				if((ch = dis.read())!= -1){
					messagebuffer.append((char)ch);
                                      //  System.out.println(i);
				} }
                else {
					// if the content-length is not available
					while ((ch = dis.read()) != -1)
						messagebuffer.append((char) ch);
				}
		//tt=dis.readUTF();
               // System.out.println("dsafd"+tt);
		dis.close();
        }catch (IOException ioe) {
		messagebuffer = new StringBuffer("ERROR!");
	}finally {
		// Free up i/o streams and http connection
		try { 
			if (hc != null) hc.close();
		} catch (IOException ignored) {}
		try { 
			if (dis != null) dis.close();
		} catch (IOException ignored) {}
		try { 
			if (dos != null) dos.close();
		} catch (IOException ignored) {}
	}
          
        //System.out.println( buff+"???");
       //  String kk=new String(test.getBytes("ISO8859-1"),"TIS-620");
        resultstring =  decodethai(messagebuffer.toString());//messagebuffer.toString();
                // Insert post-action code here
        int gg=resultstring.length();

        //String kl=new String(resultstring.getBytes("UTF-8","TIS-620"));
        Integer kk=new Integer(resultstring.length());
        
      // String tr=new String( yy.getBytes(encoding1));
        if (resultstring.equals("no"))
        { 
                        Alert alert = new Alert("Fail", "The user or password is fail.", null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
        }
        else if(resultstring.equals("yes")){
            getDisplay().setCurrent(get_List());
            
            ///////read file///////
 //           try{
        //    FileConnection fl = (FileConnection)Connector.open("file:///list.txt") ;
          //  FileConnection fl;
            
           

            
            /**/
      /*      }catch(IOException ioe){
		messagebuffer = new StringBuffer("ERROR!");
	}*/
            
           // textField3.setString(decodethai("���"));
            }
        else
        {Alert alert = new Alert("Fail",resultstring , null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
        }
    }
    public String decodethai(String test){
    
    String buff = "";
          //String tothai = new String(request.getParameter("tothai").getBytes("ISO8859_1"),"TIS-620"); 

          //String test=messagebuffer.toString();
             for (int i=0; i<test.length(); i++) {
            // value of ???\u0E01??? is 3585
                     if (test.charAt(i) >= 0xA1 && (int)test.charAt(i) <= 0xFB)
                    buff += (char)(test.charAt(i) + 3424);
                    else buff += test.charAt(i);
                    }
         return buff;
    }
    public String encodethai(String test){
        String buff = "";
          //String tothai = new String(request.getParameter("tothai").getBytes("ISO8859_1"),"TIS-620"); 

          //String test=messagebuffer.toString();
        
             for (int i=0; i<test.length(); i++) {
            // value of ???\u0E01??? is 3585
                     if (test.charAt(i) >=0xE0 && (int)test.charAt(i) <= 0xE5B)
                    buff += (char)(test.charAt(i) - 3424);
                    else buff += test.charAt(i);
                    }
         return buff;
    
    }
    
        public void sendPostRequest1() {
        HttpConnection hc = null;
	DataInputStream dis = null;
	DataOutputStream dos = null;
        SocketConnection cs= null;
        StringBuffer messagebuffer = new StringBuffer();
        try {
                // Open up a http connection with the Web server
		// for both send and receive operations
                hc = (HttpConnection)Connector.open(defaultURL+"search.php",Connector.READ_WRITE);
		// Set the request method to POST
		hc.setRequestMethod(HttpConnection.POST);
                hc.setRequestProperty("User-Agent","Profile/MIDP-2.0 Confirguration/CLDC-1.1");
                hc.setRequestProperty("Content-Language","TIS620");
                hc.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
               // hc.setRequestProperty( "Content-Length","" + req.length() + "");
                String req_temp=reqdrug;//encodethai(reqdrug);
                hc.setRequestProperty("Content-Length", Integer.toString(req_temp.length()));
              
		// Send the string entered by user byte by byte
		dos = hc.openDataOutputStream();              
		//byte[] request_body = req.getBytes();
               // System.out.println(request_body.length);
                dos.write(req_temp.getBytes());
                //dos.w
		dos.flush();
		dos.close();
                int rc;                 
                rc = hc.getResponseCode();
                if (rc != HttpConnection.HTTP_OK) {
                               throw new IOException("HTTP response code: " + rc);
                }
                else{
                        Alert alert = new Alert("Confirm", "The data has been uploaded.", null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                }

		// Retrieve the response back from the servlet
		dis = new DataInputStream(hc.openInputStream());
		int ch;
		// Check the Content-Length first
		long len = hc.getLength(); 
               // System.out.println(len);
		if(len!=-1) {
			for(int i = 0;i<len;i++)
				if((ch = dis.read())!= -1){
					messagebuffer.append((char)ch);
                                        //System.out.println(i);
				} }
                else {
					// if the content-length is not available
					while ((ch = dis.read()) != -1)
						messagebuffer.append((char) ch);
				}
		
		dis.close();
        }catch (IOException ioe) {
		messagebuffer = new StringBuffer("ERROR!");
	}finally {
		// Free up i/o streams and http connection
		try { 
			if (hc != null) hc.close();
		} catch (IOException ignored) {}
		try { 
			if (dis != null) dis.close();
		} catch (IOException ignored) {}
		try { 
			if (dos != null) dos.close();
		} catch (IOException ignored) {}
	}
          
        //System.out.println( buff+"???");
       //  String kk=new String(test.getBytes("ISO8859-1"),"TIS-620");
        resultstring =  decodethai(messagebuffer.toString());//messagebuffer.toString();
         getDisplay().setCurrent(get_Result());
         stringItem1.setText(resultstring);
         resultdata=  resultstring.toString();
  
         
        
        }
        public void sendPostRequest2() {
            
            RecordStore rs; 
            
            
            try{
                    rs=RecordStore.openRecordStore("list111111_waw",true);
                    int lastRec=rs.getNumRecords();
                    //int size=rs.getRecordSize(lastRec);
                    if(lastRec!=0)
                    { String s=getsend();
                       if(!s.equals(""))
                       { byte[] data=getBytesfromUTFString(s.toString());
                         rs.setRecord(lastRec,data,0,data.length);
                       }
                       else
                       {
                            Alert alert = new Alert("fail",decodethai("�����żԴ��Ҵ"), null, null);
                            alert.setTimeout(Alert.FOREVER);
                            alert.setType(AlertType.INFO);
                            // Display.getDisplay(mainMobiWare).setCurrent(alert);
                            getDisplay().setCurrent(alert);
                       }
                      
                                          
                    }
                    else
                    {
                        String s=getsend();
                        
                       if(!s.equals(""))
                       { byte[] data=getBytesfromUTFString(s.toString());
                         rs.addRecord(data,0,data.length);
                       }
                       else
                       {
                            Alert alert = new Alert("fail",decodethai("�����żԴ��Ҵ"), null, null);
                            alert.setTimeout(Alert.FOREVER);
                            alert.setType(AlertType.INFO);
                            // Display.getDisplay(mainMobiWare).setCurrent(alert);
                            getDisplay().setCurrent(alert);
                       }
                    }
                    rs.closeRecordStore();   

                    
                }catch(RecordStoreException e){
                    System.out.print(e);
                }
                
        //messagebuffer.toString();
         
          Alert alert = new Alert("Confirm",decodethai("��Ѻ��ا����"), null, null);
          alert.setTimeout(Alert.FOREVER);
          alert.setType(AlertType.INFO);
          // Display.getDisplay(mainMobiWare).setCurrent(alert);
          getDisplay().setCurrent(alert);
          getDisplay().setCurrent(get_Menu());        
        }
private String getsend()
{        
        HttpConnection hc = null;
        DataInputStream dis = null;
        DataOutputStream dos = null;
        SocketConnection cs= null;
        StringBuffer messagebuffer = new StringBuffer();
        try {
                // Open up a http connection with the Web server
		// for both send and receive operations
                hc = (HttpConnection)Connector.open(defaultURL+"download.php",Connector.READ_WRITE);
		// Set the request method to POST
		hc.setRequestMethod(HttpConnection.POST);
                hc.setRequestProperty("User-Agent","Profile/MIDP-2.0 Confirguration/CLDC-1.1");
                hc.setRequestProperty("Content-Language","TIS620");
                hc.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
               // hc.setRequestProperty( "Content-Length","" + req.length() + "");
                String req_temp="";//encodethai(reqdrug);
                hc.setRequestProperty("Content-Length", Integer.toString(req_temp.length()));
              
		// Send the string entered by user byte by byte
		dos = hc.openDataOutputStream();              
		//byte[] request_body = req.getBytes();
               // System.out.println(request_body.length);
                dos.write(req_temp.getBytes());
                //dos.w
                
		dos.flush();
		dos.close();
                int rc;                 
                rc = hc.getResponseCode();
                if (rc != HttpConnection.HTTP_OK) {
                               throw new IOException("HTTP response code: " + rc);
                }
                else{
                        Alert alert = new Alert("Confirm", "The data has been uploaded.", null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                }

		// Retrieve the response back from the servlet
		dis = new DataInputStream(hc.openInputStream());
		int ch;
		// Check the Content-Length first
		long len = hc.getLength(); 
               // System.out.println(len);
		if(len!=-1) {
			for(int i = 0;i<len;i++)
				if((ch = dis.read())!= -1){
					messagebuffer.append((char)ch);
                                        //System.out.println(i);
				} }
                else {
					// if the content-length is not available
					while ((ch = dis.read()) != -1)
						messagebuffer.append((char) ch);
				}
		
		dis.close();
        }catch (IOException ioe) {
		messagebuffer = new StringBuffer("");
                Alert alert = new Alert("Error", "Error", null, null);
                        alert.setTimeout(Alert.FOREVER);
                        alert.setType(AlertType.INFO);
                       // Display.getDisplay(mainMobiWare).setCurrent(alert);
                        getDisplay().setCurrent(alert);
                
	}finally {
		// Free up i/o streams and http connection
		try { 
			if (hc != null) hc.close();
		} catch (IOException ignored) {}
		try { 
			if (dis != null) dis.close();
		} catch (IOException ignored) {}
		try { 
			if (dos != null) dos.close();
		} catch (IOException ignored) {}
	}
          
        //System.out.println( buff+"???");
       //  String kk=new String(test.getBytes("ISO8859-1"),"TIS-620");
        return  decodethai(messagebuffer.toString());
    
}
private String getStringResource(String fname) { 
        InputStream is = getClass().getResourceAsStream(fname); 

        if (is != null) { 
        ByteArrayOutputStream bos = new ByteArrayOutputStream(); 

        try { 
        int read = -1; 
        while ((read = is.read()) != -1) { 
        bos.write(read); 
        } 

        return new String(bos.toByteArray()); 
        } 
        catch (IOException e) { 
           
        return null; 
        } 
        } 

        return null; 
} 
public static String[] splitData(String sep,String splitWord) 
{   
        String tmpSplitWord = splitWord;
        int i=0;
        while (splitWord.indexOf(sep)!=-1) {

            splitWord = splitWord.substring(splitWord.indexOf(sep)+sep.length());
            i++;
        }
        //System.out.print(i);
        splitWord = tmpSplitWord;
        String[] Data = new String[i+1];
        for (int j=0;j<i;j++) {
            Data[j] = splitWord.substring(0,splitWord.indexOf(sep));
            splitWord = splitWord.substring(splitWord.indexOf(sep)+sep.length());

        }
        Data[i] = splitWord;
        return Data;
}
private boolean  putStringResource(String fname,String put) { 
        
        OutputConnection conn = null;
	DataInputStream dis = null;
	DataOutputStream dos = null;
                
        String url = "file:///"+fname;
        
                
        int mode = Connector.READ_WRITE;

        try {  
                 conn =(OutputConnection) Connector.open( url, mode );
                 
             //    conn =(InputConnection) Connector.open( url, mode );

                 dos=conn.openDataOutputStream();
                 
                 dos.write(put.getBytes());
                 dos.flush();
                 dos.close();
                 return true;
            }
        catch( IOException ioe ){
                    
                   return false;//no file
             }
        
       //   return true;      
        

        
} 
public final byte[] getBytesfromUTFString(String in)
{
        try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                dos.writeUTF(in);
                byte[] byt = baos.toByteArray();

                baos.close();
                dos.close();
                baos=null;
                dos=null;

                byte[] out = new byte[byt.length-2];
                System.arraycopy(byt,2,out,0,out.length);

                return out;
        }
        catch (IOException ex) {}


        return null;
}



public final String getUTFString(byte[] in,int start,int length)
{
        byte[] sz = null;

        ByteArrayOutputStream ll = new ByteArrayOutputStream();
        int l = length/256;
        ll.write(l);
        ll.write(length - l*256);
        sz = ll.toByteArray();
        try {
                ll.close();
                ll = null;
        }
        catch (IOException ex1) {}

        byte[] byt = new byte[length+2];
        System.arraycopy(in,start,byt,2,length);
        byt[0] = sz[0];
        byt[1] = sz[1];

        //System.out.println("START readUTF");

        ByteArrayInputStream bai = new ByteArrayInputStream(byt);
        DataInputStream dis = new DataInputStream(bai);
        String ret =null;
        try {
            ret = dis.readUTF();
            //System.out.println("readUTF:" + ret);
        }
        catch (IOException ex) {
        //System.out.println("ERROR readUTF():" + ex);
        }

        try {
            dis.close();
            bai.close();
        }
        catch (IOException ex1) {}
        //System.out.println("END readUTF");

        return ret;
}

        
}
