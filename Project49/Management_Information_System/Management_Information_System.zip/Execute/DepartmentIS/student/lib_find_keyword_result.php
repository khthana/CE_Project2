<?
include("_CheckSession.php"); 
include("_StartConnection.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" onLoad="document.search_form.keyword.focus()" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"><form name="search_form" method="post" action="lib_find_keyword_result.php">
                                      <div align="center"><img src="../resource/img/search.gif" width="16" height="16"> 
                                        <input type="text" name="keyword">
                                        <input type="submit" name="Submit" value="����">
                                      </div>
                                    </form>
									<?
									$keyword = $_POST["keyword"];
									$countbooks = 1 ;
										
											$sql = "SELECT * FROM books WHERE bnamethai LIKE '%".$keyword."%' OR bnameeng LIKE  '%".$keyword."%'  ";	
											//print $sql;
											$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
											$table1 = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
											if ($keyword =="" or !($row=mysql_fetch_array($table1)))
											{
												print "<br><div align = 'center'><font color ='red'>";
												print "���鹾���¡��˹ѧ���";
												print "</div>";
											}
											else
											{
												
												
									?>
                                    <br>
                                    <table  style="BORDER-COLLAPSE: collapse" 
                              bordercolor=#c0c0c0 cellspacing=0 cellpadding=2 
                              width=765 border=1>
                                      <tr bgcolor="#CCCCCC"> 
                                        <td width="5%">�ӴѺ</td>
                                        <td width="9%">����˹ѧ���</td>
                                        <td width="25%">����������</td>
                                        <td width="37%">���������ѧ���</td>
                                        <td width="9%">�ա���֡��</td>
                                        <td width="15%">ʶҹС�����</td>
                                      </tr>
                                      <tr> 
                                        <?	
				
			while ($row = mysql_fetch_array($table))
			{
					$bookid = $row[bookid];
					$bnamethai = $row[bnamethai];
					$bnameeng = $row[bnameeng];
					$bookyear = $row[bookyear];
					
					
?>
                                        <td> 
                                          <?=$countbooks ?>
                                        </td>
                                        <td> <a href =lib_bookdetail1.php?bookid=<?=$bookid?>  target="_blank"> 
                                          <?=$bookid ?>
                                          </a> </td>
                                        <td> 
                                          <?=$bnamethai ?>
                                        </td>
                                        <td> 
                                          <?=$bnameeng ?>
                                        </td>
                                        <td> 
                                          <?=$bookyear ?>
                                        </td>
                                        <td>
                                          <?
										$sql2= "select * from bookborrow where bookid = '$bookid' and bstatus ='1' ";
										$table2 = mysql_query($sql2,$conn) or die ("�������ö���¡������㹵��ҧ��"); 	
										if ($row2 = mysql_fetch_array($table2))	{
										 	print  "<font color = 'red' >��� </red>";
										}
										else {
										   print "��ҧ";
										 }
										
										
										?>
                                        </td>
                                      </tr>
                                      <?       $countbooks +=1;
             } //��loop while
?>
                                    </table>
                                    <?
             } //�����͹� else
?>
                                    <div align="center"><br>
                                      
                                      �š�ä��� <font color ="red">
                                      <?=$countbooks-1?>
                                      </font> record(s). <br>
                                      <br>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
    include("_EndConnection.php");
?>
</body>
</html>
