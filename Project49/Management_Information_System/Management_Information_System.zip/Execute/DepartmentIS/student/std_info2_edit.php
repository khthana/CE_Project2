<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									include ("_sql_info2.php");
									?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
<form name="form1" method="post" action="std_info2_update.php">
                                      <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                        <TBODY>
                                          <TR> 
                                            <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                                <TBODY>
                                                  <TR> 
                                                    <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                      1 ����ѵԹѡ�֡��</STRONG></TD>
                                                  </TR>
                                                </TBODY>
                                              </TABLE></TD>
                                          </TR>
                                          <TR> 
                                            <TD bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
                                                <TBODY>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.1</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�Դ</STRONG>&nbsp;�ѹ���&nbsp; 
                                                      <select name="date">
                                                        <?
															$var_day = range(0,31);
															foreach ($var_day as $theday) {	
																if ($theday == 0) {
																	$theday = "";
																}
																if ($theday == $birth_day) {
																	$chk = "selected";
																}
																
															?>
                                                        <option value="<?=$theday?>" <?=$chk?>> 
                                                        <?=$theday?>
                                                        </option>
                                                        <?		
															$chk = "";
														}
														?>
                                                      </select> &nbsp;&nbsp;��͹&nbsp; 
                                                      <select name="month">
                                                        <?
														include("../resource/_array.php");
														 foreach (	$arraymonth as $valuemonth => $month)
														{				
																if ($valuemonth == 0) {
																	$valuemonth = "";
																}
																if ($valuemonth == $birth_month){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                        <option value="<?=$valuemonth?>" <?=$chk?>> 
                                                        <?=$month?>
                                                        </option>
                                                        <?
															$chk ="";
														}
														?>
                                                      </select> &nbsp;&nbsp;��&nbsp; 
                                                      <select name="year">
                                                        <?
															$var_year = range(2449,2550);
															foreach ($var_year as $theyear) {	
																if ($theyear == 2449) {
																	$theyear = "";
																}
																if ($theyear== $birth_year) {
																	$chk = "selected";
																}
																
															?>
                                                        <option value="<?=$theyear?>" <?=$chk?>> 
                                                        <?=$theyear?>
                                                        </option>
                                                        <?		
															$chk = "";
														}
														?>
                                                      </select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <STRONG>�ѧ��Ѵ����Դ</STRONG>&nbsp; 
                                                      <select name="province_of_birth">
                                                        <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $birth_place){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                        <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                        <?=$province?>
                                                        </option>
                                                        <?
															$chk ="";
														}
														?>
                                                      </select> </TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.2</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT name=race  type=radio id=radio value="��" <?=$race1?>>
                                                      �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT 
            id=radio  type=radio value="�չ" name=race <?=$race2?>>
                                                      �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT id=radio 
             type=radio value="other" name=race <?=$race3?>>
                                                      ���� (�к�)&nbsp;:&nbsp; 
                                                      <INPUT  maxLength=20 size=14 name=race2 value="<?=$racestatus?>"> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT name=citizen type=radio id=radio2 value="��" <?=$nationality1?>>
                                                      �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT id=radio2  
            type=radio value="�չ" name=citizen <?=$nationality2?>>
                                                      �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT id=radio2  
            type=radio value="other" name=citizen <?=$nationality3?>>
                                                      ���� (�к�)&nbsp;:&nbsp; 
                                                      <INPUT 
             maxLength=20 size=14 name=citizen2 value="<?=$nationalitystatus?>"></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.3</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                      <input name=religion  
            type=radio id=radio3 value="�ط�" <?=$religion1?>>
                                                      �ط� &nbsp;&nbsp;2. 
                                                      <INPUT 
            id=radio3  type=radio value="���ʵ�" name=religion <?=$religion2?>>
                                                      ���ʵ� &nbsp;3. 
                                                      <INPUT id=radio3  type=radio value="������"
            name=religion  <?=$religion3?>>
                                                      ������ &nbsp;&nbsp;4. 
                                                      <INPUT id=radio3  
            type=radio value="other" name=religion <?=$religion4?>>
                                                      ���� (�к�)&nbsp;:&nbsp; 
                                                      <INPUT 
             maxLength=20 size=16 name=religion2 value="<?=$religionstatus?>"> 
                                                    </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.4</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�������Ե</STRONG>&nbsp;&nbsp;1. 
                                                      <INPUT name=blood 
             type=radio id=radio4 value="A" <?=$blood1?> >
                                                      A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                                                      <INPUT id=radio4  
            type=radio value="B" name=blood <?=$blood2?>>
                                                      B &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. 
                                                      <INPUT id=radio4  
            type=radio value="AB" name=blood <?=$blood3?>>
                                                      AB &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4. 
                                                      <INPUT id=radio4 
             type=radio value="O" name=blood <?=$blood4?>>
                                                      O &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5. 
                                                      <INPUT id=radio4  
            type=radio value="�����" name=blood <?=$blood5?>>
                                                      ����� </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.5</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�������������¹��ҹ</STRONG> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                      <INPUT 
            maxLength=10 size=5 name=homeno1 value="<?=$number_static?>"> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                      <INPUT  
            maxLength=2 size=2 name=moo1 value="<?=$group_static?>"> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                      <INPUT 
             maxLength=20 size=16 name=soi1 value="<?=$lane_static?>"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                      <INPUT 
             maxLength=20 size=17 name=street1 value="<?=$road_static?>"> </TD>
                                                  <TR> 
                                                    <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                      <INPUT  maxLength=20 size=19 name=tambon1 value="<?=$district_static?>"> 
                                                      &nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                      <INPUT  
            maxLength=20 size=16 name=amphur1 value="<?=$region_static?>"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                      <select name="province1">
                                                        <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_static){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                        <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                        <?=$province?>
                                                        </option>
                                                        <?
															$chk ="";
														}
														?>
                                                      </select> </TD>
                                                  <TR> 
                                                    <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                      <INPUT 
             maxLength=5 size=10 name=zipcode1 value="<?=$postalcode_static?>"> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT  maxLength=15 size=16 name=telno1 value="<?=$telephone_static?>"> 
                                                    </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.6</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�������������ö�Դ�����</STRONG>&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                      <INPUT name=homeno2 value="<?=$number_contact?>" size=5  maxLength=10> 
                                                      &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                      <INPUT name=moo2 value="<?=$group_contact?>" size=2  
            maxLength=2> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                      <INPUT name=soi2 value="<?=$lane_contact?>" size=16 
             maxLength=20> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                      <INPUT name=street2 value="<?=$road_contact?>" size=17 
             maxLength=20> </TD>
                                                  <TR> 
                                                    <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                      <INPUT name=tambon2 value="<?=$district_contact?>" size=19  maxLength=20> 
                                                      &nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                      <INPUT name=amphur2 value="<?=$region_contact?>" size=16  
            maxLength=20> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                      <select name="province2">
                                                        <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                        <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                        <?=$province?>
                                                        </option>
                                                        <?
															$chk ="";
														}
														?>
                                                      </select> </TD>
                                                  <TR> 
                                                    <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                      <INPUT name=zipcode2 value="<?=$postalcode_contact?>" size=10 
             maxLength=5> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      <INPUT name=telno2 value="<?=$telephone_contact?>" size=16  maxLength=15> 
                                                    </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.7</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�Ѩ�غѹ���������Ѻ</STRONG><BR> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      1. 
                                                      <INPUT
            name=livewith type=radio id=radio5 value="�Դ�-��ô�" <?=$habital1?>>
                                                      �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      2. 
                                                      <INPUT id=radio5  type=radio value="�Դ�" name=livewith <?=$habital2?>>
                                                      �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      3. 
                                                      <INPUT id=radio5  type=radio value="��ô�" name=livewith <?=$habital3?>>
                                                      ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      4. 
                                                      <INPUT id=radio5  type=radio value="��ҹ���/��ͧ���"
            name=livewith <?=$habital4?>>
                                                      ��ҹ���/��ͧ��� &nbsp;&nbsp; 
                                                      5. 
                                                      <INPUT id=radio5 
             type=radio value="�;ѡʶҺѹ" name=livewith <?=$habital5?>>
                                                      �;ѡʶҺѹ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      6. 
                                                      <INPUT id=radio5  
            type=radio value="�;ѡ�͡��" name=livewith <?=$habital6?>>
                                                      �;ѡ�͡�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      7. 
                                                      <INPUT id=radio5  type=radio value="�ҵ�" name=livewith <?=$habital7?>>
                                                      �ҵ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      8. 
                                                      <INPUT id=radio5  type=radio value="�Ѵ" name=livewith <?=$habital8?>>
                                                      �Ѵ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      9. 
                                                      <INPUT id=radio5  type=radio value="other" name=livewith <?=$habital9?>>
                                                      ���� (�к�)&nbsp;:&nbsp; 
                                                      <INPUT  maxLength=25 size=16 
            name=livewith2 value="<?=$habitalstatus?>"> </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.8</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>ʶҹ�Ҿ���ʢͧ�Դ�-��ô�</STRONG><BR> 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      1. 
                                                      <INPUT 
            name=parentstatus  type=radio id=radio6 value="������¡ѹ" <?=$status_parent1?>>
                                                      ������¡ѹ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      2. 
                                                      <INPUT id=radio6 
             type=radio value="�Դ�-��ôҶ֧�����" name=parentstatus <?=$status_parent2?>>
                                                      �Դ�-��ôҶ֧����� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      3. 
                                                      <INPUT id=radio6  type=radio value="�ԴҶ֧�����" 
            name=parentstatus <?=$status_parent3?>>
                                                      �ԴҶ֧����� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      4. 
                                                      <INPUT id=radio6 
             type=radio value="��ôҶ֧�����" name=parentstatus <?=$status_parent4?>>
                                                      ��ôҶ֧����� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      5. 
                                                      <INPUT id=radio6  type=radio value="����" 
            name=parentstatus <?=$status_parent5?>>
                                                      ���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      6. 
                                                      <INPUT id=radio6  type=radio value="�¡�ѹ�������Ф������繷ҧ�Ҫվ" 
            name=parentstatus <?=$status_parent6?>>
                                                      �¡�ѹ�������Ф������繷ҧ�Ҫվ 
                                                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                      7. 
                                                      <INPUT id=radio6  type=radio value="�¡�ѹ���������˵ؼ����"
            name=parentstatus <?=$status_parent7?>>
                                                      �¡�ѹ���������˵ؼ���� 
                                                    </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.9</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�ѡ�֡���繺صä����</STRONG>&nbsp; 
                                                      <INPUT name=childno value="<?=$relatives?>" size=2 
             maxLength=2> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>㹨ӹǹ����ͧ �Դ�-��ô����ǡѹ����ժ��Ե����</STRONG>&nbsp; 
                                                      <INPUT name=no_of_child value="<?=$alive?>" size=2  
            maxLength=2> &nbsp;�� &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>����������ҧ����֡��</STRONG>&nbsp; 
                                                      <INPUT name=std_children value="<?=$studying?>" size=2 
             maxLength=2> &nbsp;�� </TD>
                                                  <TR> 
                                                    <TD align=left width=750 height=20>&nbsp;<STRONG>1.10</STRONG> 
                                                      &nbsp;&nbsp;<STRONG>�ѡ�֡���������ҡ��÷ӧҹ�������</STRONG>&nbsp; 
                                                      1. 
                                                      <INPUT
            name=iswork  type=radio id=radio7 value="N" <?=$salary1?>>
                                                      ���������� &nbsp;&nbsp; 
                                                      2. 
                                                      <INPUT id=radio7 
            type=radio value="Y" name=iswork <?=$salary2?>>
                                                      �� (�к�) �����&nbsp; <INPUT 
             maxLength=7 size=7 name=salary value="<?=$salarystatus?>"> &nbsp;�ҷ/��͹ 
                                                    </TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left height=20>&nbsp;</TD>
                                                  </TR>
                                                </TBODY>
                                              </TABLE></TD>
                                          </TR>
                                          <TR> 
                                            <TD><div align="right"> </div></TD>
                                          </TR>
                                        </TBODY>
                                      </TABLE>
                                      <div align="center">
                                        <input type="submit" name="Submit" value="�׹�ѹ������">
                                      </div>
                                    </form>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
