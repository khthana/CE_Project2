<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									 include ("_sql_info6.php");
									 ?>
                                </div></td>
                              </tr>
                              <tr>
							  <? if ($_SESSION["username"] == $_SESSION["person_id"]) {?>
                                             <td align="left" valign="top"><div align="right"><a href="std_info1_edit.php">���</a><br>
								<? } else { ?>	
												 <td align="left" valign="top"><div align="right"><span class="style1">���</span><br>
								<? } ?>		 
                                    </div></td>
                                <!--<td align="left" valign="top"><div align="right">&nbsp;<a href="std_info6_edit.php">���</a></div></td> -->
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD align=left height=10></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                    3 ����ѵԺԴ�-��ô� ��黡��ͧ 
                                                    ��м���ػ���д�ҹ����Թ</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
          height=24>&nbsp;<STRONG>��黡��ͧ</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.19</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>��黡��ͧ�ͧ�ѡ�֡��������ҧ����繹ѡ�֡�ҢͧʶҺѹ�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=parent_person type=radio id=parent_person value="�Դ�-��ô�"  disabled <?=$s_parent1?>>
                                                    �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT 
            id=parent_person type=radio value="�Դ�" name=parent_person  disabled <?=$s_parent2?>>
                                                    �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=parent_person type=radio value="��ô�" 
            name=parent_person disabled  <?=$s_parent3?>>
                                                    ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=parent_person type=radio value="other"  
            name=parent_person disabled  <?=$s_parent4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT  
            maxLength=25 size=25 name=parent_person2 disabled value="<?=$s_parentstatus?>" > </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;�óշ���黡��ͧ�ͧ�ѡ�֡�� 
                                                    <STRONG>����</STRONG>� �Դ�-��ô� 
                                                    ���͵��ͧ (����к���������´��ҹ��ҧ���) 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.20</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=p_name id=name2 value="<?=$name_parent?>" size=24  
            maxLength=25 disabled > &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                                                    <INPUT name=p_surname id=surname2 value="<?=$surname_parent?>" size=24  
            maxLength=25 disabled > &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=p_age id=age2 value="<?=$age_parent?>" size=2  
            maxLength=2 disabled > &nbsp;�� &nbsp;&nbsp;<STRONG>����Ǣ�ͧ�Ѻ�ѡ�֡����</STRONG>&nbsp; 
                                                    <INPUT name=p_relationship 
            id=relationship value="<?=$relationship?>" size=16 maxLength=25 disabled > </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.21</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=p_race type=radio id=radio10 
            value="��" disabled <?=$race_parent1?> >
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio10 
            type=radio value="�չ" name=p_race disabled <?=$race_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio10 
            type=radio value="other" name=p_race  disabled <?=$race_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=p_race22 value="<?=$race_parentstatus?>" size=14 maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp; <INPUT name=p_citizen type=radio 
            id=radio11 value="��"  disabled <?=$nationality_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio11 
            type=radio value="�չ" name=p_citizen disabled  <?=$nationality_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio11  
            type=radio value="other" name=p_citizen disabled  <?=$nationality_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=p_citizen22 value="<?=$nationality_parentstatus?>" size=14 
            maxLength=20 disabled ></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.22</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT name=p_religion type=radio id=radio12 value="�ط�" disabled <?=$religion_parent1?>>
                                                    �ط� &nbsp;&nbsp;2. 
                                                    <INPUT id=radio12 type=radio value="���ʵ�" 
            name=p_religion disabled <?=$religion_parent2?>>
                                                    ���ʵ� &nbsp;3. 
                                                    <INPUT id=radio12 type=radio 
            value="������" name=p_religion  disabled <?=$religion_parent3?>>
                                                    ������ &nbsp;&nbsp;4. 
                                                    <INPUT id=radio12 
            type=radio value="other" name=p_religion disabled  <?=$religion_parent4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=p_religion22 value="<?=$religion_parentstatus?>" size=16 maxLength=20 disabled > 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.23</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                                                    <INPUT name=p_id 
            id=id3 value="<?=$citizenid_parent?>" size=16 maxLength=13 disabled> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.24</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                    <INPUT name=p_homeno value="<?=$number_parent?>" size=5 
            maxLength=10 disabled> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=p_moo value="<?=$group_parent?>" size=2  
            maxLength=2 disabled > &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                    <INPUT name=p_soi value="<?=$lane_parent?>" size=16 
             maxLength=20 disabled > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                    <INPUT name=p_street value="<?=$road_parent?>" size=17  maxLength=20 disabled > 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=p_tambon value="<?=$district_parent?>" size=21  maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                    <INPUT name=p_amphur value="<?=$region_parent?>" size=16  maxLength=20 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="p_province" id="p_province" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=p_zipcode value="<?=$postalcode_parent?>" size=10  disabled
             maxLength=5> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=p_telno value="<?=$tel_parent?>" size=16  maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.25</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ��黡��ͧ</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=p_academic  type=radio id=radio13 value="��ж��֡��" disabled <?=$educational_parent1?> >
                                                    ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio13  type=radio value="�Ѹ���֡��" 
            name=p_academic  disabled <?=$educational_parent2?>>
                                                    �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio13  type=radio value="������ش��֡��"
            name=p_academic  disabled <?=$educational_parent3?>>
                                                    ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio13  type=radio value="�Ҫ���֡��"
            name=p_academic disabled  <?=$educational_parent4?>>
                                                    �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT 
            id=radio13  type=radio value="͹ػ�ԭ��������º���" 
            name=p_academic disabled  <?=$educational_parent5?> >
                                                    ͹ػ�ԭ��������º��� <BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    6. 
                                                    <INPUT id=radio13  type=radio value="��ԭ�ҵ��"
            name=p_academic disabled  <?=$educational_parent6?>>
                                                    ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio13  type=radio value="��ԭ���" 
            name=p_academic disabled  <?=$educational_parent7?>>
                                                    ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio13  type=radio value="��ԭ���͡"
            name=p_academic  disabled <?=$educational_parent8?>>
                                                    ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT id=radio13  type=radio value="������ز�"
            name=p_academic disabled <?=$educational_parent9?>>
                                                    ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    10. 
                                                    <INPUT id=radio13  type=radio value="other"
            name=p_academic disabled <?=$educational_parent10?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=p_academic2 value="<?=$educational_parentstatus?>" 
            size=16  maxLength=25 disabled> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.26</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ��黡��ͧ</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=p_occupation  type=radio id=radio14 value="�Ѻ�Ҫ���"  disabled <?=$work_parent1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio14  type=radio value="��ѡ�ҹ�Ѱ����ˡԨ" 
            name=p_occupation  disabled <?=$work_parent2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio14  
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=p_occupation  disabled <?=$work_parent3?>>
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio14  type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��"
            name=p_occupation  disabled <?=$work_parent4?>>
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=radio14  type=radio value="�١��ҧ��ǹ�Ҫ���" 
            name=p_occupation disabled <?=$work_parent5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=radio14 
             type=radio value="�ɵá�/��ǻ����" name=p_occupation disabled  <?=$work_parent6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio14  type=radio 
            value="�Ѻ��ҧ" name=p_occupation  disabled <?=$work_parent7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio14  type=radio value="����Сͺ�Ҫվ" 
            name=p_occupation  disabled <?=$work_parent8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=radio14  type=radio value="other" name=p_occupation disabled  <?=$work_parent9?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            name=p_occupation2 value="<?=$work_parentstatus?>" size=16  maxLength=25 disabled> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.27</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=p_workplace value="<?=$workplace_parent?>" size=24  maxLength=30 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="p_workprovince" id="p_workprovince" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $provincework_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>"  <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=p_workzipcode value="<?=$postalcodework_parent?>" size=10  disabled 
             maxLength=5> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                                                    <INPUT name=p_worktelno value="<?=$telwork_parent?>" size=16  maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.28</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����������/��͹�ͧ��黡��ͧ</STRONG>&nbsp; 
                                                    1. 
                                                    <INPUT name=p_earn  type=radio id=radio15 value="N" disabled <?=$salary_parent1?> >
                                                    ���������� &nbsp;&nbsp; 2. 
                                                    <INPUT id=radio15  type=radio value="Y"  disabled
            name=p_earn <?=$salary_parent2?>>
                                                    �� (�к�) �����&nbsp; <INPUT name=p_salary value="<?=$salary_parentstatus?>" size=7  maxLength=7 disabled> 
                                                    &nbsp;�ҷ/��͹ </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD height=10><div align="right"><a href="std_info5.php">Back</a> 
                                              | <a href="std_info7.php">Next</a><br>
                                            </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
