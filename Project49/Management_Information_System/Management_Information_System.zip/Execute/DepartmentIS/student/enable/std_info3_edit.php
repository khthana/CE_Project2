<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <?
									 include ("_menu.php");
									 include ("_sql_info3.php");									 
									 ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                    2 ����ѵԡ���֡��</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD valign="top" bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>2.1</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������稡���֡��</STRONG> 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����稡���֡���дѺ 
                                                    <select name="finish1">
                                                      <option value="1" <?=$education_status1?>>�дѺ�Ѹ���֡�ҵ͹���� 
                                                      (�.6) </option>
                                                      <option value="2" <?=$education_status2?>>�дѺ�Ѹ���֡�ҵ͹���� 
                                                      (�ͺ��º)</option>
                                                      <option value="3" <?=$education_status3?>>�дѺ��С�ȹ�ºѵ��ԪҪվ����٧�ҡ�ç���¹/�Է�����</option>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. �ҡ�ç���¹ 
                                                    <INPUT 
            name=highschool1 value="<?=$fin_school?>" size=45  maxLength=45> <BR>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ѧ��Ѵ&nbsp; 
                                                    <select name="select_c_name">
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $fin_province){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select>
                                                    &nbsp;㹻ա���֡��&nbsp; <select name="ayear1" id="ayear1">
                                                      <?
															$var_year = range(2449,2550);
															foreach ($var_year as $theyear) {	
																if ($theyear == 2449) {
																	$theyear = "";
																}
																if ($theyear== $fin_year) {
																	$chk = "selected";
																}
																
															?>
                                                      <option value="<?=$theyear?>" <?=$chk?>> 
                                                      <?=$theyear?>
                                                      </option>
                                                      <?		
															$chk = "";
														}
														?>
                                                    </select> &nbsp;���Ѻ����дѺ��ṹ���������&nbsp; 
                                                    <INPUT name=gpa1 value="<?=$fin_gpa?>" size=4  maxLength=4> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>2.2</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������繹ѡ�֡�ҢͧʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG> 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT
            name=kmitl  type=radio id=kmitl value="Y " <?=$before_year1?>> &nbsp;����繹ѡ�֡�ҢͧʶҺѹ�����á 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=kmitl  type=radio value="N"
            name=kmitl <?=$before_year2?>>
                                                    &nbsp;���繹ѡ�֡�ҢͧʶҺѹ� 
                                                    �ҡ�͹ �ա���֡�� 
                                                    <select name="kmitlyear" id="kmitlyear">
                                                      <?
															$var_year = range(2449,2550);
															foreach ($var_year as $theyear) {	
																if ($theyear == 2449) {
																	$theyear = "";
																}
																if ($theyear== $before_year) {
																	$chk = "selected";
																}
																
															?>
                                                      <option value="<?=$theyear?>" <?=$chk?>> 
                                                      <?=$theyear?>
                                                      </option>
                                                      <?		
															$chk = "";
														}
														?>
                                                    </select> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>2.3</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����֡�������Է�����</STRONG></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=univ  type=radio id=univ value="Y" <?=$before1?>> &nbsp;������繹ѡ�֡������Է�����/ʶҺѹ��ҡ�͹</TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=univ  type=radio value="N"
            name=univ <?=$before2?>> &nbsp;���繹ѡ�֡�Ңͧ����Է�����/ʶҺѹ� �ҡ�͹<BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�кت�������Է�����&nbsp; 
                                                    <INPUT 
            name=ounivname value="<?=$before_univ?>" size=45  maxLength=45>
                                                    &nbsp;�ա���֡��&nbsp; <select name="ounivyear" id="select2">
                                                      <?
															$var_year = range(2449,2550);
															foreach ($var_year as $theyear) {	
																if ($theyear == 2449) {
																	$theyear = "";
																}
																if ($theyear== $before_yuniv) {
																	$chk = "selected";
																}
																
															?>
                                                      <option value="<?=$theyear?>" <?=$chk?>> 
                                                      <?=$theyear?>
                                                      </option>
                                                      <?		
															$chk = "";
														}
														?>
                                                    </select> </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8 height=10></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 bgColor=#e8e8e8>&nbsp;<STRONG>�����˵� 
                                                    :</STRONG>&nbsp; 㹡óշ��ѡ�֡�����繹ѡ�֡������Է�����/ʶҺѹ���� 
                                                    �ҡ�͹ (����Է����»Դ) ����ѧ����ʶҹ�Ҿ�繹ѡ�֡�Ңͧ����Է����¹������ 
                                                    ��͹�������Ѻ��§ҹ����繹ѡ�֡�ҢͧʶҺѹ� 
                                                    �ѡ�֡�Ҩе�ͧ���Թ������͡�ҡ����繹ѡ�֡�Ңͧ����Է����¹��� 
                                                    ���¡�͹ �֧������ö����Ѻ 
                                                    ��§ҹ����繹ѡ�֡�Ңͧ�ҧʶҺѹ� 
                                                    �� </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD height=10><div align="right"><a href="std_info2.php">Back</a> 
                                              | <a href="std_info4.php">Next</a><br>
                                            </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
