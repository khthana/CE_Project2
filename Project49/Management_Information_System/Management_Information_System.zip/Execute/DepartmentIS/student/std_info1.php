<?
include("_CheckSession.php"); 
include ("_StartConnection.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

<style type="text/css">
<!--
.style1 {color: #999999}
-->
</style>
</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									include ("_sql_info1.php") ;
									?>
                                </div></td>
                              </tr>
                              <tr>
							  <? if ($_SESSION["username"] == $_SESSION["person_id"]) {?>
                                             <td align="left" valign="top"><div align="right"><a href="std_info1_edit.php">���</a><br>
								<? } else { ?>	
												 <td align="left" valign="top"><div align="right"><span class="style1">���</span><br>
								<? } ?>		 
                                    </div></td>
                              </tr>
							  
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=right width=96 rowSpan=3><div align="left"><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></div></TD>
                                                  <TD 
            height=24 colspan="2" align=middle><div align="left"><STRONG>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></div></TD>
                                                  <TD width=181 rowspan="4"><table width="53%" height="73" border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                                                      <tr> 
                                                        <td><div align="center"> 
                                                            <?
														$rootdir = "/AppServ/www/Departmentis/resource/pics/student";
														$a="$rootdir/". $person_id . ".gif";
														//print $a;
														if (file_exists($a)) { 
															print "<img src='../resource/pics/student/". $person_id . ".gif' >";
														}
														else {
															print "<img src='../resource/pics/student/default.gif' >";
														}														
														
														?>
                                                          </div></td>
                                                      </tr>
                                                    </table> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD 
            height=20 colspan="2" align=middle><div align="left"><STRONG>�͡�����§ҹ��ǹѡ�֡���������¹����ѵԹѡ�֡��</STRONG></div></TD>
                                                </TR>
                                                <TR> 
                                                  <TD height=20 colspan="2" align=middle><div align="left"><STRONG>�дѺ��ԭ�ҵ�� 
                                                      ��Шӻա���֡�� 
                                                      <input name="std_year" type="text" id="std_year" value="<?=$semester?>" size="4" maxlength="4" disabled>
                                                      </STRONG></div></TD>
                                                </TR>
                                                <TR> 
                                                  <TD width=96></TD>
                                                  <TD height=20 colspan="2" align=middle></TD>
                                                </TR>
                                                <TR> 
                                                  <TD></TD>
                                                  <TD align=middle height=20><div align="left"><strong>���ʹѡ�֡��</strong></div></TD>
                                                  <TD align=middle><div align="left"> 
                                                      <input name=student_id value="<?=$student_id?>" size=13  maxlength=8 disabled>
                                                    </div></TD>
                                                  <TD align=left>&nbsp;</TD>
                                                </TR>
                                                <TR> 
                                                  <TD width=96></TD>
                                                  <TD width=216 height=20 align=middle><div align="left"><strong>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ�</strong></div></TD>
                                                  <TD width=257 height=20 align=middle><div align="left"> 
                                                      <input name=citizen_id value="<?=$citizen_id?>" size=13 maxlength=13 disabled>
                                                    </div></TD>
                                                  <TD align=left width=181>&nbsp;</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                                                  <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                                                  <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;���ǡ�����ʵ��</TD>
                                                  <TD align=left width=300>&nbsp;���ǡ�������������</TD>
                                                  <TD align=left 
        width=300>&nbsp;���ǡ�������������</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp; <INPUT name=t_prename  type=radio  disabled
            id=t_prename value="���" <?=$flagpre_name1?>>
                                                    ��� / Mr. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="�ҧ���" disabled
            name=t_prename <?=$flagpre_name2?>>
                                                    �ҧ��� / Miss &nbsp;&nbsp; 
                                                    <INPUT id=t_prename 
            type=radio value="�ҧ" name=t_prename  disabled <?=$flagpre_name3?>>
                                                    �ҧ / Mrs. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="other" name=t_prename  disabled <?=$flagpre_name4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=t_prename2 title=������ value="<?=$pre_namestatus?>" 
            size=12  maxLength=16 disabled > </TD>
                                                  <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp; <INPUT name=gender 
            type=radio id=gender value="���"  disabled <?=$flaggender1?>>
                                                    ��� &nbsp;&nbsp; <INPUT 
            id=gender type=radio value="˭ԧ"
      name=gender  disabled <?=$flaggender2?>>
                                                    ˭ԧ</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20>&nbsp;<STRONG>����</STRONG>&nbsp;(������)</TD>
                                                  <TD align=left width=450 
            height=20>&nbsp;<STRONG>���ʡ��</STRONG>&nbsp;(������)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                                    <INPUT name=t_name value="<?=$th_name?>" size=32  
            maxLength=80 disabled></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT name=t_surname value="<?=$th_surname?>" size=32 maxLength=80 disabled></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20>&nbsp;<STRONG>����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                  <TD align=left width=450 
            height=20>&nbsp;<STRONG>���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                                    <INPUT name=e_name value="<?=$en_name?>" size=32 
            maxLength=80 disabled></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT name=e_surname value="<?=$en_surname?>" size=32  maxLength=80 disabled></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;<STRONG>����������Ѻ��ҹѡ�֡��</STRONG>&nbsp;(����Ѻ���˹�ҷ��)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#e8e8e8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left 
            width=750>&nbsp;<STRONG>�ͺ��ҹ��ǧ����Է�����</STRONG> &nbsp; <INPUT name=type1 type=radio 
            id=type value="��ѡ�ٵû���"  disabled <?=$exam_pattern1?>>
                                                    ��ѡ�ٵû��� &nbsp; <INPUT id=type type=radio value="�ç�������Ѵ"
            name=type1 disabled <?=$exam_pattern2?>>
                                                    �ç�������Ѵ &nbsp; <INPUT id=type  type=radio 
            value="��ѡ�ٵùҹҪҵ�" name=type1 disabled <?=$exam_pattern3?>>
                                                    ��ѡ�ٵùҹҪҵ� <BR> &nbsp;<STRONG>ʶҺѹ�Ѵ�ͺ�Ѵ���͡</STRONG><BR> 
                                                    &nbsp;<STRONG>��ѡ�ٵ� 4-5 
                                                    ��</STRONG> &nbsp; <INPUT id=type  type=radio value="��ѡ�ٵû���"
            name=type11  disabled <?=$flagexam1?>>
                                                    ��ѡ�ٵû���&nbsp; <INPUT id=type1  type=radio 
            value="�ǵ��" name=type11  disabled <?=$flagexam2?>>
                                                    �ǵ�� &nbsp; <INPUT id=type  type=radio 
            value="�Ҥ�����" name=type11 disabled  <?=$flagexam3?>>
                                                    �Ҥ�����&nbsp; <INPUT id=type1  type=radio 
            value="��Ƿ." name=type11  disabled <?=$flagexam4?>>
                                                    ��Ƿ. &nbsp; <INPUT id=type type=radio 
            value="��ǹ." name=type11  disabled <?=$flagexam5?>>
                                                    ��ǹ.&nbsp; <INPUT id=type11  type=radio 
            value="��ҧ��͡" name=type1  disabled <?=$flagexam6?>>
                                                    ��ҧ��͡ &nbsp; <INPUT id=type  
            type=radio value="���Ҵ���" name=type11  disabled <?=$flagexam7?>>
                                                    ���Ҵ���&nbsp; <INPUT id=type1 
             type=radio value="�ҹҪҵ�" name=type11  disabled <?=$flagexam8?>>
                                                    �ҹҪҵ� &nbsp; <INPUT id=type  type=radio value="�ع���¹���Է����ʵ��"
            name=type11 disabled  <?=$flagexam9?>>
                                                    �ع���¹���Է����ʵ�� <BR> 
                                                    &nbsp;<STRONG>��ѡ�ٵ� 1-3 
                                                    ��</STRONG> &nbsp; <INPUT id=type  type=radio value="������ͧ����"
            name=type11  disabled <?=$flagexam10?>>
                                                    ������ͧ���� &nbsp; <INPUT id=type  type=radio 
            value="������ͧ�����" name=type11  disabled <?=$flagexam11?>>
                                                    ������ͧ����� &nbsp; <INPUT id=type  
            type=radio value="�ǵ��" name=type11  disabled <?=$flagexam12?>>
                                                    �ǵ�� &nbsp; <INPUT id=type  
            type=radio value="���Ҵ���" name=type11 disabled  <?=$flagexam13?>>
                                                    ���Ҵ��� <BR> &nbsp; <INPUT id=type 
             type=radio value="�ѡ�֡�� / ����֡�����������ǵ�ҧ�ҵ�" name=type11  disabled <?=$flagexam14?>>
                                                    �ѡ�֡�� / ����֡�����������ǵ�ҧ�ҵ� 
                                                    &nbsp; <INPUT id=type  
            type=radio value="����֡��������������" name=type11 disabled <?=$flagexam15?>>
                                                    ����֡�������������� </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8 height=10></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 bgColor=#e8e8e8>&nbsp;<STRONG>�����˵� 
                                                    :</STRONG>&nbsp; �ҡ��ҡ�������ѧ��� 
                                                    ����͡�͡��� ʨ�.1 �Ҵ�س���ѵԷ���� 
                                                    ��Фس���ѵ�੾�е����С�Ȥ��͹ء�����á�û���ҹ�ҹ��äѴ���͡ 
                                                    �ؤ������֡�ҵ���ʶҺѹ�ش��֡��� 
                                                    �ͧ��ǧ����Է����� ��е����͡�˹�����ͧ�س���ѵԼ����Ѥ����ѡ�ٵ� 
                                                    ����ç��õ�ҧ� �ͧʶҺѹ� 
                                                    �ж١�Ѵ�Է��� �������Ѻ����繹ѡ�֡�ҢͧʶҺѹ�</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"><a href="std_info2.php">Next</a></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>  
                                    <div align="right"><br>
                                    </div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><div align="right"></div>
                                    <br></td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
