<?
include("_CheckSession.php");
include ("_StartConnection.php");
 ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									 include ("_sql_info5.php");
									 ?>
                                </div></td>
                              </tr>
                              <tr>
							  <? if ($_SESSION["username"] == $_SESSION["person_id"]) {?>
                                             <td align="left" valign="top"><div align="right"><a href="std_info1_edit.php">���</a><br>
								<? } else { ?>	
												 <td align="left" valign="top"><div align="right"><span class="style1">���</span><br>
								<? } ?>		 
                                    </div></td>
                                <!--<td align="left" valign="top"><div align="right">&nbsp;<a href="std_info5_edit.php">���</a></div></td> -->
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                    3 ����ѵԺԴ�-��ô� ��黡��ͧ 
                                                    ��м���ػ���д�ҹ����Թ</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ѵ���ô�</STRONG>&nbsp;(㹡óշ��Դ�-��ôҶ֧����� 
                                                    ���ѡ�֡�ҡ�͡��������ҷ���÷�Һ)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.10</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>������ô�</STRONG>&nbsp; 
                                                    <INPUT name=m_name id=name value="<?=$name_parent?>" size=24  
            maxLength=25 disabled> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                                                    <INPUT name=m_surname id=surname value="<?=$surname_parent?>" size=24  
            maxLength=25 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT name=m_alive  type=radio id=alive 
            value="Y"  disabled <?=$status_parent1?>>
                                                    �ժ��Ե���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                                                    <INPUT id=alive type=radio 
            value="N" name=m_alive disabled <?=$status_parent2?>>
                                                    �֧����� &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=m_age id=age value="<?=$age_parent?>" size=2  
            maxLength=2 disabled> &nbsp;�� </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.11</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=m_race type=radio id=radio4 
            value="��"  disabled <?=$race_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio4 
            type=radio value="�չ" name=m_race  disabled <?=$race_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio4 
             type=radio value="other" name=m_race  disabled <?=$race_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=m_race22 value="<?=$race_parentstatus?>" size=14 maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp; <INPUT name=m_citizen type=radio 
            id=radio5 value="��" disabled <?=$nationality_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio5  
            type=radio value="�չ" name=m_citizen  disabled <?=$nationality_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio5  
            type=radio value="other" name=m_citizen  disabled <?=$nationality_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=m_citizen22 value="<?=$nationality_parentstatus?>" size=14 
             maxLength=20 disabled ></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.12</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT name=m_religion  type=radio id=radio6 value="�ط�"   disabled <?=$religion_parent1?>>
                                                    �ط� &nbsp;&nbsp;2. 
                                                    <INPUT id=radio6  type=radio value="���ʵ�"
            name=m_religion   disabled <?=$religion_parent2?>>
                                                    ���ʵ� &nbsp;3. 
                                                    <INPUT id=radio6 type=radio 
            value="������" name=m_religion disabled  <?=$religion_parent3?>>
                                                    ������ &nbsp;&nbsp;4. 
                                                    <INPUT id=radio6 
            type=radio value="other"name=m_religion disabled  <?=$religion_parent4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=m_religion22 value="<?=$religion_parentstatus?>" size=16 maxLength=20 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.13</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                                                    <INPUT name=m_id id=id2 value="<?=$citizenid_parent?>" size=16 maxLength=13 disabled> 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.14</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                    <INPUT name=m_homeno value="<?=$number_parent?>" size=5 
            maxLength=10 disabled> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=m_moo value="<?=$group_parent?>" size=2  
            maxLength=2 disabled> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                    <INPUT name=m_soi value="<?=$lane_parent?>" size=16 
            maxLength=20 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                    <INPUT name=m_street value="<?=$road_parent?>" size=17 maxLength=20 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=m_tambon value="<?=$district_parent?>" size=21 maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                    <INPUT name=m_amphur value="<?=$region_parent?>" size=16 maxLength=20 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="m_province" id="m_province" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=m_zipcode value="<?=$postalcode_parent?>" size=10 
            maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=m_telno value="<?=$tel_parent?>" size=16 maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.15</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ��ô�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=m_academic type=radio id=radio7 value="��ж��֡��"  disabled <?=$educational_parent1?>>
                                                    ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio7 type=radio value="�Ѹ���֡��"  disabled
            name=m_academic <?=$educational_parent2?>>
                                                    �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio7 type=radio value="������ش��֡��"  disabled
            name=m_academic <?=$educational_parent3?>>
                                                    ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio7  type=radio value="�Ҫ���֡��"  disabled
            name=m_academic <?=$educational_parent4?>>
                                                    �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT 
            id=radio7  type=radio value="͹ػ�ԭ��������º���"  disabled
            name=m_academic <?=$educational_parent5?>>
                                                    ͹ػ�ԭ��������º��� <BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    6. 
                                                    <INPUT id=radio7  type=radio value="��ԭ�ҵ��"  disabled
            name=m_academic <?=$educational_parent6?>>
                                                    ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio7  type=radio value="��ԭ���"  disabled
            name=m_academic <?=$educational_parent7?>>
                                                    ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio7  type=radio value="��ԭ���͡"  disabled
            name=m_academic <?=$educational_parent8?>>
                                                    ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT id=radio7  type=radio value="������ز�"  disabled
            name=m_academic <?=$educational_parent9?>>
                                                    ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    10. 
                                                    <INPUT id=radio7  type=radio value="other"  disabled
            name=m_academic <?=$educational_parent10?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=m_academic2 value="<?=$educational_parentstatus?>" 
            size=16  maxLength=25 disabled> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.16</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ��ô�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=m_occupation  type=radio id=radio8 value="�Ѻ�Ҫ���"  disabled <?=$work_parent1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio8  type=radio value="��ѡ�ҹ�Ѱ����ˡԨ" 
            name=m_occupation disabled  <?=$work_parent2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio8   disabled
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=m_occupation  <?=$work_parent3?>>
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio8  type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��" 
            name=m_occupation   disabled <?=$work_parent4?>>
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=radio8  type=radio value="�١��ҧ��ǹ�Ҫ���"
            name=m_occupation  disabled  <?=$work_parent5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=radio8 
            type=radio value="�ɵá�/��ǻ����" name=m_occupation disabled  <?=$work_parent6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio8 type=radio 
            value="�Ѻ��ҧ" name=m_occupation disabled  <?=$work_parent7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio8 type=radio value="����Сͺ�Ҫվ"
            name=m_occupation   disabled <?=$work_parent8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=radio8 type=radio value="other" name=m_occupation disabled  <?=$work_parent9?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            name=m_occupation2 value="<?=$work_parentstatus?>" disabled  size=16 maxLength=25> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.17</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=m_workplace value="<?=$workplace_parent?>" size=24 maxLength=30 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="m_workprovince" id="m_workprovince" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $provincework_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=m_workzipcode value="<?=$postalcodework_parent?>" size=10 
            maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                                                    <INPUT name=m_worktelno value="<?=$telwork_parent?>" size=16 maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.18</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����������/��͹�ͧ��ô�</STRONG>&nbsp; 
                                                    1. 
                                                    <INPUT  name=m_earn type=radio id=radio9 value="N" disabled <?=$salary_parent1?>>
                                                    ���������� &nbsp;&nbsp; 2. 
                                                    <INPUT id=radio9 type=radio value="Y"  disabled
            name=m_earn <?=$salary_parent2?>>
                                                    �� (�к�) �����&nbsp; <INPUT name=m_salary value="<?=$salary_parentstatus?>" size=7 maxLength=7 disabled> 
                                                    &nbsp;�ҷ/��͹ </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD height=10><div align="right"><a href="std_info4.php">Back</a> 
                                              | <a href="std_info6.php">Next</a><br>
                                            </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
