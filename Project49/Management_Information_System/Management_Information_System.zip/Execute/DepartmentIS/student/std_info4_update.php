<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");

				include("_std_info4_include.php");

		
				$sql = "UPDATE parent
							set 
							
							name_parent = $f_name,
							surname_parent = $f_surname,
							status_parent = $f_alive,
							age_parent = $f_age,
							race_parent = $f_race,
							nationality_parent = $f_citizen,
							religion_parent = $f_religion,
							citizenid_parent = $f_id,
							number_parent = $f_homeno,
							group_parent = $f_moo,
							lane_parent = $f_soi,
							road_parent = $f_street,
							district_parent = $f_tambon,
							region_parent = $f_amphur,
							province_parent = $f_province,
							postalcode_parent = $f_zipcode,
							tel_parent = $f_telno,
							educational_parent = $f_academic,
							work_parent = $f_occupation,
							workplace_parent = $f_workplace,
							provincework_parent = $f_workprovince,
							postalcodework_parent = $f_workzipcode,
							telwork_parent = $f_worktelno,
							salary_parent = $f_iswork1							
						
						
							WHERE student_id = '$person_id'  and ptype = '0'";
							//print $sql;
						
			if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: std_info4.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			
			

?>
