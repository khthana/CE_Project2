<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									 include ("_sql_info4.php");									
									?>
                                </div></td>
                              </tr>
                              <tr>
							  <? if ($_SESSION["username"] == $_SESSION["person_id"]) {?>
                                             <td align="left" valign="top"><div align="right"><a href="std_info1_edit.php">���</a><br>
								<? } else { ?>	
												 <td align="left" valign="top"><div align="right"><span class="style1">���</span><br>
								<? } ?>		 
                                    </div></td>
                                <!--<td align="left" valign="top"><div align="right"><a href="std_info4_edit.php">&nbsp;���</a></div></td> -->
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                    3 ����ѵԺԴ�-��ô� ��黡��ͧ 
                                                    ��м���ػ���д�ҹ����Թ</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ѵԺԴ�</STRONG>&nbsp;(㹡óշ��Դ�-��ôҶ֧����� 
                                                    ���ѡ�֡�ҡ�͡��������ҷ���÷�Һ)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.1</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>���ͺԴ�</STRONG>&nbsp; 
                                                    <INPUT name=f_name id=f_name value="<?=$name_parent?>" size=24 
            maxLength=25 disabled> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                                                    <INPUT name=f_surname id=f_surname value="<?=$surname_parent?>" size=24  
            maxLength=25 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT name=f_alive  type=radio id=f_alive 
            value="Y"  disabled <?=$status_parent1?>>
                                                    �ժ��Ե���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                                                    <INPUT id=f_alive  type=radio 
            value="N" name=f_alive disabled <?=$status_parent2?>>
                                                    �֧����� &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=f_age id=f_age value="<?=$age_parent?>" size=2 
            maxLength=2 disabled > &nbsp;�� </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.2</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=f_race type=radio id=radio 
            value="��"  disabled <?=$race_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio 
             type=radio value="�չ" name=f_race disabled <?=$race_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio 
             type=radio value="other" name=f_race  disabled <?=$race_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT maxLength=20 size=14 name=f_race22 disabled value="<?=$race_parentstatus?>"> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp; <INPUT name=f_citizen type=radio id=radio2  disabled
            value="��" <?=$nationality_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT 
            id=radio2 type=radio value="�չ" name=f_citizen disabled <?=$nationality_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio2 
            type=radio value="other" name=f_citizen  disabled <?=$nationality_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            maxLength=20 size=14 name=f_citizen22  disabled value="<?=$nationality_parentstatus?>"></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.3</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT name=f_religion type=radio id=radio3 value="�ط�"  disabled <?=$religion_parent1?>>
                                                    �ط� &nbsp;&nbsp;2. 
                                                    <INPUT id=radio3 type=radio value="���ʵ�"
            name=f_religion  disabled <?=$religion_parent2?>>
                                                    ���ʵ� &nbsp;3. 
                                                    <INPUT id=radio3 type=radio 
            value="������" name=f_religion disabled <?=$religion_parent3?>>
                                                    ������ &nbsp;&nbsp;4. 
                                                    <INPUT id=radio3 
             type=radio value="other" name=f_religion  disabled <?=$religion_parent4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT maxLength=20 size=16 name=f_religion22 disabled value="<?=$religion_parentstatus?>" >  
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.4</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                                                    <INPUT 
            id=id maxLength=13 size=16 name=f_id  disabled value="<?=$citizenid_parent?>"> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.5</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                    <INPUT name=f_homeno value="<?=$number_parent?>" size=5 
            maxLength=10 disabled> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=f_moo value="<?=$group_parent?>" size=2 
            maxLength=2 disabled> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                    <INPUT name=f_soi value="<?=$lane_parent?>" size=16 
             maxLength=20 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                    <INPUT name=f_street value="<?=$road_parent?>" size=17 maxLength=20 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=f_tambon disabled value="<?=$district_parent?>" size=21 maxLength=20> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                    <INPUT name=f_amphur  disabled value="<?=$region_parent?>" size=16 
            maxLength=20>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="f_province" id="f_province" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=f_zipcode value="<?=$postalcode_parent?>" size=10 
            maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=f_telno value="<?=$tel_parent?>" size=16 maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.6</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ�Դ�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=f_academic type=radio id=academic value="��ж��֡��"  disabled <?=$educational_parent1?>>
                                                    ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=academic type=radio value="�Ѹ���֡��" disabled
            name=f_academic <?=$educational_parent2?>>
                                                    �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=academic type=radio value="������ش��֡��"  disabled
            name=f_academic <?=$educational_parent3?>>
                                                    ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=academic type=radio value="�Ҫ���֡��"  disabled
            name=f_academic <?=$educational_parent4?>>
                                                    �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT 
            id=academic type=radio value="͹ػ�ԭ��������º���"  disabled
            name=f_academic <?=$educational_parent5?>>
                                                    ͹ػ�ԭ��������º��� <BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    6. 
                                                    <INPUT id=academic type=radio value="��ԭ�ҵ��"  disabled
            name=f_academic <?=$educational_parent6?>>
                                                    ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=academic type=radio value="��ԭ���" disabled
            name=f_academic <?=$educational_parent7?>>
                                                    ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=academic type=radio value="��ԭ���͡"  disabled
            name=f_academic <?=$educational_parent8?>>
                                                    ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT id=academic type=radio value="������ز�"  disabled
            name=f_academic <?=$educational_parent9?>>
                                                    ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    10. 
                                                    <INPUT id=academic type=radio value="other" disabled
            name=f_academic <?=$educational_parent10?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT maxLength=25  disabled
            size=16 name=f_academic2 value="<?=$educational_parentstatus?>"> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.7</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ�Դ�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=f_occupation type=radio id=occupation value="�Ѻ�Ҫ���" disabled <?=$work_parent1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=occupation type=radio value="��ѡ�ҹ�Ѱ����ˡԨ" disabled
            name=f_occupation <?=$work_parent2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=occupation   disabled
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=f_occupation <?=$work_parent3?>>
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=occupation type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��" disabled
            name=f_occupation <?=$work_parent4?>>
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=occupation type=radio value="�١��ҧ��ǹ�Ҫ���"  disabled
            name=f_occupation <?=$work_parent5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=occupation  disabled
            type=radio value="�ɵá�/��ǻ����" name=f_occupation <?=$work_parent6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=occupation type=radio  disabled
            value="�Ѻ��ҧ" name=f_occupation <?=$work_parent7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=occupation type=radio value="����Сͺ�Ҫվ"  disabled
            name=f_occupation <?=$work_parent8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=occupation type=radio value="other" name=f_occupation  disabled <?=$work_parent9?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT maxLength=25 size=16  disabled
            name=f_occupation2 value="<?=$work_parentstatus?>"> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.8</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=f_workplace value="<?=$workplace_parent?>" size=24 maxLength=30 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="f_workprovince" id="f_workprovince" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $provincework_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=f_workzipcode value="<?=$postalcodework_parent?>" size=10 
            maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                                                    <INPUT name=f_worktelno value="<?=$telwork_parent?>" size=16 maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.9</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����������/��͹�ͧ�Դ�</STRONG>&nbsp; 
                                                    1. 
                                                    <INPUT name=f_earn type=radio id=earn value="N" disabled <?=$salary_parent1?>>
                                                    ���������� &nbsp;&nbsp; 2. 
                                                    <INPUT id=earn type=radio value="Y" disabled
            name=f_earn <?=$salary_parent2?>>
                                                    �� (�к�) �����&nbsp; <INPUT maxLength=7 size=7 name=f_salary2  disabled value="<?=$salary_parentstatus?>"> 
                                                    &nbsp;�ҷ/��͹ </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD height=10><div align="right"><a href="std_info3.php">Back</a> 
                                              | <a href="std_info5.php">Next</a><br>
                                            </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
