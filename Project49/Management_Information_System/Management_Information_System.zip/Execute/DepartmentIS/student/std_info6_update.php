<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");

				include("_std_info6_include.php");

				$sql1 = "select * from parent where student_id = '$person_id'  and ptype = '2'";
				$table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
				
				if($row = mysql_fetch_array($table1))
					$sp = 1; //���Ǣ����Ţͧ��黡��ͧ
				else
					$sp = 0; //������Ǣ����Ţͧ��黡��ͧ
				
/************************************************************************************************************************/
				if($sp == 0 and $p == "other"){ // ������Ǣ����Ţͧ��黡��ͧ ��� ��黡��ͧ�� ����
					
					$sql2 ="
					insert into parent values('$person_id',$pparent_status,$p_relationship,$p_name,$p_surname,null,
					$p_age,$p_race,$p_citizen,$p_religion,
					$p_id,$p_homeno,$p_moo,$p_soi,$p_street,$p_tambon,$p_amphur,	$p_province,
					$p_zipcode,$p_telno,$p_academic,$p_occupation,$p_workplace,$p_workprovince,
					$p_workzipcode,$p_worktelno,$p_iswork1)
					";
				//	print $sql2;
					if ( mysql_query($sql2,$conn) )  // insert ������ �����
					 {							
							$sql3 = "update student 	set
										s_parent = $parent_person
										where student_id = '$person_id'";
						 if ( mysql_query($sql3,$conn) )
						 {						
							header("Location: std_info6.php");		
							//print "ok";
						}
						else{
							print "�ջѭ��㹡�� update <br>" . $sql3;						
					}
					 }
					else // insert ������ ��������
					{
						print "�ջѭ��㹡�� �ѹ�֡ <br>" . $sql3;						
					}
				}
/************************************************************************************************************************/
				else if ($sp == 0 and $p != "other") { // ������Ǣ����Ţͧ��黡��ͧ ��� ��黡��ͧ����� ����
					  
						$sql3 = "update student 	set
										s_parent = $parent_person
										where student_id = '$person_id'";		
					 
						 if ( mysql_query($sql3,$conn) )
						 {						
							header("Location: std_info6.php");
						}
						else{
							print "�ջѭ��㹡�� update <br>" . $sql3;
						}						
						
				}
/************************************************************************************************************************/
				else if ($sp == 1 and $p != "other") {// ���Ǣ����Ţͧ��黡��ͧ ��� ��黡��ͧ����� ����

						$sql2 = "delete
						from parent
						where student_id = '$person_id'  and ptype = '2'";
						if ( mysql_query($sql2,$conn) ) {							
							$sql3 = "update student 	set
											s_parent = $parent_person
											where student_id = '$person_id'";
							 if ( mysql_query($sql3,$conn) )
							{						
									header("Location: std_info6.php");
							}
							else{
									print "�ջѭ��㹡�� update <br>" . $sql3;
							}							
						}
						else	{
						print "�ջѭ��㹡�� ź <br>" . $sql2;
					}
				}
/************************************************************************************************************************/
				else {  // ���Ǣ����Ţͧ��黡��ͧ ��� ��黡��ͧ�� ����


				
/************************************************************************************************************************/
	
				$sql = "UPDATE parent
							set 
							
							name_parent = $p_name,
							surname_parent = $p_surname,
							status_parent = null,
							age_parent = $p_age,
							relationship= $p_relationship,
							race_parent = $p_race,
							nationality_parent = $p_citizen,
							religion_parent = $p_religion,
							citizenid_parent = $p_id,
							number_parent = $p_homeno,
							group_parent = $p_moo,
							lane_parent = $p_soi,
							road_parent = $p_street,
							district_parent = $p_tambon,
							region_parent = $p_amphur,
							province_parent = $p_province,
							postalcode_parent = $p_zipcode,
							tel_parent = $p_telno,
							educational_parent = $p_academic,
							work_parent = $p_occupation,
							workplace_parent = $p_workplace,
							provincework_parent = $p_workprovince,
							postalcodework_parent = $p_workzipcode,
							telwork_parent = $p_worktelno,
							salary_parent = $p_iswork1							
						
						
							WHERE student_id = '$person_id'  and ptype = '2'";
							//print $sql;
						
			if( mysql_query($sql,$conn) )	{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				//header("Location: std_info6.php");
					$sql3 = "update student 	set
										s_parent = $parent_person
										where student_id = '$person_id'";
						 if (!( mysql_query($sql3,$conn) ))  {
							print "�ջѭ��㹡�� update <br>" . $sql3;
						}
						else{
							header("Location: std_info6.php");
						}
			}
			else {
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}				
		
	}
?>
