<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");

				include("_std_info5_include.php");

		
				$sql = "UPDATE parent
							set 
							
							name_parent = $m_name,
							surname_parent = $m_surname,
							status_parent = $m_alive,
							age_parent = $m_age,
							race_parent = $m_race,
							nationality_parent = $m_citizen,
							religion_parent = $m_religion,
							citizenid_parent = $m_id,
							number_parent = $m_homeno,
							group_parent = $m_moo,
							lane_parent = $m_soi,
							road_parent = $m_street,
							district_parent = $m_tambon,
							region_parent = $m_amphur,
							province_parent = $m_province,
							postalcode_parent = $m_zipcode,
							tel_parent = $m_telno,
							educational_parent = $m_academic,
							work_parent = $m_occupation,
							workplace_parent = $m_workplace,
							provincework_parent = $m_workprovince,
							postalcodework_parent = $m_workzipcode,
							telwork_parent = $m_worktelno,
							salary_parent = $m_iswork1							
						
						
							WHERE student_id = '$person_id'  and ptype = '1'";
							//$person_id ����Ҩҡ session

							//print $sql;
						
			if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: std_info5.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			
			

?>
