<?
	include ("_StartConnection.php");
	//�Ѻ��� username ��� password �ҡ form
	$username = $_POST["username"];	
	$password = $_POST["password"];	

	//print $username .$password;
	$sql ="SELECT * FROM student WHERE username = '".$username."'  AND password = password('".$password."') AND faculty_id='01' AND dept_id = '05' and std_status ='Y' "; 	
	


	$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
	if($row=mysql_fetch_array($table))
	{
		
		session_register( "username");  //ŧ����¹ session �����  username
		session_register( "password"); //ŧ����¹ session �����  password
		session_register( "personname");
		session_register( "personlastname");
		session_register( "type");
		session_register( "person_id");

		$_SESSION["username"] =  $row[username];
		$_SESSION["password"] =  $row[password];
		$_SESSION["personname"] =  $row[th_name];
		$_SESSION["personlastname"] =  $row[th_surname];
		$_SESSION["type"] = "student";
		//$_SESSION["type"] =  $row[typedegree];
		$_SESSION["person_id"] =  $row[student_id];

		header("Location: std_main.php");		
	}
	else
	{
		//����׹�ѹ��ǵ� �������
		header("Location: std_fail.php");
	}

	include ("_EndConnection.php");
?>