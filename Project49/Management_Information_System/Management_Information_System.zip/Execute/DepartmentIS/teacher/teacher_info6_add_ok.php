<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//���ͧҹ���͡�ý֡ͺ��
if ($training_name == ""){
		$training_name = "null";
}
else {
		$training_name= "'".$training_name."'";
}

//˹��§ҹ
if ($training_place == ""){
		$training_place = "null";
}
else {
		$training_place= "'".$training_place."'";
}
//�ѹ���
if ($tdate == ""){
		$tdate = "null";
}
else {
		$tdate= "'".$tdate."'";
}

// �����˵�
if ($training_comm == ""){
		$training_comm = "null";
}
else {
		$training_comm= "'".$training_comm."'";
}

$sql = "insert into training_person values( '',$training_name,$training_place,$tdate,$training_comm,'$person_id')";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info6.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>