<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

<style type="text/css">
<!--
.style13 {font-weight: bold}
.style14 {font-weight: bold}
.style15 {font-weight: bold}
.style16 {font-weight: bold}
.style17 {font-weight: bold}
.style18 {font-weight: bold}
-->
</style>
</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� 
        <?=$position ?>
        <?=$personname ?>
        &nbsp; 
        <?=$personlastname ?>
      </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <? include ("_menu.php") ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE width=750 height="30" border=1 cellPadding=0 cellSpacing=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><div align="center"><STRONG>���ҧ�����šԨ�����ҧ�Ԫҡ��</STRONG></div></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD valign="top" bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=30 colspan="4" align=left><div align="center"></div>
                                                    <div align="center"></div>
                                                    <div align="center"></div>
                                                    <div align="center"><strong>���͢����šԨ�����ҧ�Ԫҡ��</strong></div></TD>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=20 colspan="4" align=left><table width="750" height="0" border="1">
                                                      <tr> 
                                                        <td width="36" height="24" class="style13"><div align="center">�ӴѺ</div></td>
                                                        <td width="200"><strong>����</strong></td>
                                                        <td width="235"><strong>˹��§ҹ</strong></td>
                                                        <td width="75"><strong>�ѹ���</strong></td>
                                                        <td width="170"><strong>�����˵�</strong></td>
                                                      </tr>
                                                      <?
													  $count =1;
													  $sql = "select * from activity_person where person_id = '$person_id' ";
													//  print $sql;
													  $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
			while ($row = mysql_fetch_array($table))
			{
					$activity_name = $row[activity_name];
					$activity_place = $row[activity_place];
					$activity_date = $row[activity_date];
					$activity_comm = $row[activity_comm];
					
												  
													  ?>
                                                      <tr> 
                                                        <td height="32" class="style13"> 
                                                          <?=$count?>
                                                        </td>
                                                        <td> 
                                                          <?=$activity_name?>
                                                        </td>
                                                        <td> 
                                                          <?=$activity_place?>
                                                        </td>
                                                        <td> 
                                                          <?=$activity_date?>
                                                        </td>
                                                        <td> 
                                                          <?=$activity_comm?>
                                                        </td>
                                                      </tr>
                                                      <?
													  ++$count;
									}				  
													  
													  ?>
                                                    </table></TD>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 colspan="4" align=left>&nbsp;</TD>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=20 colspan="4" align=left>&nbsp;</TD>
                                                <TR bordercolor="2"> 
                                                  <TD height=9 colspan="4" align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD width="310" height=20>&nbsp;</TD>
                                                  <TD width="56" height=20>&nbsp;</TD>
                                                  <TD width="103" height=20>&nbsp;</TD>
                                                  <TD width="275" height=20>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left><p>&nbsp;</p>
                                                    <p>&nbsp;</p>
                                                    <p><br>
                                                    </p></TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE>                                            
                                            <div align="right"><a href="teacher_info7.php">Back</a>&nbsp;&nbsp; </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
