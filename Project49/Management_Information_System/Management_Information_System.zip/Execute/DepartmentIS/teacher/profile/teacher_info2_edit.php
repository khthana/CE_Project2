<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� 
        <?=$position ?>
        <?=$personname ?>
        &nbsp;
        <?=$personlastname ?>
      </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <? 
									  include ("_menu.php") ;
									   include ("_sql_info2.php");
									  ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><div align="center"><STRONG>����ѵԤ�ͺ����</STRONG></div></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left height=20><strong>����ѵԺԴ�</strong></TD>
                                                </TR>
                                                <TR> 
                                                  <TD height=20>&nbsp;<strong>&nbsp;����</strong> 
                                                    <input name="father_name" type="text" size="32" maxlength="80" value="<?=$father_name?>"> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>���ʡ��</strong> 
                                                    <input name="father_surname" type="text" size="32" maxlength="80" value="<?=$father_surname?>">  
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>&nbsp;&nbsp; 
                                                    ���</strong>� 
                                                    <input name="father_age" type="text" size="5" maxlength="10" value="<?=$father_age?>"></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left height=20>&nbsp;&nbsp;<STRONG>�Ҫվ�ͧ�Դ�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=f_occupation  type=radio id=radio14 value="�Ѻ�Ҫ���"  <?=$flagf_occupation1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio14  type=radio value="��ѡ�ҹ�Ѱ����ˡԨ" 
            name=f_occupation  <?=$flagf_occupation2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp; 
                                                    &nbsp;&nbsp;&nbsp; 3. 
                                                    <INPUT id=radio14  
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=f_occupation  <?=$flagf_occupation3?> >
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio14  type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��"
            name=f_occupation <?=$flagf_occupation4?> >
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=radio14  type=radio value="�١��ҧ��ǹ�Ҫ���"
            name=f_occupation  <?=$flagf_occupation5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=radio14 
             type=radio value="�ɵá�/��ǻ����" name=f_occupation  <?=$flagf_occupation6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio14  type=radio 
            value="�Ѻ��ҧ" name=f_occupation  <?=$flagf_occupation7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio14  type=radio value="����Сͺ�Ҫվ" 
            name=f_occupation  <?=$flagf_occupation8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=radio14  type=radio value="other" name=f_occupation <?=$flagf_occupation9?> >
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            name=f_occupation2 size=16  maxLength=25 value ="<?=$f_occupationstatus?>"> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20> 
                                                    &nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp; <INPUT name=f_citizen type=radio id=citizen value="��" <?=$flagf_citizen1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=citizen  
            type=radio value="�չ" name=f_citizen <?=$flagf_citizen2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=citizen  
            type=radio value="other" name=f_citizen <?=$flagf_citizen3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
             maxLength=20 size=14 name=f_citizen2  value="<?=$f_citizenstatus?>"></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;&nbsp;<strong>ʶҹ���ӧҹ&nbsp;&nbsp;&nbsp;</strong> 
                                                    <input name="m_workplace" type="text" size="50" maxlength="100" value="<?=$father_workplace?>"> 
                                                    &nbsp;&nbsp;&nbsp;<strong>&nbsp;�������Ѿ��Դ���</strong>&nbsp;&nbsp; 
                                                    <input name="m_telephone" type="textfield" value="<?=$father_phone?>"></TD>
                                                <TR> 
                                                  <TD align=left 
            height=20>&nbsp;</TD>
                                                <TR> 
                                                  <TD align=left height=20><strong>����ѵ���ô�</strong></TD>
                                                </TR>
                                                <TR> 
                                                  <TD height=20>&nbsp;<strong>&nbsp;����</strong> 
                                                    <input name="mother_name" type="text" size="32" maxlength="80" value="<?=$mother_name?>"> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>���ʡ��</strong> 
                                                    <input name="mother_surname" type="text" size="32" maxlength="80"  value="<?=$mother_surname?>"> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>&nbsp;&nbsp; 
                                                    ���</strong>� 
                                                    <input name="mother_age" type="text" size="5" maxlength="10"  value="<?=$mother_age?>"></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left height=20>&nbsp;&nbsp;<STRONG>�Ҫվ�ͧ��ô�</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=m_occupation  type=radio id=radio14 value="�Ѻ�Ҫ���" <?=$flagf_occupation1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio14  type=radio value="��ѡ�ҹ�Ѱ����ˡԨ"
            name=m_occupation <?=$flagf_occupation2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp; 
                                                    &nbsp;&nbsp;&nbsp; 3. 
                                                    <INPUT id=radio14  
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=m_occupation <?=$flagf_occupation3?>>
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio14  type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��" 
            name=m_occupation <?=$flagf_occupation4?>>
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=radio14  type=radio value="�١��ҧ��ǹ�Ҫ���" 
            name=m_occupation <?=$flagf_occupation5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=radio14 
             type=radio value="�ɵá�/��ǻ����" name=m_occupation <?=$flagf_occupation6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio14  type=radio 
            value="�Ѻ��ҧ" name=m_occupation <?=$flagf_occupation7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio14  type=radio value="����Сͺ�Ҫվ"
            name=m_occupation <?=$flagf_occupation8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=radio14  type=radio value="other" name=m_occupation <?=$flagf_occupation9?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            name=m_occupation2 size=16  maxLength=25 value="<?=$f_occupationstatus?>"> </TD>
                                                <TR> 
                                                  <TD align=left height=20>&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp; <INPUT name=citizen type=radio id=citizen value="��" <?=$flagf_citizen1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=citizen  
            type=radio value="�չ" name=m_citizen <?=$flagf_citizen2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=citizen  
            type=radio value="other" name=m_citizen <?=$flagf_citizen3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
             maxLength=20 size=14 name=m_citizen2 value="<?=$f_citizenstatus?>"></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left height=20>&nbsp;&nbsp;<strong>ʶҹ���ӧҹ&nbsp;&nbsp;&nbsp;</strong> 
                                                    <input name="m_workplace" type="text" size="50" maxlength="100" value="<?=$mother_workplace?>"> 
                                                    &nbsp;&nbsp;&nbsp;<strong>&nbsp;�������Ѿ��Դ���</strong>&nbsp;&nbsp; 
                                                    <input name="m_telephone" type="textfield" value="<?=$mother_phone?>"></TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;</TD>
                                                <TR> 
                                                  <TD align=left 
            height=20>&nbsp; </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp; </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;</TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;</TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=left height=20>&nbsp;</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"><a href="teacher_info1.php">Back</a> 
                                              | <a href="teacher_info3.php">Next</a></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
