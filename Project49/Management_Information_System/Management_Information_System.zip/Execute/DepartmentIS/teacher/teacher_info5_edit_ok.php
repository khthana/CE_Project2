<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//�����ҧ���
if ($reward_name == ""){
		$reward_name = "null";
}
else {
		$reward_name= "'".$reward_name."'";
}

//˹��§ҹ
if ($reward_from == ""){
		$reward_from = "null";
}
else {
		$reward_from= "'".$reward_from."'";
}


//�ѹ���
if ($tdate == ""){
		$tdate = "null";
}
else {
		$tdate= "'".$tdate."'";
}

// �����˵�
if ($reward_comm == ""){
		$reward_comm = "null";
}
else {
		$reward_comm= "'".$reward_comm."'";
}


$sql = "update reward_person
set
reward_name = $reward_name,
reward_from = $reward_from,
reward_date = $tdate,
reward_comm =$reward_comm
where reward_id = $reward_id ";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info5.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>