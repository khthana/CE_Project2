<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� 
        <?=$position ?>
        <?=$personname ?>
        &nbsp;
        <?=$personlastname ?>
        &nbsp; </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <? include ("_menu.php") ;
									  		include ("_sql_info3.php");
									  ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="right"><a href="teacher_info3_edit.php">&nbsp;</a></div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
								
								
								
								
								
								<form name="form1" method="post" action="teacher_info3_b_ok.php">
								<TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><div align="center"><STRONG>����ѵԡ���֡��</STRONG></div></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD valign="top" bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
                                                <TBODY>
                                                  <TR> 
                                                    <TD height=20>&nbsp;<strong>&nbsp;</strong><strong>�дѺ��ԭ�ҵ�� 
                                                      </strong></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left width=750 height=20> 
                                                      <strong>&nbsp;&nbsp;ʶҺѹ��診����֡��&nbsp; 
                                                      <input name="univ_name1" type="text" size="50" maxlength="100"   value="<?=$univ_name1?>">
                                                      </strong></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left width=750 height=20><strong>&nbsp;&nbsp;����ȷ�診����֡��&nbsp; 
                                                      <input type="text" name="country_name1"  value="<?=$country_name1?>">
                                                      </strong></TD>
                                                  <TR> 
                                                    <TD align=left 
            height=20><strong>&nbsp;&nbsp;�زԷ�����Ѻ&nbsp; 
                                                      <input type="text" name="senior_degree1"  value="<?=$senior_degree1?>">
                                                      &nbsp;&nbsp;�Ң��Ԫ��͡&nbsp; 
                                                      <input type="text" name="knowledge1"  value="<?=$knowledge1?>">
                                                      </strong></TD>
                                                  <TR> 
                                                    <TD align=left height=20><strong>&nbsp;&nbsp;�շ�診����֡��&nbsp; 
                                                      <input type="text" name="year_congrate1"  value="<?=$year_congrate1?>">
                                                      &nbsp;��ṹ�����&nbsp; 
                                                      <input type="text" name="grade1"  value="<?=$grade1?>">
                                                      </strong></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD height=20><strong>&nbsp;&nbsp;���ͻ�ԭ�ҹԾ��� 
                                                      <input type="text" name="thesis1"   value="<?=$thesis1?>">
                                                      </strong></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD height=20><div align="right"><strong>&nbsp;&nbsp; 
                                                        <input type="submit" name="Submit" value="�׹�ѹ�������¹�ŧ">
                                                        </strong></div></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left height=20><strong>&nbsp;</strong></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left height=20>&nbsp; 
                                                    </TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD height=20>&nbsp;</TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD align=left height=20>&nbsp;</TD>
                                                  </TR>
                                                </TBODY>
                                              </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
									
									     </form>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
