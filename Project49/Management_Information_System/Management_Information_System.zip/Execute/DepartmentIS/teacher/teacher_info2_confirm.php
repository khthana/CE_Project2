<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");

//����
if($father_name =="") {
		$father_name = "null";
}
else {
		$father_name= "'".$father_name."'";
}

//���ʡ��
if($father_surname =="") {
		$father_surname = "null";
}
else {
		$father_surname= "'".$father_surname."'";
}

//����
if($father_age =="") {
		$father_age = "null";
}
else {
		$father_age= "'".$father_age."'";
}


//�Ҫվ
 if($f_occupation == 'other') {
			$f_occupation = $f_occupation2;
			$f_occupation = "'".$f_occupation."'";							
	}
	else{
			$f_occupation = "'".$f_occupation."'";
	}

//�ѭ�ҵ�
 if($f_citizen == 'other') {
			$f_citizen = $f_citizen2;
			$f_citizen = "'".$f_citizen."'";							
	}
	else{
			$f_citizen = "'".$f_citizen."'";
	}

//ʶҹ���ӧҹ
if($f_workplace =="") {
		$f_workplace = "null";
}
else {
		$f_workplace= "'".$f_workplace."'";
}

//�������Ѿ��Դ���
if($f_telephone =="") {
		$f_telephone = "null";
}
else {
		$f_telephone= "'".$f_telephone."'";
}

///////////
//����
if($mother_name =="") {
		$mother_name = "null";
}
else {
		$mother_name= "'".$mother_name."'";
}

//���ʡ��
if($mother_surname =="") {
		$mother_surname = "null";
}
else {
		$mother_surname= "'".$mother_surname."'";
}

//����
if($mother_age =="") {
		$mother_age = "null";
}
else {
		$mother_age= "'".$mother_age."'";
}


//�Ҫվ
 if($m_occupation == 'other') {
			$m_occupation = $m_occupation2;
			$m_occupation = "'".$m_occupation."'";							
	}
	else{
			$m_occupation = "'".$m_occupation."'";
	}


//�ѭ�ҵ�
 if($m_citizen == 'other') {
			$m_citizen = $m_citizen2;
			$m_citizen = "'".$m_citizen."'";							
	}
	else{
			$m_citizen = "'".$m_citizen."'";
	}

//ʶҹ���ӧҹ
if($m_workplace =="") {
		$m_workplace = "null";
}
else {
		$m_workplace= "'".$m_workplace."'";
}

//�������Ѿ��Դ���
if($m_telephone =="") {
		$m_telephone = "null";
}
else {
		$m_telephone= "'".$m_telephone."'";
}






$sql = "update  person
set

father_name = $father_name,
father_sname= $father_surname,
father_age= $father_age,
father_work= $f_occupation,
father_nationality= $f_citizen,
father_workplace= $f_workplace,
father_phone= $f_telephone,

mother_name= $mother_name,
mother_sname= $mother_surname,
mother_age= $mother_age,
mother_work= $m_occupation,
mother_nationality= $m_citizen,
mother_workplace= $m_workplace,
mother_phone= $m_telephone

where person_id = '$person_id' ";
if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info2.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			



?>
