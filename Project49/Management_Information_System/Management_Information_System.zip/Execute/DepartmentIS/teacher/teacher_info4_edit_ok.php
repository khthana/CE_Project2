<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//����
if ($name == ""){
		$name = "null";
}
else {
		$name= "'".$name."'";
}

//����
if ($age == ""){
		$age = "null";
}
else {
		$age= "'".$age."'";
}

//��������ѹ��
if ($relation == ""){
		$relation = "null";
}
else {
		$relation= "'".$relation."'";
}

//�Ҫվ
if ($work == ""){
		$work = "null";
}
else {
		$work= "'".$work."'";
}


//$sql = "insert into relations_person values( '',$name,$age,$relation,$work,'$person_id')";

$sql = "update relations_person
set
relations_name = $name,
relation_age = $age,
relation_status = $relation,
relation_work = $work
where relations_id = $relations_id";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info4.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>