<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//�����ҧ���
if ($reward_name == ""){
		$reward_name = "null";
}
else {
		$reward_name= "'".$reward_name."'";
}

//˹��§ҹ
if ($reward_from == ""){
		$reward_from = "null";
}
else {
		$reward_from= "'".$reward_from."'";
}


//�ѹ���
if ($tdate == ""){
		$tdate = "null";
}
else {
		$tdate= "'".$tdate."'";
}

// �����˵�
if ($reward_comm == ""){
		$reward_comm = "null";
}
else {
		$reward_comm= "'".$reward_comm."'";
}

$sql = "insert into reward_person values( '',$reward_name,$reward_from,$tdate,$reward_comm,'$person_id')";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info5.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>