<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="center" background="resource/img/bar_c.gif" scope="col"> 
      <img src="resource/img/bullet-blue.gif" width="9" height="13"> <a href="index.php">˹����ѡ</a> 
      <img src="resource/img/bullet-blue.gif" width="9" height="13"> <a href="course/course_index.php">��ѡ�ٵ�</a> 
      <img src="resource/img/bullet-blue.gif" width="9" height="13"> <a href="course/subject_index.php">��������´�Ԫ�</a> 
      <img src="resource/img/bullet-blue.gif" width="9" height="13"> <a href="course/plan_index.php">Ἱ������¹</a> 
    </td>
    <td width="10" background="r" scope="col"><img src="resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top> <table cellspacing=2 cellpadding=1 width="100%" 
border=0>
                                <tr> 
                                  <td height="18" valign=top>&nbsp;</td>
                                  <td height="18" align="left" valign=top>&nbsp;</td>
                                  <td align="left" valign=top>&nbsp;</td>
                                </tr>
                                <tbody>
                                  <tr> 
                                    <td width=57 height="25" valign=top>&nbsp;</td>
                                    <td width=195 height="25" align="left" valign=top>&nbsp;                                      </td>
                                    <td width=498 rowspan="5" align="left" valign=top><table width="428" height="151" border="0">
                                      <tr>
                                        <th width="214" height="145" scope="col"><?
srand(time());
$random = (rand()%9);
srand(time());
$randagain = (rand()%9);
while ($random == $randagain)
{
	srand(time());
	$randagain = (rand()%9);
}
print "<img src = resource/Pic_Project/" . $random . ".jpg border =0  width='214' height='145'>";

?></th>
                                        <th width="198" scope="col"><? print "<img src =  resource/Pic_Project/" . $randagain . ".jpg border =0  width='214' height='145'>"; ?></th>
                                      </tr>
                                    </table></td>
                                  </tr>
                                  <tr> 
                                    <td width="57" height="25" valign=top>&nbsp; </td>
                                    <td width="195" height="25" align="left" valign=top><img src="resource/img/arrowgreenright.gif" width="13" height="13"> <a href="mis/mis_login.php">�к����ʹ�ȼ�������</a> </td>
                                  </tr>
                                  <tr> 
                                    <td width="57" height="25" valign=top>&nbsp;</td>
                                    <td width="195" height="25" align="left" valign=top><img src="resource/img/arrowgreenright.gif" width="13" height="13"> <a href="teacher/teach_login.php">�к����ʹ���Ҩ����</a></td>
                                  </tr>
                                  <tr> 
                                    <td width="57" height="25" valign=top>&nbsp;</td>
                                    <td width="195" height="25" align="left" valign=top><img src="resource/img/arrowgreenright.gif" width="13" height="13"> <a href="index_01.php">�к����ʹ�����˹�ҷ��</a> </td>
                                  </tr>
                                  <tr> 
                                    <td width="57" height="48" valign=top>&nbsp;</td>
                                    <td width="195" height="48" align="left" valign=top><img src="resource/img/arrowgreenright.gif" width="13" height="13"> <a href="student/std_login.php">�к����ʹ�ȹѡ�֡��</a></td>
                                  </tr>
                                  <tr> 
                                    <td width="57" height="25" valign=top>&nbsp;</td>
                                    <td height="25" colspan="2" align="left" valign=top>&nbsp;</td>
                                  </tr>
                                </tbody>
                              </table></td>
                            <td valign=top 
                      background="resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=8 
            src="resource/img/spacer.gif" width=8></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400 <a href="Admin/admin_login.php"><img src="resource/img/copyright.gif" width="12" height="12" border="0"></a> 
      </div></td>
  </tr>
</table>
</body>
</html>
