@echo = on
del *.bak