<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","Ẻ���������Ӥѭ����"); ?></title>
<style type="text/css">
<!--
.style24 {font-family: "CordiaUPC", Courier, mono; font-size: 16px; }
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style26 {font-family: CordiaUPC}
.style27 {font-size: large; font-weight: bold;}
.style28 {
	font-family: CordiaUPC;
	font-size: 20px;
	font-weight: bold;
}
.style29 {font-size: 20px; font-weight: bold; }
-->
</style>
</head>

<body>
<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM important_bill";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
		$sheet_id = $row[ "sheet_id" ];
		$sheet_num = $row[ "sheet_num" ];
		$pay_name = $row["pay_name"];
		$department = $row["department"];
		$date_making = $row["date_making"];
		$shop_name = $row["shop_name"];
		$bill_id = $row["bill_id"];
		$bill_num = $row["bill_num"];
		$bath = $row["bath"];
		$stang = $row["stang"];
		$note = $row["note"];
}	
    	include("EndConnect.php");
?>
<table width="100%"  border="0">
  <tr class="style25"><?php echo iconv ("TIS-620","UTF-8","��ǹ���Ŵ :"); ?><img src='pic/pdf16.gif' border=0 alt='<?php echo iconv ("TIS-620","UTF-8"," ��ǹ���Ŵ  .pdf   Ẻ���������Ӥѭ����"); ?>' />
    <td colspan="4"><div align="center" class="style29"><?php echo iconv ("TIS-620","UTF-8","Ẻ���������Ӥѭ����"); ?></div><br><br></td>
  </tr>
  <tr>
    <td ><?php echo iconv ("TIS-620","UTF-8","�������"); ?>...............
	<?php echo iconv ("TIS-620","UTF-8","�Ţ���"); ?>...............</td>
	
  </tr>
    <tr>
    <td width="30%"><?php echo iconv ("TIS-620","UTF-8","����....   "); ?><?php echo $pay_name?>.....</td>
    <td width="30%"><?php echo iconv ("TIS-620","UTF-8","�Ҥ�Ԫ�....  "); ?><?php echo $department?>....</td>
		<td class="style25" width="30%">
		<?php echo iconv ("TIS-620","UTF-8","��з�������ѹ���......"); ?> <?php echo $date_making?>.....</td>
 </tr>
  <tr>
    </tr>
</table><hr />
<table width="100%"  border="2" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="9%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ���"); ?></div>      <div align="center"></div></td>
    <td width="50%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","���ͺ���ѷ ��ҧ�����ǹ ��ҹ���"); ?> </div>      <div align="center"></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","������Ѻ�Թ"); ?></div>      <div align="center"></div></td>
    <td colspan="2"><div align="center"></div>      
    <div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ�Թ"); ?></div></td>
    <td width="10%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?></div>      <div align="center"></div></td>
  </tr>
  <tr>
    <td width="5%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�������"); ?></div></td>
    <td width="9%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�Ţ���"); ?></div></td>
    <td width="13%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ҷ"); ?></div></td>
    <td width="4%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","ʵҧ��"); ?></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="style25"><div align="center">
     <?php echo $shop_name?>
    </div></td>
    <td class="style25"><div align="center">
    <?php echo $bill_id?>
    </div></td>
    <td class="style25"><div align="center">
      <?php echo $bill_num?>
    </div></td>
    <td class="style25"><div align="center">
     <?php echo $bath?>
    </div></td>
    <td class="style25"><div align="center">
      <?php echo $stang?>
    </div></td>
    <td class="style25"><div align="center">
    <?php echo $note?>
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><div align="center"></div>      <div align="center"></div></td>
    <td colspan="2"><div align="center"></div>      
      <div align="center"><?php echo iconv ("TIS-620","UTF-8","����Թ"); ?></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">รวมเป็นเงิน.................................................................บาท</td>
  </tr>
  <tr>
    <td width="10%">&nbsp;</td>
    <td colspan="2">เจ้าหน้าที่พัสดุผู้รับ...........................................</td>
    <td colspan="2">เจ้าหน้าที่การเงินผู้รับ...........................................................</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="11%"><div align="right">วันที่</div></td>
    <td width="28%">............................................</td>
    <td width="12%"><div align="right">วันที่</div></td>
  <td width="39%">.............................................................</td>
  </tr>
</table>
...................................................................................................................................................................................................
<table width="100%"  border="0">
  <tr>
    <td width="9%">&nbsp;</td>
    <td colspan="2">ใบรับใบสำคัญเพื่อคืนเงิน</td>
    <td width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="5%">&nbsp;</td>
    <td width="53%">ใบสำคัญของอาจารย์......................................................................</td>
    <td>รวมเป็นเงิน.......................................บาท</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>เจ้าหน้าที่วัสดุผู้รับ..........................................................................</td>
    <td>วันที่................................................</td>
  </tr>
</table>
</body>
</html>
