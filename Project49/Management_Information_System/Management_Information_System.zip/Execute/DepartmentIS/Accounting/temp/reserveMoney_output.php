<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","�ѹ�֡�����Ѵ��"); ?> </title>
</head>
<style type="text/css">
<!--
.style24 {
	font-family: CordiaUPC;
	font-size: 18px;
}
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style26 {font-family: CordiaUPC}
.style27 {font-size: large; font-weight: bold;}
.style28 {
	font-family: CordiaUPC;
	font-size: 20px;
	font-weight: bold;
}
.style29 {
	font-family: AngsanaUPC;
	font-size: 32px;
	font-weight: bold;
}
-->
</style>
<body>
<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM reserve_money";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
		$sheet_id = $row[ "sheet_id" ];
		$sheet_num = $row[ "sheet_num" ];
		$date_making = $row["date_making"];
		$at = $row["at"];
		$title = $row["title"];		
		$budget_name = $row["budget_name"];
		$budget_year = $row["budget_year"];
		$name_reserve = $row["name_reserve"];
		$be_under = $row["be_under"];		
		$reason = $row["reason"];
		$list = $row["list"];
		$amount = $row["amount"];
		$bath = $row["bath"];
		$date_using = $row["date_using"];
	}	
    	include("EndConnect.php");
?>
<table width="100%"  border="0">
  <tr>
    <td colspan="4" class="style25"><div align="right"><?php echo iconv ("TIS-620","UTF-8","Ẻ �.1"); ?> </div></td>
  </tr>
  <tr>
    <td colspan="4" class="style29"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ�֡�����Ѵ��"); ?> </div></td>
  </tr>
  <tr>
    <td colspan="4"><div align="center"></div></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><div align="left"><b><?php echo iconv ("TIS-620","UTF-8","��ǹ�Ҫ��� ......"); ?> </b><?php echo iconv ("TIS-620","UTF-8","������ǡ�����ʵ��  ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ........"); ?></div>
	 </td>
  </tr>
  <tr>
    <td colspan="2" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","��� ȸ.0524.02.7/"); ?></b><?php echo $at ;?></td>
    <td colspan="2" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?></b><?php echo $date_making ;?></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","����ͧ  �����Ѵ��"); ?> </b>
	<?php echo $title ;?></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><?php echo iconv ("TIS-620","UTF-8","�����Թ...."); ?><?php echo $budget_name ;?><?php echo iconv ("TIS-620","UTF-8",".....��Шӻ�..."); ?>
	 <?php echo $budget_year ;?>...</td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><hr /><?php echo iconv ("TIS-620","UTF-8","���¹"); ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo iconv ("TIS-620","UTF-8","�����"); ?></td>
  </tr>
  <tr>
    <td width="14%">&nbsp;</td>
    <td width="26%" class="style25"><?php echo iconv ("TIS-620","UTF-8","��Ҿ���"); ?> 
        <?php echo $name_reserve ;?>
    </td>
    <td width="24%" class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѧ�Ѵ"); ?> 
     <?php echo $be_under ;?></td>
    <td width="36%" class="style25">    <?php echo iconv ("TIS-620","UTF-8","�˵ؼŤ����������"); ?> 
    <?php echo $reason ;?></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><?php echo iconv ("TIS-620","UTF-8","�����¡������Ҥҵ��仹������Ѵ�Ҿ�ʴ�  �ѧ��¡�õ��仹��"); ?> </td>
  </tr>
  <tr>
    <td width="14%" colspan="4">&nbsp;</td>
  </tr>
</table>
<table width="100%"  border="2" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="8%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ���"); ?> </div></td>
    <td width="42%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��¡��"); ?> </div></td>
    <td width="10%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ(˹���)"); ?> </div></td>
    <td width="13%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�Ҥһ���ҳ(�ҷ)"); ?> </div></td>
    <td width="25%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��˹����ҷ���ͧ�����"); ?> </div></td>
  </tr>
  <tr>
    <td><div align="center"></div></td>
    <td class="style25">
      <div align="center" class="style25">
        <?php echo $list ;?>
        </div></td>
    <td class="style25">
      <div align="center" class="style25" >
        <?php echo $amount ;?>
      </div></td>
    <td class="style25">
      <div align="center" class="style25">
        <?php echo $bath ;?>
      </div></td>
    <td class="style25"><div align="center">
      <?php echo $date_using ;?>
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" class="style25"><div align="center"></div>      <div align="center"></div>      
      <div align="right"><?php echo iconv ("TIS-620","UTF-8","������Թ������"); ?> </div></td>
    <td class ="style25"><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
</table>
<table width="100%"  cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="55%">และพร้อมกันนี้ได้แนบเอกสารประกอบการพิจารณา ดังนี้ </td>
    <td width="45%">ส่วนบันทึกการยืมเงิน</td>
  </tr>
  <tr>
    <td>1.&nbsp;&nbsp;&nbsp;&nbsp;รายละเอียดและคุณลักษณะ พัสดุ......................ชุด </td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;เห็นควรอนุมัติให้ยืมเงินทดรองจ่ายตามเสนอ</td>
  </tr>
  <tr>
    <td>2.&nbsp;&nbsp;&nbsp;&nbsp;ใบเสนอราคาพัสดุ.......................................ชุด</td>
    <td>ทั้งนี้จะต้องดำเนินการให้แลวเสร็จสิ้นพร้อมส่งหลักฐานให้</td>
  </tr>
  <tr>
    <td>3.&nbsp;&nbsp;&nbsp;&nbsp;สัญญาการยืมเงิน.......................................ใบ</td>
    <td>งานการเงอนภายในวันที่........./................/.........</td>
  </tr>
  <tr>
    <td>4.&nbsp;&nbsp;&nbsp;&nbsp;ขอเสนอรายชื่อ กรมมการตรวจรับพัสดุ </td>
    <td>มอบหมายให้หน่วยงานดำเนินการจัดหาพัสดุต่อไป</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นายประทีป บัญญัตินพรัตน์ </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นายธนัญชัย ตรีภาค</td>
    <td>ลงชื่อ......................เจ้าหน้าที่การเงิน/คณะ/สำนัก/บัณฑิต/วิทยาเขต</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;นายสมศักดิ์ วลัยรัชต์ </td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(..................)</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;จึงเรียนมาเพื่อโปรดพิจารณาเห็นชอบให้ดำเนินการจัดหาพัสดุข้างต้นต่อไปด้วย</td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;อนุมัติ</td>
  </tr>
  <tr>
    <td>จักขอบคุณยิ่ง</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ลงชื่อ.......................................(ผู้ขอให้จัดหา)</td>
    <td>ลงชื่อ.....................................................</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(....นายประทีป บัญญัตินพรัตน์....)</td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(....รศ.ดร.กอบชัย เดชหาญ....)</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;คณบดีคณะวิศวกรรมศาสตร์</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ลงชื่อ.......................................(หัวหน้าภาควิชา)</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(....นายประทีป บัญญัตินพรัตน์....)</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
