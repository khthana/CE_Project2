<?php
	mysql_free_result($table);
	mysql_close($Conn);
?>