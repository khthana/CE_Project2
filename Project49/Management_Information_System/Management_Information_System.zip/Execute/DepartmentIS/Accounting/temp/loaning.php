<?//include("_CheckSession.php"); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="style.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody">
<table width="50%"  border="0" align = "center">
  <tr>
    <td><u> �ѭ�ҡ������Թ</u> </td>
  </tr>
  <tr>
    <td><div align="right"><span >1.</span></div></td>
    <td><a href="loaning_input.php"><u>�ѭ�ҡ������Թ </u> </a></td>

  </tr>
  <tr>
    <td><div align="right"></div></td>
    <td></td>
  
  </tr>
  <tr>
    <td><div align="right"></div></td>
    <td></td>
   
  </tr>
  <tr>
    <td><div align="right"></div></td>
    <td></td>

  </tr>
</table> 
</body>
</html>