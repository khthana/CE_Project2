<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Untitled Document</title>
</head>

<body>
<? include ("StartConnect.php") ?>
<?
	$sql = "SELECT person_id,position,th_name,th_surname FROM person";
	$table = mysql_query($sql,$Conn) or die ("�������ö�Դ�����"); 
	
	
?>
<form name="teacher" method="post" action="_testrecieve.php">
  <select name="person">
   <? 
 			while ($row = mysql_fetch_array($table))
			{
					$person_id = $row[0];
					$position = $row[1];
					$th_name = $row[2];
					$th_surname = $row[3];
 ?>
    <option value="<?=$person_id ?>"><? echo iconv ("TIS-620","UTF-8",$person_id . $position .  $th_name .  $th_surname);  ?></option>
 
  <?				
  			}
  ?>
 </select> 
 <input type="submit" name="Submit" value="Submit">

</form>
<?
 include ("EndConnect.php");
 ?>
</body>
</html>