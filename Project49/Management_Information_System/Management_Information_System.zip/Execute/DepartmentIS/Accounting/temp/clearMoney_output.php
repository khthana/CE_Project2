<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","��Ӥѭ���ͤ׹�Թ������ͧ����"); ?></title>
</head>
<style type="text/css">
<!--
.style24 {
	font-family: CordiaUPC;
	font-size: 18px;
}
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style26 {font-family: CordiaUPC}
.style27 {font-size: large; font-weight: bold;}
.style28 {
	font-family: CordiaUPC;
	font-size: 20px;
	font-weight: bold;
}
.style29 {
	font-family: AngsanaUPC;
	font-size: 32px;
	font-weight: bold;
}
-->
</style>
<body><?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM clear";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
		$sheet_num = $row[ "sheet_num" ];
		$clear_to = $row[ "clear_to" ];
		$borrower_name = $row[ "borrower_name" ];
		$date_borrow = $row[ "date_borrow" ];
		$amount_borrow = $row[ "amount_borrow" ];
		$bill_name = $row[ "bill_name" ];
		$budget_name = $row[ "budget_name" ];
		$department = $row[ "department" ];
		$shop_name = $row[ "shop_name" ];
		$money = $row[ "money" ];
		$note = $row[ "note" ];

	}	
    	include("EndConnect.php");
?>
<table width="100%"  border="0">
  <tr>
    <td colspan="3"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��Ӥѭ���ͤ׹�Թ������ͧ����"); ?></div></td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"></div></td>
  </tr>
  <tr>
    <td ></td>
  </tr>
  <tr>
    <td><?php echo iconv ("TIS-620","UTF-8","�׹�Թ���"); ?>....................      
   <?php echo $clear_to?>............................</td>
    <td><?php echo iconv ("TIS-620","UTF-8","ŧ�ѹ���"); ?>
     ............................................</td>
    <td><?php echo iconv ("TIS-620","UTF-8","�ʹ�Թ���"); ?>
    .......................................<?php echo iconv ("TIS-620","UTF-8","�ҷ"); ?></td>
  </tr>
  <tr>
    <td><?php echo iconv ("TIS-620","UTF-8","���ͼ��������"); ?>..............
       <?php echo $borrower_name?>..............</td>
    <td><?php echo iconv ("TIS-620","UTF-8","ŧ�ѹ���"); ?>..............
           <?php echo $date_borrow?>..............</td>
    <td><?php echo iconv ("TIS-620","UTF-8","�ʹ�Թ���"); ?>..............
      <?php echo $amount_borrow?>...............
<?php echo iconv ("TIS-620","UTF-8","�ҷ"); ?></td>
  </tr>
  <tr>
    <td><?php echo iconv ("TIS-620","UTF-8","��"); ?>..............................
   <?php echo $budget_name?>.........................</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","�Ҥ/�ٹ��/�ӹѡ�ҹ�����"); ?>........................
    <?php echo $department?>........................</td>
      </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%"  border="2" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="6%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ���"); ?></div></td>
    <td width="40%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","���ͺ���ѷ, ��ҧ�����ǹ, ��ҹ��� "); ?></div></td>
    <td width="10%"><div align="center">
      <p><?php echo iconv ("TIS-620","UTF-8","������Ѻ�Թ"); ?></p>
      <p><?php echo iconv ("TIS-620","UTF-8","�������/�Ţ��� "); ?> </p>
    </div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ�Թ"); ?></div>      <div align="center"></div></td>
    <td width="19%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?></div></td>
  </tr>
  <tr>
    <td><div align="center"></div></td>
    <td><div align="center">
      <?php echo $shop_name?>
    </div></td>
    <td><div align="center">
     <?php echo $bill_name?> 
    </div></td>
    <td width="19%" colspan="2"><div align="center">
      <?php echo $money?>
    </div></td>
    <td width="6%"><div align="center">
      <?php echo $note?></div></td>
    </tr>
  <tr>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","������Թ"); ?></div></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
