<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","�ѭ�ҡ������Թ"); ?></title>
<style type="text/css">
<!--
.style24 {font-family: "CordiaUPC", Courier, mono; font-size: 16px; }
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style26 {font-family: CordiaUPC}
.style27 {font-size: large; font-weight: bold;}
.style28 {
	font-family: CordiaUPC;
	font-size: 20px;
	font-weight: bold;
}
.style29 {font-size: 20px; font-weight: bold; }
-->
</style>
</head>
<body>
<form name ="form1" method='post' action='Insert_loaning.php'>
<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM loaning ";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
		$sheet_num = $row[ "sheet_num" ];
		$day_expire = $row["day_expire"];
		$for = $row["for"];
		$borrower_name = $row["borrower_name"];
		$position = $row["position"];
		$level = $row["level"];
		$be_under = $row["be_under"];
		$province = $row["province"];
		$borrow_from = $row["borrow_from"];
		$borrow_for = $row["borrow_for"];
		$money = $row["money"];
		$text_money = $row["text_money"];
		$r_id = $row["r_id"];
		$status = $row["status"];
}	    
    	include("EndConnect.php");
?>
<table width="100%"  border="2" align="center" cellspacing="0" bordercolor="#000000">
  <tr class="style25">
    <td width="64%" rowspan="2" class="style26"><div align="center" class="style27">
        <table width="100%"  border="0">
          <tr>
            <td><div align="center" class="style29"><?php echo iconv ("TIS-620","UTF-8","�ѭ�ҡ������Թ"); ?> </div></td>
          </tr>
        </table>
      </div>
        <table width="100%"  border="0">
          <tr>
            <td width="91%"><span class="style25">
			<?php echo iconv ("TIS-620","UTF-8","��蹵��"); ?>&nbsp;<input  name="for" type="text" size="64" ></td> </span></td>
            <td width="8%"><div align="center" class="style25">(1)</div></td>            
          </tr>
        </table>
        <table width="100%"  border="0">
          <tr>
            <td width="40%">&nbsp;</td>
            <td width="60%">&nbsp;</td>
          </tr>
      </table></td>
    <td colspan="2"><table width="100%"  border="0">
        <tr class="style25">
        <td width="50%"><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�Ţ���  "); ?> <input  name="sheet_num" type="text" size="6" ></td></span></td>
        </tr>
      </table>        
    <div align="left" class="style4"></div>        <div align="left" class="style4"></div></td>
  </tr>
  <tr class="style5">
    <td colspan="2"><table width="100%"  border="0">
        <tr class="style25">
          <td width=""><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѹ�ú��˹�"); ?></span>
		  <select name="day_expire" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          </select>
          <select name="mount_expire" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> 
		   <select name="year_expire" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> 
		 </td>
        </tr>
      </table>
        <div align="center" class="style19"></div>
        <div align="left" class="style19"></div></td>
  </tr>
  <tr class="style5">
    <td colspan="3"><table width="100%"  border="0">
        <tr class="style25">
          <td colspan="2"><span><?php echo iconv ("TIS-620","UTF-8","��Ҿ���  "); ?> </span>
				<select name='borrower_name'>
	<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM person  WHERE type = 0 OR type = 1";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
					$person_id = $row[0];
					$position = $row[2];
					$th_name = $row[3];
					$th_surname = $row[4];
	?>
<option value = "<?=$position ." ". $th_name ."     ".$th_surname ?>"><?php echo  $position .  $th_name ."     ".$th_surname ; ?> </option	><?}?>	
</select>
</td>
	</td>
          <td width="27%"><span class="style25"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?>  </span>
	  <select name='position'>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","�Ҩ���� (��ѡ�ҹ)"); ?>"><?php echo iconv ("TIS-620","UTF-8","�Ҩ���� (��ѡ�ҹ)"); ?></option>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","�Ҩ����2"); ?>"><?php echo iconv ("TIS-620","UTF-8","�Ҩ����2"); ?></option>
			</select>		
	</td></td>
          <td width="24%"><div align="justify" class="style25"></div>
              <div align="justify" class="style25"><?php echo iconv ("TIS-620","UTF-8","�дѺ"); ?>
	 <select name='level'>
			 <option value = "1">1</option>
			<option value = "2">2</option>
			<option value = "3">3</option>
			<option value = "4">4</option>
			<option value = "5">5</option>
			<option value = "6">6</option>
			<option value = "7">7</option>
			<option value = "8">8</option>
			<option value = "9">9</option>
	</select>
</td></div></td>
        </tr>
        <tr class="style25">
          <td colspan="2"><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѧ�Ѵ"); ?> </span>
		  <select name='be_under'>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","���ǡ�����ʵ��"); ?>"><?php echo iconv ("TIS-620","UTF-8","���ǡ�����ʵ��"); ?></option>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","�Է����ʵ��"); ?>"><?php echo iconv ("TIS-620","UTF-8","�Է����ʵ��"); ?></option>
	</select>
		  
		  </td>
          <td><div align="justify" class="style25"></div>
              <div align="justify" class="style25"></div>
              <div align="justify" class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѧ��Ѵ  "); ?><select name='province'>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","��ا෾��ҹ��"); ?>"><?php echo iconv ("TIS-620","UTF-8","��ا෾��ҹ��"); ?></option>
			<option value = "<?php echo iconv ("TIS-620","UTF-8","�ҭ������"); ?>"><?php echo iconv ("TIS-620","UTF-8","�ҭ������"); ?></option>
	</select></div></td>
          <td><span class="style20"></span></td>
        </tr>
        <tr class="style25">
          <td colspan="3"><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�դ������ʧ�������Թ�ҡ  ʶҺѹ෤����վ�Ш�����Ҥس�����Ҵ��кѧ "); ?> </span>
              <div align="justify" class="style25"></div>
              <div align="justify" class="style25"></div></td>
          <td><span class="style25">(2)</span></td>
        </tr>
        <tr class="style25">
          <td width="40%"><div align="justify" class="style25"></div>
              <span class="style25"><?php echo iconv ("TIS-620","UTF-8","�����繤�������㹡��"); ?>  </span><input  name="borrow_for" type="text" size="32" ></td>
          <td colspan="2"><span class="style25"></span></td>
          <td><span class="style25"><?php echo iconv ("TIS-620","UTF-8","����������´�ѧ���仹��"); ?> </span></td>
        </tr>
    </table></td>
  </tr>
  <tr class="style5">
    <td><table width="100%"  border="0">
        <tr>
          <td class="style25" ><div ></div></td>
        </tr>
      </table>
        <table width="100%"  border="0">
          <tr>
            <td class="style25"><div ><input  name="text_money" type="text" size="50" ><?php echo iconv ("TIS-620","UTF-8","( �ӹǹ�Թ����ѡ�� )");?></div></td>
          </tr>
      </table></td>
    <td width="20%" class="style25"><div align="center"><input  name="money" type="text" size="12" >
	<?php echo iconv ("TIS-620","UTF-8","(����Ţ)");?></div></td>
  </tr>
  <tr class="style5">
    <td colspan="3"><div align="justify" class="style20"></div>
        <div align="justify" class="style20">
          <dd class="style25"><span class="style25"><?php echo iconv ("TIS-620","UTF-8"," ��Ҿ����ѭ����Ҩл�ԺѵԵ������º�ͧ�ҧ�Ҫ��÷ء��С�� ��Шй���Ӥѭ�����·��١��ͧ�����"); ?>
		  <table>
		  <tr>
		  	<td class="style25"><?php echo iconv ("TIS-620","UTF-8","����Թ����ͨ���(�����)�������㹡�˹���������º����ԡ���¨ҡ��ѧ ������� 30 �ѹ �Ѻ���ѹ������Ѻ�Թ���");?></td>
		  </tr>
		  <table>
		  <tr>
		  	<td class="style25"><?php echo iconv ("TIS-620","UTF-8","��� ��Ң�Ҿ�������觵����˹� ��Ҿ����Թ�������ѡ�Թ��͹ ��Ҩ�ҧ ������Ѵ ���˹� �ӹҭ �����Թ����ش����Ҿ���");?></td>
		   </tr>
		 <tr>
		  	<td class="style25"><?php echo iconv ("TIS-620","UTF-8","�о֧���Ѻ�ҡ�ҧ�Ҫ��ê���ӹǹ�Թ������仨��ú��ǹ��ѹ�� ");?></td>
		   </tr>
		  </table> 
		  <?php echo iconv ("TIS-620","UTF-8","�����ͪ���......................................................................�ѹ���   "); ?> 
		  <select name="day_making" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          </select>
          <select name="mount_making" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> 
		   <select name="year_making" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> 
		  </span>	         
		 <FONT color=#FF0000><?php echo iconv ("TIS-620","UTF-8","( ��سҵ�Ǩ�ͺ�����Ţͧ��ҹ )"); ?></FONT>
		  <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","�׹�ѹ"); ?>">
          <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","¡��ԡ"); ?>">
		  <br>         
          <dd class="style19">       
      </div>
        <div align="center"></div>
        <div align="center"></div></td>
  </tr>
  <tr class="style19">
    <td colspan="3"><table width="100%"  border="0">
      <tr>
        <td width="20%"><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�ʹ�"); ?></span></td>
        <td width="29%">&nbsp;</td>
        <td width="5%"><div align="center" class="style25">(4)</div></td>
        <td width="59%">&nbsp;</td>
      </tr>  
	  </table>
      <table width="100%"  border="0">
        <tr>
          <td width="33%"class="style25">&nbsp;&nbsp;&nbsp;<?php echo iconv ("TIS-620","UTF-8","���Ǩ�ͺ������������͹��ѵ����������������Ѻ����� �ӹǹ"); ?> </td>
          <td width="5%"><span class="style25"></span></td>
          <td width="22%"><span class="style25"></span></td>
          
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr>
          <td width="36%" class="style25"><?php echo iconv ("TIS-620","UTF-8","ŧ����................................................."); ?> </td>
          <td width="64%" class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѹ���................................................................................."); ?> </td>
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr>
          <td width="36%" class="style25"><div align="center" class="style26"><?php echo iconv ("TIS-620","UTF-8","(�ҧ��� ����ǧ 侺�����آʡ��)"); ?> </div></td>
          <td width="64%" rowspan="2">&nbsp;</td>
        </tr>
        <tr>
          <td class="style25"><div align="center" class="style26"><?php echo iconv ("TIS-620","UTF-8","�ѡ�Ԫҡ���Թ��кѭ�� 7"); ?>  </div></td>
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr>
          <td><div align="center" class="style28"><u><?php echo iconv ("TIS-620","UTF-8","��͹��ѵ�"); ?> </u></div></td>
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr class="style25">
          <td width="39%"><dd><?php echo iconv ("TIS-620","UTF-8","͹��ѵ�������������͹䢢�ҧ�������Թ"); ?>  </td>
          <td width="2%">&nbsp;</td>
          <td width="4%"><?php echo iconv ("TIS-620","UTF-8","�ҷ"); ?> </td>
          <td width="55%">&nbsp;</td>
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr class="style25">
          <td width="49%"><?php echo iconv ("TIS-620","UTF-8","ŧ���ͼ��͹��ѵ�..................................................................."); ?> </td>
          <td width="51%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���......................................................................"); ?> </div></td>
        </tr>
        <tr class="style25">
          <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","(��.��.���� �����)"); ?> </div></td>
          <td width="51%">&nbsp;</td>
        </tr>
        <tr class="style25">
          <td><div align="center" class="style29"></div></td>
          <td width="51%">&nbsp;</td>
        </tr>
      </table></td>
	    </tr>
		
  <tr class="style19">
    <td colspan="3"><table width="100%"  border="0">
      <tr>
        <td><div align="center" class="style28"><u><?php echo iconv ("TIS-620","UTF-8","��Ѻ�Թ"); ?> </u></div></td>
      </tr>
    </table>
      <table width="100%"  border="0">
        <tr>
          <td width="27%" class="style25"><dd><?php echo iconv ("TIS-620","UTF-8","���Ѻ�Թ����ӹǹ"); ?>  </td>
          <td width="6%" class="style25"></td>
          <td width="4%" class="style25"><?php echo iconv ("TIS-620","UTF-8","�ҷ"); ?> </td>
          <td width="40%" class="style25"></td>
          <td width="23%" class="style25"><?php echo iconv ("TIS-620","UTF-8","��繡�ö١��ͧ����"); ?> </td>
        </tr>
      </table>
      <table width="100%"  border="0">
        <tr>
          <td class="style25"><?php echo iconv ("TIS-620","UTF-8","ŧ����....................................................................����Ѻ�Թ"); ?> </td>
          <td class="style25"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................................."); ?> </td>
        </tr>
      </table></td>
  </tr>
</table>
</table>
<u><span class="style25"><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?> </span></u><span class="style25"> <?php echo iconv ("TIS-620","UTF-8","�������Թ����餳����ǡ�����ʵ��ó���觴�ǹ��� �������е�ͧ�������͡��á������Թ�ѧ��������� 2 �ѻ������ѧ�ҡ������������Թ�������������� ��Ҽ���������������������Թ�����������Ҵѧ����Ƿҧ���� �еѴ�Է���㹡������Թ�����ͧ���㹤��駵���"); ?>  </span><br>
  </form>  
</p>
</body>
</html>
