<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","��ԡ��ʴ�"); ?></title>
<style type="text/css">
<!--
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style10 {font-family: CordiaUPC; font-size: 20px; font-style: normal; font-weight: bold; color: #000000; }
-->
</style>
</head>

<body>
<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM inventory_bring";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
		$sheet_id = $row[ "sheet_id" ];
		$sheet_num = $row[ "sheet_num" ];
		$making_date = $row["making_date"];
		$bring_name = $row["bring_name"];
		$amount = $row["amount"];
		$bring_for = $row["bring_for"];
		$receiver_name = $row["receiver_name"];
		$date_using = $row["date_using"];
		$list = $row["list"];
		$bring_amount = $row["bring_amount"];
		$bring_pay = $row["bring_pay"];
		$bring_unpay = $row["bring_unpay"];
		$gpsc = $row["gpsc"];
		$capital_bath = $row["capital_bath"];
		$capital_stang = $row["capital_stang"];
		$bath = $row["bath"];
		$stang = $row["stang"];
		$note = $row["note"];
		$text_money = $row["text_money"];
	}	
    	include("EndConnect.php");
?>
<table width="100%"  border="0">
  <tr class="style25">
  <?php echo iconv ("TIS-620","UTF-8","��ǹ���Ŵ :"); ?><img src='pic/pdf16.gif' border=0 alt='<?php echo iconv ("TIS-620","UTF-8"," ��ǹ���Ŵ  .pdf   ��ԡ��ʴ�"); ?>' />
    <td width="80%">&nbsp;</td>
    <td width="20%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","Ẻ �.43 "); ?></div></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td><div align="center" class="style10"><?php echo iconv ("TIS-620","UTF-8","��ԡ��ʴ�"); ?></div></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr class="style25">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","��ǹ�Ҫ���"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","ʶҺѹ෤����վ�Ш��������Ҥس�����"); ?></td>
  </tr>
  <tr class="style25">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","˹��§ҹ"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","������ǡ�����ʵ��"); ?></td>
  </tr>
  <tr class="style25">
    <td><?php echo iconv ("TIS-620","UTF-8","�������............."); ?></td>
    <td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","�Ҥ/�ͧ"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","��ȡ�������������"); ?></td>
  </tr>
  <tr class="style25">
    <td width="13%" height="39"><?php echo iconv ("TIS-620","UTF-8","�Ţ���............."); ?></td>
    <td width="43%">&nbsp;</td>
    <td width="4%"><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?></td>
    <td width="6%">������</td>
    <td width="5%"><?php echo iconv ("TIS-620","UTF-8","��͹"); ?></td>
    <td width="5%">���������</td>
    <td width="5%"><?php echo iconv ("TIS-620","UTF-8","�.�."); ?></td>
    <td width="19%">ഡ�����</td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td width="7%" class="style25"><?php echo iconv ("TIS-620","UTF-8","���¹"); ?></td>
    <td colspan="2" class="style25">&nbsp;</td>
  </tr>
  <tr>
    <td class="style25"><dd><?php echo iconv ("TIS-620","UTF-8","����"); ?></td>
    <td width="25%" class="style25"><?php echo $bring_name ; ?></td>
    <td width="68%" class="style25"><?php echo iconv ("TIS-620","UTF-8","..............�դ������ʧ����ԡ��ʴص����¡����Шӹǹ"); ?>
	&nbsp;&nbsp;<?php echo $amount ;?>&nbsp;&nbsp;<?php echo iconv ("TIS-620","UTF-8","��¡��"); ?> <?php echo iconv ("TIS-620","UTF-8","����"); ?>
	<?php echo $bring_for ; ?>
	</td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr class="style25">
    <td><?php echo iconv ("TIS-620","UTF-8","��е�ͧ�������觢ͧ�����ԡ�������"); ?><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?> <?php echo iconv ("TIS-620","UTF-8","��͹"); ?><?php echo iconv ("TIS-620","UTF-8","�.�."); ?> <?php echo iconv ("TIS-620","UTF-8","����ͺ���"); ?>........<?php echo $receiver_name ; ?>........ <?php echo iconv ("TIS-620","UTF-8","�繼���Ѻ��ʴ�᷹"); ?></td>
  </tr>
</table>
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr class="style25">
    <td width="5%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ"); ?></div>      <div align="center"></div></td>
    <td width="24%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��¡��"); ?></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div></td>
    <td colspan="3"><div align="center"></div>      <div align="center"></div>      <div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ"); ?></div></td>
    <td colspan="5"><div align="center"></div>      <div align="center"></div>      <div align="center"><?php echo iconv ("TIS-620","UTF-8","��ǹ�ͧ�ҹ��ʴ�"); ?></div></td>
    <td width="12%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?></div>      <div align="center"></div></td>
  </tr>
  <tr class="style25">
    <td width="5%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ԡ"); ?></div></td>
    <td width="5%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","����"); ?></div></td>
    <td width="9%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��ҧ����"); ?></div></td>
    <td width="10%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","���ʾ�ʴ�"); ?></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�鹷ع/˹���"); ?></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ�Թ"); ?></div></td>
  </tr>
  <tr class="style25">
    <td><div align="center"></div></td>
    <td><div align="center"></div>
        <div align="center"><?php echo $list ; ?></div>
        <div align="center"></div></td>
    <td><div align="center"><?php echo $bring_amount; ?></div></td>
    <td><div align="center"><?php echo $bring_pay ; ?></div></td>
    <td><div align="center"><?php echo $bring_unpay ; ?></div></td>
    <td><div align="center"><?php echo $gpsc; ?></div></td>
    <td width="9%"><div align="center"><?php echo $capital_bath; ?></div></td>
    <td width="6%"><div align="center"><?php echo $capital_stang; ?></div></td>
    <td><div align="center"><?php echo $bath; ?></div></td>
    <td><div align="center"><?php echo $stang; ?></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr class="style25">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr class="style25">
    <td colspan="7">&nbsp;</td>
    <td><div align="center"> <?php echo iconv ("TIS-620","UTF-8","���"); ?></div></td>
    <td width="9%"><div align="center">40000</div></td>
    <td width="6%"><div align="center">-</div></td>
    <td><div align="center"></div></td>
  </tr>
</table>
<table width="100%"  border="0" cellspacing="2">
  <tr>
    <td class="style25"><table width="40%" align="left" cellspacing="0" bordercolor="#000000">
      <tr>
        <td width="53%"><div align="center" class="style25">
          <div align="left">
            <table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
              <tr>
                <td>( <?php echo $text_money; ?> )  </td>
              </tr>
            </table>
          </div>
        </div></td>
        </tr>
    </table>    </td>
  </tr>
</table>
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����ԡ"); ?></div></td>
        </tr>
      <tr class="style25">
        <td width="11%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div></td>
        <td width="89%"><div align="left"></div></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>          <div align="center"></div></td>
        </tr>
    </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td width="100%">&nbsp;</td>
        </tr>
        <tr class="style25">
          <td><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���˹��˹��§ҹ"); ?></div></td>
        </tr>
        <tr class="style25">
          <td><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></td>
        </tr>
        <tr class="style25">
          <td><strong><?php echo iconv ("TIS-620","UTF-8","���Ѻ��觢ͧ件١��ͧ���º��������"); ?></strong></td>
        </tr>
      </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................����Ѻ��ʴ�"); ?></div></td>
        </tr>
        <tr class="style25">
          <td width="11%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div></td>
          <td width="89%"><div align="left"></div></td>
        </tr>
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>
              <div align="center"></div></td>
        </tr>
      </table></td>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���Ѵ�ѭ�վ�ʴ�"); ?></div></td>
        </tr>
      <tr class="style25">
        <td width="12%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div>          <div align="left"></div></td>
        <td width="88%">&nbsp;</td>
      </tr>
      <tr class="style25">
        <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></td>
      </tr>
      <tr class="style25">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr class="style25">
        <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����¢ͧ"); ?></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>
            <div align="center"></div></td>
      </tr>
    </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td colspan="2"><strong><?php echo iconv ("TIS-620","UTF-8","͹��ѵ���������"); ?></strong></td>
        </tr>
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����觨���"); ?></div></td>
        </tr>
        <tr class="style25">
          <td width="49%"><div align="center">(.........................................................)</div></td>
          <td width="51%"><div align="left"></div></td>
        </tr>
        <tr class="style25">
          <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ���........................................."); ?></div>
          <div align="center"></div></td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><strong><?php echo iconv ("TIS-620","UTF-8","�͡��ü�ҹ�ҹ�ѭ������"); ?></strong></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���˹�ҧҹ�ѭ��"); ?></div></td>
      </tr>
      <tr class="style25">
        <td width="55%"><div align="center">(.........................................................)</div></td>
        <td width="45%"><div align="left"></div></td>
      </tr>
      <tr class="style25">
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ���..............................................."); ?></div>
          <div align="center"></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
