<!-- buybill_input.php -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","���觫���"); ?></title>

<style type="text/css">
<!--
.style24 {font-family: "CordiaUPC", Courier, mono; font-size: 16px; }
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
-->
</style>
</head>

<body class="style25">
<form method='post' action='Insert_buybill.php'>
<table width="100%"  cellspacing="0">
  <tr>
    <td width="75%">&nbsp;</td>
    <td width="25%"><div align="center" class="style25"><?php echo iconv ("TIS-620","UTF-8","Ẻ �.2"); ?> </div></td>
  </tr>
</table>
<p align="center"><strong><?php echo iconv ("TIS-620","UTF-8","���觫���"); ?></strong></p>
<p align="center"><strong><?php echo iconv ("TIS-620","UTF-8","ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ"); ?></strong></p>
<table width="100%" border="0" align="center">
  <tr>
    <td colspan="3"><?php echo iconv ("TIS-620","UTF-8","�Ţ���"); ?>
    <input type="text" name="sheet_num"></td>
    <td width="54%"></td>
  </tr>
  <tr>
    <td colspan="3"><?php echo iconv ("TIS-620","UTF-8","�֧....."); ?>
    <input type="text" name="to"></td>
    <td><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?> 
    <select name="day_making" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          </select>
		   <?php echo iconv ("TIS-620","UTF-8","��͹"); ?>
          <select name="mount_making" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> 
		     <?php echo iconv ("TIS-620","UTF-8","�.�."); ?>
		   <select name="year_making" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> 
 </td>	
  </tr>
  <tr>
    <td colspan="3"><?php echo iconv ("TIS-620","UTF-8","���͹䢡�ê����Թ"); ?>
    <input type="text" name="condition"></td>
    <td><?php echo iconv ("TIS-620","UTF-8","��˹��������ѹ���"); ?>
         <select name="day_expire" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          </select>
		   <?php echo iconv ("TIS-620","UTF-8","��͹"); ?>
          <select name="mount_expire" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> 
		     <?php echo iconv ("TIS-620","UTF-8","�.�."); ?>
		   <select name="year_expire" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> </td>
  </tr>
  <tr>
    <!-- ��ͧ SELECT  �Ҩҡ ���ҧ report_buy ����������ش -->
	<td width="23%"><?php echo iconv ("TIS-620","UTF-8","����ѹ�֡�ʹͫ���/��ҧ�Ţ���"); ?>
	<input name="sellhire_num" type="text" size="2"></td>
    <td width="7%"><?php echo iconv ("TIS-620","UTF-8","ŧ�ѹ���"); ?></td>
    <td width="16%"><input name="sellhire_date" type="text" size="8"></td>
    <td width="16%"><?php echo iconv ("TIS-620","UTF-8","ʶҹ����觢ͧ"); ?>
    <input type="text" name="place" size="32"></td>
  </tr>
</table>
<table width="100%" border="0">
  <tr>
    <td width="70%"><dd><?php echo iconv ("TIS-620","UTF-8","ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ �鵡ŧ���;�ʴص����ʹ��Ҥ� �ͧ��ҹ�Ţ��� ŧ�ѹ��� ��͹ �.�. �·�ҹ�е�ͧ��ԺѵԵ�����͹䢫���������ҹ��ѧ���觫��͹��ء��С��"); ?> </dd></td>
  </tr>
  <tr>
    <td>      <div align="justify"></div></td>
  </tr>
</table>
<table width="100%" height="0%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="7%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ���"); ?></div>
        <div align="center"></div></td>
    <td width="37%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��¡��"); ?></div>
        <div align="center"></div></td>
    <td width="7%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","˹��¹Ѻ"); ?></div>
        <div align="center"></div></td>
    <td width="5%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ"); ?></div>
        <div align="center"></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�Ҥ�˹�����"); ?></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ�Թ"); ?></div></td>
  </tr>
  <tr>
    <td width="9%"colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ҷ.ʵҧ��"); ?></div></td>
    <td width="9%"colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ҷ.ʵҧ��"); ?></div></td>
  </tr>
  <tr>
    <td></td>
	<td><div align="center"> <input type="text" name="list" size="64"></div></td>
    <td><div align="center"> <input type="text" name="unit_count" size="6"></div></td>
    <td><div align="center"> <input type="text" name="amount" size="8"></div></td>
    <td  colspan="2"><div align="center"> <input type="text" name="unit_price" size="8"></td>
    <td  colspan="2"><div align="center"> <input type="text" name="money" size="8"></div></td>
   
  </tr>
  <tr>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55</div></td>
    <td><div align="center">55 </div></td>
  </tr>
  <tr class="style25">
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
  <tr class="style25">
    <td colspan="5"><div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div></td>
    <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","���"); ?></div></td>
    <td><div align="center">50000</div></td>
    <td><div align="center">55</div></td>
  </tr>
</table>

<table width="100%"  cellspacing="0">
  <tr>
    <td><table width="40%"  border="1" cellspacing="0" bordercolor="#000000">
      <tr>
        <td class="style25"><input name="text_money" type="text" size="64"></td>
	</tr>
    </table></td>
  </tr>
</table>
<FONT color=#FF0000><?php echo iconv ("TIS-620","UTF-8","( ��سҵ�Ǩ�ͺ�����Ţͧ��ҹ )"); ?></FONT>
		  <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","�׹�ѹ"); ?>">
          <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","¡��ԡ"); ?>">
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="40%"><table width="100%"  cellspacing="0">
      <tr>
        <td width="98%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","ŧ����.................................................����͡���觫���"); ?></div></td>
        <td width="2%">&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center">(  <?php echo iconv ("TIS-620","UTF-8","��.��зջ �ѭ�ѵԹ��ѵ��"); ?>  )</div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","���˹���Ҥ�Ԫ�"); ?></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","ŧ����.................................................����͡���觫���"); ?></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","(�.��.���� �����)"); ?></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","��һ�зѺ............................................."); ?></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td width="60%"><table width="100%"  cellspacing="0">
      <tr>
        <td width="98%"><div align="left"><dd></dd>
       <?php echo iconv ("TIS-620","UTF-8","��Ҿ������Ѻ���觫��͵����������´��ҧ���������Һ���͹䢢�͵�ŧ�����ҧ�����͡Ѻ���������Ըա�÷�����µ�ͧ��Ժѵ�����Թ�����ԺѵԵ���ء��С�è֧ŧ�����������ѡ�ҹ"); ?></div></td>
        <td width="2%">&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","ŧ����.................................................����͡���觫���"); ?></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center">(................................................................)</div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","��һ�зѺ............................................."); ?></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center">........../.........................../.................</div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><dd></dd>

    <table width="100%"  cellspacing="0">
      <tr>
        <td><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?></td>
        <td> - <?php echo iconv ("TIS-620","UTF-8","�е�ͧ�����觫��͵鹩�Ѻ���ʴ�������Ѻ��觢ͧ/㺡ӡѺ���մ��·ء���駷�����觢ͧ"); ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>- <?php echo iconv ("TIS-620","UTF-8","��觢ͧ������觫��͹��ʶҺѹ� ������Ѻ����͡�����õ�Ǩ�Ѻ���Ǩ�Ѻ�繡�ö١��ͧ����"); ?> </td>
      </tr>
    </table>    
</td>
  </tr>
</table>
</form>
</body>
</html>
