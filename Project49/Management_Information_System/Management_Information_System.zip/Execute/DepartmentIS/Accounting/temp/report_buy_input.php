<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","�ѹ�֡��§ҹ�ͫ���/��ҧ"); ?> </title>
</head>
<style type="text/css">
<!--
.style24 {
	font-family: CordiaUPC;
	font-size: 18px;
}
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style26 {font-family: CordiaUPC}
.style27 {font-size: large; font-weight: bold;}
.style28 {
	font-family: CordiaUPC;
	font-size: 20px;
	font-weight: bold;
}
.style29 {
	font-family: AngsanaUPC;
	font-size: 32px;
	font-weight: bold;
}
-->
</style>
<body><form method='post' action='Insert_report_buy.php'>
<table width="100%"  border="0">
  <tr>
    <td colspan="4" class="style25"><div align="right"><?php echo iconv ("TIS-620","UTF-8","Ẻ ��.1"); ?> </div></td>
  </tr>
  <tr>
    <td colspan="4" class="style29"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ�֡��§ҹ�ͫ���/��ҧ"); ?> </div></td>
  </tr>
  <tr>
    <td colspan="4"><div align="center"></div></td>
  </tr>
  
  <tr>
    <td colspan="4" class="style25">
	<div align="left"><?php echo iconv ("TIS-620","UTF-8","�Ţ���  "); ?><input  name="sheet_num" type="text" size="2" >
	<div align="left"><b><?php echo iconv ("TIS-620","UTF-8","��ǹ�Ҫ��� ......"); ?> </b><?php echo iconv ("TIS-620","UTF-8","������ǡ�����ʵ��  ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ........"); ?></div>
	 </td>
  </tr>
  <tr>
    <td colspan="2" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","��� ȸ.0524.02.7/"); ?></b> <input class="style24" type="text" name="at" size ="4">  </td>
    <td colspan="2" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?></b>  
	 <select name="day_making" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
          </select>
          <select name="mount_making" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> 
		   <select name="year_making" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> </td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><b><?php echo iconv ("TIS-620","UTF-8","����ͧ  �����Ѵ��"); ?> </b>
	<input class="style24"  type="text" name="title"></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><?php echo iconv ("TIS-620","UTF-8","�����Թ"); ?> <input name="budget_name" type="radio" value="<?php echo iconv ("TIS-620","UTF-8","�Թ������ҳ"); ?>">
      <?php echo iconv ("TIS-620","UTF-8","�Թ������ҳ"); ?> 
        <input name="budget_name" type="radio" value="<?php echo iconv ("TIS-620","UTF-8","�Թ�����"); ?>"> 
        <?php echo iconv ("TIS-620","UTF-8","�Թ�����"); ?> <?php echo iconv ("TIS-620","UTF-8","��Шӻ�"); ?>
	<select name="budget_year" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2549"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2550"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2551"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2552"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2553"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2554"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2555"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2556"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2557"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2558"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2559"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2560"); ?></option>
           </select> .......<?php echo iconv ("TIS-620","UTF-8","�ҡ�����( ������ҹ / ����ѷ )"); ?><input class="style24"  type="text" name="shop_name" size = 50></td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><hr /><?php echo iconv ("TIS-620","UTF-8","���¹    "); ?> <b><?php echo iconv ("TIS-620","UTF-8","�����"); ?> </b></td>
  </tr>
  <tr>
    <td width="14%">&nbsp;</td>
    <td width="26%" class="style25"><?php echo iconv ("TIS-620","UTF-8","����"); ?> 
        <select class="style24" name="name_report" size="1">
        	<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM person  WHERE type = 0 OR type = 1";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
					$person_id = $row[0];
					$position = $row[2];
					$th_name = $row[3];
					$th_surname = $row[4];
	?>
<option value = "<?=$person_id ?>"><?php echo  $position .  $th_name ."     ".$th_surname ; ?> </option	><?}?>	
		 </select>
    </td>
    <td width="60%" class="style25"><?php echo iconv ("TIS-620","UTF-8","����§ҹ�ʹ����ͨ͢Ѵ����/��ҧ..."); ?> 
    <?php echo iconv ("TIS-620","UTF-8","  �����     �Ҥ�Ԫ����ǡ�������������"); ?> </td>
    <td>
    </td>
  </tr>
  <tr>
    <td colspan="4" class="style25"><?php echo iconv ("TIS-620","UTF-8","���ͧ�ҡ�դ�������..."); ?>  <input class="style24" type="text" name="reason"><?php echo iconv ("TIS-620","UTF-8","�����¡������Ҥҵ��仹��"); ?></td>
  </tr>
  <tr>
    <td width="14%" colspan="4">&nbsp;</td>
  </tr>
</table>
<table width="100%"  border="2" cellspacing="0" bordercolor="#000000">
  <tr>
    <td width="8%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ���"); ?> </div></td>
	 <td width="5%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","���ʾ�ʴ� GPSC"); ?> </div></td>
    <td width="40%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��¡�������������´"); ?> </div></td>
    <td width="12%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ˹���"); ?> </div></td>
    <td width="13%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�Ҥҫ���/��ҧ������ѧ�ش˹�����(�ҷ)"); ?> </div></td>
    <td width="13%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�Ҥҫ���/��ҧ���駹���ش˹�����(�ҷ)"); ?> </div></td>
	<td width="10%" class="style25"><div align="center"><?php echo iconv ("TIS-620","UTF-8","����Թ"); ?> </div></td>
  </tr>
  <tr>
    <td><div align="center"></div></td>
    <td class="style25">
      <div align="center" class="style25">
        <input class="style24" name="gpsc" type="text"  size = 8>
        </div></td>
    <td class="style25">
      <div align="center" class="style25" >
        <input class="style24" name="list" type="text" size = 60>
      </div></td>
    <td class="style25">
      <div align="center" class="style25">
        <input class="style24" name="unit_amount" type="text" size = 16>
      </div></td>
    <td><div align="center">
              <input class="style24" name="price_last" type="text" size = 16>
</div></td>
	  <td><div align="center">
              <input class="style24" name="price_this" type="text" size = 16>
</div></td>
	  <td><div align="center">
      </div></td>
  </tr>
 <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" class="style25"><div align="center"></div>      <div align="center"></div>      
      <div align="right"><?php echo iconv ("TIS-620","UTF-8","������Թ������"); ?> </div></td>
    <td class ="style25"><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
</table><FONT color=#FF0000><?php echo iconv ("TIS-620","UTF-8","( ��سҵ�Ǩ�ͺ�����Ţͧ��ҹ )"); ?></FONT>
		  <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","�׹�ѹ"); ?>">
          <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","¡��ԡ"); ?>">
 </form>

</body>
</html>
