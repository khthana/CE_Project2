<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo iconv ("TIS-620","UTF-8","��ԡ��ʴ�"); ?></title>
<style type="text/css">
<!--
.style24 {font-family: "CordiaUPC", Courier, mono; font-size: 16px; }
.style25 {
	font-family: CordiaUPC;
	font-size: 20px;
}
.style10 {font-family: CordiaUPC; font-size: 25px; font-style: normal; font-weight: bold; color: #000000; }
-->
</style>
</head>

<body>
<form method='post' action='Insert_material.php'>
<table width="100%"  border="0">
  <tr class="style25">
    <td width="80%"></td>
    <td width="20%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","Ẻ �.43 "); ?></div></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td><div align="center" class="style10"><?php echo iconv ("TIS-620","UTF-8","��ԡ��ʴ�"); ?></div></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr class="style25">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","��ǹ�Ҫ���"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","ʶҺѹ෤����վ�Ш��������Ҥس�����"); ?></td>
  </tr>
  <tr class="style25">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","˹��§ҹ"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","������ǡ�����ʵ��"); ?></td>
  </tr>
  <tr class="style25">
    <td></td>
	<td>&nbsp;</td>
    <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","�Ҥ/�ͧ"); ?></td>
    <td colspan="4"><?php echo iconv ("TIS-620","UTF-8","��ȡ�������������"); ?></td>
  </tr>
  <tr class="style25">
    <td width="13%" height="39"><?php echo iconv ("TIS-620","UTF-8","�Ţ���  "); ?><input name="sheet_num" type="text" size="8" maxlength="6"></td>
	<td width="43%">&nbsp;</td>
    <td width="4%"><?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?></td>
    <td width="6%"> 
		<select name="day_making" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
              </select> </td>
    <td width="5%" class="style25"><?php echo iconv ("TIS-620","UTF-8","��͹"); ?></td>
    <td width="5%">
		<select name="mount_making" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select> </td>
		   <td width="5%" class="style25"><?php echo iconv ("TIS-620","UTF-8","�.�."); ?></td>
    <td width="3%">
		<select name="year_making" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2006"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2007"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2008"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2009"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2010"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2011"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2012"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2013"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2014"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2015"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2016"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2017"); ?></option>
           </select> </td>
      </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td width="" class="style25"><?php echo iconv ("TIS-620","UTF-8","���¹  "); ?></td>
    <td colspan="2" class="style25"><?php echo iconv ("TIS-620","UTF-8","����դ�����ǡ�����ʵ��"); ?></td>
  </tr>
  <tr>
    <td class="style25"><dd><?php echo iconv ("TIS-620","UTF-8","����"); ?></td>
    <td width="15%" class="style25">
	<select name="bring_name" size="1">
         	<?php
	include("StartConnect.php");
	$SQL = "SELECT * FROM person  WHERE type = 0 OR type = 1";
	$table = mysql_query($SQL,$Conn) or die ("�������ö���¡�٢���������� computer_department ��");
	while($row = mysql_fetch_array($table))
	{
					$person_id = $row[0];
					$position = $row[2];
					$th_name = $row[3];
					$th_surname = $row[4];
	?>
<option value = "<?=$position ." ".$th_name ."     ".$th_surname ?>"><?php echo  $position .  $th_name ."     ".$th_surname ; ?> </option	><?}?>	
	</select>
	</td>
    <td width="80%" class="style25"><?php echo iconv ("TIS-620","UTF-8","�դ������ʧ����ԡ��ʴص����¡����Шӹǹ"); ?>
	<input name="amount" type="text" size="2" >
	<?php echo iconv ("TIS-620","UTF-8","��¡��"); ?>
	<?php echo iconv ("TIS-620","UTF-8","����  "); ?>
	<input name="bring_for" type="text" size="32" >
	</td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr class="style25">
    <td><?php echo iconv ("TIS-620","UTF-8","��е�ͧ�������觢ͧ�����ԡ�������"); ?>
		<?php echo iconv ("TIS-620","UTF-8","�ѹ���"); ?>
		 <select name="day_using" size="1">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
              </select>
		<?php echo iconv ("TIS-620","UTF-8","��͹"); ?>
		<select name="mount_using" size="1">
          <option value="1"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="2"><?php echo iconv ("TIS-620","UTF-8","����Ҿѹ��"); ?></option>
          <option value="3"><?php echo iconv ("TIS-620","UTF-8","�չҤ�"); ?></option>
          <option value="4"><?php echo iconv ("TIS-620","UTF-8","����¹"); ?></option>
          <option value="5"><?php echo iconv ("TIS-620","UTF-8","����Ҥ�"); ?></option>
          <option value="6"><?php echo iconv ("TIS-620","UTF-8","�Զع�¹"); ?></option>
          <option value="7"><?php echo iconv ("TIS-620","UTF-8","�á�Ҥ�"); ?></option>
          <option value="8"><?php echo iconv ("TIS-620","UTF-8","�ԧ�Ҥ�"); ?></option>
          <option value="9"><?php echo iconv ("TIS-620","UTF-8","�ѹ��¹"); ?></option>
          <option value="10"><?php echo iconv ("TIS-620","UTF-8","���Ҥ�"); ?></option>
          <option value="11"><?php echo iconv ("TIS-620","UTF-8","��Ȩԡ�¹"); ?></option>
          <option value="12"><?php echo iconv ("TIS-620","UTF-8","�ѹ�Ҥ�"); ?></option>
           </select>
		<?php echo iconv ("TIS-620","UTF-8","�.�."); ?>
		<select name="year_using" size="1">
          <option value="2549"><?php echo iconv ("TIS-620","UTF-8","2006"); ?></option>
          <option value="2550"><?php echo iconv ("TIS-620","UTF-8","2007"); ?></option>
          <option value="2551"><?php echo iconv ("TIS-620","UTF-8","2008"); ?></option>
          <option value="2552"><?php echo iconv ("TIS-620","UTF-8","2009"); ?></option>
          <option value="2553"><?php echo iconv ("TIS-620","UTF-8","2010"); ?></option>
          <option value="2554"><?php echo iconv ("TIS-620","UTF-8","2011"); ?></option>
          <option value="2555"><?php echo iconv ("TIS-620","UTF-8","2012"); ?></option>
          <option value="2556"><?php echo iconv ("TIS-620","UTF-8","2013"); ?></option>
          <option value="2557"><?php echo iconv ("TIS-620","UTF-8","2014"); ?></option>
          <option value="2558"><?php echo iconv ("TIS-620","UTF-8","2015"); ?></option>
          <option value="2559"><?php echo iconv ("TIS-620","UTF-8","2016"); ?></option>
          <option value="2560"><?php echo iconv ("TIS-620","UTF-8","2017"); ?></option>
           </select>
		<?php echo iconv ("TIS-620","UTF-8","����ͺ���  "); ?><input name="reciver_name" type="text" size="8" ><?php echo iconv ("TIS-620","UTF-8","  �繼���Ѻ��ʴ�᷹"); ?></td>
  </tr>
</table>
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr class="style25">
    <td width="5%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӴѺ"); ?></div>      <div align="center"></div></td>
    <td width="24%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��¡��"); ?></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div>      <div align="center"></div></td>
    <td colspan="3"><div align="center"></div>      <div align="center"></div>      <div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ"); ?></div></td>
    <td colspan="5"><div align="center"></div>      <div align="center"></div>      <div align="center"><?php echo iconv ("TIS-620","UTF-8","��ǹ�ͧ�ҹ��ʴ�"); ?></div></td>
    <td width="12%" rowspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�����˵�"); ?></div>      <div align="center"></div></td>
  </tr>
  <tr class="style25">
    <td width="5%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ԡ"); ?></div></td>
    <td width="5%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","����"); ?></div></td>
    <td width="9%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","��ҧ����"); ?></div></td>
    <td width="10%"><div align="center"><?php echo iconv ("TIS-620","UTF-8","���ʾ�ʴ�"); ?></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�鹷ع/˹���"); ?></div></td>
    <td colspan="2"><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ӹǹ�Թ"); ?></div></td>
  </tr>
  <tr class="style25">
    <td></td>
    <td><div align="center"></div>
        <div align="center"><input name="list" type="text" size="50" maxlength="64"></div>
        <div align="center"></div></td>
    <td><div align="center"><input name="bring_amount" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="bring_pay" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="bring_unpay" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="gpsc" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="capital_bath" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="capital_stang" type="text" size="8" maxlength="6"></div></td>
	<td><div align="center"> <input  name="bath" type="text" size="8" maxlength="6"></div></td>
    <td><div align="center"><input name="stang" type="text" size="8" maxlength="6"></div></td>
	<td ><div align="center"><input name="note" type="text" size="8" maxlength="6"></div></td>
  </tr>
  <tr class="style25">
    <td>&nbsp;</td>
    <td><?php echo iconv ("TIS-620","UTF-8","������Ť������ 7%"); ?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr class="style25">
    <td colspan="7">&nbsp;</td>
    <td><div align="center"> <?php echo iconv ("TIS-620","UTF-8","���"); ?></div></td>
    <td width="9%"><div align="center"></div></td>
    <td width="6%"><div align="center">-</div></td>
    <td><div align="center"></div></td>
  </tr>
</table>
<table width="100%"  border="0" cellspacing="2">
  <tr>
    <td class="style25"><table width="40%" align="left" cellspacing="0" bordercolor="#000000">
      <tr>
        <td width="53%"><div align="center" class="style25">
          <div align="left">
            <table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
              <tr>
                <td> <input  name="text_money" type="text" size="64" ></td> 	
              </tr>
            </table><?php echo iconv ("TIS-620","UTF-8","(�ӹǹ�Թ�繵���ѡ��)"); ?>
			  <FONT color=#FF0000><?php echo iconv ("TIS-620","UTF-8","( ��سҵ�Ǩ�ͺ�����Ţͧ��ҹ )"); ?></FONT>
		  <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","�׹�ѹ"); ?>">
          <input type="submit" name="Submit" class = "style24" value="<?php echo iconv ("TIS-620","UTF-8","¡��ԡ"); ?>">
          </div>
        </div></td>
        </tr>
    </table>    </td>
  </tr>
</table>
<table width="100%"  border="1" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����ԡ"); ?></div></td>
        </tr>
      <tr class="style25">
        <td width="11%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div></td>
        <td width="89%"><div align="left"></div></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>          <div align="center"></div></td>
        </tr>
    </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td width="100%">&nbsp;</td>
        </tr>
        <tr class="style25">
          <td><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���˹��˹��§ҹ"); ?></div></td>
        </tr>
        <tr class="style25">
          <td><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></td>
        </tr>
        <tr class="style25">
          <td><strong><?php echo iconv ("TIS-620","UTF-8","���Ѻ��觢ͧ件١��ͧ���º��������"); ?></strong></td>
        </tr>
      </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................����Ѻ��ʴ�"); ?></div></td>
        </tr>
        <tr class="style25">
          <td width="11%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div></td>
          <td width="89%"><div align="left"></div></td>
        </tr>
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>
              <div align="center"></div></td>
        </tr>
      </table></td>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���Ѵ�ѭ�վ�ʴ�"); ?></div></td>
        </tr>
      <tr class="style25">
        <td width="12%"><div align="left"><?php echo iconv ("TIS-620","UTF-8","���˹�"); ?></div>          <div align="left"></div></td>
        <td width="88%">&nbsp;</td>
      </tr>
      <tr class="style25">
        <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></td>
      </tr>
      <tr class="style25">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr class="style25">
        <td colspan="2"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����¢ͧ"); ?></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","�ѹ���....................................................."); ?></div>
            <div align="center"></div></td>
      </tr>
    </table>
      <table width="100%"  cellspacing="0">
        <tr class="style25">
          <td colspan="2"><strong><?php echo iconv ("TIS-620","UTF-8","͹��ѵ���������"); ?></strong></td>
        </tr>
        <tr class="style25">
          <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................�����觨���"); ?></div></td>
        </tr>
        <tr class="style25">
          <td width="49%"><div align="center">(.........................................................)</div></td>
          <td width="51%"><div align="left"></div></td>
        </tr>
        <tr class="style25">
          <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ���........................................."); ?></div>
          <div align="center"></div></td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="100%"  cellspacing="0">
      <tr class="style25">
        <td colspan="2"><strong><?php echo iconv ("TIS-620","UTF-8","�͡��ü�ҹ�ҹ�ѭ������"); ?></strong></td>
      </tr>
      <tr class="style25">
        <td colspan="2"><div align="left"><?php echo iconv ("TIS-620","UTF-8","ŧ����...................................................���˹�ҧҹ�ѭ��"); ?></div></td>
      </tr>
      <tr class="style25">
        <td width="55%"><div align="center">(.........................................................)</div></td>
        <td width="45%"><div align="left"></div></td>
      </tr>
      <tr class="style25">
        <td><div align="center"><?php echo iconv ("TIS-620","UTF-8","�ѹ���..............................................."); ?></div>
          <div align="center"></div></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>
</body>
</html>
