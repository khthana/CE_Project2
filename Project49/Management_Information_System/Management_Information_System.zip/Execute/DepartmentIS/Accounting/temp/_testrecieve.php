<?
		
			$person_id = $_POST["person"];
			print $person_id;

?>