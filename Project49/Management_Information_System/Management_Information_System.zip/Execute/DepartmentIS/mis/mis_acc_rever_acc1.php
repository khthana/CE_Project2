<? include ("_StartConnection.php")?>
<?include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
	<img src="../resource/img/titre-menu-user.gif" width="16" height="16"> ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
        
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
							  <td align="right" valign="top"><a href="mis_acc_rever_acc1_paper1.php">&nbsp;<u>�����͡���</u></a> 
                                </td>
                              </tr>
                              <tr>
                                <td align="center" valign="top">
                                  <DIV align=center><U><B>��¡�ô�ҹ����Թ (�ѭ�ҡ������Թ</B> <B>) �Ҥ�Ԫ����ǡ�������������</B></U></DIV></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="715" border="0">
								<?				{$sql = "SELECT * FROM loaning";}			  ?>		
                                  <tr>
                                    <th width="44" scope="col" bgcolor="#FFFFCC"><b>�Ţ���</b></th>
                                    <th width="120" scope="col" bgcolor="#FFFFCC">�ѹ�����ѭ������Թ</th>
                                    <th width="143" scope="col" bgcolor="#FFFFCC">�˵ؼŷ�����</th>
                                    <th width="141" scope="col" bgcolor="#FFFFCC">������</th>
                                    <th width="76" scope="col" bgcolor="#FFFFCC">�ӹǹ�Թ</th>
                                    <th width="73" scope="col" bgcolor="#FFFFCC">���</th>
                                    <th width="72" scope="col" bgcolor="#FFFFCC">�������</th>
                                  </tr>
								  <?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$borrow_num= $row[borrow_num];
												$money=$row[money];
												$borrower_name = $row[borrower_name];
												$day_making = $row[day_making];
												$day_expire = $row[day_expire];
												$fr_money = $row[fr_money];
												$make_clear = $row[make_clear];
												$borrow_for = $row[borrow_for];
												
												?>						  
                                  <tr>
                                    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center">
											<? 								
												print ($borrow_num);
											?></div></td>																
                                    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($day_making)?></div></td>
                                    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($borrow_for)?></td>
                                    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp; <? print($borrower_name)?></td>
                                    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($money)?></td>
                                    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($fr_money)?></td>
                                    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($make_clear)?></td>
                                  </tr>
								    <? } ?>
                                </table>
								<table width="717" border="0"  align="center">
                                      <tr>
                                         <th width="91%" scope="col"><div align="right">������ &nbsp;<? print ($num_rows)?> &nbsp; ��¡�� </div></th>
                                      </tr>
                                  </table>
                     	</td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
