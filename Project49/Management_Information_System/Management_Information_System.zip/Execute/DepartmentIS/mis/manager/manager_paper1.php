<? 
		session_start();	
		include ("_StartConnection.php");
		include("_CheckSession.php"); 
		?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
.style4 {color: #000000}
-->
</style>
</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">

  
    
              </table></td>
                          <tr> 
                <td align="center" valign="top">&nbsp;
                                    <div align="center"><strong>��ª��ͼ������� �Ҥ�Ԫ����ǡ�������������</strong></div></td>
                              </tr>
							  
                              <tr>
                                <td align="left" valign="top">
									<br>
									<table width="633" border="1"align="center" cellpadding="0" cellspacing="0" bordercolor="#000000" bgcolor="#FFFFFF">
							  <?
							  				$Tcode = $_POST["position"];	
											$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];			
											$mobile	= $_POST["mobile"];										
										   
											 $sql=$_SESSION["F_SQL"];
							  ?>
							  <tr bordercolor="#FF0000" bgcolor="#CCCCCC">
							  <td width="146" align="left" valign="top" bordercolor="#000000"><span class="style1">���˹觼�������</span></td>
								<td width="133" align="left" valign="top" bordercolor="#000000"><b>����</b></td>
								<td width="163" align="left" valign="top" bordercolor="#000000"><b>���ʡ��</b></td> 
								<td width="163" align="left" valign="top" bordercolor="#000000"><b>���Ѿ��</b></td>
								<td width="163" align="left" valign="top" bordercolor="#000000"><div align="center"><b>�����˵�</b></div></td> 
				              </tr>
							 <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");			
									$num_rows = mysql_num_rows($table);						 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$type1=$row[type];
												$mobile=$row[mobile];
											?>						  
                              <tr>
	                                    <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF" >
								          <span class="style4">
								          <?
									if ($type1=="0")
										print "���˹���Ҥ�Ԫ��";
									elseif ($type1=="1")
										print "�Ҩ����";
									elseif ($type1=="2")
										print "���˹�ҷ��෤�Ԥ�";			
									elseif ($type1=="3")
										print "���˹�ҷ���ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "���˹�ҷ���á��";	
									elseif ($type1=="5")	
										print "���˹�ҷ�����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
									else 
										print "�ѧ����кص��˹�";																													
								?>
					            </span></td>
								<td align="left" valign="top" ><span class="style4"><? print($position1) ?><? print($th_name) ?></span></td>
								<td align="left" valign="top"><span class="style4"><? print($th_surname) ?></span></td> 				
								<td align="left" valign="top" ><span class="style4">
							    <? 
									if ($mobile=="" or $mobile=="-") 
										print "�����������";
									else
										print $mobile;								
								?>
								</span></td>
								<td align="left" valign="top" >&nbsp;</td> 	
				              </tr>
							  <? } ?>
							  </table></td>
                              </tr>
                              <tr>
							  
                                <td><div align="right">								
                                  <table width="633" border="0"  align="center" bordercolor="#000000" bgcolor="#FFFFFF">
                                    <tr>
                                      <td width="633"><div align="right"><strong>�������÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ</strong></div></td>
                                    </tr>
                                  </table>								  
                                  </div></td>
								  
                              </tr>
                             
                            </table></td>
                            
                          </tr>
                          
                    
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
         
        
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col">&nbsp;</td>
  </tr>
</table>
</body>
</html>
