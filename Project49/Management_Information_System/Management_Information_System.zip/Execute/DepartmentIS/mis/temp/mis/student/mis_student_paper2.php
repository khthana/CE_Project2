<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody" >
<div align="left">
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td align="left" valign="top">&nbsp;
          <div align="center"><strong>��ª��͹ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div>
        <br></td>
    </tr>
  <td><table width="633"  border="1" align="center" bordercolor="#FFFFFF" bgcolor="#000000">
        <?	{$sql = "SELECT * FROM student where  student_id LIKE '%$Tcode1%' AND th_name LIKE '%$Tname%' AND th_surname LIKE '%$Tsname%' AND gender LIKE '%$gender%' AND telephone_contact LIKE '%$T_phone%'";}	  
	?> 
    <tr>
      <td width="86" align="left" valign="top"  bgcolor="#CCCCCC"><div align="center"><b> ���ʹѡ�֡��</b></div></td>
      <td width="123" align="left" valign="top" bgcolor="#CCCCCC"><b>����</b></td>
      <td width="109" align="left" valign="top" bgcolor="#CCCCCC"><b>���ʡ��</b></td>
      <td width="46" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>��</b></div></td>
      <td width="90" align="left" valign="top" bgcolor="#CCCCCC"><b>���Ѿ��</b></td>
      <td width="40" align="left" valign="top" bgcolor="#CCCCCC"><b>GPA</b></td>
      <td width="93" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>ʶҹ�</b></div></td>
    </tr>
    <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$student_id= $row[student_id];
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$gender=$row[gender];
												$telephone_contact=$row[telephone_contact];
										?>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($student_id) ?></div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? print($pre_name)?>&nbsp;<? print($th_name)?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? print($th_surname) ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? 
																															if($gender=="���")
																																print ("���") ;
																															else
																																print ("˭ԧ");
																															?></div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><?
																								if ($telephone_contact==""  or  telephone_contact =="-") 
																									print "�����������";
																								else
																									print $telephone_contact;								
																								?>      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? print("3.5") ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <? } ?>
  </table></td>
  </table>
</div>
</body>
</html>
