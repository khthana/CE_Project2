<?
		$sql ="select * from student where student_id ='$person_id'";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
	
		$birthday = $row[birthday];	
		//$birth_day= $row[birth_day];	
		//$birth_month= $row[birth_month];
		//$birth_year= $row[birth_year];
		$birth_place= $row[birth_place];
		$race= $row[race];
		$nationality= $row[nationality];
		$religion= $row[religion];
		$blood= $row[blood];

		$number_static= $row[number_static];
		$group_static= $row[group_static];
		$lane_static= $row[lane_static];
		$road_static= $row[road_static];
		$district_static= $row[district_static];
		$region_static= $row[region_static];
		$province_static= $row[province_static];
		$postalcode_static= $row[postalcode_static];
		$telephone_static= $row[telephone_static];

		$number_contact = $row[number_contact];                
		$group_contact = $row[group_contact];                
		$lane_contact = $row[lane_contact];               
		$road_contact = $row[road_contact];             
		$district_contact  = $row[district_contact];              
		$region_contact = $row[region_contact];              
		$province_contact  = $row[province_contact];               
		$postalcode_contact  = $row[postalcode_contact];               
		$telephone_contact = $row[telephone_contact];

		$habital = $row[habital];
		$status_parent= $row[status_parent];
		$relatives= $row[relatives]; //�繺صä����
		$alive= $row[alive]; //�ժ��Ե����
		$studying= $row[studying]; //���ѧ�֡������
		$salary= $row[salary];

//���ͪҵ�
	if ($race != "") {
		if ($race == "��"){
			$race1 = "checked";
		}
		else if ($race =="�չ"){
			$race2 = "checked";
		}
		else{
			$race3 = "checked";
			$racestatus = $race;
		}
	}
//�ѭ�ҵ�
	if ($nationality != "") {
		if ($nationality == "��"){
			$nationality1 = "checked";
		}
		else if ($nationality =="�չ"){
			$nationality2 = "checked";
		}
		else{
			$nationality3 = "checked";
			$nationalitystatus = $race;
		}
	}
//��ʹ�
	if ($religion != "") {
		if ($religion == "�ط�"){
			$religion1 = "checked";
		}
		else if ($religion =="���ʵ�"){
			$religion2 = "checked";
		}
		else if ($religion =="������"){
			$religion3 = "checked";
		}
		else{
			$religion4 = "checked";
			$religionstatus = $religion;
		}
	}
	//�������Ե
		if ($blood != ""){
			if($blood == "A"){
				$blood1 = "checked";
			}
			else if ($blood =="B") {
				$blood2 = "checked";
			}
			else if ($blood =="AB") {
				$blood3 = "checked";
			}
			else{
				$blood4 = "checked";
			}
		}
	
	//�ѹ�Դ
	if($birthday == "") {
		$day = "";
		$month ="";
		$year = "";
	}
	else {
		list($year,$month,$day) = explode("-",$birthday);
		$birth_year =$year + 543 ;
		$birth_month = $month;
		$birth_day = $day;
		
	}


	//�Ѩ�غѹ���������Ѻ
	if ($habital != "") {
		if ($habital == "�Դ�-��ô�"){
			$habital1 = "checked";
		}
		else if ($habital =="�Դ�"){
			$habital2 = "checked";
		}
		else if ($habital =="��ô�"){
			$habital3 = "checked";
		}
		else if ($habital =="��ҹ���/��ͧ���"){
			$habital4 = "checked";
		}
		else if ($habital =="�;ѡʶҺѹ"){
			$habital5 = "checked";
		}
		else if ($habital =="�;ѡ�͡��"){
			$habital6 = "checked";
		}
		else if ($habital =="�ҵ�"){
			$habital7 = "checked";
		}
		else if ($habital =="�Ѵ"){
			$habital8 = "checked";
		}
		else{
			$habital9 = "checked";
			$habitalstatus = $habital;
		}
	}
//ʶҹ��Ҿ���ʢͧ�Դ�-��ô�
		if ($status_parent != ""){
			if($status_parent == "������¡ѹ"){
				$status_parent1 = "checked";
			}
			else if ($status_parent =="�Դ�-��ôҶ֧�����") {
				$status_parent2 = "checked";
			}
			else if ($status_parent =="�ԴҶ֧�����") {
				$status_parent3 = "checked";
			}
				else if ($status_parent =="��ôҶ֧�����") {
				$status_parent4 = "checked";
			}
				else if ($status_parent =="����") {
				$status_parent5 = "checked";
			}
				else if ($status_parent =="�¡�ѹ�������Ф������繷ҧ�Ҫվ") {
				$status_parent6 = "checked";
			}
			else{
				$status_parent7 = "checked";
			}
		}
// �ѡ�֡���������ҡ��÷ӧҹ�������
	if($salary == 0){
		$salary1 = "checked";
	}
	else {
		$salary2 = "checked";
		$salarystatus = $salary;
	}
		
?>