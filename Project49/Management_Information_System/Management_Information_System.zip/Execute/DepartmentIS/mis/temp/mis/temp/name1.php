<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-874">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 11">
<meta name=Originator content="Microsoft Word 11">
<link rel=File-List
href="��ª��ͤ�Ҩ����%20�Ҥ�Ԫ����ǡ�������������.files/filelist.xml">
<title>name1</title>
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>CIA</o:Author>
  <o:LastAuthor>CIA</o:LastAuthor>
  <o:Revision>1</o:Revision>
  <o:TotalTime>7</o:TotalTime>
  <o:Created>2007-01-24T17:32:00Z</o:Created>
  <o:LastSaved>2007-01-24T17:40:00Z</o:LastSaved>
  <o:Pages>1</o:Pages>
  <o:Words>15</o:Words>
  <o:Characters>90</o:Characters>
  <o:Lines>1</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>104</o:CharactersWithSpaces>
  <o:Version>11.5606</o:Version>
 </o:DocumentProperties>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:ApplyBreakingRules/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
  </w:Compatibility>
  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="156">
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Angsana New";
	panose-1:2 2 6 3 5 4 5 2 3 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:16777219 0 0 0 65537 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	mso-bidi-font-size:14.0pt;
	font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Angsana New";}
@page Section1
	{size:595.3pt 841.9pt;
	margin:72.0pt 3.0cm 72.0pt 2.0cm;
	mso-header-margin:35.45pt;
	mso-footer-margin:35.45pt;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:���ҧ����;
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-ansi-language:#0400;
	mso-fareast-language:#0400;
	mso-bidi-language:#0400;}
table.MsoTableGrid
	{mso-style-name:��鹵��ҧ;
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	border:solid windowtext 1.0pt;
	mso-border-alt:solid windowtext .5pt;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid windowtext;
	mso-border-insidev:.5pt solid windowtext;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";
	mso-ansi-language:#0400;
	mso-fareast-language:#0400;
	mso-bidi-language:#0400;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="2050"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US style='tab-interval:36.0pt'>

<div class=Section1>

<p class=MsoNormal><b><u><span lang=TH style='font-size:24.0pt;font-family:
"Angsana New";mso-ascii-font-family:"Times New Roman";mso-hansi-font-family:
"Times New Roman"'>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</span></u></b><b><u><span
style='font-size:24.0pt'><o:p></o:p></span></u></b></p>
<td><table width="674"  border="0"align="left" bordercolor="#FFFFFF" bgcolor="#000000">
    <?	{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6')";}		 ?> 
	
	 <?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$telephone1=$row[mobile];
												$person_id=$row[person_id];
												$email = $row[email];
												?>
<p class=MsoNormal><b><i><u><span style='font-size:24.0pt'><o:p><span
 style='text-decoration:none'>&nbsp;</span></o:p></span></u></i></b></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0 width=679
 style='width:509.4pt;border-collapse:collapse;border:none;mso-border-alt:solid windowtext .5pt;
 mso-yfti-tbllook:480;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 .5pt solid windowtext;mso-border-insidev:.5pt solid windowtext'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:18.9pt'>
  <td width=127 valign=top style='width:95.4pt;border:solid windowtext 1.5pt;
  background:#D9D9D9;padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span lang=TH style='font-size:18.0pt;font-family:"Angsana New"'>���˹��Ԫҡ��<o:p></o:p></span></b></p>
  </td>
  <td width=118 valign=top style='width:88.2pt;border:solid windowtext 1.5pt;
  border-left:none;mso-border-left-alt:solid windowtext 1.5pt;background:#D9D9D9;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span lang=TH style='font-size:18.0pt;font-family:"Angsana New"'>����</span></b><b><span
  style='font-size:18.0pt;font-family:"Angsana New"'><o:p></o:p></span></b></p>
  </td>
  <td width=122 valign=top style='width:91.8pt;border:solid windowtext 1.5pt;
  border-left:none;mso-border-left-alt:solid windowtext 1.5pt;background:#D9D9D9;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span lang=TH style='font-size:18.0pt;font-family:"Angsana New"'>���ʡ��</span></b><b><span
  style='font-size:18.0pt;font-family:"Angsana New"'><o:p></o:p></span></b></p>
  </td>
  <td width=84 valign=top style='width:63.0pt;border:solid windowtext 1.5pt;
  border-left:none;mso-border-left-alt:solid windowtext 1.5pt;background:#D9D9D9;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span style='font-size:18.0pt;font-family:"Angsana New"'>Email<o:p></o:p></span></b></p>
  </td>
  <td width=108 valign=top style='width:81.0pt;border:solid windowtext 1.5pt;
  border-left:none;mso-border-left-alt:solid windowtext 1.5pt;background:#D9D9D9;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span lang=TH style='font-size:18.0pt;font-family:"Angsana New"'>���Ѿ��<o:p></o:p></span></b></p>
  </td>
  <td width=120 valign=top style='width:90.0pt;border:solid windowtext 1.5pt;
  border-left:none;mso-border-left-alt:solid windowtext 1.5pt;background:#D9D9D9;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.9pt'>
  <p class=MsoNormal><b><span lang=TH style='font-size:18.0pt;font-family:"Angsana New"'>�����˵�</span></b><b><span
  style='font-size:18.0pt;font-family:"Angsana New"'><o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:18.25pt'>
  <td width=127 valign=top style='width:95.4pt;border-top:none;border-left:
  solid windowtext 1.5pt;border-bottom:solid windowtext 1.5pt;border-right:
  solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;mso-border-alt:
  solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span>
    <? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?>
  </p>
  </td>
  <td width=118 valign=top style='width:88.2pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:1.5pt;mso-border-left-alt:.5pt;mso-border-bottom-alt:1.5pt;
  mso-border-right-alt:.5pt;mso-border-color-alt:windowtext;mso-border-style-alt:
  solid;padding:0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span><? print($th_name) ?></p>
  </td>
  <td width=122 valign=top style='width:91.8pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:1.5pt;mso-border-left-alt:.5pt;mso-border-bottom-alt:1.5pt;
  mso-border-right-alt:.5pt;mso-border-color-alt:windowtext;mso-border-style-alt:
  solid;padding:0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span><? print($th_surname) ?></p>
  </td>
  <td width=84 valign=top style='width:63.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:1.5pt;mso-border-left-alt:.5pt;mso-border-bottom-alt:1.5pt;
  mso-border-right-alt:.5pt;mso-border-color-alt:windowtext;mso-border-style-alt:
  solid;padding:0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span>
    <? 
								if($email=="-" or "")
										print "����� Email";
								else
										print $email;
										?>
  </p>
  </td>
  <td width=108 valign=top style='width:81.0pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-top-alt:1.5pt;mso-border-left-alt:.5pt;mso-border-bottom-alt:1.5pt;
  mso-border-right-alt:.5pt;mso-border-color-alt:windowtext;mso-border-style-alt:
  solid;padding:0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span>
    <?		
									if ($telephone1=="-" or "") 
										print "�����������";
									else
										print $telephone1;								
								?>
								<td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
	</td>
    <? } ?>
  </table>
  </p>
  </td>
  <td width=120 valign=top style='width:90.0pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.5pt;
  mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:18.25pt'>
  <p class=MsoNormal><span style='font-size:18.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal><span style='font-size:24.0pt;font-family:"Angsana New"'><o:p>&nbsp;</o:p></span></p>

</div>

</body>

</html>
