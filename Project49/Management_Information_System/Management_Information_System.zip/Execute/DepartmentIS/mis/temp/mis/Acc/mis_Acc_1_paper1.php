<? include ("_StartConnection.php")?>
<? include ("_CheckSession.php")?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
 
  
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr>
								<td align="left" valign="top"><div align="center"><u><b>�����Ŵ�ҹ��èͧ�Թ (�ѹ�֡�����Ѵ��) �Ҥ�Ԫ����ǡ�������������</b></u></div></td>
                              </tr>
                              <tr>
                                <!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
								
								<td align="left" valign="top"><br>
								  
								<!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
                                  
								<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->
                                    <table width="633" border="0" align="center" bgcolor="#000000">         
									  <?								
										{$sql ="select * from reserve_money ";}
							  ?>		<!--$sql = 'SELECT * FROM `reserve_money` LIMIT 0, 30 '; -->
                                      <tr>
                                        <th width="34" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ӴѺ</div></th>
                                        <th width="49" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�Ţ ȸ. </div></th>
                                        <th width="72" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ѹ���</div></th>
                                        <th width="101" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">����ͧ</div></th>
                                        <th width="63" align="left" bgcolor="#CCCCCC" scope="col">����Шӻ�</th>
                                        <th width="71" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ӹǹ�Թ</div></th>
                                        <th width="141" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">���ͧ�Թ</div></th>
                                        <th width="68" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ѹ���͹��ѵ�</div></th>
                                      </tr>
									  
									  <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$sheet_num= $row[sheet_num];
												$budget_year=$row[budget_year];
												$st_num= $row[st_num];			
												$title=$row[title];	
												$date_making=$row[date_making];				
												$money=$row[money];	
												$name_reserve=$row	[name_reserve];		
												$date_using=$row[date_using];											
										?>						  
                                      <tr>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($sheet_num)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($st_num)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><? print($date_using)?></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><? print($title)?></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($budget_year)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><? print($money)?></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><? print($name_reserve)?></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><?
											if ($date_using==$date_making)
											print "�ѧ���͹��ѵ�";
											 else print($date_using)?></td>
                                      </tr>
									  <? } ?>		
                                    </table>
									
									<table width="633" border="0"  align="center">
                                      <tr>
                                         <th width="91%" scope="col"><div align="right">�ͧ�Թ������ &nbsp;<? print ($num_rows)?> &nbsp; ��¡�� </div></th>
                                      </tr>
                                    </table>
									<p>&nbsp;
									  
									  
							            </p></td>
                              </tr>

                            </table>
                
              </table></td>
          </tr>
         
        </tbody>
      </table></td>
  </tr>

</table>
</body>
</html>
