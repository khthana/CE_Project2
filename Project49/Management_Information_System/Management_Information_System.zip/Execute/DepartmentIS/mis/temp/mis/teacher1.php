<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="right" valign="top">&nbsp;<a href="teacher/mis_teacher_paper1.php"><u>�����͡��� </u></a>
                                </div>
                                  <div align="center"><strong>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</strong></div><br></td></tr>
                                  
							  <td>
							  
							  <table width="633"align="center" >
																				   
									<?				{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6')";}			  ?>						
							
							  <tr>
                                <td width="206" align="left" valign="top"  bgcolor="#FFFFCC"><b>���˹��Ԫҡ��</b></td>
								<td width="195" align="left" valign="top" bgcolor="#FFFFCC"><b>����</b></td>
								<td width="243" align="left" valign="top" bgcolor="#FFFFCC"><b>���ʡ��</b></td> 
								<td width="243" align="left" valign="top" bgcolor="#FFFFCC"><b>Email</b></td>
								<td width="243" align="left" valign="top" bgcolor="#FFFFCC"><b>���Ѿ��</b></td> 
				              </tr>
							 
							<?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$telephone1=$row[mobile];
												$person_id=$row[person_id];
												$email = $row[email];
												?>						  
                              <tr>
                                <td align="left" valign="top" bgcolor="#FFFFEA"><? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA">
								<a href="../mis/teacher/teacher_info1.php?person_id=<? print($person_id) ?> " target="_blank"  ><? print($th_name) ?></a></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_surname) ?></td> 
								<td align="left" valign="top" bgcolor="#FFFFEA">
								<? 
								if($email=="-" or "")
										print "����� Email";
								else
										print $email;
										?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? 							
									if ($telephone1=="-" or "") 
										print "�����������";
									else
										print $telephone1;								
								?></td> 								
				              </tr>
							  <? } ?>
							  </table>                              
									   <table width="465" align="right"  height="5" border="0">
                                          <tr>
                                            <td width="380" height="28" align="right" valign="top"  bgcolor="#FFFFFF"><strong>��Ҩ��������� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ </strong></td>
											<td width="75" height="28" align="left" valign="top"  bgcolor="#FFFFFF">
											<form name="form1" method="post"  action="mis_teacher_search.php">									  
											  <input type="submit" name="Submit"  height="10" value="Search">
											</form></td>			   																				
                                          </tr>
                                    </table>	 									  
								  </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
