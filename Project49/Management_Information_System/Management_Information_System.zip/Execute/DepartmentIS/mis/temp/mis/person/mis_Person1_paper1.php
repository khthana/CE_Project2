<? include ("_StartConnection.php")?>
<? include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title></head>

<body class = "classbody" >
<table width="800" height="39" border="0" align="center" cellpadding="0" cellspacing="0">
  

  <tr>
    <td height="39" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
      <tbody>

                <td valign=top><table cellspacing=0 cellpadding=0 width="100%" border=0>
                  <tbody>
                          <td align="right" valign="top"><div align="center"><strong>��ª��ͺؤ�ҡ� �Ҥ�Ԫ����ǡ�������������</strong></div></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top"><br>
                                      <table width="633"  border="0"align="center" bgcolor="#000000"  >
                                        <?
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5')";}
							  ?>
                                        <tr>
                                          <td width="112" align="left" valign="top" bordercolor="#000000"  bgcolor="#999999"><b>���˹�</b></td>
                                          <td width="106" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><b>����</b></td>
                                          <td width="105" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><b>���ʡ��</b></td>
                                          <td width="82" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><b>���Ѿ��</b></td>
                                          <td width="82" align="center" valign="top" bordercolor="#000000" bgcolor="#999999"><div align="center"><strong>�����˵�</strong></div></td>
                                        </tr>
                                        <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);							 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$th_prename=$row[th_prename];
												$position1=$row[position];
												$prename=$row[prename];
												$type1=$row[type];
												$mobile=$row[mobile];
											?>
                                        <tr>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><?
									if ($type1=="0")
										print "���˹���Ҥ�Ԫ�";
									elseif ($type1=="1")
										print "�Ҩ����";
									elseif ($type1=="2")
										print "���˹�ҷ��෤�Ԥ�";			
									elseif ($type1=="3")
										print "���˹�ҷ���ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "���˹�ҷ���á��";	
									elseif ($type1=="5")	
										print "���˹�ҷ�����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
									else 
										print "�ѧ����кص��˹�";																								
								?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? print($prename) ?>&nbsp; <? print($th_name) ?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? print($th_surname) ?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? 	
																														if ($mobile=="" or $mobile=="-") 
																																print "�����������";
																															else
																																print $mobile;	?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;</td>
                                        </tr>
                                        <? } ?>
                            </table>
                            <table width="543" align="right"  height="5" border="0">
                                        <tr>
                                          <td width="454" height="28" align="right" valign="top"  bgcolor="#FFFFFF"><strong>���ҡ÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ </strong></td>
                                          <td width="79" height="28" align="left" valign="top"  bgcolor="#FFFFFF">&nbsp;</td>
                                        </tr>
                            </table></td>
                        </tr>
                        
                      </table></td>
  
                    </tr>
                    
                  </tbody>
                </table></td>
              </tr>
          </table>
</td>
        </tr>
      
      </tbody>
    </table></td>
  </tr>
  
</table>
</body>
</html>
