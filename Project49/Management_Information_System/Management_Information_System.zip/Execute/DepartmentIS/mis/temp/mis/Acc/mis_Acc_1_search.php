<? include ("_StartConnection.php")?>
<? include ("_CheckSession.php")?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../../resource/img/bar_c.gif" scope="col"><div align="left">
	<img src="../../resource/img/titre-menu-user.gif" width="16" height="16"> ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
        
    <td width="10" background="../r" scope="col"><img src="../../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="right" valign="top">&nbsp;<a href="manager/manager_paper1.php"><u>�����͡���</u></a>
                              </tr>

                              <tr>
								<td align="left" valign="top"><div align="center"><u><b>�����Ŵ�ҹ��èͧ�Թ (�ѹ�֡�����Ѵ��) �Ҥ�Ԫ����ǡ�������������</b></u></div></td>
                              </tr>
							  <?
							  				$sheet_num = $_POST["sheet_num"];	
											$st_num = $_POST["st_num"];	
											$date_making = $_POST["date_making"];		
											$title=$_POST["title"];	
											$budget_year=$_POST["budget_year"];		
											$money=$_POST["money"];	
											$name_reserve=$_POST["name_reserve"];															
		if(empty($sheet_num) AND empty($st_num) AND empty($date_making) AND empty($title) AND empty($budget_year) AND empty($money))
					{$sql ="select * from reserve_money ";}
		if (!empty($sheet_num) AND empty($st_num) AND empty($date_making) AND empty($title) AND empty($budget_year) AND empty($money))
					{$sql ="select * from reserve_money where sheet_num Like '".$sheet_num."%'";}
		if (empty($sheet_num) AND !empty($st_num) AND empty($date_making) AND empty($title) AND empty($budget_year) AND empty($money))
					{$sql ="select * from reserve_money where st_num Like '".$st_num."%'";}											
		if (empty($sheet_num) AND empty($st_num) AND !empty($date_making) AND empty($title) AND empty($budget_year) AND empty($money))
					{$sql ="select * from reserve_money where date_making Like '".$date_making."%'";}	
		if (empty($sheet_num) AND empty($st_num) AND empty($date_making) AND !empty($title) AND empty($budget_year) AND empty($money))
					{$sql ="select * from reserve_money where title Like '".$title."%'";}	
		if (empty($sheet_num) AND empty($st_num) AND empty($date_making) AND empty($title) AND empty($budget_year) AND !empty($money))
				{	if($money=='�����')
							{$sql ="SELECT * FROM reserve_money where (budget_year IS NULL or budget_year='-')";}
					else
							{$sql ="SELECT * FROM student where (budget_year Like '".$money."%')";}
								}
		//if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND !empty($Tgrade)){$sql ="select * from student where th_surname Like '".$Tgrade."%'";}													
		//if (empty($Tcode) AND empty($Tname) AND empty($Tsname)!empty($Tgrade)){$sql ="select * from student where th_surname Like ".$Tgrade;}				
		if (!empty($sheet_num) AND !empty($st_num) AND empty($date_making) AND empty($title) AND empty($budget_year) AND empty($money))
		    {$sql ="select * from student where sheet_num Like '".$sheet_num."%'"." AND st_num Like '".$st_num."%'";}											
							  ?>	  
							  
							  
							  
                              <tr>
                                <!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
								
								<td align="left" valign="top"><br>
								  
								<!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
                                  
								<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->
                                    <table width="91%" border="0" align="center">         
											                             
                                      <tr>
									   <form name="form1" method="post" action="../Acc/mis_Acc_1_search.php">							
                                        <th height="28" align="left" scope="col"><input name="sheet_num" type="text" size="2"></th>
                                        <th height="28" scope="col" align="left"><input name="st_num" type="text" size="5"></th>
                                        <th height="28" scope="col" align="left"><input name="date_making" type="text" size="6"></th>
                                        <th scope="col" align="left"><input name="textfield" type="text" size="12"></th>
                                        <th height="28" scope="col" align="left"><input name="title" type="text" size="10"></th>
                                        <th height="28" scope="col" align="left"><input name="budget_year" type="text" size="6"></th>
                                        <th height="28" scope="col" align="left"><input name="money" type="text" size="8"></th>
                                        <th height="28" scope="col" align="left"><input name="name_reserve" type="text" size="20"></th>
                                        <th height="28" scope="col" align="left"><input name="submit" type="submit" value="����"></th>
										</form>
                                      </tr>
                                      <tr>
                                        <th width="32" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�ӴѺ</div></th>
                                        <th width="48" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�Ţ ȸ. </div></th>
                                        <th width="70" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�ѹ��������ͧ</div></th>
                                        <th width="89" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�ѹ���͹��ѵ�</div></th>
                                        <th width="89" scope="col" bgcolor="#FFFFCC" align="left">����ͧ�����Ѵ��</th>
                                        <th width="69" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">����Шӻ�</div></th>
                                        <th width="74" scope="col" bgcolor="#FFFFCC" align="left">�ӹǹ�Թ</th>
                                        <th width="120" scope="col" bgcolor="#FFFFCC" align="left">���ͧ�Թ</th>
                                        <th width="101" scope="col" align="left">&nbsp;</th>
                                      </tr>
									  
									  <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$sheet_num= $row[sheet_num];
												$budget_year=$row[budget_year];
												$st_num= $row[st_num];			
												$title=$row[title];	
												$date_making=$row[date_making];				
												$money=$row[money];	
												$name_reserve=$row	[name_reserve];		
												$date_using=$row[date_using];
										?>					  
                                      <tr>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($sheet_num)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($st_num)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($date_using)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><?
											if ($date_using==$date_making)
											print "�ѧ���͹��ѵ�";
											 else print($date_using)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><? print($title)?></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($budget_year)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($money)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><? print($name_reserve)?></td>
                                        <td>&nbsp;</td>
                                      </tr>
									  <? } ?>		
                                    </table>
									<!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
									<table width="465" align="right"  height="5" border="0">
                                          <tr>
                                            <td width="379" height="28" align="right" valign="top"  bgcolor="#FFFFFF"><strong>��¡�÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��¡�� </strong></td>
											<td width="76" height="28" align="left" valign="top"  bgcolor="#FFFFFF">&nbsp;</td>			   																				
                                          </tr>
                                    </table>	 
									<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->														
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
