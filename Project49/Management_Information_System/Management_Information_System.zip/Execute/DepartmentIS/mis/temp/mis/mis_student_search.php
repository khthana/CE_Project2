<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title></head>
<body class = "classbody" >

<table width="800" height="364" border="0" align="center" cellpadding="0" cellspacing="0">

     <tr>  <th height="97" colspan="3" scope="col"><div align="right"></div>
         <div align="center"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th></tr>
   <tr>  <td width="11" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="779" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="18" height="21"> 
    ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td></tr>
  
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td width="784" valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=10 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td height="161" valign=top  background="../resource/img/border_footer04.jpg"><img  height=8 src="../resource/img/border_footer04.jpg" width=8></td>                     
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              
                                <tr><td align="left" valign="top"><div align="left"><? include ("_menu.php") ?></div></td></tr>
<td align="right" valign="top">&nbsp;
<a href="student/mis_student_paper2.php?<?php echo "Tcode1=$Tcode1&Tname=$Tname&Tsname=$Tsname&Tsex=$Tsex&T_phone=$T_phone";?>"><u>�����͡���</u></a>
                                 <!--<td align="right" valign="top">&nbsp;<a href="student/mis_student_paper1.php"><u>�����͡��� </u></a> &Tgrade=$Tgrade-->
								 <div align="center"><strong>��ª��͹ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div><br></td></tr>			     					  
							      <td>					
							
							
							<table width="633" align="center"  border="0" cellpadding="0">
							  <?
							  				$Tcode1 = $_POST["Tcode"];	
											$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];		
											$Tsex=$_POST["Tsex"];	
											$Tgrade=$_POST["Tgrade"];		
											$T_phone=$_POST["T_phone"];							
		if(empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
					{$sql ="select * from student ";}
		if (!empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
					{$sql ="select * from student where student_id Like '".$Tcode1."%'";}
		if (empty($Tcode1) AND !empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
					{$sql ="select * from student where th_name Like '".$Tname."%'";}											
		if (empty($Tcode1) AND empty($Tname) AND !empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
					{$sql ="select * from student where th_surname Like '".$Tsname."%'";}	
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND !empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
					{$sql ="select * from student where gender Like '".$Tsex."%'";}	
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND !empty($T_phone))
				{	if($T_phone=='�����')
							{$sql ="SELECT * FROM student where (telephone_contact IS NULL or telephone_contact='-')";}
					else
							{$sql ="SELECT * FROM student where (telephone_contact Like '".$T_phone."%')";}
								}
		//if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND !empty($Tgrade)){$sql ="select * from student where th_surname Like '".$Tgrade."%'";}													
		//if (empty($Tcode) AND empty($Tname) AND empty($Tsname)!empty($Tgrade)){$sql ="select * from student where th_surname Like ".$Tgrade;}				
		if (empty($Tcode1) AND !empty($Tname) AND !empty($Tsname) AND empty($Tsex) AND empty($Tgrade) AND empty($T_phone))
		    {$sql ="select * from student where th_name Like '".$Tname."%'"." AND th_surname Like '".$Tsname."%'";}											
							  ?>							  
							    <tr>
								<form name="form1" method="post" action="mis_student_search.php">
							      <td align="left" valign="top"  height="10"><input name="Tcode" type="text"  width="20" align="right"></td>
							      <td align="left" valign="top"  height="10"><input name="Tname" type="text" width="20"></td>
							      <td align="left" valign="top"  height="10"><input name="Tsname" type="text"  width="20"></td>
							      <td align="left" valign="top"  height="10"><input name="Tsex" type="text" width="20"></td>
							      <td align="left" valign="top" height="10" ><input name="T_phone" type="text" width="20"></td>
							      <td align="left" valign="top" height="10"><input name="Tgrade" type="text" width="20" vspace="10"></td>
							      <td align="left" valign="top"  height="10"><input name="submit" type="submit" value="����"></td>
								   </form>					
							      </tr>
							    <tr>
							      <td width="143" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b> ���ʹѡ�֡��</b></td>		                             				
								<td width="124" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b>���͹ѡ�֡��</b></td>
								<td width="62" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b>���ʡ��</b></td> 							
								<td width="85" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b>��</b></td> 							  
								<td width="111" align="left" valign="top"  height="10"  bgcolor="#FFFFCC"><b>���Ѿ��</b></td>
								<td width="66" align="left" valign="top" height="10" bgcolor="#FFFFCC"><b>GPA</b></td>
								<td width="102" rowspan="2" align="left" valign="top">&nbsp;</td>								
				              </tr>
							          <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$student_id= $row[student_id];
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$gender=$row[gender];
												$telephone_contact=$row[telephone_contact];
											?>						  

							     <tr> <td align="left" valign="top" bgcolor="#FFFFEA"> <a href="../mis/student/std_info1.php?person_id=<? print($student_id) ?> " target="_blank" ><? print($student_id) ?></a></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA"><? print($pre_name)?>&nbsp;<? print($th_name)?></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_surname) ?></td> 
								  <td align="left" valign="top" bgcolor="#FFFFEA" width="85"><? 
																															if($gender=="���")
																																print ("���") ;
																															else
																																print ("˭ԧ");
																																?>								  
								    <td align="left" valign="top" bgcolor="#FFFFEA"><?
																								if ($telephone_contact==""  or  telephone_contact =="-") 
																									print "�����������";
																								else
																									print $telephone_contact;								
																							?></td>
								    <td align="left" valign="top" bgcolor="#FFFFEA"><? print("3.5") ?></td>
								    </tr>				                	
							          <? } ?>									
						            </table> 
									 <table width="100%" align="right"  border="0">                                          
                                            <tr>
                                              <td width="96%" align="right" valign="top"  bgcolor="#FFFFFF"><b>�ѡ�֡�ҷ����� &nbsp;<? print ($num_rows)?> &nbsp; ��</b></td>
                                            <td width="4%"  height="28" align="right" valign="top"  bgcolor="#FFFFFF">&nbsp;</td>
                                            </tr>		                                         
                                    </table></td>
									</table>	</td>														                																									 				  
                            <td valign=top background="../resource/img/border_footer05.jpg"><img height=8 src="../resource/img/border_footer05.jpg" width=8></td>          
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="45" colspan="3" class ="classinfo" scope="col"><div align="center">
      <hr align=center width="95%" size=2> 
        Department of Computer Engineering Faculty of Engineering King Mongkut'sInstitute of Technology<BR>
    Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>