<? include ("_StartConnection.php")?>
<?include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
							
                             <tr><td align="left" valign="top"><div align="left">
							 <? include ("_menu.php") ?>
							 </div></td>
							 </tr>
                             <tr>   
					<td align="right" valign="top">&nbsp;<a href="person/mis_person1_paper2.php?<?php echo "Tname=$Tname&Tsname=$Tsname&mobile=$mobile";?>"><u>�����͡���</u></a>
							 <div align="center"><strong>��ª��ͺؤ�ҡ� �Ҥ�Ԫ����ǡ�������������</strong></div><br></td></tr>                                 
                              <td>							  
					  		  
					  		    <table width="633" align="center" border="0">
								<!--<table width="489"align="center" > -->
							  <?
							  				//$Tcode = $_POST["Tcode"];
							  				$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];	
											$mobile=$_POST["mobile"];											
										   
		if(empty($Tname) AND empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5')";}
		if(!empty($Tname) AND empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_name Like '".$Tname."%'";}
		if(empty($Tname) AND !empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_surname Like '".$Tsname."%'";}		
		if(empty($Tname) AND empty($Tsname) AND !empty($mobile))
						
						{	if($mobile=='�����')
							{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and (mobile IS NULL or mobile='-')";}
					else
							{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and mobile Like '".$mobile."%'";}
								}
						
						
						
																			
		if(!empty($Tname) AND !empty($Tsname) AND empty($mobile))
		    			{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_name Like '".$Tname."%'"." and th_surname Like '".$Tsname."%'";}											
							  ?>
							   <tr>
							   <form name="form1" method="post"  action="mis_person1_search.php">
							    <!--   <td align="left" valign="top"><input name="Tcode" type="text"></td>-->
								<td align="left" valign="top" width="20">&nbsp;</td>
								<td align="left" valign="top"><input type="text" name="Tname"></td>
							     <td align="left" valign="top"><input name="Tsname" type="text"></td>
							     <td align="left" valign="top"><input name="mobile" type="text"></td>
							     <td align="left" valign="top"><input name="submit" type="submit" value="����"></td>
								 </form>
							     </tr>								 
							   <tr>
                                <td width="200" align="left" valign="top"  bgcolor="#FFFFCC"><b>���˹�</b></td>
								<td width="71" align="left" valign="top" bgcolor="#FFFFCC"><b>����</b></td>
								<td width="86" align="left" valign="top" bgcolor="#FFFFCC"><b>���ʡ��</b></td> 
								<td width="80" align="left" valign="top" bgcolor="#FFFFCC"><b>���Ѿ��</b></td>
								<td width="46" rowspan="2" align="left" valign="top">&nbsp;</td> 
				              </tr>
							 <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);							 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$th_prename=$row[th_prename];
												$position1=$row[position];
												$prename=$row[prename];
												$type1=$row[type];
												$mobile=$row[mobile];
											?>						  
                              <tr>
                                <td  width="200"align="left" valign="top" bgcolor="#FFFFEA">								
								<?
									if ($type1=="0")
										print "���˹���Ҥ�Ԫ�";
									elseif ($type1=="1")
										print "�Ҩ����";
									elseif ($type1=="2")
										print "���˹�ҷ��෤�Ԥ�";			
									elseif ($type1=="3")
										print "���˹�ҷ���ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "���˹�ҷ���á��";	
									elseif ($type1=="5")	
										print "���˹�ҷ�����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
									else 
										print "�ѧ����кص��˹�";																								
								?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print($prename) ?>&nbsp; <? print($th_name) ?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_surname) ?></td> 	
								<td align="left" valign="top" bgcolor="#FFFFEA"><? 	
																														if ($mobile=="" or $mobile=="-") 
																																print "�����������";
																															else
																																print $mobile;	?></td>
								</tr>
							  <? } ?>
							  </table>
							   <table width="826" align="right"  height="5" border="0">                                         
                                            <tr>
                                              <td width="674" align="right" valign="top"  bgcolor="#FFFFFF"><strong>���ҡ÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ</strong></td>
                                            <td width="142" height="28" align="right" valign="top"  bgcolor="#FFFFFF">&nbsp;</td></tr>
                                  </table></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
