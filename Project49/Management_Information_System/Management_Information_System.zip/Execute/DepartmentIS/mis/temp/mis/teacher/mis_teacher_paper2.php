<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody" >
<table width="636" height="150" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="636" align="center"  valign="middle"> <p><strong>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</strong></p>
        <p>&nbsp;</p></td>
      </tr>
	  
  <td><table width="633"  border="0"align="left" bordercolor="#FFFFFF" bgcolor="#000000">
  
    <?
		
	{if ($Tcode=='�Ҩ����' )
		{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND position IS NULL";}	  
		else if($Tcode==''){$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND th_name LIKE '%$Tname%' AND position IS NOT NULL AND th_surname LIKE '%$Tsname%' AND email LIKE '%$T_Email%' AND mobile LIKE '%$Ttelephone1%'";}
		else{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND th_name LIKE '%$Tname%' AND position LIKE '%$Tcode%'  AND th_surname LIKE '%$Tsname%' AND email LIKE '%$T_Email%' AND mobile LIKE '%$Ttelephone1%'";}
		}
	?> 
    <tr bordercolor="#000000" bgcolor="#cccccc">
      <td width="110" align="left" valign="top" bordercolor="#000000"><b>���˹��Ԫҡ��</b></td>
      <td width="86" align="left" valign="top" bordercolor="#000000"><b>����</b></td>
      <td width="110" align="left" valign="top" bordercolor="#000000"><b>���ʡ��</b></td>
      <td width="131" align="left" valign="top" bordercolor="#000000"><b>Email</b></td>
      <td width="108" align="left" valign="top" bordercolor="#000000"><b>���Ѿ��</b></td>
      <td width="89" align="left" valign="top" bordercolor="#000000"><div align="center"><strong>�����˵�</strong></div></td>
    </tr>
	
    <?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$telephone1=$row[mobile];
												$person_id=$row[person_id];
												$email = $row[email];
												?>
    <tr>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? print($th_name) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? print($th_surname) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><? 
								if($email=="-" or "")
										print "����� Email";
								else
										print $email;
										?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><?		
									if ($telephone1=="-" or "") 
										print "�����������";
									else
										print $telephone1;								
								?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
   <? } ?>
  </table>
  <p>&nbsp;</p>
					<table width="633" border="0">
					  <tr>
						<td width="668"><div align="right"><strong>��Ҩ��������� &nbsp;<? print ($num_rows); ?> &nbsp; ��ҹ</strong></div></td>
					  </tr> 
					
	  </table>    </td>
  </tr>
</table>
</td>
  </tr>
  
</table>
</body>
</html>
