<?
	session_start();	   
   $_SESSION["person_id"] = $_GET["person_id"];
   $f_type = $_GET["f_type"];
   $ch = "1";
   
 //  print("<br> person_id = ".$_SESSION["person_id"]);
 //  print("<br> f_type = ".$f_type);
   
if($f_type == "STD") { 
	$_SESSION["type"] = "student";
    header("Location: ../student/std_info1.php");
}	 
 if($f_type == "TCH"){ 
 		$_SESSION["type"] = "1";
		header("Location: ../teacher/teacher_info1.php");
}
 if($f_type == "EMP"){ 
 		$_SESSION["type"] = "1";
		header("Location: ../teacher/teacher_info1.php");
		//print("EMP");
}

		// person/person_info1.php 
// if($f_type == "EMP") header("Location: ../student/std_info1.php");
   
 
 
?>