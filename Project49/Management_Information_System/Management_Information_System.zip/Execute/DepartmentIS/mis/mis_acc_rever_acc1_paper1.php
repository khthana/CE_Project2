<?
	 include ("_StartConnection.php");
 	 include ("_CheckSession.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >

  
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
        
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr>
								<td align="left" valign="top"><div align="center"><u><b>��¡�ô�ҹ����Թ (�ѭ�ҡ������Թ</b> <B>) </B><b>�Ҥ�Ԫ����ǡ�������������</b></u></div></td>
                              </tr>
                              <tr>
                                <!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
								
								<td align="left" valign="top"><br>
								  
								<!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
                                  
								<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->
                                    <table width="649" border="0" align="center" bgcolor="#000000">         
									  <?								
										{$sql ="select * from loaning ";}
							  ?>		<!--$sql = 'SELECT * FROM `reserve_money` LIMIT 0, 30 '; -->
                                      <tr>
                                        <th width="35" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�Ţ���</div></th>
                                        <th width="111" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ѹ�����ѭ������Թ</div></th>
                                        <th width="134" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�˵ؼŷ�����</div></th>
                                        <th width="132" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">������</div></th>
                                        <th width="71" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�ӹǹ�Թ</div></th>
                                        <th width="68" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">���</div></th>
                                        <th width="68" align="left" bgcolor="#CCCCCC" scope="col"><div align="center">�������</div></th>
                                       
                                      </tr>
									  
									  <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$borrow_num= $row[borrow_num];
												$money=$row[money];
												$borrower_name = $row[borrower_name];
												$day_making = $row[day_making];
												$day_expire = $row[day_expire];
												$fr_money = $row[fr_money];
												$make_clear = $row[make_clear];
												$borrow_for = $row[borrow_for];
										?>						  
                                      <tr>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center">
											<? 								
												print ($borrow_num);
											?></div></td>																
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($day_making)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($borrow_for)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($borrower_name)?></div></td>																				
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($money)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($fr_money)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($make_clear)?></div></td>
                                       
                                      </tr>
									  <? } ?>		
                                  </table>
									
									<table width="652" border="0"  align="center">
                                      <tr>
                                         <th width="91%" scope="col"><div align="right">������ &nbsp;<? print ($num_rows)?> &nbsp; ��¡�� </div></th>
                                      </tr>
                                  </table>
								
                              </tr>

                            </table>
                
              </table></td>
          </tr>
         
        </tbody>
      </table></td>
  </tr>

</table>
</body>
</html>
