<?
session_start();	
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody" >
<table width="800" height="364" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="11" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="779" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="18" height="21"> 
    ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td width="784" valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=10 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td height="161" valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
							  <td align="right" valign="top">&nbsp;<a href="find_paper.php?f_type=STD" target="_blank"><u>�����͡��� </u></a>
                                <!--<td align="left" valign="top">&nbsp;
                                  <a href="mis_student_paper1.php">print</a> -->
                                  <div align="center"><strong>��ª��͹ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div><br></td></tr>								  
							      <td><table width="713" align="center"  border="0">
							  <?								
									$sql ="select * from student where faculty_id =01 AND dept_id=05 order by  student_id ";
								     $_SESSION["F_SQL"] = $sql;	
									
							  ?>							  
							    <tr>
							      <td width="84" align="left" valign="top"  bgcolor="#FFFFCC"><div align="center"><b> ���ʹѡ�֡��</b></div></td>		                             				
								<td width="127" align="left" valign="top" bgcolor="#FFFFCC"><b>����</b></td>
								<td width="127" align="left" valign="top" bgcolor="#FFFFCC"><b>���ʡ��</b></td>
								<td width="58" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>Section</b></div></td> 							
								<td width="50" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>��</b></div></td> 							  
								<td width="96" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>���Ѿ��</b></div></td>
								<td width="59" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>GPA</b></div></td>
								<td width="95" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>ʶҹ�</b></div></td>
								</tr>
							          <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$student_id= $row[student_id];
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$gender=$row[gender];
												$telephone_contact=$row[telephone_contact];
												$std_status=$row[std_status];
												$exam1=$row[exam1];
												$gpa = $row[gpa];
										?>						  
							          
							     <tr> <td align="left" valign="top" bgcolor="#FFFFEA">
								 <a href="find_data.php?person_id=<? print($student_id) ?>&f_type=STD" target="_blank"  ><div align="center"><? print($student_id) ?></div></a></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($pre_name)?>&nbsp;<? print($th_name)?></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($th_surname) ?></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? 
																															if($exam1=="��ѡ�ٵû���")
																																print ("D");
																															else if($exam1=="������ͧ����")
																																print ("P");
																																else 
																																print 'NULL';
																															?>	</div></td> 
								  <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? 
																															if($gender=="���")
																																print ("���") ;
																															else
																																print ("˭ԧ");
																															?>	</div></td>							  
								    <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;
																								<?
																								if ($telephone_contact==""  or  $telephone_contact =="-") 
																									print "�����������";
																								else
																									print $telephone_contact;								
																								?>									</td>
								    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="right"><? print($gpa) ?></div></td>
								    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? 
																																	if ($std_status==""  or  $std_status =="Y") 
																																		print "�ѡ�֡��";
																																	else
																																		print "����Ҿ";								
																															?></div></td>
								    </tr>				               
							          <? } ?>									
						            </table> 
							            <table width="465" align="right"  height="5" border="0">
                                          <tr>
                                            <td width="378" height="28" align="right" valign="top"  bgcolor="#FFFFFF"><strong>�ѡ�֡�ҷ����� &nbsp;<? print ($num_rows)?> &nbsp; �� </strong></td>
											<td width="77" height="28" align="left" valign="top"  bgcolor="#FFFFFF">
											<form name="form1" method="post"  action="mis_student_search.php">									  
											  <input type="submit" name="Submit"  height="10" value="����">
											</form></td>			   																				
                                          </tr>
                                    </table>	 
						         </td>																										 
							      </table></td>									  
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="45" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
    Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
