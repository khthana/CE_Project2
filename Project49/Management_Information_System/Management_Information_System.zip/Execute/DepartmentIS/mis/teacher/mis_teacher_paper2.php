<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title></head>

<body class = "classbody" >
<table width="658" height="150" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="658" align="center" ><strong>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</strong>  </td>
     
      </tr>
	  
  <td><table width="730"  border="0"align="center" bordercolor="#FFFFFF" bgcolor="#000000" >
  
    <?
		
	{if ($Tcode=='�Ҩ����' )
		{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND position IS NULL";}	  
		else if($Tcode==''){$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND th_name LIKE '%$Tname%' AND position IS NOT NULL AND th_surname LIKE '%$Tsname%' AND email LIKE '%$T_Email%' AND mobile LIKE '%$Ttelephone1%'";}
		else{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6') AND th_name LIKE '%$Tname%' AND position LIKE '%$Tcode%'  AND th_surname LIKE '%$Tsname%' AND email LIKE '%$T_Email%' AND mobile LIKE '%$Ttelephone1%'";}
		}
	?> 
    <tr bordercolor="#000000" bgcolor="#cccccc" align="center">
      <td width="99" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���˹��Ԫҡ��</b></div></td>
      <td width="127" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>����</b></div></td>
      <td width="135" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���ʡ��</b></div></td>
      <td width="100" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>Email</b></div></td>
      <td width="98" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���Ѿ��</b></div></td>
      <td width="75" align="left" valign="middle" bordercolor="#000000"><div align="center"><strong>ʶҹ�</strong></div></td>
      <td width="66" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>�����˵�</b></div></td>
    </tr>
	
    <?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$telephone1=$row[mobile];
												$person_id=$row[person_id];
												$email = $row[email];
												$person_status=$row[person_status];
												?>
    <tr>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; --><div align="center"><? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?></div></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($th_name) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($th_surname) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? 
								if($email=="-" or $email=="")
										print "����� Email";
								else
										print $email;
										?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<?		
									if ($telephone1=="-" or $telephone1=="") 
										print "�����������";
									else
										print $telephone1;								
								?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center"><? 
	  																																if ($person_status==""  or  $person_status =="Y") 
																																		print "��Ҩ����";
																																	else
																																		print "�鹵�˹�";		
	  																																		?></div></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"></td>
    </tr>
   <? } ?>
  </table>
 
				
					<table width="730" border="0" align="center">
					  <tr>
						<td width="730"><div align="right"><strong>��Ҩ��������� &nbsp;<? print ($num_rows); ?> &nbsp; ��ҹ</strong></div></td>
					  </tr> 
					
	  </table>    </td>
  </tr>
</table>
</td>
</table>
</td>
  </tr>
  

</body>
</html>
