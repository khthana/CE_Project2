<?
		$sql ="select * from edu_person 
		where degree = '0' and person_id ='$person_id' ";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
		
		$univ_name1= $row[univ_name];
		$country_name1= $row[country_name];
		$year_congrate1= $row[year_congrate];
		$senior_degree1= $row[senior_degree];
		$knowledge1= $row[knowledge];
		$grade1= $row[grade];
		$thesis1= $row[thesis];


		$sql ="select * from edu_person 
		where degree = '1' and person_id ='$person_id' ";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
		
		$univ_name2= $row[univ_name];
		$country_name2= $row[country_name];
		$year_congrate2= $row[year_congrate];
		$senior_degree2= $row[senior_degree];
		$knowledge2= $row[knowledge];
		$grade2= $row[grade];
		$thesis2= $row[thesis];


		$sql ="select * from edu_person 
		where degree = '2' and person_id ='$person_id' ";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
		
		$univ_name3= $row[univ_name];
		$country_name3= $row[country_name];
		$year_congrate3= $row[year_congrate];
		$senior_degree3= $row[senior_degree];
		$knowledge3= $row[knowledge];
		$grade3= $row[grade];
		$thesis3= $row[thesis];





?>