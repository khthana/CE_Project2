<?
session_start();	
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title></head>

<body class = "classbody" >
<table width="658" border="0" align="center" >
      <tr>
        <td width="658" align="center"><strong>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</strong>
        <p></p></td>
      </tr>	  
  <td><table width="658"  border="0"align="center" bordercolor="#FFFFFF" bgcolor="#000000">
    <?		
	     $sql =$_SESSION["F_SQL"] ;
	
	 ?>
    <tr bordercolor="#000000" bgcolor="#cccccc">
      <td width="103" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���˹��Ԫҡ��</b></div></td>
      <td width="126" align="left"  valign="middle" bordercolor="#000000"><div align="center"><b>����</b></div></td>
      <td width="125" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���ʡ��</b></div></td>
      <td width="148" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>Email</b></div></td>
      <td width="107" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>���Ѿ��</b></div></td>
      <td width="107" align="left" valign="middle" bordercolor="#000000"><div align="center"><strong>ʶҹ�</strong></div></td>
      <td width="89" align="left" valign="middle" bordercolor="#000000"><div align="center"><b>�����˵�</b></div></td>
    </tr>
    <?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$telephone1=$row[mobile];
												$person_id=$row[person_id];
												$email = $row[email];
												$person_status=$row[person_status];
												?>
    <tr>
      <td align="right" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; --><div align="center"><? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?></div></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($th_name) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($th_surname) ?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? 
								if($email=="-" or  $email=="")
										print "����� Email";
								else
										print $email;
										?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<?		
									if ($telephone1=="-" or  $telephone1=="") 
										print "�����������";
									else
										print $telephone1;								
								?></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center"><? 
	  																																if ($person_status==""  or  $person_status =="Y") 
																																		print "��Ҩ����";
																																	else
																																		print "�鹵��˹�";		
	  																																		?></div></td>
      <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"></td>
    </tr>
    <? } ?>
  </table>
  					<table width="658" border="0">
					  <tr>
						<td width="658"><div align="right"><strong>��Ҩ��������� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ</strong></div></td>
					  </tr>
	  </table>    </td>
  </tr>
</table></td>
  </tr>
</table>
</body>
</html>
