<?
		$sql ="select * from person where person_id ='$person_id'";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
	
		
		$person_id= $row[person_id];
		$citizenid= $row[citizenid];
		$prename= $row[prename];
		$gender= $row[gender];
		$position= $row[position];
		$level= $row[level];
		$th_name= $row[th_name];
		$th_surname= $row[th_surname];
		$en_name= $row[en_name];
		$en_surname= $row[en_surname];
		$type= $row[type];

		$number1= $row[number1];
		$group1= $row[group1];
		$lane1= $row[lane1];
		$road1= $row[road1];
		$district1= $row[district1];
		$region1= $row[region1];
		$province1= $row[province1];
		$postalcode1= $row[postalcode1];
		$telephone1= $row[telephone1];

		$number2= $row[number2];
		$group2= $row[group2];
		$lane2= $row[lane2];
		$road2= $row[road2];
		$district2= $row[district2];
		$region2= $row[region2];
		$province2= $row[province2];
		$postalcode2= $row[postalcode2];
		$telephone2= $row[telephone2];

		$telephone= $row[telephone];
		$mobile= $row[mobile];
		$email= $row[email];
	

		


//�ӹ�˹�Ҫ���
		if ($prename == "���"){
			$flagprename1 = "checked";
		}
		else if ($prename == "�ҧ���"){
			$flagprename2 = "checked";
		}
		else if ($prename == "�ҧ"){
			$flagprename3 = "checked";
		}
		else{
			$flagprename4 = "checked";
			$prenamestatus = $prename;
		}

//��
	if ($gender == "���"){
			$flaggender1 = "checked";
		}
	else {
			$flaggender2 = "checked";
		}	

//�дѺ user
	if($type == "0") {
		$flagtype0 = "checked";
	}
	else if ($type == "1") {
		$flagtype1 = "checked";
	}
	else if ($type == "2") {
		$flagtype2 = "checked";
	}
	else if ($type == "3") {
		$flagtype3 = "checked";
	}
	else if ($type == "4") {
		$flagtype4 = "checked";
	}
	else  {
		$flagtype5 = "checked";
	}
?>