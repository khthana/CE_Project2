<? include ("_StartConnection.php")?>
<? include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody" >
<table width="800" height="39" border="0" align="center" cellpadding="0" cellspacing="0">
  

  <tr>
    <td height="39" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
      <tbody>

                <td valign=top><table cellspacing=0 cellpadding=0 width="100%" border=0>
                  <tbody>
                          <td align="right" valign="top"><div align="center"><strong>��ª��ͺؤ�ҡ� �Ҥ�Ԫ����ǡ�������������</strong></div></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top"><br>
                                      <table width="633"  border="0"align="center" bgcolor="#000000"  >
                                      <?    {$sql = "SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') AND th_name LIKE '%$Tname%' AND th_surname LIKE '%$Tsname%' AND mobile LIKE '%$mobile%'";} ?>
                                        <tr>
                                          <td width="119" align="left" valign="top" bordercolor="#000000"  bgcolor="#999999"><div align="center"><b>���˹�</b></div></td>
                                          <td width="135" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><div align="center"><b>����</b></div></td>
                                          <td width="129" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><div align="center"><b>���ʡ��</b></div></td>
                                          <td width="91" align="left" valign="top" bordercolor="#000000" bgcolor="#999999"><div align="center"><b>���Ѿ��</b></div></td>
                                          <td width="67" align="center" valign="top" bordercolor="#000000" bgcolor="#999999"><b>ʶҹ�</b></td>
                                          <td width="66" align="center" valign="top" bordercolor="#000000" bgcolor="#999999"><div align="center"><strong>�����˵�</strong></div></td>
                                        </tr>
                                        <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);							 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$th_prename=$row[th_prename];
												$position1=$row[position];
												$prename=$row[prename];
												$type1=$row[type];
												$mobile=$row[mobile];
												$person_status=$row[person_status];
											?>
                                        <tr>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<?
									if ($type1=="0")
										print "���˹���Ҥ�Ԫ�";
									elseif ($type1=="1")
										print "�Ҩ����";
									elseif ($type1=="2")
										print "���˹�ҷ��෤�Ԥ�";			
									elseif ($type1=="3")
										print "���˹�ҷ���ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "���˹�ҷ���á��";	
									elseif ($type1=="5")	
										print "���˹�ҷ�����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
									else 
										print "�ѧ����кص��˹�";																								
								?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($prename) ?>&nbsp; <? print($th_name) ?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? print($th_surname) ?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;<? 	
																														if ($mobile=="" or $mobile=="-") 
																																print "�����������";
																															else
																																print $mobile;	?></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center"><? 
																																	if ($person_status==""  or  $person_status =="Y") 
																																		print "�ѡ�֡��";
																																	else
																																		print "����Ҿ";								
																															?></div></td>
                                          <td align="left" valign="top" bordercolor="#000000" bgcolor="#FFFFFF">&nbsp;</td>
                                        </tr>
                                        <? } ?>
                            </table>
                            <table width="633" align="center" border="0">
                                        <tr>
                                          <td width="633" align="right" valign="top"  bgcolor="#FFFFFF"><div align="right"><strong>���ҡ÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ </strong></div></td>
                              </tr>
                            </table></td>
                        </tr>
                        
                      </table></td>
  
                    </tr>
                    
                  </tbody>
                </table></td>
              </tr>
          </table>
</td>
        </tr>
      
      </tbody>
    </table></td>
  </tr>
  
</table>
</body>
</html>

