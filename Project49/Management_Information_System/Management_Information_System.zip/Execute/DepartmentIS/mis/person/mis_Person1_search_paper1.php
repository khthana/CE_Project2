<? include ("_StartConnection.php")?>
<? include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="633" height="152" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th width="633" height="152" colspan="3" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      
      <tr>
        <td align="left" valign="top">&nbsp;
            <div align="center"><strong>��ª��ͺؤ�ҡ� �Ҥ�Ԫ����ǡ�������������</strong></div>
          <br></td>
      </tr>
  <td><table width="521" border="0" align="center" bgcolor="#000000">
    <!--<table width="489"align="center" > -->
    <?
							  				//$Tcode = $_POST["Tcode"];
							  				$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];	
											$mobile=$_POST["mobile"];											
										   
		if(empty($Tname) AND empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5')";}
		if(!empty($Tname) AND empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_name Like '".$Tname."%'";}
		if(empty($Tname) AND !empty($Tsname) AND empty($mobile))
						{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_surname Like '".$Tsname."%'";}		
		if(empty($Tname) AND empty($Tsname) AND !empty($mobile))
						
						{	if($mobile=='�����')
							{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and (mobile IS NULL or mobile='-')";}
					else
							{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and mobile Like '".$mobile."%'";}
								}										
		if(!empty($Tname) AND !empty($Tsname) AND empty($mobile))
		    			{$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5') and th_name Like '".$Tname."%'"." and th_surname Like '".$Tsname."%'";}											
							  ?>
    <tr>
      <td width="85" align="left" valign="top"  bgcolor="#CCCCCC"><b>���˹�</b></td>
      <td width="146" align="left" valign="top" bgcolor="#CCCCCC"><b>����</b></td>
      <td width="146" align="left" valign="top" bgcolor="#CCCCCC"><b>���ʡ��</b></td>
      <td width="126" align="left" valign="top" bgcolor="#CCCCCC"><b>���Ѿ��</b></td>
      </tr>
    <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);							 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$th_prename=$row[th_prename];
												$position1=$row[position];
												$prename=$row[prename];
												$type1=$row[type];
												$mobile=$row[mobile];
											?>
    <tr>
      <td  width="85"align="left" valign="top" bgcolor="#FFFFFF"><?
									if ($type1=="0")
										print "���˹���Ҥ�Ԫ�";
									elseif ($type1=="1")
										print "�Ҩ����";
									elseif ($type1=="2")
										print "෤�Ԥ�";			
									elseif ($type1=="3")
										print "��ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "��á��";	
									elseif ($type1=="5")	
										print "����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
									else 
										print "�ѧ����кص��˹�";																								
								?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? print($prename) ?>&nbsp; <? print($th_name) ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? print($th_surname) ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><? 	
																														if ($mobile=="" or $mobile=="-") 
																																print "�����������";
																															else
																																print $mobile;	?></td>
      </tr>
    <? } ?>
  </table></td>
  </tr>
  <tr>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
    </table></th>
  </tr>
</table>
</body>
</html>
