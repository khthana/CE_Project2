<?
if (empty($person_id)){
		$sql ="select * from student";
} else {
		$sql ="select * from student where student_id ='$person_id'";
}		
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
	
		
		$semester= $row[semester];
		$student_id= $row[student_id];
		$citizen_id= $row[citizen_id];
		$pre_name= $row[pre_name];
		$gender= $row[gender];
		$th_name= $row[th_name];
		$th_surname= $row[th_surname];
		$en_name= $row[en_name];
		$en_surname= $row[en_surname];
		$exam_pattern= $row[exam_pattern];
		$exam1= $row[exam1];
		$exam2= $row[exam2];

//�ӹ�˹�Ҫ���
		if ($pre_name == "���"){
			$flagpre_name1 = "checked";
		}
		else if ($pre_name == "�ҧ���"){
			$flagpre_name2 = "checked";
		}
		else if ($pre_name == "�ҧ"){
			$flagpre_name3 = "checked";
		}
		else{
			$flagpre_name4 = "checked";
			$pre_namestatus = $pre_name;
		}

//��
	if ($gender == "���"){
			$flaggender1 = "checked";
		}
	else {
			$flaggender2 = "checked";
		}

//�ͺ��ҹ��ǧ����Է�����
	if($exam_pattern != "") {
		if($exam_pattern == "��ѡ�ٵû���") {
			$exam_pattern1 = "checked";				
		}
		else if ($exam_pattern == "�ç�������Ѵ") {
			$exam_pattern2 ="checked";
		}
		else
			$exam_pattern3 = "checked";
	}

//��ѡ�ٵ� 4-5 �� 		
	if($exam1 != "") {
		if($exam1 == "1") {
			$flagexam1 = "checked";
		}
		else if ($exam1 == "2") {
			$flagexam2 ="checked";
		}
		else if ($exam1 == "3") {
			$flagexam3 ="checked";
		}
		else if ($exam1 == "4") {
			$flagexam4 ="checked";
		}
		else if ($exam1 == "5") {
			$flagexam5 ="checked";
		}
		else if ($exam1 == "6") {
			$flagexam6 ="checked";
		}
		else if ($exam1 == "7") {
			$flagexam7 ="checked";
		}
		else if ($exam1 == "8") {
			$flagexam8 ="checked";
		}
		else
			$flagexam9 = "checked";
	}	
	
//��ѡ�ٵ� 1-3 ��  
	if($exam2 != "") {
		if($exam2 == "1") {
			$flag_exam1 = "checked";
		}
		else if ($exam2 == "2") {
			$flag_exam2 ="checked";
		}
		else if ($exam2 == "3") {
			$flag_exam3 ="checked";
		}
		else if ($exam2 == "4") {
			$flag_exam4 ="checked";
		}
		else if ($exam2 == "5") {
			$flag_exam5 ="checked";
		}		
		else
			$flag_exam6 = "checked";
	}	

?>