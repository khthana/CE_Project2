<? 
		include ("_StartConnection.php");
	 	include("_CheckSession.php"); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
	<img src="../resource/img/titre-menu-user.gif" width="16" height="16"> ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
        
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="center"><strong><u><b>��¡�ô�ҹ��õ���ԡ (��ԡ��ʴ�) �Ҥ�Ԫ����ǡ�������������</b></u></strong></div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><br>
                                    <table width="726" border="0" align="center">                                     
									    <?								
										{$sql ="select SUM(`money`) as sum_money,bring_num , making_date, bring_name, receiver_name , note from inventory_bring  Group by bring_num";}
							  			?>		
							   <tr>
                                        <th width="60" bgcolor="#FFFFCC" scope="col"><div align="center">�Ţ�����ԡ</div></th>
                                        <th width="99" bgcolor="#FFFFCC" scope="col"><div align="center">�ѹ������ԡ</div></th>
                                        <th width="150" bgcolor="#FFFFCC" scope="col"><div align="center">�����ԡ</div></th>
                                        <th width="149" bgcolor="#FFFFCC" scope="col"><div align="center">����Ѻ��ʴ�</div></th>                                      
                                        <th width="108" bgcolor="#FFFFCC" scope="col"><div align="center">�ӹǹ�Թ�����ԡ</div></th>
                                        <th width="120" bgcolor="#FFFFCC" scope="col"><div align="center">�����˵�</div></th>
                                      </tr>
									  <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$list_id= $row[list_id];
												$budget_year=$row[budget_year];
												$st_num= $row[st_num];			
												$title=$row[title];	
												$date_making=$row[date_making];				
												$money=$row[money];	
												$name_reserve=$row	[name_reserve];		
												$date_using=$row[date_using];											
												$bring_num = $row[bring_num];
												$making_date = $row[making_date];
												$note = $row[note];
												$bring_name = $row[bring_name];
												$receiver_name = $row[receiver_name];
												$sum_money = $row[sum_money];
												
										?>						
                                      <tr>
                                        <td width="60" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($bring_num)?></div></td>
                                        <td width="99" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($making_date)?></div></td>
                                        <td width="150" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($bring_name)?></div></td>
                                        <td width="149" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($receiver_name)?></div></td>
                                        <td width="108" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($sum_money)?></div></td>
										 <td width="120" bgcolor="#FFFFEA" scope="col"><div align="center"><? print($note)?></div></td>
                                      </tr>
									   <? } ?>		
                                    </table>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
