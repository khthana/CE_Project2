<?
		$sql ="select * from parent where student_id ='$std_id' and ptype ='1'";
		
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
		$row=mysql_fetch_array($table);
	
		$ptype = $row[ptype];

		$name_parent = $row[name_parent];
		$surname_parent = $row[surname_parent];
		$status_parent = $row[status_parent];
		
		$age_parent= $row[age_parent];
		$race_parent= $row[race_parent];
		$nationality_parent= $row[nationality_parent];
		$religion_parent= $row[religion_parent];
		$citizenid_parent= $row[citizenid_parent];

		$number_parent = $row[number_parent];                
		$group_parent = $row[group_parent];                
		$lane_parent  = $row[lane_parent];              
		$road_parent  = $row[road_parent];               
		$district_parent = $row[district_parent];              
		$region_parent= $row[region_parent];               
		$province_parent  = $row[province_parent];              
		$postalcode_parent  = $row[postalcode_parent];               
		$tel_parent = $row[tel_parent];
		$educational_parent= $row[educational_parent];


		$work_parent= $row[work_parent];
		$workplace_parent= $row[workplace_parent];
		$provincework_parent= $row[provincework_parent];
		$postalcodework_parent= $row[postalcodework_parent];
		$telwork_parent= $row[telwork_parent];
		$salary_parent= $row[salary_parent];	
	
//ʶҹС���ժ��Ե����ͧ��ô�
if( $status_parent == "Y"){
	$status_parent1 = "checked";
}
else{
	$status_parent2 = "checked";
}

	
//���ͪҵ�
	if ($race_parent != "") {
		if ($race_parent == "��"){
			$race_parent1 = "checked";
		}
		else if ($race_parent =="�չ"){
			$race_parent2 = "checked";
		}
		else{
			$race_parent3 = "checked";
			$race_parentstatus = $race_parent;
		}
	}
//�ѭ�ҵ�
	if ($nationality_parent != "") {
		if ($nationality_parent == "��"){
			$nationality_parent1 = "checked";
		}
		else if ($nationality_parent =="�չ"){
			$nationality_parent2 = "checked";
		}
		else{
			$nationality_parent3 = "checked";
			$nationality_parentstatus = $nationality_parent;
		}
	}
//��ʹ�
	if ($religion_parent != "") {
		if ($religion_parent == "�ط�"){
			$religion_parent1 = "checked";
		}
		else if ($religion_parent =="���ʵ�"){
			$religion_parent2 = "checked";
		}
		else if ($religion_parent =="������"){
			$religion_parent3 = "checked";
		}
		else{
			$religion_parent4 = "checked";
			$religion_parentstatus = $religion_parent;
		}
	}		

//����֡�Ңͧ��ô�

	if ($educational_parent != "") {
		if ($educational_parent == "��ж��֡��"){
			$educational_parent1 = "checked";
		}
		else if ($educational_parent =="�Ѹ���֡��"){
			$educational_parent2 = "checked";
		}
			else if ($educational_parent =="������ش��֡��"){
			$educational_parent3 = "checked";
		}
			else if ($educational_parent =="�Ҫ���֡��"){
			$educational_parent4 = "checked";
		}
			else if ($educational_parent =="͹ػ�ԭ��������º���"){
			$educational_parent5 = "checked";
		}
			else if ($educational_parent =="��ԭ�ҵ��"){
			$educational_parent6 = "checked";
		}
			else if ($educational_parent =="��ԭ���"){
			$educational_parent7 = "checked";
		}
			else if ($educational_parent =="��ԭ���͡"){
			$educational_parent8 = "checked";
		}
			else if ($educational_parent =="������ز�"){
			$educational_parent9 = "checked";
		}
		else{
			$educational_parent10 = "checked";
			$educational_parentstatus = $educational_parent;
		}
		//print $educational_parentstatus;
	}
	
	//�Ҫվ�ͧ��ô�
	if ($work_parent != "") {
		if ($work_parent == "�Ѻ�Ҫ���"){
			$work_parent1 = "checked";
		}
		else if ($work_parent =="��ѡ�ҹ�Ѱ����ˡԨ"){
			$work_parent2 = "checked";
		}
			else if ($work_parent =="��ѡ�ҹ�����١��ҧ�͡��"){
			$work_parent3 = "checked";
		}
			else if ($work_parent =="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��"){
			$work_parent4 = "checked";
		}
			else if ($work_parent =="�١��ҧ��ǹ�Ҫ���"){
			$work_parent5 = "checked";
		}
			else if ($work_parent =="�ɵá�/��ǻ����"){
			$work_parent6 = "checked";
		}
			else if ($work_parent =="�Ѻ��ҧ"){
			$work_parent7 = "checked";
		}
			else if ($work_parent =="����Сͺ�Ҫվ"){
			$work_parent8 = "checked";	
		}
		else{
			$work_parent9 = "checked";
			$work_parentstatus = $work_parent;
		}
	}
//�����ͧ��ô�
	if($salary_parent == 0){
		$salary_parent1 = "checked";
	}
	else {
		$salary_parent2 = "checked";
		$salary_parentstatus = $salary_parent;
	}
?>