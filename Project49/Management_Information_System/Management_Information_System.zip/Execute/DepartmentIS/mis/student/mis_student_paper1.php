<?
session_start();	
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody" >

  <table width="715" border="0" cellpadding="0" cellspacing="0" align="center">
    <tr>
      <td align="left" valign="top">&nbsp;
          <div align="center"><strong>��ª��͹ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div>
        <br></td>
    </tr>
  <td><table width="723"  border="1" align="center" bordercolor="#FFFFFF" bgcolor="#000000">
    <?								
									$sql =$_SESSION["F_SQL"];		
	?>
    <tr>
      <td width="84" align="left" valign="top"  bgcolor="#CCCCCC"><div align="center"><b> ���ʹѡ�֡��</b></div></td>
      <td width="118" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>����</b></div></td>
      <td width="106" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>���ʡ��</b></div></td>
      <td width="52" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>Section</b></div></td>
      <td width="46" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>��</b></div></td>
      <td width="87" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>���Ѿ��</b></div></td>
      <td width="43" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>GPA</b></div></td>
      <td width="57" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>ʶҹ�</b></div></td>
      <td width="72" align="left" valign="top" bgcolor="#CCCCCC"><div align="center"><b>�����˵�</b></div></td>
    </tr>
    <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$student_id= $row[student_id];
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$gender=$row[gender];
												$telephone_contact=$row[telephone_contact];
												$std_status=$row[std_status];
												$exam1=$row[exam1];
												$gpa = $row[gpa];
										?>
    <tr>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? print($student_id) ?></div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;<? print($pre_name)?>&nbsp;<? print($th_name)?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;<? print($th_surname) ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? 
																															if($exam1=="��ѡ�ٵû���")
																																print ("D");
																															else if($exam1=="������ͧ����")
																																print ("P");
																																else 
																																print 'NULL';
																															?>	</div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center"><? 
																															if($gender=="���")
																																print ("���") ;
																															else
																																print ("˭ԧ");
																															?></div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;<?
																								if ($telephone_contact==""  or  telephone_contact =="-") 
																									print "�����������";
																								else
																									print $telephone_contact;								
																								?>      </td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;<? print($gpa) ?></td>
      <td align="left" valign="top" bgcolor="#FFFFFF"><div align="center">
        <? 
																																	if ($std_status==""  or  $std_status =="Y") 
																																		print "�ѡ�֡��";
																																	else
																																		print "����Ҿ";								
																															?>
      </div></td>
      <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <? } ?>
  </table>
      <table width="715" border="0" align="center">
          <tr>
             <td width="84%" align="right" valign="top"  bgcolor="#FFFFFF"><b>�ѡ�֡�ҷ����� &nbsp;<? print ($num_rows)?> &nbsp; ��</b></td>
          </tr>
      </table>
  </table>

</body>
</html>
