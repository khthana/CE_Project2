<?
		session_start();	
	 include ("_StartConnection.php");
	 include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                 <td align="right" valign="top">&nbsp;<a href="find_paper.php?f_type=EMP" target="_blank"><u>�����͡���</u></a>
								<div align="center"><strong>��ª��ͺؤ�ҡ� �Ҥ�Ԫ����ǡ�������������</strong></div></td></tr>
                                  
                              <tr>
                                <td align="left" valign="top">
								<br>
								<table width="583"align="center" >
							  <?
									$sql ="SELECT * FROM person where (type='2' or type='3' or type='4' or type='5')";
									$_SESSION["F_SQL"] = $sql;	
							  ?>						  
							  <tr>
                                <td width="125" align="left" valign="top"  bgcolor="#FFFFCC"><div align="center"><b>���˹�</b></div></td>
								<td width="131" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>����</b></div></td>
								<td width="111" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>���ʡ��</b></div></td> 
								<td width="93" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>���Ѿ��</b></div></td>
								<td width="99" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>ʶҹ�</b></div></td>
				              </tr>
							 <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);							 
							while ($row=mysql_fetch_array($table))
									{
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$th_prename=$row[th_prename];
												$position1=$row[position];
												$prename=$row[prename];
												$type1=$row[type];
												$mobile=$row[mobile];
												$person_status=$row[person_status];
												$person_id=$row[person_id];
											?>						  
                              <tr>
                                <td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<a href="find_data.php?person_id=<? print($person_id) ?>&f_type=EMP" target="_blank"  >
								<?

									if ($type1=="2")
										print "���˹�ҷ��෤�Ԥ�";			
									elseif ($type1=="3")
										print "���˹�ҷ���ԡ���Ԫҡ��";	
									elseif ($type1=="4")	
										print "���˹�ҷ���á��";	
									elseif ($type1=="5")	
										print "���˹�ҷ�����Թ";	
									elseif ($type1=="6")	
										print "�Ţҹء���Ҥ�Ԫ��";		
																															
								?></a></td>
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;
								<a href="find_data.php?person_id=<? print($person_id) ?>&f_type=EMP" target="_blank"  ><? print($prename) ?>&nbsp;<? print($th_name) ?></a></td>  								
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;
								<a href="find_data.php?person_id=<? print($person_id) ?>&f_type=EMP" target="_blank"  ><? print($th_surname) ?></a></td> 		
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? 	
																														if ($mobile=="" or $mobile=="-") 
																																print "�����������";
																															else
																																print $mobile;	?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><div align="center">										
										<? 	if ($person_status==""  or  $person_status =="Y") 
																																		print "����";
																																	else
																																		print "���͡";		
	  																															?></div></td> 						
				              </tr>
							  <? } ?>
							  </table>
							   <table width="583" align="center"  height="5" border="0">
                                          <tr>
                                            <td width="527" height="28" align="right" valign="top"  bgcolor="#FFFFFF"><strong>���ҡ÷����� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ </strong></td>
											<td width="46" height="28" align="left" valign="top"  bgcolor="#FFFFFF">
											<form name="form1" method="post"  action="mis_person1_search.php">									  
											  <input type="submit" name="Submit"  height="10" value="����">
											</form></td>			   																				
                                          </tr>
                                    </table>	 
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
