<? include ("_StartConnection.php")?>
<? include ("_CheckSession.php")?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
	<img src="../resource/img/titre-menu-user.gif" width="16" height="16"> ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
        
    <td width="10" background="../r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="right" valign="top"><a href="mis_Acc_1_paper1.php">&nbsp;<u>�����͡���</u></a>                              </tr>
                             
                              <tr>
								<td align="left" valign="top"><div align="center"><u><b>��¡�ô�ҹ����Թ (�ѹ�֡�����Ѵ��) �Ҥ�Ԫ����ǡ�������������</b></u></div></td>
                              </tr>
                              <tr>
                                <!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
								
								<td align="left" valign="top"><br>
								  
								<!--000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 -->
                                  
								<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->
                                    <table width="652" border="0" align="center">         
									  <?								
										{$sql ="select SUM(`money`) as sum_money,st_num,date_using,date_making,budget_year, name_reserve from reserve_money Group by st_num;";}
							  ?>		<!--$sql = 'SELECT * FROM `reserve_money` LIMIT 0, 30 '; -->
                                      <tr>
                                      
                                        <th width="64" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�Ţ ȸ. </div></th>
                                        <th width="95" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�ѹ���ͧ</div></th>
                                        <th width="99" scope="col" bgcolor="#FFFFCC" align="left"><div align="center">�ѹ���͹��ѵ�</div></th>
                                      
                                        <th width="79" scope="col" bgcolor="#FFFFCC"><div align="center">������ҳ</div></th>
                                        <th width="103" scope="col" bgcolor="#FFFFCC"><div align="center">�ӹǹ�Թ</div></th>
                                        <th width="162" scope="col" bgcolor="#FFFFCC"><div align="center">���ͧ�Թ</div></th>
                                      </tr>
									  
									  <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$list_id= $row[list_id];
												$budget_year=$row[budget_year];
												$st_num= $row[st_num];			
												$title=$row[title];	
												$date_making=$row[date_making];				
												$sum_money=$row[sum_money];	
												$name_reserve=$row	[name_reserve];		
												$date_using=$row[date_using];											
										?>						  
                                      <tr>
                                      
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($st_num)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($date_using)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><?
											if ($date_using==$date_making)
											print "�ѧ���͹��ѵ�";
											 else print($date_using)?></div></td>
                                       
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($budget_year)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? print($sum_money)?></div></td>
                                        <td align="left" valign="top" bgcolor="#FFFFEA"><? print($name_reserve)?></td>
                                      </tr>
									  <? } ?>		
                                    </table>
									<!--0000000000000000000000000000 table 000000000000000000000000000000000000000000000000000 -->
								

    
                                    <table width="100%" align="right">
                                      <tr>
                                        <th width="92%" scope="col"><div align="right">�ͧ�Թ������ &nbsp;<? print ($num_rows)?> ��¡��</div></th>
                                        <th width="8%" scope="col"></th>
										
                                      </tr>
                                    </table>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1>
            <hr align=center width="95%" size=2></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
