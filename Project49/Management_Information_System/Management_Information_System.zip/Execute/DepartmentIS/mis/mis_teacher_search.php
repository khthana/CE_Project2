<?
session_start();	
 include ("_StartConnection.php");
 include("_CheckSession.php"); 
 ?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css"> 
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title></head>

<body class="classbody">
<table width="800" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
	<img src="../resource/img/titre-menu-user.gif" width="16" height="16"> ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
        
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
									<br>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="right" valign="top">&nbsp;<a href="find_paper.php?f_type=TCH" target="_blank"><u>�����͡��� </u></a>                                 								   
                                   <div align="center"><strong>��ª��ͤ�Ҩ���� �Ҥ�Ԫ����ǡ�������������</strong></div></td></tr>
                           <td>
						   <br>
						   	
							 <!--<input name="Tgrade" type="text" width="76" vspace="10"> -->
							
						   <table width="658"align="center" >
							  <?
											$Tcode = $_POST["Tcode"];	
											$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];		
											$Ttelephone1	= $_POST["Ttelephone1"];	
											$T_Email = $_POST["T_Email"];	
											$Tstatus = $_POST["Tstatus"];							
																				   
			if(empty($Tcode) AND empty($Tname) AND empty($Tsname) AND empty($Ttelephone1) AND empty($T_Email) AND empty($Tstatus))
								{$sql = "SELECT * FROM person where (type='0' or type='1' or type='6')";}				
			if (!empty($Tcode) AND empty($Tname) AND empty($Tsname) AND empty($Ttelephone1) AND empty($T_Email) AND empty($Tstatus)){							
							if($Tcode == '�Ҩ����'){ 
							   $sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and position IS NULL ";					
							  }  else {$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and position Like '".$Tcode."%'";}					
             }
			if (empty($Tcode) AND !empty($Tname) AND empty($Tsname) AND empty($Ttelephone1) AND  empty($T_Email) AND empty($Tstatus))
								{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and th_name Like '".$Tname."%'";}															
			if (empty($Tcode) AND empty($Tname) AND !empty($Tsname) AND empty($Ttelephone1) AND empty($T_Email) AND empty($Tstatus))
								{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and th_surname Like '".$Tsname."%'";}		
																							
			if (empty($Tcode) AND empty($Tname) AND empty($Tsname) AND !empty($Ttelephone1)  AND empty($T_Email) AND empty($Tstatus))
					{	if($Ttelephone1=='�����')
									{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and (mobile IS NULL or mobile='-')";}
						else		{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and mobile Like '".$Ttelephone1."%'" ;}
						}	
			if (empty($Tcode) AND empty($Tname) AND empty($Tsname) AND empty($Ttelephone1)  AND !empty($T_Email) AND empty($Tstatus))						
					{		if($T_Email == '�����') 
							   			{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and (email IS NULL or email='-')";}				
							else 	{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and email Like '".$T_Email."%'";}					
             		}		
			if (empty($Tcode) AND empty($Tname) AND empty($Tsname) AND empty($Ttelephone1)  AND empty($T_Email) AND !empty($Tstatus))	
					{		if ($Tstatus=='�鹨ҡ���˹�')
									{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) AND person_status = 'n'";	}
									else
									{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) AND person_status = 'y'";	}}
								//{$sql ="SELECT * FROM person where (type='0' or type='1' or type='6' ) and  Email Like '".$T_Email."%'" ;}															
			if (empty($Tcode) AND !empty($Tname) AND !empty($Tsname) AND empty($Ttelephone1) AND empty($T_Email) AND empty($Tstatus))
		    					{$sql ="select * from person where (type='0' or type='1' or type='6' ) and th_name Like '".$Tname."%'"." AND th_surname Like '".$Tsname."%'";}		
								
						     $_SESSION["F_SQL"] = $sql;									
							  ?>

							  <tr>
							  <form name="form1" method="post" action="mis_teacher_search.php">							  
							    <td align="center" valign="top"><!--<input name="Tcode" type="text" size="15" align="right"  width="120"> -->
							     	 <select name="Tcode" tabindex="3" >
									 <option></option>
								  	<option>�Ҩ����</option>
								  	<option>��.</option>									
									<option>��.</option>
									<option>��.</option>
									
							        </select>
							      </td>
							    <td align="left" valign="top"><input name="Tname" type="text" size="12"  width="50"></td>
							    <td align="left" valign="top"><input name="Tsname" type="text" size="12" width="100"></td>
							    <td align="left" valign="top"><input name="T_Email" type="text" size="18" width="100"></td>
							    <td align="left" valign="top"><input name="Ttelephone1" type="text" size="10" width="80"></td>
							    <td align="left" valign="top" width="97"><!--<input type="text" name="Tstatus" size="10"> -->
								<select name="Tstatus">
								<option></option>
								<option>��Ҩ����</option>
								<option>�鹨ҡ���˹�</option>
								</select>
								</td>
							    <td align="left" valign="top"><input name="submit" type="submit" value="����"></td>
								 </form>
							  </tr>
							  <tr>
                                <td width="103" align="left"  valign="middle" bgcolor="#FFFFCC"><div align="center"><b>���˹��Ԫҡ�� </b></div></td>
								<td width="126" align="left" valign="middle" bgcolor="#FFFFCC"><div align="center"><b>����</b></div></td>
								<td width="125" align="left"  valign="middle" bgcolor="#FFFFCC"><div align="center"><b>���ʡ��</b></div></td>
								<td width="148" align="left"  valign="middle" bgcolor="#FFFFCC"><div align="center"><b>Email</b></div></td> 
								<td width="107" align="left"  valign="middle" bgcolor="#FFFFCC"><div align="center"><b>���Ѿ��</b></div></td>
								<td width="107" align="left" valign="middle" bgcolor="#FFFFCC"><div align="center"><b>ʶҹ�</b></div></td>
				              </tr>
							 
							<?   $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");				
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{										
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$position1=$row[position];
												$email = $row[email];
												$person_id=$row[person_id];
												$person_status=$row[person_status];
												$telephone1=$row[mobile];?>						  
                              <tr>
                                <td align="left" valign="top" bgcolor="#FFFFEA"><!--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; --><div align="center"><? 								
											if ($position1 == "")
												print "�Ҩ����";
											else
												print ($position1);
								?></div></td>
								<td align="left" valign="top" bgcolor="#FFFFEA">
								<a href="find_data.php?person_id=<? print($person_id) ?>&f_type=TCH" target="_blank"  ><? print($th_name) ?></a></td>
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? print($th_surname) ?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? 
								if($email=="")
										print "����� Email";
								else
										print $email;
										?></td> 
										
								<td align="left" valign="top" bgcolor="#FFFFEA">&nbsp;<? 							
									if ($telephone1=="") 
										print "�����������";
									else
										print $telephone1;								
								?> </td>
								<td width="97" align="left" valign="top"  bgcolor="#FFFFEA">	<div align="center">
										<? 
	  																																if ($person_status==""  or  $person_status =="Y") 
																																		print "��Ҩ����";
																																	else
																																		print "�鹨ҡ���˹�";		
	  																															?></div></td>
                              </tr>
							  <? } ?>
							  </table>
						    <table width="100%" align="center"  border="0">                                          
                                            <tr>
                                              <td width="652" align="right" valign="top"  bgcolor="#FFFFFF"><b>��Ҩ��������� &nbsp;<? print ($num_rows)?> &nbsp; ��ҹ</b></td>
                                              <td width="122"  height="28" align="right" valign="top"  bgcolor="#FFFFFF">&nbsp;</td>
                                            </tr>		                                         
                                    </table></td>
									</table>	</td>   
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
