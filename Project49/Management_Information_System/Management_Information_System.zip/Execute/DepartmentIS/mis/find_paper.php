<?
	session_start();	
	$ch = $_GET["f_type"];   
	$_SESSION["type"] = "0";
    
	if($ch == "STD") header("Location: student/mis_student_paper1.php");
	if($ch == "TCH") header("Location: teacher/mis_teacher_paper1.php");
	if($ch == "EMP") header("Location: person/mis_Person1_paper1.php");		
	if($ch == "MD") header("Location: manager/manager_paper1.php");	
	if($ch == "ACC") header("Location: Acc/mis_acc_loading.php");		
 
?>