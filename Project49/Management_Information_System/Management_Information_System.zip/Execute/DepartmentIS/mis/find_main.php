<?
	session_start();	   
	$_SESSION["type"] = "0";
    header("Location: ../index_01.php");
 
?>