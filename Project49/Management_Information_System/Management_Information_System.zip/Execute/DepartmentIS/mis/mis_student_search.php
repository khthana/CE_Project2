<?
session_start();	
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody" >

<table width="800" height="364" border="0" align="center" cellpadding="0" cellspacing="0">
     <tr>  <th height="97" colspan="3" scope="col"><img src="../resource/img/newlogo.gif" width="750" height="95"></th>   </tr>
         
  
   <tr>  <td width="11" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="779" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="18" height="21"> 
    ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td></tr>
  
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td width="784" valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=10 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td height="161" valign=top  background="../resource/img/border_footer04.jpg"><img  height=8 src="../resource/img/border_footer04.jpg" width=8></td>                     
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              
                                <tr><td align="left" valign="top"><div align="left"><? include ("_menu.php") ?></div></td></tr>
<td align="right" valign="top">&nbsp;<a href="find_paper.php?f_type=STD" target="_blank"><u>�����͡��� </u></a>
                                 <!--<td align="right" valign="top">&nbsp;<a href="student/mis_student_paper1.php"><u>�����͡��� </u></a> &Tgrade=$Tgrade-->
								 <div align="center"><strong>��ª��͹ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div><br></td></tr>			     					  
							      <td>					
							
							
							<table width="680" align="center" >
							  <?
							  				$Tcode1 = $_POST["Tcode"];	
											$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];		
											$Tsex=$_POST["Tsex"];	
											$gpa=$_POST["gpa"];		
											$T_phone=$_POST["T_phone"];	
											$Tstatus=$_POST["Tstatus"];		
											$Tsection = $_POST["Tsection"];				
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND student_id";}
		if (!empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND student_id Like '".$Tcode1."%'";}
		if (empty($Tcode1) AND !empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND th_name Like '".$Tname."%'";}											
		if (empty($Tcode1) AND empty($Tname) AND !empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND th_surname Like '".$Tsname."%'";}	
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND !empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND gender Like '".$Tsex."%'";}	
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND !empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
				{	if($T_phone=='�����')
							{$sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND  (telephone_contact IS NULL or telephone_contact='-')";}
					else
							{$sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND (telephone_contact Like '".$T_phone."%')";}
								}
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND !empty($Tstatus) AND empty($Tsection))	
					{	if ($Tstatus=='�ѡ�֡��')
							 $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND std_status ='y'";
							else  if ($Tstatus=='����Ҿ')
							 $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND std_status ='n'";	
							else
							 $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05)";
							}		
							
				if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND !empty($Tsection))	
							{	if ($Tsection=='D')
							{ $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND exam1 ='��ѡ�ٵû���'";}	
							else 
							{ $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND exam1 ='������ͧ����'";}								
							}	
							
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND !empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
					{$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND gpa Like '".$gpa."%'";}													
		
		if (empty($Tcode1) AND empty($Tname) AND empty($Tsname) AND empty($Tsex) AND !empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND !empty($Tsection))
					{	if ($Tsection=='D')
							 $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND exam1 ='��ѡ�ٵû���' and gpa Like '".$gpa."%'";
							else 
							 $sql ="SELECT * FROM student where (faculty_id =01 AND dept_id=05) AND exam1 ='������ͧ����' and gpa Like '".$gpa."%'";
							}	
					//$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND gpa Like '".$gpa."%'";													
		//if (empty($Tcode) AND empty($Tname) AND empty($Tsname)!empty($Tgrade)){$sql ="select * from student where th_surname Like ".$Tgrade;}				
		if (empty($Tcode1) AND !empty($Tname) AND !empty($Tsname) AND empty($Tsex) AND empty($gpa) AND empty($T_phone) AND empty($Tstatus) AND empty($Tsection))
		    {$sql ="select * from student where (faculty_id =01 AND dept_id=05) AND th_name Like '".$Tname."%'"." AND th_surname Like '".$Tsname."%'";}				
			
	     $_SESSION["F_SQL"] = $sql;
										
							  ?>							  
							    <tr>
								<form name="form1" method="post" action="mis_student_search.php">
							      <td align="left" valign="top"  height="10"><input name="Tcode" type="text" size="10" align="right" ></td>
								  
									
							      <td align="left" valign="top"  height="10"><input name="Tname" type="text" size="15" ></td>
							      <td align="left" valign="top"  height="10"><input name="Tsname" type="text" size="15" ></td>
							      <td align="center" valign="top"><!--<input type="text" name="Tsection" size="5"> -->
								  	<select name="Tsection">
									<option></option>
									<option>D</option>
									<option>P</option>							
									</select></td>
							      <td align="left" valign="top"  height="10"><!--<input name="Tsex" type="text" size="5"> -->
								  	<select name="Tsex">
									<option></option>
									<option>���</option>
									<option>˭ԧ</option>
									</select></td>
							      <td align="left" valign="top" height="10" ><input name="T_phone" type="text" size="10"></td>
							      <td align="left" valign="top"><input name="gpa" type="text" size="2" width="50" vspace="10"></td>
							      <td align="left" valign="top" height="10" width="63"><!--<input type="Tstatus" name="textfield" size="10"> -->
								  	<select name="Tstatus">
									<option></option>
									<option>�ѡ�֡��</option>
									<option>����Ҿ</option>									
									</select>
								  </td>
							      <td align="left" valign="top"  height="10"><input name="submit" type="submit" value="����" ></td>
								   </form>					
							      </tr>
							    <tr>
							      <td width="84" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><div align="center"><b> ���ʹѡ�֡��</b></div></td>		                             				
								<td width="127" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b>���͹ѡ�֡��</b></td>
								<td width="127" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><b>���ʡ��</b></td> 							
								<td width="58" align="left" valign="top" bgcolor="#FFFFCC"><div align="center"><b>Section</strong></b></td>
								<td width="50" align="left" valign="top"  height="10" bgcolor="#FFFFCC"><div align="center"><b>��</b></div></td> 							  
								<td width="96" align="left" valign="top"  height="10"  bgcolor="#FFFFCC"><b>���Ѿ��</b></td>
								<td width="59" align="left" valign="top" bgcolor="#FFFFCC"><b>GPA</b></td>
								<td width="95" align="left" valign="top" height="10" bgcolor="#FFFFCC"><div align="center"><b>ʶҹ�</b></div></td>
															
				              </tr>
							          <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							while ($row=mysql_fetch_array($table))
									{
												$student_id= $row[student_id];
												$pre_name= $row[pre_name];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$gender=$row[gender];
												$telephone_contact=$row[telephone_contact];
												$std_status=$row[std_status];
												$exam1=$row[exam1];
												$gpa = $row[gpa];
											?>						  

							     <tr> <td align="left" valign="top" bgcolor="#FFFFEA"> 
								<a href="find_data.php?person_id=<? print($student_id) ?>&f_type=STD" target="_blank"  ><div align="center"><? print($student_id) ?></div></a></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA"><? print($pre_name)?>&nbsp;<? print($th_name)?></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_surname) ?></td> 
								  <td align="left" valign="top" bgcolor="#FFFFEA" width="54"><div align="center"><? 
																															if($exam1=="��ѡ�ٵû���")
																																print ("D");
																															else if($exam1=="������ͧ����")
																																print ("P");
																																else 
																																print 'NULL';
																															?>	</div></td>
								  <td align="left" valign="top" bgcolor="#FFFFEA" width="38"><div align="center"><? 
																															if($gender=="���")
																																print ("���") ;
																															else
																																print ("˭ԧ");
																																?>		</div>			</td>			  
								    <td align="left" valign="top" bgcolor="#FFFFEA"><?
																								if ($telephone_contact==""  or  telephone_contact =="-") 
																									print "�����������";
																								else
																									print $telephone_contact;								
																							?></td>
								    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="right"><? print($gpa) ?></div></td>
								    <td align="left" valign="top" bgcolor="#FFFFEA"><div align="center"><? 
																																	if ($std_status =="Y") 
																																		print "�ѡ�֡��";
																																	else 
																																		print "����Ҿ";		
																																	
																															?></div></td>
								    </tr>				                	
							          <? } ?>									
						            </table> 
									 <table width="100%" align="right"  border="0">                                          
                                            <tr>
                                              <td width="87%" align="right" valign="top"  bgcolor="#FFFFFF"><b>�ѡ�֡�ҷ����� &nbsp;<? print ($num_rows)?> &nbsp; ��</b></td>
                                            <td width="13%"  height="28" align="right" valign="top"  bgcolor="#FFFFFF">&nbsp;</td>
                                            </tr>		                                         
                                    </table></td>
									</table>	</td>														                																									 				  
                            <td valign=top background="../resource/img/border_footer05.jpg"><img height=8 src="../resource/img/border_footer05.jpg" width=8></td>          
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="45" colspan="3" class ="classinfo" scope="col"><div align="center">
      <hr align=center width="95%" size=2> 
        Department of Computer Engineering Faculty of Engineering King Mongkut'sInstitute of Technology<BR>
    Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>