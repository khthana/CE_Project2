<?
session_start();	
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>
<body class = "classbody" >
<table width="800" height="364" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="11" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="779" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="18" height="21"> 
    ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td width="784" valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=10 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td height="161" valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
							  <td align="right" valign="top">&nbsp;<a href="find_paper.php?f_type=STD" target="_blank"><u>�����͡��� </u></a>
                                <!--<td align="left" valign="top">&nbsp;
                                  <a href="mis_student_paper1.php">print</a> -->
                                  <div align="center"><strong>�ѡ�֡�� �Ҥ�Ԫ����ǡ�������������</strong></div>
                                  <br></td></tr>								  
							      <td>
								  
								  <table width="393" align="center"  border="0">
							  <?								

   						        $sql ="SELECT semester,count(semester) FROM student where faculty_id =01 AND dept_id=05 GROUP BY semester Order by semester DESC";
							
								    $_SESSION["F_SQL"] = $sql;	
									
							  ?>							  

								
							     <tr> 
								 <td width="73" align="center" valign="top" bgcolor="#FFFFCC"><b> �ա���֡�� </b></td>
								  <td width="64" align="center" valign="top" bgcolor="#FFFFCC"><b>�ӹǹ</b></div></td>
								  <td colspan="4" align="center" valign="top" bgcolor="#FFFFCC">&nbsp; </td>
								    </tr>										
							          <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");		
									$num_rows = mysql_num_rows($table);				 
							         while ($row=mysql_fetch_array($table))
									{
												$year_std= $row[semester];
												$year_num= $row[count(semester)];
									
										?>						  
							          
							     <tr> 
								 <td align="center" valign="top" bgcolor="#F4FFE6"><? print($year_std) ?></td>
								 <td align="center" valign="top" bgcolor="#F4FFE6"><? print($year_num)?></td>
								  <td width="331" colspan="4"  valign="top" bgcolor="#F4FFE6">&nbsp;</td>
  							      </tr>		
								  <tr>
								  <td colspan="2">&nbsp;</td>
								  <td colspan="4">
								  		      <table width="100%">
											    <?
 										                 $sql_exam ="SELECT  exam1,count(exam1) FROM student where faculty_id =01 AND dept_id=05 AND semester = ".$year_std." Group by exam1";
													 //    print("<tr><td colspan =2 ><font color=#ff0000>".$sql_exam."</font></tr></td>");
								  						$table_exam = mysql_query($sql_exam,$conn) or die ("No connect Database.");		
												         while ($row_exam=mysql_fetch_array($table_exam)) {
														 			$exam_std= $row_exam[exam1];
																	$exam_num= $row_exam[count(exam1)];																								 												                    
											    ?>
												
												       <tr >
														    <td width="63" align="center" valign="top" bgcolor="#F4FFE6"><div align="left"><? print($exam_std) ?></div></td>
								  							<td width="39" align="center" valign="top" bgcolor="#F4FFE6"><div align="left"><? print($exam_num)?></div></td>
															<td width="139"  colspan="2" bgcolor="#F4FFE6" >&nbsp;</td>
												       </tr>
													   <tr><td colspan="2"></td><td colspan="2">
													   			         	     <table width="100%">
											                                     <?
 										                                           //$sql_sex ="SELECT  * FROM student where faculty_id =01 AND dept_id=05 AND semester = ".$year_std." Group by gender";
								   $sql_sex ="select  gender,count(gender) FROM student where faculty_id =01 AND dept_id=05 AND semester =" .$year_std." AND exam1 = '".$exam_std."' Group by gender ";
													                               //    print("<tr><td colspan =2 ><font color=#ff0000>".$sql_sex."</font></tr></td>");
								  					   	                           $table_sex = mysql_query($sql_sex,$conn) or die ("No connect  DB Sex.");		
												                                   while ($row_sex=mysql_fetch_array($table_sex)) {
														 		  	               $gender_std= $row_sex[gender];
																				   $gender_num= $row_sex[count(gender)];
 
											                                    ?>
																				<tr>
																		          <td width="61"   align="left" valign="top" bgcolor="#F4FFE6"><div align="left"><? print($gender_std)?></div></td>
																		          <td width="129"   align="left" valign="top" bgcolor="#F4FFE6"><div align="left"><? print($gender_num)?></div></td>  
																				  </tr>
																			   <? } ?>
																			   </table>							
													   
													   
													   
													</td><tr>   
												<? } ?>	   
						  			      </table>
										  
								   </td>
								  
								  </tr>

						    <? } ?>									
						      </table>	
				                 </td>																										 
							      </table></td>		
								  					  
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="45" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
    Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
