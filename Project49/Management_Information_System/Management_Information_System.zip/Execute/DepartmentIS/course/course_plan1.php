<?
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
       
 <?
		include("_menu.php");
		?>
</div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="2" cellpadding="3">
                                <tr valign="middle"> 
                                  <td colspan="3" align="left"><div align="center"><img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                      Ἱ������¹</div></td>
                                </tr>
                                <tr> 
                                  <td colspan="3" align="left" valign="top"><div align="left">���������֡�ҷ�� 
                                      1 (��ѡ�ٵ� 4 ��)</div></td>
                                </tr>
                                <tr> 
                                  <td colspan="3" align="left" valign="top"> �շ�� 
                                    1 �Ҥ����֡�ҷ�� 1</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '1'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 031500__</td>
                                  <td align="left" valign="top">�Ԫ����͡�ҧ�������ʵ��<br>
                                    ELECTIVE COURSES IN HUMANITIES</td>
                                  <td align="left" valign="top">2 (2 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">19 
                                    (17 - 10)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp; </td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  1 �Ҥ����֡�ҷ�� 2</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '1'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 031500_</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ�ѧ����ʵ��<br>
                                    ELECTIVE COURSES IN SOCIAL SCIENCE</td>
                                  <td align="left" valign="top">2 (2 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">19 
                                    (17 - 8)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  2 �Ҥ����֡�ҷ�� 1</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '2'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 030_____ 
                                  </td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ����<br>
                                    ELECTIVE IN LANGUAGE</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">18 
                                    (15 - 9)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  2 �Ҥ����֡�ҷ�� 2</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '2'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 030_____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ����<br>
                                    ELECTIVE IN LANGUAGE</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">18 
                                    (15 - 9)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  3 �Ҥ����֡�ҷ�� 1</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '3'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">18 
                                    (18 - 0)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  3 �Ҥ����֡�ҷ�� 2</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '3'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">19 
                                    (18 - 3)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  3 �Ҥ����֡�ҷ�� 3</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '3'
								AND term = '3'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top">˹��¡Ե���</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">0 (0 - 0)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  4 �Ҥ����֡�ҷ�� 1</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '4'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 01______</td>
                                  <td align="left" valign="top"> �Ԫ����͡�����<br>
                                    FREE ELECTIVE COURSES</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">15 
                                    (12 - 9)</td>
                                </tr>
                                <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <td colspan="3" align="left" valign="top"> �շ�� 
                                  4 �Ҥ����֡�ҷ�� 2</td>
                                </tr>
                                <tr> 
                                  <td width="18%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="38%" align="left" valign="top" bgcolor="#CCCCCC">�����Ԫ�</td>
                                  <td width="44%" align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե 
                                    (������ - ��Ժѵ�)</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '1'
								AND pyear = '4'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    ) </td>
                                </tr>
                                <?
									}
								?>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 01______</td>
                                  <td align="left" valign="top"> �Ԫ����͡�����<br>
                                    FREE ELECTIVE COURSES</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 0107____</td>
                                  <td align="left" valign="top"> �Ԫ����͡�ҧ���ǡ�������������<br>
                                    ELECTIVE COURSES IN COMPUTER ENGINEERING</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <br> &nbsp; 01______</td>
                                  <td align="left" valign="top"> �Ԫ����͡�����<br>
                                    FREE ELECTIVE COURSES</td>
                                  <td align="left" valign="top">3 (3 - 0)</td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top" bgcolor="#CCCCCC">˹��¡Ե���</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">&nbsp;</td>
                                  <td align="left" valign="top" bgcolor="#CCCCCC">15 
                                    (12 - 9)</td>
                                </tr>
                                <tr> 
                                  <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '1'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '1'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '2'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '2'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '3'
								AND term = '1'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                                <?
								$sql ="SELECT *
								FROM plansubject p, subject s
								WHERE p.scode = s.scode
								AND plan_id = '2'
								AND pyear = '3'
								AND term = '2'
								";
								$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											
								
								?>
                                <?
									}
								?>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<?
include ("_EndConnection.php");
?>
</body>
</html>
