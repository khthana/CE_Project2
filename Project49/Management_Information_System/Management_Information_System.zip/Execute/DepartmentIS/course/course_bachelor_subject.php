<?
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >


<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
         <?
		include("_menu.php");
		?>
		</div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="98%" border="0" cellspacing="3" cellpadding="2">
                                <tr bgcolor="#CCCCCC"> 
                                  <td colspan="4" align="left" valign="top"><div align="center"><img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                      �ç���ҧ��ѡ�ٵ� </div></td>
                                </tr>
                                <?
									//$category_id = $category_id;
									//$gsubject_id = $gsubject;  //�Ѻ���Ẻ get
									$sql1="SELECT * 
									FROM category c, groups g 
									WHERE c.category_id = g.category_id 
									AND c.category_id = '$category_id' 
									AND g.gsubject_id = '$gsubject_id' ";
									$table = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��");
									$row=mysql_fetch_array($table);
										$category = $row[category];
										$cprogram_unit1 = $row[cprogram_unit1];
										$cprogram_unit2 = $row[cprogram_unit2];
								
										$gsubject = $row[gsubject];
										$gprogram_unit1 = $row[gprogram_unit1];
										$gprogram_unit2 = $row[gprogram_unit2];
								?>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="2" align="left" valign="top">&nbsp;</td>
                                  <td width="28%" align="left" valign="top">���������֡�ҷ�� 
                                    1</td>
                                  <td width="28%" align="left" valign="top">���������֡�ҷ�� 
                                    2 </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$category?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$cprogram_unit1?>
                                    ˹��¡Ե </td>
                                  <td align="left" valign="top"> 
                                    <?=$cprogram_unit1?>
                                    ˹��¡Ե </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td width="11%" align="left" valign="top">&nbsp;</td>
                                  <td width="33%" align="left" valign="top"> 
                                    <?=$gsubject?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$gprogram_unit1?>
                                    ˹��¡Ե </td>
                                  <td align="left" valign="top"> 
                                    <?=$gprogram_unit2?>
                                    ˹��¡Ե </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top"> ˹��¡Ե (������ 
                                    - ��Ժѵ�)</td>
                                  <td align="left" valign="top"> ˹��¡Ե (������ 
                                    - ��Ժѵ�)</td>
                                </tr>
								
                               
								<?
								$sql = "SELECT *
											FROM groups g, subject s
											WHERE g.gsubject_id = s.gsubject_id
											AND g.gsubject_id = '$gsubject_id' ";
											
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table))
									{
											$scode = $row[scode];
											$th_name = $row[th_name];
											$en_name = $row[en_name];
											$unit = $row[unit];
											$unit_d = $row[unit_d];
											$unit_o = $row[unit_o];
											$unit1 = $row[unit1];
											$unit_d1 = $row[unit_d1];
											$unit_o1= $row[unit_o1];
								?>
								 <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">
                                    <a href ="course_bachelor_subjectlink.php?scode=<?=$scode?>"><?=$scode?></a>
                                  </td>
                                  <td align="left" valign="top">
                                    <?=$th_name?><br><?=$en_name?>
                                  </td>
                                  <td align="left" valign="top"> 
                                    <?=$unit?>
                                    ( 
                                    <?=$unit_d?>
                                    - 
                                    <?=$unit_o?>
                                    )</td>
                                  <td align="left" valign="top">
                                    <?=$unit1?>
                                    ( 
                                    <?=$unit_d1?>
                                    - 
                                    <?=$unit_o1?>
                                    )</td>
								   </tr>  
								   <?
									} // �� loop while �ͧ�Ԫ����¹ (subject)
								?>
                             
                               
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<?
include ("_EndConnection.php");
?>
</body>
</html>
