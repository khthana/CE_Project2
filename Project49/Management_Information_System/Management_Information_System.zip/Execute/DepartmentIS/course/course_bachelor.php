<?
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >

<?
	$sql ="SELECT * FROM intro t, structure s WHERE t.course_year = s.course_year";
	$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
	$row=mysql_fetch_array($table);
	
	$course_year = $row[course_year];
	$th_name = $row[th_name];
	$en_name = $row[en_name];
	$th_fname = $row[th_fname];
	$th_sname = $row[th_sname];
	$en_fname = $row[en_fname];
	$en_sname = $row[en_sname];
	$program_unit1 = $row[program_unit1];
	$program_unit2 = $row[program_unit2];
	$struct_id = $row[struct_id];

	


?>
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
        <?
		include("_menu.php");
		?>
		</div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="98%" border="0" cellspacing="3" cellpadding="2">
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top"><div align="center">��ѡ�ٵ����ǡ�����ʵúѳ�Ե 
                                      �Ң��Ԫ����ǡ�������������<br>
                                      ��ѡ�ٵû�Ѻ��ا �� �.�. 
                                      <!--<input name="textfield" type="text" value="<?=$course_year?>" size="1"> -->
									    <select name="select">
                                        <option><?=$course_year?></option>
                                      </select>
                                      <br>
                                      �Ҥ�Ԫ����ǡ������������� ������ǡ�����ʵ��<br>
                                      ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</div></td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top"><div align="left">&nbsp; 
                                      <img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                      ������ѡ�ٵ� 
                                    
                                      
                                      
                                    </div></td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td width="20%" align="left" valign="top">&nbsp; 
                                    ����������</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$th_name ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top"> &nbsp;���������ѧ���</td>
                                  <td colspan="2" align="left" valign="top"> &nbsp; 
                                    <?=$en_name ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp; 
                                    <img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                    ���ͻ�ԭ��</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;������� 
                                    (��)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$th_fname ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;������� 
                                    (��)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$th_sname ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;������� 
                                    (�ѧ���)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$en_fname ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;������� 
                                    (�ѧ���)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$en_sname ?>
                                  </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp; 
                                    <img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                    ��ѡ�ٵ�</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp; 
                                    <img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                    �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;���������֡�ҷ�� 
                                    1 (��ѡ�ٵ� 4 ��)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$program_unit1 ?>
                                    ˹��¡Ե </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top"> &nbsp;���������֡�ҷ�� 
                                    2 (��ѡ�ٵ���º�͹)</td>
                                  <td colspan="2" align="left" valign="top">&nbsp; 
                                    <?=$program_unit2 ?>
                                    ˹��¡Ե </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top">&nbsp;</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top"> <img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                    �ç���ҧ��ѡ�ٵ�</td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td width="39%" align="left" valign="top">���������֡�ҷ�� 
                                    1</td>
                                  <td width="41%" align="left" valign="top">���������֡�ҷ�� 
                                    2</td>
                                </tr>
                                <?
									$sql1 = "select * from  category where struct_id = $struct_id";
									$table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table1))
									{
											$category_id = $row[category_id];
											$category = $row[category];
											$cprogram_unit1 = $row[cprogram_unit1];
											$cprogram_unit2 = $row[cprogram_unit2];					
											
											
								?>
                                <tr bgcolor="#CCCCCC"> 
                                  <td align="left" valign="top"><strong>&nbsp; 
                                    <?=$category?>
                                    </strong></td>
                                  <td align="center" valign="top">&nbsp; 
                                    <?=$cprogram_unit1?>
                                    ˹��¡Ե </td>
                                  <td align="center" valign="top">&nbsp; 
                                    <?=$cprogram_unit2?>
                                    ˹��¡Ե </td>
                                </tr>
                                <?
									$sql2 = "select * from  groups where category_id = '$category_id'";
									$table2 = mysql_query($sql2,$conn) or die ("�������ö���¡������㹵��ҧ��");
									while ($row = mysql_fetch_array($table2))
									{
											$gsubject_id = $row[gsubject_id];
											$gsubject = $row[gsubject];
											$gprogram_unit1 = $row[gprogram_unit1];
											$gprogram_unit2 = $row[gprogram_unit2];
								?>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp; 
                                    <a href ="course_bachelor_subject.php?category_id=<?=$category_id?>&gsubject_id=<?=$gsubject_id?>"><?=$gsubject?> </a>
                                  </td>
                                  <td align="center" valign="top">&nbsp; 
                                    <?=$gprogram_unit1?>
                                    ˹��¡Ե </td>
                                  <td align="center" valign="top">&nbsp; 
                                    <?=$gprogram_unit2?>
                                    ˹��¡Ե </td>
                                </tr>
                                <?
										} // �� loop while �ͧ������Ԫ� (Groups)
								?>
                                <?
									} // �� loop while �ͧ��Ǵ�Ԫ� (Category)
								?>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;��ʹ��ѡ�ٵ�</td>
                                  <td align="center" valign="top"> &nbsp; 
                                    <?=$program_unit1 ?>
                                    ˹��¡Ե </td>
                                  <td align="center" valign="top"> &nbsp; 
                                    <?=$program_unit2 ?>
                                    ˹��¡Ե </td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<?
include ("_EndConnection.php");
?>
</body>
</html>
