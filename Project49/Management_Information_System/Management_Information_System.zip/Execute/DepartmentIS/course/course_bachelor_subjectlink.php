<?
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >

<?
	$sql ="SELECT * FROM  subject where scode = '$scode'";
	$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
	$row=mysql_fetch_array($table);
	
	$scode = $row[scode];
	$th_name = $row[th_name];
	$en_name = $row[en_name];
	$unit = $row[unit];
	$unit_d = $row[unit_d];
	$unit_o = $row[unit_o];
	$scode_to = $row[scode_to];
	$sdetail= $row[sdetail];
	$url = $row[url];
	

	


?>
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left">
        <?
		include("_menu.php");
		?>
		</div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="98%" border="0" cellspacing="3" cellpadding="2">
                                <tr bgcolor="#CCCCCC"> 
                                  <td colspan="3" align="left" valign="top"><div align="center"><img src="../resource/img/bullet-blue.gif" width="9" height="13"> 
                                      ��͸Ժ������Ԫ�</div></td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td width="15%" align="left" valign="top">&nbsp; 
                                    <?=$scode?>
                                  </td>
                                  <td width="51%" align="left" valign="top">&nbsp; 
                                    <?=$th_name?>
                                    <br> &nbsp; 
                                    <?=$en_name?>
                                    <br> &nbsp;�ԪҺѧ�Ѻ��͹: 
                                    <?=$scode_to?>
                                  </td>
                                  <td width="34%" align="left" valign="top"><div align="center">˹��¡Ե 
                                      (������ - ��Ժѵ�)<br>
                                      <?=$unit?>
                                      ( 
                                      <?=$unit_d?>
                                      - 
                                      <?=$unit_o?>
                                      ) </div></td>
                                </tr>
                                <tr bgcolor="#F2F2F2"> 
                                  <td colspan="3" align="left" valign="top"> &nbsp; 
                                    <?=$sdetail?>
                                  </td>
                                </tr>
                              </table>
                              <br>
                            </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<?
include ("_EndConnection.php");
?>
</body>
</html>
