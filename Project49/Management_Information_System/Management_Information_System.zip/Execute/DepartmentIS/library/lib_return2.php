<?
include("_CheckSession.php"); 
include ("_StartConnection.php");

if($book != "") {		   //����� �� check box
		foreach ($book as $eachbook) {
					$sql = "update bookborrow
								set bstatus = '0' where borrowid = $eachbook";
					if( mysql_query($sql,$conn) ){
							header("Location: lib_return1.php");
					}
					else	{											
							//header("Location: store_borrowstatus_fail.php");
							print $sql;
							print "Has problem to update";
					}			
		}	
}	
header("Location: lib_return1.php");											
									  
 ?>


