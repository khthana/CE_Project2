<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
include("../resource/_res_function.php");
 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"> <img src="../resource/img/icon_required.gif" width="11" height="11">&nbsp;�ѡ�֡�ҹ͡�Ҥ�Ԫ��<br>
                                    <br>
                                    <table 
                              width=841 height="52" border=1 cellpadding=2 cellspacing=0 
                              bordercolor=#c0c0c0  style="BORDER-COLLAPSE: collapse">
                                      <tr bgcolor="#CCCCCC"> 
                                        <td width="42">�ӴѺ</td>
                                        <td width="113">���</td>
                                        <td width="130">�Ҥ�Ԫ�</td>
                                        <td width="81">���ʹѡ�֡��</td>
                                        <td width="114">����</td>
                                        <td width="106"> ���ʡ�� </td>
                                        <td width="88"> ���Ѿ�� </td>
                                        <td width="52">���</td>
                                        <td width="59">ź</td>
                                      </tr>
                                      <?
									  $scount = 1;
									 $sql ="select student_id, faculty_id , dept_id, pre_name,th_name,th_surname,telephone_contact
									 			from student
												where not( faculty_id  = '01' and dept_id ='05')
												";
									//print $sql;
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
												while ($row = mysql_fetch_array($table))
												{
														$student_id= $row[0];
														$faculty_id = $row[1];
														$dept_id = $row[2];
														$pre_name = $row[3];
														$th_name = $row[4];
														$th_surname = $row[5];
														$telephone_contact = $row[6];
									  
									  ?>
                                      <tr bgcolor="#FFFFFF"> 
                                        <td>&nbsp; 
                                          <?=$scount?>
                                        </td>
                                        <td>&nbsp;
										<?
										$sql1 = "select faculty_thname from faculty where faculty_id = '$faculty_id' ";
										//print $sql1;
										$table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��");
										$row1 = mysql_fetch_array($table1);
											$faculty_thname = $row1[0];
										?>
                                          <?=$faculty_thname?>
                                        </td>
                                        <td>&nbsp;
										<?
										$sql1 = "select dept_thname from department where dept_id = '$dept_id' and  faculty_id ='$faculty_id' ";
										//print $sql1;
										$table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��");
										$row1 = mysql_fetch_array($table1);
											$dept_thname = $row1[0];
										?>
                                            <?=$dept_thname?>
                                        </td>
                                        <td>&nbsp;
                                            <?=$student_id?>
                                        </td>
                                        <td>&nbsp;
                                          <?  print $pre_name . $th_name ;?>
                                        </td>
                                        <td>&nbsp;
                                            <?=$th_surname?>
                                        </td>
                                        <td>&nbsp;
                                          <?=$telephone_contact?>
                                        </td>
                                        <td> <a href ="lib_std_sdetail.php?std_id=<?=$student_id?>"><img src="../resource/img/icon_template_edit.gif" width="16" height="16" border="0"> </a>
                                        </td>
                                        <td><a href ="lib_std_delsdetail.php?std_id=<?=$student_id?>"><img src="../resource/img/icon_delete.gif" width="16" height="16" border="0"></a></td>
                                      </tr>
                                      <?
									  ++$scount;
									  }
									  
									  ?>
                                    </table>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
