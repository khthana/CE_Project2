<?include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type='text/javascript'>

function formValidator(){
	
	var bookid1 = document.getElementById('bookid1');
	var bookyear = document.getElementById('bookyear');
	var bnamethai = document.getElementById('bnamethai');
	var bnameeng = document.getElementById('bnameeng');
	var advisor1 = document.getElementById('advisor1');
	var student1 = document.getElementById('student1');
	var studentid1 = document.getElementById('studentid1');
	
	// Check each input in the order that it appears in the form!
	if(isNumeric(bookid1, "��سһ�͹����˹ѧ���")){
		if(isNumeric(bookyear, "��سһ�͹�ա���֡��")){
			if(isEmpty(bnamethai, "��سһ�͹����˹ѧ���������")){
				if(isEmpty(bnameeng, "��سһ�͹˹ѧ��������ѧ���")){
					if(isEmpty(advisor1, "��سһ�͹�����Ҩ�������֡��")){
						if(isEmpty(student1, "��سһ�͹���͹ѡ�֡��")){
							if(isNumeric(studentid1, "��سһ�͹���ʹѡ�֡��")){
								var r=confirm("�׹�ѹ�������������˹ѧ���")
								if (r==true){
									return true;
								}
								else{
									return false;
								}						
							}
						}					
					}
				}
			}
		}
	}				
	return false;
}

function isEmpty(elem, helperMsg){
	if(elem.value.length != 0){		
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}


function isNumeric(elem, helperMsg){
	var alphaExp = /^[0-9]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody"  >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">
								  
								    <table width="29%" border="0" align="center" cellpadding="2" cellspacing="2">
                                      <tr>
                                        <td width="8%"><img src="../resource/img/bullet-blue.gif" width="9" height="13"></td>
                                        <td width="92%"><a href="lib_add_std.php">���� ��.�͡�Ҥ�Ԫ��</a></td>
                                      </tr>
                                      <tr>
                                        <td><img src="../resource/img/bullet-blue.gif" width="9" height="13"></td>
                                        <td><a href="lib_detail_std.php">�ʴ���������´ ��.�͡�Ҥ�Ԫ��</a></td>
                                      </tr>
                                    </table>
								    <br>
                                    <br>
                                    <br>
                                    <br>
                                  </td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
