<?
include("_CheckSession.php"); 
include("_StartConnection.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody"  >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
								<?
									$sql = "SELECT bookyear FROM books GROUP BY bookyear";									
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 								
								
								?>
                                  <td align="left" valign="top"><form name="list_year" method="post" action="lib_find_year_result.php">
                                      <div align="center"><img src="../resource/img/search.gif" width="16" height="16"> 
                                        <select name="byear">
											<?
											while ($row = mysql_fetch_array($table))
											{
												$bookyear = $row[bookyear];
											?>
                                          <option value="<?=$bookyear?>" >�ա���֡��  <?=$bookyear?> </option>
										  <?
										  		}
											?>
                                        </select>
                                        <input type="submit" name="Submit" value="�ʴ�">
                                      </div>
                                    </form>
                                    <br>
									          <?
											  //print $byear;
									//$bookyear = $_POST["bookyear"];										

									$sql1 = "select count(*) as c from books WHERE bookyear =  '".$byear."' ";
									$table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��"); 	
									$row = mysql_fetch_array($table1);
									$bookcount1 =  $row[c];
									$bookcount = $bookcount1 /10 + 1;   //�Ѻ�ӹǹ��㹵��ҧ ���ͧ�ӹǹ�Ҩӹǹ˹��						


									if($pagei == ""){
										$pagei =1;
									}

									//��Ǩ�ͺ��Ҥ�� ྨ �繤����ҧ������� �ó��Դ����Ҥ����á

									print "<img src= '../resource/img/point.gif'> ";
									for ($page=1; $page< $bookcount;++$page) {										
										$x = ($page-1)*10;
																				
										print "<a href = lib_find_year_result.php?xi=$x&pagei=$page&byear=$byear>" .$page . " </a>  ";
																	
									}									
									if($xi == "" ){
										$xi=0;																												
									}
									//��Ǩ�ͺ��Ҥ��  �繤����ҧ������� �ó��Դ����Ҥ����á
									
																	
									$countid = ($pagei-1)*10+1;	
										
											$sql = "SELECT * FROM books WHERE bookyear =  '".$byear."' LIMIT $xi,10 ";	
											//print $sql;
											$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
										
												
									?>
                                    <br> <table  style="BORDER-COLLAPSE: collapse" 
                              bordercolor=#c0c0c0 cellspacing=0 cellpadding=2 
                              width=765 border=1>
                                      <tr bgcolor="#CCCCCC"> 
                                        <td width="6%">�ӴѺ</td>
                                        <td width="10%">����˹ѧ���</td>
                                        <td width="27%">����������</td>
                                        <td width="37%">���������ѧ���</td>
                                        <td width="20%">�ա���֡��</td>
                                      </tr>
                                      <tr> 
                                        <?	
				
			while ($row = mysql_fetch_array($table))
			{
					$bookid = $row[bookid];
					$bnamethai = $row[bnamethai];
					$bnameeng = $row[bnameeng];
					$bookyear = $row[bookyear];
					
					
?>
                                        <td>
                                          <?=$countid ?>
                                        </td>
                                        <td> <a href =lib_bookdetail1.php?bookid=<?=$bookid?>  target="_blank">
                                          <?=$bookid ?>
                                          </a></td>
                                        <td>
                                          <?=$bnamethai ?>
                                        </td>
                                        <td>
                                          <?=$bnameeng ?>
                                        </td>
                                        <td>
                                          <?=$byear ?>
                                        </td>
                                      </tr>
                                      <?       ++$countid;
             } //��loop while
?>
                                    </table>
                                    <?
 //            } //�����͹� else
?>
                                    <div align="center"><br>
                                      �š�ä��� <font color ="red"> 
                                      <?=$bookcount1?>
                                      </font> record(s). </div>
                                    <br>
                                    <br>
                                    
                                    <br>
                                    <br>
                                  </td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
    include("_EndConnection.php");
?>
</body>
</html>
