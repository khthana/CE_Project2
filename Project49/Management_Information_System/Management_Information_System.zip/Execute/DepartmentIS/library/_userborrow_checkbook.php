<?		
		$bookid1 = $bookid1;
		$sql = "select * from books where bookid = '$bookid1'";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
				if($row = mysql_fetch_array($table)){	

				
				//session_register( "bo_id");  
				//session_register( "prename");  
				//session_register( "bo_name");  
				session_register( "book_id");  
				session_register( "book_name"); 				
				//session_register( "th_surname");  
					
				$_SESSION["book_id"] =  $row[bookid];	
				$_SESSION["book_name"] =  $row[bnamethai];	
				//$_SESSION["bo_id"] =  $row[student_id];					//���ʹѡ�֡��				
			//	$_SESSION["prename"] =  $row[prename];					//�ӹ�˹�Ҫ���
			//	$_SESSION["bo_name"] =  $row[th_name];				//����
			//	$_SESSION["th_surname"] =  $row[th_surname];		//���ʡ��			

				}	
				else {				

					header("Location: lib_checkbookfail.php");
				}

			$sql = "select * from bookborrow where bookid ='$bookid1' and bstatus ='1' ";
			//print $sql;
			$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
				if($row = mysql_fetch_array($table)){	
					
					$borrow_id =$row[student_id];
					header("Location: lib_validbookfail.php?borrow_id=$borrow_id");		

				}


?>