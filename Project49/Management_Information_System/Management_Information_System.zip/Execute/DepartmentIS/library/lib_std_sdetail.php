<?
include("_CheckSession.php"); 
include("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type='text/javascript'>

function formValidator(){
	
	var std_name = document.getElementById('std_name');
	var std_surname = document.getElementById('std_surname');
	var std_id = document.getElementById('std_id');
	var mobile = document.getElementById('mobile');
	
	
	// Check each input in the order that it appears in the form!
	if(isEmpty(std_name, "��سһ�͹����")){
		if(isEmpty(std_surname, "��سһ�͹���ʡ��")){
			if(isNumeric(std_id, "��سһ�͹���ʹѡ�֡��")){
				if(isNumeric(mobile, "��سһ�͹�����Ţ���Ѿ��")){
					
								var r=confirm("�׹�ѹ������������Źѡ�֡�ҹ͡�Ҥ�Ԫ��")
								if (r==true){
									return true;
								}
								else{
									return false;
								}						
							
				}
			}
		}
	}				
	return false;
}

function isEmpty(elem, helperMsg){
	if(elem.value.length != 0){		
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}


function isNumeric(elem, helperMsg){
	var alphaExp = /^[0-9]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody"  >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">
								  
								  <form name="add_book" method="post" action="lib_edit_stdcheck.php"   onsubmit='return formValidator()'>
								  <?
								  $sql1 ="select * from student where student_id = '$std_id' ";
								  $table1 = mysql_query($sql1,$conn) or die ("�������ö���¡������㹵��ҧ��");
								  $row1 = mysql_fetch_array($table1);
											$prename = $row1[prename];
											$th_name = $row1[th_name];
											$th_surname = $row1[th_surname];
											$student_id = $row1[student_id];
											$faculty_id = $row1[faculty_id];
											$dept_id = $row1[dept_id];
											$telephone_contact = $row1[telephone_contact];
											
											
								  
								  ?>
								      <table 
                              width=650 border=1 align="center" cellpadding=2 cellspacing=0 
                              bordercolor=#c0c0c0 style="BORDER-COLLAPSE: collapse">
                                        <tr> 
                                          <td bgcolor="#F9F9F9"><div align="center"><img src="../resource/img/icon_container.gif" width="13" height="16"> 
                                              ��䢹�. �͡�Ҥ�Ԫ�� </div></td>
                                        </tr>
                                        <tr> 
                                          <td valign="top"> <table width="100%" height="70" border="0" align="center" cellpadding="2" cellspacing="2">
                                            <tr>
                                              <td>�ӹ�˹�Ҫ���<font color="#FF0000">&nbsp;</font></td>
                                              <td><select name="std_prename">
                                                <option value="���">���</option>
                                                <option value="�ҧ���">�ҧ���</option>
                                                <option value="�ҧ">�ҧ</option>
                                              </select></td>
                                            </tr>
                                              <tr> 
                                                <td width="19%">����<font color="#FF0000">&nbsp;</font></td>
                                                <td><input name="std_name" type="text" id="std_name" value="<?=$th_name?>" size="25"></td>
                                              </tr>
                                              <tr> 
                                                <td>���ʡ��<font color="#FF0000">&nbsp;</font></td>
                                                <td><input name="std_surname" type="text"  id ="std_surname" value="<?=$th_surname?>" size="25"></td>
                                              </tr>
                                              <tr> 
                                                <td>���ʻ�Шӵ��<font color="#FF0000">&nbsp;</font></td>
                                                <td><input name="std_id" type="text" id="std_id" value="<?=$student_id?>" size="10" maxlength="8" ></td>
                                              </tr>
                                              <tr> 
                                                <td>���<font color="#FF0000">&nbsp;</font></td>
                                                <td>
												<select name="faculty">
												<?
												$sql1 = "select * from faculty";
												$table1 = mysql_query($sql1,$conn) or die ("can not connect DB"); 	
												while ($row = mysql_fetch_array($table1))
												{
														$faculty_id = $row[faculty_id];
														$faculty_thname = $row[faculty_thname];
														
												
												?>
												
                                                  <option value="<?=$faculty_id ?>"><?=$faculty_thname ?></option>
                                                
												<?
												}
												?>
												</select>
												</td>
                                              </tr>
                                              <tr> 
                                                <td>�Ҥ�Ԫ�<font color="#FF0000">&nbsp;</font></td>
                                                <td><select name="department">
												<?
												$sql1 = "select * from department";
												$table1 = mysql_query($sql1,$conn) or die ("can not connect DB"); 	
												while ($row = mysql_fetch_array($table1))
												{
														$dept_id = $row[dept_id];
														$dept_thname = $row[dept_thname];
														
												
												?>
                                                  <option value="<?=$dept_id ?>"><?=$dept_thname ?></option>
												  <?
												}
												?>
                                                </select></td>
                                              </tr>
                                              <tr> 
                                                <td>�����Ţ���Ѿ��</td>
                                                <td><input name="mobile" type="text" id="mobile" value="<?=$telephone_contact?>"></td>
                                              </tr>
                                            </table> 
                                            <br> &nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td bgcolor="#F9F9F9"><div align="center"> 
                                              <input type="submit" name="Submit" value="   �׹�ѹ   ">
                                            </div></td>
                                        </tr>
                                      </table>
									 </form>
									
									
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                  </td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>

</body>
</html>
