
<?		
		//include("checksession.php");	
		session_start();
		session_unregister("username");
		session_unregister("password");
		session_unset();		
		session_destroy();			
		
		print "<br> <div align ='center'>";
		print "<a href = 'loginpage1.php'> GOTO ME PAGE </a>";
?>
