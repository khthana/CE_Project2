<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody"  >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"><table width="87%" border="0" align="center" cellpadding="0" cellspacing="0">
                                      <tr>
                                        <td><fieldset>
                                          <legend>��������´˹ѧ���</legend>
                                          <br>
										  <?
										  $sql = "select * from books where bookid ='$bookid'";
										 // print $sql;
										 $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 	
										 $row = mysql_fetch_array($table);
										 	$bookid   = $row[bookid];		
											$bnamethai   = $row[bnamethai];	
											$bnameeng   = $row[bnameeng];	
											$advisor1   = $row[advisor1];	
											$advisor2   = $row[advisor2];
											$advisor3   = $row[advisor3];
											$student1   = $row[student1];	
											$studentid1   = $row[studentid1];
											$email1   = $row[email1];	
											$student2   = $row[student2];	
											$studentid2   = $row[studentid2];	
											$email2   = $row[email2];	
											$student3   = $row[student3];	
											$studentid3   = $row[studentid3];	
											$email3   = $row[email3];	
											$student4   = $row[student4];	
											$studentid4   = $row[studentid4];	
											$email4   = $row[email4];	
											$bookyear  = $row[bookyear];
										  
										  
										  ?>


                                          
                                            <table width="101%" height="82" border="0" cellpadding="2" cellspacing="2">
                                              <tr> 
                                                <td width="21%">����</td>
                                                <td width="23%"><input name="bookid1" type="text" id="bookid1" value="<?=$bookid?>" size="4" disabled></td>
                                                <td width="5%">&nbsp;</td>
                                                <td width="24%">&nbsp;</td>
                                                <td width="4%">&nbsp;</td>
                                                <td width="23%">&nbsp;</td>
                                              </tr>
                                              <tr> 
                                                <td>�ա���֡��</td>
                                                <td><input name="bookyear" type="text" id ="bookyear" value="<?=$bookyear?>" size="4" maxlength="4" disabled></td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr> 
                                                <td>����������</td>
                                                <td colspan="5"><input name="bnamethai" type="text" id="bnamethai" value="<?=$bnamethai?>" size="50" disabled></td>
                                              </tr>
                                              <tr> 
                                                <td>���������ѧ���</td>
                                                <td colspan="5"><input name="bnameeng" type="text" id="bnameeng" value="<?=$bnameeng?>" size="50" disabled></td>
                                              </tr>
                                              <tr> 
                                                <td>�Ҩ�������֡�� 1</td>
                                                <td><input name="advisor1" type="text" id="advisor1" value="<?=$advisor1?>" disabled></td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr> 
                                                <td>�Ҩ�������֡�� 2</td>
                                                <td><input name="advisor2" type="text" value="<?=$advisor2?>" disabled></td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr> 
                                                <td>�Ҩ�������֡�� 3</td>
                                                <td><input name="advisor3" type="text" value="<?=$advisor3?>" disabled></td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr> 
                                                <td>�ѡ�֡��1</td>
                                                <td><input name="student1" type="text" id="student1" value="<?=$student1?>" disabled></td>
                                                <td>����</td>
                                                <td><input name="studentid1" type="text" id="studentid1" value="<?=$studentid1?>" maxlength="8" disabled></td>
                                                <td>�����</td>
                                                <td><input name="email1" type="text" value="<?=$email1?>" disabled></td>
                                              </tr>
                                              <tr> 
                                                <td>�ѡ�֡��2</td>
                                                <td><input name="student2" type="text" value="<?=$student2?>" disabled></td>
                                                <td>����</td>
                                                <td><input name="studentid2" type="text" value="<?=$studentid2?>" maxlength="8" disabled></td>
                                                <td>�����</td>
                                                <td><input name="email2" type="text" value="<?=$email2?>" disabled></td>
                                              </tr>
                                              <tr> 
                                                <td>�ѡ�֡��3</td>
                                                <td><input name="student3" type="text" value="<?=$student3?>" disabled></td>
                                                <td>����</td>
                                                <td><input name="studentid3" type="text" value="<?=$studentid3?>" maxlength="8" disabled></td>
                                                <td>�����</td>
                                                <td><input name="email3" type="text" value="<?=$email3?>" disabled></td>
                                              </tr>
                                              <tr> 
                                                <td>�ѡ�֡��4</td>
                                                <td><input name="student4" type="text" value="<?=$student4?>" disabled></td>
                                                <td>����</td>
                                                <td><input name="studentid4" type="text" value="<?=$studentid4?>" maxlength="8" disabled></td>
                                                <td>�����</td>
                                                <td><input name="email4" type="text" value="<?=$email4?>" disabled></td>
                                              </tr>
                                            </table>
                                            <div align="center"><br>
                                              <a href="javascript:history.back(1)"> BACK </a>
                                            </div>
                                          
                                          <br>
                                          </fieldset>&nbsp;</td>
                                      </tr>
                                    </table>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                  </td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
    include("_EndConnection.php");
?>
</body>
</html>
