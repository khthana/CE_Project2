<?php	
	//Modified 28 �ԧ�Ҥ� 2549
	
	include("startconnection.php");
	
	// Get user name and password from login.php
	$username = $_POST[username];
	$password = $_POST[password]; 

   	// Run the query on the authentication through the connection
	
	//$strconn = "SELECT * FROM tUser WHERE username = '".$username."' AND password =password('".$password."')";
	$strconn = "SELECT * FROM person WHERE personuser = '".$username."' AND personpassword =password('".$password."') AND persontype = '3'";

	//echo $strconn;
   	if (!($result = @ mysql_query ($strconn)))
      		showerror( );
	
	//  Check result 
	if($orderrow=mysql_fetch_array($result))
	{		
		
		//Valid username and redirect to Loginpage1.php
		//session_start();
		//session_register("username");		
		//session_register("password");
		//$username = $orderrow[username];
		//$password = $orderrow[password];
		
		// Free resultset
		mysql_free_result($result);
		session_register( "username");  //ŧ����¹ session �����  username
		session_register( "password"); //ŧ����¹ session �����  password
		session_register( "personname");
		session_register( "personlastname");

		$_SESSION["username"] =  $orderrow[personuser];
		$_SESSION["password"] =  $orderrow[personpassword];
		$_SESSION["personname"] =  $orderrow[personname];
		$_SESSION["personlastname"] =  $orderrow[personlastname];
		header("Location: library_main.php");
		exit;
				
	}
	else
	{
		//Invalid username
		header("Location: fail.php");
		
	}
   
?>