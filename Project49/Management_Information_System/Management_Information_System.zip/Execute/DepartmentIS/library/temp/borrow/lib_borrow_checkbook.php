<?
	include("_CheckSession.php");
	include("_StartConnection.php");
	include("../resource/_res_function.php");
	include("../resource/_Constant_variable.php");
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" onLoad="document.id_form.b_id.focus()">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س  <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> 
                                    <?
				$book_id = $_POST["book_id"];	
				
				$sql ="SELECT bookid,bnamethai FROM books WHERE bookid ='".$book_id."'";	
				$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
	
				if ($book_id =="" or !($row=mysql_fetch_array($table)))
				{
					print "<div align = 'center'><font color ='red'>";
					print "���������˹ѧ��͹��";
					print "</div>";
				}
				else
				{					
				session_register( "$bookid");
				//session_register( "$bnamethai");
				$_SESSION["bookid"] =  $row[bookid];
				//$_SESSION["bnamethai"] =  $row[bnamethai];
				$bnamethai = $row[bnamethai];
				
				//��Ǩ���������˹ѧ��͹��١�����ҧ����������
				    $sql = "SELECT bookid  FROM bookborrow WHERE bstatus = '1' AND bookid ='".$book_id."'";
					$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
					if ($row=mysql_fetch_array($table)) //�ա�������ҧ���
					{
							print "<div align = 'center'><font color ='red'>";
							print "��͹����˹ѧ��ͼԴ���ͧ�ҡ˹ѧ��Ͷ١�����ҧ���";
							print "</div>";
							//�ʴ���һ�͹����˹ѧ��ͼԴ���ͧ�ҡ�١�����ҧ���
					}
					else
					{		
								//�����ŷ���͹����Ҷ١��ͧ�ء���ҧ
		?>
                                    <div align="center"><br>
                                    </div>
                                    <table width="57%" height="107" border="0" align="center">
                                      <tr> 
                                        <td width="32%">���ʼ�����</td>
                                        <td width="68%"> 
                                          <?=$sess_userid?>
                                        </td>
                                      </tr>
                                      <tr> 
                                        <td>���ͼ�����</td>
                                        <td> 
                                          <?=$th_name?>
                                          &nbsp; 
                                          <?=$th_surname?>
                                        </td>
                                      </tr>
                                      <tr> 
                                        <td>����˹ѧ���</td>
                                        <td> 
                                          <?=$book_id?>
                                        </td>
                                      </tr>
                                      <tr> 
                                        <td>����˹ѧ���</td>
                                        <td> 
                                          <?=$bnamethai?>
                                        </td>
                                      </tr>
                                      <tr> 
                                        <td>�ѹ������</td>
                                        <td> 
                                          <?=convert_thai_date()?>
                                        </td>
                                      </tr>
                                      <tr> 
                                        <td>&nbsp;</td>
                                        <td><form name="form1" method="post" action="lib_borrow_success.php">
                                            <div align="left"> <br>
                                              <input type="submit" name="Submit" value="�׹�ѹ������">
                                            </div>
                                          </form></td>
                                      </tr>
                                    </table>
                                    <br>
                                  </td>
                                </tr>
				<?
				 }
				    }
				 
				  ?>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table> </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
    include("_EndConnection.php");?>

</body>
</html>
