<?
$servername = "localhost";
$databasename = "department_is";
$user = "root";
$password = "dorothy";

	function showerror( )
   	{
      		die("<center>  Error " . mysql_errno( ) . " : " . mysql_error( ). " </center>");
   	}

   	// (1) Open the database connection
   	if (!($connection = @ mysql_pconnect($servername,$user,$password)))
      		die("Could not connect");
	
	//�������������ҹ��(utf8)
	mysql_db_query($databasename,"SET NAMES tis620");

   	// (2) Select the winestore database
   	if (!(@ mysql_select_db($databasename)))
      		showerror( );
?>