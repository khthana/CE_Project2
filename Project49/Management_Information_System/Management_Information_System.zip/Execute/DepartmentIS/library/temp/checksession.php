<?php
	//Check session register 
	session_start();		
	
	if(!(isset($_SESSION['username']) and isset($_SESSION['password'])))
	{
		header("Location: fail.php");
	}
	
	$username = $_SESSION['username'];
	$password = $_SESSION['password'];
	$personname = $_SESSION['personname'];
	$personlastname = $_SESSION['personlastname'];
?>