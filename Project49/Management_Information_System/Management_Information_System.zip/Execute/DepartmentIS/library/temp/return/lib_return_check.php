<?
	include("_CheckSession.php");
	include("_StartConnection.php");
	include("../resource/_res_function.php");
	include("../resource/_Constant_variable.php");
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" onLoad="document.id_form.b_id.focus()">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س  <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> 
                                    <div align ="center"> 
                                      <?
			$bookid = $_POST["bookid"];	
			$sql ="SELECT s.student_id,s.pre_name,s.th_name,s.th_surname,bk.bookid,bk.bnamethai,b.dborrow,b.bstatus,b.borrowid
						FROM student s, bookborrow b, books bk
						WHERE s.student_id = b.student_id
						AND b.bookid = bk.bookid
						AND b.bookid = '".$bookid."'
						AND bstatus = '1' ";
			//print $sql;
				$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
				//if ($keyword =="" or !($row=mysql_fetch_array($table1)))
				 if ($bookid =="")
											{
												print "<br><div align = 'center'><font color ='red'>";
												print "����˹ѧ��ͼԴ��Ҵ";
												print "</div>";
											}
											else
											{
	?>
                                      <div align ="center"> 
                                        <table style="BORDER-COLLAPSE: collapse" 
                              bordercolor=#c0c0c0 cellspacing=0 cellpadding=2 
                              width=765 border=1>
                                          <tr> 
                                            <td>���ʼ�����</td>
                                            <td>����</td>
                                            <td>���ʡ��</td>
                                            <td>����˹ѧ���</td>
                                            <td>����˹ѧ���</td>
                                            <td>�ѹ������</td>
                                            <td>ʶҹ�</td>
                                            <td>�ӹǹ�ѹ</td>
                                            <td>�ӹǹ�Թ</td>
                                          </tr>
                                          <?	
			$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 	
			while ($row = mysql_fetch_array($table))
			{
					$sid = $row[0];
					$spre_name = $row[1];
					$sname = $row[2];
					$surname = $row[3];
					$bid = $row[4];
					$btname = $row[5];
					$dborrow = $row[6];	//�ѹ������
					$th_dborrow  = convert_thai_date_db($dborrow) ; //���¡�ѧ���� �ҡ��� resource 
					$bstatus = $row[7];
					$diff = diffday($dborrow); //�Ҽŵ�ҧ�ͧ�ѹ�����������					
					$bcost = cost($diff); //��һ�Ѻ					
					$borrowid = $row[8];					
					
?>
                                          <tr> 
                                            <td>
                                              <?=$sid?>
                                            </td>
                                            <td>
                                              <?=$spre_name . $sname?>
                                            </td>
                                            <td>
                                              <?=$surname?>
                                            </td>
                                            <td>
                                              <?=$bid ?>
                                            </td>
                                            <td>
                                              <?=$btname?>
                                            </td>
                                            <td>
                                              <?=$th_dborrow?>
                                            </td>
                                            <td>��ҧ���</td>
                                            <td>
                                              <?=$diff?>
                                              &nbsp;�ѹ</td>
                                            <td>
                                              <?=$bcost?>
                                              &nbsp;�ҷ</td>
                                          </tr>
                                          <?
			}
			
?>
                                        </table>
                                        <form name="form1" method="post" action="lib_return_confirm.php">
                                          <br>
                                          <input type ="hidden" name ="borrowid" value ="<?=$borrowid?>" >
                                          <input type="submit" name="Submit" value="�׹�ѹ��ä׹˹ѧ���" >
                                        </form>
	<?
	   }   // ���͹� else
	?>
                                        <br>
                                        <br>
                                        <br>
                                      </div>
                                    </div></td>
                                </tr>
			
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table> </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
    include("_EndConnection.php");?>

</body>
</html>
