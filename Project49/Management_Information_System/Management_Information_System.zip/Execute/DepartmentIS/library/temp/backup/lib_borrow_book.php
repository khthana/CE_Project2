<?include("_CheckSession.php"); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Department Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
</head>

<body class = "classbody"  >
<div align="right">�к����ʹ���Ҥ�Ԫ��<br>
  Department Information System<br>
</div>
<hr>
�к��ҹ��ԡ���Ԫҡ�� <br>
������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?> <br>
<table width="100%" border="0">
  <tr> 
    <td width="19%"><strong>��¡��</strong></td>
    <td width="81%" rowspan="2" align="left" valign="top"><div align="center">��ԡ�����˹ѧ���<br>
        <br>
      </div>
      <form action="lib_borrow_checkbook.php" method="post" name="submit" id="submit">
        <div align="center"><font color="#FF0000">��͹����˹ѧ��� :</font> 
          <input type="text" name="book_id">
          <input type="submit" name="Submit" value="�׹�ѹ">
          <input type="reset" name="Submit2" value="������">
        </div>
      </form> </td>
  </tr>
  <tr> 
    <td><?include ("_menu.php") ?></td>
  </tr>
</table>
</body>
</html>
