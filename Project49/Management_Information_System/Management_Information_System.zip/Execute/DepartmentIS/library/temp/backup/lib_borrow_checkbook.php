<?
	include("_CheckSession.php");
	include("_StartConnection.php");	
	include("../resource/_res_function.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Department Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
</head>

<body class = "classbody"  >
<div align="right">�к����ʹ���Ҥ�Ԫ��<br>
  Department Information System<br>
</div>
<hr>
�к��ҹ��ԡ���Ԫҡ�� <br>
������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?> <br>
<table width="100%" border="0">
  <tr> 
    <td width="19%"><strong>��¡��</strong></td>
    <td width="81%" rowspan="2" align="left" valign="top"><div align="center"> 
        <?
				$book_id = $_POST["book_id"];	
				
				$sql ="SELECT bookid,bnamethai FROM books WHERE bookid ='".$book_id."'";	
				$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
	
				if ($book_id =="" or !($row=mysql_fetch_array($table)))
				{
					print "���������˹ѧ��͹��";
				}
				else
				{
				session_register( "$bookid");
				session_register( "$bnamethai");
				$_SESSION["bookid"] =  $row[bookid];
				$_SESSION["bnamethai"] =  $row[bnamethai];
		?>
        <br>
        <table width="57%" height="107" border="0">
          <tr>
            <td width="32%">���ʼ�����</td>
            <td width="68%"><?=$sess_userid?></td>
          </tr>
          <tr>
            <td>���ͼ�����</td>
            <td><?=$th_name?>&nbsp;<?=$th_surname?></td>
          </tr>
          <tr>
            <td>����˹ѧ���</td>
            <td><?=$book_id?></td>
          </tr>
		  <tr>
            <td>����˹ѧ���</td>
            <td><?=$row[bnamethai]?></td>
          </tr>
          <tr>
            <td>�ѹ������</td>
            <td><?=convert_thai_date()?></td>
          </tr>
        </table>
        <form name="form1" method="post" action="lib_borrow_success.php">
          <input type="submit" name="Submit" value="�׹�ѹ������">
        </form>
        <br>
        <br>
        <br>
        <?
				}

		?>
      </div>
  </tr>
  <tr> 
    <td align="left" valign="top"><?include ("_menu.php") ?></td>
  </tr>
</table>
</body>
<? include("_EndConnection.php");?>
</html>
