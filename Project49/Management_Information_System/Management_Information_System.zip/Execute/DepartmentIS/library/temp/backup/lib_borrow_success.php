<?include("_CheckSession.php"); 
	include("_StartConnection.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Department Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
</head>

<body class = "classbody"  >
<div align="right">�к����ʹ���Ҥ�Ԫ��<br>
  Department Information System<br>
</div>
<hr>
�к��ҹ��ԡ���Ԫҡ�� <br>
������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?> <br>
<table width="100%" border="0"  align="left" valign="top">
  <tr> 
    <td width="19%"><strong>��¡��</strong></td>
    <td width="81%" rowspan="2" align="left" valign="top">
	<?
			$status ="1";
			$today =date ("Y-m-d");
			$sql ="insert into bookborrow values ('','".$sess_userid."','".$bookid."','".$today."','".$status."') ";	
			
			if( mysql_query($sql,$conn) )
			{
				print "�ѹ�֡���º����";
			}
			else
			{
				print "�ջѭ��㹡�úѹ�֡";
			}
			//$sess_userid;
			//$book_id
	?>
	</td>
  </tr>
  <tr> 
    <td  align="left" valign="top"><?include ("_menu.php") ?></td>
  </tr>
</table>
</body>
<? // include("_EndConnection.php");?>
</html>
