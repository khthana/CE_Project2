<html>
<head>
<title>Authentication Failure!</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body class = "classbody">
<table class = "classbody" width="303" height="104" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#999999">
  <tr>
    <td width="105"><img src="img/error.gif" width="96" height="96"></td>
    <td width="182"><span class="style1">Authentication Failure ! </span></td>
  </tr>
</table>
<div align="center"><br> 
  <a href="plogin.php">HOME
</a></div>
</body>
</html>