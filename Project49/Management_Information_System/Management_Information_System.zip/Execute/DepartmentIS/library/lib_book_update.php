<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class = "classbody"  >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td align="left" valign="top"> <div align="left"> 
                                      <? include ("_menu.php") ?>
                                    </div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> <div align="left">&nbsp;</div></td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top"> 
                                    <?
									/*
										  $sql = "select * from books where bookid ='$bookid'";
										 // print $sql;
										 $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 	
										 $row = mysql_fetch_array($table);
										 	$bookid   = $row[bookid];		
											$bnamethai   = $row[bnamethai];	
											$bnameeng   = $row[bnameeng];	
											$advisor1   = $row[advisor1];	
											$advisor2   = $row[advisor2];
											$advisor3   = $row[advisor3];
											$student1   = $row[student1];	
											$studentid1   = $row[studentid1];
											$email1   = $row[email1];	
											$student2   = $row[student2];	
											$studentid2   = $row[studentid2];	
											$email2   = $row[email2];	
											$student3   = $row[student3];	
											$studentid3   = $row[studentid3];	
											$email3   = $row[email3];	
											$student4   = $row[student4];	
											$studentid4   = $row[studentid4];	
											$email4   = $row[email4];	
											$bookyear  = $row[bookyear];
										*/
											//�.����֡�� 2			
			if($advisor2 =="") {
					$advisor2 = "null";
				}
			else {
					$advisor2= "'".$advisor2."'";
				}	
				
				//�.����֡�� 3			
			if($advisor3 =="") {
					$advisor3 = "null";
				}
			else {
					$advisor3= "'".$advisor3."'";
				}
		
			//�������1			
			if($email1 =="") {
					$email1 = "null";
				}
			else {
					$email1= "'".$email1."'";
				}

			//���͹ѡ�֡��2			
			if($student2 =="") {
					$student2 = "null";
				}
			else {
					$student2= "'".$student2."'";
				}

			//���ʹѡ�֡��2			
			if($studentid2 =="") {
					$studentid2 = "null";
				}
			else {
					$studentid2= "'".$studentid2."'";
				}
				
				//�������2			
			if($email2 =="") {
					$email2 = "null";
				}
			else {
					$email2= "'".$email2."'";
				}
		
		//���͹ѡ�֡��3			
			if($student3 =="") {
					$student3 = "null";
				}
			else {
					$student3= "'".$student3."'";
				}

			//���ʹѡ�֡��3			
			if($studentid3 =="") {
					$studentid3 = "null";
				}
			else {
					$studentid3= "'".$studentid3."'";
				}
				
				//�������3			
			if($email3 =="") {
					$email3 = "null";
				}
			else {
					$email3= "'".$email3."'";
				}
				
					//���͹ѡ�֡��4			
			if($student4 =="") {
					$student4 = "null";
				}
			else {
					$student4= "'".$student4."'";
				}

			//���ʹѡ�֡��4			
			if($studentid4 =="") {
					$studentid4 = "null";
				}
			else {
					$studentid4= "'".$studentid4."'";
				}
				
				//�������4			
			if($email4 =="") {
					$email4 = "null";
				}
			else {
					$email4= "'".$email4."'";
				}
			
				$sql = "UPDATE books
							set 
							bnamethai  = '$bnamethai' ,	
							bnameeng  = '$bnameeng' ,	
							advisor1  = '$advisor1' ,	
							advisor2  = $advisor2 ,
							advisor3  = $advisor3 ,
							student1  = '$student1' ,	
							studentid1  = '$studentid1',
							email1 = $email1,	
							student2  = $student2 ,	
							studentid2  = $studentid2,	
							email2 = $email2,	
							student3  = $student3,	
							studentid3  = $studentid3,	
							email3  = $email3,	
							student4  = $student4,	
							studentid4  = $studentid4,	
							email4  = $email4,	
							bookyear  =$bookyear
							WHERE bookid = '$bookid1' ";
							//print $sql;
						
			if( mysql_query($sql,$conn) )
			{
				print "<div align ='center'>";
				//print $sql;
				print "�ѹ�֡���º����";
				print "</div>";
			}
			else
			{
				print "<div align ='center'>";
				print $sql;
				print "�ջѭ��㹡�úѹ�֡";
				print "</div>";
			}			
																  
										  ?>
                                    <br>
                                    <br>
                                    <br>
                                  </td>
                                </tr>
                                <tr> 
                                  <td align="left" valign="top">&nbsp;</td>
                                </tr>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
<? 
   // include("_EndConnection.php");
?>
</body>
</html>
