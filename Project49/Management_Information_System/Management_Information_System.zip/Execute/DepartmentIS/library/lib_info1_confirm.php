<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");


 //�Ţ���ºѵû�Шӵ�ǻ�ЪҪ�
if($citizenid =="") {
		$citizenid = "null";
}
else {
		$citizenid= "'".$citizenid."'";
}

 //�ӹ�˹�Ҫ���
 if($prename == 'other') {
			$prename = $prename2;
			$prename = "'".$prename."'";							
	}
	else{
			$prename = "'".$prename."'";
	}

 //��
 $gender = "'".$gender."'";

 //���˹觷ҧ�Ԫҡ��
//print $position;
if($position1 =="") {
		$position1 = "null";
}
else {
		$position1= "'".$position1."'";
}

 //�дѺ�ҧ�Ԫҡ��
if($level =="") {
		$level = "null";
}
else {
		$level= "'".$level."'";
}

 //���͠(������)
$th_name = "'".$th_name."'";

 //���ʡ�Š(������)
 $th_surname = "'".$th_surname."'";

 //���͠(�����ѧ��ɵ�Ǿ�����˭�)
if($en_name =="") {
	$en_name = "null";
}
else {
	$en_name= "'".$en_name."'";
}

 //���ʡ�Š(�����ѧ��ɵ�Ǿ�����˭�)
if($en_surname =="") {
	$en_surname = "null";
}
else {
	$en_surname= "'".$en_surname."'";
}

// ��ҹ�Ţ���
if($homeno1 =="") {
	$homeno1 = "null";
}
else {
	$homeno1= "'".$homeno1."'";
}

//����
if($moo1 =="") {
	$moo1 = "null";
}
else {
	$moo1= "'".$moo1."'";
}

//��͡���
if($soi1 =="") {
	$soi1 = "null";
}
else {
	$soi1= "'".$soi1."'";
}

//���
if($street1 =="") {
	$street1 = "null";
}
else {
	$street1= "'".$street1."'";
}

//�Ӻ�
if($tambon1 =="") {
	$tambon1 = "null";
}
else {
	$tambon1= "'".$tambon1."'";
}

//�����
if($amphur1 =="") {
	$amphur1 = "null";
}
else {
	$amphur1= "'".$amphur1."'";
}


//�ѧ��Ѵ
if($province1 =="") {
	$province1 = "null";
}
else {
	$province1= "'".$province1."'";
}	

//������ɳ���
if($zipcode1 =="") {
	$zipcode1 = "null";
}
else {
	$zipcode1= "'".$zipcode1."'";
}	

//���Ѿ��
if($telno1 =="") {
	$telno1 = "null";
}
else {
	$telno1= "'".$telno1."'";
}	


// ��ҹ�Ţ���
if($homeno2 =="") {
	$homeno2 = "null";
}
else {
	$homeno2= "'".$homeno2."'";
}

//����
if($moo2 =="") {
	$moo2 = "null";
}
else {
	$moo2= "'".$moo2."'";
}

//��͡���
if($soi2 =="") {
	$soi2 = "null";
}
else {
	$soi2= "'".$soi2."'";
}

//���
if($street2 =="") {
	$street2 = "null";
}
else {
	$street2= "'".$street2."'";
}

//�Ӻ�
if($tambon2 =="") {
	$tambon2 = "null";
}
else {
	$tambon2= "'".$tambon2."'";
}

//�����
if($amphur2 =="") {
	$amphur2 = "null";
}
else {
	$amphur2= "'".$amphur2."'";
}

//�ѧ��Ѵ
if($province2 =="") {
	$province2 = "null";
}
else {
	$province2= "'".$province2."'";
}	

//������ɳ���
if($zipcode2 =="") {
	$zipcode2 = "null";
}
else {
	$zipcode2= "'".$zipcode2."'";
}	

//���Ѿ��
if($telno2 =="") {
	$telno2 = "null";
}
else {
	$telno2= "'".$telno2."'";
}	

//���Ѿ��Դ�������
if($telin =="") {
	$telin = "null";
}
else {
	$telin= "'".$telin."'";
}	


//���Ѿ����Ͷ��
if($mobile =="") {
	$mobile = "null";
}
else {
	$mobile= "'".$mobile."'";
}	


//E-MAIL
if($email =="") {
	$email = "null";
}
else {
	$email= "'".$email."'";
}	

$sql = "update  person
set

gender= $gender,
position= $position1,
level= $level,
prename= $prename,
th_name= $th_name,
th_surname= $th_surname,
en_name= $en_name,
en_surname= $en_surname,
citizenid= $citizenid,

telephone= $telin,
mobile= $mobile,
email= $email,

number1= $homeno1,
group1= $moo1,
lane1= $soi1,
road1= $street1,
district1= $tambon1,
region1= $amphur1,
province1= $province1,
postalcode1= $zipcode1,
telephone1= $telno1,

number2= $homeno2,
group2= $moo2,
lane2= $soi2,
road2= $street2,
district2= $tambon2,
region2= $amphur2,
province2= $province2,
postalcode2= $zipcode2,
telephone2= $telno2

where person_id = '$person_id' ";
if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: lib_info1.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			



?>
