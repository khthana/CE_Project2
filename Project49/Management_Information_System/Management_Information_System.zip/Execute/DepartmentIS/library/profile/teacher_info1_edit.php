<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� 
        <?=$position ?>
        <?=$personname ?>
        &nbsp;
        <?=$personlastname ?>
      </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <?
									   include ("_menu.php");
									   include ("_sql_info1.php");
									   ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left"><br>
                                    </div></td>
                              </tr>
							  
                              <tr>
                                <td align="left" valign="top">
								
								
								
								
								
								
								
								
								
								
								
					  <form name="form1" method="post" action="teacher_info1_confirm.php">			
								<TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                                <TBODY>
                                                  <TR> 
                                                    <TD align=right width=67 rowSpan=3><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></TD>
                                                    <TD 
            height=24 colspan="2" align=middle><div align="center"><STRONG> ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></div></TD>
                                                    <TD width=216 rowspan="4"><table width="53%" height="73" border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                                                        <tr> 
                                                          <td><div align="center"><?
														$rootdir = "/AppServ/www/Departmentis/resource/pics/person";
														$a="$rootdir/". $person_id . ".gif";
														//print $a;
														if (file_exists($a)) { 
															print "<img src='../resource/pics/person/". $person_id . ".gif'>";
														}
														else {
															print "<img src='../resource/pics/person/default.gif' >";
														}														
														
														?></div></td>
                                                        </tr>
                                                      </table></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD 
            height=20 colspan="2" align=middle><div align="center"><strong> �����Ż���ѵԺؤ�ҡ�</strong></div></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD height=20 colspan="2" align=middle>&nbsp;</TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD width=67></TD>
                                                    <TD height=20 colspan="2" align=middle></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD></TD>
                                                    <TD width=219 height=20 align=middle><div align="left"><strong>���ʻ�Шӵ��&nbsp; 
                                                        </strong></div></TD>
                                                    <TD width=248 align=middle><div align="left"><strong> 
                                                        <input name=person_id size=13  maxlength=8  value="<?=$person_id?>" disabled>
                                                        </strong></div></TD>
                                                    <TD align=left> <div align="center"><A HREF="upload.php" onClick="popup = window.open('upload.php', 'PopupPage', 'height=100,width=360,scrollbars=no,resizable=no'); return false" target="_blank"> 
                                                        ����¹ </a> | <a href="javascript:window.location.reload()">���ê</a></div></TD>
                                                  </TR>
                                                  <TR> 
                                                    <TD width=67></TD>
                                                    <TD height=20 align=middle><div align="left"><strong>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ� 
                                                        </strong></div></TD>
                                                    <TD height=20 align=middle><div align="left"><strong> 
                                                        <input name=citizenid size=13 maxlength=13  value="<?=$citizenid?>"  >
                                                        </strong></div></TD>
                                                    <TD align=left width=216>&nbsp;</TD>
                                                  </TR>
                                                </TBODY>
                                              </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                                                  <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                                                  <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;���ǡ�����ʵ��</TD>
                                                  <TD align=left width=300>&nbsp;���ǡ�������������</TD>
                                                  <TD align=left 
        width=300>&nbsp;���ǡ�������������</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp; 
			<INPUT name=prename  type=radio  value="���"  <?=$flagprename1?>> ��� / Mr. &nbsp;&nbsp; 
			<INPUT name=prename type=radio value="�ҧ���"  <?=$flagprename2?> > �ҧ��� / Miss &nbsp;&nbsp; 
            <INPUT name=prename type=radio value="�ҧ"  <?=$flagprename3?> >�ҧ / Mrs. &nbsp;&nbsp; 
			<INPUT  name=prename type=radio value="other"  <?=$flagprename4?>>  ���� (�к�)&nbsp;:&nbsp; 
             <INPUT name=prename2  size=12  maxLength=16 value="<?=$prenamestatus?>" > </TD>
                                                  <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp; 
			<INPUT name=gender  type=radio id=gender value="���" <?=$flaggender1?>>��� &nbsp;&nbsp; 
			<INPUT  name=gender type=radio value="˭ԧ"  <?=$flaggender2?> > ˭ԧ
			</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><strong>&nbsp;���˹觷ҧ�Ԫҡ��</strong></TD>
                                                  <TD align=left width=450 
            height=20><strong>&nbsp;�дѺ�ҧ�Ԫҡ��</strong></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                            <INPUT size=32  maxLength=80 name = position1 value="<?=$position1?>"></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT size=32 maxLength=80 name = level value="<?=$level?>"> </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(������)</TD>
                                                  <TD align=left width=450 
            height=20><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(������)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                                    <INPUT name=th_name size=32  maxLength=80 value="<?=$th_name?>"></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT name=th_surname  size=32  maxLength=80 value="<?=$th_surname?>"></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                  <TD align=left width=450><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD><table width="750" border="1">
                                            <tr>
                                              <td width="293" height="20" align="left" bgcolor="#f8f8f8">&nbsp;
                                                <input name=en_name type="text" size="32" maxlength="80" value="<?=$en_name?>"></td>
                                              <td width="441" bgcolor="#f8f8f8">&nbsp;
											  <input name="en_surname" type="text" size="32" maxlength="80" value="<?=$en_surname?>"></td>
                                            </tr>
                                          </table></TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;<strong>�������ͧ�ؤ�ҡ�</strong><BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.
    <INPUT  name=ptype  type=radio  value=0  disabled <?=$flagtype0?> >
    ��������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.
    <INPUT  type=radio value=1 name=ptype disabled  <?=$flagtype1?>>
    �Ҩ����&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.
    <INPUT  type=radio value=2 name=ptype  disabled <?=$flagtype2?>>
    ���˹�ҷ��෤�Ԥ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4.
    <INPUT  type=radio value=3  name=ptype  disabled <?=$flagtype3?>>
    ���˹�ҷ���ԡ���Ԫҡ��<BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.
    <INPUT  type=radio value=4 name=ptype   disabled <?=$flagtype4?>> 
    ���˹�ҷ���á��&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 6.
    <INPUT  type=radio value=5 name=ptype  disabled <?=$flagtype5?> >
    ���˹�ҷ�����Թ</TD>                                        
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;</TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8"><strong> ����ѵ���ǹ��� </strong></TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">  <STRONG>&nbsp;�������������¹��ҹ</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp;
                                            <INPUT  maxLength=10 size=5 name=homeno1 value ="<?=$number1?>">
&nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp;
<INPUT  maxLength=2 size=2 name=moo1 value="<?=$group1?>">
&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp;
<INPUT  maxLength=20 size=16 name=soi1 value="<?=$lane1?>">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp;
<INPUT  maxLength=20 size=17 name=street1 value ="<?=$road1?>"></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp;
  <INPUT  maxLength=20 size=19 name=tambon1 value ="<?=$district1?>">
&nbsp;&nbsp;&nbsp;<STRONG> �����/ࢵ</STRONG>&nbsp;&nbsp;
<INPUT  maxLength=20 size=16 name=amphur1 value ="<?=$region1?>" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp;
<select name="province1">
  <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province1){
																	$chk ="selected";
																	}		
																			
													  ?>
													   <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
  <?
															$chk ="";
														}
														?>
</select></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp;&nbsp;
           <INPUT  maxLength=5 size=10 name=zipcode1 value ="<?=$postalcode1?>">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;
<INPUT  maxLength=15 size=16 name=telno1 value ="<?=$telephone1?>"></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;<STRONG>�������������ö�Դ�����</STRONG>&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp;
  <INPUT name=homeno2 size=5  maxLength=10 value ="<?=$number2?>">
&nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp;
    <INPUT name=moo2 size=2    maxLength=2 value ="<?=$group2?>">
&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp;
    <INPUT name=soi2 size=16  maxLength=20 value ="<?=$lane2?>">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp;
    <INPUT name=street2 size=17 maxLength=20 value ="<?=$road2?>">
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp;
<INPUT name=tambon2 size=19  maxLength=20 value ="<?=$district2?>">
&nbsp;&nbsp;&nbsp;<STRONG> �����/ࢵ</STRONG>&nbsp;&nbsp;
    <INPUT name=amphur2 size=16   maxLength=20 value ="<?=$region2?>">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp;
    <select name="province2">
      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province2){
																	$chk ="selected";
																	}		
																			
													  ?>
													     <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
      <?
															$chk ="";
														}
														?>
    </select>
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;<STRONG>������ɳ���</STRONG>&nbsp;&nbsp;
              <INPUT name=zipcode2 size=10  maxLength=5 value ="<?=$postalcode2?>">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;
    <INPUT name=telno2 size=16  maxLength=15 value ="<?=$telephone2?>">
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8"><div align="center"><strong>���Ѿ��Դ�������</strong>&nbsp;&nbsp;                                              
                                            <input type="text" name="telin" value ="<?=$telephone?>">
                                            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                           <strong>                                          ���Ѿ����Ͷ��&nbsp;&nbsp;</strong>                                          
                                            <input type="text" name="mobile" value ="<?=$mobile?>">
                                          </div></TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8"><div align="center"><strong>E-Mail</strong>&nbsp;&nbsp;
                                              <input type="text" name="email" value ="<?=$email?>">
                                          </div></TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;                                          </TD>
                                        <TR> 
                                          <TD bgColor=#f8f8f8 height=41><div align="center">
                                                <input type="submit" name="Submit" value="�׹�ѹ�������¹�ŧ">
                                              </div></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8> <br>
                                          <br>
                                          <br></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"><a href="teacher_info2.php">Next</a></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>  
                                    </form>
									
                                    <div align="right"> <br>
                                    </div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><div align="right"></div>
</td>
                              </tr>
                            </table>                            </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
