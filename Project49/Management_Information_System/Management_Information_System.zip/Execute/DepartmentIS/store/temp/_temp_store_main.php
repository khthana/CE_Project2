<?include("_CheckSession.php"); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Department Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
</head>

<body class = "classbody"  >
<div align="right">�к����ʹ���Ҥ�Ԫ��<br>
  Department Information System<br>
</div>
<hr>
�к��ҹ���˹�ҷ��෤�Ԥ� <br>
������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?> <br>
<table width="100%" border="0">
  <tr> 
    <td width="19%"><strong>��¡��</strong></td>
    <td width="81%" rowspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td><?//include ("_menu.php") ?></td>
  </tr>
</table>
</body>
</html>
