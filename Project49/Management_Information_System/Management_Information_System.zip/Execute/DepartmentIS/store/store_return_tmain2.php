<?
include("_CheckSession.php"); 
include ("_StartConnection.php");

if($tool != "") {		   //����� �� check box
		foreach ($tool as $eachtool) {
					$sql = "update tool_tborrow
								set status = '0' where bid = $eachtool";
					if( mysql_query($sql,$conn) ){
							header("Location: store_return_tmain1.php");
					}
					else	{											
							header("Location: store_tborrowstatus_fail.php");
					}			
		}	
}	
header("Location: store_return_tmain1.php");												
									  
 ?>


