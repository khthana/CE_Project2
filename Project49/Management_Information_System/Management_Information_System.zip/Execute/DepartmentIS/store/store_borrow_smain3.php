<?
include("_CheckSession.php"); 
include ("_StartConnection.php");

									  			//print $to_id . $bo_id . $total . $comment;
												$status ="1";
												$today =date ("Y-m-d");
												
												//��Ǩ�ͺ�����ҧ�ͧ�ӹǹ������
												if ($total == "") {
													$total = 1;
												}
												//��Ǩ�����ҧ�ͧ comment
												if ($comment == "")  {
													$comment = "null";
												}
												else {
													$comment =  "'".$comment."'";		
												}
												
												$sql = "insert into tool_sborrow values('', '$bo_id','$to_id','$today',$total,'$status',$comment)";
												//print $sql;
											if( mysql_query($sql,$conn) )
											{
												//print "<div align ='center'>";
												//print "�ѹ�֡���º����";
												//print "</div>";
												header("Location: store_borrow_smain1.php");
											}
											else
											{
												//print "<div align ='center'>";
												//print "�ջѭ��㹡�úѹ�֡";
												//print "</div>";
												header("Location: store_borrowstatus_fail.php");
												
											}
																				
									  
 ?>


