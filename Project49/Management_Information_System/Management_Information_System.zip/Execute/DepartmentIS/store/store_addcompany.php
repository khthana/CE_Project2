<?include("_CheckSession.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<script type='text/javascript'>

function formValidator(){
	
	var cname = document.getElementById('cname');
	var address = document.getElementById('address');
	var phone = document.getElementById('phone');
	var fax = document.getElementById('fax');
	
	// Check each input in the order that it appears in the form!
	if(isEmpty(cname, "��سһ�͹���ͺ���ѷ")){
		if(isEmpty(address, "��سһ�͹�������")){
			if(isEmpty(phone, "��سһ�͹�������Ѿ�")){
				if(isEmpty(fax, "��سһ�͹�����硫�")){
								var r=confirm("�׹�ѹ������������ź���ѷ")
								if (r==true){
									return true;
								}
								else{
									return false;
								}						
							}
						}					
					}
				}
	return false;
}

function isEmpty(elem, helperMsg){
	if(elem.value.length != 0){		
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}


function isNumeric(elem, helperMsg){
	var alphaExp = /^[0-9]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"> 
                                    <form name="form1" method="post" action="store_addcompany_success.php"onsubmit='return formValidator()'>
                                      <table 
                              width=557 height="150" border=1 align="center" cellpadding=2 cellspacing=0 
                              bordercolor=#c0c0c0  style="BORDER-COLLAPSE: collapse">
                                        <tr bgcolor="#CCCCCC"> 
                                          <td colspan="2"><img src="../resource/img/icon_container.gif" width="13" height="16"> 
                                            ���������� ����ѷ�ػ�ó�</td>
                                        </tr>
                                        <tr> 
                                          <td width="25%"><img src="../resource/img/red.gif" width="6" height="12"> 
                                            ���ͺ���ѷ</td>
                                          <td width="75%"><input name="cname" type="text" size="45"></td>
                                        </tr>
                                        <tr> 
                                          <td><img src="../resource/img/red.gif" width="6" height="12"> 
                                            ������� </td>
                                          <td><input name="address" type="text" size="45"></td>
                                        </tr>
                                        <tr> 
                                          <td><img src="../resource/img/red.gif" width="6" height="12"> 
                                            ���Ѿ��</td>
                                          <td><input name="phone" type="text" size="15"></td>
                                        </tr>
                                        <tr> 
                                          <td><img src="../resource/img/red.gif" width="6" height="12"> 
                                            ῡ��</td>
                                          <td><input name="fax" type="text" size="15"></td>
                                        </tr>
                                      </table>
                                      <div align="center"> <br>
                                        <input type="submit" name="Submit" value="Submit">
                                        <br>
                                      </div>
                                    </form>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
