<?		
		$bo_id = $bo_id;
		$sql = "select * from person where person_id = '$bo_id'";
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
				if($row = mysql_fetch_array($table)){	

				
				session_register( "bo_id");  
				session_register( "bo_name");  
				session_register( "to_id");  
				session_register( "to_name");  
				session_register( "position");  
				session_register( "th_surname");  
					
				$_SESSION["bo_id"] =  $row[person_id];					//���ʹѡ�֡��
				$_SESSION["position"] =  $row[position];			//�ӹ�˹�Ҫ���
				$_SESSION["bo_name"] =  $row[th_name];				//����
				$_SESSION["th_surname"] =  $row[th_surname];		//���ʡ��

				//session_start();
				//$bo_id = $_SESSION["bo_id"];
				//print $bo_id;

				}	
				else {
					header("Location: store_checktuserfail.php");
				}

		 

?>