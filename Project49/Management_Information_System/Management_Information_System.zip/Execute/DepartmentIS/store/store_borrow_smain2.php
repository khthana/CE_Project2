<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
include("../resource/_res_function.php");
 include("_userborrow_checktool.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top">
								  <form name="borrowform" method="post" action="store_borrow_smain3.php">
                                      <img src="../resource/img/icon_required.gif" width="11" height="11">&nbsp;�ѡ�֡�� 
                                      <br>
									  <?
									   //include("_userborrow_session.php");
									  
									  ?>
									  
									  
                                      <br>
                                      <table 
                              width=506 border=0 cellpadding=3 cellspacing=2 
                              bordercolor=#c0c0c0 bgcolor="#FFFFFF"  style="BORDER-COLLAPSE: collapse">
                                        <tr> 
                                          <td width="157" background="../resource/img/horline_165.jpg"> 
                                            ���ʼ�����</td>
                                          <td width="296">
										  <?=$bo_id?>
										  
										  </td>
                                          <td width="27">&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td background="../resource/img/horline_165.jpg"> 
                                            ���ͼ����� </td>
                                          <td> <? print $pre_name . $bo_name . "  " . $th_surname ?></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td background="../resource/img/horline_165.jpg"> �����ػ�ó�</td>
                                          <td>
                                            <?=$to_id?>
                                          </td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr> 
                                          <td background="../resource/img/horline_165.jpg"> �����ػ�ó�</td>
                                          <td>
                                            <?=$to_name?>
                                          </td>
                                          <td>&nbsp;</td>
                                        </tr>
                                      </table>
                                      <br>
                                      <img src="../resource/img/icon_required.gif" width="11" height="11">�����š�����<br>
                                      <br>
                                      <table  style="BORDER-COLLAPSE: collapse" 
                              bordercolor=#c0c0c0 cellspacing=0 cellpadding=2 
                              width=765 border=1>
                                        <tr bgcolor="#CCCCCC"> 
                                          <td width="62">��¡��</td>
                                          <td width="90">�����ػ�ó�</td>
                                          <td width="292">�����ػ�ó�</td>
                                          <td width="81">�ѹ������</td>
                                          <td width="45">�ӹǹ</td>
                                          <td width="89">�ӹǹ�ѹ����ҧ</td>
                                          <td width="62">�����˵�</td>
                                        </tr>
                                        <?
												$counttool = 1;
												$sql = "SELECT *
												FROM student s, tool_sborrow tos, tool t
												WHERE s.student_id = tos.student_id
												AND tos.toolid = t.toolid
												AND STATUS = '1' 
												AND tos.student_id = '$bo_id' order by bid
												";
												//print $sql;
												$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
												while ($row = mysql_fetch_array($table))
												{
														$toolid = $row[toolid];
														$toolname = $row[toolname];
														$bdate = $row[bdate];
														$total = $row[total];
														$comment = $row[comment];
														$th_dborrow  = convert_thai_date_db($bdate) ; //���¡�ѧ���� �ҡ��� resource 
														$diff = diffday($bdate); //�Ҽŵ�ҧ�ͧ�ѹ�����������
										
										?>
                                        <tr> 
                                          <td>&nbsp; 
                                            <?=$counttool?>
                                          </td>
                                          <td>&nbsp; 
                                            <?=$toolid?>
                                          </td>
                                          <td>&nbsp; 
                                            <?=$toolname?>
                                          </td>
                                          <td>&nbsp; 
                                            <?=$th_dborrow?>
                                          </td>
                                          <td><input name="textfield3" type="text" value="<?=$total?>" size="3" maxlength="3" disabled></td>
                                          <td>&nbsp; 
                                            <?=$diff?>
                                          </td>
                                          <td><input name="textfield" type="text" value="<?=$comment?>" disabled></td>
                                        </tr>
                                        <?
											++$counttool;
										  }
										  ?>
                                        <tr bgcolor="#F2F2F2"> 
                                          <td><font color="#0000FF">&nbsp; 
                                            <?=$counttool?>
                                            </font></td>
                                          <td><font color="#0000FF">&nbsp; 
                                            <?=$to_id?>
                                            </font></td>
                                          <td><font color="#0000FF">&nbsp; 
                                            <?=$to_name?>
                                            </font></td>
                                          <td><font color="#0000FF">&nbsp; �ѹ���</font></td>
                                          <td><font color="#0000FF"> 
                                            <input name="total" type="text" value="1" size="3" maxlength="3" >
                                            </font></td>
                                          <td><font color="#0000FF">&nbsp;</font> </td>
                                          <td><font color="#0000FF"> 
                                            <input name="comment" type="text" >
                                            </font></td>
                                        </tr>
                                      </table>
                                      <div align="right"><br>
                                        <input type="submit" name="Submit" value="Submit">
                                      </div>
                                    </form>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
