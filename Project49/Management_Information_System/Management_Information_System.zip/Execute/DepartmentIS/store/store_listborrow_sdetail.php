<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
include("../resource/_res_function.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" onLoad="document.borrowform.bo_id.focus()">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"> <br>
                                    <?
								  $sql ="select  pre_name,th_name,th_surname from student where student_id ='$borrow_id' ";
								 // print $sql;
								  $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
									$row = mysql_fetch_array($table);
									$pre_name = $row[0];
									$th_name = $row[1];
									$th_surname = $row[2];
												
								  
								  ?>
                                    ��¡������ػ�ó�ͧ <? print $pre_name . $th_name . "  " . $th_surname ;?><br>
                                    <br>
                                    <table  style="BORDER-COLLAPSE: collapse" 
                              bordercolor=#c0c0c0 cellspacing=0 cellpadding=2 
                              width=765 border=1>
                                      <tr bgcolor="#CCCCCC"> 
                                        <td width="45">��¡��</td>
                                        <td width="93">�����ػ�ó�</td>
                                        <td width="248">�����ػ�ó�</td>
                                        <td width="85">�ѹ������</td>
                                        <td width="50">�ӹǹ</td>
                                        <td width="89">�ӹǹ�ѹ����ҧ</td>
                                        <td width="111">�����˵�</td>
                                      </tr>
									  <?
									  $tcount = 1;
									 $sql ="SELECT p.student_id, p.pre_name, p.th_name, p.th_surname ,to1.toolid, to1.toolname, t.bdate, t.total, t.comment
												FROM student p, tool_sborrow t, tool to1
												WHERE p.student_id = t.student_id
												AND t.status = '1' and to1.toolid = t.toolid
												and p.student_id ='$borrow_id'
												";
									//print $sql;
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
												while ($row = mysql_fetch_array($table))
												{
														$borrow_id= $row[0];
														$position = $row[1];
														$th_name = $row[2];
														$th_surname = $row[3];
														
														$toolid = $row[4];
														$toolname =  $row[5];
														$bdate =   $row[6];
														$total =  $row[7];
														$comment =  $row[8];
														$th_dborrow  = convert_thai_date_db($bdate) ; //���¡�ѧ���� �ҡ��� resource 
														$diff = diffday($bdate); //�Ҽŵ�ҧ�ͧ�ѹ�����������
												
									  
									
									?>
									  
									
									  
                                      <tr> 
                                        <td>&nbsp; <?=$tcount?></td>
                                        <td>&nbsp; <?=$toolid?></td>
                                        <td>&nbsp; <?=$toolname?></td>
                                        <td>&nbsp; <?=$th_dborrow?></td>
                                        <td>&nbsp;<?=$total?></td>
                                        <td>&nbsp; <?=$diff?></td>
                                        <td>&nbsp;<?=$comment?></td>
                                      </tr>
									  <?	++$tcount;
									  						}
									  
									  ?>
									  
									  
                                    </table>
                                    <br>
                                    <form name="form1" method="post" action="store_listborrow.php">
                                      <div align="center">
                                        <input type="submit" name="Submit" value="Back">
                                      </div>
                                    </form>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
