<?			
				//�Ѵ��â����Ż���ѵ���ǹ�ͧ��黡��ͧ
				//���ʹѡ�֡��				
				//$student_id = "'".$student_id."'";

				//ʶҹТͧ��黡��ͧ
				$pparent_status = 2;
				$pparent_status = "'".$pparent_status."'";

				//��黡��ͧ��� 
				if($parent_person == "other"){
					$parent_person_check = $parent_person;
					$parent_person = $parent_person2;
					$parent_person = "'".$parent_person."'";		
				}		
				else{
					$parent_person = "'".$parent_person."'";	
				}		



				//���ͼ�黡��ͧ
				if($p_name =="") {
					$p_name = "null";
				}
				else {
					$p_name= "'".$p_name."'";
				}	

				//���ʡ��
				if($p_surname =="") {
					$p_surname = "null";
				}
				else {
					$p_surname= "'".$p_surname."'";
				}	

				//���� 
				if($p_age =="") {
					$p_age = "null";
				}
				else {
					//$p_age= "'".$p_age."'";
					$p_age = $p_age;
				}	

				//����Ǣ�ͧ�Ѻ�ѡ�֡����
				if($p_relationship =="") {
					$p_relationship = "null";
				}
				else {
					$p_relationship= "'".$p_relationship."'";					
				}	
				

				//���ͪҵ�
				if($p_race == "other"){
					$p_race = $p_race22;
					$p_race = "'".$p_race."'";		
				}		
				else{
					$p_race = "'".$p_race."'";	
				}		

				//�ѭ�ҵ�
				if($p_citizen == "other"){
					$p_citizen = $p_citizen22;
					$p_citizen = "'".$p_citizen."'";		
				}		
				else{
					$p_citizen = "'".$p_citizen."'";	
				}		

				//��ʹ�
				if($p_religion == "other"){
					$p_religion = $p_religion22;
					$p_religion = "'".$p_religion."'";		
				}		
				else{
					$p_religion = "'".$p_religion."'";	
				}	

				//�����Ţ��Шӵ�ǻ�ЪҪ�
				if($p_id =="") {
					$p_id = "null";
				}
				else {
					$p_id= "'".$p_id."'";
				}	

				//��ҹ�Ţ���
				if($p_homeno =="") {
					$p_homeno = "null";
				}
				else {
					$p_homeno= "'".$p_homeno."'";
				}
				
				//������
				if($p_moo =="") {
					$p_moo = "null";
				}
				else {
					$p_moo= "'".$p_moo."'";
				}	

				//��͡���
				if($p_soi =="") {
					$p_soi = "null";
				}
				else {
					$p_soi= "'".$p_soi."'";
				}	

				//���
				if($p_street =="") {
					$p_street = "null";
				}
				else {
					$p_street= "'".$p_street."'";
				}	

				//�Ӻ�
				if($p_tambon =="") {
					$p_tambon = "null";
				}
				else {
					$p_tambon= "'".$p_tambon."'";
				}	

				//�����
				if($p_amphur =="") {
					$p_amphur = "null";
				}
				else {
					$p_amphur= "'".$p_amphur."'";
				}	

				//�ѧ��Ѵ
				if($p_province =="") {
					$p_province = "null";
				}
				else {
					$p_province= "'".$p_province."'";
				}	

				//������ɳ���
				if($p_zipcode =="") {
					$p_zipcode = "null";
				}
				else {
					$p_zipcode= "'".$p_zipcode."'";
				}	

				//���Ѿ��
				if($p_telno =="") {
					$p_telno = "null";
				}
				else {
					$p_telno= "'".$p_telno."'";
				}	

				//�ز��٧�ش�ͧ��黡��ͧ
				if($p_academic == "other"){
					$p_academic = $p_academic2;
					$p_academic = "'".$p_academic."'";		
				}		
				else{
					$p_academic = "'".$p_academic."'";	
				}	

				//�Ҫվ�ͧ��黡��ͧ
				if($p_occupation == "other"){
					$p_occupation = $p_occupation2;
					$p_occupation = "'".$p_occupation."'";		
				}		
				else{
					$p_occupation = "'".$p_occupation."'";	
				}	

				//����ʶҹ��Сͺ�Ҫվ
				if($p_workplace =="") {
					$p_workplace = "null";
				}
				else {
					$p_workplace= "'".$p_workplace."'";
				}	


				//�ѧ��Ѵ ʶҹ��Сͺ�Ҫվ
				if($p_workprovince =="") {
					$p_workprovince = "null";
				}
				else {
					$p_workprovince= "'".$p_workprovince."'";
				}	


				//������ɳ���
				if($p_workzipcode =="") {
					$p_workzipcode = "null";
				}
				else {
					$p_workzipcode= "'".$p_workzipcode."'";
				}	


				//���Ѿ��
				if($p_worktelno =="") {
					$p_worktelno = "null";
				}
				else {
					$p_worktelno= "'".$p_worktelno."'";
				}	


				//����������
				if($p_earn == "N"){
					$p_iswork1 = 0;
				}
				else{		
					if($p_salary == ""){
						$p_iswork1 = 0;
					}else{
						$p_iswork1 = $p_salary;
					}					
				}

?>