<?			
				include("_CheckSession.php"); 
				include ("_StartConnection.php");



$sql = "update  person
set
type= '$ptype',
person_status  = '$personstatus'
where person_id = '$p_id' ";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: admin_person_edit1.php?p_id=$p_id");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			



?>
