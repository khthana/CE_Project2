<?			
				//�Ѵ��â����Ż���ѵ���ǹ�ͧ��ô�
				//���ʹѡ�֡��				
				//$student_id = "'".$student_id."'";

				//ʶҹТͧ��ô�
				$mparent_status = 1;
				$mparent_status = "'".$mparent_status."'";

				//������ô�
				if($m_name =="") {
					$m_name = "null";
				}
				else {
					$m_name= "'".$m_name."'";
				}	

				//���ʡ��
				if($m_surname =="") {
					$m_surname = "null";
				}
				else {
					$m_surname= "'".$m_surname."'";
				}	

				//ʶҹС���ժ��Ե����
				if($m_alive =="") {
					$m_alive = "null";
				}
				else {
					$m_alive= "'".$m_alive."'";
				}	

				//���� 
				if($m_age =="") {
					$m_age = "null";
				}
				else {
					//$m_age= "'".$m_age."'";
					$m_age = $m_age;
				}	

				//���ͪҵ�
				if($m_race == "other"){
					$m_race = $m_race22;
					$m_race = "'".$m_race."'";		
				}		
				else{
					$m_race = "'".$m_race."'";	
				}		

				//�ѭ�ҵ�
				if($m_citizen == "other"){
					$m_citizen = $m_citizen22;
					$m_citizen = "'".$m_citizen."'";		
				}		
				else{
					$m_citizen = "'".$m_citizen."'";	
				}		

				//��ʹ�
				if($m_religion == "other"){
					$m_religion = $m_religion22;
					$m_religion = "'".$m_religion."'";		
				}		
				else{
					$m_religion = "'".$m_religion."'";	
				}	

				//�����Ţ��Шӵ�ǻ�ЪҪ�
				if($m_id =="") {
					$m_id = "null";
				}
				else {
					$m_id= "'".$m_id."'";
				}	

				//��ҹ�Ţ���
				if($m_homeno =="") {
					$m_homeno = "null";
				}
				else {
					$m_homeno= "'".$m_homeno."'";
				}
				
				//������
				if($m_moo =="") {
					$m_moo = "null";
				}
				else {
					$m_moo= "'".$m_moo."'";
				}	

				//��͡���
				if($m_soi =="") {
					$m_soi = "null";
				}
				else {
					$m_soi= "'".$m_soi."'";
				}	

				//���
				if($m_street =="") {
					$m_street = "null";
				}
				else {
					$m_street= "'".$m_street."'";
				}	

				//�Ӻ�
				if($m_tambon =="") {
					$m_tambon = "null";
				}
				else {
					$m_tambon= "'".$m_tambon."'";
				}	

				//�����
				if($m_amphur =="") {
					$m_amphur = "null";
				}
				else {
					$m_amphur= "'".$m_amphur."'";
				}	

				//�ѧ��Ѵ
				if($m_province =="") {
					$m_province = "null";
				}
				else {
					$m_province= "'".$m_province."'";
				}	

				//������ɳ���
				if($m_zipcode =="") {
					$m_zipcode = "null";
				}
				else {
					$m_zipcode= "'".$m_zipcode."'";
				}	

				//���Ѿ��
				if($m_telno =="") {
					$m_telno = "null";
				}
				else {
					$m_telno= "'".$m_telno."'";
				}	

				//�ز��٧�ش�ͧ��ô�
				if($m_academic == "other"){
					$m_academic = $m_academic2;
					$m_academic = "'".$m_academic."'";		
				}		
				else{
					$m_academic = "'".$m_academic."'";	
				}	

				//�Ҫվ�ͧ��ô�
				if($m_occupation == "other"){
					$m_occupation = $m_occupation2;
					$m_occupation = "'".$m_occupation."'";		
				}		
				else{
					$m_occupation = "'".$m_occupation."'";	
				}	

				//����ʶҹ��Сͺ�Ҫվ
				if($m_workplace =="") {
					$m_workplace = "null";
				}
				else {
					$m_workplace= "'".$m_workplace."'";
				}	


				//�ѧ��Ѵ ʶҹ��Сͺ�Ҫվ
				if($m_workprovince =="") {
					$m_workprovince = "null";
				}
				else {
					$m_workprovince= "'".$m_workprovince."'";
				}	


				//������ɳ���
				if($m_workzipcode =="") {
					$m_workzipcode = "null";
				}
				else {
					$m_workzipcode= "'".$m_workzipcode."'";
				}	


				//���Ѿ��
				if($m_worktelno =="") {
					$m_worktelno = "null";
				}
				else {
					$m_worktelno= "'".$m_worktelno."'";
				}	


				//����������
				if($m_earn == "N"){
					$m_iswork1 = 0;
				}
				else{				
					if($m_salary == ""){
						$m_iswork1 = 0;
					}else{
						$m_iswork1 = $m_salary;
					}
				}

?>