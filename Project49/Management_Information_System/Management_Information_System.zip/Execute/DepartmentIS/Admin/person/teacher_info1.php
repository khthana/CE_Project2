
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س  &nbsp;  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left"><br>
                                    </div></td>
                              </tr>
							  
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=right width=200 rowSpan=3><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></TD>
                                                  <TD align=middle width=350 
            height=24><STRONG>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></TD>
                                                  <TD width=200>&nbsp;</TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=middle width=350 
            height=20><strong>�����Ż���ѵԺؤ�ҡ�</strong></TD>
                                                  <TD align=left width=200><STRONG>���ʻ�Шӵ��</STRONG></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=middle width=350 height=20>&nbsp;</TD>
                                                  <TD align=left width=200><INPUT name=student_id size=13  maxLength=8> 
                                                  </TD>
                                                </TR>
                                                <TR> 
                                                  <TD width=200></TD>
                                                  <TD align=middle width=350 height=20></TD>
                                                  <TD align=left 
          width=200><STRONG>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ�</STRONG></TD>
                                                </TR>
                                                <TR> 
                                                  <TD width=200></TD>
                                                  <TD align=middle width=350 height=20></TD>
                                                  <TD align=left width=200><INPUT name=citizen_id size=13 maxLength=13></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                                                  <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                                                  <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=150 height=20>&nbsp;���ǡ�����ʵ��</TD>
                                                  <TD align=left width=300>&nbsp;���ǡ�������������</TD>
                                                  <TD align=left 
        width=300>&nbsp;���ǡ�������������</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp; <INPUT name=t_prename  type=radio 
            id=t_prename value="���" <?=$flagpre_name1?>>
                                                    ��� / Mr. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="�ҧ���"
            name=t_prename <?=$flagpre_name2?>>
                                                    �ҧ��� / Miss &nbsp;&nbsp; 
                                                    <INPUT id=t_prename 
            type=radio value="�ҧ" name=t_prename <?=$flagpre_name3?>>
                                                    �ҧ / Mrs. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="other" name=t_prename <?=$flagpre_name4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=t_prename2 title=������ 
            size=12  maxLength=16 > </TD>
                                                  <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp; <INPUT name=gender 
            type=radio id=gender value="���" <?=$flaggender1?>>
                                                    ��� &nbsp;&nbsp; <INPUT 
            id=gender type=radio value="˭ԧ"
      name=gender <?=$flaggender2?>>
                                                    ˭ԧ</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><strong>&nbsp;���˹觷ҧ�Ԫҡ��</strong></TD>
                                                  <TD align=left width=450 
            height=20><strong>&nbsp;�дѺ�ҧ�Ԫҡ��</strong></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                                    <INPUT size=32  
            maxLength=80></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT size=32 maxLength=80></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(������)</TD>
                                                  <TD align=left width=450 
            height=20><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(������)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 height=20>&nbsp; 
                                                    <INPUT name=t_name id="t_name" size=32 
            maxLength=80></TD>
                                                  <TD align=left width=450>&nbsp; 
                                                    <INPUT name=t_surname id="t_surname" size=32  maxLength=80></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                  <TD align=left width=450><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD><table width="750" border="1">
                                            <tr>
                                              <td width="293" height="20" align="left" bgcolor="#f8f8f8">&nbsp;
                                                <input name="e_name" type="text" id="e_name" size="32" maxlength="80"></td>
                                              <td width="441" bgcolor="#f8f8f8">&nbsp;<input name="e_surname" type="text" id="e_surname" size="32" maxlength="80"></td>
                                            </tr>
                                          </table></TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;<strong>�������ͧ�ؤ�ҡ�</strong><BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.
    <INPUT 
            name=p_occupation  type=radio id=radio14 value=1 <?=$work_parent1?>>
    ��������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.
    <INPUT id=radio14  type=radio value=2 
            name=p_occupation <?=$work_parent2?>>
    �Ҩ����&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.
    <INPUT id=radio14  
            type=radio value=3 name=p_occupation <?=$work_parent3?>>
    ���˹�ҷ��෤�Ԥ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4.
    <INPUT id=radio14  type=radio value=4 
            name=p_occupation <?=$work_parent4?>>
    ���˹�ҷ���ԡ���Ԫҡ��<BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.
    <INPUT id=radio14  type=radio value=5 
            name=p_occupation <?=$work_parent5?>> 
    ���˹�ҷ���á��&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 6.
    <INPUT id=radio14 
             type=radio value=6 name=p_occupation <?=$work_parent6?>>
    ���˹�ҷ�����Թ</TD>                                        
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;</TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8"><strong> ����ѵ���ǹ��� </strong></TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">  <STRONG>&nbsp;�������������¹��ҹ</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp;
                                            <INPUT 
            maxLength=10 size=5 name=homeno1>
&nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp;
<INPUT  
            maxLength=2 size=2 name=moo1>
&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp;
<INPUT 
             maxLength=20 size=16 name=soi1>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp;
<INPUT 
             maxLength=20 size=17 name=street1></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp;
                                            <INPUT  maxLength=20 size=19 name=tambon1>
&nbsp;&nbsp;&nbsp;<STRONG> �����/ࢵ</STRONG>&nbsp;&nbsp;
<INPUT  
            maxLength=20 size=16 name=amphur1>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp;
<select name="province1">
  <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_static){
																	$chk ="selected";
																	}		
																			
													  ?>
  <?
															$chk ="";
														}
														?>
</select></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp;&nbsp;
                                            <INPUT 
             maxLength=5 size=10 name=zipcode1>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;
<INPUT  maxLength=15 size=16 name=telno1></TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;<STRONG>�������������ö�Դ�����</STRONG>&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp;
                                              <INPUT name=homeno2 size=5  maxLength=10>
&nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp;
    <INPUT name=moo2 size=2  
            maxLength=2>
&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp;
    <INPUT name=soi2 size=16 
             maxLength=20>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp;
    <INPUT name=street2 size=17 
             maxLength=20>
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp;
                                              <INPUT name=tambon2 size=19  maxLength=20>
&nbsp;&nbsp;&nbsp;<STRONG> �����/ࢵ</STRONG>&nbsp;&nbsp;
    <INPUT name=amphur2 size=16  
            maxLength=20>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp;
    <select name="province2">
      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
      <?
															$chk ="";
														}
														?>
    </select>
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;<STRONG>������ɳ���</STRONG>&nbsp;&nbsp;
                                              <INPUT name=zipcode2 size=10 
             maxLength=5>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;
    <INPUT name=telno2 size=16  maxLength=15>
                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;                                          </TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8"><div align="center"><strong>���Ѿ��Դ�������</strong>&nbsp;&nbsp;                                              
                                            <input type="text" name="textfield">
                                            &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                           <strong>                                          ���Ѿ����Ͷ��&nbsp;&nbsp;</strong>                                          
                                            <input type="text" name="textfield">
                                          </div></TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8"><div align="center"><strong>E-Mail</strong>&nbsp;&nbsp;
                                              <input type="text" name="textfield">
                                          </div></TD>
                                        <TR>
                                          <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;                                          </TD>
                                        <TR> 
                                          <TD bgColor=#f8f8f8 height=40></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8> <br>
                                          <br>
                                          <br></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"><a href="teacher_info2.html">Next</a></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>  
                                    <div align="right"><br>
                                    </div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><div align="right"></div>
</td>
                              </tr>
                            </table>                            </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
