<?
	//Check session register 
	session_start();		

	if(!(isset($_SESSION["username"]) and isset($_SESSION["password"]) and $type =="admin"))
	{
		header("Location: admin_fail.php");
	}
	
		$username = $_SESSION["username"] ;
		$password = $_SESSION["password"] ;		

		
?>