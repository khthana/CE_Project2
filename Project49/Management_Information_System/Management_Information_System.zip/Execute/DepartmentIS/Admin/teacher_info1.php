<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type='text/javascript'>

function formValidator(){
	
	var person_id = document.getElementById('person_id');
	var th_name = document.getElementById('th_name');
	var th_surname = document.getElementById('th_surname');

	
	
	// Check each input in the order that it appears in the form!
	if(isEmpty(person_id, "��سһ�͹���ʺؤ�ҡ�")){
		if(isEmpty(th_name, "��سһ�͹���ͺؤ�ҡ�")){
			if(isEmpty(th_surname, "��سһ�͹���ʡ�źؤ�ҡ�")){
				
						
								var r=confirm("�׹�ѹ������������źؤ�ҡ�")
								if (r==true){
									return true;
								}
								else{
									return false;
								}						
									
					
			}
		}
	}				
	return false;
}

function isEmpty(elem, helperMsg){
	if(elem.value.length != 0){		
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}


function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

<style type="text/css">
<!--
.style1 {color: #FF0000}
-->
</style>
</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        �������к� </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><form name="form1" method="post" action="teacher_confirm.php" onsubmit='return formValidator()'>
                                    <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR>
                                                  <TD align=right width=200 rowSpan=3><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></TD>
                                                  <TD align=middle width=350 
            height=24><STRONG>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></TD>
                                                  <TD width=200>&nbsp;</TD>
                                                </TR>
                                                <TR>
                                                  <TD align=middle width=350 
            height=20><strong>�����Ż���ѵԺؤ�ҡ�</strong></TD>
                                                  <TD align=left width=200><STRONG>���ʻ�Шӵ�� <span class="style1">* </span></STRONG></TD>
                                                </TR>
                                                <TR>
                                                  <TD align=middle width=350 height=20>&nbsp;</TD>
                                                  <TD align=left width=200><INPUT name=person_id  id = person_id size=13  maxLength=8>
                                                  </TD>
                                                </TR>
                                                <TR>
                                                  <TD width=200></TD>
                                                  <TD align=middle width=350 height=20></TD>
                                                  <TD align=left 
          width=200><STRONG>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ�</STRONG></TD>
                                                </TR>
                                                <TR>
                                                  <TD width=200></TD>
                                                  <TD align=middle width=350 height=20></TD>
                                                  <TD align=left width=200><INPUT name=citizenid size=13 maxLength=13 ></TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                                                  <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                                                  <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=150 height=20>&nbsp;���ǡ�����ʵ��</TD>
                                                  <TD align=left width=300>&nbsp;���ǡ�������������</TD>
                                                  <TD align=left 
        width=300>&nbsp;���ǡ�������������</TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp;
                                                      <INPUT name=prename  type=radio  value="���" checked  <?=$flagprename1?>>
                  ��� / Mr. &nbsp;&nbsp;
                  <INPUT name=prename type=radio value="�ҧ���"  <?=$flagprename2?> >
                  �ҧ��� / Miss &nbsp;&nbsp;
                  <INPUT name=prename type=radio value="�ҧ"  <?=$flagprename3?> >
                  �ҧ / Mrs. &nbsp;&nbsp;
                  <INPUT  name=prename type=radio value="other"  <?=$flagprename4?>>
                  ���� (�к�)&nbsp;:&nbsp;
                  <INPUT name=prename2  size=12  maxLength=16 >
                                                  </TD>
                                                  <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp;
                                                      <INPUT name=gender  type=radio id=gender value="���" checked <?=$flaggender1?>>
                  ��� &nbsp;&nbsp;
                  <INPUT  name=gender type=radio value="˭ԧ"  <?=$flaggender2?> >
                  ˭ԧ </TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=300 
            height=20><strong>&nbsp;���˹觷ҧ�Ԫҡ�� </strong></TD>
                                                  <TD align=left width=450 
            height=20><strong>&nbsp;�дѺ�ҧ�Ԫҡ�� </strong></TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=300 height=20>&nbsp;
                                                      <INPUT size=32  maxLength=80 name = position1></TD>
                                                  <TD align=left width=450>&nbsp;
                                                      <INPUT size=32 maxLength=80 name = level>
                                                  </TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(������) <span class="style1">* </span></TD>
                                                  <TD align=left width=450 
            height=20><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(������) <span class="style1">* </span></TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=300 height=20>&nbsp;
                                                      <INPUT name=th_name id = th_name size=32  maxLength=80></TD>
                                                  <TD align=left width=450>&nbsp;
                                                      <INPUT name=th_surname id =th_surname  size=32  maxLength=80></TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR>
                                                  <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                  <TD align=left width=450><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                </TR>
                                              </TBODY>
                                          </TABLE></TD>
                                        </TR>
                                        <TR>
                                          <TD><table width="750" border="1">
                                              <tr>
                                                <td width="293" height="20" align="left" bgcolor="#f8f8f8">&nbsp;
                                                    <input name=en_name type="text" size="32" maxlength="80"></td>
                                                <td width="441" bgcolor="#f8f8f8">&nbsp;
                                                    <input name="en_surname" type="text" size="32" maxlength="80"></td>
                                              </tr>
                                          </table></TD>
                                        </TR>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;&nbsp;<strong>�������ͧ�ؤ�ҡ�</strong><BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.
          <INPUT  name=ptype  type=radio  value=0 <?=$flagtype0?> >
          ��������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.
          <INPUT name=ptype  type=radio value=1 checked  <?=$flagtype1?>>
          �Ҩ����&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.
          <INPUT  type=radio value=2 name=ptype  <?=$flagtype2?>>
          ���˹�ҷ��෤�Ԥ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4.
          <INPUT  type=radio value=3  name=ptype  <?=$flagtype3?>>
          ���˹�ҷ���ԡ���Ԫҡ��<BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.
          <INPUT  type=radio value=4 name=ptype  <?=$flagtype4?>>
          ���˹�ҷ���á��&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 6.
          <INPUT  type=radio value=5 name=ptype <?=$flagtype5?> >
          ���˹�ҷ�����Թ</TD>
                                        <TR>
                                          <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;</TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8 height=40><div align="right">
                                              <input type="submit" name="Submit" value="Submit">
                                          </div></TD>
                                        </TR>
                                        <TR>
                                          <TD bgColor=#f8f8f8><br>
                                              <br>
                                              <br></TD>
                                        </TR>
                                        <TR>
                                          <TD><div align="right"></div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                  </form>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
