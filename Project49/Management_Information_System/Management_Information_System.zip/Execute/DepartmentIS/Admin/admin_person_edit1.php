<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

<style type="text/css">
<!--
.style1 {color: #FF0000}
-->
</style>
</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> �������к� </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <?
									   include ("_menu.php");
									   include ("_sql_info1.php");
									   ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="right"><br>
                                    </div></td>
                              </tr>
							  
                              <tr>
                                <td align="left" valign="top"><form name="form1" method="post" action="admin_person_confirm.php">
                                  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                    <TBODY>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                            <TBODY>
                                              <TR>
                                                <TD align=right width=67 rowSpan=3><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></TD>
                                                <TD 
            height=24 colspan="2" align=middle><div align="center"><STRONG> ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></div></TD>
                                                <TD width=216 rowspan="4"><table width="53%" height="73" border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                                                    <tr>
                                                      <td><div align="center">
                                                          <?
														$rootdir = "/AppServ/www/Departmentis/resource/pics/person";
														$a="$rootdir/". $person_id . ".gif";
														//print $a;
														if (file_exists($a)) { 
															print "<img src='../resource/pics/person/". $person_id . ".gif' >";
														}
														else {
															print "<img src='../resource/pics/person/default.gif' >";
														}														
														
														?>
                                                      </div></td>
                                                    </tr>
                                                </table></TD>
                                              </TR>
                                              <TR>
                                                <TD 
            height=20 colspan="2" align=middle><div align="center"><strong> �����Ż���ѵԺؤ�ҡ�</strong></div></TD>
                                              </TR>
                                              <TR>
                                                <TD height=20 colspan="2" align=middle>&nbsp;</TD>
                                              </TR>
                                              <TR>
                                                <TD width=67></TD>
                                                <TD height=20 colspan="2" align=middle></TD>
                                              </TR>
                                              <TR>
                                                <TD></TD>
                                                <TD width=219 height=20 align=middle><div align="left"><strong>���ʻ�Шӵ��&nbsp; </strong></div></TD>
                                                <TD width=248 align=middle><div align="left"><strong>
                                                    <input name=person_id size=13  maxlength=8  value="<?=$person_id?>" disabled>
													<input type = "hidden"  name=p_id size=13  maxlength=8  value="<?=$person_id?>" >
                                                </strong></div></TD>
                                                <TD align=left>&nbsp;</TD>
                                              </TR>
                                              <TR>
                                                <TD width=67></TD>
                                                <TD height=20 align=middle><div align="left"><strong>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ� </strong></div></TD>
                                                <TD height=20 align=middle><div align="left"><strong>
                                                    <input name=citizenid size=13 maxlength=13  value="<?=$citizenid?>" disabled >
                                                </strong></div></TD>
                                                <TD align=left width=216>&nbsp;</TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                                                <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                                                <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=150 height=20>&nbsp;���ǡ�����ʵ��</TD>
                                                <TD align=left width=300>&nbsp;���ǡ�������������</TD>
                                                <TD align=left 
        width=300>&nbsp;���ǡ�������������</TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp;
                                                    <INPUT name=prename  type=radio  value="���" disabled  <?=$flagprename1?> >
                ��� / Mr. &nbsp;&nbsp;
                <INPUT name=prename type=radio value="�ҧ���"  disabled <?=$flagprename2?>  >
                �ҧ��� / Miss &nbsp;&nbsp;
                <INPUT name=prename type=radio value="�ҧ" disabled  <?=$flagprename3?> >
                �ҧ / Mrs. &nbsp;&nbsp;
                <INPUT  name=prename type=radio value="other"   disabled <?=$flagprename4?>>
                ���� (�к�)&nbsp;:&nbsp;
                <INPUT name=prename2  size=12  maxLength=16 disabled value="<?=$prenamestatus?>" >
                                                </TD>
                                                <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp;
                                                    <INPUT name=gender  type=radio id=gender  disabled value="���" <?=$flaggender1?>>
                                                    ��� &nbsp;&nbsp;
                                                    <INPUT  name=gender type=radio value="˭ԧ"  disabled <?=$flaggender2?> >
                ˭ԧ </TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=300 
            height=20><strong>&nbsp;���˹觷ҧ�Ԫҡ��</strong></TD>
                                                <TD align=left width=450 
            height=20><strong>&nbsp;�дѺ�ҧ�Ԫҡ��</strong></TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=300 height=20>&nbsp;
                                                    <INPUT size=32  maxLength=80 name = position1  disabled value="<?=$position1?>"></TD>
                                                <TD align=left width=450>&nbsp;
                                                    <INPUT size=32 maxLength=80 name = level  disabled value="<?=$level?>">
                                                </TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(������)</TD>
                                                <TD align=left width=450 
            height=20><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(������)</TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=300 height=20>&nbsp;
                                                    <INPUT name=th_name size=32  maxLength=80 disabled  value="<?=$th_name?>"></TD>
                                                <TD align=left width=450>&nbsp;
                                                    <INPUT name=th_surname  size=32  maxLength=80  disabled value="<?=$th_surname?>"></TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                            <TBODY>
                                              <TR>
                                                <TD align=left width=300 
            height=20><STRONG>&nbsp;����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                                <TD align=left width=450><STRONG>&nbsp;���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                                              </TR>
                                            </TBODY>
                                        </TABLE></TD>
                                      </TR>
                                      <TR>
                                        <TD><table width="750" border="1">
                                            <tr>
                                              <td width="293" height="20" align="left" bgcolor="#f8f8f8">&nbsp;
                                                  <input name=en_name type="text" size="32" maxlength="80"  disabled value="<?=$en_name?>"></td>
                                              <td width="441" bgcolor="#f8f8f8">&nbsp;
                                                  <input name="en_surname" type="text" size="32" maxlength="80"  disabled value="<?=$en_surname?>"></td>
                                            </tr>
                                        </table></TD>
                                      </TR>
                                      <TR>
                                        <TD height=20 align=left bgcolor="#f8f8f8"><table width="99%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF0000">
                                          <tr>
                                            <td><strong><br>
                                              �������ͧ�ؤ�ҡ�</strong><BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.
<INPUT  name=ptype  type=radio  value=0  <?=$flagtype0?> >
��������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.
<INPUT  type=radio value=1 name=ptype   <?=$flagtype1?>>
�Ҩ����&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.
<INPUT  type=radio value=2 name=ptype    <?=$flagtype2?>>
���˹�ҷ��෤�Ԥ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4.
<INPUT  type=radio value=3  name=ptype    <?=$flagtype3?>>
���˹�ҷ���ԡ���Ԫҡ��<BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.
<INPUT  type=radio value=4 name=ptype    <?=$flagtype4?>>
���˹�ҷ���á��&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 6.
<INPUT  type=radio value=5 name=ptype   <?=$flagtype5?> >
���˹�ҷ�����Թ<br>
<strong><br>
ʶҹТͧ�ؤ�ҡ�</strong><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.
<INPUT  name=personstatus  type=radio  value="Y"  <?=$flagpersonstatus0?> > 
�繺ؤ�ҡâͧ�Ҥ�Ԫ��<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.
<INPUT  type=radio value="N" name=personstatus   <?=$flagpersonstatus1?>> 
<span class="style1">������繺ؤ�ҡâͧ�Ҥ�Ԫ������</span><br>
<br></td>
                                          </tr>
                                        </table>                                          ��</TD>
                                      <TR>
                                        <TD height=20 align=left bgcolor="#f8f8f8">&nbsp;</TD>
                                      </TR>
                                      <TR>
                                        <TD 
            height=20 align=left bgcolor="#f8f8f8">&nbsp;</TD>
                                      <TR>
                                        <TD><div align="right"></div></TD>
                                      </TR>
                                    </TBODY>
                                  </TABLE>
                                  <div align="center"><br>
                                      <br>
                                      <input type="Submit" name="Submit" value="�׹�ѹ�������¹�ŧ">
                                  </div>
                                </form>
                                <div align="right"><br>
                                  <br>
                                    </div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><div align="right"></div>
</td>
                              </tr>
                            </table>                            </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
