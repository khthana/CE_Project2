<?			
				//�Ѵ��â����Ż���ѵ���ǹ�ͧ�Դ�
				//���ʹѡ�֡��				
				//$student_id = "'".$student_id."'";

				//ʶҹТͧ�Դ�
				$fparent_status = 0;
				$fparent_status = "'".$fparent_status."'";

				//���ͺԴ�
				if($f_name =="") {
					$f_name = "null";
				}
				else {
					$f_name= "'".$f_name."'";
				}	

				//���ʡ��
				if($f_surname =="") {
					$f_surname = "null";
				}
				else {
					$f_surname= "'".$f_surname."'";
				}	

				//ʶҹС���ժ��Ե����
				if($f_alive =="") {
					$f_alive = "null";
				}
				else {
					$f_alive= "'".$f_alive."'";
				}	

				//���� 
				if($f_age =="") {
					$f_age = "null";
				}
				else {
					//$f_age= "'".$f_age."'";
					$f_age = $f_age;
				}	

				//���ͪҵ�
				if($f_race == "other"){
					$f_race = $f_race22;
					$f_race = "'".$f_race."'";		
				}		
				else{
					$f_race = "'".$f_race."'";	
				}		

				//�ѭ�ҵ�
				if($f_citizen == "other"){
					$f_citizen = $f_citizen22;
					$f_citizen = "'".$f_citizen."'";		
				}		
				else{
					$f_citizen = "'".$f_citizen."'";	
				}		

				

				//��ʹ�
				if($f_religion == "other"){
					$f_religion = $f_religion22;
					$f_religion = "'".$f_religion."'";		
				}		
				else{
					$f_religion = "'".$f_religion."'";	
				}	

				//�����Ţ��Шӵ�ǻ�ЪҪ�
				if($f_id =="") {
					$f_id = "null";
				}
				else {
					$f_id= "'".$f_id."'";
				}	

				//��ҹ�Ţ���
				if($f_homeno =="") {
					$f_homeno = "null";
				}
				else {
					$f_homeno= "'".$f_homeno."'";
				}
				
				//������
				if($f_moo =="") {
					$f_moo = "null";
				}
				else {
					$f_moo= "'".$f_moo."'";
				}	

				//��͡���
				if($f_soi =="") {
					$f_soi = "null";
				}
				else {
					$f_soi= "'".$f_soi."'";
				}	

				//���
				if($f_street =="") {
					$f_street = "null";
				}
				else {
					$f_street= "'".$f_street."'";
				}	

				//�Ӻ�
				if($f_tambon =="") {
					$f_tambon = "null";
				}
				else {
					$f_tambon= "'".$f_tambon."'";
				}	

				//�����
				if($f_amphur =="") {
					$f_amphur = "null";
				}
				else {
					$f_amphur= "'".$f_amphur."'";
				}	

				//�ѧ��Ѵ
				if($f_province =="") {
					$f_province = "null";
				}
				else {
					$f_province= "'".$f_province."'";
				}	

				//������ɳ���
				if($f_zipcode =="") {
					$f_zipcode = "null";
				}
				else {
					$f_zipcode= "'".$f_zipcode."'";
				}	

				//���Ѿ��
				if($f_telno =="") {
					$f_telno = "null";
				}
				else {
					$f_telno= "'".$f_telno."'";
				}	

				//�ز��٧�ش�ͧ�Դ�
				if($f_academic == "other"){
					$f_academic = $f_academic2;
					$f_academic = "'".$f_academic."'";		
				}		
				else{
					$f_academic = "'".$f_academic."'";	
				}	

				//�Ҫվ�ͧ�Դ�
				if($f_occupation == "other"){
					$f_occupation = $f_occupation2;
					$f_occupation = "'".$f_occupation."'";		
				}		
				else{
					$f_occupation = "'".$f_occupation."'";	
				}	

				//����ʶҹ��Сͺ�Ҫվ
				if($f_workplace =="") {
					$f_workplace = "null";
				}
				else {
					$f_workplace= "'".$f_workplace."'";
				}	


				//�ѧ��Ѵ ʶҹ��Сͺ�Ҫվ
				if($f_workprovince =="") {
					$f_workprovince = "null";
				}
				else {
					$f_workprovince= "'".$f_workprovince."'";
				}	


				//������ɳ���
				if($f_workzipcode =="") {
					$f_workzipcode = "null";
				}
				else {
					$f_workzipcode= "'".$f_workzipcode."'";
				}	


				//���Ѿ��
				if($f_worktelno =="") {
					$f_worktelno = "null";
				}
				else {
					$f_worktelno= "'".$f_worktelno."'";
				}	


				//����������
				if($f_earn == "N"){
					$f_iswork1 = 0;
				}
				else{					
					if($f_salary2==""){
						$f_iswork1 = 0;
					}else{
						$f_iswork1 = $f_salary2;
					}					
				}		


?>