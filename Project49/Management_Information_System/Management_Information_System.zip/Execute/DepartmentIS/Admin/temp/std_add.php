<?
include("_CheckSession.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<script type='text/javascript'>

function formValidator(){
	
	var bookid1 = document.getElementById('std_year');
	var bookyear = document.getElementById('student_id');
	var bnamethai = document.getElementById('t_prename');
	var bnameeng = document.getElementById('t_name');
	var advisor1 = document.getElementById('t_surname');
	
	
	// Check each input in the order that it appears in the form!
	if(isEmpty(bookid1, "��سһ�͹�ա���֡��")){
		if(isEmpty(bookyear, "��سһ�͹���ʹѡ�֡��")){
			if(isEmpty(bnamethai, "��سһ�͹�ӹ�˹�Ҫ���")){
				if(isEmpty(bnameeng, "��سһ�͹����������")){
					if(isEmpty(advisor1, "��سһ�͹���ʡ��������")){
						
								var r=confirm("�׹�ѹ������������Źѡ�֡��")
								if (r==true){
									return true;
								}
								else{
									return false;
								}						
									
					}
				}
			}
		}
	}				
	return false;
}

function isEmpty(elem, helperMsg){
	if(elem.value.length != 0){		
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}


function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">

<title>�к����ʹ���Ҥ�Ԫ����ǡ�������������</title>
</head>

<body class = "classbody">
<FORM name=edit action=admin_std_add.php method=post onsubmit='return formValidator()'>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD height=10></TD>
      </TR>
      <TR> 
        <TD align=middle>&nbsp;</TD>
      </TR>
      <TR> 
        <TD vAlign=bottom align=left height=25><a href="admin_main.php"><img src="../resource/img/home.gif" width="16" height="17" border="0"></a> 
         <u> ���������Źѡ�֡�һ�ԭ�ҵ��</u> </TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=right width=200 rowSpan=3><IMG height=64 
            src="../resource/img/kmitl_logo3.gif" width=64></TD>
                <TD align=middle width=350 
            height=24><STRONG>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG></TD>
                <TD width=200>&nbsp;</TD>
              </TR>
              <TR> 
                <TD align=middle width=350 
            height=20><STRONG>�͡�����§ҹ��ǹѡ�֡���������¹����ѵԹѡ�֡��</STRONG></TD>
                <TD align=left width=200><STRONG>���ʹѡ�֡��<font color="#FF0000">*</font></STRONG></TD>
              </TR>
              <TR> 
                <TD align=middle width=350 height=20><STRONG>�дѺ��ԭ�ҵ�� ��Шӻա���֡��<font color="#FF0000">* 
                  </font> 
                  <input name="std_year" type="text" id="std_year" size="4" maxlength="4">
                  </STRONG></TD>
                <TD align=left width=200><INPUT  maxLength=8 size=13 name=student_id> 
                </TD>
              </TR>
              <TR> 
                <TD width=200></TD>
                <TD align=middle width=350 height=20></TD>
                <TD align=left 
          width=200><STRONG>�Ţ���ºѵû�Шӵ�ǻ�ЪҪ�</STRONG></TD>
              </TR>
              <TR> 
                <TD width=200></TD>
                <TD align=middle width=350 height=20></TD>
                <TD align=left width=200><INPUT maxLength=13 size=13 name=citizen_id></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=150 height=20>&nbsp;<STRONG>���</STRONG></TD>
                <TD align=left width=300 height=20>&nbsp;<STRONG>�Ҥ�Ԫ�</STRONG></TD>
                <TD align=left width=300 
        height=20>&nbsp;<STRONG>�Ң��Ԫ�</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=150 height=20>���ǡ�����ʵ��</TD>
                <TD align=left width=300>���ǡ�������������</TD>
                <TD align=left 
        width=300>���ǡ�������������</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=620 
            height=20>&nbsp;<STRONG>�ӹ�˹�Ҫ���</STRONG>&nbsp; <INPUT name=t_prename  type=radio 
            id=t_prename value="���" checked>
                  ��� / Mr. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="�ҧ���"
            name=t_prename>
                  �ҧ��� / Miss &nbsp;&nbsp; <INPUT id=t_prename 
            type=radio value="�ҧ" name=t_prename>
                  �ҧ / Mrs. &nbsp;&nbsp; <INPUT id=t_prename  type=radio value="other" name=t_prename>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT title=������  maxLength=16 
            size=12 name=t_prename2> </TD>
                <TD align=left width=130 
            height=20>&nbsp;<STRONG>��</STRONG>&nbsp; <INPUT name=gender 
            type=radio id=gender value="���" checked>
                  ��� &nbsp;&nbsp; <INPUT 
            id=gender type=radio value="˭ԧ"
      name=gender>
                  ˭ԧ</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=300 
            height=20>&nbsp;<STRONG>����</STRONG>&nbsp;(������)<font color="#FF0000">*</font></TD>
                <TD align=left width=450 
            height=20>&nbsp;<STRONG>���ʡ��</STRONG>&nbsp;(������)<font color="#FF0000">*</font></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=300 height=20>&nbsp; <INPUT  
            maxLength=80 size=32 name=t_name></TD>
                <TD align=left width=450>&nbsp; <INPUT maxLength=80 size=32 name=t_surname></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=300 
            height=20>&nbsp;<STRONG>����</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
                <TD align=left width=450 
            height=20>&nbsp;<STRONG>���ʡ��</STRONG>&nbsp;(�����ѧ��ɵ�Ǿ�����˭�)</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=300 height=20>&nbsp; <INPUT 
            maxLength=80 size=32 name=e_name></TD>
                <TD align=left width=450>&nbsp; <INPUT  maxLength=80 size=32 name=e_surname></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;<STRONG>����������Ѻ��ҹѡ�֡��</STRONG>&nbsp;(����Ѻ���˹�ҷ��)</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#e8e8e8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left 
            width=750>&nbsp;<STRONG>�ͺ��ҹ��ǧ����Է�����</STRONG> &nbsp; <INPUT name=type1 type=radio 
            id=type value="��ѡ�ٵû���" checked>
                  ��ѡ�ٵû��� &nbsp; <INPUT id=type type=radio value="�ç�������Ѵ"
            name=type1>
                  �ç�������Ѵ &nbsp; <INPUT id=type  type=radio 
            value="��ѡ�ٵùҹҪҵ�" name=type1>
                  ��ѡ�ٵùҹҪҵ� <BR> &nbsp;<STRONG>ʶҺѹ�Ѵ�ͺ�Ѵ���͡</STRONG><BR> 
                  &nbsp;<STRONG>��ѡ�ٵ� 4-5 ��</STRONG> &nbsp; <INPUT id=type  type=radio value=1
            name=type11>
                  ��ѡ�ٵû���&nbsp; <INPUT id=type1  type=radio 
            value=2 name=type11>
                  �ǵ�� &nbsp; <INPUT id=type  type=radio 
            value=3 name=type11>
                  �Ҥ�����&nbsp; <INPUT id=type1  type=radio 
            value=4 name=type11>
                  ��Ƿ. &nbsp; <INPUT id=type type=radio 
            value=5 name=type11>
                  ��ǹ.&nbsp; <INPUT id=type11  type=radio 
            value=6 name=type1>
                  ��ҧ��͡ &nbsp; <INPUT id=type  
            type=radio value=7 name=type11>
                  ���Ҵ���&nbsp; <INPUT id=type1 
             type=radio value=8 name=type11>
                  �ҹҪҵ� &nbsp; <INPUT id=type  type=radio value=9
            name=type11>
                  �ع���¹���Է����ʵ�� <BR> &nbsp;<STRONG>��ѡ�ٵ� 1-3 ��</STRONG> 
                  &nbsp; <INPUT id=type  type=radio value=1
            name=type12>
                  ������ͧ���� &nbsp; <INPUT id=type  type=radio 
            value=2 name=type12>
                  ������ͧ����� &nbsp; <INPUT id=type  
            type=radio value=3 name=type12>
                  �ǵ�� &nbsp; <INPUT id=type  
            type=radio value=4 name=type12>
                  ���Ҵ��� <BR> &nbsp; <INPUT id=type 
             type=radio value=5 name=type12>
                  �ѡ�֡�� / ����֡�����������ǵ�ҧ�ҵ� &nbsp; <INPUT id=type  
            type=radio value=6 name=type12>
                  ����֡�������������� </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 bgColor=#e8e8e8>&nbsp;<STRONG>�����˵� 
                  :</STRONG>&nbsp; �ҡ��ҡ�������ѧ��� ����͡�͡��� ʨ�.1 �Ҵ�س���ѵԷ���� 
                  ��Фس���ѵ�੾�е����С�Ȥ��͹ء�����á�û���ҹ�ҹ��äѴ���͡ 
                  �ؤ������֡�ҵ���ʶҺѹ�ش��֡��� �ͧ��ǧ����Է����� ��е����͡�˹�����ͧ�س���ѵԼ����Ѥ����ѡ�ٵ� 
                  ����ç��õ�ҧ� �ͧʶҺѹ� �ж١�Ѵ�Է��� �������Ѻ����繹ѡ�֡�ҢͧʶҺѹ�</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 1 ����ѵԹѡ�֡��</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.1</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Դ</STRONG>&nbsp;�ѹ���&nbsp; <select name="date">
                    <?
															$var_day = range(0,31);
															foreach ($var_day as $theday) {	
																if ($theday == 0) {
																	$theday = "";
																}
																if ($theday == $birth_day) {
																	$chk = "selected";
																}
																
															?>
                    <option value="<?=$theday?>" <?=$chk?>> 
                    <?=$theday?>
                    </option>
                    <?		
															$chk = "";
														}
														?>
                  </select>
                  &nbsp;&nbsp;��͹&nbsp; <select name="month">
                    <?
														include("../resource/_array.php");
														 foreach (	$arraymonth as $valuemonth => $month)
														{				
																if ($valuemonth == 0) {
																	$valuemonth = "";
																}
																if ($valuemonth == $birth_month){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valuemonth?>" <?=$chk?>> 
                    <?=$month?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select>
                  &nbsp;&nbsp;��&nbsp; <select name="year">
                    <?
															$var_year = range(2449,2550);
															foreach ($var_year as $theyear) {	
																if ($theyear == 2449) {
																	$theyear = "";
																}
																if ($theyear== $birth_year) {
																	$chk = "selected";
																}
																
															?>
                    <option value="<?=$theyear?>" <?=$chk?>> 
                    <?=$theyear?>
                    </option>
                    <?		
															$chk = "";
														}
														?>
                  </select>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <STRONG>�ѧ��Ѵ����Դ</STRONG>&nbsp; <select name="province_of_birth">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $birth_place){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.2</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=race  type=radio id=race value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT 
            id=race  type=radio value="�չ" name=race>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=race 
             type=radio value="other" name=race>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=20 size=14 name=race2> 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=citizen type=radio id=citizen value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=citizen  
            type=radio value="�չ" name=citizen>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=citizen  
            type=radio value="other" name=citizen>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
             maxLength=20 size=14 name=citizen2></TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.3</STRONG> 
                  &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <input name=religion  
            type=radio id=religion value="�ط�" checked>
                  �ط� &nbsp;&nbsp;2. 
                  <INPUT 
            id=religion  type=radio value="���ʵ�" name=religion>
                  ���ʵ� &nbsp;3. 
                  <INPUT id=religion  type=radio value="������"
            name=religion>
                  ������ &nbsp;&nbsp;4. 
                  <INPUT id=religion  
            type=radio value="other" name=religion>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
             maxLength=20 size=16 name=religion2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.4</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������Ե</STRONG>&nbsp;&nbsp;1. 
                  <INPUT name=blood 
             type=radio id=blood value="A" checked>
                  A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                  <INPUT id=blood  
            type=radio value="B" name=blood>
                  B &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. 
                  <INPUT id=blood  
            type=radio value="AB" name=blood>
                  AB &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4. 
                  <INPUT id=blood 
             type=radio value="O" name=blood>
                  O &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5. 
                  <INPUT id=blood  
            type=radio value="�����" name=blood>
                  ����� </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.5</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������������¹��ҹ</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=10 size=5 name=homeno1> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT  
            maxLength=2 size=2 name=moo1> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=16 name=soi1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=17 name=street1> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=20 size=19 name=tambon1> &nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT  
            maxLength=20 size=16 name=amphur1>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="province1">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_static){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=zipcode1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=15 size=16 name=telno1> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.6</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������������ö�Դ�����</STRONG>&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <INPUT  maxLength=10 size=5 name=homeno2> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT  
            maxLength=2 size=2 name=moo2> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=16 name=soi2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=17 name=street2> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=20 size=19 name=tambon2> &nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT  
            maxLength=20 size=16 name=amphur2>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="province2">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=zipcode2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=15 size=16 name=telno2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.7</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Ѩ�غѹ���������Ѻ</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT
            name=livewith type=radio id=livewith value="�Դ�-��ô�" checked>
                  �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=livewith  type=radio value="�Դ�" name=livewith>
                  �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=livewith  type=radio value="��ô�" name=livewith>
                  ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=livewith  type=radio value="��ҹ���"
            name=livewith>
                  ��ҹ���/��ͧ��� &nbsp;&nbsp; 5. 
                  <INPUT id=livewith 
             type=radio value="�;ѡʶҺѹ" name=livewith>
                  �;ѡʶҺѹ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6. 
                  <INPUT id=livewith  
            type=radio value="�;ѡ�͡��" name=livewith>
                  �;ѡ�͡�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=livewith  type=radio value="�ҵ�" name=livewith>
                  �ҵ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  8. 
                  <INPUT id=livewith  type=radio value="�Ѵ" name=livewith>
                  �Ѵ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  9. 
                  <INPUT id=livewith  type=radio value="other" name=livewith>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=25 size=16 
            name=livewith2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.8</STRONG> 
                  &nbsp;&nbsp;<STRONG>ʶҹ�Ҿ���ʢͧ�Դ�-��ô�</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=parentstatus  type=radio id=parentstatus value=1 checked>
                  ������¡ѹ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=parentstatus 
             type=radio value=2 name=parentstatus>
                  �Դ�-��ôҶ֧����� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=parentstatus  type=radio value=3 
            name=parentstatus>
                  �ԴҶ֧����� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. 
                  <INPUT id=parentstatus 
             type=radio value=4 name=parentstatus>
                  ��ôҶ֧����� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT id=parentstatus  type=radio value=5 
            name=parentstatus>
                  ���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  6. 
                  <INPUT id=parentstatus  type=radio value=6 
            name=parentstatus>
                  �¡�ѹ�������Ф������繷ҧ�Ҫվ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=parentstatus  type=radio value=7 
            name=parentstatus>
                  �¡�ѹ���������˵ؼ���� </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.9</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ѡ�֡���繺صä����</STRONG>&nbsp; <INPUT 
             maxLength=2 size=2 name=childno> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>㹨ӹǹ����ͧ 
                  �Դ�-��ô����ǡѹ����ժ��Ե����</STRONG>&nbsp; <INPUT  
            maxLength=2 size=2 name=no_of_child> &nbsp;�� &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>����������ҧ����֡��</STRONG>&nbsp; 
                  <INPUT 
             maxLength=2 size=2 name=std_children> &nbsp;�� </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>1.10</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ѡ�֡���������ҡ��÷ӧҹ�������</STRONG>&nbsp; 
                  1. 
                  <INPUT
            name=iswork  type=radio id=iswork value="N" checked>
                  ���������� &nbsp;&nbsp; 2. 
                  <INPUT id=iswork 
            type=radio value="Y"name=iswork>
                  �� (�к�) �����&nbsp; <INPUT 
             maxLength=7 size=7 name=salary> &nbsp;�ҷ/��͹ </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 2 ����ѵԡ���֡��</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD valign="top" bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>2.1</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������稡���֡��</STRONG> </TD>
              </TR>
              <TR> 
                <TD align=left 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����稡���֡���дѺ 
                  <select name="finish1">
                    <option value="1">�дѺ�Ѹ���֡�ҵ͹���� (�.6) </option>
                    <option value="2">�дѺ�Ѹ���֡�ҵ͹���� (�ͺ��º)</option>
                    <option value="3">�дѺ��С�ȹ�ºѵ��ԪҪվ����٧�ҡ�ç���¹/�Է�����</option>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. �ҡ�ç���¹ 
                  <INPUT  maxLength=45 size=45 
            name=highschool1> <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ѧ��Ѵ&nbsp; 
                  <SELECT  name=select_c_name>
                    <OPTION value="" 
              selected></OPTION>
                    <OPTION value=10>��ا෾��ҹ��</OPTION>
                    <OPTION 
              value=71>�ҭ������</OPTION>
                    <OPTION 
              value=46>����Թ���</OPTION>
                    <OPTION 
              value=62>��ᾧྪ�</OPTION>
                    <OPTION value=81>��к��</OPTION>
                    <OPTION 
              value=40>�͹��</OPTION>
                    <OPTION value=22>�ѹ�����</OPTION>
                    <OPTION 
              value=24>���ԧ���</OPTION>
                    <OPTION 
              value=20>�ź���</OPTION>
                    <OPTION value=18>��¹ҷ</OPTION>
                    <OPTION 
              value=36>�������</OPTION>
                    <OPTION value=86>�����</OPTION>
                    <OPTION 
              value=50>��§����</OPTION>
                    <OPTION 
              value=57>��§���</OPTION>
                    <OPTION value=92>��ѧ</OPTION>
                    <OPTION 
              value=63>�ҡ</OPTION>
                    <OPTION value=23>��Ҵ</OPTION>
                    <OPTION 
              value=12>�������</OPTION>
                    <OPTION value=73>��û��</OPTION>
                    <OPTION 
              value=30>����Ҫ����</OPTION>
                    <OPTION 
              value=80>�����ո����Ҫ</OPTION>
                    <OPTION 
              value=60>������ä�</OPTION>
                    <OPTION 
              value=26>��ù�¡</OPTION>
                    <OPTION value=48>��þ��</OPTION>
                    <OPTION 
              value=55>��ҹ</OPTION>
                    <OPTION value=96>��Ҹ����</OPTION>
                    <OPTION 
              value=31>���������</OPTION>
                    <OPTION 
              value=13>�����ҹ�</OPTION>
                    <OPTION 
              value=77>��ШǺ���բѹ��</OPTION>
                    <OPTION 
              value=25>��Ҩչ����</OPTION>
                    <OPTION 
              value=94>�ѵ�ҹ�</OPTION>
                    <OPTION 
              value=14>��й�������ظ��</OPTION>
                    <OPTION 
              value=76>ྪú���</OPTION>
                    <OPTION value=82>�ѧ��</OPTION>
                    <OPTION 
              value=93>�ѷ�ا</OPTION>
                    <OPTION value=66>�ԨԵ�</OPTION>
                    <OPTION 
              value=67>ྪú�ó�</OPTION>
                    <OPTION 
              value=65>��ɳ��š</OPTION>
                    <OPTION value=54>���</OPTION>
                    <OPTION 
              value=56>�����</OPTION>
                    <OPTION value=83>����</OPTION>
                    <OPTION 
              value=58>�����ͧ�͹</OPTION>
                    <OPTION 
              value=44>�����ä��</OPTION>
                    <OPTION 
              value=49>�ء�����</OPTION>
                    <OPTION value=35>��ʸ�</OPTION>
                    <OPTION 
              value=95>����</OPTION>
                    <OPTION value=70>�Ҫ����</OPTION>
                    <OPTION 
              value=21>���ͧ</OPTION>
                    <OPTION value=85>�йͧ</OPTION>
                    <OPTION 
              value=45>�������</OPTION>
                    <OPTION value=16>ž����</OPTION>
                    <OPTION 
              value=51>�Ӿٹ</OPTION>
                    <OPTION value=52>�ӻҧ</OPTION>
                    <OPTION 
              value=42>���</OPTION>
                    <OPTION value=33>�������</OPTION>
                    <OPTION 
              value=74>��ط��Ҥ�</OPTION>
                    <OPTION 
              value=11>��طû�ҡ��</OPTION>
                    <OPTION 
              value=75>��ط�ʧ����</OPTION>
                    <OPTION 
              value=72>�ؾ�ó����</OPTION>
                    <OPTION 
              value=17>�ԧ�����</OPTION>
                    <OPTION 
              value=19>��к���</OPTION>
                    <OPTION value=27>������</OPTION>
                    <OPTION 
              value=32>���Թ���</OPTION>
                    <OPTION value=64>��⢷��</OPTION>
                    <OPTION 
              value=47>ʡŹ��</OPTION>
                    <OPTION 
              value=84>����ɮ��ҹ�</OPTION>
                    <OPTION 
              value=90>ʧ���</OPTION>
                    <OPTION value=91>ʵ��</OPTION>
                    <OPTION 
              value=43>˹ͧ���</OPTION>
                    <OPTION 
              value=39>˹ͧ�������</OPTION>
                    <OPTION 
              value=15>��ҧ�ͧ</OPTION>
                    <OPTION 
              value=61>�ط�¸ҹ�</OPTION>
                    <OPTION 
              value=53>�صôԵ��</OPTION>
                    <OPTION 
              value=37>�ӹҨ��ԭ</OPTION>
                    <OPTION 
              value=41>�شøҹ�</OPTION>
                    <OPTION 
            value=34>�غ��Ҫ�ҹ�</OPTION>
                  </SELECT> &nbsp;㹻ա���֡��&nbsp; <SELECT  name=ayear1>
                    <OPTION value="" 
              selected></OPTION>
                    <OPTION value=2449>2449</OPTION>
                    <OPTION 
              value=2450>2450</OPTION>
                    <OPTION value=2451>2451</OPTION>
                    <OPTION 
              value=2452>2452</OPTION>
                    <OPTION value=2453>2453</OPTION>
                    <OPTION 
              value=2454>2454</OPTION>
                    <OPTION value=2455>2455</OPTION>
                    <OPTION 
              value=2456>2456</OPTION>
                    <OPTION value=2457>2457</OPTION>
                    <OPTION 
              value=2458>2458</OPTION>
                    <OPTION value=2459>2459</OPTION>
                    <OPTION 
              value=2460>2460</OPTION>
                    <OPTION value=2461>2461</OPTION>
                    <OPTION 
              value=2462>2462</OPTION>
                    <OPTION value=2463>2463</OPTION>
                    <OPTION 
              value=2464>2464</OPTION>
                    <OPTION value=2465>2465</OPTION>
                    <OPTION 
              value=2466>2466</OPTION>
                    <OPTION value=2467>2467</OPTION>
                    <OPTION 
              value=2468>2468</OPTION>
                    <OPTION value=2469>2469</OPTION>
                    <OPTION 
              value=2470>2470</OPTION>
                    <OPTION value=2471>2471</OPTION>
                    <OPTION 
              value=2472>2472</OPTION>
                    <OPTION value=2473>2473</OPTION>
                    <OPTION 
              value=2474>2474</OPTION>
                    <OPTION value=2475>2475</OPTION>
                    <OPTION 
              value=2476>2476</OPTION>
                    <OPTION value=2477>2477</OPTION>
                    <OPTION 
              value=2478>2478</OPTION>
                    <OPTION value=2479>2479</OPTION>
                    <OPTION 
              value=2480>2480</OPTION>
                    <OPTION value=2481>2481</OPTION>
                    <OPTION 
              value=2482>2482</OPTION>
                    <OPTION value=2483>2483</OPTION>
                    <OPTION 
              value=2484>2484</OPTION>
                    <OPTION value=2485>2485</OPTION>
                    <OPTION 
              value=2486>2486</OPTION>
                    <OPTION value=2487>2487</OPTION>
                    <OPTION 
              value=2488>2488</OPTION>
                    <OPTION value=2489>2489</OPTION>
                    <OPTION 
              value=2490>2490</OPTION>
                    <OPTION value=2491>2491</OPTION>
                    <OPTION 
              value=2492>2492</OPTION>
                    <OPTION value=2493>2493</OPTION>
                    <OPTION 
              value=2494>2494</OPTION>
                    <OPTION value=2495>2495</OPTION>
                    <OPTION 
              value=2496>2496</OPTION>
                    <OPTION value=2497>2497</OPTION>
                    <OPTION 
              value=2498>2498</OPTION>
                    <OPTION value=2499>2499</OPTION>
                    <OPTION 
              value=2500>2500</OPTION>
                    <OPTION value=2501>2501</OPTION>
                    <OPTION 
              value=2502>2502</OPTION>
                    <OPTION value=2503>2503</OPTION>
                    <OPTION 
              value=2504>2504</OPTION>
                    <OPTION value=2505>2505</OPTION>
                    <OPTION 
              value=2506>2506</OPTION>
                    <OPTION value=2507>2507</OPTION>
                    <OPTION 
              value=2508>2508</OPTION>
                    <OPTION value=2509>2509</OPTION>
                    <OPTION 
              value=2510>2510</OPTION>
                    <OPTION value=2511>2511</OPTION>
                    <OPTION 
              value=2512>2512</OPTION>
                    <OPTION value=2513>2513</OPTION>
                    <OPTION 
              value=2514>2514</OPTION>
                    <OPTION value=2515>2515</OPTION>
                    <OPTION 
              value=2516>2516</OPTION>
                    <OPTION value=2517>2517</OPTION>
                    <OPTION 
              value=2518>2518</OPTION>
                    <OPTION value=2519>2519</OPTION>
                    <OPTION 
              value=2520>2520</OPTION>
                    <OPTION value=2521>2521</OPTION>
                    <OPTION 
              value=2522>2522</OPTION>
                    <OPTION value=2523>2523</OPTION>
                    <OPTION 
              value=2524>2524</OPTION>
                    <OPTION value=2525>2525</OPTION>
                    <OPTION 
              value=2526>2526</OPTION>
                    <OPTION value=2527>2527</OPTION>
                    <OPTION 
              value=2528>2528</OPTION>
                    <OPTION value=2529>2529</OPTION>
                    <OPTION 
              value=2530>2530</OPTION>
                    <OPTION value=2531>2531</OPTION>
                    <OPTION 
              value=2532>2532</OPTION>
                    <OPTION value=2533>2533</OPTION>
                    <OPTION 
              value=2534>2534</OPTION>
                    <OPTION value=2535>2535</OPTION>
                    <OPTION 
              value=2536>2536</OPTION>
                    <OPTION value=2537>2537</OPTION>
                    <OPTION 
              value=2538>2538</OPTION>
                    <OPTION value=2539>2539</OPTION>
                    <OPTION 
              value=2540>2540</OPTION>
                    <OPTION value=2541>2541</OPTION>
                    <OPTION 
              value=2542>2542</OPTION>
                    <OPTION value=2543>2543</OPTION>
                    <OPTION 
              value=2544>2544</OPTION>
                    <OPTION value=2545>2545</OPTION>
                    <OPTION 
              value=2546>2546</OPTION>
                    <OPTION value=2547>2547</OPTION>
                    <OPTION 
              value=2548>2548</OPTION>
                  </SELECT> &nbsp;���Ѻ����дѺ��ṹ���������&nbsp; <INPUT  maxLength=4 size=4 name=gpa1> 
                </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>2.2</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������繹ѡ�֡�ҢͧʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</STRONG> 
                </TD>
              </TR>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT
            name=kmitl  type=radio id=kmitl value="Y " checked> &nbsp;����繹ѡ�֡�ҢͧʶҺѹ�����á </TD>
              </TR>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=kmitl  type=radio value="N"
            name=kmitl> &nbsp;���繹ѡ�֡�ҢͧʶҺѹ� �ҡ�͹ �ա���֡�� 
                  <SELECT 
             name=kmitlyear>
                    <OPTION value="" selected></OPTION>
                    <OPTION 
              value=2449>2449</OPTION>
                    <OPTION value=2450>2450</OPTION>
                    <OPTION 
              value=2451>2451</OPTION>
                    <OPTION value=2452>2452</OPTION>
                    <OPTION 
              value=2453>2453</OPTION>
                    <OPTION value=2454>2454</OPTION>
                    <OPTION 
              value=2455>2455</OPTION>
                    <OPTION value=2456>2456</OPTION>
                    <OPTION 
              value=2457>2457</OPTION>
                    <OPTION value=2458>2458</OPTION>
                    <OPTION 
              value=2459>2459</OPTION>
                    <OPTION value=2460>2460</OPTION>
                    <OPTION 
              value=2461>2461</OPTION>
                    <OPTION value=2462>2462</OPTION>
                    <OPTION 
              value=2463>2463</OPTION>
                    <OPTION value=2464>2464</OPTION>
                    <OPTION 
              value=2465>2465</OPTION>
                    <OPTION value=2466>2466</OPTION>
                    <OPTION 
              value=2467>2467</OPTION>
                    <OPTION value=2468>2468</OPTION>
                    <OPTION 
              value=2469>2469</OPTION>
                    <OPTION value=2470>2470</OPTION>
                    <OPTION 
              value=2471>2471</OPTION>
                    <OPTION value=2472>2472</OPTION>
                    <OPTION 
              value=2473>2473</OPTION>
                    <OPTION value=2474>2474</OPTION>
                    <OPTION 
              value=2475>2475</OPTION>
                    <OPTION value=2476>2476</OPTION>
                    <OPTION 
              value=2477>2477</OPTION>
                    <OPTION value=2478>2478</OPTION>
                    <OPTION 
              value=2479>2479</OPTION>
                    <OPTION value=2480>2480</OPTION>
                    <OPTION 
              value=2481>2481</OPTION>
                    <OPTION value=2482>2482</OPTION>
                    <OPTION 
              value=2483>2483</OPTION>
                    <OPTION value=2484>2484</OPTION>
                    <OPTION 
              value=2485>2485</OPTION>
                    <OPTION value=2486>2486</OPTION>
                    <OPTION 
              value=2487>2487</OPTION>
                    <OPTION value=2488>2488</OPTION>
                    <OPTION 
              value=2489>2489</OPTION>
                    <OPTION value=2490>2490</OPTION>
                    <OPTION 
              value=2491>2491</OPTION>
                    <OPTION value=2492>2492</OPTION>
                    <OPTION 
              value=2493>2493</OPTION>
                    <OPTION value=2494>2494</OPTION>
                    <OPTION 
              value=2495>2495</OPTION>
                    <OPTION value=2496>2496</OPTION>
                    <OPTION 
              value=2497>2497</OPTION>
                    <OPTION value=2498>2498</OPTION>
                    <OPTION 
              value=2499>2499</OPTION>
                    <OPTION value=2500>2500</OPTION>
                    <OPTION 
              value=2501>2501</OPTION>
                    <OPTION value=2502>2502</OPTION>
                    <OPTION 
              value=2503>2503</OPTION>
                    <OPTION value=2504>2504</OPTION>
                    <OPTION 
              value=2505>2505</OPTION>
                    <OPTION value=2506>2506</OPTION>
                    <OPTION 
              value=2507>2507</OPTION>
                    <OPTION value=2508>2508</OPTION>
                    <OPTION 
              value=2509>2509</OPTION>
                    <OPTION value=2510>2510</OPTION>
                    <OPTION 
              value=2511>2511</OPTION>
                    <OPTION value=2512>2512</OPTION>
                    <OPTION 
              value=2513>2513</OPTION>
                    <OPTION value=2514>2514</OPTION>
                    <OPTION 
              value=2515>2515</OPTION>
                    <OPTION value=2516>2516</OPTION>
                    <OPTION 
              value=2517>2517</OPTION>
                    <OPTION value=2518>2518</OPTION>
                    <OPTION 
              value=2519>2519</OPTION>
                    <OPTION value=2520>2520</OPTION>
                    <OPTION 
              value=2521>2521</OPTION>
                    <OPTION value=2522>2522</OPTION>
                    <OPTION 
              value=2523>2523</OPTION>
                    <OPTION value=2524>2524</OPTION>
                    <OPTION 
              value=2525>2525</OPTION>
                    <OPTION value=2526>2526</OPTION>
                    <OPTION 
              value=2527>2527</OPTION>
                    <OPTION value=2528>2528</OPTION>
                    <OPTION 
              value=2529>2529</OPTION>
                    <OPTION value=2530>2530</OPTION>
                    <OPTION 
              value=2531>2531</OPTION>
                    <OPTION value=2532>2532</OPTION>
                    <OPTION 
              value=2533>2533</OPTION>
                    <OPTION value=2534>2534</OPTION>
                    <OPTION 
              value=2535>2535</OPTION>
                    <OPTION value=2536>2536</OPTION>
                    <OPTION 
              value=2537>2537</OPTION>
                    <OPTION value=2538>2538</OPTION>
                    <OPTION 
              value=2539>2539</OPTION>
                    <OPTION value=2540>2540</OPTION>
                    <OPTION 
              value=2541>2541</OPTION>
                    <OPTION value=2542>2542</OPTION>
                    <OPTION 
              value=2543>2543</OPTION>
                    <OPTION value=2544>2544</OPTION>
                    <OPTION 
              value=2545>2545</OPTION>
                    <OPTION value=2546>2546</OPTION>
                    <OPTION 
              value=2547>2547</OPTION>
                    <OPTION value=2548>2548</OPTION>
                  </SELECT> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>2.3</STRONG> 
                  &nbsp;&nbsp;<STRONG>����֡�������Է�����</STRONG></TD>
              </TR>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=univ  type=radio id=univ value="Y" checked> &nbsp;������繹ѡ�֡������Է�����/ʶҺѹ��ҡ�͹</TD>
              </TR>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=univ  type=radio value="N"
            name=univ> &nbsp;���繹ѡ�֡�Ңͧ����Է�����/ʶҺѹ� �ҡ�͹<BR> 
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�кت�������Է�����&nbsp; 
                  <INPUT  maxLength=45 size=45 
            name=ounivname> &nbsp;�ա���֡��&nbsp; <SELECT  
            name=ounivyear>
                    <OPTION value="" selected></OPTION>
                    <OPTION 
              value=2449>2449</OPTION>
                    <OPTION value=2450>2450</OPTION>
                    <OPTION 
              value=2451>2451</OPTION>
                    <OPTION value=2452>2452</OPTION>
                    <OPTION 
              value=2453>2453</OPTION>
                    <OPTION value=2454>2454</OPTION>
                    <OPTION 
              value=2455>2455</OPTION>
                    <OPTION value=2456>2456</OPTION>
                    <OPTION 
              value=2457>2457</OPTION>
                    <OPTION value=2458>2458</OPTION>
                    <OPTION 
              value=2459>2459</OPTION>
                    <OPTION value=2460>2460</OPTION>
                    <OPTION 
              value=2461>2461</OPTION>
                    <OPTION value=2462>2462</OPTION>
                    <OPTION 
              value=2463>2463</OPTION>
                    <OPTION value=2464>2464</OPTION>
                    <OPTION 
              value=2465>2465</OPTION>
                    <OPTION value=2466>2466</OPTION>
                    <OPTION 
              value=2467>2467</OPTION>
                    <OPTION value=2468>2468</OPTION>
                    <OPTION 
              value=2469>2469</OPTION>
                    <OPTION value=2470>2470</OPTION>
                    <OPTION 
              value=2471>2471</OPTION>
                    <OPTION value=2472>2472</OPTION>
                    <OPTION 
              value=2473>2473</OPTION>
                    <OPTION value=2474>2474</OPTION>
                    <OPTION 
              value=2475>2475</OPTION>
                    <OPTION value=2476>2476</OPTION>
                    <OPTION 
              value=2477>2477</OPTION>
                    <OPTION value=2478>2478</OPTION>
                    <OPTION 
              value=2479>2479</OPTION>
                    <OPTION value=2480>2480</OPTION>
                    <OPTION 
              value=2481>2481</OPTION>
                    <OPTION value=2482>2482</OPTION>
                    <OPTION 
              value=2483>2483</OPTION>
                    <OPTION value=2484>2484</OPTION>
                    <OPTION 
              value=2485>2485</OPTION>
                    <OPTION value=2486>2486</OPTION>
                    <OPTION 
              value=2487>2487</OPTION>
                    <OPTION value=2488>2488</OPTION>
                    <OPTION 
              value=2489>2489</OPTION>
                    <OPTION value=2490>2490</OPTION>
                    <OPTION 
              value=2491>2491</OPTION>
                    <OPTION value=2492>2492</OPTION>
                    <OPTION 
              value=2493>2493</OPTION>
                    <OPTION value=2494>2494</OPTION>
                    <OPTION 
              value=2495>2495</OPTION>
                    <OPTION value=2496>2496</OPTION>
                    <OPTION 
              value=2497>2497</OPTION>
                    <OPTION value=2498>2498</OPTION>
                    <OPTION 
              value=2499>2499</OPTION>
                    <OPTION value=2500>2500</OPTION>
                    <OPTION 
              value=2501>2501</OPTION>
                    <OPTION value=2502>2502</OPTION>
                    <OPTION 
              value=2503>2503</OPTION>
                    <OPTION value=2504>2504</OPTION>
                    <OPTION 
              value=2505>2505</OPTION>
                    <OPTION value=2506>2506</OPTION>
                    <OPTION 
              value=2507>2507</OPTION>
                    <OPTION value=2508>2508</OPTION>
                    <OPTION 
              value=2509>2509</OPTION>
                    <OPTION value=2510>2510</OPTION>
                    <OPTION 
              value=2511>2511</OPTION>
                    <OPTION value=2512>2512</OPTION>
                    <OPTION 
              value=2513>2513</OPTION>
                    <OPTION value=2514>2514</OPTION>
                    <OPTION 
              value=2515>2515</OPTION>
                    <OPTION value=2516>2516</OPTION>
                    <OPTION 
              value=2517>2517</OPTION>
                    <OPTION value=2518>2518</OPTION>
                    <OPTION 
              value=2519>2519</OPTION>
                    <OPTION value=2520>2520</OPTION>
                    <OPTION 
              value=2521>2521</OPTION>
                    <OPTION value=2522>2522</OPTION>
                    <OPTION 
              value=2523>2523</OPTION>
                    <OPTION value=2524>2524</OPTION>
                    <OPTION 
              value=2525>2525</OPTION>
                    <OPTION value=2526>2526</OPTION>
                    <OPTION 
              value=2527>2527</OPTION>
                    <OPTION value=2528>2528</OPTION>
                    <OPTION 
              value=2529>2529</OPTION>
                    <OPTION value=2530>2530</OPTION>
                    <OPTION 
              value=2531>2531</OPTION>
                    <OPTION value=2532>2532</OPTION>
                    <OPTION 
              value=2533>2533</OPTION>
                    <OPTION value=2534>2534</OPTION>
                    <OPTION 
              value=2535>2535</OPTION>
                    <OPTION value=2536>2536</OPTION>
                    <OPTION 
              value=2537>2537</OPTION>
                    <OPTION value=2538>2538</OPTION>
                    <OPTION 
              value=2539>2539</OPTION>
                    <OPTION value=2540>2540</OPTION>
                    <OPTION 
              value=2541>2541</OPTION>
                    <OPTION value=2542>2542</OPTION>
                    <OPTION 
              value=2543>2543</OPTION>
                    <OPTION value=2544>2544</OPTION>
                    <OPTION 
              value=2545>2545</OPTION>
                    <OPTION value=2546>2546</OPTION>
                    <OPTION 
              value=2547>2547</OPTION>
                    <OPTION value=2548>2548</OPTION>
                  </SELECT> </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 bgColor=#e8e8e8>&nbsp;<STRONG>�����˵� 
                  :</STRONG>&nbsp; 㹡óշ��ѡ�֡�����繹ѡ�֡������Է�����/ʶҺѹ���� 
                  �ҡ�͹ (����Է����»Դ) ����ѧ����ʶҹ�Ҿ�繹ѡ�֡�Ңͧ����Է����¹������ 
                  ��͹�������Ѻ��§ҹ����繹ѡ�֡�ҢͧʶҺѹ� �ѡ�֡�Ҩе�ͧ���Թ������͡�ҡ����繹ѡ�֡�Ңͧ����Է����¹��� 
                  ���¡�͹ �֧������ö����Ѻ ��§ҹ����繹ѡ�֡�Ңͧ�ҧʶҺѹ� 
                  �� </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 3 ����ѵԺԴ�-��ô� 
                  ��黡��ͧ ��м���ػ���д�ҹ����Թ</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ѵԺԴ�</STRONG>&nbsp;(㹡óշ��Դ�-��ôҶ֧����� 
                  ���ѡ�֡�ҡ�͡��������ҷ���÷�Һ)</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.1</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͺԴ�</STRONG>&nbsp; <INPUT id=f_name 
            maxLength=25 size=24 name=f_name> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                  <INPUT id=f_surname  
            maxLength=25 size=24 name=f_surname> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT name=f_alive  type=radio id=f_alive 
            value="Y" checked>
                  �ժ��Ե���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                  <INPUT id=f_alive  type=radio 
            value="N" name=f_alive>
                  �֧����� &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; <INPUT id=f_age 
            maxLength=2 size=2 name=f_age> &nbsp;�� </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.2</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=f_race type=radio id=radio 
            value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio 
             type=radio value="�չ" name=f_race>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio 
             type=radio value="other" name=f_race>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=14 name=f_race22> 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=f_citizen type=radio id=radio2 
            value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT 
            id=radio2 type=radio value="�չ" name=f_citizen>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio2 
            type=radio value="other" name=f_citizen>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
            maxLength=20 size=14 name=f_citizen22></TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.3</STRONG> 
                  &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT name=f_religion type=radio id=radio3 value="�ط�" checked>
                  �ط� &nbsp;&nbsp;2. 
                  <INPUT id=radio3 type=radio value="���ʵ�"
            name=f_religion>
                  ���ʵ� &nbsp;3. 
                  <INPUT id=radio3 type=radio 
            value="������" name=f_religion>
                  ������ &nbsp;&nbsp;4. 
                  <INPUT id=radio3 
             type=radio value="other" name=f_religion>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=16 name=f_religion22> 
                </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.4</STRONG> 
                  &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                  <INPUT 
            id=id maxLength=13 size=16 name=f_id> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.5</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=10 size=5 name=f_homeno> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT 
            maxLength=2 size=2 name=f_moo> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=16 name=f_soi> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT maxLength=20 size=17 name=f_street> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=20 size=21 name=f_tambon> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT 
            maxLength=20 size=16 name=f_amphur>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="f_province" id="f_province">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=5 size=10 name=f_zipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=15 size=16 name=f_telno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.6</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ�Դ�</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=f_academic type=radio id=academic value=1 checked>
                  ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=academic type=radio value=2 
            name=f_academic>
                  �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=academic type=radio value=3 
            name=f_academic>
                  ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. 
                  <INPUT id=academic type=radio value=4 
            name=f_academic>
                  �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT 
            id=academic type=radio value=5 
            name=f_academic>
                  ͹ػ�ԭ��������º��� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  6. 
                  <INPUT id=academic type=radio value=6 
            name=f_academic>
                  ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=academic type=radio value=7 
            name=f_academic>
                  ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  8. 
                  <INPUT id=academic type=radio value=8 
            name=f_academic>
                  ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  9. 
                  <INPUT id=academic type=radio value=9 
            name=f_academic>
                  ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  10. 
                  <INPUT id=academic type=radio value=10 
            name=f_academic>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=25 
            size=16 name=f_academic2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.7</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ�Դ�</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=f_occupation type=radio id=occupation value=1 checked>
                  �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=occupation type=radio value=2 
            name=f_occupation>
                  ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. 
                  <INPUT id=occupation  
            type=radio value=3 name=f_occupation>
                  ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=occupation type=radio value=4 
            name=f_occupation>
                  ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT id=occupation type=radio value=5 
            name=f_occupation>
                  �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                  <INPUT id=occupation 
            type=radio value=6 name=f_occupation>
                  �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 7. 
                  <INPUT id=occupation type=radio 
            value=7 name=f_occupation>
                  �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8. 
                  <INPUT id=occupation type=radio value=8
            name=f_occupation>
                  ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 9. 
                  <INPUT 
            id=f_occupation type=radio value=9 name=f_occupation>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=25 size=16 
            name=f_occupation2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.8</STRONG> 
                  &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=30 size=24 name=f_workplace>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="f_workprovince" id="f_workprovince">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=5 size=10 name=f_workzipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                  <INPUT maxLength=15 size=16 name=f_worktelno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.9</STRONG> 
                  &nbsp;&nbsp;<STRONG>����������/��͹�ͧ�Դ�</STRONG>&nbsp; 
                  1. 
                  <INPUT name=f_earn type=radio id=earn value="N" checked>
                  ���������� &nbsp;&nbsp; 2. 
                  <INPUT id=earn type=radio value="Y"
            name=f_earn>
                  �� (�к�) �����&nbsp; <INPUT maxLength=7 size=7 name=f_salary2> 
                  &nbsp;�ҷ/��͹ </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 3 ����ѵԺԴ�-��ô� 
                  ��黡��ͧ ��м���ػ���д�ҹ����Թ</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ѵ���ô�</STRONG>&nbsp;(㹡óշ��Դ�-��ôҶ֧����� 
                  ���ѡ�֡�ҡ�͡��������ҷ���÷�Һ)</TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.10</STRONG> 
                  &nbsp;&nbsp;<STRONG>������ô�</STRONG>&nbsp; <INPUT id=name  
            maxLength=25 size=24 name=m_name> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                  <INPUT id=surname  
            maxLength=25 size=24 name=m_surname>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT name=m_alive  type=radio id=alive 
            value="Y" checked>
                  �ժ��Ե���� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 
                  <INPUT id=alive type=radio 
            value="N" name=m_alive>
                  �֧����� &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; <INPUT id=age  
            maxLength=2 size=2 name=m_age> &nbsp;�� </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.11</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=m_race type=radio id=radio4 
            value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio4 
            type=radio value="�չ" name=m_race>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio4 
             type=radio value="other" name=m_race>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=14 name=m_race22> 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> &nbsp;&nbsp; 
                  <INPUT name=m_citizen type=radio 
            id=radio5 value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio5  
            type=radio value="�չ" name=m_citizen>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio5  
            type=radio value="other" name=m_citizen>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
             maxLength=20 size=14 name=m_citizen22></TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.12</STRONG> 
                  &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT name=m_religion  type=radio id=radio6 value="�ط�" checked>
                  �ط� &nbsp;&nbsp;2. 
                  <INPUT id=radio6  type=radio value="���ʵ�"
            name=m_religion>
                  ���ʵ� &nbsp;3. 
                  <INPUT id=radio6 type=radio 
            value="������" name=m_religion>
                  ������ &nbsp;&nbsp;4. 
                  <INPUT id=radio6 
            type=radio value="other"name=m_religion>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=16 name=m_religion22> 
                </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.13</STRONG> 
                  &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                  <INPUT id=id2 maxLength=13 size=16 name=m_id> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.14</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=10 size=5 name=m_homeno> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT  
            maxLength=2 size=2 name=m_moo> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=20 size=16 name=m_soi> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT maxLength=20 size=17 name=m_street> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=20 size=21 name=m_tambon> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT maxLength=20 size=16 name=m_amphur>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="m_province" id="m_province">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=5 size=10 name=m_zipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=15 size=16 name=m_telno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.15</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ��ô�</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=m_academic type=radio id=radio7 value=1 checked>
                  ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=radio7 type=radio value=2 
            name=m_academic>
                  �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=radio7 type=radio value=3 
            name=m_academic>
                  ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. 
                  <INPUT id=radio7  type=radio value=4 
            name=m_academic>
                  �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT 
            id=radio7  type=radio value=5 
            name=m_academic>
                  ͹ػ�ԭ��������º��� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  6. 
                  <INPUT id=radio7  type=radio value=6 
            name=m_academic>
                  ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=radio7  type=radio value=7 
            name=m_academic>
                  ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  8. 
                  <INPUT id=radio7  type=radio value=8 
            name=m_academic>
                  ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  9. 
                  <INPUT id=radio7  type=radio value=9 
            name=m_academic>
                  ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  10. 
                  <INPUT id=radio7  type=radio value=10 
            name=m_academic>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=25 
            size=16 name=m_academic2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.16</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ��ô�</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=m_occupation  type=radio id=radio8 value=1 checked>
                  �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=radio8  type=radio value=2 
            name=m_occupation>
                  ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. 
                  <INPUT id=radio8  
            type=radio value=3 name=m_occupation>
                  ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=radio8  type=radio value=4 
            name=m_occupation>
                  ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT id=radio8  type=radio value=5 
            name=m_occupation>
                  �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                  <INPUT id=radio8 
            type=radio value=6 name=m_occupation>
                  �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 7. 
                  <INPUT id=radio8 type=radio 
            value=7 name=m_occupation>
                  �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8. 
                  <INPUT id=radio8 type=radio value=8 
            name=m_occupation>
                  ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 9. 
                  <INPUT 
            id=radio8 type=radio value=9 name=m_occupation>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=25 size=16 
            name=m_occupation2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.17</STRONG> 
                  &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT maxLength=30 size=24 name=m_workplace>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="m_workprovince" id="m_workprovince">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=5 size=10 name=m_workzipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                  <INPUT maxLength=15 size=16 name=m_worktelno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.18</STRONG> 
                  &nbsp;&nbsp;<STRONG>����������/��͹�ͧ��ô�</STRONG>&nbsp; 
                  1. 
                  <INPUT name=m_earn type=radio id=radio9 value="N" checked>
                  ���������� &nbsp;&nbsp; 2. 
                  <INPUT id=radio9 type=radio value="Y" 
            name=m_earn>
                  �� (�к�) �����&nbsp; <INPUT maxLength=7 size=7 name=m_salary> 
                  &nbsp;�ҷ/��͹ </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD align=left height=10></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 3 ����ѵԺԴ�-��ô� 
                  ��黡��ͧ ��м���ػ���д�ҹ����Թ</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 
          height=24>&nbsp;<STRONG>��黡��ͧ</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.19</STRONG> 
                  &nbsp;&nbsp;<STRONG>��黡��ͧ�ͧ�ѡ�֡��������ҧ����繹ѡ�֡�ҢͧʶҺѹ�</STRONG><BR> 
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=parent_person type=radio id=parent_person value="�Դ�-��ô�" checked >
                  �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT 
            id=parent_person type=radio value="�Դ�" name=parent_person >
                  �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=parent_person type=radio value="��ô�" 
            name=parent_person >
                  ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=parent_person type=radio value="other"  
            name=parent_person >
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  
            maxLength=25 size=25 name=parent_person2 > </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;�óշ���黡��ͧ�ͧ�ѡ�֡�� 
                  <STRONG>����</STRONG>� �Դ�-��ô� ���͵��ͧ (����к���������´��ҹ��ҧ���) 
                </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.20</STRONG> 
                  &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; <INPUT id=name2  
            maxLength=25 size=24 name=p_name> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                  <INPUT id=surname2  
            maxLength=25 size=24 name=p_surname> &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT id=age2  
            maxLength=2 size=2 name=p_age> &nbsp;�� &nbsp;&nbsp;<STRONG>����Ǣ�ͧ�Ѻ�ѡ�֡����</STRONG>&nbsp; 
                  <INPUT 
            id=relationship maxLength=25 size=16 name=p_relationship> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.21</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=p_race type=radio id=radio10 
            value="��" checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio10 
            type=radio value="�չ"  name=p_race>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio10 
            type=radio value="other"  name=p_race>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=14 name=p_race22> 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> &nbsp;&nbsp; 
                  <INPUT name=p_citizen type=radio 
            id=radio11 value="��"  checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio11 
            type=radio value="�չ"  name=p_citizen>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio11  
            type=radio value="other"  name=p_citizen>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
            maxLength=20 size=14 name=p_citizen22></TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.22</STRONG> 
                  &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT name=p_religion type=radio id=radio12 value="�ط�"  checked>
                  �ط� &nbsp;&nbsp;2. 
                  <INPUT id=radio12 type=radio value="���ʵ�"  
            name=p_religion>
                  ���ʵ� &nbsp;3. 
                  <INPUT id=radio12 type=radio 
            value="������"  name=p_religion>
                  ������ &nbsp;&nbsp;4. 
                  <INPUT id=radio12 
            type=radio value="other"  name=p_religion>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT maxLength=20 size=16 name=p_religion22> 
                </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.23</STRONG> 
                  &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                  <INPUT 
            id=id3 maxLength=13 size=16 name=p_id> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.24</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <INPUT 
            maxLength=10 size=5 name=p_homeno> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT  
            maxLength=2 size=2 name=p_moo> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=16 name=p_soi> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT  maxLength=20 size=17 name=p_street> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=20 size=21 name=p_tambon> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT  maxLength=20 size=16 name=p_amphur>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="p_province" id="p_province">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=p_zipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=15 size=16 name=p_telno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.25</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ��黡��ͧ</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=p_academic  type=radio id=radio13 value=1 checked>
                  ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=radio13  type=radio value=2 
            name=p_academic>
                  �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=radio13  type=radio value=3 
            name=p_academic>
                  ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. 
                  <INPUT id=radio13  type=radio value=4 
            name=p_academic>
                  �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT 
            id=radio13  type=radio value=5 
            name=p_academic>
                  ͹ػ�ԭ��������º��� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  6. 
                  <INPUT id=radio13  type=radio value=6 
            name=p_academic>
                  ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=radio13  type=radio value=7 
            name=p_academic>
                  ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  8. 
                  <INPUT id=radio13  type=radio value=8 
            name=p_academic>
                  ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  9. 
                  <INPUT id=radio13  type=radio value=9 
            name=p_academic>
                  ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  10. 
                  <INPUT id=radio13  type=radio value=10 
            name=p_academic>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=25 
            size=16 name=p_academic2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.26</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ��黡��ͧ</STRONG><BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=p_occupation  type=radio id=radio14 value=1 checked>
                  �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=radio14  type=radio value=2 
            name=p_occupation>
                  ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. 
                  <INPUT id=radio14  
            type=radio value=3 name=p_occupation>
                  ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=radio14  type=radio value=4 
            name=p_occupation>
                  ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT id=radio14  type=radio value=5 
            name=p_occupation>
                  �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                  <INPUT id=radio14 
             type=radio value=6 name=p_occupation>
                  �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 7. 
                  <INPUT id=radio14  type=radio 
            value=7 name=p_occupation>
                  �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8. 
                  <INPUT id=radio14  type=radio value=8
            name=p_occupation>
                  ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 9. 
                  <INPUT 
            id=radio14  type=radio value=9 name=p_occupation>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=25 size=16 
            name=p_occupation2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.27</STRONG> 
                  &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=30 size=24 name=p_workplace>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="p_workprovince" id="p_workprovince">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=p_workzipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                  <INPUT  maxLength=15 size=16 name=p_worktelno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.28</STRONG> 
                  &nbsp;&nbsp;<STRONG>����������/��͹�ͧ��黡��ͧ</STRONG>&nbsp; 
                  1. 
                  <INPUT name=p_earn  type=radio id=radio15 value="N" checked>
                  ���������� &nbsp;&nbsp; 2. 
                  <INPUT id=radio15  type=radio value="Y" 
            name=p_earn>
                  �� (�к�) �����&nbsp; <INPUT  maxLength=7 size=7 name=p_salary> 
                  &nbsp;�ҷ/��͹ </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
    <TBODY>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=middle width=750 height=24><STRONG>�͹��� 3 ����ѵԺԴ�-��ô� 
                  ��黡��ͧ ��м���ػ���д�ҹ����Թ</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD align=left width=750 
      height=20>&nbsp;<STRONG>�����Թ�ش˹ع����֡�Ңͧ��ҹ��ҡ</STRONG><BR> 
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          1. 
          <INPUT name=sponsor  type=radio id=sponsor value="�Դ�-��ô�" checked>
          �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
          <INPUT id=sponsor  
      type=radio value="�Դ�" name=sponsor>
          �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          3. 
          <INPUT id=sponsor  type=radio value="��ô�" name=sponsor>
          ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          4. 
          <INPUT id=sponsor  type=radio value="��黡��ͧ" name=sponsor>
          ��黡��ͧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5. 
          <INPUT id=sponsor 
       type=radio value="����ػ����" name=sponsor>
          ����ػ���� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          6. 
          <INPUT id=sponsor  type=radio value="�ҵ�" name=sponsor>
          �ҵ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          7. 
          <INPUT id=sponsor  type=radio value="�ӧҹ" name=sponsor>
          �ӧҹ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          8. 
          <INPUT id=sponsor  type=radio value="�ع����֡��" name=sponsor>
          �ع����֡�� &nbsp;&nbsp;&nbsp;&nbsp; 9. 
          <INPUT id=sponsor  type=radio value="������" 
      name=sponsor>
          ������ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          10. 
          <INPUT id=sponsor  type=radio value="other" name=sponsor>
          ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=32 size=16 name=sponsor2> 
        </TD>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
            <TBODY>
              <TR> 
                <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ػ���д�ҹ����Թ�ͧ�ѡ�֡��</STRONG></TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
            <TBODY>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;�óշ�����ػ���д�ҹ����Թ�ͧ�ѡ�֡��������ҧ����繹ѡ�֡�ҢͧʶҺѹ� 
                  <STRONG>����</STRONG>� �Դ�-��ô� ���ͧ ���ͺؤ�����ǡѺ��黡��ͧ 
                  (����к���������´) </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.29</STRONG> 
                  &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; <INPUT id=name3  
            maxLength=25 size=24 name=o_name> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                  <INPUT id=surname3  
            maxLength=25 size=24 name=o_surname> &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT id=age3  
            maxLength=2 size=2 name=o_age> &nbsp;�� &nbsp;&nbsp;<STRONG>����Ǣ�ͧ�Ѻ�ѡ�֡����</STRONG>&nbsp; 
                  <INPUT 
            id=relationship2  maxLength=25 size=16 name=o_relationship> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.30</STRONG> 
                  &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT name=o_race  type=radio id=radio16 value="��"  checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT 
            id=radio16  type=radio value="�չ"  name=o_race>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio16 
             type=radio value="other"  name=o_race>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=20 size=14 name=o_race22> 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> &nbsp;&nbsp; 
                  <INPUT name=o_citizen  type=radio 
            id=radio17 value="��"  checked>
                  �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio17  
            type=radio value="�չ"  name=o_citizen>
                  �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <INPUT id=radio17  
            type=radio value="other" name=o_citizen>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT 
             maxLength=20 size=14 name=o_citizen22></TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.31</STRONG> 
                  &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                  <INPUT 
            name=o_religion  type=radio id=radio18 value="�ط�" checked>
                  �ط� &nbsp;&nbsp;2. 
                  <INPUT id=radio18  
            type=radio value="���ʵ�" name=o_religion>
                  ���ʵ� &nbsp;3. 
                  <INPUT id=radio18 
             type=radio value="������" name=o_religion>
                  ������ &nbsp;&nbsp;4. 
                  <INPUT id=radio18  type=radio value="other"
            name=o_religion>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=20 
            size=16 name=o_religion22> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.32</STRONG> 
                  &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                  <INPUT 
            id=id4  maxLength=13 size=16 name=o_id> </TD>
              </TR>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.33</STRONG> 
                  &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                  <input  
            maxlength=10 size=5 name=o_homeno> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                  <INPUT  
            maxLength=2 size=2 name=o_moo> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=20 size=16 name=o_soi> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                  <INPUT  maxLength=20 size=17 name=o_street> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=20 size=21 name=o_tambon> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                  <INPUT  maxLength=20 size=16 name=o_amphur>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="o_province" id="o_province">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=o_zipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=15 size=16 name=o_telno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.34</STRONG> 
                  &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ����ػ���д�ҹ����Թ</STRONG><BR> 
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=o_academic  type=radio id=radio19 value=1 checked>
                  ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. 
                  <INPUT id=radio19  type=radio value=2 
            name=o_academic>
                  �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  3. 
                  <INPUT id=radio19  type=radio value=3 
            name=o_academic>
                  ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. 
                  <INPUT id=radio19  type=radio value=4 
            name=o_academic>
                  �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT 
            id=radio19  type=radio value=5 
            name=o_academic>
                  ͹ػ�ԭ��������º��� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  6. 
                  <INPUT id=radio19  type=radio value=6 
            name=o_academic>
                  ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  7. 
                  <INPUT id=radio19  type=radio value=7 
            name=o_academic>
                  ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  8. 
                  <INPUT id=radio19  type=radio value=8 
            name=o_academic>
                  ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  9. 
                  <INPUT id=radio19  type=radio value=9 
            name=o_academic>
                  ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  10. 
                  <INPUT id=radio19  type=radio value=10 
            name=o_academic>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  maxLength=25 
            size=16 name=o_academic2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.35</STRONG> 
                  &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ����ػ���д�ҹ����Թ</STRONG><BR> 
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  1. 
                  <INPUT 
            name=o_occupation  type=radio id=radio20 value=1 checked>
                  �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  2. 
                  <INPUT id=radio20  type=radio value=2 
            name=o_occupation>
                  ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. 
                  <INPUT id=radio20  
            type=radio value=3 name=o_occupation>
                  ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  4. 
                  <INPUT id=radio20  type=radio value=4 
            name=o_occupation>
                  ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  5. 
                  <INPUT id=radio20  type=radio value=5 
            name=o_occupation>
                  �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                  <INPUT id=radio20 
             type=radio value=6 name=o_occupation>
                  �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 7. 
                  <INPUT id=radio20  type=radio 
            value=7 name=o_occupation>
                  �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8. 
                  <INPUT id=radio20  type=radio value=8
            name=o_occupation>
                  ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 9. 
                  <INPUT 
            id=radio20  type=radio value=9
            name=o_occupation>
                  ���� (�к�)&nbsp;:&nbsp; <INPUT  
            maxLength=25 size=16 
            name=o_occupation2> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.36</STRONG> 
                  &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                  <INPUT  maxLength=30 size=24 
            name=o_workplace>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                  <select name="o_workprovince" id="o_workprovince">
                    <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_contact){
																	$chk ="selected";
																	}		
																			
													  ?>
                    <option value="<?=$valueprovince?>" <?=$chk?>> 
                    <?=$province?>
                    </option>
                    <?
															$chk ="";
														}
														?>
                  </select> </TD>
              <TR> 
                <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                  &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                  <INPUT 
             maxLength=5 size=10 name=o_workzipcode> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                  <INPUT  maxLength=15 size=16 
            name=o_worktelno> </TD>
              <TR> 
                <TD align=left width=750 height=20>&nbsp;<STRONG>3.37</STRONG> 
                  &nbsp;&nbsp;<STRONG>����������/��͹�ͧ����ػ���д�ҹ����Թ</STRONG>&nbsp; 
                  1. 
                  <INPUT name=o_earn  type=radio id=radio21 value="N" checked>
                  ���������� &nbsp;&nbsp; 2. 
                  <INPUT id=radio21  type=radio value="Y "
            name=o_earn>
                  �� (�к�) �����&nbsp; <INPUT  maxLength=7 size=7 name=o_salary> 
                  &nbsp;�ҷ/��͹ </TD>
              </TR>
            </TBODY>
          </TABLE></TD>
      </TR>
      <TR> 
        <TD bgColor=#f8f8f8 height=10></TD>
      </TR>
      <TR> 
        <TD align=left height=20>&nbsp; </TD>
      </TR>
      <TR> 
        <TD noWrap align=left><FONT 
color=#ff9900>&nbsp; 
          <input type="submit" name="Submit" value="�׹�ѹ">
          </FONT></TD>
      </TR>
    </TBODY>
  </TABLE>
  <br>
  <br>
</FORM>
</body>
</html>
