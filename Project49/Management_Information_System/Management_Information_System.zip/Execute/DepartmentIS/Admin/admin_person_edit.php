<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        �������к� </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                  <td align="left" valign="top"><img src="../resource/img/icon_required.gif" width="11" height="11">&nbsp;�Ҩ����<br>
                                    <br>
                                    <table 
                              width=745 height="52" border=1 cellpadding=2 cellspacing=0 
                              bordercolor=#c0c0c0  style="BORDER-COLLAPSE: collapse">
                                      <tr bgcolor="#CCCCCC">
                                        <td width="57">����</td>
                                        <td width="120">����</td>
                                        <td width="151">���ʡ��</td>
                                        <td width="154">�������ؤ�ҡ�</td>
                                        <td width="149">ʶҹ�</td>
                                        <td width="76">���</td>
                                      </tr>
                                      <?
									  $scount = 1;
									 $sql ="SELECT person_id, position, prename, th_name, th_surname, type , person_status 
									 FROM person 
									 WHERE type = '0' 
									 OR type = '1' 
									 ORDER BY type 	";
									//print $sql;
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
												while ($row = mysql_fetch_array($table))
												{
														$person_id= $row[0];
														$pos = $row[1];
														$prename = $row[2];														
														$th_name = $row[3];
														$th_surname = $row[4];
														$persontype = $row[5];
														$person_status = $row[6];
									  
									  ?>
                                      <tr bgcolor="#FFFFFF">
                                        <td>&nbsp;
                                            <?=$person_id?>
                                        </td>
                                        <td>&nbsp;
                                         
                                            <?
												if($pos == "") {
													print "�Ҩ���� ";
												}
												else {
													print $pos;
												}
												print $th_name;
											?>
                                        </td>
                                        <td>&nbsp;
                                            <?=$th_surname?>
                                        </td>
                                        <td>&nbsp;
                                            <?
												if($persontype == "0" ) {
													print "��������";
												}
												else {
													print "�Ҩ����";
												}
											
											?>
                                        </td>
                                        <td>&nbsp;
                                            <? 
													if($person_status == "Y") {
													 	print "���Ҩ����ͧ�Ҥ�Ԫ��";
													}
													else {
														print " <font color = 'red' >��������Ҩ����ͧ�Ҥ�Ԫ�� </font>" ;
													}
											?>
                                        </td>
                                        <td><a href ="admin_person_edit1.php?p_id=<?=$person_id?>"><img src="../resource/img/icon_template_edit.gif" width="16" height="16" border="0"> </a> </td>
                                      </tr>
                                      <?
									  ++$scount;
									  }
									  
									  ?>
                                    </table>
                                    <br>
                                    <img src="../resource/img/icon_required.gif" width="11" height="11">&nbsp;���˹�ҷ��<br>
                                    <br>
                                    <table 
                              width=742 height="53" border=1 cellpadding=2 cellspacing=0 
                              bordercolor=#c0c0c0  style="BORDER-COLLAPSE: collapse">
                                      <tr bgcolor="#CCCCCC">
                                        <td width="57">����</td>
                                        <td width="122">����</td>
                                        <td width="152">���ʡ��</td>
                                        <td width="153">�������ؤ�ҡ�</td>
                                        <td width="146">ʶҹ�</td>
                                        <td width="74">���</td>
                                      </tr>
                                      <?
									  $scount = 1;
									 $sql ="SELECT person_id, position, prename, th_name, th_surname, type , person_status 
									 FROM person 
									 WHERE not(type = '0' OR type = '1' )
									 ORDER BY type 	";
									//print $sql;
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
												while ($row = mysql_fetch_array($table))
												{
														$person_id= $row[0];
														$pos = $row[1];
														$prename = $row[2];														
														$th_name = $row[3];
														$th_surname = $row[4];
														$persontype = $row[5];
														$person_status = $row[6];
									  
									  ?>
                                      <tr bgcolor="#FFFFFF">
                                        <td>&nbsp;
                                            <?=$person_id?>
                                        </td>
                                        <td>&nbsp;
                                            <?
												
												print  $prename . $th_name;
											?>
                                        </td>
                                        <td>&nbsp;
                                            <?=$th_surname?>
                                        </td>
                                        <td>&nbsp;
                                            <?
												if($persontype == "2" ) {
													print "���˹�ҷ��෤�Ԥ�";
												}
											 	else if($persontype == "3" ) {
													print "���˹�ҷ���ԡ���Ԫҡ��";
												}
												else if($persontype == "4" ) {
													print "���˹�ҷ���á��";
												}
												else if($persontype == "5" ) {
													print "���˹�ҷ�����Թ";
												}
												else {
													print "�Ҩ����";
												}
											
											?>
                                        </td>
                                        <td>&nbsp;
                                            <? 
													if($person_status == "Y") {
													 	print "�����˹�ҷ���Ҥ�Ԫ��";
													}
													else {
														print " <font color = 'red' >����������˹�ҷ���Ҥ�Ԫ�� </font>" ;
													}
											?>
                                        </td>
                                        <td><a href ="admin_person_edit1.php?p_id=<?=$person_id?>"><img src="../resource/img/icon_template_edit.gif" width="16" height="16" border="0"> </a> </td>
                                      </tr>
                                      <?
									  ++$scount;
									  }
									  
									  ?>
                                    </table>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
