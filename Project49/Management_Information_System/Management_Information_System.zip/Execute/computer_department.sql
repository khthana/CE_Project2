-- phpMyAdmin SQL Dump
-- version 2.9.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 22, 2007 at 03:13 AM
-- Server version: 5.0.24
-- PHP Version: 4.4.4
-- 
-- Database: 'computer_department'
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table 'activity_person'
-- 

CREATE TABLE activity_person (
  activity_id int(11) NOT NULL auto_increment COMMENT 'รหัสของกิจกรรมทางวิชาการ',
  activity_name varchar(100) default NULL COMMENT 'ชื่อกิจกรรมทางวิชาการ',
  activity_place varchar(100) default NULL COMMENT 'สถานที่',
  activity_date date default NULL COMMENT 'วันที่',
  activity_comm varchar(100) default NULL COMMENT 'หมายเหตุ',
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (activity_id),
  KEY person_id (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'activity_person'
-- 

INSERT INTO activity_person VALUES (2, 'กิจกรรมที่1', 'หน่วยงานที่1', '2006-05-31', 'กิจกรรมของรัฐ\r\n', 't0009');
INSERT INTO activity_person VALUES (3, 'กิจกรรมที่2', 'หน่วยงานที่2', '2006-01-15', 'กิจกรรมสถาบัน\r\n', 't0009');

-- --------------------------------------------------------

-- 
-- Table structure for table 'administrator'
-- 

CREATE TABLE administrator (
  id int(11) NOT NULL auto_increment,
  username varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'administrator'
-- 

INSERT INTO administrator VALUES (2, 'root', '0c35c3d3695edbff');

-- --------------------------------------------------------

-- 
-- Table structure for table 'bookborrow'
-- 

CREATE TABLE bookborrow (
  borrowid int(11) NOT NULL auto_increment,
  student_id varchar(8) NOT NULL,
  bookid varchar(5) NOT NULL,
  dborrow date NOT NULL,
  bstatus varchar(1) NOT NULL,
  PRIMARY KEY  (borrowid),
  KEY student_id (student_id),
  KEY bookid (bookid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'bookborrow'
-- 

INSERT INTO bookborrow VALUES (1, '47015323', '00001', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (2, '47015323', '00002', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (3, '47015314', '00003', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (4, '47015314', '00004', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (5, '47015314', '00005', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (6, '48014001', '00006', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (7, '48014001', '00007', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (8, '46012361', '00008', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (9, '46012361', '00009', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (10, '46012361', '00017', '2007-01-26', '1');
INSERT INTO bookborrow VALUES (11, '48013001', '00012', '2007-01-30', '1');
INSERT INTO bookborrow VALUES (12, '47015328', '00010', '2007-02-01', '1');
INSERT INTO bookborrow VALUES (13, '47015328', '00016', '2007-02-01', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table 'books'
-- 

CREATE TABLE books (
  bookid varchar(5) NOT NULL COMMENT 'รหัสหนังสือ',
  bnamethai varchar(100) NOT NULL COMMENT 'ชื่อโครงงานภาษาไทย',
  bnameeng varchar(100) NOT NULL COMMENT 'ชื่อโครงงานภาษาอังกฤษ',
  advisor1 varchar(50) NOT NULL COMMENT 'อ.ที่ปรึกษา1',
  advisor2 varchar(50) default NULL COMMENT 'อ.ที่ปรึกษา2',
  advisor3 varchar(50) default NULL COMMENT 'อ.ที่ปรึกษา3',
  student1 varchar(50) NOT NULL COMMENT 'ชื่อนักศึกษา1',
  studentid1 varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา1',
  email1 varchar(30) default NULL COMMENT 'อีเมลนักศึกษา1',
  student2 varchar(50) default NULL COMMENT 'ชื่อนักศึกษา2',
  studentid2 varchar(8) default NULL COMMENT 'รหัสนักศึกษา2',
  email2 varchar(30) default NULL COMMENT 'อีเมลนักศึกษา2',
  student3 varchar(50) default NULL COMMENT 'ชื่อนักศึกษา3',
  studentid3 varchar(8) default NULL COMMENT 'รหัสนักศึกษา3',
  email3 varchar(30) default NULL COMMENT 'อีเมลนักศึกษา3',
  student4 varchar(50) default NULL COMMENT 'ชื่อนักศึกษา4',
  studentid4 varchar(8) default NULL COMMENT 'รหัสนักศึกษา4',
  email4 varchar(30) default NULL COMMENT 'อีเมลนักศึกษา4',
  bookyear int(11) default NULL COMMENT 'ปีการศึกษา',
  PRIMARY KEY  (bookid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'books'
-- 

INSERT INTO books VALUES ('00001', 'โครงงาน การจำแนกภาพรหัสแท่งแบบสองมิติ', '2D-Barcode Image Recognition', 'ดร. วัชระ ฉัตรวิริยะ', NULL, NULL, 'นายพิภพ   พรยั่งยืน', '46015359', 's6015359@kmilt.ac.th', 'นายสันติพล   ครุธงาม', '46015377', 's6015377@kmilt.ac.th', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO books VALUES ('00002', 'ระบบตรวจตราความปลอดภัยบนโทรศัพท์เคลื่อนที่', 'ACCESS MONITORING SYSTEM ON MOBILE', 'อ. อำนาจ ขาวเน', NULL, NULL, 'นาย กรนิต ปั้นปรีชา', '45010008', 'koranit111@hotmail.com', 'นาย โกเมท ตุลยนิษกะ', '45010071', 'mr_komate@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO books VALUES ('00003', 'ระบบต่อต้านการบุกรุกช่องโหว่ทางซอฟต์แวร์', 'ANTI-EXPLOIT CODE SYSTEM', 'อาจารย์ อัครเดช วัชระภูพงษ์', NULL, NULL, 'กิจชัย รังสิมันต์ไพบูลย์', '45010044', NULL, 'ดนวัต กัณฑ์สุข', '45010260', 'thailandlity@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO books VALUES ('00004', 'การพัฒนาต้นแบบสาขาเสมือนของธนาคารโดยใช้เทคโนโลยี', 'Developing The Prototype Of Virtual Branch Banking Using .NET Technology', 'รศ.ดร.ศุภมิตร จิตตะยโศธร', NULL, NULL, 'ธนาพงษ์ ฉัตรธนุปกรณ์', '46015350', 'thanapong_o@hotmail.com', 'ธวัชชัย บุญศรี', '46015351', 'operand2002@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO books VALUES ('00005', 'การพัฒนากระดานข่าวและโปรแกรมเสริมสำหรับผู้ใช้หลายคน', 'Implementation of online multiuser whiteboard and its plugins', 'ดร.อรัญญา วลัยรัชต์', 'ดร.สมศักดิ์ วลัยรัชต์', NULL, 'ธนา ทัศนาเสถียรกิจ', '45010324', 'thana_jew@hotmail.com', 'นนทสิทธิ์ นครชัย', '45010367', 's5010367@kmitl.ac.th', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO books VALUES ('00006', 'เมาส์สำหรับคนพิการ', 'ASSISTIVE MOUSE FOR THE DISABLE PERSON', 'อ. เกียรติกูล  เจียรนัยธนะกิจ', NULL, NULL, 'เศรษฐา  ฉัตรไชยเดช', '45015384', 'yeekung@hotmail.com', 'ทนงเกียรติ  พาดี', '45015366', 'notting_b@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO books VALUES ('00007', 'รถยนต์ขับเคลื่อนอัตโนมัติ', 'AUTONOMOUS CAR', 'อ.สมเกียรติ วังศิริพิทักษ์', NULL, NULL, 'พชร จิรไพศาลสกุล', '45015376', 'xenigma_machinex@hotmail.com', 'ชัยณรงค์ กรโกษา', '45015361', 'oat_tc11@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO books VALUES ('00008', 'ลายมือชื่อดิจิตอล', 'Digital Signature', 'อ.ธนา หงษ์สุวรรณ', 'อ.อัครเดช วัชระภูพงษ์', NULL, 'กิตติศักดิ์ เตรียมล้ำเลิศ', '44010027', 'benzene_9195@yahoo.com', 'ประภัสสร เยาวรัตน์เควิน', '44010285', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO books VALUES ('00009', 'เครื่องมือพัฒนาเว็บไซต์ส่งเสริมการท่องเที่ยว', 'E-Tourism Web Development Tool', 'อ.ชุติเมษฏ์ ศรีนิลทา', NULL, NULL, 'พิสิทธิ์ โกยสันติสุข', '44010338', 'himmy1983ja@hotmail.com', 'พรภัทร์ ศิริธรรมกุล', '44010319', 'sirithumgul@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO books VALUES ('00010', 'บล็อกวีดีโอเคลื่อนที่', 'MOBILE VIDEO BLOG', 'ผศ.ดร. สุรินทร์ กิตติธรกุล', 'อ.เอนก กอธนสาร', NULL, 'มานพ ไพรศรีสวัสดิ์', '44010377', 'prisrisawat@hotmail.com', 'ชัชพงษ์ มาทอง', '44010433', 'markce2526@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO books VALUES ('00011', 'ระบบให้บริการจัดหางาน', 'Job Search Service System', 'ผศ. อภิเนตร อูนากูล', NULL, NULL, 'มนต์ชัย ภัทรเชาว์นกุล', '43010331', 'mon5e@yahoo.com', 'ศรายุธ  ดำรงเกียรติวณิช', '44015348', 'magician_ch2@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2546);
INSERT INTO books VALUES ('00012', 'ลีนุกส์โพรเซสคลัสเตอร์ริ่ง', 'LINUX PROCESS CLUSTERING', 'ดร.วรวัฒน์ ลิ้มโภคา', 'ดร.ชุติเมษฏ์ ศรีนิลทา', NULL, 'วีรยุทธ องค์สุนทรชัย', '43010406', 'cloud_2499@hotmail.com', 'เศกสวัสดิ์ เอี่ยมสินวัฒนา', '43010441', 'jumpkung@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2546);
INSERT INTO books VALUES ('00013', 'โมบายอินเตอร์เฟส', 'Mobile Interface', 'ดร.วัชระ ฉัตรวิริยะ', NULL, NULL, 'สาธิต วิเชียรพงษ์เจริญ', '44015354', 'xenia545@hotmail.com', 'คชา สมทา', '44015318', 'kacha_somtha@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2546);
INSERT INTO books VALUES ('00014', 'โปรแกรมซีเคียวเชลเซิร์ฟเวอร์สำหรับวินโดวส์', 'Secure Shell Server for Windows', 'อ.ธนา หงษ์สุวรรณ', 'อ.อัครเดช วัชระภูพงษ์', NULL, 'ธนาธิป ยินดี', '43010167', NULL, 'ปิติ จิโรจน์กุล', '43010267', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2546);
INSERT INTO books VALUES ('00015', 'การประยุกต์ใช้ดาต้าไมนิ่งในทางธุรกิจ', 'Data mining application for business', 'รศ.ประทีป บัญญัตินพรัตน์', NULL, NULL, 'ณัฐพงษ์ สววิบูลย์', '43010131', 'noteudom@hotmail.com', 'อินทกะ พิริยะกุล', '43010547', 'intaka@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2546);
INSERT INTO books VALUES ('00016', 'กล้องติดตามวัตถุ', 'Camera System For Tracking A Moving Object', 'อาจารย์สมเกียรติ  วังศิริพิทักษ์', 'อาจารย์สมศักดิ์  วลัยรัชต์', NULL, 'เมธี  บูรณ์จินดา', '43015380', 'metee_tee@hotmail.com', 'มนตรี  อินตาคำ', '43015378', 'ottr@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2545);
INSERT INTO books VALUES ('00017', 'โปรแกรมเล่นไฟล์มีดี้จากการจดจำโน้ตดนตรี', 'MIDI PLAYER FROM NOTE RECOGNITION', 'ดร. อรฉัตร จิตต์โสภักตร์', 'อ. เจริญ วงษ์ชุ่มเย็น', NULL, 'สมภพ อดุลประเสริฐสุข', '42010363', 'phobjang@hotmail.com', 'สรศักดิ์ คงเลิศวิบูลย์', '42010372', 'nu_sor@hotmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 2545);
INSERT INTO books VALUES ('00018', 'ระบบเครือข่ายสำหรับระบบรักษาความปลอดภัยในหมู่บ้าน', 'NETWORK SYSTEM FOR VILLAGE SECURITY SYSTEM', 'รศ.สมศักดิ์ มิตะถา', 'อ.อวัชริน นาชิน', NULL, 'จตุเดช วิวัฒน์สมวงศ์', '42010045', 'aha_olanla@yahoo.com', 'คมสันต์ ประพันธเทวา', '42010041', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2545);
INSERT INTO books VALUES ('00019', 'แหล่งรวมสื่อและข้อมูลดิจิตอลบนเว็บ', 'Digital Collections on the web', 'ดร. วิศิษฏ์ หิรัญกิตติ', NULL, NULL, 'สุรพันธ์ อัสสะรัตน์', '42010401', 'sabsa38@hotmail.com', 'อาทิตย์ สิริอารีย์', '42010441', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2545);
INSERT INTO books VALUES ('00020', 'คลังข้อมูลเชิงวัตถุสัมพันธ์', 'Object - Relational Information Warehouse', 'รศ.ดร.ศุภมิตร   จิตตะยโสธร', NULL, NULL, 'กานต์   ผู้ภักดี', '42010015', NULL, 'หิรัณย์  อโนวรรณพันธ์', '42010417', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2545);

-- --------------------------------------------------------

-- 
-- Table structure for table 'buybill'
-- 

CREATE TABLE buybill (
  buy_num varchar(2) NOT NULL COMMENT 'เลขที่ใบสั่งซื้อ',
  list_id varchar(2) NOT NULL COMMENT 'ลำดับรายการ',
  shop_name varchar(64) NOT NULL COMMENT 'ชื่อร้านค้า',
  date_making date NOT NULL COMMENT 'วันที่ทำใบสั่งซื้อ',
  `condition` varchar(32) NOT NULL COMMENT 'เงื่อนไขการชำระเงิน',
  day_expire date NOT NULL COMMENT 'วันกำหนดส่ง',
  place varchar(32) NOT NULL COMMENT 'สถานที่ส่วของ',
  list varchar(32) NOT NULL COMMENT 'รายการ',
  unit_count varchar(16) NOT NULL COMMENT 'หน่วยนับ',
  amount varchar(6) NOT NULL COMMENT 'จำนวน',
  unit_price double NOT NULL COMMENT 'ราคาหน่วยละ',
  money double NOT NULL COMMENT 'จำนวนเงิน',
  text_money varchar(64) NOT NULL COMMENT 'จำนวนเงิน(ตัวอักษร)',
  `type` varchar(8) NOT NULL COMMENT 'ชนิดของธุรกรรม',
  sheet_num varchar(2) NOT NULL COMMENT 'คู่กับใบรายงานขอซื้อ/จ้างเลขที่',
  PRIMARY KEY  (buy_num,list_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'buybill'
-- 

INSERT INTO buybill VALUES ('3', '1', 'nontakorn group', '2549-02-01', 'ตั้งเบิกใบเสร็จ', '2549-01-01', 'ECC-NETWORK', 'คอมพิวเตอร์', 'เครื่อง', '2', 23000, 49220, 'สี่หมื่นเก้าพันสองร้อยยี่สิบบาท', 'bring', '4');
INSERT INTO buybill VALUES ('2', '1', 'อ่อนนุช จำกัด', '2549-03-01', 'ตั้งเบิกใบเสร็จ', '2549-01-01', 'ECC-NETWORK', 'scaner', 'เครื่อง', '1', 62669, 67055.83, 'หกหมื่นเจ็ดพันห้าสิบห้าบาทถ้วน', 'bring', '3');
INSERT INTO buybill VALUES ('1', '2', 'อ่อนหมากน้อย จำกัด', '2549-02-01', 'ตั้งเบิกใบเสร็จ', '2549-01-01', 'ECC-601', 'scaner2', 'เครื่อง', '2', 5500, 11770, 'หนึ่งหมื่นเก้าพันเจ็ดร้อยเก้าสิบห้าบาทถ้วน', 'bring', '1');
INSERT INTO buybill VALUES ('1', '1', 'อ่อนหมากน้อย จำกัด', '2549-02-01', 'ตั้งเบิกใบเสร็จ', '2549-01-01', 'ECC-601', 'scaner', 'เครื่อง', '3', 2500, 8025, 'หนึ่งหมื่นเก้าพันเจ็ดร้อยเก้าสิบห้าบาทถ้วน', 'bring', '1');
INSERT INTO buybill VALUES ('4', '1', 'นัฐวุฒิคอมพิวเตอร์เซอร์วิส  จำกั', '2550-02-18', 'ตั้งเบิกใบเสร็จ', '2550-02-28', 'ECC-601', 'scaner', 'เครื่อง', '3', 8500, 27285, 'สองหมื่นเจ็ดพันสองร้อยแปดสิบห้าบาทถ้วน', 'bring', '4');
INSERT INTO buybill VALUES ('5', '1', 'พงศธรคอมพิวเตอร์ จำกัด', '2550-02-21', 'ตั้งเบิกใบเสร็จ', '2550-02-28', 'ECC-601', 'คอมพิวเตอร์', 'เครื่อง', '2', 22000, 0, 'สี่หมื่นเจ็ดพันแปดสิบบาทถ้วน', 'clear', '5');
INSERT INTO buybill VALUES ('6', '1', 'อ่อนนุช จำกัด', '2549-01-01', 'เงินสด', '2549-01-01', 'ECC-NETWORK', '', 'เครื่อง', '3', 22000, 70620, 'เจ็ดพันสี่ร้อยเก้าสิบบาทถ้วน', 'bring', '6');

-- --------------------------------------------------------

-- 
-- Table structure for table 'category'
-- 

CREATE TABLE category (
  category_id varchar(2) NOT NULL COMMENT 'รหัสหมวดวิชาโครงสร้างหลักสูตร',
  category varchar(20) NOT NULL,
  struct_id varchar(2) NOT NULL COMMENT 'รหัสโครงสร้างหลักสูตร',
  cprogram_unit1 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตของหมวดวิชาของหลักสูตรของโปรแกรมการศึกษาที่ 1',
  cprogram_unit2 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตของหมวดวิชาของหลักสูตรของโปรแกรมการศึกษาที่ 2',
  PRIMARY KEY  (category_id),
  KEY struct_id (struct_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'category'
-- 

INSERT INTO category VALUES ('1', 'หมวดวิชาศึกษาทั่วไป', '1', 31, 13);
INSERT INTO category VALUES ('2', 'หมวดวิชาเฉพาะ', '1', 101, 88);
INSERT INTO category VALUES ('3', 'หมวดวิชาเลือกเสรี', '1', 9, 6);

-- --------------------------------------------------------

-- 
-- Table structure for table 'clear'
-- 

CREATE TABLE clear (
  clear_num int(2) NOT NULL default '0' COMMENT 'เลขที่ใบคืนเงินยืม',
  list_id varchar(2) NOT NULL COMMENT 'ลำดับรายการ',
  borrower_name varchar(32) NOT NULL COMMENT 'ชื่อผู้ยืม',
  date_borrow date NOT NULL COMMENT 'วันที่ทำสัญญายืมเงิน',
  amount_borrow varchar(8) NOT NULL COMMENT 'จำนวนเงินที่ยืม',
  budget_name varchar(32) NOT NULL COMMENT 'ชื่องบประมาณ',
  shop_name varchar(32) NOT NULL COMMENT 'ชื่อร้านค้า',
  bill_name varchar(8) NOT NULL COMMENT 'ใบเสร็จรับเงินเล่มที่/เลขที่',
  money double NOT NULL COMMENT 'จำนวนเงิน',
  note varchar(32) NOT NULL COMMENT 'หมายเหตุ',
  `type` varchar(8) NOT NULL COMMENT 'ชนิดของธุรกรรม',
  PRIMARY KEY  (clear_num,list_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'clear'
-- 

INSERT INTO clear VALUES (1, '1', 'ดร.  ชุติเมตร     ศรีนิลทา', '2549-01-01', '22400', 'เงินงบประมาณ', 'nontakorn group', 'abc254', 21828, 'ตั้งเบิกเงินงบประมาณ', 'clear');
INSERT INTO clear VALUES (2, '1', '  ธนัญชัย      ตรีภาค', '2550-01-01', '48000', 'เงินงบประมาณ', 'พงศธรคอมพิวเตอร์ จำกัด', 'Kmit2007', 47080, 'ตั้งเบิกเงินงบประมาณ', 'clear');

-- --------------------------------------------------------

-- 
-- Table structure for table 'department'
-- 

CREATE TABLE department (
  dept_id varchar(2) NOT NULL,
  faculty_id varchar(2) NOT NULL,
  dept_thname varchar(80) NOT NULL,
  dept_enname varchar(80) NOT NULL,
  PRIMARY KEY  (faculty_id,dept_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'department'
-- 

INSERT INTO department VALUES ('01', '01', 'วิศวกรรมโทรคมนาคม', 'Telecommunication Engineering');
INSERT INTO department VALUES ('02', '01', 'วิศวกรรมไฟฟ้า', 'Electrical Engineering');
INSERT INTO department VALUES ('03', '01', 'อิเล็กทรอนิกส์', 'Electronics Engineering');
INSERT INTO department VALUES ('04', '01', 'วิศวกรรมระบบควบคุม', 'Control Engineering');
INSERT INTO department VALUES ('05', '01', 'วิศวกรรมคอมพิวเตอร์', 'Computer Engineering');
INSERT INTO department VALUES ('06', '01', 'วิศวกรรมเครื่องกล', 'Machanical Engineering');
INSERT INTO department VALUES ('07', '01', 'วิศวกรรมการวัดคุม', 'Instrumental Engineering');
INSERT INTO department VALUES ('08', '01', 'วิศวกรรมโยธา', 'Civil Engineering');
INSERT INTO department VALUES ('09', '01', 'วิศวกรรมเกษตร', 'Agriculture Engineering');
INSERT INTO department VALUES ('10', '01', 'วิศวกรรมเคมี', 'Chemical Engineering');
INSERT INTO department VALUES ('11', '01', 'วิศวกรรมอาหาร', 'Food Engineering');
INSERT INTO department VALUES ('12', '01', 'วิศวกรรมสารสนเทศ', 'Information Technology Engineering');
INSERT INTO department VALUES ('14', '01', 'วิศวกรรมอุตสาหการ', 'Industrial Engineering');
INSERT INTO department VALUES ('01', '02', 'สถาปัตยกรรม', 'Architecture');
INSERT INTO department VALUES ('02', '02', 'สถาปัตยกรรมภายใน', 'Interior Architecture');
INSERT INTO department VALUES ('03', '02', 'ศิลปอุตสาหกรรม', 'Industrial Design');
INSERT INTO department VALUES ('04', '02', 'นิเทศศิลป์', 'Communication Arts and Design');
INSERT INTO department VALUES ('05', '02', 'วิจิตรศิลป์', 'Fine Arts');
INSERT INTO department VALUES ('06', '02', 'การวางแผนภาคและผังเมือง', 'Urban and Regional Planning');
INSERT INTO department VALUES ('01', '03', 'ครุศาสตร์สถาปัตยกรรม', 'Architectural Education');
INSERT INTO department VALUES ('05', '03', 'ครุศาสตร์อุตสาหกรรม', 'Agricultural Education');
INSERT INTO department VALUES ('11', '03', 'ครุศาสตร์วิศวกรรม', 'Engineering Education');
INSERT INTO department VALUES ('21', '03', 'ครุศาสตร์เกษตร', 'Agricultural Education');
INSERT INTO department VALUES ('31', '03', 'ภาษาและสังคม', 'Languages and Social Science');
INSERT INTO department VALUES ('01', '04', 'บริหารธุรกิจเกษตร', 'Agricultural Business Administration');
INSERT INTO department VALUES ('03', '04', 'วิทยาศาสตร์การประมง', 'Fisheries Science');
INSERT INTO department VALUES ('04', '04', 'พืชสวน', 'Horticulture');
INSERT INTO department VALUES ('05', '04', 'เทคโนโลยีการผลิตพืช', 'Plant Production Technology');
INSERT INTO department VALUES ('06', '04', 'เทคโนโลยีการผลิตสัตว์', 'Animal Production Technology');
INSERT INTO department VALUES ('07', '04', 'เทคนิคเกษตร', 'Agricultural Technique');
INSERT INTO department VALUES ('08', '04', 'ปฐพีวิทยา', 'Soil Science');
INSERT INTO department VALUES ('09', '04', 'เทคโนโลยีการจัดการศัตรูพืช', 'Pest Management Technology');
INSERT INTO department VALUES ('01', '05', 'คณิตศาสตร์และวิทยาการคอมพิวเตอร์', 'Mathematics and Computer Science');
INSERT INTO department VALUES ('02', '05', 'เคมี', 'Chemistry');
INSERT INTO department VALUES ('03', '05', 'ชีววิทยาประยุกต์', 'Applied Biology');
INSERT INTO department VALUES ('04', '05', 'ฟิสิกส์ประยุกต์', 'Applied Physics');
INSERT INTO department VALUES ('05', '05', 'สถิติประยุกต์', 'Applied Statistics');
INSERT INTO department VALUES ('01', '06', 'อุตสาหกรรมเกษตร', 'Agricultural Industry');
INSERT INTO department VALUES ('01', '07', 'เทคโนโลยีสารสนเทศ', 'Information Technology');

-- --------------------------------------------------------

-- 
-- Table structure for table 'edu_person'
-- 

CREATE TABLE edu_person (
  degree char(1) NOT NULL COMMENT 'ระดับ (0 ป.ตรี) (1 ป.โท) (2 ป.เอก)',
  univ_name varchar(50) default NULL COMMENT 'ชื่อสถาบัน',
  country_name varchar(50) default NULL COMMENT 'ชื่อประเทศ',
  year_congrate int(5) default NULL COMMENT 'ปีที่สำเร็จการศึกษา',
  senior_degree varchar(50) default NULL COMMENT 'วุฒิที่ได้รับ',
  knowledge varchar(50) default NULL COMMENT 'วิชาเอก',
  grade float default NULL COMMENT 'คะแนนเฉลี่ย',
  thesis varchar(100) default NULL,
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (degree,person_id),
  KEY person_id (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'edu_person'
-- 

INSERT INTO edu_person VALUES ('0', 'สถานศึกษาปริญญาตรี', 'ปรเทศที่จบปริญญาตรี', 0, 'วุฒิปริญญาตรี', 'วิชาเอกปริญญาตรี', 0, 'ปพ.ปริญญาตรี', 't0009');
INSERT INTO edu_person VALUES ('1', 'สถานศึกษาปริญญาโท', 'ประเทศที่จบปริญญาโท', 0, 'วุฒิปริญญาโท', 'วิชาเอกปริญญาโท', 0, 'วพ.ปริญญาโท', 't0009');
INSERT INTO edu_person VALUES ('2', 'สถานศึกษาปริญญาเอก', 'ประเทศที่จบปริญญาเอก', 0, 'วุฒิปริญญาเอก', 'วิชาเอกปริญญาเอก', 0, 'วพ.ปริญญาเอก', 't0009');

-- --------------------------------------------------------

-- 
-- Table structure for table 'faculty'
-- 

CREATE TABLE faculty (
  faculty_id varchar(2) NOT NULL,
  faculty_thname varchar(80) NOT NULL,
  faculty_enname varchar(80) NOT NULL,
  PRIMARY KEY  (faculty_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'faculty'
-- 

INSERT INTO faculty VALUES ('01', 'วิศวกรรมศาสตร์', 'Engineering');
INSERT INTO faculty VALUES ('02', 'สถาปัตยกรรมศาสตร์', 'Architecture');
INSERT INTO faculty VALUES ('03', 'ครุศาสตร์อุตสาหกรรม', 'Industrial Education');
INSERT INTO faculty VALUES ('04', 'เทคโนโลยีการเกษตร', 'Agricultural Technology');
INSERT INTO faculty VALUES ('05', 'วิทยาศาสตร์', 'Science');
INSERT INTO faculty VALUES ('06', 'อุตสาหกรรมเกษตร', 'Agricultural Technology');
INSERT INTO faculty VALUES ('07', 'เทคโนโลยีสารสนเทศ', 'Information Technology');

-- --------------------------------------------------------

-- 
-- Table structure for table 'groups'
-- 

CREATE TABLE groups (
  gsubject_id varchar(2) NOT NULL,
  gsubject varchar(100) NOT NULL COMMENT 'ชื่อกลุ่มวิชาของหลักสูตร',
  gprogram_unit1 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 1',
  gprogram_unit2 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 2',
  gdetail text NOT NULL COMMENT 'คำอธิบายกลุ่มวิชาของหลักสูตร',
  category_id varchar(2) NOT NULL,
  PRIMARY KEY  (gsubject_id),
  KEY category_id (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'groups'
-- 

INSERT INTO groups VALUES ('1', 'กลุ่มวิชาสังคมศาสตร์', 2, 2, '', '1');
INSERT INTO groups VALUES ('10', 'กลุ่มวิชาเลือกเสรี', 9, 6, '', '3');
INSERT INTO groups VALUES ('2', 'กลุ่มวิชามนุษยศาสตร์', 2, 2, '', '1');
INSERT INTO groups VALUES ('3', 'กลุ่มวิชาภาษา', 6, 6, '', '1');
INSERT INTO groups VALUES ('4', 'กลุ่มวิชาวิทยาศาสตร์', 12, 0, '', '1');
INSERT INTO groups VALUES ('5', 'กลุ่มวิชาคณิตศาสตร์', 9, 3, '', '1');
INSERT INTO groups VALUES ('6', 'กลุ่มวิชาวิศวกรรมพื้นฐาน', 16, 3, '', '2');
INSERT INTO groups VALUES ('7', 'กลุ่มวิชาบังคับ', 49, 49, '', '2');
INSERT INTO groups VALUES ('8', 'กลุ่มวิชาบังคับเลือก', 21, 21, '', '2');
INSERT INTO groups VALUES ('9', 'กลุ่มวิชาเลือกเฉพาะสาขา', 15, 15, '', '2');

-- --------------------------------------------------------

-- 
-- Table structure for table 'important_bill'
-- 

CREATE TABLE important_bill (
  pay_num int(2) NOT NULL COMMENT 'เลขที่ใบสำคัญจ่าย',
  list_id int(2) NOT NULL COMMENT 'ลำดับรายการ',
  st_num int(3) NOT NULL COMMENT 'เลขที่ ศธ.',
  pay_name varchar(32) NOT NULL COMMENT 'ชื่อผู้สั่งจ่าย',
  shop_name varchar(32) NOT NULL COMMENT 'ชื่อร้านค้า',
  bill_id varchar(2) default NULL COMMENT 'ใบเสร็จรับเงินเล่มที่',
  bill_num varchar(6) NOT NULL COMMENT 'ใบเสร็จรับเงินเลขที่',
  money double NOT NULL COMMENT 'จำนวนเงิน',
  note varchar(32) NOT NULL COMMENT 'หมายเหตุ',
  text_money varchar(64) NOT NULL COMMENT 'จำนวนเงิน(ตัวอักษร)',
  PRIMARY KEY  (pay_num,list_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'important_bill'
-- 

INSERT INTO important_bill VALUES (2, 1, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'อ่อนนุช จำกัด', '', '244', 67055.83, 'ตั้งเบิกเงินงบประมาณ', '');
INSERT INTO important_bill VALUES (3, 1, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'nontakorn group', '', 'app243', 49220, 'ตั้งเบิกเงินงบประมาณ', '');
INSERT INTO important_bill VALUES (1, 1, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'อ่อนหมากน้อย จำกัด', '', 'rtytr', 19795, '', '');
INSERT INTO important_bill VALUES (1, 2, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'abc', '', 'deg', 48150, '', '');
INSERT INTO important_bill VALUES (4, 1, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'นัฐวุฒิคอมพิวเตอร์เซอร์วิส  จำกั', '', '1235', 27285, '', '');
INSERT INTO important_bill VALUES (4, 2, 103, 'รศ.  ประทีป     บัญญัตินพรัตน์', 'อ่อนนุช จำกัด', '', 'efg', 70620, '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table 'intro'
-- 

CREATE TABLE intro (
  course_year int(10) NOT NULL COMMENT 'ปีการศึกษา',
  th_name varchar(100) NOT NULL COMMENT 'ชื่อหลักสูตรภาษาไทย',
  en_name varchar(100) NOT NULL COMMENT 'ชื่อหลักสูตรภาษาอังกฤษ',
  th_fname varchar(100) NOT NULL COMMENT 'ชื่อเต็มภาษาไทยของหลักสูตร',
  th_sname varchar(100) NOT NULL COMMENT 'ชื่อย่อภาษาไทยของหลักสูตร',
  en_fname varchar(100) NOT NULL COMMENT 'ชื่อเต็มภาษาอังกฤษของหลักสูตร',
  en_sname varchar(100) NOT NULL COMMENT 'ชื่อย่อภาษาอังกฤษของหลักสูตร',
  accept text COMMENT 'หน่วยงานที่รับผิดชอบ',
  philosophy text COMMENT 'ปรัชญาของหลักสูตร',
  article text COMMENT 'วัตถุประสงค์ของหลักสูตร',
  program text COMMENT 'กำหนดการเปิดสอนของหลักสูตร',
  property text COMMENT 'คุณสมบัติของผู้เข้าศึกษา',
  ctest text COMMENT 'การคัดเลือกผู้เข้าศึกษา',
  csystem text COMMENT 'ระบบการศึกษา',
  ctime text COMMENT 'ระยะเวลาการศึกษา',
  register text COMMENT 'ระบบการลงทะเบียนเรียน',
  `process` text COMMENT 'การวัดผลและการสำเร็จการศึกษา',
  place text COMMENT 'สถานที่',
  tool text COMMENT 'อุปกรณ์',
  PRIMARY KEY  (course_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'intro'
-- 

INSERT INTO intro VALUES (2545, 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมคอมพิวเตอร์ ', 'Curriculum for Bachelor of Engineering Program in Computer', 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมคอมพิวเตอร์) ', 'วศ.บ. (วิศวกรรมคอมพิวเตอร์) ', 'Bachelor of Engineering (Computer Engineering) ', 'B.Eng. (Computer Engineering) ', 'ภาควิชาวิศวกรรมคอมพิวเตอร์ \r\nคณะวิศวกรรมศาสตร์\r\nสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง', 'ในปัจจุบันเป็นที่ทราบกันดีว่า วิศวกร เป็นวิชาชีพหนึ่งที่มีความสำคัญและมีบทบาทในสังคมไทย โดยเฉพาะในยุคที่ประเทศไทยจำเป็นต้องหันมาพึ่งตนเอง โดยการสร้างเทคโนโลยีขึ้นใช้เองภายในประเทศ วิศวกรคอมพิวเตอร์เป็นอาชีพหนึ่งที่มีหน้าที่สร้างสรรค์ และประยุกต์ใช้เทคโนโลยีคอมพิวเตอร์เพื่อความเป็นอยู่ที่ดีขึ้นของคนในสังคม ดังนั้นบุคคลที่สำเร็จการศึกษาเป็นวิศวกรคอมพิวเตอร์ ควรได้รับการฝึกฝนให้มีทั้งความรู้พื้นฐานในสาขา จัดระบบทั้งการคิดและการกระทำ ตลอดจนความคิดสร้างสรรค์ และความรับผิดชอบในวิชาชีพและสังคม ก่อนเข้าสู่การปฏิบัติงานจริง\r\nหลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิศวกรรมคอมพิวเตอร์นี้ได้ออกแบบขึ้นโดยมีเป้าหมายเพื่อสร้างวิศวกรคอมพิวเตอร์ ที่สามารถสำเร็จการศึกษาออกไปทำงานในสาขาต่าง ๆ ได้อย่างมีประสิทธิภาพ ไม่ว่าเป็นทางด้านคอมพิวเตอร์ซอฟต์แวร์ ด้านคอมพิวเตอร์ฮาร์ดแวร์ หรือด้านระบบเครือข่ายคอมพิวเตอร์ โดยหลักสูตรนี้จะให้นักศึกษาได้เรียนรู้ในรายวิชาที่เป็นพื้นฐานของสาขาวิชาต่าง ๆ และรายวิชาที่เป็นพื้นฐานที่     จำเป็นต้องใช้ในการศึกษาต่อในอนาคต นอกจากนั้นหลักสูตรนี้ได้เปิดโอกาสให้นักศึกษาได้เลือกเรียนในสาขาวิชาที่หลากหลายตามต้องการ ไม่ว่าจะเป็นการเรียนรู้ในทางกว้าง หรือการเรียนรู้ที่เจาะลึกเป็นพิเศษในบางสาขา \r\n      นักศึกษาที่สำเร็จการศึกษาจากหลักสูตรนี้ จะมีความรู้ความชำนาญในสาขาคอมพิวเตอร์ ทั้งด้านทฤษฎีและปฏิบัติ เพียงพอต่อการศึกษาในระดับสูงขึ้น และเพียงพอต่อการเข้าสู่ตลาดแรงงานได้อย่างมั่นใจ\r\n', '1.ผลิตบัณฑิตที่มีความรู้พื้นฐานทางคอมพิวเตอร์ทั้งทางทฤษฎีและปฏิบัติสำหรับตลาดแรงงานและพร้อมสำหรับการศึกษาในระดับสูงต่อไป\r\n2.ฝึกหัดและอบรมนักศึกษาในสาขาวิศวกรรมคอมพิวเตอร์ให้เป็นผู้มีวินัย ความคิด และการทำงานอย่างมีระบบ พร้อมด้วยคุณธรรม และจริยธรรมที่เหมาะสม\r\n', 'ปีการศึกษา 2545 เป็นต้นไป', '1.สำเร็จการศึกษาระดับมัธยมศึกษาตอนปลายหรือเทียบเท่าตามที่กระทรวงศึกษาธิการรับรอง\r\n2.สำเร็จการศึกษาประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.) ในสาขาไฟฟ้า อิเล็กทรอนิกส์ โทรคมนาคม คอมพิวเตอร์ หรือเทียบเท่าตามหลักสูตรที่กระทรวงศึกษาธิการรับรองสำหรับหลักสูตรเทียบโอน\r\n ', '1. สำหรับหลักสูตร 4 ปี จะต้องเป็นผู้ผ่านการคัดเลือกตามระเบียบของทบวงมหาวิทยาลัย\r\n2.สำหรับหลักสูตรเทียบโอน จะต้องเป็นผู้ผ่านการคัดเลือกตามระเบียบของคณะวิศวกรรมศาสตร์ สถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการรับนักศึกษาเข้าเรียนในระดับปริญญาตรี\r\n ', '1.ระบบการศึกษาใช้ระบบการศึกษาแบบทวิภาค โดย 1 ปีการศึกษาแบ่งออกเป็น 2 ภาคการศึกษาและใน 1 ภาคการศึกษาปกติมีระยะเวลาการศึกษาไม่น้อยกว่า 15 สัปดาห์\r\n2.การคิดหน่วยกิต\r\n      2.1รายวิชาภาคทฤษฎีที่ใช้เวลาบรรยายหรืออภิปรายปัญหา 1 ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติ หรือไม่น้อยกว่า 15 ชั่วโมงให้มีค่าเท่ากับ 1 หน่วยกิต\r\n2.2 รายวิชาภาคปฏิบัติ ที่ใช้เวลาฝึกหรือทดลอง  2  ถึง  3 ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติ หรือตั้งแต่ 30 ถึง 45 ชั่วโมงให้มีค่าเท่ากับ 1 หน่วยกิต  \r\n2.3 การฝึกงานหรือการฝึกภาคสนาม    ที่ใช้เวลาฝึกหรือทดลอง   3   ถึง   6  ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติตั้งแต่ 45 ถึง 90 ชั่วโมง ให้มีค่าเท่ากับ 1 หน่วยกิต\r\n', '1.สำหรับหลักสูตร 4 ปี ให้ใช้ระยะเวลาการศึกษาอย่างมากไม่เกิน 8 ปีการศึกษา \r\n2.สำหรับหลักสูตรเทียบโอน ให้ใช้ระยะเวลาการศึกษาอย่างมากไม่เกิน 6 ปีการศึกษา ', ' ให้ลงทะเบียนได้ไม่น้อยกว่า 9 หน่วยกิต และไม่เกิน 22 หน่วยกิต ในแต่ละภาคการศึกษาปกติ และไม่เกิน 10 หน่วยกิต สำหรับการศึกษาภาคฤดูร้อน โดยให้เป็นไปตามระเบียบการวัดผลของสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการวัดผลการศึกษาระดับปริญญาตรี \r\n ', 'การวัดผลให้เป็นไปตามระเบียบการวัดผลของสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการวัดผลการศึกษาระดับปริญญาตรี พ.ศ. 2534 ', 'ภาควิชาวิศวกรรมคอมพิวเตอร์\r\nคณะวิศวกรรมศาสตร์\r\nสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง', 'ภาควิชาวิศวกรรมคอมพิวเตอร์ คณะวิศวกรรมศาสตร์ สถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ได้ดำเนินการสอนในระดับปริญญาตรีมาเป็นเวลานานกว่า 15 ปี มีอุปกรณ์สำหรับการเรียน การสอน และห้องปฏิบัติการคอมพิวเตอร์ที่มีความพร้อม โดยภาควิชาฯ มีเครื่องระดับมินิคอมพิวเตอร์ที่ใช้ระบบปฏิบัติการยูนิกซ์ จำนวน 2 เครื่อง มีเครื่องคอมพิวเตอร์แม่ข่ายที่ใช้ระบบปฏิบัติการตระกูลวินโดวส์และตระกูลเน็ตแวร์ จำนวน 4 เครื่อง ภาควิชาฯ ได้ติดตั้งบริการต่าง ๆ สำหรับนักศึกษา อาทิ บริการเว็บเพจ ทั้งเว็บเพจของภาควิชาฯ และเว็บเพจส่วนตัว บริการไฟล์ บริการจดหมายอิเล็กทรอนิกส์ และบริการงานพิมพ์ ซึ่งเครื่องคอมพิวเตอร์แม่ข่ายที่ให้บริการต่าง ๆ เหล่านี้จะช่วยให้อำนวยความสะดวกในการใช้งานของนักศึกษาได้เป็นอย่างดี\r\n       ทางด้านเครื่องคอมพิวเตอร์สำหรับใช้งานทั่วไป ภาควิชาฯ มีเครื่องคอมพิวเตอร์ลูกข่าย จำนวน 140 เครื่อง ทำหน้าที่ให้นักศึกษาทดลองในรายวิชาต่าง ๆ และให้นักศึกษาเข้ามาใช้งานทั่วไป ในช่วงที่ไม่มีการเรียน นอกจากนั้นนักศึกษาภาควิชาฯ ยังสามารถสืบค้นข้อมูลในเครือข่ายอินเตอร์เน็ต โดยสถาบันฯ มีความเร็วในการเชื่อมต่อกับเครือข่ายอินเตอร์เน็ตด้วยความเร็วถึง 4 เมกะบิตต่อวินาที นอกจากนั้นภาควิชาฯ ยังมีห้องปฏิบัติการดิจิตอล ห้องปฏิบัติการเชื่อมต่อด้วยไมโครโพรเซสเซอร์ที่ทันสมัย และห้องปฏิบัติการออกแบบวงจรดิจิตอลโดยใช้เทคโนโลยี FPGA สามารถให้นักศึกษาได้ทำการทดลองทางด้านฮาร์ดแวร์ตั้งแต่ระดับพื้นฐาน จนถึงการออกแบบวงจรดิจิตอลระดับสูง ');

-- --------------------------------------------------------

-- 
-- Table structure for table 'inventory_bring'
-- 

CREATE TABLE inventory_bring (
  bring_num varchar(6) NOT NULL COMMENT 'เลขที่ใบเบิกวัสดุ',
  list_id varchar(2) NOT NULL COMMENT 'ลำดับรายการ',
  making_date date NOT NULL COMMENT 'วันที่ทำใบเบิกวัสดุ',
  bring_name varchar(32) NOT NULL COMMENT 'ชื่อผู้ขอให้เบิกวัสดุ',
  bring_for varchar(64) NOT NULL COMMENT 'เหตุผลที่เบิกวัสดุ',
  receiver_name varchar(32) NOT NULL COMMENT 'ชื่อผู้รับวัสดุแทน',
  date_using date NOT NULL COMMENT 'วันที่ต้องการใช้สิ่งของ',
  list varchar(64) NOT NULL COMMENT 'รายการ',
  amount_bing varchar(16) default NULL COMMENT 'จำนวนที่เบิก',
  amount_pay varchar(16) default NULL COMMENT 'จำนวนที่จ่าย',
  amount_unpay varchar(6) default NULL COMMENT 'จำนวนที่ค้างจ่าย',
  gpsc varchar(8) default NULL COMMENT 'รหัสพัสดุ',
  capital_bath double default NULL COMMENT 'ต้นทุนต่อหน่วย',
  money double NOT NULL COMMENT 'จำนวนเงิน',
  note varchar(20) default NULL COMMENT 'หมายเหตุ',
  text_money varchar(64) NOT NULL COMMENT 'จำนวนเงิน(ตัวอักษร)',
  `type` varchar(8) NOT NULL COMMENT 'ชนิดของธุรกรรม',
  sheet_num varchar(2) NOT NULL COMMENT 'เลขที่ใบรายงานขอซื้อ/จ้าง',
  clear_num varchar(2) NOT NULL COMMENT 'เลขที่ใบคืนเงินยืม',
  pay_num varchar(2) NOT NULL COMMENT 'เลขที่ใบสำคัญจ่าย',
  PRIMARY KEY  (bring_num,list_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='ตารางใบเบิกวัสดุ';

-- 
-- Dumping data for table 'inventory_bring'
-- 

INSERT INTO inventory_bring VALUES ('4', '1', '2550-02-18', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', 'ดร. สมศักดิ์     วลัยรัชต์', '2550-02-28', 'scaner', '3 เครื่อง', '3 เครื่อง', '', '', 0, 27285, 'ตั้งเบิกเงินงบประมาณ', 'สองหมื่นเจ็ดพันสองร้อยแปดสิบห้าบาทถ้วน', 'bring', '4', '-', '4');
INSERT INTO inventory_bring VALUES ('3', '1', '2549-02-01', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้งานในห้องวิจัย', 'ดร. ชุติมตร     ศรีนิลทา', '2549-02-12', 'คอมพิวเตอร์', '2 เครื่อง', '2 เครื่อง', '', '', 0, 49220, 'ตั้งเบิกเงินงบประมาณ', 'สี่หมื่นเก้าพันสองร้อยยี่สิบบาท', 'bring', '4', '-', '3');
INSERT INTO inventory_bring VALUES ('1', '2', '2549-02-01', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', 'ดร. ชุติมตร     ศรีนิลทา', '2549-02-07', 'scaner2', '2 เครื่อง', '2 เครื่อง', '', '', 0, 11770, 'ตั้งเบิกเงินงบประมาณ', 'หนึ่งหมื่นเก้าพันเจ็ดร้อยเก้าสิบห้าบาทถ้วน', 'bring', '1', '-', '1');
INSERT INTO inventory_bring VALUES ('2', '1', '2549-03-01', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้งานในห้องวิจัย', 'ดร. ชุติมตร     ศรีนิลทา', '2549-01-01', 'scaner', '1 เครื่อง', '1 เครื่อง', '', '', 0, 67055.83, 'ตั้งเบิกเงินงบประมาณ', 'หกหมื่นเจ็ดพันห้าสิบห้าบาทถ้วน', 'bring', '3', '-', '2');
INSERT INTO inventory_bring VALUES ('1', '1', '2549-02-01', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', 'ดร. ชุติมตร     ศรีนิลทา', '2549-02-07', 'scaner', '3 เครื่อง', '3 เครื่อง', '', '', 0, 8025, 'ตั้งเบิกเงินงบประมาณ', 'หนึ่งหมื่นเก้าพันเจ็ดร้อยเก้าสิบห้าบาทถ้วน', 'bring', '1', '-', '1');
INSERT INTO inventory_bring VALUES ('5', '1', '2550-02-21', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', 'ดร. สมศักดิ์     วลัยรัชต์', '2550-02-28', 'คอมพิวเตอร์', '2 เครื่อง', '2 เครื่อง', '', '', 0, 47080, 'ตั้งเบิกเงินงบประมาณ', 'สี่หมื่นเจ็ดพันแปดสิบบาทถ้วน', 'clear', '5', '2', '-');
INSERT INTO inventory_bring VALUES ('6', '1', '2549-01-01', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', 'ดร. สมศักดิ์     วลัยรัชต์', '2549-01-01', '', '3 เครื่อง', '3 เครื่อง', '', '', 0, 70620, 'ตั้งเบิกเงินงบประมาณ', 'เจ็ดหมื่นหกร้อยยี่สิบบาทถ้วน', 'bring', '6', '-', '4');

-- --------------------------------------------------------

-- 
-- Table structure for table 'loaning'
-- 

CREATE TABLE loaning (
  borrow_num varchar(2) NOT NULL COMMENT 'เลขที่สัญญาการยืมเงิน',
  day_expire date NOT NULL COMMENT 'วันครบกำหนด',
  borrower_name varchar(32) NOT NULL COMMENT 'ชื่อผู้ยืม',
  `for` varchar(32) NOT NULL COMMENT 'ยื่นต่อ',
  position varchar(20) NOT NULL COMMENT 'ตำแหน่ง',
  `level` varchar(2) default NULL COMMENT 'ระดับ',
  borrow_for varchar(64) NOT NULL COMMENT 'เหตุผลที่ยืม',
  day_making date NOT NULL COMMENT 'วันที่ทำสัญญายืมเงิน',
  text_money varchar(64) NOT NULL COMMENT 'จำนวนเงิน(ตัวอักษร)',
  money double NOT NULL COMMENT 'จำนวนเงิน',
  make_clear double NOT NULL COMMENT 'เงินที่คืนมา',
  fr_money double NOT NULL COMMENT 'คืนด้วยเงินสด',
  `status` tinyint(1) NOT NULL default '0' COMMENT 'สถานะการคืนเงิน',
  clear_num int(11) NOT NULL COMMENT 'เลขที่ใบคืนเงินยืม',
  PRIMARY KEY  (borrow_num)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='ตารางสัญญาการยืมเงิน';

-- 
-- Dumping data for table 'loaning'
-- 

INSERT INTO loaning VALUES ('1', '2549-02-01', 'ดร.  ชุติเมตร     ศรีนิลทา', 'คณบดี คณะวิศวกรรมศาสตร์', 'อาจารย์ (พนักงาน)', '1', 'ในห้องวิจัย ECC-601', '2549-01-01', 'สองหมื่นสองพันสี่ร้อยบาทถ้วน', 22400, 21828, 572, 1, 1);
INSERT INTO loaning VALUES ('2', '2550-02-01', '  ธนัญชัย      ตรีภาค', 'คณบดี คณะวิศวกรรมศาสตร์', 'อาจารย์ (พนักงาน)', '1', 'ในห้องวิจัย ECC-601', '2550-01-01', 'สี่หมื่นแปดพันบาทถ้วน', 48000, 47080, 920, 1, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table 'parent'
-- 

CREATE TABLE parent (
  student_id varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  ptype char(1) NOT NULL COMMENT 'ความสัมพันธ์กับนักศึกษา(0 = บิดา, 1 = มารดา, 2 = ผู้ปกครอง, 3 = ผู้อุปการะด้านการเงิน)',
  relationship varchar(15) default NULL COMMENT 'ความสัมพันธ์',
  name_parent varchar(50) default NULL COMMENT 'ชื่อของผู้ปกครอง',
  surname_parent varchar(50) default NULL COMMENT 'นามสกุลของผู้ปกครอง',
  status_parent varchar(1) default NULL COMMENT 'สถานะของผู้ปกครอง ',
  age_parent int(11) default NULL COMMENT 'อายุของผู้ปกครอง',
  race_parent varchar(50) default NULL COMMENT 'เชื้อชาติของผู้ปกครอง',
  nationality_parent varchar(50) default NULL COMMENT 'สัญชาติของผู้ปกครอง',
  religion_parent varchar(50) default NULL COMMENT 'ศาสนาของผู้ปกครอง ',
  citizenid_parent varchar(13) default NULL COMMENT 'หมายเลขประจำตัวประชาชนของผู้ปกครอง',
  number_parent varchar(10) default NULL COMMENT 'บ้านเลขที่ของผู้ปกครอง',
  group_parent varchar(10) default NULL COMMENT 'หมู่ที่ของผู้ปกครอง',
  lane_parent varchar(50) default NULL COMMENT 'ตรอก/ซอยของผู้ปกครอง',
  road_parent varchar(50) default NULL COMMENT 'ถนนของผู้ปกครอง',
  district_parent varchar(50) default NULL COMMENT 'ตำบล/แขวงของผู้ปกครอง',
  region_parent varchar(50) default NULL COMMENT 'อำเภอ/เขตของผู้ปกครอง',
  province_parent varchar(50) default NULL COMMENT 'จังหวัดของผู้ปกครอง',
  postalcode_parent varchar(10) default NULL COMMENT 'รหัสไปรษณีย์ของผู้ปกครอง',
  tel_parent varchar(15) default NULL COMMENT 'หมายเลขโทรศัพท์ของผู้ปกครอง',
  educational_parent varchar(50) default NULL COMMENT 'วุฒิสูงสุดของผู้ปกครอง',
  work_parent varchar(50) default NULL COMMENT 'อาชีพของผู้ปกครอง',
  workplace_parent varchar(100) default NULL COMMENT 'ชื่อสถานประกอบอาชีพของผู้ปกครอง',
  provincework_parent varchar(50) default NULL COMMENT 'จังหวัดสถานประกอบอาชีพของผู้ปกครอง',
  postalcodework_parent varchar(10) default NULL COMMENT 'รหัสไปรษณีย์สถานประกอบอาชีพของผู้ปกครอง',
  telwork_parent varchar(15) default NULL COMMENT 'โทรศัพท์สถานประกอบอาชีพของผู้ปกครอง',
  salary_parent int(11) default NULL COMMENT 'รายได้เฉลี่ย/เดือนของผู้ปกครอง',
  PRIMARY KEY  (student_id,ptype)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'parent'
-- 

INSERT INTO parent VALUES ('46015001', '0', NULL, 'มนัส', 'รังสรรค์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('46015001', '1', NULL, 'รัชนี', 'รังสรรค์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('46015323', '0', NULL, 'กิตกร', 'วรรณพร', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('46015323', '1', NULL, 'ดวงพร', 'วรรณพร', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('47014001', '0', NULL, 'ชนะ', 'ดวงปทุม', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('47014001', '1', NULL, 'ปราณี', 'ดวงปทุม', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('47014002', '0', NULL, 'วสันต์', 'จันทร์เจริญ', 'Y', 50, 'ไทย', 'ไทย', 'พุทธ', '1527554365635', '337/11-12', '4', NULL, 'ประพัทธ์บำรุง', 'ในเมือง', 'บ้านไผ่', '6', '40110', '0-1493-8739', 'ปริญญาตรี', 'พนักงานหรือลูกจ้างเอกชน', 'บริษัท ซอฟท์สแคว์ จำกัด', '28', '20320', '021536548', 30000);
INSERT INTO parent VALUES ('47014002', '1', NULL, 'ดวงจันทร์', 'จันทร์เจริญ', 'Y', 49, 'ไทย', 'ไทย', 'พุทธ', '2424545324553', '337/11-12', '4', NULL, 'ประพัทธ์บำรุง', 'ในเมือง', 'บ้านไผ่', '6', '40110', '0-1493-8739', 'ปริญญาเอก', 'รับราชการ', 'วิทยาลัยเทคนิคขอนแก่น', '6', '40000', '043125785', 40000);
INSERT INTO parent VALUES ('47014323', '0', NULL, 'สมยศ', 'ไชยวงศ์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('47014323', '1', NULL, 'ศิวาภรณ์', 'ไชยวงศ์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('47015314', '0', NULL, 'ชัยยศ', 'นาคนาวา', 'Y', 58, 'ไทย', 'ไทย', 'อิสลาม', '1004785963211', '12', '10', '-', '-', 'แปดริ้ว', 'เมือง', '8', '20000', '0451245872', 'อนุปริญญาหรือเทียบเท่า', 'รับราชการ', 'ที่ว่าการอำเภอฉะเชิงเทรา', '8', '20000', '038-9856321', 15000);
INSERT INTO parent VALUES ('47015314', '1', NULL, 'อัมพร', 'นาคนาวา', 'Y', 49, 'ไทย', 'ไทย', 'อิสลาม', '1006322354946', '12', '10', NULL, NULL, 'แปดริ้ว', 'เมือง', '8', '20000', '038-4552123', 'อาชีวศึกษา', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บ้าน', '8', '20000', '038-4552123', 10000);
INSERT INTO parent VALUES ('47015323', '0', NULL, 'สุพจน์', 'แสนหอม', 'Y', 56, 'อิตาเลี่ยน', 'ไทย', 'พุทธ', '2563210255555', '69/1', '11', '11', 'สุขาภิบาล1', 'บางกระปิ', 'บางกะปิ', '1', '10630', '02-9654123', 'ปริญญาตรี', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บ้าน', '1', '10630', '02-9654123', 25000);
INSERT INTO parent VALUES ('47015323', '1', NULL, 'สมพร', 'แสนหอม', 'Y', 48, 'ไทย', 'ไทย', 'พุทธ', '1005236245896', '69/1', '11', '11', 'สุขาภิบาล1', 'บางกะปิ', 'บางกะปิ', '1', '10630', '02-9654123', 'อาชีวศึกษา', 'พนักงานหรือลูกจ้างเอกชน', 'บริษัททรูคอปอเรชั่น', '1', '10450', '02-8547123', 9000);
INSERT INTO parent VALUES ('47015323', '2', 'ลุง', 'ประจักษ์', 'รัตนวิภาค', NULL, 60, 'ไทย', 'ไทย', 'พุทธ', '9876543211123', '12', '1', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '024587562', 'ปริญญาเอก', 'รับราชการ', 'มหาวิทยาลัยมหิดล', '1', '10200', '0864523521', 80000);
INSERT INTO parent VALUES ('47015323', '3', 'น้า', 'บรรจง', 'วิกายภาค', NULL, 55, 'จีน', 'จีน', 'อิสลาม', '6548952154312', '22/5', '10', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '0875123412', 'ปริญญาเอก', 'พนักงานรัฐวิสาหกิจ', 'การไฟฟ้าฝ่ายผลิต', '76', '50400', '0813564856', 100000);
INSERT INTO parent VALUES ('47015328', '0', NULL, 'สุวิทย์', 'ศรีเบญจลักษณ์', 'Y', 56, 'ไทย', 'ไทย', 'พุทธ', '2345234523452', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 'มัธยมศึกษา', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บริษัทกรุงชลการค้า', '9', '20200', '038-987987', 50000);
INSERT INTO parent VALUES ('47015328', '1', NULL, 'บุญส่ง', 'ศรีเบญจลักษณ์', 'Y', 48, 'ไทย', 'ไทย', 'พุทธ', '4351523456262', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 'มัธยมศึกษา', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บริษัทกรุงชลการค้า', '9', '20200', '038-987987', 20000);
INSERT INTO parent VALUES ('48014001', '0', NULL, 'ประภาส', 'กิตติรัตน์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('48014001', '1', NULL, 'จริงใจ', 'กิตติรัตน์', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('48014323', '0', NULL, 'วุฒิชัย', 'เจริญไชย', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('48014323', '1', NULL, 'รัตธิตา', 'เจริญไชย', 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO parent VALUES ('48015001', '0', NULL, 'สุพจน์', 'อนุรัตนวงศ์', 'Y', 55, 'ไทย', 'ไทย', 'พุทธ', '1023000405666', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', '0813748574', 'ปริญญาโท', 'รับราชการ', 'มหาวิทยาลัยเชียงใหม่', '13', '50500', '-', 27500);
INSERT INTO parent VALUES ('48015001', '1', NULL, 'อโนทัย', 'อนุรัตนวงศ์', 'Y', 44, 'ไทย', 'ไทย', 'พุทธ', '1087600054687', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', '0867656787', 'ปริญญาตรี', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'ที่บ้าน', '13', NULL, NULL, 15000);
INSERT INTO parent VALUES ('48015323', '0', NULL, 'วินัย', 'รัตนามณี', 'Y', 50, 'จีน', 'จีน', 'คริสต์', '1527554365635', '10', '10', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '024563225', 'ปริญญาเอก', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'มหาวิทยาลัยกรุงเทพฯ', '1', '15000', '02555666', 100000);
INSERT INTO parent VALUES ('48015323', '1', NULL, 'จินดามณี', 'รัตนามณี', 'Y', 49, 'ไทย', 'ไทย', 'พุทธ', '2424545324553', '1', '1', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '023514652', 'ปริญญาเอก', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'มหาวิทยาลัยศรีปทุม', '1', '10500', '02458736', 150000);
INSERT INTO parent VALUES ('49015001', '0', NULL, 'สมชาย', 'สมวงศ์', 'Y', 52, 'ไทย', 'ไทย', 'คริสต์', '1003232525252', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', '65000', '0894543678', 'ปริญญาตรี', 'พนักงานรัฐวิสาหกิจ', 'การไฟฟ้าส่วนภูมิภาค', '38', '65000', '-', 17500);
INSERT INTO parent VALUES ('49015001', '1', NULL, 'วาสนา', 'สมวงศ์', 'Y', 45, 'ไทย', 'ไทย', 'พุทธ', '1008767689968', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', '65000', NULL, 'อนุปริญญาหรือเทียบเท่า', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', '-', NULL, NULL, NULL, 9000);
INSERT INTO parent VALUES ('49015323', '0', NULL, 'บรรจง', 'รุ่งเรือง', 'Y', 43, 'ไทย', 'ไทย', 'พุทธ', '1578978678675', '44', '4', 'สุขุมวิท12', 'สุขุมวิท', 'บางละมุง', 'พัทยา', '9', '20320', '0245624588', 'ประถมศึกษา', 'รับจ้าง', 'บ้าน', '9', '20320', '02555666', 4500);
INSERT INTO parent VALUES ('49015323', '1', NULL, 'มณีลักษ์', 'รุ่งเรือง', 'Y', 43, 'ไทย', 'ไทย', 'คริสต์', '2424545324553', '44', '4', 'สุขุมวิท12', 'สุขุมวิท', 'บางละมุง', 'พัทยา', '9', '20320', '0245624588', 'มัธยมศึกษา', 'ไม่ประกอบอาชีพ', NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table 'performance_person'
-- 

CREATE TABLE performance_person (
  performance_id int(11) NOT NULL auto_increment COMMENT 'รหัสของผลงานทางวิชาการ',
  performance_name varchar(100) default NULL COMMENT 'ชื่อผลงานทางวิชาการ',
  performance_place varchar(100) default NULL COMMENT 'สถานที่',
  performance_country varchar(100) default NULL COMMENT 'ประเทศ',
  performance_date date default NULL COMMENT 'วันที่',
  performance_comm varchar(100) default NULL COMMENT 'หมายเหตุ',
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (performance_id),
  KEY person_id (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'performance_person'
-- 

INSERT INTO performance_person VALUES (2, 'ผลงานที่1', 'สถานที่1', 'ประเทศ1', '2005-08-23', 'ระดับสากล\r\n', 't0009');
INSERT INTO performance_person VALUES (3, 'ผลงานที่2', 'สถานที่2', 'ประเทศ', '2005-02-01', 'ระดับเอเชีย\r\n', 't0009');

-- --------------------------------------------------------

-- 
-- Table structure for table 'person'
-- 

CREATE TABLE person (
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  gender varchar(10) NOT NULL COMMENT 'เพศ',
  position varchar(10) default NULL COMMENT 'ตำแหน่งทางวิชาการ',
  `level` varchar(10) default NULL COMMENT 'ระดับทางวิชาการ',
  prename varchar(15) default NULL COMMENT 'คำนำหน้าชื่อ',
  th_name varchar(50) NOT NULL COMMENT 'ชื่อภาษาไทย',
  th_surname varchar(50) NOT NULL COMMENT 'นามสกุลภาษาไทย',
  en_name varchar(30) default NULL COMMENT 'ชื่อภาษาอังกฤษ',
  en_surname varchar(30) default NULL COMMENT 'นามสกุลภาษาอังกฤษ',
  `type` varchar(1) NOT NULL COMMENT 'ประเภทบุคลากร (0=ผู้บริหาร)',
  citizenid varchar(13) default NULL COMMENT 'รหัสประจำตัวประชาชน',
  telephone varchar(20) default NULL COMMENT 'เบอร์โทรศัพท์ภายใน',
  mobile varchar(10) default NULL COMMENT 'เบอร์โทรศัพท์มือถือ',
  email varchar(30) default NULL COMMENT 'อีเมล',
  username varchar(20) default NULL COMMENT 'ชื่อล็อกอิน',
  `password` varchar(20) default NULL COMMENT 'รหัสล็อกอิน',
  number1 varchar(10) default NULL COMMENT 'บ้านเลขที่',
  group1 varchar(5) default NULL COMMENT 'หมู่ที่',
  lane1 varchar(50) default NULL COMMENT 'ตรอก/ซอย',
  road1 varchar(50) default NULL COMMENT 'ถนน',
  district1 varchar(50) default NULL COMMENT 'ตำบล/แขวง',
  region1 varchar(50) default NULL COMMENT 'อำเภอ',
  province1 varchar(2) default NULL COMMENT 'จังหวัด',
  postalcode1 varchar(5) default NULL COMMENT 'รหัสไปรษณีย์',
  telephone1 varchar(10) default NULL COMMENT 'โทรศัพท์',
  number2 varchar(10) default NULL COMMENT 'บ้านเลขที่',
  group2 varchar(5) default NULL COMMENT 'หมู่ที่',
  lane2 varchar(50) default NULL COMMENT 'ตรอก/ซอย',
  road2 varchar(50) default NULL COMMENT 'ถนน',
  district2 varchar(50) default NULL COMMENT 'ตำบล/แขวง',
  region2 varchar(50) default NULL COMMENT 'อำเภอ',
  province2 varchar(2) default NULL COMMENT 'จังหวัด',
  postalcode2 varchar(5) default NULL COMMENT 'รหัสไปรษณีย์',
  telephone2 varchar(10) default NULL COMMENT 'โทรศัพท์',
  father_name varchar(20) default NULL COMMENT 'ชื่อของบิดา',
  father_sname varchar(30) default NULL COMMENT 'นามสกุลของบิดา',
  father_age int(11) default NULL COMMENT 'อายุของบิดา',
  father_work varchar(50) default NULL COMMENT 'อาชีพของบิดา',
  father_nationality varchar(20) default NULL COMMENT 'สัญชาติของบิดา',
  father_workplace varchar(50) default NULL COMMENT 'สถานที่ทำงานของบิดา',
  father_phone varchar(10) default NULL COMMENT 'โทรศัพท์ของบิดา',
  mother_name varchar(20) default NULL COMMENT 'ชื่อของมารดา',
  mother_sname varchar(30) default NULL COMMENT 'นามสกุลของมารดา ',
  mother_age int(3) default NULL COMMENT 'อายุของมารดา',
  mother_work varchar(50) default NULL COMMENT 'อาชีพของมารดา',
  mother_nationality varchar(20) default NULL COMMENT 'สัญชาติของมารดา',
  mother_workplace varchar(50) default NULL COMMENT 'สถานที่ทำงานของมารดา',
  mother_phone varchar(10) default NULL COMMENT 'โทรศัพท์ของมารดา',
  person_status varchar(1) default NULL COMMENT 'สถานะยังเป็นอาจารย์',
  PRIMARY KEY  (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'person'
-- 

INSERT INTO person VALUES ('t0000', 'ชาย', NULL, NULL, 'นาย', 'ทดสอบ', 'ทดสอบ', NULL, NULL, '1', '12345678', NULL, '0876005496', 'ktosoap@kmitl.ac.th', 't0000', '5b552b055cd5c08a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'N');
INSERT INTO person VALUES ('t0001', 'ชาย', 'รศ.', NULL, 'นาย', 'ประทีป', 'บัญญัตินพรัตน์', NULL, NULL, '0', NULL, NULL, '0816371055', 'kbprathe@kmitl.ac.th', 't0001', '5b552a155cd5c19a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0002', 'ชาย', 'ดร.', NULL, 'นาย', 'สมศักดิ์', 'วลัยรัชต์', NULL, NULL, '6', '1234567891011', NULL, '0852416325', 'kwsomsak@kmitl.ac.th', 't0002', '5b5529255cd5beaa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0003', 'ชาย', 'รศ.ดร.', NULL, 'นาย', 'ครรชิต', 'ไมตรี', NULL, NULL, '1', NULL, NULL, '0843254789', 'kmkanchit@kmitl.ac.th', 't0003', '5b5528355cd5bfba', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0004', 'ชาย', 'รศ.ดร.', NULL, 'นาย', 'เอื้อน', 'ปิ่นเงิน', NULL, NULL, '1', NULL, NULL, '0874569321', 'kpouen@kmitl.ac.th', 't0004', '5b552f455cd5bcca', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0005', 'ชาย', 'รศ.ดร.', NULL, 'นาย', 'ศุภมิตร', ' จิตตะยโศธร', NULL, NULL, '1', NULL, NULL, '0896547521', 'suphamit@kmitl.ac.th', 't0005', '5b552e555cd5bdda', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0006', 'ชาย', 'รศ.ดร.', NULL, 'นาย', 'บุญวัฒน์', 'อัตชู', NULL, NULL, '1', NULL, NULL, '0832159874', 'boonwat@kmitl.ac.th', 't0006', '5b552d655cd5baea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0007', 'ชาย', 'รศ.ดร.', NULL, 'นาย', 'บุญธีร์', 'เครือตราชู', NULL, NULL, '1', NULL, NULL, '0856547899', 'kkboonte@kmitl.ac.th', 't0007', '5b552c755cd5bbfa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0008', 'ชาย', 'รศ.', NULL, 'นาย', 'สมศักดิ์', 'มิตะถา', NULL, NULL, '1', NULL, NULL, '0866552211', 'kmsomsak@kmitl.ac.th', 't0008', '5b5553855cd5e90a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0009', 'ชาย', 'ผศ.ดร.', NULL, 'นาย', 'สุรินทร์', 'กิตติธรกุล', 'SURIN', 'KITTITORNKUL', '1', '1075421365213', '0-2739-240', '0892222224', 'kksurin@kmitl.ac.th', 't0009', '5b5552955cd5ea1a', '111', '2', 'ซอย01', 'ถนน01', 'แขวง01', 'เขต01', '1', '11120', '089-222222', '111', '2', 'ซอย01', 'ถนน01', 'แขวง01', 'เขต01', '1', '11120', '089-222222', 'ชื่อบิดา01', 'นามสกุลบิดา', 60, 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'ไทย', 'สถานที่ทำงานบิดา', '081-222222', 'ชื่อมารดา01', 'นามสกุลมารดา', 57, 'รับราชการ', 'ไทย', 'สถานที่ทำงานมารดา', '081-111111', 'Y');
INSERT INTO person VALUES ('t0010', 'ชาย', 'ผศ.ดร.', NULL, 'นาย', 'ศักดิ์ชัย', 'ทิพย์จักษุรัตน์', NULL, NULL, '1', NULL, NULL, '0812362456', 'ktsakcha@kmitl.ac.th', 't0010', '5b520dd55ccf7c3a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0011', 'ชาย', 'ผศ.ดร.', NULL, 'นาย', 'วิศิษฎ์', 'หิรัญกิตติ', NULL, NULL, '1', NULL, NULL, '0863254178', 'visit@ce.kmitl.ac.th', 't0011', '5b520c845ccf7ce9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0012', 'ชาย', 'ผศ.ดร.', NULL, 'นาง', 'อรฉัตร', 'จิตต์โสภักตร์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0012', '5b5233775ccf69dc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0013', 'ชาย', 'ผศ.', NULL, 'นาง', 'กฤตวัน', 'ศิริบูรณ์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0013', '5b5232265ccf6a8b', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0014', 'ชาย', 'ผศ.', NULL, 'นาย', 'ธนา', 'หงษ์สุวรรณ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0014', '5b5231115ccf6776', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0015', 'ชาย', 'ผศ.', NULL, 'นาย', 'อภิเนตร', 'อูนากูล', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0015', '5b5237c05ccf6625', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0016', 'ชาย', 'ผศ.', NULL, 'นาย', 'เกียรติกูล', 'เจียรนัยธนะกิจ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0016', '5b5236b35ccf6718', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0017', 'ชาย', 'ผศ.', NULL, 'นาย', 'สมเกียรติ', 'วังศิริพิทักษ์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0017', '5b5235625ccf63c7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0018', 'ชาย', 'ดร.', NULL, 'นาย', 'วรวัฒน์', 'ลิ้มโภคา', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0018', '5b52345d5ccf64c2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0019', 'ชาย', 'ดร.', NULL, 'นาย', 'วัชระ', 'ฉัตรวิริยะ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0019', '5b523b0c5ccf7171', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0020', 'ชาย', 'ดร.', NULL, 'นาง', 'อรัญญา', 'วลัยรัชต์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0020', '5b4af4a55cd4bdea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0021', 'ชาย', 'ดร.', NULL, 'นางสาว', 'ชุติเมษฎ์', 'ศรีนิลทา', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0021', '5b4af5b75cd4bcfc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0022', 'ชาย', 'ดร.', NULL, 'นาย', 'ปกรณ์', 'วัฒนจตุรพร', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0022', '5b4af6415cd4bf86', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0023', 'ชาย', NULL, NULL, 'นาย', 'ประสาร', 'ดังติสานนท์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0023', '5b4af7535cd4be98', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0024', 'ชาย', NULL, NULL, 'นาย', 'วิบูลย์', 'พร้อมพานิชย์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0024', '5b4af06d5cd4c1b2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0025', 'ชาย', NULL, NULL, 'นาย', 'คณัฐ', 'ตังสินานนท์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0025', '5b4af17f5cd4c0c4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0026', 'ชาย', NULL, NULL, 'นาย', 'บัณฑิต', 'พัสยา', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0026', '5b4af2095cd4c34e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0027', 'ชาย', NULL, NULL, 'นาย', 'อัครเดช', 'วัชระภูพงษ์', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0027', '5b4af31b5cd4c260', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0028', 'ชาย', NULL, NULL, 'นาย', 'เจริญ', 'วงษ์ชุ่มเย็น', NULL, NULL, '1', '6546568678675', NULL, NULL, NULL, 't0028', '5b4b0c355cd5557a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0029', 'ชาย', NULL, NULL, 'นาย', 'อำนาจ', 'ขาวเน', NULL, NULL, '1', '6546568678675', NULL, NULL, NULL, 't0029', '5b4b0ec75cd5580c', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0030', 'ชาย', NULL, NULL, 'นาย', 'วัจนพงศ์', 'เกษมศิริ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0030', '5b4bd3355cd5035a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0031', 'ชาย', NULL, NULL, 'นาย', 'ธนัญชัย', ' ตรีภาค', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0031', '5b4bd2665cd5048b', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0032', 'ชาย', NULL, NULL, 'นาย', 'เกียรติณรงค์', 'ทองประเสริฐ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0032', '5b4bed535cd4d578', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0033', 'ชาย', NULL, NULL, 'นาย', 'สุภกิจ', 'นุตยะสกุล', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0033', '5b4bef8c5cd4d7b1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0034', 'ชาย', NULL, NULL, 'นาย', 'เอนก', 'กอธนสาร', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0034', '5b4beef95cd4d91e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0035', 'ชาย', NULL, NULL, 'นาย', 'เอกพล', 'อนันตพรกิจ', NULL, NULL, '1', NULL, NULL, NULL, NULL, 't0035', '5b4be92a5cd4d94f', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0037', 'หญิง', NULL, NULL, 'นาง', 'ฉวีวรรณ', 'มงคลลาภกิจ', NULL, NULL, '4', NULL, NULL, NULL, 'kmchawee@kmitl.ac.th', 't0037', '5b4beb505cd4db75', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0038', 'หญิง', NULL, NULL, 'นาง', 'กนกทิพย์', 'มิตะถา', NULL, NULL, '5', NULL, '027895624-', NULL, 'kmkanokt@kmitl.ac.th', 't0038', '5b4be58d5cd4cdb2', '128', '10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0039', 'ชาย', NULL, NULL, 'นาย', 'อมต', 'หลวงพล', 'AMATA', 'HLUNGPOL', '2', '2145236985214', '027895624-', '0861254622', 'lotus2475@hotmail.com', 't0039', '5b4be4fe5cd4cf23', '13', '3', 'อ่อนนุช1', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '0245624588', '13', '3', 'อ่อนนุช1', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '0245624588', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0040', 'หญิง', NULL, NULL, 'นางสาว', 'ศิวพร', 'ทรัพย์เจริญไชย', 'SIWAPORN', 'SUBCHARUNCHAI', '3', '9876421846464', '02-7373000', '0121445222', 'ae_s@hotmail.com', 't0040', '5b48b6455cd4c14a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0041', 'ชาย', NULL, NULL, 'นาย', 'สุรชัย', 'ตันศิริ', NULL, NULL, '2', NULL, NULL, NULL, NULL, 't0041', '5b48b7515cd4c056', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0043', 'ชาย', NULL, NULL, 'นาย', 'นนทวัฒน์', 'ไชยคำ', NULL, NULL, '2', NULL, NULL, NULL, NULL, 't0043', '5b48b5795cd4be7e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0044', 'ชาย', NULL, NULL, 'นาย', 'ภาคินัย', 'ลครราช', NULL, NULL, '2', NULL, NULL, NULL, NULL, 't0044', '5b48b3955cd4c49a', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t0046', 'ชาย', NULL, NULL, 'นาย', 'ภัทรชัย', 'แซ่ตั้ง', NULL, NULL, '2', NULL, NULL, NULL, NULL, 't0046', '5b48b1bd5cd4c2c2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Y');
INSERT INTO person VALUES ('t9999', 'ชาย', NULL, NULL, 'ว่าที่ร้อยตรี', 'นิรุต', 'วรวัฒน์', NULL, NULL, '3', '5896532458562', NULL, NULL, NULL, 't9999', '6fb3449630a33d32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'N');

-- --------------------------------------------------------

-- 
-- Table structure for table 'plan'
-- 

CREATE TABLE plan (
  plan_id varchar(1) NOT NULL COMMENT 'รหัสของโปรแกรมการศึกษา',
  plan_name varchar(50) NOT NULL COMMENT 'ชื่อโปรแกรมการศึกษา',
  PRIMARY KEY  (plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'plan'
-- 

INSERT INTO plan VALUES ('1', 'โปรแกรมการศึกษาที่ 1 (หลักสูตร 4 ปี)');
INSERT INTO plan VALUES ('2', 'โปรแกรมการศึกษาที่ 2 (หลักสูตรเทียบโอน)');

-- --------------------------------------------------------

-- 
-- Table structure for table 'plansubject'
-- 

CREATE TABLE plansubject (
  plan_id varchar(1) NOT NULL COMMENT 'รหัสโปรแกรมการศึกษา',
  scode varchar(8) NOT NULL COMMENT 'รหัสวิชาเรียน',
  pyear varchar(1) NOT NULL COMMENT 'ปีที่',
  term varchar(1) NOT NULL COMMENT 'เทอมที่',
  PRIMARY KEY  (plan_id,scode),
  KEY scode (scode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'plansubject'
-- 

INSERT INTO plansubject VALUES ('1', '01001008', '1', '2');
INSERT INTO plansubject VALUES ('1', '01001009', '1', '1');
INSERT INTO plansubject VALUES ('1', '01001010', '1', '2');
INSERT INTO plansubject VALUES ('1', '01001011', '1', '2');
INSERT INTO plansubject VALUES ('1', '01001012', '1', '1');
INSERT INTO plansubject VALUES ('1', '01001013', '1', '2');
INSERT INTO plansubject VALUES ('1', '01003001', '3', '3');
INSERT INTO plansubject VALUES ('1', '01072111', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072112', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072113', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072114', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072115', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072116', '2', '1');
INSERT INTO plansubject VALUES ('1', '01072117', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072118', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072119', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072120', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072121', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072122', '2', '2');
INSERT INTO plansubject VALUES ('1', '01072123', '3', '1');
INSERT INTO plansubject VALUES ('1', '01072124', '3', '1');
INSERT INTO plansubject VALUES ('1', '01072125', '3', '1');
INSERT INTO plansubject VALUES ('1', '01072126', '3', '2');
INSERT INTO plansubject VALUES ('1', '01072127', '3', '2');
INSERT INTO plansubject VALUES ('1', '01072128', '3', '2');
INSERT INTO plansubject VALUES ('1', '01072129', '3', '2');
INSERT INTO plansubject VALUES ('1', '01072130', '4', '1');
INSERT INTO plansubject VALUES ('1', '01072131', '4', '2');
INSERT INTO plansubject VALUES ('1', '05010101', '1', '1');
INSERT INTO plansubject VALUES ('1', '05010102', '1', '2');
INSERT INTO plansubject VALUES ('1', '05010103', '2', '1');
INSERT INTO plansubject VALUES ('1', '05100193', '1', '1');
INSERT INTO plansubject VALUES ('1', '05100194', '1', '1');
INSERT INTO plansubject VALUES ('1', '05300121', '1', '1');
INSERT INTO plansubject VALUES ('1', '05300122', '1', '1');
INSERT INTO plansubject VALUES ('1', '05300123', '1', '2');
INSERT INTO plansubject VALUES ('1', '05300124', '1', '2');
INSERT INTO plansubject VALUES ('2', '01001012', '1', '1');
INSERT INTO plansubject VALUES ('2', '01072111', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072112', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072113', '1', '1');
INSERT INTO plansubject VALUES ('2', '01072114', '1', '1');
INSERT INTO plansubject VALUES ('2', '01072115', '1', '1');
INSERT INTO plansubject VALUES ('2', '01072116', '1', '1');
INSERT INTO plansubject VALUES ('2', '01072117', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072118', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072119', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072120', '1', '2');
INSERT INTO plansubject VALUES ('2', '01072121', '2', '1');
INSERT INTO plansubject VALUES ('2', '01072122', '2', '1');
INSERT INTO plansubject VALUES ('2', '01072123', '2', '1');
INSERT INTO plansubject VALUES ('2', '01072124', '2', '1');
INSERT INTO plansubject VALUES ('2', '01072125', '2', '1');
INSERT INTO plansubject VALUES ('2', '01072126', '2', '2');
INSERT INTO plansubject VALUES ('2', '01072127', '2', '2');
INSERT INTO plansubject VALUES ('2', '01072128', '2', '2');
INSERT INTO plansubject VALUES ('2', '01072129', '2', '2');
INSERT INTO plansubject VALUES ('2', '01072130', '3', '1');
INSERT INTO plansubject VALUES ('2', '01072131', '3', '2');
INSERT INTO plansubject VALUES ('2', '05010101', '1', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table 'relations_person'
-- 

CREATE TABLE relations_person (
  relations_id int(11) NOT NULL auto_increment COMMENT 'รหัสของพี่น้อง',
  relations_name varchar(50) default NULL COMMENT 'ชื่อนามสกุล',
  relation_age int(11) default NULL COMMENT 'อายุ',
  relation_status char(10) default NULL COMMENT 'ความสัมพันธ์',
  relation_work varchar(30) default NULL COMMENT 'อาชีพ',
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (relations_id),
  KEY person_id (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'relations_person'
-- 

INSERT INTO relations_person VALUES (2, 'คนที่1', 50, 'พี่', 'อาชีพ1', 't0009');
INSERT INTO relations_person VALUES (3, 'คนที่2', 25, 'น้อง', 'อาชีพ2', 't0009');

-- --------------------------------------------------------

-- 
-- Table structure for table 'report'
-- 

CREATE TABLE report (
  r_id int(11) NOT NULL auto_increment,
  person_id varchar(13) NOT NULL,
  title varchar(16) NOT NULL,
  PRIMARY KEY  (r_id)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='ชุดเอกสาร';

-- 
-- Dumping data for table 'report'
-- 

INSERT INTO report VALUES (19, 'ดร.  ชุติเมตร', 'จองเงิน');
INSERT INTO report VALUES (18, '5411200002850', 'จองเงิน');
INSERT INTO report VALUES (17, '5411200002850', 'จองเงิน');
INSERT INTO report VALUES (16, '0001', 'จองเงิน');
INSERT INTO report VALUES (15, '0001', 'จองเงิน');
INSERT INTO report VALUES (14, '0001', 'จองเงิน');
INSERT INTO report VALUES (13, '5411200002850', 'ตั้งเบิก');
INSERT INTO report VALUES (12, '5411200002850', 'ตั้งเบิก');
INSERT INTO report VALUES (11, '5411200002850', 'ตั้งเบิก');
INSERT INTO report VALUES (20, 'ดร.  ชุติเมตร', 'จองเงิน');
INSERT INTO report VALUES (21, 'รศ. ประทีป   ', 'ยืมเงิน');
INSERT INTO report VALUES (22, 'รศ.  ประทีป  ', 'ตั้งเบิก');

-- --------------------------------------------------------

-- 
-- Table structure for table 'report_buy'
-- 

CREATE TABLE report_buy (
  sheet_num varchar(2) NOT NULL COMMENT 'เลขที่ใบรายงานขอซื้อ/จ้าง',
  list_id int(11) NOT NULL COMMENT 'ลำดับรายการ',
  st_num varchar(3) NOT NULL COMMENT 'เลขที่ ศธ.',
  date_making date NOT NULL COMMENT 'วันที่ทำใบรายงานซื้อ/จ้าง',
  title varchar(32) NOT NULL COMMENT 'เรื่อง',
  budget_name varchar(32) NOT NULL COMMENT 'ชื่องบประมาณ',
  budget_year varchar(4) NOT NULL COMMENT 'ปีงบประมาณ',
  shop_name varchar(32) NOT NULL COMMENT 'ชื่อร้านค้า',
  name_report varchar(32) NOT NULL COMMENT 'ชื่อผู้ทำรายงานขอซื้อ/จ้าง',
  reason varchar(32) NOT NULL COMMENT 'เหตุผลความจำเป็น',
  gpsc varchar(6) default NULL COMMENT 'รหัสพัสดุ',
  list varchar(64) NOT NULL COMMENT 'รายการ',
  unit_amount varchar(16) NOT NULL COMMENT 'จำนวนหน่วย',
  price_last double default NULL COMMENT 'ราคาซื้อ/จ้างครั้งหลังสุด',
  price_this double NOT NULL COMMENT 'ราคาซื้อ/จ้างครั้งนี้',
  `type` varchar(8) NOT NULL COMMENT 'ชนิดของธุรกรรม',
  clear_num varchar(2) NOT NULL COMMENT 'เลขที่ใบคืนเงินยืม',
  pay_num varchar(2) NOT NULL COMMENT 'เลขที่ใบสำคัญจ่าย',
  PRIMARY KEY  (sheet_num,list_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'report_buy'
-- 

INSERT INTO report_buy VALUES ('4', 1, '103', '2550-02-18', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษ', 'เงินงบประมาณ', '2550', 'นัฐวุฒิคอมพิวเตอร์เซอร์วิส  จำกั', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', '', 'scaner', '3 เครื่อง', 0, 8500, 'bring', '-', '4');
INSERT INTO report_buy VALUES ('3', 1, '103', '2549-03-01', 'วัสดุ', 'เงินงบประมาณ', '2549', 'อ่อนนุช จำกัด', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้งานในห้องวิจัย', '', 'scaner', '1 เครื่อง', 0, 62669, 'bring', '-', '2');
INSERT INTO report_buy VALUES ('1', 2, '103', '2549-02-01', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษ', 'เงินงบประมาณ', '2549', 'อ่อนหมากน้อย จำกัด', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', '', 'scaner2', '2 เครื่อง', 0, 5500, 'bring', '-', '1');
INSERT INTO report_buy VALUES ('2', 1, '103', '2007-02-14', '', '', '', 'abc', '', '', NULL, 'computer', '2', 0, 18000, 'bring', '', '1');
INSERT INTO report_buy VALUES ('2', 2, '103', '2007-02-14', '', '', '', 'abc', '', '', NULL, 'printer', '2', 0, 4500, 'bring', '', '1');
INSERT INTO report_buy VALUES ('1', 1, '103', '2549-02-01', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษ', 'เงินงบประมาณ', '2549', 'อ่อนหมากน้อย จำกัด', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', '', 'scaner', '3 เครื่อง', 0, 2500, 'bring', '-', '1');
INSERT INTO report_buy VALUES ('5', 1, '102', '2550-02-21', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษ', 'เงินงบประมาณ', '2550', 'พงศธรคอมพิวเตอร์ จำกัด', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', '', 'คอมพิวเตอร์', '2 เครื่อง', 0, 22000, 'clear', '2', '-');
INSERT INTO report_buy VALUES ('6', 1, '103', '2549-01-01', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษ', 'เงินงบประมาณ', '2549', 'อ่อนนุช จำกัด', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญ', '', '', '3 เครื่อง', 0, 22000, 'bring', '-', '4');

-- --------------------------------------------------------

-- 
-- Table structure for table 'reserve_money'
-- 

CREATE TABLE reserve_money (
  list_id int(2) NOT NULL COMMENT 'ลำดับรายการ',
  st_num varchar(3) NOT NULL COMMENT 'เลขที่ ศธ.',
  date_making date NOT NULL COMMENT 'วันที่ทำการจองเงิน',
  title varchar(64) NOT NULL COMMENT 'เรื่อง',
  budget_name varchar(32) NOT NULL COMMENT 'ชื่องบประมาณ',
  budget_year varchar(4) NOT NULL COMMENT 'ปีงบประมาณ',
  name_reserve varchar(32) NOT NULL COMMENT 'ชื่อผู้ขอให้จัดหา',
  reason varchar(64) NOT NULL COMMENT 'เหตุผลความจำเป็น',
  list varchar(64) NOT NULL COMMENT 'รายการ',
  amount varchar(16) NOT NULL COMMENT 'จำนวนหน่วย',
  money double NOT NULL COMMENT 'ราคาประมาณ',
  balance double default NULL COMMENT 'เงินคงเหลือ',
  date_using date NOT NULL COMMENT 'กำหนดเวลาที่ต้องการใช้เงิน',
  name_commit1 varchar(32) NOT NULL COMMENT 'ชื่อกรรมการคนที่แรก',
  name_commit2 varchar(32) NOT NULL COMMENT 'ชื่อกรรมการคนที่สอง',
  borrow_num int(2) NOT NULL COMMENT 'เลขที่สัญญาการยืมเงิน',
  bring_num int(11) NOT NULL COMMENT 'เลขที่ใบสำคัญจ่าย',
  PRIMARY KEY  (list_id,st_num)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'reserve_money'
-- 

INSERT INTO reserve_money VALUES (1, '103', '2549-03-01', 'วัสดุ', 'เงินงบประมาณ', '2549', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ห้องวิจัย', 'คอมพิวเตอร์1', '4 เครื่อง', 108000, 37095, '2549-05-01', 'ดร.  ชุติเมตร     ศรีนิลทา', 'ดร.  ชุติเมตร     ศรีนิลทา', 0, 4);
INSERT INTO reserve_money VALUES (2, '103', '2550-01-18', 'วัสดุ', 'เงินงบประมาณ', '2549', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ห้อง network', 'คอมพิวเตอร์2', '1เครื่อง', 27000, 37095, '2549-03-21', 'ดร.  ชุติเมตร     ศรีนิลทา', 'ดร.  ชุติเมตร     ศรีนิลทา', 0, 4);
INSERT INTO reserve_money VALUES (1, '102', '2550-01-18', 'วัสดุ', 'เงินงบประมาณ', '2550', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ห้อง network', 'คอมพิวเตอร์', '2 เครื่อง', 48000, 0, '2549-03-21', 'ดร.  ชุติเมตร     ศรีนิลทา', 'ดร.  ชุติเมตร     ศรีนิลทา', 2, 0);
INSERT INTO reserve_money VALUES (2, '101', '2550-01-18', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษา', 'เงินงบประมาณ', '2549', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญาโท', 'scaner2', '2 เครื่อง', 9400, 0, '2549-02-14', 'ดร.  ชุติเมตร     ศรีนิลทา', 'ดร.  ชุติเมตร     ศรีนิลทา', 1, 0);
INSERT INTO reserve_money VALUES (1, '101', '2550-01-18', 'รายงานขอซื้อขอจ้าง  วัสดุการศึกษา', 'เงินงบประมาณ', '2549', 'รศ.  ประทีป     บัญญัตินพรัตน์', 'ใช้ในงานวิจัยสำหรับนักศึกษาปริญญาโท', 'scaner', '1 เครื่อง', 13000, 0, '2549-02-14', 'ดร.  ชุติเมตร     ศรีนิลทา', 'ดร.  ชุติเมตร     ศรีนิลทา', 1, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table 'reward_person'
-- 

CREATE TABLE reward_person (
  reward_id int(11) NOT NULL auto_increment COMMENT 'รหัสของรางวัลหรือทุนที่เคยได้รับ',
  reward_name varchar(100) default NULL COMMENT 'ชื่อรางวัลหรือทุนที่เคยได้รับ',
  reward_from varchar(100) default NULL COMMENT 'ได้รับจาก',
  reward_date date default NULL COMMENT 'วันที่',
  reward_comm varchar(100) default NULL COMMENT 'หมายเหตุ',
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (reward_id),
  KEY person_id (person_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'reward_person'
-- 

INSERT INTO reward_person VALUES (2, 'รางวัล1', 'หน่วยงาน1', '2006-10-01', '-', 't0009');
INSERT INTO reward_person VALUES (3, 'ทุน1', 'หน่วยงาน2', '2006-09-11', '-', 't0009');

-- --------------------------------------------------------

-- 
-- Table structure for table 'structure'
-- 

CREATE TABLE structure (
  struct_id varchar(2) NOT NULL COMMENT 'รหัสโครงสร้างหลักสูตร',
  course_year int(10) NOT NULL COMMENT 'ปีการศึกษา',
  detail text NOT NULL COMMENT 'คำอธิบายโครงสร้างหลักสูตรปริญญาตรี',
  program_unit1 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 1',
  program_unit2 int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 2',
  PRIMARY KEY  (struct_id),
  KEY course_year (course_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'structure'
-- 

INSERT INTO structure VALUES ('1', 2545, 'การจัดการศึกษาแบ่งเป็นสองหลักสูตรตามพื้นฐานการศึกษาของนักศึกษา ในกรณีของนักศึกษาที่จบการศึกษาในระดับมัธยมศึกษาชั้นปีที่ 6 หรือเทียบเท่าใช้หลักสูตร 4 ปี ส่วนนักศึกษาที่มีพื้นฐานการศึกษาในระดับประกาศนียบัติวิชาชีพชั้นสูงจะใช้หลักสูตรเทียบโอนที่ใช้เวลาการศึกษา 3 ถึง 4 ปี', 141, 107);

-- --------------------------------------------------------

-- 
-- Table structure for table 'student'
-- 

CREATE TABLE student (
  student_id varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  faculty_id varchar(2) NOT NULL COMMENT 'รหัสคณะ',
  dept_id varchar(2) NOT NULL COMMENT 'รหัสภาควิชา',
  citizen_id varchar(13) default NULL COMMENT 'หมายเลขประจำตัวประชาชน',
  pre_name varchar(15) default NULL COMMENT 'คำนำหน้าชื่อ',
  gender varchar(10) default NULL,
  th_name varchar(50) NOT NULL COMMENT 'ชื่อภาษาไทย',
  th_surname varchar(50) NOT NULL COMMENT 'นามสกุลภาษาไทย',
  en_name varchar(30) default NULL COMMENT 'ชื่อภาษาอังกฤษ',
  en_surname varchar(30) default NULL COMMENT 'นามสกุลภาษาอังกฤษ',
  semester int(11) default NULL COMMENT 'ปีการศึกษา',
  username varchar(20) default NULL COMMENT 'ชื่อล็อกอิน',
  `password` varchar(20) default NULL COMMENT 'รหัสล็อกอิน',
  birthday date default NULL COMMENT 'วันเกิด',
  birth_place varchar(2) default NULL COMMENT 'จังหวัดที่เกิด',
  race char(20) default NULL COMMENT 'เชื้อชาติ',
  nationality char(20) default NULL COMMENT 'สัญชาติ',
  religion char(20) default NULL COMMENT 'ศาสนา',
  blood char(10) default NULL COMMENT 'หมู่โลหิต',
  number_static varchar(10) default NULL COMMENT 'บ้านเลขที่ ตามทะเบียนบ้าน',
  group_static varchar(5) default NULL COMMENT 'หมู่ที่ ตามทะเบียนบ้าน',
  lane_static varchar(50) default NULL COMMENT 'ตรอก/ซอย ตามทะเบียนบ้าน ',
  road_static varchar(50) default NULL COMMENT 'ถนน ตามทะเบียนบ้าน',
  district_static varchar(50) default NULL COMMENT 'ตำบล/แขวง ตามทะเบียนบ้าน',
  region_static varchar(50) default NULL COMMENT 'อำเภอ/เขต ตามทะเบียนบ้าน',
  province_static varchar(2) default NULL COMMENT 'จังหวัด ตามทะเบียนบ้าน',
  postalcode_static varchar(5) default NULL COMMENT 'รหัสไปรษณีย์ ตามทะเบียนบ้าน',
  telephone_static varchar(10) default NULL COMMENT 'โทรศัพท์ ตามทะเบียนบ้าน',
  number_contact varchar(10) default NULL COMMENT 'บ้านเลขที่ ที่ติดต่อได้',
  group_contact varchar(5) default NULL COMMENT 'หมู่ที่ ที่ติดต่อได้ ',
  lane_contact varchar(50) default NULL COMMENT 'ตรอก/ซอย ที่ติดต่อได้ ',
  road_contact varchar(50) default NULL COMMENT 'ถนน ที่ติดต่อได้ ',
  district_contact varchar(50) default NULL COMMENT 'ตำบล/แขวง ที่ติดต่อได้ ',
  region_contact varchar(50) default NULL COMMENT 'อำเภอ/เขต ที่ติดต่อได้ ',
  province_contact varchar(2) default NULL COMMENT 'จังหวัด ที่ติดต่อได้ ',
  postalcode_contact varchar(5) default NULL COMMENT 'รหัสไปรษณีย์ ที่ติดต่อได้ ',
  telephone_contact varchar(10) default NULL COMMENT 'โทรศัพท์ ที่ติดต่อได้ ',
  relatives int(11) default NULL COMMENT 'นักศึกษาเป็นบุตรคนที่ในจำนวนพี่น้องบิดา-มารดาเดียวกัน ',
  alive int(11) default NULL COMMENT 'มีชีวิตอยู่',
  studying int(11) default NULL COMMENT 'อยู่ในระหว่างการศึกษา',
  salary int(11) default NULL COMMENT 'รายได้จากการทำงาน',
  exam_pattern char(20) default NULL COMMENT 'รูปแบการสอบผ่านทบวงมหาวิทยาลัย',
  exam1 char(20) default NULL COMMENT 'การดำเนินการจัดสอบ/คัดเลือกหลักสูตร4-5ปี ',
  habital char(50) default NULL COMMENT 'อาศัยอยู่กับ',
  status_parent char(50) default NULL COMMENT 'สถานภาพสมรสของบิดา-มารดา',
  education_status char(1) default NULL COMMENT 'สถานะการจบการศึกษา (ม.6 – สอบเทียบ-ปวส) ',
  fin_school varchar(100) default NULL COMMENT 'สำเร็จการศึกษาจากโรงเรียน',
  fin_province varchar(50) default NULL COMMENT 'สำเร็จการศึกษาจากจังหวัด',
  fin_year int(11) default NULL COMMENT 'สำเร็จการศึกษาในปีการศึกษา',
  fin_gpa float default NULL COMMENT 'สำเร็จการศึกษาระดับคะแนนเฉลี่ยสะสม',
  before_year int(11) default NULL COMMENT 'ปีที่เคยเป็นนักศึกษาของสถาบันฯมาก่อน',
  before_univ varchar(100) default NULL COMMENT 'ชื่อมหาวิทยาลัย/สถาบันฯที่เคยศึกษามาก่อน ',
  before_yuniv int(11) default NULL COMMENT 'ปีการศึกษามหาวิทยาลัย/สถาบันฯที่เคยศึกษามาก่อน ',
  s_parent varchar(20) default NULL COMMENT 'ผู้ปกครอง',
  sm_parent varchar(20) default NULL COMMENT 'แหล่งอุดหนุนการศึกษา',
  std_status varchar(1) default NULL COMMENT 'สถานะของนักศึกษาที่จบออกไป',
  gpa float default NULL COMMENT 'ค่า GPA ของนักศึกษา',
  PRIMARY KEY  (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'student'
-- 

INSERT INTO student VALUES ('46012361', '01', '02', NULL, 'นาย', NULL, 'เอกชัย', 'วิทยาการ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '123456789', NULL, NULL, NULL, NULL, NULL, 'ต่อเนื่องปกติ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2.8);
INSERT INTO student VALUES ('46015001', '01', '05', NULL, 'นาย', 'ชาย', 'รัฐพงศ์', 'รังสรรค์', NULL, NULL, 2546, '46015001', '7c29a5eb12b440ec', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 2);
INSERT INTO student VALUES ('46015323', '01', '05', NULL, 'นางสาว', 'ชาย', 'มธุรส', 'วรรณพร', NULL, NULL, 2546, '46015323', '7c8d8c6e0c130953', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 1.8);
INSERT INTO student VALUES ('47014001', '01', '05', NULL, 'นาย', 'ชาย', 'อุทัย', 'ดวงปทุม', NULL, NULL, 2547, '47014001', '08cd15fb1f4f9cef', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 3.4);
INSERT INTO student VALUES ('47014002', '01', '05', NULL, 'นาย', 'ชาย', 'คมสัน', 'จันทร์เจริญ ', NULL, NULL, 2547, '47014002', '08cd2b7c1f4f9a70', '1985-04-12', '6', 'ไทย', 'ไทย', 'พุทธ', 'AB', '337/11-12', '4', '-', 'ประพัทธ์บำรุง', 'ในเมือง', 'บ้านไผ่', '6', '40110', '0-1493-873', '337/11-12', '4', '-', 'ประพัทธ์บำรุง', 'ในเมือง', 'บ้านไผ่', '6', '40110', '0-1493-873', 1, 1, 1, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', 'แก่นนครวิทยาลัย', '6', 2458, 3.55, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 1.89);
INSERT INTO student VALUES ('47014323', '01', '05', NULL, 'นาย', 'ชาย', 'ชัยยา', 'ไชยวงศ์', NULL, NULL, 2547, '47014323', '0e78320e1984c6ce', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 2.35);
INSERT INTO student VALUES ('47015314', '01', '05', '1234567891234', 'นาย', 'ชาย', 'คมสัน', 'นาคนาวา', 'KOMSON', 'NAKNAWA', 2547, '47015314', '798ebb136331ad81', '1982-04-11', '8', 'ไทย', 'ไทย', 'อิสลาม', 'A', '12', '10', '-', '-', 'แปดริ้ว', 'เมือง', '8', '20000', '-', '12', '10', '-', '-', 'แปดริ้ว', 'เมือง', '8', '20000', '0861234562', 2, 2, 1, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บ้านเช่า/ห้องเช่า', 'อยู่ด้วยกัน', '3', 'วิทยาลัยเทคนิคฉะเชิงเทรา', '8', 2545, 3.25, NULL, NULL, NULL, 'บิดา', 'ทุนการศึกษา', 'Y', 2.6);
INSERT INTO student VALUES ('47015323', '01', '05', '9876543211111', 'ว่าที่รต. ', 'ชาย', 'ธีระยุทธ', 'แสนหอม', 'TEERAYUTH', 'SANHOM', 2547, '47015323', '798ca9c76335054e', '1981-12-30', '1', 'อิตาเลี่ยน', 'อิตาเลี่ยน', 'ฮินดู', 'ไม่มี', '69/1', '11', '-', 'สุขาภิบาล1', 'บางกะปิ', 'บางกะปิ', '1', '10630', '02-9654123', '124/53', '2', 'อ่อนนุช12', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10320', '02-8541236', 2, 3, 2, 12450, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'โรงแรม', 'อยู่ด้วยกัน', '2', 'สถาบันเทคโนโลยีราชมงคลกรุงเทพ', '1', 2545, 2.5, NULL, NULL, NULL, 'ญาติ', 'ญาติ', 'Y', 4);
INSERT INTO student VALUES ('47015328', '01', '05', '1234567890321', 'นาย', 'ชาย', 'ปัญญ์', 'ศรีเบญจลักษณ์', 'PANN', 'SRIBENJALAK', 2547, '47015328', '798ca2106334fb97', '1984-02-14', '1', 'ไทย', 'ไทย', 'พุทธ', 'B', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 1, 2, 2, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'หอพักเอกชน', 'อยู่ด้วยกัน', '3', 'โรงเรียนเทคโนโลยีภาคตะวันออก', '9', 2546, 3.5, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 3.14);
INSERT INTO student VALUES ('48013001', '01', '03', NULL, 'นางสาว', 'หญิง', 'ดวงมณี', 'ปัทมกุลวงศ์', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0847152314', NULL, NULL, NULL, NULL, NULL, 'ต่อเนื่องปกติ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1.99);
INSERT INTO student VALUES ('48014001', '01', '05', NULL, 'นาย', 'ชาย', 'มงคล', 'กิตติรัตน์', NULL, NULL, 2548, '48014001', '2c609c280687c2b0', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 2.1);
INSERT INTO student VALUES ('48014323', '01', '05', NULL, 'นาย', 'ชาย', 'วินัย', 'เจริญไชย', NULL, NULL, 2548, '48014323', '31c203376b366bf7', '0000-00-00', '', 'ไทย', 'ไทย', 'พุทธ', 'A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 2.34);
INSERT INTO student VALUES ('48015001', '01', '05', '3242351265346', 'นางสาว', 'หญิง', 'รัตนาภรณ์', 'อนุรัตนวงศ์', 'RATTANAPORN', 'ANURATTANAWONG', 2548, '48015001', '2e629c294295c2ae', '1985-05-25', '13', 'ไทย', 'ไทย', 'พุทธ', 'AB', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', NULL, '32', '2', 'เกกีงาม1', NULL, 'ลาดกระบัง', 'ลาดกระบัง', '1', '20200', NULL, 3, 4, 2, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '3', 'วิทยาลัยเทคนิคเชียงใหม่', NULL, NULL, NULL, NULL, NULL, NULL, 'มารดา', 'บิดา-มารดา', 'Y', 3.1);
INSERT INTO student VALUES ('48015323', '01', '05', '9876543212354', 'นางสาว', 'หญิง', 'วิจิตรา', 'รัตนามณี', 'VIJITRA', 'RATANAMANEE', 2548, '48015323', '31c3e0cc453c6bf1', '1986-08-21', '1', 'จีน', 'จีน', 'คริสต์', 'AB', '12/6', '10', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '0245624588', '17', '1', '-', '-', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10500', '0812345852', 2, 3, 1, 50000, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บ้านเช่า/ห้องเช่า', 'อยู่ด้วยกัน', '3', 'สถาบันเทคโนโลยีราชมงคล', '18', 2546, 3.52, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา', 'Y', 2.02);
INSERT INTO student VALUES ('49015001', '01', '05', '1253453645745', 'นาย', 'ชาย', 'เอกราช', 'สมวงศ์', 'AKERACH', 'SOMWONG', 2549, '49015001', '033423ca3eda4e51', '1985-04-23', '13', 'ไทย', 'ไทย', 'คริสต์', 'AB', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', '65000', '0897676545', '76', '1', 'ริมสวน', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10320', '0897676545', 1, 1, 1, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'หอพักเอกชน', 'อยู่ด้วยกัน', '1', 'พิษณุโลกราชูทิศ', '38', 2546, 2.43, NULL, NULL, NULL, 'บิดา', 'กู้ยืม', 'N', 2.99);
INSERT INTO student VALUES ('49015323', '01', '05', '4154564521321', 'นาย', 'ชาย', 'รุ่งโรจน์', 'รุ่งเรื่อง', 'RUNGROJ', 'RONGRANG', 2549, '49015323', '0f7afc91330c68e0', '1985-03-25', '9', 'ไทย', 'ไทย', 'คริสต์', 'B', '1', '10', 'สุขุมวิท12', 'สุขุมวิท', 'บางละมุง', 'พัทยา', '9', '20320', '0245624588', '1', '10', 'สุขุมวิท12', 'สุขุมวิท', 'บางละมุง', 'พัทยา', '9', '20320', '0245624588', 2, 2, 1, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '3', 'วิทยาลัยเทคนิคชลบุรี', '9', 2466, 3.52, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา', 'Y', 1.51);
INSERT INTO student VALUES ('49015874', '01', '01', NULL, 'นาย', NULL, 'รณฤทธ์', 'ประสิทธิ์ชัย', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0121445222', NULL, NULL, NULL, NULL, NULL, 'หลักสูตรปกติ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2.79);

-- --------------------------------------------------------

-- 
-- Table structure for table 'subject'
-- 

CREATE TABLE `subject` (
  scode varchar(8) NOT NULL COMMENT 'รหัสวิชา',
  th_name varchar(100) NOT NULL COMMENT 'ชื่อวิชาภาษาไทย',
  en_name varchar(100) NOT NULL COMMENT 'ชื่อวิชาภาษาอังกฤษ',
  unit int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตทั้งหมด',
  unit_d int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตบรรยาย',
  unit_o int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตปฏิบัติ',
  unit1 int(11) NOT NULL COMMENT 'หน่วยกิตรวมของโปรแกรมที่2',
  unit_d1 int(11) NOT NULL COMMENT 'หน่วยกิตทฤษฎีของโปรแกรมที่2',
  unit_o1 int(11) NOT NULL COMMENT 'หน่วยกิตปฏิบัติของโปรแกรมที่2',
  scode_to varchar(50) default NULL COMMENT 'รหัสวิชาบังคับก่อน',
  sdetail text COMMENT 'คำอธิบายรายวิชา',
  url varchar(100) default NULL COMMENT 'URL ใช้ลิงค์ไปยังโฮมเพจรายวิชา',
  gsubject_id varchar(2) NOT NULL,
  PRIMARY KEY  (scode),
  KEY gsubject_id (gsubject_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'subject'
-- 

INSERT INTO subject VALUES (' 0310000', 'การเงินและการธนาคาร', 'MONEY AND BANKING', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES (' 0310002', 'หลักการตลาด', ' Principles of Marketing', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('01000001', 'คณิตศาสตร์ 1', 'Mathematics I', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('01000002', 'คณิตศาสตร์ 2', 'Mathematics II', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('01000003', 'คณิตศาสตร์ 3', 'Mathematics III', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('01000010', 'ฟิสิกส์ทั่วไป 1', 'General Physics I', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('01000011', 'ปฏิบัติการฟิสิกส์ทั่วไป 1', 'General Physics Laboratory I', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('01000014', 'เคมีทั่วไป', 'General Chemistry', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('01000015', 'ปฏิบัติการเคมีทั่วไป', 'Practices in General Chemistry', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('01001008', 'การทดลองทางวิศวกรรม', 'Engineering Practices', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01001009', 'เขียนแบบวิศวกรรม', 'Engineering Drawing', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01001010', 'กลศาสตร์วิศวกรรม', 'Engineering Mechanics', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01001011', 'วัสดุวิศวกรรม', 'Engineering Materials', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01001012', 'หลักการเขียนโปรแกรมคอมพิวเตอร์', 'Principle of Computer Programming', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01001013', 'วิศวกรรมไฟฟ้า', 'ELECTRICAL ENGINEERING', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01003001', 'การฝึกงานอุตสาหกรรมภาคฤดูร้อน', 'Industrial Training in Summer', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO subject VALUES ('01072001', 'การเขียนโปรแกรมคอมพิวเตอร์ 2', 'Computer Programming II', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072003', 'การออกแบบวงจรดิจิตอลและวงจรตรรก', 'Digital Circuit and Logic Design', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072004', 'ปฏิบัติการวงจรดิจิตอล', 'Digital Circuit Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072008', 'ปฏิบัติการโครงสร้างข้อมูลและอัลกอริทึม', 'Data Structure and Algorithm Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072111', 'การเขียนโปรแกรมคอมพิวเตอร์ 2', 'COMPUTER PROGRAMMING 2', 3, 3, 0, 0, 0, 0, '01001012', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072112', 'ปฏิบัติการโปรแกรมคอมพิวเตอร์ 2', 'COMPUTER PROGRAMMING LABORATORY 2', 1, 0, 3, 0, 0, 0, '01001012', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072113', 'การออกแบบวงจรดิจิตอลและวงจรตรรก', 'DIGITAL CIRCUIT AND LOGIC DESIGN', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072114', 'ปฏิบัติการวงจรดิจิตอล', 'DIGITAL CIRCUIT LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072115', 'อิเล็กทรอนิกส์พื้นฐานสำหรับวิศวกรรมคอมพิวเตอร์', 'BASIC ELECTRONICS FOR COMPUTER ENGINEER', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072116', 'ปฏิบัติการวิศวกรรมคอมพิวเตอร์', 'COMPUTER ENGINEERING LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072117', 'โครงสร้างข้อมูลและอัลกอริธึม', 'DATA STRUCTURE AND ALGORITHM', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072118', 'ปฏิบัติการโครงสร้างข้อมูลและอัลกอริธึม', 'DATA STRUCTURE AND ALGORITHM LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072119', 'การสื่อสารข้อมูล', 'DATA COMMUNICATION', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072120', 'ปฏิบัติการสื่อสารข้อมูล', 'DATA COMMUNICATION LABORATORY', 1, 0, 3, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072121', 'องค์ประกอบคอมพิวเตอร์และภาษาแอสเซมบลี', 'COMPUTER ORGANIZATION AND ASSEMBLY LANGUAGE', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072122', 'ปฏิบัติการภาษาแอสเซมบลี', 'ASSEMBLY LANGUARE LABORATORY', 1, 0, 3, 0, 0, 0, '1072113', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072123', 'ทฤษฎีการคำนวณ', 'THEORY OF COMPUTATION', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072124', 'สถาปัตยกรรมคอมพิวเตอร์', 'COMPUTER ARCHITECTURE', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072125', 'เครือข่ายคอมพิวเตอร์', 'COMPUTER NETWORK', 3, 3, 0, 0, 0, 0, '01072119', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072126', 'ระบบปฏิบัติการ', 'OPERATING SYSTEMS', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072127', 'ระบบฐานข้อมูล', 'DATABASE SYSTEMS', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072128', 'วิศวกรรมซอฟต์แวร์', 'SOFTWARE ENGINEERING', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO subject VALUES ('01072129', 'โครงงานคอมพิวเตอร์', 'COMPUTER PROJECT', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072130', 'โครงงาน 1', 'PROJECT 1', 3, 0, 9, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO subject VALUES ('01072131', 'โครงงาน 2', 'PROJECT 2', 3, 0, 9, 0, 0, 0, '01072130', NULL, NULL, '7');
INSERT INTO subject VALUES ('01073101', 'การออกแบบระบบดิจิตอลขั้นสูง', 'Advanced Digital System Design', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO subject VALUES ('01073102', 'ปฏิบัติการวงจรดิจิตอลขั้นสูง', 'Advanced Digital System Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO subject VALUES ('01073202', 'การพัฒนาซอฟต์แวร์ระบบ', 'System Software Development', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO subject VALUES ('01073301', 'ระบบเครือข่ายท้องถิ่น', 'Local Area Networks', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO subject VALUES ('01074107', 'การพัฒนาหุ่นยนต์ขนาดเล็ก', 'Micro Robot Development', 3, 1, 6, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO subject VALUES ('01074201', 'การเขียนโปรแกรมเครือข่าย', 'Network Programming', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO subject VALUES ('01074204', 'ปฏิบัติการเขียนโปรแกรมบนระบบยูนิกซ์ขั้นสูง', 'Advanced UNIX Programming Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO subject VALUES ('01074220', 'ระบบฐานข้อมูลขั้นสูง', 'Advanced Database Systems', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO subject VALUES ('03010026', 'ภาษาอังกฤษพื้นฐาน 1', 'Foundation English 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO subject VALUES ('03010027', 'ภาษาอังกฤษพื้นฐาน 2', 'Foundation English 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO subject VALUES ('03020001', 'ภาษาญี่ปุ่นพื้นฐาน 1', 'Elementary to Japanese 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO subject VALUES ('03020002', 'ภาษาญี่ปุ่นพื้นฐาน 2', 'Elementary to Japanese 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO subject VALUES ('03100001', 'เศรษฐศาสตร์เบื้องต้น', 'INTRODUCTION TO ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100002', 'เศรษฐศาสตร์อุตสาหกรรม', 'INDUSTRIAL ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100003', 'เศรษฐศาสตร์อุตสาหกรรม', 'INDUSTRIAL ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100005', 'เศรษฐศาสตร์ผู้บริโภค', 'Consumer Economics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100006', 'เศรษฐศาสตร์อุตสาหกรรม', 'Industrial Economics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100022', 'พฤติกรรมผู้บริโภค', 'Consumer Behaviour', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100031', 'การบริหารธุรกิจ ', 'Business Administration', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100032', 'การบริหารอุตสาหกรรม', ' Industrial Management, Industrial and Administration', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100033', 'การจัดองค์การและการบริหารทั่วไป', 'Organization and General Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100034', 'การบริหารอุตสาหกรรม', 'Industrial Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100035', 'การบริหารงานบุคคล', 'Personnel Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100037', 'การบริหารการเงิน', 'Financial Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100038', 'การจัดการธุรกิจขนาดย่อม', 'Small Business Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100051', 'หลักการบัญชี', 'Principles of Accounting', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100061', 'ความรู้เบื้องต้นเกี่ยวกับกฎหมายทั่วไป', 'Introduction to the Studies of Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100062', 'กฎหมายแพ่งและพาณิชย์', 'Civil and Commercial Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100063', 'กฎหมายแรงงาน', 'Labour Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03100064', 'กฎหมายแรงงานและ พ.ร.บ.วิชาชีพวิศวกรรม', 'Labour Laws and the Engineering Profession Act', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO subject VALUES ('03150001', 'ปรัชญาพื้นฐาน', 'Fundamental Philosophy', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO subject VALUES ('03150002', 'ปรัชญาวิทยาศาสตร์', 'Philosophy of Science', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO subject VALUES ('03150003', 'พุทธปรัชญา', 'Philosophy of Buddhism', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO subject VALUES ('03150004', 'สุนทรียศาสตร์', 'Aesthetics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO subject VALUES ('03150005', 'จริยศาสตร์และสุนทรียศาสตร์', 'Ethics and Aesthetics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO subject VALUES ('05010101', 'คณิตศาสตร์วิศวกรรม 1', 'ENGINEERING MATHEMATICS 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('05010102', 'คณิตศาสตร์วิศวกรรม 2', 'ENGINEERING MATHEMATICS 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('05010103', 'คณิตศาสตร์วิศวกรรม 3', 'ENGINEERING MATHEMATICS 3', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO subject VALUES ('05100193', 'เคมีทั่วไป', 'GENERAL CHEMISTRY', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('05100194', 'ปฏิบัติการเคมีทั่วไป', 'PRACTICES IN GENERAL CHEMISTRY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('05300121', 'ฟิสิกส์ทั่วไป 1', 'GENERAL PHYSICS 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('05300122', 'ปฏิบัติการฟิสิกส์ทั่วไป 1', 'GENERAL PHYSICS LABORATORY 1', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('05300123', 'ฟิสิกส์ทั่วไป 2', 'GENERAL PHYSICS 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO subject VALUES ('05300124', 'ปฏิบัติการฟิสิกส์ทั่วไป 2', 'GENERAL PHYSICS LABORATORY 2', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');

-- --------------------------------------------------------

-- 
-- Table structure for table 'tool'
-- 

CREATE TABLE tool (
  toolid varchar(30) NOT NULL COMMENT 'รหัสอุปกรณ์',
  toolname varchar(50) NOT NULL COMMENT 'ชื่ออุปกรณ์',
  price int(11) default NULL COMMENT 'ราคา',
  amount int(11) default NULL COMMENT 'จำนวน',
  tdate date default NULL COMMENT 'วันที่ซื้อ',
  brand varchar(50) default NULL COMMENT 'ยี่ห้อ',
  cid int(11) default NULL COMMENT 'รหัสบริษัทของอุปกรณ์',
  PRIMARY KEY  (toolid),
  KEY cid (cid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'tool'
-- 

INSERT INTO tool VALUES ('48CE201-001', 'ไมโครโฟน NPE PN48', 650, 1, '2006-10-17', 'panasonic', NULL);
INSERT INTO tool VALUES ('48CE201-002', 'ไมโครโฟน NPE PN48', 650, 1, '2006-10-17', 'panasonic', NULL);
INSERT INTO tool VALUES ('48CE203-001', 'ลำโพง NPE V-ST 302BT', 500, 1, '2006-12-14', 'sony', 1);
INSERT INTO tool VALUES ('48CE203-002', 'ลำโพง NPE V-ST 302BT', 500, 1, '2006-12-12', 'sony', 1);
INSERT INTO tool VALUES ('48CE203-003', 'ลำโพง NPE V-ST 302BT', 500, 1, '2006-12-12', 'sony', 1);
INSERT INTO tool VALUES ('48CE206-001', 'ปริ้นเตอร์ HP Laserjet1320', 8950, 1, '2006-11-29', 'HP', 3);
INSERT INTO tool VALUES ('48CE206-002', 'ปริ้นเตอร์ HP Laserjet1320', 8950, 1, '2006-11-29', 'HP', 2);
INSERT INTO tool VALUES ('48CE207-002', 'ฉากฉาย Projector สามขา', 1500, 1, '2006-12-10', 'samsung', NULL);
INSERT INTO tool VALUES ('48CE208-001', 'Bord ทดลอง Digital', 8000, 1, '2006-12-19', 'xdigit', NULL);
INSERT INTO tool VALUES ('48CE208-002', 'Bord ทดลอง Digital', 8000, 1, '2006-12-19', 'xdigit', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table 'tool_company'
-- 

CREATE TABLE tool_company (
  cid int(11) NOT NULL auto_increment COMMENT 'รหัสบริษัทของอุปกรณ์',
  cname varchar(50) NOT NULL COMMENT 'ชื่อบริษัท',
  address varchar(100) default NULL COMMENT 'ที่อยู่',
  phone varchar(20) default NULL COMMENT 'หมายเลขโทรศัพท์',
  fax varchar(20) default NULL COMMENT 'หมายเลขแฟก',
  PRIMARY KEY  (cid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'tool_company'
-- 

INSERT INTO tool_company VALUES (1, 'บริษัทอิเล็กทรอนิกส์คอมมิท', '245/1 หมู่6 อ่อนนุช อ่อนนุช กรุงเทพ', '02-8569523', '02-8569524');
INSERT INTO tool_company VALUES (2, 'บริษัทคอมพิวเตอร์อินโฟร์เทค', '963 หมู่9  บางเสาธง สมุทรปราการ', '02-3256985-7', '02-3256988');
INSERT INTO tool_company VALUES (3, 'บริษัท เบสคอมแอนอิเล็กทริค จำกัด', '521/56 หมู่8  บางบอน3  บางบอน กทม. 10150', '02-7412586-8', '02-7412589');

-- --------------------------------------------------------

-- 
-- Table structure for table 'tool_sborrow'
-- 

CREATE TABLE tool_sborrow (
  bid int(11) NOT NULL auto_increment COMMENT 'ลำดับการยืม',
  student_id varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  toolid varchar(30) NOT NULL COMMENT 'รหัสอุปกรณ์',
  bdate date NOT NULL COMMENT 'วันที่ยืม',
  total int(11) NOT NULL COMMENT 'จำนวนอุปกรณ์',
  `status` varchar(1) NOT NULL COMMENT 'สถานะการยืม',
  `comment` text COMMENT 'หมายเหตุ',
  PRIMARY KEY  (bid),
  KEY student_id (student_id),
  KEY toolid (toolid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'tool_sborrow'
-- 

INSERT INTO tool_sborrow VALUES (1, '47015323', '48CE203-001', '2007-01-26', 1, '0', NULL);
INSERT INTO tool_sborrow VALUES (2, '47015323', '48CE206-001', '2007-01-26', 1, '1', NULL);
INSERT INTO tool_sborrow VALUES (3, '47015328', '48CE201-001', '2007-02-01', 1, '1', NULL);
INSERT INTO tool_sborrow VALUES (4, '47015328', '48CE208-001', '2007-02-01', 1, '1', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table 'tool_tborrow'
-- 

CREATE TABLE tool_tborrow (
  bid int(11) NOT NULL auto_increment COMMENT 'ลำดับการยืม',
  person_id varchar(13) NOT NULL COMMENT 'รหัสนักศึกษา',
  toolid varchar(30) NOT NULL COMMENT 'รหัสอุปกรณ์',
  bdate date NOT NULL COMMENT 'วันที่ยืม',
  total int(11) NOT NULL COMMENT 'จำนวนอุปกรณ์',
  `status` varchar(1) NOT NULL COMMENT 'สถานะการยืม',
  `comment` text COMMENT 'หมายเหตุ',
  PRIMARY KEY  (bid),
  KEY person_id (person_id),
  KEY toolid (toolid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'tool_tborrow'
-- 

INSERT INTO tool_tborrow VALUES (1, 't0003', '48CE201-001', '2007-01-26', 1, '1', NULL);
INSERT INTO tool_tborrow VALUES (2, 't0003', '48CE201-002', '2007-01-26', 1, '0', NULL);
INSERT INTO tool_tborrow VALUES (3, 't0007', '48CE208-001', '2007-01-26', 1, '1', 'ยืมทดลองใช้ทั้งเทอม');
INSERT INTO tool_tborrow VALUES (4, 't0029', '48CE203-001', '2007-02-01', 1, '1', NULL);
INSERT INTO tool_tborrow VALUES (5, 't0029', '48CE206-002', '2007-02-01', 1, '1', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table 'training_person'
-- 

CREATE TABLE training_person (
  training_id int(11) NOT NULL auto_increment COMMENT 'รหัสของประวัติการดูงานหรือฝึกอบรม',
  training_name varchar(100) default NULL COMMENT 'ชื่อประวัติการดูงานหรือฝึกอบรม',
  training_place varchar(100) default NULL COMMENT 'สถานที่',
  training_date date default NULL COMMENT 'วันที่',
  training_comm varchar(100) default NULL COMMENT 'หมายเหตุ',
  person_id varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (training_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table 'training_person'
-- 

INSERT INTO training_person VALUES (6, '1', '1', '2007-01-15', '1', 't0010');
INSERT INTO training_person VALUES (7, 'ดูงานที่1', 'สถานที่1', '2006-09-22', '-', 't0002');
INSERT INTO training_person VALUES (8, 'อบรมที่1', 'สถานที่2', '2005-04-05', '-', 't0002');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `activity_person`
-- 
ALTER TABLE `activity_person`
  ADD CONSTRAINT activity_person_ibfk_1 FOREIGN KEY (person_id) REFERENCES person (person_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `bookborrow`
-- 
ALTER TABLE `bookborrow`
  ADD CONSTRAINT bookborrow_ibfk_1 FOREIGN KEY (student_id) REFERENCES student (student_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `category`
-- 
ALTER TABLE `category`
  ADD CONSTRAINT category_ibfk_1 FOREIGN KEY (struct_id) REFERENCES structure (struct_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `department`
-- 
ALTER TABLE `department`
  ADD CONSTRAINT department_ibfk_1 FOREIGN KEY (faculty_id) REFERENCES faculty (faculty_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `edu_person`
-- 
ALTER TABLE `edu_person`
  ADD CONSTRAINT edu_person_ibfk_1 FOREIGN KEY (person_id) REFERENCES person (person_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `groups`
-- 
ALTER TABLE `groups`
  ADD CONSTRAINT groups_ibfk_1 FOREIGN KEY (category_id) REFERENCES category (category_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `parent`
-- 
ALTER TABLE `parent`
  ADD CONSTRAINT parent_ibfk_1 FOREIGN KEY (student_id) REFERENCES student (student_id) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `performance_person`
-- 
ALTER TABLE `performance_person`
  ADD CONSTRAINT performance_person_ibfk_1 FOREIGN KEY (person_id) REFERENCES person (person_id) ON DELETE CASCADE ON UPDATE CASCADE;
