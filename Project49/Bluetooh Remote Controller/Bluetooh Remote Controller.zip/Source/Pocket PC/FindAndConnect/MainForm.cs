using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using Franson.BlueTools;
using System.IO;
using System.Text;
using System.Xml;

namespace FindAndConnect
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.Button discoverDevices;
        private System.Windows.Forms.ListBox deviceList;
        private System.Windows.Forms.TextBox serviceOutput;

		// BlueTools Fields
		private Manager			manager			= null;
		private Network			m_network		= null;
		private RemoteService	currentService	= null;
		private Stream			currentStream	= null;
        private System.Windows.Forms.Label lStatus;
        private Label lStackVersion;
        private MenuItem menuItem1;
        private MenuItem menuItem2;
        private MenuItem menuItem6;
        private MenuItem menuItem12;
        private MenuItem menuItem13;
        private MenuItem menuItem7;
        private MenuItem menuItem14;
        private MenuItem menuItem15;
        private MenuItem menuItem8;
        private MenuItem menuItem16;
        private MenuItem menuItem17;
        private MenuItem menuItem9;
        private MenuItem menuItem18;
        private MenuItem menuItem19;
        private MenuItem menuItem10;
        private MenuItem menuItem20;
        private MenuItem menuItem21;
        private MenuItem menuItem11;
        private MenuItem menuItem22;
        private MenuItem menuItem23;
        private MenuItem menuItem3;
        private MenuItem menuItem24;
        private MenuItem menuItem4;
        private MenuItem menuItem5;
        private MenuItem menuItem25;
        private MenuItem menuItem26;
        private MenuItem menuItem27;
        private MenuItem menuItem32;
        private MenuItem menuItem33;
        private MenuItem menuItem28;
        private MenuItem menuItem29;
        private MenuItem menuItem30;
        private MenuItem menuItem31;
        private Button closeConnection;
        private MenuItem menuItem34;
        private MenuItem menuItem35;
        private MenuItem menuItem36;
        private MenuItem menuItem37;
        private MenuItem menuItem38;
        private Button button1;
		private byte[]			m_buffer		= new byte[25];	// Buffer to read data into
	
		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// You can get a valid evaluation key for BlueTools at
			// http://franson.com/bluetools/
			// That key will be valid for 14 days. Just cut and paste that key into the statement below.
			// To get a key that do not expire you need to purchase a license
			Franson.BlueTools.License license = new Franson.BlueTools.License();
            license.LicenseKey = "HU5Uaer1y2KNNX38jijhPlXRZvs0RQQaHXEX";

			try
			{
				manager	= Manager.GetManager();

				switch(Manager.StackID)
				{
					case StackID.STACK_MICROSOFT:
						lStackVersion.Text = "Microsoft ";
						break;
					case StackID.STACK_WIDCOMM:
						lStackVersion.Text = "WidComm ";
						break;
				}

				this.Closing += new System.ComponentModel.CancelEventHandler(MainForm_Closing);

				// Call events in GUI thread
				manager.Parent = this;
				// Call events in new thread (multi-threading)
				// manager.Parent = null

				// Get first netowrk (BlueTools 1.0 only supports one network == one dongle)
				m_network = manager.Networks[0];

				// Add events for device discovery
				m_network.DeviceDiscovered += new BlueToolsEventHandler(network_DeviceDiscovered);
				m_network.DeviceDiscoveryStarted += new BlueToolsEventHandler(network_DeviceDiscoveryStarted);
				m_network.DeviceDiscoveryCompleted += new BlueToolsEventHandler(network_DeviceDiscoveryCompleted);
				m_network.DeviceLost += new BlueToolsEventHandler(m_network_DeviceLost);

				lStackVersion.Text += m_network.StackVersion.ToString();
			} 
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message);
				discoverDevices.Enabled = false;
			}
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );

			// Dispose must be called for the application to exit!
			Manager.GetManager().Dispose();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem12 = new System.Windows.Forms.MenuItem();
            this.menuItem13 = new System.Windows.Forms.MenuItem();
            this.menuItem32 = new System.Windows.Forms.MenuItem();
            this.menuItem33 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem14 = new System.Windows.Forms.MenuItem();
            this.menuItem15 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.menuItem16 = new System.Windows.Forms.MenuItem();
            this.menuItem17 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem18 = new System.Windows.Forms.MenuItem();
            this.menuItem19 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem20 = new System.Windows.Forms.MenuItem();
            this.menuItem21 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.menuItem22 = new System.Windows.Forms.MenuItem();
            this.menuItem23 = new System.Windows.Forms.MenuItem();
            this.menuItem34 = new System.Windows.Forms.MenuItem();
            this.menuItem35 = new System.Windows.Forms.MenuItem();
            this.menuItem36 = new System.Windows.Forms.MenuItem();
            this.menuItem37 = new System.Windows.Forms.MenuItem();
            this.menuItem38 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem24 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem28 = new System.Windows.Forms.MenuItem();
            this.menuItem29 = new System.Windows.Forms.MenuItem();
            this.menuItem25 = new System.Windows.Forms.MenuItem();
            this.menuItem26 = new System.Windows.Forms.MenuItem();
            this.menuItem27 = new System.Windows.Forms.MenuItem();
            this.menuItem30 = new System.Windows.Forms.MenuItem();
            this.menuItem31 = new System.Windows.Forms.MenuItem();
            this.discoverDevices = new System.Windows.Forms.Button();
            this.deviceList = new System.Windows.Forms.ListBox();
            this.serviceOutput = new System.Windows.Forms.TextBox();
            this.lStatus = new System.Windows.Forms.Label();
            this.lStackVersion = new System.Windows.Forms.Label();
            this.closeConnection = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            // 
            // mainMenu
            // 
            this.mainMenu.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.MenuItems.Add(this.menuItem2);
            this.menuItem1.MenuItems.Add(this.menuItem3);
            this.menuItem1.Text = "MENU";
            // 
            // menuItem2
            // 
            this.menuItem2.MenuItems.Add(this.menuItem6);
            this.menuItem2.MenuItems.Add(this.menuItem7);
            this.menuItem2.MenuItems.Add(this.menuItem8);
            this.menuItem2.MenuItems.Add(this.menuItem9);
            this.menuItem2.MenuItems.Add(this.menuItem10);
            this.menuItem2.MenuItems.Add(this.menuItem11);
            this.menuItem2.MenuItems.Add(this.menuItem34);
            this.menuItem2.Text = "Bedroom";
            // 
            // menuItem6
            // 
            this.menuItem6.MenuItems.Add(this.menuItem12);
            this.menuItem6.MenuItems.Add(this.menuItem13);
            this.menuItem6.MenuItems.Add(this.menuItem32);
            this.menuItem6.MenuItems.Add(this.menuItem33);
            this.menuItem6.Text = "Light1";
            // 
            // menuItem12
            // 
            this.menuItem12.Checked = true;
            this.menuItem12.Text = "On";
            this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
            // 
            // menuItem13
            // 
            this.menuItem13.Text = "Off";
            this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
            // 
            // menuItem32
            // 
            this.menuItem32.Text = "Increase";
            this.menuItem32.Click += new System.EventHandler(this.menuItem32_Click);
            // 
            // menuItem33
            // 
            this.menuItem33.Text = "Decrease";
            this.menuItem33.Click += new System.EventHandler(this.menuItem33_Click);
            // 
            // menuItem7
            // 
            this.menuItem7.MenuItems.Add(this.menuItem14);
            this.menuItem7.MenuItems.Add(this.menuItem15);
            this.menuItem7.Text = "Stereo";
            // 
            // menuItem14
            // 
            this.menuItem14.Text = "On";
            this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
            // 
            // menuItem15
            // 
            this.menuItem15.Text = "Off";
            this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
            // 
            // menuItem8
            // 
            this.menuItem8.MenuItems.Add(this.menuItem16);
            this.menuItem8.MenuItems.Add(this.menuItem17);
            this.menuItem8.Text = "TV";
            // 
            // menuItem16
            // 
            this.menuItem16.Text = "On";
            this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
            // 
            // menuItem17
            // 
            this.menuItem17.Text = "Off";
            this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click);
            // 
            // menuItem9
            // 
            this.menuItem9.MenuItems.Add(this.menuItem18);
            this.menuItem9.MenuItems.Add(this.menuItem19);
            this.menuItem9.Text = "Radio";
            // 
            // menuItem18
            // 
            this.menuItem18.Text = "On";
            this.menuItem18.Click += new System.EventHandler(this.menuItem18_Click);
            // 
            // menuItem19
            // 
            this.menuItem19.Text = "Off";
            this.menuItem19.Click += new System.EventHandler(this.menuItem19_Click);
            // 
            // menuItem10
            // 
            this.menuItem10.MenuItems.Add(this.menuItem20);
            this.menuItem10.MenuItems.Add(this.menuItem21);
            this.menuItem10.Text = "Computer";
            // 
            // menuItem20
            // 
            this.menuItem20.Text = "On";
            this.menuItem20.Click += new System.EventHandler(this.menuItem20_Click);
            // 
            // menuItem21
            // 
            this.menuItem21.Text = "Off";
            this.menuItem21.Click += new System.EventHandler(this.menuItem21_Click);
            // 
            // menuItem11
            // 
            this.menuItem11.MenuItems.Add(this.menuItem22);
            this.menuItem11.MenuItems.Add(this.menuItem23);
            this.menuItem11.Text = "Fan";
            // 
            // menuItem22
            // 
            this.menuItem22.Text = "On";
            this.menuItem22.Click += new System.EventHandler(this.menuItem22_Click);
            // 
            // menuItem23
            // 
            this.menuItem23.Text = "Off";
            this.menuItem23.Click += new System.EventHandler(this.menuItem23_Click);
            // 
            // menuItem34
            // 
            this.menuItem34.MenuItems.Add(this.menuItem35);
            this.menuItem34.MenuItems.Add(this.menuItem36);
            this.menuItem34.MenuItems.Add(this.menuItem37);
            this.menuItem34.MenuItems.Add(this.menuItem38);
            this.menuItem34.Text = "Light2";
            // 
            // menuItem35
            // 
            this.menuItem35.Text = "On";
            this.menuItem35.Click += new System.EventHandler(this.menuItem35_Click);
            // 
            // menuItem36
            // 
            this.menuItem36.Text = "Off";
            this.menuItem36.Click += new System.EventHandler(this.menuItem36_Click);
            // 
            // menuItem37
            // 
            this.menuItem37.Text = "Increase";
            this.menuItem37.Click += new System.EventHandler(this.menuItem37_Click);
            // 
            // menuItem38
            // 
            this.menuItem38.Text = "Decrease";
            this.menuItem38.Click += new System.EventHandler(this.menuItem38_Click);
            // 
            // menuItem3
            // 
            this.menuItem3.MenuItems.Add(this.menuItem24);
            this.menuItem3.MenuItems.Add(this.menuItem25);
            this.menuItem3.Text = "Restroom";
            // 
            // menuItem24
            // 
            this.menuItem24.MenuItems.Add(this.menuItem4);
            this.menuItem24.MenuItems.Add(this.menuItem5);
            this.menuItem24.MenuItems.Add(this.menuItem28);
            this.menuItem24.MenuItems.Add(this.menuItem29);
            this.menuItem24.Text = "Light3";
            // 
            // menuItem4
            // 
            this.menuItem4.Text = "On";
            this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
            // 
            // menuItem5
            // 
            this.menuItem5.Text = "Off";
            this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
            // 
            // menuItem28
            // 
            this.menuItem28.Text = "Increase";
            this.menuItem28.Click += new System.EventHandler(this.menuItem28_Click);
            // 
            // menuItem29
            // 
            this.menuItem29.Text = "Decrease";
            this.menuItem29.Click += new System.EventHandler(this.menuItem29_Click);
            // 
            // menuItem25
            // 
            this.menuItem25.MenuItems.Add(this.menuItem26);
            this.menuItem25.MenuItems.Add(this.menuItem27);
            this.menuItem25.MenuItems.Add(this.menuItem30);
            this.menuItem25.MenuItems.Add(this.menuItem31);
            this.menuItem25.Text = "Light4";
            // 
            // menuItem26
            // 
            this.menuItem26.Text = "On";
            this.menuItem26.Click += new System.EventHandler(this.menuItem26_Click);
            // 
            // menuItem27
            // 
            this.menuItem27.Text = "Off";
            this.menuItem27.Click += new System.EventHandler(this.menuItem27_Click);
            // 
            // menuItem30
            // 
            this.menuItem30.Text = "Increase";
            this.menuItem30.Click += new System.EventHandler(this.menuItem30_Click);
            // 
            // menuItem31
            // 
            this.menuItem31.Text = "Decrease";
            this.menuItem31.Click += new System.EventHandler(this.menuItem31_Click);
            // 
            // discoverDevices
            // 
            this.discoverDevices.Location = new System.Drawing.Point(10, 87);
            this.discoverDevices.Size = new System.Drawing.Size(100, 20);
            this.discoverDevices.Text = "Discover";
            this.discoverDevices.Click += new System.EventHandler(this.discoverDevices_Click);
            // 
            // deviceList
            // 
            this.deviceList.Location = new System.Drawing.Point(10, 9);
            this.deviceList.Size = new System.Drawing.Size(204, 72);
            this.deviceList.SelectedIndexChanged += new System.EventHandler(this.deviceList_SelectedIndexChanged);
            // 
            // serviceOutput
            // 
            this.serviceOutput.Location = new System.Drawing.Point(10, 129);
            this.serviceOutput.Multiline = true;
            this.serviceOutput.ReadOnly = true;
            this.serviceOutput.Size = new System.Drawing.Size(204, 89);
            this.serviceOutput.TextChanged += new System.EventHandler(this.serviceOutput_TextChanged);
            // 
            // lStatus
            // 
            this.lStatus.Location = new System.Drawing.Point(10, 110);
            this.lStatus.Size = new System.Drawing.Size(204, 16);
            this.lStatus.Text = "Click Discover!";
            // 
            // lStackVersion
            // 
            this.lStackVersion.Location = new System.Drawing.Point(10, 221);
            this.lStackVersion.Size = new System.Drawing.Size(204, 19);
            this.lStackVersion.ParentChanged += new System.EventHandler(this.lStackVersion_ParentChanged);
            // 
            // closeConnection
            // 
            this.closeConnection.Enabled = false;
            this.closeConnection.Location = new System.Drawing.Point(114, 87);
            this.closeConnection.Size = new System.Drawing.Size(100, 20);
            this.closeConnection.Text = "Disconnect";
            this.closeConnection.Click += new System.EventHandler(this.closeConnection_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(142, 108);
            this.button1.Size = new System.Drawing.Size(72, 20);
            this.button1.Text = "Load XML";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(226, 240);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.closeConnection);
            this.Controls.Add(this.lStackVersion);
            this.Controls.Add(this.lStatus);
            this.Controls.Add(this.serviceOutput);
            this.Controls.Add(this.deviceList);
            this.Controls.Add(this.discoverDevices);
            this.Menu = this.mainMenu;
            this.MinimizeBox = false;
            this.Text = "Controller";
            this.Load += new System.EventHandler(this.MainForm_Load);

		}
		#endregion          

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void discoverDevices_Click(object sender, System.EventArgs e)
		{
			try
			{
				// Start looking for devices on the network
				// Use Network.DiscoverDevices() if you don't want to use events.
				m_network.DiscoverDevicesAsync();
			} 
			catch (BlueToolsException exc)
			{
				MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
			}
		}

		private void network_DeviceDiscoveryStarted(object sender, BlueToolsEventArgs eventArgs)
		{
			// Search for devices on the network started

			//serviceList.Items.Clear();
			discoverDevices.Enabled = false;

			lStatus.Text = "Discovering devices...";
		}

		private void network_DeviceDiscovered(object sender, BlueToolsEventArgs eventArgs)
		{
			// A new device was discovered!
			// Note that this event is only called for NEW devices on the network

			// Use Network.Devices for a complete list of discovered devices.

			RemoteDevice device = (RemoteDevice)((DiscoveryEventArgs)eventArgs).Discovery;
			deviceList.Items.Add(device);
		}

		private void network_DeviceDiscoveryCompleted(object sender, BlueToolsEventArgs eventArgs)
		{
			// Search for devices on the network ended.
			lStatus.Text = "Click on a Device!";
			discoverDevices.Enabled = true;
		}


		private void deviceList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Get the remote device that is currently selected
			RemoteDevice device = (RemoteDevice)deviceList.SelectedItem;

			if(device != null)
			{	
				try
				{
					// Disable the device list so the user doesn't attempt to select a device while
					// the service lookup is pending
					deviceList.Enabled = false;

					// Remove the existing items from the service list
					//serviceList.Items.Clear();

					// Add a DiscoveryListener so we get service discovery events
					device.ServiceDiscovered += new BlueToolsEventHandler(device_ServiceDiscovered);

					// Add a DiscoveryListener so we get service discovery completion events
					device.ServiceDiscoveryCompleted += new BlueToolsEventHandler(device_ServiceDiscoveryCompleted);

					device.Error += new BlueToolsEventHandler(device_Error);

					// Cancel any ongoing device discovery
					m_network.CancelDeviceDiscovery();

					// Discover all services offered by the device
					// Use e.g. ServiceType.SerialPort to list only serial port services
					// Use Device.DiscoverServices() if you don't want to use events.
					device.DiscoverServicesAsync(ServiceType.RFCOMM);

					// Add already discovered services to list box (for this device) 
					//serviceList.Items.Clear();
                    Service[] services = device.Services;
					foreach(RemoteService service in services)
					{
                        if(service.Name=="BTpmp") Connectservice(service);
						//serviceList.Items.Add(service);
					}

					lStatus.Text = "Searching for Services...";
				} 
				catch (Exception exc)
				{
					MessageBox.Show(exc.Message);
				}
			}
		}

		private void device_ServiceDiscovered(object sender, BlueToolsEventArgs eventArgs)
		{
			// A new serive found for device!
			// Note that this event is only called for NEW services found
			// Use Device.Services for a complete list of services for device

			// Get the service associated with the discovery event
			Service service = (Service)((DiscoveryEventArgs)eventArgs).Discovery;
            if (service.Name == "BTpmp") Connectservice((RemoteService)service);
			// Add the newly discovered service to the service list
			//serviceList.Items.Add(service);
		}

		private void device_ServiceDiscoveryCompleted(object sender, BlueToolsEventArgs eventArgs)
		{
			// All services for device discovered"

			// Get the remote device that raised the event
			RemoteDevice device = (RemoteDevice)sender;

			// You find an array of all found services here. Or by using Device.Services
			// Note that all services are RemoteService
			// Service[] services = (Service[])((DiscoveryEventArgs)eventArgs).Discovery;

			// Remove event handlers
			device.ServiceDiscovered -= new BlueToolsEventHandler(device_ServiceDiscovered);
			device.ServiceDiscoveryCompleted -= new BlueToolsEventHandler(device_ServiceDiscoveryCompleted);

			// Reenable the device list
			deviceList.Enabled = true;

			lStatus.Text = "Click on a Service";
		}

        private void Connectservice(RemoteService RS)
		//private void serviceList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Close any connections that are open
			//

			if(currentService != null)
			{
				currentStream.Close();

				currentService	= null;
				currentStream	= null;
			}
			
			// Attempt to connect to the service
			//

			// Get service object from list box
			currentService = RS;
            

			try
			{
				// Connect to service by reading its Stream
				currentStream = currentService.Stream;

				currentStream.BeginRead(m_buffer, 0, m_buffer.Length, new AsyncCallback(readCallback), currentStream);

				closeConnection.Enabled		= true;
                menuItem1.Enabled = true;
				//serviceList.Enabled			= false;
				lStatus.Text = "Connected";
			} 
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message);
				currentService = null;
			}
		}

		private void readCallback(IAsyncResult result)
		{
			byte[] buffer = null;

			// result is always a BlueToolsAsyncResult object
			BlueToolsAsyncResult blueAsyncResult = (BlueToolsAsyncResult) result;

			// We passed on buffer as custom object, you can pass on any object here. We passed the stream object
			ServiceStream stream = (ServiceStream) blueAsyncResult.AsyncState;
			
			// The buffer used for reading can be found in the result object.
			buffer = blueAsyncResult.Buffer;

			try
			{
				// EndRead() must always be called!
				// If stream has been closed due to an error, we'll have an excpetion here
				int len = stream.EndRead(result);

				System.Text.ASCIIEncoding enc = new ASCIIEncoding(); 
				string str = enc.GetString(buffer, 0, len);

				serviceOutput.Text = str;

				// Start new async read
				stream.BeginRead(m_buffer, 0, m_buffer.Length, new AsyncCallback(readCallback), stream);
			}
			catch(ObjectDisposedException ex)
			{
				// Thrown if stream has been closed.
				closeConnection.Enabled = false;
                menuItem1.Enabled = false;
				//serviceList.Enabled = true;

				lStatus.Text = ex.Message;
			}
		}
																																								  
		private void closeConnection_Click(object sender, System.EventArgs e)
		{
			if(currentService != null)
			{
				currentStream.Close();
				currentService = null;
				currentStream = null;
			}

			closeConnection.Enabled = false;
            menuItem1.Enabled = false;
			//serviceList.Enabled = true;
			lStatus.Text = "OK";
		}

		private void device_Error(object sender, BlueToolsEventArgs eventArgs)
		{
			Franson.BlueTools.ErrorEventArgs errorEventArgs = (Franson.BlueTools.ErrorEventArgs)eventArgs;
			MessageBox.Show(errorEventArgs.ErrorCode + ": " + errorEventArgs.Message);
		}

		private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Dispose();
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
		
		}

		private void m_network_DeviceLost(object sender, BlueToolsEventArgs eventArgs)
		{
			RemoteDevice device = (RemoteDevice)((DiscoveryEventArgs)eventArgs).Discovery;
			deviceList.Items.Remove(device);
		}

        void SendString(string str)
        {
            System.Text.ASCIIEncoding enc = new ASCIIEncoding();
            byte[] b = enc.GetBytes(str.ToCharArray());
            currentStream.Write(b, 0, b.Length);
        }

        private void menuItem12_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light1_On");
        }

        private void menuItem13_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light1_Off");
        }

        private void menuItem32_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light1_Inc");
        }

        private void menuItem33_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light1_Dec");
        }
        private void menuItem14_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Stereo_On");
        }

        private void menuItem15_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Stereo_Off");
        }

        private void menuItem16_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_TV_On");
        }

        private void menuItem17_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_TV_Off");
        }

        private void menuItem18_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Radio_On");
        }

        private void menuItem19_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Radio_Off");
        }

        private void menuItem20_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Computer_On");
        }

        private void menuItem21_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Computer_Off");
        }

        private void menuItem22_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Fan_On");
        }

        private void menuItem23_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Fan_Off");
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light3_On");
        }

        private void menuItem5_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light3_Off");
        }

        private void menuItem28_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light3_Inc");
        }

        private void menuItem29_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light3_Dec");
        }

        private void menuItem26_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light4_On");
        }

        private void menuItem27_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light4_Off");
        }

        private void menuItem30_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light4_Inc");
        }

        private void menuItem31_Click(object sender, EventArgs e)
        {
            SendString("Restroom_Light4_Dec");
        }

        private void menuItem35_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light2_On");
        }

        private void menuItem36_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light2_Off");
        }

        private void menuItem37_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light2_Inc");
        }

        private void menuItem38_Click(object sender, EventArgs e)
        {
            SendString("Bedroom_Light2_Dec");
        }

        private void serviceOutput_TextChanged(object sender, EventArgs e)
        {

        }

        struct Item
        {
            public string command;
            public MenuItem menu;
        }

        ArrayList items = new ArrayList();

        private void makemenu(MenuItem parentmenu,XmlElement xml)
        {
            MenuItem menu = new MenuItem();
            menu.Text = xml.Attributes["name"].Value;            
            parentmenu.MenuItems.Add(menu);
            try
            {
                foreach (XmlElement node in xml.ChildNodes)
                {
                    makemenu(menu, node);
                }
            }
            catch
            {
                menu.Click += new EventHandler(menu_Click);
                Item item = new Item();
                item.menu = menu;
                item.command = xml.InnerText;
                items.Add(item);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XmlDocument xml = new XmlDocument();
            try
            {
                xml.Load("menu.xml");
                foreach (XmlElement node in xml.DocumentElement.ChildNodes)
                {
                    makemenu(menuItem1, node);
                }
                MessageBox.Show("Complete");
            }
            catch
            {
                MessageBox.Show("Can not load menu.xml");
            }
        }

        void menu_Click(object sender, EventArgs e)
        {
            MenuItem menu = (MenuItem)sender;

            /*string str = menu.Text;
            try
            {
                menu = (MenuItem)(menu.Parent);
                while (!menu.Equals(menuItem1))
                {
                    str = menu.Text + "_" + str;
                    menu = (MenuItem)(menu.Parent);
                }
            }
            catch { }
            MessageBox.Show(str);*/

            foreach (Item item in items)
            {
                if (menu.Equals(item.menu)) MessageBox.Show("command:" + item.command);
            }
        }

        private void lStackVersion_ParentChanged(object sender, EventArgs e)
        {

        }


	}
}
