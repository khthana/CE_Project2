<?
session_start();
$_SESSION[level];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��ͧ��ش�Ҥ�Ԫ����Ǥ���������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="style1.css" rel="stylesheet"  type="text/css" />
</head>
<?
	if($_SESSION["level"]==1)
	{
	echo"
		<frameset rows=\"106,*\" cols=\"*\" framespacing=\"0\"  frameborder =\"no\"  bordercolor=\"#FFFFFF\" border=\"0\" >
			<frame src=\"head.php\" frameborder=\"no\" scrolling=\"no\" noresize bordercolor=\"#FFFFFF\" />
			<frameset cols=\"171,*\" framespacing=\"0\" frameborder=\"no\" bordercolor=\"#FFFFFF\" border=\"0\">
				<frame src=\"admin/menuadmin.php\"  noresize scrolling=\"no\" />
				<frame src=\"admin/empty.php\" name =\"show\" />
			 </frameset>
		</frameset>";
	}
	else if($_SESSION["level"]==2)
	{
	echo"
		<frameset rows=\"106,*\" cols=\"*\" framespacing=\"0\"  frameborder =\"no\"  bordercolor=\"#FFFFFF\"border=\"0\">
			<frame src=\"head.php\" frameborder=\"no\" scrolling=\"no\" noresize bordercolor=\"#FFFFFF\" />
			<frameset cols=\"171,*\" framespacing=\"0\" frameborder=\"no\" bordercolor=\"#FFFFFF\" border=\"0\">
				<frame src=\"user/menustudent.php\"  noresize scrolling=\"no\" />
				<frame src=\"user/news.php\" name =\"show\" />
			 </frameset>
		</frameset>";
	}
	else if($_SESSION["level"]==3)
	{
	echo"
		<frameset rows=\"106,*\" cols=\"*\" framespacing=\"0\"  frameborder =\"no\"  bordercolor=\"#FFFFFF\"border=\"0\">
			<frame src=\"head.php\" frameborder=\"no\" scrolling=\"no\" noresize bordercolor=\"#FFFFFF\" />
			<frameset cols=\"171,*\" framespacing=\"0\" frameborder=\"no\" bordercolor=\"#FFFFFF\" border=\"0\">
				<frame src=\"librarian/menuadmin.php\"  noresize scrolling=\"no\" />
				<frame src=\"librarian/newslibrarian.php\" name =\"show\" />
			 </frameset>
		</frameset>";
	}
	else
	{
echo"
		<frameset rows=\"106,*\" cols=\"*\" framespacing=\"0\"  frameborder =\"no\"  bordercolor=\"#FFFFFF\" border=\"0\" >
			<frame src=\"head.php\" frameborder=\"no\" scrolling=\"no\" noresize bordercolor=\"#FFFFFF\" />
			<frameset cols=\"171,*\" framespacing=\"0\" frameborder=\"no\" bordercolor=\"#FFFFFF\" border=\"0\" >
				<frame src=\"all/menu.php\"  noresize scrolling=\"no\" />
				<frame src=\"all/news.php\" name =\"show\"  />
			 </frameset>
		</frameset>";
	}
?>
</html>

			