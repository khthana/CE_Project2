<?
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>���Ǻ�ó��ѡ��</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr> 
    <td width="613" height="228" align="left" valign="top"><div align="left"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ><img src="image/chapass.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"><a href="marenewslibrarian.php"><img src="image/buttom_more.gif" width="52" height="20" border="0"></a></div></td>
          </tr>
          <?
			$today=date("Y-m-d");
			$strSQL ="SELECT * FROM  reservation WHERE receive_status='reserv' ORDER BY receive_date ASC ";
			$result = mysql_query($strSQL,$conn) or  die ("�������ö���͡������ŧ���ҧ��");
		  ?>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="4%" background="image/center_top.jpg" >&nbsp;</td>
            <td width="9%" background="image/center_top.jpg" >&nbsp;</td>
            <td width="15%" background="image/center_top.jpg" >&nbsp;</td>
            <td width="58%" background="image/center_top.jpg" >&nbsp;</td>
            <td width="14%" background="image/center_top.jpg">&nbsp;</td>
          </tr>
          <? 
		  $bg=1;
		  while($rs=mysql_fetch_array($result))
		  {
		  		if($bg<20)
		  		{
				$str ="SELECT * FROM  informationmedia WHERE serial='$rs[serial]' ";
				$re = mysql_query($str,$conn) or  die ("�������ö���͡������ŧ���ҧ��");
				$rm = mysql_fetch_array($re);
				$receive_date= explode("-",$rs["receive_date"]);
					if($rs[receive_date]==$today)
					{if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
					?>
          <tr> 
            <td >&nbsp;</td>
            <td >&nbsp;</td>
            <td width="15%" >&nbsp;</td>
            <td width="58%" >&nbsp;</td>
            <td width="14%">&nbsp;</td>
          </tr>
          <?
					}
					elseif($rs[receive_date]>$today)
					{if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
					?>
          <tr> 
            <td width="4%" >&nbsp;</td>
            <td >&nbsp;</td>
            <td width="15%" >&nbsp;</td>
            <td width="58%" >&nbsp;</td>
            <td width="14%">&nbsp;</td>
          </tr>
          <?
					}
					else
					{
									$str ="UPDATE informationmedia
										 SET  media_status='shelve' 
									 	WHERE serial='$rs[serial]' "; 
						 			$result=mysql_query($str,$conn);
									$str ="UPDATE reservation
										 SET  receive_status ='cancel' 
									 	WHERE serial='$rs[serial]' "; 
						 			$result=mysql_query($str,$conn);
					}
				}  
				$bg=$bg+1;
		  }
		 ?>
          <tr> 
            <td colspan="5">&nbsp;</td>
          </tr>
        </table>
      </div></td>
     </tr>
</table>
</BODY>
</HTML>
