<html>
<head>
<title>logout</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="style1.css" rel="stylesheet"  type="text/css" />
</head>
<body>
<?		
session_start();
				
unset($_SESSION["login1"]);
unset($_SESSION["login2"]);
unset($_SESSION["login3"]);
unset($_SESSION["date"]);
unset($_SESSION["level"]);

unset($_SESSION["isbn"]);
unset($_SESSION["author"]);
unset($_SESSION["author2"]);
unset($_SESSION["author3"]);
unset($_SESSION["title"]);
unset($_SESSION["title2"]);
unset($_SESSION["printing"]);
unset($_SESSION["year"]);
unset($_SESSION["page"]);
unset($_SESSION["subject"]);
unset($_SESSION["subject2"]);
unset($_SESSION["subject3"]);
unset($_SESSION["series"]);
unset($_SESSION["mediatype"]);
unset($_SESSION["mediastatus"]);
unset($_SESSION["description"]);

unset($_SESSION["type_name"]);		
unset($_SESSION["shortname_type"]);

unset($_SESSION["level_name"]);
unset($_SESSION["limit_day"]);
unset($_SESSION["limit_book"]);

unset($_SESSION["mem_name"]	);
unset($_SESSION["mem_pass"]);		
unset($_SESSION["mem_fullname"]);
unset($_SESSION["mem_tel"]);
unset($_SESSION["mem_email"]);
unset($_SESSION["mem_status"]);
unset($_SESSION["mem_level"] );
unset($_SESSION["mem_comment"]);

session_destroy();


echo"<td><center>
<font color=\"#009900\" size=\"4\"><strong>�͡�ҡ�к�����  ��س����ѡ����</strong></font><br><br>
</center></td>
<META HTTP-EQUIV=\"Refresh\" CONTENT=\"1; URL=../index.php\">";
?>
</body>
</html>
