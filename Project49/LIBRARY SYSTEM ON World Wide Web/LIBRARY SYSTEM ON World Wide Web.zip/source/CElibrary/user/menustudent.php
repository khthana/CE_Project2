<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> menu </TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="style1.css" rel="stylesheet"  type="text/css" />
</HEAD>

<BODY bgcolor="#FFFFFF" topmargin="0" leftmargin="0">
<table width="162" height="261" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    
    <td width="92%" align="left" valign="top"><table width="171" height="1044"  border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="171" height="1044" align="left" valign="top" background="image/menu.jpg"><table width="100%" border="0" cellspacing="2" cellpadding="0">
              <tr> 
                <td  height="20" colspan="2"><font color="#996600"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<font color="#663333">&nbsp;CE 
                  Library KMITL</font></strong></font></td>
              </tr>
              <tr bgcolor="#663333"> 
                <td colspan="3"><div align="center"><font color="#FF6600"><strong><font color="#FF9900" size="2">���</font><font color="#FF9900">�</font></strong></font></div></td>
              </tr>
              <tr> 
                <td width="7%" height="23">&nbsp;</td>
                <td width="90%" height="23" background="image/hhh.gif">&nbsp;<a href="../index.php" target="_parent">˹����ѡ</a></td>
              </tr>
              <tr> 
                <td height="11">&nbsp;</td>
                <td width="90%" height="23" background="image/hhh.gif">&nbsp;<a href="chkborr_return.php" target="show">��Ǩ�ͺ�������׹</a></td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td   height="23" background="image/hhh.gif">&nbsp;<a href="indexreserve.php" target="show">�ͧ</a></td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td  height="23" background="image/hhh.gif">&nbsp;<a href="indexsearch.php" target="show">����</a></td>
              </tr>
              <tr bgcolor="#663333"> 
                <td  height="3" colspan="2" ><div align="center"><font color="#FF9900" size="2"><strong>�����ҹ�к�</strong></font></div></td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td  height="23" background="image/hhh.gif"><a href="editmember.php" target="show">&nbsp;��䢻���ѵ</a>�</td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td  height="23" background="image/hhh.gif"><a href="logout.php" target="_parent">&nbsp;Logout</a></td>
              </tr>
              <tr bgcolor="#663333"> 
                <td  height="3" colspan="2"><div align="center"><font color="#FF9900" size="2"><strong>����˹��ʹ�</strong></font></div></td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td  height="23" background="image/hhh.gif">&nbsp;<a href="http://www.ce.kmitl.ac.th" target="_blank">����Ҥ�Ԫ��</a></td>
              </tr>
              <tr> 
                <td  height="23">&nbsp;</td>
                <td  height="23" background="image/hhh.gif">&nbsp;<a href="http://www.ce.kmitl.ac.th" target="_blank">���ʶҺѹ�</a></td>
              </tr>
              <tr> 
                <td height="20">&nbsp;</td>
                <td  height="20">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
<div align="left"></div>
</BODY>
</HTML>
