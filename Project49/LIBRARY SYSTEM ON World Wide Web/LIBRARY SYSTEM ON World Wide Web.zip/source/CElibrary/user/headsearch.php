<?
session_start();
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>����</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="95" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr> 
    <td width="100%" height="68"  align="left" valign="top"><div align="left"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ><img src="image/search.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"></div></td>
          </tr>
        </table>
      </div></td>
  </tr>
  <tr> 
    <td>
	    <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <form name="searchmedia" method="post" action="showmedia.php" target="viwe">
            <td width="11%"><strong>&nbsp;<font color="#FF6600" size="2">�Ӥ��� 
              : </font></strong></td>
            <td width="24%"><font color="#FF6600" size="2"><strong> 
              <input type="text" name="search">
              </strong></font></td>
            <td width="29%"><strong><font color="#FF6600" size="2">���ҵ�� : 
              <select name="media" >
                <option value="title">����˹ѧ���</option>
                <option value="aurthor">���ͼ����</option>
                <option value="subject" selected>�������ͧ</option>
                <option value="call_number">�Ţ���¡˹ѧ���</option>
                <option value="isbn">ISBN</option>
              </select>
              </font></strong></td>
            <td width="12%"><input type="submit" name="submit" value="   ����   "></td>
            <td width="24%">&nbsp;</td>
          </form>
      </table>
     
    </td>
	  
  </tr>
</table>
</BODY>
</HTML>
