<?
session_start();
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>����</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="108" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr> 
    <td width="100%" height="68"  align="left" valign="top"><div align="left"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ><img src="image/rev.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"></div></td>
          </tr>
        </table>
      </div></td>
  </tr>
  <?
  $strSQL ="SELECT * 	 FROM  reservation 
									 WHERE  user_id='$_SESSION[login1] ' && receive_status ='reserv'   "; 
  $result=mysql_query($strSQL,$conn);
  $row=mysql_num_rows($result);																																													
  if( $row>0)
  {
  ?>
   <tr> 
    <td width="100%" align="left" valign="top"><div align="left"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ></td>
            <td width="47%" ><div align="center"><strong><font color="#FF0000" size="2">�������ö�ͧ����˹ѧ��ͨͧ��ҧ����</font></strong></div></td>
            <td width="23%" ><div align="right"></div></td>
          </tr>
        </table>
      </div></td>
  </tr>
  <?
    }
	else
	{
	?>
	<tr> 
    <td width="100%" height="39" align="left" valign="top"><div align="left"> 
	<form name="form1" method="post" action="showreserve.php" target ="viwe">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
              <td width="39%" ><strong><font color="#FF6600" size="2">&nbsp;&nbsp;�Ţ���¡���� 
                : 
                <input type="text" name="reservenumber">
                </font></strong></td>
            <td width="38%" ><div align="left"><strong>
                  <input type="submit" name="Submit" value="  �ͧ  ">
                  </strong></div></td>
            <td width="23%" ><div align="right"></div></td>
          </tr>
        </table>
	</form>
      </div></td>
  </tr>
  <?
	}
  
 ?>
  
  
 </table>
</BODY>
</HTML>
