<?
session_start();
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>����</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="546" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr> 
    <td width="613" height="174" align="left" valign="top"><div align="left"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
	   <td colspan="3" valign="top">
	 	<table width="100%" border="0" cellspacing="0" cellpadding="0" >
								
                <?
				$borrowname=$_SESSION["login1"] ;
				$day=date("Y-m-d");
				include("popborrow.php");
			$strSQL ="SELECT borrow_history.serial ,borrow_history.must_return_date  
				FROM  borrow_history  
				LEFT JOIN borrow ON borrow_history.borrow_id = borrow.borrow_id 
				WHERE  borrow.user_id='$borrowname' &&   borrow_history.penalty  IS NULL  && borrow_history.must_return_date='$day'"; 
			$result=mysql_query($strSQL,$conn);
													$bg=0;
													$countrow=mysql_num_rows($result);
								if($countrow>0)
								{	
								?><tr> 
                  				
                  <td width="77%" background="image/center_top.jpg"><strong><font color="#660000" size="2">&nbsp;���ͷ��֧��˹���</font></strong></td>
                  				<td width="20%" background="image/center_top.jpg"><strong><font size="2">&nbsp;<font color="#660000">�ѹ�׹</font></font></strong></td>
                				</tr><?
                 				
													while($rs=mysql_fetch_array($result))
															{
															$str ="SELECT * FROM informationmedia  
																		WHERE  serial=$rs[serial] "; 
															$re=mysql_query($str,$conn);
															$rm=mysql_fetch_array($re);
															
																																																						
																	echo "<tr>";
																	if(($bg%2)==0)
																	{
																		$begindate= explode("-",$rs["must_return_date"]);
																	    echo "<td bgcolor=\"#E7EBEA\"><font color=\"#FF0000\" size=\"2\">$rm[title]</font ></td>";			
				  															if(	$rs[must_return_date]==$today)
																			{
																			echo "<td	bgcolor=\"#E7EBEA\"><font color=\"#cc0000\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]<img src=\"image/new.gif\"></font></td>";
																			}
																	}
																	else
																	{
																	$begindate= explode("-",$rs["must_return_date"]);
																	echo "<td ><font color=\"#FF0000\" size=\"2\">$rm[title]></font ></td>";			
				  															if(	$rs[must_return_date]==$today)
																			{																								
																			echo "<td	><font color=\"#cc0000\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]<img src=\"image/new.gif\"></font></td>";
																			}
																	}		
																	$bg=$bg+1;
																	  echo " </tr>";
																 }	
															
							}
			 ?>
              </table> 
			  </td>
			  </tr>		
          <tr> 
            <td width="30%" ><img src="image/head_news.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"><a href="morenews.php"><img src="image/buttom_more.gif" width="52" height="20" border="0"></a></div></td>
          </tr>
          <?
			if(!isset($_SESSION["newsstatus"]))
			{
			$today=date("Y-m-d");
			$strSQL ="SELECT * FROM  news WHERE status=0  && end_date > '$today' ORDER BY begin_date DESC ";
			}
			else
			{
			$today=date("Y-m-d");
			$strSQL ="SELECT * FROM  news   WHERE status=0 && end_date > '$today' ORDER BY begin_date DESC ";
			}
			$result = mysql_query($strSQL,$conn) or  die ("�������ö����������ŧ���ҧ��");
		  
        	$bg=0;

			while($rs=mysql_fetch_array($result))
			{
				if($bg<= 15)//�ӹǹ ���Ƿ���ʴ���˹�����
				{
					echo "<tr>";
					if(($bg%2)==0)
						{
							if($bg<=3)
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td height=\"15\" 	bgcolor=\"#E7EBEA\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a><img src=\"image/new.gif\"></font></td> ";
								echo"<td height=\"15\" bgcolor=\"#E7EBEA\" ><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
							else
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td height=\"15\" 	bgcolor=\"#E7EBEA\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a></font></td> ";
								echo"<td height=\"15\" bgcolor=\"#E7EBEA\" ><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
			  			}		
					else
						{
							if($bg<=3)
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a><img src=\"image/new.gif\"></font></td> ";
								echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
							else
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a></font></td> ";
								echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
						}
						$bg=$bg+1;
				}

			
			}
								
			?>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ><img src="image/head_media.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"></div></td>
          </tr>
          <?
         $strSQL ="SELECT * FROM  informationmedia ORDER BY date DESC ";
		 $result = mysql_query($strSQL,$conn);
		 $bg=0;	 
			while($rs=mysql_fetch_array($result))
		 	{
			 if($bg<=15)
		 	{
				if($bg<=4)
				{
					if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
					$begindate= explode("-",$rs["date"]);
					echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"show_media.php?mediaid=$rs[serial]\" target=\"_bank\" > $rs[title] </a><img src=\"image/new.gif\"></font></td> ";
					echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
					echo "</tr>";
				}
				else
				{
					if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
					$begindate= explode("-",$rs["date"]);
					echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"show_media.php?mediaid=$rs[serial]\" target=\"_bank\" > $rs[title] </a></font></td> ";
					echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
					echo "</tr>";         
				}		
			}
			$bg=$bg+1;
		}		  
		  ?>
        </table>
      </div></td>
     </tr>
	 
	   
			  
</table>
</BODY>
</HTML>
