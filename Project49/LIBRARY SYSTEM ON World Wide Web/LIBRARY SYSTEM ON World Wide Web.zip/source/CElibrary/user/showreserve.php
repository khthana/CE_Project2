<?
session_start();
include("phpconfig.php");
include("dbconnect.php");
			$strSQL ="SELECT * FROM  reservation WHERE receive_status='reserv' && user_id='$_SESSION[login1]'  ";
			$result = mysql_query($strSQL,$conn) or  die ("�������ö���͡������ŧ���ҧ��");
			$rs=mysql_fetch_array($result);
?>
<HEAD>
<script type="text/javascript">
function cancelre()
{
    alert ("<? echo " ¡��ԡ��èͧ"; ?> ");
	submitOK="True"
}
</script>
<TITLE>���</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr>
    <td height="228" align="left" valign="top"><div align="left">
        <table width="617" border="0" cellspacing="0" cellpadding="0">
          <?
		  		$str ="SELECT * FROM  informationmedia WHERE serial='$rs[serial]' ";
				$re = mysql_query($str,$conn) or  die ("�������ö���͡������㹵��ҧ��");
				$rm = mysql_fetch_array($re);
				$row=mysql_num_rows($result);
				$receive_date= explode("-",$rs["receive_date"]);
		  if($row>0)
		  {?>
          <tr > 
            <td width="51" background="image/center_top.jpg"><strong><font color="#333333" size="2">&nbsp;</font></strong></td>
            <td background="image/center_top.jpg"><strong><font color="#660000" size="2">˹ѧ������</font></strong></td>
            <td width="109" background="image/center_top.jpg"><strong><font color="660000" size="2">�ѹ�Ѻ</font></strong></td>
          </tr>
          <tr> 
            <form name="form1" method="post" action="cancel.php?id=<? echo $rm[serial]; ?>"  onsubmit="return cancelre()" target="show"><td width="51" valign="bottom">
                <input type="submit" name="Submit" value="¡��ԡ">
              </td></form>
            <td><font color="#000000" size="2"><? echo $rm[title];?></font></td>
            <td width="109"><font color="#339900" size="2"><? echo $receive_date[2]."-".$receive_date[1]."-".$receive_date[0]; ?></font></td>
          </tr>
          <? 
		  }
		  if(@$reservenumber)
		  {
		  			$strSQL ="SELECT * FROM  informationmedia WHERE media_status ='shelve' && call_number='$reservenumber'  ";
					$result = mysql_query($strSQL,$conn) or  die ("�������ö���͡������ŧ���ҧ��");
					$rs=mysql_fetch_array($result);
					$shelve=mysql_num_rows($result);
					
					$strSQL ="SELECT * FROM  informationmedia WHERE  call_number='$reservenumber'  ";
					$result = mysql_query($strSQL,$conn) or  die ("�������ö���͡�����ŵ��ҧ��");
					$rs=mysql_fetch_array($result);
					$miss=mysql_num_rows($result);
					if($miss<1 && $shelve<1)
					{				?>
          <tr> 
            <td width="51"><strong><font color="#333333" size="2">&nbsp;</font></strong></td>
            <td><div align="center"><font color="#FF0000" size="2"><strong>��辺˹ѧ����������</strong></font></div></td>
            <td width="109"><font color="#339900">&nbsp;</font></td>
          </tr>
          <?
					}		
		  			elseif($miss>0 && $shelve<1)
					{				?>
          <tr> 
            <td width="51"><strong><font color="#333333" size="2">&nbsp;</font></strong></td>
            <td><div align="center"><font color="#FF0000" size="2"><strong>˹ѧ�������������������</strong></font></div></td>
            <td width="109"><font color="#339900">&nbsp;</font></td>
          </tr>
          <?
					}
					elseif($miss>0 && $shelve>0)
					{				$today =date("Y-m-d");
									
									$month=date("m"); 
									$day=date("d")+1; 
									$year=date("Y"); 
									$mk_data=mktime(22, 15, 10, $month, $day, $year);  
									 $receive_date=date("Y-m-d", $mk_data); 
									 
		   							$strSQL ="UPDATE informationmedia
										 SET  media_status='in use' 
									 	WHERE call_number='$reservenumber' "; 
						 			$result=mysql_query($strSQL,$conn);
									
									$strSQL ="INSERT INTO reservation (user_id ,mark_date,serial,receive_date ,receive_status ) 
										VALUES('$_SESSION[login1]','$today ','$rs[serial]','$receive_date','reserv') "; 
				 					$result=mysql_query($strSQL,$conn);
									$receive_date= explode("-", $receive_date);
		  							?>
          <tr> 
            <td colspan="3"><div align="center"><strong><font color="#339900" size="2">�ӡ�èͧ���º��������</font></strong></div></td>
          </tr>
		   <tr > 
            <td width="51" background="image/center_top.jpg"><strong></strong></td>
            <td background="image/center_top.jpg"><strong><font color="#660000" size="2">��������</font></strong></td>
            <td width="109" background="image/center_top.jpg"><font color="#660000" size="2"><strong>�ѹ�Ѻ</strong></font></td>
          </tr>
          <tr> 
            <td width="51" align="center" valign="middle"></td>
            <td><font color="#000000" size="2"><? echo $rs[title];?></font></td>
            <td width="109"><font color="339900" size="2"><? echo $receive_date[2]."-".$receive_date[1]."-".$receive_date[0]; ?></font></td>
          </tr>
          <?
					}
		  }
		  ?>
          <tr> 
            <td height="182" colspan="3" align="left" valign="top"><div align="left"> 
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
</BODY>
</HTML>

