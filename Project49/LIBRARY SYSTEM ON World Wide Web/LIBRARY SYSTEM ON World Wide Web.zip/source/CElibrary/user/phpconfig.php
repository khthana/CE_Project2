<?
$server="localhost";
$username="root";
$userpassword="";
$dbname="library";
?>