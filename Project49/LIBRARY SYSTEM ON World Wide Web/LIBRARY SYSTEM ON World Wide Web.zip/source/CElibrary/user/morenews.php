<?
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>search</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
</HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr>
    <td height="228" align="left" valign="top"><div align="left">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
           <tr> 
            <td height="182" align="left" valign="top"><div align="left"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                <tr> 
                  <td width="30%" ><img src="image/head_news.gif" width="188" height="68"></td>
                  <td width="47%" background="image/line3.gif" >&nbsp;</td>
                  <td width="23%" background="image/line3.gif"><div align="right"></div></td>
                </tr>
                <?
			if(!isset($_SESSION["newsstatus"]))
			{
			$today=date("Y-m-d");
			$strSQL ="SELECT * FROM  news WHERE status=0 ORDER BY begin_date DESC ";
			}
			else
			{
			$today=date("Y-m-d");
			$strSQL ="SELECT * FROM  news WHERE status='$_SESSION[newsstatus]' ORDER BY begin_date DESC ";
			}
			$result = mysql_query($strSQL,$conn) or  die ("�������ö����������ŧ���ҧ��");
		  
        	$bg=0;

			while($rs=mysql_fetch_array($result))
			{
				    echo "<tr>";
					if(($bg%2)==0)
						{
							if($bg<=3)
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td height=\"15\" 	bgcolor=\"#E7EBEA\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a><img src=\"image/new.gif\"></font></td> ";
								echo"<td height=\"15\" bgcolor=\"#E7EBEA\" ><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
							else
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td height=\"15\" 	bgcolor=\"#E7EBEA\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a></font></td> ";
								echo"<td height=\"15\" bgcolor=\"#E7EBEA\" ><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
			  			}
						else
						{
							if($bg<=3)
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a><img src=\"image/new.gif\"></font></td> ";
								echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
							else
							{
								$begindate= explode("-",$rs["begin_date"]);
								echo"<td  height=\"15\" colspan=\"2\" >&nbsp;&nbsp;<img src=\"image/news.gif\"><font color=\"#000000\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >   $rs[subject] </a></font></td> ";
								echo"<td   height=\"15\"><div align=\"right\"><font color=\"#339900\" size=\"2\">$begindate[2]-$begindate[1]-$begindate[0]</font></div ></td>";
								echo "</tr>";
							}
					 }			
						$bg=$bg+1;
				}
		
								
			?>
              </table></tr>
                  </table>
				
              </div></td>
          </tr>
        </table>
     
  </tr>
</table>
</BODY>
</HTML>
