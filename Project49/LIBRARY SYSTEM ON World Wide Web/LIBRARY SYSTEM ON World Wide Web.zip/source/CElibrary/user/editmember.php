<?
session_start();
		

include("phpconfig.php");
include("dbconnect.php");


		$strSQL ="SELECT * FROM  member  WHERE user_id='$_SESSION[login1]' ";
		$result = mysql_query($strSQL,$conn) or  die ("�������ö����������ŧ���ҧ��");
		$ms=mysql_fetch_array($result);
		?>
		<HEAD>
<TITLE>�����Ҫԡ</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
 </HEAD>
 <html>
 <BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0"> 
<table width="617" height="291" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="228" align="left" valign="top"><div align="left">
        <table width="617" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="617" background="../librarian/image/center_top.jpg"><strong><font color="#333333" size="2">&nbsp;�����Ҫԡ</font></strong></td>
          </tr>
          <tr> 
            <td height="182" align="left" valign="top"><div align="left"> 
			     <form name="form1" method="post" action="../user/chkaddeditmember.php?action=<?=$_SESSION["login1"]?>">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td width="14%">&nbsp;</td>
                      <td width="27%">&nbsp;</td>
                      <td width="59%">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#FF6600" size="2">����������к� 
                          :</font></div></td>
                      <td><input name="mem_name" type="text"  value="<?echo $ms[user_id];?>"> 
                        <font color="#FF6600" size="2">*&nbsp;<font color="#009900">Ex. 
                        47015678&nbsp;</font>&nbsp;&nbsp;&nbsp;</font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#FF6600" size="2">����-���ʡ�� 
                          :</font></div></td>
                      <td><input name="mem_fullname" type="text" value="<?echo $ms[name];?>"> 
                        <font color="#FF6600" size="2">*<font color="#009900"> 
                        Ex. �ҹ��� �����è��</font></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#FF6600" size="2">���ʼ�ҹ 
                          :</font></div></td>
                      <td><input name="mem_pass" type="password" value="<?echo $ms[passwd];?>">
                        <font color="#FF6600" size="2">&nbsp;*</font > </td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#FF6600" size="2">�������Ѿ�� 
                          :</font></div></td>
                      <td><input name="mem_tel" type="text"  value="<?echo $ms[phone];?>"> 
                        <font color="#FF6600" size="2">* <font color="#009900">Ex. 
                        0891288803</font></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td><div align="right"><font color="#FF6600" size="2">E-mail 
                          :</font></div></td>
                      <td><input name="mem_email" type="text" value="<?echo $ms[email];?>"> 
                        <font color="#FF6600" size="2">* <font color="#009900">Ex. 
                        torteera_1@hotmail.com</font></font></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td valign="top"><div align="right"><font color="#FF6600" size="2">��������´ 
                          :</font></div></td>
                      <td><textarea name="mem_comment" cols="50"  rows="5" value="<?echo $ms[comment];?>"></textarea></td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td><input type="submit" name="userlogin" value="�����Ҫԡ"></td>
                    </tr>
                  </table>
                </form>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
</BODY>
</HTML>
<?
	

?>
 






