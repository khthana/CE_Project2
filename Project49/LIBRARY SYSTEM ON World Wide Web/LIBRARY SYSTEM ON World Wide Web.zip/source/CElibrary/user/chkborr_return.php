<?
session_start();
include("phpconfig.php");
include("dbconnect.php");
$borrowname=$_SESSION["login1"];

?>
<HEAD>
<TITLE>����</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" /></HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr> 
    <td width="613" height="228" align="left" valign="top"><div align="left"> 
        
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="30%" ><img src="image/head_media.gif" width="188" height="68"></td>
            <td width="47%" background="image/line3.gif" >&nbsp;</td>
            <td width="23%" background="image/line3.gif"><div align="right"></div></td>
          </tr>
          <tr> 
            <td colspan="3" >
			
			<table width="100%" border="0" cellspacing="0" cellpadding="0" >
								<tr> 
                  				<td width="77%" background="image/center_top.jpg"><strong><font color="#660000" size="2">&nbsp;˹ѧ��ͤ�ҧ��</font></strong></td>
                  				<td width="20%" background="image/center_top.jpg"><strong><font size="2">&nbsp;<font color="#660000">�ѹ�׹</font></font></strong></td>
                				</tr>
                 
                <?
				include("popborrow.php");
			$strSQL ="SELECT borrow_history.serial ,borrow_history.must_return_date  
				FROM  borrow_history  
				LEFT JOIN borrow ON borrow_history.borrow_id = borrow.borrow_id 
				WHERE  borrow.user_id='$borrowname' &&   borrow_history.penalty  IS NULL
				ORDER BY  borrow_history.must_return_date  ASC"; 
			$result=mysql_query($strSQL,$conn);
													$bg=0;
													$day=getdate(Y-m-d);
													while($rs=mysql_fetch_array($result))
															{
															$str ="SELECT * FROM informationmedia  
																		WHERE  serial=$rs[serial] "; 
															$re=mysql_query($str,$conn);
															$rm=mysql_fetch_array($re);
															
																if($numborrow==0)
																{
																	?>
																	
                													<tr> 
                 													 <td colspan="2" > <div align="center"><strong><font color="#FF0000" size="2">��辺������ù��Ȥ�ҧ��</font></strong></div></td>
                													</tr>
                													<?
																}	
																else
																{																																									
																	echo "<tr>";
																	if(($bg%2)==0)
																	{
																	    echo "<td bgcolor=\"#E7EBEA\"><font color=\"#660000\" size=\"2\">$rm[title]</font ></td>";			
				  															if(	$rs[must_return_date]>$today)
																			{																								
																		echo "<td	bgcolor=\"#E7EBEA\"><font color=\"#009900\" size=\"2\">$rs[must_return_date]</font></td>";
                  															}													
																		else
																	  		echo "<td	bgcolor=\"#E7EBEA\"><font color=\"#cc0000\" size=\"2\">$rs[must_return_date]<img src=\"image/new.gif\"></font></td>";
																	}
																	else
																	{
																	echo "<td ><font color=\"#660000\" size=\"2\">$rm[title]></font ></td>";			
				  															if(	$rs[must_return_date]>$today)
																			{																								
																		echo "<td	><font color=\"#009900\" size=\"2\">$rs[must_return_date]</font></td>";
                  															}													
																		else
																	  		echo "<td	><font color=\"#cc0000\" size=\"2\">$rs[must_return_date]<img src=\"image/new.gif\"></font></td>";
																	}		
																	$bg=$bg+1;
																	  echo " </tr>";
																 }	
															}
			 ?>
              </table> 
			  </td>
             </tr>
        </table>

			
			
			
			</td>
          </tr>
        </table>
      </div></td>
     </tr>
</table>
</BODY>
</HTML>

