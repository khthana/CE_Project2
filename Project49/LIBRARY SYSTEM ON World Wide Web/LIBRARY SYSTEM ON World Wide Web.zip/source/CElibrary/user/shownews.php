<?
include("phpconfig.php");
include("dbconnect.php");

 			$strSQL ="SELECT * FROM  news WHERE news_id=$newsid";
			$result = mysql_query($strSQL,$conn) or  die ("�������ö����������ŧ���ҧ��");
		$rs=mysql_fetch_array($result);
					
					
				
					
					
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> ��С�� </TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</HEAD>
<BODY bgcolor="#FFFFFF" topmargin="0" leftmargin="0" >
<table width="1024" height="605" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
    <td width="617" height="70" background="image/center_top.jpg"><img src="image/titlehead.gif" width="500" height="70"></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td  height="34" align="center" valign="top" background="image/underhead.jpg">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr> 
    <td background="image/shadow_hilight_left.gif">&nbsp;</td>
    <td align="center" valign="top" background="image/bg.jpg"><table width="100%" border="0" cellpadding="0" cellspacing="0" dwcopytype="CopyTableCell">
        <tr> 
          <td width="34%"><div align="right"><font size="2"><font color="#FF6600"></font></font></div></td>
          <td width="66%">&nbsp;</td>
        </tr>
        <tr> 
          <td><div align="right"><strong><font color="#FF6600" size="2">����ͧ 
              :</font></strong></div></td>
          <td> <font size="2"> 
            <?=$rs[subject]?>
            </font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td><div align="right"><strong><font color="#FF6600" size="2">������ 
              :</font></strong></div></td>
          <td><font size="2"> 
            <?=$rs[news]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><strong><font color="#FF6600" size="2">�ѹ��С�� 
              :</font></strong></div></td>
          <? $begindate= explode("-",$rs["begin_date"]);?>
          <td><font size="2"><? echo $begindate[2]."-".$begindate[1]."-".$begindate[0]; ?></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td><div align="right"><strong><font color="#FF6600" size="2">����С�� 
              : </font></strong><font  size="2">
              <?=$rs[announcer]?>
              </font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
        </tr>
      </table></td>
    <td background="image/shadow_hilight.gif">&nbsp;</td>
  </tr>
</table>

</BODY>
</HTML>