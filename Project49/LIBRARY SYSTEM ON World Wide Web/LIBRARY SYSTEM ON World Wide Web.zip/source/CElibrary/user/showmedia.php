<?
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>search</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
</HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr>
    <td height="228" align="left" valign="top"><div align="left">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="182" align="left" valign="top"><div align="left">
                
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <?
						if($media=="title")
						{
						$strSQL ="SELECT * FROM informationmedia WHERE title like '%$search%' OR  title_2 like '%$search%' ";
						}
						elseif($media=="aurthor")
						{
						$strSQL ="SELECT * FROM informationmedia WHERE aurthor like '%$search%'  OR  aurthor_2 like '%$search%'  OR  aurthor_3 like '%$search%' ";
						}
						elseif($media=="subject")
						{
						$strSQL ="SELECT * FROM informationmedia WHERE subject like '%$search%' OR subject_2 like '%$search%' OR  subject_3 like '%$search%' " ;
						}
						else
						$strSQL ="SELECT * FROM informationmedia WHERE $media like '%$search%'";
						
						$result = mysql_query($strSQL,$conn) or  die ("�������ö���͡��������");
				?>
                    <tr> 
                      <td width="25" background="image/center_top.jpg" ><font color="#660000" size="2"><strong>No.</strong></font></td>
                      <td width="107" background="image/center_top.jpg"><div align="center"><font color="#000000" size="2">&nbsp;&nbsp;<font color="#660000"><strong>�Ţ���¡˹ѧ���</strong></font></font></div></td>
                      <td width="231" background="image/center_top.jpg"><div align="left"><font color="#000000" size="2"><strong>&nbsp;&nbsp;<font color="#660000">����˹ѧ���</font></strong></font></div></td>
                      <td width="174" background="image/center_top.jpg"><div align="left"><font color="#000000" size="2"><strong>&nbsp;&nbsp;<font color="#660000">�����</font></strong></font></div></td>
                      <td width="80" background="image/center_top.jpg"><div align="left"><strong><font color="#660000" size="2"> 
                       &nbsp; ʶҹ�</font></strong></div></td>
                    </tr>
                    <? 
					$bg=1;
				while($rs=mysql_fetch_array($result))
					{
					if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
					 ?>
                      <td width="25" ><font color="#000000" size="2"><? echo $bg ;?></font></td>
                      <td width="107" ><font color="#000000" size="2"><a href="show_media.php?mediaid=<?=$rs[serial]?>" target="_bank" > &nbsp;<? echo $rs["call_number"] ; ?></a></font></td>
                      <td width="231" ><font color="#000000" size="2"><a href="show_media.php?mediaid=<?=$rs[serial]?>" target="_bank" > &nbsp;<? echo $rs["title"] ;echo "<br>" ;echo $rs["title_2"]?></a></font></td>
                      <td width="174" ><font color="#000000" size="2">&nbsp;<a href="show_media.php?mediaid=<?=$rs[serial]?>" target="_bank" > <?  echo $rs["aurthor"] ;echo "<br>" ;echo $rs["aurthor_2"]; echo "<br>" ;echo $rs["aurthor_3"];?></a></font></td>
            		  <td width="80" ><? if($rs[media_status]=='shelve'){echo "<font color=\"#339900\" size=\"2\">���躹���</font>"; } elseif($rs[media_status]=='repair'){echo "<font color=\"#FF0000\" size=\"2\">������</font>";}elseif($rs[media_status]=='in use'){echo "<font color=\"#FF0000\" size=\"2\">�ռ����ҹ</font>" ;} elseif($rs[media_status]=='library use only'){echo "<font color=\"#FF0000\" size=\"2\">�����ͧ��ش��ҹ��</font>";}elseif($rs[media_status]=='missing'){echo "<font color=\"#FF0000\" size=\"2\">�٭���</font>";}  else echo"<font color=\"#FF0000\" size=\"2\">ʧǹ���</font>" ?></td>
                    </tr>
                    <?
					$bg=	$bg+1;
				    }				
				    ?>
                  </table>				
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
</BODY>
</HTML>
