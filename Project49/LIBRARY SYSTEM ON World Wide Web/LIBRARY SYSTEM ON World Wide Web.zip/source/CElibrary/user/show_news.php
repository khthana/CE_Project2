<?
include("phpconfig.php");
include("dbconnect.php");
?>
<HEAD>
<TITLE>search</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
</HEAD>
<BODY bgcolor="#FFFFFF" leftmargin="0" topmargin="0">
<table width="617" height="600" border="0" cellpadding="0" cellspacing="0" background="image/bg.jpg">
  <tr>
    <td height="228" align="left" valign="top"><div align="left">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="182" align="left" valign="top"><div align="left">
                <form name="form1" method="post" action="">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
					<?
						
						$strSQL ="SELECT * FROM news WHERE $search_news like '%$search%'";
						$result = mysql_query($strSQL,$conn) or  die ("�������ö����������ŧ���ҧ��");
							echo"<tr>";
					
					  echo"<td width=\"14\">&nbsp;</td>";
					   echo"<td width=\"17\">&nbsp;</td>";
					  echo"<td width=\"50\"><font color=\"#000000\" size=\"2\">&nbsp;</font></td>";
					  echo"<td width=\"17\"><font color=\"#000000\" size=\"2\">&nbsp;</font></td> ";
					  echo"<td width=\"17\"><font color=\"#000000\" size=\"2\">&nbsp;</font></td> ";
					echo"</tr>";
							
					
					echo"<tr>";
					
					  echo"<td  background=\"image/center_top.jpg\">&nbsp;</td>";
					   echo"<td  background=\"image/center_top.jpg\">&nbsp;</td>";
					  echo"<td  background=\"image/center_top.jpg\"><font color=\"#000000\" size=\"2\">&nbsp;�������ͧ</font></td>";
					  echo"<td  background=\"image/center_top.jpg\"><font color=\"#000000\" size=\"2\">&nbsp;�ѹ�����</font></td> ";
					  echo"<td  background=\"image/center_top.jpg\"><font color=\"#000000\" size=\"2\">&nbsp;�ѹ����ش</font></td> ";
					echo"</tr>";
					$bg=0;
					
				while($rs=mysql_fetch_array($result))
					{  $begindate= explode("-",$rs["begin_date"]);
						$enddate= explode("-",$rs["end_date"]);
					  if(($bg%2)==0) {echo" <tr bgcolor=\"#E7EBEA\" > ";}else echo" <tr > ";
								             
					   echo"<td ></td>";
                      echo"<td ><a href=\"delnews.php?action=$rs[news_id]\"><img src=\"image/delete.gif\" border=\"0\"></a></td>";
					  echo"<td ><div align=\"left\"><font color=\"#FF6600\" size=\"2\"><a href=\"shownews.php?newsid=$rs[news_id]\" target=\"_bank\" >&nbsp;$rs[subject]</a></font> </div></td>";
					  echo"<td ><div align=\"left\"><font color=\"#FF6600\" size=\"2\">&nbsp;$begindate[2]-$begindate[1]-$begindate[0]</font></div></td> ";
					   echo"<td ><div align=\"left\"><font color=\"#FF6600\" size=\"2\">&nbsp;$enddate[2]-$enddate[1]-$enddate[0]</font></div></td> ";
				   	  echo"</tr>";
					  $bg=	$bg+1;
				    }
								
				    ?>
					
                  </table>
                </form>
              </div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
</BODY>
</HTML>
