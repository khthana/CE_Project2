<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��ͧ��ش�Ҥ�Ԫ����Ǥ���������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
		<frameset rows="118,*" cols="*" framespacing="0"  frameborder ="no"  bordercolor="#dfddFF" border="0" >
			<frame src="headreserve.php" frameborder="no" scrolling="no" />
			<frame src="showreserve.php" name ="viwe" scrolling="no"  />
		</frameset>				 
</html>

			