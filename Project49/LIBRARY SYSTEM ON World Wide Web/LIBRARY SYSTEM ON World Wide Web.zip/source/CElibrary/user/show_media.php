<?
include("phpconfig.php");
include("dbconnect.php");

  $strSQL ="SELECT * FROM  informationmedia WHERE serial='$mediaid' ";
		 $result = mysql_query($strSQL,$conn);
		 $rs=mysql_fetch_array($result);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> ��С�� </TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</HEAD>
<BODY bgcolor="#FFFFFF" topmargin="0" leftmargin="0" >
<table width="1024" height="605" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
    <td width="617" height="70" background="image/center_top.jpg"><img src="image/titlehead.gif" width="500" height="70"></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td  height="34" align="center" valign="top" background="image/underhead.jpg">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr> 
    <td background="image/shadow_hilight_left.gif">&nbsp;</td>
    <td align="center" valign="top" background="image/bg.jpg"><table width="100%" border="0" cellpadding="0" cellspacing="0" dwcopytype="CopyTableCell">
        <tr> 
          <td width="43%"><div align="right"><font size="2"><font color="#FF6600"></font></font></div></td>
          <td width="57%">&nbsp;</td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>ISBN :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[isbn]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>���ͼ���� 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[aurthor]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>���ͼ������������ͧ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[aurthor_2]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>���ͼ�������������� 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[aurthor_3]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>��������ͧ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[title]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>��������ͧ����ͧ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[title_2]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�ӹѡ�����,����Ե 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[printing]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�շ������,�շ��Ѵ��˹��� 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[printing_year]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�ӹǹ˹�� 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[page]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�������ͧ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[subject]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�������ͧ����ͧ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[subject_2]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�������ͧ������ 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <?=$rs[subject_3]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>�ش��� 
              :</strong></font></div></td>
          <td><font color="#000000" size="2">&nbsp; 
            <?=$rs[series]?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>���������� 
              :</strong></font></div></td>
          <td><font size="2">&nbsp; 
            <? $strSQL ="SELECT * FROM  mediatype WHERE type_id ='$rs[type_id]' ";
		 											$result = mysql_query($strSQL,$conn);
													$rm=mysql_fetch_array($result);  echo $rm[type_name]; ?>
            </font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>ʶҹ� 
              :</strong></font></div></td>
          <td>&nbsp;<? if($rs[media_status]=='shelve'){echo "<font color=\"#339900\" size=\"2\">���躹���</font>"; } elseif($rs[media_status]=='repair'){echo "<font color=\"#FF0000\" size=\"2\">������</font>";}elseif($rs[media_status]=='in use'){echo "<font color=\"#FF0000\" size=\"2\">�ռ����ҹ</font>" ;} elseif($rs[media_status]=='library use only'){echo "<font color=\"#FF0000\" size=\"2\">�����ͧ��ش��ҹ��</font>";}elseif($rs[media_status]=='missing'){echo "<font color=\"#FF0000\" size=\"2\">�٭���</font>";}  else echo"<font color=\"#FF0000\" size=\"2\">ʧǹ���</font>" ?></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#FF6600" size="2"><strong>��������´������� 
              :</strong></font></div></td>
          <td><font color="#CCCCFF" size="2">&nbsp; 
            <?=$rs[description]?>
            </font> </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
    <td background="image/shadow_hilight.gif">&nbsp;</td>
  </tr>
</table>

</BODY>
</HTML>