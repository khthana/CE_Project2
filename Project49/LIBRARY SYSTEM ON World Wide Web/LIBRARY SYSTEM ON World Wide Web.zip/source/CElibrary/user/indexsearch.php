<?
session_start();
 ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��ͧ��ش�Ҥ�Ԫ����Ǥ���������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

		<frameset rows="118,*" cols="*" framespacing="0"  frameborder ="no"  bordercolor="#dfddFF" border="0"  >
			<frame src="headsearch.php" frameborder="no"  />
			<frame src="empty" name ="viwe"   />
		</frameset>
		
			 

</html>

			