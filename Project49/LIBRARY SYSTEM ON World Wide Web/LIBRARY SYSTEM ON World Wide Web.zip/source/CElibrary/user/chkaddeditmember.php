<?
include("phpconfig.php");
include("dbconnect.php");
?>
<html>
<head>
<title>�����Ҫԡ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../librarian/style1.css" rel="stylesheet"  type="text/css" />
</head>
</html>
<?
		
	if(empty($mem_name) or 
		empty($mem_fullname) or
		empty($mem_tel) or
		empty($mem_email))
	{
			
			?>
			<td><center>
			<font color="#009900" size="4"><strong>���������١��ͧ</strong></font><br><br>
				<a href="../librarian/addmember.php?action=<?=$mem_name?>">�����Ҫԡ</a>
			</center></td>
			<?		
	}
	else
	{		
	$mem_pass=md5($mem_pass);
		 $strSQL="update member set user_id='$mem_name',
		 passwd='$mem_pass',
			 name='$mem_fullname',
			 phone='$mem_tel',
				email='$mem_email',
			    comment=' $mem_comment'	
			 WHERE user_id='$action' "; 
    						
			$result=mysql_query($strSQL,$conn);
			if(!$result) 
			die ("UPDATE �բ�ͼԴ��Ҵ".mysql_error());

			?>
			<td><center>
			<font color="#009900" size="4"><strong>�ӡ�������Ҫԡ���º��������</strong></font><br><br>
			<a href="../user/news.php" target="show">��Ѻ</a>	</center></td>
			<?		
		}	

?>	
</html>
