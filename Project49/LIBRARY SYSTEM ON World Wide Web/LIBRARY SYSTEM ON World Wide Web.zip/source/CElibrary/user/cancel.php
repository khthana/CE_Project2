<?
include("phpconfig.php");
include("dbconnect.php");
									
										$strSQL ="UPDATE informationmedia
										 SET  media_status='shelve' 
									 	WHERE serial = '$id' "; 
						 				$result=mysql_query($strSQL,$conn);
										
										$strSQL ="UPDATE reservation  SET receive_status='cancel'  WHERE receive_status='reserv'  && serial = '$id'  ";
						 				$result=mysql_query($strSQL,$conn);
										echo"<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0 URL=indexreserve.php\">";
?>