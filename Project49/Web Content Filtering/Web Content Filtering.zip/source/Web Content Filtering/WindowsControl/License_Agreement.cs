using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsControl
{
    public partial class License_Agreement : Form
    {
        public License_Agreement()
        {
            InitializeComponent();
        }
    }
}