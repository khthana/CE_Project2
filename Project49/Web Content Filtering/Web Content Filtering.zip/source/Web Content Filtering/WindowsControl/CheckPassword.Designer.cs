namespace WindowsControl
{
    partial class CheckPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CheckPassword));
            this.btn_chkok = new System.Windows.Forms.Button();
            this.txt_chkpassword = new System.Windows.Forms.TextBox();
            this.btn_chkcancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_chkok
            // 
            this.btn_chkok.Location = new System.Drawing.Point(92, 68);
            this.btn_chkok.Name = "btn_chkok";
            this.btn_chkok.Size = new System.Drawing.Size(75, 23);
            this.btn_chkok.TabIndex = 0;
            this.btn_chkok.Text = "OK";
            this.btn_chkok.UseVisualStyleBackColor = true;
            this.btn_chkok.Click += new System.EventHandler(this.btn_chkok_Click);
            // 
            // txt_chkpassword
            // 
            this.txt_chkpassword.Location = new System.Drawing.Point(109, 29);
            this.txt_chkpassword.Name = "txt_chkpassword";
            this.txt_chkpassword.Size = new System.Drawing.Size(139, 20);
            this.txt_chkpassword.TabIndex = 1;
            this.txt_chkpassword.UseSystemPasswordChar = true;
            // 
            // btn_chkcancel
            // 
            this.btn_chkcancel.Location = new System.Drawing.Point(173, 68);
            this.btn_chkcancel.Name = "btn_chkcancel";
            this.btn_chkcancel.Size = new System.Drawing.Size(75, 23);
            this.btn_chkcancel.TabIndex = 2;
            this.btn_chkcancel.Text = "Cancel";
            this.btn_chkcancel.UseVisualStyleBackColor = true;
            this.btn_chkcancel.Click += new System.EventHandler(this.btn_chkcancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Password";
            // 
            // CheckPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(271, 111);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_chkcancel);
            this.Controls.Add(this.txt_chkpassword);
            this.Controls.Add(this.btn_chkok);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CheckPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Web Content Filtering";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_chkok;
        private System.Windows.Forms.TextBox txt_chkpassword;
        private System.Windows.Forms.Button btn_chkcancel;
        private System.Windows.Forms.Label label1;
    }
}