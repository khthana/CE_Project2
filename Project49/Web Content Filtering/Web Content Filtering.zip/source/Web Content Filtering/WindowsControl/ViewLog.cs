using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Globalization;

namespace WindowsControl
{
    public partial class ViewLog : Form
    {
        #region ViewLog()
        public ViewLog()
        {
        }
        public ViewLog(string day, string month, string year)
        {
            InitializeComponent();
            label_dateLog.Text = day + " " + month + " " + year;
        }
        #endregion

        #region void ShowLogFile(string pathLogFile)
        public void ShowLogFile(string pathLogFile)
        {
            using (StreamReader strReader = new StreamReader(pathLogFile))
            {
                string line,time,status,url;
                string[] arrStr;
                ListViewItem item;
                while ((line = strReader.ReadLine()) != null)
                {
                    arrStr = line.Split(new String[] { "   " }, StringSplitOptions.None);
                    status = arrStr[1];
                    status = status.Remove(status.Length-1);
                    status = status.Substring(1);

                    time = arrStr[0];
                    url = arrStr[2];
                    item = new ListViewItem(url);
                    item.SubItems.Add(status);
                    item.SubItems.Add(time);
                    listView_log.Items.Add(item);    
                }
            }
        }
        #endregion

        #region void btn_close_Click(object sender, EventArgs e)
        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}