using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

using AppModule.NamedPipes;
using AppModule.InterProcessComm;
using UsingNamedPipe;

namespace WindowsControl
{
    #region comment
    /// <summary>
    /// Named Pipe for using with Windows Control only.(Listening)
    /// </summary> 
    #endregion
    public class WControlNamedPipe : ServerNamedPipe{
        private bool disposed = false;
        public delegate void UpdateListViewBlock(string uri);
        public delegate void UpdateListViewPass(string uri);
        
        #region comment
        /// <summary>
        /// constructor of Windows Control NamedPipe Instance.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="outBuffer"></param>
        /// <param name="inBuffer"></param>
        /// <param name="maxReadBytes"></param>
        /// <param name="secure"></param> 
        #endregion
        public WControlNamedPipe(String name, uint outBuffer, uint inBuffer, int maxReadBytes, bool secure)
            : base(name, outBuffer, inBuffer, maxReadBytes, secure)
        {
            this.pipeManager = pipeManager;
        }
        #region comment
        /// <summary>
        /// this loop for listening: data from Windows Service.
        /// </summary> 
        #endregion
        public override void PipeListener()
        {
            CheckIfDisposed();
            Debug.WriteLine("555555555555555555");
            try
            {
                Listen = pipeManager.Listen;
                while (Listen)
                {
                    LastAction = DateTime.Now;
                    Debug.WriteLine("Pre-Read: "+PipeConnection.NativeHandle);

                        string request = PipeConnection.Read();
                        Debug.WriteLine("Post-Read: " + PipeConnection.NativeHandle);
                        ///Split string Read by ","
                        split = request.Split(new Char[] { ',' });
                        str1 = split[0];
                        str2 = split[1];
                        LastAction = DateTime.Now;
                        if (request.Trim() != "")
                        {
                            if(str1 == " "){
                                WindowsControl.refListView_UrlBlocked.Invoke(new UpdateListViewBlock(WindowsControl.Append_UrlBlocked), new Object[] { str2 });
                                
                            }else{
                                WindowsControl.refListView_UrlPassed.Invoke(new UpdateListViewPass(WindowsControl.Append_UrlPassed), new Object[] { str1 });
                            }
                        }
                        LastAction = DateTime.Now;
                    Debug.WriteLine("Pre-Disconnect: "+PipeConnection.NativeHandle);
                    PipeConnection.Disconnect();
                    Debug.WriteLine("Post-Disconnect: " + PipeConnection.NativeHandle);

                    if (Listen)
                    {
                        Debug.WriteLine("Pre-Connect: " + PipeConnection.NativeHandle);
                        Connect();
                        Debug.WriteLine("Post-Connect: " + PipeConnection.NativeHandle);
                    }
                    
                    pipeManager.WakeUp();
                    Debug.WriteLine("FinLoop: " + PipeConnection.NativeHandle+"\n\n");
                }
            }
            catch (System.Threading.ThreadAbortException ex) { }
            catch (System.Threading.ThreadStateException ex) { }
            catch (Exception ex)
            {
                // Log exception
            }
           // finally
           // {
           //     this.Close();
           // }
        }
       /* #region comment
        /// <summary>
        /// check if dispoesd
        /// </summary> 
        #endregion
        protected override void CheckIfDisposed()
        {
            Debug.WriteLine("disposed(WControl " + this.ToString() + "): " + this.disposed.ToString());
            if (this.disposed)
            {
                throw new ObjectDisposedException("WControlNamedPipe");
            }
        }*/

        #region comment
        /// <summary>
        ///Dispose(bool disposing) executes in two distinct scenarios.
        /// If disposing equals true, the method has been called directly
        /// or indirectly by a user's code. Managed and unmanaged resources
        /// can be disposed.
        /// If disposing equals false, the method has been called by the 
        /// runtime from inside the finalizer and you should not reference 
        /// other objects. Only unmanaged resources can be disposed.

        /// </summary>
        /// <param name="disposing"></param> 
        #endregion
        protected override void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                PipeConnection.Dispose();
                if (PipeThread != null)
                {
                    try
                    {
                        PipeThread.Abort();
                    }
                    catch (System.Threading.ThreadAbortException ex) { }
                    catch (System.Threading.ThreadStateException ex) { }
                    catch (Exception ex)
                    {
                        // Log exception
                    }
                }
            }
            disposed = true;
        }
        #region comment
        /// <summary>
        /// Destructor of WControlNamedPipe.
        /// </summary> 
        #endregion
        ~WControlNamedPipe()
        {
			Dispose(false);
		}
    }
}
