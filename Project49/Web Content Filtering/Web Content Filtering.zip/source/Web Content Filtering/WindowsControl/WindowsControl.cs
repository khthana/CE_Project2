using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceProcess;
using System.Diagnostics;
using System.Globalization;

using AppModule.InterProcessComm;
using AppModule.NamedPipes;
using UsingNamedPipe;

using Microsoft.Win32;//Registry
using System.IO;//read/write file

namespace WindowsControl
{
    public partial class WindowsControl : Form
    {
        #region Member class
        //*****Member*****
        public static PipeManager pipeManager;
        public static ListView refListView_UrlPassed;
        public static ListView refListView_UrlBlocked;
        //Assign Date & Time to en-US Culture.
        static CultureInfo en_cl;
        static DateTimeFormatInfo en_dt;
        //Program Path.
        static string pathprogram;
        static string pathlog;
        //Get Path .exe of program
        string appPath = Application.ExecutablePath;
        
        //levelMode is a Mode on filtering operation.
        private string levelMode;
        //Registry path
        public string registry_program = "Software\\WebContentFiltering";
        public RegistryKey getReg,setReg;
        public string registry_levelMode;
        //about Month Calender
        private DateTime selectedDate;
        #endregion
        //*****Method*****
        #region Method

        #region WindowsControl()
        public WindowsControl()
        {
            ///*****Initialize in every control.*****
            InitializeComponent();
            pathprogram = appPath.Substring(0, appPath.Length - 18);
            pathlog = pathprogram + "\\Logs";
            getReg = Registry.CurrentUser.OpenSubKey(registry_program,true);
            setReg = Registry.CurrentUser.CreateSubKey(registry_program);

            //Don't resize parent window.
            //????

            //Initial Date & Time : en Culture
            en_cl = new CultureInfo("en-US");
            en_dt = en_cl.DateTimeFormat;
            selectedDate = new DateTime();


            //Start Timer 
            timer.Start();
            //Set Control Reference
            refListView_UrlPassed = listViewPass;
            refListView_UrlBlocked = listViewBlock;

            ///Default Variable Value For Interprocess communication
            uint OutBuffer = 512;
            uint InBuffer = 512;
            const int MAX_READ_BYTES = 5000;
            WControlNamedPipe pipe = new WControlNamedPipe("WindowsControl", OutBuffer, InBuffer, MAX_READ_BYTES, false);

            ///*****Initial PipeManager*****
            pipeManager = new PipeManager();
            pipeManager.SetServerNamedPipe(pipe);
            pipeManager.Initialize();
            pipe.SetPipeManager(pipeManager);

            //*****Set Default show date on MonthCalendar*****
            monthCalendar1.SetDate(DateTime.Now);
            #region Set Bolded Day(has a log file.)
            //*****take day that has a log file.by set day to bolding*****
            string[] logfiles;
            //Has Logs Path?
            if (Directory.Exists(pathlog))
            {
                logfiles = Directory.GetFiles(pathlog, "*_*_????WCFA.txt");
                //Get only day of the logfilename.
                string day, month, year;
                DateTime[] datetime = new DateTime[logfiles.Length];
                for (int i = 0; i < logfiles.Length; i++)
                {
                    string[] temp = (logfiles[i].Split('\\'));
                    //,e.g. 22_12_2006.txt
                    logfiles[i] = temp[temp.Length - 1];
                    //[0]==22,[1]==12,[2]==2006WCFA.txt
                    string[] arrStr = logfiles[i].Split('_');
                    day = arrStr[0];
                    month = arrStr[1];
                    year = arrStr[2].Split(new string[] { "WCFA.txt" }, StringSplitOptions.None)[0];
                    datetime[i] = new DateTime(Convert.ToInt16(year, en_dt), Convert.ToInt16(month, en_dt), Convert.ToInt16(day, en_dt), 0, 0, 0, DateTimeKind.Utc);
                    //MessageBox.Show( datetime[i].ToString(en_dt));

                }
                //Set the day has a log file to Bolded day in MonthCalender.
                monthCalendar1.BoldedDates = datetime;
            }
            #endregion

            //*****set start Program*****
            #region Check used level from registry
            registry_levelMode = getReg.GetValue("Level").ToString();
            levelMode = registry_levelMode;
            if (levelMode == "LOW")
            {
                scroll_Level.Value = 0;
                StopService();
                
                SetBlackOnLowMode();
                SetSilverOnHighMode();
                SetSilverOnMediumMode();
                setUnUseableProxy();
                CloseBrowser();
            }
            else if (levelMode == "MEDIUM")
            {
                scroll_Level.Value = 5;
                StartService();
                
                SetBlackOnMediumMode();
                SetSilverOnHighMode();
                SetSilverOnLowMode();
                setUseableProxy();
                CloseBrowser();
            }
            else if (levelMode == "HIGH")
            {
                scroll_Level.Value = 10;
                StartService();
                
                SetBlackOnHighMode();
                SetSilverOnMediumMode();
                SetSilverOnLowMode();
                setUseableProxy();
                CloseBrowser();
            }
            #endregion
            SendGoodListRegistryToService();
        }
        #endregion

        #region void SetBlackOnHighMode()
        private void SetBlackOnHighMode()
        {
            lb_high.ForeColor = System.Drawing.Color.Black;
            lb_high_des1.ForeColor = System.Drawing.Color.Black;
            lb_high_des2.ForeColor = System.Drawing.Color.Black;
        }
        #endregion

        #region void SetSilverOnHighMode()
        private void SetSilverOnHighMode()
        {
            lb_high.ForeColor = System.Drawing.Color.DarkGray;
            lb_high_des1.ForeColor = System.Drawing.Color.DarkGray;
            lb_high_des2.ForeColor = System.Drawing.Color.DarkGray;
        }
        #endregion

        #region void SetGrayOnHighMode()
        private void SetGrayOnHighMode()
        {
            lb_high.ForeColor = System.Drawing.Color.Gray;
            lb_high_des1.ForeColor = System.Drawing.Color.Gray;
            lb_high_des2.ForeColor = System.Drawing.Color.Gray;
        }
        #endregion

        #region void SetBlackOnMediumMode()
        private void SetBlackOnMediumMode()
        {
            lb_medium.ForeColor = System.Drawing.Color.Black;
            lb_medium_des1.ForeColor = System.Drawing.Color.Black;
            lb_medium_des2.ForeColor = System.Drawing.Color.Black;
        }
        #endregion

        #region void SetSilverOnMediumMode()
        private void SetSilverOnMediumMode()
        {
            lb_medium.ForeColor = System.Drawing.Color.DarkGray;
            lb_medium_des1.ForeColor = System.Drawing.Color.DarkGray;
            lb_medium_des2.ForeColor = System.Drawing.Color.DarkGray;
        }
        #endregion

        #region void SetGrayOnMediumMode()
        private void SetGrayOnMediumMode()
        {
            lb_medium.ForeColor = System.Drawing.Color.Gray;
            lb_medium_des1.ForeColor = System.Drawing.Color.Gray;
            lb_medium_des2.ForeColor = System.Drawing.Color.Gray;
        }
        #endregion

        #region void SetBlackOnLowMode()
        private void SetBlackOnLowMode()
        {
            lb_low.ForeColor = System.Drawing.Color.Black;
            lb_low_des1.ForeColor = System.Drawing.Color.Black;
        }
        #endregion

        #region void SetSilverOnLowMode()
        private void SetSilverOnLowMode()
        {
            lb_low.ForeColor = System.Drawing.Color.DarkGray;
            lb_low_des1.ForeColor = System.Drawing.Color.DarkGray;
        }
        #endregion

        #region void SetGrayOnLowMode()
        private void SetGrayOnLowMode()
        {
            lb_low.ForeColor = System.Drawing.Color.Gray;
            lb_low_des1.ForeColor = System.Drawing.Color.Gray;
        }
        #endregion

        #region void trackBar1_Scroll(object sender, EventArgs e)
        private void trackBar1_Scroll(object sender, EventArgs e)
        {

            if (scroll_Level.Value == 0 || scroll_Level.Value == 1 || scroll_Level.Value == 2)
            {//LOW
                if (levelMode != "LOW")
                {
                    SetGrayOnLowMode();
                    if (levelMode == "MEDIUM") { SetSilverOnHighMode(); }
                    else { SetSilverOnMediumMode(); }
                    //Set enabled Apply Button
                    btn_apply.Enabled = true;
                }
                else
                {
                    SetSilverOnHighMode();
                    SetSilverOnMediumMode();
                    //Set enabled Apply Button
                    btn_apply.Enabled = false;
                }
                scroll_Level.Value = 0;
            }
            else if (scroll_Level.Value == 3 || scroll_Level.Value == 4 || scroll_Level.Value == 5 || scroll_Level.Value == 6 || scroll_Level.Value == 7)
            {//MEDIUM
                if (levelMode != "MEDIUM")
                {
                    SetGrayOnMediumMode();
                    if (levelMode == "HIGH") { SetSilverOnLowMode(); }
                    else { SetSilverOnHighMode(); }
                    //Set enabled Apply Button
                    btn_apply.Enabled = true;
                }
                else
                {
                    SetSilverOnLowMode();
                    SetSilverOnHighMode();
                    //Set enabled Apply Button
                    btn_apply.Enabled = false;
                }
                scroll_Level.Value = 5;
            }
            else if (scroll_Level.Value == 8 || scroll_Level.Value == 9 || scroll_Level.Value == 10)
            {//HIGH
                if (levelMode != "HIGH")
                {
                    SetGrayOnHighMode();
                    if (levelMode == "MEDIUM") { SetSilverOnLowMode(); }
                    else { SetSilverOnMediumMode(); }
                    //Set enabled Apply Button
                    btn_apply.Enabled = true;
                }
                else
                {
                    SetSilverOnLowMode();
                    SetSilverOnMediumMode();
                    //Set enabled Apply Button
                    btn_apply.Enabled = false;
                }
                scroll_Level.Value = 10;
            }
            //textBox1.Clear();


        }
        #endregion

        #region void btn_apply_Click(object sender, EventArgs e)
        private void btn_apply_Click(object sender, EventArgs e)
        {
            //Check Username & Password
            CheckPassword cls_chkpassword = new CheckPassword();
            cls_chkpassword.ShowDialog();
            //Check Scroll Level Value to set levelMode value.
            if (CheckPassword.chk_password_correct == false)
            {
                //if user press cancel button,or input wrong password ==> CheckPassword.chk_password_correct == false
                return;
            }
            //Set enabled Apply Button to Default
            btn_apply.Enabled = false;
            if ((scroll_Level.Value == 0 || scroll_Level.Value == 1 || scroll_Level.Value == 2) && levelMode != "LOW")
            {
                //Set Color on Mode Label,when select "LOW"
                SetBlackOnLowMode();
                SetSilverOnHighMode();
                SetSilverOnMediumMode();

                levelMode = "LOW";
                setUnUseableProxy();
                CloseBrowser();
                setReg.SetValue("Level", "LOW");


            }
            else if ((scroll_Level.Value == 3 || scroll_Level.Value == 4 || scroll_Level.Value == 5 || scroll_Level.Value == 6 || scroll_Level.Value == 7) && levelMode != "MEDIUM")
            {
                if (levelMode == "LOW")
                {
                    setUseableProxy();
                    CloseBrowser();
                }
                //Set Color on Mode Label,when select "MEDIUM"
                SetBlackOnMediumMode();
                SetSilverOnHighMode();
                SetSilverOnLowMode();

                levelMode = "MEDIUM";
                setReg.SetValue("Level", "MEDIUM");
            }
            else if ((scroll_Level.Value == 8 || scroll_Level.Value == 9 || scroll_Level.Value == 10) && levelMode != "HIGH")
            {
                if (levelMode == "LOW")
                {
                    setUseableProxy();
                    CloseBrowser();
                }
                else { }
                //Set Color on Mode Label,when select "HIGH"
                SetBlackOnHighMode();
                SetSilverOnMediumMode();
                SetSilverOnLowMode();

                levelMode = "HIGH";
                setReg.SetValue("Level", "HIGH");
            }
            else { MessageBox.Show("ERROR"); return; }

            if (levelMode == "LOW")
            {
                StopService();
                ////Set Proxy Registry IE For Unuseable 
                setUnUseableProxy();
            }
            else///"MEDIUM" OR "HIGH"
            {
                //Set Proxy Registry IE For useable 
                setUseableProxy();
                StartService();
            }

        }
        #endregion

        #region comment
        /// <summary>
        /// Terminate IE and Firefox Browser Process.
        /// </summary> 
        #endregion

        #region void CloseBrowser()
        private void CloseBrowser()
        {
            //Close Browser: IE and Firefox
            Process[] ie = Process.GetProcessesByName("iexplore");
            Process[] firefox = Process.GetProcessesByName("FIREFOX");
            if (ie.Length > 0)
            {
                //MessageBox.Show("hasie");
                foreach (Process each_ie in ie)
                {
                    each_ie.Kill();
                }
            }
            if (firefox.Length > 0)
            {
                //MessageBox.Show("hasfirefox");
                foreach (Process each_firefox in firefox)
                {
                    each_firefox.Kill();
                }
            }
        }
        #endregion

        #region void StopService()
        private void StopService()
        {
            ///Stoping Service
            if (serviceController1.CanStop)
            {
                serviceController1.Stop();
                serviceController1.Refresh();
            }
        }
        #endregion

        #region void StartService()
        private void StartService()
        {
            ClientPipeConnection clientConnection = null;
            try
            {
                ///Starting Service
                if ((serviceController1.Status.Equals(ServiceControllerStatus.Stopped)) || (serviceController1.Status.Equals(ServiceControllerStatus.StopPending)))
                {
                    serviceController1.Start();
                    serviceController1.WaitForStatus(ServiceControllerStatus.Running);
                    serviceController1.Refresh();
                }

                // send data by interprocess
                clientConnection = new ClientPipeConnection("WindowsService", ".");
                clientConnection.Connect();
                clientConnection.Write(levelMode + "," + " ");
                //textBox1.Text = clientConnection.Read();
                clientConnection.Close();
            }
            catch (Exception ex)
            {
                clientConnection.Dispose();
                throw (ex);
            }
        }
        #endregion

        #region void MenuItemShutdown_Click(object sender, EventArgs e)
        private void MenuItemShutdown_Click(object sender, EventArgs e)
        {
            //Check Username & Password
            CheckPassword cls_chkpassword = new CheckPassword();
            
            cls_chkpassword.ShowDialog();
            //Check Scroll Level Value to set levelMode value.
            if (CheckPassword.chk_password_correct == false)
            {
                //if user press cancel button,or input wrong password ==> CheckPassword.chk_password_correct == false
                return;
            }
            string save_registry_level = levelMode;
            //Update a Log File
            SaveLogInFile();
            //Terminate IE&Firefox Browser Process.
            setUnUseableProxy();
            
            //Shutdown Web Content Filtering
            StopService();
            
            Application.Exit();
            Application.ExitThread();
            //Level has save to registry
            setReg.SetValue("Level", save_registry_level);
            CloseBrowser();
        }
        #endregion

        #region static void Append_UrlBlocked(string uri)
        public static void Append_UrlBlocked(string uri)
        {
            ListViewItem item = new ListViewItem(uri);
            item.SubItems.Add(DateTime.Now.ToString("t", en_dt));
            refListView_UrlBlocked.Items.Add(item);
        }
        #endregion

        #region static void Append_UrlPassed(string uri)
        public static void Append_UrlPassed(string uri)
        {
            ListViewItem item = new ListViewItem(uri);
            item.SubItems.Add(DateTime.Now.ToString("t", en_dt));
            refListView_UrlPassed.Items.Add(item);
        }
        #endregion

        #region void notifyIcon1_DoubleClick(object sender, EventArgs e)
        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            //this.DialogResult = DialogResult.OK;
            this.WindowState = FormWindowState.Normal;
            this.Show();

        }
        #endregion

        #region void WindowsControl_FormClosing(object sender, FormClosingEventArgs e)
        private void WindowsControl_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
            //this.DialogResult = DialogResult.Cancel;
        }
        #endregion

        #region void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tabControl1.SelectedIndex == 1)
            {//URL Blocked Tab
                label_date1.Text = "     Today: " + DateTime.Now.ToString("dddd dd MMMM yyyy", en_dt);
            }
            else if (tabControl1.SelectedIndex == 2)
            {//URL Passes Tab
                label_date2.Text = "     Today: " + DateTime.Now.ToString("dddd dd MMMM yyyy", en_dt);
            }
            else if (tabControl1.SelectedIndex == 3)
            {//Trusted URL
                //Reload Trusted URL to list
                btn_cleargoodlist_Click(EventArgs.Empty, EventArgs.Empty);
            }
            else if (tabControl1.SelectedIndex == 4)
            {//Log & Password Tab
                //Set Default show date on MonthCalendar
                monthCalendar1.SetDate(DateTime.Now);
                //Check today-logfile.
                string todayFilelog = pathprogram + "\\Logs\\" + DateTime.Now.Day.ToString(en_dt) + "_" + DateTime.Now.Month.ToString(en_dt) + "_" + DateTime.Now.Year.ToString(en_dt) + "WCFA.txt";
                if(File.Exists(todayFilelog)){
                    DateTime datenow = new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day);
                    DateRangeEventArgs dateevent = new DateRangeEventArgs(datenow, datenow);
                    monthCalendar1_DateSelected(EventArgs.Empty, dateevent);
                    btn_viewlog.Enabled = true;
                    btn_viewlog.Text = "View Log";
                }
            }
        }
        #endregion

        #region void timer_Tick(object sender, EventArgs e)
        private void timer_Tick(object sender, EventArgs e)
        {
            
            if (DateTime.Now.ToString("T", DateTimeFormatInfo.InvariantInfo) == "23:59:00")
            {
                MessageBox.Show("true");
                //SaveLogInFile();
            }
        }
        #endregion

        #region void SaveLogInFile()
        private void SaveLogInFile()
        {
            if (!Directory.Exists(pathprogram + "\\Logs\\"))
            {
                Directory.CreateDirectory(pathprogram + "\\Logs\\");
            }

            //URL[]==>Blocked URL
            ListView.ListViewItemCollection itemsblock = listViewBlock.Items;
            //URL[]==>Passed URL
            ListView.ListViewItemCollection itemspass = listViewPass.Items;

            string filelog = pathprogram + "\\Logs\\" + DateTime.Now.Day.ToString(en_dt) + "_" + DateTime.Now.Month.ToString(en_dt) + "_" + DateTime.Now.Year.ToString(en_dt) + "WCFA.txt";
            ///Check logfile existing?.
            if (File.Exists(filelog))
            {
                ///"using" word that it defines a scope at the end of which an object will be disposed
                ///Append to a Log File
                using (StreamWriter sw = File.AppendText(filelog))
                {
                    #region Print Blocked URL
                    foreach (ListViewItem item in itemsblock)
                    {
                        //One log line that will input to filename.
                        //1 line,e.g. 12:34 �.   [BLOCKED]   http://www.sax.com
                        string log = "";
                        //Time[]==>Blocked URL
                        ListViewItem.ListViewSubItemCollection subitems = item.SubItems;
                        foreach (ListViewItem.ListViewSubItem subitem in subitems)
                        {
                            log = subitem.Text + "   [BLOCKED]   ";
                        }
                        log = log + item.Text;
                        sw.WriteLine(log);
                    }
                    #endregion
                    #region Print Passed URL
                    foreach (ListViewItem item in itemspass)
                    {
                        //One log line that will input to filename.
                        //1 line,e.g. 12:35 �.   [PASSED]   http://www.google.co.th
                        string log = "";
                        //Time[]==>Passed URL
                        ListViewItem.ListViewSubItemCollection subitems = item.SubItems;
                        foreach (ListViewItem.ListViewSubItem subitem in subitems)
                        {
                            log = subitem.Text + "   [PASSED]   ";
                        }
                        log = log + item.Text;
                        sw.WriteLine(log);
                    }
                    #endregion
                    sw.Close();
                }

            }
            else
            {
                ///"using" word that it defines a scope at the end of which an object will be disposed
                ///Create a Log File
                if (itemsblock.Count != 0 || itemspass.Count != 0)
                {
                    using (StreamWriter sw = File.CreateText(filelog))
                    {
                        #region Print Blocked URL
                        foreach (ListViewItem item in itemsblock)
                        {
                            //One log line that will input to filename.
                            //1 line,e.g. 12:34 �.   [BLOCKED]   http://www.sax.com
                            string log = "";
                            //Time[]==>Blocked URL
                            ListViewItem.ListViewSubItemCollection subitems = item.SubItems;
                            foreach (ListViewItem.ListViewSubItem subitem in subitems)
                            {
                                log = subitem.Text + "   [BLOCKED]   ";
                            }
                            log = log + item.Text;
                            sw.WriteLine(log);
                        }
                        #endregion
                        #region Print Passed URL
                        foreach (ListViewItem item in itemspass)
                        {
                            //One log line that will input to filename.
                            //1 line,e.g. 12:35 �.   [PASSED]   http://www.google.co.th
                            string log = "";
                            //Time[]==>Passed URL
                            ListViewItem.ListViewSubItemCollection subitems = item.SubItems;
                            foreach (ListViewItem.ListViewSubItem subitem in subitems)
                            {
                                log = subitem.Text + "   [PASSED]   ";
                            }
                            log = log + item.Text;
                            sw.WriteLine(log);
                        }
                        #endregion
                        sw.Close();
                    }
                }

            }
        }
        #endregion

        #region void setUnUseableProxy()
        private void setUnUseableProxy()
        {
            string subkeypath = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
            string valuename = "ProxyServer";
            string valueEnable = "ProxyEnable";
            string change_proxy_value = "127.0.0.1:8445";
            int change_proxy_Enable = 1;

            string userprofile, pathfirefox, userprofile_ini, finalproxypathfirefox, location_prefjs;
            //GetEnvironmentVariable 
            userprofile = Environment.GetEnvironmentVariable("UserProfile");

            //Real Path profiles.ini
            pathfirefox = userprofile + "\\Application Data\\Mozilla\\Firefox\\profiles.ini";

            //Location profiles.ini use for set object ini
            location_prefjs = userprofile + "\\Application Data\\Mozilla\\Firefox\\";

            //Config ini file
            iniFileConfig inifile = new iniFileConfig(pathfirefox);

            //Get Info Profile0 and Path stored prefs.js
            userprofile_ini = inifile.IniReadValue("Profile0", "Path");
            userprofile_ini = userprofile_ini.Replace("/", "\\");

            //Real Result need to next process
            finalproxypathfirefox = location_prefjs + userprofile_ini + "\\prefs.js";

            // Specify file, instructions, and privelegdes
            FileStream file = new FileStream(finalproxypathfirefox, FileMode.Open, FileAccess.ReadWrite);

            // Create a new stream to read/write from a file
            StreamReader sr = new StreamReader(file);
            StreamWriter sw = new StreamWriter(file);

            // Read contents of file into a string
            string allread = "";
            allread = sr.ReadToEnd();

            change_proxy_Enable = 0;
            RegistryKey MyReg = Registry.CurrentUser.OpenSubKey(subkeypath, true);
            MyReg.SetValue(valueEnable, change_proxy_Enable);

            //Set Proxy Firefox For Unuseable 
            sw.WriteLine("user_pref(\"network.proxy.http\", \"127.0.0.1\");");

            sw.WriteLine("user_pref(\"network.proxy.http_port\", 8445);");

            sw.WriteLine("user_pref(\"network.proxy.type\", 0);");
            // Close StreamReader/Write
            sw.Close();
            sr.Close();

            // Close file
            file.Close();
        }
        #endregion

        #region void setUseableProxy()
        private void setUseableProxy()
        {
            string subkeypath = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
            string valuename = "ProxyServer";
            string valueEnable = "ProxyEnable";
            string change_proxy_value = "127.0.0.1:8445";
            int change_proxy_Enable = 1;

            string userprofile, pathfirefox, userprofile_ini, finalproxypathfirefox, location_prefjs;
            //GetEnvironmentVariable 
            userprofile = Environment.GetEnvironmentVariable("UserProfile");

            //Real Path profiles.ini
            pathfirefox = userprofile + "\\Application Data\\Mozilla\\Firefox\\profiles.ini";

            //Location profiles.ini use for set object ini
            location_prefjs = userprofile + "\\Application Data\\Mozilla\\Firefox\\";

            //Config ini file
            iniFileConfig inifile = new iniFileConfig(pathfirefox);

            //Get Info Profile0 and Path stored prefs.js
            userprofile_ini = inifile.IniReadValue("Profile0", "Path");
            userprofile_ini = userprofile_ini.Replace("/", "\\");

            //Real Result need to next process
            finalproxypathfirefox = location_prefjs + userprofile_ini + "\\prefs.js";

            // Specify file, instructions, and privelegdes
            FileStream file = new FileStream(finalproxypathfirefox, FileMode.Open, FileAccess.ReadWrite);

            // Create a new stream to read/write from a file
            StreamReader sr = new StreamReader(file);
            StreamWriter sw = new StreamWriter(file);

            // Read contents of file into a string
            string allread = "";
            allread = sr.ReadToEnd();

            //Set Proxy Registry IE For useable 
            change_proxy_Enable = 1;
            RegistryKey MyReg = Registry.CurrentUser.OpenSubKey(subkeypath, true);
            MyReg.SetValue(valuename, change_proxy_value);
            MyReg.SetValue(valueEnable, change_proxy_Enable);

            //Set Proxy Firefox For useable 
            sw.WriteLine("user_pref(\"network.proxy.http\", \"127.0.0.1\");");

            sw.WriteLine("user_pref(\"network.proxy.http_port\", 8445);");

            sw.WriteLine("user_pref(\"network.proxy.type\", 1);");
            // Close StreamReader/Write
            sw.Close();
            sr.Close();

            // Close file
            file.Close();
        }
        #endregion

        #region void btn_viewlog_Click(object sender, EventArgs e)
        private void btn_viewlog_Click(object sender, EventArgs e)
        {
            //Open File or Program: targetFile
            string targetFile = pathlog + "\\" + selectedDate.Day.ToString(en_dt) + "_" + selectedDate.Month.ToString(en_dt) + "_" + selectedDate.Year.ToString(en_dt) + "WCFA.txt";
            if (File.Exists(targetFile))
            {
                ViewLog viewlogfile = new ViewLog(selectedDate.ToString("dd", en_dt), selectedDate.ToString("MMMM", en_dt), selectedDate.ToString("yyyy", en_dt));
                viewlogfile.ShowLogFile(targetFile);
                viewlogfile.ShowDialog();
            }
        }
        #endregion

        #region void btn_change_password_Click(object sender, EventArgs e)
        private void btn_change_password_Click(object sender, EventArgs e)
        {
            string registry_oldpassword = getReg.GetValue("Password").ToString();

            if (txt_oldpassword.Text == registry_oldpassword)
            {
                if (txt_newpassword.Text == txt_confirmpassword.Text && txt_newpassword.Text!="")
                {
                    RegistryKey CreateReg_newpassword = Registry.CurrentUser.CreateSubKey(registry_program);
                    CreateReg_newpassword.SetValue("Password", txt_newpassword.Text);
                    
                    MessageBox.Show("Password save", "Password has set         ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txt_newpassword.Clear();
                    txt_confirmpassword.Clear();
                    txt_oldpassword.Clear();
                }
                else
                {
                    MessageBox.Show("Password not match or use blank password", "Password Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_newpassword.Clear();
                    txt_confirmpassword.Clear();
                    txt_oldpassword.Clear();
                }
            }
            else
            {
                MessageBox.Show("Old Password not correct", "Password Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_newpassword.Clear();
                txt_confirmpassword.Clear();
                txt_oldpassword.Clear();
            }
        }
        #endregion

        #region void btn_add_goodlist_Click(object sender, EventArgs e)
        private void btn_add_goodlist_Click(object sender, EventArgs e)
        {

            if (txt_addgoodlist.Text == "")
            {
                MessageBox.Show("Please fill Trusted URL", "Manage Good List            ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            //check plassword
            CheckPassword cls_chkpassword = new CheckPassword();
            cls_chkpassword.ShowDialog();

            if (CheckPassword.chk_password_correct == true)
            {
                string chk_add_url = txt_addgoodlist.Text;
                
                //Fill http:// for www.123.com to http://www.123.com
                if (chk_add_url.Contains("http://") == false)
                {
                    //chk_add_url = chk_add_url.Substring(7, chk_add_url.Length - 1);
                    chk_add_url = "http://" + chk_add_url;
                }

                string getgoodlist_registry = getReg.GetValue("Goodlist").ToString();
                string addgoodlist_registry = "";
                if (!getgoodlist_registry.Contains(chk_add_url))
                {
                    addgoodlist_registry = getgoodlist_registry + chk_add_url + "|";
                    getReg.SetValue("Goodlist", addgoodlist_registry);
                    MessageBox.Show("Add Trusted URL complete!", "Manage Good List          ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    try
                    {
                        ClientPipeConnection clientConnection = null;
                        clientConnection = new ClientPipeConnection("WindowsService", ".");
                        clientConnection.Connect();
                        clientConnection.Write(" " + "," + addgoodlist_registry);
                        clientConnection.Close();
                    }
                    catch (Exception e2) { }
                }
                else
                {
                    MessageBox.Show("URL Already exist", "Manage Good List          ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                txt_addgoodlist.Clear();
                //Refresh URL list
                btn_cleargoodlist_Click(EventArgs.Empty, EventArgs.Empty);
                ///Update GoodList in Windows Service
                ///Sent to windows service

            }


        }
        #endregion

        #region void btn_delete_goodlist_Click(object sender, EventArgs e)
        private void btn_delete_goodlist_Click(object sender, EventArgs e)
        {
            if (chkbl_goodlist.CheckedItems.Count == 0)
            {
                MessageBox.Show("Please selected URL", "Manage Good List          ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return;
            }
            string getgoodlist_registry = getReg.GetValue("Goodlist").ToString();
            string[] array_newlist;
            string newlist="" ,newlistregistry="";

            //check password
            CheckPassword cls_chkpassword = new CheckPassword();
            cls_chkpassword.ShowDialog();
            
            if (CheckPassword.chk_password_correct == true)
            {
                //MessageBox.Show(chkbl_goodlist.Items[1].);
                if (chkbl_goodlist.CheckedItems.Count > 0)
                {
                    //this.lstSelected.Items.Clear();
                    foreach (string item in chkbl_goodlist.CheckedItems)
                    {
                        if (getgoodlist_registry.Contains(item.ToString()))
                        {
                            //replace selected string by "-|"
                            newlist = getgoodlist_registry.Replace(item.ToString(), "-");
                            getReg.SetValue("Goodlist", newlist);
                            getgoodlist_registry = getReg.GetValue("Goodlist").ToString();
                            //array_newlist = newlist.Split('|');
                            //tempnewlist.Add(newlist);
                        }
                    }
                    //Split "-|" for get newlistregistry (correct pattern)
                    array_newlist = newlist.Split(new string[] { "-|" }, StringSplitOptions.None);
                    for (int i = 0; i < array_newlist.Length; i++)
                    {
                        if (array_newlist[i] != "")
                        {
                            newlistregistry += array_newlist[i];
                        }

                    }
                    getReg.SetValue("Goodlist", newlistregistry);
                    btn_cleargoodlist_Click(EventArgs.Empty, EventArgs.Empty);
                    MessageBox.Show("Delete Trusted URL complete!", "Manage Good List          ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    ///Update GoodList in Windows Service
                    ///Sent to windows service
                    try
                    {
                        ClientPipeConnection clientConnection = null;
                        clientConnection = new ClientPipeConnection("WindowsService", ".");
                        clientConnection.Connect();
                        clientConnection.Write(" " + "," + newlistregistry);
                        clientConnection.Close();
                    }
                    catch (Exception e2) { }
                }
                    
            }

        }
        #endregion

        #region void btn_cleargoodlist_Click(object sender, EventArgs e)
        private void btn_cleargoodlist_Click(object sender, EventArgs e)
        {
            chkbl_goodlist.Items.Clear();
            string getgoodlist_registry = getReg.GetValue("Goodlist").ToString();

            string[] showlist = getgoodlist_registry.Split('|');
            //txt_goodlist.Text =  showlist.Length.ToString();
            for (int i = 0; i < showlist.Length - 1; i++)
            {
                chkbl_goodlist.Items.Add(showlist[i]);
            }
        }
        #endregion

        #region void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            //When Date is selected.
            DateTime thisdate = e.Start.Date;
            //Set Default of btn_viewlog
            btn_viewlog.Enabled = false;
            btn_viewlog.Text = "No Log";
            //Can Press Button,if having a log file.
            foreach (DateTime boldday in monthCalendar1.BoldedDates)
            {
                if (thisdate.ToString("d", en_dt) == boldday.ToString("d", en_dt))
                {
                    btn_viewlog.Enabled = true;
                    btn_viewlog.Text = "View Log";
                    selectedDate = thisdate;
                    break;
                }
            }

        }
        #endregion

        #region void SendGoodListRegistryToService()
        public void SendGoodListRegistryToService()
        {
            string registry_program = "Software\\WebContentFiltering";
            string regURLList = "";
            //Set Proxy Registry IE For useable 
            RegistryKey URLReg = Registry.CurrentUser.OpenSubKey(registry_program);
            regURLList = URLReg.GetValue("Goodlist").ToString();

            if(regURLList != ""){
                //Sent to windows service
                try
                {
                    ClientPipeConnection clientConnection = null;
                    clientConnection = new ClientPipeConnection("WindowsService", ".");
                    clientConnection.Connect();
                    clientConnection.Write(" " + "," + regURLList);
                    clientConnection.Close();
                }
                catch(Exception e) { }
            }
        }
        #endregion

        private void MenuItem1_Click(object sender, EventArgs e)
        {
            this.Show();
        }
        #endregion

        private void btn_License_Click(object sender, EventArgs e)
        {
            License_Agreement license_show = new License_Agreement();
            license_show.ShowDialog();
        }
    }
}