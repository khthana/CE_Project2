using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;//Registry

namespace WindowsControl
{
    public partial class CheckPassword : Form
    {
        private string registry_program = "Software\\WebContentFiltering";
        public RegistryKey getPwd ;
        public static bool chk_password_correct = false;

        #region CheckPassword()
        public CheckPassword()
        {
            InitializeComponent();
            getPwd = Registry.CurrentUser.OpenSubKey(registry_program, true);
        }
        #endregion

        #region void btn_chkok_Click(object sender, EventArgs e)
        private void btn_chkok_Click(object sender, EventArgs e)
        {
            string str_check = "";
            //Show value
            string str_password = getPwd.GetValue("Password").ToString();
            str_check = txt_chkpassword.Text;
            if (str_check == str_password)
            {
                chk_password_correct = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Password doesn't match", "Web Content Filtering         ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //chk_password_correct = false;

        }
        #endregion

        #region btn_chkcancel_Click(object sender, EventArgs e)
        private void btn_chkcancel_Click(object sender, EventArgs e)
        {
            chk_password_correct = false;
            this.Close();
        }
        #endregion
    }
}