using System.Drawing;
namespace WindowsControl
{
    partial class WindowsControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WindowsControl));
            this.scroll_Level = new System.Windows.Forms.TrackBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btn_apply = new System.Windows.Forms.Button();
            this.lb_low_des1 = new System.Windows.Forms.Label();
            this.lb_medium_des2 = new System.Windows.Forms.Label();
            this.lb_medium_des1 = new System.Windows.Forms.Label();
            this.lb_high_des2 = new System.Windows.Forms.Label();
            this.lb_high_des1 = new System.Windows.Forms.Label();
            this.lb_high = new System.Windows.Forms.Label();
            this.lb_medium = new System.Windows.Forms.Label();
            this.lb_low = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_date1 = new System.Windows.Forms.Label();
            this.listViewBlock = new System.Windows.Forms.ListView();
            this.col_urlblock = new System.Windows.Forms.ColumnHeader();
            this.col_timeblock = new System.Windows.Forms.ColumnHeader();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label_date2 = new System.Windows.Forms.Label();
            this.listViewPass = new System.Windows.Forms.ListView();
            this.col_urlpass = new System.Windows.Forms.ColumnHeader();
            this.col_timepass = new System.Windows.Forms.ColumnHeader();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_delete_goodlist = new System.Windows.Forms.Button();
            this.btn_cleargoodlist = new System.Windows.Forms.Button();
            this.chkbl_goodlist = new System.Windows.Forms.CheckedListBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btn_add_goodlist = new System.Windows.Forms.Button();
            this.txt_addgoodlist = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_change_password = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_confirmpassword = new System.Windows.Forms.TextBox();
            this.txt_newpassword = new System.Windows.Forms.TextBox();
            this.txt_oldpassword = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_viewlog = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.serviceController1 = new System.ServiceProcess.ServiceController();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemShutdown = new System.Windows.Forms.ToolStripMenuItem();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.logo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.scroll_Level)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.SuspendLayout();
            // 
            // scroll_Level
            // 
            this.scroll_Level.BackColor = System.Drawing.Color.Lavender;
            resources.ApplyResources(this.scroll_Level, "scroll_Level");
            this.scroll_Level.Name = "scroll_Level";
            this.scroll_Level.SmallChange = 0;
            this.scroll_Level.TickFrequency = 5;
            this.scroll_Level.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.btn_apply);
            this.groupBox1.Controls.Add(this.lb_low_des1);
            this.groupBox1.Controls.Add(this.lb_medium_des2);
            this.groupBox1.Controls.Add(this.lb_medium_des1);
            this.groupBox1.Controls.Add(this.lb_high_des2);
            this.groupBox1.Controls.Add(this.lb_high_des1);
            this.groupBox1.Controls.Add(this.lb_high);
            this.groupBox1.Controls.Add(this.lb_medium);
            this.groupBox1.Controls.Add(this.lb_low);
            this.groupBox1.Controls.Add(this.scroll_Level);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // btn_apply
            // 
            resources.ApplyResources(this.btn_apply, "btn_apply");
            this.btn_apply.Name = "btn_apply";
            this.btn_apply.UseVisualStyleBackColor = true;
            this.btn_apply.Click += new System.EventHandler(this.btn_apply_Click);
            // 
            // lb_low_des1
            // 
            resources.ApplyResources(this.lb_low_des1, "lb_low_des1");
            this.lb_low_des1.Name = "lb_low_des1";
            // 
            // lb_medium_des2
            // 
            resources.ApplyResources(this.lb_medium_des2, "lb_medium_des2");
            this.lb_medium_des2.ForeColor = System.Drawing.Color.DarkGray;
            this.lb_medium_des2.Name = "lb_medium_des2";
            // 
            // lb_medium_des1
            // 
            resources.ApplyResources(this.lb_medium_des1, "lb_medium_des1");
            this.lb_medium_des1.ForeColor = System.Drawing.Color.DarkGray;
            this.lb_medium_des1.Name = "lb_medium_des1";
            // 
            // lb_high_des2
            // 
            resources.ApplyResources(this.lb_high_des2, "lb_high_des2");
            this.lb_high_des2.ForeColor = System.Drawing.Color.DarkGray;
            this.lb_high_des2.Name = "lb_high_des2";
            // 
            // lb_high_des1
            // 
            resources.ApplyResources(this.lb_high_des1, "lb_high_des1");
            this.lb_high_des1.ForeColor = System.Drawing.Color.DarkGray;
            this.lb_high_des1.Name = "lb_high_des1";
            // 
            // lb_high
            // 
            resources.ApplyResources(this.lb_high, "lb_high");
            this.lb_high.ForeColor = System.Drawing.Color.Silver;
            this.lb_high.Name = "lb_high";
            // 
            // lb_medium
            // 
            resources.ApplyResources(this.lb_medium, "lb_medium");
            this.lb_medium.ForeColor = System.Drawing.Color.Silver;
            this.lb_medium.Name = "lb_medium";
            // 
            // lb_low
            // 
            resources.ApplyResources(this.lb_low, "lb_low");
            this.lb_low.Name = "lb_low";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage2);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox2);
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_date1);
            this.groupBox2.Controls.Add(this.listViewBlock);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // label_date1
            // 
            resources.ApplyResources(this.label_date1, "label_date1");
            this.label_date1.Name = "label_date1";
            // 
            // listViewBlock
            // 
            this.listViewBlock.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listViewBlock.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_urlblock,
            this.col_timeblock});
            this.listViewBlock.GridLines = true;
            this.listViewBlock.HideSelection = false;
            this.listViewBlock.HoverSelection = true;
            resources.ApplyResources(this.listViewBlock, "listViewBlock");
            this.listViewBlock.Name = "listViewBlock";
            this.listViewBlock.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listViewBlock.UseCompatibleStateImageBehavior = false;
            this.listViewBlock.View = System.Windows.Forms.View.Details;
            // 
            // col_urlblock
            // 
            resources.ApplyResources(this.col_urlblock, "col_urlblock");
            // 
            // col_timeblock
            // 
            resources.ApplyResources(this.col_timeblock, "col_timeblock");
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox3);
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label_date2);
            this.groupBox3.Controls.Add(this.listViewPass);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // label_date2
            // 
            resources.ApplyResources(this.label_date2, "label_date2");
            this.label_date2.Name = "label_date2";
            // 
            // listViewPass
            // 
            this.listViewPass.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_urlpass,
            this.col_timepass});
            this.listViewPass.GridLines = true;
            this.listViewPass.HideSelection = false;
            resources.ApplyResources(this.listViewPass, "listViewPass");
            this.listViewPass.Name = "listViewPass";
            this.listViewPass.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listViewPass.UseCompatibleStateImageBehavior = false;
            this.listViewPass.View = System.Windows.Forms.View.Details;
            // 
            // col_urlpass
            // 
            resources.ApplyResources(this.col_urlpass, "col_urlpass");
            // 
            // col_timepass
            // 
            resources.ApplyResources(this.col_timepass, "col_timepass");
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox6);
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Controls.Add(this.groupBox9);
            resources.ApplyResources(this.tabPage6, "tabPage6");
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label19);
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_delete_goodlist);
            this.groupBox8.Controls.Add(this.btn_cleargoodlist);
            this.groupBox8.Controls.Add(this.chkbl_goodlist);
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // btn_delete_goodlist
            // 
            resources.ApplyResources(this.btn_delete_goodlist, "btn_delete_goodlist");
            this.btn_delete_goodlist.Name = "btn_delete_goodlist";
            this.btn_delete_goodlist.UseVisualStyleBackColor = true;
            this.btn_delete_goodlist.Click += new System.EventHandler(this.btn_delete_goodlist_Click);
            // 
            // btn_cleargoodlist
            // 
            resources.ApplyResources(this.btn_cleargoodlist, "btn_cleargoodlist");
            this.btn_cleargoodlist.Name = "btn_cleargoodlist";
            this.btn_cleargoodlist.UseVisualStyleBackColor = true;
            this.btn_cleargoodlist.Click += new System.EventHandler(this.btn_cleargoodlist_Click);
            // 
            // chkbl_goodlist
            // 
            this.chkbl_goodlist.FormattingEnabled = true;
            resources.ApplyResources(this.chkbl_goodlist, "chkbl_goodlist");
            this.chkbl_goodlist.Name = "chkbl_goodlist";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btn_add_goodlist);
            this.groupBox9.Controls.Add(this.txt_addgoodlist);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label13);
            resources.ApplyResources(this.groupBox9, "groupBox9");
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.TabStop = false;
            // 
            // btn_add_goodlist
            // 
            resources.ApplyResources(this.btn_add_goodlist, "btn_add_goodlist");
            this.btn_add_goodlist.Name = "btn_add_goodlist";
            this.btn_add_goodlist.UseVisualStyleBackColor = true;
            this.btn_add_goodlist.Click += new System.EventHandler(this.btn_add_goodlist_Click);
            // 
            // txt_addgoodlist
            // 
            resources.ApplyResources(this.txt_addgoodlist, "txt_addgoodlist");
            this.txt_addgoodlist.Name = "txt_addgoodlist";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Controls.Add(this.groupBox4);
            resources.ApplyResources(this.tabPage5, "tabPage5");
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.btn_change_password);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.txt_confirmpassword);
            this.groupBox5.Controls.Add(this.txt_newpassword);
            this.groupBox5.Controls.Add(this.txt_oldpassword);
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // btn_change_password
            // 
            resources.ApplyResources(this.btn_change_password, "btn_change_password");
            this.btn_change_password.Name = "btn_change_password";
            this.btn_change_password.UseVisualStyleBackColor = true;
            this.btn_change_password.Click += new System.EventHandler(this.btn_change_password_Click);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // txt_confirmpassword
            // 
            resources.ApplyResources(this.txt_confirmpassword, "txt_confirmpassword");
            this.txt_confirmpassword.Name = "txt_confirmpassword";
            this.txt_confirmpassword.UseSystemPasswordChar = true;
            // 
            // txt_newpassword
            // 
            resources.ApplyResources(this.txt_newpassword, "txt_newpassword");
            this.txt_newpassword.Name = "txt_newpassword";
            this.txt_newpassword.UseSystemPasswordChar = true;
            // 
            // txt_oldpassword
            // 
            resources.ApplyResources(this.txt_oldpassword, "txt_oldpassword");
            this.txt_oldpassword.Name = "txt_oldpassword";
            this.txt_oldpassword.UseSystemPasswordChar = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.btn_viewlog);
            this.groupBox4.Controls.Add(this.monthCalendar1);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // btn_viewlog
            // 
            resources.ApplyResources(this.btn_viewlog, "btn_viewlog");
            this.btn_viewlog.Name = "btn_viewlog";
            this.btn_viewlog.UseVisualStyleBackColor = true;
            this.btn_viewlog.Click += new System.EventHandler(this.btn_viewlog_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.Color.Lavender;
            resources.ApplyResources(this.monthCalendar1, "monthCalendar1");
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TitleBackColor = System.Drawing.Color.LightSteelBlue;
            this.monthCalendar1.TrailingForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox7);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.label6);
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label2);
            this.groupBox10.Controls.Add(this.label3);
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.label4);
            this.groupBox10.Controls.Add(this.label7);
            this.groupBox10.Controls.Add(this.label5);
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // serviceController1
            // 
            this.serviceController1.ServiceName = "Web Content Filtering";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            resources.ApplyResources(this.notifyIcon1, "notifyIcon1");
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem1,
            this.MenuItemShutdown});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.contextMenuStrip1.ShowImageMargin = false;
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // MenuItem1
            // 
            this.MenuItem1.Name = "MenuItem1";
            resources.ApplyResources(this.MenuItem1, "MenuItem1");
            this.MenuItem1.Click += new System.EventHandler(this.MenuItem1_Click);
            // 
            // MenuItemShutdown
            // 
            this.MenuItemShutdown.Name = "MenuItemShutdown";
            resources.ApplyResources(this.MenuItemShutdown, "MenuItemShutdown");
            this.MenuItemShutdown.Click += new System.EventHandler(this.MenuItemShutdown_Click);
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // logo
            // 
            this.logo.Image = global::WindowsControl.Properties.Resources.logo_Webcontentfiltering2;
            resources.ApplyResources(this.logo, "logo");
            this.logo.Name = "logo";
            this.logo.TabStop = false;
            // 
            // WindowsControl
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.logo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "WindowsControl";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WindowsControl_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.scroll_Level)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.TrackBar scroll_Level;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lb_high;
        private System.Windows.Forms.Label lb_medium;
        private System.Windows.Forms.Label lb_low;
        private System.Windows.Forms.Button btn_apply;
        private System.Windows.Forms.Label lb_high_des1;
        private System.Windows.Forms.Label lb_low_des1;
        private System.Windows.Forms.Label lb_medium_des2;
        private System.Windows.Forms.Label lb_medium_des1;
        private System.Windows.Forms.Label lb_high_des2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.ServiceProcess.ServiceController serviceController1;
        public System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MenuItemShutdown;
        private System.Windows.Forms.ListView listViewBlock;
        private System.Windows.Forms.ColumnHeader col_timeblock;
        private System.Windows.Forms.ColumnHeader col_urlblock;
        private System.Windows.Forms.ListView listViewPass;
        private System.Windows.Forms.ColumnHeader col_urlpass;
        private System.Windows.Forms.ColumnHeader col_timepass;
        private System.Windows.Forms.Label label_date2;
        private System.Windows.Forms.Label label_date1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_viewlog;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox txt_oldpassword;
        private System.Windows.Forms.TextBox txt_confirmpassword;
        private System.Windows.Forms.TextBox txt_newpassword;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_change_password;
        private System.Windows.Forms.CheckedListBox chkbl_goodlist;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_delete_goodlist;
        private System.Windows.Forms.Button btn_add_goodlist;
        private System.Windows.Forms.TextBox txt_addgoodlist;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btn_cleargoodlist;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
    }
}

