namespace WindowsControl
{
    partial class ViewLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewLog));
            this.listView_log = new System.Windows.Forms.ListView();
            this.col_urlblock = new System.Windows.Forms.ColumnHeader();
            this.col_status = new System.Windows.Forms.ColumnHeader();
            this.col_timeblock = new System.Windows.Forms.ColumnHeader();
            this.label_dateLog = new System.Windows.Forms.Label();
            this.btn_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listView_log
            // 
            this.listView_log.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_urlblock,
            this.col_status,
            this.col_timeblock});
            this.listView_log.GridLines = true;
            this.listView_log.Location = new System.Drawing.Point(12, 39);
            this.listView_log.Name = "listView_log";
            this.listView_log.Size = new System.Drawing.Size(403, 225);
            this.listView_log.TabIndex = 0;
            this.listView_log.UseCompatibleStateImageBehavior = false;
            this.listView_log.View = System.Windows.Forms.View.Details;
            // 
            // col_urlblock
            // 
            this.col_urlblock.Text = "URL";
            this.col_urlblock.Width = 238;
            // 
            // col_status
            // 
            this.col_status.Text = "Status";
            this.col_status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_status.Width = 84;
            // 
            // col_timeblock
            // 
            this.col_timeblock.Text = "Time";
            this.col_timeblock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_timeblock.Width = 77;
            // 
            // label_dateLog
            // 
            this.label_dateLog.AutoSize = true;
            this.label_dateLog.Location = new System.Drawing.Point(92, 13);
            this.label_dateLog.Name = "label_dateLog";
            this.label_dateLog.Size = new System.Drawing.Size(36, 13);
            this.label_dateLog.TabIndex = 1;
            this.label_dateLog.Text = "Date: ";
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(337, 270);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(78, 26);
            this.btn_close.TabIndex = 2;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Log Date :";
            // 
            // ViewLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(427, 303);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.label_dateLog);
            this.Controls.Add(this.listView_log);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ViewLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Log";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView_log;
        private System.Windows.Forms.ColumnHeader col_urlblock;
        private System.Windows.Forms.ColumnHeader col_timeblock;
        private System.Windows.Forms.Label label_dateLog;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.ColumnHeader col_status;
        private System.Windows.Forms.Label label1;
    }
}