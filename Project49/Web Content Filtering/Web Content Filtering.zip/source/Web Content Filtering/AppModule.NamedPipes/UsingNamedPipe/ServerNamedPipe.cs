using System;
using System.Threading;
using System.IO;
using System.Diagnostics;

using AppModule.InterProcessComm;
using AppModule.NamedPipes;

namespace UsingNamedPipe
{
    #region comment
    /// <summary>
    /// This Class Work about Server Named Pipe,especially Listening on Pipe
    /// </summary> 
    #endregion
	public class ServerNamedPipe : IDisposable {
        #region comment
        /// <summary>
        /// Instance of the Pipe thread 
        /// </summary> 
        #endregion
		protected internal Thread PipeThread;
        #region comment
        /// <summary>
        /// Instance of Pipe when connection: transfer data across pipe.
        /// </summary> 
        #endregion
		protected internal ServerPipeConnection PipeConnection;
        #region comment
        /// <summary>
        /// Now, listen?
        /// </summary> 
        #endregion
		protected internal bool Listen = false;//Old value = true
        #region comment
        /// <summary>
        /// Now time that action
        /// </summary> 
        #endregion
		protected internal DateTime LastAction;
        #region comment
        /// <summary>
        /// 
        /// </summary> 
        #endregion
        private bool disposed = false;
        #region comment
        /// <summary>
        /// argument 1 of data from client.
        /// </summary> 
        #endregion
        protected static string str1;
        #region comment
        /// <summary>
        /// argument 2 of data from client.
        /// </summary> 
        #endregion
        protected static string str2;
        #region comment
        /// <summary>
        /// specify spliter.
        /// </summary> 
        #endregion
        protected static string[] split;
        #region comment
        /// <summary>
        /// Instance of the PipeManager
        /// </summary> 
        #endregion
        protected PipeManager pipeManager = null;
        #region comment
        /// <summary>
        /// set Instance of the PipeManager
        /// </summary>
        /// <param name="pipemanager"></param> 
        #endregion
        public void SetPipeManager(PipeManager pipemanager)
        {
            this.pipeManager = pipemanager;
        }
        #region comment
        /// <summary>
        /// loop for Listening: data from another side.
        /// </summary> 
        #endregion
        public virtual void PipeListener()
        {
			//CheckIfDisposed();
			/*try {
                Listen = pipeManager.Listen;
				//Form1.ActivityRef.AppendText("Pipe " + this.PipeConnection.NativeHandle.ToString() + ": new pipe started" + Environment.NewLine);
                while (Listen) {
					LastAction = DateTime.Now;
					string request = PipeConnection.Read();
                    //Split string Read by ","
                    split = request.Split(new Char[] { ',' });
                    str1 = split[0];
                    str2 = split[1];
					LastAction = DateTime.Now;
                    if (request.Trim() != "")
                    {
                        //PipeConnection.Write("this like a abstract");
					}
					else {
						//PipeConnection.Write("Error: bad request");
					}
                   
					LastAction = DateTime.Now;
					PipeConnection.Disconnect();
					if (Listen) {
						//Form1.ActivityRef.AppendText("Pipe " + this.PipeConnection.NativeHandle.ToString() + ": listening" + Environment.NewLine);
						Connect();
					}
                    pipeManager.WakeUp();
				}
			} 
			catch (System.Threading.ThreadAbortException ex) { }
			catch (System.Threading.ThreadStateException ex) { }
			catch (Exception ex) { 
				// Log exception
			}
			finally {
				this.Close();
			}*/
		}
        #region comment
        /// <summary>
        /// connect on this pipe.
        /// </summary> 
        #endregion
		protected internal void Connect() {
			CheckIfDisposed();
			PipeConnection.Connect();
		}
        #region comment
        /// <summary>
        /// close on this pipe.
        /// </summary> 
        #endregion
		protected internal void Close() {
			CheckIfDisposed();
			this.Listen = false;
            pipeManager.RemoveServerChannel(this.PipeConnection.NativeHandle);
			this.Dispose();
		}
        #region comment
        /// <summary>
        /// start pipe connection for transferable data
        /// </summary> 
        #endregion
		protected internal void Start() {
			CheckIfDisposed();
			PipeThread.Start();
		}
        #region comment
        /// <summary>
        /// check if dispoesd
        /// </summary> 
        #endregion
        public void CheckIfDisposed()
        {
            Debug.WriteLine("disposed(ServerN "+this.ToString()+"): " + this.disposed.ToString());
			if(this.disposed) {
				throw new ObjectDisposedException("ServerNamedPipe");
			}
		}
        #region comment
        /// <summary>
        /// Implement IDisposable.
        /// Do not make this method virtual.
        /// A derived class should not be able to override this method.
        /// </summary> 
        #endregion
        public void Dispose()
        {
			Dispose(true);
            #region comment
            /// This object will be cleaned up by the Dispose method.
            /// Therefore, you should call GC.SupressFinalize to
            /// take this object off the finalization queue 
            /// and prevent finalization code for this object
            /// from executing a second time. 
            #endregion
			GC.SuppressFinalize(this);
		}
        #region comment
        /// <summary>
        ///Dispose(bool disposing) executes in two distinct scenarios.
        /// If disposing equals true, the method has been called directly
        /// or indirectly by a user's code. Managed and unmanaged resources
        /// can be disposed.
        /// If disposing equals false, the method has been called by the 
        /// runtime from inside the finalizer and you should not reference 
        /// other objects. Only unmanaged resources can be disposed.

        /// </summary>
        /// <param name="disposing"></param> 
        #endregion
        protected virtual void Dispose(bool disposing)
        {
			if(!this.disposed) {
				PipeConnection.Dispose();
				if (PipeThread != null) {
					try {
						PipeThread.Abort();
					} 
					catch (System.Threading.ThreadAbortException ex) { }
					catch (System.Threading.ThreadStateException ex) { }
					catch (Exception ex) {
						// Log exception
					}
				}
			}
			disposed = true;         
		}
        #region comment
        /// <summary>
        /// Destructor of ServerNamedPipe.
        /// </summary> 
        #endregion
		~ServerNamedPipe() {
			Dispose(false);
		}
        #region comment
        /// <summary>
        /// Constructor of the ServerNamedPipe
        /// </summary>
        /// <param name="name"></param>
        /// <param name="outBuffer"></param>
        /// <param name="inBuffer"></param>
        /// <param name="maxReadBytes"></param>
        /// <param name="secure"></param> 
        #endregion
        public ServerNamedPipe(string name, uint outBuffer, uint inBuffer, int maxReadBytes, bool secure)
        {
			PipeConnection = new ServerPipeConnection(name, outBuffer, inBuffer, maxReadBytes, secure);

		}
        #region comment
        /// <summary>
        /// command this create thread for loop listening.
        /// </summary> 
        #endregion
        public void StartThread(){
            PipeThread = new Thread(new ThreadStart(PipeListener));
            PipeThread.IsBackground = true;
            PipeThread.Name = "Pipe Thread " + this.PipeConnection.NativeHandle.ToString();
            LastAction = DateTime.Now;
        }
	}
}