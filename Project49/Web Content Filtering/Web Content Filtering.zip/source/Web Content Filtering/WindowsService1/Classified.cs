using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Drawing;
namespace WindowsService1
{
    class Classified
    {
        private double[,] eigenvec;
        private double[] mean_di, cen1, cen2, cen3;

        //Class for classifly Image by their dimention
        #region Classified()
        public Classified()
        {
            //Create init parameter that gave from eigen function
            //Eigenvector of dimention taht have maximum eigen value 
            eigenvec = new double[,]{{-0.46076256 ,-0.48284077 , 0.2327821 , -0.05986624  ,0.10544402 , 0.69690225},
                              { 0.37311171 , 0.37007975  ,0.03439508 ,0.50656072 , 0.50569109  ,0.45860481}};

            mean_di = new double[] { 34.63125, 32.711525, 12.8, 56.332, 58.8755, 65.11667025 };// mean of dimention 1 ,2 ,3 ,4 ,5 ,6
            cen1 = new double[] { -34.1640, 28.3840 }; // Centriod of group 1 that isn't Pornographic
            cen2 = new double[] { 76.3960, -4.6239 }; // Centriod of group 2 that is Pornographic
            cen3 = new double[] { -113.0394, -18.9615 };// Centriod of group 3 that hasn't skin pixel


        }
        #endregion

        #region double[] Fn_Eigenvec(double[] Data)
        public double[] Fn_Eigenvec(double[] Data)
        {
            //Function to find FinalData to use in K-nearest neighbor

            //Find DataAdjusted By minus every data with their mean
            //ArrayList DataAdj = new ArrayList();
            ArrayList DataAdjust = new ArrayList();
            int CCV = 0;
            double ME;
            for (int i = 0; i < Data.Length;i++ )
            {
                //DataAdjust = new ArrayList();
                ME = mean_di[CCV];
                DataAdjust.Add(Data[i] - ME);
                ++CCV;
                //DataAdj.Add(DataAdjust);
            }
            double[] FinalData = matrixmultiply(eigenvec, DataAdjust);
            return FinalData;
        }
        #endregion

        #region double[] matrixmultiply(double[,] eigenvec_in, ArrayList DataAdj_in)
        public double[] matrixmultiply(double[,] eigenvec_in, ArrayList DataAdj_in)
        {
            double sum=0;
            double DataAdj_out =0 ;
            double[] Final = new double[2];
            for (int i = 0; i < eigenvec_in.GetLength(0);i++ )
            {
                for (int j = 0; j < eigenvec_in.GetLength(1); j++)
                {
                    DataAdj_out = (double)DataAdj_in[j];
                    sum += eigenvec_in[i, j] * DataAdj_out;
                }
                Final[i] = sum;
            }
            return Final;
        }
        #endregion

        #region string KNN(double[] Final, bool limitrecursive_inclassify)
        public string KNN(double[] Final, bool limitrecursive_inclassify)
        {
            //Function classified data with K-nearest neighbor
            //double[] cas1, cas2, cas3,index;
            double dist1=0, dist2=0, dist3=0,Dall=0;
            string summary="";
            bool limitrecursive_classify = limitrecursive_inclassify;

            //Find lenght of that dimention with 3 centriod
           // for (int i = 0; i < Final.Length;i++ )
            //{
                dist1 = Math.Sqrt(((Final[1] - cen1[0]) * (Final[1] - cen1[0])) + ((Final[0] - cen1[1]) * (Final[0] - cen1[1])));
                dist2 = Math.Sqrt(((Final[1] - cen2[0]) * (Final[1] - cen2[0])) + ((Final[0] - cen2[1]) * (Final[0] - cen2[1])));
                dist3 = Math.Sqrt(((Final[1] - cen3[0]) * (Final[1] - cen3[0])) + ((Final[0] - cen3[1]) * (Final[0] - cen3[1])));
                
                Dall = Math.Min(dist1,Math.Min(dist2,dist3));
                //Find shortest lenght from 3 lenght
                if (Dall == dist2 || limitrecursive_classify == true)
                {
                    summary = "This is Pornographic";
                }
                else
                {
                    summary = "This is NO Pornographic";
                }
           // }
            return summary;

        }
        #endregion

    }
}
