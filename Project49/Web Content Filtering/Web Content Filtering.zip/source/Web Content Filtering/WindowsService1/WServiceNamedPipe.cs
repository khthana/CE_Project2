using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using AppModule.NamedPipes;
using UsingNamedPipe;

namespace WindowsService1
{
    #region comment
    /// <summary>
    /// Named Pipe for using with Windows Service only.(Listening)
    /// </summary> 
    #endregion
    public class WServiceNamedPipe : ServerNamedPipe{
        private bool disposed = false;
        public static string gobal_level = "LOW";
        public static string[] goodList = null;
        public WServiceNamedPipe(String name,uint outBuffer, uint inBuffer, int maxReadBytes, bool secure)
            : base(name, outBuffer, inBuffer, maxReadBytes, secure)
        {
            this.pipeManager = pipeManager;
        }
        #region comment
        /// <summary>
        /// this loop for listening: data from Windows Control.
        /// </summary> 
        #endregion
        public override void PipeListener()
        {
            CheckIfDisposed();
            try
            {
                Listen = pipeManager.Listen;
                while (Listen)
                {
                    LastAction = DateTime.Now;
                    string request = PipeConnection.Read();
                    ///Split string Read by ","
                    split = request.Split(new Char[] { ',' });
                    if (split[0] != " ")
                    {
                        gobal_level = split[0];
                    }
                    else
                    {
                        if(split[1] != ""){
                            goodList = split[1].Split('|');
                        }
                    }
                    
                   
                    LastAction = DateTime.Now;
                    /*if (request.Trim() != "")
                    {
                        PipeConnection.Write(gobal_level);
                    }
                    else
                    {
                        PipeConnection.Write("Error");
                    }*/
                    LastAction = DateTime.Now;
                    PipeConnection.Disconnect();
                    if (Listen)
                    {
                        Connect();
                    }
                    pipeManager.WakeUp();
                }
            }
            catch (System.Threading.ThreadAbortException ex) { }
            catch (System.Threading.ThreadStateException ex) { }
            catch (Exception ex)
            {
                // Log exception
            }
            //finally
            //{
            //    this.Close();
            //}
        }
        #region comment
        /// <summary>
        /// check if dispoesd
        /// </summary> 
        #endregion
        /*protected override void CheckIfDisposed()
        {
            if (this.disposed)
            {
                throw new ObjectDisposedException("WServiceNamedPipe");
            }
        }*/

        #region comment
        /// <summary>
        ///Dispose(bool disposing) executes in two distinct scenarios.
        /// If disposing equals true, the method has been called directly
        /// or indirectly by a user's code. Managed and unmanaged resources
        /// can be disposed.
        /// If disposing equals false, the method has been called by the 
        /// runtime from inside the finalizer and you should not reference 
        /// other objects. Only unmanaged resources can be disposed.

        /// </summary>
        /// <param name="disposing"></param> 
        #endregion
        protected override void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                PipeConnection.Dispose();
                if (PipeThread != null)
                {
                    try
                    {
                        PipeThread.Abort();
                    }
                    catch (System.Threading.ThreadAbortException ex) { }
                    catch (System.Threading.ThreadStateException ex) { }
                    catch (Exception ex)
                    {
                        // Log exception
                    }
                }
            }
            disposed = true;
        }
        #region comment
        /// <summary>
        /// Destructor of WServiceNamedPipe.
        /// </summary> 
        #endregion
        ~WServiceNamedPipe()
        {
			Dispose(false);
		}

        public static bool IsInGoodList(string url)
        {
            if(goodList == null || goodList.Length < 1){
                return false;
            }
            //the last good-url is "",so its index is a regURLSplite.Length-2 
            for (int i = 0; i < goodList.Length - 1; i++)
            {
                if (url.Contains(goodList[i]))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
