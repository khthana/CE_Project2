using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;//Registry

namespace WindowsService1
{
    #region comment
    /// <summary>
    /// All privilege domain names on regular format.
    /// </summary> 
    ///<remarks>
    /// Privilege domain names ==>.ac.th, .or.th, .edu, .go.th, .co.th, .gov, .msn.
    ///</remarks>
    #endregion
    
    #region struct PrivilegeDN
    public struct PrivilegeDN
    {
        public ArrayList listPrivilegeDN;
        public void InitialListPrivilege()
        {
            // Creates and initializes a new WordPoolReg ArrayList.(Default)
            // Privilege domain names ==>.ac.th, .or.th, .edu, .go.th, .co.th, .gov, .msn. 
            listPrivilegeDN = new ArrayList();
            listPrivilegeDN.Add(new Regex("(.*)\\.ac\\.th[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.or\\.th[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.edu[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.go\\.th[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.co\\.th[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.gov[/:.](.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listPrivilegeDN.Add(new Regex("(.*)\\.msn\\.(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
        }
        #region comment
        /// <summary>
        /// return true,if your url is a privilege domain name.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns> 
        #endregion
        public bool IsPrivilegeDN(string url)
        {
            for (int i = 0; i < listPrivilegeDN.Count; i++)
            {
                if (((Regex)listPrivilegeDN[i]).IsMatch(url) == true)
                {
                    return true;
                }
            }
            return false;
        }
    }
    #endregion

    #region struct WordPool
    public struct WordPool
    {
        public static ArrayList listWordPool;
        public static void InitialListWordPool()
        {
            // Creates and initializes a new WordPoolReg ArrayList.(Default)
            listWordPool = new ArrayList();
            //listWordPool.Add(new Regex("[^\\w]+18[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+adulter[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)amateurcouple(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+anal[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+anilingus(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+anus[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+ass[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)bdsm(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)blowjob(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+bondage[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+boob(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+boobie(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)borrachas(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)bulldoglist(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+busty[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+cam(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)cfnm(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+cock(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)creampie(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+cum[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+cumshot(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)cybersex(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)cybersexual(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+dildo(s)?[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)femdom(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)fuck(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)handjob(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)hentai(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)interracial(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)maledom(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)malestripper(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)masturbat(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+mature(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)milf(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+nude(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+nudism(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)nudistas(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+nudity(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+oral(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)orgasm(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+pantie(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)penis(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+pantie(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+piss(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)porn(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)pued(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)purecfnm(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+puss(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+putas(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+rimjob(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+rimming(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)rubias(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            //listWordPool.Add(new Regex("(.*)sex(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)shemale(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)tetazas(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)tgp(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("[^\\w]+tits[^\\w]+", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)titworld(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)upskirt(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)xnxx(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)xxx(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)yobt(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
            listWordPool.Add(new Regex("(.*)ztod(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled));
        }
    }
    #endregion

    #region class WebPage
    class WebPage
    {
        private string url;
        private string code;
        //IMG...META...META-POOL...SCRIPT...All-LINK...IMG-LINK...TXT-LINK...LINK-NON...LINK-Rela...PARAM
        private double countImg;
        private double countMeta;
        private double countMalefWord;
        private double countScript;
        private double countAllLink;
        private double countImgLink;
        private double countTxtLink;
        private double countLinkNonRela;
        private double countLinkRela;
        private double countParam;

        private ArrayList arrWord = new ArrayList();

        public WebPage()
        {
            //Set Default Member Values
            this.countMeta = 0;
            this.countImg = 0;
            this.countMalefWord = 0;
            this.countScript = 0;
            this.countAllLink = 0;
            this.countImgLink = 0;
            this.countTxtLink = 0;
            this.countLinkNonRela = 0;
            this.countLinkRela = 0;
            this.countParam = 0;

            this.url = "";
            this.code = "";
            
        }
        public WebPage(string url,string htmlCode)
        {
            //Set Default Member Values
            this.countMeta = 0;
            this.countImg = 0;
            this.countMalefWord = 0;
            this.countScript = 0;
            this.countAllLink = 0;
            this.countImgLink = 0;
            this.countTxtLink = 0;
            this.countLinkNonRela = 0;
            this.countLinkRela = 0;
            this.countParam = 0;

            this.url = url;
            this.code = htmlCode.ToLower();

            DetectTag();
        }
        public int FindMaleficWord(string str)
        {
            int number = 0;
            //Look for Malefic words
            //Match match;

            #region Solution 1
            /*Regex word = new Regex("^18$|^adulter$|(.*)amateurcouple(.*)|^anal$|^anilingus(.*)|^anus$|^ass$|(.*)bdsm(.*)"
                + "|(.*)blowjob(.*)|^bondage$|^boob(s)?$|^boobie(s)?$|(.*)borrachas(.*)|(.*)bulldoglist(.*)|^busty$|^cam(s)?$"
                + "|(.*)cfnm(.*)|^cock(s)?$|(.*)creampie(.*)|^cum$|^cumshot(s)?$|^cunt$|(.*)cybersex(.*)|(.*)cybersexual(.*)"
                + "|^dildo(s)?$|(.*)femdom(.*)|(.*)fuck(.*)|(.*)handjob(.*)|(.*)hentai(.*)|(.*)interracial(.*)|(.*)maledom(.*)"
                + "|(.*)malestripper(.*)|(.*)masturbat(.*)|^mature(.*)|(.*)milf(.*)|^nude(.*)|^nudism(.*)|(.*)nudistas(.*)"
                + "|^nudity(.*)|^oral(.*)|(.*)orgasm(.*)|^pantie(.*)|(.*)penis(.*)|^piss(.*)|(.*)porn(.*)|(.*)pued(.*)"
                + "|(.*)purecfnm(.*)|^puss(.*)|^putas(.*)|^rimjob(.*)|^rimming(.*)|(.*)rubias(.*)|(.*)sex(.*)|(.*)shemale(.*)"
                + "|(.*)tetazas(.*)|(.*)tgp(.*)|^tits$|(.*)titworld(.*)|(.*)upskirt(.*)|(.*)xnxx(.*)|(.*)xxx(.*)|(.*)yobt(.*)"
                + "|(.*)ztod(.*)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (match = word.Match(code); match.Success; match = match.NextMatch())
            {
                number++;
            }*/
            #endregion

            //Solution 2 for using arraylist
            return number;
        }
        public static string DeletePopup(string htmlCode)
        {
            Match m;
            string temp = htmlCode ;
            //#Extension: Detect Popup,And Delete it!!
            Regex r = new Regex("(<body[\\s]+)([^>]*)(onload)([\\s]*)=([^>]+)(>)",RegexOptions.IgnoreCase);
            if (r.IsMatch(htmlCode))
            {
                m = r.Match(htmlCode);
                int index = m.Groups[3].Index;
                //MessageBox.Show("Block Popup", "  Caption     ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                temp = htmlCode.Remove(index, 6);
                
            }
            return temp;
        }
        public void DetectTag()
        {
            int minute1 = DateTime.Now.Minute;
            int second1 = DateTime.Now.Second;
            Match m;
            //Analyze code value that find number of tags'
            //Scan Title Tag
            Regex r = new Regex("(<title[\\s]*)([^>]*)(>)([^<]*)(<)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                //countMalefWord = FindMaleficWord(m.Groups[4].ToString()) + countMalefWord;

                for (int i = 0; i < WordPool.listWordPool.Count; i++)
                {
                    if (((Regex)WordPool.listWordPool[i]).IsMatch(m.Groups[4].ToString()) == true)
                    {
                        countMalefWord++;
                        arrWord.Add("\n"+m.Groups[4].ToString()+":");
                        arrWord.Add(WordPool.listWordPool[i].ToString());
                    }
                }
            }

            //Image Tag
            r = new Regex("(<img[\\s]+)([^>]*)([\\s]*src[\\s]*=[\"]?)([^\">]+)([\"]?)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countImg++;
            }

            //Meta Tag
            r = new Regex("(<meta[\\s]+)([^>]*)(>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countMeta++;
                //Solution1
                //countMalefWord =  FindMaleficWord(m.Groups[2].ToString()) + countMalefWord;

                //Solution2 (cann't regular expression ,therefore not flexible checking)
                /*string[] split = m.Groups[2].ToString().Split(new Char[] { ',', '.',' '});
                foreach(string str in split)
                {
                    if(word.IndexOf(str) != -1){
                    //if(word.BinarySearch(str) >= 0){
                        countMalefWord++;
                    }
                }*/

                //Solution3
                for (int i=0; i<WordPool.listWordPool.Count; i++){
                    if (((Regex)WordPool.listWordPool[i]).IsMatch(m.Groups[2].ToString()) == true){
                        countMalefWord++;
                        arrWord.Add("\n" + m.Groups[2].ToString() + ":");
                        arrWord.Add(WordPool.listWordPool[i].ToString());
                    }
                }
            }

            //Script Tag
            r = new Regex("(<script[\\s]*)([^>]*)(>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countScript++;
            }

            //Param Tag
            r = new Regex("(<param[\\s]*)([^>]*)(>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countParam++;
            }

            //All Link Tag
            r = new Regex("(<a[\\s]+)([^>]*)([\\s]*href[\\s]*=[\\s]*[\"]?)([^\">]+)([\"]?)([^>]*>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countAllLink++;
            }

            //Image Link Tag
            r = new Regex("(<a[\\s]+)([^>]*)([\\s]*href[\\s]*=[\\s]*[\"]?)([^\">]+)([\"]?)([^>]*>)[\\s]*(<img[\\s]+[^>]*>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                countImgLink++;
            }

            //Text Link Tag
            countTxtLink = countAllLink - countImgLink;

            //Non-Rela Link Tag and Rela Link Tag
            r = new Regex("(<a[\\s]+)([^>]*)([\\s]*href[\\s]*=[\\s]*[\"]?)([^\">]+)([\"]?)([^>]*>)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
            for (m = r.Match(code); m.Success; m = m.NextMatch())
            {
                Regex r2 = new Regex("^[\\s]*(http:\\/\\/)([^>]*)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
                if (r2.IsMatch(m.Groups[4].ToString()) == true)
                {
                    countLinkNonRela++;
                }
                else
                {
                    countLinkRela++;
                }
            }
            //Show time span.
            int minute2 = DateTime.Now.Minute;
            int second2 = DateTime.Now.Second;
            int difsec = (minute2*60+second2) - (minute1*60+second1);
            //1MessageBox.Show("spend " + difsec + " seconds.");
            //Show Detail that number of tags
            /*1MessageBox.Show("Number of Tag\n"+
                            "\nURI : "+url+
                            "\nImage Tag : "+countImg+
                            "\nMeta Tag  : "+countMeta+
                            "\nMalefic Word:"+countMalefWord+
                            "\nScript Tag: "+countScript+
                            "\nParam Tag : "+countParam+
                            "\nAll Link Tag:"+countAllLink+
                            "\n-Image Link :"+countImgLink+
                            "\n-Text Link  :"+countTxtLink+
                            "\n--Non-Rela Link :"+countLinkNonRela+
                            "\n--Rela Link :"+countLinkRela);
            string test="";
            for (int i = 0; i < arrWord.Count;i++ )
            {
                test = test + ","+arrWord[i].ToString();
            }
            MessageBox.Show("MalWord: "+test);*/

        }
        public bool IsMaleficWeb()
        {
            //Normalize Data
            countImg = countImg * 100.0 / 878.0 - 5.58635925749;
            countMeta = countMeta * 100.0 / 48.0 - 8.88960666092;
            countMalefWord = countMalefWord * 100.0 / 47.0 - 3.52777319625;
            countScript = countScript * 100.0 / 232.0 - 1.78576732306;
            countAllLink = countAllLink * 100.0 / 2278.0 - 4.67169396973;
            countImgLink = countImgLink * 100.0 / 454.0 - 4.09699218735;
            countTxtLink = countTxtLink * 100.0 / 2201.0 - 3.99004289414;
            countLinkNonRela = countLinkNonRela * 100.0 / 1946.0 - 3.2875139534;
            countLinkRela = countLinkRela * 100.0 / 2032.0 - 2.08888617605;
            countParam = countParam * 100.0 / 195.0 - 1.27299631176;
            //Initial FeatureVector[* * * * * * * * * * * *]
            //[2,12]               [* * * * * * * * * * * *]
            double[,] FeatureV = new double[2, 12] { { -0.35957221, -0.11547346, 0.22476676, -0.03699852, -0.49346665, -0.2672396, -0.45560666, -0.38026062, -0.18904029, -0.04007976, 0.22476676, 0.22476676 }, { -0.02643652, -0.07546966, -0.5233763, -0.00477049, -0.2355682, -0.05733572, -0.23198271, -0.2405511, -0.03371648, 0.0147328, -0.5233763, -0.5233763 } };
            //Initial DataAdjust[12,1]
            double[,] DataAdjust = new double[12, 1] { { countImg }, { countMeta }, { countMalefWord }, { countScript }, { countAllLink }, { countImgLink }, { countTxtLink }, { countLinkNonRela }, { countLinkRela }, { countParam }, { countMalefWord }, { countMalefWord } };
            double[,] FinalData = new double[2, 1];
            //Feature x DataAdjust = FinalData
            double sum;
            for (int i = 0; i < 2; i++)
            {
                sum = 0.0;
                for (int j = 0; j < 12; j++)
                {
                    sum = sum + (FeatureV[i, j] * DataAdjust[j, 0]);
                }
                FinalData[i, 0] = sum;
            }

            //MessageBox.Show("x: "+FinalData[1,0].ToString()+"\ny: "+FinalData[0,0].ToString());

            //Conjecture this web by Equation: y = 2.6741x - 9.9498 (From Graph)
            //Remark: Crossing Axis Y is -9.9498,therefore if this value is less then -9.9498,then Non-Malefic Web ,otherwise Malefic Web
            double crossingY;
            double x = FinalData[1, 0];
            double y = FinalData[0, 0];
            crossingY = y - (2.6741 * x);

            if (crossingY > -9.9498)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #region Get Method
        public double GetCountMeta()
        {
            return countMeta;
        }
        public double GetCountImg()
        {
            return countImg;
        }
        public double GetCountMalefWord()
        {
            return countMalefWord;
        }
        public double GetCountScript()
        {
            return countScript;
        }
        public double GetCountAllLink()
        {
            return countAllLink;
        }
        public double GetCountImgLink()
        {
            return countImgLink;
        }
        public double GetCountTxtLink()
        {
            return countTxtLink;
        }
        public double GetCountLinkNonRela()
        {
            return countLinkNonRela;
        }
        public double GetCountLinkRela()
        {
            return countLinkRela;
        }
        public double GetCountParam()
        {
            return countParam;
        }
        public string GetUrl()
        {
            return url;
        }
        public string GetCode()
        {
            return code;
        } 
        #endregion
        #region Set Method
        public void SetCountMeta(double countMeta)
        {
            this.countMeta = countMeta;
        }
        public void SetCountImg(double countImg)
        {
            this.countImg = countImg;
        }
        public void SetCountMalefWord(double countMalefWord)
        {
            this.countMalefWord = countMalefWord;
        }
        public void SetCountScript(double countScript)
        {
            this.countScript = countScript;
        }
        public void SetCountAllLink(double countAllLink)
        {
            this.countAllLink = countAllLink;
        }
        public void SetCountImgLink(double countImgLink)
        {
            this.countImgLink = countImgLink;
        }
        public void SetCountTxtLink(double countTxtLink)
        {
            this.countTxtLink = countTxtLink;
        }
        public void SetCountLinkNonRela(double countLinkNonRela)
        {
            this.countLinkNonRela = countLinkNonRela;
        }
        public void SetCountLinkRela(double countLinkRela)
        {
            this.countLinkRela = countLinkRela;
        }
        public void SetCountParam(double countParam)
        {
            this.countParam = countParam;
        }
        public void SetUrl(string url)
        {
            this.url = url;
        }
        public void SetCode(string code)
        {
            this.code = code;
        }
        #endregion


    }
    #endregion
}
