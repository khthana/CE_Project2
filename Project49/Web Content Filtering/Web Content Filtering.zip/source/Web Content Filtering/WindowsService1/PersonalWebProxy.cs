using System;
using System.IO;
using System.Net;
using System.Net.Cache;
using System.Net.Sockets;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

using AppModule.InterProcessComm;
using AppModule.NamedPipes;

using Microsoft.Win32;//Registry
namespace WindowsService1
{
    public class PersonalWebProxy
    {
        public PersonalWebProxy()
        {
            //Initial WordPool
            WordPool.InitialListWordPool();
            //Initial Webpage
            web_page = new WebPage();
            //Initial Privilege Domain Names
            privilegeDN.InitialListPrivilege();
        }

        #region AsyncProxyServer
        //Privilege Domain Names (On regular format)
        private PrivilegeDN privilegeDN;
        //Instance of Webpage to use check in goodlist.
        private WebPage web_page;
        // Thread signal.
        public static ManualResetEvent SocketEvent = new ManualResetEvent(false);
        public static int countPic = 0;//Ex Fix 5 pics for request web"http://www.pramool.com/html-howto/useword.html"
        private Socket sListener;
        public static int count = 0;
        public static int countAll = 0;
        private int m_clientCount = 0;
        public AsyncCallback pfnWorkerCallBack;

        // An ArrayList is used to keep track of worker sockets that are designed
        // to communicate with each connected client. Make it a synchronized ArrayList
        // For thread safety
        private System.Collections.ArrayList m_workerSocketList =
                ArrayList.Synchronized(new System.Collections.ArrayList());

        public class SocketPacket
        {
            // Constructor which takes a Socket and a client number
            public SocketPacket(Socket socket, int clientNumber)
            {
                m_currentSocket = socket;
                m_clientNumber = clientNumber;
            }
            public Socket m_currentSocket;
            public int m_clientNumber;
            // Buffer to store the data sent by the client
            public byte[] dataBuffer = new byte[1024];
        }

        #region void Start_Server()
        public void Start_Server()
        {
            try
            {
                string portStr = "8445";
                int port = System.Convert.ToInt32(portStr);
                // Create the listening socket...
                sListener = new Socket(AddressFamily.InterNetwork,
                    SocketType.Stream,
                    ProtocolType.Tcp);
                IPEndPoint ipLocal = new IPEndPoint(IPAddress.Any, port);
                // Bind to local IP Address...
                sListener.Bind(ipLocal);
                // Start listening - The argument is the size of the queue of waiting connections
                // that we should allow before we start refusing connections
                sListener.Listen(30);
                // Create the call back for any client connections...
                sListener.BeginAccept(new AsyncCallback(OnClientConnect), sListener);
                // Update Control When connection
                //UpdateControlsWhenConnect();
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message);
            }
        }
        #endregion
        // This is the call back function, which will be invoked when a client is connected
        #region void OnClientConnect(IAsyncResult asyn)
        public void OnClientConnect(IAsyncResult asyn)
        {
            try
            {
                // After a connection is accepted, we actually use a different Socket object
                // (this one is called "socketWorker") to do the input and output to the
                // client(Web Browser)
                Socket workerSocket = sListener.EndAccept(asyn);
                // Since the main Socket is now free, it can go back and wait for
                // other clients who are attempting to connect
                sListener.BeginAccept(new AsyncCallback(OnClientConnect), sListener);

                if (workerSocket.Connected)
                {
                    // Now increment the client count for this client 
                    // in a thread safe manner
                    Interlocked.Increment(ref m_clientCount);

                    // Add the workerSocket reference to our ArrayList
                    m_workerSocketList.Add(workerSocket);
                }
                else { MessageBox.Show("ERROR accept connection"); }
                // Method to BeginReceive
                WaitForData(workerSocket, m_clientCount);        
            }
            catch (ObjectDisposedException)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\n OnClientConnection: Socket has been closed\n");
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message);
            }

        }
        #endregion
        // Start waiting for data from the client(Web Browser)//
        #region WaitForData(Socket soc, int clientNumber)
        public void WaitForData(Socket soc, int clientNumber)
        {
            try
            {
                    if (pfnWorkerCallBack == null)
                    {
                        // Specify the call back function which is to be 
                        // invoked when there is any write activity by the 
                        // connected client(Web Browser)
                        pfnWorkerCallBack = new AsyncCallback(ReceiveCallBack);
                    }
                    SocketPacket theSocPkt = new SocketPacket(soc, clientNumber);
                    //char[] for Accept-Encoding: gzip, deflate is be instanded of XXXXXXXXXXXXXXX: XXXXXXXXXXXXX by Firewall such as ZoneAlarm
                    soc.BeginReceive(theSocPkt.dataBuffer, 0,
                        1024,//theSocPkt.dataBuffer.Length,
                        0,//SocketFlags.None,
                        pfnWorkerCallBack,
                        theSocPkt);
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message);
            }
        }
        #endregion
        // This the call back function which will be invoked when the socket
        // detects any client writing of data on the stream
        #region void ReceiveCallBack(IAsyncResult asyn)
        public void ReceiveCallBack(IAsyncResult asyn)
        {
            //socketData is a handler in text-book.
            SocketPacket socketData = (SocketPacket)asyn.AsyncState;
            if (!socketData.m_currentSocket.Connected)
            {
                //MessageBox.Show("Client: "+socketData.m_clientNumber+" Now Disconnect");
                CloseSockets(socketData.m_currentSocket);
                return;
            }
            try
            {
                /// Complete the BeginReceive() asynchronous call by EndReceive() method
                /// which will return the number of characters written to the stream
                /// by the client
                /// (WEBBROWSER ==DATA==> PROXY)
                int bytesRead = socketData.m_currentSocket.EndReceive(asyn);
                // More Data?
                if (bytesRead > 0)
                {
                    //chars = content char
                    char[] chars = new char[bytesRead];
                    // Extract the characters as a buffer
                    Decoder d = Encoding.UTF8.GetDecoder();
                    int charLen = d.GetChars(socketData.dataBuffer,
                        0, bytesRead, chars, 0);
                    String szData = new String(chars);
                    //Create Requested-HTTP Header (and body, if POST method)
                    HttpWebRequest req = RequestHTTPHeader(szData);

                    // Check having (HttpWebRequest)WebRequest instance?
                    if (req != null)
                    {
                        //Get Response from requestHTTP (WEBSERVER ==DATA==> PROXY)
                        HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                        // Read in the data, performing ASCII->Unicode encoding
                        Stream s = resp.GetResponseStream();//Will error if it not bypass proxy.
                        StreamReader sr;
                        //System.Text.Encoding.Default -> An encoding for the system's current ANSI code page. 
                        int read = 0;
                        string read_temp = "", doc = "";
                        byte[] byteArray = new byte[2];
                        //if CharacterSet is "" ==> Medie(Pic+FLASH+..),Otherwise is HtmlCode.
                        if (resp.CharacterSet != "")
                        #region Html Code.
                        {//HtmlCode
                            sr = new StreamReader(s, Encoding.GetEncoding(resp.CharacterSet));
                            //doc is a content string from Web Server
                            doc = sr.ReadToEnd();
                        } 
                        #endregion
                        else
                        #region Media(Pic+FLASH+..)
                        {//Media(Pic+FLASH+..)
                            ///
                            ///FILTERING
                            ///Picture Portion(Stream).
                            ///
                            //Check type img
                            int uri_length = req.RequestUri.ToString().Length;
                            uri_length = uri_length - 3;
                            string uri_type = "";
                            uri_type = req.RequestUri.ToString().Substring(uri_length);

                            sr = new StreamReader(s, Encoding.Default);
                            MemoryStream teststream = new MemoryStream();
                            WebPage chkGoodList = new WebPage();
                            if (WServiceNamedPipe.gobal_level == "HIGH" && (uri_type == "jpg" || uri_type == "gif" || uri_type == "bmp" || uri_type == "png") && !privilegeDN.IsPrivilegeDN(req.RequestUri.ToString()) && !WServiceNamedPipe.IsInGoodList(req.RequestUri.ToString()))
                            {//LOOP==>Pic
                                while (true)
                                {
                                    //System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                                    System.Text.Encoding encoding = System.Text.Encoding.Default;
                                    read = s.ReadByte();//read current byte and advance to next byte
                                    if (read == -1)
                                    {
                                        break;
                                    }
                                    byteArray[0] = (byte)read;
                                    //use for sent to Web Browser
                                    read_temp += encoding.GetString(byteArray, 0, 1);

                                    //Use for test Image
                                    teststream.WriteByte(byteArray[0]);
                                }
                                Bitmap imagetest = new Bitmap(teststream);
                                Class_image identifys = new Class_image();
                                String resultrreceive = "This is NO Pornographic";
                                if (identifys.is_sizeicon(imagetest) == true)
                                {//ICON
                                    resultrreceive = "This is icon";
                                }
                                else
                                {//PIC
                                    identifys.importimage(imagetest);
                                    identifys.checkpornographic();
                                    resultrreceive = identifys.getResult();
                                    if (resultrreceive == "This is Pornographic")
                                    {
                                        string picblock_string = "";
                                        #region replace pic block
                                        //int readpic = 0;
                                        //byte[] picblock_byteArray = new byte[1];
                                        //FileStream picblock_file = new FileStream("testblock.jpg", FileMode.Open, FileAccess.Read);
                                        //System.Text.Encoding picblock_encoding = System.Text.Encoding.Default;
                                        //while (true)
                                        //{
                                        //    readpic = picblock_file.ReadByte();
                                        //    if (readpic == -1)
                                        //        break;
                                        //    picblock_byteArray[0] = (byte)readpic;
                                        //    picblock_string += picblock_encoding.GetString(picblock_byteArray, 0, 1);

                                        //}
                                        //picblock_file.Close();
                                        #endregion
                                        read_temp = picblock_string;
                                    }
                                }
                                //Return Used Resource.
                                imagetest.Dispose();
                                doc = read_temp;
                                //pictureBox1.Dispose();
                            }
                            else
                            {//LOOP ==> swf,js
                                doc = sr.ReadToEnd();
                            }
                        }  
                        #endregion                       
                        //has data(be String)?,if has data that will be send to webbrowser
                        if (doc != null)
                        {
                            byte[] msg;
                            if (resp.CharacterSet != "")
                            #region Html Code.
                            {//HtmlCode
                                ///***Delete Popup***
                                doc = WebPage.DeletePopup(doc);
                                msg = Encoding.GetEncoding(resp.CharacterSet).GetBytes(doc);
                                ///*****Not Filter ==>.css*****
                                ///Privilege domain names ==>.ac.th, .or.th, .edu, .go.th, .co.th, .gov, .msn. 
                                if (!req.RequestUri.ToString().EndsWith(".css") && !privilegeDN.IsPrivilegeDN(req.RequestUri.ToString()) && !WServiceNamedPipe.IsInGoodList(req.RequestUri.ToString()))
                                {
                                    ///
                                    ///FILTERING
                                    ///HTML Code Portion(String).
                                    ///
                                    //*********ANALYZE HTML TAGS*******************************
                                    WebPage web = new WebPage(req.RequestUri.ToString(), doc);
                                    bool block = web.IsMaleficWeb();
                                    if (block == true)
                                    {
                                        //string exePath = Application.ExecutablePath;
                                        //string floderPath = exePath.Substring(0, exePath.Length - "WindowsService1.exe".Length);
                                        //string imagePath = floderPath + "images\\Blocked-Page.jpg";
                                        doc = "<title>Blocked by Web Content Filtering</title></head><body><font style=\"font-family:'MS Sans Serif', sans-serif, serif\"><font color=\"#000000\" style=\"font-weight:bold\" >This web site has been </font><font color=\"#FF0000\" style=\"font-weight:bold\" > BLOCKED </font> <font color=\"#3366FF\" style=\"font-weight:bold\" >by Web Content Filtering </font></font></body>";

                                        msg = Encoding.GetEncoding(resp.CharacterSet).GetBytes(doc);
                                    }
                                    //*********SEND URI TO WINDOWSCONTROL**********************
                                    ClientPipeConnection clientConnection = null;
                                    try
                                    {
                                        clientConnection = new ClientPipeConnection("WindowsControl", ".");
                                        //if (clientConnection.TryConnect())
                                        //{
                                        clientConnection.Connect();
                                        if (block == false)
                                        {
                                            clientConnection.Write(req.RequestUri.ToString() + "," + " ");
                                        }
                                        else
                                        {
                                            clientConnection.Write(" " + "," + req.RequestUri.ToString());
                                        }
                                        clientConnection.Close();
                                        //}
                                    }
                                    catch (Exception ex)
                                    {
                                        clientConnection.Dispose();
                                        throw (ex);
                                    }
                                    //***********************************************************
                                }
                            }
                            #endregion
                            else
                            #region Media(Pic+FLASH+..)
                            {//Media(Pic+FLASH+..)
                                msg = Encoding.Default.GetBytes(doc);
                            }
                            #endregion
                            ///PROXY ==DATA==> WEB BROWSER.
                            ///Sent content to IE Browser.//Asynchronous Sending
                            socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                            //Close HttpWebResponse
                            resp.Close();
                            //Close StreamReader
                            sr.Close();
                        }
                        else
                        {
                            //MessageBox.Show("Cannot get content from Web Server");
                            byte[] msg = Encoding.Default.GetBytes("<html><body>Cannot get content from Web Server</body></html>");
                            socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                            CloseSockets(socketData.m_currentSocket);
                        }
                    }
                }
                else { WaitForData(socketData.m_currentSocket, socketData.m_clientNumber); }
            }
            /*catch(IOException io){
                byte[] msg = Encoding.Default.GetBytes("<html><body>ERROR IOException</body></html>");
                socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                //CloseSockets2(socketData.m_currentSocket);
            }*/
            catch (SocketException se)
            {
                if (se.ErrorCode == 10054) // Error code for Connection reset by peer
                {
                    string msg = "Client " + socketData.m_clientNumber + " Disconnected" + "\n";
                    // Remove the reference to the worker socket of the closed client
                    // so that this object will get garbage collected
                    m_workerSocketList[socketData.m_clientNumber - 1] = null;
                }
            }
            catch (WebException w)
            {
                //"File Not Found"
                byte[] msg = Encoding.Default.GetBytes("<html><body>File Not Found</body></html>");
                try
                {
                    socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                }
                catch (Exception e) { }
                //CloseSockets2(socketData.m_currentSocket);
            }
            catch (ArgumentException e)
            {
                //"Not a Supported Encoding";
                //byte[] msg = Encoding.Default.GetBytes("<html><body>Not a Supported Encoding</body></html>");
                //socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                CloseSockets(socketData.m_currentSocket);
            }
            catch (OutOfMemoryException e)
            {
                byte[] msg = Encoding.Default.GetBytes("<html><body>OutOfMemoryException</body></html>");
                try
                {
                    socketData.m_currentSocket.BeginSend(msg, 0, msg.Length, 0, new AsyncCallback(SendCallBack), socketData.m_currentSocket);
                }
                catch (Exception e2) { }
                //CloseSockets(socketData.m_currentSocket);
            }
            catch (Exception w)
            {
                CloseSockets(socketData.m_currentSocket);
            }
        }
        #endregion

        #region void SendCallBack(IAsyncResult ar)
        public void SendCallBack(IAsyncResult ar)
        {
            Socket handler = (Socket)ar.AsyncState;
            if (handler.Connected)
            {
                //Send data  back to the client
                int byteSent = handler.EndSend(ar);
            }
            //close down socket
            handler.Shutdown(SocketShutdown.Both);
            handler.Close();
            //allowing one or more waiting threads to proceed
            //SocketEvent.Set();
        }
        #endregion

        #region void CloseSocketsListening()
        void CloseSocketsListening()
        {
            if (sListener != null)
            {
                sListener.Close();
            }
        }
        #endregion

        #region void CloseSockets(Socket workerSocket)
        void CloseSockets(Socket workerSocket)
        {
            if (workerSocket != null)
            {
                workerSocket.Shutdown(SocketShutdown.Both);
                workerSocket.Close();
                workerSocket = null;
            }
            SocketEvent.Set();
        }
        #endregion

        #region HttpWebRequest RequestHTTPHeader(string szData)
        private HttpWebRequest RequestHTTPHeader(string szData)
        {
            //split each header line to header arrayString.
            string[] header = szData.Split(new Char[] { '\n' });
            string[] headerLine1 = header[0].Split(' ');
            //Method,such as GET POST 
            string method = headerLine1[0];
            string uri = headerLine1[1];
            //Check that, is
            //Create HttpWebRequest instance.
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(uri); req.KeepAlive = true;
            //get method of HTTPHeader
            req.Method = method;

            //check IsHTTP:// ?    
            if (!req.RequestUri.ToString().Contains("http://"))
            {
                return null;
            }
            //no cache policy
            req.CachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
            // This application doesn't want the proxy to be used so it sets 
            // the global proxy to an empty proxy.: By pass Proxy !!!
            HttpWebRequest.DefaultWebProxy = null;
            IWebProxy myProxy = HttpWebRequest.DefaultWebProxy;
            GlobalProxySelection.Select = myProxy;

            //HTTPHeader Format: ==>headerType: content\n
            string[] stringSeparators = new string[] { ": " };
            for (int i = 1; i < header.Length; i++)
            {
                string eachHeader = header[i];
                if (eachHeader.Contains(": "))
                {
                    string[] headerAndContent = eachHeader.Split(stringSeparators, StringSplitOptions.None);
                    if (headerAndContent.Length == 2)
                    {
                        //remove string"\r"
                        string content = headerAndContent[1].Remove(headerAndContent[1].Length - 1, 1);
                        if (headerAndContent[0] == "Accept")
                        {
                            req.Accept = content;
                        }
                        else if (headerAndContent[0] == "Accept-Encoding")
                        {
                            //
                        }
                        else if (headerAndContent[0] == "Connection")
                        {
                            req.Connection = content;
                        }
                        else if (headerAndContent[0] == "Content-Length")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                        }
                        else if (headerAndContent[0] == "Content-Type")
                        {
                            req.ContentType = content;
                        }
                        else if (headerAndContent[0] == "Date")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                        }
                        else if (headerAndContent[0] == "Expect")
                        {
                            req.Expect = content;
                        }
                        else if (headerAndContent[0] == "Host")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                        }
                        else if (headerAndContent[0] == "If-Modified-Since")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                        }
                        else if (headerAndContent[0] == "Range")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                        }
                        else if (headerAndContent[0] == "Referer")
                        {
                            req.Referer = content;
                        }
                        else if (headerAndContent[0] == "Transfer-Encoding")
                        {
                            req.TransferEncoding = content;
                        }
                        else if (headerAndContent[0] == "User-Agent")
                        {
                            req.UserAgent = content;
                        }
                        else if (headerAndContent[0] == "Proxy-Connection")
                        {
                            //cannot delete,otherwise will be add in req.Headers ==>affect to error
                            //req.Headers.Add(headerAndContent[0], content);
                        }
                        else
                        {//Add Special HTTPHeader
                            req.Headers.Set(headerAndContent[0], content);
                        }
                    }
                }
                //data in body portion.
                else if (eachHeader == "\r" && req.Method == "POST")
                {
                    //string body = header[i+1].Remove(header[i+1].Length - 1, 1);
                    string body = header[i + 1];
                    //ASCIIEncoding encoding = new ASCIIEncoding();
                    byte[] byte1 = Encoding.ASCII.GetBytes(body);
                    req.ContentType = "application/x-www-form-urlencoded";
                    req.ContentLength = byte1.Length;

                    Stream newStream = req.GetRequestStream();
                    newStream.Write(byte1, 0, byte1.Length);

                    newStream.Close();

                    break;
                }
            }
            //MessageBox.Show(req.Headers.ToString());
            return req;

        }
        #endregion 

        #region bool isGoodListRegistry(string url)
        public bool isGoodListRegistry(string url)
        {
            string registry_program = "Software\\WebContentFiltering";
            string regURLList = "";
            string[] regURLSplite;
            //Set Proxy Registry IE For useable 
            MessageBox.Show("11");
            regURLList = Registry.CurrentUser.OpenSubKey(registry_program, true).GetValue("Goodlist").ToString(); ;//,RegistryKeyPermissionCheck.Default,System.Security.AccessControl.RegistryRights.FullControl );
            MessageBox.Show("222");
            //URLReg.SetAccessControl(System.Security.AccessControl.RegistrySecurity);
            //URLReg.GetValue("Goodlist");
            MessageBox.Show("333");
            regURLSplite = regURLList.Split(new string[] { "|" }, StringSplitOptions.None);
            for (int i = 0; i < regURLSplite.Length; i++)
            {
                MessageBox.Show("44");
                if (regURLSplite[i] == url)
                    return true;
            }
            return false;
        }
        #endregion
        #endregion

    }
}
