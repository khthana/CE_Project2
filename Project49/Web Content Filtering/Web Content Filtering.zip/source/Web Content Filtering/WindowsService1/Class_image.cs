using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;

namespace WindowsService1
{
    class Class_image
    {
        private Bitmap org_bmp, m, picskin, filterimage;
        private int[] maskX;
        private int[] maskY;
        private double[,] Y, Cb, Cr;
        private double Y1, Cb1, Cr1, Q1, Q2, Q3, Q4;
        private int[,] r, b, g, v;
        private int firstloop, secloop, iv, countin, limit_recursive;
        private string resultall_out;
        private ArrayList count;
        private bool isrecursivelimit = false;

        #region Class_image()
        public Class_image()
        {
            count = new ArrayList();
            iv = 1;
            countin = 0;
            //self.count = [] # keep size of region
            //self.countin = 0 # parameter count pixel in region
            //self.iv = 1 # parameter number of region
            //self.im = self.connectPIC(url) # source Image
            //self.m = self.SobelMask() # sobel Image
            //self.v = [[0 for i in range(self.im.size[1])] for i in range(self.im.size[0])] # list  pixel that have skin color
        }
        #endregion

        #region void importimage(Bitmap input_image)
        public void importimage(Bitmap input_image)
        {
            count = new ArrayList();
            iv = 1;
            countin = 0;
            org_bmp = input_image;
        }
        #endregion

        #region void checkpornographic()
        public void checkpornographic()
        {
            resize(org_bmp.Height, org_bmp.Width);
            picskin = new Bitmap(org_bmp);
            v = new int[org_bmp.Width, org_bmp.Height];
            for (int i = 0; i < org_bmp.Width; i++)
            {
                for (int j = 0; j < org_bmp.Height; j++)
                {
                    v[i,j]=0;
                }
            }
            //show resize info
            //rehbox.Text = org_bmp.Height.ToString();
            //rewbox.Text = org_bmp.Width.ToString();
            firstloop = 0;
            secloop = 0;
            //chk value for first loop
            if (org_bmp.Height > org_bmp.Width)
            {
                firstloop = org_bmp.Height;
                secloop = org_bmp.Width;
            }
            firstloop = org_bmp.Width;
            secloop = org_bmp.Height;

            //call Fn forRGB-YCbCr
            getRGB(org_bmp);
            rgb2YCbCr(r, b, g);

            //display rgb-ycbcr
            //ytext.Text = Y[firstloop - 1, secloop - 1].ToString();
            //cbtext.Text = Cb[firstloop - 1, secloop - 1].ToString();
            //crtext.Text = Cr[firstloop - 1, secloop - 1].ToString();
            
            //show get pixel
            //redtext.Text = r[firstloop-1, secloop-1].ToString();
            //greentext.Text = g[firstloop - 1, secloop - 1].ToString();
            //bluetext.Text = b[firstloop - 1, secloop - 1].ToString();
            SobelMask();
            //sobelBox.Image = m;
            findSkin();
            //findskinbox.Image = picskin;
            //sobelBox.Refresh();
            //findskinbox.Refresh();

            //check result of image
            string resultall = "";
            Classified classify = new Classified();
            resultall = classify.KNN(classify.Fn_Eigenvec(calWeight()), isrecursivelimit);
            resultall_out = resultall;
            //resultbox.Text = resultall;
            //filterbox.Image = filterimage;
            //filterbox.Refresh();
        }
        #endregion

        #region string getResult()
        public string getResult()
        {
            return resultall_out;
        }
        #endregion

        #region bool is_sizeicon(Bitmap bmp_size)
        public bool is_sizeicon(Bitmap bmp_size)
        {
            if (bmp_size.Height <= 50 || bmp_size.Width <= 50)
            {
                return true;
                //resultbox.Text = "This is NO Pornographic";
            }
            return false;
        }
        #endregion

        #region resize(double heigth, double width)
        public void resize(double heigth, double width)
        {
            double factor = 1;
            if (heigth > width)
            {
                if (heigth > 100)
                {
                    factor = heigth / 100;
                }
            }
            else
            {
                if (width > 100)
                {
                    factor = width / 100;
                }
            }
            if (factor != 1)
            {
                //Image currentImage = Image.FromFile(org_bmp);
				//int h = currentImage.Height;
				//int w = currentImage.Width;

                int newH = (int)Math.Ceiling((double)heigth / factor);
                int newW = (int)Math.Ceiling((double)width / factor);

                // get the Image name from the path 
                ////string imageName = org_bmp.ToString().Substring(path.Length + 1, images[i].Length - path.Length - 5);

                // create the new bitmap with the specified size
                org_bmp = new Bitmap(org_bmp, new Size(newW, newH));
            }
        }
        #endregion
        //Function to call gen function in Sobel
        #region void SobelMask()
        public void SobelMask()
        {
            //Create mask for sobel
            maskX = new int[] {1,2,1,0,0,0,-1,-2,-1};
            maskY = new int[] {1,0,-1,2,0,-2,1,0,-1};

                    
           // """Call function gen fromSobel"""
            m = genSobel(org_bmp, maskX, maskY);

            //"""Retrun Image that had been sobeled"""
            //return m
        }
        #endregion

        #region Bitmap genSobel(Bitmap m, int[] maskXin, int[] maskYin)
        public Bitmap genSobel(Bitmap m, int[] maskXin, int[] maskYin)
        {
            Bitmap sobel_out = new Bitmap(m);
            Color temp;
            int RED, GREEN, BLUE;
            for (int x = 1; x < m.Width-1;x++)
            {
                for (int y = 1; y < m.Height-1; y++)
                {
                    ArrayList rs = new ArrayList();
                    ArrayList gs = new ArrayList();
                    ArrayList bs = new ArrayList();
                    for(int i = -1 ; i < 2 ; i++)
                    {
                        for (int j = -1; j < 2; j++)
                        {
                            temp =  m.GetPixel(x+i,y+j);
                            rs.Add(temp.R);
                            gs.Add(temp.G);
                            bs.Add(temp.B);
                        }

                    }
                    //int teeeee =Convert.ToInt32( rs[0]);
                    //int[] rs1 = (int[])rs.ToArray(typeof(int));
                    //int[] gs1 = (int[])gs.ToArray(typeof(int));
                    //int[] bs1 = (int[])bs.ToArray(typeof(int));
                    RED = Convolution(maskXin, maskYin, rs);
                    GREEN = Convolution(maskXin, maskYin, gs);
                    BLUE = Convolution(maskXin, maskYin, bs);
                    sobel_out.SetPixel(x,y,Color.FromArgb(RED,GREEN,BLUE));
                }
            }
            return sobel_out;
        }
        #endregion

        #region int Convolution(int[] CoefficientX, int[] CoefficientY, ArrayList Raw_Data)
        public int Convolution(int[] CoefficientX, int[] CoefficientY, ArrayList Raw_Data)
        {
            ArrayList mX = new ArrayList();
            ArrayList mY = new ArrayList();
            int sumreturn = 0;
            int summx=0, summy=0;
            
            for (int i = 0; i < CoefficientX.Length;i++ )
            {
                mX.Add(CoefficientX[i] * Convert.ToInt32(Raw_Data[i]));
                mY.Add(CoefficientY[i] * Convert.ToInt32(Raw_Data[i]));
            }
            for (int i = 0; i < CoefficientX.Length;i++ )
            {
                summx += Convert.ToInt32(mX[i]);
                //summx += double.Parse(mX[i].ToString());
                //summy += double.Parse(mY[i].ToString());
            }
            for (int i = 0; i < CoefficientY.Length; i++)
            {
                summy += Convert.ToInt32(mY[i]);
            }
            if ((Math.Abs(summx) + Math.Abs(summy)) > 255)
            {
                sumreturn = 255;
            }
            else
            {
                sumreturn = (Math.Abs(summx) + Math.Abs(summy));
            }
            return sumreturn;

        }
        #endregion

        #region void getRGB(Bitmap org_bmp)
        public void getRGB(Bitmap org_bmp)
        {
            r = new int[firstloop, secloop];
            b = new int[firstloop, secloop];
            g = new int[firstloop, secloop];
            //get pixel
            for (int i = 0; i < firstloop; i++)
            {
                for (int j = 0; j < secloop; j++)
                {
                    r[i, j] = org_bmp.GetPixel(i, j).R;
                    b[i, j] = org_bmp.GetPixel(i, j).B;
                    g[i, j] = org_bmp.GetPixel(i, j).G;

                }
            }
        }
        #endregion

        #region void rgb2YCbCr(int[,] R, int[,] G, int[,] B)
        public void rgb2YCbCr(int[,] R, int[,] G, int[,] B)
        {
            ///Function to convert R,G,B color space to Y,Cb,Cr color space
            Y = new double[firstloop, secloop];
            Cb = new double[firstloop, secloop];
            Cr = new double[firstloop, secloop];
            for (int i = 0; i < firstloop; i++)
            {
                for (int j = 0; j < secloop; j++)
                {
                    Y[i, j] = (0.299 * R[i,j]) + (0.587 * G[i,j]) + (0.114 * B[i,j]);
                    Cb[i, j] = (-0.1687 * R[i, j]) + (-0.3313 * G[i, j]) + (0.5 * B[i, j]);
                    Cr[i, j] = (0.5 * R[i, j]) + (-0.4187 * G[i, j]) + (-0.0813 * B[i, j]);

                }
            }
        }
        #endregion

        #region void rgb2YCbCrONE(int R, int G, int B)
        public void rgb2YCbCrONE(int R, int G, int B)
        {
            ///Function to convert R,G,B color space to Y,Cb,Cr color space
            
            Y1 = (0.299 * R) + (0.587 * G) + (0.114 * B);
            Cb1 = (-0.1687 * R) + (-0.3313 * G) + (0.5 * B);
            Cr1 = (0.5 * R) + (-0.4187 * G) + (-0.0813 * B);

        }
        #endregion

        #region void findSkin()
        public void findSkin()
        {
            //Find Skin pixel in image

            //Loop for check every pixel in source Image
            for (int i = 0; i < org_bmp.Width;i++ )
            {
                for (int j = 0; j < org_bmp.Height;j++ )
                {
                    limit_recursive = 10929;
                    //Call Function to check pixel
                    SetSkin(i,j);
                    //complete check in Region set count with number of skin pixek in region and set countin to zero
                    if(countin!=0)
                    {
                        count.Add(countin);
                        countin = 0;
                        iv++; 
                    }
                }
            }
        }
        #endregion

        #region void SetSkin(int i, int j)
        public void SetSkin(int i, int j)
        {
            if (limit_recursive <= 0)
            {
                isrecursivelimit = true;
                return;
            }
            int Rss, Gss, Bss, rss, gss, bss;
            double Yss,Cbss,Crss;
            bool CrCondition=false;

            //Function to check Skin pixel and their neighbor and mark it in list 'v'
            //Base case for when i,j lookover image size

                if (i < 0 || j < 0 || j >= org_bmp.Height || i >= org_bmp.Width)
                    return;
               
            //Check Skin colorpixel

            //try
            //{
                if(v[i,j]==0)
                {
                    // # Get R,G,B from source Image
                    Rss = org_bmp.GetPixel(i, j).R;
                    Gss = org_bmp.GetPixel(i, j).G;
                    Bss = org_bmp.GetPixel(i, j).B;

                    //Get r,g,b from sobel Image
                    rss = m.GetPixel(i, j).R;
                    gss = m.GetPixel(i, j).G;
                    bss = m.GetPixel(i, j).B;

                    //Convert Input R,G,B to Y,Cb,Cr color space
                    rgb2YCbCrONE(Rss, Gss, Bss);
                    Yss = Y1;
                    Cbss = Cb1;
                    Crss = Cr1;

                    //Condition to check that pixel is skin clor or not skin color
                    //Pre-calculate for Cr condition

                    if (Yss > 128.0 )
                    {
                        Q1 = ((256.0-Yss)/16.0)-2.0;
                        Q2 = 20.0-((256.0-Yss)/16.0);
                        Q3 = 6.0;
                        Q4 = -8.0;
                    }
                    else if (Yss <= 128.0) 
                    {
                        Q1 = 6.0;
                        Q2 = 12.0;
                        Q3 = 2.0+(Yss/32.0);
                        Q4 = (Yss / 16.0) - 16.0;
                    }

                    //Cr condition if that pixel has property that match with this condition , that pixel is skin color pixel
                    if (Crss >= -2.0*(Cbss+24.0) && Crss >= -1.0*(Cbss+17.0) && Crss >= -4.0*(Cbss+32.0) && 
                        Crss >= 2.5*(Cbss+Q1) && Crss >= Q3 && Crss >= -0.5*(Q4-Cbss) && 
                        Crss <= (220.0-Cbss)/6.0 && Crss <= (4.0/3.0)*(Q2-Cbss))
                    {
                        CrCondition = true;
                    }

                    //Check our pixel with Cr condition and sobel(from skin pixel isn't eage pixel)
                    if (CrCondition==true && (rss != 255 && gss != 255 && bss != 255))
                    {
                        //mark that pixel to skin pixel
                        v[i, j] = iv;

                        //count number of skin pixel in region
                        countin = countin + 1;

                        //Check their neighbor with recursive Function Setskin . 
                        //We check all neighbor of that pixel(8-nighbor)
                        SetSkin(i-1,j-1);
                        SetSkin(i-1,j);
                        SetSkin(i-1,j+1);
                        SetSkin(i,j-1);
                        SetSkin(i+1,j-1);
                        SetSkin(i,j+1);
                        SetSkin(i+1,j);
                        SetSkin(i + 1, j + 1);
                    }
                    //Bitmap findskin_out = new Bitmap(org_bmp);
                    else
                    {
                        picskin.SetPixel(i, j, Color.FromArgb(255, 255, 255));
                    }
                
                }
            //}
            //catch (IndexOutOfRangeException index)
            //{
            //    MessageBox.Show("IndexOutOfRangeException");
            //}
            //catch (OutOfMemoryException o)
            //{
            //    MessageBox.Show("OutOfMemoryException");
            //}
            limit_recursive--;
            return;
        }
        #endregion

        #region double[] calWeight()
        public double[] calWeight()
        {
            filterimage = new Bitmap(picskin);
            //Function to calculate 6 dimention of attribute that we retrive from main function
            //parameter = [allsize,size,nsegment,Rheight,Rwidth,LargePerAll ]
            double[] parameter = new double[] { 0, 0, 0, 0, 0, 0 };

            //If count empty that mean don't have skin pixel in source Image we return 0 for all dimention
                    
            if (count.Count == 0)
            {
                return parameter;
            }

            ///Crate parameter for use in function
            
            ArrayList Region = new ArrayList();//Information about Region
            ArrayList RegionMx = new ArrayList();
            ArrayList RegionMy = new ArrayList();
            ArrayList countTemp = count;
            
            int loopc = 1 ;//loop count 
            double allsize = 0 ;// all number of skin color pixel in source Image 
            int locationM = 0 ;// Index to Region that has maximum number of pixel
            /// maximum number of pixel in source Image
            int MAXC = 0;
            int[] countTemp1 = (int[])countTemp.ToArray(typeof(int));
            for (int i=0;i<countTemp1.Length;i++)
            {
                MAXC = Math.Max(MAXC, countTemp1[i]);//maximum number of pixel in source Image
            }

            // filter small area
            for (int i = 0; i < countTemp1.Length;i++ )
            {
                if (countTemp1[i] > 50)
                {
                    Region.Add(loopc);// keep Index of region in Image
                    allsize = allsize + countTemp1[i];//count pixel that is skin pixel
                }
                if (MAXC == countTemp1[i])
                {
                    locationM = loopc;// keep Index of maximum region in Image
                }
                loopc++;
            }
            //After filter if Image don't have Region that has pixel more than 50 pixel 
            //we will ignore it and return 0 for all dimention

            if (allsize == 0)
            {
                return parameter;
            }
            int[] Region1 = (int[])Region.ToArray(typeof(int));
            //we will find region with Index from above
            for (int i = 0; i < org_bmp.Width;i++ )
            {
                for (int j = 0; j < org_bmp.Height; j++)
                {
                    //int vtemp = v[i,j];
                    bool chkRegion=false;
                    //Ignore region that has small size                 
                    for (int z = 0; z < Region1.Length;z++ )
                    {
                        if (v[i, j] == Region1[z])
                        {
                            chkRegion = true;
                        }
                    }
                    if (chkRegion == false)
                    {
                        filterimage.SetPixel(i, j, Color.FromArgb(255, 255, 255));
                    }

                    //when meet region that has maximum size we will keep its coordinate
                    if (v[i, j] == locationM)
                    {
                        RegionMy.Add(i);
                        RegionMx.Add(j);
                        
                    }  
                }
            }

            //Calculate 6 dimention of source Image
            double LargePerAll=0;
            int temp = countTemp1[0];

            //First Dimention is Ratio of largest per all
            for (int i = 0; i < countTemp1.Length; i++)
            {
                temp = Math.Max(temp, countTemp1[i]);

            }
            LargePerAll = temp * 100.0 / allsize;

            //Second Dimention is Ratio of height
            double Rheight = 0, maxRegionMx1 = Convert.ToDouble(RegionMx[0]), minRegionMx1 = Convert.ToDouble(RegionMx[0]);
            //int[] RegionMx1 = (int[])RegionMx.ToArray(typeof(int));
            for (int i = 0; i < RegionMx.Count; i++)
            {
                maxRegionMx1 = Math.Max(maxRegionMx1, Convert.ToDouble(RegionMx[i]));
                minRegionMx1 = Math.Min(minRegionMx1, Convert.ToDouble(RegionMx[i]));

            }
            Rheight = (maxRegionMx1 - minRegionMx1 + 1) * 100 / org_bmp.Height;

            //Third Dimention is Ratio of width
            double Rwidth = 0, maxRegionMy1 = Convert.ToDouble(RegionMy[0]), minRegionMy1 = Convert.ToDouble(RegionMy[0]);
            //int[] RegionMy1 = (int[])RegionMy.ToArray(typeof(int));
            for (int i = 0; i < RegionMy.Count; i++)
            {
                maxRegionMy1 = Math.Max(maxRegionMy1, Convert.ToDouble(RegionMy[i]));
                minRegionMy1 = Math.Min(minRegionMy1, Convert.ToDouble(RegionMy[i]));
            }
            Rwidth = (maxRegionMy1 - minRegionMy1 + 1) * 100.0 / org_bmp.Width;

            //Fourth Dimention is Ratio of skin area
            // the ratio of skin area to image area
            allsize = allsize*100.0/(org_bmp.Width*org_bmp.Height);

            //Fifth Dimention is Ratio of largest area
            // the ratio of the area of the largest skin segment to the image area
            double size1 = 0;
            size1 = MAXC * 100.0 / (org_bmp.Width * org_bmp.Height);

            //Sixth Dimention is Number of segment
            double nsegment = Region1.Length;
            nsegment = nsegment * 100 / 13;

            //Return all dimention
            parameter = new double[] { allsize, size1, nsegment, Rheight, Rwidth, LargePerAll };
            return parameter;
        }
        #endregion
    }
}
