using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Timers;
using AppModule.InterProcessComm;
using AppModule.NamedPipes;
using UsingNamedPipe;
using Microsoft.Win32;//Registry
namespace WindowsService1
{
    
    public partial class Service1 : ServiceBase
    {
        public static PipeManager pipeManager;
        public Service1()
        {
            InitializeComponent();
            /////Default Variable Value For Interprocess communication
            uint OutBuffer = 512;
            uint InBuffer = 512;
            const int MAX_READ_BYTES = 5000;
            WServiceNamedPipe pipe = new WServiceNamedPipe("WindowsService", OutBuffer, InBuffer, MAX_READ_BYTES, false);
            
            ///Initial PipeManager
            pipeManager = new PipeManager();
            pipeManager.SetServerNamedPipe(pipe);
            pipeManager.Initialize();

            pipe.SetPipeManager(pipeManager);
            /////
        }
        protected override void OnStart(string[] args)
        {
            /// TODO: Add code here to start your service.
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            ///Start Personal Web Proxy for working.
            PersonalWebProxy server = new PersonalWebProxy();
            server.Start_Server();

            /*///Start Windows Control for working.
            string servicePath = Application.ExecutablePath;
            string controlPath = servicePath.Replace("windowsservice1.exe", "windowscontrol.exe");
            Process[] pro_Wcintrol = Process.GetProcessesByName("WindowsControl.exe");
            if (pro_Wcintrol.Length < 1)
            {
                ProcessStartInfo oInfo = new ProcessStartInfo(controlPath);   
                oInfo.ErrorDialog = false;   
                //oInfo 
                Process.Start(oInfo);
            }*/
        }

        protected override void OnStop()
        {
        }

    }
}
