<?php include("class_system.php"); ?>
<?php
$str = "<?xml version=\"1.0\" ?>";
?>
<?php 
function Get_Date($day)
{
	if($day == "To_Day")
	{
		$date = getdate();
		$strdate = $date['year'] . '-' . $date['mon'] . '-' . $date['mday']; 
		return $strdate;
	}
	else return $day;
} // function Get_Date($day)
function Get_Dates($val)
{
		$date = getdate();
		//$time =   $date[hours] * 100 + $date[minutes];
		//$time =  $time - $val ;
		//$min = $time % 100;
		//$hour = ($time - $min) / 100;
		//if($min > 59 ) $min = $min - 30;
		//if($hour > 59 && $hour < 0) $hour = 0;
		//$strdate = $date['year'] . '-' . $date['mon'] . '-' . $date['mday'] . ' ' . $hour . ':' . $min . ':' . $date[seconds];
		$strdate = $date['year'] . '-' . $date['mon'] . '-' . $date['mday'] . ' ' . ($date[hours] - $val) . ':' . $date[minutes] . ':' . $date[seconds];
		return $strdate;
}// function Get_Dates($val)
$Mode = $_GET['Mode'];
	if($Mode == "real"){
		$start_date =  Get_Dates(1);
		$end_date =  Get_Dates(0);
	}// if
	else {
		$Sday = $_GET['Sday'];
		$Stime = $_GET['Stime'];
		$Eday = $_GET['Eday'];
		$Etime = $_GET['Etime'];
		$start_date = Get_Date($Sday) . ' ' . $Stime . ':00';
		$end_date = Get_Date($Eday) . ' ' . $Etime . ':59';
	}// else
		$car = $_GET['ID'];
		$ob = new point_object();
		$ob->Set_config("localhost","root","","map");
		$ob->ConnectDB();
		$sql = "SELECT * FROM real_history WHERE carid=" . $car . " AND dateandtime >= '" . $start_date . "' AND dateandtime <= '" . $end_date . "' ORDER BY dateandtime";		
		//$sql = "SELECT * FROM history WHERE id_car=" . $car . " ORDER BY date_time";	
		$ans = $ob->Get_value($sql);
		$num = mysql_num_rows($ans);
		$count = 0;
		
		if($num > 0)
		{
			$str = $str . "<data>";
			$row = mysql_fetch_array($ans);
			$str = $str . "<begin>";
			$str = $str . '<latitude>' . $row['latitude'] . '</latitude>';
			$str = $str . '<longitude>' . $row['longitude'] . '</longitude>';
			$str = $str . '<dateandtime>' . $row['dateandtime'] . '</dateandtime>';
			$str = $str . "</begin>"; 
			$str = $str . '<item>';					
			$str = $str . '<latitude>' . $row['latitude'] . '</latitude>';
			$str = $str . '<longitude>' . $row['longitude'] . '</longitude>';
			$str = $str . '</item>';
			$count++;
			while($count < $num - 1){
				$row = mysql_fetch_array($ans);
				$str = $str . '<item>';
				$str = $str . '<latitude>' . $row['latitude'] . '</latitude>';
				$str = $str . '<longitude>' . $row['longitude'] . '</longitude>';
				$str = $str . '</item>';
				$count++;
			}// while

			$row = mysql_fetch_array($ans);
			$str = $str . '<item>';
			$str = $str . '<latitude>' . $row['latitude'] . '</latitude>';
			$str = $str . '<longitude>' . $row['longitude'] . '</longitude>';
			$str = $str . '</item>';

			$str = $str . "<end>";
			$str = $str . '<latitude>' . $row['latitude'] . '</latitude>';
			$str = $str . '<longitude>' . $row['longitude'] . '</longitude>';
			$str = $str . '<dateandtime>' . $row['dateandtime'] . '</dateandtime>';
			$str = $str . "</end>";
			
			$str = $str . "</data>";
			mysql_free_result($ans);
		} // if
		else $str = 0;
		
		$ob->CloseDB();
		echo $str;
		//echo $sql;
?>