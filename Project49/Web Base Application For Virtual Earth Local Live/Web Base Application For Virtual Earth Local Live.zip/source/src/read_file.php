<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<?php include("class_system.php"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
</head>
<body>
<?php
$name_dir = "YASOTHON";

$patheng = "D:\working\data\Data Map Eng\\" . $name_dir;
$paththai = "D:\working\data\Data Map Thai\\" . $name_dir;

$dir = opendir($patheng);
$file_name[50];
$count = 0;
while (($data = readdir($dir)) !== false){
	$file_name[$count] = $data;
	++$count;
}
closedir($dir);
$start = 2;
while($start != $count){
	$str = $file_name[$start];
	$pos = strpos($str, '.tmg ');
	if($pos !== 0)$str = substr($str,$pos + 4);
	$str = substr($str,0,-4);
	$str = substr($str,3);
	
	read($patheng .'\\'. $file_name[$start],$paththai .'\\'. $file_name[$start],$str);
	$start++;
}

function read($patheng,$paththai,$nametb)
{
	echo "<font color=\"#00FF00\">file name: </font>" . $nametb;
	echo "<br>";
	echo "path : " . $patheng;
	echo "<br>";

	$pos = strpos($nametb,' ');
	if($pos == true)$nametb[$pos] = '_';
	/*
	if( $ob->Create_table($nametb))echo "<font color=\"#00FF00\">Create_table Complete</font> ";
	else echo "<font color=\"red\"> Create_table Error </font>";
	echo "<br>";
	*/
	$aeng = file($patheng);
	$athai = file($paththai);
	$ob = new point_object();
	$ob->Set_config("localhost","root","","map");
	$ob->ConnectDB();
	for($i = 0; $i < count($aeng); $i++){
		//echo $aeng[$i] . '<br>';
		//echo $athai[$i] . '<br>';
		$va = get($aeng[$i] ,$athai[$i]);
		if($va != 0) {
			$sql = "INSERT INTO " . $nametb . " VALUES(" . $va . ")";
			echo $sql . ";<br/>";
			mysql_query($sql);
		}
		else echo "Not insert ! <br/>";
		/*
		if($ob->Add_object($nametb,'(' . $va . ')'))echo "<font color=\"#00FF00\">Insert Complete</font> <br>";
		else echo "<font color=\"red\">Insert Error </font><br>";
		*/
	} // for
	$ob->CloseDB();
}
function get($data_eng,$data_thai)
{
	$pos = strpos($data_eng,',');
	$name_eng = substr($data_eng,0,$pos);
	$data_eng = substr($data_eng,$pos + 1); 

	$pos = strpos($data_thai,',');
	$name_thai = substr($data_thai,0,$pos);
	$data_thai = substr($data_thai,$pos + 1); 
	if($data_eng != $data_thai)
	{
		echo "<font color=00FFFF>------------------------------------------------<br>";
		echo "<font color=\"red\"> Error </font><br>";
		echo $data_eng . '<br>';
		echo $data_thai . '</font><br>';
		return 0;
	}
	$code_thai = "35";
	return $data_eng . ",\"" . $name_eng . "\",\"" . $name_thai . "\"," . $code_thai; 
}
?>
</body>
</html>