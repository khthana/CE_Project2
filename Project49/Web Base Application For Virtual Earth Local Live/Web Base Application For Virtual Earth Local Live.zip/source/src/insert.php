INSERT INTO AMPHURE VALUES (9.256708, 99.187101,"Amphoe Tha Chang","�����������",0)
SELECT * FROM AMPHURE WHERE latilude =8.864003 AND longtilude =98.326578

CREATE TABLE AMPHURE(latilude double(8,6) NOT NULL ,longtilude double(9,6) NOT NULL ,PRIMARY KEY(latilude,longtilude),name_eng VARCHAR(80) ,name_thai VARCHAR(80) CHARACTER SET tis620,code_state INT(3))
