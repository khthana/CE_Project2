<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php include("class_system.php"); ?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<title>Map</title>
</head>
<body>
<form action="http://161.246.5.208/Map/src/add_province.php" method="POST">
<table>
<tr>
	<td>ID</td>
	<td><input type="text" name="id" /></td>
</tr>
<tr>
	<td>Name Eng</td>
	<td><input type="text" name="eng" /></td>
</tr>
<tr>
	<td>Name Thai</td>
	<td><input type="text" name="thai" /></td>
</tr>
</table>
<input type="SUBMIT" value="ADD" />
</form>
<?php
$id = $_POST['id']; 
$eng = $_POST['eng']; 
$thai = $_POST['thai'];
if($id)
{
	$ob = new point_object();
	$ob->Set_config("localhost","root","","map");
	$ob->ConnectDB();
	$sql = "INSERT INTO province VALUES($id,\"$eng\",\"$thai\")";
	echo $sql . "<br/>";
	mysql_query($sql);
	$sql = "SELECT * FROM province WHERE province_id=$id";
	$ans = mysql_query($sql);
	$row = mysql_fetch_array($ans);
	echo "Id:". $row['province_id'] . "<br/>";
	echo "Eng:". $row['name_eng'] . "<br/>";
	echo "Thai:". $row['name_thai'] . "<br/>";

	$ob->CloseDB();
}
?>
</body>
</html>