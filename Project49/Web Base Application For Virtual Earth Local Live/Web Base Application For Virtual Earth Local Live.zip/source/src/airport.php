<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php include("class_system.php"); ?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<title>Map</title>
</head>
<body>
<table>
<tr>
	<td>ID</td>
	<td><input type="text" name="id" /></td>
</tr>
<tr>
	<td>Name Eng</td>
	<td><input type="text" name="eng" /></td>
</tr>
<tr>
	<td>Name Thai</td>
	<td><input type="text" name="thai" /></td>
</tr>
</table>
<input type="SUBMIT" value="ADD" />
<?php
$id = "10";
$ob = new point_object();
$ob->Set_config("localhost","root","","map");
$ob->ConnectDB();
$sql = "SELECT * FROM province ";
$ans = mysql_query($sql);
while($row = mysql_fetch_array($ans))
{
	$id_pro = $row['province_id'];
	$eng = $row['name_eng'];
	$thai = $row['name_thai']; 
echo "Id:$id_pro<br/>";
echo "Eng:$eng<br/>";
echo "Thai:$thai<br/>";
echo "-----------------<br/>";
$new_eng = "Airport " . $eng;
$new_thai = "ʹ���Թ " . $thai;
$sql = "UPDATE airport SET name_eng = \"" . $new_eng . "\",name_thai=\"". $new_thai . "\" WHERE province=" . $id_pro;
mysql_query($sql);
echo "$sql<br/>";
}
$ob->CloseDB();
?>
</body>
</html>