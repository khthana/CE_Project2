<?php

class point_object
{
	private $dbserver;
	private $username;
	private $pwd;
	private $dbname;
	function __construct() 
	{
		$this->dbserver = "localhost";
		$this->username = "root";
		$this->pwd = "";
		$this->dbname = "map";
	}
	public function Set_config($dbser,$uname,$pass,$dbn) 
	{
		$this->dbserver = $dbser;
		$this->username = $uname;
		$this->pwd = $pass;
		$this->dbname = $dbn;
	}
	public function Get_dbserver() 
	{
		return $this->dbserver;
	}
	public function Get_username() 
	{
		return $this->username;
	}
	public function Get_password() 
	{
		return $this->pwd;
	}
	public function Get_dbname() 
	{
		return $this->dbname;
	}
	public function ConnectDB()
	{
		if(! ($dbh = mysql_connect($this->dbserver,$this->username,$this->pwd))) return "Error Connect server";
		if(! ($dbh = mysql_select_db($this->dbname))) return "Error Connect Database";
		else return "ok"; 
	}
	public function CloseDB() 
	{
		mysql_close();
	}
	/* parameter $layer is name table
				 $value is value of table (value 1 ,value 2,....)
				 Data Type �Zero� Value 
				 DATETIME '0000-00-00 00:00:00' 
				 DATE 'YYYY-MM-DD'
				 DATE '0000-00-00' 
				 TIMESTAMP '0000-00-00 00:00:00' 
				 TIME 'HH:MM:SS'
				 TIME '00:00:00' 
				 YEAR 0000 
	*/
	public function Add_object($layer , $value)
	{
		if(mysql_query("INSERT INTO " . $layer . " VALUES " . $value)) return true;
		else return false;
	}
	public function Delete_object($layer,$key)
	{
		try
		{
			mysql_query("DELETE FROM " . $layer ." WHERE " . $value); 
			return true;
		}
		catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage();
			return false;
		}
	}
	public function Get_allvalue($layer)
	{
		return mysql_query("select * from " . $layer);
	}
	public function Get_value($sql)
	{
		return mysql_query($sql);
	}
	public function Create_table($nametable)
	{
		$str = "CREATE TABLE " . $nametable ."(latilude double(8,6) NOT NULL ,longtilude double(9,6) NOT NULL ,PRIMARY KEY(latilude,longtilude),name_eng VARCHAR(80) ,name_thai VARCHAR(80) CHARACTER SET tis620,code_state INT(3))";
		if(!mysql_query($str)) return false;
		else return true;
	}
}
?>