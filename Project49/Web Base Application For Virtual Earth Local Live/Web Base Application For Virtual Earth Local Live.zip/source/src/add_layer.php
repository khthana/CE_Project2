<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<?php include("class_system.php"); ?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<title>Map</title>
</head>
<body>
<form action="http://161.246.5.208/Map/src/add_layer.php" method="POST">
<table>
<tr>
	<td>Layer group</td>
	<td><input type="text" name="group" /></td>
</tr>
<tr>
	<td>Layer Name Eng</td>
	<td><input type="text" name="eng" /></td>
</tr>
<tr>
	<td>Layer Name Thai</td>
	<td><input type="text" name="thai" /></td>
</tr>
</table>
<input type="SUBMIT" value="ADD" />
</form>
<?php
$group = $_POST['group']; 
$eng = $_POST['eng']; 
$thai = $_POST['thai'];
if($eng)
{
	$ob = new point_object();
	$ob->Set_config("localhost","root","","map");
	$ob->ConnectDB();
	$sql = "INSERT INTO layer VALUES(''," . $group .",\"". $eng . "\",\"" . $thai . "\")";
	echo $sql . "<br/>";
	mysql_query($sql);
	//$sql = "SELECT * FROM ";
	//mysql_query($sql);
	$ob->CloseDB();
}
?>
</body>
</html>