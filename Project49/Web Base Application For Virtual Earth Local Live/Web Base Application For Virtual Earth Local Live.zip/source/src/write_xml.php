<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php header("Cache-Control: no-cache, must-revalidate"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<title>Map</title>
<?php include("class_system.php"); ?>
</head>
<body>
<?php
function wxml($layer,$plat,$plon,$plat2,$plon2,$num)
{
	$link = mysql_connect("127.0.0.1","root","") or die('Could not connect: ' . mysql_error());
	mysql_select_db('map') or die('Could not select database');
	$table = str_replace(" ","_",$layer);
	$sql = "SELECT * FROM $table WHERE latitude BETWEEN $plat2 AND $plat AND longitude BETWEEN $plon AND $plon2 ";
	$ans = mysql_query($sql);
	$number = mysql_num_rows($ans);
	echo $sql . "<br/>";

	if($number != 0)
	{
		echo "<font color=\"#00FF00\">Count of row:[" . $number . "]</font><br/>";
		$ans2 =mysql_query("SELECT * FROM layer WHERE name_eng=\"$layer\" ");
		$number = mysql_num_rows($ans2);
		$file_name_eng = $layer . "_eng" . $num . ".xml";
		$file_name_thai = $layer . "_thai" . $num . ".xml";
		if($number != 0 )
		{
			$row = mysql_fetch_array($ans2);
			$id = $row['layer_id'];
			$neng = $row['name_eng'];
			$nthai = $row['name_thai'];
			//echo "<font color=\"#00FF44\">[$neng][$nthai]</font><br/>";
			mysql_free_result($ans2);
			$sql2 = " INSERT INTO layer_data (layer_id, name_eng, name_thai, latitude_start, longitude_start, latitude_end, longitude_end) VALUES( $id , \"$file_name_eng\" , \"$file_name_thai\" ,$plat , $plon ,$plat2 ,$plon2) ";
			//echo $sql2 . "<br/>"; 
			mysql_query($sql2);// or die('Query failed: ' . mysql_error());
		}// if
		$file_eng = fopen("xml/" . $layer . "/". $file_name_eng,"w");
		$file_thai = fopen("xml/" . $layer . "/". $file_name_thai,"w");

		fputs($file_eng,"<?xml version=\"1.0\" encoding=\"tis-620\" ?>\n");
		fputs($file_eng,"<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\" xmlns=\"http://purl.org/rss/1.0/\">\n"); 

		fputs($file_thai,"<?xml version=\"1.0\" encoding=\"tis-620\"  ?>\n");
		fputs($file_thai,"<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\" xmlns=\"http://purl.org/rss/1.0/\">\n"); 
		while($row = mysql_fetch_array($ans))
		{
			//print_r($row);
			fputs($file_eng,"<item>\n");
			fputs($file_thai,"<item>\n");
			$title = "<title>" . $neng . "</title>\n";
			$title_thai = "<title>" . $nthai . "</title>\n";
			$des = "<description>" . $row['name_eng'] . "</description>\n";
			$des_thai = "<description>" . $row['name_thai'] . "</description>\n";
			$lat = "<geo:lat>" . $row['latitude'] . "</geo:lat>\n";
			$long = "<geo:long>" . $row['longitude'] . "</geo:long>\n";
			//<geo:Details>--------- </geo:Details>
			fputs( $file_eng, $title);
			fputs( $file_eng, $des);
			fputs( $file_eng, $lat);
			fputs( $file_eng, $long);
			fputs($file_eng,"</item>\n");

			fputs( $file_thai, $title_thai);
			fputs( $file_thai, $des_thai);
			fputs( $file_thai, $lat);
			fputs( $file_thai, $long);
			fputs($file_thai,"</item>\n");
		
		}	// while
		fputs($file_eng,"</rdf:RDF>\n");
		fputs($file_thai,"</rdf:RDF>\n");
		Fclose($file_eng);
		Fclose($file_thai);
	
	}// if
	else
	{
		mysql_close($link);
		return $num;
	}
	mysql_close($link);
	echo "number: $num <br/>";
	return ++$num;
}

$count = 0; // number of file
// all thailand
// from  20.5 --> 4.5 
$sizeof = 0.05;
for($lat = 20.5;$lat > 4.5;$lat = $lat -$sizeof)
{
	//$lat = 19.2;
	// from 97.1 -- > 105.9 
	for($lon = 97.1;$lon < 105.9;$lon = $lon + $sizeof)
	{
		$lat2 = ($lat - $sizeof) ;
		$lon2 = ($lon + $sizeof); 
		//echo "{ $lat,$lon,$lat2,$lon2,$count }<br/>";
		$count = wxml("tour",$lat,$lon,$lat2,$lon2,$count); // department store
	}
}
?>
</body>
</html>