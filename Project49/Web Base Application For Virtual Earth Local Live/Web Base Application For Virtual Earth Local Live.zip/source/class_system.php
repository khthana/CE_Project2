<?php
class point_object
{
	private $dbserver;
	private $username;
	private $pwd;
	private $dbname;
	function __construct() 
	{
		$this->dbserver = "localhost";
		$this->username = "root";
		$this->pwd = "";
		$this->dbname = "map";
	}// function __construct 
	public function Set_config($dbser,$uname,$pass,$dbn) 
	{
		$this->dbserver = $dbser;
		$this->username = $uname;
		$this->pwd = $pass;
		$this->dbname = $dbn;
	} //  function Set_config($dbser,$uname,$pass,$dbn) 
	public function Get_dbserver() 
	{
		return $this->dbserver;
	} // function Get_dbserver() 
	public function Get_username() 
	{
		return $this->username;
	} // function Get_username() 
	public function Get_password() 
	{
		return $this->pwd;
	} // function Get_password() 
	public function Get_dbname() 
	{
		return $this->dbname;
	} // function Get_dbname() 
	public function ConnectDB()
	{
		if(! ($dbh = mysql_connect($this->dbserver,$this->username,$this->pwd))) return "Error Connect server";
		if(! ($dbh = mysql_select_db($this->dbname))) return "Error Connect Database";
		else return "ok"; 
	} //  function ConnectDB()
	public function CloseDB() 
	{
		mysql_close();
	} // function CloseDB() 
	/* parameter $layer is name table
				 $value is value of table (value 1 ,value 2,....)
				 Data Type �Zero� Value 
				 DATETIME '0000-00-00 00:00:00' 
				 DATE 'YYYY-MM-DD'
				 DATE '0000-00-00' 
				 TIMESTAMP '0000-00-00 00:00:00' 
				 TIME 'HH:MM:SS'
				 TIME '00:00:00' 
				 YEAR 0000 
	*/
	public function Add_object($layer , $value)
	{
		if(mysql_query("INSERT INTO " . $layer . " VALUES " . $value)) return true;
		else return false;
	} // function Add_object($layer , $value)
	public function Delete_object($layer,$key)
	{
		try
		{
			mysql_query("DELETE FROM " . $layer ." WHERE " . $value); 
			return true;
		} // try
		catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage();
			return false;
		} // catch
	} // function Delete_object($layer,$key)
	public function Get_allvalue($layer)
	{
		return mysql_query("select * from " . $layer);
	} // function Get_allvalue($layer)
	public function Get_value($sql)
	{
		return mysql_query($sql);
	} // function Get_value($sql)
	public function Create_table($nametable)
	{
		$str = "CREATE TABLE " . $nametable ."(latilude double(8,6) NOT NULL ,longtilude double(9,6) NOT NULL ,PRIMARY KEY(latilude,longtilude),name_eng VARCHAR(50),name_thai VARCHAR(50),code_state INT(4))";
		if(!mysql_query($str)) return false;
		else return true;
	} // function Create_table($nametable)
} // class
function GetPoint($data)
{
	$str = "";
	while($row = mysql_fetch_array($data))
	{
			$str = $str . 'new VELatLong(' . $row['latilude'] . "," . $row['longtilude'] . '),';
	}
	$index = strlen($str);
	$str[$index - 1] = ']';
	mysql_free_result($ans);
	$str = '[' . $str;
	return $str;
}
?>