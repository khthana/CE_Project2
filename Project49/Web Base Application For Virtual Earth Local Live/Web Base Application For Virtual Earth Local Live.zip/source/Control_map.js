<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="pushpins.css"> <? // Download file pushpins.css at use add object ?>
<script src="http://dev.virtualearth.net/mapcontrol/v4/mapcontrol.js"></script> // Download Map
<script>
// create object communication of ajax
var number = 0;
var index = 0;
 var isIE = navigator.userAgent.toLowerCase().indexOf('msie') != -1;
        // If Firefox.  Define loadXML method.
        if (!isIE) {
             Document.prototype.loadXML = function (s) {        
             // Parse the string to a new doc.
             var doc2 = (new DOMParser()).parseFromString(s, 'text/xml');
			// Remove all initial children.
            while (this.hasChildNodes())
                    this.removeChild(this.lastChild);
					// Insert and import nodes.
                    for (var i = 0; i < doc2.childNodes.length; i++) { this.appendChild(this.importNode(doc2.childNodes[i], true));       }
           };
     } // if
// Get position of object or car
function OnGet(ID,Mode,Sday,Eday,Stime,Etime)
{
	xmlHttp = GetXmlHttpObject();
	//Set_Map($IDCar,$mode,$s_carlender,$e_carlender,$s_hour . ':' . $s_ss,$e_hour . ':' . $e_ss);
	var  parameter = "ID=" + ID + "&Mode=" + Mode + "&Sday=" + Sday + "&Eday=" + Eday;
	parameter = parameter + "&Stime=" + Stime + "&Etime=" + Etime + "&id="+Math.random();
	var url="http://161.246.5.208/Map/data.php?"  + parameter;	
	//var url="http://161.246.5.208/Map/ajax/getdata.php?id=1";
	//alert (url); 
	xmlHttp.onreadystatechange = stateChanged;  // When server respond go to function stateChanged
	xmlHttp.open("GET",url,true);

	xmlHttp.send(null);
}
// Computing respond from server
// "xmlHttp.responseText" is message of server
function stateChanged() 
{ 
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{
		var  outputString = "";
		var xmlDocument;
		//alert (xmlHttp.responseText); 
		if (xmlHttp.responseText == "0") 
		{
			alert ("Not has data !"); 
			mode = "history";
			return 0;
		}
		 else if (isIE) {
                  xmlDocument = new ActiveXObject('Microsoft.XMLDOM');
                  xmlDocument.loadXML(xmlHttp.responseText);
        }// if
        else { // If Firefox.
                  xmlDocument = document.implementation.createDocument('', 'doc', null);
                  xmlDocument.loadXML(xmlHttp.responseText);
        }// else
		if (index != 0)
		{
					Delete_object("End");
					Delete_object("Begin");
					DeletePoly("Line")
		}
		var lat;
		var lon;
		var datetime;
		var data;
		var x;
		var y;
		var outputString = "";
		var point = new Array();
		// Get data from message and create point and line
		var begin = xmlDocument.getElementsByTagName('begin');
                lat = begin[0].getElementsByTagName('latitude');
                lon = begin[0].getElementsByTagName('longitude');
				datetime = begin[0].getElementsByTagName('dateandtime');
                 x = lat[0].firstChild.data;
                 y = lon[0].firstChild.data;
				 data = datetime[0].firstChild.data;
				 data = "Begin at date : " + data;
				 Add_object('Begin',x,y,'car.bmp',"Begin Car " ,data);

				var end = xmlDocument.getElementsByTagName('end');
                lat = end[0].getElementsByTagName('latitude');
                lon = end[0].getElementsByTagName('longitude');
				datetime = end[0].getElementsByTagName('dateandtime');
                 x = lat[0].firstChild.data;
                 y = lon[0].firstChild.data;
				 data = datetime[0].firstChild.data;
				 data = "End at date : " + data;
				 Add_object('End',x,y,'carend.bmp',"End Car " ,data);
				 GoTo(x,y);
				var items = xmlDocument.getElementsByTagName('item');
                for (var i = 0; i < items.length; i++) {
                    lat = items[i].getElementsByTagName('latitude');
                    lon = items[i].getElementsByTagName('longitude');
                    x = lat[0].firstChild.data;
                    y = lon[0].firstChild.data;
					point[i] = new VELatLong(x,y);
                  // outputString += x + ' : ' + y;
                  }
			// write line on map
			DrawPoly("Line", point , 1 , new VEColor(255,0,255,1));
			index = 1;
	//alert (outputString); 
	//alert (xmlHttp.responseText);
	} // if
}// function stateChanged() 
// create object of ajax (firefox or IE )
function GetXmlHttpObject()
{ 
	var objXMLHttp = null;
	if (window.XMLHttpRequest)
	{
		objXMLHttp = new XMLHttpRequest();
	}// if
	else if (window.ActiveXObject)
	{
		objXMLHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}// else if
	return objXMLHttp;
}// function GetXmlHttpObject()

//----------------------------------------------------------------------------------------------------------------------------------------------
var map = null;
var lat = null;
var lon = null;
var zoom = 12;
//----------------------------------------------------------------------------------------------------------------------------------------------
function GetMap() // create Map
{
	map = new VEMap('myMap');
	map.LoadMap(new VELatLong(13.8, 100.5), zoom ,'r' , false);
	// Add Event
	//map.AttachEvent("onclick", OnMapClick);
	map.AttachEvent("onmouseup", Manage_Layer); // Add event of map on mouse up
}
function Manage_Layer(e) // create send massage to server
{
	var new_lat = map.GetCenter().Latitude;
	var new_lon = map.GetCenter().Longitude;
	lat = new_lat;
	lon = new_lon;
	var box = "0";
	
	if(document.getElementById("bank").checked == true) box = "1";
	if(document.getElementById("bureau").checked == true) box = box + ",2";
	if(document.getElementById("building").checked == true) box = box + ",3";
	if(document.getElementById("apartment").checked == true) box = box + ",4";
	if(document.getElementById("hotel").checked == true) box = box + ",5";
	if(document.getElementById("hospital").checked == true) box = box + ",6";
	if(document.getElementById("tour").checked == true) box = box + ",7";
	if(document.getElementById("transport_station").checked == true) box = box + ",8";
	if(document.getElementById("embassy").checked == true) box = box + ",9";
	if(document.getElementById("police").checked == true) box = box + ",10";
	if(document.getElementById("airport").checked == true) box = box + ",11";
	if(document.getElementById("university").checked == true) box = box + ",12";
	if(document.getElementById("school").checked == true) box = box + ",13";
	if(document.getElementById("temple").checked == true) box = box + ",14";
	if(document.getElementById("cinema").checked == true) box = box + ",15";
	if(document.getElementById("department_store").checked == true) box = box + ",16";
	if(document.getElementById("market").checked == true) box = box + ",17"; 
	
	box = box + ";";
	if(box != "0;")SendLayer(new_lat,new_lon,box);
}
function SendLayer(local_lat,local_lon,layer_name) // Send massage to server
{
		xmlHttp = GetXmlHttpObject();
		//alert(mode_layer);
		var  parameter = "latitude=" + local_lat +  "&longitude="+ local_lon + "&layer=" + layer_name + "&mode=" + mode_layer + "&id=" + Math.random();
		var url = "http://161.246.5.208/Map/Get_File_Name.php?" + parameter;	
		xmlHttp.onreadystatechange = FileData; // When server respond go to function FildData
		xmlHttp.open("GET",url,true);
		xmlHttp.send(null);
}
// computing respond massage from server
function FileData()
{
	if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
	{
		var  outputString = "";
		var xmlDocument;
		//alert(xmlHttp.responseText);
		if (xmlHttp.responseText == "0")
		{
			//alert ("Not has data !"); 
			return 0;
		}// if
		 else if (isIE) {
                  xmlDocument = new ActiveXObject('Microsoft.XMLDOM');
                  xmlDocument.loadXML(xmlHttp.responseText);
        }// else if
        else { // If Firefox.
                  xmlDocument = document.implementation.createDocument('', 'doc', null);
                  xmlDocument.loadXML(xmlHttp.responseText);
        }// else
		var items = xmlDocument.getElementsByTagName('item');
		var layer,name,src,icon;
		// get name layer and name file per one around
        for (var i = 0; i < items.length; i++)
		{
				layer = items[i].getElementsByTagName('layer');
                name = items[i].getElementsByTagName('name');
				layer = layer[0].firstChild.data;
                name = name[0].firstChild.data;
				icon = "http://161.246.5.208/Map/src/icon/" + layer + ".bmp";
				src = "http://161.246.5.208/Map/src/xml/" + layer + "/" + name;
				AddLayer(layer,name,src,icon); // send file name and layer name to function addlayer
				//alert(src);
		}
		//alert(xmlHttp.responseText);
	}//if
}
function GoTo(lat,lon)
{
	map.SetCenter(new VELatLong(lat, lon));
}
function OnMapClick(e)
{
      alert('Latitude = ' + e.view.LatLong.Latitude + ', Longitude = ' + e.view.LatLong.Longitude + ', Zoom=' + e.view.zoomLevel);
}
// image is path and file name of file image (jpg,png)
function Add_object(name_object,lat,lon,image,main_str,sub_str)
{
	var pin = new VEPushpin(name_object,new VELatLong(lat, lon),image,main_str,sub_str);
    map.AddPushpin(pin);
}
function Delete_object(name_object)
{
	map.DeletePushpin(name_object);
}
function Clear_map()
{
	map.Clear();
}
function DrawPoly(id,points,width,color)
{
	poly = new VEPolyline(id,points);
    poly.SetWidth(width);
    poly.SetColor(color);
    map.AddPolyline(poly);
}
function DeletePoly(id)
{
	 map.DeletePolyline(id);
}
// create layer on map
function AddLayer(layer_name,name,src,icon)
{
	try{
			
            var veLayerSpec = new VELayerSpecification();
            veLayerSpec.Type =VELayerType.GeoRSS;
            veLayerSpec.ID = name; // file name
            veLayerSpec.LayerSource =  src; // "http://161.246.5.208/Map/src/xml/Bank/bank_thai0.xml";
            veLayerSpec.Method = 'POST';
            veLayerSpec.FnCallback = onFeedLoad;
			veLayerSpec.IconUrl =  icon;// "http://161.246.5.208/Map/src/icon/bank.bmp";
            map.AddLayer(veLayerSpec);
			Set_File_Layer(layer_name,name);
	}
catch(err)
  {
  txt = "Error description: " + err.description + "\n\n";
 // alert(txt);
  }// catch
}// function
function DeleteLayer(id)
{
	 map.DeleteLayer(id);
}
 function onFeedLoad(feed)
 {
            //alert('Number of : ' + feed.length);
			1-1;
 }
 //  Create Layer
 var bank = new Array();
 var bureau = new Array();
 var building = new Array();
var apartment = new Array();
var hotel = new Array();
var hospital = new Array();
var tour = new Array();
var transport_station = new Array();
var embassy = new Array();
var police = new Array();
var airport = new Array();
var university = new Array();
var school = new Array();
var temple = new Array();
var cinema = new Array();
var department_store = new Array();
var market = new Array();
// buffer file name of  layer
 function Set_File_Layer(layer_name,file_name)
 {
		if(layer_name == "bank")  bank[bank.length] = file_name;
		else if(layer_name == "bureau") bureau[bureau.length] = file_name;
		else if(layer_name == "building") building[building.length] = file_name;
		else if(layer_name == "apartment") apartment[apartment.length] = file_name;
		else if(layer_name == "hotel") hotel[hotel.length] = file_name;
		else if(layer_name == "hospital") hospital[hospital.length] = file_name;
		else if(layer_name == "tour") tour[tour.length] = file_name;
		else if(layer_name == "transport station") transport_station[transport_station.length] = file_name;
		else if(layer_name == "embassy") embassy[embassy.length] = file_name;
		else if(layer_name == "police") police[police.length] = file_name;
		else if(layer_name == "airport") airport[airport.length] = file_name;
		else if(layer_name == "university") university[university.length] = file_name;
		else if(layer_name == "school") school[school.length] = file_name;
		else if(layer_name == "temple") temple[temple.length] = file_name;
		else if(layer_name == "cinema") cinema[cinema.length] = file_name;
		else if(layer_name == "department store") department_store[department_store.length] = file_name;
		else if(layer_name == "market") market[market.length] = file_name;

 }
 // remove layer
function Hide_Layer(layer_name)
{
		var buffer = new Array();
		if(layer_name == "bank"){  buffer = bank; bank = new Array(); }
		else if(layer_name == "bureau"){ buffer = bureau; bureau = new Array(); }
		else if(layer_name == "building"){ buffer = building; building = new Array(); }
		else if(layer_name == "apartment") { buffer = apartment; apartment = new Array(); }
		else if(layer_name == "hotel"){ buffer = hotel; hotel = new Array(); }
		else if(layer_name == "hospital"){ buffer = hospital; hospital = new Array(); }
		else if(layer_name == "tour"){ buffer = tour; tour = new Array(); }
		else if(layer_name == "transport station"){ buffer = transport_station; transport_station = new Array(); }
		else if(layer_name == "embassy"){ buffer = embassy; embassy = new Array(); }
		else if(layer_name == "police"){ buffer = police; police = new Array(); }
		else if(layer_name == "airport"){ buffer = airport; airport = new Array(); }
		else if(layer_name == "university") { buffer = university; university = new Array(); }
		else if(layer_name == "school"){ buffer = school; school = new Array(); }
		else if(layer_name == "temple"){ buffer = temple; temple = new Array(); }
		else if(layer_name == "cinema"){ buffer = cinema; cinema = new Array(); }
		else if(layer_name == "department store") { buffer = department_store; department_store = new Array(); }
		else if(layer_name == "market") { buffer = market; market = new Array(); }

		for (i = 0; i < buffer.length; i++)
		{
			map.DeleteLayer(buffer[i]);
		}
}
// click on control layer
function Select_Layer(layer_name)
{
	var new_lat = map.GetCenter().Latitude;
	var new_lon = map.GetCenter().Longitude;
	var id = ID_Layer(layer_name) + ";";
	var layer_id = layer_name.replace(" ","_");
	if(document.getElementById(layer_id).checked == true)SendLayer(new_lat,new_lon,id);
	else Hide_Layer(layer_name);
}
function ID_Layer(layer_name)
{
		if(layer_name == "bank")  return 1;
		else if(layer_name == "bureau")  return 2;
		else if(layer_name == "building")  return 3;
		else if(layer_name == "apartment") return 4;
		else if(layer_name == "hotel")  return 5;
		else if(layer_name == "hospital")  return 6;
		else if(layer_name == "tour")  return 7;
		else if(layer_name == "transport station")  return 8;
		else if(layer_name == "embassy")  return 9;
		else if(layer_name == "police")  return 10;
		else if(layer_name == "airport")  return 11;
		else if(layer_name == "university")  return 12;
		else if(layer_name == "school")  return 13;
		else if(layer_name == "temple")  return 14;
		else if(layer_name == "cinema") return 15;
		else if(layer_name == "department store") return 16;
		else if(layer_name == "market") return 17;
		else return 0;
}
 </script>