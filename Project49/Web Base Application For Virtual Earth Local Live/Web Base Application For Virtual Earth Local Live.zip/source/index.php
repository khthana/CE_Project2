<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<? //php header("Cache-Control: no-cache, must-revalidate"); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<title>Map</title>

<?php
	$mode_layer = $_GET['mode'];
	print "<script>";
	if($mode_layer == "" || $mode == "eng")print "var mode_layer = \"eng\";";
	else print "var mode_layer = \"thai\";";
	print "</script>";
	include("Control_map.js");
	include("class_system.php");
	include("func.php");
	//include("GetData.js");
?>
<script language="JavaScript" src="calendar.js"></script>
<link href="calendar-mos.css" rel="stylesheet" type="text/css"> 
<link rel="stylesheet" href="MapStyle.css" type="text/css" />
<script>
var mode = "real";
var idcar = "";
var sday = "";
var eday = "";
var stime = "";
var etime = "";
function Get_Map()
{
	GetMap();
	//setTimeout("alert('hello')",1250);
	var a="";
}
function Get(state)
{
	if(state == 0)
	{
		idcar = document.getElementById("id_car").value;
		if(document.getElementById("real").checked == true) mode = document.getElementById("real").value;
		else mode = document.getElementById("history").value;
		sday = document.getElementById("s_carlender").value;
		eday = document.getElementById("e_carlender").value;
		stime = document.getElementById("s_hour").value + ":" + document.getElementById("s_ss").value;
		etime = document.getElementById("e_hour").value + ":" + document.getElementById("e_ss").value;
	}
	OnGet( idcar , mode , sday , eday , stime , etime);
	if (mode == "real")	
	{
		//alert('hello');
		setTimeout("Get(1)",10000);
	}
}
 function control_layer(name_layer)
 {
	if(name_layer == "temple")
	{
		if(document.getElementById("temple").checked == true) Show_Layer("temple");
		else Hide_Layer("temple");
	}
 }
 var menu_state = 0;
 function Hidden_Menu()
 {
	 if(menu_state == 0)
	 {
		document.getElementById("menu").style.left = "-220px";
		document.getElementById("myMap").style.left = "5px";
		document.getElementById("myMap").style.width = "980px";
		document.getElementById("ch").src = "img/show.png";
		menu_state = 1;
	 }
	 else
	 {
		document.getElementById("menu").style.left = "5px";
		document.getElementById("myMap").style.left = "208px";
		document.getElementById("myMap").style.width = "780px";
		document.getElementById("ch").src = "img/hidden.png";
		menu_state = 0;
	 }
 }
</script>
</head>
<body  onload="Get_Map();" bgcolor="#E3DFE0">
<div id="myMap" style="border:solid gray; border-width:2px;" class="Main"></div>

<?php Print_Menu(); ?>

<div class="help">
<table width="190px">
<tr align="center">
	<td><img id="ch" src="img/hidden.png" onclick="Hidden_Menu()"/></td>
	<td><a href="/guide.zip"><img src="img/help.png" alt="guide"/></a></td>
</tr>
<tr align="center">
	<td><a href="http://161.246.5.208/Map/index.php?mode=eng" ><img src="img/eng.jpg" alt="English language"/></a></td>
	<td><a href="http://161.246.5.208/Map/index.php?mode=thai" ><img src="img/thai.jpg" alt="Thai language"/></a></td>
</tr>
</table>
</div>

<div class="Control_Layer">
<table style="border: solid gray;border-width:2px; background-color: #FFFFCC;" width="780" color="#990000">
<?php
	 Set_Layer();
?>
</table>
</div>
</body>