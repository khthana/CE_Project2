<?php include("class_system.php"); ?>
<?php
	function GETFILE($lat,$lon,$layer,$mode)
	{
	$ob = new point_object();
	$ob->ConnectDB();
	//echo "Lat[ $lat ]";
	$sql = "SELECT  l2.name_eng as name_layer,l1.name_eng as n_eng,l1.name_thai as n_thai FROM layer_data l1, layer l2 WHERE l1.layer_id = l2.layer_id AND l1.latitude_start >  $lat  AND l1.latitude_end < $lat AND l1.longitude_start < $lon AND l1.longitude_end > $lon  AND l1.layer_id=$layer";
	$ans = mysql_query($sql);
	//echo $sql . "<br/>";
	$output = 0;
	//$number = mysql_num_rows($ans);
	if($mode == "thai")
	{
		while($row = mysql_fetch_array($ans))
		{		
			$output = "<item>";
			$output = $output . "<layer>" . $row['name_layer'] . "</layer>";
			$output = $output . "<name>" . $row['n_thai'] . "</name>";
			$output = $output . "</item>";
		}// while
	}// if
	else
	{
		while($row = mysql_fetch_array($ans))
		{		
			$output = "<item>";
			$output = $output . "<layer>" . $row['name_layer'] . "</layer>";
			$output = $output . "<name>" . $row['n_eng'] . "</name>";
			$output = $output . "</item>";
		}// while
	}// else
	$ob->CloseDB();
	return $output;
	}// Function

	$x = $_GET['latitude'];
	$y = $_GET['longitude'];
	$l = $_GET['layer'];
	$mode = $_GET['mode'];
	$str = "<?xml version=\"1.0\" ?>";
	$str = $str . "<file>";
	$px = $x;
	$py = $y;
	$var = "";
	$state = false;
	if(strlen($l) == 0) $str = 0;
	else
	{
	$count = 0;
	while($state != true)
	{
		$buffer = $l[$count];
		if($buffer == ';') 
		{ 
			$state = true; 
			$data = GETFILE($px,$py,$var,$mode);
			if($data != "0") $str = $str . $data ;
		}
		else if ($buffer == ',') 
		{
			$data = GETFILE($px,$py,$var,$mode);
			if($data != "0") $str = $str . $data ;
			$var = ""; 
		}
		else $var = $var . $buffer;
		$count++;
	}// while
	$str = $str . "</file>";
	}// else
	echo $str;
	
?>