<?php
function init_idcar()
{
	$ob = new point_object();
	$ob->ConnectDB();
	$ans = $ob->Get_value("SELECT DISTINCT(carid) FROM real_history ORDER BY carid");
	while($row = mysql_fetch_array($ans))
	{
		echo "<OPTION VALUE=" . $row['carid'] . ">" . $row['carid'];
	}// while
	mysql_free_result($ans);
	$ob->CloseDB();
} // function init_idcar()
function print_digi($end ,$not)
{
	for($i=0;$i< 10;$i++)
	{
		echo "<option value=\"0" . $i . "\">" . $i . "</option>";
	}// for
	for($i=10;$i<$end - 1;$i++)
	{
		echo "<option value=\"" . $i . "\">" . $i . "</option>";
	}// for
	if ($not == "not") { echo "<option value=\"" . $i . "\" selected=\"selected\">" . $i . "</option>"; }
	else { echo "<option value=\"" . $i . "\">" . $i . "</option>"; }
}// function print_digi($end ,$not)
function Set_Layer()
{
	$ob = new point_object();
	$ob->ConnectDB();
	$ans = $ob->Get_value("SELECT * FROM layer ORDER BY group_id");
	$count = 0;
	while($row = mysql_fetch_array($ans))
	{
		if($count == 0 ) echo "<tr>";
		$layer = $row ['name_eng'];
		$layer_id = str_replace(" ","_",$layer);
		$id = $row['layer_id'];
		$mode_layer = $_GET['mode'];
		if($mode_layer == "eng" || $mode_layer == "") $name = $row ['name_eng'];
		else $name = $row ['name_thai'];
		echo "<td><INPUT  type=\"checkbox\" id=\"$layer_id\" onclick=\"Select_Layer('$layer');\" /></td>\n"; 
		echo "<td><font style=\"color: #660000; \">$name  </font><img src=\"src/icon/$layer.bmp\" /></td>";
		$count++;
		if($count == 5 ){ echo "</tr>"; $count = 0; }
	}// while
	if($count != 0){
		while($count != 5)
		{
			echo "<td></td>";
			$count++;
		}
		echo "</tr>";
	}
	mysql_free_result($ans);
	$ob->CloseDB();
}
function Print_Menu()
{
	$mode_layer = $_GET['mode'];
	if($mode_layer == "eng" || $mode_layer == "") 
	{
		$object =  " ID Object";
		$mode_object = "Mode";
		$mode_real = "Real Time";
		$mode_history = "History Time";
		$time_start = "Start Time";
		$time_end = "End Time";
		$day = " Date ";
		$h = "Hour";
		$m = "Minute";
		$t = " Time ";
		$show = "     Show     ";
		}
	else
	{
		$object =  " �����ѵ��";
		$mode_object = "�ٻẺ ";
		$mode_real = "���Ң�й�� ";
		$mode_history = "������͹��ѧ";
		$time_start = "���������";
		$time_end = "�����ش����";
		$day = " �ѹ";
		$h = "�������";
		$m = "�ҷ�";
		$t = " ����";
		$show = "      �ʴ�     ";
	}
	$font = "style=\"color:#000066;text-align:center; font-weight:bold;\"";
	$font2 = "style=\"color:#0B5822;text-align:center; font-weight:bold;\"";
	print "<div id=\"menu\" class=\"Menu\"><form>";
	print "<table style=\"border: solid gray; border-width:2px; background-color: #FFFFCC;\" class=\"table_1\" >";
	//<tr bgcolor="#FFFFFF" background="file:///C|/AppServ/www/Map/img/rr.jpg">
	print "<tr style=\" text-align:center;\" >";
	print "	<td colspan=\"3\" style=\"font-size: 20px; color: #000066;\"> $object  <select id=\"id_car\" name=\"IDCar\" size=\"1\" >";
	init_idcar(); 
	print "</select> </td>	</tr>";
	print "	<tr><td colspan=\"3\"><hr class=\"end_line\" /></td>	</tr>";
	print "<tr style=\"color: #000066;  text-align:center;\" ><td colspan=\"3\" style=\"font-size: 20px\">$mode_object </td></tr>";
	print "<tr></tr><tr><td align=\"center\"><input id=\"real\" name=\"mode\" type=\"radio\" value=\"real\" checked=\"checked\" /></td>"; 
	print "	<td colspan=\"2\" >$mode_real </td></tr>";
	print "	<tr><td align=\"center\"><input id=\"history\" name=\"mode\" type=\"radio\" value=\"history\"/></td> <td colspan=\"2\" >$mode_history</td></tr>";
	print "<tr><td colspan=\"3\"><hr class=\"end_line\" /></td>	</tr>";
	print "	<tr style=\"color: #000066;  text-align:center;\"><td colspan=\"3\" style=\"font-size: 20px\">$time_start </td>	</tr>";
	print "<tr $font>";
	print "<td >$day</td>";
	print "	<td><input id=\"s_carlender\" name=\"s_carlender\" type=\"text\" readonly=\"true\" size=\"10\" value=\"To_Day\"/></td>";
	print "	<td><input type=\"button\" name=\"Submit1\" value=\"$day\" onclick=\"showCalendar('s_carlender','YYYY-MM-DD')\" /></td>	</tr>";
	print "<tr><td rowspan=\"2\" $font>$t</td><td><select id=\"s_hour\" name=\"s_hour\" value=\"23\">";
	print_digi(24,""); 
	print "</select></td>	<td>$h</td></tr>	<tr><td><select id=\"s_ss\" name=\"s_ss\">";
	print_digi(60,""); 
	print "</select></td><td>$m</td></tr><tr><td colspan=\"3\"><hr class=\"end_line\" /></td></tr>";
	print "	<tr  style=\"color: #000066;  text-align:center;\">	<td colspan=\"3\" style=\"font-size: 20px\">$time_end  </td></tr>";
	print "<tr $font> <td>$day</td>";
	print "	<td><input id=\"e_carlender\" name=\"e_carlender\" type=\"text\" readonly=\"true\" size=\"10\" value=\"To_Day\"/></td>";
	print "	<td><input type=\"button\" name=\"Submit2\" value=\"$day\" onclick=\"showCalendar('e_carlender','YYYY-MM-DD')\" /></td>	</tr>";
	print "	<tr><td rowspan=\"2\" $font>$t</td><td><select id=\"e_hour\" name=\"e_hour\">";
	print_digi(24,"not");  
	print "</select></td>	<td>$h</td> </tr>";
	print "<tr><td><select id=\"e_ss\" name=\"e_ss\">";
	print_digi(60,"not"); 
	print "</select></td>	<td>$m</td></tr>";
	print "<tr><td colspan=\"3\"><hr class=\"end_line\" /></td>	</tr>";
	print "<tr align=\"center\"><td colspan=\"3\"> <input id=\"showcar\" type=\"button\" value=\" $show \" onclick=\"Get(0);\" /></td></tr>";
	print "</table></form></div>";
}

?>