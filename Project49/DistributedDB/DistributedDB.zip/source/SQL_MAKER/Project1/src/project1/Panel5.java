package project1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;


public class Panel5 extends JPanel {
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JButton jButton1 = new JButton();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private CreateConnection conn = null;
    private Fragment frag;
    private boolean namepass;
    private boolean ischecked = false;
    private Vector dblink;

    public Panel5() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {

        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        jLabel1.setText("Global Name Configuration");
        jLabel1.setBounds(new Rectangle(75, 15, 320, 15));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jLabel2.setText("Table Name :");
        jLabel2.setBounds(new Rectangle(75, 60, 80, 15));
        jTextField1.setBounds(new Rectangle(150, 55, 175, 20));

        jTextField1.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        jTextField1_keyTyped(e);
                    }
                });
        jButton1.setText("Check Available");
        jButton1.setBounds(new Rectangle(355, 55, 130, 20));
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jLabel3.setText("Column :");
        jLabel3.setBounds(new Rectangle(75, 135, 90, 15));

        jLabel4.setText("Available");
        jLabel4.setBounds(new Rectangle(150, 95, 555, 15));
        this.add(jLabel4, null);

        this.add(jLabel3, null);
        this.add(jButton1, null);
        this.add(jTextField1, null);
        this.add(jLabel2, null);
        this.add(jLabel1, null);
        jLabel4.setVisible(false);
        namepass = false;
    }
    
    // Set Connection 
    public void setConn(CreateConnection newconn) {
        this.conn = newconn;
    }

    // Set Fragment for set Global Name
    public void setData(Fragment F) {
        this.frag = F;
        Vector s[] = new Vector[2];
        s = frag.getAllCol();
        //System.out.println(s);
        Vector data = new Vector();
        Vector header = new Vector();
        for (int i = 0; i < s[0].size(); i++) {
            Vector row = new Vector();
            row.add(s[0].elementAt(i));
            row.add(s[1].elementAt(i));
            data.add(row);
        }
        header.add("Column Name");
        header.add("Data Type");
        JTable table = new JTable(data, header);
        JScrollPane scrollpane = new JScrollPane(table);

        scrollpane.setBounds(new Rectangle(115, 170, 590, 290));
        this.add(scrollpane, null);
    }

    // Return Global that set Name complete
    public Fragment getGlobalFrag() {
        return frag;
    }

    // Return All DB Link
    public Vector getAllDB() {
        return dblink;
    }

    // Check Panel Valid
    public boolean isValidName() {

        if (namepass && ischecked) {
            frag.setName(jTextField1.getText());
            return true;
        } else if (!ischecked) {
            //jButton1.doClick();
            checkName();
            if (namepass) {
                frag.setName(jTextField1.getText());
                return true;
            } else
                return false;
        } else {

            return false;
        }
    }

    // Check Global For Not Exist in Any Table or view
    public void checkName() {


        if (jTextField1.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please Insert Table Name", 
                                          "Error", 0);
            namepass = false;
            return;
        }
        namepass = true;
        dblink = new Vector();
        dblink.addElement(conn.getSid().toUpperCase() + "." + 
                          conn.getHostname().toUpperCase());
        try {
            ResultSet result = 
                conn.CreateStatement("select * from all_db_links");
            while (result.next()) {
                dblink.addElement(result.getString(2).toUpperCase());
            }
        } catch (SQLException f) {
            System.out.println("Error Can't get data");
        }

        for (int i = 0; i < dblink.size(); i++) {

            try {
                ResultSet result2;
                result2 = 
                        conn.CreateStatement("select TABLE_NAME from USER_TABLES@" + 
                                             dblink.elementAt(i) + 
                                             " WHERE TABLE_NAME = '" + 
                                             jTextField1.getText().toUpperCase() + 
                                             "'");

                if (result2 != null && result2.next()) {
                    jLabel4.setForeground(Color.RED);
                    jLabel4.setText("This Name Not Available @ " + 
                                    dblink.elementAt(i));
                    namepass = false;
                    break;
                } else {
                    ResultSet result3;
                    result3 = 
                            conn.CreateStatement("select VIEW_NAME from USER_VIEWS@" + 
                                                 dblink.elementAt(i) + 
                                                 " WHERE VIEW_NAME = '" + 
                                                 jTextField1.getText().toUpperCase() + 
                                                 "'");

                    if (result3 != null && result3.next()) {
                        jLabel4.setForeground(Color.RED);
                        jLabel4.setText("This Name Not Available @ " + 
                                        dblink.elementAt(i) + "(VIEW)");
                        namepass = false;
                        break;
                    } else {
                        jLabel4.setForeground(Color.GREEN);
                        jLabel4.setText(" Available ");
                    }
                }


            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, 
                                              f.getMessage() + "@ " + dblink.elementAt(i));

            }

        }
        jLabel4.setVisible(true);
        ischecked = true;
    }

    private void jTextField1_keyTyped(KeyEvent e) {
        ischecked = false;
    }
    
    private void jButton1_actionPerformed(ActionEvent e) {
        checkName();

    }
}
