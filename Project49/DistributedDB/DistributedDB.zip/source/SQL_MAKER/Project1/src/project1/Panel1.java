package project1;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Panel1 extends JPanel {
    private JLabel jLabel1 = new JLabel();


    private JPasswordField jPasswordField1 = new JPasswordField();
    private JTextField jTextField5 = new JTextField();
    private JLabel jLabel6 = new JLabel();
    private JTextField jTextField4 = new JTextField();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JTextField jTextField3 = new JTextField();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JTextField jTextField1 = new JTextField();

    public String[] getData() {
        String[] output = new String[5];
        output[0] = new String(jTextField3.getText());
        output[1] = new String(jTextField4.getText());
        output[2] = new String(jTextField5.getText());
        output[3] = new String(jTextField1.getText());
        output[4] = new String(jPasswordField1.getPassword());

        return output;
    }

    public Panel1() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        jPasswordField1.setBounds(new Rectangle(265, 305, 175, 20));
        jPasswordField1.addKeyListener(new KeyAdapter() {
                    public void keyPressed(KeyEvent e) {
                        jPasswordField1_keyPressed(e);
                    }
                });
        jTextField5.setBounds(new Rectangle(395, 165, 45, 20));
        jTextField5.setText("1521");
        jLabel6.setText("Port  :");
        jLabel6.setBounds(new Rectangle(350, 170, 30, 14));
        jTextField4.setBounds(new Rectangle(245, 165, 55, 20));
        jTextField4.setText("orcl");
        jLabel5.setText("SID  :");
        jLabel5.setBounds(new Rectangle(195, 170, 27, 14));
        jLabel4.setText("Host  :");
        jLabel4.setBounds(new Rectangle(195, 125, 32, 14));
        jTextField3.setBounds(new Rectangle(245, 120, 195, 20));
        jTextField3.setText("ungrad15.ce.kmitl.ac.th");
        jLabel3.setText("Database  :");
        jLabel3.setBounds(new Rectangle(195, 75, 56, 14));
        jLabel2.setText("Password  :");
        jLabel2.setBounds(new Rectangle(195, 305, 56, 14));
        jLabel1.setText("Username  :");
        jLabel1.setBounds(new Rectangle(195, 260, 58, 14));
        jTextField1.setBounds(new Rectangle(265, 255, 175, 20));

        this.add(jPasswordField1, null);
        this.add(jTextField5, null);
        this.add(jTextField4, null);
        this.add(jTextField3, null);
        this.add(jTextField1, null);
        this.add(jLabel1, null);
        this.add(jLabel2, null);
        this.add(jLabel3, null);
        this.add(jLabel4, null);
        this.add(jLabel5, null);
        this.add(jLabel6, null);

    }

    // Check if Enter in Password Field Fire Login Button
    private void jPasswordField1_keyPressed(KeyEvent e) {
        if (e.getKeyCode() == 10) {
            ((Panel3)this.getParent()).login();
        }
    }
}
