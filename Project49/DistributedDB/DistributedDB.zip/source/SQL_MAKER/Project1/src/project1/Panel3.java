package project1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.net.URL;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;

import oracle.jdbc.OracleDriver;


public class Panel3 extends JPanel {
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();

    private Panel1 newLoginPane = new Panel1();
    
    private Panel2 menu = new Panel2();
   
    private JButton jButton3 = new JButton();
    private JLabel jLabel7 = new JLabel();
    private JSeparator jSeparator1 = new JSeparator();
    public static CreateConnection conn = null;
    private Fragment globalFrag;
    private FKcreate createFK = new FKcreate();
    private CreateFragment newFragment = new CreateFragment();
    private CreateGlobalFK createFKglobal = new CreateGlobalFK();
    private Panel4 setFragment = new Panel4();
    private Panel5 setGlobalName = new Panel5();
    private Panel6 lastPanel = new Panel6();
    private JLabel jLabel1 = new JLabel();
    private ImageIcon kmitlLogo ;
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();

    public Panel3() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(null);
        this.setSize(new Dimension(795, 572));

        jButton1.setText("< Back");
        jButton1.setBounds(new Rectangle(560, 510, 73, 22));
        jButton1.setVisible(false);
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jButton2.setText("Next >");
        jButton2.setBounds(new Rectangle(660, 510, 73, 22));
        jButton2.setVisible(false);
        jButton2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton2_actionPerformed(e);
                    }
                });
        jButton3.setText("Login");
        jButton3.setBounds(new Rectangle(640, 510, 75, 20));
        jButton3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton3_actionPerformed(e);
                    }
                });
        jLabel7.setText("Error !!! Can't connect database Please try again");
        jLabel7.setBounds(new Rectangle(375, 510, 236, 14));
        jLabel7.setForeground(Color.red);
        jLabel7.setVisible(false);
        jSeparator1.setBounds(new Rectangle(50, 500, 695, 2));
        jLabel1.setBounds(new Rectangle(50, 505, 60, 60));
        this.add(jLabel3, null);
        this.add(jLabel2, null);
        this.add(jLabel1, null);
        this.add(jLabel7, null);
        this.add(jSeparator1, null);
        this.add(newLoginPane, null);
        this.add(jButton2, null);
        this.add(jButton1, null);
        this.add(jButton3, null);
        kmitlLogo = new ImageIcon((URL)getResource("KMITL_logo.png"));
        jLabel1.setIcon(kmitlLogo);
        jLabel2.setText("Department of Computer Engineering ");
        jLabel2.setBounds(new Rectangle(130, 520, 240, 15));
        jLabel2.setFont(new Font("Tahoma", 0, 9));
        jLabel3.setText("Faculty of Engineering King Mongkut's Institute of Technology ");
        jLabel3.setBounds(new Rectangle(130, 540, 380, 15));
        jLabel3.setFont(new Font("Tahoma", 0, 9));
    }

    // Login Button
    private void jButton3_actionPerformed(ActionEvent e) {
        login();
    }

    // Login ( Create Connection to DB )
    public void login() {
        try {
            // Load Oracle driver
            DriverManager.registerDriver(new OracleDriver());
            //String[] input = loginPane.getData();
            String[] input = newLoginPane.getData();
            String hostname = new String(input[0]);
            String sid = new String(input[1]);
            String port = new String(input[2]);
            String user = new String(input[3]);
            String pass = new String(input[4]);

            conn = new CreateConnection(hostname, port, sid, user, pass);

            if (conn.Create()) { //newFragment = new CreateFragment();
                jLabel7.setVisible(false);
                //newFragment.setConn(conn);
                //newFragment.setup();
                this.remove(newLoginPane);
                //this.add(newFragment,null);
                this.add(menu, null);
                jButton3.setVisible(false);
                jButton1.setVisible(true);
                jButton2.setText("Exit");
                jButton2.setVisible(true);
                this.repaint();
                // Panel1 p1 = new Panel1();
                return;
            } else {
                jLabel7.setVisible(true);
            }

        } catch (SQLException ex) {
            //ex.printStackTrace();
            jLabel7.setVisible(true);
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", 0);

            System.out.println(ex.getMessage());
        }

    }
    
    // Menu --> Create Global
    public void createglobal() {

        try {
            if (conn.Create()) {
                newFragment = new CreateFragment();
                jLabel7.setVisible(false);
                newFragment.setConn(conn);
                newFragment.setup();
                this.remove(menu);
                this.add(newFragment, null);
                jButton2.setText("Next >");
                jButton3.setVisible(false);
                jButton1.setVisible(true);
                jButton2.setVisible(true);
                this.repaint();
                // Panel1 p1 = new Panel1();
                return;
            } else {
                jLabel7.setVisible(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", 0);
        }
    }
    
    // Menu --> Create FK
    public void createFK() {

        createFK.setConn(conn);
        createFK.setData();
      
        jButton2.setText("Next >");
        jButton3.setVisible(false);
        jButton1.setVisible(true);
        jButton2.setVisible(true);
        this.remove(menu);
        this.add(createFK, null);
        this.validate();
        this.repaint();
        

      
    }

    // Next Button
    private void jButton2_actionPerformed(ActionEvent e) {
        if (newFragment.isShowing()) {
            if (newFragment.isValid()) {
                setFragment.setConn(conn);
                globalFrag = (Fragment)newFragment.getAllFragment();
                if (globalFrag.getHrCount() > 0) {
                    setFragment.addData(globalFrag);

                    this.remove(newFragment);
                    this.add(setFragment, null);
                    this.validate();

                    this.repaint();
                } else {
                    setGlobalName.setData(globalFrag);
                    setGlobalName.setConn(conn);
                    this.remove(newFragment);
                    this.add(setGlobalName, null);
                    this.validate();
                    this.repaint();
                }

            } else {
                JOptionPane.showMessageDialog(this, 
                                              "Error !! All Fragment must Contains at least 2 tables", 
                                              "Error", 0);

            }
        } else if (setFragment.isShowing()) {
            if (setFragment.isDataValid()) {

                setGlobalName.setData(globalFrag);
                setGlobalName.setConn(conn);
                this.remove(setFragment);
                this.add(setGlobalName, null);

                this.repaint();
            } else {
                JOptionPane.showMessageDialog(this, 
                                              "Please Set all Condition of Horizontal Table", 
                                              "Error", 0);
                System.out.println("Please Set all Condition of Horizontal Table");
            }
        } else if (setGlobalName.isShowing()) {
            if (setGlobalName.isValidName()) {
                globalFrag = setGlobalName.getGlobalFrag();
                createFKglobal.setConn(conn);
                createFKglobal.setData(globalFrag);
                this.remove(setGlobalName);
                this.add(createFKglobal, null);              
                this.validate();
                this.repaint();
            }
        } 
        else if (createFKglobal.isShowing()) {
            jButton2.setText("Finish");
            globalFrag = createFKglobal.getGlobalFrag();
            Vector command = createFKglobal.getCommand();
            Vector commandBefore = createFKglobal.getCommandAddColumn();
            lastPanel.setConn(conn);
            lastPanel.setData(globalFrag, setGlobalName.getAllDB());
            lastPanel.setInitCommand(commandBefore,command);
            this.remove(createFKglobal);
            this.add(lastPanel, null);
            this.validate();
            this.repaint();
            
        }else if (createFK.isShowing()) {
            jButton2.setText("Finish");
            lastPanel.setConn(conn);
            lastPanel.setData(createFK.getCommand());
            this.remove(createFK);
            this.add(lastPanel, null);
            this.validate();
            this.repaint();
        }
        else if (lastPanel.isShowing()) {
            globalFrag = new Fragment();
            createFK = new FKcreate();
            newFragment = new CreateFragment();
            createFKglobal = new CreateGlobalFK();
            setFragment = new Panel4();
            setGlobalName = new Panel5();
            
            jButton2.setText("Next >");
            jButton3.setVisible(false);
            jButton2.setVisible(true);
            jButton1.setVisible(true);
            jLabel7.setVisible(false);
            this.remove(lastPanel);
            this.add(menu, null);
            lastPanel = new Panel6();
            //this.validate();
            this.repaint();

        }
        else if (menu.isShowing()) {
            System.exit(0);
        }
           
    }
        
    
    // Back Button
    private void jButton1_actionPerformed(ActionEvent e) {
        if (menu.isShowing()) {
            jButton2.setText("Next >");
            jButton3.setVisible(true);
            jButton1.setVisible(false);
            jButton2.setVisible(false);
            this.remove(menu);
            this.add(newLoginPane, null);
            try {
                conn.CloseConnection();
            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

                System.out.println(f);
            }
            this.validate();
            this.repaint();
        } else if (newFragment.isShowing()) {
            //jLabel7.setVisible(false);
            //newFragment.setConn(conn);
            //newFragment.genDBHost();
            this.remove(newFragment);
            //this.add(newLoginPane,null);
            this.add(menu, null);

            jButton2.setText("Exit");
            jButton3.setVisible(false);
            jButton1.setVisible(true);
            jButton2.setVisible(true);
            this.validate();
            this.repaint();
        } else if (setFragment.isShowing()) {
            this.remove(setFragment);
            this.add(newFragment, null);
            this.validate();
            this.repaint();
        } else if (setGlobalName.isShowing()) {
            jButton2.setText("Next >");
            if (globalFrag.getHrCount() > 0){
                setFragment.addData(globalFrag);
                this.remove(setGlobalName);
                this.add(setFragment, null);
            }else{
                this.remove(setGlobalName);
                this.add(newFragment, null);
            }
            
           
            this.validate();
            this.repaint();
        } else if (lastPanel.isShowing()) {
            if (lastPanel.getCaller().equals("Panel5")) {
                globalFrag = setGlobalName.getGlobalFrag();
                jButton2.setText("Next >");
                createFKglobal.setConn(conn);
                createFKglobal.setData(globalFrag);

                this.remove(lastPanel);
                this.add(createFKglobal, null);
               // this.repaint();
            }
            else {
                jButton2.setText("Next >");
                createFK.setConn(conn);
                createFK.setData();
                this.remove(lastPanel);
                this.add(createFK, null);

            }
            this.validate();
            this.repaint();
        } else if (createFK.isShowing()) {
            this.remove(createFK);
            //this.add(newLoginPane,null);
            this.add(menu, null);

            jButton2.setText("Exit");
            jButton3.setVisible(false);
            jButton1.setVisible(true);
            jButton2.setVisible(true);
            this.validate();
            this.repaint();
        } else if (createFKglobal.isShowing()) {
            setGlobalName.setData(globalFrag);
            setGlobalName.setConn(conn);
            this.remove(createFKglobal);
            this.add(setGlobalName, null);
            this.validate();
            this.repaint();

        }
    }
    
    // Get Icon Picture 
    private Object getResource(String key) {

        URL url = null;
        String name = key;

        if (name != null) {

            try {
                Class c = Class.forName("project1.Panel3");
                url = c.getResource(name);
            } catch (ClassNotFoundException cnfe) {
                System.err.println(cnfe);
            }
            return url;
        } else
            return null;

    }
}
