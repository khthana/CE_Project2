package project1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

public class CreateGlobalFK extends JPanel {
    private JLabel jLabel1 = new JLabel();
    private JComboBox jComboBox1 = new JComboBox();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JComboBox jComboBox2 = new JComboBox();
    private JLabel jLabel4 = new JLabel();
    private JComboBox jComboBox3 = new JComboBox();
    private JTextField jTextField1 = new JTextField();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JComboBox jComboBox4 = new JComboBox();
    private JComboBox jComboBox5 = new JComboBox();
    private JComboBox jComboBox6 = new JComboBox();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JSeparator jSeparator1 = new JSeparator();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel12 = new JLabel();
    private JComboBox jComboBox7 = new JComboBox();
    private JComboBox jComboBox8 = new JComboBox();
    private JButton jButton1 = new JButton();
    private CreateConnection conn = null;
    private Vector allCommand= new Vector();;
    private Vector commandSite= new Vector();;
    private Vector colName;
    private Vector colType;
    private Fragment globalFrag;
    private boolean isUpdateCaseCade = false;
    private Vector commandCreate = new Vector();
    private Vector commandSite2 = new Vector();
    private Vector colAdded = new Vector();
    private JLabel jLabel13 = new JLabel();

    public CreateGlobalFK() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        jLabel1.setText("Foreign Key Create");
        jLabel1.setBounds(new Rectangle(75, 15, 345, 15));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jComboBox1.setBounds(new Rectangle(115, 90, 215, 20));

        jComboBox1.setEnabled(false);
        jLabel2.setText("Site :");
        jLabel2.setBounds(new Rectangle(70, 90, 45, 15));
        jLabel3.setText("Table :");
        jLabel3.setBounds(new Rectangle(70, 140, 34, 14));
        jComboBox2.setBounds(new Rectangle(135, 140, 195, 20));

        jComboBox2.setEnabled(false);
        jLabel4.setText("Column :");
        jLabel4.setBounds(new Rectangle(70, 190, 75, 15));
        jComboBox3.setBounds(new Rectangle(135, 190, 195, 20));

        jComboBox3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox3_actionPerformed(e);
                    }
                });
        jTextField1.setBounds(new Rectangle(135, 240, 145, 20));
        jTextField1.setEditable(false);
        jLabel5.setText("Data Type :");
        jLabel5.setBounds(new Rectangle(70, 240, 110, 15));
        jLabel6.setText("Site :");
        jLabel6.setBounds(new Rectangle(465, 90, 45, 15));
        jLabel7.setText("Table :");
        jLabel7.setBounds(new Rectangle(465, 140, 35, 15));
        jLabel8.setText("Column :");
        jLabel8.setBounds(new Rectangle(465, 190, 75, 15));
        jComboBox4.setBounds(new Rectangle(515, 90, 215, 20));

        jComboBox4.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox4_actionPerformed(e);
                    }
                });
        jComboBox5.setBounds(new Rectangle(535, 140, 195, 20));

        jComboBox5.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox5_actionPerformed(e);
                    }
                });
        jComboBox6.setBounds(new Rectangle(535, 190, 195, 20));
        jLabel9.setText("Child Table");
        jLabel9.setBounds(new Rectangle(75, 55, 130, 15));
        jLabel9.setFont(new Font("Tahoma", 1, 12));
        jLabel10.setText("Parent Table");
        jLabel10.setBounds(new Rectangle(470, 55, 130, 15));
        jLabel10.setFont(new Font("Tahoma", 1, 12));
        jSeparator1.setBounds(new Rectangle(70, 290, 660, 2));
        jLabel11.setText("Update Type :");
        jLabel11.setBounds(new Rectangle(240, 330, 95, 15));
        jLabel12.setText("Delete Type :");
        jLabel12.setBounds(new Rectangle(240, 380, 95, 15));
        jComboBox7.setBounds(new Rectangle(330, 330, 145, 20));
        jComboBox8.setBounds(new Rectangle(330, 375, 145, 20));
        jButton1.setText("Add");
        jButton1.setBounds(new Rectangle(400, 430, 73, 22));

        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jLabel13.setText("");
        jLabel13.setBounds(new Rectangle(490, 435, 245, 15));
        this.add(jLabel13, null);
        this.add(jButton1, null);
        this.add(jComboBox8, null);
        this.add(jComboBox7, null);
        this.add(jLabel12, null);
        this.add(jLabel11, null);
        this.add(jSeparator1, null);
        this.add(jLabel10, null);
        this.add(jLabel9, null);
        this.add(jComboBox6, null);
        this.add(jComboBox5, null);
        this.add(jComboBox4, null);
        this.add(jLabel8, null);
        this.add(jLabel7, null);
        this.add(jLabel6, null);
        this.add(jLabel5, null);
        this.add(jTextField1, null);
        this.add(jComboBox3, null);
        this.add(jLabel4, null);
        this.add(jComboBox2, null);
        this.add(jLabel3, null);
        this.add(jLabel2, null);
        this.add(jComboBox1, null);
        this.add(jLabel1, null);
        jComboBox7.addItem("Restrict");
        jComboBox7.addItem("Cascade");
        jComboBox7.addItem("Set Null");
        jComboBox8.addItem("Restrict");
        jComboBox8.addItem("Cascade");
        jComboBox8.addItem("Set Null");
    }
    
    //Set DB Connection
    public void setConn(CreateConnection newconn) {
        this.conn = newconn;
    }
    
    // Init data
    public void setData(Fragment globalFrag) {
        jComboBox1.removeAllItems();
        jComboBox2.removeAllItems();
        jComboBox3.removeAllItems();
        jComboBox4.removeAllItems();
        jComboBox5.removeAllItems();
        jComboBox6.removeAllItems();
        jComboBox1.addItem("Global");
        jComboBox2.addItem(globalFrag.getName());
        colName = globalFrag.getAllCol()[0];
        colType = globalFrag.getAllCol()[1]; 
        this.globalFrag = globalFrag;
        for (int i = 0;i < colName.size();i++){
            jComboBox3.addItem(colName.elementAt(i));
        }
        
        // Add dblink to combobox
        try {
        ResultSet result = 
            conn.CreateStatement("select * from all_db_links");
            jComboBox1.addItem(conn.getSid().toUpperCase() + "." + 
                               conn.getHostname().toUpperCase());
            jComboBox4.addItem(conn.getSid().toUpperCase() + "." + 
                               conn.getHostname().toUpperCase());
            while (result.next()) {
                jComboBox4.addItem(result.getString(2).toUpperCase());
            }
        } catch (SQLException f) {
            JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 0);

            System.out.println("Error Can't get data");
        }
        colAdded = new Vector();
        jLabel13.setText("");
        
        commandCreate = new Vector();
        commandSite2 = new Vector();
        allCommand = new Vector();
        commandSite = new Vector();
    }

    private void jComboBox3_actionPerformed(ActionEvent e) {
        if (jComboBox3.getSelectedItem() != null) {
            jTextField1.setText(colType.elementAt(jComboBox3.getSelectedIndex()).toString());
            
         
            if (conn != null && jComboBox5.getSelectedItem() != null && 
                e.getActionCommand() == "comboBoxChanged" && jComboBox4.getSelectedItem() != null) {
                jComboBox6.removeAllItems();
                try {
                    ResultSet result = 
                            conn.CreateStatement("select COLUMN_NAME from USER_TAB_COLUMNS@" + 
                                                 jComboBox4.getSelectedItem() + 
                                                 " WHERE TABLE_NAME = '" + 
                                                 jComboBox5.getSelectedItem() + 
                                                 "' AND DATA_TYPE = '" + jTextField1.getText() + "'");
                    while (result.next()) {

                        jComboBox6.addItem(result.getString(1).toUpperCase());
                       
                    }

                 
                } catch (SQLException f) {
                    JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                                  0);

                }

            }
        }
        
        
    }

    private void jComboBox4_actionPerformed(ActionEvent e) {
        if (conn != null && e.getActionCommand() == "comboBoxChanged" && 
            jComboBox4.getItemCount() != 0) {
            jComboBox5.removeAllItems();
           

            try {
                ResultSet result = 
                    conn.CreateStatement("select TABLE_NAME from USER_TABLES@" + 
                                         jComboBox4.getSelectedItem());
            
                while (result.next()) {

                    jComboBox5.addItem(result.getString(1).toUpperCase());
                   
                }
            } catch (SQLException f) {
                
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

                System.out.println(f.getMessage());
            }

        }
    }

    private void jComboBox5_actionPerformed(ActionEvent e) {
        if (conn != null && jComboBox5.getSelectedItem() != null && 
            e.getActionCommand() == "comboBoxChanged" && jComboBox4.getSelectedItem() != null) {
            jComboBox6.removeAllItems();
            ResultSet result;
            try {
                result = 
                        conn.CreateStatement("select COLUMN_NAME from USER_TAB_COLUMNS@" + 
                                             jComboBox4.getSelectedItem() + 
                                             " WHERE TABLE_NAME = '" + 
                                             jComboBox5.getSelectedItem() + 
                                             "' AND DATA_TYPE = '" + jTextField1.getText() + "'");
                while (result.next()) {

                    jComboBox6.addItem(result.getString(1).toUpperCase());
                   
                }

             
            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

            }

        }
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        String nw = "\n";
        boolean exists = false;
        
        // Create Trigger For Child Table
        String csite = conn.getDB();
        String psite = jComboBox4.getSelectedItem().toString();
        String ctable = jComboBox2.getSelectedItem().toString();
        String ptable = jComboBox5.getSelectedItem().toString();
        String ccol = jComboBox3.getSelectedItem().toString();
        String pcol = jComboBox6.getSelectedItem().toString();
        String type = jTextField1.getText();
        for (int i = 0 ; i < colAdded.size(); i ++) {
            if (colAdded.elementAt(i).toString().equals(ccol + "." + ctable + "." + csite)) {
                exists = true;
                jLabel13.setForeground(Color.red);
                jLabel13.setText("This Column has already setup");
                break;
            }
        }
        
        if (!exists){
            jLabel13.setForeground(Color.green);
            jLabel13.setText("Added");
            colAdded.add(ccol + "." + ctable + "." + csite);
            addColUpdateID(globalFrag);
            String str2 = "";
            createCheckFK(globalFrag);
            //UPDATE
            if (jComboBox7.getSelectedIndex() == 0){ // Restrict
             str2 += "CREATE OR REPLACE TRIGGER " + ptable + "_" + ctable + "_UPDATE_RESTRICT"   + " BEFORE UPDATE OF " + pcol + " ON " + ptable +"\n" ;
             str2 += "FOR EACH ROW \n"  ;
             str2 += "DECLARE";
             str2 += " Dummy    "+ type + ";\n" ;
             str2 += " present     EXCEPTION;\n" ; 
             str2 += " not_present EXCEPTION;\n";
             str2 += " CURSOR Dummy_cursor (Dn " + type + ") IS\n" ;
             str2 += "  SELECT " + ccol + " FROM " + ctable + "@" + csite + " WHERE " + ccol + " = Dn;\n";
             str2 += "BEGIN";
             str2 += " OPEN Dummy_cursor (:old." + pcol + ");\n" ;
             str2 += " FETCH Dummy_cursor INTO Dummy;";
             str2 += " IF Dummy_cursor%FOUND THEN\n" ;
             str2 += "  RAISE present;  \n" ;
             str2 += " ELSE\n" ;
             str2 += "  RAISE not_present; \n"; 
             str2 += " END IF;\n" ;
             str2 += "  CLOSE Dummy_cursor;";
             str2 += "EXCEPTION\n" ;
             str2 += " WHEN present THEN\n" ; 
             str2 += "  CLOSE Dummy_cursor;\n"; 
             str2 += "  Raise_application_error(-20001, ' || ''' FK Present in" ;
             str2 += "  "+  ctable + "@" + csite +" ''' || ');\n" ; 
             str2 += " WHEN not_present THEN\n" ;
             str2 += "  CLOSE Dummy_cursor;\n"; 
             str2 += "END;";
                allCommand.add(str2);
                commandSite.add(psite);
            }else if (jComboBox7.getSelectedIndex() == 1) { // Cascade
              

                str2 = "";     
                str2 += "CREATE SEQUENCE " + ptable + "_" + ctable +"_Update_sequence\n" ; 
                str2 += "INCREMENT BY 1 MAXVALUE 5000\n" ; 
                str2 += "CYCLE\n" ; 
                allCommand.add(str2);
                commandSite.add(psite);
                
                str2 = "";     
                str2 += "CREATE OR REPLACE PACKAGE " + ptable + "_UpdateIntegritypackage AS\n" + 
                "   Updateseq NUMBER;\n" + 
                "END " + ptable + "_UpdateIntegritypackage;";
                allCommand.add(str2);
                commandSite.add(psite);
                
                str2 = "";     
                str2 += "CREATE OR REPLACE TRIGGER " + ptable + "_" + ctable + "_UPDATE_CASCADE1 "   + " BEFORE UPDATE OF " + pcol + " ON " + ptable +"\n" ;
                str2 += "DECLARE\n" ; 
                str2 += " Dummy " +  type +";" ;
                str2 += "BEGIN\n" ; 
                str2 += " SELECT " +ptable + "_" + ctable +"_Update_sequence.NEXTVAL\n" ; 
                str2 += "  INTO Dummy\n" ; 
                str2 += "  FROM dual;\n" ; 
                str2 += "   " + ptable + "_UpdateIntegritypackage.Updateseq := Dummy;\n" ; 
                str2 += "END;"  ;
                allCommand.add(str2);
                commandSite.add(psite);
                
                str2 = "";            
                str2 += "CREATE OR REPLACE TRIGGER " + ptable + "_" + ctable + "_UPDATE_CASCADE2 "   + " BEFORE UPDATE OF " + pcol + " ON " + ptable +"\n" ;
                str2 += "FOR EACH ROW \n"  ;
                //str2 += "REFERENCING " + ctable + "@" + csite +" AS CHILD_TAB \n";
                str2 += "BEGIN\n" ; 
                str2 += " IF UPDATING THEN\n" ; 
                str2 += "  UPDATE " + ctable + "@" + csite +"\n"; 
                str2 += "     SET " + ccol + " = :new." + pcol + ",\n" ; 
                str2 += "    Update_id = " + ptable + "_UpdateIntegritypackage.Updateseq   --from 1st\n" ; 
                str2 += "    WHERE " + ccol + " = :old." + pcol + "\n" ; 
                str2 += "    AND Update_id IS NULL;\n" ;
                str2 += " END IF;\n";
                str2 += "END;"  ;
                allCommand.add(str2);
                commandSite.add(psite);
                
                str2 = "";     
                str2 += "CREATE OR REPLACE TRIGGER " + ptable + "_" + ctable + "_UPDATE_CASCADE3 "   ;
                str2 += "AFTER UPDATE OF " + pcol + " ON " + ptable +"\n" ;
                //str2 += "REFERENCING " + ctable + "@" + csite +" AS CHILD_TAB \n";
                str2 += "BEGIN  UPDATE  " + ctable + "@" + csite +"\n"; 
                str2 += " SET Update_id = NULL\n" ; 
                str2 += "  WHERE  Update_id = " + ptable + "_UpdateIntegritypackage.Updateseq;   --from 1st\n" ; 
                str2 += "END;";
                allCommand.add(str2);
                commandSite.add(psite);
            
            }else{ // Set NULL
                str2 += "CREATE OR REPLACE TRIGGER "+ ptable + "_" + ctable + "_UPDATE_SETNULL\n";
                str2 += "AFTER UPDATE OF " + pcol + " ON " + ptable +"\n" ;
                str2 += "FOR EACH ROW\n" ; 

                str2 += "BEGIN\n" ; 
                str2 += "   IF UPDATING AND :OLD." + pcol +" != :NEW." + pcol +" THEN\n" ; 
                str2 += "      UPDATE " + ctable + "@" + csite +" SET " + ccol + " = NULL\n" ; 
                str2 += "         WHERE " + ccol + " = :old." + pcol + ";\n" ; 
                str2 += "   END IF;\n" ; 
                str2 += "END;"  ; 
                allCommand.add(str2);
                commandSite.add(psite);
            }
            
            
            
            String str3 = "";
             //DEL
             if (jComboBox8.getSelectedIndex() == 0){// Restrict
             
                  str3 += "CREATE OR REPLACE TRIGGER " + ptable + "_" + ctable + "_DEL_RESTRICT"   + " BEFORE DELETE ON " + ptable +"\n" ;
                  str3 += "FOR EACH ROW \n"  ;
                  str3 += "DECLARE";
                  str3 += " Dummy    "+ type + ";\n" ;
                  str3 += " present     EXCEPTION;\n" ; 
                  str3 += " not_present EXCEPTION;\n";
                  str3 += " CURSOR Dummy_cursor (Dn " + type + ") IS\n" ;
                  str3 += "  SELECT " + ccol + " FROM " + ctable + "@" + csite + " WHERE " + ccol + " = Dn;\n";
                  str3 += "BEGIN";
                  str3 += " OPEN Dummy_cursor (:old." + pcol + ");\n" ;
                  str3 += " FETCH Dummy_cursor INTO Dummy\n;";
                  str3 += " IF Dummy_cursor%FOUND THEN\n" ;
                  str3 += "  RAISE present;  \n" ;
                  str3 += " ELSE\n" ;
                  str3 += "  RAISE not_present; \n"; 
                  str3 += " END IF;\n" ;
                  str3 += "  CLOSE Dummy_cursor;";
                  str3 += "EXCEPTION\n" ;
                  str3 += " WHEN present THEN\n" ; 
                  str3 += "  CLOSE Dummy_cursor;\n"; 
                  str3 += "  Raise_application_error(-20001, ' || '''FK Present in" ;
                  str3 += "  "+  ctable + "@" + csite +" ''' || ');\n" ; 
                  str3 += " WHEN not_present THEN\n" ;
                  str3 += "  CLOSE Dummy_cursor;\n"; 
                  str3 += "END;";
                  allCommand.add(str3);
                  commandSite.add(psite);
             }else if (jComboBox8.getSelectedIndex() == 1) { // Cascade
                 str3 += "CREATE OR REPLACE TRIGGER "+ ptable + "_" + ctable + "_DEL__CASCADE \n";
                 str3 += "AFTER DELETE ON " + ptable +"\n" ; 
                 str3 += "FOR EACH ROW \n" ;
                 str3 += "BEGIN\n" ; 
                 str3 += "DELETE FROM " + ctable + "@" + csite +"\n";
                 str3 += "WHERE " +ctable + "." + ccol + " = :old." + pcol + ";\n" ; 
                 str3 += "END;";
                 allCommand.add(str3);
                 commandSite.add(psite);
             }else{ // Set NULL
                  str3 += "CREATE OR REPLACE TRIGGER "+ ptable + "_" + ctable + "_DEL_SETNULL\n";
                  str3 += "AFTER DELETE ON " + ptable +"\n" ;
                  str3 += "FOR EACH ROW\n" ; 
            
                  str3 += "BEGIN\n" ; 
                  str3 += "   IF DELETING THEN\n" ; 
                  str3 += "      UPDATE " + ctable + "@" + csite +" SET " + ccol + " = NULL\n" ; 
                  str3 += "         WHERE " +ctable + "." + ccol + " = :old." + pcol + ";\n" ; 
                  str3 += "   END IF;\n" ; 
                  str3 += "END;"  ; 
                 allCommand.add(str3);
                 commandSite.add(psite);
             }
        }
       
    }
    
    // Add Comlumn "Update_id" for Update Cascade
    public void addColUpdateID(Fragment input){
        Vector allTable = input.getTable();
        for (int i =0 ; i < allTable.size();i++){
            if (allTable.elementAt(i) instanceof Fragment) {
                if (!((Fragment)allTable.elementAt(i)).hasCol(jComboBox3.getSelectedItem().toString())) {
                     addColUpdateID((Fragment)allTable.elementAt(i));
                }
            }else{
                if (!((Table)allTable.elementAt(i)).hasCol("UPDATE_ID")){
                    String str2 = "";     
                    str2 += "ALTER TABLE " + ((Table)allTable.elementAt(i)).getName() + " ADD Update_id Number"; 
                    commandCreate.add(str2);
                    commandSite2.add(((Table)allTable.elementAt(i)).getSite());
                    ((Table)allTable.elementAt(i)).addCol("UPDATE_ID","NUMBER");
                    isUpdateCaseCade = true;
                }
              
            }
        }

    
    }
    
    // Check Add Column Command
    public boolean haveCreateCommand() {
        return isUpdateCaseCade;
    }
    
    // Creae Check Trigger @ Child Table
    public void createCheckFK(Fragment input) {
        Vector allTable = input.getTable();
        for (int i =0 ; i < allTable.size();i++){
            if (allTable.elementAt(i) instanceof Fragment) {
                if (((Fragment)allTable.elementAt(i)).hasCol(jComboBox3.getSelectedItem().toString())) {
                     createCheckFK((Fragment)allTable.elementAt(i));
                }
            }else{
                if (((Table)allTable.elementAt(i)).hasCol(jComboBox3.getSelectedItem().toString())) {
                    String csite = ((Table)allTable.elementAt(i)).getSite();
                    String psite = jComboBox4.getSelectedItem().toString();
                    String ctable = ((Table)allTable.elementAt(i)).getName();
                    String ptable = jComboBox5.getSelectedItem().toString();
                    String ccol = jComboBox3.getSelectedItem().toString();
                    String pcol = jComboBox6.getSelectedItem().toString();
                    String type = jTextField1.getText();
                    String nw = "\n";
                    String str1 = "CREATE OR REPLACE TRIGGER " + ctable + "_" + ptable;
                    str1 += "_CHECK " + nw;
                    str1 += "BEFORE INSERT OR UPDATE OF " +ccol  + " ON " + ctable + nw;
                    str1 += "FOR EACH ROW WHEN (new." + ccol + " IS NOT NULL)" + nw;
                    str1 += "DECLARE " + nw;
                    str1 += " Dummy  " + type +";"+ nw;
                    str1 += " KInvalid EXCEPTION;" + nw;
                    str1 += " KValid  EXCEPTION;" + nw;
                    str1 += " Mutating_table    EXCEPTION;" + nw;
                    str1 += " PRAGMA    EXCEPTION_INIT  (Mutating_table, -4901);" + nw;
                    str1 += " CURSOR Dummy_cursor   (Dn " + type + ") IS" + nw;
                    str1 += "  SELECT " + pcol + " FROM " + ptable + "@"+psite + " WHERE ";
                    str1 +=  pcol + " = Dn FOR UPDATE OF " + ccol + " ;"+ nw;
                    str1 += "BEGIN " + nw;
                    str1 += " OPEN Dummy_cursor ( :new." + ccol +");" + nw;
                    str1 += " FETCH Dummy_cursor INTO Dummy;" + nw;
                    str1 += "   IF Dummy_cursor%NOTFOUND THEN\n" + 
                    "      RAISE KInvalid;\n" + 
                    "   ELSE\n" + 
                    "      RAISE KValid;\n" + 
                    "   END IF;\n" + 
                    "   CLOSE Dummy_cursor;\n" + 
                    "EXCEPTION\n" + 
                    "   WHEN KInvalid THEN\n" + 
                    "      CLOSE Dummy_cursor;\n" + 
                    "      Raise_application_error(-20000, ' || '''Invalid Parent PK Key''' || ');\n" + 
                    "   WHEN KValid THEN\n" + 
                    "      CLOSE Dummy_cursor;\n" + 
                    "   WHEN Mutating_table THEN\n" + 
                    "      NULL;\n" + 
                    "END;";
                    allCommand.add(str1);
                    commandSite.add(csite);
                }
            }
        }
       
        
    }
    
    // Get all Command Except Add Column Command
    public Vector getCommand() {
        for (int i = 0;i < allCommand.size();i++){
            if (!commandSite.elementAt(i).toString().equals(conn.getDB())){
                String str1 = "";
                str1 =    "BEGIN \n DBMS_SQL.PARSE@" + commandSite.elementAt(i) + 
                    "(DBMS_SQL.OPEN_CURSOR@" +  commandSite.elementAt(i) + 
                    ",'" + allCommand.elementAt(i) + "',DBMS_SQL.NATIVE); \nEND;";
                allCommand.setElementAt(str1,i);
            }else {
                String str1 = "";
                str1 =    "BEGIN \n DBMS_SQL.PARSE" + 
                    "(DBMS_SQL.OPEN_CURSOR"  + 
                    ",'" + allCommand.elementAt(i) + "',DBMS_SQL.NATIVE); \nEND;";
                allCommand.setElementAt(str1,i);
            }
          
        }
        
        return allCommand;
    }
    
    // Get Add Column Update_id command
    public Vector getCommandAddColumn() {
        for (int i = 0;i < commandCreate.size();i++){
            if (!commandSite2.elementAt(i).toString().equals(conn.getDB())){
                String str1 = "";
                str1 =    "BEGIN \n DBMS_SQL.PARSE@" + commandSite2.elementAt(i) + 
                    "(DBMS_SQL.OPEN_CURSOR@" +  commandSite2.elementAt(i) + 
                    ",'" + commandCreate.elementAt(i) + "',DBMS_SQL.NATIVE); \nEND;";
                commandCreate.setElementAt(str1,i);
            }else {
                String str1 = "";
                str1 =    "BEGIN \n DBMS_SQL.PARSE" + 
                    "(DBMS_SQL.OPEN_CURSOR"  + 
                    ",'" + commandCreate.elementAt(i) + "',DBMS_SQL.NATIVE); \nEND;";
                commandCreate.setElementAt(str1,i);
            }
          
        }
        
        return commandCreate;
    }
    
    // Return Flagment after add Update_id Column (if Need)
    public Fragment getGlobalFrag(){
        return globalFrag;
    }
}
