package project1;

import java.util.Vector;


public class Fragment {
    private String fragName;
    private String fragType;
    private String condition = "";
    private Vector allTable = new Vector();

    public Fragment() {
        fragName = "";
        fragType = "";


    }

    public Fragment(String name, String type) {
        setName(name);
        setType(type);
    }

    public void setName(String name) {
        this.fragName = name;
    }

    public void setType(String type) {
        this.fragType = type;
    }

    public void setcondition(String c) {
        condition = c;
    }

    public String getName() {
        return fragName;
    }

    public String getType() {
        return fragType;
    }

    public void addTable(Object in) {
        allTable.addElement(in);
    }

    public Vector getTable() {
        return allTable;
    }

    public void getCopy(Fragment in) {
        this.setName(in.getName());
        this.setType(in.getType());
    }

    public Vector[] getAllCol() {
        Vector[] result = new Vector[2];
        result[0] = new Vector();
        result[1] = new Vector();
        //Vector[0] is ColName
        //Vector[1] is ColType
        for (int i = 0; i < allTable.size(); i++) {
            if (allTable.elementAt(i) instanceof Table) {
                for (int j = 0; 
                     j < ((Table)allTable.elementAt(i)).getColCount(); j++) {
                    if (!Fragment.isInVector(result[0], 
                                             ((Table)allTable.elementAt(i)).getColNameAt(j))) {
                        result[0].addElement(((Table)allTable.elementAt(i)).getColNameAt(j));
                        result[1].addElement(((Table)allTable.elementAt(i)).getColTypeAt(j));
                    }
                }
            } else if (allTable.elementAt(i) instanceof Fragment) {
                Vector[] tmp = new Vector[2];
                tmp = ((Fragment)allTable.elementAt(i)).getAllCol();
                for (int j = 0; j < tmp[0].size(); j++) {
                    if (!Fragment.isInVector(result[0], 
                                             tmp[0].elementAt(j).toString())) {
                        result[0].addElement(tmp[0].elementAt(j).toString());
                        result[1].addElement(tmp[1].elementAt(j).toString());
                    }
                }
            }
        }

        return result;
    }

    public Vector getPK() {
        Vector result = new Vector();
        for (int i = 0; i < allTable.size(); i++) {
            if (allTable.elementAt(i) instanceof Table) {
                for (int j = 0; 
                     j < ((Table)allTable.elementAt(i)).getPK().size(); j++) {
                    if (!Fragment.isInVector(result, 
                                             ((Table)allTable.elementAt(i)).getPK().elementAt(j).toString())) {
                        result.addElement(((Table)allTable.elementAt(i)).getPK().elementAt(j));
                    }
                }
            } else if (allTable.elementAt(i) instanceof Fragment) {
                Vector tmp = new Vector();
                tmp = ((Fragment)allTable.elementAt(i)).getPK();
                for (int j = 0; j < tmp.size(); j++) {
                    if (!Fragment.isInVector(result, 
                                             tmp.elementAt(j).toString())) {
                        result.addElement(tmp.elementAt(j).toString());

                    }
                }
            }
        }

        return result;
    }

    public int getHrCount() {
        int count = 0;
        if (fragType.equals("Horizontal")) {
            count++;
        }
        for (int i = 0; i < allTable.size(); i++) {
            if (allTable.elementAt(i) instanceof Fragment) {
                // if (((Fragment)allTable.elementAt(i)).getType().equals("Horizontal")) {
                //     count ++;
                // }
                count += ((Fragment)allTable.elementAt(i)).getHrCount();
            }
        }

        return count;
    }

    public static boolean isInVector(Vector input, String ColName) {
        boolean chk = false;
        for (int i = 0; i < input.size(); i++) {
            if (input.elementAt(i).toString().equals(ColName)) {
                chk = true;
                break;
            }
        }
        return chk;
    }

    public boolean hasCol(String colName) {
        boolean re = false;
        for (int i = 0; i < allTable.size(); i++) {
            if (allTable.elementAt(i) instanceof Table) {
                if (((Table)allTable.elementAt(i)).hasCol(colName)) {
                    re = true;
                    break;
                }
            } else {
                if (((Fragment)allTable.elementAt(i)).hasCol(colName)) {
                    re = true;
                    break;
                }
            }
        }
        return re;
    }

    public String toString() {
        if (fragType == "")
            return fragName + "                      ";
        else
            return fragName + " : " + fragType;
    }

    public boolean isPK(String colName) {
        Vector pk = getPK();
        for (int i = 0; i < pk.size(); i++) {
            if (pk.elementAt(i).toString().equals(colName)) {
                return true;
            }
        }
        return false;
    }

    public String getCondition() {
        return condition;
    }
}
