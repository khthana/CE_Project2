package project1;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.SQLException;

import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class Panel6 extends JPanel {
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JTextArea jTextArea1 = new JTextArea();
    private Fragment global;
    private Vector dblink;
    private CreateConnection conn = null;
    private JButton jButton1 = new JButton();
    private int clickcount = 0;
    private Vector allCommand;

    private String caller;

    public Panel6() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void jbInit() throws Exception {
        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        jLabel1.setText("Global Table Configuration Complete");
        jLabel1.setBounds(new Rectangle(75, 15, 345, 15));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jLabel2.setText("SQL Command :");
        jLabel2.setBounds(new Rectangle(75, 60, 130, 15));
        //jTextArea1.setBounds(new Rectangle(100, 105, 620, 355));
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setEditable(false);
        //this.add(jTextArea1, null);
        this.add(jButton1, null);
        this.add(jLabel2, null);
        this.add(jLabel1, null);

        JScrollPane scrollpane = new JScrollPane(jTextArea1);
        scrollpane.setBounds(new Rectangle(100, 105, 620, 355));
        jButton1.setText("Execute All");
        jButton1.setBounds(new Rectangle(605, 60, 115, 20));
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        this.add(scrollpane, null);
        this.repaint();
    }

    // Set Data ( From Global Creater )
    public void setData(Fragment input, Vector link) {
        this.global = input;
        this.dblink = link;
        
        caller = "Panel5";
    }
    
    // Set Before All Command ( if Have) 
    public void setInitCommand(Vector before,Vector after) {
        allCommand = new Vector();
        allCommand.addAll(before);
        createSQL();
        allCommand.addAll(after);
        String text;
        text = printVector(allCommand);
        jTextArea1.setText(text);
    }
    
    // Set Data ( From FK Creater )
    public void setData(Vector commandIn) {
        String text;
        allCommand = commandIn;
        text = printVector(allCommand);
        jTextArea1.setText(text);
        caller = "FKcreate";
    }
    
    // Return Who call This Panel
    public String getCaller() {
        return caller;
    }

    // Set Connection
    public void setConn(CreateConnection newconn) {
        this.conn = newconn;
    }

    // Create SQL for Global View
    public void createSQL() {
        Vector tmp = new Vector();
        
        tmp = 
createFragmentSQL((Fragment)global, ((Fragment)global).getName());
        //for (int i = 0 ; i < tmp.size();i++) {
        //    text += tmp.elementAt(i).toString() + "\n";
        //}

        for (int i = 1; i < dblink.size(); i++) {
            String str1 = 
                "BEGIN \n DBMS_SQL.PARSE@" + dblink.elementAt(i).toString() + 
                "(DBMS_SQL.OPEN_CURSOR@" + dblink.elementAt(i).toString() + 
                ",'CREATE OR REPLACE SYNONYM ";
            str1 += global.getName();
            str1 += " FOR " + global.getName() + "@" + conn.getDB();
            str1 += "',DBMS_SQL.NATIVE); \nEND;";
            tmp.add(str1);
        }
        allCommand.addAll(tmp);
        
    }

    // Recursive Fn for Create SQL for Fragment
    public Vector createFragmentSQL(Fragment input, String refName) {
        Vector SQLCommand = new Vector();

        //Recursive Call 
        for (int i = 0; i < input.getTable().size(); i++) {
            if (input.getTable().elementAt(i) instanceof Fragment) {
                Vector tmp = new Vector();
                tmp = 
createFragmentSQL(((Fragment)input.getTable().elementAt(i)), 
                  refName + "_" + ((Fragment)input.getTable().elementAt(i)).getName());
                SQLCommand.addAll(tmp);
            }
        }

        // Check Vertical or Horizontal
        if (input.getType().equals("Vertical")) {
            Vector glCol[] = new Vector[2];
            //String cols = " (";
            String allcols = "";
            String alltab = "";
            String where = "";
            String selectcol = "";
            String nwln = "\n";
            for (int i = 0; i < input.getTable().size(); i++) {
                if (input.getTable().elementAt(i) instanceof Table) {


                    //Create Symnonym for every table come from other site
                    if (!((Table)input.getTable().elementAt(i)).getSite().equals(conn.getDB())) {
                        String str1 = "CREATE OR REPLACE SYNONYM ";
                        str1 += 
                                refName + "_" + ((Table)input.getTable().elementAt(i)).getName() + 
                                nwln;
                        str1 += 
                                " FOR " + ((Table)input.getTable().elementAt(i)).toString() + 
                                nwln;
                        SQLCommand.add(str1);
                        ((Table)input.getTable().elementAt(i)).setSynonym(refName + 
                                                                          "_" + 
                                                                          ((Table)input.getTable().elementAt(i)).getName());
                        alltab += 
                                ((Table)input.getTable().elementAt(i)).getSynonym();
                    } else {
                        alltab += 
                                ((Table)input.getTable().elementAt(i)).getName();
                        ((Table)input.getTable().elementAt(i)).setSynonym(((Table)input.getTable().elementAt(i)).getName());
                    }
                    if (i != input.getTable().size() - 1) {
                        alltab += ", ";
                    }

                } else {
                    alltab += 
                            refName + "_" + ((Fragment)input.getTable().elementAt(i)).getName();
                    if (i != input.getTable().size() - 1) {
                        alltab += ", ";
                    }
                }
            }


            //Crate Global View
            glCol = input.getAllCol();
            for (int i = 0; i < glCol[0].size(); i++) {
                if (i == glCol[0].size() - 1) {
                    allcols += glCol[0].elementAt(i).toString() + " ";
                } else {
                    allcols += glCol[0].elementAt(i).toString() + ", ";
                }
            }

            for (int g = 0; g < glCol[0].size(); g++) {
                for (int i = 0; i < input.getTable().size(); i++) {
                    if (input.getTable().elementAt(i) instanceof Table) {
                        if (((Table)input.getTable().elementAt(i)).hasCol(glCol[0].elementAt(g).toString())) {
                            //if (((Table)input.getTable().elementAt(i)).getSynonym().equals("")) {
                            //    selectcol += ((Table)input.getTable().elementAt(i)).getName() + "." + glCol[0].elementAt(g).toString();
                            //}else{
                            selectcol += 
                                    ((Table)input.getTable().elementAt(i)).getSynonym() + 
                                    "." + glCol[0].elementAt(g).toString();
                            //}
                            if (g != glCol[0].size() - 1) {
                                selectcol += ", ";
                            }
                            break;
                        }
                    } else {
                        if (((Fragment)input.getTable().elementAt(i)).hasCol(glCol[0].elementAt(g).toString())) {
                            selectcol += 
                                    refName + "_" + ((Fragment)input.getTable().elementAt(i)).getName() + 
                                    "." + glCol[0].elementAt(g).toString();
                            if (g != glCol[0].size() - 1) {
                                selectcol += ", ";
                            }
                            break;
                        }
                    }
                }
            }

            if (input.getTable().elementAt(0) instanceof Table) {

                for (int i = 0; i < input.getPK().size(); i++) {
                    for (int j = 1; j < input.getTable().size(); j++) {
                        where += 
                                ((Table)input.getTable().elementAt(0)).getSynonym() + 
                                "." + input.getPK().elementAt(i) + " = ";
                        if (input.getTable().elementAt(j) instanceof Table) {
                            where += 
                                    ((Table)input.getTable().elementAt(j)).getSynonym() + 
                                    "." + input.getPK().elementAt(i) + " ";
                        } else {
                            where += 
                                    refName + "_" + ((Fragment)input.getTable().elementAt(j)).getName() + 
                                    "." + input.getPK().elementAt(i) + " ";
                        }
                    }
                    if (i != input.getPK().size() - 1) {
                        where += " AND ";
                    }
                }

            } else {
                for (int i = 0; i < input.getPK().size(); i++) {
                    for (int j = 1; j < input.getTable().size(); j++) {
                        where += 
                                refName + "_" + ((Fragment)input.getTable().elementAt(0)).getName() + 
                                "." + input.getPK().elementAt(i) + " = ";
                        if (input.getTable().elementAt(j) instanceof Table) {
                            where += 
                                    ((Table)input.getTable().elementAt(j)).getSynonym() + 
                                    "." + input.getPK().elementAt(i) + " ";
                        } else {
                            where += 
                                    refName + "_" + ((Fragment)input.getTable().elementAt(j)).getName() + 
                                    "." + input.getPK().elementAt(i) + " ";
                        }

                    }
                    if (i != input.getPK().size() - 1) {
                        where += " AND ";
                    }
                }

            }

            selectcol += " ";
            alltab += " ";
            String str2 = 
                "CREATE OR REPLACE VIEW " + refName + " (" + allcols + 
                " ) AS " + nwln;
            str2 += "SELECT  " + selectcol;
            str2 += "FROM " + alltab;
            str2 += "WHERE " + where;
            SQLCommand.add(str2);

            // Create INSTEAD OF Trigger
            // INSERT Trigger
            String insT = "";
            insT += "CREATE OR REPLACE TRIGGER " + refName + "_INST ";
            insT += "INSTEAD OF INSERT ON " + refName + " " + nwln;
            insT += "FOR EACH ROW " + nwln + " BEGIN " + nwln;
            Vector tmp = input.getTable();
            for (int i = 0; i < tmp.size(); i++) {
                String value = " VALUES ( ";
                insT += " BEGIN " + nwln;
                if (tmp.elementAt(i) instanceof Table) {
                    //if (((Table)tmp.elementAt(i)).getSynonym().equals("")) {
                    //    insT += " INSERT INTO " + ((Table)tmp.elementAt(i)).getName();
                    //}else {
                    insT += 
                            " INSERT INTO "  + ((Table)tmp.elementAt(i)).getSynonym();
                    insT += " ( ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getColCount(); j++) {
                        insT += ((Table)tmp.elementAt(i)).getColNameAt(j);
                        value += 
                                ":new." + ((Table)tmp.elementAt(i)).getColNameAt(j);
                        if (j != ((Table)tmp.elementAt(i)).getColCount() - 1) {
                            insT += ", ";
                            value += ", ";
                        }
                    }
                    insT += " ) ";
                    value += " ) ";
                    //}

                } else {

                    insT += 
                            " INSERT INTO " + refName + "_" +((Fragment)tmp.elementAt(i)).getName();
                    insT += " (";
                    Vector[] coll = ((Fragment)tmp.elementAt(i)).getAllCol();
                    for (int j = 0; j < coll[0].size(); j++) {
                        insT += coll[0].elementAt(j).toString();
                        value += ":new." + coll[0].elementAt(j).toString();
                        ;
                        if (j != (coll[0].size() - 1)) {
                            insT += ", ";
                            value += ", ";
                        }
                    }
                    insT += " ) ";
                    value += " ) ";
                }
                insT += value + "; ";
                insT += nwln + " END ; " + nwln;
            }
            insT += 
                    "  EXCEPTION" + " WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20000, 'unique constraint violated');			  \n" + 
                    "END ;";
            SQLCommand.add(insT);

            //UPDATE Trigger
            String updT = "";

            updT += "CREATE OR REPLACE TRIGGER " + refName + "_UPDT ";
            updT += "INSTEAD OF UPDATE ON " + refName + " ";
            updT += "FOR EACH ROW " + nwln + " BEGIN " + nwln;
            tmp = input.getTable();
            for (int i = 0; i < tmp.size(); i++) {
                String update = "UPDATE ";
                updT += "BEGIN " + nwln;
                updT += "IF ";
                if (tmp.elementAt(i) instanceof Table) {

                    update +=  ((Table)tmp.elementAt(i)).getSynonym() + " SET ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getColumnName().size(); 
                         j++) {
                        if (((Table)tmp.elementAt(i)).isPK(((Table)tmp.elementAt(i)).getColNameAt(j))) {
                            updT += 
                                    ":old." + ((Table)tmp.elementAt(i)).getColNameAt(j);
                            updT += 
                                    " != :new." + ((Table)tmp.elementAt(i)).getColNameAt(j);

                            update += 
                                    ((Table)tmp.elementAt(i)).getColNameAt(j) + 
                                    " = :new." + 
                                    ((Table)tmp.elementAt(i)).getColNameAt(j);

                        } else {
                            String name = 
                                ((Table)tmp.elementAt(i)).getColNameAt(j);
                            updT += 
                                    "(:old." + name + " IS NULL AND :new." + name + 
                                    " IS NOT NULL) OR";
                            updT += 
                                    "(:old." + name + " IS NOT NULL AND :new." + 
                                    name + " IS NOT NULL AND :old." + name + 
                                    " != :new." + name + ") OR ";
                            updT += 
                                    "(:old." + name + " IS NOT NULL AND :new." + 
                                    name + " IS NULL) ";

                            update += name + " = :new." + name;

                        }
                        if (j != 
                            ((Table)tmp.elementAt(i)).getColumnName().size() - 
                            1) {
                            updT += " OR ";
                            update += ", ";
                        }

                    }

                    updT += " THEN ";
                    where = " WHERE ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getPK().size(); j++) {
                        where += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:old." + 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " ";
                        if (j != 
                            ((Table)tmp.elementAt(i)).getPK().size() - 1) {
                            where += " AND ";
                        }
                    }
                } else { // For Fragment
                    update += refName + "_" +((Fragment)tmp.elementAt(i)).getName() + " SET ";
                    Vector tabtmp = 
                        ((Fragment)tmp.elementAt(i)).getAllCol()[0];
                    for (int j = 0; j < tabtmp.size(); j++) {
                        if (((Fragment)tmp.elementAt(i)).isPK(tabtmp.elementAt(j).toString())) {
                            updT += ":old." + tabtmp.elementAt(j).toString();
                            updT += 
                                    " != :new." + tabtmp.elementAt(j).toString();

                            update += 
                                    tabtmp.elementAt(j).toString() + " = :new." + 
                                    tabtmp.elementAt(j).toString();

                        } else {
                            String name = tabtmp.elementAt(j).toString();
                            updT += 
                                    "(:old." + name + " IS NULL AND :new." + name + 
                                    " IS NOT NULL) OR";
                            updT += 
                                    "(:old." + name + " IS NOT NULL AND :new." + 
                                    name + " IS NOT NULL AND :old." + name + 
                                    " != :new." + name + ") OR ";
                            updT += 
                                    "(:old." + name + " IS NOT NULL AND :new." + 
                                    name + " IS NULL) ";

                            update += name + " = :new." + name;

                        }
                        if (j != tabtmp.size() - 1) {
                            updT += " OR ";
                            update += ", ";
                        }

                    }

                    updT += " THEN " + nwln;
                    where = " WHERE ";
                    for (int j = 0; 
                         j < ((Fragment)tmp.elementAt(i)).getPK().size(); 
                         j++) {
                        where += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:old." + 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " ";
                        if (j != 
                            ((Fragment)tmp.elementAt(i)).getPK().size() - 1) {
                            where += " AND ";
                        }
                    }
                }
                updT += update + where + "; " + nwln;
                updT += nwln + " END IF; " + nwln;
                updT += nwln + " END ; " + nwln;
            }
            updT += "END;";
            SQLCommand.add(updT);
            //DELETE Trigger
            String delT = "";
            delT += "CREATE OR REPLACE TRIGGER " + refName + "_DELT ";
            delT += "INSTEAD OF DELETE ON " + refName + " ";
            delT += "FOR EACH ROW " + nwln + " BEGIN " + nwln;
            tmp = input.getTable();
            for (int i = 0; i < tmp.size(); i++) {
                delT += "BEGIN " + nwln;
                if (tmp.elementAt(i) instanceof Table) {
                    delT += 
                            " DELETE FROM "  +((Table)tmp.elementAt(i)).getSynonym();
                    delT += " WHERE ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getPK().size(); j++) {
                        delT += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:old." + 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " ";
                        if (j != 
                            ((Table)tmp.elementAt(i)).getPK().size() - 1) {
                            delT += " AND ";
                        }
                    }
                } else {

                    delT += 
                            " DELETE FROM " + refName + "_" +((Fragment)tmp.elementAt(i)).getName();
                    delT += " WHERE ";
                    for (int j = 0; 
                         j < ((Fragment)tmp.elementAt(i)).getPK().size(); 
                         j++) {
                        delT += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:old." + 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " ";
                        if (j != 
                            ((Fragment)tmp.elementAt(i)).getPK().size() - 1) {
                            delT += " AND ";
                        }
                    }
                }
                delT += "; ";
                delT += nwln + " END ; " + nwln;
            }
            delT += "END ;";
            SQLCommand.add(delT);
        }


        // Horizontal
        else {
            Vector glCol[] = new Vector[2];
            //String cols = " (";
            String allcols = "";

            String nwln = "\n";
            for (int i = 0; i < input.getTable().size(); i++) {
                if (input.getTable().elementAt(i) instanceof Table) {


                    //Create Symnonym for every table come from other site
                    if (!((Table)input.getTable().elementAt(i)).getSite().equals(conn.getDB())) {
                        String str1 = "CREATE OR REPLACE SYNONYM ";
                        str1 += 
                                refName + "_" + ((Table)input.getTable().elementAt(i)).getName();
                        str1 += 
                                " FOR " + ((Table)input.getTable().elementAt(i)).toString() + 
                                nwln;
                        SQLCommand.add(str1);
                        ((Table)input.getTable().elementAt(i)).setSynonym(refName + 
                                                                          "_" + 
                                                                          ((Table)input.getTable().elementAt(i)).getName());

                    } else {

                        ((Table)input.getTable().elementAt(i)).setSynonym(((Table)input.getTable().elementAt(i)).getName());
                    }

                }
            }

            //Crate Global View
            // All Col
            glCol = input.getAllCol();
            for (int i = 0; i < glCol[0].size(); i++) {
                if (i == glCol[0].size() - 1) {
                    allcols += glCol[0].elementAt(i).toString() + " ";
                } else {
                    allcols += glCol[0].elementAt(i).toString() + ", ";
                }
            }


            String str2 = 
                "CREATE OR REPLACE VIEW " + refName + " (" + allcols + 
                " ) AS ";
            for (int i = 0; i < input.getTable().size(); i++) {
                str2 += "SELECT  " + allcols;
                if (input.getTable().elementAt(i) instanceof Table) {
                    str2 += 
                            "FROM " + ((Table)input.getTable().elementAt(i)).getSynonym();
                } else {
                    str2 += 
                            "FROM " + refName + "_" + ((Fragment)input.getTable().elementAt(i)).getName();
                }
                if (i != input.getTable().size() - 1) {
                    str2 += " UNION ";
                }
            }


            SQLCommand.add(str2);

            // Create INSTEAD OF Trigger
            // INSERT Trigger
            String insT = "";
            String insT2 = "";
            insT += "CREATE OR REPLACE TRIGGER " + refName + "_INST ";
            insT += "INSTEAD OF INSERT ON " + refName;
            insT += " REFERENCING OLD AS OLD NEW AS NEW  " + nwln;
            insT += "FOR EACH ROW  BEGIN " + nwln;
            Vector tmp = input.getTable();
            for (int i = 0; i < tmp.size(); i++) {
                String value = " VALUES ( ";

                if (tmp.elementAt(i) instanceof Table) {
                    //if (((Table)tmp.elementAt(i)).getSynonym().equals("")) {
                    //    insT += " INSERT INTO " + ((Table)tmp.elementAt(i)).getName();
                    //}else {
                    insT2 += 
                            "IF :NEW." + ((Table)tmp.elementAt(i)).getCondition() + 
                            " THEN BEGIN";

                    insT2 += 
                            " INSERT INTO " + ((Table)tmp.elementAt(i)).getSynonym();
                    insT2 += " ( ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getColCount(); j++) {
                        insT2 += ((Table)tmp.elementAt(i)).getColNameAt(j);
                        value += 
                                ":new." + ((Table)tmp.elementAt(i)).getColNameAt(j);
                        if (j != ((Table)tmp.elementAt(i)).getColCount() - 1) {
                            insT2 += ", ";
                            value += ", ";
                        }
                    }
                    insT2 += " ) ";
                    value += " ) ";
                    //}

                } else {
                    insT2 += 
                            "IF :NEW." + ((Fragment)tmp.elementAt(i)).getCondition() + 
                            " THEN BEGIN";
                    insT2 += 
                            " INSERT INTO " + ((Fragment)tmp.elementAt(i)).getName();
                    insT2 += " (";
                    Vector[] coll = ((Fragment)tmp.elementAt(i)).getAllCol();
                    for (int j = 0; j < coll[0].size(); j++) {
                        insT2 += coll[0].elementAt(j).toString();
                        value += ":new." + coll[0].elementAt(j).toString();
                        ;
                        if (j != (coll[0].size() - 1)) {
                            insT2 += ", ";
                            value += ", ";
                        }
                    }
                    insT2 += " ) ";
                    value += " )";
                }
                insT2 += value + ";";
                insT2 += nwln + " END ;" + nwln;
                insT2 += nwln + " END IF ;" + nwln;
            }
            insT += insT2;
            insT += 
                    "  EXCEPTION " + "WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20000, 'unique constraint violated');                    \n" + 
                    "END ;";
            SQLCommand.add(insT);

            //UPDATE Trigger
            String updT = "";
            String where = "";
            updT += "CREATE OR REPLACE TRIGGER " + refName + "_UPDT ";
            updT += "INSTEAD OF UPDATE ON " + refName + " ";
            updT += "FOR EACH ROW " + nwln;
            updT += "DECLARE rowcnt       number;";
            updT += " BEGIN " + nwln;
            updT += "IF ";
            for (int i = 0; i < input.getAllCol()[0].size(); i++) {
                if (input.isPK(input.getAllCol()[0].elementAt(i).toString())) {
                    updT += 
                            ":old." + input.getAllCol()[0].elementAt(i).toString();
                    updT += 
                            " != :new." + input.getAllCol()[0].elementAt(i).toString();


                } else {
                    String name = input.getAllCol()[0].elementAt(i).toString();
                    updT += 
                            "(:old." + name + " IS NULL AND :new." + name + " IS NOT NULL) OR";
                    updT += 
                            "(:old." + name + " IS NOT NULL AND :new." + name + " IS NOT NULL AND :old." + 
                            name + " != :new." + name + ") OR ";
                    updT += 
                            "(:old." + name + " IS NOT NULL AND :new." + name + " IS NULL) ";

                }
                if (i != input.getAllCol()[0].size() - 1) {
                    updT += " OR ";
                }
            }
            updT += " THEN ";
            updT += "BEGIN " + nwln;
            tmp = input.getTable();
            for (int i = 0; i < tmp.size(); i++) {
                String w = "";
                if (tmp.elementAt(i) instanceof Table) {
                    updT += 
                            "SELECT COUNT(*) INTO rowcnt FROM " + ((Table)tmp.elementAt(i)).getSynonym();
                    updT += " WHERE ";
                    w += " WHERE ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getPK().size(); j++) {
                        updT += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:OLD.";
                        updT += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j) + 
                                " ";
                        w += 
 ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + " =:OLD.";
                        w += 
 ((Table)tmp.elementAt(i)).getPK().elementAt(j) + " ";
                        if (j != 
                            ((Table)tmp.elementAt(i)).getPK().size() - 1) {
                            updT += " AND ";
                            w += " AND ";
                        }
                    }
                    updT += ";";
                    w += ";";
                    updT += "IF rowcnt = 1 THEN ";
                    updT += 
                            " DELETE " + ((Table)tmp.elementAt(i)).getSynonym() + 
                            w;
                    updT += " END IF; ";

                } else { // For Fragment
                    updT += 
                            "SELECT COUNT(*) INTO rowcnt FROM " + ((Fragment)tmp.elementAt(i)).getName();
                    updT += " WHERE ";
                    w += " WHERE ";
                    for (int j = 0; 
                         j < ((Fragment)tmp.elementAt(i)).getPK().size(); 
                         j++) {
                        updT += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:OLD.";
                        updT += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j) + 
                                " ";
                        w += 
 ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + " =:OLD.";
                        w += 
 ((Fragment)tmp.elementAt(i)).getPK().elementAt(j) + " ";
                        if (j != 
                            ((Fragment)tmp.elementAt(i)).getPK().size() - 1) {
                            updT += " AND ";
                            w += " AND ";
                        }
                    }
                    updT += ";";
                    w += ";";
                    updT += "IF rowcnt = 1 THEN ";
                    updT += 
                            " DELETE " + ((Fragment)tmp.elementAt(i)).getName() + 
                            w;
                    updT += " END IF ;";
                }

            }
            updT += " " + insT2;
            updT += nwln + "END; " + nwln + "END IF;";
            updT += 
                    "  EXCEPTION" + " WHEN DUP_VAL_ON_INDEX THEN RAISE_APPLICATION_ERROR(-20000, 'unique constraint violated');                    \n" + 
                    "END ;";
            SQLCommand.add(updT);
            //DELETE Trigger
            String delT = "";
            delT += "CREATE OR REPLACE TRIGGER " + refName + "_DELT ";
            delT += "INSTEAD OF DELETE ON " + refName + " ";
            delT += "FOR EACH ROW " + nwln;
            delT += "DECLARE rowcnt       number;";
            delT += " BEGIN " + nwln;
            for (int i = 0; i < tmp.size(); i++) {
                String w = "";
                if (tmp.elementAt(i) instanceof Table) {
                    delT += 
                            "SELECT COUNT(*) INTO rowcnt FROM " + ((Table)tmp.elementAt(i)).getSynonym();
                    delT += " WHERE ";
                    w += " WHERE ";
                    for (int j = 0; 
                         j < ((Table)tmp.elementAt(i)).getPK().size(); j++) {
                        delT += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:OLD.";
                        delT += 
                                ((Table)tmp.elementAt(i)).getPK().elementAt(j) + 
                                " ";
                        w += 
 ((Table)tmp.elementAt(i)).getPK().elementAt(j).toString() + " =:OLD.";
                        w += 
 ((Table)tmp.elementAt(i)).getPK().elementAt(j) + " ";
                        if (j != 
                            ((Table)tmp.elementAt(i)).getPK().size() - 1) {
                            delT += " AND ";
                            w += " AND ";
                        }
                    }
                    delT += ";";
                    w += ";";
                    delT += "IF rowcnt = 1 THEN ";
                    delT += 
                            " DELETE " + ((Table)tmp.elementAt(i)).getSynonym() + 
                            w;
                    delT += " END IF;";

                } else { // For Fragment
                    delT += 
                            "SELECT COUNT(*) INTO rowcnt FROM " + ((Fragment)tmp.elementAt(i)).getName();
                    delT += " WHERE ";
                    w += " WHERE ";
                    for (int j = 0; 
                         j < ((Fragment)tmp.elementAt(i)).getPK().size(); 
                         j++) {
                        delT += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + 
                                " =:OLD.";
                        delT += 
                                ((Fragment)tmp.elementAt(i)).getPK().elementAt(j) + 
                                " ";
                        w += 
 ((Fragment)tmp.elementAt(i)).getPK().elementAt(j).toString() + " =:OLD.";
                        w += 
 ((Fragment)tmp.elementAt(i)).getPK().elementAt(j) + " ";
                        if (j != 
                            ((Fragment)tmp.elementAt(i)).getPK().size() - 1) {
                            delT += " AND ";
                            w += " AND ";
                        }
                    }
                    delT += ";";
                    w += ";";
                    delT += "IF rowcnt = 1 THEN ";
                    delT += 
                            " DELETE " + ((Fragment)tmp.elementAt(i)).getName() + 
                            w;
                    delT += " END IF; ";
                }

            }
            delT += "END ;";
            SQLCommand.add(delT);
        }
        return SQLCommand;
    }

    // Recursive Fn for Print Command in Vector
    public String printVector(Vector in) {
        String result = "";
        for (int i = 0; i < in.size(); i++) {
            if (in.elementAt(i) instanceof Vector) {
                result = 
                        result + printVector((Vector)in.elementAt(i)) + "\n\n";
            } else {
                result = result + in.elementAt(i).toString() + "\n\n";
            }

        }
        return result;
    }

    // Button for Send All Command to Server
    private void jButton1_actionPerformed(ActionEvent e) {
        for (int i = 0; i < allCommand.size(); i++) {
            try {

                conn.CreateDDLStatement(allCommand.elementAt(i).toString());
            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);
                System.out.println("-------------------");
                System.out.println(f.getMessage());
                System.out.println("-------------------");
            }
        }
    }
}
