package project1;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;


public class Panel4 extends JPanel {

    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private QueryTableModel qtm = new QueryTableModel();
    private JButton jButton1 = new JButton();
    private JLabel jLabel9 = new JLabel();
    private Fragment frag = new Fragment();
    private CreateConnection conn = null;
    private JComboBox jComboBox1 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JTable table;
    private JScrollPane scrollpane;

    public Panel4() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {

        this.setLayout(null);
        this.setSize(new Dimension(795, 500));

        table = new JTable(qtm);

        scrollpane = new JScrollPane(table);
        scrollpane.setBounds(new Rectangle(175, 230, 435, 225));
        jLabel1.setText("Horizontal Fragment Setup");
        jLabel1.setBounds(new Rectangle(75, 15, 225, 15));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jLabel5.setText("Fragment Name : ");
        jLabel5.setBounds(new Rectangle(75, 60, 100, 15));
        jLabel4.setText("Table : ");
        jLabel4.setBounds(new Rectangle(75, 110, 70, 15));
        jLabel8.setText("Condition :");
        jLabel8.setBounds(new Rectangle(75, 160, 75, 15));
        jTextField1.setBounds(new Rectangle(175, 160, 220, 20));


        jComboBox1.setBounds(new Rectangle(175, 60, 335, 20));
        jComboBox1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox1_actionPerformed(e);
                    }
                });
        jComboBox2.setBounds(new Rectangle(175, 110, 335, 20));
        jComboBox2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox2_actionPerformed(e);
                    }
                });

        jButton1.setText("Set");
        jButton1.setBounds(new Rectangle(440, 160, 71, 23));
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jLabel9.setText("Eg. DEPTNO < 20 ");
        jLabel9.setBounds(new Rectangle(175, 195, 335, 15));

        this.add(jComboBox2, null);
        this.add(jComboBox1, null);

        this.add(jLabel9, null);
        this.add(jButton1, null);
        this.add(scrollpane, null);
        this.add(jTextField1, null);
        this.add(jLabel8, null);
        this.add(jLabel4, null);
        this.add(jLabel5, null);
        this.add(jLabel1, null);

    }

    public void setConn(CreateConnection newconn) {
        this.conn = newconn;
    }

    public void addData(Fragment input) {
        frag = input;
        jComboBox1.removeAllItems();
        jComboBox2.removeAllItems();
        getAllFragment();
        if (jComboBox2.getItemCount() > 0) {
            jComboBox2.setSelectedIndex(0);
        }
        this.repaint();
    }

    public void getAllFragment() {

        Vector tmp = new Vector();
        tmp.addElement(frag);
        tmp = getFrag(frag, tmp);
        for (int i = 0; i < tmp.size(); i++) {
            if (((Fragment)tmp.elementAt(i)).getType().equals("Horizontal"))
                jComboBox1.addItem((Fragment)tmp.elementAt(i));
        }


    }

    public Vector getFrag(Fragment parent, Vector output) {

        for (int i = 0; i < parent.getTable().size(); i++) {
            if (parent.getTable().elementAt(i) instanceof Fragment) {
                output = 
                        getFrag((Fragment)parent.getTable().elementAt(i), output);
                output.addElement(parent.getTable().elementAt(i));
            }
        }
        return output;
    }

    private void jComboBox1_actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("comboBoxChanged") && 
            jComboBox1.getItemCount() > 0) {
            jComboBox2.removeAllItems();
            for (int i = 0; 
                 i < ((Fragment)jComboBox1.getSelectedItem()).getTable().size(); 
                 i++) {
                if (((Fragment)jComboBox1.getSelectedItem()).getTable().elementAt(i) instanceof 
                    Table) {
                    jComboBox2.addItem(((Fragment)jComboBox1.getSelectedItem()).getTable().elementAt(i));
                } else {
                    jComboBox2.addItem(((Fragment)jComboBox1.getSelectedItem()).getTable().elementAt(i));
                }

            }

        }
    }

    private void jComboBox2_actionPerformed(ActionEvent e) {
        if (conn != null && jComboBox2.getSelectedItem() != null && 
            e.getActionCommand() == "comboBoxChanged") {
            // Vector columnNames = new Vector();
            //Vector data = new Vector();

            if (jComboBox2.getSelectedItem() instanceof Table) {
                //System.out.println(jComboBox2.getSelectedItem());
                ResultSet result;
                try {
                    result = 
                            conn.CreateStatement("select COLUMN_NAME , DATA_TYPE from USER_TAB_COLUMNS@" + 
                                                 ((Table)jComboBox2.getSelectedItem()).getSite() + 
                                                 " WHERE TABLE_NAME = '" + 
                                                 ((Table)jComboBox2.getSelectedItem()).getName() + 
                                                 "'");

                    String str = 
                        "select COLUMN_NAME , DATA_TYPE from USER_TAB_COLUMNS@" + 
                        ((Table)jComboBox2.getSelectedItem()).getSite() + 
                        " WHERE TABLE_NAME = '" + 
                        ((Table)jComboBox2.getSelectedItem()).getName() + "'";
                    //System.out.println(str);

                    //tmpRes = result;

                    qtm.setQuery(result);
                    //table = new JTable(qtm);
                } catch (SQLException f) {

                    JOptionPane.showMessageDialog(this, f.getMessage());
                }
                if (!((Table)jComboBox2.getSelectedItem()).getCondition().equals("")) {
                    jTextField1.setText(((Table)jComboBox2.getSelectedItem()).getCondition());
                } else {
                    jTextField1.setText("");
                }
            } else {
                Vector s[] = new Vector[2];
                s = ((Fragment)jComboBox2.getSelectedItem()).getAllCol();
                //System.out.println(s);
                Vector data = new Vector();
                Vector header = new Vector();
                for (int i = 0; i < s[0].size(); i++) {
                    String[] row = new String[2];
                    row[0] = s[0].elementAt(i).toString();
                    row[1] = s[1].elementAt(i).toString();
                    data.add(row);
                }
                header.add("Column Name");
                header.add("Data Type");
                qtm.setQuery(header, data);
                //table = new JTable(data,header);
                if (!((Fragment)jComboBox2.getSelectedItem()).getCondition().equals("")) {
                    jTextField1.setText(((Fragment)jComboBox2.getSelectedItem()).getCondition());
                } else {
                    jTextField1.setText("");
                }
            }
            //this.validate();
            //scrollpane.repaint();
        }
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        if (!jTextField1.getText().equals("")) {
            if (jComboBox2.getSelectedItem() instanceof Table) {
                ((Table)jComboBox2.getSelectedItem()).setcondition(jTextField1.getText());
            } else {
                ((Fragment)jComboBox2.getSelectedItem()).setcondition(jTextField1.getText());
            }

        } else {
            System.out.println("Please Insert Condition");
        }
    }

    public boolean isDataValid() {
        boolean result = true;
        for (int i = 0; i < jComboBox1.getItemCount(); i++) {
            Vector tmp = ((Fragment)jComboBox1.getItemAt(i)).getTable();
            for (int j = 0; j < tmp.size(); j++) {
                if (tmp.elementAt(j) instanceof Table) {
                    if (((Table)tmp.elementAt(j)).getCondition().equals("")) {
                        result = false;
                        break;
                    }
                } else {
                    if (((Fragment)tmp.elementAt(j)).getCondition().equals("")) {
                        result = false;
                        break;
                    }
                }
            }
            if (!result) {
                break;
            }
        }
        return result;
    }

    public boolean isInit() {
        if (conn != null) {
            return true;
        } else {
            return false;
        }
    }
}
