package project1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.tree.DefaultMutableTreeNode;


public class CreateFragment extends JPanel {
    private JButton jButton1 = new JButton();
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JComboBox jComboBox1 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JComboBox jComboBox3 = new JComboBox();
    protected CreateConnection conn = null;
    private JTable jTable1; // = new JTable();
    private JLabel jLabel5 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JComboBox jComboBox4 = new JComboBox();
    private JButton jButton2 = new JButton();
    private DynamicTree treePanel;
    private QueryTableModel qtm = new QueryTableModel();
    private JLabel jLabel8 = new JLabel();
    private JComboBox jComboBox5 = new JComboBox();
    private Vector tableInTree = new Vector();
    private Vector fragInTree = new Vector();
    private JLabel jLabel9 = new JLabel();
    private JButton jButton3 = new JButton();
    private JLabel jLabel10 = new JLabel();
    private JComboBox jComboBox6 = new JComboBox();
    private ResultSet tmpRes;

    public CreateFragment() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {

        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        
        JTable table = new JTable(qtm);
        JScrollPane scrollpane = new JScrollPane(table);
        scrollpane.setBounds(new Rectangle(440, 300, 335, 170));
        jLabel10.setText(" Fragment : ");
        jLabel10.setBounds(new Rectangle(75, 240, 75, 15));
        jLabel10.setToolTipText("null");
        jComboBox6.setBounds(new Rectangle(150, 240, 155, 20));
        jLabel9.setText("Set Fragment Type");
        jLabel9.setBounds(new Rectangle(75, 150, 125, 15));
        jLabel9.setFont(new Font("Tahoma", 1, 12));
        jButton3.setText("Set");
        jButton3.setBounds(new Rectangle(325, 235, 70, 25));
        jButton3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton3_actionPerformed(e);
                    }
                });
        jLabel8.setText("Add to Fragment : ");
        jLabel8.setBounds(new Rectangle(75, 105, 125, 15));
        jComboBox5.setBounds(new Rectangle(180, 100, 125, 20));
        jButton1.setText("Create");
        jButton1.setBounds(new Rectangle(320, 100, 71, 23));
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jLabel1.setText("Fragment Creation");
        jLabel1.setBounds(new Rectangle(75, 15, 125, 15));
        jLabel1.setFont(new Font("Tahoma", 1, 12));
        jLabel2.setText("Type :");
        jLabel2.setBounds(new Rectangle(75, 200, 35, 15));
        jComboBox1.setBounds(new Rectangle(150, 195, 155, 20));
        jComboBox1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox1_actionPerformed(e);
                    }
                });
        jComboBox2.setBounds(new Rectangle(150, 325, 230, 20));
        jComboBox2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox2_actionPerformed(e);
                    }
                });
        jLabel3.setText("Database : ");
        jLabel3.setBounds(new Rectangle(75, 325, 65, 15));
        jLabel4.setText("Table : ");
        jLabel4.setBounds(new Rectangle(75, 370, 70, 15));
        jComboBox3.setBounds(new Rectangle(150, 370, 230, 20));
        jComboBox3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jComboBox3_actionPerformed(e);
                    }
                });
        jLabel5.setText("Fragment Name : ");
        jLabel5.setBounds(new Rectangle(75, 60, 95, 15));
        jTextField1.setBounds(new Rectangle(180, 60, 210, 20));
        jLabel6.setText("Add Table to Fragment :");
        jLabel6.setBounds(new Rectangle(75, 285, 205, 15));
        jLabel6.setFont(new Font("Tahoma", 1, 12));
        jLabel7.setText("Add to Fragment : ");
        jLabel7.setBounds(new Rectangle(75, 415, 125, 15));
        jComboBox4.setBounds(new Rectangle(180, 415, 200, 20));
        jButton2.setText("Add");
        jButton2.setBounds(new Rectangle(305, 460, 73, 22));
        jButton2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton2_actionPerformed(e);
                    }
                });
        jComboBox1.addItem("Vertical");
        jComboBox1.addItem("Horizontal");
        Fragment root = new Fragment();
        root.setName("Global");
        treePanel = new DynamicTree(root);
        treePanel.setBounds(new Rectangle(440, 60, 335, 205));
        treePanel.setPreferredSize(new Dimension(300, 150));
        jComboBox4.addItem(treePanel.getRootNode());
        jComboBox5.addItem(treePanel.getRootNode());
        this.add(jComboBox6, null);
        this.add(jLabel10, null);
        this.add(jButton3, null);
        this.add(jLabel9, null);
        this.add(jComboBox5, null);
        this.add(jLabel8, null);
        this.add(treePanel, BorderLayout.CENTER);
        this.add(jButton2, null);
        this.add(jComboBox4, null);
        this.add(jLabel7, null);
        this.add(jLabel6, null);
        this.add(jTextField1, null);
        this.add(jLabel5, null);
        this.add(scrollpane, null);
        this.add(jComboBox3, null);
        this.add(jLabel4, null);
        this.add(jLabel3, null);
        this.add(jComboBox2, null);
        this.add(jComboBox1, null);
        this.add(jLabel2, null);
        this.add(jLabel1, null);
        this.add(jButton1, null);
        jComboBox6.addItem(treePanel.getRootNode());


    }

    // Set DB Connection
    public void setConn(CreateConnection newconn) {
        this.conn = newconn;
    }

    // Init ComboBox Value ( DBLink , Table , Column , Fragment Type )
    public void setup() throws SQLException {
        if (conn != null && conn.Create()) {
            tableInTree.clear();
            fragInTree.clear();
            jComboBox2.removeAllItems();
            jComboBox3.removeAllItems();
            jComboBox4.removeAllItems();
            jComboBox5.removeAllItems();
            jComboBox6.removeAllItems();
            treePanel.clear();
            jComboBox4.addItem(treePanel.getRootNode());
            jComboBox5.addItem(treePanel.getRootNode());
            jComboBox6.addItem(treePanel.getRootNode());
            jComboBox2.addItem(conn.getSid().toUpperCase() + "." + 
                               conn.getHostname().toUpperCase());
            ResultSet result = 
                conn.CreateStatement("select * from all_db_links");
            try {
                while (result.next()) {

                    jComboBox2.addItem(result.getString(2).toUpperCase());
                    //System.out.println (result.getString (2));
                }
            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

                System.out.println("Error Can't get data");
            }

        }
    }

    private void jComboBox1_actionPerformed(ActionEvent e) {
    }

    private void jComboBox2_actionPerformed(ActionEvent e) {
        // System.out.println("Combo2 " + e.getActionCommand());
        if (conn != null && e.getActionCommand() == "comboBoxChanged" && 
            jComboBox2.getItemCount() != 0) {
            jComboBox3.removeAllItems();
            //jComboBox2.addItem(conn.getSid().toUpperCase() + "."+ conn.getHostname().toUpperCase());

            try {
                ResultSet result = 
                    conn.CreateStatement("select TABLE_NAME from USER_TABLES@" + 
                                         jComboBox2.getSelectedItem());
                //System.out.println("select TABLE_NAME from USER_TABLES@" + jComboBox2.getSelectedItem());
                while (result.next()) {

                    jComboBox3.addItem(result.getString(1).toUpperCase());
                    //System.out.println (result.getString (1));
                }
            } catch (SQLException f) {
                //System.out.println("Error Can't get data");
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

                System.out.println(f.getMessage());
            }

        }
    }

    private void jComboBox3_actionPerformed(ActionEvent e) {
        //System.out.println("Combo3 " +e.getActionCommand());
        if (conn != null && jComboBox3.getSelectedItem() != null && 
            e.getActionCommand() == "comboBoxChanged") {
            // Vector columnNames = new Vector();
            //Vector data = new Vector();

            System.out.println(jComboBox3.getSelectedItem());
            ResultSet result;
            try {
                result = 
                        conn.CreateStatement("select COLUMN_NAME , DATA_TYPE from USER_TAB_COLUMNS@" + 
                                             jComboBox2.getSelectedItem() + 
                                             " WHERE TABLE_NAME = '" + 
                                             jComboBox3.getSelectedItem() + 
                                             "'");

                //String str = "select COLUMN_NAME , DATA_TYPE from USER_TAB_COLUMNS@" + jComboBox2.getSelectedItem() +  " WHERE TABLE_NAME = '" +jComboBox3.getSelectedItem() +"'";
                //System.out.println(str);

                //tmpRes = result;

                qtm.setQuery(result);
            } catch (SQLException f) {
                JOptionPane.showMessageDialog(this, f.getMessage(), "Error", 
                                              0);

            }

        }
    }

    // Create Fragment
    private void jButton1_actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode tmp;
        Fragment fragtmp;

        if (treePanel == null) {

        } else {
            fragtmp = new Fragment();
            fragtmp.setName(jTextField1.getText().toUpperCase());
            boolean chk = true;
            //System.out.println(fragInTree.size());
            // Check For Add Exist Fragment
            for (int i = 0; i < fragInTree.size(); i++) {
                if (fragInTree.elementAt(i).toString().equals(fragtmp.toString()))
                    chk = false;
            }
            if (jTextField1.getText().toUpperCase().equals("")) {
                chk = false;
            }
            if (chk) {
                if (jComboBox5.getSelectedIndex() == 0) {
                    //tmp = treePanel.addObject(null,jTextField1.getText() + " : " + jComboBox1.getSelectedItem());
                    tmp = treePanel.addObject(null, fragtmp);
                    //tmp = treePanel.addObject(null,"Global " + treePanel.getRootNode().getChildCount() + " : " + jTextField1.getText());

                } else {
                    tmp = 
treePanel.addObject((DefaultMutableTreeNode)jComboBox5.getSelectedItem(), 
                    fragtmp);
                    //tmp = treePanel.addObject((DefaultMutableTreeNode)jComboBox5.getSelectedItem(),jComboBox5.getSelectedItem().toString() + " " + treePanel.getChildCount((DefaultMutableTreeNode)jComboBox5.getSelectedItem())  + " : " + jTextField1.getText());

                }
                treePanel.expandAll();
                jComboBox4.addItem(tmp);
                jComboBox5.addItem(tmp);
                jComboBox6.addItem(tmp);
                fragInTree.addElement(fragtmp);
            } else {
                System.out.println("fragment Exist");
            }
        }
        if (jComboBox6.getItemCount() > 0 && jButton3.isEnabled() == false) {
            jButton3.setEnabled(true);
        }


    }

    // Add Table To Fragment
    private void jButton2_actionPerformed(ActionEvent e) {
        boolean chk = true;
        int conditionNo = 0;
        Table tableTMP = 
            new Table(jComboBox3.getSelectedItem().toString(), jComboBox2.getSelectedItem().toString());
        try {
            ResultSet result = 
                conn.CreateStatement("select COLUMN_NAME , DATA_TYPE from USER_TAB_COLUMNS@" + 
                                     jComboBox2.getSelectedItem() + 
                                     " WHERE TABLE_NAME = '" + 
                                     jComboBox3.getSelectedItem() + "'");

            // tmpRes.beforeFirst();
            tableTMP.addCol(result);
            String sqlpk = 
                "select column_name from all_cons_columns@" + tableTMP.getSite() + 
                " where table_name = '" + tableTMP.getName() + "'" + 
                " and constraint_name in " + " ( select constraint_name" + 
                "  from all_constraints@" + tableTMP.getSite() + 
                "  where table_name = '" + tableTMP.getName() + "'" + 
                "  and constraint_type = 'P'" + "  )";
            ResultSet resultpk = conn.CreateStatement(sqlpk);
            tableTMP.addPK(resultpk);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", 0);
        }
        //Check for Set Type of Fragmentsaaa
        if ((((Fragment)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getUserObject()).getType().equals(""))) {
            //System.out.println(tableInTree.size());
            // Check For Add Exist Table in Fragment
            conditionNo = 1;
            //System.out.println("Please set Type of Fragment before Add Table to fragmant");
        }

        for (int i = 0; i < tableInTree.size(); i++) {
            if (tableInTree.elementAt(i).toString().equals(jComboBox3.getSelectedItem() + 
                                                           "@" + 
                                                           jComboBox2.getSelectedItem()) && 
                conditionNo == 0) {
                chk = false;
                conditionNo = 2;
                //System.out.println("Table Used");
            }
        }
        if (treePanel.isExist((DefaultMutableTreeNode)jComboBox4.getSelectedItem(), 
                              jComboBox3.getSelectedItem() + "@" + 
                              jComboBox2.getSelectedItem()) && 
            conditionNo == 0) {
            conditionNo = 3;
            //System.out.println("User Insert Same Table in " + jComboBox4.getSelectedItem());
        }
        if (((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildCount() > 
            0) {
            boolean chkTable = true;
            int ii = 0;
            while (chkTable && 
                   ii < ((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildCount()) {
                //System.out.println(((DefaultMutableTreeNode)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildAt(ii)).getUserObject().getClass());
                if (((DefaultMutableTreeNode)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildAt(ii)).getUserObject() instanceof 
                    Table) {
                    chkTable = false;
                }
                ii++;
            }
            ii--;
            if (!chkTable) {
                Table t1 = 
                    (Table)((DefaultMutableTreeNode)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildAt(ii)).getUserObject();
                // Vertical
                if (((Fragment)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getUserObject()).getType() == 
                    jComboBox1.getItemAt(0)) {
                    String sql1 = 
                        "select column_name from all_cons_columns@" + tableTMP.getSite() + 
                        " where table_name = '" + tableTMP.getName() + "'" + 
                        " and constraint_name in " + 
                        " ( select constraint_name" + 
                        "  from all_constraints@" + tableTMP.getSite() + 
                        "  where table_name = '" + tableTMP.getName() + "'" + 
                        "  and constraint_type = 'P'" + "  )";
                    String sql2 = 
                        "select column_name from all_cons_columns@" + t1.getSite() + 
                        " where table_name = '" + t1.getName() + "'" + 
                        " and constraint_name in " + 
                        " ( select constraint_name" + 
                        "  from all_constraints@" + t1.getSite() + 
                        "  where table_name = '" + t1.getName() + "'" + 
                        "  and constraint_type = 'P'" + "  )";
                    try {
                        ResultSet re1 = conn.CreateStatement(sql1);
                        ResultSet re2 = conn.CreateStatement(sql2);


                        if (!Table.isSamePK(re1, tableTMP, re2, t1)) {
                            conditionNo = 4;
                        }
                    } catch (SQLException f) {
                        JOptionPane.showMessageDialog(this, f.getMessage(), 
                                                      "Error", 0);
                        System.out.println(f.getMessage());
                        conditionNo = 4;
                    }
                }
                // Horizontal
                else {
                    if (!((Table)((DefaultMutableTreeNode)((DefaultMutableTreeNode)jComboBox4.getSelectedItem()).getChildAt(ii)).getUserObject()).isSameDDL(tableTMP)) {
                        conditionNo = 4;
                    }

                }
            }

        }
        if (conditionNo == 0) {
            //treePanel.addObject((DefaultMutableTreeNode)jComboBox4.getSelectedItem(),jComboBox4.getSelectedItem().toString() + " " + treePanel.getChildCount((DefaultMutableTreeNode)jComboBox4.getSelectedItem()) + " : "+ jComboBox3.getSelectedItem() + "@" + jComboBox2.getSelectedItem());
            // treePanel.addObject((DefaultMutableTreeNode)jComboBox4.getSelectedItem(), jComboBox3.getSelectedItem() + "@" + jComboBox2.getSelectedItem());

            treePanel.addObject((DefaultMutableTreeNode)jComboBox4.getSelectedItem(), 
                                tableTMP);
            treePanel.expandAll();
            tableInTree.addElement(jComboBox3.getSelectedItem() + "@" + 
                                   jComboBox2.getSelectedItem());
        } else {
            switch (conditionNo) {
            case 1:
                System.out.println("Please set Type of Fragment before Add Table to fragmant");
                JOptionPane.showMessageDialog(this, 
                                              "Please set Type of Fragment before Add Table to fragmant", 
                                              "Error", 0);
                return;
            case 2:
                System.out.println("Table Used");
                JOptionPane.showMessageDialog(this, "Table are Used", "Error", 
                                              0);
                return;
            case 3:
                System.out.println("User Insert Same Table in " + 
                                   jComboBox4.getSelectedItem());
                JOptionPane.showMessageDialog(this, 
                                              "User Insert Same Table in " + 
                                              jComboBox4.getSelectedItem(), 
                                              "Error", 0);
                return;
            case 4:
                System.out.println("Table can't add to this Fragment (wrong structure)");
                JOptionPane.showMessageDialog(this, 
                                              "Table can't add to this Fragment (wrong structure)", 
                                              "Error", 0);
                return;
            }

        }

    }

    // Set Type
    private void jButton3_actionPerformed(ActionEvent e) {
        if (jComboBox6.getSelectedItem() != null) {
            DefaultMutableTreeNode tmp;
            boolean chk = true;
            //System.out.println(fragInTree.size());
            if (jComboBox6.getSelectedItem().equals(treePanel.getRootNode())) {
                ((Fragment)treePanel.getRootNode().getUserObject()).setType(jComboBox1.getSelectedItem().toString());
            } else {
                ((Fragment)((DefaultMutableTreeNode)jComboBox6.getSelectedItem()).getUserObject()).setType(jComboBox1.getSelectedItem().toString());
            }
            jComboBox6.removeItemAt(jComboBox6.getSelectedIndex());
            jComboBox4.repaint();
            jComboBox5.repaint();
            jComboBox6.repaint();
            treePanel.repaint();
            treePanel.expandAll();
            if (jComboBox6.getItemCount() == 0) {
                jButton3.setEnabled(false);
            }
        }

    }

    // Check All Data Valid
    public boolean isValid() {
        boolean re = true;
        for (int i = 0; i < jComboBox4.getItemCount(); i++) {
            if (((DefaultMutableTreeNode)jComboBox4.getItemAt(i)).getChildCount() < 
                2) {
                re = false;
            }
        }
        return re;
    }

    public DynamicTree getTree() {
        return treePanel;
    }

    public Object getAllFragment() {
        Fragment frag = new Fragment();
        DefaultMutableTreeNode tmp;
        tmp = treePanel.getRootNode();

        frag.getCopy((Fragment)((DefaultMutableTreeNode)jComboBox4.getItemAt(0)).getUserObject());

        frag = getFragment(frag, tmp);
        return frag;
    }

    public Fragment getFragment(Fragment parent, DefaultMutableTreeNode in) {
        for (int i = 0; i < in.getChildCount(); i++) {
            if (in.getChildAt(i).isLeaf()) {
                Table tmp = new Table();
                tmp.getCopy((Table)((DefaultMutableTreeNode)in.getChildAt(i)).getUserObject());
                parent.addTable(tmp);
            } else {
                Fragment t = new Fragment();
                t.getCopy((Fragment)((DefaultMutableTreeNode)in.getChildAt(i)).getUserObject());
                t = getFragment(t, (DefaultMutableTreeNode)in.getChildAt(i));
                parent.addTable((Fragment)t);

            }

        }
        return parent;
    }

    public Fragment getGlobalFrag() {
        return (Fragment)((DefaultMutableTreeNode)jComboBox4.getItemAt(0)).getUserObject();
    }
}
