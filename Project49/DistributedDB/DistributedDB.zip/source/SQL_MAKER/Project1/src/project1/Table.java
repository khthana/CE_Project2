package project1;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Vector;


public class Table {
    private String name;
    private String site;
    private String synonym;
    private String condition = "";
    private Vector columnName;
    private Vector columnDataType;
    private Vector pk;

    public Table() {
        columnName = new Vector();
        columnDataType = new Vector();
        synonym = "";
        pk = new Vector();
    }

    public Table(String n, String s) {
        setName(n);
        setSite(s);
        columnName = new Vector();
        columnDataType = new Vector();
        pk = new Vector();
        synonym = "";
    }

    public void setName(String n) {
        name = n;
    }

    public void setSynonym(String n) {
        synonym = n;
    }

    public void setcondition(String c) {
        condition = c;
    }

    public void setSite(String s) {
        site = s;
    }

    public void addCol(ResultSet rs) throws SQLException {

        while (rs.next()) {
            String[] record = new String[2];
            for (int i = 0; i < 2; i++) {
                record[i] = rs.getString(i + 1);
            }
            addCol(record[0], record[1]);
        }

    }

    public boolean isSameDDL(Table in) {
        boolean re = true;
        boolean tmp;
        if (this.getColCount() != in.getColCount()) {
            re = false;

        } else {
            for (int i = 0; i < this.getColCount(); i++) {
                tmp = false;
                for (int j = 0; j < in.getColCount(); j++) {

                    if (this.getColNameAt(j).toString().equals(in.getColNameAt(i).toString()) && 
                        this.getColTypeAt(j).toString().equals(in.getColTypeAt(i).toString())) {
                        tmp = true;
                        //   System.out.println(this.getColNameAt(j) + "::" + in.getColNameAt(i) );
                        //   System.out.println(this.getColTypeAt(j) + "::" + in.getColTypeAt(i) );
                    }
                }
                if (tmp == false) {
                    re = false;
                    return re;
                }

            }
        }
        return re;
    }

    public static boolean isSamePK(ResultSet rTable1, Table t1, 
                                   ResultSet rTable2, 
                                   Table t2) throws SQLException {
        Vector tmp1 = new Vector();
        Vector tmp2 = new Vector();
        boolean tmp;
        boolean re = true;
        while (rTable1.next()) {
            String[] record = new String[2];
            record[0] = rTable1.getString(1);
            record[1] = t1.getColType(record[0]);
            tmp1.addElement(record);
        }
        while (rTable2.next()) {
            String[] record = new String[2];
            record[0] = rTable2.getString(1);
            record[1] = t2.getColType(record[0]);
            tmp2.addElement(record);
        }
        if (tmp1.size() != tmp2.size()) {
            re = false;

        } else {
            for (int i = 0; i < tmp1.size(); i++) {
                tmp = false;
                for (int j = 0; j < tmp2.size(); j++) {
                    String[] tt1 = (String[])tmp1.elementAt(i);
                    String[] tt2 = (String[])tmp2.elementAt(j);

                    if (tt1[0].equals(tt2[0]) && tt1[1].equals(tt2[1])) {
                        tmp = true;
                        //   System.out.println(this.getColNameAt(j) + "::" + in.getColNameAt(i) );
                        //   System.out.println(this.getColTypeAt(j) + "::" + in.getColTypeAt(i) );
                    }
                }
                if (tmp == false) {
                    re = false;
                    return re;
                }

            }
        }
        return re;
    }

    public void addCol(String colName, String colType) {
        columnName.addElement(colName);
        columnDataType.addElement(colType);
    }

    public String getName() {
        return name;
    }

    public String getSite() {
        return site;
    }

    public String getCondition() {
        return condition;
    }

    public String getSynonym() {
        return synonym;
    }

    public String getColType(String ColName) {
        String re = "";
        for (int i = 0; i < columnName.size(); i++) {
            if (columnName.elementAt(i).toString().equals(ColName))
                re = columnDataType.elementAt(i).toString();
        }
        return re;

    }

    public int getColCount() {
        return columnName.size();
    }

    public String toString() {
        return name + "@" + site;
    }

    public String getColNameAt(int index) {
        return columnName.elementAt(index).toString();
    }

    public String getColTypeAt(int index) {
        return columnDataType.elementAt(index).toString();

    }

    public Vector getColumnName() {
        return columnName;
    }

    public Vector getColumnDataType() {
        return columnDataType;
    }

    public void addPK(ResultSet rs) throws SQLException {
        while (rs.next()) {
            pk.addElement(rs.getString(1));

        }

    }

    public void addPK(Vector in) {
        pk = in;
    }

    public Vector getPK() {
        return pk;
    }

    public void getCopy(Table in) {
        this.name = in.getName();
        this.site = in.getSite();
        this.condition = in.getCondition();
        this.columnName = (Vector)in.getColumnName().clone();
        this.columnDataType = (Vector)in.getColumnDataType().clone();
        this.pk = in.getPK();
    }

    public boolean hasCol(String colName) {
        boolean re = false;
        for (int i = 0; i < columnName.size(); i++) {
            if (columnName.elementAt(i).toString().equals(colName)) {
                re = true;
                break;
            }
        }
        return re;
    }

    public boolean isPK(String colName) {
        for (int i = 0; i < pk.size(); i++) {
            if (pk.elementAt(i).toString().equals(colName)) {
                return true;
            }
        }
        return false;
    }
}
