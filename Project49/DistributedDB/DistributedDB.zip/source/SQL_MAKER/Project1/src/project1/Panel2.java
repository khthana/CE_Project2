package project1;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Panel2 extends JPanel {
    private JLabel jLabel1 = new JLabel();
    private JButton jButton1 = new JButton();
    private ImageIcon b1;
    private ImageIcon b2;
    private JButton jButton2 = new JButton();

    public Panel2() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout(null);
        this.setSize(new Dimension(795, 500));
        jLabel1.setText("Menu");
        jLabel1.setBounds(new Rectangle(360, 80, 50, 40));
        jLabel1.setFont(new Font("Tahoma", 1, 16));
        jButton1.setText("Create New Global Table");
        jButton1.setBounds(new Rectangle(285, 180, 205, 40));
        b1 = new ImageIcon((URL)getResource("database-add.png"));
        b2 = new ImageIcon((URL)getResource("script-add.png"));
        //System.out.println(b1.getDescription());
        //jButton1.setIcon();
        jButton1.setIcon(b1);
        jButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton1_actionPerformed(e);
                    }
                });
        jButton2.setIcon(b2);
        jButton2.setText("Create New Foreign Key ");
        jButton2.setBounds(new Rectangle(285, 280, 205, 40));
        jButton2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jButton2_actionPerformed(e);
                    }
                });
        this.add(jButton2, null);
        this.add(jButton1, null);
        this.add(jLabel1, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        ((Panel3)this.getParent()).createglobal();
    }

    private void jButton2_actionPerformed(ActionEvent e) {
        ((Panel3)this.getParent()).createFK();
    }
    
    // Get Icon Picture 
    private Object getResource(String key) {

        URL url = null;
        String name = key;

        if (name != null) {

            try {
                Class c = Class.forName("project1.Panel2");
                url = c.getResource(name);
            } catch (ClassNotFoundException cnfe) {
                System.err.println(cnfe);
            }
            return url;
        } else
            return null;

    }
     
}
