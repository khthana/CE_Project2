package project1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.OracleDriver;


public class CreateConnection {

    private String hostname, port, sid, user, pass;
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet rset = null;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public CreateConnection(String hostname, String port, String sid, 
                            String user, String pass) {
        this.setHostname(hostname);
        this.setPort(port);
        this.setSid(sid);
        this.setUser(user);
        this.setPass(pass);
    }


    public boolean Create() throws SQLException {
        //System.out.println("jdbc:oracle:thin:"+ hostname +":"+ port +":"+ sid + "//" +user + "//"+ pass);
        DriverManager.registerDriver(new OracleDriver());
        conn = 
DriverManager.getConnection("jdbc:oracle:thin:@" + hostname + ":" + port + 
                            ":" + sid, user, pass);

        if (conn != null) {
            return true;
        } else {
            System.out.println("Error Occur");
            return false;
        }
    }

    public void CloseConnection() throws SQLException {
        conn.close();
    }

    public ResultSet CreateStatement(String str) throws SQLException {
        ResultSet res = null;
        ;
        //  try {
        stmt = conn.createStatement();
        res = stmt.executeQuery(str);
        System.out.println(str + ": : " + this.getHostname());

        // } catch (SQLException e) {
        //System.out.println("Create Statement Error");
        //System.out.println(e.getMessage());
        //}
        return res;
    }

    public int CreateDDLStatement(String str) throws SQLException {

        stmt = conn.createStatement();

        System.out.println("DDL : " + str + ": : " + this.getHostname());
        int c = stmt.executeUpdate(str);
        return c;
    }

    public void ShowResult() {
        try {
            while (rset.next())
                System.out.println(rset.getString(1));
        } catch (SQLException e) {
            System.out.println("Show Result Error");
        }

    }

    public String getDB() {
        return sid.toUpperCase() + "." + hostname.toUpperCase();
    }


}
