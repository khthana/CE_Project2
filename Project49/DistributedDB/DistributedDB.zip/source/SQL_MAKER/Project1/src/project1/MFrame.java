package project1;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class MFrame extends JFrame {
    private BorderLayout borderLayout1 = new BorderLayout();


    public MFrame() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(borderLayout1);
        //this.setUndecorated(true);
        this.setSize(new Dimension(800, 600));
        //       GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(this);;


        this.setTitle("Distributed Database Helper");
        JPanel mainPanel = new Panel3();
        this.add(mainPanel, BorderLayout.CENTER);

    }


}
