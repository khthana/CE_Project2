// FiT2.h : main header file for the FIT2 application
//
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <winuser.h>

#include <crtdbg.h>  // for ASSERT macro

//=============================================================================
// MISC CONSTANTS
//=============================================================================
#define LAUNCH_WAIT_TIME                   5000 // sleep time = 5 seconds
#define EVENT_WAIT_TIME                    5   // sleep time in ms
#define CAPTIONLENGTH                      32   // length of caption info field
#define WNDCLASSLENGTH                     32   // length of wnd class

//=============================================================================
// ERROR CODES
//=============================================================================

#ifndef NO_ERROR
#define NO_ERROR                           0
#endif
#define ERR_BAD_LAUNCH                     1
#define ERR_INVALID_CMD_LINE               2
#define ERR_INVALID_ARG                    3
#define ERR_WND_NOT_FOUND                  4
#define ERR_SIZE_FAIL                      5
#define ERR_TOP_LEVEL_NOT_VISIBLE          6
#define ERR_TOP_LEVEL_ZERO_DIM             7
#define ERR_INVALID_PID                    8

// mouse state array indexing
#define LBUTTON                            0
#define RBUTTON                            1

//=============================================================================
// Decls
//=============================================================================

// FUZZ OPTIONS STRUCTURE
//   encapsulates the options given on the command line
typedef struct _FUZZ_OPTIONS {
    BOOL fRandomEvents;           // send fake user events

    BOOL fRandomWin32ViaSendMessage; // use SendMessage API function for tests
    BOOL fRandomWin32ViaPostMessage; // use PostMessage API function for tests
    BOOL fSendWMCommandMessages;    // send only random WM_COMMAND msgs
    BOOL fSendNULLParams;           // use NULL for lparam and wparam in msgs

    DWORD dwNumMessages;            // number of messages to send

    DWORD dwSeed;                   // seed for random number generation

    LPSTR pszAppCmdLine;            // command to use when launching test app
    DWORD dwProcessId;              // process id of process to test
} FUZZ_OPTIONS, *PFUZZ_OPTIONS; 
 
    
//=============================================================================
// Prototypes
//=============================================================================
LONG parseArgs(LONG nNumArgs, LPSTR ppszArgs[], PFUZZ_OPTIONS options);

// launch a process
LONG launchApp(LPSTR pszCommandLine, PROCESS_INFORMATION &pi);

// message sending tests
LONG sendRandomWin32(HWND hwnd, HANDLE hProc, PFUZZ_OPTIONS pOptions);
LONG sendRandomEvents(HWND hwnd, HANDLE hProc, PFUZZ_OPTIONS pOptions);

// fabricated user message helper funcs
LONG generateRandomKeyboardEvent(BOOL *pfKeyStates);
LONG generateRandomMouseEvent(BOOL *pfMouseButtonStates, RECT *pWndDim,
                              DWORD dwScreenHeight, DWORD dwScreenWidth);

// cleaup after the fabricated user message tests
VOID cleanupMouseKeyboardState(VOID);

// determine whether a given key will do unwanted things in the system
BOOL isSystemHotKey(BYTE bVKCode, DWORD dwFlags, BOOL *pfKeyStates);

// command line usage information
VOID printHelp(void);

#if !defined(AFX_FIT2_H__38420E55_6BE2_4A4F_B748_7CB7E3EEE390__INCLUDED_)
#define AFX_FIT2_H__38420E55_6BE2_4A4F_B748_7CB7E3EEE390__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFiT2App:
// See FiT2.cpp for the implementation of this class
//

class CFiT2App : public CWinApp
{
public:
	CFiT2App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiT2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFiT2App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIT2_H__38420E55_6BE2_4A4F_B748_7CB7E3EEE390__INCLUDED_)
