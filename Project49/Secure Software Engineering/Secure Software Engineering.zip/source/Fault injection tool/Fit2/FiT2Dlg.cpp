// FiT2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "FiT2.h"
#include "FiT2Dlg.h"
#include "strsafe.h"

TCHAR g_tszBuffer[1024];

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//=============================================================================
// Function: sendRandomWin32
//     Description:
//         Perform random win32 message test
//     Parameters:
//         hwnd - window to send messages to
//         hProc - handle to the target process
//         pOptions - testing options
//     Return Value:
//         error status
//=============================================================================
LONG sendRandomWin32(HWND hwnd, HANDLE hProc, PFUZZ_OPTIONS pOptions)
{
	TCHAR tszTemp[512];

	// validate params
    _ASSERT(pOptions);

    if (hwnd == INVALID_HANDLE_VALUE)
    {
        return ERR_INVALID_ARG;
    }
    
    // message decls
    UINT Msg = 0;
    UINT wParam = 0;
    UINT lParam = 0;
    
    DWORD dwNumSent = 0;
    DWORD dwNumTimeouts = 0;
    while (dwNumSent < pOptions->dwNumMessages || 0 == pOptions->dwNumMessages)
    {
        // make sure process is still alive
        DWORD dwExitStatus = 0;
        if (0 == GetExitCodeProcess(hProc, &dwExitStatus))
        {
            return ERR_INVALID_ARG;
        }
        else if (STILL_ACTIVE != dwExitStatus)
        {
			/*
            fprintf(stdout, "The target was closed or killed\n");
			*/
			StringCbCat(g_tszBuffer, 1024, TEXT("The target was closed or killed\r\n"));
            break;
        }

        // generate random message type
        do 
        {
            if (pOptions->fSendWMCommandMessages)
                Msg = WM_COMMAND;
            else
                Msg = (UINT) rand();
        
            if (pOptions->fSendNULLParams)
            {
                wParam = NULL;
                lParam = NULL;
            }
            else
            {
                wParam = (UINT) rand();
                lParam = (LONG) rand();
            }
        }
        // don't send close, quit, or destroy msgs
        while (WM_CLOSE == Msg || WM_QUIT == Msg || WM_DESTROY == Msg);
        
        if (pOptions->fRandomWin32ViaPostMessage)
        {
            PostMessage(hwnd, Msg, wParam, lParam);
            dwNumSent++;

        }
        else if (pOptions->fRandomWin32ViaSendMessage)
        {
            // we are also using SendMessageTimeout to avoid any deadlock
            // conditions where the app is waiting for input that will
            // never come because we are waiting for the app to process the 
            // message -- ex. right-click context menus that are popped
            // up by the WM_CONTEXTMENU message
            
            // An Access Violation occasionally occurred in User32.dll 
            // after SendMessage returned.  Documentation in MSDN 
            // indicates this is not just a problem with this app.  
            // The error was very intermittent and not critical, so the 
            // exception is ignored. 
            __try 
            { 
                DWORD dwResult;
                if (FAILED(SendMessageTimeout(hwnd, Msg, wParam, lParam, 
                                              0, 5000, &dwResult)))
                    dwNumTimeouts++;
            } 
            __except(EXCEPTION_EXECUTE_HANDLER) { }

            dwNumSent++;
            
        }

        // send out a status message every 50,000 messages
        if (dwNumSent % 50000 == 0)
        {
            //fprintf(stdout, "Number of messages sent: %d\n", dwNumSent);
			StringCbPrintf(tszTemp, 512, TEXT("Number of messages sent: %d\r\n"), dwNumSent);
			StringCbCat(g_tszBuffer, 1024, tszTemp);
        }

        // let us play nice with other processes and yield
        Sleep(0);
    }
    if (dwNumTimeouts > 0)
	{
			//fprintf(stdout, "Number of timeouts: %d\n", dwNumTimeouts);
			StringCbPrintf(tszTemp, 512, TEXT("Number of timeouts: %d\r\n"), dwNumTimeouts);
			StringCbCat(g_tszBuffer, 1024, tszTemp);
	}
    //fprintf(stdout, "Number of messages sent: %d\n", dwNumSent);
	StringCbPrintf(tszTemp, 512, TEXT("Number of messages sent: %d\r\n"), dwNumSent);
	StringCbCat(g_tszBuffer, 1024, tszTemp);
    return NO_ERROR;

} // end sendRandomWin32

//=============================================================================
// Function: isSystemHotKey
//     Description:
//         determine whether the given key is a system hotkey
//         For the random tests, we don't want to introduce known hotkeys that 
//         will things such as the following:
//             - switch control to another application (ALT-TAB)
//             - close the given window (ALT-F4)
//     Parameters:
//         bVKCode - the virtual key code of the key in question
//         dwFlags - key event flags (up or down essentially, not ext)
//         pfKeyStates - context in which the key event occurs
//                       this is needed to tell if context keys are pressed
//     Return Value:
//         TRUE if the given key event will trigger a system hotkey
//         FALSE otherwise
//=============================================================================
BOOL isSystemHotKey(BYTE bVKCode, DWORD dwFlags, BOOL *pfKeyStates)
{
    // validate params
    _ASSERT(pfKeyStates);

    BOOL fIsHotKey = FALSE;

    switch (bVKCode)
    {
    case VK_TAB: // ALT-TAB
        if (pfKeyStates[VK_MENU]) fIsHotKey = TRUE;
        break;

    case VK_F4: // ALT-F4 & CTRL-F4
        if (pfKeyStates[VK_MENU] || pfKeyStates[VK_CONTROL]) fIsHotKey = TRUE;
        break;

	case VK_F1:   // help
    case VK_LWIN: // anything involving the windows keys 
    case VK_RWIN:
        fIsHotKey = TRUE;
        break;

    case VK_ESCAPE: // CTRL-ESC (start menu) and ALT-ESC (task switch)
        if (pfKeyStates[VK_CONTROL] || pfKeyStates[VK_MENU]) fIsHotKey = TRUE;
        break;

    case VK_CONTROL: // CTRL-ALT
        if (pfKeyStates[VK_MENU]) fIsHotKey = TRUE;
        break;

    case VK_MENU: // ALT-CTRL
        if (pfKeyStates[VK_CONTROL]) fIsHotKey = TRUE;
        break;
    }

    return fIsHotKey;

} // end isSystemHotKey

//=============================================================================
// Function: parseArgs
//     Description:
//         naive parse routine to handle command line arguments
//     Parameters:
//         nNumArgs - number of arguments
//         ppszArgs - array of string arguments
//         options - structure to fill in with command line options
//     Return Value:
//         handle to the window 
//         on failure, INVALID_HANDLE_VALUE will be returned
//=============================================================================
void parseArgs(int pid_f_p,int n_message_f_p,int t_message_f_p,PFUZZ_OPTIONS pOptions)
{
	_ASSERT(pOptions);
	if(t_message_f_p == 1){
		pOptions->fRandomWin32ViaSendMessage = TRUE;
	}else
		if(t_message_f_p == 2){
			pOptions->fRandomWin32ViaPostMessage = TRUE;
		}
	
	pOptions->dwNumMessages = (DWORD) n_message_f_p;
	pOptions->dwProcessId = (DWORD) pid_f_p;
}


//============================Main===========================
//============================Main===========================
//============================Main===========================
//============================Main===========================
//============================Main===========================
//============================Main===========================
//============================Main===========================
int CFiT2Dlg::mainFIT(int pid_f,int n_message_f,int t_message_f)

{
	//AfxMessageBox("hello");
	LONG nErrStatus = NO_ERROR;

    // create and zero out a struct for the fuzz testing options
    //FUZZ_OPTIONS options;
    ZeroMemory(&options, sizeof(FUZZ_OPTIONS));

    parseArgs(pid_f,n_message_f,t_message_f,&options);

    // hide the console window away for the duration of message sending
    // to ensure that the test environment is as sterile as possible
    // i.e. there is no possibility of interaction with windows other than
    // the system windows which are common to all systems (e.g. desktop, etc)
	HWND hConsoleWindow = ::GetForegroundWindow();

    WINDOWPLACEMENT wp;
    ZeroMemory(&wp, sizeof(WINDOWPLACEMENT));
    wp.length = sizeof(WINDOWPLACEMENT);
	::GetWindowPlacement(hConsoleWindow, &wp);
    //wp.showCmd = SW_MINIMIZE;
    ::SetWindowPlacement(hConsoleWindow, &wp);

    //================================================
    // START TARGET APPLICATION
    //================================================

    // fire up the target application
    HANDLE hTargetProcess = INVALID_HANDLE_VALUE;
    // pid spec'd on command line

        // get process information
        hTargetProcess = OpenProcess(PROCESS_QUERY_INFORMATION, 
                                     FALSE, 
                                     options.dwProcessId);
		if (NULL == hTargetProcess)
        {
            fprintf(stderr, "Unable to get process information for pid %d\n", options.dwProcessId);

            // done with the tests, restore the console window
            wp.showCmd = SW_RESTORE;
            ::SetWindowPlacement(hConsoleWindow, &wp);

            return ERR_INVALID_PID;
        }

    
    //================================================
    // GET WINDOW INFO FOR TARGET APPLICATION
    //================================================

    // get the top level window for the target application
    pWindowList = new WindowList();
    pWindowList->genWindowList(options.dwProcessId);

    // make sure that we found at least 1 window
    LONG nWindowCount = pWindowList->numWindows();
    if (0 == nWindowCount)
    {
        fprintf(stderr, "Unable to get top level window for process id %d\n", options.dwProcessId);
        
        // done with the tests, restore the console window
        wp.showCmd = SW_RESTORE;
        ::SetWindowPlacement(hConsoleWindow, &wp);    

        return ERR_WND_NOT_FOUND;
    }

    HWND hTargetWindow = (HWND) INVALID_HANDLE_VALUE;
    LONG nTargetIndex = 1;

    // if there are more than 1 top-level windows associated with 
    // this process, present the tester with a list to choose from, 
    // since we will be sending messages to only 1 top level window
    if (nWindowCount > 1)
    {
		/*
        // pop the console window back up
        wp.showCmd = SW_RESTORE;
        ::SetWindowPlacement(hConsoleWindow, &wp);

        // present list of entries to choose from
		//m_edit_pane.SetWindowText("More than one top-level window found for process options.dwProcessId");
	
        fprintf(stdout, "\n\nMore than one top-level window found for process %d\n", options.dwProcessId);
        fprintf(stdout, "Choose target for tests:\n\n");

        fprintf(stdout, "%2s  %-25.25s  %-20.20s  (%-10.10s) (%-10.10s)\n", 
                "#",
                "Window caption",
                "Window class",
                "Upper Left",
                "Lower Rt.");

        fprintf(stdout, "%2s  %-25.25s  %-20.20s  %-12s %-12s\n", 
                "--",
                "-------------------------",
                "--------------------",
                "------------",
                "------------");

        // print the list of windows
        for (int i = 1; i <= nWindowCount; i++)
        {
            WindowSpec *pCurr = pWindowList->getWindowAt(i);
            
            fprintf(stdout, "%2d. %-25.25s  %-20.20s  (%-4d, %-4d) (%-4d, %-4d)\n", 
                    i, 
                    pCurr->pszCaption,
                    pCurr->pszWndClassName,
                    pCurr->rect.left,
                    pCurr->rect.top,
                    pCurr->rect.right,
                    pCurr->rect.bottom
               );
        }

        // read the user input
        do 
        {
            fprintf(stdout, "\nEnter # of choice: ");
            fflush(stdin);
        } while ((0 == fscanf(stdin, "%d", &nTargetIndex)) ||
                 (nTargetIndex < 0) || 
                 (nTargetIndex > nWindowCount));
        
        // hide the console window again
        //wp.showCmd = SW_MINIMIZE; 
        ::SetWindowPlacement(hConsoleWindow, &wp);
		*/

		// Update ListCtrl
		CListCtrl* pListCtrl = (CListCtrl*)GetDlgItem(IDC_LIST1);
		pListCtrl->DeleteAllItems();

        for (int i = 1; i <= nWindowCount; i++)
        {
            WindowSpec *pCurr = pWindowList->getWindowAt(i);
			
			LVITEM lvItem;
			ZeroMemory(&lvItem, sizeof(LVITEM));	// Zero struct's members.
			lvItem.mask			= LVIF_TEXT;		// Text Style
			lvItem.cchTextMax	= 32;				// Max size of test
			lvItem.iItem		= i - 1;

			TCHAR tszBuffer[32];
			lvItem.iSubItem     = 0;
			lvItem.pszText		= tszBuffer;
			StringCbPrintf(tszBuffer, 32, TEXT("%2d"), i);
			pListCtrl->InsertItem(&lvItem);

			lvItem.iSubItem		= 4;				// Choose item
			StringCbPrintf(tszBuffer, 32, TEXT("%-25.25s"), pCurr->pszCaption);
			pListCtrl->SetItem(&lvItem);

			lvItem.iSubItem		= 3;				// Choose item
			StringCbPrintf(tszBuffer, 32, TEXT("%-20.20s"), pCurr->pszWndClassName);
			pListCtrl->SetItem(&lvItem);

			lvItem.iSubItem		= 2;				// Choose item
			StringCbPrintf(tszBuffer, 32, TEXT("(%-4d, %-4d)"), pCurr->rect.left, pCurr->rect.top);
			pListCtrl->SetItem(&lvItem);

			lvItem.iSubItem		= 1;				// Choose item
			StringCbPrintf(tszBuffer, 32, TEXT("(%-4d, %-4d)"), pCurr->rect.bottom, pCurr->rect.right);
			pListCtrl->SetItem(&lvItem);
        }
		pListCtrl->RedrawWindow();

		/*
        // read the user input
        do 
        {
            fprintf(stdout, "\nEnter # of choice: ");
            fflush(stdin);
        } while ((0 == fscanf(stdin, "%d", &nTargetIndex)) ||
                 (nTargetIndex < 0) || 
                 (nTargetIndex > nWindowCount));
		*/
    }

	/*
    // set the target window
    hTargetWindow = pWindowList->getWindowAt(nTargetIndex)->hWnd;

    //================================================
    // DO MESSAGE SENDING
    //================================================

    // seed the random number generator
    if (0 == options.dwSeed)
    {
        srand((unsigned)time(NULL));
    }
    else
    {
        srand(options.dwSeed);
    }

    // do message sending
    fprintf(stdout, "Sending to pid %d, hwnd %#x\n", 
            options.dwProcessId, 
            hTargetWindow);
   
	sendRandomWin32(hTargetWindow, hTargetProcess, &options);
    

    // done with the tests, restore the console window
    wp.showCmd = SW_RESTORE;
    ::SetWindowPlacement(hConsoleWindow, &wp);

    fprintf(stdout, "Test complete\n");
	*/

	m_hTargetWindow = hTargetWindow;
	m_hTargetProcess = hTargetProcess;

    return NO_ERROR;

}// end of main
//============================end of Main===========================
//============================end of Main===========================
//============================end of Main===========================
//============================end of Main===========================
//============================end of Main===========================
//============================end of Main===========================
//============================end of Main===========================

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiT2Dlg dialog

CFiT2Dlg::CFiT2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFiT2Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFiT2Dlg)
	m_operation = -1;
	m_edit_pane = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFiT2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFiT2Dlg)
	DDX_Control(pDX, IDC_EDIT2, m_edit_number);
	DDX_Control(pDX, IDC_EDIT1, m_edit_pid);
	DDX_Radio(pDX, IDC_RADIO1, m_operation);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFiT2Dlg, CDialog)
	//{{AFX_MSG_MAP(CFiT2Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_BUTTON1, OnSendMessageClicked)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON2, &CFiT2Dlg::OnBnClickedButton2)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiT2Dlg message handlers

BOOL CFiT2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	// List Control

	TCHAR tszBuffer[64];

    CListCtrl* pListCtrl = (CListCtrl*)GetDlgItem(IDC_LIST1);
    pListCtrl->SetExtendedStyle(LVS_EX_FULLROWSELECT);
    LVCOLUMN lvColumn;
    ::ZeroMemory(&lvColumn, sizeof(LVCOLUMN));								// Zero struct's members.
    lvColumn.mask		= LVCF_TEXT | LVCF_WIDTH | LVCF_ORDER | LVCF_FMT;	// Type of mask.
    lvColumn.fmt        = LVCFMT_RIGHT;
    lvColumn.pszText = tszBuffer;

    lvColumn.cx	= 20;
    lvColumn.iOrder = 0;
	StringCbPrintf(tszBuffer, 64, TEXT("#"));
    pListCtrl->InsertColumn(0, &lvColumn);

    lvColumn.cx	= 160;
    lvColumn.iOrder = 1;
    StringCbPrintf(tszBuffer, 64, TEXT("Window Caption"));
    pListCtrl->InsertColumn(1, &lvColumn);

	lvColumn.cx	= 100;
    lvColumn.iOrder = 2;
    StringCbPrintf(tszBuffer, 64, TEXT("Window Class"));
    pListCtrl->InsertColumn(1, &lvColumn);

	lvColumn.cx	= 100;
    lvColumn.iOrder = 3;
    StringCbPrintf(tszBuffer, 64, TEXT("Upper Left"));
    pListCtrl->InsertColumn(1, &lvColumn);

	lvColumn.cx	= 100;
    lvColumn.iOrder = 4;
    StringCbPrintf(tszBuffer, 64, TEXT("Lower Right"));
    pListCtrl->InsertColumn(1, &lvColumn);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFiT2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFiT2Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFiT2Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFiT2Dlg::OnOK() 
{
	CDialog::OnOK();
}



void CFiT2Dlg::OnRadio1() 
{	
	if(IsDlgButtonChecked(IDC_RADIO1))
	{
		m_operation=1;
	}
	
}

void CFiT2Dlg::OnRadio2()
{
	if(IsDlgButtonChecked(IDC_RADIO2))
	{
		m_operation=2;
	}
}



void CFiT2Dlg::OnSendMessageClicked() 
{
	// TODO: Add your control notification handler code here
	int t_message;
	CString s_pid;
	CString s_n_message;

	m_edit_pid.GetWindowText(s_pid);
		int pid = atoi(s_pid);
	m_edit_number.GetWindowText(s_n_message);
		int n_message = atoi(s_n_message);
	
	switch(m_operation)
	{
	case 1:
		t_message=1;
	case 2:
		t_message=2;
	}
	mainFIT(pid,n_message,t_message);

	/*------------------------------- echo Parameter
	AfxMessageBox(pid);
	AfxMessageBox(n_message);
	switch(m_operation)
	{
	case 1:
		AfxMessageBox("SendMessage");
		break;
	case 2:
		AfxMessageBox("PostMessage");
		break;
	}
	------------------------------- echo Parameter */
	
}

void CFiT2Dlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	UpdateData(FALSE);

	CListCtrl* pListCtrl = (CListCtrl*)GetDlgItem(IDC_LIST1);
	int nTargetIndex = pListCtrl->GetNextItem(-1, LVNI_SELECTED);
	nTargetIndex++;

    // set the target window
    m_hTargetWindow = pWindowList->getWindowAt(nTargetIndex)->hWnd;

    //================================================
    // DO MESSAGE SENDING
    //================================================

    // seed the random number generator
    srand((unsigned)time(NULL));

	// do message sending
	/*
    fprintf(stdout, "Sending to pid %d, hwnd %#x\n", 
            options.dwProcessId, 
            hTargetWindow);
	*/
	StringCbPrintf(g_tszBuffer, 1024, TEXT("Sending to pid %d, hwnd %#x\r\n"),
            options.dwProcessId, 
            m_hTargetWindow);
   
	sendRandomWin32(m_hTargetWindow, m_hTargetProcess, &options);
    
	/*
    fprintf(stdout, "Test complete\n");
	*/
	StringCbCat(g_tszBuffer, 1024, TEXT("Test complete\r\n"));
	
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
	pEdit->SetWindowText(g_tszBuffer);
}
