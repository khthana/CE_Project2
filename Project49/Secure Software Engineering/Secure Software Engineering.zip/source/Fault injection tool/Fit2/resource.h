//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FiT2.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FIT2_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT4                       1016
#define IDC_BUTTON1                     1017
#define IDC_LIST1                       1018
#define IDC_BUTTON2                     1019
#define IDC_EDIT3                       1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
