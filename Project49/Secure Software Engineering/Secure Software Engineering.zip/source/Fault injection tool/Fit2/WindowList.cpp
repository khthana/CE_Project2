#include "WindowList.h"

//=============================================================================
// Method: WindowSpec
//     Description:
//         Constructor for WindowSpec class
//     Parameters:
//         none
//     Return Value:
//         none
//=============================================================================
WindowSpec::WindowSpec(VOID)
{
    pszCaption = new CHAR[CAPTIONLENGTH];
    pszWndClassName = new CHAR[WNDCLASSLENGTH];
    
    hWnd = (HWND) INVALID_HANDLE_VALUE;

    rect.left = rect.right = rect.top = rect.bottom = 0;

    pNext = NULL;

} // end WindowSpec


//=============================================================================
// Method: ~WindowSpec
//     Description:
//         destructor for WindowSpec class
//     Parameters:
//         none
//     Return Value:
//         none 
//=============================================================================
WindowSpec::~WindowSpec(VOID)
{
    delete [] pszCaption;
    delete [] pszWndClassName;

} // end ~WindowSpec


//=============================================================================
// static window list
//=============================================================================
WindowSpec *WindowList::pWindowSpecs = NULL;
LONG WindowList::nNumWindows = 0;


//=============================================================================
// Method: WindowList
//     Description:
//         constructor
//     Parameters:
//         none
//     Return Value:
//         none
//=============================================================================
WindowList::WindowList(VOID)
{
    pWindowSpecs = NULL;
    nNumWindows = 0;
} // end WindowList



//=============================================================================
// Method: ~WindowList
//     Description:
//         destructor for window list
//     Parameters:
//         none
//     Return Value:
//         none
//=============================================================================
WindowList::~WindowList(VOID)
{
    WindowSpec *pCurr = pWindowSpecs;
    WindowSpec *pNext;
    
    while (pCurr != NULL)
    {
        pNext = pCurr->pNext;
        delete pCurr;
        pCurr = pNext;
    }

} // end ~WindowList


//=============================================================================
// Method: numWindows
//     Description:
//         get the total number of windows associated in the list
//     Parameters:
//         none
//     Return Value:
//         number of windows in list
//=============================================================================
LONG WindowList::numWindows(VOID)
{
    return nNumWindows;

} // end numWindows 


//=============================================================================
// Method: genWindowsList
//     Description:
//         fill in the list structure with all the top level windows for a 
//         given process
//     Parameters:
//         dwProcessId - process id of target process 
//     Return Value:
//         none
//=============================================================================
VOID WindowList::genWindowList(DWORD dwProcessId)
{
    // enumerate all the top-level windows and store the top level 
    // windows for the process
    EnumWindows(WindowList::enumWindowsCallback, dwProcessId);

    return;

} // end genWindowList


//=============================================================================
// Method: enumWindowsCallback
//     Description:
//         callback that is called by EnumWindows 
//         builds up list of all windows associated with the given process
//     Parameters:
//         hwnd - handle to current window
//         lParam - will contain the process id we are looking for
//     Return Value:
//         will always be TRUE because we want EnumWindows to go through 
//         all top level windows
//=============================================================================
BOOL CALLBACK WindowList::enumWindowsCallback(HWND hwnd, LPARAM lParam)
{
    DWORD dwTargetId = (DWORD) lParam;
    
    // get the process id for the current window
    DWORD dwCurrWndId;
    if (!GetWindowThreadProcessId(hwnd, &dwCurrWndId))
    {
        return TRUE;
    }

    // see if the process id matches the one we're looking for
    if (dwCurrWndId == dwTargetId)
    {
        // add it to our list
        WindowSpec *pNewSpec = new WindowSpec;
        pNewSpec->pNext = pWindowSpecs;
        pNewSpec->hWnd = hwnd;
        GetWindowText(hwnd, pNewSpec->pszCaption, CAPTIONLENGTH);
        GetClassName(hwnd, pNewSpec->pszWndClassName, WNDCLASSLENGTH);
        GetWindowRect(hwnd, &(pNewSpec->rect));

        nNumWindows++;

        // reset the head pointer for the target windows list
        pWindowSpecs = pNewSpec;
    }
    
    return TRUE;

} // end enumWindowsCallback


//=============================================================================
// Method: getWindowAt
//     Description:
//         get the window at the specified index in the list
//     Parameters:
//         nIndex - index into the list
//     Return Value:
//         pointer to the window spec or NULL if there is no such index
//=============================================================================
WindowSpec *WindowList::getWindowAt(LONG nIndex)
{
    WindowSpec *pRetSpec = pWindowSpecs;

    // not the best algorithm, but in this case it works
    for (int i = 1; i < nIndex; i++)
    {
        if (NULL == pRetSpec)
        {
            return NULL;
        }
        pRetSpec = pRetSpec->pNext;
    }
    
    return pRetSpec;

} // end getWindowAt
