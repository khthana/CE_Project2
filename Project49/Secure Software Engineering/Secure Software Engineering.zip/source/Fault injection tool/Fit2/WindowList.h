#ifndef WINDOW_LIST_H_INCLUDED
#define WINDOW_LIST_H_INCLUDED

#include <windows.h>

//=============================================================================
// Support classes
//     These classes basically implement a simple linked list 
//     Yes, I could have used MFC collection classes, but I did not want to 
//     have to rely on MFC for this simple app.  
//=============================================================================

// Max length of strings
#define CAPTIONLENGTH  32
#define WNDCLASSLENGTH 32

//=============================================================================
// WindowSpec - individual window specifiers
//=============================================================================
class WindowSpec
{
public:
    friend class WindowList;
    WindowSpec(VOID);
    ~WindowSpec(VOID);
    HWND hWnd;
    LPSTR pszCaption;
    LPSTR pszWndClassName;
    RECT rect;
    WindowSpec *pNext;
};


//=============================================================================
// WindowList - main class that will hold the window class
//=============================================================================
class WindowList
{
public:
    WindowList(VOID);
    ~WindowList(VOID);

    // get current number of windows associated with this process
    LONG numWindows(VOID);

    // generate the list of top level windows associated with this process
    VOID genWindowList(DWORD dwProcessId);

    // helper function for genWindowList
    static BOOL CALLBACK enumWindowsCallback(HWND hwnd, LPARAM lParam);

    // get a specific window in the list
    WindowSpec *getWindowAt(LONG nIndex);
protected:
    static LONG nNumWindows;
    static WindowSpec *pWindowSpecs;
};

#endif