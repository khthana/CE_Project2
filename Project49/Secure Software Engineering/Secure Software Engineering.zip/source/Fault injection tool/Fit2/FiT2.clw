; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CFiT2Dlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FiT2.h"

ClassCount=3
Class1=CFiT2App
Class2=CFiT2Dlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_FIT2_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_FIT2_DIALOG (English (U.S.))

[CLS:CFiT2App]
Type=0
HeaderFile=FiT2.h
ImplementationFile=FiT2.cpp
Filter=N
LastObject=CFiT2App

[CLS:CFiT2Dlg]
Type=0
HeaderFile=FiT2Dlg.h
ImplementationFile=FiT2Dlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CFiT2Dlg

[CLS:CAboutDlg]
Type=0
HeaderFile=FiT2Dlg.h
ImplementationFile=FiT2Dlg.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_FIT2_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CFiT2Dlg

[DLG:IDD_FIT2_DIALOG (English (U.S.))]
Type=1
Class=CFiT2Dlg
ControlCount=11
Control1=IDC_EDIT1,edit,1350631552
Control2=IDC_EDIT2,edit,1350631552
Control3=IDC_STATIC,button,1342308359
Control4=IDC_RADIO1,button,1342308361
Control5=IDC_RADIO2,button,1342177289
Control6=IDOK,button,1342242817
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDC_EDIT4,edit,1350633600
Control11=IDC_BUTTON1,button,1342242816

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

