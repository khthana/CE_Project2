// FiT2Dlg.h : header file
//

#if !defined(AFX_FIT2DLG_H__822DB1A4_B014_4611_8364_990133F14160__INCLUDED_)
#define AFX_FIT2DLG_H__822DB1A4_B014_4611_8364_990133F14160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WindowList.h"

/////////////////////////////////////////////////////////////////////////////
// CFiT2Dlg dialog

class CFiT2Dlg : public CDialog
{
// Construction
public:
	CFiT2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFiT2Dlg)
	enum { IDD = IDD_FIT2_DIALOG };
	CEdit	m_edit_pane2;
	CEdit	m_edit_number;
	CEdit	m_edit_pid;
	int		m_operation;
	CString	m_edit_pane;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiT2Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFiT2Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnSendMessageClicked();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	int mainFIT(int pid_f,int n_message_f,int t_message_f);
public:
	afx_msg void OnBnClickedButton2();

	FUZZ_OPTIONS options;
	WindowList* pWindowList;

	HWND m_hTargetWindow;
	HANDLE m_hTargetProcess;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIT2DLG_H__822DB1A4_B014_4611_8364_990133F14160__INCLUDED_)
