void *myrealloc(void *ptr, size_t size);
size_t WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data);
int get_file(char* file_url);
int file_copy( char *oldname, char *newname );
int copy_xml(char* source,char* destination);
void *myrealloc(void *ptr, size_t size);
size_t WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data);
void server_XML(char *local_xmlLink,char *local_id,char* local_version);
char* find_substr(char *s1, char *s2);
void get_xml_value(char *beg_tag, char *end_tag,char* outStr,char * path);
void update(char *File_XML);
unsigned char *simple_digest (char *alg,
                              char *buffer,
                              unsigned int len,
                              int *olen);
void print_hex (unsigned char *bs, unsigned int n);
unsigned char *read_file (FILE * f, int *len);
unsigned char *process_file (char *algorithm, FILE * f, unsigned int *olen);
int process_stdin (char *algorithm);
void cal_sha1(char *file_name);
