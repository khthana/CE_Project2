#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>
#include "update_library.h"

struct MemoryStruct {
  char *memory;
  size_t size;
};
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//================ HPPTS ===================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

void *myrealloc(void *ptr, size_t size)
{
  /* There might be a realloc() out there that doesn't like reallocing
     NULL pointers, so we take care of it here */
   if(ptr)
    return realloc(ptr, size);
   else
    return malloc(size);
}

size_t
WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data)
{
   size_t realsize = size * nmemb;
   struct MemoryStruct *mem = (struct MemoryStruct *)data;

   mem->memory = (char *)myrealloc(mem->memory, mem->size + realsize + 1);
  if (mem->memory) {
    memcpy(&(mem->memory[mem->size]), ptr, realsize);
     mem->size += realsize;
    mem->memory[mem->size] = 0;
   }
   return realsize;
 }

int get_file(char* file_url)
{
    struct MemoryStruct chunk;
 
   chunk.memory=NULL; /* we expect realloc(NULL, size) to work */
   chunk.size = 0;    /* no data at this point */

   CURL *curl;
   CURLcode res;
	
	FILE *tmpfile;
   char* tempname = "tmpf.aaa";
 
   curl = curl_easy_init();
   if(curl) {
     curl_easy_setopt(curl, CURLOPT_URL, file_url);
 
#ifdef SKIP_PEER_VERIFICATION
    /*
     * If you want to connect to a site who isn't using a certificate that is
     * signed by one of the certs in the CA bundle you have, you can skip the
    * verification of the server's certificate. This makes the connection
     * A LOT LESS SECURE.
     *
     * If you have a CA cert for the server stored someplace else than in the
      * default bundle, then the CURLOPT_CAPATH option might come handy for
     * you.
      */
     curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
 #endif

 #ifdef SKIP_HOSTNAME_VERFICATION
    /*
      * If the site you're connecting to uses a different host name that what
     * they have mentioned in their server certificate's commonName (or
     * subjectAltName) fields, libcurl will refuse to connect. You can skip
      * this check, but this will make the connection less secure.
     */
     curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0);
#endif


//---------------------
 /* send all data to this function  */
   curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
 
   /* we pass our 'chunk' struct to the callback function */
   curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
 
   /* some servers don't like requests that are made without a user-agent
      field, so we provide one */
   curl_easy_setopt(curl, CURLOPT_USERAGENT, "libcurl-agent/1.0");
//---------------------




    res = curl_easy_perform(curl);
 
    /* always cleanup */
     curl_easy_cleanup(curl);

	//GET FILE
	//printf("%s",chunk.memory);
	tmpfile = fopen(tempname, "w");  /* Use appropriate mode */
	fprintf(tmpfile,"%s",chunk.memory);

	fclose(tmpfile);
	


	  if(chunk.memory)
     free(chunk.memory);

   }
   return 0;
 }

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//==============END HTTPS ===================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\



//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//================ COPY =====================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
  /* Copying a file. */

 int file_copy( char *oldname, char *newname )
 {
//	printf("FILE_COPY\n");
     FILE *fold, *fnew;
     int c;

     /* Open the source file for reading in binary mode. */

     if ( ( fold = fopen( oldname, "rb" ) ) == NULL )
         return -1;

     /* Open the destination file for writing in binary mode. */

     if ( ( fnew = fopen( newname, "wb" ) ) == NULL  )
     {
         fclose ( fold );
         return -1;
     }

     /* Read one byte at a time from the source; if end of file */
     /* has not been reached, write the byte to the */
     /* destination. */

     while (1)
     {
         c = fgetc( fold );

         if ( !feof( fold ) )
             fputc( c, fnew );
         else
             break;
     }

     fclose ( fnew );
     fclose ( fold );

     return 0;
}

int copy_xml(char* source,char* destination)
  {
//	  printf("COPY XML\n");
 //     char source[80], destination[80];

     /* Get the source and destination names. */
/*
     printf("\nEnter source file: ");
     gets(source);
     printf("\nEnter destination file: ");
     gets(destination);
*/
     if ( file_copy( source, destination ) != 0 )
	  {
		fprintf(stderr, "Error during copy operation");
		 return (1);
	  }     
/*     else
	  {
         puts("Copy operation successful");
	  }*/
     return(0);
 }


//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//==============END COPY ====================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//================ GETINMEMORY ===================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

/*
size_t
WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data)
{
   size_t realsize = size * nmemb;
   struct MemoryStruct *mem = (struct MemoryStruct *)data;

   mem->memory = (char *)myrealloc(mem->memory, mem->size + realsize + 1);
  if (mem->memory) {
    memcpy(&(mem->memory[mem->size]), ptr, realsize);
     mem->size += realsize;
    mem->memory[mem->size] = 0;
   }
   return realsize;
 }
*/

 void server_XML(char *local_xmlLink,char *local_id,char* local_version)
 {
	 //printf("IN FN SEVER_XML\n");
//   char tempname[80];
	FILE *tmpfile;

	char* tempname = "temp.sss";

	char server_id[100];
	char server_version[100];
	float ver;
	float curr_ver;
   
   CURL *curl_handle;
 
   struct MemoryStruct chunk;
 
  chunk.memory=NULL; /* we expect realloc(NULL, size) to work */
   chunk.size = 0;    /* no data at this point */
 
   curl_global_init(CURL_GLOBAL_ALL);
 
   /* init the curl session */
   curl_handle = curl_easy_init();
 
   /* specify URL to get */
   curl_easy_setopt(curl_handle, CURLOPT_URL, local_xmlLink);
 
   /* send all data to this function  */
   curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
 
   /* we pass our 'chunk' struct to the callback function */
   curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&chunk);
 
   /* some servers don't like requests that are made without a user-agent
      field, so we provide one */
   curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
 
   /* get it! */
   curl_easy_perform(curl_handle);
 
   /* cleanup curl stuff */
   curl_easy_cleanup(curl_handle);
 
   /*
    * Now, our chunk.memory points to a memory block that is chunk.size
    * bytes big and contains the remote file.
    *
    * Do something nice with it!
    *
    * You should be aware of the fact that at this point we might have an
    * allocated data block, and nothing has yet deallocated that data. So when
    * you're done with it, you should free() it as a nice application.
    */
 
	//TRY PRINT TO TMP FILE
//	printf("TRY PRINT TO TMP FILE\n");
//	tmpnam(tempname);
	tmpfile = fopen(tempname, "w");  /* Use appropriate mode */
	fprintf(tmpfile,"%s",chunk.memory);

	fclose(tmpfile);
	

	get_xml_value("<id>","</id>",server_id,tempname);
	//printf("%s\n",server_id);	
	get_xml_value("<version>","</version>",server_version,tempname);	
//	printf("%s\n",server_version);	

//	printf("CONVERT VERSION TO FLOAT\n");	
	curr_ver = atof(local_version);
	ver =  atof(server_version);

//	printf("CMP ID AND VERSION\n");	
	if (strcmp(server_id,local_id) != 0)
	{
		printf("Update Fail. Program ID Mis-Match!!");
		exit(1);
	} else if (curr_ver >= ver)
				{
					remove(tempname);
					printf("Update Cancel.\n Your signature is UP-TO-DATE\n");
					exit(1);
				}
/*	
	printf("CALL COPY_XML\n");
	copy_xml(tempname,"./update.xml");
*/
//	printf("REMOVE TEMPNAME\n");
//	remove(tempname);


   if(chunk.memory)
     free(chunk.memory);

//   return 0;
 }


//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//================END GETINMEMORY ================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\



char* find_substr(char *s1, char *s2)
{
  register int t;
  char *p, *p2;

  for(t=0; s1[t]; t++) {
    p = &s1[t];
    p2 = s2;

    while(*p2 && *p2==*p) {
      p++;
      p2++;
    }
    if(!*p2) return p; /* 1st return */
  }
   return NULL; /* 2nd return */
}

void get_xml_value(char *beg_tag, char *end_tag,char* outStr,char * path)
{
//	printf("in fn get xml value\n");
	char line[100];
	char* begin;
	char* end;
	int lcount = 0;
	FILE *fp;
//	char* localXML = "./update.xml";
	char* localXML = path;
	
	if ((fp = fopen(localXML,"r")) != NULL)
	{
		while( fgets(line, sizeof(line), fp) != NULL ) 
		{
			/* Get each line from the infile */
			lcount++;
			/* print the line number and data */
			if (begin = find_substr(line,beg_tag))
			{
				if (end = find_substr(line,end_tag))
				{
					end -= strlen(end_tag);
					
					strncpy(outStr,begin,end-begin);
					*(outStr+(end - begin)) = '\0';
				}
			}
		}
	}else
        {
            fprintf(stderr, "\nError opening file\n");
			exit(1);
		}
	fclose(fp);
}

void update(char *File_XML)
{
	printf("UPDATE\n");

	char local_id[100];
	char local_version[100];
	char local_xmlLink[100];
	char local_fileLink[100];
	char local_sum[100];

	char server_id[100];
	char server_version[100];
	char server_xmlLink[100];
	char server_fileLink[100];
	char server_fileSha1[100];


	char wget_command[100];
	char wget_file[100];

	char doc_Sha1[100];
	char file_Sha1[100];
	char file_name[100];
	char line[100];

	FILE* tempfile;

	//GET VALUE FROM LOCAL XML
//	printf("GET VALUE FROM LOCAL XML\n");

	get_xml_value("<id>","</id>",local_id,File_XML);
	get_xml_value("<version>","</version>",local_version,File_XML);
	get_xml_value("<xmlLink>","</xmlLink>",local_xmlLink,File_XML);
//	get_xml_value("<fileLink>","</fileLink>",local_fileLink,File_XML);	NOT NEED
//	get_xml_value("<checksum>","<\checksum>",local_sum,File_XML);

	//CHECK SUM LOCAL XML
	//implement here..............





	//GET XML FROM SERVER AND CHECK DATA

/*	OLD STYLE
	printf("%s\n",local_xmlLink);
	strcpy(wget_command,"wget ");
	printf("%s\n",wget_command);
	strcat(wget_command,local_xmlLink);
	printf ("%s\n",wget_command);
	system(wget_command);
*/
//	printf("server_XML\n");
	server_XML(local_xmlLink,local_id,local_version);

	//GET FILE URL FOR D/L

//	get_xml_value("<id>","</id>",server_id,"./update.xml.1");
//	get_xml_value("<version>","</version>",server_version,"./update.xml.1");
//	get_xml_value("<xmlLink>","</xmlLink>",server_xmlLink,"./update.xml.1");
//	printf("get xml value server\n");
	get_xml_value("<fileLink>","</fileLink>",server_fileLink,"./temp.sss");
	get_xml_value("<fileSha1>","</fileSha1>",server_fileSha1,"./temp.sss");

	//GET UPDATE FILE
//	printf("GET UPDATE FILE");
	get_file(server_fileSha1);
	//FIND SHA1 IN DESCRIPTION
	get_xml_value("<checksum:",">",doc_Sha1,"./tmpf.aaa");
	get_xml_value("<filename:",">",file_name,"./tmpf.aaa");
//	printf("name DOC :%s\n",file_name);
//	printf("Sha1 DOC :%s\n",doc_Sha1);

	get_file(server_fileLink);
	cal_sha1("tmpf.aaa");
//	get_xml_value("<checksum:",">",file_Sha1,"./tmpf.aaa");
	
	tempfile = fopen("sha1", "r");  /* Use appropriate mode */
	fgets(line, sizeof(line), tempfile);
//	printf("FILE SHA1 :%s\n",line);
	fclose(tempfile);
	remove("sha1");	


	if (strcmp(doc_Sha1,line) == 0)
	{
//		printf("CHECK SUM OK!!!");
//		printf("CALL COPY_XML FOR FILE\n");

	/*	if ( remove(file_name) == 0)
			printf("The file %s has been deleted.\n",file_name);
		else
			fprintf(stderr, "Error deleting the file %s.\n",file_name);
*/
		copy_xml("tmpf.aaa",file_name);
		copy_xml("temp.sss",File_XML);
		
		//REMOVE TMP FILE;
		remove("tmpf.aaa");
		remove("temp.sss");
//		remove("sha1");
		printf("\nUPDATE PROCESS SUCCESSFUL.\n");
		/*
		if ( remove("tmpf.aaa") == 0)
			printf("The file tmpf.aaa has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file tmpf.aaa.\n");

		if ( remove("./sha1") == 0)
			printf("The file sha1 has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file sha1.\n");

		if ( remove("temp.sss") == 0)
			printf("The file temp.sss has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file temp.sss.\n");
		if ( remove("sha1") == 0)
			printf("The file sha1 has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file sha1.\n");
		printf("UPDATE COMPLETE");
		*/
	} else
	{
		printf("Update FAIL! Check Sum ERROR!!!\n");
		remove("tmpf.aaa");
		remove("sha1");
		remove("temp.sss");

		/*
		if ( remove("tmpf.aaa") == 0)
			printf("The file tmpf.aaa has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file tmpf.aaa.\n");

		if ( remove("sha1") == 0)
			printf("The file sha1 has been deleted.\n");
		else
			fprintf(stderr, "Error deleting the file sha1.\n");
		exit(1);
		*/
	}
	exit(0);
}

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//===================== SHA1 ====================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

#define READSIZE 1024
                                                                                
unsigned char *simple_digest (char *alg,
                              char *buffer,
                              unsigned int len,
                              int *olen)
{
   EVP_MD *m;
   EVP_MD_CTX ctx;
   unsigned char *ret;
                                                                                
   OpenSSL_add_all_digests ();
   if (!(m = (EVP_MD*) EVP_get_digestbyname (alg)))
      return NULL;
   if (!(ret = (unsigned char *) malloc (EVP_MAX_MD_SIZE)))
      return NULL;
   EVP_DigestInit (&ctx, m);
   EVP_DigestUpdate (&ctx, buffer, len);
   EVP_DigestFinal (&ctx, ret, olen);
   return ret;
}
                                                                                
void print_hex (unsigned char *bs, unsigned int n)
{
   int i;

   	FILE *tmpfile;
	char* tempname = "sha1";
	tmpfile = fopen(tempname, "w");  /* Use appropriate mode */

   for (i = 0; i < n; i++)
	{   
//			printf ("%02x", bs[i]);
			// TO FILE CHECKSUM;
			
			fprintf(tmpfile,"%02x",bs[i]);
	}

	fclose(tmpfile);

}

unsigned char *read_file (FILE * f, int *len)
{
   unsigned char *buffer = NULL, *last = NULL;
   unsigned char inbuffer[READSIZE];
   int tot, n;
                                                                                
   tot = 0;
   for (;;)
   {
      n = fread (inbuffer, sizeof (unsigned char), READSIZE, f);
      if (n > 0)
      {
         last = buffer;
         buffer = (unsigned char *) malloc (tot + n);
         memcpy (buffer, last, tot);
         memcpy (&buffer[tot], inbuffer, n);
         if (last)
            free (last);
         tot += n;
         if (feof (f) > 0)
         {
            *len = tot;
            return buffer;
         }
      }
      else
      {
         if (buffer)
            free (buffer);
         break;
      }
   }
   return NULL;
}

unsigned char *process_file (char *algorithm, FILE * f, unsigned int *olen)
{
   int filelen;
   unsigned char *ret, *contents = read_file (f, &filelen);
   if (!contents)
      return NULL;
   ret = simple_digest (algorithm, contents, filelen, olen);
   free (contents);
   return ret;
}
                                                                                
int process_stdin (char *algorithm)
{
   unsigned int olen;
   unsigned char *digest = process_file (algorithm, stdin, &olen);
   if (!digest)
      return 0;
   print_hex (digest, olen);
   printf ("\n");
   free(digest);
   return 1;
}

/*																		
void usage (char *progname) {
                                                                                
   printf ("Usage: %s [ md2 | md4 | md5 | sha | sha1 ] [ Files ] \n\n",
            progname);
   exit(0);
}
*/

void cal_sha1(char *file_name)
{
   int i;
                                                                                
   /* Sin parametros */
//   if (argc < 2) usage(argv[0]);
                                                                                
   /* Verificamos los algoritmos */
/*   if ( (strcmp(argv[1], "md2")  != 0) &&
        (strcmp(argv[1], "md4")  != 0) &&
        (strcmp(argv[1], "md5")  != 0) &&
        (strcmp(argv[1], "sha")  != 0) &&
        (strcmp(argv[1], "sha1") != 0) ) usage(argv[0]);
*/                                                                                
                                                                                
   /* Un solo parametro, entrada estandar */
//   if (argc == 2) { if (!process_stdin (argv[1])) perror ("stdin"); }
                                                                                
   /* Lee y procesa todos los parametros recibidos */
//   else {
                                                                                
//      for (i = 2; i < argc; i++) {
                                                                                
         FILE *file = fopen (file_name, "rb");
         unsigned int olen;
         unsigned char *digest;
                                                                                
//         if (!file) { perror (argv[i]); return -1; }
                                                                                
         digest = process_file ("sha1", file, &olen);
                                                                                
         if (!digest) {
                                                                                
            fclose (file);
            return -1;
         }
                                                                                
         fclose (file);
         print_hex (digest, olen);
//         printf ("  %s\n", argv[i]);
         free(digest);
//     }
 //  }
   return 1;
}

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//===============END SHA1 ========================
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
