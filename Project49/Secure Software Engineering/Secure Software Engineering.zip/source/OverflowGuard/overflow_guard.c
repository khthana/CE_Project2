#include <stdio.h>		/* defines stdin */
#include <stdarg.h>		/* defines va_args */
#define __NO_STRING_INLINES 1	/* stops the inline expansion of strcpy() */
#define __USE_GNU 1		/* defines strnlen() */
#include <string.h>		/* defines strncat() */
#include <unistd.h>		/* defines getcwd(), readlink() */
#include <sys/param.h>		/* MAXPATHLEN for realpath() */
#include <limits.h>		/* PATH_MAX for getwd(); actually in */
				/*     linux/limits.h */
#include <signal.h>		/* defines kill() */
#include <syslog.h>		/* defines syslog(3) */

#include <pwd.h>		/* defines getpass() */
#include <errno.h>		/* defines errno */
#include <dlfcn.h>		/* defines dlsym() */
#include <wchar.h>		/* for the wide-char functions */
#include <ctype.h>		/* for the isdigit() */

#define LIBNAME  "overflow_guard.so"
123456798
/*
 * -----------------------------------------------------------------
 * ----------------- system library protocols ----------------------
 */
typedef char *(*strncpy_t) (char *dest, const char *src, size_t n);
typedef void *(*memcpy_t) (void *dest, const void *src, size_t n);
typedef char *(*strcpy_t) (char *dest, const char *src);
typedef wchar_t *(*wcscpy_t) (wchar_t *dest, const wchar_t *src);
typedef char *(*stpcpy_t) (char *dest, const char *src);
typedef wchar_t *(*wcpcpy_t) (wchar_t *dest, const wchar_t *src);
typedef char *(*strcat_t) (char *dest, const char *src);
typedef char *(*strncat_t) (char *dest, const char *src, size_t n);
typedef wchar_t *(*wcscat_t) (wchar_t *dest, const wchar_t *src);
typedef char *(*getwd_t) (char *buf);
typedef char *(*realpath_t) (char *path, char resolved_path[]);
typedef int (*vsprintf_t) (char *str, const char *format, va_list ap);
typedef int (*vsnprintf_t) (char *str, size_t size, const char *format, va_list
	ap);


static memcpy_t real_memcpy = NULL;
/*
 * -----------------------------------------------------------------
 * ------------------- utility functions ---------------------------
 */
#ifndef __USE_GNU
inline size_t strnlen(const char *s, size_t count)
{
	register int __res;
	__asm__ __volatile__("movl %1,%0\n\t"
			     "jmp 2f\n"
			     "1:\tcmpb $0,(%0)\n\t"
			     "je 3f\n\t"
			     "incl %0\n"
			     "2:\tdecl %2\n\t"
			     "cmpl $-1,%2\n\t"
			     "jne 1b\n" "3:\tsubl %1,%0":"=a"(__res)
			     :"c"(s), "d"(count)
			     :"dx");
	return __res;
}
#endif

/*
 * returns a pointer to the implementation of 'funcName' in
 * the libc library.  If not found, terminates the program.
 */
static void *getLibraryFunction(const char *funcName)
{
	void *res;

	if ((res = dlsym(RTLD_NEXT, funcName)) == NULL) {
		fprintf(stderr, "dlsym %s error:%s\n", funcName,
			dlerror());
		_exit(1);
	}
	return res;
}

void send_log(char * func)
{
openlog(LIBNAME, LOG_CONS | LOG_PID, LOG_AUTHPRIV);
    	syslog(LOG_CRIT, "Overflow [%s] by uid:%d euid:%d pid:%d",func,getuid(),geteuid(),getpid());
	closelog();

}

void activated(char *format, ...)
{
	printf("Overflow Detected\n");
	printf("OverflowGuard Activated\n");
    raise(SIGKILL);
}

uint checked_buffer(void *addr) 
{
	uint bufsize = 0;
	void *fp, *sp;
  	//void *nextfp;
	//void *stack_start;
    	sp = &fp;
    	if (sp > addr)
	{
		//printf("out global");
		return 0;
	}
	fp = __builtin_frame_address(2); //check for fp at main
	//printf("sp4=%x\nfp4=%x\naddr4=%x\n",sp,fp,addr);  // debug
	if(sp < fp) 
	{
		if (fp > addr) 
		{
			//printf("fp > addr\n");
	    		bufsize = fp - addr;
			//printf("buff = %d\n",bufsize);
		}
    	}

    	if (bufsize == 0) 
	{
		//printf("bufsize = 0");
		return 0;
    	}

	if (sp < fp) 
	{
	 	return bufsize;
    	}

    	return 0;
}

//***********************************************************
//******************* strncpy *******************************
//***********************************************************
char *strncpy(char *dest, const char *src, size_t n) //proove
{
    static strncpy_t real_strncpy = NULL;
    size_t max_size, len;
	//printf(" heloo %x",dest);

    if (!real_strncpy)
	real_strncpy = (strncpy_t) getLibraryFunction("strncpy");

    //if (_libsafe_exclude)
	//return real_strncpy(dest, src, n);/
//printf("size of dest = %d" ,sizeof(dest));
    if ((max_size = checked_buffer(dest)) == 0) {
	//LOG(5, "strncpy(<heap var> , <src>)\n");
	//printf("strncpy(<heap var> , <src>)\n");
	return real_strncpy(dest, src, n);
    }

   // LOG(4, "strncpy(<stack var> , <src>) stack limit=%d)\n", max_size);

    if (n > max_size && (len = strnlen(src, max_size)) == max_size)
{
	send_log("strncpy()");
	activated("Overflow caused by strncpy()");

}

    return real_strncpy(dest, src, n);
}


//***********************************************************
//******************* strcpy *******************************
//***********************************************************

char *strcpy(char *dest, const char *src)	//proove
{
//printf("strcpy nana");
    static strcpy_t real_strcpy = NULL;
    size_t max_size, len;

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");
    if (!real_strcpy)
	real_strcpy = (strcpy_t) getLibraryFunction("strcpy");


    if ((max_size = checked_buffer(dest)) == 0) {
	//printf("strcpy(<heap var> , <src>)\n");
//printf("22");
	return real_strcpy(dest, src);
    }
	//printf("strcpy(<stack var> , <src>) stack limit=%d)\n",max_size);

    if ((len = strnlen(src, max_size)) == max_size)
{
send_log("strcpy()");
//printf("33");
	//openlog(LIBNAME, LOG_CONS | LOG_PID, LOG_AUTHPRIV);
    	//syslog(LOG_CRIT, "Overflow [strcpy()] by %d",getuid());
	//closelog();
	activated("Overflow caused by strcpy()");
}
    real_memcpy(dest, src, len + 1);
	//printf("11");
    return dest;
}

//***********************************************************
//******************* stpcpy ********************************
//***********************************************************

char *stpcpy(char *dest, const char *src)
{
    static stpcpy_t real_stpcpy = NULL;
    size_t max_size, len;

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");
    if (!real_stpcpy)
	real_stpcpy = (stpcpy_t) getLibraryFunction("stpcpy");


    if ((max_size = checked_buffer(dest)) == 0) {
	//printf("stpcpy(<heap var> , <src>)\n");
	return real_stpcpy(dest, src);
    }
	//printf("stpcpy(<stack var> , <src>) stack limit=%d)\n");

    if ((len = strnlen(src, max_size)) == max_size){
send_log("stpcpy()");
	activated("Overflow caused by stpcpy()");

}
    real_memcpy(dest, src, len + 1);
    return dest + len;
}

//***********************************************************
//******************* wcscpy ********************************
//***********************************************************


wchar_t *wcscpy(wchar_t *dest, const wchar_t *src)
{
    static wcscpy_t real_wcscpy = NULL;
    size_t max_bytes, max_wchars, len;

    if (!real_wcscpy)
	real_wcscpy = (wcscpy_t) getLibraryFunction("wcscpy");


    if ((max_bytes = checked_buffer(dest)) == 0) {
	//printf("strcpy(<heap var> , <src>)\n");
	return real_wcscpy(dest, src);
    }
    
	//printf("wcscpy(<stack var> , <src>) stack)\n");

    max_wchars = max_bytes / sizeof(wchar_t);
    if ((len = wcsnlen(src, max_wchars)) == max_wchars) {
	
	send_log("wcscpy()");
	activated("Overflow caused by wcscpy()");
    }

    return real_wcscpy(dest, src);
}

//***********************************************************
//******************* wcpscpy ********************************
//***********************************************************

wchar_t *wcpcpy(wchar_t *dest, const wchar_t *src)
{
    static wcpcpy_t real_wcpcpy = NULL;
    size_t max_bytes, max_wchars, len;

    if (!real_wcpcpy)
	real_wcpcpy = (wcpcpy_t) getLibraryFunction("wcpcpy");

;

    if ((max_bytes = checked_buffer(dest)) == 0) {
	//printf("strcpy(<heap var> , <src>)\n");
	return real_wcpcpy(dest, src);
    }

   
    /*
     * Note: we can't use the standard wcsncpy()!  From the wcsncpy(3) manual
     * pages: "If the length wcslen(src) is smaller than n, the remaining wide
     * characters in the array pointed to by dest are filled with  L'\0'
     * characters."  We do not want null written all over the 'dest', hence,
     * our own implementation.
     */
    max_wchars = max_bytes / sizeof(wchar_t);
    if ((len = wcsnlen(src, max_wchars)) == max_wchars) {
	/*
	 * If wcsnlen() returns max_wchars, it means that no L'\0' character was
	 * found in the first max_wchars wide characters.  So, this
	 * wide-character string won't fit in the stack frame.
	 */
	send_log("wcpcpy()");
	activated("Overflow caused by wcpcpy()");
    }

    /*
     * Note that we can use wcpcpy() directly since there is no memcpy()
     * optimization as in the case of strcpy().
     */
    return real_wcpcpy(dest, src);
}

/*
 * This is needed!  See the strcpy() for the reason. -ab.
 */

//***********************************************************
//******************* memcpy ********************************
//***********************************************************
void *memcpy(void *dest, const void *src, size_t n)
{
    size_t max_size;

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");


    if ((max_size = checked_buffer(dest)) == 0) {
	//printf("memcpy(<heap var> , <src>, %d)\n");
	return real_memcpy(dest, src, n);
    }

    if (n > max_size){
	send_log("memcpy()");
	activated("Overflow caused by memcpy()");
}
    return real_memcpy(dest, src, n);
}

//***********************************************************
//******************* strcat ********************************
//***********************************************************

char *strcat(char *dest, const char *src)
{
    static strcat_t real_strcat = NULL;
    size_t max_size;
    uint dest_len, src_len;

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");
    if (!real_strcat)
	real_strcat = (strcat_t) getLibraryFunction("strcat");



    if ((max_size = checked_buffer(dest)) == 0) {
	//printf("strcat(<heap var> , <src>)\n");
	return real_strcat(dest, src);
    }

    
    dest_len = strnlen(dest, max_size);
    src_len = strnlen(src, max_size);

    if (dest_len + src_len >= max_size){
send_log("strcat()");
	activated("Overflow caused by strcat()");
}
    real_memcpy(dest + dest_len, src, src_len + 1);

    return dest;
}

//***********************************************************
//******************* strncat ********************************
//***********************************************************

char *strncat(char *dest, const char *src, size_t n)
{
    static strncat_t real_strncat = NULL;
    size_t max_size;
    uint dest_len, src_len;

    if (!real_strncat)
	real_strncat = (strncat_t) getLibraryFunction("strncat");


    if ((max_size = checked_buffer(dest)) == 0) {
	//printf("strncat(<heap var> , <src>)\n");
	return real_strncat(dest, src, n);
    }

    dest_len = strnlen(dest, max_size);
    src_len = strnlen(src, max_size);

    if (dest_len + n > max_size && dest_len + src_len >= max_size){
send_log("strncat()");
	activated("Overflow caused by strncat()");
}
    return real_strncat(dest, src, n);
}


//#ifndef MISSING_WCSNLEN
//***********************************************************
//******************* wcscat ********************************
//***********************************************************

wchar_t *wcscat(wchar_t *dest, const wchar_t *src)
{
    static wcscat_t real_wcscat = NULL;
    size_t max_bytes;
    uint dest_len, src_len;

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");
    if (!real_wcscat)
	real_wcscat = (wcscat_t) getLibraryFunction("wcscat");



    if ((max_bytes = checked_buffer(dest)) == 0) {
	//printf("wcscat(<heap var> , <src>)\n");
	return real_wcscat(dest, src);
    }


    dest_len = wcsnlen(dest, max_bytes/sizeof(wchar_t));
    src_len = wcsnlen(src, max_bytes/sizeof(wchar_t));

    if (dest_len + src_len + 1 >= max_bytes/sizeof(wchar_t)){
send_log("wcscat()");
	activated("Overflow caused by wcscat()");
}

    real_memcpy(dest + dest_len, src, src_len + 1);

    return dest;
}

char *getwd(char *buf)
{
    static getwd_t real_getwd = NULL;
    size_t max_size;
    char *res;

    if (!real_getwd)
	real_getwd = (getwd_t) getLibraryFunction("getwd");



    if ((max_size = checked_buffer(buf)) == 0) {
	//printf("getwd(<heap var>)\n");
	return real_getwd(buf);
    }

    
    res = getcwd(buf, PATH_MAX);
    if ((strlen(buf) + 1) > max_size){
        send_log("getwd()");
	activated("Overflow caused by getwd()");
	}
    return res;
}


char *realpath(char *path, char resolved_path[])
{
    static realpath_t real_realpath = NULL;
    size_t max_size, len;
    char *res;
    char buf[MAXPATHLEN + 1];

    if (!real_memcpy)
	real_memcpy = (memcpy_t) getLibraryFunction("memcpy");
    if (!real_realpath)
	real_realpath = (realpath_t) getLibraryFunction("realpath");

//    if (_libsafe_exclude)
//	return real_realpath(path, resolved_path);

    if ((max_size = checked_buffer(resolved_path)) == 0) {
//	LOG(5, "realpath(<src>, <heap var>)\n");
	return real_realpath(path, resolved_path);
    }

 //   LOG(4, "realpath(<src>, <stack var>) stack limit=%d\n", max_size);
    /*
     * realpath(3) copies at most MAXNAMLEN characters
     */
    res = real_realpath(path, buf);
    if ((len = strnlen(buf, max_size)) == max_size){
		send_log("realpath()");
		activated("Overflow caused by realpath()");
	}
//	_libsafe_die("Overflow caused by realpath()");

    real_memcpy(resolved_path, buf, len + 1);
    return (res == NULL) ? NULL : resolved_path;
}


int vsprintf(char *str, const char *format, va_list ap)
{
    static vsprintf_t real_vsprintf = NULL;
    static vsnprintf_t real_vsnprintf = NULL;
    size_t max_size;
    int res;

    if (!real_vsprintf)
	real_vsprintf = (vsprintf_t) getLibraryFunction("vsprintf");
    if (!real_vsnprintf)
	real_vsnprintf = (vsnprintf_t) getLibraryFunction("vsnprintf");

 //   if (_libsafe_exclude)
//	return real_vsprintf(str, format, ap);

    if ((max_size = checked_buffer(str)) == 0) {
//	LOG(5, "vsprintf(<heap var>, <format>, <va_list>)\n");
	return real_vsprintf(str, format, ap);
    }

//    LOG(4, "vsprintf(<stack var>, <format>, <va_list>)\n");

    /*
     * Some man pages say that -1 is returned if vsnprintf truncates the
     * output.  However, some implementations actually return the number of
     * chars that would have been output with a sufficiently large output
     * buffer.  Hence, we check for both res==-1 and res>max_size-1.  The
     * max_size-1 is to make sure that there is room for the string-terminating
     * NULL.
     */
    res = real_vsnprintf(str, max_size, format, ap);
    if (res == -1 || res > max_size-1)
    {
		send_log("vsprintf()");
		activated("Overflow caused by vsprintf()"); 
//	_libsafe_die("overflow caused by vsprintf()");
    }
    return res;
}


int vsnprintf(char *str, size_t size, const char *format, va_list ap)
{
    static vsnprintf_t real_vsnprintf = NULL;
    size_t max_size;
    int res;

    if (!real_vsnprintf)
	real_vsnprintf = (vsnprintf_t) getLibraryFunction("vsnprintf");

//    if (_libsafe_exclude)
//	return real_vsnprintf(str, size, format, ap);

    if ((max_size = checked_buffer(str)) == 0) {
//	LOG(5, "vsnprintf(<heap var>, <format>, <va_list>)\n");
	return real_vsnprintf(str, size, format, ap);
    }

 //   LOG(4, "vsnprintf(<stack var>, <format>, <va_list>)\n");

    /*
     * Some man pages say that -1 is returned if vsnprintf truncates the
     * output.  However, some implementations actually return the number of
     * chars that would have been output with a sufficiently large output
     * buffer.  Hence, we check for both res==-1 and res>max_size-1.  The
     * max_size-1 is to make sure that there is room for the string-terminating
     * NULL.
     */
    res = real_vsnprintf(str, size, format, ap);
    if ((res == -1 || res > max_size-1) && (size > max_size))
    {
		send_log("vsnprintf()");
		activated("Overflow caused by vsnprintf()"); 
//	_libsafe_die("overflow caused by vsnprintf()");
    }
    return res;
}
