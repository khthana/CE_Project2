import re
import sys
import string

global lineStr
global comment_flag

def File_Open(name):                                            # File Open Function
    try:
        UncleanFile = open(name,"r")
        
    except IOError:
        print
        print "No such file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    return UncleanFile

def unique(arr,val):                                            # Uniqe Array, remove duplicate
#    print "unique arr"
    val = val.split("[")
    
    for i in range(len(arr)):
       tmp = arr[i].split("[")
       if val[0] == tmp[0]:
           return False   
    return True
            
def find_oob(all,fn,glob,UncleanFile,file_name):                # Find out of bound Array
    print ""
    print "Find array out of bound"
    print ""
#    print "fn :",fn
#    print "global :",glob
#    print "all :",all
    
    UncleanFile = File_Open(file_name)
    fileList = UncleanFile.readlines()
    line = 1
    find = 0
    oob = 0
    
    for i in range(len(glob)):
        line = 1
        find = 0
#        print i
        str = glob[i].split("[")
#        print "str0",str[0]
#  not use      print "str1",str[1][:-1]
        for lineStr in fileList:
            n = re.findall("[^\w]"+str[0]+"\[[0-9]+\]",lineStr)
            if n:
#                print n
                find += 1
                if find > 1:
#                    print "find in line",line,n
                    for j in range(len(n)):
                            max = str[1][:-1]
                            tmp = n[j].split("[")
#                            print "tmp",tmp
                            val = tmp[1][:-1]
                            
#                            print "val,max",val,max
                            if int(val) >= int(max):
                                print "Out of Bound variable '",str[0],"' in line :",line
                                oob = 1
            line += 1 
    if oob == 0:
        print "No Out Of Bound Array"
    
def find_arr(file_name):                                        # Find Arrat and store them
    
    UncleanFile = File_Open(file_name)
    fileList = UncleanFile.readlines()

    type_pattern = "char|signed char|unsigned char|unsigned short|short|int|unsigned int|unsigned long|long|float|double|void"
    line = 1
    fn_num = 0
    glob = 0
    pos = 0
    pos_g = 0
    pos_ar = 0
    my_fn = {}
    my_arr = {}
    global_arr = {}
       
    for lineStr in fileList:
        n = re.findall("(\w+)[\s]+(\w+)[\s]*\((.*)\)",lineStr)
        if n:
            if glob == 1:
                my_arr[pos_ar] = "-"
                pos_ar += 1
#            print "Fn Found!!! in line ",line
            my_fn[pos] = n[0][1]
            pos += 1
            glob = 1
            
        else:
            m = re.findall("\w+\[\w+\]",lineStr)
            if m:
#                print m
                if glob == 0:
                    for i in range(0,len(m)):
                        if (unique(global_arr,m[i])):  
                            global_arr[pos_g] = m[i]
                            pos_g += 1
                else:
                    for i in range(0,len(m)):
                        if (unique(my_arr,m[i])):
                            my_arr[pos_ar] = m[i]
                            pos_ar += 1
        line += 1
        lineStr = UncleanFile.readline()
    
    all = {}
    ran = 0
    for i in range(0,len(my_fn)):
        pos = 0
        tmp_arr = {}
        for j in range(ran,len(my_arr)):
            if my_arr[j] != "-":
                tmp_arr[pos] = my_arr[j]
                pos += 1
            else:
                ran = j + 1
                break
        all[my_fn[i]] = tmp_arr
        
#    print "ALL",all
#    print "GLO",global_arr
    
    find_oob(all,my_fn,global_arr,UncleanFile,file_name)
    
    UncleanFile.close()
"""
def update():                                                   # Update Database <--- Weak security
    
    import urllib
    import urlparse
    import os

    myURL = "http://webserv.kmitl.ac.th/~waan/function.db"

    tmp_db = open("tmp.db","w")
    tempFile = urllib.urlopen(myURL)
    tmp_db.write(tempFile.read())
    tmp_db.close()

    tmp_read = open("tmp.db","r")

    for line in tmp_read:
        tmp = line.split(":")
        server_v = float(tmp[1])
        break
    tmp_read.close()
    
    #Find Current Version
    try:
        V = open("function.db","r")
    except IOError:
        print
        print "No such database file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    
    for line in V:
        tmp = line.split(":")
        current_v = float(tmp[1])
        V.close()
        break
    
    if server_v > current_v:
        os.remove("./delme")
        os.remove("./function.db")
        os.rename("./tmp.db","./function.db")
        os.remove("./tmp.db")
        print "Update database signature to version ",server_v
    else:
        print "Your signature is up to date"
        os.remove("./tmp.db")
    sys.exit()
"""


def update():

    import urllib
    import urlparse
    import os
    
    f = urllib.urlopen("http://www.kmitl.ac.th/~s6010279/pad.xml")
#    for k,v in f.headers.items():
#        print k, '=' ,v
    
    my_text = f.read()
#    print my_text
    
    text = my_text.split("<Program_id>{")
    id = text[1].split("}</Program_id>")
    
    print "ID :",id[0]
#    print "ID :"+"42a1c32a-01ad-40f2-9fa5-eff1c80dfb93"
    
    text = my_text.split("<Program_Version>")
    server_v = text[1].split("</Program_Version>")
    
    print "Version :",server_v[0]
    
    text = my_text.split("<UpdateURL>")
    UpdateURL = text[1].split("</UpdateURL>")
    
    print "Update URL :",UpdateURL[0]
    f.close()
    
    #Find Current Version
    try:
        V = open("function.db","r")
    except IOError:
        print
        print "No such database file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    
    for line in V:
        tmp = line.split(":")
        current_v = float(tmp[1])
        print "Current Version :",current_v
        V.close()
        break
    
    if id[0] != "42a1c32a-01ad-40f2-9fa5-eff1c80dfb93":
        print "Program ID mis-match"
        sys.exit()
    else:
    
        if server_v[0] > current_v:
            tempFile = urllib.urlopen(UpdateURL[0])
            tmp_db = open("./function.db","w")
            tmp_db.write(tempFile.read())
            tmp_db.close()
            print "Update database signature to version ",server_v[0]
        else:
            print "Your signature is up to date"
        sys.exit()

"""
def update():                                                   # Update Database <--- Weak security
    
    import urllib
    import urlparse
    import os

    myURL = "http://161.246.5.10/project/pad.xml"

#    tmp_db = open("tmp.db","w")
    tempFile = urllib.urlopen(myURL)
#    tmp_db.write(tempFile.read())
#    tmp_db.close()

#    tmp_read = open("tmp.db","r")

    File = tempFile.read()
    for line in File:
        print line
        break
#    tmp_read.close()
"""

def show_version():                                             # Show Current Version
    try:
        V = open("function.db","r")
    except IOError:
        print
        print "No such database file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    
    for line in V:
        tmp = line.split(":")
        print "current version :",tmp[1]
        V.close()
        sys.exit()

def find_flaw():                                                # Find Security Flaw
    prompt1 = sys.argv[2]

    try:
        UncleanFile = open(prompt1,"r")
        
    except IOError:
        print
        print "No such file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    
    
    try:
        FunctionFile = open("function.db","r")
        
    except IOError:
        print
        print "Can't file database file, sorry."
        print "Now exiting program."
        print
        sys.exit()
    
    my_fn = {}
    my_fn_des = {}
       
    lines = 0
    for line in FunctionFile:
        lines += 1
        tmp_fn = line.split(":")
        my_fn[lines] = tmp_fn[0]
        my_fn_des[lines] = tmp_fn[1]
    
    print "Entries in C database:",lines-1,"\n"    
    
    comment_flag = 0
    flag = 0
    count = 1
    fileList = UncleanFile.readlines()   
    for lineStr in fileList:
        
        if comment_flag == 1:
            m = re.findall("\*/",lineStr)
            if m:
                n = lineStr.split("\*/")
                if n:
                    comment_flag = 0
                    lineStr = n[0]
      
        if comment_flag == 0:

            #lineStr = comment_multi(lineStr) 
            m = re.findall("/\*",lineStr)    #comment found
            if m:
                n = lineStr.split("/\*")    #split
                if n:
                    comment_flag = 1
                    lineStr = n[0]
                    
               
            
            #lineStr = comment_slash(lineStr)
            n = lineStr.split("//")
            lineStr = n[0]
    
       
            #---------------------
            n = re.findall("\w+\[\w+\]",lineStr)
            if n:
                flag = 1
                print "Line:",count,"Fixed sized buffer"
                
        o = re.findall("\*/",lineStr)
        if o:
            comment_flag = 0
                
        lineStr = UncleanFile.readline()
        
        #lineStr = comment_multi_end(lineStr)
        
        count = count + 1
        
    if flag == 1:
        print "Extra care should be taken to ensure that character arrays that are allocated on the stack are used safely. They are prime targets for buffer overflow attacks.\n"
    
    del fileList,lineStr
    UncleanFile.close()
    
    
    #---------------- FUNCTION ---------------------------------
    
    
    UncleanFile = open(prompt1,"r")
    fileList = UncleanFile.readlines()    
    
    for i in range(1,lines):
        comment_flag = 0
        count = 1
        flag = 0
        for lineStr in fileList:
            
            if comment_flag == 1:                    #in comment now
                #print "comment now in line", count
                m = re.findall("\*/",lineStr)
                if m:
                   n = lineStr.split("\*/")
                   if n:
                       comment_flag = 0
                       lineStr = n[0]
                       
            if comment_flag == 0:
                m = re.findall("/\*",lineStr)  #comment found
                if m:
                    #print "comment found in line", count
                    n = lineStr.split("/\*")        #split
                    if n:
                        comment_flag = 1
                        lineStr = n[0]   
            
            #lineStr = comment_slash(lineStr)
                n = lineStr.split("//")
                lineStr = n[0]
                
                if comment_flag == 0:
            #---------------------
                    m = re.search("[^\w]"+my_fn[i],lineStr)
                    if m: 
                        #print "Line:",count,":",m.group()
                        print "Line:",count,":",my_fn[i]
                        flag = 1
                        
            o = re.findall("\*/",lineStr)
            if o:
                comment_flag = 0
            
            lineStr = UncleanFile.readline()
            count = count + 1
        if flag == 1: 
            print (str(my_fn_des[i])).replace("\\n", "\n") 
    UncleanFile.close()    
    

if __name__ == "__main__":                                      # Main function
    if sys.argv[1] == "-u":  #update
        update()
    else: 
        if sys.argv[1] == "-v": #show version
            show_version()
        else: 
            if sys.argv[1] == "-r": # find array out bound
                find_arr(sys.argv[2])
            else:
                if sys.argv[1] == "-f": #find flaw
                    find_flaw()
                else:
                    print "Wrong Argument [-u ,-r ,-v ,-f]";
                    