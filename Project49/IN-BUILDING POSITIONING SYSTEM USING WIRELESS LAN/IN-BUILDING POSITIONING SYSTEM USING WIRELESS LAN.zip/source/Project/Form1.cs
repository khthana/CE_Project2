using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WifiCore;
using System.Management;
using System.Threading;
using System.IO;


namespace Project
{
    
    
    public partial class Form1 : Form
    {
        //--------------------------- Global Variable -------
        public static string Position;
        public static string NameUser;
        int E801; int E803; int E804;
        int E802; int E805; int E806;
        int E807; int E808; int E810;
        int E811; int SMC; int CENTER1;
        //--------------------------- Functions -------------
        
        //-------- Get AccessPoints ------
        private void getAp()
        {
            int sass = 0;
            // Bind the Wireless device to be used
            // We try to bind the best AP 
            while (sass != 1)
            {

                int signal = -300; // Signal is in decibel (from -20 to -200)
                string ssid = null;

                foreach (AccessPoint ap in WirelessManager.CurrentDevice.ScanAPList())
                {
                    if (ap.InfrastructureMode == NDIS_802_11_NETWORK_INFRASTRUCTURE.Ndis802_11Infrastructure &&
                        ap.SignalStrength > signal)
                    {
                        signal = ap.SignalStrength;
                        ssid = ap.SSID;
                    }
                    string apStr = Convert.ToString(ap.MAC);
                    string SsidStr = "SSID: " + ap.SSID;
                    string SignalStr = "Signal strength: " + ap.SignalStrength;
                    MapAccessPoint(apStr);
                }MapLoction();
                
                if (ssid != null && ssid != "")
                {
                    string Att = "Attempting to bind " + ssid;
                    WirelessManager.SSID = ssid;
                }
                sass++;
            }
        }
        private void MapLoction()
        {

            if ((E804 == 0) && (E806 == 0) && (E810 == 0) && (E811 == 0) && (E808 == 0) && (E807 == 1) && (E801 == 1) && (E802 == 1))
            {
                clearList();
                Position = "ECC807"; }
            if ((SMC != 1)||(CENTER1 !=1 ))
            {
                int[] test = new int[10];
                test[0] = E801; test[1] = E802;
                test[2] = E803; test[3] = E804;
                test[4] = E805; test[5] = E806;
                test[6] = E807; test[7] = E808;
                test[8] = E810; test[9] = E811;

                for (int yu = 0; yu < 10; yu++)
                {
                    if (test[yu] == 0)
                    {
                        test[yu] = 100;
                    }
                    else
                    {
                        test[yu] = test[yu];
                    }
                }
                test[0] = test[0] - 3; test[5] = test[5] - 4;
                test[1] = test[1] - 4; test[6] = test[6] - 1;
                test[2] = test[2] - 6; test[7] = test[7] - 6;
                test[3] = test[3] - 4; test[8] = test[8] - 2;
                test[4] = test[4] - 4; test[9] = test[9] - 2;

                for (int asd = 0; asd < 10; asd++)
                {
                    if (test[asd] < 0)
                    {
                        test[asd] = test[asd] * -1;
                    }else
                    {
                        test[asd] = test[asd];
                    }
                }
                int index = 0;
                int min = test[0];

                for (int asdf = 0; asdf < 10; asdf++)
                {
                    if (test[asdf] < min)
                    {
                        min = test[asdf];
                        index = asdf;
                    }
                }
                if (index == 0)
                {
                    clearList();
                    Position = "ECC801";
                }
                else if (index == 1)
                {
                    clearList();
                    Position = "ECC802";
                }
                else if (index == 2)
                {
                    clearList();
                    Position = "ECC803";
                }
                else if (index == 3)
                {
                    clearList();
                    Position = "ECC804";
                }
                else if (index == 4)
                {
                    clearList();
                    Position = "ECC805";
                }
                else if (index == 5)
                {
                    clearList();
                    Position = "ECC806";
                }
                else if (index == 6)
                {
                    clearList();
                    Position = "ECC807";
                }
                else if (index == 7)
                {
                    clearList();
                    Position = "ECC808";
                }
                else if (index == 8)
                {
                    clearList();
                    Position = "ECC810";
                }
                else if (index == 9)
                {
                    clearList();
                    Position = "ECC811";
                }

            }
            if ((SMC == 1) && (CENTER1 != 1))
            {
                clearList();
                Position = "ECC811";
            }else if((SMC != 1)&&(CENTER1 == 1))
            {
                clearList();
                Position = "ECC806";
            }

            

        }
        private void clearList()
        {
            E801 = 0;
            E802 = 0;
            E803 = 0;
            E804 = 0;
            E805 = 0;
            E806 = 0;
            E807 = 0;
            E808 = 0;
            E810 = 0;
            E811 = 0;
            SMC = 0;
            CENTER1 = 0;
        }


        //-------- MapAccessPoint --------
        private void MapAccessPoint(string accessPoint)
        {
                
            if(accessPoint == "00:0D:54:9C:CF:D8")    // Mac Address ��ҡѺ CE-ISAG
                {
                    E801 = E801 + 1;
                    E802 = E802 + 1;
                    E803 = E803 + 1;
                }
            if(accessPoint == "00:09:5B:D5:86:AE")  // Mac Address ��ҡѺ GRAD804
                {
                    E801 = E801 + 1;
                    E802 = E802 + 1;
                    E803 = E803 + 1;
                    E804 = E804 + 1;
                    E806 = E806 + 1;
                    E808 = E808 + 1;
                }
            if(accessPoint == "00:17:9A:C9:BA:F2")  // Mac Address ��ҡѺ ce_room901
                {
                    E801 = E801 + 1;
                    E802 = E802 + 1;
                    E807 = E807 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:1E")  // Mac Address ��ҡѺ 3Com(1E)
                {
                    E801 = E801 + 1;
                    E802 = E802 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:28")  // Mac Address ��ҡѺ CE_ACCESS704
                {
                    E803 = E803 + 1;
                    E804 = E804 + 1;
                    E808 = E808 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:1A")  // Mac Address ��ҡѺ CE_ACCESS910
                {
                    E803 = E803 + 1;
                    E804 = E804 + 1;
                    E806 = E806 + 1;
                    E807 = E807 + 1;
                    E808 = E808 + 1;
                    E810 = E810 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:26")  // Mac Address ��ҡѺ CE_ACCESS905(26)
                {
                    E803 = E803 + 1;
                    E804 = E804 + 1;
                    E806 = E804 + 1;
                    E808 = E808 + 1;
                    E810 = E810 + 1;
                    E811 = E811 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:2C")  // Mac Address ��ҡѺ CE_ACCESS905(2C)
                {
                    E803 = E803 + 1;
                    E804 = E804 + 1;
                    E806 = E806 + 1;
                    E808 = E808 + 1;
                    E810 = E810 + 1;
                    E811 = E811 + 1;

                }
            if(accessPoint == "00:0F:CB:C1:85:1C") // Mac Address ��ҡѺ 3Com(1C)
                {
                    E803 = E803 + 1;

                }
            if(accessPoint == "00:04:E2:E0:20:7A") // Mac Address ��ҡѺ Center1
                {
                    E806 = E806 + 1;
                    CENTER1 = 1;
                }
            if(accessPoint == "00:0F:CB:C1:85:22") // Mac Address ��ҡѺ CE_ACCESS708
                {
                    E808 = E808 + 1;
                }
                
            if (accessPoint == "00:0A:E9:0F:FF:E9") // Mac Address ��ҡѺ SMC
                {
                    E811 = E811 + 1;
                    SMC = 1;

                }         
        }

        //-------- Connect to Server --------
        private void ConnectServer()
        {
            NameUser = textBox1.Text;
 
        }

        //-------------------------- Form ------------------
        public Form1()
        {
            InitializeComponent();
            //------ wireless start --------
            WirelessManager.Init();
            foreach (NdisDevice d in WirelessManager.EnumerateDevices())
            {
                // FIXMD: At the moment we can't decide the type of NIC (either 802.3 or 802.11)
                // We assume that the description of the card helps us
                if (d.Description.IndexOf("Wireless") != -1 || d.Description.IndexOf("WLAN") != -1)
                {
                    WirelessManager.CurrentDevice = d;
                    break;
                }
            }
        }


        //------------ Exit Program -------
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        

        //------------ Login --------------
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                progressBar1.Value = 0;
                Thread ns = new Thread(new ThreadStart(getAp));
                ns.Start();
                for (int i = 0; i < 100; i++)
                {
                    if (i != 100)
                    {
                        progressBar1.Value += 1;
                        progressBar1.Show();
                        Thread.Sleep(200);
                    }
                    if (progressBar1.Value == 100)
                    {                      
                        NameUser = textBox1.Text;
                        Form2 F2 = new Form2();
                        this.Hide();
                        F2.Show();
                    }
                }
            }
            else
            {
                textBox1.Text = "Please Insert Name To Login";
            }
        }
    }
}