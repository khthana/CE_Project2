/// File: ManagedWiFi\WifiCore\MWrapi.cs
/// 
/// ------------------------------------------------------------
/// Copyright (c) 2004
///   Antonio Cisternino (cisterni.unipi.it),
///   Diego Colombo      (colombod.unipi.it),
///   Giorgio Ennas      (   ennas.unipi.it),
///   Daniele Picciaia   (picciaia.unipi.it)
/// 
/// The use and distribution terms for this software are 
/// contained in the file named license.txt, which can be found 
/// in the root of this distribution.
/// By using this software in any fashion, you are agreeing to 
/// be bound by the terms of this license.
///
/// You must not remove this notice, or any other, from this
/// software.
/// ------------------------------------------------------------

using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using WiFiException = System.IO.IOException;

namespace WifiCore 
{
	using Handle = IntPtr;

	/// <summary>
	/// Purpose of this class is to Manage WiFi connections.
	/// The class relies on PInvoke to call DeviceIoControl, CreateFile, and
	/// CloseHandle.
	/// </summary>
	public class WirelessManager : IEnumerable
	{
		#region PInvoke definitions
		/// <summary>
		/// PInvoke version of DeviceIoControl. See MSDN documentation for further
		/// information. Note that the PInvoke version hasn't been tested with
		/// overlapped I/O.
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern bool DeviceIoControl(Handle hDevice,
			IOCTL dwIoControlCode, IntPtr lpInBuffer, int nInBufferSize,
			IntPtr lpOutBuffer, int nOutBufferSize, out int lpBytesReturned,
			IntPtr lpOverlapped);

		/// <summary>
		/// PInvoke version of CreateFile. See MSDN documentation for further
		/// information. The constants used and their values in this library are
		/// reported nearby parameters.
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern Handle CreateFile(
			// file name
			string FileName,
			// access mode GENERIC_READ = 0x80000000, GENERIC_WRITE = 0x40000000
			uint DesiredAccess,
			// share mode 0
			uint ShareMode,
			// Security Attributes NULL
			uint SecurityAttributes,
			// how to create OPEN_EXISTING = 3
			uint CreationDisposition,
			// file attributes FILE_ATTRIBUTE_NORMAL = 0x80
			uint FlagsAndAttributes,
			// handle to template file INVALID_HANDLE_VALUE = -1
			int hTemplateFile
			);

		/// <summary>
		/// PInvoke version of CloseHandle. It is used to close the interface to
		/// the Ndisuio file.
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern bool CloseHandle(Handle h);

		/// <summary>
		/// PInvoke version of Format Message. See MSDN documentation for further
		/// information.
		/// Warning! This function is imported to be used only in the
		/// way GetLastErrorMessage() does!
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern int FormatMessage(
			int dwFlags,
			string lpSource,
			int dwMessageId,
			int dwLanguageId,
			[MarshalAs(UnmanagedType.LPStr)]System.Text.StringBuilder lpBuffer,
			int nSize,
			IntPtr Arguments
			);

		/// <summary>
		/// Constant to be used with CreateFile.
		/// </summary>
		private const uint GENERIC_READ = 0x80000000;

		/// <summary>
		/// Constant to be used with CreateFile.
		/// </summary>
		private const uint GENERIC_WRITE = 0x40000000;

		/// <summary>
		/// Constant to be used with CreateFile.
		/// </summary>
		private const uint OPEN_EXISTING = 3;

		/// <summary>
		/// Constant to be used with CreateFile.
		/// </summary>
		private const uint FILE_ATTRIBUTE_NORMAL = 0x80;
		
		/// <summary>
		/// Constant to be used with CreateFile.
		/// </summary>
		private const int INVALID_HANDLE_VALUE = -1;

		/// <summary>
		/// Constant to be used with FormatMessage
		/// </summary>
		private const int FORMAT_MESSAGE_FROM_SYSTEM = 0x1000;

		/// <summary>
		/// Constant to be used with FormatMessage
		/// </summary>
		private const int FORMAT_MESSAGE_IGNORE_INSERTS = 0x200;

		/// <summary>
		/// Constant to be used with DeviceIoControl
		/// </summary>
		private const int ERROR_NO_MORE_ITEMS = 259;

		#endregion

		/// <summary>
		/// File name of Ndisuio driver.
		/// </summary>
		private const string NDIS_FILE_NAME = @"\\.\\Ndisuio";
		/// <summary>
		/// Handle to the NDISUIO driver returned by CreateFile in Init().
		/// </summary>
		private static Handle DriverHandle = Handle.Zero;
		/// <summary>
		/// Lock object to ensure mutual exclusion accessing to the driver.
		/// </summary>
		private static object WiFiLock = new object();

		/// <summary>
		/// Initialize the WirelessManager by establishing a connection with
		/// the NDISUIO driver. After CreateFile the IOCTL_NDISUIO_BIND_WAIT
		/// message is sent to the driver.
		/// </summary>
		public static void Init() 
		{
			ServiceController svc = new ServiceController("WZCSVC");
			if (svc.Status == ServiceControllerStatus.Running)
			{
				svc.Stop();
				svc.WaitForStatus(ServiceControllerStatus.Stopped);
			}
			lock (WiFiLock) 
			{
				if (DriverHandle != Handle.Zero)
					throw new WiFiException("Wireless connection already initialized!");

				DriverHandle = CreateFile(NDIS_FILE_NAME, 
					GENERIC_READ | GENERIC_WRITE, 0, 0, 
					OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
					INVALID_HANDLE_VALUE);

				int BytesReturned;
				if (!DeviceIoControl(DriverHandle,
					IOCTL.IOCTL_NDISUIO_BIND_WAIT,
					IntPtr.Zero,
					0,
					IntPtr.Zero,
					0,
					out BytesReturned,
					Handle.Zero)) 
				{
					CloseHandle(DriverHandle);
					DriverHandle = Handle.Zero;
					throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
				}
			}
		}

		/// <summary>
		/// Buffer used to interact with the driver. This is shared among the calls
		/// and it is synchronized using the WiFiLock object.
		/// </summary>
		private static byte[] Buffer = new byte[8192];

		/// <summary>
		/// The devices found during the last invocation of EnumerateDevices.
		/// The array is initialized to the array of 0 length.
		/// </summary>
		private static NdisDevice[] devices = new NdisDevice[]{};
		
		/// <summary>
		/// Return an array of the devices found during the last invocation of
		/// EnumerateDevices. Before the first invocation of EnumerateDevices
		/// an array of zero length is returned.
		/// </summary>
		public static NdisDevice[] Devices 
		{
			get 
			{
				return (NdisDevice[]) devices.Clone(); // Clone is for safety!
			}
		}

		/// <summary>
		/// Get a Device Enumerator
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return devices.GetEnumerator();
		}

		/// <summary>
		/// Enumerate the NDIS devices in the system. BEWARE: you may get not only
		/// 802.11 devices! Also 802.3 cards are returned through this method.
		/// The list is obtained by sending the IOCTL_NDISUIO_QUERY_BINDING message.
		/// </summary>
		/// <returns>
		/// An array of objects representing system devices. If no devices are found
		/// an array with zero elements is returned.
		/// </returns>
		public static NdisDevice[] EnumerateDevices() 
		{
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int	dwBytesWritten;

						// Used to guarantee device identity
						Hashtable dev = new Hashtable();
						foreach (NdisDevice d in devices)
							dev[d.Name] = d;
						ArrayList newList = new ArrayList();

						NDISUIO_QUERY_BINDING* p = (NDISUIO_QUERY_BINDING*)buf;
	
						for (uint i = 0; /* Nothing */; i++) 
						{
							p->BindingIndex = i;
							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_BINDING,
								new IntPtr(p),
								sizeof(NDISUIO_QUERY_BINDING),
								new IntPtr(buf),
								Buffer.Length,
								out dwBytesWritten,
								IntPtr.Zero)) 
							{
								string devName, devDesc;
								NdisDevice d = null;

								// -2 to avoid the trailing \0\0!
								devName = new String((sbyte*)p, (int)p->DeviceNameOffset, (int)p->DeviceNameLength - 2, System.Text.Encoding.Unicode);
								if (!dev.ContainsKey(devName)) 
								{
									devDesc = new String((sbyte*)p, (int)p->DeviceDescrOffset, (int)p->DeviceDescrLength - 2, System.Text.Encoding.Unicode);
									d = new NdisDevice(devName, devDesc);
								} 
								else
									d = (NdisDevice)dev[devName];

								newList.Add(d);
			
								Array.Clear(Buffer, 0, Buffer.Length);
							} 
							else if (Marshal.GetLastWin32Error() != ERROR_NO_MORE_ITEMS)
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
							else
								break;
						}
						devices = (NdisDevice[])newList.ToArray(typeof(NdisDevice));
						return devices;
					}
				}
			}
		}

		/// <summary>
		/// This field holds the reference to the current
		/// device. Only a device at a time can be opened.
		/// </summary>
		private static NdisDevice current = null;

		/// <summary>
		/// This property represents the current opened device. If no device has
		/// been opened its value is null.
		/// Assigning a device to the property results in opening the corresponding
		/// device.
		/// BEWARE: If you assign to this property in a shared environment you may
		/// get undesired behavior.
		/// </summary>
		public static NdisDevice CurrentDevice 
		{
			get { return current; }
			set 
			{
				if (current != null) 
				{
					Close();
					Init();
				}
				string name = value.Name + "\0";
				int bytesReturned;
				unsafe 
				{
					fixed (char* s = name) 
					{
						if (!DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_OPEN_DEVICE,
							new IntPtr((void*)s),
							2*value.Name.Length,
							IntPtr.Zero,
							0,
							out bytesReturned,
							IntPtr.Zero))
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						current = value;
					}
				}
			}
		}

		/// <summary>
		/// This property represents the SSID of the current wireless network.
		/// The property simply issues a OID_802_11_SSID query to the NDISUIO
		/// driver.
		/// If you set the SSID you change the network associated with the device.
		/// </summary>
		public static string SSID 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID* pQueryOid;
							int bytesReturned;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_SSID;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero)) 
							{
								NDIS_802_11_SSID* ssid = (NDIS_802_11_SSID*) &(pQueryOid->Data);
								return new String((sbyte*)&(ssid->Ssid_0), 0, (int)ssid->SsidLength, System.Text.Encoding.ASCII);
							} 
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_SET_OID*			pSetOid;
							pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_SSID;
							NDIS_802_11_SSID*			SSID = (NDIS_802_11_SSID*)&pSetOid->Data;

							SSID->SsidLength = (uint)value.Length;
							sbyte* p = (sbyte*)&(SSID->Ssid_0);
							for (int i = 0; i < value.Length; i++) *p++ = (sbyte)value[i];

							int bytesReturned;
		
							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID)+sizeof(NDIS_802_11_SSID),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero))
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}
		/// <summary>
		/// When set, the OID_11_RTS_THRESHOLD OID requests the miniport driver to
		/// set the Request To Send (RTS) threshold to a specified value. This
		/// value, which is specified in bytes, specifies the packet size beyond
		/// which the 802.11 wireless LAN invokes its RTS/CTS mechanism. Packets
		/// that exceed the specified RTS threshold trigger the RTS/CTS mechanism.
		/// The NIC transmits smaller packets without using RTS/CTS. An RTS
		/// threshold value of zero indicates that the NIC should transmit all
		/// packets using RTS/CTS.
		/// When queried, this OID requests the miniport driver to return its NIC's
		/// RTS threshold setting.
		/// </summary>
		public static uint RTSThreshold 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_RTS_THRESHOLD;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return pQueryOid->Data;
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_RTS_THRESHOLD;
							pSetOid->Data = value;

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_FRAGMENTATION_THRESHOLD OID requests that the
		/// miniport driver set the NIC's packet fragmentation threshold to a
		/// specified value. The fragmentation threshold, which is specified in
		/// bytes, determines whether packets will be fragmented and at what size.
		/// On an 802.11 wireless LAN, packets that are larger than the
		/// fragmentation threshold are fragmented. Packets that are smaller than
		/// the specified fragmentation threshold value are not fragmented. A
		/// fragmentation threshold of zero indicates that the NIC should not
		/// fragment packets.
		/// When queried, this OID requests the miniport driver to return the
		/// fragmentation threshold setting.
		/// </summary>
		public static uint FragmentationThreshold 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_FRAGMENTATION_THRESHOLD;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return pQueryOid->Data;
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_FRAGMENTATION_THRESHOLD;
							pSetOid->Data = value;

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_POWER_MODE OID requests the miniport driver to
		/// set the power mode of the 802.11 NIC to the specified value.
		/// When queried, this OID requests that the miniport driver return the
		/// power mode of the 802.11 NIC.
		/// The power modes that can be assigned to the 802.11 NIC are defined in the
		/// NDIS_802_11_POWER_MODE enumeration as follows: 
		/// 
		/// Ndis802_11PowerModeCAM: Specifies continuous access mode (CAM). When
		///   the power mode is set to CAM, the device is always on.
		/// Ndis802_11PowerModeMAX_PSP: Specifies maximum (MAX) power saving. A
		///   power mode of MAX results in the greatest power savings for the
		///   802.11 NIC radio. 
		/// Ndis802_11PowerModeFast_PSP: Specifies fast power-saving mode. This
		///   power mode provides the best combination of network performance and
		///   power usage.
		/// </summary>
		public static NDIS_802_11_POWER_MODE PowerMode 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_POWER_MODE;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return (NDIS_802_11_POWER_MODE)(*((int*)&(pQueryOid->Data)));
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_POWER_MODE;
							int data = (int)value;
							pSetOid->Data = *((uint*)&data);

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// The OID_802_11_NETWORK_TYPES_SUPPORTED OID requests the miniport driver
		/// to return an array of all physical layer network subtypes that the
		/// 802.11 NIC and the driver support.
		/// </summary>
		public static NDIS_802_11_NETWORK_TYPE[] NetworkTypes 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_NETWORK_TYPES_SUPPORTED;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero)) 
							{
								int* data = (int*)&(pQueryOid->Data);
								int count = *data++;
								NDIS_802_11_NETWORK_TYPE[] ret = new NDIS_802_11_NETWORK_TYPE[count];
								for (int i = 0; i < count; i++)
									ret[i] = (NDIS_802_11_NETWORK_TYPE)(*data++);
								return ret;
							} 
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_NETWORK_TYPE_IN_USE OID requests the miniport
		/// driver to set type information about the physical layer network used
		/// by the 802.11 NIC to a specified value.
		/// When queried, this OID requests the miniport driver to return the type
		/// information.
		/// The NDIS_802_11_NETWORK_TYPE enumeration specifies network subtype
		/// values for the physical layer. The network subtypes are defined as
		/// follows:
		/// 
		/// Ndis802_11FH: Indicates the physical layer of the frequency hopping
		///   spread-spectrum radio.
		/// Ndis802_11DS: Indicates the physical layer of the direct sequencing
		///   spread-spectrum radio.
		/// </summary>
		public static NDIS_802_11_NETWORK_TYPE NetworkTypeInUse 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_NETWORK_TYPE_IN_USE;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return (NDIS_802_11_NETWORK_TYPE)(*((int*)&(pQueryOid->Data)));
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_NETWORK_TYPE_IN_USE;
							int data = (int)value;
							pSetOid->Data = *((uint*)&data);

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// The OID_802_11_RSSI OID requests the miniport driver to return the
		/// received signal strength indication (RSSI) in response to a query or as
		/// a status indication event.
		/// If status indications are enabled with OID_802_11_RSSI_TRIGGER, the
		/// miniport driver must call NdisMIndicateStatus to provide notification
		/// values according to the RSSI that was specified in the
		/// OID_802_11_RSSI_TRIGGER set. Normal values for the RSSI value are
		/// between -10 and -200.
		/// </summary>
		public static int SignalStrength 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_RSSI;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return *((int*)&(pQueryOid->Data));
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// The OID_802_11_NUMBER_OF_ANTENNAS OID requests the miniport driver to
		/// return the number of antennas on the NIC's radio.
		/// </summary>
		public static uint NumberOfAntennas 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_NUMBER_OF_ANTENNAS;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return pQueryOid->Data;
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_TX_POWER_LEVEL OID requests the miniport driver
		/// to set the transmit power level of the 802.11 NIC to a specified value.
		/// The NDIS_802_11_TX_POWER_LEVEL value is specified in milliwatts (mW).
		/// When queried, this OID requests the miniport driver to return the
		/// transmit power level of the 802.11 NIC.
		/// </summary>
		public static uint TxPowerLevel 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_TX_POWER_LEVEL;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return pQueryOid->Data;
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_TX_POWER_LEVEL;
							pSetOid->Data = value;

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								IntPtr.Zero,
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_INFRASTRUCTURE_MODE OID requests the miniport
		/// driver to set the 802.11 NIC's infrastructure mode to a specified
		/// value. The infrastructure mode determines how the 802.11 NIC connects
		/// to the network. Setting the infrastructure mode resets the network
		/// association algorithm.
		/// When queried, this OID requests the miniport driver to return the
		/// 802.11 NIC's infrastructure mode setting.
		/// This OID uses the NDIS_802_11_NETWORK_INFRASTRUCTURE enumeration, which
		/// is defined as follows:
		/// 
		/// Ndis802_11IBSS: Specifies the independent basic service set (IBSS)
		///   mode. This mode is also known as ad hoc mode. 
		/// Ndis802_11Infrastructure: Specifies the infrastructure mode.
		/// Ndis802_11AutoUnknown: Specifies an automatic mode. In this mode, the
		///   802.11 NIC can switch between ad hoc and infrastructure modes as required.
		/// </summary>
		public static NDIS_802_11_NETWORK_INFRASTRUCTURE NetworkMode 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_INFRASTRUCTURE_MODE;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return (NDIS_802_11_NETWORK_INFRASTRUCTURE)(*((int*)&(pQueryOid->Data)));
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_INFRASTRUCTURE_MODE;
							int data = (int)value;
							pSetOid->Data = *((uint*)&data);

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_AUTHENTICATION_MODE OID requests the miniport
		/// driver to set its NIC's 802.11 authentication mode to a specified
		/// value.
		/// When queried, this OID requests the miniport driver to return its NIC's
		/// 802.11 authentication mode.
		/// The NDIS_802_11_AUTHENTICATION_MODE enumeration defines the
		/// authentication modes as follows:
		/// 
		/// Ndis802_11AuthModeOpen: Specifies 802.11 open authentication mode.
		///   There are no checks when accepting clients in this mode. 
		/// Ndis802_11AuthModeShared: Specifies 802.11 shared authentication that
		///   uses a pre-shared wired equivalent privacy (WEP) key. 
		/// Ndis802_11AuthModeAutoSwitch: Specifies auto-switch mode. When using
		///   auto-switch mode, the NIC tries 802.11 shared authentication mode
		///   first. If shared mode fails, the NIC attempts to use 802.11 open
		///   authentication mode.
		/// </summary>
		public static NDIS_802_11_AUTHENTICATION_MODE AuthenticationMode 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							NDISUIO_QUERY_OID	*pQueryOid;

							pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_AUTHENTICATION_MODE;

							int bytesReturned;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return (NDIS_802_11_AUTHENTICATION_MODE)(*((int*)&(pQueryOid->Data)));
							else
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_AUTHENTICATION_MODE;
							int data = (int)value;
							pSetOid->Data = *((uint*)&data);

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(uint),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero)) 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// When set, the OID_802_11_CONFIGURATION OID requests the miniport driver
		/// to set the NIC's radio configuration parameters to specified values.
		/// When queried, this OID requests the miniport driver to return the NIC's
		/// current radio configuration.
		/// This OID uses an NDIS_802_11_CONFIGURATION structure, which describes
		/// the configuration of a radio.
		/// The members of this structure contain the following information:
		/// 
		/// Length: Specifies the length of the NDIS_802_11_CONFIGURATION structure
		///   in bytes.
		/// BeaconPeriod: Specifies the interval between beacon message
		///   transmissions. This value is specified in K�sec (1024 �sec). 
		/// ATIMWindow: Specifies the announcement traffic information message
		///   (ATIM) window in K�sec (1024 �sec). The ATIM window is a short time
		///   period immediately after the transmission of each beacon in an IBSS
		///   configuration. During the ATIM window, any station can indicate the
		///   need to transfer data to another station during the following data-
		///   transmission window.
		/// DSConfig: Specifies the frequency of the selected channel in kHz. 
		/// FHConfig: Specifies the frequency hopping configuration in an
		///   NDIS_802_11_CONFIGURATION_FH structure.
		///   The members of NDIS_802_11_CONFIGURATION_FH structure contain the
		///   following information:
		///   Length:	Specifies the length of the NDIS_802_11_CONFIGURATION_FH
		///     structure in bytes.
		///   HopPattern: Specifies the hop pattern used to determine the hop
		///     sequence. As defined by the 802.11 standard, the layer management
		///     entity (LME) of the physical layer uses a hop pattern to determine
		///     the hop sequence.
		///   HopSet: Specifies a set of patterns. The LME of the physical layer
		///     uses these patterns to determine the hop sequence.
		///   DwellTime: Specifies the maximum period of time during which the
		///     transmitter should remain fixed on a channel. This interval is
		///     described in K�sec (1024 �sec). 
		/// </summary>
		public static NDIS_802_11_CONFIGURATION Configuration 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;

							NDISUIO_QUERY_OID* pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_CONFIGURATION;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return *((NDIS_802_11_CONFIGURATION*) &pQueryOid->Data);
							else 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
			set 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
							pSetOid->Oid = OID.OID_802_11_CONFIGURATION;

							*((NDIS_802_11_CONFIGURATION*)&pSetOid->Data) = value;

							if (!DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
								new IntPtr(buf),
								sizeof(OID) + sizeof(NDIS_802_11_CONFIGURATION),
								new IntPtr(buf),
								0,
								out bytesReturned,
								IntPtr.Zero))
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// The OID_802_11_STATISTICS OID requests the miniport driver to return
		/// the current statistics for the 802.11 interface.
		/// The members of this structure contain the following information:
		/// 
		/// Length: Specifies the length of the NDIS_802_11_STATISTICS structure in
		///   bytes.
		/// TransmittedFragmentCount: Indicates the number of data and management
		///   fragments that the NIC has successfully transmitted. 
		/// MulticastTransmittedFrameCount: Indicates the number of frames that the
		///   NIC has transmitted by multicast or broadcast. This count is
		///   incremented each time that the multicast/broadcast bit is set in the
		///   destination MAC address of a transmitted frame.
		/// FailedCount: Indicates the number of NIC frame transmissions that
		///   failed after exceeding either the short frame or the long frame retry
		///   limits.
		/// RetryCount: Indicates the number of frames that the NIC successfully
		///   retransmitted after one or more retransmission attempts.
		/// MultipleRetryCount: Indicates the number of frames that the NIC
		///   successfully retransmitted after more than one retransmission attempt.
		/// RTSSuccessCount: Indicates the number of times that the NIC received a
		///   CTS in response to an RTS.
		/// RTSFailureCount: Indicates the number of times that the NIC did not
		///   receive a CTS in response to an RTS.
		/// ACKFailureCount: Indicates the number of times that the NIC expected an
		///   ACK that was not received.
		/// FrameDuplicateCount: Indicates the number of duplicate frames that were
		///   received. The sequence control field in the frameidentifies duplicate
		///   frames.
		/// ReceivedFragmentCount: Indicates the number of data and management
		///   fragments that the NIC has successfully received. This count is
		///   incremented each time that either a data fragment or a management
		///   fragment is received.
		/// MulticastReceivedFrameCount: Indicates the number of received frames
		///   that were set to multicast or broadcast. This count is incremented
		///   each time the NIC receives a frame with the multicast/broadcast bit
		///   set in the destination MAC address.
		/// FCSErrorCount: Indicates the number of frames the NIC received that
		///   contained FCS errors.
		/// </summary>
		public static NDIS_802_11_STATISTICS PacketStatistics 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int bytesReturned;
							NDISUIO_QUERY_OID* pQueryOid = (NDISUIO_QUERY_OID*) buf;
							pQueryOid->Oid = OID.OID_802_11_STATISTICS;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero))
								return *((NDIS_802_11_STATISTICS*) &pQueryOid->Data);
							else 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// The OID_802_11_BSSID_LIST_SCAN OID requests the miniport driver to
		/// direct the 802.11 NIC to request a survey of BSSs. No data is
		/// associated with this OID. The NIC will use the following parameters,
		/// set as defined in the 802.11 specifications, in its request:
		/// 
		/// - BSSType indicates that both the infrastructure BSS and independent
		///   BSS are used.
		/// - BSSID indicates that the BSSID is broadcast.
		/// - SSID indicates that the SSID is broadcast.
		/// - ScanType indicates active, passive, or a combination of both passive
		///   and active scanning approaches.
		/// - ChannelList indicates all permitted frequency channels.
		/// 
		/// The NIC use active or passive scanning methods or a combination of both
		/// passive and active scanning methods to perform a scan. It might also
		/// refresh the list of BSSIDs in its database.
		/// The NIC should minimize the response time for this OID. Active scanning
		/// is preferred, when possible.
		/// The NIC's database includes BSSIDs for all BSS's responding on
		/// frequency channels that are permitted in the region in which the NIC is
		/// operating.
		/// Note  If the NIC is associated with a particular BSSID and SSID that
		/// are not contained in the list of BSSIDs generated by this scan, the
		/// BSSID description of the currently associated BSSID and SSID should be
		/// appended to the list of BSSIDs in the NIC's database.
		/// Note  This OID might be called very frequently (for example, every five
		/// seconds). Miniport drivers should minimize the performance impact of
		/// servicing this OID. A query of this OID should not cause the NIC to
		/// associate with a different access point.
		/// </summary>
		/// <param name="dev">Device that should start the AP Scan.</param>
		internal static void StartAPScan(NdisDevice dev) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int bytesReturned;
						NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
						pSetOid->Oid = OID.OID_802_11_BSSID_LIST_SCAN;

						if (!DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
							new IntPtr(buf),
							sizeof(NDISUIO_SET_OID),
							new IntPtr(buf),
							0,
							out bytesReturned,
							IntPtr.Zero))
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
					}
				}
			}
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// The OID_802_11_BSSID_LIST OID requests the miniport driver to return a
		/// list containing all BSSIDs and their attributes, as listed in the
		/// 801.11 NIC's database. This list contains all the BSSs that the NIC
		/// detected during its most recent survey of BSSs. The miniport driver
		/// should respond immediately to this OID.
		/// Note: If this OID is called while the NIC is active without a preceding
		/// OID_802_11_BSSID_LIST_SCAN, it might return a list of BSSIDs limited to
		/// those IDs included in the NIC's current configuration. However, if this
		/// OID is called at least six seconds after OID_802_11_BSSID_LIST_SCAN,
		/// the list of BSSIDs should contain all the BSSIDs found during the
		/// OID_802_11_BSSID_LIST_SCAN.
		/// </summary>
		/// <param name="dev">Device that should be queried for APs</param>
		/// <returns>
		/// The list of access point cached by the device during the last scan
		/// </returns>
		internal static AccessPoint[] GetAPList(NdisDevice dev) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int bytesReturned;
						NDISUIO_QUERY_OID* pQueryOid = (NDISUIO_QUERY_OID*) buf;
						pQueryOid->Oid = OID.OID_802_11_BSSID_LIST;

						if (DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
							new IntPtr(buf),
							Buffer.Length,
							new IntPtr(buf),
							Buffer.Length,
							out bytesReturned,
							IntPtr.Zero)) 
						{
							uint count = *((uint*)&(pQueryOid->Data));
							NDIS_WLAN_BSSID* data = (NDIS_WLAN_BSSID*)(((byte*)&(pQueryOid->Data)) + sizeof(uint));

							Hashtable apCache = new Hashtable(dev.accessPoints.Length);
							foreach (AccessPoint ap in dev.accessPoints)
								apCache[ap.mac] = ap;

							if (dev.accessPoints.Length != count)
								dev.accessPoints = new AccessPoint[count];

							for (int i = 0; i < count; i++) 
							{
								MacAddress curMac = data->MAC;
								AccessPoint ap = apCache.ContainsKey(curMac) ?
									(AccessPoint)apCache[curMac] :
									new AccessPoint(curMac, data->Rssi, data->InfrastructureMode,
									new String((sbyte*)&(data->Ssid.Ssid_0), 0, 
									(int)data->Ssid.SsidLength, System.Text.Encoding.ASCII));
								ap.signalStrength = data->Rssi;
								dev.accessPoints[i] = ap;

								// data++;

								byte* newpos = (byte*)data + data->Length;
								data = (NDIS_WLAN_BSSID*)newpos;
							}
							return dev.accessPoints;
						} 
						else 
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
					}
				}
			}
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// This method combines StartAPScan() and GetAPList ensuring 6 seconds of
		/// pause between the two calls. This ensures that the list returned by
		/// GetAPList is the most updated.
		/// </summary>
		/// <param name="dev">Device that should be queried for APs</param>
		/// <returns>
		/// The list of access point cached by the device during the last scan
		/// </returns>
		internal static AccessPoint[] ScanAPList(NdisDevice dev) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			StartAPScan(dev);
			System.Threading.Thread.Sleep(6000);
			return GetAPList(dev);
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// When set, the OID_802_11_BSSID OID requests a miniport driver to set
		/// the media access control (MAC) address of the access point associated
		/// with the NIC to a specified value.
		/// When queried, this OID requests the miniport driver to return the MAC
		/// address of the associated access point. The miniport driver should
		/// return an error code of NDIS_STATUS_ADAPTER_NOT_READY if the NIC is not
		/// associated with an access point.
		/// </summary>
		/// <param name="dev">Device to be queried</param>
		/// <returns>The mac address of the AP associated with the device</returns>
		internal static MacAddress GetAssociatedAP(NdisDevice dev) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int bytesReturned;
						NDISUIO_QUERY_OID* pQueryOid = (NDISUIO_QUERY_OID*) buf;
						pQueryOid->Oid = OID.OID_802_11_BSSID;

						if (DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
							new IntPtr(buf),
							Buffer.Length,
							new IntPtr(buf),
							Buffer.Length,
							out bytesReturned,
							IntPtr.Zero))
							return *((MacAddress*)&(pQueryOid->Data));
						else 
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
					}
				}
			}
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// When set, the OID_802_11_BSSID OID requests a miniport driver to set
		/// the media access control (MAC) address of the access point associated
		/// with the NIC to a specified value.
		/// When queried, this OID requests the miniport driver to return the MAC
		/// address of the associated access point. The miniport driver should
		/// return an error code of NDIS_STATUS_ADAPTER_NOT_READY if the NIC is not
		/// associated with an access point.
		/// </summary>
		/// <param name="dev">Device to be changed</param>
		/// <param name="ap">Access Point to associate with the device</param>
		internal static void SetAssociatedAP(NdisDevice dev, AccessPoint ap) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int bytesReturned;
						NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*) buf;
						pSetOid->Oid = OID.OID_802_11_BSSID;

						*((MacAddress*)&(pSetOid->Data)) = ap.mac;

						if (!DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
							new IntPtr(buf),
							sizeof(OID) + sizeof(MacAddress),
							new IntPtr(buf),
							0,
							out bytesReturned,
							IntPtr.Zero))
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
					}
				}
			}
		}

		/// <summary>
		/// This method is invoked by a NdisDevice. It is defined in this class
		/// for homogeneity, though the device object is required to perform the
		/// request.
		/// The OID_802_11_DISASSOCIATE OID requests the miniport driver to command
		/// its NIC to disassociate from the current service set and turn off the
		/// radio. No data is associated with this OID.
		/// If the NIC is associated with an access point when the miniport driver
		/// receives this OID, then the miniport driver should indicate a disconnect
		/// event upon a successful disassociation.
		/// The miniport driver should maintain a list of the current service set
		/// Ids (SSIDs). Once a NIC has disassociated from an SSID, it should not
		/// use it again until it has associated with all other SSIDs or until
		/// OID_802_11_INFRASTRUCTURE_MODE has been set. If the NIC is not
		/// associated with an access point, the miniport driver should return an
		/// error code of NDIS_STATUS_ADAPTER_NOT_READY in response to 
		/// OID_802_11_DISASSOCIATE.
		/// </summary>
		/// <param name="dev">Device to disassociate</param>
		internal static void DisassociateAP(NdisDevice dev) 
		{
			if (dev != current)
				throw new WiFiException("WiFiMan: The device isn't the currently open one!");
			lock (WiFiLock) 
			{
				unsafe 
				{
					fixed (byte* buf = Buffer) 
					{
						int bytesReturned;
						NDISUIO_SET_OID* pSetOid = (NDISUIO_SET_OID*)buf;
						pSetOid->Oid = OID.OID_802_11_DISASSOCIATE;

						if (!DeviceIoControl(DriverHandle,
							IOCTL.IOCTL_NDISUIO_SET_OID_VALUE,
							new IntPtr(buf),
							sizeof(NDISUIO_SET_OID),
							new IntPtr(buf),
							0,
							out bytesReturned,
							IntPtr.Zero)) 
							throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage())); 
						else
							SSID = "Wireless&"; // Some device require the SSID to be set as Wireless& to get disassociated
					}
				}
			}
		}

		/// <summary>
		/// Return an 8 array of bytes according with the outcome of
		/// OID_802_11_DESIRED_RATES message.
		/// When set, the OID_802_11_DESIRED_RATES OID requests the miniport driver
		/// to set its NIC's set of data transmission rates to the values specified
		/// in an array. This array specifies the rates that are desirable for
		/// operation within the current wireless network.
		/// When queried, this OID requests the miniport driver to return its NIC's
		/// set of data transmission rates.
		/// This OID uses the NDIS_802_11_RATES array. This array is defined as
		/// follows:
		/// 
		/// typedef  UCHAR   NDIS_802_11_RATES[8];
		/// 
		/// This array contains a set of 8 octets. Each octet specifies a desired
		/// data rate in units of 0.5 Mbps.
		/// The 802.11 network might transmit packets at rates other than the basic
		/// rates. The NIC can receive data at rates other than the rates included
		/// in the BSSBasicRateSet. For a description of the supported rates, see
		/// OID_802_11_SUPPORTED_RATES.
		/// </summary>
		public static byte[] DesiredRates 
		{
			get 
			{
				lock (WiFiLock) 
				{
					unsafe 
					{
						fixed (byte* buf = Buffer) 
						{
							int	bytesReturned;

							NDISUIO_QUERY_OID* pQueryOid = (NDISUIO_QUERY_OID*)buf;
							pQueryOid->Oid = OID.OID_802_11_DESIRED_RATES;

							if (DeviceIoControl(DriverHandle,
								IOCTL.IOCTL_NDISUIO_QUERY_OID_VALUE,
								new IntPtr(buf),
								Buffer.Length,
								new IntPtr(buf),
								Buffer.Length,
								out bytesReturned,
								IntPtr.Zero)) 
							{
								byte[] ret = new byte[8];
								byte* data = (byte*)&(pQueryOid->Data);
								for (int i = 0; i < 8; i++ ) 
								{
									ret[i] = *data++;
								}
								return ret;
							} 
							else 
								throw new WiFiException(string.Format("WiFiMan: {0}", GetLastErrorMessage()));
						}
					}
				}
			}
		}

		/// <summary>
		/// Close the WirelessManager connection with the Ndisuio driver. It resets
		/// the internal state of the manager.
		/// </summary>
		public static void Close() 
		{
			CloseHandle(DriverHandle);
			DriverHandle = Handle.Zero;
			current = null;
			devices = new NdisDevice[0];
			ServiceController svc = new ServiceController("WZCSVC");
			if (svc.Status == ServiceControllerStatus.Stopped)
			{
				svc.Start();
				svc.WaitForStatus(ServiceControllerStatus.Running);
			}
		}

		/// <summary>
		/// Retrieve the string associated with the GetLastError() error.
		/// </summary>
		/// <returns>The error message returned by the last PInvoke call</returns>
		private static string GetLastErrorMessage() 
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder(1024);
			FormatMessage(
				FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
				null,
				Marshal.GetLastWin32Error(),
				//MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				((((short)(0x01)) << 10) | (short)(0x00)),
				sb,
				1024,
				IntPtr.Zero );
			return sb.ToString();
		}
	} 

	/// <summary>
	/// This class represents a NdisDevice. Instances of this class are created
	/// by the WirelessManager class. The device class is used to track the
	/// Access Points associated with it.
	/// </summary>
	public class NdisDevice : IEnumerable
	{
		/// <summary>
		/// Name of the device.
		/// </summary>
		private string n;
		/// <summary>
		/// Description of the device.
		/// </summary>
		private string d;
		/// <summary>
		/// Access Points retrived by the last scan.
		/// </summary>
		internal AccessPoint[] accessPoints;
		/// <summary>
		/// Construct a new device. This constructor is invoked by WirelessManager
		/// class.
		/// </summary>
		/// <param name="name">Name of the device</param>
		/// <param name="desc">Description for the device</param>
		internal NdisDevice(string name, string desc) 
		{
			n = name;
			d = desc;
			accessPoints = new AccessPoint[0];
		}

		public override bool Equals(object obj)
		{
			NdisDevice comp = (NdisDevice)obj;
			return (n.CompareTo(comp.n) == 0);
		}


		/// <summary>
		/// Name of the device.
		/// </summary>
		public string Name 
		{
			get { return n; }
		}

		public IEnumerator GetEnumerator() 
		{
			return accessPoints.GetEnumerator();
		}

		/// <summary>
		/// Description for the device.
		/// </summary>
		public string Description 
		{
			get { return d; }
		}
		
		/// <summary>
		/// Return the list of access points retrived from the device. This
		/// property acts as a cache for the AP available. Beware that the
		/// array is cloned every time the property is accessed.
		/// </summary>
		public AccessPoint[] AccessPoints 
		{
			get 
			{
				return (AccessPoint[])accessPoints.Clone();
			}
		}

		/// <summary>
		/// Get or set the access point associated with the device. If the property
		/// is set to null the device is simply disassociated from the device.
		/// </summary>
		public AccessPoint CurrentAP 
		{
			get 
			{
				AccessPoint ret = null;
				MacAddress mac = WirelessManager.GetAssociatedAP(this);
				for (int i = 0; i < accessPoints.Length; i++)
					if (accessPoints[i].mac.Equals(mac)) 
					{
						ret = accessPoints[i];
						break;
					}
						
				return ret;
			}
			set 
			{
				if (value == null) 
				{
					WirelessManager.DisassociateAP(this);
					WirelessManager.SSID = "Wireless&";
					return;
				}
				WirelessManager.SetAssociatedAP(this, value);
			}
		}

		/// <summary>
		/// Start a scan for access points. It takes 6 seconds to generate the list.
		/// You can retrieve the list with GetAPList() method.
		/// </summary>
		public void StartAPScan() 
		{
			WirelessManager.StartAPScan(this);
		}

		/// <summary>
		/// Retrieve from the device the list of the access points found during the
		/// last scan.
		/// </summary>
		/// <returns>The list of access points discovered by the device.</returns>
		public AccessPoint[] GetAPList() 
		{
			return WirelessManager.GetAPList(this);
		}

		/// <summary>
		/// This method perform a scan, wait 6 seconds and retrieve the AP list.
		/// </summary>
		/// <returns>The AP list result of the scan</returns>
		public AccessPoint[] ScanAPList() 
		{
			return WirelessManager.ScanAPList(this);
		}

		/// <summary>
		/// Convert the device into a string. It returns the device's decription.
		/// </summary>
		/// <returns></returns>
		public override string ToString() 
		{
			return d;
		}
	}

	/// <summary>
	/// Instances of this class represent Wireless Access Points. The library 
	/// returns the AP objects through the device objects.
	/// </summary>
	public class AccessPoint 
	{
		/// <summary>
		/// SSID of the AP.
		/// </summary>
		internal string ssid;

		/// <summary>
		/// Network type.
		/// </summary>
		internal NDIS_802_11_NETWORK_INFRASTRUCTURE inf;

		/// <summary>
		/// MAC address of the AP.
		/// </summary>
		internal MacAddress mac;

		/// <summary>
		/// Strength of the signal (in dBm).
		/// </summary>
		internal int signalStrength;

		/// <summary>
		/// Build an access point object. It is used by WirelessManager when the list
		/// of access points is built.
		/// </summary>
		/// <param name="m">MAC address of the AP</param>
		/// <param name="sign">Signal strength</param>
		/// <param name="infr">Type of network</param>
		/// <param name="id">SSID of the AP</param>
		internal AccessPoint(MacAddress m, int sign, NDIS_802_11_NETWORK_INFRASTRUCTURE infr, string id) 
		{
			mac = m;
			signalStrength = sign;
			inf = infr;
			ssid = id;
		}

		/// <summary>
		/// Return the SSID of the Access Point
		/// </summary>
		public string SSID 
		{
			get { return ssid; }
		}

		/// <summary>
		/// Type of network of the access point (infrastructure or AdHoc).
		/// </summary>
		public NDIS_802_11_NETWORK_INFRASTRUCTURE InfrastructureMode 
		{
			get { return inf;	}
		}

		/// <summary>
		/// MAC address of the access point.
		/// </summary>
		public MacAddress MAC 
		{
			get { return mac; }
		}

		/// <summary>
		/// Signal strength in dBm (usually between -20 and -200). It is read
		/// during scan: to update it perform another scan. The AccessPoint
		/// object is preserved across scan.
		/// </summary>
		public int SignalStrength 
		{
			get { return signalStrength; }
		}

		/// <summary>
		/// Produces a string representing the Access Point.
		/// </summary>
		/// <returns></returns>
		public override string ToString() 
		{
			return string.Format("{0} {1} - {2}", inf == NDIS_802_11_NETWORK_INFRASTRUCTURE.Ndis802_11Infrastructure ? "Infrastructure" : "AdHoc", ssid, mac);
		}

		public override bool Equals(object obj)
		{
			return mac.Equals(((AccessPoint)obj).mac);
		}

	}

	public class APSignalComparer : IComparer 
	{
		#region IComparer Members

		public int Compare(object x, object y) 
		{
			//Add APSignalComparer.Compare implementation
			return ((AccessPoint)x).SignalStrength - ((AccessPoint)y).SignalStrength;
		}

		#endregion

	}

	public class APMacComparer : IComparer 
	{
		#region IComparer Members

		public int Compare(object x, object y) 
		{
			//Add APMacComparer.Compare implementation
			return ((AccessPoint)x).MAC.CompareTo( ((AccessPoint)y).MAC );
		}

		#endregion

	}

	/// <summary>
	/// Represent a Mac address. It is a value type so that in interop can be
	/// used to maniipulate unmanaged memory. The address is 6 bytes wide, and
	/// it is represented with an int and a short.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, Pack=1)]
	public struct MacAddress :IComparable
	{
		/// <summary>
		/// The first four bytes of the MAC address.
		/// </summary>
		private uint b0_3;

		/// <summary>
		/// The remaining two bytes.
		/// </summary>
		private ushort b4_5;

		/// <summary>
		/// Indexer that provides access to the bytes of the MAC address.
		/// </summary>
		public byte this[int pos] 
		{
			get 
			{
				if (pos < 0 || pos > 7)
					throw new IndexOutOfRangeException();

				return (pos < 4) ?
					(byte)((0xff) & (b0_3 >> (pos * 8))) :
					(byte)((0xff) & (b4_5 >> ((pos - 4) * 8)));
			}
		}

		/// <summary>
		/// Convert the MAC into a string.
		/// </summary>
		/// <returns></returns>
		public override string ToString() 
		{
			return string.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}",
				this[0], this[1], this[2], this[3], this[4], this[5]);
		}

		/// <summary>
		/// Generates an hash code for a mac based on the MAC address.
		/// </summary>
		/// <returns></returns>
		public override int GetHashCode() 
		{
			return (int)(b0_3 ^ b4_5);
		}

		/// <summary>
		/// Compare the MAC address with other objects.
		/// </summary>
		/// <param name="obj">Object to compare with</param>
		/// <returns>
		/// True if the argument is a MAC address with the same value
		/// </returns>
		public override bool Equals(object obj) 
		{
			if (obj is MacAddress) 
			{
				MacAddress m = (MacAddress)obj;
				return m.b0_3 == b0_3 && m.b4_5 == b4_5;
			}
			return false;
		}

		/// <summary>
		/// Compare two Mac Addresses
		/// </summary>
		/// <param name="o"></param>
		/// <returns></returns>
		public int CompareTo(object o) 
		{
			MacAddress t = (MacAddress)o;
			int diff =  0;
			for (int i = 0; i < 6; i++)
				diff += ((int)this[i] - (int)t[i])*((int)Math.Pow(10, i));
			return diff;
		}
	}

	#region IOCTL enums (from nuiouser.h, winioctl.h, ntddndis.h)
	/// <summary>
	/// Subset of constants needed to interop with DeviceIoControl.
	/// We used the following define from DDK:
	/// (Winioctl.h)
	/// 
	/// #define FILE_DEVICE_NETWORK             0x00000012
	/// #define CTL_CODE( DeviceType, Function, Method, Access ) ( \
	/// ((DeviceType) &lt;&lt; 16) | ((Access) &lt;&lt; 14) | ((Function) &lt;&lt; 2) | (Method) \
	/// #define METHOD_BUFFERED                 0
	/// #define FILE_READ_ACCESS          ( 0x0001 )    // file & pipe
	/// #define FILE_WRITE_ACCESS         ( 0x0002 )    // file & pipe
	/// 
	/// (nuiouser.h)
	/// #define FSCTL_NDISUIO_BASE      FILE_DEVICE_NETWORK
	/// #define _NDISUIO_CTL_CODE(_Function, _Method, _Access)  \
	///    CTL_CODE(FSCTL_NDISUIO_BASE, _Function, _Method, _Access)
	/// #define IOCTL_NDISUIO_OPEN_DEVICE   \
	///    _NDISUIO_CTL_CODE(0x200, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// #define IOCTL_NDISUIO_QUERY_OID_VALUE   \
	///    _NDISUIO_CTL_CODE(0x201, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// #define IOCTL_NDISUIO_SET_OID_VALUE   \
	///    _NDISUIO_CTL_CODE(0x205, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// #define IOCTL_NDISUIO_SET_ETHER_TYPE   \
	///    _NDISUIO_CTL_CODE(0x202, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// #define IOCTL_NDISUIO_QUERY_BINDING   \
	///    _NDISUIO_CTL_CODE(0x203, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// #define IOCTL_NDISUIO_BIND_WAIT   \
	///    _NDISUIO_CTL_CODE(0x204, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
	/// </summary>
	internal enum IOCTL 
	{
		IOCTL_NDISUIO_BIND_WAIT = ((0x12) << 16) | ((0x1 | 0x2) << 14) | ((0x204) << 2) | (0),
			IOCTL_NDISUIO_QUERY_BINDING = ((0x12) << 16) | ((0x1 | 0x2) << 14) | ((0x203) << 2) | (0),
				IOCTL_NDISUIO_OPEN_DEVICE = ((0x12) << 16) | ((0x1 | 0x2) << 14) | ((0x200) << 2) | (0),
					IOCTL_NDISUIO_QUERY_OID_VALUE = ((0x12) << 16) | ((0x1 | 0x2) << 14) | ((0x201) << 2) | (0),
						IOCTL_NDISUIO_SET_OID_VALUE = ((0x12) << 16) | ((0x1 | 0x2) << 14) | ((0x205) << 2) | (0)
						}
	/// <summary>
	/// Subset of messages for interacting with 802.11 miniport driver. These
	/// constants have been taken from the DDK's ntddndis.h include file:
	/// 
	/// #define OID_802_11_BSSID                        0x0D010101
	/// #define OID_802_11_SSID                         0x0D010102
	/// #define OID_802_11_NETWORK_TYPES_SUPPORTED      0x0D010203
	/// #define OID_802_11_NETWORK_TYPE_IN_USE          0x0D010204
	/// #define OID_802_11_TX_POWER_LEVEL               0x0D010205
	/// #define OID_802_11_RSSI                         0x0D010206
	/// #define OID_802_11_RSSI_TRIGGER                 0x0D010207
	/// #define OID_802_11_INFRASTRUCTURE_MODE          0x0D010108
	/// #define OID_802_11_FRAGMENTATION_THRESHOLD      0x0D010209
	/// #define OID_802_11_RTS_THRESHOLD                0x0D01020A
	/// #define OID_802_11_NUMBER_OF_ANTENNAS           0x0D01020B
	/// #define OID_802_11_RX_ANTENNA_SELECTED          0x0D01020C
	/// #define OID_802_11_TX_ANTENNA_SELECTED          0x0D01020D
	/// #define OID_802_11_SUPPORTED_RATES              0x0D01020E
	/// #define OID_802_11_DESIRED_RATES                0x0D010210
	/// #define OID_802_11_CONFIGURATION                0x0D010211
	/// #define OID_802_11_STATISTICS                   0x0D020212
	/// #define OID_802_11_ADD_WEP                      0x0D010113
	/// #define OID_802_11_REMOVE_WEP                   0x0D010114
	/// #define OID_802_11_DISASSOCIATE                 0x0D010115
	/// #define OID_802_11_POWER_MODE                   0x0D010216
	/// #define OID_802_11_BSSID_LIST                   0x0D010217
	/// #define OID_802_11_AUTHENTICATION_MODE          0x0D010118
	/// #define OID_802_11_PRIVACY_FILTER               0x0D010119
	/// #define OID_802_11_BSSID_LIST_SCAN              0x0D01011A
	/// #define OID_802_11_WEP_STATUS                   0x0D01011B
	/// #define OID_802_11_RELOAD_DEFAULTS              0x0D01011C
	/// </summary>
	internal enum OID 
	{
		OID_802_11_BSSID                        = 0x0D010101,
			OID_802_11_SSID                         = 0x0D010102,
			OID_802_11_NETWORK_TYPES_SUPPORTED      = 0x0D010203,
				OID_802_11_NETWORK_TYPE_IN_USE          = 0x0D010204,
				OID_802_11_TX_POWER_LEVEL               = 0x0D010205,
					OID_802_11_RSSI                         = 0x0D010206,
					OID_802_11_RSSI_TRIGGER                 = 0x0D010207,
						OID_802_11_INFRASTRUCTURE_MODE          = 0x0D010108,
						OID_802_11_FRAGMENTATION_THRESHOLD      = 0x0D010209,
							OID_802_11_RTS_THRESHOLD                = 0x0D01020A,
							OID_802_11_NUMBER_OF_ANTENNAS           = 0x0D01020B,
								OID_802_11_RX_ANTENNA_SELECTED          = 0x0D01020C,
								OID_802_11_TX_ANTENNA_SELECTED          = 0x0D01020D,
									OID_802_11_SUPPORTED_RATES              = 0x0D01020E,
									OID_802_11_DESIRED_RATES                = 0x0D010210,
										OID_802_11_CONFIGURATION                = 0x0D010211,
										OID_802_11_STATISTICS                   = 0x0D020212,
											OID_802_11_ADD_WEP                      = 0x0D010113,
											OID_802_11_REMOVE_WEP                   = 0x0D010114,
												OID_802_11_DISASSOCIATE                 = 0x0D010115,
												OID_802_11_POWER_MODE                   = 0x0D010216,
													OID_802_11_BSSID_LIST                   = 0x0D010217,
													OID_802_11_AUTHENTICATION_MODE          = 0x0D010118,
														OID_802_11_PRIVACY_FILTER               = 0x0D010119,
														OID_802_11_BSSID_LIST_SCAN              = 0x0D01011A,
															OID_802_11_WEP_STATUS                   = 0x0D01011B,
															OID_802_11_RELOAD_DEFAULTS              = 0x0D01011C
															}
	#endregion
	
	#region IOCTL structs (from nuiouser.h)
	//
	//  Structure to go with IOCTL_NDISUIO_QUERY_BINDING.
	//  The input parameter is BindingIndex, which is the
	//  index into the list of bindings active at the driver.
	//  On successful completion, we get back a device name
	//  and a device descriptor (friendly name).
	//	
	[StructLayout(LayoutKind.Sequential)]
	internal struct NDISUIO_QUERY_BINDING 
	{
		internal uint			BindingIndex;		// 0-based binding number
		internal uint			DeviceNameOffset;	// from start of this struct
		internal uint			DeviceNameLength;	// in bytes
		internal uint			DeviceDescrOffset;	// from start of this struct
		internal uint			DeviceDescrLength;	// in bytes
	}
	//
	//  Structure to go with IOCTL_NDISUIO_QUERY_OID_VALUE.
	//  The Data part is of variable length, determined by
	//  the input buffer length passed to DeviceIoControl.
	//
	[StructLayout(LayoutKind.Sequential)]
	internal struct NDISUIO_QUERY_OID 
	{
		internal OID Oid;
		internal uint Data;
	}
	//
	//  Structure to go with IOCTL_NDISUIO_SET_OID_VALUE.
	//  The Data part is of variable length, determined
	//  by the input buffer length passed to DeviceIoControl.
	//
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	internal struct NDISUIO_SET_OID 
	{
		internal OID Oid;
		internal uint Data;
	}
	#endregion

	#region 802.11 enums (from ntddndis.h)
	public enum NDIS_802_11_NETWORK_TYPE 
	{
		Ndis802_11FH,
			Ndis802_11DS,
			Ndis802_11NetworkTypeMax    // not a real type, defined as an upper bound
		}
	public enum NDIS_802_11_POWER_MODE 
	{
		Ndis802_11PowerModeCAM,
			Ndis802_11PowerModeMAX_PSP,
			Ndis802_11PowerModeFast_PSP,
			Ndis802_11PowerModeMax      // not a real mode, defined as an upper bound
		}
	public enum NDIS_802_11_NETWORK_INFRASTRUCTURE 
	{
		Ndis802_11IBSS,
			Ndis802_11Infrastructure,
			Ndis802_11AutoUnknown,
			Ndis802_11InfrastructureMax         // Not a real value, defined as upper bound
		}
	public enum NDIS_802_11_AUTHENTICATION_MODE 
	{
		Ndis802_11AuthModeOpen,
			Ndis802_11AuthModeShared,
			Ndis802_11AuthModeAutoSwitch,
			Ndis802_11AuthModeMax               // Not a real mode, defined as upper bound
		}
	public enum NDIS_802_11_PRIVACY_FILTER 
	{
		Ndis802_11PrivFilterAcceptAll,
			Ndis802_11PrivFilter8021xWEP
		}
	public enum NDIS_802_11_WEP_STATUS 
	{
		Ndis802_11WEPEnabled,
			Ndis802_11WEPDisabled,
			Ndis802_11WEPKeyAbsent,
			Ndis802_11WEPNotSupported
		}  
	public enum NDIS_802_11_RELOAD_DEFAULTS 
	{
		Ndis802_11ReloadWEPKeys
		}
	#endregion

	#region 802.11 structs (from ntddndis.h)
	[StructLayout(LayoutKind.Sequential)]
	internal struct NDIS_802_11_CONFIGURATION_FH 
	{
		uint           Length;             // Length of structure
		uint           HopPattern;         // As defined by 802.11, MSB set
		uint           HopSet;             // to one if non-802.11
		uint           DwellTime;          // units are Kusec
	}
	[StructLayout(LayoutKind.Sequential)]
	public struct NDIS_802_11_CONFIGURATION 
	{
		uint           Length;             // Length of structure
		uint           BeaconPeriod;       // units are Kusec
		uint           ATIMWindow;         // units are Kusec
		uint           DSConfig;           // Frequency, units are kHz
		NDIS_802_11_CONFIGURATION_FH    FHConfig;
	}
	[StructLayout(LayoutKind.Sequential)]
	public struct NDIS_802_11_STATISTICS 
	{
		uint           Length;             // Length of structure
		long   TransmittedFragmentCount; // FIXME: all the long here were LARGE_INTEGER: check!
		long   MulticastTransmittedFrameCount;
		long   FailedCount;
		long   RetryCount;
		long   MultipleRetryCount;
		long   RTSSuccessCount;
		long   RTSFailureCount;
		long   ACKFailureCount;
		long   FrameDuplicateCount;
		long   ReceivedFragmentCount;
		long   MulticastReceivedFrameCount;
		long   FCSErrorCount;
	}
	[StructLayout(LayoutKind.Sequential)]
	internal struct NDIS_802_11_WEP 
	{
		uint           Length;             // Length of this structure
		uint           KeyIndex;           // 0 is the per-client key, 1-N are the
		// global keys
		uint           KeyLength;          // length of key in bytes
		byte           KeyMaterial_0;     // variable length depending on above field
		// In unsafe code we should handle this!
	}
	// This is needed because default packing is 8
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	internal struct NDIS_802_11_SSID 
	{
		internal uint   SsidLength;         // length of SSID field below, in bytes;
		// this can be zero.
		// SSID array of 32 UCHAR
		internal long   Ssid_0;
		internal long   Sssid_1, Ssid_2, Ssid_3;           // SSID information field
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	internal struct NDIS_WLAN_BSSID 
	{
		internal uint									Length;             // Length of this structure
		// Mac address is 6 byte long: an int and a short
		internal MacAddress								MAC;
		internal byte									Reserved_0, Reserved_1;
		internal NDIS_802_11_SSID						Ssid;               // SSID
		internal uint									Privacy;            // WEP encryption requirement
		internal int									Rssi;               // receive signal
		// strength in dBm
		internal NDIS_802_11_NETWORK_TYPE				NetworkTypeInUse;
		internal NDIS_802_11_CONFIGURATION				Configuration;
		internal NDIS_802_11_NETWORK_INFRASTRUCTURE		InfrastructureMode;
		// 8 byte UCHAR array.
		internal long									SupportedRates_0, SupportedRates_1;
	} 
	#endregion

	/// <summary>
	/// This structure supports a NIC statistics query through IOCTL_NDISUIO_NIC_STATISTICS
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct NIC_STATISTICS {
		/// <summary>
		/// Size of the NIC_STATISTICS structure
		/// </summary>
		public uint Size;
		/// <summary>
		/// Device name to query
		/// </summary>
		public string ptcDeviceName;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_MEDIA_IN_USE
		/// The following table shows the valid DeviceState values.
		/// State											Value 
		/// DEVICE_STATE_CONNECTED			1 
		/// DEVICE_STATE_DISCONNECTED		0 
		/// </summary>
 		public uint DeviceState;
		/// <summary>
		/// NDISMediumxxx value. The following table shows the valid NDIS medium values for MediaType.
		/// NdisMediumxxx						Description
		/// NdisMedium802_3					Specifies an Ethernet (802.3) medium.
		/// NdisMedium802_5					Not supported for NDISUIO. Specifies a Token Ring (802.5) medium.  
		/// NdisMediumWan						Not supported for NDISUIO. Specifies a WAN.  
		/// NdisMediumDix						Not supported for NDISUIO. Specifies DEC/Intel/Xerox (DIX) Ethernet medium.  
		/// NdisMediumWirelessWan		Not supported for NDISUIO. Specifies various types of wireless medium.  
		/// NdisMediumIrda					Not supported for NDISUIO. Specifies an infrared (IrDA) medium.  
		/// NdisMediumBpc						Not supported for NDISUIO. Specifies a broadcast architecture medium.  
		/// NdisMediumCoWan					Not supported for NDISUIO. Specifies a connection-oriented WAN medium, which is not supported.  
		/// NdisMedium1394					Not supported for NDISUIO. Specifies an IEEE 1394 medium.  
		/// NdisMediumMax						Not supported for NDISUIO. Specifies an upper bound.
		/// </summary>
		public uint MediaType;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_MEDIA_CONNECT_STATUS. The following table 
		/// shows the valid MediaState values.
		/// Media state							Value 
		/// MEDIA_STATE_CONNECTED			0 
		/// MEDIA_STATE_DISCONNECTED	1
		/// MEDIA_STATE_UNKNOWN			 -1 
		/// </summary>
		public uint MediaState;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_PHYSICAL_MEDIUM
		/// </summary>
		public uint PhysicalMediaType;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_LINK_SPEED. This is the speed of the link
		/// in 100 bits/s. For example, 10 Mb/s = 100000
		/// </summary>
		public uint LinkSpeed;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_XMIT_OK. For more information about
		/// OID_GEN_XMIT_OK, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public ulong PacketsSent;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_RCV_OK. For more information about
		/// OID_GEN_RECV_OK, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public ulong PacketsReceived;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_INIT_TIME_MS. This is the
		/// initialization time, in milliseconds. For more information about
		/// OID_GEN_INIT_TIME_MS, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint InitTime;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_ELAPSED_TIME. This is the connection
		/// time, in seconds. For more information about OID_GEN_ELAPSED_TIME,
		/// see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint ConnectTime;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_XMIT_OK, where 0 indicates unknown,
		/// or not supported. For more information about OID_GEN_XMIT_OK,
		/// see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint BytesSent;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_RCV_OK, where 0 indicates unknown,
		/// or not supported. For more information about OID_GEN_RECV_OK,
		/// see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public ulong BytesReceived;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_DIRECTED_BYTES_RCV. For more
		/// information about OID_GEN_DIRECTED_BYTES_RCV, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public ulong DirectedBytesReceived;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_DIRECTED_FRAMES_RCV. For more
		/// information about OID_GEN_DIRECTED_FRAMES_RCV, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public ulong DirectedPacketsReceived;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_RCV_ERROR. For more information
		/// about OID_GEN_RCV_ERROR, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint PacketsReceiveErrors;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_XMIT_ERROR. For more information
		/// about OID_GEN_XMIT_ERROR, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint PacketsSendErrors;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_RESET_COUNTS. For more information
		/// about OID_GEN_RESET_COUNTS, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint ResetCount;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_MEDIA_SENSE_COUNTS. For more
		/// information about OID_GEN_MEDIA_SENSE_COUNTS, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint MediaSenseConnectCount;
		/// <summary>
		/// Result of the NDISUIO query of OID_GEN_MEDIA_SENSE_COUNTS. For more
		/// oid_information about OID_GEN_MEDIA_SENSE_COUNTS, see OID_GEN_SUPPORTED_LIST
		/// </summary>
		public uint MediaSenseDisconnectCount;
	}
}
