﻿/// File: ManagedWiFi\ListWiFi\Program.cs
/// 
/// ------------------------------------------------------------
/// Copyright (c) 2004
///   Antonio Cisternino (cisterni.unipi.it),
///   Diego Colombo      (colombod.unipi.it),
///   Giorgio Ennas      (   ennas.unipi.it),
///   Daniele Picciaia   (picciaia.unipi.it)
/// 
/// The use and distribution terms for this software are 
/// contained in the file named license.txt, which can be found 
/// in the root of this distribution.
/// By using this software in any fashion, you are agreeing to 
/// be bound by the terms of this license.
///
/// You must not remove this notice, or any other, from this
/// software.
/// ------------------------------------------------------------



using System;
using System.Collections.Generic;
using System.Text;

using WifiCore;


namespace ListWiFi {
  class Program {
    static void Main(string[] args) {
      WirelessManager.Init();

      // Bind the Wireless device to be used
      foreach (NdisDevice d in WirelessManager.EnumerateDevices()) {
        // FIXME: At the moment we can't decide the type of NIC (either 802.3 or 802.11)
        // We assume that the description of the card helps us
        if (d.Description.IndexOf("Wireless") != -1 || d.Description.IndexOf("WLAN") != -1) {
          WirelessManager.CurrentDevice = d;
          break;
        }
      }

      // We try to bind the best AP 
      int signal = -300; // Signal is in decibel (from -20 to -200)
      string ssid = null;

      // Enumerate Access Points
      foreach (AccessPoint ap in WirelessManager.CurrentDevice.ScanAPList()) {
        if (ap.InfrastructureMode == NDIS_802_11_NETWORK_INFRASTRUCTURE.Ndis802_11Infrastructure &&
            ap.SignalStrength > signal) {
          signal = ap.SignalStrength;
          ssid = ap.SSID;
        }
        Console.WriteLine("AP {0}", ap.MAC);
        Console.WriteLine("SSID: {0}", ap.SSID);
        Console.WriteLine("Signal strength: {0}", ap.SignalStrength);
        Console.WriteLine("Infrastructure mode: {0}",
          (ap.InfrastructureMode == NDIS_802_11_NETWORK_INFRASTRUCTURE.Ndis802_11Infrastructure ?
           "Access Point" : "Ad Hoc"));
        Console.WriteLine();
      }

      // Try to bind the best AP
      if (ssid != null && ssid != "") {
        Console.WriteLine("Attempting to bind {0}", ssid);
        WirelessManager.SSID = ssid;
      }

      Console.ReadLine();
    }
  }
}
