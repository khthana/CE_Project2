using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using WifiCore;

namespace Project
{
    public partial class Form2 : Form
    { 
        
        string FileOpen;
        string Have = "D:\\Project_Last\\Project\\Project\\SourceProject\\map\\have3.JPG";
        string NotHave = "D:\\Project_Last\\Project\\Project\\SourceProject\\map\\Nohave3.JPG";
        string Na = Form1.NameUser;
        string PosiTion = Form1.Position;
        bool state = true;
        int[] stg = new int[13];
        int E801; int E803; int E804; int PE801; int PE802; int PE810;
        int E802; int E805; int E806; int PE803; int PE804; int PE811;
        int E807; int E808; int E810; int PE805; int PE806;
        int E811; int SMC; int CENTER1; int PE807; int PE808;
        Bitmap FileOpenP = new Bitmap("D:\\Project_Last\\Project\\Project\\SourceProject\\map\\Nohave3.JPG");
        bool draw = false;
        
        private void getAp()
        {
            
            // Bind the Wireless device to be used
            // We try to bind the best AP 
            while (state)
            {
                int sassa = 0;
                DateTime sa = DateTime.Now;
                int signal = -300; // Signal is in decibel (from -20 to -200)
                string ssid = null;

                foreach (AccessPoint ap in WirelessManager.CurrentDevice.ScanAPList())
                {
                    if (ap.InfrastructureMode == NDIS_802_11_NETWORK_INFRASTRUCTURE.Ndis802_11Infrastructure &&
                        ap.SignalStrength > signal)
                    {
                        signal = ap.SignalStrength;
                        ssid = ap.SSID;
                    }
                    string apStr = Convert.ToString(ap.MAC);
                    string SsidStr = "SSID: " + ap.SSID;
                    string SignalStr = "Signal strength: " + ap.SignalStrength;
                    //MapAccessPoint(apStr);
                    listBox2.Items.Add(apStr);
                    listBox2.Items.Add(SsidStr);
                    listBox2.Items.Add(SignalStr);
                    sassa++;
                    mapAp(apStr);//

                } //MapLoction(sassa);
                MapLoca();
                listBox2.Items.Add("-------------------------------");

                if (ssid != null && ssid != "")
                {
                    string Att = "Attempting to bind " + ssid;
                    WirelessManager.SSID = ssid;
                }
                Thread.Sleep(3000);
                if ((PE801 == 2) || (PE802 == 2) || (PE803 == 2) || (PE804 == 2) || (PE805 == 2) || (PE806 == 2) || (PE807 == 2) || (PE808 == 1) || (PE810 == 2) || (PE811 == 2))
                {   
                    draw = true;
                    PEClear();
                    clearAr();
                    textBox2.Text += "Name = " + Na + "  Position : " + PosiTion + Environment.NewLine + Convert.ToString(sa.Date).Substring(0, 9) + Environment.NewLine;
                    //Thread.Sleep(3000);
                } 
            }
        }
        private void clearAr()
        {
            for (int iis = 0; iis < 13; iis++)
            {
                stg[iis] = 0;
            }
        }
        private void MapLoca()
        {
            if (stg[0] == 1)
            {
                if((stg[6] == 1)&&(stg[4]!=1))
                {
                    PE802 = PE802 + 1;
                    PosiTion = "ECC802";
                }
                else if ((stg[5] == 1)||(stg[4] == 1))
                {
                    PE803 = PE803 + 1;
                    PosiTion = "ECC803";
                }
                else
                {
                    PE801 = PE801 + 1;
                    PosiTion = "ECC801";
                }
            }
            else if (stg[1] == 1)
            {
                if (stg[8] == 1) 
                {
                    PE806 = PE806 + 1;
                    PosiTion = "ECC806";
                }
                /*else if ((stg[3] == 1) || (stg[13] == 1))
                {
                    PE804 = PE804 + 1;
                    PosiTion = "ECC804";
                }*/
                else{
                    PE808 = PE808 + 1;
                    PosiTion = "ECC808";
                }
            }
            else if ((stg[5] == 1) || (stg[11] == 1))
            {
                PE810 = PE810 + 1;
                PosiTion = "ECC810";
            }
            else if ((stg[6] == 1) || (stg[10] == 1))
            {
                PE811 = PE811 + 1;
                PosiTion = "ECC811";
            }
            else if (stg[3] == 1)
            {
                PE807 = PE807 + 1;
                PosiTion = "ECC807";
            }
        }

        private void mapAp(string accessPoint)
        {
            if (accessPoint == "00:0D:54:9C:CF:D8")    // Mac Address ��ҡѺ CE-ISAG
            {
                stg[0] = 1;
            }
            if (accessPoint == "00:09:5B:D5:86:AE")  // Mac Address ��ҡѺ GRAD804
            {
                stg[1] = 1;
            }
            if (accessPoint == "00:17:9A:C9:BA:F2")  // Mac Address ��ҡѺ ce_room901
            {
                stg[2] = 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:1E")  // Mac Address ��ҡѺ 3Com(1E)
            {
                stg[3] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:28")  // Mac Address ��ҡѺ CE_ACCESS704
            {
                stg[4] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:1A")  // Mac Address ��ҡѺ CE_ACCESS910
            {
                stg[5] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:26")  // Mac Address ��ҡѺ CE_ACCESS905(26)
            {
                stg[6] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:2C")  // Mac Address ��ҡѺ CE_ACCESS905(2C)
            {
                stg[7] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:1C") // Mac Address ��ҡѺ 3Com(1C)
            {
                stg[8] = 1;
            }
            if (accessPoint == "00:04:E2:E0:20:7A") // Mac Address ��ҡѺ Center1
            {
                stg[9] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:22") // Mac Address ��ҡѺ CE_ACCESS708
            {
                stg[11] = 1;
            }

            if (accessPoint == "00:0A:E9:0F:FF:E9") // Mac Address ��ҡѺ SMC
            {
                stg[10] = 1;
            }
            if (accessPoint == "00:03:2F:23:9C:30") // Mac Address ��ҡѺ Defualt 5
            {
                stg[12] = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:24") // Mac Address ��ҡѺ ce access607
            {
                stg[10] = 1;
            }
        }

        private void PEClear()
        {
            PE811 = 0;
            PE810 = 0;
            PE808 = 0;
            PE807 = 0;
            PE806 = 0;
            PE805 = 0;
            PE804 = 0;
            PE803 = 0;
            PE802 = 0;
            PE801 = 0;
        }

        /*private void MapLoction(int ase)
        {

            if ((E804 == 0) && (E806 == 0) && (E810 == 0) && (E811 == 0) && (E808 == 0) && (E807 == 1) && (E801 == 1) && (E802 == 1))
            {
                clearList();
                PE807 = PE807 + 1;
                PosiTion = "ECC807";
            }
            if ((SMC != 1) && (CENTER1 != 1))
            {
                int[] test = new int[10];
                test[0] = E801; test[1] = E802;
                test[2] = E803; test[3] = E804;
                test[4] = E805; test[5] = E806;
                test[6] = E807; test[7] = E808;
                test[8] = E810; test[9] = E811;

                for (int yu = 0; yu < 10; yu++)
                {
                    if (test[yu] == 0)
                    {
                        test[yu] = 100;
                    }
                    else
                    {
                        test[yu] = test[yu];
                    }
                }
                test[0] = test[0] - ase; test[5] = test[5] - ase;
                test[1] = test[1] - ase; test[6] = test[6] - ase;
                test[2] = test[2] - ase; test[7] = test[7] - ase;
                test[3] = test[3] - ase; test[8] = test[8] - ase;
                test[4] = test[4] - ase; test[9] = test[9] - ase;

                for (int asd = 0; asd < 10; asd++)
                {
                    if (test[asd] < 0)
                    {
                        test[asd] = test[asd] * -100;
                    }
                    else
                    {
                        test[asd] = test[asd];
                    }
                }
                int index = 0;
                int min = test[0];

                //----- min fn ------------------
                for (int asdf = 0; asdf < 10; asdf++)
                {
                    if (test[asdf] < min)
                    {
                        min = test[asdf];
                        index = asdf;
                    }
                }
                if (index == 0)
                {
                    clearList();
                    PE801 = PE801 + 1;
                    PosiTion = "ECC801";
                }
                else if (index == 1)
                {
                    clearList();
                    PE802 = PE802 + 1;
                    PosiTion = "ECC802";
                }
                else if (index == 2)
                {
                    clearList();
                    PE803 = PE803 + 1;
                    PosiTion = "ECC803";
                }
                else if (index == 3)
                {
                    clearList();
                    PE804 = PE804 + 1;
                    PosiTion = "ECC804";
                }
                else if (index == 4)
                {
                    clearList();
                    PE805 = PE805 + 1;
                    PosiTion = "ECC805";
                }
                else if (index == 5)
                {
                    clearList();
                    PE806 = PE806 + 1;
                    PosiTion = "ECC806";
                }
                else if (index == 6)
                {
                    clearList();
                    PE807 = PE807 + 1;
                    PosiTion = "ECC807";
                }
                else if (index == 7)
                {
                    clearList();
                    PE808 = PE808 + 1;
                    PosiTion = "ECC808";
                }
                else if (index == 8)
                {
                    clearList();
                    PE810 = PE810 + 1;
                    PosiTion = "ECC810";
                }
                else if (index == 9)
                {
                    clearList();
                    PE811 = PE811 + 1;
                    PosiTion = "ECC811";
                }

            }
            if ((SMC == 1) && (CENTER1 != 1))
            {
                clearList();
                PE811 = PE811 + 1;
                PosiTion = "ECC811";
            }
            else if ((SMC != 1) && (CENTER1 == 1))
            {
                clearList();
                PE806 = PE806 + 1;
                PosiTion = "ECC806";
            }



        }
        private void clearList()
        {
            E801 = 0;
            E802 = 0;
            E803 = 0;
            E804 = 0;
            E805 = 0;
            E806 = 0;
            E807 = 0;
            E808 = 0;
            E810 = 0;
            E811 = 0;
            SMC = 0;
            CENTER1 = 0;
        }


        //-------- MapAccessPoint --------
        private void MapAccessPoint(string accessPoint)
        {

            if (accessPoint == "00:0D:54:9C:CF:D8")    // Mac Address ��ҡѺ CE-ISAG
            {
                E801 = E801 + 1;
                E802 = E802 + 1;
                E803 = E803 + 1;
            }
            if (accessPoint == "00:09:5B:D5:86:AE")  // Mac Address ��ҡѺ GRAD804
            {
                E801 = E801 + 1;
                E802 = E802 + 1;
                E803 = E803 + 1;
                E804 = E804 + 1;
                E806 = E806 + 1;
                E808 = E808 + 1;
            }
            if (accessPoint == "00:17:9A:C9:BA:F2")  // Mac Address ��ҡѺ ce_room901
            {
                E801 = E801 + 1;
                E802 = E802 + 1;
                E807 = E807 + 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:1E")  // Mac Address ��ҡѺ 3Com(1E)
            {
                E801 = E801 + 1;
                E802 = E802 + 1;
                E803 = E803 + 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:28")  // Mac Address ��ҡѺ CE_ACCESS704
            {
                E803 = E803 + 1;
                E804 = E804 + 1;
                E808 = E808 + 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:1A")  // Mac Address ��ҡѺ CE_ACCESS910
            {
                E803 = E803 + 1;
                E804 = E804 + 1;
                E806 = E806 + 1;
                E807 = E807 + 1;
                E808 = E808 + 1;
                E810 = E810 + 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:26")  // Mac Address ��ҡѺ CE_ACCESS905(26)
            {
                E803 = E803 + 1;
                E804 = E804 + 1;
                E806 = E804 + 1;
                E808 = E808 + 1;
                E810 = E810 + 1;
                E811 = E811 + 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:2C")  // Mac Address ��ҡѺ CE_ACCESS905(2C)
            {
                E803 = E803 + 1;
                E804 = E804 + 1;
                E806 = E806 + 1;
                E808 = E808 + 1;
                E810 = E810 + 1;
                E811 = E811 + 1;

            }
            if (accessPoint == "00:0F:CB:C1:85:1C") // Mac Address ��ҡѺ 3Com(1C)
            {
                E803 = E803 + 1;

            }
            if (accessPoint == "00:04:E2:E0:20:7A") // Mac Address ��ҡѺ Center1
            {
                E806 = E806 + 1;
                CENTER1 = 1;
            }
            if (accessPoint == "00:0F:CB:C1:85:22") // Mac Address ��ҡѺ CE_ACCESS708
            {
                E803 = E803 + 1;
                E808 = E808 + 1;
            }

            if (accessPoint == "00:0A:E9:0F:FF:E9") // Mac Address ��ҡѺ SMC
            {
                E811 = E811 + 1;
                SMC = 1;

            }
        }*/
        private void CheckCom()
        {
           
            if (comboBox1.Text == "ECC801")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC801.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC802")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC802.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC803")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC803.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC804")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC804.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC805")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC805.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC806")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC806.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC807")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC807.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC808")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC808.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC810")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC810.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else if (comboBox1.Text == "ECC811")
            {
                FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC811.txt");
                StreamReader sr = new StreamReader(FileOpen);
                textBox1.Clear();
                textBox1.Text = sr.ReadToEnd();
                sr.Close();
            }
            else
            {
                textBox1.Clear();
                textBox1.Text = ("Do Not Thing");

            }
        }
        private void drawMap()
        {
            while (state)
            {
                if (draw == true)
                {
                    if (PosiTion == "ECC801")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox2.Image = FileOpenP;

                    }
                    else if (PosiTion == "ECC802")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox3.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC803")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox4.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC804")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox5.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC805")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox6.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC806")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC807")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox11.Image = FileOpenP;

                    }
                    else if (PosiTion == "ECC808")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox12.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC810")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox14.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox13.Image = FileOpenP;
                    }
                    else if (PosiTion == "ECC811")
                    {
                        FileOpenP = new Bitmap(NotHave);
                        pictureBox10.Image = FileOpenP;
                        pictureBox11.Image = FileOpenP;
                        pictureBox12.Image = FileOpenP;
                        pictureBox13.Image = FileOpenP;
                        pictureBox2.Image = FileOpenP;
                        pictureBox15.Image = FileOpenP;
                        pictureBox16.Image = FileOpenP;
                        pictureBox17.Image = FileOpenP;
                        pictureBox18.Image = FileOpenP;
                        pictureBox19.Image = FileOpenP;
                        pictureBox20.Image = FileOpenP;
                        pictureBox3.Image = FileOpenP;
                        pictureBox4.Image = FileOpenP;
                        pictureBox5.Image = FileOpenP;
                        pictureBox6.Image = FileOpenP;
                        pictureBox7.Image = FileOpenP;
                        pictureBox8.Image = FileOpenP;
                        pictureBox9.Image = FileOpenP;
                        FileOpenP = new Bitmap(Have);
                        pictureBox14.Image = FileOpenP;
                    }
                    //Thread.Sleep(5000);
                }
                draw = false;
                //PosiTion = "ECC811";
            }
        }

        public Form2()
        {
            
            InitializeComponent();
            textBox2.Text = "Name User : " + Na + "  Positions : " + PosiTion; //sr.ReadLine();

            Bitmap FileOpenB = new Bitmap("D:\\Project_Last\\Project\\Project\\SourceProject\\map\\floor8th.jpg");
            pictureBox1.Image = FileOpenB;
            draw = true;
            Thread gs = new Thread(new ThreadStart(drawMap));
            gs.Start();
            Thread gi = new Thread(new ThreadStart(getAp));
            gi.Start();

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            state = false;
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                CheckCom();
            }
            else
            {
                comboBox1.Text = "Select Room";
            }
        }

        //-------------- PictureBox ------------------------------

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC805";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC805.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC801";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC801.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC802";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC802.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC803";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC803.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC804";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC804.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC806";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC806.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC806";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC806.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC807";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC807.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC808";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC808.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC810";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC810.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "ECC811";
            FileOpen = ("D:\\Project_Last\\Project\\Project\\SourceProject\\Map_Detail\\ECC811.txt");
            StreamReader sr = new StreamReader(FileOpen);
            textBox1.Clear();
            textBox1.Text = sr.ReadToEnd();
            sr.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = " Name User : " + Na + "  Positions : " + PosiTion +" Date : " +DateTime.Now;
            draw = true;
        }
    }
}