#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <ldap.h>

char *ldap_host = "192.168.1.100";			// Firestation host name or IP address
char *root_dn = "cn=Administrator, cn=Users, dc=hephaestus, dc=com"; // Root dn of Active directory
char *root_pw = "92189327";				// Root dn's password
char *dn = NULL;

int logging(LDAP *ld, unsigned char *log)
{
	char* dn;
	LDAPMod *list_of_attrs[2];
	LDAPMod attribute;
	LDAPControl **srvrctrls, **clntctrls;

	// Distinguished name of the entry that you want to modify
	dn = "cn=firescreen, cn=computers, dc=hephaestus, dc=com";

	// Values to add or change
	char *logEntry[] = { log, NULL };

	// Specify each change in separate LDAPMod structures
	attribute.mod_type = "firewallLog";
	attribute.mod_op = LDAP_MOD_ADD;
	attribute.mod_values = logEntry;

	// Add the pointers to these LDAPMod structures to an array
	list_of_attrs[0] = &attribute;
	list_of_attrs[1] = NULL;

	// Change the entry
	if ( ldap_modify_s( ld, dn, list_of_attrs ) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_modify_s" );
		return( 1 );
	}
	
	return 0;
}

int main( int argc, char *argv[] )
{
	printf("\n[ PEBKAC ]\n\n");
	
	LDAP *ld;
	
	FILE *fp;
	unsigned char log[999], temp[999];
	unsigned char *token;
	
	int chk=0;
	
	// Init LDAP connection
	if ((ld = ldap_init(ldap_host, LDAP_PORT)) == NULL ) {
		perror( "ldap_init failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// LDAP binding
	if (ldap_bind_s(ld, root_dn, root_pw, LDAP_AUTH_SIMPLE) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_bind failed!!!" );
		exit( EXIT_FAILURE );
	}
		
	fp=fopen("/var/log/syslog", "r");
	int i=0, counter=0;
	while (fgets(log, 999, fp) != NULL) {
			
		//printf("\nlog na ja: %s\n", log);
		strcpy(temp, log);
		
		// tokens seperated with " "
		token = strtok(temp, " ");

		while (token != NULL) {
			if (!strcmp(token, "FIRESCREEN")) {
				logging(ld, log);
				printf("%s\n", log);
			}
			//printf("%s\n", token);
			token = strtok(NULL, " ");
		}
	}
	counter++;
		
	fclose(fp);
	fp=fopen("/var/log/syslog", "w+");		// clear log file
	fclose(fp);
	printf("counter: %d\n", counter);
	chk = counter;

	exit(0);
}
