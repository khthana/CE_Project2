#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>

int main(void) {
        
        // Our process ID and Session ID
        pid_t pid, sid;
        
        // Fork off the parent process
        pid = fork();
        if (pid < 0) {
                exit(EXIT_FAILURE);
        }
		
        // exit the parent process
        if (pid > 0) {
                exit(EXIT_SUCCESS);
        }

        // Change the file mode mask
        umask(0);     
                
        // Create a new SID for the child process
        sid = setsid();
        if (sid < 0) {
                // Log the failure
                exit(EXIT_FAILURE);
        }
        
        // Close out the standard file descriptors
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
        
        
        // Firescreen Loop
        while (1) {
			
			//system("firescreen");
			//sleep(5); // wait 5 seconds

			system("firelog");
			sleep(5); // wait 5 seconds
			
			//system("/usr/share/firescreen/rules");
			//sleep(5);
        }
   		exit(EXIT_SUCCESS);
}
