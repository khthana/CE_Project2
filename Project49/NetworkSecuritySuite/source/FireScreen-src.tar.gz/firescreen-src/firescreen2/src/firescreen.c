#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <lber.h>
#include <ldap.h>

#define MAX_RULES 	 100				// Maximum rules can be apply to Firescreen 
#define FIRESTATION 	 "192.168.1.100"		// Firestation host name or IP address
#define FIRESCREEN_INET  "161.246.5.48"			// IP address of Firescreen NIC that connected to internet
#define FIRESCREEN_DMZ 	 "172.16.144.135"		// IP address of Firescreen NIC that connected to DMZ
#define FIRESCREEN_LOCAL "172.16.142.1"		// IP address of Firescreen NIC that connected to local network
#define	INET_INTERFACE	 "eth0"				// NIC connected to internet
#define DMZ_INTERFACE	 "eth1"				// NIC connected to DMZ
#define	LOCAL_INTERFACE	 "eth2"				// NIC connected to local network
#define DMZ		 "172.16.144.0"			// DMZ network address
#define LOCAL 		 "172.16.142.0"			// Local network address

char *ldap_host = "192.168.1.100";			// Firestation host name or IP address
char *root_dn = "cn=Administrator, cn=Users, dc=hephaestus, dc=com"; // Root dn of Active directory
char *root_pw = "92189327";				// Root dn's password
char *dn = NULL;
unsigned char *iptables_save[MAX_RULES];


int get_attr (char **vals, char *base, char *filter, char *attr)
{
	LDAP *ld;
	int result;
	
	BerElement* ber;
   	LDAPMessage* msg;
    LDAPMessage* entry;

	FILE* fp;
	unsigned char whenChanged[18];
	int i;
	int mod=0;

	// Init LDAP connection
	if ((ld = ldap_init(ldap_host, LDAP_PORT)) == NULL ) { //LDAP Port = 389
		perror( "ldap_init failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// LDAP binding
	if (ldap_bind_s(ld, root_dn, root_pw, LDAP_AUTH_SIMPLE) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_bind failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// Query arbritary from AD
	if (ldap_search_s(ld, base, LDAP_SCOPE_SUBTREE, filter, &attr, 0, &msg) != LDAP_SUCCESS) {
		ldap_perror( ld, "ldap_search_s failed!!!" );
		exit(EXIT_FAILURE);
	}
	
	
	// Processing returned information
	
	// 1st for loop is for gather all returned information (in this case there's only one attribute returned)
	for(entry = ldap_first_entry(ld, msg); entry != NULL; entry = ldap_next_entry(ld, entry)) {
	        
		//catching errors
		if((dn = ldap_get_dn(ld, entry)) != NULL) {
		       printf("Returned dn: %s\n\n", dn);
		       ldap_memfree(dn);
		}

		
		// Following for loop is for seperate each value of the specific attribute
		for( attr = ldap_first_attribute(ld, entry, &ber); attr != NULL; attr = ldap_next_attribute(ld, entry, ber)) {
			if ((vals = ldap_get_values(ld, entry, attr)) != NULL)  {
			
				//fp=open("whenChanged", "r");
				//fclose(fp);
				
				printf("\nupdate: %s\n", vals[0]);
				
				/*fp=fopen("/root/firescreen/whenChanged", "r");
				fgets(whenChanged, 18, fp);
				printf("\nfgets : %s\n", whenChanged);
				fclose(fp);*/
				
				if (!strcmp(vals[0], "YES")) {
					printf("\nHey, modification detected!!!\n");
					mod=1;
				}

				updateFlag(ld);
				
				/*fp=fopen("/root/firescreen/whenChanged", "w+");
				fprintf(fp, "%s\n", vals[0]);
				fclose(fp);*/
				
				ldap_value_free(vals);
				
				// Traverse all value completed
			}
			ldap_memfree(attr);
        }
		// All attribute has been retrieved

		// Free BerElement
		if (ber != NULL) {
			ber_free(ber,0);
		}

	    printf("\n");
	}
	// End of processing returned information
	
	ldap_unbind_s(ld);

	return(mod);
}


/* get_rules does the job in fetching rules from AD then save in shell script (rules) in iptables command format */
int get_rules (char **vals, char *base, char *filter, char *attr)
{
	LDAP *ld;
	int result;
	
	BerElement* ber;
   	LDAPMessage* msg;
    LDAPMessage* entry;

	int i, num;

	unsigned char* token;
	unsigned char* iptables;

	// Init LDAP connection
	if ((ld = ldap_init(ldap_host, LDAP_PORT)) == NULL ) {
		perror( "ldap_init failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// LDAP binding
	if (ldap_bind_s(ld, root_dn, root_pw, LDAP_AUTH_SIMPLE) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_bind failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// Query arbritary from AD
	if (ldap_search_s(ld, base, LDAP_SCOPE_SUBTREE, filter, &attr, 0, &msg) != LDAP_SUCCESS) {
		ldap_perror( ld, "ldap_search_s failed!!!" );
		exit(EXIT_FAILURE);
	}
	

	// Processing returned information
	
	// 1st for loop is for gather all returned information (in this case there's only one attribute returned)
	for(entry = ldap_first_entry(ld, msg); entry != NULL; entry = ldap_next_entry(ld, entry)) {
	        
		//catching errors
		if((dn = ldap_get_dn(ld, entry)) != NULL) {
		       printf("Returned dn: %s\n\n", dn);
		       ldap_memfree(dn);
		}

		
		// Following for loop is for seperate each value of the specific attribute ...says "firewallRule"
		for( attr = ldap_first_attribute(ld, entry, &ber); attr != NULL; attr = ldap_next_attribute(ld, entry, ber)) {
			if ((vals = ldap_get_values(ld, entry, attr)) != NULL)  {
				
				// get number of values in firewallRule attribute
				for(i = 0; vals[i] != NULL; i++) {
					num = i;
				}
				
				// Open (or create) file with proper permission
				FILE *fp;
				fp = open("rules", O_CREAT, S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IROTH);
				close(fp);

				// Initiate shell script
				fp=fopen("rules", "w+");
				fprintf(fp, "#!/bin/sh\n\n");
				fclose(fp);

				// Open file ready to append
				fp=fopen("rules", "a");		

				// Interprete values into iptables commands
				
				int count=1; // iptables command index

				// Following for loop is for traverse in all values at opposite order (as it should be)
				for(i = num; i >= 0 ; i--) {
					strcpy(iptables, "");
					
					printf("---------------------------------------------------------------------------------------------------------------------------------\n");
					printf("%s: %s\n",  attr, vals[i]);
					
					// Generate iptables command from AD rule
					if ( iptables_gen( vals[i], iptables ) ) {
						printf("\nGenerate iptables command failed!!!\n");
					}

					// iptables-save in shell script
					fprintf(fp, "%s\n",iptables);
					printf("\n%s\n", iptables);
					printf("---------------------------------------------------------------------------------------------------------------------------------\n\n");

				}
				ldap_value_free(vals);
				
				// Close earlier opened file
				fclose(fp);
				
				// Traverse all value completed
			}
			ldap_memfree(attr);
             	}
		// All attribute has been retrieved (in fact it's only one, firewallRule)

		// Free BerElement
		if (ber != NULL) {
			ber_free(ber,0);
		}

	    printf("\n");
	}
	/* End of processing returned information */
	
	ldap_unbind_s(ld);

	return(0);
}
/* End of get_rules */


/* iptables_gen breaks value into tokens and generate a proper iptables command */
int iptables_gen( char *vals, unsigned char *iptables )
{
	int i;
	unsigned char* token;
	unsigned char temp[200];

	// tokens seperated with ":"
	token = strtok(vals, ":");

	int chk = 0;
	printf("\n");
	for (i=0; i <= 10; i++) {
		printf("%s\n", token);
		switch (i) {
			// source address
			case 1 : if ( strcmp(token, "0.0.0.0") ) {
				 	strcat(iptables, " -s ");
				 	strcat(iptables, token);
					chk = 1;
				}
				break;

			// sources address mask
			case 2 : if (chk==1) {
					strcat(iptables, "/");
				 	strcat(iptables, token);
					chk = 0;
				}
				break;

			// destination address
			case 3 : if ( strcmp(token, "0.0.0.0") ) {
				 	strcat(iptables, " -d ");
				 	strcat(iptables, token);
					chk = 1;
				}
				break;

			// destination address mask
			case 4 : if (chk==1) {
					strcat(iptables, "/");
				 	strcat(iptables, token);
					chk = 0;
				}
				break;

			// matching protocal
			case 5 : if ( strcmp(token, "any") ) {
					strcat(iptables, " -p ");
					strcat(iptables, token);
				 }
				 break;

			// source port
			case 6 : if ( strcmp(token, "-") ) {
				 	strcat(iptables, " --sport ");
				 	strcat(iptables, token);
				 }
				 break;

			// destination port
			case 7 : if ( strcmp(token, "-") ) {
				 	strcat(iptables, " --dport ");
				 	strcat(iptables, token);
				 }
				 break;

			// ICMP type
			case 8 : if ( strcmp(token, "-" ) ) {
					strcat(iptables, " --icmp-type ");
                    strcat(iptables, token);
				 }
				 break;

			// working zone
			case 9 : if ( !strcmp(token, "LOCAL-in") ) {
					strcpy(temp, "iptables -A INPUT");
					strcat(temp, iptables);
					strcpy(iptables, temp);
				 }
				 if ( !strcmp(token, "DMZ-in") ) {
					strcpy(temp, "iptables -A FORWARD");
					strcat(temp, iptables);
					strcpy(iptables, temp);
					strcat(iptables, " -o ");
					strcat(iptables, DMZ_INTERFACE);
				 }
				 if ( !strcmp(token, "DMZ-out") ) {
					strcpy(temp, "iptables -A FORWARD");
					strcat(temp, iptables);
					strcpy(iptables, temp);
					strcat(iptables, " -i ");
					strcat(iptables, DMZ_INTERFACE);
				 }
				 if ( !strcmp(token, "INTERNAL-in") ) {
					strcpy(temp, "iptables -A FORWARD");
					strcat(temp, iptables);
					strcpy(iptables, temp);
					strcat(iptables, " -o ");
					strcat(iptables, LOCAL_INTERFACE);
				 }
				 if ( !strcmp(token, "INTERNAL-out") ) {
					strcpy(temp, "iptables -A FORWARD");
					strcat(temp, iptables);
					strcpy(iptables, temp);
					strcat(iptables, " -i ");
					strcat(iptables, LOCAL_INTERFACE);
				 }
				 break;

			// jump target
			case 10 : strcat(iptables, " -j ");
				  if (!strcmp(token, "DROP"))
					  strcat(iptables, "LOG-CHAIN");
				  else
					  strcat(iptables, token);
				  break;						  
		}

		// to next token (seperate with ":")
		token = strtok(NULL, ":");	
	}

	return (0);

}
/* End of iptables_gen function */

/* iptables_apply execute iptables command saved in shell script named rule */
int iptables_apply()
{
	//system("./init.sh");
	//system("./rules");
	system("/usr/share/firescreen//init.sh");
	//system("/usr/share/rules");

	return(0);
}
/* End of iptables_apply */

int updateFlag(LDAP *ld)
{
	//LDAP *ld;
	
	char* dn;
	LDAPMod *list_of_attrs[2];
	LDAPMod attribute;
	//LDAPControl **srvrctrls, **clntctrls;
/*	
	// Init LDAP connection
	if ((ld = ldap_init(ldap_host, LDAP_PORT)) == NULL ) {
		perror( "ldap_init failed!!!" );
		exit( EXIT_FAILURE );
	}
	
	// LDAP binding
	if (ldap_bind_s(ld, root_dn, root_pw, LDAP_AUTH_SIMPLE) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_bind failed!!!" );
		exit( EXIT_FAILURE );
	}*/
	// Distinguished name of the entry that you want to modify
	dn = "cn=firescreen, cn=computers, dc=hephaestus, dc=com";
	
	// Values to add or change
	char *updateEntry[] = { "NO", NULL };

	// Specify each change in separate LDAPMod structures
	attribute.mod_type = "update";
	attribute.mod_op = LDAP_MOD_REPLACE;
	attribute.mod_values = updateEntry;

	// NOTE: When removing entire attributes, you need to specify a NULL value for the mod_values or mod_bvalues field

	// Add the pointers to these LDAPMod structures to an array
	list_of_attrs[0] = &attribute;
	list_of_attrs[1] = NULL;

	// Change the entry
	if ( ldap_modify_s( ld, dn, list_of_attrs ) != LDAP_SUCCESS ) {
		ldap_perror( ld, "ldap_modify_s" );
		return( 1 );
	}
	
	return 0;
}


int main( int argc, char *argv[] )
{
	printf("\n[ PEBKAC ]\n\n");
	
	char* base;
	char* filter;
	char* errstring;
	char* dn;
	char* attr;
	char** vals;
	
	iptables_apply();

	// Change the current working directory
	if ((chdir("/usr/share/firescreen")) < 0) {
		// Log the failure
	    exit(EXIT_FAILURE);
	}
	
	// Check whether new rules have been appied or not
	base = "cn=computers, dc=hephaestus, dc=com";
	filter = "cn=firescreen";
	attr = "update";
	
	if (1) {
		// Update new rules
		
		// Get firewall rules from Firestation ...dn = "cn=firescreen, cn=computers, dc=hephaestus, dc=com"
		base = "cn=computers, dc=hephaestus, dc=com";
		filter = "cn=firescreen";
		attr = "firewallRule";
		if ( get_rules(vals, base, filter, attr) ) {
			printf("\nFetching rules failed!!!\n");
		}
		// Get firewall rules completed

		// Apply iptables rules from Firestation
		if ( iptables_apply() ) {
			 printf("\nApply iptables rules failed!!!");
	    }
	
		printf("\nmod flag is set!!!\n\n");
	} else {
		// No changes have been made since last time updated
		printf("\nNo changed detected.\n\n");
	}

	exit(0);
}
