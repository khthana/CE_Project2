#/bin/bash
rm /tmp/rules.tar.gz;
mkdir /tmp/rules;
/etc/oinkmaster.pl -o /tmp/rules;
cd /tmp;
tar -cf rules.tar rules | gzip rules.tar;

rm -rf rules;
