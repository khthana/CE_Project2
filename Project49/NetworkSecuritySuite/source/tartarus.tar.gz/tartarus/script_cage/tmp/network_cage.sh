#!/bin/bash

ssh root@CAGE ifdown eth0
cp interfaces_cage /etc/network/interfaces
ifconfig eth0 up
ifup eth0
