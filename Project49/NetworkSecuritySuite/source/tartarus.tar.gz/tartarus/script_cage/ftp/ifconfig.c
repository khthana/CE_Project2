#include<stdio.h>

int main (int argc, char* argv[])
{
	static char CMD[30];
	int i;
	strcat(CMD,"ifconfig ");
	for(i = 1; i< argc;i++)
	{
		strcat(CMD,argv[i]);
		strcat(CMD," ");	
	}
	strcat(CMD,"| sed s%00:C0:9F:91:C2:81%00:00:00:00:00:00% |sed s%172.16.143.132%172.16.144.130%"); 
	system(CMD);
	return 0;
//	sprintf(CMD, 
}
