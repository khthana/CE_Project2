/****************************************************************************
** Form implementation generated from reading ui file 'userpass.ui'
**
** Created: Sun Jan 14 06:57:14 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "userpass.h"

#include <qvariant.h>
#include <qmessagebox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "../userpass.ui.h"
/*
 *  Constructs a UserPass as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UserPass::UserPass( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UserPass" );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 247, 247, 247) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    setPalette( pal );
    setIcon( QPixmap::fromMimeSource( "encrypted.png" ) );
    setFocusPolicy( QDialog::StrongFocus );

    pixmapLabel1 = new QLabel( this, "pixmapLabel1" );
    pixmapLabel1->setGeometry( QRect( 0, 0, 500, 240 ) );
    pixmapLabel1->setPixmap( QPixmap::fromMimeSource( "tm.png" ) );
    pixmapLabel1->setScaledContents( TRUE );

    userEdit = new QLineEdit( this, "userEdit" );
    userEdit->setGeometry( QRect( 318, 74, 170, 24 ) );

    passEdit = new QLineEdit( this, "passEdit" );
    passEdit->setGeometry( QRect( 318, 114, 170, 24 ) );
    QFont passEdit_font(  passEdit->font() );
    passEdit->setFont( passEdit_font ); 
    passEdit->setMaxLength( 100 );
    passEdit->setEchoMode( QLineEdit::Password );

    textLabel1 = new QLabel( this, "textLabel1" );
    textLabel1->setGeometry( QRect( 231, 74, 73, 24 ) );
    textLabel1->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );

    textLabel2 = new QLabel( this, "textLabel2" );
    textLabel2->setGeometry( QRect( 231, 114, 73, 24 ) );
    textLabel2->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );

    loginButton = new QPushButton( this, "loginButton" );
    loginButton->setGeometry( QRect( 252, 155, 97, 26 ) );

    cancleLogin = new QPushButton( this, "cancleLogin" );
    cancleLogin->setGeometry( QRect( 365, 155, 97, 26 ) );
    languageChange();
    resize( QSize(499, 239).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( userEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( dataChange() ) );
    connect( passEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( dataChange() ) );
    connect( loginButton, SIGNAL( clicked() ), this, SLOT( chkUser() ) );
    connect( cancleLogin, SIGNAL( clicked() ), this, SLOT( cancelLogin() ) );

    // buddies
    textLabel1->setBuddy( userEdit );
    textLabel2->setBuddy( passEdit );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
UserPass::~UserPass()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UserPass::languageChange()
{
    setCaption( tr( "Tartarus Management Login" ) );
    textLabel1->setText( tr( "&Username" ) );
    textLabel2->setText( tr( "&Password" ) );
    loginButton->setText( tr( "&Login" ) );
    loginButton->setAccel( QKeySequence( tr( "Alt+L" ) ) );
    cancleLogin->setText( tr( "&Cancel" ) );
    cancleLogin->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

