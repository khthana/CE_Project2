/****************************************************************************
** Form implementation generated from reading ui file 'honeywallmm.ui'
**
** Created: Sun Feb 11 04:59:53 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "honeywallmm.h"

#include <qvariant.h>
#include <qprogressdialog.h>
#include <qmessagebox.h>
#include <qlistbox.h>
#include <qstring.h>
#include <qdialog.h>
#include <qlabel.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <qpushbutton.h>
#include <qframe.h>
#include <qtabwidget.h>
#include <qwidget.h>
#include <qcombobox.h>
#include <qbuttongroup.h>
#include <qlineedit.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qtable.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "connectdatabase.h"
#include "../honeywallmm.ui.h"
/*
 *  Constructs a HoneywallMM as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
HoneywallMM::HoneywallMM( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "HoneywallMM" );
    setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 103, 141, 178) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 221, 223, 228) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 85, 85, 85) );
    cg.setColor( QColorGroup::Mid, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::Text, QColor( 199, 199, 199) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 86, 117, 148) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 238) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 82, 24, 139) );
    pal.setDisabled( cg );
    setPalette( pal );
    setIcon( QPixmap::fromMimeSource( "find.png" ) );

    pixmapLabel1_2 = new QLabel( this, "pixmapLabel1_2" );
    pixmapLabel1_2->setGeometry( QRect( 0, 0, 710, 680 ) );
    pixmapLabel1_2->setPixmap( QPixmap::fromMimeSource( "main.png" ) );
    pixmapLabel1_2->setScaledContents( TRUE );

    frame9 = new QFrame( this, "frame9" );
    frame9->setGeometry( QRect( 500, 10, 66, 60 ) );
    frame9->setFrameShape( QFrame::StyledPanel );
    frame9->setFrameShadow( QFrame::Raised );

    configPushButton = new QPushButton( frame9, "configPushButton" );
    configPushButton->setGeometry( QRect( 4, 4, 57, 50 ) );
    configPushButton->setFocusPolicy( QPushButton::NoFocus );
    configPushButton->setPixmap( QPixmap::fromMimeSource( "configure.png" ) );

    frame9_2 = new QFrame( this, "frame9_2" );
    frame9_2->setGeometry( QRect( 582, 10, 66, 60 ) );
    frame9_2->setFrameShape( QFrame::StyledPanel );
    frame9_2->setFrameShadow( QFrame::Raised );

    refreshPushButton = new QPushButton( frame9_2, "refreshPushButton" );
    refreshPushButton->setGeometry( QRect( 4, 4, 57, 50 ) );
    refreshPushButton->setFocusPolicy( QPushButton::NoFocus );
    refreshPushButton->setPixmap( QPixmap::fromMimeSource( "kcmsystem.png" ) );

    frame8_3 = new QFrame( this, "frame8_3" );
    frame8_3->setGeometry( QRect( 664, 10, 66, 60 ) );
    frame8_3->setFrameShape( QFrame::StyledPanel );
    frame8_3->setFrameShadow( QFrame::Raised );

    aboutPushButton = new QPushButton( frame8_3, "aboutPushButton" );
    aboutPushButton->setGeometry( QRect( 4, 4, 57, 50 ) );
    aboutPushButton->setFocusPolicy( QPushButton::NoFocus );
    aboutPushButton->setPixmap( QPixmap::fromMimeSource( "sisadmin.png" ) );

    tabPage = new QTabWidget( this, "tabPage" );
    tabPage->setGeometry( QRect( 10, 80, 712, 560 ) );
    tabPage->setPaletteBackgroundColor( QColor( 255, 255, 255 ) );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 247, 247, 247) );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 239, 239, 239) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 119, 119, 119) );
    cg.setColor( QColorGroup::Mid, QColor( 159, 159, 159) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, white );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 200, 200, 200) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    tabPage->setPalette( pal );

    statusPage = new QWidget( tabPage, "statusPage" );

    pixmapLabel1 = new QLabel( statusPage, "pixmapLabel1" );
    pixmapLabel1->setGeometry( QRect( 88, 77, 60, 60 ) );
    pixmapLabel1->setPixmap( QPixmap::fromMimeSource( "find.png" ) );
    pixmapLabel1->setScaledContents( TRUE );

    pixmapLabel2_2 = new QLabel( statusPage, "pixmapLabel2_2" );
    pixmapLabel2_2->setGeometry( QRect( 79, 236, 70, 60 ) );
    pixmapLabel2_2->setPixmap( QPixmap::fromMimeSource( "agt_update_drivers.png" ) );
    pixmapLabel2_2->setScaledContents( TRUE );

    pixmapLabel2 = new QLabel( statusPage, "pixmapLabel2" );
    pixmapLabel2->setGeometry( QRect( 79, 403, 70, 60 ) );
    pixmapLabel2->setPixmap( QPixmap::fromMimeSource( "window_list.png" ) );
    pixmapLabel2->setScaledContents( TRUE );

    frame18 = new QFrame( statusPage, "frame18" );
    frame18->setGeometry( QRect( 207, 23, 310, 140 ) );
    frame18->setFrameShape( QFrame::StyledPanel );
    frame18->setFrameShadow( QFrame::Raised );

    h1StopButton = new QPushButton( frame18, "h1StopButton" );
    h1StopButton->setGeometry( QRect( 173, 94, 68, 30 ) );

    QWidget* privateLayoutWidget = new QWidget( frame18, "layout28" );
    privateLayoutWidget->setGeometry( QRect( 35, 20, 243, 60 ) );
    layout28 = new QVBoxLayout( privateLayoutWidget, 11, 6, "layout28"); 

    layout27 = new QGridLayout( 0, 1, 1, 0, 6, "layout27"); 

    textLabel16 = new QLabel( privateLayoutWidget, "textLabel16" );

    layout27->addWidget( textLabel16, 0, 1 );

    textLabel12 = new QLabel( privateLayoutWidget, "textLabel12" );

    layout27->addWidget( textLabel12, 0, 2 );

    textLabel13 = new QLabel( privateLayoutWidget, "textLabel13" );

    layout27->addWidget( textLabel13, 0, 0 );
    layout28->addLayout( layout27 );

    layout26 = new QGridLayout( 0, 1, 1, 0, 6, "layout26"); 

    hostnameLabel = new QLabel( privateLayoutWidget, "hostnameLabel" );
    QFont hostnameLabel_font(  hostnameLabel->font() );
    hostnameLabel_font.setPointSize( 8 );
    hostnameLabel->setFont( hostnameLabel_font ); 
    hostnameLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout26->addWidget( hostnameLabel, 0, 0 );

    textLabel15_3 = new QLabel( privateLayoutWidget, "textLabel15_3" );

    layout26->addWidget( textLabel15_3, 0, 1 );

    h1Status = new QLabel( privateLayoutWidget, "h1Status" );
    QFont h1Status_font(  h1Status->font() );
    h1Status_font.setPointSize( 8 );
    h1Status->setFont( h1Status_font ); 
    h1Status->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout26->addWidget( h1Status, 0, 2 );
    layout28->addLayout( layout26 );

    h1StartButton = new QPushButton( frame18, "h1StartButton" );
    h1StartButton->setGeometry( QRect( 78, 94, 68, 30 ) );

    textLabel17_3 = new QLabel( statusPage, "textLabel17_3" );
    textLabel17_3->setGeometry( QRect( 68, 201, 100, 30 ) );
    QFont textLabel17_3_font(  textLabel17_3->font() );
    textLabel17_3_font.setPointSize( 8 );
    textLabel17_3->setFont( textLabel17_3_font ); 

    frame20 = new QFrame( statusPage, "frame20" );
    frame20->setGeometry( QRect( 208, 350, 430, 150 ) );
    frame20->setFrameShape( QFrame::StyledPanel );
    frame20->setFrameShadow( QFrame::Raised );

    cage1SuspendButton = new QPushButton( frame20, "cage1SuspendButton" );
    cage1SuspendButton->setGeometry( QRect( 347, 33, 65, 27 ) );

    cage3SuspendButton = new QPushButton( frame20, "cage3SuspendButton" );
    cage3SuspendButton->setGeometry( QRect( 347, 106, 65, 27 ) );

    cage2SuspendButton = new QPushButton( frame20, "cage2SuspendButton" );
    cage2SuspendButton->setGeometry( QRect( 347, 69, 65, 27 ) );

    cage3StartButton = new QPushButton( frame20, "cage3StartButton" );
    cage3StartButton->setGeometry( QRect( 273, 106, 68, 27 ) );

    cage2StartButton = new QPushButton( frame20, "cage2StartButton" );
    cage2StartButton->setGeometry( QRect( 273, 69, 68, 27 ) );

    QWidget* privateLayoutWidget_2 = new QWidget( frame20, "layout25" );
    privateLayoutWidget_2->setGeometry( QRect( 21, 27, 250, 110 ) );
    layout25 = new QGridLayout( privateLayoutWidget_2, 1, 1, 11, 6, "layout25"); 

    cage3Status = new QLabel( privateLayoutWidget_2, "cage3Status" );
    QFont cage3Status_font(  cage3Status->font() );
    cage3Status_font.setPointSize( 9 );
    cage3Status->setFont( cage3Status_font ); 
    cage3Status->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( cage3Status, 2, 2 );

    cage2Status = new QLabel( privateLayoutWidget_2, "cage2Status" );
    QFont cage2Status_font(  cage2Status->font() );
    cage2Status_font.setPointSize( 9 );
    cage2Status->setFont( cage2Status_font ); 
    cage2Status->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( cage2Status, 1, 2 );

    nameCage3 = new QLabel( privateLayoutWidget_2, "nameCage3" );
    QFont nameCage3_font(  nameCage3->font() );
    nameCage3_font.setPointSize( 8 );
    nameCage3->setFont( nameCage3_font ); 
    nameCage3->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( nameCage3, 2, 1 );

    hostNametextLabel1 = new QLabel( privateLayoutWidget_2, "hostNametextLabel1" );
    QFont hostNametextLabel1_font(  hostNametextLabel1->font() );
    hostNametextLabel1_font.setPointSize( 8 );
    hostNametextLabel1->setFont( hostNametextLabel1_font ); 
    hostNametextLabel1->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( hostNametextLabel1, 0, 0 );

    cage1Status = new QLabel( privateLayoutWidget_2, "cage1Status" );
    QFont cage1Status_font(  cage1Status->font() );
    cage1Status_font.setPointSize( 9 );
    cage1Status->setFont( cage1Status_font ); 
    cage1Status->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( cage1Status, 0, 2 );

    nameCage2 = new QLabel( privateLayoutWidget_2, "nameCage2" );
    QFont nameCage2_font(  nameCage2->font() );
    nameCage2_font.setPointSize( 8 );
    nameCage2->setFont( nameCage2_font ); 
    nameCage2->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( nameCage2, 1, 1 );

    hostNametextLabel3 = new QLabel( privateLayoutWidget_2, "hostNametextLabel3" );
    QFont hostNametextLabel3_font(  hostNametextLabel3->font() );
    hostNametextLabel3_font.setPointSize( 8 );
    hostNametextLabel3->setFont( hostNametextLabel3_font ); 
    hostNametextLabel3->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( hostNametextLabel3, 2, 0 );

    hostNametextLabel2 = new QLabel( privateLayoutWidget_2, "hostNametextLabel2" );
    QFont hostNametextLabel2_font(  hostNametextLabel2->font() );
    hostNametextLabel2_font.setPointSize( 8 );
    hostNametextLabel2->setFont( hostNametextLabel2_font ); 
    hostNametextLabel2->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( hostNametextLabel2, 1, 0 );

    nameCage1 = new QLabel( privateLayoutWidget_2, "nameCage1" );
    QFont nameCage1_font(  nameCage1->font() );
    nameCage1_font.setPointSize( 8 );
    nameCage1->setFont( nameCage1_font ); 
    nameCage1->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    layout25->addWidget( nameCage1, 0, 1 );

    textLabel12_3 = new QLabel( frame20, "textLabel12_3" );
    textLabel12_3->setGeometry( QRect( 203, 5, 54, 22 ) );
    QFont textLabel12_3_font(  textLabel12_3->font() );
    textLabel12_3_font.setPointSize( 8 );
    textLabel12_3->setFont( textLabel12_3_font ); 

    textLabel13_3_2 = new QLabel( frame20, "textLabel13_3_2" );
    textLabel13_3_2->setGeometry( QRect( 116, 5, 58, 22 ) );
    QFont textLabel13_3_2_font(  textLabel13_3_2->font() );
    textLabel13_3_2_font.setPointSize( 8 );
    textLabel13_3_2->setFont( textLabel13_3_2_font ); 

    textLabel13_3 = new QLabel( frame20, "textLabel13_3" );
    textLabel13_3->setGeometry( QRect( 14, 5, 96, 22 ) );
    QFont textLabel13_3_font(  textLabel13_3->font() );
    textLabel13_3_font.setPointSize( 8 );
    textLabel13_3->setFont( textLabel13_3_font ); 

    cage1StartButton = new QPushButton( frame20, "cage1StartButton" );
    cage1StartButton->setGeometry( QRect( 273, 33, 68, 27 ) );

    textLabel17 = new QLabel( statusPage, "textLabel17" );
    textLabel17->setGeometry( QRect( 78, 358, 71, 40 ) );
    QFont textLabel17_font(  textLabel17->font() );
    textLabel17_font.setPointSize( 8 );
    textLabel17->setFont( textLabel17_font ); 

    textLabel17_2 = new QLabel( statusPage, "textLabel17_2" );
    textLabel17_2->setGeometry( QRect( 51, 44, 130, 27 ) );
    QFont textLabel17_2_font(  textLabel17_2->font() );
    textLabel17_2_font.setPointSize( 9 );
    textLabel17_2_font.setBold( TRUE );
    textLabel17_2->setFont( textLabel17_2_font ); 

    frame13 = new QFrame( statusPage, "frame13" );
    frame13->setGeometry( QRect( 207, 200, 310, 111 ) );
    frame13->setFrameShape( QFrame::StyledPanel );
    frame13->setFrameShadow( QFrame::Raised );

    textLabel1_6 = new QLabel( frame13, "textLabel1_6" );
    textLabel1_6->setGeometry( QRect( 32, 62, 80, 21 ) );
    QFont textLabel1_6_font(  textLabel1_6->font() );
    textLabel1_6_font.setPointSize( 8 );
    textLabel1_6->setFont( textLabel1_6_font ); 

    snorthost_combo = new QComboBox( FALSE, frame13, "snorthost_combo" );
    snorthost_combo->setGeometry( QRect( 132, 62, 110, 26 ) );

    display_update = new QLabel( frame13, "display_update" );
    display_update->setGeometry( QRect( 31, 21, 240, 24 ) );

    pushButton34_2 = new QPushButton( frame13, "pushButton34_2" );
    pushButton34_2->setGeometry( QRect( 252, 62, 26, 26 ) );
    pushButton34_2->setPixmap( QPixmap::fromMimeSource( "down.png" ) );
    tabPage->insertTab( statusPage, QString::fromLatin1("") );

    rulePage = new QWidget( tabPage, "rulePage" );

    textLabel2_4 = new QLabel( rulePage, "textLabel2_4" );
    textLabel2_4->setGeometry( QRect( 297, 13, 65, 20 ) );

    QWidget* privateLayoutWidget_3 = new QWidget( rulePage, "layout62" );
    privateLayoutWidget_3->setGeometry( QRect( 603, 42, 73, 230 ) );
    layout62 = new QVBoxLayout( privateLayoutWidget_3, 11, 6, "layout62"); 

    layout47 = new QVBoxLayout( 0, 0, 6, "layout47"); 

    RuleOkButton = new QPushButton( privateLayoutWidget_3, "RuleOkButton" );
    layout47->addWidget( RuleOkButton );

    RuleCancleButton = new QPushButton( privateLayoutWidget_3, "RuleCancleButton" );
    layout47->addWidget( RuleCancleButton );
    layout62->addLayout( layout47 );
    spacer26_2 = new QSpacerItem( 50, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout62->addItem( spacer26_2 );

    QWidget* privateLayoutWidget_4 = new QWidget( rulePage, "layout66" );
    privateLayoutWidget_4->setGeometry( QRect( 270, 43, 49, 456 ) );
    layout66 = new QVBoxLayout( privateLayoutWidget_4, 11, 6, "layout66"); 
    spacer29 = new QSpacerItem( 20, 161, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout66->addItem( spacer29 );

    layout48 = new QVBoxLayout( 0, 0, 6, "layout48"); 

    SelectRuleButton = new QPushButton( privateLayoutWidget_4, "SelectRuleButton" );
    SelectRuleButton->setPixmap( QPixmap::fromMimeSource( "next-sail.png" ) );
    layout48->addWidget( SelectRuleButton );

    UnselectRuleButton = new QPushButton( privateLayoutWidget_4, "UnselectRuleButton" );
    UnselectRuleButton->setPixmap( QPixmap::fromMimeSource( "previos-sail.png" ) );
    layout48->addWidget( UnselectRuleButton );
    layout66->addLayout( layout48 );
    spacer27_2 = new QSpacerItem( 30, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout66->addItem( spacer27_2 );
    spacer30 = new QSpacerItem( 20, 191, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout66->addItem( spacer30 );

    selectRuleListbox = new QListBox( rulePage, "selectRuleListbox" );
    selectRuleListbox->setGeometry( QRect( 347, 42, 230, 456 ) );

    textLabel1_3 = new QLabel( rulePage, "textLabel1_3" );
    textLabel1_3->setGeometry( QRect( 13, 13, 65, 20 ) );

    RuleChoiceListbox = new QListBox( rulePage, "RuleChoiceListbox" );
    RuleChoiceListbox->setGeometry( QRect( 12, 42, 230, 456 ) );
    tabPage->insertTab( rulePage, QString::fromLatin1("") );

    TabPage = new QWidget( tabPage, "TabPage" );

    Label_Firescreen_2 = new QLabel( TabPage, "Label_Firescreen_2" );
    Label_Firescreen_2->setGeometry( QRect( 37, 18, 202, 20 ) );
    QFont Label_Firescreen_2_font(  Label_Firescreen_2->font() );
    Label_Firescreen_2_font.setBold( TRUE );
    Label_Firescreen_2->setFont( Label_Firescreen_2_font ); 

    buttonGroup2 = new QButtonGroup( TabPage, "buttonGroup2" );
    buttonGroup2->setGeometry( QRect( 18, 101, 671, 160 ) );

    Label_sadd_2_3 = new QLabel( buttonGroup2, "Label_sadd_2_3" );
    Label_sadd_2_3->setGeometry( QRect( 336, 29, 130, 20 ) );
    QFont Label_sadd_2_3_font(  Label_sadd_2_3->font() );
    Label_sadd_2_3->setFont( Label_sadd_2_3_font ); 

    Label_sadd_2_2_2_3 = new QLabel( buttonGroup2, "Label_sadd_2_2_2_3" );
    Label_sadd_2_2_2_3->setGeometry( QRect( 336, 69, 130, 20 ) );
    QFont Label_sadd_2_2_2_3_font(  Label_sadd_2_2_2_3->font() );
    Label_sadd_2_2_2_3->setFont( Label_sadd_2_2_2_3_font ); 

    Label_sadd_3_2_3_2_2_2 = new QLabel( buttonGroup2, "Label_sadd_3_2_3_2_2_2" );
    Label_sadd_3_2_3_2_2_2->setGeometry( QRect( 336, 111, 64, 20 ) );
    QFont Label_sadd_3_2_3_2_2_2_font(  Label_sadd_3_2_3_2_2_2->font() );
    Label_sadd_3_2_3_2_2_2->setFont( Label_sadd_3_2_3_2_2_2_font ); 

    Label_sadd_3_2_3_2 = new QLabel( buttonGroup2, "Label_sadd_3_2_3_2" );
    Label_sadd_3_2_3_2->setGeometry( QRect( 22, 111, 45, 20 ) );
    QFont Label_sadd_3_2_3_2_font(  Label_sadd_3_2_3_2->font() );
    Label_sadd_3_2_3_2->setFont( Label_sadd_3_2_3_2_font ); 

    Caction_combo = new QComboBox( FALSE, buttonGroup2, "Caction_combo" );
    Caction_combo->setGeometry( QRect( 70, 110, 81, 26 ) );
    QFont Caction_combo_font(  Caction_combo->font() );
    Caction_combo_font.setPointSize( 9 );
    Caction_combo->setFont( Caction_combo_font ); 

    Label_sadd_3_2_3_2_2 = new QLabel( buttonGroup2, "Label_sadd_3_2_3_2_2" );
    Label_sadd_3_2_3_2_2->setGeometry( QRect( 178, 111, 60, 20 ) );
    QFont Label_sadd_3_2_3_2_2_font(  Label_sadd_3_2_3_2_2->font() );
    Label_sadd_3_2_3_2_2->setFont( Label_sadd_3_2_3_2_2_font ); 

    Cprotocol_combo = new QComboBox( FALSE, buttonGroup2, "Cprotocol_combo" );
    Cprotocol_combo->setGeometry( QRect( 240, 110, 70, 26 ) );
    QFont Cprotocol_combo_font(  Cprotocol_combo->font() );
    Cprotocol_combo_font.setPointSize( 9 );
    Cprotocol_combo->setFont( Cprotocol_combo_font ); 

    Cdirection_combo = new QComboBox( FALSE, buttonGroup2, "Cdirection_combo" );
    Cdirection_combo->setGeometry( QRect( 405, 110, 70, 26 ) );

    Label_sadd_4 = new QLabel( buttonGroup2, "Label_sadd_4" );
    Label_sadd_4->setGeometry( QRect( 22, 29, 104, 20 ) );
    QFont Label_sadd_4_font(  Label_sadd_4->font() );
    Label_sadd_4->setFont( Label_sadd_4_font ); 

    Label_sadd_3_2_3 = new QLabel( buttonGroup2, "Label_sadd_3_2_3" );
    Label_sadd_3_2_3->setGeometry( QRect( 22, 69, 104, 20 ) );
    QFont Label_sadd_3_2_3_font(  Label_sadd_3_2_3->font() );
    Label_sadd_3_2_3->setFont( Label_sadd_3_2_3_font ); 

    Cdport_edit = new QLineEdit( buttonGroup2, "Cdport_edit" );
    Cdport_edit->setGeometry( QRect( 471, 67, 110, 26 ) );
    QFont Cdport_edit_font(  Cdport_edit->font() );
    Cdport_edit_font.setPointSize( 9 );
    Cdport_edit->setFont( Cdport_edit_font ); 

    Csource_edit = new QLineEdit( buttonGroup2, "Csource_edit" );
    Csource_edit->setGeometry( QRect( 131, 27, 190, 26 ) );
    QFont Csource_edit_font(  Csource_edit->font() );
    Csource_edit_font.setPointSize( 9 );
    Csource_edit->setFont( Csource_edit_font ); 

    Cdest_edit = new QLineEdit( buttonGroup2, "Cdest_edit" );
    Cdest_edit->setGeometry( QRect( 471, 27, 190, 26 ) );
    QFont Cdest_edit_font(  Cdest_edit->font() );
    Cdest_edit_font.setPointSize( 9 );
    Cdest_edit->setFont( Cdest_edit_font ); 

    Csport_edit = new QLineEdit( buttonGroup2, "Csport_edit" );
    Csport_edit->setGeometry( QRect( 131, 67, 110, 26 ) );
    QFont Csport_edit_font(  Csport_edit->font() );
    Csport_edit_font.setPointSize( 9 );
    Csport_edit->setFont( Csport_edit_font ); 

    Label_sadd_2_3_2 = new QLabel( TabPage, "Label_sadd_2_3_2" );
    Label_sadd_2_3_2->setGeometry( QRect( 28, 60, 90, 20 ) );
    QFont Label_sadd_2_3_2_font(  Label_sadd_2_3_2->font() );
    Label_sadd_2_3_2->setFont( Label_sadd_2_3_2_font ); 

    Cname_edit = new QLineEdit( TabPage, "Cname_edit" );
    Cname_edit->setGeometry( QRect( 120, 60, 170, 26 ) );

    Label_sadd_2_3_2_2 = new QLabel( TabPage, "Label_sadd_2_3_2_2" );
    Label_sadd_2_3_2_2->setGeometry( QRect( 340, 60, 90, 20 ) );
    QFont Label_sadd_2_3_2_2_font(  Label_sadd_2_3_2_2->font() );
    Label_sadd_2_3_2_2->setFont( Label_sadd_2_3_2_2_font ); 

    pushButton32_2 = new QPushButton( TabPage, "pushButton32_2" );
    pushButton32_2->setGeometry( QRect( 649, 46, 40, 40 ) );
    pushButton32_2->setPixmap( QPixmap::fromMimeSource( "button_cancel.png" ) );

    groupBox24 = new QGroupBox( TabPage, "groupBox24" );
    groupBox24->setGeometry( QRect( 18, 290, 671, 200 ) );

    textLabel1_5 = new QLabel( groupBox24, "textLabel1_5" );
    textLabel1_5->setGeometry( QRect( 13, 31, 66, 20 ) );

    checkBox17_2 = new QCheckBox( groupBox24, "checkBox17_2" );
    checkBox17_2->setGeometry( QRect( 347, 150, 80, 21 ) );
    QFont checkBox17_2_font(  checkBox17_2->font() );
    checkBox17_2->setFont( checkBox17_2_font ); 

    Cflow_combo = new QComboBox( FALSE, groupBox24, "Cflow_combo" );
    Cflow_combo->setGeometry( QRect( 541, 150, 120, 26 ) );
    QFont Cflow_combo_font(  Cflow_combo->font() );
    Cflow_combo_font.setPointSize( 9 );
    Cflow_combo->setFont( Cflow_combo_font ); 

    textLabel1_5_2 = new QLabel( groupBox24, "textLabel1_5_2" );
    textLabel1_5_2->setGeometry( QRect( 12, 71, 60, 20 ) );

    Cmessage_edit = new QLineEdit( groupBox24, "Cmessage_edit" );
    Cmessage_edit->setGeometry( QRect( 91, 30, 570, 26 ) );

    Csid_edit = new QLineEdit( groupBox24, "Csid_edit" );
    Csid_edit->setGeometry( QRect( 90, 150, 120, 26 ) );
    QFont Csid_edit_font(  Csid_edit->font() );
    Csid_edit_font.setPointSize( 9 );
    Csid_edit->setFont( Csid_edit_font ); 

    textLabel1_5_3_2 = new QLabel( groupBox24, "textLabel1_5_3_2" );
    textLabel1_5_3_2->setGeometry( QRect( 12, 150, 60, 20 ) );

    textLabel1_5_3_2_2_2 = new QLabel( groupBox24, "textLabel1_5_3_2_2_2" );
    textLabel1_5_3_2_2_2->setGeometry( QRect( 12, 110, 50, 20 ) );

    Cpriority_edit = new QLineEdit( groupBox24, "Cpriority_edit" );
    Cpriority_edit->setGeometry( QRect( 91, 109, 120, 26 ) );
    QFont Cpriority_edit_font(  Cpriority_edit->font() );
    Cpriority_edit_font.setPointSize( 9 );
    Cpriority_edit->setFont( Cpriority_edit_font ); 

    Crev_edit = new QLineEdit( groupBox24, "Crev_edit" );
    Crev_edit->setGeometry( QRect( 540, 109, 120, 26 ) );
    QFont Crev_edit_font(  Crev_edit->font() );
    Crev_edit_font.setPointSize( 9 );
    Crev_edit->setFont( Crev_edit_font ); 

    textLabel1_5_3_2_2 = new QLabel( groupBox24, "textLabel1_5_3_2_2" );
    textLabel1_5_3_2_2->setGeometry( QRect( 252, 110, 67, 20 ) );

    checkBox17 = new QCheckBox( groupBox24, "checkBox17" );
    checkBox17->setGeometry( QRect( 253, 150, 70, 21 ) );
    QFont checkBox17_font(  checkBox17->font() );
    checkBox17->setFont( checkBox17_font ); 

    textLabel1_5_3_2_2_2_2 = new QLabel( groupBox24, "textLabel1_5_3_2_2_2_2" );
    textLabel1_5_3_2_2_2_2->setGeometry( QRect( 482, 150, 30, 20 ) );

    textLabel1_5_3_2_3 = new QLabel( groupBox24, "textLabel1_5_3_2_3" );
    textLabel1_5_3_2_3->setGeometry( QRect( 482, 110, 50, 20 ) );

    Ccontent_edit = new QLineEdit( groupBox24, "Ccontent_edit" );
    Ccontent_edit->setGeometry( QRect( 90, 70, 570, 26 ) );

    Cclasstype_edit = new QLineEdit( groupBox24, "Cclasstype_edit" );
    Cclasstype_edit->setGeometry( QRect( 320, 109, 120, 26 ) );
    QFont Cclasstype_edit_font(  Cclasstype_edit->font() );
    Cclasstype_edit_font.setPointSize( 9 );
    Cclasstype_edit->setFont( Cclasstype_edit_font ); 

    pushButton32 = new QPushButton( TabPage, "pushButton32" );
    pushButton32->setGeometry( QRect( 600, 46, 40, 40 ) );
    pushButton32->setPixmap( QPixmap::fromMimeSource( "button_check.png" ) );

    host_combo = new QComboBox( FALSE, TabPage, "host_combo" );
    host_combo->setGeometry( QRect( 440, 60, 130, 26 ) );
    tabPage->insertTab( TabPage, QString::fromLatin1("") );

    managePage = new QWidget( tabPage, "managePage" );

    frame4 = new QFrame( managePage, "frame4" );
    frame4->setGeometry( QRect( 60, 240, 590, 275 ) );
    frame4->setFrameShape( QFrame::StyledPanel );
    frame4->setFrameShadow( QFrame::Raised );
    frame4Layout = new QGridLayout( frame4, 1, 1, 11, 6, "frame4Layout"); 

    layout21 = new QHBoxLayout( 0, 0, 6, "layout21"); 

    layout19 = new QVBoxLayout( 0, 0, 6, "layout19"); 

    numCheck = new QCheckBox( frame4, "numCheck" );
    layout19->addWidget( numCheck );

    groupCheck = new QCheckBox( frame4, "groupCheck" );
    layout19->addWidget( groupCheck );

    ownCheck = new QCheckBox( frame4, "ownCheck" );
    layout19->addWidget( ownCheck );

    passCheck = new QCheckBox( frame4, "passCheck" );
    layout19->addWidget( passCheck );

    modeCheck = new QCheckBox( frame4, "modeCheck" );
    layout19->addWidget( modeCheck );
    layout21->addLayout( layout19 );

    layout20 = new QVBoxLayout( 0, 0, 6, "layout20"); 

    numUser = new QSpinBox( frame4, "numUser" );
    layout20->addWidget( numUser );

    groupRoot = new QSpinBox( frame4, "groupRoot" );
    layout20->addWidget( groupRoot );

    ownerPass = new QLineEdit( frame4, "ownerPass" );
    layout20->addWidget( ownerPass );

    passCh = new QComboBox( FALSE, frame4, "passCh" );
    layout20->addWidget( passCh );

    modePass = new QComboBox( FALSE, frame4, "modePass" );
    layout20->addWidget( modePass );
    layout21->addLayout( layout20 );

    frame4Layout->addLayout( layout21, 1, 0 );

    layout279 = new QVBoxLayout( 0, 0, 6, "layout279"); 

    saveConfigButton = new QPushButton( frame4, "saveConfigButton" );
    layout279->addWidget( saveConfigButton );

    resetConfigButton = new QPushButton( frame4, "resetConfigButton" );
    layout279->addWidget( resetConfigButton );

    frame4Layout->addLayout( layout279, 2, 0 );

    textLabel5 = new QLabel( frame4, "textLabel5" );
    QFont textLabel5_font(  textLabel5->font() );
    textLabel5_font.setBold( TRUE );
    textLabel5_font.setUnderline( TRUE );
    textLabel5->setFont( textLabel5_font ); 
    textLabel5->setAlignment( int( QLabel::AlignCenter ) );

    frame4Layout->addWidget( textLabel5, 0, 0 );

    frame24 = new QFrame( managePage, "frame24" );
    frame24->setGeometry( QRect( 60, 10, 590, 220 ) );
    frame24->setFrameShape( QFrame::StyledPanel );
    frame24->setFrameShadow( QFrame::Raised );

    textLabel1 = new QLabel( frame24, "textLabel1" );
    textLabel1->setGeometry( QRect( 34, 61, 46, 20 ) );
    QFont textLabel1_font(  textLabel1->font() );
    textLabel1->setFont( textLabel1_font ); 

    textLabel2 = new QLabel( frame24, "textLabel2" );
    textLabel2->setGeometry( QRect( 33, 104, 35, 20 ) );
    QFont textLabel2_font(  textLabel2->font() );
    textLabel2->setFont( textLabel2_font ); 

    textLabel3 = new QLabel( frame24, "textLabel3" );
    textLabel3->setGeometry( QRect( 313, 62, 20, 20 ) );
    QFont textLabel3_font(  textLabel3->font() );
    textLabel3->setFont( textLabel3_font ); 

    textLabel4 = new QLabel( frame24, "textLabel4" );
    textLabel4->setGeometry( QRect( 313, 100, 90, 28 ) );
    QFont textLabel4_font(  textLabel4->font() );
    textLabel4->setFont( textLabel4_font ); 

    pathCage = new QLineEdit( frame24, "pathCage" );
    pathCage->setGeometry( QRect( 83, 100, 200, 26 ) );
    QFont pathCage_font(  pathCage->font() );
    pathCage_font.setPointSize( 9 );
    pathCage->setFont( pathCage_font ); 

    PushButtonDelete = new QPushButton( frame24, "PushButtonDelete" );
    PushButtonDelete->setGeometry( QRect( 412, 175, 160, 28 ) );

    hostnamecomboBox = new QComboBox( FALSE, frame24, "hostnamecomboBox" );
    hostnamecomboBox->setEnabled( TRUE );
    hostnamecomboBox->setGeometry( QRect( 432, 100, 140, 28 ) );
    QFont hostnamecomboBox_font(  hostnamecomboBox->font() );
    hostnamecomboBox_font.setPointSize( 9 );
    hostnamecomboBox->setFont( hostnamecomboBox_font ); 
    hostnamecomboBox->setAcceptDrops( FALSE );
    hostnamecomboBox->setEditable( FALSE );
    hostnamecomboBox->setDuplicatesEnabled( FALSE );

    ipCage = new QLineEdit( frame24, "ipCage" );
    ipCage->setGeometry( QRect( 373, 58, 200, 26 ) );
    QFont ipCage_font(  ipCage->font() );
    ipCage_font.setPointSize( 9 );
    ipCage->setFont( ipCage_font ); 

    textLabel6 = new QLabel( frame24, "textLabel6" );
    textLabel6->setGeometry( QRect( 7, 18, 580, 21 ) );
    QFont textLabel6_font(  textLabel6->font() );
    textLabel6_font.setBold( TRUE );
    textLabel6_font.setUnderline( TRUE );
    textLabel6->setFont( textLabel6_font ); 

    PushButtonLast = new QPushButton( frame24, "PushButtonLast" );
    PushButtonLast->setGeometry( QRect( 442, 141, 130, 28 ) );

    PushButtonFirst = new QPushButton( frame24, "PushButtonFirst" );
    PushButtonFirst->setGeometry( QRect( 15, 141, 130, 28 ) );

    PushButtonNext = new QPushButton( frame24, "PushButtonNext" );
    PushButtonNext->setGeometry( QRect( 302, 141, 130, 28 ) );

    PushButtonPrev = new QPushButton( frame24, "PushButtonPrev" );
    PushButtonPrev->setGeometry( QRect( 159, 141, 130, 28 ) );

    nameCage = new QLineEdit( frame24, "nameCage" );
    nameCage->setGeometry( QRect( 84, 58, 200, 26 ) );
    QFont nameCage_font(  nameCage->font() );
    nameCage_font.setPointSize( 9 );
    nameCage->setFont( nameCage_font ); 

    PushButtonClear = new QPushButton( frame24, "PushButtonClear" );
    PushButtonClear->setGeometry( QRect( 15, 175, 160, 28 ) );

    PushButtonInsert = new QPushButton( frame24, "PushButtonInsert" );
    PushButtonInsert->setGeometry( QRect( 217, 175, 160, 28 ) );
    tabPage->insertTab( managePage, QString::fromLatin1("") );

    controlPage = new QWidget( tabPage, "controlPage" );

    cageTable = new QTable( controlPage, "cageTable" );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Name" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "IP" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Path" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Hostname" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "State" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Current User" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Limit User" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "User of group root" ) );
    cageTable->setNumCols( cageTable->numCols() + 1 );
    cageTable->horizontalHeader()->setLabel( cageTable->numCols() - 1, tr( "Limit of group root" ) );
    cageTable->setGeometry( QRect( 18, 50, 670, 470 ) );
    QFont cageTable_font(  cageTable->font() );
    cageTable_font.setPointSize( 9 );
    cageTable->setFont( cageTable_font ); 
    cageTable->setNumRows( 0 );
    cageTable->setNumCols( 9 );
    cageTable->setReadOnly( TRUE );

    textLabel1_2 = new QLabel( controlPage, "textLabel1_2" );
    textLabel1_2->setGeometry( QRect( 37, 18, 150, 20 ) );
    QFont textLabel1_2_font(  textLabel1_2->font() );
    textLabel1_2_font.setBold( TRUE );
    textLabel1_2->setFont( textLabel1_2_font ); 
    tabPage->insertTab( controlPage, QString::fromLatin1("") );

    eventPage = new QWidget( tabPage, "eventPage" );

    textLabel3_2 = new QLabel( eventPage, "textLabel3_2" );
    textLabel3_2->setGeometry( QRect( 507, 26, 60, 20 ) );
    QFont textLabel3_2_font(  textLabel3_2->font() );
    textLabel3_2->setFont( textLabel3_2_font ); 

    LogcomboBox2 = new QComboBox( FALSE, eventPage, "LogcomboBox2" );
    LogcomboBox2->setGeometry( QRect( 400, 20, 100, 31 ) );
    QFont LogcomboBox2_font(  LogcomboBox2->font() );
    LogcomboBox2->setFont( LogcomboBox2_font ); 

    textLabel2_3 = new QLabel( eventPage, "textLabel2_3" );
    textLabel2_3->setGeometry( QRect( 350, 26, 40, 20 ) );
    QFont textLabel2_3_font(  textLabel2_3->font() );
    textLabel2_3->setFont( textLabel2_3_font ); 

    snort_inline_log = new QGroupBox( eventPage, "snort_inline_log" );
    snort_inline_log->setEnabled( TRUE );
    snort_inline_log->setGeometry( QRect( 17, 58, 670, 430 ) );

    QWidget* privateLayoutWidget_5 = new QWidget( snort_inline_log, "layout31_2" );
    privateLayoutWidget_5->setGeometry( QRect( 20, 40, 630, 380 ) );
    layout31_2 = new QGridLayout( privateLayoutWidget_5, 1, 1, 11, 6, "layout31_2"); 

    layout50_2 = new QHBoxLayout( 0, 0, 6, "layout50_2"); 

    layout19_3 = new QHBoxLayout( 0, 0, 6, "layout19_3"); 

    layout14_2 = new QVBoxLayout( 0, 0, 6, "layout14_2"); 

    ip_src_checkBox = new QCheckBox( privateLayoutWidget_5, "ip_src_checkBox" );
    QFont ip_src_checkBox_font(  ip_src_checkBox->font() );
    ip_src_checkBox_font.setPointSize( 9 );
    ip_src_checkBox->setFont( ip_src_checkBox_font ); 
    layout14_2->addWidget( ip_src_checkBox );

    ip_src_lineEdit = new QLineEdit( privateLayoutWidget_5, "ip_src_lineEdit" );
    layout14_2->addWidget( ip_src_lineEdit );
    layout19_3->addLayout( layout14_2 );

    layout15_2 = new QVBoxLayout( 0, 0, 6, "layout15_2"); 

    ip_dst_checkBox = new QCheckBox( privateLayoutWidget_5, "ip_dst_checkBox" );
    QFont ip_dst_checkBox_font(  ip_dst_checkBox->font() );
    ip_dst_checkBox_font.setPointSize( 9 );
    ip_dst_checkBox->setFont( ip_dst_checkBox_font ); 
    layout15_2->addWidget( ip_dst_checkBox );

    ip_dst_lineEdit = new QLineEdit( privateLayoutWidget_5, "ip_dst_lineEdit" );
    layout15_2->addWidget( ip_dst_lineEdit );
    layout19_3->addLayout( layout15_2 );

    layout16_2 = new QVBoxLayout( 0, 0, 6, "layout16_2"); 

    sig_name_checkBox = new QCheckBox( privateLayoutWidget_5, "sig_name_checkBox" );
    QFont sig_name_checkBox_font(  sig_name_checkBox->font() );
    sig_name_checkBox_font.setPointSize( 9 );
    sig_name_checkBox->setFont( sig_name_checkBox_font ); 
    layout16_2->addWidget( sig_name_checkBox );

    sig_lineEdit = new QLineEdit( privateLayoutWidget_5, "sig_lineEdit" );
    layout16_2->addWidget( sig_lineEdit );
    layout19_3->addLayout( layout16_2 );

    layout17_3 = new QVBoxLayout( 0, 0, 6, "layout17_3"); 
    layout19_3->addLayout( layout17_3 );
    layout50_2->addLayout( layout19_3 );

    snortFind = new QPushButton( privateLayoutWidget_5, "snortFind" );
    QFont snortFind_font(  snortFind->font() );
    snortFind_font.setPointSize( 9 );
    snortFind->setFont( snortFind_font ); 
    layout50_2->addWidget( snortFind );

    layout31_2->addLayout( layout50_2, 0, 0 );

    snortLogTable = new QTable( privateLayoutWidget_5, "snortLogTable" );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "time" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "sid" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "cid" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "signature" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "sig_name" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "sig_class_id" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "sig_priority" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "ip_src" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "ip_dst" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "sport" ) );
    snortLogTable->setNumCols( snortLogTable->numCols() + 1 );
    snortLogTable->horizontalHeader()->setLabel( snortLogTable->numCols() - 1, tr( "dport" ) );
    QFont snortLogTable_font(  snortLogTable->font() );
    snortLogTable_font.setPointSize( 9 );
    snortLogTable->setFont( snortLogTable_font ); 
    snortLogTable->setNumRows( 0 );
    snortLogTable->setNumCols( 11 );
    snortLogTable->setSelectionMode( QTable::NoSelection );

    layout31_2->addWidget( snortLogTable, 1, 0 );

    samhain_log = new QGroupBox( snort_inline_log, "samhain_log" );
    samhain_log->setEnabled( TRUE );
    samhain_log->setGeometry( QRect( 0, 0, 670, 430 ) );

    QWidget* privateLayoutWidget_6 = new QWidget( samhain_log, "layout32_3" );
    privateLayoutWidget_6->setGeometry( QRect( 20, 40, 630, 380 ) );
    layout32_3 = new QGridLayout( privateLayoutWidget_6, 1, 1, 11, 6, "layout32_3"); 

    layout38_3 = new QHBoxLayout( 0, 0, 6, "layout38_3"); 

    layout36_4 = new QVBoxLayout( 0, 0, 6, "layout36_4"); 

    path_checkBox = new QCheckBox( privateLayoutWidget_6, "path_checkBox" );
    QFont path_checkBox_font(  path_checkBox->font() );
    path_checkBox_font.setPointSize( 9 );
    path_checkBox->setFont( path_checkBox_font ); 
    layout36_4->addWidget( path_checkBox );

    path_lineEdit = new QLineEdit( privateLayoutWidget_6, "path_lineEdit" );
    layout36_4->addWidget( path_lineEdit );
    layout38_3->addLayout( layout36_4 );

    layout35_4 = new QVBoxLayout( 0, 0, 6, "layout35_4"); 

    owner_old_checkBox = new QCheckBox( privateLayoutWidget_6, "owner_old_checkBox" );
    QFont owner_old_checkBox_font(  owner_old_checkBox->font() );
    owner_old_checkBox_font.setPointSize( 9 );
    owner_old_checkBox->setFont( owner_old_checkBox_font ); 
    layout35_4->addWidget( owner_old_checkBox );

    owner_old_lineEdit = new QLineEdit( privateLayoutWidget_6, "owner_old_lineEdit" );
    layout35_4->addWidget( owner_old_lineEdit );
    layout38_3->addLayout( layout35_4 );

    layout34_4 = new QVBoxLayout( 0, 0, 6, "layout34_4"); 

    owner_new_checkBox = new QCheckBox( privateLayoutWidget_6, "owner_new_checkBox" );
    QFont owner_new_checkBox_font(  owner_new_checkBox->font() );
    owner_new_checkBox_font.setPointSize( 9 );
    owner_new_checkBox->setFont( owner_new_checkBox_font ); 
    layout34_4->addWidget( owner_new_checkBox );

    owner_new_lineEdit = new QLineEdit( privateLayoutWidget_6, "owner_new_lineEdit" );
    layout34_4->addWidget( owner_new_lineEdit );
    layout38_3->addLayout( layout34_4 );

    layout32_3->addLayout( layout38_3, 0, 0 );

    samhainLogTable = new QTable( privateLayoutWidget_6, "samhainLogTable" );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "time" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "host" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "messege" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "path" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "mode_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "mode_new" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "owner_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "owner_new" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "group_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "group_new" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "ctime_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "ctime_new" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "link_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "link_new" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "hardlink_old" ) );
    samhainLogTable->setNumCols( samhainLogTable->numCols() + 1 );
    samhainLogTable->horizontalHeader()->setLabel( samhainLogTable->numCols() - 1, tr( "hardlink_new" ) );
    QFont samhainLogTable_font(  samhainLogTable->font() );
    samhainLogTable_font.setPointSize( 9 );
    samhainLogTable->setFont( samhainLogTable_font ); 
    samhainLogTable->setResizePolicy( QTable::Manual );
    samhainLogTable->setNumRows( 0 );
    samhainLogTable->setNumCols( 16 );
    samhainLogTable->setReadOnly( TRUE );
    samhainLogTable->setSorting( FALSE );
    samhainLogTable->setSelectionMode( QTable::NoSelection );

    layout32_3->addMultiCellWidget( samhainLogTable, 1, 1, 0, 1 );

    samhainFind = new QPushButton( privateLayoutWidget_6, "samhainFind" );
    QFont samhainFind_font(  samhainFind->font() );
    samhainFind_font.setPointSize( 9 );
    samhainFind->setFont( samhainFind_font ); 

    layout32_3->addWidget( samhainFind, 0, 1 );

    sebek_log = new QGroupBox( samhain_log, "sebek_log" );
    sebek_log->setGeometry( QRect( 0, 0, 670, 430 ) );

    QWidget* privateLayoutWidget_7 = new QWidget( sebek_log, "layout38_2_2" );
    privateLayoutWidget_7->setGeometry( QRect( 20, 20, 560, 80 ) );
    layout38_2_2 = new QHBoxLayout( privateLayoutWidget_7, 11, 6, "layout38_2_2"); 

    layout36_2_2 = new QVBoxLayout( 0, 0, 6, "layout36_2_2"); 

    command_checkBox1 = new QCheckBox( privateLayoutWidget_7, "command_checkBox1" );
    QFont command_checkBox1_font(  command_checkBox1->font() );
    command_checkBox1_font.setPointSize( 9 );
    command_checkBox1->setFont( command_checkBox1_font ); 
    layout36_2_2->addWidget( command_checkBox1 );

    command_lineEdit1 = new QLineEdit( privateLayoutWidget_7, "command_lineEdit1" );
    layout36_2_2->addWidget( command_lineEdit1 );
    layout38_2_2->addLayout( layout36_2_2 );

    layout35_2_2 = new QVBoxLayout( 0, 0, 6, "layout35_2_2"); 

    command_checkBox2 = new QCheckBox( privateLayoutWidget_7, "command_checkBox2" );
    QFont command_checkBox2_font(  command_checkBox2->font() );
    command_checkBox2_font.setPointSize( 9 );
    command_checkBox2->setFont( command_checkBox2_font ); 
    layout35_2_2->addWidget( command_checkBox2 );

    command_lineEdit2 = new QLineEdit( privateLayoutWidget_7, "command_lineEdit2" );
    layout35_2_2->addWidget( command_lineEdit2 );
    layout38_2_2->addLayout( layout35_2_2 );

    layout34_2_2 = new QVBoxLayout( 0, 0, 6, "layout34_2_2"); 

    command_checkBox3 = new QCheckBox( privateLayoutWidget_7, "command_checkBox3" );
    QFont command_checkBox3_font(  command_checkBox3->font() );
    command_checkBox3_font.setPointSize( 9 );
    command_checkBox3->setFont( command_checkBox3_font ); 
    layout34_2_2->addWidget( command_checkBox3 );

    command_lineEdit3 = new QLineEdit( privateLayoutWidget_7, "command_lineEdit3" );
    layout34_2_2->addWidget( command_lineEdit3 );
    layout38_2_2->addLayout( layout34_2_2 );

    sebekLogTable = new QTable( sebek_log, "sebekLogTable" );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "ip_addr" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "insert_time" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "command" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "counter" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "filed" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "pid" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "uid" ) );
    sebekLogTable->setNumCols( sebekLogTable->numCols() + 1 );
    sebekLogTable->horizontalHeader()->setLabel( sebekLogTable->numCols() - 1, tr( "length" ) );
    sebekLogTable->setGeometry( QRect( 20, 110, 630, 300 ) );
    QFont sebekLogTable_font(  sebekLogTable->font() );
    sebekLogTable_font.setPointSize( 9 );
    sebekLogTable->setFont( sebekLogTable_font ); 
    sebekLogTable->setNumRows( 0 );
    sebekLogTable->setNumCols( 8 );

    sebekFind = new QPushButton( sebek_log, "sebekFind" );
    sebekFind->setGeometry( QRect( 588, 60, 60, 26 ) );
    QFont sebekFind_font(  sebekFind->font() );
    sebekFind_font.setPointSize( 9 );
    sebekFind->setFont( sebekFind_font ); 

    LogcomboBox = new QComboBox( FALSE, eventPage, "LogcomboBox" );
    LogcomboBox->setGeometry( QRect( 30, 20, 140, 31 ) );
    QFont LogcomboBox_font(  LogcomboBox->font() );
    LogcomboBox->setFont( LogcomboBox_font ); 
    tabPage->insertTab( eventPage, QString::fromLatin1("") );

    TabPage_2 = new QWidget( tabPage, "TabPage_2" );

    snort_inline_log_2 = new QGroupBox( TabPage_2, "snort_inline_log_2" );
    snort_inline_log_2->setEnabled( TRUE );
    snort_inline_log_2->setGeometry( QRect( 17, 58, 670, 430 ) );

    firebreakTable = new QTable( snort_inline_log_2, "firebreakTable" );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "time" ) );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "sid" ) );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "sig_name" ) );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "sig_priority" ) );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "ip_src" ) );
    firebreakTable->setNumCols( firebreakTable->numCols() + 1 );
    firebreakTable->horizontalHeader()->setLabel( firebreakTable->numCols() - 1, tr( "ip_dst" ) );
    firebreakTable->setGeometry( QRect( 21, 41, 628, 370 ) );
    QFont firebreakTable_font(  firebreakTable->font() );
    firebreakTable_font.setPointSize( 9 );
    firebreakTable->setFont( firebreakTable_font ); 
    firebreakTable->setNumRows( 0 );
    firebreakTable->setNumCols( 6 );
    firebreakTable->setSelectionMode( QTable::NoSelection );

    textLabel1_2_2 = new QLabel( TabPage_2, "textLabel1_2_2" );
    textLabel1_2_2->setGeometry( QRect( 37, 18, 263, 20 ) );
    QFont textLabel1_2_2_font(  textLabel1_2_2->font() );
    textLabel1_2_2_font.setBold( TRUE );
    textLabel1_2_2->setFont( textLabel1_2_2_font ); 
    tabPage->insertTab( TabPage_2, QString::fromLatin1("") );
    languageChange();
    resize( QSize(735, 637).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( configPushButton, SIGNAL( clicked() ), this, SLOT( configTartarus() ) );
    connect( aboutPushButton, SIGNAL( clicked() ), this, SLOT( about() ) );
    connect( refreshPushButton, SIGNAL( clicked() ), this, SLOT( refresh() ) );
    connect( LogcomboBox, SIGNAL( activated(const QString&) ), this, SLOT( showLog() ) );
    connect( sebekFind, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( command_checkBox3, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( command_checkBox2, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( command_checkBox1, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( samhainFind, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( owner_new_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( owner_old_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( path_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( snortFind, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( sig_name_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( ip_dst_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( ip_src_checkBox, SIGNAL( clicked() ), this, SLOT( showLog() ) );
    connect( LogcomboBox2, SIGNAL( activated(const QString&) ), this, SLOT( showLog() ) );
    connect( PushButtonClear, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( nameCage, SIGNAL( textChanged(const QString&) ), this, SLOT( dataChange() ) );
    connect( PushButtonInsert, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( PushButtonPrev, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( PushButtonNext, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( PushButtonFirst, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( PushButtonLast, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( ipCage, SIGNAL( textChanged(const QString&) ), this, SLOT( dataChange() ) );
    connect( PushButtonDelete, SIGNAL( pressed() ), this, SLOT( checkButton() ) );
    connect( pathCage, SIGNAL( textChanged(const QString&) ), this, SLOT( dataChange() ) );
    connect( resetConfigButton, SIGNAL( pressed() ), this, SLOT( createCageConfig() ) );
    connect( saveConfigButton, SIGNAL( pressed() ), this, SLOT( createCageConfig() ) );
    connect( modeCheck, SIGNAL( stateChanged(int) ), this, SLOT( dataChange() ) );
    connect( passCheck, SIGNAL( stateChanged(int) ), this, SLOT( dataChange() ) );
    connect( ownCheck, SIGNAL( stateChanged(int) ), this, SLOT( dataChange() ) );
    connect( groupCheck, SIGNAL( stateChanged(int) ), this, SLOT( dataChange() ) );
    connect( numCheck, SIGNAL( stateChanged(int) ), this, SLOT( dataChange() ) );
    connect( pushButton32_2, SIGNAL( clicked() ), this, SLOT( clear_CreateSnort() ) );
    connect( pushButton32, SIGNAL( clicked() ), this, SLOT( createSnortRule() ) );
    connect( UnselectRuleButton, SIGNAL( clicked() ), this, SLOT( removeRule() ) );
    connect( SelectRuleButton, SIGNAL( clicked() ), this, SLOT( selectRule() ) );
    connect( RuleCancleButton, SIGNAL( clicked() ), this, SLOT( clearRule() ) );
    connect( RuleOkButton, SIGNAL( clicked() ), this, SLOT( applyRule() ) );
    connect( h1StartButton, SIGNAL( clicked() ), this, SLOT( starth1() ) );
    connect( h1StopButton, SIGNAL( clicked() ), this, SLOT( stoph1() ) );
    connect( pushButton34_2, SIGNAL( clicked() ), this, SLOT( update_snort() ) );
    connect( cage2StartButton, SIGNAL( clicked() ), this, SLOT( startcage2() ) );
    connect( cage3StartButton, SIGNAL( clicked() ), this, SLOT( startcage3() ) );
    connect( cage2SuspendButton, SIGNAL( clicked() ), this, SLOT( suspendcage2() ) );
    connect( cage3SuspendButton, SIGNAL( clicked() ), this, SLOT( suspendcage3() ) );
    connect( cage1SuspendButton, SIGNAL( clicked() ), this, SLOT( suspendcage1() ) );
    connect( cage1StartButton, SIGNAL( clicked() ), this, SLOT( startcage1() ) );

    // tab order
    setTabOrder( tabPage, h1StartButton );
    setTabOrder( h1StartButton, h1StopButton );
    setTabOrder( h1StopButton, snorthost_combo );
    setTabOrder( snorthost_combo, pushButton34_2 );
    setTabOrder( pushButton34_2, cage1StartButton );
    setTabOrder( cage1StartButton, cage1SuspendButton );
    setTabOrder( cage1SuspendButton, cage2StartButton );
    setTabOrder( cage2StartButton, cage2SuspendButton );
    setTabOrder( cage2SuspendButton, cage3StartButton );
    setTabOrder( cage3StartButton, cage3SuspendButton );
    setTabOrder( cage3SuspendButton, RuleChoiceListbox );
    setTabOrder( RuleChoiceListbox, selectRuleListbox );
    setTabOrder( selectRuleListbox, SelectRuleButton );
    setTabOrder( SelectRuleButton, UnselectRuleButton );
    setTabOrder( UnselectRuleButton, RuleOkButton );
    setTabOrder( RuleOkButton, RuleCancleButton );
    setTabOrder( RuleCancleButton, Cname_edit );
    setTabOrder( Cname_edit, Csource_edit );
    setTabOrder( Csource_edit, Cdest_edit );
    setTabOrder( Cdest_edit, Csport_edit );
    setTabOrder( Csport_edit, Cdport_edit );
    setTabOrder( Cdport_edit, Caction_combo );
    setTabOrder( Caction_combo, Cprotocol_combo );
    setTabOrder( Cprotocol_combo, Cdirection_combo );
    setTabOrder( Cdirection_combo, Cmessage_edit );
    setTabOrder( Cmessage_edit, Ccontent_edit );
    setTabOrder( Ccontent_edit, Cpriority_edit );
    setTabOrder( Cpriority_edit, Cclasstype_edit );
    setTabOrder( Cclasstype_edit, Crev_edit );
    setTabOrder( Crev_edit, Csid_edit );
    setTabOrder( Csid_edit, checkBox17 );
    setTabOrder( checkBox17, checkBox17_2 );
    setTabOrder( checkBox17_2, Cflow_combo );
    setTabOrder( Cflow_combo, nameCage );
    setTabOrder( nameCage, ipCage );
    setTabOrder( ipCage, pathCage );
    setTabOrder( pathCage, hostnamecomboBox );
    setTabOrder( hostnamecomboBox, PushButtonFirst );
    setTabOrder( PushButtonFirst, PushButtonPrev );
    setTabOrder( PushButtonPrev, PushButtonNext );
    setTabOrder( PushButtonNext, PushButtonLast );
    setTabOrder( PushButtonLast, PushButtonClear );
    setTabOrder( PushButtonClear, PushButtonInsert );
    setTabOrder( PushButtonInsert, PushButtonDelete );
    setTabOrder( PushButtonDelete, numCheck );
    setTabOrder( numCheck, numUser );
    setTabOrder( numUser, groupCheck );
    setTabOrder( groupCheck, groupRoot );
    setTabOrder( groupRoot, ownCheck );
    setTabOrder( ownCheck, ownerPass );
    setTabOrder( ownerPass, passCheck );
    setTabOrder( passCheck, passCh );
    setTabOrder( passCh, modeCheck );
    setTabOrder( modeCheck, modePass );
    setTabOrder( modePass, saveConfigButton );
    setTabOrder( saveConfigButton, resetConfigButton );
    setTabOrder( resetConfigButton, cageTable );
    setTabOrder( cageTable, LogcomboBox );
    setTabOrder( LogcomboBox, LogcomboBox2 );
    setTabOrder( LogcomboBox2, samhainLogTable );
    setTabOrder( samhainLogTable, command_checkBox1 );
    setTabOrder( command_checkBox1, command_checkBox2 );
    setTabOrder( command_checkBox2, command_checkBox3 );
    setTabOrder( command_checkBox3, command_lineEdit1 );
    setTabOrder( command_lineEdit1, command_lineEdit2 );
    setTabOrder( command_lineEdit2, command_lineEdit3 );
    setTabOrder( command_lineEdit3, sebekFind );
    setTabOrder( sebekFind, sebekLogTable );
    setTabOrder( sebekLogTable, snortLogTable );
    setTabOrder( snortLogTable, path_checkBox );
    setTabOrder( path_checkBox, owner_old_checkBox );
    setTabOrder( owner_old_checkBox, owner_new_checkBox );
    setTabOrder( owner_new_checkBox, path_lineEdit );
    setTabOrder( path_lineEdit, owner_old_lineEdit );
    setTabOrder( owner_old_lineEdit, owner_new_lineEdit );
    setTabOrder( owner_new_lineEdit, samhainFind );
    setTabOrder( samhainFind, ip_src_checkBox );
    setTabOrder( ip_src_checkBox, ip_dst_checkBox );
    setTabOrder( ip_dst_checkBox, sig_name_checkBox );
    setTabOrder( sig_name_checkBox, ip_src_lineEdit );
    setTabOrder( ip_src_lineEdit, ip_dst_lineEdit );
    setTabOrder( ip_dst_lineEdit, sig_lineEdit );
    setTabOrder( sig_lineEdit, snortFind );
    setTabOrder( snortFind, pushButton32 );
    setTabOrder( pushButton32, pushButton32_2 );

    // buddies
    Label_sadd_2_3->setBuddy( ipCage );
    Label_sadd_2_2_2_3->setBuddy( ipCage );
    Label_sadd_3_2_3_2_2_2->setBuddy( ipCage );
    Label_sadd_3_2_3_2->setBuddy( ipCage );
    Label_sadd_3_2_3_2_2->setBuddy( ipCage );
    Label_sadd_4->setBuddy( ipCage );
    Label_sadd_3_2_3->setBuddy( ipCage );
    Label_sadd_2_3_2->setBuddy( ipCage );
    Label_sadd_2_3_2_2->setBuddy( ipCage );
    textLabel1->setBuddy( nameCage );
    textLabel2->setBuddy( pathCage );
    textLabel3->setBuddy( ipCage );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
HoneywallMM::~HoneywallMM()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void HoneywallMM::languageChange()
{
    setCaption( tr( "Tartarus Management  v2.0" ) );
    configPushButton->setText( QString::null );
    QToolTip::add( configPushButton, tr( "Configuration" ) );
    refreshPushButton->setText( QString::null );
    QToolTip::add( refreshPushButton, tr( "Refresh" ) );
    aboutPushButton->setText( QString::null );
    QToolTip::add( aboutPushButton, tr( "About" ) );
    h1StopButton->setText( tr( "Stop" ) );
    textLabel16->setText( tr( "<b><p align=\"center\"><i>Location</i></p></b>" ) );
    textLabel12->setText( tr( "<b><p align=\"center\"><i>Status</i></p></b>" ) );
    textLabel13->setText( tr( "<b><p align=\"center\"><i>Hostname</i></p></b>" ) );
    hostnameLabel->setText( tr( "Firescreen_01" ) );
    textLabel15_3->setText( tr( "<p align=\"center\"><font size=\"-1\">Internet<font size=\"-1\"></font></font></p>" ) );
    h1Status->setText( tr( "Active" ) );
    h1StartButton->setText( tr( "Start" ) );
    textLabel17_3->setText( tr( "<font size=\"+1\"><font size=\"+1\"><b><p align=\"center\">Update Snort</p></b></font></font>" ) );
    cage1SuspendButton->setText( tr( "Suspend" ) );
    cage3SuspendButton->setText( tr( "Suspend" ) );
    cage2SuspendButton->setText( tr( "Suspend" ) );
    cage3StartButton->setText( tr( "Start" ) );
    cage2StartButton->setText( tr( "Start" ) );
    cage3Status->setText( QString::null );
    cage2Status->setText( QString::null );
    nameCage3->setText( QString::null );
    hostNametextLabel1->setText( QString::null );
    cage1Status->setText( QString::null );
    nameCage2->setText( QString::null );
    hostNametextLabel3->setText( QString::null );
    hostNametextLabel2->setText( QString::null );
    nameCage1->setText( QString::null );
    textLabel12_3->setText( tr( "<b><p align=\"center\"><i>State</i></p></b>" ) );
    textLabel13_3_2->setText( tr( "<b><p align=\"center\"><i>Name</i></p></b>" ) );
    textLabel13_3->setText( tr( "<b><p align=\"center\"><i>Type</i></p></b>" ) );
    cage1StartButton->setText( tr( "Start" ) );
    cage1StartButton->setAccel( QKeySequence( QString::null ) );
    textLabel17->setText( tr( "<font size=\"+1\"><font size=\"+1\"><b><p align=\"center\">FireTrap</p></b></font></font>" ) );
    textLabel17_2->setText( tr( "<p align=\"center\">FireScreen Status</p>" ) );
    textLabel1_6->setText( tr( "<b><p align=\"center\">Snort's Host</p></b>" ) );
    snorthost_combo->clear();
    snorthost_combo->insertItem( tr( "FireScreen" ) );
    snorthost_combo->insertItem( tr( "FireBreak" ) );
    display_update->setText( tr( "<p align=\"center\">:: Update Signature ::</p>" ) );
    pushButton34_2->setText( QString::null );
    QToolTip::add( pushButton34_2, tr( "Update Snort's Rules" ) );
    tabPage->changeTab( statusPage, tr( "&Status" ) );
    textLabel2_4->setText( tr( "Selected" ) );
    RuleOkButton->setText( tr( "Apply" ) );
    RuleCancleButton->setText( tr( "Clear" ) );
    SelectRuleButton->setText( QString::null );
    UnselectRuleButton->setText( QString::null );
    textLabel1_3->setText( tr( "Avaliable" ) );
    tabPage->changeTab( rulePage, tr( "S&nort" ) );
    Label_Firescreen_2->setText( tr( "Create Snort_inline's Rule" ) );
    buttonGroup2->setTitle( tr( "Rules Headers" ) );
    Label_sadd_2_3->setText( tr( "Destination           :" ) );
    Label_sadd_2_2_2_3->setText( tr( "Destination Port   :" ) );
    Label_sadd_3_2_3_2_2_2->setText( tr( "Direction" ) );
    Label_sadd_3_2_3_2->setText( tr( "Action" ) );
    Caction_combo->clear();
    Caction_combo->insertItem( tr( "alert" ) );
    Caction_combo->insertItem( tr( "log" ) );
    Caction_combo->insertItem( tr( "pass" ) );
    Caction_combo->insertItem( tr( "drop" ) );
    Caction_combo->insertItem( tr( "sdrop" ) );
    Caction_combo->insertItem( tr( "reject" ) );
    Caction_combo->insertItem( tr( "activate" ) );
    Caction_combo->insertItem( tr( "dynamic" ) );
    Label_sadd_3_2_3_2_2->setText( tr( "Protocol" ) );
    Cprotocol_combo->clear();
    Cprotocol_combo->insertItem( tr( "tcp" ) );
    Cprotocol_combo->insertItem( tr( "udp" ) );
    Cprotocol_combo->insertItem( tr( "icmp" ) );
    Cprotocol_combo->insertItem( tr( "ip" ) );
    Cprotocol_combo->insertItem( tr( "any" ) );
    Cdirection_combo->clear();
    Cdirection_combo->insertItem( tr( "->" ) );
    Cdirection_combo->insertItem( tr( "<>" ) );
    Label_sadd_4->setText( tr( "Source            :" ) );
    Label_sadd_3_2_3->setText( tr( "Source Port    :" ) );
    QWhatsThis::add( Cdport_edit, tr( "you can edit cage's ip here" ) );
    QWhatsThis::add( Csource_edit, QString::null );
    QWhatsThis::add( Cdest_edit, QString::null );
    QWhatsThis::add( Csport_edit, tr( "you can edit cage's ip here" ) );
    Label_sadd_2_3_2->setText( tr( "Rule's name" ) );
    Label_sadd_2_3_2_2->setText( tr( "Snort's host" ) );
    pushButton32_2->setText( QString::null );
    groupBox24->setTitle( tr( "Rules Options" ) );
    textLabel1_5->setText( tr( "message" ) );
    checkBox17_2->setText( tr( "rowbyte" ) );
    Cflow_combo->clear();
    Cflow_combo->insertItem( tr( "established" ) );
    Cflow_combo->insertItem( tr( "to_client" ) );
    Cflow_combo->insertItem( tr( "to_server" ) );
    Cflow_combo->insertItem( tr( "from_client" ) );
    Cflow_combo->insertItem( tr( "from_server" ) );
    Cflow_combo->insertItem( tr( "stateless" ) );
    Cflow_combo->insertItem( tr( "no_stream" ) );
    Cflow_combo->insertItem( tr( "only_stream" ) );
    textLabel1_5_2->setText( tr( "content" ) );
    textLabel1_5_3_2->setText( tr( "snort id" ) );
    textLabel1_5_3_2_2_2->setText( tr( "priority" ) );
    textLabel1_5_3_2_2->setText( tr( "classtype" ) );
    checkBox17->setText( tr( "nocase" ) );
    textLabel1_5_3_2_2_2_2->setText( tr( "flow" ) );
    textLabel1_5_3_2_3->setText( tr( "revision" ) );
    pushButton32->setText( QString::null );
    host_combo->clear();
    host_combo->insertItem( tr( "firescreen" ) );
    host_combo->insertItem( tr( "firebreak" ) );
    tabPage->changeTab( TabPage, tr( "Snort &Rule" ) );
    numCheck->setText( tr( "&Number of Limt Users" ) );
    numCheck->setAccel( QKeySequence( tr( "Alt+N" ) ) );
    groupCheck->setText( tr( "Number User of &Group \"root\"" ) );
    groupCheck->setAccel( QKeySequence( tr( "Alt+G" ) ) );
    ownCheck->setText( tr( "&Owner of file \"/etc/passwd\"" ) );
    ownCheck->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    passCheck->setText( tr( "&Password root changed" ) );
    passCheck->setAccel( QKeySequence( tr( "Alt+P" ) ) );
    modeCheck->setText( tr( "&Mode of file \"/etc/passwd\"" ) );
    modeCheck->setAccel( QKeySequence( tr( "Alt+M" ) ) );
    ownerPass->setText( tr( "root" ) );
    passCh->clear();
    passCh->insertItem( tr( "Yes" ) );
    passCh->insertItem( tr( "No" ) );
    modePass->clear();
    modePass->insertItem( tr( "-rw-r--r--" ) );
    saveConfigButton->setText( tr( "Save" ) );
    resetConfigButton->setText( tr( "Reset" ) );
    textLabel5->setText( tr( "Cage Configuration" ) );
    textLabel1->setText( tr( "Name" ) );
    textLabel2->setText( tr( "Path" ) );
    textLabel3->setText( tr( "IP" ) );
    textLabel4->setText( tr( "Hostname" ) );
    PushButtonDelete->setText( tr( "Delete Cage" ) );
    hostnamecomboBox->clear();
    hostnamecomboBox->insertItem( tr( "WWW" ) );
    hostnamecomboBox->insertItem( tr( "FTP" ) );
    QWhatsThis::add( ipCage, tr( "you can edit cage's ip here" ) );
    textLabel6->setText( tr( "<p align=\"center\">Cage Information</p>" ) );
    PushButtonLast->setText( tr( "Last" ) );
    PushButtonFirst->setText( tr( "First" ) );
    PushButtonNext->setText( tr( "Next" ) );
    PushButtonPrev->setText( tr( "Previous" ) );
    PushButtonClear->setText( tr( "Clear" ) );
    PushButtonInsert->setText( tr( "Add Cage" ) );
    tabPage->changeTab( managePage, tr( "Cage &Management" ) );
    cageTable->horizontalHeader()->setLabel( 0, tr( "Name" ) );
    cageTable->horizontalHeader()->setLabel( 1, tr( "IP" ) );
    cageTable->horizontalHeader()->setLabel( 2, tr( "Path" ) );
    cageTable->horizontalHeader()->setLabel( 3, tr( "Hostname" ) );
    cageTable->horizontalHeader()->setLabel( 4, tr( "State" ) );
    cageTable->horizontalHeader()->setLabel( 5, tr( "Current User" ) );
    cageTable->horizontalHeader()->setLabel( 6, tr( "Limit User" ) );
    cageTable->horizontalHeader()->setLabel( 7, tr( "User of group root" ) );
    cageTable->horizontalHeader()->setLabel( 8, tr( "Limit of group root" ) );
    textLabel1_2->setText( tr( "Cage Information" ) );
    tabPage->changeTab( controlPage, tr( "Cage &Information" ) );
    textLabel3_2->setText( tr( "Records" ) );
    LogcomboBox2->clear();
    LogcomboBox2->insertItem( tr( "50" ) );
    LogcomboBox2->insertItem( tr( "100" ) );
    textLabel2_3->setText( tr( "Show" ) );
    snort_inline_log->setTitle( tr( "Snort Events" ) );
    ip_src_checkBox->setText( tr( "Souce IP" ) );
    ip_dst_checkBox->setText( tr( "Destination IP" ) );
    sig_name_checkBox->setText( tr( "Signature name" ) );
    snortFind->setText( tr( "Filter" ) );
    snortLogTable->horizontalHeader()->setLabel( 0, tr( "time" ) );
    snortLogTable->horizontalHeader()->setLabel( 1, tr( "sid" ) );
    snortLogTable->horizontalHeader()->setLabel( 2, tr( "cid" ) );
    snortLogTable->horizontalHeader()->setLabel( 3, tr( "signature" ) );
    snortLogTable->horizontalHeader()->setLabel( 4, tr( "sig_name" ) );
    snortLogTable->horizontalHeader()->setLabel( 5, tr( "sig_class_id" ) );
    snortLogTable->horizontalHeader()->setLabel( 6, tr( "sig_priority" ) );
    snortLogTable->horizontalHeader()->setLabel( 7, tr( "ip_src" ) );
    snortLogTable->horizontalHeader()->setLabel( 8, tr( "ip_dst" ) );
    snortLogTable->horizontalHeader()->setLabel( 9, tr( "sport" ) );
    snortLogTable->horizontalHeader()->setLabel( 10, tr( "dport" ) );
    samhain_log->setTitle( tr( "Samhain Events" ) );
    path_checkBox->setText( tr( "Path" ) );
    owner_old_checkBox->setText( tr( "Owner_old" ) );
    owner_new_checkBox->setText( tr( "Owner_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 0, tr( "time" ) );
    samhainLogTable->horizontalHeader()->setLabel( 1, tr( "host" ) );
    samhainLogTable->horizontalHeader()->setLabel( 2, tr( "messege" ) );
    samhainLogTable->horizontalHeader()->setLabel( 3, tr( "path" ) );
    samhainLogTable->horizontalHeader()->setLabel( 4, tr( "mode_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 5, tr( "mode_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 6, tr( "owner_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 7, tr( "owner_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 8, tr( "group_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 9, tr( "group_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 10, tr( "ctime_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 11, tr( "ctime_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 12, tr( "link_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 13, tr( "link_new" ) );
    samhainLogTable->horizontalHeader()->setLabel( 14, tr( "hardlink_old" ) );
    samhainLogTable->horizontalHeader()->setLabel( 15, tr( "hardlink_new" ) );
    samhainFind->setText( tr( "Filter" ) );
    sebek_log->setTitle( tr( "Sebek Events" ) );
    command_checkBox1->setText( tr( "IP address" ) );
    command_checkBox2->setText( tr( "Command1" ) );
    command_checkBox3->setText( tr( "Command2" ) );
    sebekLogTable->horizontalHeader()->setLabel( 0, tr( "ip_addr" ) );
    sebekLogTable->horizontalHeader()->setLabel( 1, tr( "insert_time" ) );
    sebekLogTable->horizontalHeader()->setLabel( 2, tr( "command" ) );
    sebekLogTable->horizontalHeader()->setLabel( 3, tr( "counter" ) );
    sebekLogTable->horizontalHeader()->setLabel( 4, tr( "filed" ) );
    sebekLogTable->horizontalHeader()->setLabel( 5, tr( "pid" ) );
    sebekLogTable->horizontalHeader()->setLabel( 6, tr( "uid" ) );
    sebekLogTable->horizontalHeader()->setLabel( 7, tr( "length" ) );
    sebekFind->setText( tr( "Filter" ) );
    LogcomboBox->clear();
    LogcomboBox->insertItem( tr( "Snort Logging" ) );
    LogcomboBox->insertItem( tr( "Samhain Logging" ) );
    LogcomboBox->insertItem( tr( "Sebek Logging" ) );
    tabPage->changeTab( eventPage, tr( "&Logging" ) );
    snort_inline_log_2->setTitle( tr( "Snort Events" ) );
    firebreakTable->horizontalHeader()->setLabel( 0, tr( "time" ) );
    firebreakTable->horizontalHeader()->setLabel( 1, tr( "sid" ) );
    firebreakTable->horizontalHeader()->setLabel( 2, tr( "sig_name" ) );
    firebreakTable->horizontalHeader()->setLabel( 3, tr( "sig_priority" ) );
    firebreakTable->horizontalHeader()->setLabel( 4, tr( "ip_src" ) );
    firebreakTable->horizontalHeader()->setLabel( 5, tr( "ip_dst" ) );
    textLabel1_2_2->setText( tr( "Logging From FireBreak intrusion" ) );
    tabPage->changeTab( TabPage_2, tr( "Log Fire&break" ) );
}

