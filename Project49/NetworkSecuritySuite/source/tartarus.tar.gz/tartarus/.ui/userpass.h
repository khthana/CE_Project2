/****************************************************************************
** Form interface generated from reading ui file 'userpass.ui'
**
** Created: Sun Jan 14 06:52:37 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef USERPASS_H
#define USERPASS_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QPushButton;

class UserPass : public QDialog
{
    Q_OBJECT

public:
    UserPass( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UserPass();

    QLabel* pixmapLabel1;
    QLineEdit* userEdit;
    QLineEdit* passEdit;
    QLabel* textLabel1;
    QLabel* textLabel2;
    QPushButton* loginButton;
    QPushButton* cancleLogin;

    int getFlag();

public slots:
    virtual void dataChange();
    virtual void chkUser();
    virtual void cancelLogin();

protected:

protected slots:
    virtual void languageChange();

private:
    int flag;

    void init();

};

#endif // USERPASS_H
