/****************************************************************************
** Form interface generated from reading ui file 'honeywallmm.ui'
**
** Created: Sun Feb 11 04:01:16 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef HONEYWALLMM_H
#define HONEYWALLMM_H

#include <qvariant.h>
#include <qdialog.h>
#include "wizardform.h"
#include "aboutdialog.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QFrame;
class QPushButton;
class QTabWidget;
class QWidget;
class QComboBox;
class QListBox;
class QListBoxItem;
class QButtonGroup;
class QLineEdit;
class QGroupBox;
class QCheckBox;
class QSpinBox;
class QTable;

class HoneywallMM : public QDialog
{
    Q_OBJECT

public:
    HoneywallMM( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~HoneywallMM();

    QLabel* pixmapLabel1_2;
    QFrame* frame9;
    QPushButton* configPushButton;
    QFrame* frame9_2;
    QPushButton* refreshPushButton;
    QFrame* frame8_3;
    QPushButton* aboutPushButton;
    QTabWidget* tabPage;
    QWidget* statusPage;
    QLabel* pixmapLabel1;
    QLabel* pixmapLabel2_2;
    QLabel* pixmapLabel2;
    QFrame* frame18;
    QPushButton* h1StopButton;
    QLabel* textLabel16;
    QLabel* textLabel12;
    QLabel* textLabel13;
    QLabel* hostnameLabel;
    QLabel* textLabel15_3;
    QLabel* h1Status;
    QPushButton* h1StartButton;
    QLabel* textLabel17_3;
    QFrame* frame20;
    QPushButton* cage1SuspendButton;
    QPushButton* cage3SuspendButton;
    QPushButton* cage2SuspendButton;
    QPushButton* cage3StartButton;
    QPushButton* cage2StartButton;
    QLabel* cage3Status;
    QLabel* cage2Status;
    QLabel* nameCage3;
    QLabel* hostNametextLabel1;
    QLabel* cage1Status;
    QLabel* nameCage2;
    QLabel* hostNametextLabel3;
    QLabel* hostNametextLabel2;
    QLabel* nameCage1;
    QLabel* textLabel12_3;
    QLabel* textLabel13_3_2;
    QLabel* textLabel13_3;
    QPushButton* cage1StartButton;
    QLabel* textLabel17;
    QLabel* textLabel17_2;
    QFrame* frame13;
    QLabel* textLabel1_6;
    QComboBox* snorthost_combo;
    QLabel* display_update;
    QPushButton* pushButton34_2;
    QWidget* rulePage;
    QLabel* textLabel2_4;
    QPushButton* RuleOkButton;
    QPushButton* RuleCancleButton;
    QPushButton* SelectRuleButton;
    QPushButton* UnselectRuleButton;
    QListBox* selectRuleListbox;
    QLabel* textLabel1_3;
    QListBox* RuleChoiceListbox;
    QWidget* TabPage;
    QLabel* Label_Firescreen_2;
    QButtonGroup* buttonGroup2;
    QLabel* Label_sadd_2_3;
    QLabel* Label_sadd_2_2_2_3;
    QLabel* Label_sadd_3_2_3_2_2_2;
    QLabel* Label_sadd_3_2_3_2;
    QComboBox* Caction_combo;
    QLabel* Label_sadd_3_2_3_2_2;
    QComboBox* Cprotocol_combo;
    QComboBox* Cdirection_combo;
    QLabel* Label_sadd_4;
    QLabel* Label_sadd_3_2_3;
    QLineEdit* Cdport_edit;
    QLineEdit* Csource_edit;
    QLineEdit* Cdest_edit;
    QLineEdit* Csport_edit;
    QLabel* Label_sadd_2_3_2;
    QLineEdit* Cname_edit;
    QLabel* Label_sadd_2_3_2_2;
    QPushButton* pushButton32_2;
    QGroupBox* groupBox24;
    QLabel* textLabel1_5;
    QCheckBox* checkBox17_2;
    QComboBox* Cflow_combo;
    QLabel* textLabel1_5_2;
    QLineEdit* Cmessage_edit;
    QLineEdit* Csid_edit;
    QLabel* textLabel1_5_3_2;
    QLabel* textLabel1_5_3_2_2_2;
    QLineEdit* Cpriority_edit;
    QLineEdit* Crev_edit;
    QLabel* textLabel1_5_3_2_2;
    QCheckBox* checkBox17;
    QLabel* textLabel1_5_3_2_2_2_2;
    QLabel* textLabel1_5_3_2_3;
    QLineEdit* Ccontent_edit;
    QLineEdit* Cclasstype_edit;
    QPushButton* pushButton32;
    QComboBox* host_combo;
    QWidget* managePage;
    QFrame* frame4;
    QCheckBox* numCheck;
    QCheckBox* groupCheck;
    QCheckBox* ownCheck;
    QCheckBox* passCheck;
    QCheckBox* modeCheck;
    QSpinBox* numUser;
    QSpinBox* groupRoot;
    QLineEdit* ownerPass;
    QComboBox* passCh;
    QComboBox* modePass;
    QPushButton* saveConfigButton;
    QPushButton* resetConfigButton;
    QLabel* textLabel5;
    QFrame* frame24;
    QLabel* textLabel1;
    QLabel* textLabel2;
    QLabel* textLabel3;
    QLabel* textLabel4;
    QLineEdit* pathCage;
    QPushButton* PushButtonDelete;
    QComboBox* hostnamecomboBox;
    QLineEdit* ipCage;
    QLabel* textLabel6;
    QPushButton* PushButtonLast;
    QPushButton* PushButtonFirst;
    QPushButton* PushButtonNext;
    QPushButton* PushButtonPrev;
    QLineEdit* nameCage;
    QPushButton* PushButtonClear;
    QPushButton* PushButtonInsert;
    QWidget* controlPage;
    QTable* cageTable;
    QLabel* textLabel1_2;
    QWidget* eventPage;
    QLabel* textLabel3_2;
    QComboBox* LogcomboBox2;
    QLabel* textLabel2_3;
    QGroupBox* snort_inline_log;
    QCheckBox* ip_src_checkBox;
    QLineEdit* ip_src_lineEdit;
    QCheckBox* ip_dst_checkBox;
    QLineEdit* ip_dst_lineEdit;
    QCheckBox* sig_name_checkBox;
    QLineEdit* sig_lineEdit;
    QPushButton* snortFind;
    QTable* snortLogTable;
    QGroupBox* samhain_log;
    QCheckBox* path_checkBox;
    QLineEdit* path_lineEdit;
    QCheckBox* owner_old_checkBox;
    QLineEdit* owner_old_lineEdit;
    QCheckBox* owner_new_checkBox;
    QLineEdit* owner_new_lineEdit;
    QTable* samhainLogTable;
    QPushButton* samhainFind;
    QGroupBox* sebek_log;
    QCheckBox* command_checkBox1;
    QLineEdit* command_lineEdit1;
    QCheckBox* command_checkBox2;
    QLineEdit* command_lineEdit2;
    QCheckBox* command_checkBox3;
    QLineEdit* command_lineEdit3;
    QTable* sebekLogTable;
    QPushButton* sebekFind;
    QComboBox* LogcomboBox;
    QWidget* TabPage_2;
    QGroupBox* snort_inline_log_2;
    QTable* firebreakTable;
    QLabel* textLabel1_2_2;

public slots:
    virtual void startcage1();
    virtual void suspendcage1();
    virtual void startcage2();
    virtual void suspendcage2();
    virtual void startcage3();
    virtual void suspendcage3();
    virtual void starth1();
    virtual void stoph1();
    virtual void dataChange();
    virtual void copyVmware();
    virtual void regisCage();
    virtual void delCage();
    virtual void createCageConfig();
    virtual void applyRule();
    virtual void clearRule();
    virtual void selectRule();
    virtual void removeRule();
    virtual void showLog();
    virtual void showCageInformation();
    virtual void showCageTable();
    virtual void querySnortDB( QString sqlcmd );
    virtual void querySamhainDB( QString sqlcmd );
    virtual void querySebekDB( QString sqlcmd );
    virtual void queryCageDB( QString sqlcmd );
    virtual void checkButton();
    virtual void chageCageState();
    virtual void configTartarus();
    virtual void about();
    virtual void refresh();
    virtual void createSnortRule();
    virtual void clear_CreateSnort();
    virtual void update_snort();
    virtual void showLogFirebreak();

protected:
    QVBoxLayout* layout28;
    QGridLayout* layout27;
    QGridLayout* layout26;
    QGridLayout* layout25;
    QVBoxLayout* layout62;
    QSpacerItem* spacer26_2;
    QVBoxLayout* layout47;
    QVBoxLayout* layout66;
    QSpacerItem* spacer29;
    QSpacerItem* spacer27_2;
    QSpacerItem* spacer30;
    QVBoxLayout* layout48;
    QGridLayout* frame4Layout;
    QHBoxLayout* layout21;
    QVBoxLayout* layout19;
    QVBoxLayout* layout20;
    QVBoxLayout* layout279;
    QGridLayout* layout31_2;
    QHBoxLayout* layout50_2;
    QHBoxLayout* layout19_3;
    QVBoxLayout* layout14_2;
    QVBoxLayout* layout15_2;
    QVBoxLayout* layout16_2;
    QVBoxLayout* layout17_3;
    QGridLayout* layout32_3;
    QHBoxLayout* layout38_3;
    QVBoxLayout* layout36_4;
    QVBoxLayout* layout35_4;
    QVBoxLayout* layout34_4;
    QHBoxLayout* layout38_2_2;
    QVBoxLayout* layout36_2_2;
    QVBoxLayout* layout35_2_2;
    QVBoxLayout* layout34_2_2;

protected slots:
    virtual void languageChange();

private:
    void init();
    void destroy();

};

#endif // HONEYWALLMM_H
