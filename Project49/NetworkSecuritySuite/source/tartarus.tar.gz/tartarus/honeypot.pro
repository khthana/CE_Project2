TEMPLATE	= app
LANGUAGE	= C++

CONFIG	+= qt warn_on release

HEADERS	+= connectdatabase.h

SOURCES	+= main.cpp

FORMS	= honeywallmm.ui \
	userpass.ui \
	wizardform.ui \
	aboutdialog.ui

IMAGES	= images/encrypted.png \
	images/find.png \
	images/kcontrol.png \
	images/window_list.png \
	images/package_settings.png \
	images/kfloppy.png \
	images/windows_users.png \
	images/forward.png \
	images/next-sail.png \
	images/previos-sail.png \
	images/xmag.png \
	images/reload.png \
	images/configure.png \
	images/agent.png \
	images/cache.png \
	images/button_cance.png \
	images/sisadmin.png \
	images/kcmsystem.png \
	images/agt_update_drivers.png \
	images/button_ok.png \
	images/button_cancel.png \
	images/up.png \
	images/button_check.png \
	images/main.png \
	images/down.png \
	images/rotate.png \
	images/reload2.png \
	images/netscape.png \
	images/tm.png

DBFILE	= honeypot.db
unix {
  UI_DIR = .ui
  MOC_DIR = .moc
  OBJECTS_DIR = .obj
}




