#!/usr/bin/perl

use DBI;
use Term::ReadKey;
#=====================[define_variable]====================
$check_user = 0;
$check_group = 0;
$check_owner = 0;
$check_pass = 0;
$check_mode = 0;
$pass_old = `cat shadow_old | grep root |cut -d \':\' -f 2`;
chop($pass_old);
print("pass_old= ",$pass_old,"\n");
#=====================[define_DMZ]=====================
$ip_webserver = '172.16.144.129';
$ip_ftpserver = '172.16.144.130';

#=====================[define_snort]=====================
$host_snort = 'logserver';
$db_snort = 'snort';
$table_snort = 'acid_event';
$user_snort = 'snort';
$password_snort = 'honeypot';

#=====================[define_samhain]=====================
$host_samhain = 'logserver';
$db_samhain = 'samhain';
$table_samhain = 'log';
$user_samhain = 'samhain';
$password_samhain = 'honeypot';

#=====================[define_cage]=======================
$host_cage = 'logserver';
$db_cage = 'cage';
$table_cage = 'information';
$user_cage = 'cage';
$password_cage = 'honeypot';

#====================[define_s2i]=======================
$ipsrc;
$ipsrc_tmp="xxx.xxx.xxx.xxx";
$ipdst_tmp="xxx.xxx.xxx.xxx";
$ipdst;
$ipcage;
$dbh1;
$qip_dst;
$upcage;
$iptble=1;

#====================[do job check Integrity]========================
read_config();
open_dbi_samhain();
open_dbi_cage();
query_dbi_samhain();
query_dbi_cage();
check_cage();
close_dbi_samhain();
close_dbi_cage();

open_dbi_snort();
query_ipsrc();
$row = query_match($ipsrc,$ipdst);
close_dbi_snort();

if ($ipdst eq $ip_webserver)
{
	if ($row eq 2)
	#if (($row  1) && ($row lt 3))
	{
		$chostname = 'www';
		$addrule = 1;
		open_dbi_cage();
		$qip_dst = query_ipdst($chostname);
		setipcage($qip_dst);
		$upcage = update_cage();
		close_dbi_cage();
		addiptablesCMD($ipsrc,$ipcage);
	}
}

if ($ipdst eq $ip_ftpserver)
{
	if ($row eq 2)
	{
		$chostname = 'ftp';
		$addrule = 1;
		$dbh1 = open_dbi_cage();
		$qip_dst = query_ipdst($chostname);
		setipcage($qip_dst);
		$upcage = update_cage();
		close_dbi_cage($dbh1);
		addiptablesCMD($ipsrc,$ipcage);
	}
}
#==================[End Main Function]=======================

#=====================[read_config_file]=======================
sub read_config
{
	if(open(file, "./cage.conf"))
	{	
	#read line from file
		my $line = <file>;
		my $count = 0;
		#read line until end of file
		while($count lt 6)
		{
			$count++;
			chop($line);
			@word = split(/=/,$line);
			if($count eq 1)
			{
				$name = $word[1];
			}
			if($count eq 2)
			{
				$user_limit = $word[1];
				if($user_limit ne 0)
				{	
					$check_user = 1 ;
				}
			}
			if($count eq 3)
			{
				$group_limit = $word[1];
				if($group_limit ne 0)
				{	
					$check_owner = 1 ;
				}
			}
			if($count eq 4)
			{
				$owner = $word[1];
				if($owner ne "")
				{	
					$check_owner = 1 ;
				}
			}
			if($count eq 5)
			{
				if($word[1] eq "Yes")
				{
					$check_pass = 1;
				print("chk_pass = ",$check_pass,"\n");
				}
			}
			if($count eq 6)
			{
				$mode = $word[1];
				if($mode ne "")
				{	
					$check_mode = 1 ;
				}
			}		
			$line = <file>;
		}
	}
	else
	{
		print("cannot open file\n");
	}
}

#=====================[open_dbi_samhain]=======================
sub open_dbi_samhain
{
	$dbh_samhain = DBI->connect("dbi:mysql:$db_samhain:$host_samhain","$user_samhain","$password_samhain") or err_trap("Cannot connect to database");
	$drh_samhain = DBI->install_driver("mysql");
	@databases_samhain = DBI->data_sources("mysql");
	print("open samhain OK\n");
}
#=====================[query_dbi_samhain]======================
sub query_dbi_samhain
{
	$sth_samhain = $dbh_samhain->prepare("select * from $table_samhain where path like \'/etc/passwd%'");
	if(!$sth_samhain) 
	{
		die "Error:" . $dbh_samhain->errstr . "\n"
	}	
	if(!$sth_samhain->execute) 
	{
		die "Error:" . $sth_samhain->errstr . "\n";
	}
	print("query samhain OK\n");
}


#=======================[open_dbi_cage]=======================
sub open_dbi_cage
{
	$dbh_cage = DBI->connect("dbi:mysql:$db_cage:$host_cage","$user_cage","$password_cage") or err_trap("Cannot connect to database");
	$drh_cage = DBI->install_driver("mysql");
	@databases_cage = DBI->data_sources("mysql");
	print("open cage OK\n");
}
#=======================[query_dbi_cage]=====================
sub query_dbi_cage
{
	$sth_cage = $dbh_cage->prepare("select * from $table_cage where cname = \'$name\' ");
	if(!$sth_cage) 
	{
		die "Error:" . $dbh_cage->errstr . "\n"
	}
	if(!$sth_cage->execute) 
	{
		die "Error:" . $sth_cage->errstr . "\n";
	}

	$ref_cage = $sth_cage->fetchrow_hashref;
	$path = $ref_cage->{'cpath'}.'/cage/';
	$ip = $ref_cage->{'cip'};
	$cmd = 'ssh root@'.$ip.' cat /etc/shadow | grep root | cut -d \':\' -f 2';
	$pass_new = `$cmd`;
	chop($pass_new);
	#print("pass_new = ",$pass_new,"\n");
	$cmd2 = '`ssh root@'.$ip.' cat /etc/passwd | wc -l\`';
	#$user_current = `$cmd`;
	chop($user_current);
	$cmd3 = 'ssh root@'.$ip.' cat /etc/group | grep root | cut -d \':\' -f 4';
	#$group_current = `$cmd3`;
	#print("cmd3 = ",$cmd3,"\n");
}
#=====================[close_dbi_samhain]======================
sub close_dbi_samhain
{
	$sth_samhain->finish;
	$dbh_samhain->disconnect or err_trap("Cannot disconnect from the database");
}

#=====================[close_dbi_cage]======================
sub close_dbi_cage
{
	$sth_cage->finish;
	$dbh_cage->disconnect or err_trap("Cannot disconnect from the database");
}

#=====================[close_dbi_snort]======================
sub close_dbi_snort
{
 	$sth_snort->finish;
	$dbh_snort->disconnect or err_trap("Cannot disconnect from the database");
 
}#end: close_dbi 
#=====================[check_cage]==================
sub check_cage
{
	print("check_cage.......\n");
	print("chk_pass2 =",$check_pass,"\n");
	if($check_user)
	{
		if($user_current > $user_limit)
 		{
			#$cmd_start = 'vmware-cmd -q '
			query_new_cage();
			addiptablesCMD($ipsrc,$ipcage_chg);
 			$cmd_suspend = 'vmware-cmd -q '.$path.$name.'.vmx suspended hard &';
#  			`$cmd_suspend`;
		}
	}
	elsif($check_pass)
	{
		print("check_pass1.......\n");
		if($pass_old ne $pass_new)
 		{
			print("check_pass........\n");
			query_new_cage();
			$cmd_start = 'vmware-cmd -q '.$path_chg.$name_chg.'.vmx start&';
			print("start new cage = ",$cmd_start,"\n");
			addiptablesCMD($ipsrc,$ipcage_chg);
 			$cmd_suspend = 'vmware-cmd -q '.$path.$name.'.vmx suspended hard &';
			print("check pass = ",$cmd_suspend,"\n");
#  			`$cmd_suspend`;
		}
	}
	elsif($check_group)
	{
		
	}
	elsif($check_owner or $check_mode)
	{
		samhain_check();
	}
	print("check_cage OK\n");
}
#=====================[pattern_match]==================
sub samhain_check
{	
	$stop = 1;
	while(($ref_samhain = $sth_samhain->fetchrow_hashref) and $stop)
	{
		$ref_samhain = $sth_samhain->fetchrow_hashref;
		if($check_owner)
		{
  			if($ref_samhain->{'owner_new'} ne $ref_samhain->{'owner_old'})
 			{
 				$cmd = 'vmware-cmd -q '.$path.$name.'.vmx suspended hard &';
#  				`$cmd`;
				$stop = 0;
			}	
		}
		if($check_mode)
		{
			if($ref_samhain->{'mode_old'} ne "" or $ref_samhain->{'mode_new'} ne "")
			{
				if($ref_samhain->{'mode_new'} ne $ref_samhain->{'mode_old'})
				{	
					$cmd = 'vmware-cmd -q '.$path.$name.'.vmx suspended hard &';
 					#`$cmd`;
					$stop = 0;
				}
			}
		}
	}
}


#=====================[err_trap]=======================
sub err_trap
{
 	my $error_message = shift(@_);
 
 	die "$error_message\nERROR: $DBI::err ($DBI::errstr)\n";
}#end: err_trap

sub open_dbi_snort
{
 	$dbh_snort = DBI->connect("dbi:mysql:$db_snort:$host_snort","$user_snort","$password_snort") or err_trap("Cannot connect to database");
 	$drh = DBI->install_driver("mysql");
 	@databases = DBI->data_sources("mysql");
 	print("open snort OK\n");
}#end: open_dbi_snort


#################### Query DB #####################
sub query_ipsrc
{
	$table = 'acid_event';
 	$sth_snort = $dbh_snort->prepare("select inet_ntoa(ip_src) AS ip_src,inet_ntoa(ip_dst) AS ip_dst, timestamp from $table where sig_priority = '1' order by 'timestamp' DESC limit 1,1");

 	if(!$sth_snort) {
		die "Error:" . $dbh_snort->errstr . "\n"
 	}
	if(!$sth_snort->execute) {
		die "Error:" . $sth_snort->errstr . "\n";
 	}
	my $ref = $sth_snort->fetchrow_hashref;
	$ipsrc=$ref->{'ip_src'};
	$ipdst=$ref->{'ip_dst'};
		 
 	#return $sth_snort;
}

sub query_match
{
	$src = shift(@_);
	$dst = shift(@_);
	printf("%s\n",$src);
	printf("%s\n",$dst);
	$sth_snort = $dbh_snort->prepare("select distinct inet_ntoa(ip_src), inet_ntoa(ip_dst),timestamp from $table where inet_ntoa(ip_src)= \"$src\" and inet_ntoa(ip_dst) = \"$dst\" and sig_priority = '1' order by 'timestamp' DESC");
	$sth_snort->execute();
	$count = $sth_snort->rows();
	print "row = $count\n";
 	if(!$sth_snort) {
		die "Error:" . $dbh_snort->errstr . "\n"
 	}
	if(!$sth_snort->execute) {
		die "Error:" . $sth_snort->errstr . "\n";
 	}
	return $count;
}

sub query_ipdst
{
	my $host = shift(@_);
	my $table = 'information';
 	my $sth1 = $dbh1->prepare("select cip from $table where chostname = \`$host\' and cstate = 'stop' ");

	if(!$sth1) {
		die "Error:" . $dbh1->errstr . "\n"
	}
	if(!$sth1->execute) {
		die "Error:" . $sth1->errstr . "\n";
	}
 	my $ref = $sth1->fetchrow_hashref;
	$ipcage=$ref->{'cip'};
	printf("ipcage=%s\n",$ipcage);
}


sub update_cage 
{
	my $table = 'information';
 	my $sth2 = $dbh1->prepare("update `$table` set cstate = 'start' where cip = '$ipcage' ");

	if(!$sth2) {
		die "Error:" . $dbh1->errstr . "\n"
	}
	if(!$sth2->execute) {
		die "Error:" . $sth2->errstr . "\n";
	}
 	return $sth2;
}


##################### End Query #######################

sub addiptablesCMD
{
	my $src = shift(@_);
	my $dst = shift(@_);
	
	if ($chg_ip eq 1)
	{
	`iptables -F -t nat`;
	`iptables-restore < iptable.rule`;
	`iptables -t nat -A PREROUTING -s $src/32 -i eth1 -j DNAT --to-destination $dst`; 
	printf("NEW!! iptables -t nat -A PREROUTING -s %s/32 -i eth1 -j DNAT --to-destination %s\n",$src,$dst); 
 	}
	
	elsif ($addrule eq 1)
	{
	#Add iptables rule
	`iptables -t nat -A PREROUTING -s $src/32 -i eth1 -j DNAT --to-destination $dst`; 
	printf("iptables -t nat -A PREROUTING -s %s/32 -i eth1 -j DNAT --to-destination %s\n",$src,$dst); 
	}
}

sub query_new_cage
{
	my $sth_new_cage = $dbh_cage->prepare("select cip from $table where chostname = 'www' and cstate = 'stop' ");
	if(!$sth_new_cage) 
	{
		die "Error:" . $dbh_cage->errstr . "\n"
	}
	if(!$sth_cage->execute) 
	{
		die "Error:" . $sth_new_cage->errstr . "\n";
	}

	my $ref_cage = $sth_new_cage->fetchrow_hashref;
	$name_chg = $ref_cage->{'cname'};
	$path_chg = $ref_cage->{'cpath'}.'/cage/';
	$ipcage_chg = $ref_cage->{'cip'};
	$chg_ip = 1;
	printf("name chg = %s,path chg = %s,ipcage-chg = %s\n",$name_chg,$path_chg,$ipcage_chg);
}
