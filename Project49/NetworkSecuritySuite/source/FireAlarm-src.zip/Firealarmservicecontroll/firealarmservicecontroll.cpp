// firealarmservicecontroll.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "firealarmservicecontroll.h"

#include "Include/psapi.h"
#include "Include/winBase.h"
#include "Include/windows.h"
#include <process.h>
#include <windows.h>
#include <winbase.h>
#include <winsvc.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;


/////////////////////////////////////////////////
//////	Service Managment Function
const int nBufferSize = 500;
char pServiceName[nBufferSize+1];
char pExeFile[nBufferSize+1];
char pInitFile[nBufferSize+1];
char pLogFile[nBufferSize+1];
const int nMaxProcCount = 127;
PROCESS_INFORMATION pProcInfo[nMaxProcCount];


SERVICE_STATUS          serviceStatus; 
SERVICE_STATUS_HANDLE   hServiceStatusHandle; 

VOID WINAPI XYNTServiceMain( DWORD dwArgc, LPTSTR *lpszArgv );
VOID WINAPI XYNTServiceHandler( DWORD fdwControl );

CRITICAL_SECTION myCS;

void WriteLog(char* pMsg)
{
	// write error or other information into log file
	::EnterCriticalSection(&myCS);
	try
	{
		SYSTEMTIME oT;
		::GetLocalTime(&oT);
		FILE* pLog = fopen(pLogFile,"a");
		fprintf(pLog,"%02d/%02d/%04d, %02d:%02d:%02d\n    %s\n",oT.wMonth,oT.wDay,oT.wYear,oT.wHour,oT.wMinute,oT.wSecond,pMsg); 
		fclose(pLog);
	} catch(...) {}
	::LeaveCriticalSection(&myCS);
}

////////////////////////////////////////////////////////////////////// 
//
// Configuration Data and Tables
//

SERVICE_TABLE_ENTRY   DispatchTable[] = 
{ 
	{pServiceName, XYNTServiceMain}, 
	{NULL, NULL}
};


// helper functions

BOOL StartProcess(int nIndex) 
{ 
	// start a process with given index
	STARTUPINFO startUpInfo = { sizeof(STARTUPINFO),NULL,"",NULL,0,0,0,0,0,0,0,STARTF_USESHOWWINDOW,0,0,NULL,0,0,0};  
	char pItem[nBufferSize+1];
	sprintf(pItem,"Process%d\0",nIndex);
	char pCommandLine[nBufferSize+1];
	GetPrivateProfileString(pItem,"CommandLine","",pCommandLine,nBufferSize,pInitFile);
	if(strlen(pCommandLine)>4)
	{
		char pUserInterface[nBufferSize+1];
		GetPrivateProfileString(pItem,"UserInterface","N",pUserInterface,nBufferSize,pInitFile);
		BOOL bUserInterface = (pUserInterface[0]=='y'||pUserInterface[0]=='Y'||pUserInterface[0]=='1')?TRUE:FALSE;
		char CurrentDesktopName[512];
		// set the correct desktop for the process to be started
		if(bUserInterface)
		{
			startUpInfo.wShowWindow = SW_SHOW;
			startUpInfo.lpDesktop = NULL;
		}
		else
		{
			HDESK hCurrentDesktop = GetThreadDesktop(GetCurrentThreadId());
			DWORD len;
			GetUserObjectInformation(hCurrentDesktop,UOI_NAME,CurrentDesktopName,MAX_PATH,&len);
			startUpInfo.wShowWindow = SW_HIDE;
			startUpInfo.lpDesktop = CurrentDesktopName;
		}
		// create the process
		char pWorkingDir[nBufferSize+1];
		GetPrivateProfileString(pItem,"WorkingDir","",pWorkingDir,nBufferSize,pInitFile);
		if(CreateProcess(NULL,pCommandLine,NULL,NULL,TRUE,NORMAL_PRIORITY_CLASS,NULL,strlen(pWorkingDir)==0?NULL:pWorkingDir,&startUpInfo,&pProcInfo[nIndex]))
		{
			char pPause[nBufferSize+1];
			GetPrivateProfileString(pItem,"PauseStart","100",pPause,nBufferSize,pInitFile);
			Sleep(atoi(pPause));
			return TRUE;
		}
		else
		{
			long nError = GetLastError();
			char pTemp[121];
			sprintf(pTemp,"Failed to start program '%s', error code = %d", pCommandLine, nError); 
			WriteLog(pTemp);
			return FALSE;
		}
	}
	else return FALSE;
}

void EndProcess(int nIndex) 
{	
	// end a program started by the service
	if(pProcInfo[nIndex].hProcess)
	{
		char pItem[nBufferSize+1];
		sprintf(pItem,"Process%d\0",nIndex);
		char pPause[nBufferSize+1];
		GetPrivateProfileString(pItem,"PauseEnd","100",pPause,nBufferSize,pInitFile);
		int nPauseEnd = atoi(pPause);
		// post a WM_QUIT message first
		PostThreadMessage(pProcInfo[nIndex].dwThreadId,WM_QUIT,0,0);
		// sleep for a while so that the process has a chance to terminate itself
		::Sleep(nPauseEnd>0?nPauseEnd:50);
		// terminate the process by force
		TerminateProcess(pProcInfo[nIndex].hProcess,0);
		pProcInfo[nIndex].hProcess = 0;
	}
}

BOOL BounceProcess(char* pName, int nIndex) 
{ 
	// bounce the process with given index
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "OpenSCManager failed, error code = %d", nError);
		WriteLog(pTemp);
	}
	else
	{
		// open the service
		SC_HANDLE schService = OpenService( schSCManager, pName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			long nError = GetLastError();
			char pTemp[121];
			sprintf(pTemp, "OpenService failed, error code = %d", nError); 
			WriteLog(pTemp);
		}
		else
		{
			// call ControlService to invoke handler
			SERVICE_STATUS status;
			if(nIndex>=0&&nIndex<128)
			{
				if(ControlService(schService,(nIndex|0x80),&status))
				{
					CloseServiceHandle(schService); 
					CloseServiceHandle(schSCManager); 
					return TRUE;
				}
				long nError = GetLastError();
				char pTemp[121];
				sprintf(pTemp, "ControlService failed, error code = %d", nError); 
				WriteLog(pTemp);
			}
			else
			{
				char pTemp[121];
				sprintf(pTemp, "Invalid argument to BounceProcess: %d", nIndex); 
				WriteLog(pTemp);
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager); 
	}
	return FALSE;
}

BOOL KillService(char* pName) 
{	
	// kill service with given name
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "OpenSCManager failed, error code = %d", nError);
		WriteLog(pTemp);
	}
	else
	{
		// open the service
		SC_HANDLE schService = OpenService( schSCManager, pName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{	
			long nError = GetLastError();
			char pTemp[121];
			sprintf(pTemp, "OpenService failed, error code = %d", nError);
			WriteLog(pTemp);
		}
		else
		{
			// call ControlService to kill the given service
			SERVICE_STATUS status;
			if(ControlService(schService,SERVICE_CONTROL_STOP,&status))
			{
				CloseServiceHandle(schService); 
				CloseServiceHandle(schSCManager); 
				return TRUE;
			}
			else
			{	return FALSE;
				long nError = GetLastError();
				char pTemp[121];
				sprintf(pTemp, "ControlService failed, error code = %d", nError);
				WriteLog(pTemp);
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager); 
	}
	return FALSE;
}

BOOL RunService(char* pName, int nArg, char** pArg) 
{ 
	// run service with given name
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "OpenSCManager failed, error code = %d", nError);
		WriteLog(pTemp);
	}
	else
	{
		// open the service
		SC_HANDLE schService = OpenService( schSCManager, pName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			long nError = GetLastError();
			char pTemp[121];
			sprintf(pTemp, "OpenService failed, error code = %d", nError);
			WriteLog(pTemp);
		}
		else
		{
			// call StartService to run the service
			if(StartService(schService,nArg,(const char**)pArg))
			{
				CloseServiceHandle(schService); 
				CloseServiceHandle(schSCManager); 
				return TRUE;
			}
			else
			{	return FALSE;
				long nError = GetLastError();
				char pTemp[121];
				sprintf(pTemp, "StartService failed, error code = %d", nError);
				WriteLog(pTemp);
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager); 
	}
	return FALSE;
}

////////////////////////////////////////////////////////////////////// 
//
// This routine gets used to start your service
//
VOID WINAPI XYNTServiceMain( DWORD dwArgc, LPTSTR *lpszArgv )
{
	DWORD   status = 0; 
    DWORD   specificError = 0xfffffff; 
 
    serviceStatus.dwServiceType        = SERVICE_WIN32; 
    serviceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    serviceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN | SERVICE_ACCEPT_PAUSE_CONTINUE; 
    serviceStatus.dwWin32ExitCode      = 0; 
    serviceStatus.dwServiceSpecificExitCode = 0; 
    serviceStatus.dwCheckPoint         = 0; 
    serviceStatus.dwWaitHint           = 0; 
 
    hServiceStatusHandle = RegisterServiceCtrlHandler(pServiceName, XYNTServiceHandler); 
    if (hServiceStatusHandle==0) 
    {
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "RegisterServiceCtrlHandler failed, error code = %d", nError);
		WriteLog(pTemp);
        return; 
    } 
 
    // Initialization complete - report running status 
    serviceStatus.dwCurrentState       = SERVICE_RUNNING; 
    serviceStatus.dwCheckPoint         = 0; 
    serviceStatus.dwWaitHint           = 0;  
    if(!SetServiceStatus(hServiceStatusHandle, &serviceStatus)) 
    { 
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "SetServiceStatus failed, error code = %d", nError);
		WriteLog(pTemp);
    } 

	for(int i=0;i<nMaxProcCount;i++)
	{
		pProcInfo[i].hProcess = 0;
		StartProcess(i);
	}
}

////////////////////////////////////////////////////////////////////// 
//
// This routine responds to events concerning your service, like start/stop
//
VOID WINAPI XYNTServiceHandler(DWORD fdwControl)
{
	switch(fdwControl) 
	{
		case SERVICE_CONTROL_STOP:
		case SERVICE_CONTROL_SHUTDOWN:
			serviceStatus.dwWin32ExitCode = 0; 
			serviceStatus.dwCurrentState  = SERVICE_STOPPED; 
			serviceStatus.dwCheckPoint    = 0; 
			serviceStatus.dwWaitHint      = 0;
			// terminate all processes started by this service before shutdown
			{
				for(int i=nMaxProcCount-1;i>=0;i--)
				{
					EndProcess(i);
				}			
				if (!SetServiceStatus(hServiceStatusHandle, &serviceStatus))
				{ 
					long nError = GetLastError();
					char pTemp[121];
					sprintf(pTemp, "SetServiceStatus failed, error code = %d", nError);
					WriteLog(pTemp);
				}
			}
			return; 
		case SERVICE_CONTROL_PAUSE:
			serviceStatus.dwCurrentState = SERVICE_PAUSED; 
			break;
		case SERVICE_CONTROL_CONTINUE:
			serviceStatus.dwCurrentState = SERVICE_RUNNING; 
			break;
		case SERVICE_CONTROL_INTERROGATE:
			break;
		default: 
			// bounce processes started by this service
			if(fdwControl>=128&&fdwControl<256)
			{
				int nIndex = fdwControl&0x7F;
				// bounce a single process
				if(nIndex>=0&&nIndex<nMaxProcCount)
				{
					EndProcess(nIndex);
					StartProcess(nIndex);
				}
				// bounce all processes
				else if(nIndex==127)
				{
					for(int i=nMaxProcCount-1;i>=0;i--)
					{
						EndProcess(i);
					}
					for(i=0;i<nMaxProcCount;i++)
					{
						StartProcess(i);
					}
				}
			}
			else
			{
				long nError = GetLastError();
				char pTemp[121];
				sprintf(pTemp,  "Unrecognized opcode %d", fdwControl);
				WriteLog(pTemp);
			}
	};
    if (!SetServiceStatus(hServiceStatusHandle,  &serviceStatus)) 
	{ 
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "SetServiceStatus failed, error code = %d", nError);
		WriteLog(pTemp);
    } 
}


////////////////////////////////////////////////////////////////////// 
//
// Uninstall
//
VOID UnInstall(char* pName)
{
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS); 
	if (schSCManager==0) 
	{
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "OpenSCManager failed, error code = %d", nError);
		WriteLog(pTemp);
	}
	else
	{
		SC_HANDLE schService = OpenService( schSCManager, pName, SERVICE_ALL_ACCESS);
		if (schService==0) 
		{
			long nError = GetLastError();
			char pTemp[121];
			sprintf(pTemp, "OpenService failed, error code = %d", nError);
			WriteLog(pTemp);
		}
		else
		{
			if(!DeleteService(schService)) 
			{
				char pTemp[121];
				sprintf(pTemp, "Failed to delete service %s", pName);
				WriteLog(pTemp);
			}
			else 
			{
				char pTemp[121];
				sprintf(pTemp, "Service %s removed",pName);
				WriteLog(pTemp);
			}
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager);	
	}
}

////////////////////////////////////////////////////////////////////// 
//
// Install
//
VOID Install(char* pPath, char* pName) 
{  
	SC_HANDLE schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE); 
	if (schSCManager==0) 
	{
		long nError = GetLastError();
		char pTemp[121];
		sprintf(pTemp, "OpenSCManager failed, error code = %d", nError);
		WriteLog(pTemp);
	}
	else
	{
		SC_HANDLE schService = CreateService
		( 
			schSCManager,	/* SCManager database      */ 
			pName,			/* name of service         */ 
			pName,			/* service name to display */ 
			SERVICE_ALL_ACCESS,        /* desired access          */ 
			SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS , /* service type            */ 
			SERVICE_AUTO_START,      /* start type              */ 
			SERVICE_ERROR_NORMAL,      /* error control type      */ 
			pPath,			/* service's binary        */ 
			NULL,                      /* no load ordering group  */ 
			NULL,                      /* no tag identifier       */ 
			NULL,                      /* no dependencies         */ 
			NULL,                      /* LocalSystem account     */ 
			NULL
		);                     /* no password             */ 
		if (schService==0) 
		{
			long nError =  GetLastError();
			char pTemp[121];
			sprintf(pTemp, "Failed to create service %s, error code = %d", pName, nError);
			WriteLog(pTemp);
		}
		else
		{
			char pTemp[121];
			sprintf(pTemp, "Service %s installed", pName);
			WriteLog(pTemp);
			CloseServiceHandle(schService); 
		}
		CloseServiceHandle(schSCManager);
	}	
}

void WorkerProc(void* pParam)
{
	int nCheckProcessSeconds = 0;
	char pCheckProcess[nBufferSize+1];
	GetPrivateProfileString("Settings","CheckProcess","0",pCheckProcess, nBufferSize,pInitFile);
	int nCheckProcess = atoi(pCheckProcess);
	if(nCheckProcess>0) nCheckProcessSeconds = nCheckProcess*60;
	else
	{
		GetPrivateProfileString("Settings","CheckProcessSeconds","600",pCheckProcess, nBufferSize,pInitFile);
		nCheckProcessSeconds = atoi(pCheckProcess);
	}
	while(nCheckProcessSeconds>0)
	{
		::Sleep(1000*nCheckProcessSeconds);
		for(int i=0;i<nMaxProcCount;i++)
		{
			if(pProcInfo[i].hProcess)
			{
				char pItem[nBufferSize+1];
				sprintf(pItem,"Process%d\0",i);
				char pRestart[nBufferSize+1];
				GetPrivateProfileString(pItem,"Restart","No",pRestart,nBufferSize,pInitFile);
				if(pRestart[0]=='Y'||pRestart[0]=='y'||pRestart[0]=='1')
				{
					DWORD dwCode;
					if(::GetExitCodeProcess(pProcInfo[i].hProcess, &dwCode))
					{
						if(dwCode!=STILL_ACTIVE)
						{
							if(StartProcess(i))
							{
								char pTemp[121];
								sprintf(pTemp, "Restarted process %d", i);
								WriteLog(pTemp);
							}
						}
					}
					else
					{
						long nError = GetLastError();
						char pTemp[121];
						sprintf(pTemp, "GetExitCodeProcess failed, error code = %d", nError);
						WriteLog(pTemp);
					}
				}
			}
		}
	}
}

void Refresh()
{
	if(!KillService("FireAlarmService"))
	{	printf("Running State 1 ");
		RunService("FireAlarmService",0,NULL);
		for(int i=0;i<60;i++)
		{	printf(".");}
		printf("\n");	
		while(!KillService("FireAlarmService"))
		{}
		
		printf("Running State 2 ");
		RunService("FireAlarmService",0,NULL);
		for(int i2=0;i2<60;i2++)
		{	printf(".");}
		printf("\n");	
		while(!KillService("FireAlarmService"))
		{}

		printf("Running State 3 ");
		RunService("FireAlarmService",0,NULL);
		for(int i3=0;i3<60;i3++)
		{	printf(".");}
		printf("\n");	
	
	}else
	{
		printf("Running State 1 ");
		RunService("FireAlarmService",0,NULL);
		for(int i=0;i<60;i++)
		{	printf(".");}
		printf("\n");	
		while(!KillService("FireAlarmService"))
		{}
		
		printf("Running State 2 ");
		RunService("FireAlarmService",0,NULL);
		for(int i2=0;i2<60;i2++)
		{	printf(".");}
		printf("\n");	
		while(!KillService("FireAlarmService"))
		{}

		printf("Running State 3 ");
		RunService("FireAlarmService",0,NULL);
		for(int i3=0;i3<60;i3++)
		{	printf(".");}
		printf("\n");	
	}

		printf("Runing Service FireAlarm Complete !! \n");

}

//////
/////////////////////////////////////////////////


/////////////////////////////////////////////////
//////  Get Login User
HANDLE GetHandleExplorer()
{
	HANDLE hProcess;
	// Get the list of process identifiers.

	DWORD aProcesses[1024], cbNeeded, cProcesses;
	unsigned int i;

	if ( !EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded ) )
		return 0;

	// Calculate how many process identifiers were returned.

	cProcesses = cbNeeded / sizeof(DWORD);

	// Print the name and process identifier for each process.

	for ( i = 0; i < cProcesses; i++ )
	{
		TCHAR szProcessName[MAX_PATH] = TEXT("<unknown>");
		TCHAR ProcessName[MAX_PATH] = TEXT("Explorer.EXE");

		// Get a handle to the process.

		hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
									   PROCESS_VM_READ,
									   FALSE, aProcesses[i] );

		// Get the process name.

		if (NULL != hProcess )
		{
			HMODULE hMod;
			DWORD cbNeeded;

			if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), 
				 &cbNeeded) )
			{
				GetModuleBaseName( hProcess, hMod, szProcessName, 
								   sizeof(szProcessName)/sizeof(TCHAR) );
			}
		}
		
		if(_tcscmp(szProcessName,ProcessName) == 0){
			return hProcess;
		}

	}
	CloseHandle( hProcess );
	hProcess = NULL;
	return hProcess;
}

CString GetLoginUser()
{
	HANDLE explorer = GetHandleExplorer();
	if(explorer==NULL)
	{	return "SYSTEM";
	}
	HANDLE t_handle;
	
	DWORD lenght;
	TOKEN_OWNER* pOwner = NULL;
	if (!OpenProcessToken(explorer,TOKEN_QUERY,&t_handle))
		return GetLastError();
	GetTokenInformation(t_handle,TokenOwner,pOwner,0, &lenght);
	pOwner = (TOKEN_OWNER*) new char[lenght];
	if (GetTokenInformation(t_handle, TokenOwner, pOwner, lenght, &lenght)== 0)
	{
		printf("GetTokenInformation() failed (error code = %d)",GetLastError());
	}
	TCHAR bufName[MAX_PATH];
	TCHAR bufDomain[MAX_PATH];
	SID_NAME_USE SidNameUse;
	DWORD dwCbName = 0;
	DWORD dwCbDomainName = 0;
	dwCbName = sizeof(bufName);
	dwCbDomainName = sizeof(bufDomain);
	LookupAccountSid(NULL, pOwner->Owner, bufName, &dwCbName, bufDomain, &dwCbDomainName, &SidNameUse);
	CString tmp(bufName);
	return tmp;
}

void Thread_CheckUser(LPVOID pParam)
{	
	CString user1="";
	int flag = 0;
	user1 = GetLoginUser();
	cout << "Running Thread CheckUser"<< endl;
	while(1)
	{
		while(user1==GetLoginUser())
		{
			if(GetLoginUser()=="SYSTEM" && flag==0)
			{
				if(!KillService("FireAlarmService"))
				{	cout << "Process Stopped" << endl;
				}
				if(!RunService("DefaultFireAlarmRule",0,NULL))
				{	cout << "Cannot run Default Rule !!" << endl;
				}
				
				flag = 1;
			}
			if(GetLoginUser()!="SYSTEM" && flag==0)
			{	if(!KillService("DefaultFireAlarmRule"))
				{	cout << "Cannot Kill Default Rule !!" << endl;
				}
				
				if(RunService("FireAlarmService",0,NULL))
				{	cout << "FireAlarm Service Start 1" << endl;
				}
				Refresh();
				Refresh();
				Refresh();
/*	
				if(RunService("FireAlarmService",0,NULL))
				{	cout << "FireAlarm Service Start 1" << endl;
				}
				while(!KillService("FireAlarmService"))
				{	Sleep(100);
					cout << "Can't Kill FireAlarm Service" << endl;
				}
				if(RunService("FireAlarmService",0,NULL))
				{	cout << "FireAlarm Service Start 2" << endl;
				}else cout << "Can't Run FireAlarm Service" << endl;
				while(!KillService("FireAlarmService"))
				{	Sleep(100);
					cout << "Can't Kill FireAlarm Service" << endl;
				}*/
//				if(RunService("FireAlarmService",0,NULL))
//				{	cout << "FireAlarm Service Start 3" << endl;
//				}else cout << "Can't Run FireAlarm Service" << endl;

				flag = 1;
			}
			Sleep(500);	
		}
		Sleep(500);
		flag = 0;
		user1=GetLoginUser();
	}
}
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CString strHello;
		strHello.LoadString(IDS_HELLO);
		if(_beginthread(Thread_CheckUser, 0, NULL)==-1)
		{	cout << "Error begin Thread_CheckUser !!" << endl;
		}
		cout << (LPCTSTR)GetLoginUser() << endl;
	}
	int t;
	cin >> t;
	return nRetCode;
}


