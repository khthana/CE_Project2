// FireAlarm.h : main header file for the FIREALARM application
//

#if !defined(AFX_FIREALARM_H__38A9069A_4C1F_49E8_B36B_3BE87F72A2F9__INCLUDED_)
#define AFX_FIREALARM_H__38A9069A_4C1F_49E8_B36B_3BE87F72A2F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmApp:
// See FireAlarm.cpp for the implementation of this class
//

class CFireAlarmApp : public CWinApp
{
public:
	CFireAlarmApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFireAlarmApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARM_H__38A9069A_4C1F_49E8_B36B_3BE87F72A2F9__INCLUDED_)
