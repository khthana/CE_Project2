// FireAlarmDlg.h : header file
//

#if !defined(AFX_FIREALARMDLG_H__238977E8_4AB8_4CA0_9316_0A5B7F772121__INCLUDED_)
#define AFX_FIREALARMDLG_H__238977E8_4AB8_4CA0_9316_0A5B7F772121__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FireAlarmActivity.h"
#include "FireAlarmRule.h"
#include "FireAlarmNetStat.h"
/////////////////////////////////////////////////////////////////////////////
// CFireAlarmDlg dialog

class CFireAlarmDlg : public CDialog
{
// Construction
public:

	NOTIFYICONDATA m_notifyIconData;
	CFireAlarmDlg(CWnd* pParent = NULL);	// standard constructor
	FireAlarmActivity	m_dFireAlarmActivityDlg;
	FireAlarmRule		m_dFireAlarmRuleDlg;
	CFireAlarmNetStat	m_dFireAlarmNetStatDlg;
	void ShowWindowNumber(int number);
// Dialog Data
	//{{AFX_DATA(CFireAlarmDlg)
	enum { IDD = IDD_FIREALARM_DIALOG };
	CTabCtrl	m_cTab;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFireAlarmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnSelchangeMaintab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LONG OnSystrayNotify(WPARAM wParam, LPARAM lParam);
	afx_msg void OnRestore();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnShutdown();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private :
	CRect m_rSettingsRect;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMDLG_H__238977E8_4AB8_4CA0_9316_0A5B7F772121__INCLUDED_)
