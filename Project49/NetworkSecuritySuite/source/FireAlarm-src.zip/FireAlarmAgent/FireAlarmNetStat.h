#if !defined(AFX_FIREALARMNETSTAT_H__9D8C2BC6_0BE5_49A2_9752_450FA23B5D5B__INCLUDED_)
#define AFX_FIREALARMNETSTAT_H__9D8C2BC6_0BE5_49A2_9752_450FA23B5D5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireAlarmNetStat.h : header file
//
#include "UDPClass.h"
#include "TCPTable.h"
#include "ConnContainer.h"
#include "RuleManage.h"

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmNetStat dialog
#include <afxtempl.h>
#include "commctrl.h"
#include "afxmt.h"

#include "Widget/TaskbarNotifier.h"
#include "Widget/SystemTray.h"
#include "Widget/SplitterBar.h"
#include "Widget/SplashWnd.h"

#include <map>
using std::map;

typedef map<CString, DWORD> Ico2Index;

typedef enum _SUBITEMS
{
	hProto			= 0x00,
	hPid			= 0x01,
	hProcessName	,
	hLocalAddress	,
	hLocalPort		,
	hRemoteAddress	,
	hRemotePort		,
	hState			
} SUBITEMS;

typedef enum _CONNVIEW
{
	viewAll = 0,
	TCP = 1,
	UDP = 2
} CONNVIEW;

class CFireAlarmNetStat : public CDialog
{
// Construction
public:
	CFireAlarmNetStat(CWnd* pParent = NULL);   // standard constructor
	static	DWORD		ms_dwUpdateTime;
	static	HANDLE		m_hndLogConnEvent;
	CRuleManage* ruleUser;

// Dialog Data	
	//{{AFX_DATA(CFireAlarmNetStat)
	enum { IDD = IDD_FIREALARMNETSTAT };
	CComboBox	m_cView;
	CComboBox	m_cRefreshCombo;
	CButton	m_cRefresh;
	CListCtrl	m_cListNetStat;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmNetStat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFireAlarmNetStat)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeComborefresh();
	afx_msg void OnButtonrefresh();
	afx_msg LRESULT OnUpdateList(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnTcpNewConnMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSelchangeComboview();
	afx_msg void OnRclickListnetstat(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSysKillprocess();
	afx_msg void OnSysCloseconnection();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CImageList  *m_pImageListMain;
	Ico2Index	 m_mProcName2IcoIndex;
	int			 m_nItem;
	CTCPTable	*m_pTcp;
	CUDPClass	*m_pUdp;
	CStatusBar	m_bar;
	static	int			m_bFlagInit;
	static	int			m_nItemMain;
	static	CONNVIEW	m_eConnView;

	//TCPTABLE_EX
	static PMIB_TCPTABLE_EX m_pOldBuffTcpTableEx;
	static CCriticalSection __CriticalSection__;
 
	HANDLE		m_hndThUser;
	HANDLE		m_hndTh;

private:
	void		InitListAll			();
	int			InitListTcpInfo		();
	void		InitListUdpInfo		(DWORD next);
	int			UpdateIncommingConn	();
	bool		DetectNewConn		();
	CString		GetItemText			(HWND hWnd, int nItem, int nSubItem) const;
	void		SetCell				(HWND hWnd1, CString value, int nRow, int nCol);
	int			GetProcessIcon		(CString strAppName, CString strPathAppName);
	void		InitCriticalSection	(void);
	void		CheckMenu			(UINT idSubItem);

/************************************************************************/
/* Note: 
	Outgoing connection: (connection state is set to "ESTABLISHED")
	       + new local port (don't care about remote context, but store it) #ACT
		   	   		
	Incomming connection: (connection state is set to "ESTABLISHED")
	       + on existing local port
		       - new remote IP (don't care about remote port, but store it) #ACT
		       + same remote IP
		           - different remote port(store it)						#ACT
                                                                     */
/************************************************************************/
	CList<INTERFACE_HANDLE, INTERFACE_HANDLE&> m_ListHInterf;
		CMap<int, int, INTERFACE_HANDLE, INTERFACE_HANDLE&> m_MapHInterf;
		CMap<DWORD, DWORD, TCPTABLE, TCPTABLE&> m_MapNewTcpConn; //for balloon info


		CSplitterBar	 m_ctrlSplitterBar;
		CTaskbarNotifier m_ctrlTaskBarIn;
		CTaskbarNotifier m_ctrlTaskBarOut;
		CSystemTray		 m_TrayIcon;
		bool			 m_bFocus;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMNETSTAT_H__9D8C2BC6_0BE5_49A2_9752_450FA23B5D5B__INCLUDED_)
