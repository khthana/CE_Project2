# Microsoft Developer Studio Project File - Name="FireAlarm" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=FireAlarm - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "FireAlarm.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "FireAlarm.mak" CFG="FireAlarm - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "FireAlarm - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "FireAlarm - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "FireAlarm - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "FireAlarm - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 Extern\Lib\iphlpapi.lib ws2_32.lib Extern\Lib\psapi.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "FireAlarm - Win32 Release"
# Name "FireAlarm - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\ADConnect.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_ICMP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_IP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_TCP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_UDP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analysis.cpp
# End Source File
# Begin Source File

SOURCE=.\Base.cpp
# End Source File
# Begin Source File

SOURCE=.\Bomb_Packet.cpp
# End Source File
# Begin Source File

SOURCE=.\ConnContainer.cpp
# End Source File
# Begin Source File

SOURCE=.\FireAlarm.cpp
# End Source File
# Begin Source File

SOURCE=.\FireAlarm.rc
# End Source File
# Begin Source File

SOURCE=.\FireAlarmActivity.cpp
# End Source File
# Begin Source File

SOURCE=.\FireAlarmDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\FireAlarmNetStat.cpp
# End Source File
# Begin Source File

SOURCE=.\FireAlarmRule.cpp
# End Source File
# Begin Source File

SOURCE=.\Fragment.cpp
# End Source File
# Begin Source File

SOURCE=.\GetFin.cpp
# End Source File
# Begin Source File

SOURCE=.\GetPort.cpp
# End Source File
# Begin Source File

SOURCE=.\Header_Packet.cpp
# End Source File
# Begin Source File

SOURCE=.\Link_Fragment.cpp
# End Source File
# Begin Source File

SOURCE=.\PacketFilter.cpp
# End Source File
# Begin Source File

SOURCE=.\PingSweeps.cpp
# End Source File
# Begin Source File

SOURCE=.\Result.cpp
# End Source File
# Begin Source File

SOURCE=.\RuleManage.cpp
# End Source File
# Begin Source File

SOURCE=.\Sniff.cpp
# End Source File
# Begin Source File

SOURCE=.\sockUtil.cpp
# End Source File
# Begin Source File

SOURCE=.\Widget\SplitterBar.cpp
# End Source File
# Begin Source File

SOURCE=.\Widget\SplitterControl.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\Widget\SystemTray.cpp
# End Source File
# Begin Source File

SOURCE=.\Widget\TaskbarNotifier.cpp
# End Source File
# Begin Source File

SOURCE=.\TCPTable.cpp
# End Source File
# Begin Source File

SOURCE=.\TDriver.cpp
# End Source File
# Begin Source File

SOURCE=.\UDPClass.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\ADConnect.h
# End Source File
# Begin Source File

SOURCE=.\AddDefines.h
# End Source File
# Begin Source File

SOURCE=.\Analy_ICMP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_IP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_TCP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_UDP.h
# End Source File
# Begin Source File

SOURCE=.\Analysis.h
# End Source File
# Begin Source File

SOURCE=.\Base.h
# End Source File
# Begin Source File

SOURCE=.\Bomb_Packet.h
# End Source File
# Begin Source File

SOURCE=.\ConnContainer.h
# End Source File
# Begin Source File

SOURCE=.\FireAlarm.h
# End Source File
# Begin Source File

SOURCE=.\FireAlarmActivity.h
# End Source File
# Begin Source File

SOURCE=.\FireAlarmDlg.h
# End Source File
# Begin Source File

SOURCE=.\FireAlarmNetStat.h
# End Source File
# Begin Source File

SOURCE=.\FireAlarmRule.h
# End Source File
# Begin Source File

SOURCE=.\Fragment.h
# End Source File
# Begin Source File

SOURCE=.\GetFin.h
# End Source File
# Begin Source File

SOURCE=.\GetPort.h
# End Source File
# Begin Source File

SOURCE=.\Header_Packet.h
# End Source File
# Begin Source File

SOURCE=.\Link_Fragment.h
# End Source File
# Begin Source File

SOURCE=.\PacketFilter.h
# End Source File
# Begin Source File

SOURCE=.\PingSweeps.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\Result.h
# End Source File
# Begin Source File

SOURCE=.\RuleManage.h
# End Source File
# Begin Source File

SOURCE=.\Sniff.h
# End Source File
# Begin Source File

SOURCE=.\sockutil.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TCPTable.h
# End Source File
# Begin Source File

SOURCE=.\TDriver.h
# End Source File
# Begin Source File

SOURCE=.\UDPClass.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=".\res\Bar copy.bmp"
# End Source File
# Begin Source File

SOURCE=.\res\bar.bmp
# End Source File
# Begin Source File

SOURCE=.\res\bar2.bmp
# End Source File
# Begin Source File

SOURCE=.\res\FILE_URL.ICO
# End Source File
# Begin Source File

SOURCE=.\res\fireAlarm.bmp
# End Source File
# Begin Source File

SOURCE=.\res\FireAlarm.ico
# End Source File
# Begin Source File

SOURCE=.\res\FireAlarm.rc2
# End Source File
# Begin Source File

SOURCE=.\res\inactive.ico
# End Source File
# Begin Source File

SOURCE=.\res\LOGO.bmp
# End Source File
# Begin Source File

SOURCE=.\res\program.ico
# End Source File
# Begin Source File

SOURCE=.\res\tooltip_in.bmp
# End Source File
# Begin Source File

SOURCE=.\res\tooltip_out.bmp
# End Source File
# Begin Source File

SOURCE=".\res\tooltipIN copy.bmp"
# End Source File
# Begin Source File

SOURCE=".\res\tooltipout copy.bmp"
# End Source File
# End Group
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
