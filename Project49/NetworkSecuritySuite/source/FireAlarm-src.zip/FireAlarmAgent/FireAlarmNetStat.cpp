// FireAlarmNetStat.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarm.h"
#include "FireAlarmNetStat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmNetStat dialog
//defines
#define ID_FAKE_CONTROL 0x9999

//init static members
	static UINT BASED_CODE indicators[] =
	{
		ID_INDICATOR_ERROR,
		ID_INDICATOR_TIME
	};	
	BOOL			 CFireAlarmNetStat::m_bFlagInit			 = FALSE;
	int				 CFireAlarmNetStat::m_nItemMain			 = -1;
	HANDLE			 CFireAlarmNetStat::m_hndLogConnEvent	= NULL;

	CONNVIEW		 CFireAlarmNetStat::m_eConnView			 = viewAll;
	PMIB_TCPTABLE_EX CFireAlarmNetStat::m_pOldBuffTcpTableEx = NULL;
	CCriticalSection CFireAlarmNetStat::__CriticalSection__;
	DWORD			 CFireAlarmNetStat::ms_dwUpdateTime		 = 20 * 1000;

//implement out func
	DWORD WINAPI LogConn_ThreadProc(LPVOID lpParameter)
	{
		while (INFINITE)
		{
			if(CConnContainer::IsNewConnection())
			{
				//update table info
				::PostMessage((HWND)lpParameter, EVENT_TIMER_NEW_TCP_CONN, 0, 0);
			}
			else
			{
				//do nothing
			}

			Sleep(1000);
		}
		return 1;
	}

	DWORD WINAPI LogConn_ThreadProcUser(LPVOID lpParameter)
	{
		while (INFINITE)
		{
			if(CConnContainer::IsNewConnection())
				::SendMessage((HWND)lpParameter, EVENT_TIMER_REFRESH_LIST, 0, 0); //update table info
			
			Sleep(CFireAlarmNetStat::ms_dwUpdateTime);
			TRACE1("\n\t User update time : %d", CFireAlarmNetStat::ms_dwUpdateTime);
		}
		return 1;
	}

CFireAlarmNetStat::CFireAlarmNetStat(CWnd* pParent /*=NULL*/)
	: CDialog(CFireAlarmNetStat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFireAlarmNetStat)
	//}}AFX_DATA_INIT

	m_pTcp				=	new CTCPTable();
	m_pUdp				=	new CUDPClass();

	m_pImageListMain	=	NULL;
	
	m_hndThUser			=	NULL;
	m_hndTh				=	NULL;
}


void CFireAlarmNetStat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFireAlarmNetStat)
	DDX_Control(pDX, IDC_COMBOVIEW, m_cView);
	DDX_Control(pDX, IDC_COMBOREFRESH, m_cRefreshCombo);
	DDX_Control(pDX, IDC_BUTTONREFRESH, m_cRefresh);
	DDX_Control(pDX, IDC_LISTNETSTAT, m_cListNetStat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFireAlarmNetStat, CDialog)
	//{{AFX_MSG_MAP(CFireAlarmNetStat)
	ON_CBN_SELCHANGE(IDC_COMBOREFRESH, OnSelchangeComborefresh)
	ON_BN_CLICKED(IDC_BUTTONREFRESH, OnButtonrefresh)
	ON_MESSAGE(EVENT_TIMER_REFRESH_LIST, OnUpdateList)
	ON_MESSAGE(EVENT_TIMER_NEW_TCP_CONN, OnTcpNewConnMsg)
	ON_CBN_SELCHANGE(IDC_COMBOVIEW, OnSelchangeComboview)
	ON_NOTIFY(NM_RCLICK, IDC_LISTNETSTAT, OnRclickListnetstat)
	ON_COMMAND(ID_SYS_KILLPROCESS, OnSysKillprocess)
	ON_COMMAND(ID_SYS_CLOSECONNECTION, OnSysCloseconnection)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmNetStat message handlers

BOOL CFireAlarmNetStat::OnInitDialog() 
{
	CDialog::OnInitDialog();

	ruleUser	= new CRuleManage();
	//init thread and event log
	InitCriticalSection();

	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 15;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_STAT1);
	Static1->SetFont(F1,TRUE);

	//init taskbarnotifier
	m_ctrlTaskBarIn.Create(this);
	m_ctrlTaskBarIn.SetSkin(IDB_BITMAP_TOOLTIP_IN, 255, 0, 255);
	//m_ctrlTaskBarIn.SetSkin("F:\\MyProjects\\ENetStatX\\res\\tooltip_in.bmp",255,0,255);
	m_ctrlTaskBarIn.SetTextFont("Verdana",80,TN_TEXT_NORMAL, TN_TEXT_BOLD);
	m_ctrlTaskBarIn.SetTextColor(RGB(255,255,255), RGB(255,255,255));
	m_ctrlTaskBarIn.SetTextRect(CRect(
			10, //left
			0, //top
			m_ctrlTaskBarIn.m_nSkinWidth-10, //right
			m_ctrlTaskBarIn.m_nSkinHeight-15)); //bottom
	m_ctrlTaskBarIn.SetTransparent(90); //default 58

	//init taskbarnotifier
	m_ctrlTaskBarOut.Create(this);
	m_ctrlTaskBarOut.SetSkin(IDB_BITMAP_TOOLTIP_OUT, 255, 0, 255);
	//m_ctrlTaskBarOut.SetSkin("F:\\MyProjects\\ENetStatX\\res\\tooltip_out.bmp",255,0,255);
	m_ctrlTaskBarOut.SetTextFont("Verdana",80,TN_TEXT_NORMAL, TN_TEXT_BOLD);
	m_ctrlTaskBarOut.SetTextColor(RGB(255,255,255), RGB(255,255,255));
	m_ctrlTaskBarOut.SetTextRect(CRect(
			10,
			0,
			m_ctrlTaskBarOut.m_nSkinWidth-10,
			m_ctrlTaskBarOut.m_nSkinHeight-15));
	m_ctrlTaskBarOut.SetTransparent(90); //default 58

	CWinApp *pApp = AfxGetApp();
	m_pImageListMain = new CImageList();
	ASSERT(m_pImageListMain != NULL);
	BOOL brez = m_pImageListMain->Create(16,16 ,ILC_COLOR32,16 ,64);
	m_pImageListMain->SetBkColor(CLR_DEFAULT);
	m_pImageListMain->Add(pApp->LoadIcon(IDI_ICON_PROTO));
	m_pImageListMain->Add(pApp->LoadIcon(IDI_ICON_UNK_PROCESS));
	m_cListNetStat.SetImageList(m_pImageListMain, LVSIL_SMALL);

	m_cListNetStat.InsertColumn(hProto,			"Protocol",				LVCFMT_CENTER,60,	-1);
	m_cListNetStat.InsertColumn(hPid,			"PID",					LVCFMT_CENTER,40,	-1);
	m_cListNetStat.InsertColumn(hProcessName,	"Process Name",			LVCFMT_CENTER,100,	-1);
	m_cListNetStat.InsertColumn(hLocalAddress,	"Local Address",		LVCFMT_CENTER,87,	-1);
	m_cListNetStat.InsertColumn(hLocalPort,		"Local Port",			LVCFMT_CENTER,68,	-1);
	m_cListNetStat.InsertColumn(hRemoteAddress,	"Remote Address",	LVCFMT_CENTER,110,	-1);
	m_cListNetStat.InsertColumn(hRemotePort,	"Remote Port",		LVCFMT_CENTER,94,	-1);
	m_cListNetStat.InsertColumn(hState,			"State",				LVCFMT_CENTER,80,	-1);

	m_cListNetStat.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);
	
	//Init Connection Map
	m_MapNewTcpConn.InitHashTable(257);
//	m_MapHInterf.InitHashTable(257);	

	//create status bar
	m_bar.Create(this); //We create the status bar
	m_bar.SetIndicators(indicators,2); //Set the number of panes 
	CRect sb_rect;
	GetClientRect(&sb_rect);
	//Size the two panes
	m_bar.SetPaneInfo(0,ID_INDICATOR_ERROR,SBPS_NORMAL,sb_rect.Width()-100);      
	m_bar.SetPaneInfo(1,ID_INDICATOR_TIME,SBPS_STRETCH ,0);

	//This is where we actually draw it on the screen
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,ID_INDICATOR_TIME);
	
	m_cRefreshCombo.SetCurSel(3);
	m_cView.SetCurSel(0);

	UpdateData();
		
	SuspendThread(m_hndThUser); //suspend thread
	ms_dwUpdateTime	= 20 * 1000; //update cycle time 
	ResumeThread(m_hndThUser);	//resume thread

	InitListAll();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CFireAlarmNetStat::GetProcessIcon(CString strAppName,CString strPathAppName)
{
	/*
	 *	Note: -> there is no need to clean-up the map: knowledge is better
	 *        -> icon cache mechanism 
	 */
	int nUnk = 1;		//default icon (app without icon)
	int nIcoIndex = -1; 

	if (strPathAppName.IsEmpty() || (strPathAppName == "error"))
		return nUnk; //default for unk process

	if (strAppName.IsEmpty())
		strAppName = strPathAppName.Right((strPathAppName.GetLength()-1) - strPathAppName.ReverseFind('\\'));

	//is it already assigned ?
	Ico2Index::iterator it = m_mProcName2IcoIndex.find(strAppName);
	if (it != m_mProcName2IcoIndex.end())
	{
		TRACE2("\n Existing map, process: %s, icon: %d\n",(*it).first, m_mProcName2IcoIndex[strAppName]);
		nIcoIndex = m_mProcName2IcoIndex[strAppName];
		return --nIcoIndex;
	}
	
	//add a new record
	HICON hSmallIco = NULL;
	if (NULL == (hSmallIco = ::ExtractIcon(NULL, strPathAppName, 0)))
		return nUnk;
	 
	m_pImageListMain->Add(hSmallIco);
	DestroyIcon(hSmallIco);

	nIcoIndex = (m_pImageListMain->GetImageCount());
	if (nIcoIndex >= 1)
	{
		TRACE2("\n New map, process: %s, icon: %d\n", strAppName, nIcoIndex);
		m_mProcName2IcoIndex[strAppName] = nIcoIndex;
		return --nIcoIndex;
	}
	else
		return nUnk;
}

int CFireAlarmNetStat::InitListTcpInfo()
{
	in_addr stAddr;
	char	strLocAddress[16];
	char	strRemAddress[16];
	CString strText(L"");
	DWORD	iItem;
	LVITEM  item;

	/**********************Get TCP info**********************/
	//fill buffer
	DWORD	dwRez = 0;

	// init tcp table
	if (m_pTcp == NULL) return 0;
	if (NO_ERROR != (dwRez = m_pTcp->GetTableEx()))	return 0;

	//print the info
	int iSubItem = 1;
	for (iItem = 0; iItem < m_pTcp->GetNumberOfEntries(); iItem++)
	{
			//prepare the local address field
			u_long ulLocalAddress = static_cast<u_long>(m_pTcp->GetLocalAddress(iItem));
			stAddr.s_addr = ulLocalAddress;
			strcpy(strLocAddress, inet_ntoa(stAddr));
		
			//prepare the local port field
			u_short usLocalPort = ntohs(static_cast<u_short>(m_pTcp->GetLocalPort(iItem)));

			//prepare the remote address field
			u_long ulRemoteAddress = static_cast<u_long>(m_pTcp->GetRemoteAddress(iItem));
			stAddr.s_addr = ulRemoteAddress;
			strcpy(strRemAddress, inet_ntoa(stAddr));

			//prepare the remote port field
			u_short usRemotePort = ntohs(static_cast<u_short>(m_pTcp->GetRemotePort(iItem)));

			//prepare the Pid
			DWORD dwPid = m_pTcp->GetProcessId(iItem);
			CString strProcName = m_pTcp->GetProcById(dwPid);

			//print TCP info
			if ("TCP" != m_cListNetStat.GetItemText(iItem, hProto))
			m_cListNetStat.InsertItem(iItem, "TCP");
			
			//print info for locals
			strText.Format(TEXT("%d"), dwPid);
			m_cListNetStat.SetItemText(iItem, hPid, strText);
						
			//proc icon
			//LVITEM item;
			item.mask = LVIF_TEXT | LVIF_IMAGE;
			item.iItem = iItem;
			item.iSubItem = hProto; //hProcessName;
			item.pszText = "TCP"; //to be ignored
			int iIcoIndex = -1;
			iIcoIndex = GetProcessIcon(strProcName, m_pTcp->GetProcPath(dwPid));
			item.iImage = iIcoIndex;
			m_cListNetStat.SetItem(&item);
			strText.Format(TEXT("%s"), strProcName);
			m_cListNetStat.SetItemText(iItem, hProcessName, strText);

			strText.Format(TEXT("%s"), strLocAddress);
			m_cListNetStat.SetItemText(iItem, hLocalAddress, strText);

			strText.Format(TEXT("%u"), usLocalPort);
			m_cListNetStat.SetItemText(iItem, hLocalPort, strText);

			//print info for remote
			strText.Format(TEXT("%s"), strRemAddress);
			m_cListNetStat.SetItemText(iItem,hRemoteAddress, strText);

			//print info for state
			strText.Format(TEXT("%s"), m_pTcp->Convert2State(m_pTcp->m_pBuffTcpTableEx->table[iItem].dwState));
			m_cListNetStat.SetItemText(iItem,hState, strText);

			if (m_pTcp->m_pBuffTcpTableEx->table[iItem].dwState == MIB_TCP_STATE_ESTAB)
			{
				strText.Format(TEXT("%u"), usRemotePort);
				m_cListNetStat.SetItemText(iItem, hRemotePort, strText);
			}
			else
			{
				strText = "-";
				m_cListNetStat.SetItemText(iItem, hRemotePort, strText);			
			}
	}
	return  iItem;
}
void CFireAlarmNetStat::InitListUdpInfo(DWORD next)
{
	CString strText(L"");
	DWORD	iItem=next;
	LVITEM  item;

		/**********************Get UDP info**********************/
	in_addr _stAddr;
	char	_strLocAddress[16];
	u_long	_ulLocalAddress = 0;
	u_short _usLocalPort = 0;
	DWORD	_dwPid = 0;
	CString _strProcName (L"");
	int		_iSubItem = 1;
	
	//fill buffer
	m_pUdp->GetTableEx();

	//print the info
	for (DWORD _iItem = 0; _iItem < m_pUdp->m_pBuffUdpTableEx->dwNumEntries; _iItem++)
	{
		//prepare the local address field
		_ulLocalAddress = static_cast<u_long>(m_pUdp->m_pBuffUdpTableEx->table[_iItem].dwLocalAddr);
		_stAddr.s_addr = _ulLocalAddress;
		strcpy(_strLocAddress, inet_ntoa(_stAddr));

		//prepare the local port field
		_usLocalPort = ntohs(static_cast<u_short>(m_pUdp->m_pBuffUdpTableEx->table[_iItem].dwLocalPort));

		//prepare the Pid
		_dwPid = m_pUdp->m_pBuffUdpTableEx->table[_iItem].dwProcessId;

		_strProcName = m_pUdp->GetProcById(m_pUdp->m_pBuffUdpTableEx->table[_iItem].dwProcessId);

		//print UDP info
		if ("UDP" != m_cListNetStat.GetItemText(iItem, hProto))
		m_cListNetStat.InsertItem(iItem, "UDP");

		//print info for locals
		strText.Format(TEXT("%d"), _dwPid);
		m_cListNetStat.SetItemText(iItem,hPid, strText);

		//proc icon
		//LVITEM item;
		item.mask = LVIF_TEXT | LVIF_IMAGE;
		item.iItem = iItem;
		item.iSubItem = hProto;//hProcessName;
		item.pszText = "UDP"; //to be ignored
		int _iIcoIndex = GetProcessIcon(_strProcName, m_pTcp->GetProcPath(_dwPid));
		item.iImage = _iIcoIndex;
		m_cListNetStat.SetItem(&item);
		strText.Format(TEXT("%s"), _strProcName);
		m_cListNetStat.SetItemText(iItem, hProcessName, strText);

		strText.Format(TEXT("%s"), _strLocAddress);
		m_cListNetStat.SetItemText(iItem,hLocalAddress, strText);

		strText.Format(TEXT("%u"), _usLocalPort);
		m_cListNetStat.SetItemText(iItem,hLocalPort, strText);


		//print info for remote
		m_cListNetStat.SetItemText(iItem,hRemoteAddress, "-");
		m_cListNetStat.SetItemText(iItem,hRemotePort, "-");

		
		//print info for state
		m_cListNetStat.SetItemText(iItem,hState, "-");

		iItem++;
	}

}
void CFireAlarmNetStat::InitListAll()
{
	DWORD	next;
	//clean list
	m_cListNetStat.SetRedraw(FALSE);
	m_cListNetStat.DeleteAllItems();


	if (m_eConnView == TCP)
	{
		next=InitListTcpInfo();
		m_cListNetStat.SetRedraw(TRUE);
		return;
	}else if(m_eConnView == UDP)
	{
		InitListUdpInfo(0);
		m_cListNetStat.SetRedraw(TRUE);
		return;
	}
	next=InitListTcpInfo();
	InitListUdpInfo(next);

	m_cListNetStat.SetRedraw(TRUE);
}

void CFireAlarmNetStat::OnSelchangeComborefresh() 
{
	UpdateData();
	
	
	SuspendThread(m_hndThUser); //suspend thread
	switch(m_cRefreshCombo.GetCurSel())
	{
	case 0: ms_dwUpdateTime	= 1*1000; //update cycle time 
			break;
	case 1: ms_dwUpdateTime	= 5*1000; //update cycle time 
			break;
	case 2: ms_dwUpdateTime	= 10*1000; //update cycle time 
			break;
	case 3: ms_dwUpdateTime	= 20*1000; //update cycle time 
			break;
	case 4: ms_dwUpdateTime	= 60*1000; //update cycle time 
			break;
	};
	ResumeThread(m_hndThUser);	//resume thread

	InitListAll();
}

void CFireAlarmNetStat::OnButtonrefresh() 
{
	UpdateData();
	InitListAll();
}

LRESULT CFireAlarmNetStat::OnUpdateList(WPARAM wParam, LPARAM lParam)
{
	UpdateData();
	InitListAll();	
	return 1;
}
LRESULT CFireAlarmNetStat::OnTcpNewConnMsg(WPARAM wParam, LPARAM lParam)
{
	return DetectNewConn();
}
void CFireAlarmNetStat::InitCriticalSection()
{
	CString strLogEvent(L"EnetstatLogEvent");

	//create event for log
	m_hndLogConnEvent = ::CreateEvent(NULL, FALSE, TRUE, strLogEvent);

	//autoupdate 
	m_hndTh = ::CreateThread(NULL, 0, LogConn_ThreadProc, this->m_hWnd, THREAD_SUSPEND_RESUME, NULL);

	//user update 
	m_hndThUser = ::CreateThread(NULL, 0, LogConn_ThreadProcUser, this->m_hWnd, THREAD_SUSPEND_RESUME, NULL);	

}

bool CFireAlarmNetStat::DetectNewConn()
{
	// let's ask some privacy
	__CriticalSection__.Lock();

	TCPTABLE	sTcpTable;
	in_addr		stAddr;
	DWORD		dwRez		= 0;

	// init tcp table
	if (m_pTcp == NULL) return false;
	if (NO_ERROR != (dwRez = m_pTcp->GetTableEx()))	return false;
		
	/**********************Get TCP info**********************/
	for (DWORD i = 0; i < m_pTcp->GetNumberOfEntries(); i++)
	{
		stAddr.s_addr				 = static_cast<u_long>(m_pTcp->GetLocalAddress(i));
		sTcpTable.strLocalAddress	 = inet_ntoa(stAddr);
		sTcpTable.ulLocalPort		 = ntohs(static_cast<u_short>(m_pTcp->GetLocalPort(i)));
		stAddr.s_addr				 = static_cast<u_long>(m_pTcp->GetRemoteAddress(i));
		sTcpTable.strRemoteAddress	 = inet_ntoa(stAddr);
		sTcpTable.ulRemotePort		 = ntohs(static_cast<u_short>(m_pTcp->GetRemotePort(i)));
		sTcpTable.dwPid				 = m_pTcp->GetProcessId(i);
		sTcpTable.strProcessName	 = m_pTcp->GetProcById(sTcpTable.dwPid);
		sTcpTable.strConnectionState = m_pTcp->Convert2State(m_pTcp->GetElement(i).dwState);

		//check present conn state
		if (sTcpTable.strConnectionState == "ESTABLISHED")
		{
			CString strLP(L"");
			CString strRP(L"");
			TCPTABLE sTcpTableOut;
			
			//is there already stored this outgoing connection?
 			if (0 == m_MapNewTcpConn.Lookup(sTcpTable.ulLocalPort, sTcpTableOut))
			{
				//can happen on any local port allocated by the OS(it will be random allocated)
				//new outgoing conn
				m_MapNewTcpConn.SetAt(sTcpTable.ulLocalPort, sTcpTable);
				
				//tooltip info
				strLP.Format(TEXT("%u"), sTcpTable.ulLocalPort);
				strRP.Format(TEXT("%u"), sTcpTable.ulRemotePort);

				m_ctrlTaskBarOut.Show("\n\n\n OUT remote address: " + sTcpTable.strRemoteAddress + \
								      "\n on remote port: " + strRP + \
								      "\n process: " + sTcpTable.strProcessName);
				UpdateData();
				InitListAll();
				return true;
			}

			else //if state has changed (be aware the connection already exist in the map)
			{					
				if ((sTcpTableOut.strConnectionState != sTcpTable.strConnectionState) || \
					(sTcpTableOut.strRemoteAddress != sTcpTable.strRemoteAddress))
				{
					//update conn
					m_MapNewTcpConn.SetAt(sTcpTable.ulLocalPort, sTcpTable);
					
					//tooltip info
					strLP.Format(TEXT("%u"), sTcpTable.ulLocalPort);
					strRP.Format(TEXT("%u"), sTcpTable.ulRemotePort);
					m_ctrlTaskBarIn.Show("\n\n\n IN remote address: " + sTcpTable.strRemoteAddress + \
									     "\n on local port: " + strLP + \
								         "\n process: " + sTcpTable.strProcessName);
					UpdateData();
					InitListAll();
					return true;
				}
			}
		}
	}

	return false;

	__CriticalSection__.Unlock();
}

void CFireAlarmNetStat::OnSelchangeComboview() 
{
	// TODO: Add your control notification handler code here
	switch(m_cView.GetCurSel())
	{
	case 0:
		m_eConnView = viewAll;
		break;
	case 1:
		m_eConnView = TCP;
		break;
	case 2:
		m_eConnView = UDP;
	}
	UpdateData();
	InitListAll();
}

void CFireAlarmNetStat::OnRclickListnetstat(NMHDR* pNMHDR, LRESULT* pResult) 
{
	//*****************************************************************
	//Get selected Item
	int nItem = -1;
	POSITION pos = m_cListNetStat.GetFirstSelectedItemPosition();
	if (pos == NULL) TRACE("No items were selected!\n");
	else
	{
	   while (pos)
	   {
		  nItem = m_cListNetStat.GetNextSelectedItem(pos);
		  TRACE1("Item %d was selected!\n", nItem);
	   }
	}

	if(nItem == -1) //if not selected 
	{
		m_bar.SetPaneText(0, "Please select the item first and then choose the operation ...");
		return;
	}
	else 
	{
		m_nItemMain = nItem;
	}

	//*****************************************************************
	//Load Pop-Up Menu
	POINT point = {0,0};
	::GetCursorPos(&point);

	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MENU_SYSCONN));

	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);

	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);

	*pResult = 0;
}

void CFireAlarmNetStat::OnSysKillprocess() 
{
	CString strPid = m_cListNetStat.GetItemText(m_nItemMain, hPid);

	//query exit code
	HANDLE hndProc = ::OpenProcess(
			PROCESS_QUERY_INFORMATION,
			FALSE,
			static_cast<DWORD>(atoi(strPid)));
	if(hndProc == NULL)
	{
		m_bar.SetPaneText(0,"Error openning process in order to kill it ...");
		return;
	}

	DWORD dwExitCode = 0;
	if (FALSE == GetExitCodeProcess(hndProc, &dwExitCode))
	{
		m_bar.SetPaneText(0,"Error getting exit code in order to kill it ...");
		return;
	}

	//terminate process
	hndProc = ::OpenProcess(
			PROCESS_TERMINATE,
			FALSE,
			static_cast<DWORD>(atoi(strPid)));
	if(hndProc == NULL)
	{
		m_bar.SetPaneText(0,"Error opening process in order to kill it ...");
		return;
	}

	if (FALSE == TerminateProcess(hndProc, dwExitCode))
	{
		m_bar.SetPaneText(0,"Error terminating process ...");
		return;
	}
	
	CloseHandle(hndProc);
	InitListAll();
	
}

void CFireAlarmNetStat::OnSysCloseconnection() 
{
	MIB_TCPROW sKillConn;

	sKillConn.dwState	   = MIB_TCP_STATE_DELETE_TCB;
	sKillConn.dwLocalAddr  = (DWORD)inet_addr((LPCSTR)m_cListNetStat.GetItemText(m_nItemMain, hLocalAddress));
	sKillConn.dwRemoteAddr = (DWORD)inet_addr((LPCSTR)m_cListNetStat.GetItemText(m_nItemMain, hRemoteAddress));
	
	CString strLP		   = m_cListNetStat.GetItemText(m_nItemMain, hLocalPort);
	sKillConn.dwLocalPort  = (DWORD)htons((u_short)atoi(strLP.GetBuffer(strLP.GetLength())));
	//sKillConn.dwLocalPort  = strtod((LPCSTR)strLP, (LPSTR*)&strLP);

	CString strRP		   = m_cListNetStat.GetItemText(m_nItemMain, hRemotePort);
	sKillConn.dwRemotePort = (DWORD)htons((u_short)atoi(strRP.GetBuffer(strRP.GetLength())));
	//sKillConn.dwRemotePort = strtod((LPCSTR)strRP, (LPSTR*)&strRP);
	
	DWORD dwRez = SetTcpEntry(&sKillConn);
	if(dwRez != NO_ERROR)
	{
		dwRez = ::GetLastError();
		m_bar.SetPaneText(0,"Error closing connection ;(");
		TRACE("\nError closing connection ;(\n");
		return;
	}
	
	InitListAll();
	m_bar.SetPaneText(0,"Success closing connection ;)");
	TRACE("\nSuccess closing connection ;(\n");
	
}


