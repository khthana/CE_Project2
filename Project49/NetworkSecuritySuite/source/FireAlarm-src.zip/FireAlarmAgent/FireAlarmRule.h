#if !defined(AFX_FIREALARMRULE_H__56E58BDF_B5F6_481E_B796_28D3FF68D0FF__INCLUDED_)
#define AFX_FIREALARMRULE_H__56E58BDF_B5F6_481E_B796_28D3FF68D0FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireAlarmRule.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FireAlarmRule dialog
#include "RuleManage.h"
#include "PacketFilter.h"
#include "sockUtil.h"
class FireAlarmRule : public CDialog
{
// Construction
public:
	FireAlarmRule(CWnd* pParent = NULL);   // standard constructor

	void UpdateUserRuleList();
	CRuleManage* ruleUser;

// Dialog Data
	//{{AFX_DATA(FireAlarmRule)
	enum { IDD = IDD_FIREALARMRULE };
	CListCtrl	m_cListRule;
	CString	m_sIpAddress;
	CString	m_sNumberOfRules;
	CString	m_sUserName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FireAlarmRule)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CString GetUser();
	void AddUserRuleToList(	unsigned long srcIp, 
								unsigned long srcMask,
								unsigned short srcPort, 
								unsigned long dstIp, 
								unsigned long dstMask,
								unsigned short dstPort, 
								unsigned int protocol, 
								int action 
							);
	// Generated message map functions
	//{{AFX_MSG(FireAlarmRule)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMRULE_H__56E58BDF_B5F6_481E_B796_28D3FF68D0FF__INCLUDED_)
