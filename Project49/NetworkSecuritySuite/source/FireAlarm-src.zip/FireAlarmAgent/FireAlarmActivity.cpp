// FireAlarmActivity.cpp : implementation file
//
#include "windows.h"
#include "stdafx.h"
#include "FireAlarm.h"
#include "FireAlarmActivity.h"
#include "sockutil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "Sniff.h"
#include "Analysis.h"

CAnalysis AnalyPacket;
CSniff Sniffer;
BOOL StatusStop = TRUE;

CString allRule;
CString allIntrusion;
CString o_allIntrusion;
//Pipe Define
#define g_szPipeName "\\\\.\\Pipe\\MyNamedPipe"  //Name given to the pipe
#define g_alarmcheck "\\\\.\\Pipe\\AlarmCheckPipe"
#define g_szPipeNameIntru "\\\\.\\Pipe\\MyNamedPipeIntru"
//Pipe name format - \\servername\pipe\pipename
//This pipe is for server on the same computer, however, pipes can be used to
//connect to a remote server

#define BUFFER_SIZE 1024 //1k
#define ACK_MESG_RECV "Message received successfully"

/////////////////////////////////////////////////////
//////// IDS SECTION
#define TIME_ELAP 1000 // Time out value in milliseconds
/////////////////////////////////////////////////
//////  IDS CAPTURE PACKET FUNCTION
UINT Thread_Analysis(LPVOID pParam)
{	
	CString T_Type,T_Src,T_Dst,T_Time;
	while((!StatusStop))
	{
		Header_Packet Packet;
		if (Sniffer.GetPacket(Packet))		//Get Packet From Buffer
		{
			if (AnalyPacket.Check(Packet))
			{
				Sniffer.ClearSniff();
			}
		}
		else
			Sleep(1);
	}
	return 0;
}

UINT Thread_Sniff(LPVOID pParam)
{
	while((!StatusStop))
	{
		Sniffer.PacketFromDevice();
	}
	return 0;
}

void alarmCheck()
{	 FILE *fp=NULL;
     HANDLE hPipe;
	 char buff[8];
  	 char *strfp;

     //Connect to the server pipe using CreateFile()
     hPipe = CreateFile( 
          g_alarmcheck,   // pipe name 
          GENERIC_READ ,  // read and write access 
          //GENERIC_WRITE, 
          0,              // no sharing 
          NULL,           // default security attributes
          OPEN_EXISTING,  // opens existing pipe 
          0,              // default attributes 
          NULL);          // no template file 
     
     if (INVALID_HANDLE_VALUE == hPipe) 
     {
          printf("\nError occurred while connecting to the server: %d", GetLastError()); 
     }
     else
     {
          printf("\nCreateFile() was successful.");
     }
     
     char szBuffer[BUFFER_SIZE];
     DWORD cbBytes;
     BOOL bResult = ReadFile( 
          hPipe,                // handle to pipe 
          szBuffer,             // buffer to receive data 
          sizeof(szBuffer),     // size of buffer 
          &cbBytes,             // number of bytes read 
          NULL);                // not overlapped I/O 
//    printf("\nServer sent the following message: %s", szBuffer);
	if(strcmp(szBuffer,"0")==0)
	{
		while(fp==NULL)
		{	fp = fopen("c:\\alarmcheck.dat","w");
			if(fp!=NULL)
			{	fprintf(fp,"1");
				fclose(fp);
			}
		}
	}
    CloseHandle(hPipe);

    hPipe = CreateFile( 
          g_alarmcheck,   // pipe name 
          GENERIC_READ ,  // read and write access 
          //GENERIC_WRITE, 
          0,              // no sharing 
          NULL,           // default security attributes
          OPEN_EXISTING,  // opens existing pipe 
          0,              // default attributes 
          NULL);          // no template file 
     
     if (INVALID_HANDLE_VALUE == hPipe) 
     {
          printf("\nError occurred while connecting to the server: %d", GetLastError()); 
     }
     else
     {
          printf("\nCreateFile() was successful.");
     }
     
	BOOL a_Result = ReadFile( 
          hPipe,                // handle to pipe 
          szBuffer,             // buffer to receive data 
          sizeof(szBuffer),     // size of buffer 
          &cbBytes,             // number of bytes read 
          NULL);                // not overlapped I/O 
    CloseHandle(hPipe);
	fp = NULL;
	while(fp==NULL)
	{	while(strcmp(szBuffer,"2")!=0){
			fp = fopen("c:\\alarmcheck.dat","r");
			if(fp!=NULL)
			{	strfp = fgets(buff,8,fp);
				strcpy(szBuffer,strfp);
				fclose(fp);
		//		AfxMessageBox(szBuffer);

			}
		}
	}

	fp = NULL;
	while(fp==NULL)
	{	fp = fopen("c:\\alarmcheck.dat","w");
		if(fp!=NULL)
		{	fprintf(fp,"0");
			fclose(fp);
		}
	}
//	AfxMessageBox(szBuffer);
	for(int a=1;a<30000;a++)
	{	printf("");
		for(int b=1;b<3000;b++)
		{printf("");
		}
	}
}

void readIntrusion()
{
     HANDLE hPipeIntru;

     //Connect to the server pipe using CreateFile()
     hPipeIntru = CreateFile( 
          g_szPipeNameIntru,   // pipe name 
          GENERIC_READ ,  // read and write access 
          //GENERIC_WRITE, 
          0,              // no sharing 
          NULL,           // default security attributes
          OPEN_EXISTING,  // opens existing pipe 
          0,              // default attributes 
          NULL);          // no template file 
     
     if (INVALID_HANDLE_VALUE == hPipeIntru) 
     {
          printf("\nError occurred while connecting to the server: %d", GetLastError()); 
     }
     else
     {
          printf("\nCreateFile() was successful.");
     }
     
     char szBuffer[5000];
     DWORD cbBytes;
     BOOL bResult = ReadFile( 
          hPipeIntru,                // handle to pipe 
          szBuffer,             // buffer to receive data 
          sizeof(szBuffer),     // size of buffer 
          &cbBytes,             // number of bytes read 
          NULL);                // not overlapped I/O 
    printf("\nServer sent the following message: %s", szBuffer);
	allIntrusion = szBuffer;
//	AfxMessageBox(allIntrusion+"gp");
    CloseHandle(hPipeIntru);
}

BOOL readPipe()
{
     HANDLE hPipe;

     //Connect to the server pipe using CreateFile()
     hPipe = CreateFile( 
          g_szPipeName,   // pipe name 
          GENERIC_READ ,  // read and write access 
          //GENERIC_WRITE, 
          0,              // no sharing 
          NULL,           // default security attributes
          OPEN_EXISTING,  // opens existing pipe 
          0,              // default attributes 
          NULL);          // no template file 
     
     if (INVALID_HANDLE_VALUE == hPipe) 
     {	  return FALSE; 	
          //printf("\nError occurred while connecting to the server"); 
     }
     
     char szBuffer[BUFFER_SIZE];
     DWORD cbBytes;
     BOOL bResult = ReadFile( 
          hPipe,                // handle to pipe 
          szBuffer,             // buffer to receive data 
          sizeof(szBuffer),     // size of buffer 
          &cbBytes,             // number of bytes read 
          NULL);                // not overlapped I/O 
    printf("\nServer sent the following message: %s", szBuffer);
	allRule = szBuffer;
//	AfxMessageBox(allRule);
    CloseHandle(hPipe);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// FireAlarmActivity dialog


FireAlarmActivity::FireAlarmActivity(CWnd* pParent /*=NULL*/)
	: CDialog(FireAlarmActivity::IDD, pParent)
{
	//{{AFX_DATA_INIT(FireAlarmActivity)
	m_sUserName = _T("");
	m_sIPAddr = _T("");
	m_sTotalRules = _T("");
	//}}AFX_DATA_INIT
}


void FireAlarmActivity::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FireAlarmActivity)
	DDX_Control(pDX, IDC_LISTGROUP, m_cListGroup);
	DDX_Control(pDX, IDC_LISTACTIVITY, m_cListActivity);
	DDX_Text(pDX, IDC_USERNAME, m_sUserName);
	DDX_Text(pDX, IDC_IPADDR, m_sIPAddr);
	DDX_Text(pDX, IDC_TOTALRULES, m_sTotalRules);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FireAlarmActivity, CDialog)
	//{{AFX_MSG_MAP(FireAlarmActivity)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FireAlarmActivity message handlers

BOOL FireAlarmActivity::OnInitDialog() 
{
	CDialog::OnInitDialog();
//	alarmCheck();
	while(!readPipe())
	{Sleep(15000);}

/*	ipFltDrv.LoadDriver("IpFilterDriver", "System32\\Drivers\\IpFltDrv.sys", NULL, TRUE);
	ipFltDrv.SetRemovable(FALSE);
	
	//Load Filter Driver //For windows Service put DrvFltIp.sys in windows directory
	if(filterDriver.LoadDriver("DrvFltIp","System32\\Drivers\\DrvFltIp.sys",NULL, TRUE) != DRV_SUCCESS)
	{
		AfxMessageBox("Error loading the driver.");
		AfxMessageBox("GOpgop");
		exit(-1);
	}
*/
	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 15;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_ACT1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_ACT2);
	Static2->SetFont(F1,TRUE);
	CFont *F2 = new CFont();
	LOGFONT lf2 = {0};
    _tcscpy(lf2.lfFaceName, _T("Arial"));
    lf2.lfHeight = 14;
    lf2.lfWeight = FW_BOLD;
    F2->CreateFontIndirect(&lf2);
	CStatic *Static3 = (CStatic*) GetDlgItem(IDC_STATIC_ACT3);
	Static3->SetFont(F2,TRUE);
	CStatic *Static4 = (CStatic*) GetDlgItem(IDC_STATIC_ACT4);
	Static4->SetFont(F2,TRUE);
	CStatic *Static5 = (CStatic*) GetDlgItem(IDC_STATIC_ACT5);
	Static5->SetFont(F2,TRUE);

	ruleFilter	= new CRuleManage();
	ruleUser	= new CRuleManage();
	
// Get information to variable
	int u_pos = allRule.Find("__USERNAME__");
	CString tmp_sname = allRule.Left(u_pos);
	allRule.Delete(0,u_pos+12);
//	AfxMessageBox(tmp_sname);
	sUserName = tmp_sname;
	sUserDN = GetUserDN();

	m_sUserName = " "+sUserName;
	m_sIPAddr.Format(" %s",ruleUser->GetClientIP());
	if(sUserDN!=" "){
		ListMemberOf();
		AddGroupRule();
		StartFilter();
		m_cListActivity.AddString("# Firewall Started ...");	
		OnStart();
	}
	if(ruleUser->nRules>1){
		m_sTotalRules.Format(" %d Rules",ruleUser->nRules);
	}else{
		m_sTotalRules.Format(" %d Rule",ruleUser->nRules);
	}
//	MessageBox(saADGroup.GetAt(0),NULL,MB_OK);
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
HANDLE GetHandleExplorer()
{
	HANDLE hProcess;
	// Get the list of process identifiers.

	DWORD aProcesses[1024], cbNeeded, cProcesses;
	unsigned int i;

	if ( !EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded ) )
		return 0;

	// Calculate how many process identifiers were returned.

	cProcesses = cbNeeded / sizeof(DWORD);

	// Print the name and process identifier for each process.

	for ( i = 0; i < cProcesses; i++ )
	{
		TCHAR szProcessName[MAX_PATH] = TEXT("<unknown>");
		TCHAR ProcessName[MAX_PATH] = TEXT("Explorer.EXE");

		// Get a handle to the process.

		hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
									   PROCESS_VM_READ,
									   FALSE, aProcesses[i] );

		// Get the process name.

		if (NULL != hProcess )
		{
			HMODULE hMod;
			DWORD cbNeeded;

			if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), 
				 &cbNeeded) )
			{
				GetModuleBaseName( hProcess, hMod, szProcessName, 
								   sizeof(szProcessName)/sizeof(TCHAR) );
			}
		}
		
		if(_tcscmp(szProcessName,ProcessName) == 0){
			return hProcess;
		}

	}

	CloseHandle( hProcess );
	return hProcess;


}

CString GetLoginUser()
{
	HANDLE explorer = GetHandleExplorer();
	HANDLE t_handle;
	
	DWORD lenght;
	TOKEN_OWNER* pOwner = NULL;
	if (!OpenProcessToken(explorer,TOKEN_QUERY,&t_handle))
	{	printf("OpenProcessToken() failed (error code = %d)",GetLastError());
	}
	GetTokenInformation(t_handle,TokenOwner,pOwner,0, &lenght);
	pOwner = (TOKEN_OWNER*) new char[lenght];
	if (GetTokenInformation(t_handle, TokenOwner, pOwner, lenght, &lenght)== 0)
	{	printf("GetTokenInformation() failed (error code = %d)",GetLastError());
	}
	TCHAR bufName[MAX_PATH];
	TCHAR bufDomain[MAX_PATH];
	SID_NAME_USE SidNameUse;
	DWORD dwCbName = 0;
	DWORD dwCbDomainName = 0;
	dwCbName = sizeof(bufName);
	dwCbDomainName = sizeof(bufDomain);
	LookupAccountSid(NULL, pOwner->Owner, bufName, &dwCbName, bufDomain, &dwCbDomainName, &SidNameUse);
	CString tmp(bufName);
	return tmp;
}
CString FireAlarmActivity::GetUser(){
	return GetLoginUser();
}
CString FireAlarmActivity::GetUserDN(){
	CStringArray uDistinguishedName;
	CStringArray uName;
	
	if (ADCon.GetList("user",uName,uDistinguishedName) != TRUE)
	{
	//	m_cListLog.AddString("# Can't get domain...!!!");
		return " ";
	}

	CString UserDomain;	
	for(int i=0;i<uDistinguishedName.GetSize();i++){
		if(sUserName==uName.GetAt(i)){
			UserDomain = uDistinguishedName.GetAt(i);
		//	MessageBox(UserDomain,NULL,MB_OK);
		}
	}
	return UserDomain;
}

void FireAlarmActivity::ListMemberOf(){

	CString TmpMo;

	int g_pos;
	while(allRule.Find("__GROUP__") != -1){
	g_pos = allRule.Find("__GROUP__");
	CString tmp_group = allRule.Left(g_pos);
	allRule.Delete(0,g_pos+9);
//	AfxMessageBox(tmp_group+"ZZ");
	saADGroup.Add(tmp_group);
	}

	int iFWGroupAll = saADGroup.GetSize() -1;
//-- Error here ->> icount <=iFWGroupAll-5
	for(int icount = 0 ; icount <=iFWGroupAll ;icount++){
		TmpMo = saADGroup.GetAt(icount);
		//MessageBox(saADGroup.GetAt(icount),"test",MB_OK);
		m_cListGroup.AddString(TmpMo.Mid(3,TmpMo.Find(",")-3));
	}
	// All Group of User

	sGroup = TmpMo.Mid(3,TmpMo.Find(",")-3);
}

void FireAlarmActivity::AddGroupRule(){
	CStringArray saAllRule;

	int r_pos;
	while(allRule.GetLength()>=7){
	r_pos = allRule.Find("__END__");
	//AfxMessageBox(r_pos);
	CString tmp_rule = allRule.Left(r_pos);
	allRule.Delete(0,r_pos+7);
//	AfxMessageBox(tmp_rule+"ZZ");
	saAllRule.Add(tmp_rule);
	}

	for(int i =saAllRule.GetSize()-1 ;i >=0;i--){
	     	CString sLongRule = saAllRule.GetAt(i);

		// change long rule string to each variables
			CString tmpString;
			sLongRule.TrimLeft();	//removes newline, space, and tab characters
			sLongRule.TrimRight();	//removes newline, space, and tab characters

			for ( int j = 0; j<7; j++ ) 
			{
				int pos = sLongRule.Find(' ');
				tmpString = sLongRule.Left(pos);
				sLongRule.Delete(0, pos+1);

				switch(j)
				{
					case 0 :
						sSrcAddress = tmpString;
						break;
					case 1 :
						sSrcMask = tmpString;
						break;
					case 2 :
						sSrcPort = tmpString;
						break;
					case 3 :
						sDstAddress = tmpString;
						break;
					case 4 :
						sDstMask = tmpString;
						break;
					case 5 :
						sDstPort = tmpString;
						break;
					case 6 :
						sProtocol = tmpString;
						break;
				}

			}	

			sAction = sLongRule;
	
//	AfxMessageBox(sSrcAddress + "\n" + sSrcMask + "\n" + sSrcPort + "\n" + sDstAddress + "\n"
//					+ sDstMask + "\n" + sDstPort + "\n" + sProtocol + "\n" + sAction);
			int result;
			result = inet_addr(sSrcAddress, &srcIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid source address");
				return;
			}

			result = inet_addr(sSrcMask, &srcMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid source mask");
				return;
			}

			result = inet_addr(sDstAddress, &dstIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination address");
				return;
			}

			result = inet_addr(sDstMask, &dstMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination mask");
				return;
			}
	
			if(sProtocol == "TCP")
				protocol = 6;
			else if(sProtocol == "UDP")
				protocol = 17;
			else if(sProtocol == "ICMP")
				protocol = 1;
			else
				protocol = 0;
			
			if(sAction == "")
			{
				AfxMessageBox("Please, fill action field.");
				return;
			}
			else
			{
				if(sAction == "ALLOW")
					iAction = 0;
				else
					iAction = 1;

				if (i == 0)
					iDefaultAction = iAction;
			}

			srcPort = atoi(sSrcPort);
			dstPort = atoi(sDstPort);

		// check number of rules
			if(ruleUser->nRules < MAX_RULES )
			{
			// Add the rule to the rule lists			
				if(ruleUser->AddRule(	srcIp, 
								srcMask, 
								srcPort, 
								dstIp, 
								dstMask, 
								dstPort, 
								protocol, 
								iAction) != 0)
				AfxMessageBox("Error adding the rule.");
				else
				{
//					AfxMessageBox("Add rule OK");
				}
			}
	}
}
BOOL FireAlarmActivity::StartFilter(){

	return TRUE;
}
BOOL FireAlarmActivity::StopFilter(){
	if(filterDriver.WriteIo(STOP_IP_HOOK, NULL, 0) != DRV_SUCCESS)
	{
		AfxMessageBox("filterDriver.WriteIo Fail !!!");
		return FALSE;
	}
	return TRUE;
}
BOOL FireAlarmActivity::AddFilterToFw(unsigned long srcIp, unsigned long srcMask,
									  unsigned short srcPort, unsigned long dstIp,
									  unsigned long dstMask, unsigned short dstPort,
									  unsigned int protocol, int action)
{
	IPFilter pf;

	pf.protocol = protocol;

	pf.destinationIp = dstIp;			
	pf.sourceIp		 = srcIp;

	pf.destinationMask = dstMask;	
	pf.sourceMask	   = srcMask;		

	pf.destinationPort = htons(dstPort);						
	pf.sourcePort	   = htons(srcPort);				

	pf.drop = action;		
	
	// Send rule to the driver
	DWORD result = filterDriver.WriteIo(ADD_FILTER, &pf, sizeof(pf));

	if (result != DRV_SUCCESS) 
	{
		AfxMessageBox("Send rules to the driver !!!");
		return FALSE;
	}

	else
		return TRUE;
}
void FireAlarmActivity::OnStart()
{	
	if(Sniffer.GetStatusDirectPacket() == FALSE )
	{
		UpdateData(FALSE); 
		if(Sniffer.OpenDirectPacket(1))
		{
			//send number of Adapter to select capture
			SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=1000
			m_cListActivity.AddString("# Starting Intrusion Detection ...");

			m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

			UpdateData(FALSE);		//set variable to control
			StatusStop = FALSE;		//Flag Star Thread Function (initial Value True);

			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,GetSafeHwnd(),THREAD_PRIORITY_IDLE);

		}
	}
	else{
			SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=1000

			m_cListActivity.AddString("# Starting Intrusion Detection ...");
			m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

			UpdateData(FALSE); //set variable to control
			StatusStop = FALSE; //Flag Star Thread Function (initial Value True);

			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
	}

}

void FireAlarmActivity::OnStop()
{
	if(Sniffer.GetStatusDirectPacket() == TRUE)
	{
		KillTimer(1); //Kill Timer ID = 1
		StatusStop = TRUE;
		m_cListActivity.AddString("# Intrusion Detection has been stop!.");
		m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

		UpdateData(FALSE); //set variable to control

		Sniffer.ClearSniff();
		Sniffer.CloseDirectPacket();
	}
}
void FireAlarmActivity::OnTimer(UINT nIDEvent) 
{
	// Client Attacked.
	CString Type,Src,Dst,Time;
	if (AnalyPacket.GetResult(Type,Src,Dst,Time))
	{
		CTime t = CTime::GetCurrentTime();
		CString sSecond,sDay,sMonth,sYear,sDate;
		sSecond.Format("%d",t.GetSecond());
		sDay.Format("%d",t.GetDay());
		sMonth.Format("%d",t.GetMonth());
		sYear.Format("%d",t.GetYear());
		sDate = sDay+"/"+sMonth+"/"+sYear;

		Time += ":" + sSecond;
//		CString msg = "# Attacked from:"+Src+" , Type:"+Type+" , Date:"+sDate+" , Time:"+Time+" #";
		readPipe();
		readIntrusion();
		CString msg;
		int i_pos;
		if(o_allIntrusion=="")
		{	o_allIntrusion = allIntrusion;
		}
		if(strcmp(o_allIntrusion,allIntrusion)!=0)
		{	CString tmp_intru = allIntrusion;
//			AfxMessageBox("o_allIntrusion : "+o_allIntrusion);
			allIntrusion.Replace(o_allIntrusion,"");
			o_allIntrusion = tmp_intru;
		}

		while(allIntrusion.Find("__INTRUSION__")!= -1){
		i_pos = allIntrusion.Find("__INTRUSION__");
		//AfxMessageBox(i_pos);
		CString tmp_intru = allIntrusion.Left(i_pos);
		allIntrusion.Delete(0,i_pos+13);
		msg = tmp_intru;

		m_cListActivity.AddString(msg);		// Add message to log list
		m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);// Show last message in log list

		}
		

		CString sTmpLog = Type+","+Src+","+Dst+","+sDate+","+Time+","+sGroup+","+sUserName;
			
		m_cListActivity.SetHorizontalExtent(450);
		//MessageBox(sTmpLog,NULL,MB_OK);
		ADCon.SetNewLog(saADGroup.GetAt(0),sTmpLog);	// Add Log to AD
		//MessageBox("ADD to AD !!");
	}	
	CDialog::OnTimer(nIDEvent);
}
