// FireAlarmRule.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarm.h"
#include "FireAlarmRule.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FireAlarmRule dialog


FireAlarmRule::FireAlarmRule(CWnd* pParent /*=NULL*/)
	: CDialog(FireAlarmRule::IDD, pParent)
{
	//{{AFX_DATA_INIT(FireAlarmRule)
	m_sIpAddress = _T("");
	m_sNumberOfRules = _T("");
	m_sUserName = _T("");
	//}}AFX_DATA_INIT
}


void FireAlarmRule::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FireAlarmRule)
	DDX_Control(pDX, IDC_LISTRULE, m_cListRule);
	DDX_Text(pDX, IDC_IPADDRESS, m_sIpAddress);
	DDX_Text(pDX, IDC_NUMRULE, m_sNumberOfRules);
	DDX_Text(pDX, IDC_UNAME, m_sUserName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FireAlarmRule, CDialog)
	//{{AFX_MSG_MAP(FireAlarmRule)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FireAlarmRule message handlers

BOOL FireAlarmRule::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("MS Sans Serif"));
    lf.lfHeight = 14;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_R1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_R2);
	Static2->SetFont(F1,TRUE);
	CStatic *Static3 = (CStatic*) GetDlgItem(IDC_STATIC_R3);
	Static3->SetFont(F1,TRUE);



	m_cListRule.InsertColumn(1,"Source Address",LVCFMT_CENTER,87,1);
	m_cListRule.InsertColumn(2,"Source Mask"		,LVCFMT_CENTER,94,2);
	m_cListRule.InsertColumn(3,"Source Port"		,LVCFMT_CENTER,68,3);
	m_cListRule.InsertColumn(4,"Destination Address"  ,LVCFMT_CENTER,110,4);
	m_cListRule.InsertColumn(5,"Destination Mask",LVCFMT_CENTER,94,5);
	m_cListRule.InsertColumn(6,"Destination Port",LVCFMT_CENTER,94,6);
	m_cListRule.InsertColumn(7,"Protocol"		,LVCFMT_CENTER,51,7);
	m_cListRule.InsertColumn(8,"Action"			,LVCFMT_CENTER,50,8);

	m_cListRule.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);
	//Set Initial Mask Value 
	
	ruleUser = new CRuleManage();
	m_sIpAddress.Format(" %s",ruleUser->GetClientIP());
	m_sUserName= " "+GetUser();
	UpdateData(FALSE);	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void FireAlarmRule::UpdateUserRuleList(){
	
	m_cListRule.DeleteAllItems();

	unsigned int i;
	for(i=0;i<ruleUser->nRules;i++){
		AddUserRuleToList(ruleUser->rules[i].sourceIp,
						  ruleUser->rules[i].sourceMask,
						  ruleUser->rules[i].sourcePort,
						  ruleUser->rules[i].destinationIp,
						  ruleUser->rules[i].destinationMask,
						  ruleUser->rules[i].destinationPort,
						  ruleUser->rules[i].protocol,
						  ruleUser->rules[i].action);
	}
	m_sNumberOfRules.Format(" %d",ruleUser->nRules);
	UpdateData(FALSE);
}


void FireAlarmRule::AddUserRuleToList(unsigned long srcIp, 
										unsigned long srcMask,
										unsigned short srcPort, 
										unsigned long dstIp, 
										unsigned long dstMask,
										unsigned short dstPort, 
										unsigned int protocol, 
										int action)
{

	char ip[16];
	char port[6];
	LVITEM it;
	int pos;

	
	it.mask		= LVIF_TEXT;
	it.iItem	= m_cListRule.GetItemCount();
	it.iSubItem	= 0;
	it.pszText	= (srcIp == 0) ? "All" : IpToString(ip, srcIp);
	pos			= m_cListRule.InsertItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 1;
	it.pszText	= IpToString(ip, srcMask);
	m_cListRule.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 2;

	it.pszText	= (srcPort == 0) ? "All" : itoa(srcPort, port, 10);

	m_cListRule.SetItem(&it);
	
	it.iItem	= pos;
	it.iSubItem	= 3;
	it.pszText	= (dstIp == 0) ? "All" : IpToString(ip, dstIp);
	m_cListRule.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 4;
	it.pszText	= IpToString(ip, dstMask);
	m_cListRule.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem = 5;

	it.pszText	= (dstPort == 0) ? "All" : itoa(dstPort, port, 10);

	m_cListRule.SetItem(&it);


	it.iItem	= pos;
	it.iSubItem	= 6;

	if(protocol == 1)
		it.pszText = "ICMP";

	else if(protocol == 6)
		it.pszText = "TCP";

	else if(protocol == 17)
		it.pszText = "UDP";

	else
		it.pszText = "All";

	m_cListRule.SetItem(&it);


	it.iItem	= pos;
	it.iSubItem	= 7;
	it.pszText = action ? "Deny" : "Allow";
	m_cListRule.SetItem(&it);


}

CString FireAlarmRule::GetUser()
{
	char User[100];
	DWORD Len = sizeof(User);
	GetUserName(User, &Len);
	return User;

}
