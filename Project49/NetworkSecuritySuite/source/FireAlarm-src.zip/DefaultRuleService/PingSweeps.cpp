// PingSweeps.cpp: implementation of the PingSweeps class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "FirewallSuite.h"
#include "PingSweeps.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

PingSweeps::PingSweeps()
{

}
PingSweeps::~PingSweeps()
{

}
