// FireAlarmActivity.cpp : implementation file
//
#include "stdafx.h"
#include "FireAlarmActivity.h"
#include "sockutil.h"

#include "Include/psapi.h"
#include "Include/winBase.h"
#include "Include/windows.h"

#include <process.h>

//#include "ThreadIDS.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "Sniff.h"
#include "Analysis.h"
#include <process.h>

using namespace std;
CAnalysis AnalyPacket;
CSniff Sniffer;
BOOL StatusStop = TRUE;

CString g_sGroup,g_sUserName;
ADConnect g_ADCon;
CStringArray g_saADGroup;
#define BUFFER_SIZE 1024 //1k
//Pipe Define
#define defaultRule "\\\\.\\Pipe\\defaultRule"  //Name given to the pipe

/////////////////////////////////////////////////////
//////// IDS SECTION
#define TIME_ELAP 1000 // Time out value in milliseconds
/////////////////////////////////////////////////
//////  IDS CAPTURE PACKET FUNCTION
void Thread_Analysis(LPVOID pParam)
{	
	CString T_Type,T_Src,T_Dst,T_Time;
	while((!StatusStop))
	{	
		Header_Packet Packet;
		if (Sniffer.GetPacket(Packet))		//Get Packet From Buffer
		{	//cout << "Analysis" <<endl;
			if (AnalyPacket.Check(Packet))
			{
				Sniffer.ClearSniff();
			}
		}
		else
			Sleep(1);
	}
//	return 0;
}

void Thread_Sniff(LPVOID pParam)
{	cout << "Running Thread !!" << endl;
	while((!StatusStop))
	{	cout <<"Sniff" <<endl;
		Sniffer.PacketFromDevice();
	}
//	return 0;
}

void Thread_Intrusion(LPVOID pParam)
{	
	CString Type,Src,Dst,Time;
	while((!StatusStop))
	{	cout << "Intrusion Detecting" << endl;
		if (AnalyPacket.GetResult(Type,Src,Dst,Time))
		{
			CTime t = CTime::GetCurrentTime();
			CString sSecond,sDay,sMonth,sYear,sDate;
			sSecond.Format("%d",t.GetSecond());
			sDay.Format("%d",t.GetDay());
			sMonth.Format("%d",t.GetMonth());
			sYear.Format("%d",t.GetYear());
			sDate = sDay+"/"+sMonth+"/"+sYear;

			Time += ":" + sSecond;
			CString msg = "# Attacked from:"+Src+" , Type:"+Type+" , Date:"+sDate+" , Time:"+Time+" #";
			//m_cListActivity.AddString(msg);							// Add message to log list
			//m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);		// Show last message in log list

			CString sTmpLog = Type+","+Src+","+Dst+","+sDate+","+Time+","+ g_sGroup+","+ g_sUserName;
			//m_cListActivity.SetHorizontalExtent(450);
			//MessageBox(sTmpLog,NULL,MB_OK);
			//cout << "Log : " + sTmpLog << endl;
			g_ADCon.SetNewLog(g_saADGroup.GetAt(0),sTmpLog);	// Add Log to AD
			cout << "add Log to AD" << endl;
		}	
		else
			Sleep(1);
	}
}

/////////////////////////////////////////////////
//////  Get Login User
HANDLE GetHandleExplorer()
{
	HANDLE hProcess;
	// Get the list of process identifiers.

	DWORD aProcesses[1024], cbNeeded, cProcesses;
	unsigned int i;

	if ( !EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded ) )
		return 0;

	// Calculate how many process identifiers were returned.

	cProcesses = cbNeeded / sizeof(DWORD);

	// Print the name and process identifier for each process.

	for ( i = 0; i < cProcesses; i++ )
	{
		TCHAR szProcessName[MAX_PATH] = TEXT("<unknown>");
		TCHAR ProcessName[MAX_PATH] = TEXT("Explorer.EXE");

		// Get a handle to the process.

		hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
									   PROCESS_VM_READ,
									   FALSE, aProcesses[i] );

		// Get the process name.

		if (NULL != hProcess )
		{
			HMODULE hMod;
			DWORD cbNeeded;

			if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), 
				 &cbNeeded) )
			{
				GetModuleBaseName( hProcess, hMod, szProcessName, 
								   sizeof(szProcessName)/sizeof(TCHAR) );
			}
		}
		
		if(_tcscmp(szProcessName,ProcessName) == 0){
			return hProcess;
		}

	}
	printf("Close Handel Process");
	CloseHandle( hProcess );
	hProcess = NULL;
	return hProcess;
}

CString GetLoginUser()
{
	HANDLE explorer = GetHandleExplorer();
	if(explorer==NULL)
	{	return "SYSTEM";
	}
	HANDLE t_handle;
	
	DWORD lenght;
	TOKEN_OWNER* pOwner = NULL;
	if (!OpenProcessToken(explorer,TOKEN_QUERY,&t_handle))
		return GetLastError();
	GetTokenInformation(t_handle,TokenOwner,pOwner,0, &lenght);
	pOwner = (TOKEN_OWNER*) new char[lenght];
	if (GetTokenInformation(t_handle, TokenOwner, pOwner, lenght, &lenght)== 0)
	{
		printf("GetTokenInformation() failed (error code = %d)",GetLastError());
	}
	TCHAR bufName[MAX_PATH];
	TCHAR bufDomain[MAX_PATH];
	SID_NAME_USE SidNameUse;
	DWORD dwCbName = 0;
	DWORD dwCbDomainName = 0;
	dwCbName = sizeof(bufName);
	dwCbDomainName = sizeof(bufDomain);
	LookupAccountSid(NULL, pOwner->Owner, bufName, &dwCbName, bufDomain, &dwCbDomainName, &SidNameUse);
	CString tmp(bufName);
	return tmp;
}

FireAlarmActivity::FireAlarmActivity()
{	

	ruleFilter	= new CRuleManage();
	ruleUser	= new CRuleManage();
	
// Get information to variable
	sUserName = GetUser();
	g_sUserName = sUserName;
	sUserDN = GetUserDN();

	ipFltDrv.LoadDriver("IpFilterDriver", "System32\\Drivers\\IpFltDrv.sys", NULL, TRUE);
	ipFltDrv.SetRemovable(FALSE);
	
	//Load Filter Driver
	if(filterDriver.LoadDriver("DrvFltIp", "System32\\Drivers\\DrvFltIp.sys", NULL, TRUE) != DRV_SUCCESS)
	{
		AfxMessageBox("Error loading the driver.");
		AfxMessageBox("GOpgop");
		exit(-1);
	}

	if(sUserDN!=" "){
		ListMemberOf();
		AddGroupRule();
		StartFilter();
		cout << "# Firewall Started ..." << endl;	
//		OnStart();
	}
	

//TestTEst
//			CString nowuser22 = GetLoginUser();
//		FILE *s_user1=NULL;
//		s_user1 = fopen("c:\\checkuser.dat","w");
//		fprintf(s_user1,nowuser22);
//		fclose(s_user1);
///////////////////////////////////////////////////////////////
//	char szBuffer[BUFFER_SIZE];
//	DWORD cbBytes;
	char tt;
	cin >> tt;
	g_ADCon = ADCon;
//- Rule
//	if(ruleUser->nRules>1){
//		m_sTotalRules.Format(" %d Rules",ruleUser->nRules);
//	}else{
//		m_sTotalRules.Format(" %d Rule",ruleUser->nRules);
//	}

}

FireAlarmActivity::~FireAlarmActivity()
{	StopFilter();
	cout << "end "<< endl;
}

CString FireAlarmActivity::GetUser(){
	cout << "User : " << (LPCTSTR)GetLoginUser() << endl;
	return "default";
//	return GetLoginUser();
}

CString FireAlarmActivity::GetUserDN(){
	CStringArray uDistinguishedName;
	CStringArray uName;
	
	if (ADCon.GetList("user",uName,uDistinguishedName) != TRUE)
	{
	//	m_cListLog.AddString("# Can't get domain...!!!");
		cout << "Can't get domain !!" << endl;
		return " ";
	}

	CString UserDomain;	
	for(int i=0;i<uDistinguishedName.GetSize();i++){
		if(sUserName==uName.GetAt(i)){
			UserDomain = uDistinguishedName.GetAt(i);
		//	MessageBox(UserDomain,NULL,MB_OK);
		}
	}
	return UserDomain;
}

void FireAlarmActivity::ListMemberOf(){

	CString TmpMo;
	ADCon.GetMemberOf(sUserDN,saADGroup);
	g_saADGroup.Copy(saADGroup);
	int iFWGroupAll = saADGroup.GetSize() -1;
//-- Error here ->> icount <=iFWGroupAll-5
	for(int icount = 0 ; icount <=iFWGroupAll ;icount++){
		TmpMo = saADGroup.GetAt(icount);
	}
	// All Group of User
	sGroup = TmpMo.Mid(3,TmpMo.Find(",")-3);
	g_sGroup = sGroup;
}

void FireAlarmActivity::AddGroupRule(){
	int iGroupRule = 0;
//	int iRuleNumber ;
	bool bSameRule = false;
	CString sRuleIn,sRuleOut;
	CStringArray saAllRule;
	saADGroup.RemoveAll();
	ADCon.GetMemberOf(sUserDN,saADGroup);

	int iFWGroupAll = saADGroup.GetSize();
	saUserRule.RemoveAll();
	ADCon.GetRule(sUserDN,saUserRule);

	saGroupRule = new CStringArray[iFWGroupAll];
	for(int iCountGroup = 0 ; iCountGroup < iFWGroupAll ; iCountGroup++)
	{
		ADCon.GetRule(saADGroup.GetAt(iCountGroup),saGroupRule[iCountGroup]);
	}
	for(iCountGroup = 0 ; iCountGroup < iFWGroupAll ; iCountGroup++)
	{
		iGroupRule = saGroupRule[iCountGroup].GetSize();
		for( int i = 0 ; i < iGroupRule  ; i++)
		{
			
			for(int j = 0 ;j < iCountGroup;j++){
				int iRule=saGroupRule[j].GetSize();
				for(int x=0;x < iRule;x++){
					if(saGroupRule[iCountGroup].GetAt(i)==saGroupRule[j].GetAt(x)){
					//	MessageBox(saGroupRule[iCountGroup].GetAt(i),NULL,MB_OK);
						bSameRule = true;
						break;
					}	
				}
				if(bSameRule){
					break;
				}
			}
			if(!bSameRule){
				if(iGroupRule-i==2||iGroupRule-i==1){
					if(iGroupRule-i==2){
						sRuleOut= saGroupRule[iCountGroup].GetAt(i);
					}else{
						sRuleIn = saGroupRule[iCountGroup].GetAt(i);
					}
				}else{
					saAllRule.Add(saGroupRule[iCountGroup].GetAt(i));	
				}
			}
			bSameRule = false;
		}
	}

	if(saUserRule.GetSize()!=0){
		for(int i=saUserRule.GetSize()-1;i>=0;i--){
			saAllRule.Add(saUserRule.GetAt(i));
		}
	}
	saAllRule.Add(sRuleOut);
	saAllRule.Add(sRuleIn);
	for(int i =saAllRule.GetSize()-1 ;i >=0;i--){
	     	CString sLongRule = saAllRule.GetAt(i);

		// change long rule string to each variables
			CString tmpString;
			sLongRule.TrimLeft();	//removes newline, space, and tab characters
			sLongRule.TrimRight();	//removes newline, space, and tab characters

			for ( int j = 0; j<7; j++ ) 
			{
				int pos = sLongRule.Find(' ');
				tmpString = sLongRule.Left(pos);
				sLongRule.Delete(0, pos+1);

				switch(j)
				{
					case 0 :
						sSrcAddress = tmpString;
						break;
					case 1 :
						sSrcMask = tmpString;
						break;
					case 2 :
						sSrcPort = tmpString;
						break;
					case 3 :
						sDstAddress = tmpString;
						break;
					case 4 :
						sDstMask = tmpString;
						break;
					case 5 :
						sDstPort = tmpString;
						break;
					case 6 :
						sProtocol = tmpString;
						break;
				}

			}	

			sAction = sLongRule;
	
//	AfxMessageBox(sSrcAddress + "\n" + sSrcMask + "\n" + sSrcPort + "\n" + sDstAddress + "\n"
//					+ sDstMask + "\n" + sDstPort + "\n" + sProtocol + "\n" + sAction);
			int result;
			result = inet_addr(sSrcAddress, &srcIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid source address");
				return;
			}

			result = inet_addr(sSrcMask, &srcMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid source mask");
				return;
			}

			result = inet_addr(sDstAddress, &dstIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination address");
				return;
			}

			result = inet_addr(sDstMask, &dstMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination mask");
				return;
			}
	
			if(sProtocol == "TCP")
				protocol = 6;
			else if(sProtocol == "UDP")
				protocol = 17;
			else if(sProtocol == "ICMP")
				protocol = 1;
			else
				protocol = 0;
			
			if(sAction == "")
			{
				AfxMessageBox("Please, fill action field.");
				return;
			}
			else
			{
				if(sAction == "ALLOW")
					iAction = 0;
				else
					iAction = 1;

				if (i == 0)
					iDefaultAction = iAction;
			}

			srcPort = atoi(sSrcPort);
			dstPort = atoi(sDstPort);

		// check number of rules
			if(ruleUser->nRules < MAX_RULES )
			{
			// Add the rule to the rule lists			
				if(ruleUser->AddRule(	srcIp, 
								srcMask, 
								srcPort, 
								dstIp, 
								dstMask, 
								dstPort, 
								protocol, 
								iAction) != 0)
				AfxMessageBox("Error adding the rule.");
				else
				{	//cout << "Add rule OK !!" << endl;
//					AfxMessageBox("Add rule OK");
				}
			}
	}
}

BOOL FireAlarmActivity::StartFilter(){
	
	unsigned int i;

	if(filterDriver.WriteIo(START_IP_HOOK,NULL,0) != DRV_SUCCESS){
//		AfxMessageBox("filterDriver.WriteIo Fail !!!");
		cout << "filterDriver.WriteIo Fail !!!" << endl;
		return FALSE;
	}

	// Send all rules to the driver
	for(i = 0;i < ruleUser->nRules;i++)
	{	
		if (!AddFilterToFw(	ruleUser->rules[i].sourceIp, 
							ruleUser->rules[i].sourceMask,
							ruleUser->rules[i].sourcePort,
							ruleUser->rules[i].destinationIp,
							ruleUser->rules[i].destinationMask,
							ruleUser->rules[i].destinationPort,
							ruleUser->rules[i].protocol,
							ruleUser->rules[i].action))
		{
			cout << "Error adding all rules to driver !!!" << endl;
//			AfxMessageBox("Error adding all rules to driver !!!.");
			return FALSE;
		}
	}
	cout << " Filter Complete !!" << endl;
	return TRUE;
}

BOOL FireAlarmActivity::StopFilter(){
	cout << "Stop Filter !!";
	if(filterDriver.WriteIo(STOP_IP_HOOK, NULL, 0) != DRV_SUCCESS)
	{
		cout << "filterDriver.WriteIo Fail !!!" << endl;
		return FALSE;
	}
	return TRUE;
}

BOOL FireAlarmActivity::AddFilterToFw(unsigned long srcIp, unsigned long srcMask,
									  unsigned short srcPort, unsigned long dstIp,
									  unsigned long dstMask, unsigned short dstPort,
									  unsigned int protocol, int action)
{
	IPFilter pf;

	pf.protocol = protocol;

	pf.destinationIp = dstIp;			
	pf.sourceIp		 = srcIp;

	pf.destinationMask = dstMask;	
	pf.sourceMask	   = srcMask;		

	pf.destinationPort = htons(dstPort);						
	pf.sourcePort	   = htons(srcPort);				

	pf.drop = action;		
	
	// Send rule to the driver
	DWORD result = filterDriver.WriteIo(ADD_FILTER, &pf, sizeof(pf));

	if (result != DRV_SUCCESS) 
	{
		//AfxMessageBox("Send rules to the driver !!!");
		cout << "Send rules to the driver !!!" << endl;
		return FALSE;
	}

	else
		return TRUE;
}

void FireAlarmActivity::OnStart()
{	
	int temp;
	if(Sniffer.GetStatusDirectPacket() == FALSE )
	{
		if(Sniffer.OpenDirectPacket(1))
		{
			//send number of Adapter to select capture
			SetTimer(NULL,1,TIME_ELAP,NULL);//TIME_ELAP=1000
//			cout << "# Starting Intrusion Detection ..." << endl;

			StatusStop = FALSE;		//Flag Star Thread Function (initial Value True);

			if(_beginthread(Thread_Sniff, 0, NULL)==-1)
			{	cout << "Error begin Thread_Sniff !!" << endl;
			}
//			if(_beginthread(Thread_Analysis, 0, NULL)==-1)
//			{	cout << "Error begin Thread_Analysis !!" << endl;
//			}
//			if(_beginthread(Thread_Intrusion, 0, NULL)==-1)
//			{	cout << "Error begin Thread_Intrusion !!" << endl;
//			}
			cin >> temp ;
//			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,NULL,THREAD_PRIORITY_IDLE);
//			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,NULL,THREAD_PRIORITY_IDLE);
		}
	}
	else{
			SetTimer(NULL,1,TIME_ELAP,NULL);//TIME_ELAP=1000

//			cout << "# Starting Intrusion Detection ..." << endl;

			StatusStop = FALSE; //Flag Star Thread Function (initial Value True);

			if(_beginthread(Thread_Sniff, 0, NULL)==-1)
			{	cout << "Error begin Thread_Sniff !!" << endl;
			}
//			if(_beginthread(Thread_Analysis, 0, NULL)==-1)
//			{	cout << "Error begin Thread_Analysis !!" << endl;
//			}
//			if(_beginthread(Thread_Intrusion, 0, NULL)==-1)
//			{	cout << "Error begin Thread_Intrusion !!" << endl;
//			}

			cin >> temp ;

//			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,NULL,THREAD_PRIORITY_IDLE);
//			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,NULL,THREAD_PRIORITY_IDLE);
	}
	

}
/*
void FireAlarmActivity::OnStop()
{
	if(Sniffer.GetStatusDirectPacket() == TRUE)
	{
		KillTimer(1); //Kill Timer ID = 1
		StatusStop = TRUE;
		cout << "# Intrusion Detection has been stop!." << endl;
		//m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

		UpdateData(FALSE); //set variable to control
		Sniffer.ClearSniff();
		Sniffer.CloseDirectPacket();
	}
}
*/

