#if !defined(AFX_FIREALARMACTIVITY_H__FE9E1052_3D57_4A2F_B531_59F0EB4CD2B9__INCLUDED_)
#define AFX_FIREALARMACTIVITY_H__FE9E1052_3D57_4A2F_B531_59F0EB4CD2B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireAlarmActivity.h : header file
//

#include "winioctl.h"

#include "ADConnect.h"
#include "RuleManage.h"
//#include "PacketFilter.h"
#include "TDriver.h"
#include "DrvFltIp.h"

#pragma comment(lib, "Lib/psapi.lib")
#pragma comment(lib, "Lib/AdvAPI32.lib")

class FireAlarmActivity 
{
// Construction
public:
	FireAlarmActivity();   // standard constructor
	~FireAlarmActivity();
	CString GetUser();
	CString GetUserDN();
	void ListMemberOf();

	BOOL StartFilter();	
	BOOL StopFilter();
	BOOL AddFilterToFw(unsigned long srcIp, 
					   unsigned long srcMask,
					   unsigned short srcPort, 
					   unsigned long dstIp,
					   unsigned long dstMask,
					   unsigned short dstPort,
					   unsigned int protocol,
					   int action);

	CRuleManage* ruleUser;

// Implementation
protected:
	CRuleManage* ruleFilter;
	ADConnect ADCon;

	CString sUserName;
	CString sUserDN;
	CString sGroup;

	CStringArray saADGroup;
	CStringArray* saGroupRule;
	CStringArray saUserRule;

	void AddGroupRule();

	CString sSrcAddress;
	CString sSrcMask;
	CString sSrcPort;
	CString sDstAddress;
	CString sDstMask;
	CString sDstPort;
	CString sProtocol;
	CString sAction;

	unsigned long srcIp;
	unsigned long srcMask;
	unsigned short srcPort;
	unsigned long dstIp;
	unsigned long dstMask;
	unsigned short dstPort;
	unsigned int protocol;
	int iAction;

	TDriver filterDriver;
	TDriver ipFltDrv;

private:
	int iDefaultAction;
//	void OnStop();	 //Stop Thread and Clear buffer and Close Adapter
	void OnStart();  //Starting Thread Sniff and Analysis
};
#endif // !defined(AFX_FIREALARMACTIVITY_H__FE9E1052_3D57_4A2F_B531_59F0EB4CD2B9__INCLUDED_)

