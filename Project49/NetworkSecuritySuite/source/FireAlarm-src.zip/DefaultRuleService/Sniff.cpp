// Sniff.cpp: implementation of the CSniff class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Sniff.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#pragma comment(lib, "Lib/packet.lib")

//define a pointer to an ADAPTER structure
LPADAPTER  lpAdapter;
//define a pointer to a PACKET structure
LPPACKET   lpPacket;

CSniff::CSniff()
{
	StatusDirectPacket = FALSE;
}

CSniff::~CSniff()
{
}

BOOL CSniff::OpenDirectPacket(int NumberDevice)
{

	//if not Open Adapter & NumberDevice is true
	if ( StatusDirectPacket == FALSE)
	{	
		if(NumberDevice < 0)
		{
			AfxMessageBox("Unable to open the adapter",MB_OK | MB_ICONSTOP);
			return FALSE;
		}
		char AdapterList[Max_Num_Adapter][1024];

		//Device is a class Variable
		Device = NumberDevice;	//Integer Number of Adapter
		char *temp, *temp1;
		char AdapterName[8192];
		ULONG AdapterLength;
		char buffer[256000]; //buffer to hold the data coming
		int AdapterNum = 0;

		int SumAdapter=0;
		
		AdapterLength = sizeof(AdapterName);

		//get Adapter Name
		if(PacketGetAdapterNames(AdapterName, &AdapterLength)==FALSE)
		{	
			AfxMessageBox("Unable to retrieve the list of the adapters!",MB_OK | MB_ICONSTOP);
			return FALSE;
		};

		temp = AdapterName;
		temp1 = AdapterName;

		while((*temp!='\0') || (*(temp-1)!='\0'))
		{
			if(*temp=='\0')
			{
				memcpy(AdapterList[SumAdapter],temp1,(temp-temp1)*2);
				AdapterList[SumAdapter][((temp-temp1)*2)+0] = NULL;
				AdapterList[SumAdapter][((temp-temp1)*2)+1] = NULL;
				AdapterList[SumAdapter][((temp-temp1)*2)+2] = NULL;
				AdapterList[SumAdapter][((temp-temp1)*2)+3] = NULL;
				temp1=temp+1;
				SumAdapter++;
			}
			temp++;
		}

		//CString test= AdapterList[NumberDevice];
		//MessageBox(NULL,test,NULL,MB_OK);

		//OpenAdapter To capture
		::lpAdapter = PacketOpenAdapter(AdapterList[NumberDevice]) ;
		
		if (!::lpAdapter || (::lpAdapter->hFile == INVALID_HANDLE_VALUE))
		{
			AfxMessageBox("Unable to open the adapter",MB_OK | MB_ICONSTOP);
			return FALSE;
		}

		// set the network adapter in Directed mode	
		//PacketSetHwFilter(::lpAdapter,NDIS_PACKET_TYPE_PROMISCUOUS);	// Promiscuous Mode Opening
		//PacketSetHwFilter(::lpAdapter,NDIS_PACKET_TYPE_ALL_LOCAL);
		if(PacketSetHwFilter(::lpAdapter,NDIS_PACKET_TYPE_DIRECTED) == FALSE)
		{
			AfxMessageBox("Unable to set directed mode!",MB_OK | MB_ICONEXCLAMATION);
		};		// Normal Mode

		// set a 512K buffer in the driver
		if(PacketSetBuff(lpAdapter,512000)==FALSE)
		{
			AfxMessageBox("Unable to set the kernel buffer!",MB_OK | MB_ICONSTOP);
			return FALSE;
		}

		// set a 1 second read timeout
		if(PacketSetReadTimeout(::lpAdapter,1000)==FALSE){
			AfxMessageBox("Unable to set the read tiemout!",MB_OK | MB_ICONEXCLAMATION);
		}
		
		//allocate and initialize a packet structure that will be used to
		//receive the packets.
		if((::lpPacket = PacketAllocatePacket())==NULL)
		{
			AfxMessageBox("Failed to allocate the LPPACKET structure.",MB_OK | MB_ICONSTOP);
			return FALSE;
		}

		PacketInitPacket(::lpPacket,(char*)buffer,256000);
		StatusDirectPacket = TRUE;
		return TRUE;
	}
	
	return FALSE;
}
BOOL CSniff::CloseDirectPacket()
{
	if ( StatusDirectPacket == TRUE )
	{
		PacketFreePacket(::lpPacket);
		PacketCloseAdapter(::lpAdapter);
		StatusDirectPacket = FALSE;
		return TRUE;
	}
	return FALSE;
}

BOOL CSniff::GetStatusPacket(LONG &SumPacket,LONG &SumLost)
{
	if ( StatusDirectPacket == TRUE )
	{
		struct bpf_stat stat;
		PacketGetStats(::lpAdapter,&stat);
		SumPacket = stat.bs_recv;
		SumLost = stat.bs_drop;
		return TRUE;
	}
	SumPacket = 0;
	SumLost = 0;
	return FALSE;	
}

BOOL CSniff::GetPacket(Header_Packet &Packet)
{
	if ( DataPacket.GetCount() > 0 )
	{
		CSingleLock singleLock(&Cs);
		singleLock.Lock();  // Attempt to lock the shared resource
		if (singleLock.IsLocked())  // Resource has been locked
		{
			Packet = DataPacket.GetHead();
			DataPacket.RemoveHead();
			singleLock.Unlock();
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CSniff::PacketFromDevice()
{
	if (StatusDirectPacket == TRUE )
	{
		// capture the packets
		if(PacketReceivePacket(::lpAdapter,::lpPacket,TRUE)==FALSE){
			AfxMessageBox("PacketReceivePacket failed", MB_OK | MB_ICONSTOP);
			return (FALSE);
		}

		if ( ::lpPacket->ulBytesReceived > 0 )
		{
			ULONG	ulBytesReceived;
			char	*pChar,*pBase;
			char	*buf;
			struct	bpf_hdr *hdr;
			UINT	offset;

			ulBytesReceived = ::lpPacket->ulBytesReceived;
			buf = (char *)::lpPacket->Buffer;		// Set buffer to point the Buffer of PacketRecieve
			offset = 0;
	
			while(offset<ulBytesReceived)
			{

				hdr=(struct bpf_hdr *)(buf+offset);
				offset+=hdr->bh_hdrlen ;

				pChar =(char*)(buf + offset);  // Initial base of Packet
				offset=Packet_WORDALIGN(offset+hdr->bh_caplen) ;

				pBase = pChar;

				Header_Packet temp;
				//#define Max_Packet_Analys 100000
				if (DataPacket.GetCount() < Max_Packet_Analys)
				{
					temp.Mac_Dest[0] = *(BYTE *)(pBase);
					temp.Mac_Dest[1] = *(BYTE *)(pBase+1);
					temp.Mac_Dest[2] = *(BYTE *)(pBase+2);
					temp.Mac_Dest[3] = *(BYTE *)(pBase+3);
					temp.Mac_Dest[4] = *(BYTE *)(pBase+4);
					temp.Mac_Dest[5] = *(BYTE *)(pBase+5);
					temp.Mac_Src[0] = *(BYTE *)(pBase+6);
					temp.Mac_Src[1] = *(BYTE *)(pBase+7);
					temp.Mac_Src[2] = *(BYTE *)(pBase+8);
					temp.Mac_Src[3] = *(BYTE *)(pBase+9);
					temp.Mac_Src[4] = *(BYTE *)(pBase+10);
					temp.Mac_Src[5] = *(BYTE *)(pBase+11);
					temp.Frame_Type[0] = *(BYTE *)(pBase+12);
					temp.Frame_Type[1] = *(BYTE *)(pBase+13);
					temp.IP_Version_and_Header_Length = *(BYTE *)(pBase+14);
					temp.Type_Of_Service = *(BYTE *)(pBase+15);
					temp.Total_Length[0] = *(BYTE *)(pBase+16);
					temp.Total_Length[1] = *(BYTE *)(pBase+17);
					temp.Identification[0] = *(BYTE *)(pBase+18);
					temp.Identification[1] = *(BYTE *)(pBase+19);
					temp.Flag_and_Fragment_Offset[0] = *(BYTE *)(pBase+20);
					temp.Flag_and_Fragment_Offset[1] = *(BYTE *)(pBase+21);
					temp.TTL = *(BYTE *)(pBase+22);
					temp.Protocol = *(BYTE *)(pBase+23);
					temp.Header_Checksum[0] = *(BYTE *)(pBase+24);
					temp.Header_Checksum[1] = *(BYTE *)(pBase+25);
					temp.Src_Addr[0] = *(BYTE *)(pBase+26);
					temp.Src_Addr[1] = *(BYTE *)(pBase+27);
					temp.Src_Addr[2] = *(BYTE *)(pBase+28);
					temp.Src_Addr[3] = *(BYTE *)(pBase+29);
					temp.Dest_Addr[0] = *(BYTE *)(pBase+30);
					temp.Dest_Addr[1] = *(BYTE *)(pBase+31);
					temp.Dest_Addr[2] = *(BYTE *)(pBase+32);
					temp.Dest_Addr[3] = *(BYTE *)(pBase+33);
					temp.Data[0] = *(BYTE *)(pBase+34);
					temp.Data[1] = *(BYTE *)(pBase+35);
					temp.Data[2] = *(BYTE *)(pBase+36);
					temp.Data[3] = *(BYTE *)(pBase+37);
					temp.Data[4] = *(BYTE *)(pBase+38);
					temp.Data[5] = *(BYTE *)(pBase+39);
					temp.Data[6] = *(BYTE *)(pBase+40);
					temp.Data[7] = *(BYTE *)(pBase+41);
					temp.Data[8] = *(BYTE *)(pBase+42);
					temp.Data[9] = *(BYTE *)(pBase+43);
					temp.Data[10] = *(BYTE *)(pBase+44);
					temp.Data[11] = *(BYTE *)(pBase+45);
					temp.Data[12] = *(BYTE *)(pBase+46);
					temp.Data[13] = *(BYTE *)(pBase+47);
					temp.Data[14] = *(BYTE *)(pBase+48);
					temp.Data[15] = *(BYTE *)(pBase+49); 
					temp.Data[16] = *(BYTE *)(pBase+50);
					temp.Data[17] = *(BYTE *)(pBase+51);
					temp.Data[18] = *(BYTE *)(pBase+52);
					temp.Data[19] = *(BYTE *)(pBase+53);

					CSingleLock singleLock(&Cs);
					singleLock.Lock();  // Attempt to lock the shared resource
					if (singleLock.IsLocked())  // Resource has been locked
					{
						DataPacket.AddTail(temp);
						singleLock.Unlock();
					}

				} // end if fix packet
				else
				{
					PacketSetHwFilter(::lpAdapter,NDIS_PACKET_TYPE_DIRECTED);
					StatusDirectPacket = FALSE;
				}

			}

			return TRUE;
		}

		return FALSE;
	}

	return FALSE;

}

BOOL CSniff::ClearSniff()
{
	CSingleLock singleLock(&Cs);
	singleLock.Lock();  // Attempt to lock the shared resource
	if (singleLock.IsLocked())  // Resource has been locked
	{
		DataPacket.RemoveAll();
		singleLock.Unlock();
	}
	return TRUE;

}

BOOL CSniff::GetStatusDirectPacket()
{
	return StatusDirectPacket;// Boolean
}
