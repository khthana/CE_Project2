// firealarmservice.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "firealarmservice.h"
#include "FireAlarmActivity.h"
#include <process.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;
	int temp;
	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
//		CString strHello;
//		strHello.LoadString(IDS_HELLO);
//		cout << (LPCTSTR)strHello << endl;

		cout << "Fire Alarm Service Started !!" << endl;

		FireAlarmActivity activity;
	}

	return nRetCode;
}


