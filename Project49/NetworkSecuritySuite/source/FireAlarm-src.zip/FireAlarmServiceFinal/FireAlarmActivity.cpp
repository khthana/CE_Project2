// FireAlarmActivity.cpp : implementation file
//

//#include "stdafx.h"
#include "windows.h"


#include "stdafx.h"
#include "FireAlarm.h"
#include "FireAlarmActivity.h"
#include "sockutil.h"
#include "IntrusionSocket.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "Sniff.h"
#include "Analysis.h"

CAnalysis AnalyPacket;
CSniff Sniffer;
BOOL StatusStop = TRUE;
HANDLE hPipe;
HANDLE hPipe_Intru;

CString allRule;
CString allIntrusion;
/////////////////////////////////////////////////////
//////// IDS SECTION
#define TIME_ELAP 1000 // Time out value in milliseconds

//////// Pipe SECTION
#define g_szPipeName "\\\\.\\Pipe\\MyNamedPipe"  //Name given to the pipe
#define g_szPipeNameIntru "\\\\.\\Pipe\\MyNamedPipeIntru"
//Pipe name format - \\.\pipe\pipename

#define BUFFER_SIZE 1024 //1k
#define ACK_MESG_RECV "Message received successfully"


/////////////////////////////////////////////////
//////  IDS CAPTURE PACKET FUNCTION
UINT Thread_Analysis(LPVOID pParam)
{	
	CString T_Type,T_Src,T_Dst,T_Time;
	while((!StatusStop))
	{
		Header_Packet Packet;
		if (Sniffer.GetPacket(Packet))		//Get Packet From Buffer
		{
			if (AnalyPacket.Check(Packet))
			{
				Sniffer.ClearSniff();
			}
		}
		else
			Sleep(1);
	}
	return 0;
}

UINT Thread_Sniff(LPVOID pParam)
{
	while((!StatusStop))
	{
		Sniffer.PacketFromDevice();
	}
	return 0;
}

UINT Thread_Pipe(LPVOID pParam)
{
	while(1){
     hPipe = CreateNamedPipe( 
          g_szPipeName,             // pipe name 
          PIPE_ACCESS_DUPLEX,       // read/write access 
          PIPE_TYPE_MESSAGE |       // message type pipe 
          PIPE_READMODE_MESSAGE |   // message-read mode 
          PIPE_WAIT,                // blocking mode 
          PIPE_UNLIMITED_INSTANCES, // max. instances  
          BUFFER_SIZE,              // output buffer size 
          BUFFER_SIZE,              // input buffer size 
          NMPWAIT_USE_DEFAULT_WAIT, // client time-out 
          NULL);                    // default security attribute 
     
     if (INVALID_HANDLE_VALUE == hPipe) 
     {
          printf("\nError occurred while creating the pipe: %d", GetLastError()); 
//          return 1;  //Error
     }
     else
     {
          printf("\nCreateNamedPipe() was successful.");
     }
     
     printf("\nWaiting for client connection...");
	 BOOL bClientConnected = ConnectNamedPipe(hPipe, NULL);

     char szBuffer[BUFFER_SIZE];
     DWORD cbBytes;
     
   
	 strcpy(szBuffer,allRule);	
     BOOL bResult = WriteFile( 
          hPipe,                // handle to pipe 
          szBuffer,             // buffer to write from 
          strlen(szBuffer)+1,   // number of bytes to write, include the NULL 
          &cbBytes,             // number of bytes written 
          NULL);                // not overlapped I/O 
     
     if (FALSE == bClientConnected)
     {
          printf("\nError occurred while connecting to the client: %d", GetLastError()); 
          CloseHandle(hPipe);
     }
     else
     {
          printf("\nConnectNamedPipe() was successful.");
     }
    
     CloseHandle(hPipe);
	}
}

UINT Thread_PipeIntrusion(LPVOID pParam)
{	
	while(1)
	{
		  hPipe_Intru = CreateNamedPipe( 
          g_szPipeNameIntru,             // pipe name 
          PIPE_ACCESS_DUPLEX,       // read/write access 
          PIPE_TYPE_MESSAGE |       // message type pipe 
          PIPE_READMODE_MESSAGE |   // message-read mode 
          PIPE_WAIT,                // blocking mode 
          PIPE_UNLIMITED_INSTANCES, // max. instances  
          BUFFER_SIZE,              // output buffer size 
          BUFFER_SIZE,              // input buffer size 
          NMPWAIT_USE_DEFAULT_WAIT, // client time-out 
          NULL);                    // default security attribute 
    
     if (INVALID_HANDLE_VALUE == hPipe_Intru) 
     {
          printf("\nError occurred while creating the pipe: %d", GetLastError()); 
//          return 1;  //Error
     }
     else
     {
          printf("\nCreateNamedPipe() was successful.");
     }
     
     printf("\nWaiting for client connection...");
	 BOOL bClientConnected = ConnectNamedPipe(hPipe_Intru, NULL);

     char szBuffer[5000];
     DWORD cbBytes;
     
//	 AfxMessageBox(allIntrusion+"Gop");
	 strcpy(szBuffer,allIntrusion);	
     BOOL bResult = WriteFile( 
          hPipe_Intru,                // handle to pipe 
          szBuffer,             // buffer to write from 
          strlen(szBuffer)+1,   // number of bytes to write, include the NULL 
          &cbBytes,             // number of bytes written 
          NULL);                // not overlapped I/O 
     
     if (FALSE == bClientConnected)
     {
          printf("\nError occurred while connecting to the client: %d", GetLastError()); 
          CloseHandle(hPipe);
     }
     else
     {
          printf("\nConnectNamedPipe() was successful.");
     }
    
     CloseHandle(hPipe_Intru);
	}

}
/////////////////////////////////////////////////////////////////////////////
// FireAlarmActivity dialog


FireAlarmActivity::FireAlarmActivity(CWnd* pParent /*=NULL*/)
	: CDialog(FireAlarmActivity::IDD, pParent)
{
	//{{AFX_DATA_INIT(FireAlarmActivity)
	m_sUserName = _T("");
	m_sIPAddr = _T("");
	m_sTotalRules = _T("");
	//}}AFX_DATA_INIT
}


void FireAlarmActivity::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FireAlarmActivity)
	DDX_Control(pDX, IDC_LISTGROUP, m_cListGroup);
	DDX_Control(pDX, IDC_LISTACTIVITY, m_cListActivity);
	DDX_Text(pDX, IDC_USERNAME, m_sUserName);
	DDX_Text(pDX, IDC_IPADDR, m_sIPAddr);
	DDX_Text(pDX, IDC_TOTALRULES, m_sTotalRules);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FireAlarmActivity, CDialog)
	//{{AFX_MSG_MAP(FireAlarmActivity)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FireAlarmActivity message handlers

void sendPipe()
{
//	AfxBeginThread((AFX_THREADPROC)Thread_Pipe,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
}

BOOL FireAlarmActivity::OnInitDialog() 
{
	
	ipFltDrv.LoadDriver("IpFilterDriver", "System32\\Drivers\\IpFltDrv.sys", NULL, TRUE);
	ipFltDrv.SetRemovable(FALSE);
	
	//Load Filter Driver //For windows Service put DrvFltIp.sys in windows directory
	if(filterDriver.LoadDriver("DrvFltIp","System32\\Drivers\\DrvFltIp.sys",NULL, TRUE) != DRV_SUCCESS)
	{
		AfxMessageBox("Error loading the driver.");
		AfxMessageBox("GOpgop");
		exit(-1);
	}

	CDialog::OnInitDialog();


	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 15;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_ACT1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_ACT2);
	Static2->SetFont(F1,TRUE);
	CFont *F2 = new CFont();
	LOGFONT lf2 = {0};
    _tcscpy(lf2.lfFaceName, _T("Arial"));
    lf2.lfHeight = 14;
    lf2.lfWeight = FW_BOLD;
    F2->CreateFontIndirect(&lf2);
	CStatic *Static3 = (CStatic*) GetDlgItem(IDC_STATIC_ACT3);
	Static3->SetFont(F2,TRUE);
	CStatic *Static4 = (CStatic*) GetDlgItem(IDC_STATIC_ACT4);
	Static4->SetFont(F2,TRUE);
	CStatic *Static5 = (CStatic*) GetDlgItem(IDC_STATIC_ACT5);
	Static5->SetFont(F2,TRUE);

	ruleFilter	= new CRuleManage();
	ruleUser	= new CRuleManage();
	
// Get information to variable
	sUserName = GetUser();
	sUserDN = GetUserDN();

	allRule = sUserName + "__USERNAME__";
	m_sUserName = " "+sUserName;
	m_sIPAddr.Format(" %s",ruleUser->GetClientIP());
	if(sUserDN!=" "){
		ListMemberOf();
		AddGroupRule();
		StopFilter();
		StopFilter();
		StartFilter();
		m_cListActivity.AddString("# Firewall Started ...");	

		OnStart();

	}
	if(ruleUser->nRules>1){
		m_sTotalRules.Format(" %d Rules",ruleUser->nRules);
	}else{
		m_sTotalRules.Format(" %d Rule",ruleUser->nRules);
	}
//	MessageBox(saADGroup.GetAt(0),NULL,MB_OK);
	UpdateData(FALSE);
//   	sendPipe(allRule);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
HANDLE GetHandleExplorer()
{
	HANDLE hProcess;
	// Get the list of process identifiers.

	DWORD aProcesses[1024], cbNeeded, cProcesses;
	unsigned int i;

	if ( !EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded ) )
		return 0;

	// Calculate how many process identifiers were returned.

	cProcesses = cbNeeded / sizeof(DWORD);

	// Print the name and process identifier for each process.

	for ( i = 0; i < cProcesses; i++ )
	{
		TCHAR szProcessName[MAX_PATH] = TEXT("<unknown>");
		TCHAR ProcessName[MAX_PATH] = TEXT("Explorer.EXE");

		// Get a handle to the process.

		hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
									   PROCESS_VM_READ,
									   FALSE, aProcesses[i] );

		// Get the process name.

		if (NULL != hProcess )
		{
			HMODULE hMod;
			DWORD cbNeeded;

			if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), 
				 &cbNeeded) )
			{
				GetModuleBaseName( hProcess, hMod, szProcessName, 
								   sizeof(szProcessName)/sizeof(TCHAR) );
			}
		}
		
		if(_tcscmp(szProcessName,ProcessName) == 0){
			return hProcess;
		}

	}

	CloseHandle( hProcess );
	return hProcess;


}

CString GetLoginUser()
{
	HANDLE explorer = GetHandleExplorer();
	HANDLE t_handle;
	
	DWORD lenght;
	TOKEN_OWNER* pOwner = NULL;
	if (!OpenProcessToken(explorer,TOKEN_QUERY,&t_handle))
	{	printf("OpenProcessToken() failed (error code = %d)",GetLastError());
	}
	GetTokenInformation(t_handle,TokenOwner,pOwner,0, &lenght);
	pOwner = (TOKEN_OWNER*) new char[lenght];
	if (GetTokenInformation(t_handle, TokenOwner, pOwner, lenght, &lenght)== 0)
	{	printf("GetTokenInformation() failed (error code = %d)",GetLastError());
	}
	TCHAR bufName[MAX_PATH];
	TCHAR bufDomain[MAX_PATH];
	SID_NAME_USE SidNameUse;
	DWORD dwCbName = 0;
	DWORD dwCbDomainName = 0;
	dwCbName = sizeof(bufName);
	dwCbDomainName = sizeof(bufDomain);
	LookupAccountSid(NULL, pOwner->Owner, bufName, &dwCbName, bufDomain, &dwCbDomainName, &SidNameUse);
	CString tmp(bufName);
	return tmp;
}
CString FireAlarmActivity::GetUser(){
	return GetLoginUser();
}
CString FireAlarmActivity::GetUserDN(){
	CStringArray uDistinguishedName;
	CStringArray uName;
	
	if (ADCon.GetList("user",uName,uDistinguishedName) != TRUE)
	{
	//	m_cListLog.AddString("# Can't get domain...!!!");
		return " ";
	}

	CString UserDomain;	
	for(int i=0;i<uDistinguishedName.GetSize();i++){
		if(sUserName==uName.GetAt(i)){
			UserDomain = uDistinguishedName.GetAt(i);
		//	MessageBox(UserDomain,NULL,MB_OK);
		}
	}
	return UserDomain;
}

void FireAlarmActivity::ListMemberOf(){

	CString TmpMo;
	ADCon.GetMemberOf(sUserDN,saADGroup);

	int iFWGroupAll = saADGroup.GetSize() -1;
//-- Error here ->> icount <=iFWGroupAll-5
	for(int icount = 0 ; icount <=iFWGroupAll ;icount++){
		TmpMo = saADGroup.GetAt(icount);
		//MessageBox(saADGroup.GetAt(icount),"test",MB_OK);
		allRule = allRule + TmpMo +"__GROUP__";
		m_cListGroup.AddString(TmpMo.Mid(3,TmpMo.Find(",")-3));
	}
	// All Group of User

	sGroup = TmpMo.Mid(3,TmpMo.Find(",")-3);

}

void FireAlarmActivity::AddGroupRule(){
	
	int iGroupRule = 0;
//	int iRuleNumber ;
	bool bSameRule = false;
	CString sRuleIn,sRuleOut;
	CStringArray saAllRule;
	saADGroup.RemoveAll();
	ADCon.GetMemberOf(sUserDN,saADGroup);

	int iFWGroupAll = saADGroup.GetSize();
	saUserRule.RemoveAll();
	ADCon.GetRule(sUserDN,saUserRule);


	saGroupRule = new CStringArray[iFWGroupAll];
	for(int iCountGroup = 0 ; iCountGroup < iFWGroupAll ; iCountGroup++)
	{
		ADCon.GetRule(saADGroup.GetAt(iCountGroup),saGroupRule[iCountGroup]);
	}
	for(iCountGroup = 0 ; iCountGroup < iFWGroupAll ; iCountGroup++)
	{
		iGroupRule = saGroupRule[iCountGroup].GetSize();
		for( int i = 0 ; i < iGroupRule  ; i++)
		{
			
			for(int j = 0 ;j < iCountGroup;j++){
				int iRule=saGroupRule[j].GetSize();
				for(int x=0;x < iRule;x++){
					if(saGroupRule[iCountGroup].GetAt(i)==saGroupRule[j].GetAt(x)){
					//	MessageBox(saGroupRule[iCountGroup].GetAt(i),NULL,MB_OK);
						bSameRule = true;
						break;
					}	
				}
				if(bSameRule){
					break;
				}
			}
			if(!bSameRule){
				if(iGroupRule-i==2||iGroupRule-i==1){
					if(iGroupRule-i==2){
						sRuleOut= saGroupRule[iCountGroup].GetAt(i);
					}else{
						sRuleIn = saGroupRule[iCountGroup].GetAt(i);
					}
				}else{
					saAllRule.Add(saGroupRule[iCountGroup].GetAt(i));	
				}
			}
			bSameRule = false;
		}
	}

	if(saUserRule.GetSize()!=0){
		for(int i=saUserRule.GetSize()-1;i>=0;i--){
			saAllRule.Add(saUserRule.GetAt(i));
		}
	}
	saAllRule.Add(sRuleOut);
	saAllRule.Add(sRuleIn);


// Send Rule by Pipe
	for(int p =saAllRule.GetSize()-1 ;p >=0;p--){
		allRule = allRule + saAllRule.GetAt(p)+"__END__";
	}

	for(int i =saAllRule.GetSize()-1 ;i >=0;i--){
	     	CString sLongRule = saAllRule.GetAt(i);
			// change long rule string to each variables
			CString tmpString;
			sLongRule.TrimLeft();	//removes newline, space, and tab characters
			sLongRule.TrimRight();	//removes newline, space, and tab characters

			for ( int j = 0; j<7; j++ ) 
			{
				int pos = sLongRule.Find(' ');
				tmpString = sLongRule.Left(pos);
				sLongRule.Delete(0, pos+1);

				switch(j)
				{
					case 0 :
						sSrcAddress = tmpString;
						break;
					case 1 :
						sSrcMask = tmpString;
						break;
					case 2 :
						sSrcPort = tmpString;
						break;
					case 3 :
						sDstAddress = tmpString;
						break;
					case 4 :
						sDstMask = tmpString;
						break;
					case 5 :
						sDstPort = tmpString;
						break;
					case 6 :
						sProtocol = tmpString;
						break;
				}

			}	

			sAction = sLongRule;
	
//	AfxMessageBox(sSrcAddress + "\n" + sSrcMask + "\n" + sSrcPort + "\n" + sDstAddress + "\n"
//					+ sDstMask + "\n" + sDstPort + "\n" + sProtocol + "\n" + sAction);
			int result;
			result = inet_addr(sSrcAddress, &srcIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid source address");
				return;
			}

			result = inet_addr(sSrcMask, &srcMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid source mask");
				return;
			}

			result = inet_addr(sDstAddress, &dstIp);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination address");
				return;
			}

			result = inet_addr(sDstMask, &dstMask);
			if(result == -1)
			{
				AfxMessageBox("Invalid destination mask");
				return;
			}
	
			if(sProtocol == "TCP")
				protocol = 6;
			else if(sProtocol == "UDP")
				protocol = 17;
			else if(sProtocol == "ICMP")
				protocol = 1;
			else
				protocol = 0;
			
			if(sAction == "")
			{
				AfxMessageBox("Please, fill action field.");
				return;
			}
			else
			{
				if(sAction == "ALLOW")
					iAction = 0;
				else
					iAction = 1;

				if (i == 0)
					iDefaultAction = iAction;
			}

			srcPort = atoi(sSrcPort);
			dstPort = atoi(sDstPort);

		// check number of rules
			if(ruleUser->nRules < MAX_RULES )
			{
			// Add the rule to the rule lists			
				if(ruleUser->AddRule(	srcIp, 
								srcMask, 
								srcPort, 
								dstIp, 
								dstMask, 
								dstPort, 
								protocol, 
								iAction) != 0)
				AfxMessageBox("Error adding the rule.");
				else
				{
//					AfxMessageBox("Add rule OK");
				}
			}
	}
}
BOOL FireAlarmActivity::StartFilter(){
	
	unsigned int i;

	if(filterDriver.WriteIo(START_IP_HOOK,NULL,0) != DRV_SUCCESS){
		AfxMessageBox("filterDriver.WriteIo Fail !!!");
		return FALSE;
	}

	// Send all rules to the driver
	for(i = 0;i < ruleUser->nRules;i++)
	{
		if (!AddFilterToFw(	ruleUser->rules[i].sourceIp, 
							ruleUser->rules[i].sourceMask,
							ruleUser->rules[i].sourcePort,
							ruleUser->rules[i].destinationIp,
							ruleUser->rules[i].destinationMask,
							ruleUser->rules[i].destinationPort,
							ruleUser->rules[i].protocol,
							ruleUser->rules[i].action))
		{
			AfxMessageBox("Error adding all rules to driver !!!.");
			return FALSE;
		}
	}
	return TRUE;
}
BOOL FireAlarmActivity::StopFilter(){
	if(filterDriver.WriteIo(STOP_IP_HOOK, NULL, 0) != DRV_SUCCESS)
	{
		AfxMessageBox("filterDriver.WriteIo Fail !!!");
		return FALSE;
	}
	return TRUE;
}
BOOL FireAlarmActivity::AddFilterToFw(unsigned long srcIp, unsigned long srcMask,
									  unsigned short srcPort, unsigned long dstIp,
									  unsigned long dstMask, unsigned short dstPort,
									  unsigned int protocol, int action)
{
	IPFilter pf;

	pf.protocol = protocol;

	pf.destinationIp = dstIp;			
	pf.sourceIp		 = srcIp;

	pf.destinationMask = dstMask;	
	pf.sourceMask	   = srcMask;		

	pf.destinationPort = htons(dstPort);						
	pf.sourcePort	   = htons(srcPort);				

	pf.drop = action;		
	
	// Send rule to the driver
	DWORD result = filterDriver.WriteIo(ADD_FILTER, &pf, sizeof(pf));

	if (result != DRV_SUCCESS) 
	{
		AfxMessageBox("Send rules to the driver !!!");
		return FALSE;
	}

	else
		return TRUE;
}
void FireAlarmActivity::OnStart()
{	
	if(Sniffer.GetStatusDirectPacket() == FALSE )
	{
		UpdateData(FALSE); 
		if(Sniffer.OpenDirectPacket(1))
		{
			//send number of Adapter to select capture
			SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=1000
			m_cListActivity.AddString("# Starting Intrusion Detection ...");

			m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

			UpdateData(FALSE);		//set variable to control
			StatusStop = FALSE;		//Flag Star Thread Function (initial Value True);

			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Pipe,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_PipeIntrusion,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
		}
	}
	else{
			SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=1000

			m_cListActivity.AddString("# Starting Intrusion Detection ...");
			m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

			UpdateData(FALSE); //set variable to control
			StatusStop = FALSE; //Flag Star Thread Function (initial Value True);

			AfxBeginThread((AFX_THREADPROC)Thread_Sniff,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Analysis,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
			AfxBeginThread((AFX_THREADPROC)Thread_Pipe,GetSafeHwnd(),THREAD_PRIORITY_IDLE);		
			AfxBeginThread((AFX_THREADPROC)Thread_PipeIntrusion,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
	}

}

void FireAlarmActivity::OnStop()
{
	if(Sniffer.GetStatusDirectPacket() == TRUE)
	{
		KillTimer(1); //Kill Timer ID = 1
		StatusStop = TRUE;
		m_cListActivity.AddString("# Intrusion Detection has been stop!.");
		m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);

		UpdateData(FALSE); //set variable to control

		Sniffer.ClearSniff();
		Sniffer.CloseDirectPacket();
	}
}
void FireAlarmActivity::OnTimer(UINT nIDEvent) 
{
	// Client Attacked.
	CString Type,Src,Dst,Time;
	if (AnalyPacket.GetResult(Type,Src,Dst,Time))
	{
		CTime t = CTime::GetCurrentTime();
		CString sSecond,sDay,sMonth,sYear,sDate;
		sSecond.Format("%d",t.GetSecond());
		sDay.Format("%d",t.GetDay());
		sMonth.Format("%d",t.GetMonth());
		sYear.Format("%d",t.GetYear());
		sDate = sDay+"/"+sMonth+"/"+sYear;

		Time += ":" + sSecond;
		CString msg = "# Attacked from:"+Src+" , Type:"+Type+" , Date:"+sDate+" , Time:"+Time+" #";
		allIntrusion = allIntrusion + msg + "__INTRUSION__";
		m_cListActivity.AddString(msg);							// Add message to log list
		m_cListActivity.SetTopIndex(m_cListActivity.GetCount() - 1);		// Show last message in log list

		CString sTmpLog = Type+","+Src+","+Dst+","+sDate+","+Time+","+sGroup+","+sUserName;
		m_cListActivity.SetHorizontalExtent(450);
		//MessageBox(sTmpLog,NULL,MB_OK);

		IntrusionSocket client;
		if(client.Create())
		{	
			client.Connect("192.168.1.100",4000);
			int r = client.Send(LPCTSTR(sTmpLog),sTmpLog.GetLength());
			while(r==SOCKET_ERROR)
			{	r = client.Send(LPCTSTR(sTmpLog),sTmpLog.GetLength());
			}
		}
		else
		{	AfxMessageBox("Client Create Socket Error !!");
		}
		client.Close();
		ADCon.SetNewLog(saADGroup.GetAt(0),sTmpLog);	// Add Log to AD
		//MessageBox("ADD to AD !!");
	}	
	CDialog::OnTimer(nIDEvent);
}
