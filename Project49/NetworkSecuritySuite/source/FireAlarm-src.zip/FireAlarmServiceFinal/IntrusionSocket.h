#if !defined(AFX_INTRUSIONSOCKET_H__CB710A6F_A5B3_4421_8646_623E922DF168__INCLUDED_)
#define AFX_INTRUSIONSOCKET_H__CB710A6F_A5B3_4421_8646_623E922DF168__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IntrusionSocket.h : header file
//
#include <afxsock.h>


/////////////////////////////////////////////////////////////////////////////
// IntrusionSocket command target

class IntrusionSocket : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	IntrusionSocket();
	virtual ~IntrusionSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(IntrusionSocket)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(IntrusionSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTRUSIONSOCKET_H__CB710A6F_A5B3_4421_8646_623E922DF168__INCLUDED_)
