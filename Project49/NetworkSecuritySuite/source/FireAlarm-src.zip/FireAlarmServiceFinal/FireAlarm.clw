; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=IntrusionSocket
LastTemplate=CAsyncSocket
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FireAlarm.h"

ClassCount=7
Class1=CFireAlarmApp
Class2=CFireAlarmDlg
Class3=CAboutDlg

ResourceCount=15
Resource1=IDR_MENUTRAY
Resource2=IDR_MAINFRAME
Resource3=IDD_FIREALARMNETSTAT
Resource4=IDD_FIREALARMRULE
Class4=FireAlarmRule
Class5=FireAlarmActivity
Resource5=IDD_FIREALARMACTIVITY
Resource6=IDD_FIREALARM_DIALOG
Resource7=IDD_FIREALARMNETSTAT (English (U.S.))
Resource8=IDR_MENUTRAY (English (U.S.))
Resource9=IDR_MENU_SYSCONN
Resource10=IDD_FIREALARM_DIALOG (English (U.S.))
Resource11=IDD_FIREALARMRULE (English (U.S.))
Class6=CFireAlarmNetStat
Resource12=IDD_ABOUTBOX (English (U.S.))
Resource13=IDD_ABOUTBOX
Resource14=IDD_FIREALARMACTIVITY (English (U.S.))
Class7=IntrusionSocket
Resource15=IDR_MENU_SYSCONN (English (U.S.))

[CLS:CFireAlarmApp]
Type=0
HeaderFile=FireAlarm.h
ImplementationFile=FireAlarm.cpp
Filter=N

[CLS:CFireAlarmDlg]
Type=0
HeaderFile=FireAlarmDlg.h
ImplementationFile=FireAlarmDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CFireAlarmDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=FireAlarmDlg.h
ImplementationFile=FireAlarmDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=3
Control1=IDC_STATIC,static,1342177294
Control2=IDOK,button,1342373889
Control3=IDC_STATIC,static,1342308352

[DLG:IDD_FIREALARM_DIALOG]
Type=1
Class=CFireAlarmDlg
ControlCount=3
Control1=IDC_MAINTAB,SysTabControl32,1342177280
Control2=IDC_STATIC,static,1342177294
Control3=IDC_STATIC,static,1342177294

[DLG:IDD_FIREALARMACTIVITY]
Type=1
Class=FireAlarmActivity
ControlCount=10
Control1=IDC_LISTACTIVITY,listbox,1345392897
Control2=IDC_LISTGROUP,listbox,1344340227
Control3=IDC_STATIC_ACT3,static,1342308352
Control4=IDC_STATIC_ACT2,static,1342308352
Control5=IDC_USERNAME,static,1342308352
Control6=IDC_STATIC_ACT1,button,1342177287
Control7=IDC_STATIC_ACT4,static,1342308352
Control8=IDC_IPADDR,static,1342308352
Control9=IDC_STATIC_ACT5,static,1342308352
Control10=IDC_TOTALRULES,static,1342308352

[DLG:IDD_FIREALARMRULE]
Type=1
Class=FireAlarmRule
ControlCount=7
Control1=IDC_STATIC_R1,button,1342177287
Control2=IDC_UNAME,static,1342308352
Control3=IDC_STATIC_R2,static,1342308352
Control4=IDC_IPADDRESS,static,1342308352
Control5=IDC_STATIC_R3,static,1342308352
Control6=IDC_NUMRULE,static,1342308354
Control7=IDC_LISTRULE,SysListView32,1342242817

[CLS:FireAlarmRule]
Type=0
HeaderFile=FireAlarmRule.h
ImplementationFile=FireAlarmRule.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=FireAlarmRule

[CLS:FireAlarmActivity]
Type=0
HeaderFile=FireAlarmActivity.h
ImplementationFile=FireAlarmActivity.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=FireAlarmActivity

[MNU:IDR_MENUTRAY]
Type=1
Class=?
Command1=ID_RESTORE
Command2=ID_SHUTDOWN
CommandCount=2

[MNU:IDR_MENUTRAY (English (U.S.))]
Type=1
Class=?
Command1=ID_RESTORE
Command2=ID_SHUTDOWN
CommandCount=2

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=3
Control1=IDC_STATIC,static,1342177294
Control2=IDOK,button,1342373889
Control3=IDC_STATIC,static,1342308352

[DLG:IDD_FIREALARM_DIALOG (English (U.S.))]
Type=1
Class=CFireAlarmDlg
ControlCount=3
Control1=IDC_MAINTAB,SysTabControl32,1342177280
Control2=IDC_STATIC,static,1342177294
Control3=IDC_STATIC,static,1342177294

[DLG:IDD_FIREALARMACTIVITY (English (U.S.))]
Type=1
Class=FireAlarmActivity
ControlCount=10
Control1=IDC_LISTACTIVITY,listbox,1345392897
Control2=IDC_LISTGROUP,listbox,1344340227
Control3=IDC_STATIC_ACT3,static,1342308352
Control4=IDC_STATIC_ACT2,static,1342308352
Control5=IDC_USERNAME,static,1342308352
Control6=IDC_STATIC_ACT1,button,1342177287
Control7=IDC_STATIC_ACT4,static,1342308352
Control8=IDC_IPADDR,static,1342308352
Control9=IDC_STATIC_ACT5,static,1342308352
Control10=IDC_TOTALRULES,static,1342308352

[DLG:IDD_FIREALARMRULE (English (U.S.))]
Type=1
Class=FireAlarmRule
ControlCount=7
Control1=IDC_STATIC_R1,button,1342177287
Control2=IDC_UNAME,static,1342308352
Control3=IDC_STATIC_R2,static,1342308352
Control4=IDC_IPADDRESS,static,1342308352
Control5=IDC_STATIC_R3,static,1342308352
Control6=IDC_NUMRULE,static,1342308354
Control7=IDC_LISTRULE,SysListView32,1342242817

[DLG:IDD_FIREALARMNETSTAT (English (U.S.))]
Type=1
Class=CFireAlarmNetStat
ControlCount=7
Control1=IDC_STATIC_STAT1,button,1342177287
Control2=IDC_LISTNETSTAT,SysListView32,1342242817
Control3=IDC_COMBOREFRESH,combobox,1344340227
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_COMBOVIEW,combobox,1344340227
Control7=IDC_BUTTONREFRESH,button,1342275584

[CLS:CFireAlarmNetStat]
Type=0
HeaderFile=FireAlarmNetStat.h
ImplementationFile=FireAlarmNetStat.cpp
BaseClass=CDialog
Filter=D
LastObject=ID_SYS_CLOSECONNECTION
VirtualFilter=dWC

[DLG:IDD_FIREALARMNETSTAT]
Type=1
Class=CFireAlarmNetStat
ControlCount=7
Control1=IDC_STATIC_STAT1,button,1342177287
Control2=IDC_LISTNETSTAT,SysListView32,1342242817
Control3=IDC_COMBOREFRESH,combobox,1344340227
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_COMBOVIEW,combobox,1344340227
Control7=IDC_BUTTONREFRESH,button,1342275584

[MNU:IDR_MENU_SYSCONN]
Type=1
Class=?
Command1=ID_SYS_KILLPROCESS
Command2=ID_SYS_CLOSECONNECTION
CommandCount=2

[MNU:IDR_MENU_SYSCONN (English (U.S.))]
Type=1
Class=?
Command1=ID_SYS_KILLPROCESS
Command2=ID_SYS_CLOSECONNECTION
CommandCount=2

[CLS:IntrusionSocket]
Type=0
HeaderFile=IntrusionSocket.h
ImplementationFile=IntrusionSocket.cpp
BaseClass=CAsyncSocket
Filter=N

