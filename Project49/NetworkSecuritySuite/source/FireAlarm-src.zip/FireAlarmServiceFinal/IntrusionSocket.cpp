// IntrusionSocket.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarm.h"
#include "IntrusionSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IntrusionSocket

IntrusionSocket::IntrusionSocket()
{
}

IntrusionSocket::~IntrusionSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(IntrusionSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(IntrusionSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// IntrusionSocket member functions
