// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__6843E53C_40B2_4F9F_8441_CF03E6F9537D__INCLUDED_)
#define AFX_STDAFX_H__6843E53C_40B2_4F9F_8441_CF03E6F9537D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxsock.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

//custom defines
#ifndef WM_SOCKEVENT
#define WM_SOCKEVENT WM_USER + 0x100
#endif

//custom includes
#include "Extern\Includes\iphlpapi.h"
#include "Extern\Includes\Iprtrmib.h"
#include "Extern\Includes\Fltdefs.h"
#include "Extern\Includes\FilterDefs.h"
#include "Extern\Includes\Psapi.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__6843E53C_40B2_4F9F_8441_CF03E6F9537D__INCLUDED_)
