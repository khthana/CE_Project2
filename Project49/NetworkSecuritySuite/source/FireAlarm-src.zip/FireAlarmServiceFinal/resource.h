//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FireAlarm.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FIREALARM_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_FIREALARMACTIVITY           129
#define IDD_FIREALARMRULE               130
#define IDB_BITMAP1                     136
#define IDB_BITMAP2                     137
#define IDB_BITMAP3                     138
#define IDR_MENUTRAY                    139
#define IDD_FIREALARMNETSTAT            142
#define IDI_ICON_PROTO                  143
#define IDI_ICON_UNK_PROCESS            144
#define IDB_BITMAP_TOOLTIP_IN           148
#define IDB_BITMAP_TOOLTIP_OUT          149
#define IDR_MENU_SYSCONN                150
#define IDB_BITMAP4                     153
#define IDB_BITMAP5                     154
#define IDC_MAINTAB                     1000
#define IDC_UNAME                       1001
#define IDC_IPADDRESS                   1002
#define IDC_NUMRULE                     1003
#define IDC_LISTRULE                    1004
#define IDC_LISTACTIVITY                1005
#define IDC_LISTGROUP                   1006
#define IDC_USERNAME                    1007
#define IDC_IPADDR                      1008
#define IDC_LISTNETSTAT                 1008
#define IDC_TOTALRULES                  1009
#define IDC_COMBOREFRESH                1010
#define IDC_COMBOVIEW                   1011
#define IDC_BUTTONREFRESH               1012
#define ID_INDICATOR_ERROR              1013
#define ID_INDICATOR_TIME               1014
#define IDC_STATIC_ACT1                 1017
#define IDC_STATIC_ACT2                 1018
#define IDC_STATIC_ACT3                 1019
#define IDC_STATIC_ACT4                 1020
#define IDC_STATIC_ACT5                 1021
#define IDC_STATIC_R1                   1022
#define IDC_STATIC_R2                   1023
#define IDC_STATIC_R3                   1024
#define IDC_STATIC_STAT1                1025
#define ID_RESTORE                      32771
#define ID_SHUTDOWN                     32773
#define ID_SYS_KILLPROCESS              32774
#define ID_SYS_CLOSECONNECTION          32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
