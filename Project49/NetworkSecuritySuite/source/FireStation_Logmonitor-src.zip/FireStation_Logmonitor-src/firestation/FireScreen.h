#if !defined(AFX_FIRESCREEN_H__C1DE7186_CF23_4126_943C_160FC92A3559__INCLUDED_)
#define AFX_FIRESCREEN_H__C1DE7186_CF23_4126_943C_160FC92A3559__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireScreen.h : header file
//
#include "ADConnect.h"
#include "SockUtil.h"
#include "RuleFireScreen.h"

/////////////////////////////////////////////////////////////////////////////
// FireScreen dialog

class FireScreen : public CDialog
{
// Construction
public:
	FireScreen(CWnd* pParent = NULL);   // standard constructor

	void GetDataFromAD();
	CString dwAddressToString(DWORD dwAddress);
	void BreakLongRule(CString sLongRule);
	void IPStringToIPBYTE(CString sIP);
	void AddRule();
	void UpdateList();
	void ListBoxShow();
	int  SetPosition(int iOldPos);
	void AddRuleToList(	CString status  ,
						CString srcIp,	  
						CString srcMask, 
						CString dstIp,   
						CString dstMask, 
						CString protocol, 
						CString srcPort,
						CString	dstPort, 
						CString icmp_type,
						CString	zone ,	  
						CString target,
						CString comments,
						CString sNotSrc,
						CString sNotDst);
// Dialog Data
	//{{AFX_DATA(FireScreen)
	enum { IDD = IDD_FIRESCREEN };
	CComboBox	m_cProtocol;
	CIPAddressCtrl	m_cDstMask;
	CIPAddressCtrl	m_cDstAddr;
	CIPAddressCtrl	m_cSrcMask;
	CIPAddressCtrl	m_cSrcAddr;
	CListCtrl	m_cListRuleOfFireScreen;
	CString	m_sSrcPort;
	CString	m_sDstPort;
	CString	m_sTarget;
	CString	m_sNumberOfRule;
	CString	m_sStatus;
	CString	m_sZone;
	BOOL	m_bNotDst;
	CString	m_sICMP_type;
	BOOL	m_bNotSrc;
	int		m_sProtocol;
	CString	m_sShowComment;
	CString	m_sShowDstAddr;
	CString	m_sShowDstMask;
	CString	m_sShowDstPort;
	CString	m_sShowICMP;
	CString	m_sShowProtocol;
	CString	m_sShowSrcAddr;
	CString	m_sShowSrcMask;
	CString	m_sShowSrcPort;
	CString	m_sShowStatus;
	CString	m_sShowTarget;
	CString	m_sShowZone;
	CString	m_sComment;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FireScreen)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(FireScreen)
	virtual BOOL OnInitDialog();
	afx_msg void OnFirescreenAddRule();
	afx_msg void OnFirescreenDeleteRule();
	afx_msg void OnFirescreenEditRule();
	afx_msg void OnFirescreenClearRule();
	afx_msg void OnSelchangeComboProtocolScreen();
	afx_msg void OnClickListctrlRuleOfFirescreen(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonPolicy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	ADConnect		ADCon;
	CRuleFireScreen* ruleManage;
	BOOL	bEditRule;				// Check First Click Edit Rule Button
	BYTE	ip01,ip02,ip03,ip04;

/*	unsigned long	srcIp;		// Source IP
	unsigned long	srcMask;	// Source Mask
	unsigned short	srcPort;	// Source Port
	unsigned long	dstIp;		// Destination IP
	unsigned long	dstMask;	// Destination Mask
	unsigned short	dstPort;	// Destination Port
	int				target;	// 0 Drop 1 Forward
	unsigned int	zone;
	unsigned int	status;
	int				icmp_type;
	unsigned int	protocol;*/ 

	CString sSrcAddress;
	CString sSrcMask;
	CString sSrcPort;
	CString sDstAddress;
	CString sDstMask;
	CString sDstPort;
	CString sZone;
	CString sProtocol;
	CString	sTarget;
	CString sICMP_Type;
	CString sStatus;
	CString sComment;
	CString	sNotSrc;
	CString	sNotDst;

	CStringArray	rmDistinguishedName;
//	CStringArray cName;
//	CStringArray cDistinguishedName;
	int		iComputerAll;
	int		iCountRule;
	int		iRulePosition;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESCREEN_H__C1DE7186_CF23_4126_943C_160FC92A3559__INCLUDED_)
