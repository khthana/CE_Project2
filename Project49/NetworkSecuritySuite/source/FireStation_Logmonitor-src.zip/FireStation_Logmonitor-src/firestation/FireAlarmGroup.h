#if !defined(AFX_FIREALARMGROUP_H__624079D2_D290_4653_9FB8_414124D6DC95__INCLUDED_)
#define AFX_FIREALARMGROUP_H__624079D2_D290_4653_9FB8_414124D6DC95__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireAlarmGroup.h : header file
//
#include "ADConnect.h"
#include "SockUtil.h"
#include "RuleManage.h"
/////////////////////////////////////////////////////////////////////////////
// FireAlarmGroup dialog

class FireAlarmGroup : public CDialog
{
// Construction
public:
	FireAlarmGroup(CWnd* pParent = NULL);   // standard constructor

	CString GetUser(); 
	CString GetUserDN();
	CString dwAddressToString(DWORD dwAddress);

	void GetDataFromAD();
	void ListMemberOf();
	void AddRuleToList(	unsigned long srcIp, 
						unsigned long srcMask,
						unsigned short srcPort, 
						unsigned long dstIp, 
						unsigned long dstMask,
						unsigned short dstPort, 
						unsigned int protocol, 
						int action );
	void UpdateList();
	void AddRule();
	void BreakLongRule(CString sLongRule);
	void IPStringToIPBYTE(CString sIP);

	int SetPosition(int);

// Dialog Data
	//{{AFX_DATA(FireAlarmGroup)
	enum { IDD = IDD_GROUP };
	CListBox	m_cListGroup;
	CIPAddressCtrl	m_cDstAddr;
	CIPAddressCtrl	m_cSrcMask;
	CIPAddressCtrl	m_cSrcAddr;
	CIPAddressCtrl	m_cDstMask;
	CListCtrl	m_cListRuleOfGroup;
	CString	m_sAction;
	CString	m_sProtocol;
	CString	m_sDstPort;
	CString	m_sSrcPort;
	CString	m_sNumberOfGroup;
	CString	m_sNumberOfRule;
	CString	m_sGroupName;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FireAlarmGroup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	ADConnect ADCon;

	BOOL			bAddRule;				// Check First Click Add Rule Button
	BOOL			bEditRule;				// Check First Click Edit Rule Button
	CRuleManage*	ruleManage;

	BYTE			ip01,ip02,ip03,ip04;

	int iFWGroupNo;
	int iFWGroupAll;
	int iADGroupAll;
	int iADGroupNo;
	int iCountRule;
	int iRulePosition;

	CString sAllowAll;
	CString sDenyAll;

	CStringArray gName;
	CStringArray gDistinguishedName;

	CStringArray	rmDistinguishedName;
	CString			sUserName;
	CString			sUserDN;

	CString sSrcAddress;
	CString sSrcMask;
	CString sSrcPort;
	CString sDstAddress;
	CString sDstMask;
	CString sDstPort;
	CString sProtocol;
	CString sAction;

	CString sServerAddress;
	CString sServerRuleIn;
	CString sServerRuleOut;

	unsigned long	srcIp;		// Source IP
	unsigned long	srcMask;	// Source Mask
	unsigned short	srcPort;	// Source Port
	unsigned long	dstIp;		// Destination IP
	unsigned long	dstMask;	// Destination Mask
	unsigned short	dstPort;	// Destination Port
	unsigned int	protocol;	// Protocaol Number
	int				iAction;	// 0 Drop 1 Forward
	// Generated message map functions
	//{{AFX_MSG(FireAlarmGroup)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeListboxGroup();
	afx_msg void OnButtonAddRule();
	afx_msg void OnButtonClearRule();
	afx_msg void OnButtonDefaultRule();
	afx_msg void OnButtonDeleteRule();
	afx_msg void OnButtonEditRule();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMGROUP_H__624079D2_D290_4653_9FB8_414124D6DC95__INCLUDED_)

