// Firewall StationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Firewall Station.h"
#include "Firewall StationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireStationDlg dialog

CFireStationDlg::CFireStationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFireStationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFireStationDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFireStationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFireStationDlg)
	DDX_Control(pDX, IDC_TAB1, m_cTab);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFireStationDlg, CDialog)
	//{{AFX_MSG_MAP(CFireStationDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireStationDlg message handlers

BOOL CFireStationDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Broadway"));
    lf.lfHeight = 14;
    lf.lfWeight = FW_NORMAL;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_TAB1);
	Static1->SetFont(F1,TRUE);


	CRect tabRect;

	m_cTab.GetWindowRect(tabRect);

	// Set the size and location of the child windows based on the tab control
	m_rSettingsRect.left = 1;
	m_rSettingsRect.top = 72;
	m_rSettingsRect.right = tabRect.Width() - 5;
	m_rSettingsRect.bottom = tabRect.Height() - 5;

	// Create the child windows for the main window class
	m_dGroupDlg.Create(IDD_GROUP, this);
	m_dUserDlg.Create(IDD_USERS, this);
	m_dFireScreenDlg.Create(IDD_FIRESCREEN, this);

	// This is redundant with the default value, considering what OnShowWindow does
	ShowWindowNumber(0);

	// Set the titles for each tab
	TCITEM tabItem;
	tabItem.mask = TCIF_TEXT;

	tabItem.pszText = _T("  Groups     ");
	m_cTab.InsertItem(0, &tabItem); 
  
	tabItem.pszText = _T("  Users      ");
	m_cTab.InsertItem(1, &tabItem);

	tabItem.pszText = _T("  FireScreen ");
	m_cTab.InsertItem(2, &tabItem);


	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFireStationDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFireStationDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFireStationDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFireStationDlg::ShowWindowNumber(int number)
{
     // three windows : Group User FireScreen
     int windowCount = 3;

     // Validate the parameter
     if ((number >= 0) && (number < windowCount))
     {
          // Create and assign pointers to each window
          CDialog *m_dPointer[4];

          m_dPointer[0] = &m_dGroupDlg;
          m_dPointer[1] = &m_dUserDlg;
          m_dPointer[2] = &m_dFireScreenDlg;

          // Hide every window except for the chosen one
          for (int count = 0; count < windowCount; count++)
          {
               if (count != number)
               {
                    m_dPointer[count]->ShowWindow(SW_HIDE);
               }
               else if (count == number)
               {
                    // Show the chosen window and set it's location
                    m_dPointer[count]->SetWindowPos(&wndTop, m_rSettingsRect.left,
                         m_rSettingsRect.top, m_rSettingsRect.right,
                         m_rSettingsRect.bottom, SWP_SHOWWINDOW);

                    m_cTab.SetCurSel(count);
               }
          }
     }
}

void CFireStationDlg::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
	// Get the number of the currently selected tab, and show it
	ShowWindowNumber(m_cTab.GetCurFocus());

	// Do something with the "formal parameters" so the compiler is happy in warning level 4
	pNMHDR = NULL;
	pResult = NULL;
}

void CFireStationDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	
	// When the dialog is shown, display the Group window
	if (bShow)
	{
		ShowWindowNumber(0);
	}
}
