#ifndef RULEFIRESCREEN_H
#define RULEFIRESCREEN_H

#define MAX_RULES 50
// Protocol Values

#pragma comment(lib, "Lib/WSock32.lib")
typedef struct _RuleIPTables
{
		CString status ;
		CString srcIp;  
		CString srcMask; 
		CString dstIp;  
		CString dstMask; 	
		CString protocol; 
		CString srcPort;
		CString	dstPort; 
		CString icmp_type;
		CString	zone ;	  
		CString target;
		CString comments;
		CString sNotSrc;
		CString sNotDst;

}RuleIPTables ;


class CRuleFireScreen  
{
public:
	CRuleFireScreen ();
	virtual ~CRuleFireScreen ();

// Attributes
public:
	unsigned int nRules;
	RuleIPTables rules[MAX_RULES];
//	PFFORWARD_ACTION defaultAction;

// Implementation
public:
	void DeleteRule(unsigned int position);
	void ResetRules();
	int AddRule(CString status  ,
				CString srcIp,	  
				CString srcMask, 
				CString dstIp,   
				CString dstMask, 
				CString protocol, 
				CString srcPort,
				CString	dstPort, 
				CString icmp_type,
				CString	zone ,	  
				CString target,
				CString comments,
				CString sNotSrc,
				CString sNotDst);

	//static CString GetClientIP();
};


#endif