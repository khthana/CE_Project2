// Firewall Station.h : main header file for the FIREWALL STATION application
//

#if !defined(AFX_FIREWALLSTATION_H__4D8156D3_E9FC_42EC_ABEA_2794DA79947F__INCLUDED_)
#define AFX_FIREWALLSTATION_H__4D8156D3_E9FC_42EC_ABEA_2794DA79947F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFireStationApp:
// See Firewall Station.cpp for the implementation of this class
//

class CFireStationApp : public CWinApp
{
public:
	CFireStationApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireStationApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFireStationApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESTATION_H__4D8156D3_E9FC_42EC_ABEA_2794DA79947F__INCLUDED_)
