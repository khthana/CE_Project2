#include "stdafx.h"
#include "RuleFireScreen.h"

#include "Winsock2.h"

CRuleFireScreen::CRuleFireScreen()
{
	nRules = 0;
}

CRuleFireScreen::~CRuleFireScreen()
{

}
int CRuleFireScreen::AddRule(CString status  ,
				CString srcIp,	  
				CString srcMask, 
				CString dstIp,   
				CString dstMask, 
				CString protocol, 
				CString srcPort,
				CString	dstPort, 
				CString icmp_type,
				CString	zone ,	  
				CString target,
				CString comments,
				CString sNotSrc,
				CString sNotDst)
{
	if(nRules >= MAX_RULES)
	{
		return -1;
	}

	else
	{
		rules[nRules].status		  = status;
		rules[nRules].srcIp		  = srcIp;
		rules[nRules].srcMask	  = srcMask;
		rules[nRules].srcPort	  = srcPort;
		rules[nRules].dstIp			= dstIp;
		rules[nRules].dstMask			= dstMask;
		rules[nRules].dstPort			= dstPort;
		rules[nRules].protocol		  = protocol;
		rules[nRules].icmp_type		  = icmp_type;
		rules[nRules].zone			  = zone;
		rules[nRules].target		  = target;
		rules[nRules].comments		  = comments;
		rules[nRules].sNotSrc		  = sNotSrc;
		rules[nRules].sNotDst		  = sNotDst;
		nRules++;
	}

	return 0;
}

void CRuleFireScreen::ResetRules()
{
	nRules = 0;
}

void CRuleFireScreen::DeleteRule(unsigned int position)
{
	// out of range
	if(position >= nRules)
		return;

	// If it's the las rule, I only decrement nRules
	if(position != nRules - 1)
	{
		unsigned int i;

		for(i = position + 1;i<nRules;i++)
		{
			rules[i - 1].status				= rules[i].status;
			rules[i - 1].srcIp				= rules[i].srcIp;
			rules[i - 1].srcMask			= rules[i].srcMask;
			rules[i - 1].srcPort			= rules[i].srcPort;
			rules[i - 1].dstIp				= rules[i].dstIp;
			rules[i - 1].dstMask			= rules[i].dstMask;
			rules[i - 1].dstPort			= rules[i].dstPort;
			rules[i - 1].protocol			= rules[i].protocol;
			rules[i - 1].icmp_type			= rules[i].icmp_type;
			rules[i - 1].zone				= rules[i].zone;
			rules[i - 1].target				= rules[i].target;
			rules[i - 1].comments			= rules[i].comments;
			rules[i - 1].sNotSrc			= rules[i].sNotSrc;
			rules[i - 1].sNotDst			= rules[i].sNotDst;
		}
	}
	nRules--;
}
