#if !defined(AFX_FIREALARMUSER_H__2391689E_CC44_406B_9C4B_7D05E4586206__INCLUDED_)
#define AFX_FIREALARMUSER_H__2391689E_CC44_406B_9C4B_7D05E4586206__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FireAlarmUser.h : header file
//
#include"ADConnect.h"
#include "SockUtil.h"
#include "RuleManage.h"
/////////////////////////////////////////////////////////////////////////////
// FireAlarmUser dialog

class FireAlarmUser : public CDialog
{
// Construction
public:
	FireAlarmUser(CWnd* pParent = NULL);   // standard constructor
	
	CString GetUser(); 
	CString GetUserDN();
	void GetMemberFromAD();
	void GetDataFromAD();
	CString dwAddressToString(DWORD dwAddress);
	void BreakLongRule(CString sLongRule);
	void IPStringToIPBYTE(CString sIP);
	void AddRule();
	void UpdateList();
	void AddRuleToList(	unsigned long srcIp, 
						unsigned long srcMask,
						unsigned short srcPort, 
						unsigned long dstIp, 
						unsigned long dstMask,
						unsigned short dstPort, 
						unsigned int protocol, 
						int action );
	int SetPosition(int iOldPos);

// Dialog Data
	//{{AFX_DATA(FireAlarmUser)
	enum { IDD = IDD_USERS };
	CListBox	m_cListUser;
	CComboBox	m_cComboGroup;
	CIPAddressCtrl	m_cSrcMask;
	CIPAddressCtrl	m_cSrcAddr;
	CIPAddressCtrl	m_cDstMask;
	CIPAddressCtrl	m_cDstAddr;
	CListCtrl	m_cListRuleOfUser;
	CString	m_sNumberOfRule;
	CString	m_sNumberOfUser;
	CString	m_sSrcPort;
	CString	m_sProtocol;
	CString	m_sAction;
	CString	m_sDstPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(FireAlarmUser)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	ADConnect ADCon;
	
	BOOL	bEditRule;				// Check First Click Edit Rule Button


	int iMemberAll;
	int iMemberNo;
	int iFWGroupNo;
	int iFWGroupAll;
	int iADGroupAll;
	int iADGroupNo;
	int iCountRule;
	int iRulePosition;

	CString sSrcAddress;
	CString sSrcMask;
	CString sSrcPort;
	CString sDstAddress;
	CString sDstMask;
	CString sDstPort;
	CString sProtocol;
	CString sAction;

	BYTE	ip01,ip02,ip03,ip04;

	CRuleManage*	ruleManage;
	CStringArray gName;
	CStringArray gDistinguishedName;
	CStringArray uDistinguishedName;
	CStringArray uName;
	CStringArray Members;
	CStringArray DistinguishedMember;

	CStringArray	rmDistinguishedName;
	CString			sUserName;
	CString			sUserDN;

	unsigned long	srcIp;		// Source IP
	unsigned long	srcMask;	// Source Mask
	unsigned short	srcPort;	// Source Port
	unsigned long	dstIp;		// Destination IP
	unsigned long	dstMask;	// Destination Mask
	unsigned short	dstPort;	// Destination Port
	unsigned int	protocol;	// Protocaol Number
	int				iAction;	// 0 Drop 1 Forward
	// Generated message map functions
	//{{AFX_MSG(FireAlarmUser)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeComboGroup();
	afx_msg void OnSelchangeListboxUser();
	afx_msg void OnAddRuleUser();
	afx_msg void OnClearRuleUser();
	afx_msg void OnDeleteRuleUser();
	afx_msg void OnEditRuleUser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMUSER_H__2391689E_CC44_406B_9C4B_7D05E4586206__INCLUDED_)
