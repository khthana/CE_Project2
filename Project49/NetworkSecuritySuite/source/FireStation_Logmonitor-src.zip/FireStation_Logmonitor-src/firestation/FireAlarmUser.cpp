// FireAlarmUser.cpp : implementation file
//

#include "stdafx.h"
#include "Firewall Station.h"
#include "FireAlarmUser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FireAlarmUser dialog


FireAlarmUser::FireAlarmUser(CWnd* pParent /*=NULL*/)
	: CDialog(FireAlarmUser::IDD, pParent)
{
	//{{AFX_DATA_INIT(FireAlarmUser)
	m_sNumberOfRule = _T("");
	m_sNumberOfUser = _T("");
	m_sSrcPort = _T("0");
	m_sProtocol = _T("ALL");
	m_sAction = _T("DENY");
	m_sDstPort = _T("0");
	//}}AFX_DATA_INIT
}


void FireAlarmUser::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FireAlarmUser)
	DDX_Control(pDX, IDC_LISTBOX_USER, m_cListUser);
	DDX_Control(pDX, IDC_COMBO_GROUP, m_cComboGroup);
	DDX_Control(pDX, IDC_IPADDRESS_SRC_MASK_USER, m_cSrcMask);
	DDX_Control(pDX, IDC_IPADDRESS_SRC_ADDR_USER, m_cSrcAddr);
	DDX_Control(pDX, IDC_IPADDRESS_DST_MASK_USER, m_cDstMask);
	DDX_Control(pDX, IDC_IPADDRESS_DST_ADDR_USER, m_cDstAddr);
	DDX_Control(pDX, IDC_LISTCTRL_RULE_OF_USER, m_cListRuleOfUser);
	DDX_Text(pDX, IDC_STATIC_RULE_OF_USER, m_sNumberOfRule);
	DDX_Text(pDX, IDC_NUMBER_OF_USER, m_sNumberOfUser);
	DDX_Text(pDX, IDC_SRC_PORT_USER, m_sSrcPort);
	DDX_CBString(pDX, IDC_COMBO_PROTOCOL_USER, m_sProtocol);
	DDX_CBString(pDX, IDC_COMBO_ACTION_USER, m_sAction);
	DDX_Text(pDX, IDC_DST_PORT_USER, m_sDstPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FireAlarmUser, CDialog)
	//{{AFX_MSG_MAP(FireAlarmUser)
	ON_CBN_SELCHANGE(IDC_COMBO_GROUP, OnSelchangeComboGroup)
	ON_LBN_SELCHANGE(IDC_LISTBOX_USER, OnSelchangeListboxUser)
	ON_BN_CLICKED(IDC_ADD_RULE_USER, OnAddRuleUser)
	ON_BN_CLICKED(IDC_CLEAR_RULE_USER, OnClearRuleUser)
	ON_BN_CLICKED(IDC_DELETE_RULE_USER, OnDeleteRuleUser)
	ON_BN_CLICKED(IDC_EDIT_RULE_USER, OnEditRuleUser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FireAlarmUser message handlers
BOOL FireAlarmUser::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	bEditRule = FALSE;
	// Add Column To ListControl
	m_cListRuleOfUser.InsertColumn(1,"Source IP"		,LVCFMT_CENTER,87,1);
	m_cListRuleOfUser.InsertColumn(2,"Source Mask"		,LVCFMT_CENTER,94,2);
	m_cListRuleOfUser.InsertColumn(3,"Source Port"		,LVCFMT_CENTER,68,3);
	m_cListRuleOfUser.InsertColumn(4,"Destination IP"	,LVCFMT_CENTER,87,4);
	m_cListRuleOfUser.InsertColumn(5,"Destination Mask"	,LVCFMT_CENTER,94,5);
	m_cListRuleOfUser.InsertColumn(6,"Destination Port"	,LVCFMT_CENTER,94,6);
	m_cListRuleOfUser.InsertColumn(7,"Protocol"			,LVCFMT_CENTER,51,7);
	m_cListRuleOfUser.InsertColumn(8,"Action"			,LVCFMT_CENTER,50,8);

	m_cListRuleOfUser.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);
	
	m_cSrcAddr.SetAddress(0,0,0,0);
	m_cSrcMask.SetAddress(255,255,255,255);
	m_cDstAddr.SetAddress(0,0,0,0);
	m_cDstMask.SetAddress(255,255,255,255);


	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 15;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_RULE);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_USER1);
	Static2->SetFont(F1,TRUE);
	CStatic *Static3 = (CStatic*) GetDlgItem(IDC_STATIC_USER2);
	Static3->SetFont(F1,TRUE);
	CStatic *Static4 = (CStatic*) GetDlgItem(IDC_STATIC_ASS);
	Static4->SetFont(F1,TRUE);

	ruleManage = new CRuleManage();

	m_cComboGroup.ResetContent();
	m_cListUser.ResetContent();

	ADCon.GetList("group",gName,gDistinguishedName);

	sUserName = GetUser(); 
	sUserDN = GetUserDN();

	iADGroupAll = gName.GetSize();
	iFWGroupAll = gName.GetSize() - 31;

	for(int iCount = 31 ; iCount < iADGroupAll ;iCount++)
	{
		m_cComboGroup.AddString(gName.GetAt(iCount));
	//	MessageBox(gDistinguishedName.GetAt(iCount),NULL,MB_OK);
	}
	ADCon.GetMember(gDistinguishedName.GetAt(31),Members,DistinguishedMember);

	for(iCount =0; iCount< Members.GetSize();iCount++)
	{	
		m_cListUser.AddString(Members.GetAt(iCount));
		//MessageBox(DistinguishedMember.GetAt(iCount),NULL,MB_OK);
	}

	iMemberAll = Members.GetSize();

	m_cComboGroup.SetCurSel(0);
	m_cListUser.SetCurSel(0);

	m_sNumberOfUser.Format(" %d",iMemberAll);
	
	OnSelchangeListboxUser();

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void FireAlarmUser::GetMemberFromAD()
{
	Members.RemoveAll();
	DistinguishedMember.RemoveAll();
	ADCon.GetMember(gDistinguishedName.GetAt(iADGroupNo),Members,DistinguishedMember);
}

void FireAlarmUser::GetDataFromAD()
{
	rmDistinguishedName.RemoveAll();
//	MessageBox(DistinguishedMember.GetAt(iMemberNo),NULL,MB_OK);
	ADCon.GetRule(DistinguishedMember.GetAt(iMemberNo),rmDistinguishedName);
	iCountRule = rmDistinguishedName.GetSize();
}
CString FireAlarmUser::GetUser()
{
	char User[100];
	DWORD Len = sizeof(User);
	GetUserName(User, &Len);
	return User;
}

CString FireAlarmUser::GetUserDN()
{
	
	if (ADCon.GetList("user",uName,uDistinguishedName) != TRUE)
	{
		AfxMessageBox("Can't get domain...!!!");
		return " ";
	}

	for(long icount=0 ; icount < uName.GetSize();icount++)
	{
		if(sUserName.Compare(uName.GetAt(icount)) == 0)
		{
			return uDistinguishedName.GetAt(icount);
		}
	}
	return "";
}


void FireAlarmUser::OnSelchangeComboGroup() 
{
	iADGroupNo = m_cComboGroup.GetCurSel()+31;	// Get specific group in this project
	
	GetMemberFromAD();
	CString Str;
	int totalItem = m_cListUser.GetCount();
	for (int i =0 ; i<totalItem ;i++){
		m_cListUser.DeleteString(0);
	}

	for(int iCount =0; iCount< Members.GetSize();iCount++)
	{
		m_cListUser.AddString(Members.GetAt(iCount));
	}
	iMemberAll = Members.GetSize();
	m_sNumberOfUser.Format(" %d",iMemberAll);
	UpdateData(FALSE);
}

void FireAlarmUser::OnSelchangeListboxUser() 
{	
	// TODO: Add your control notification handler code here
	iMemberNo = m_cListUser.GetCurSel();
	GetDataFromAD();

	m_cListRuleOfUser.DeleteAllItems();		// Clear All Item in List

	if (iCountRule != 0)
	{
		ruleManage->ResetRules();
		AddRule();
		UpdateList();
	}else{
		m_sNumberOfRule.Format("%u",0);
		UpdateData(FALSE);
	}
}
CString FireAlarmUser::dwAddressToString(DWORD dwAddress)
{
	CString strIP,strF1,strF2,strF3,strF4;

	DWORD temp1,temp2,temp3,dwF1,dwF2,dwF3;
	temp1 = dwAddress%16777216;
	dwF1 = dwAddress/16777216;
	strF1.Format("%u",dwF1);
	temp2 = temp1%65536;
	dwF2 = temp1/65536;
	strF2.Format("%u",dwF2);
	temp3 = temp2%256;
	dwF3 = temp2/256;
	strF3.Format("%u",dwF3);
	strF4.Format("%u",temp3);

	strIP = strF1 + "." + strF2 + "." + strF3 + "." + strF4;

	return strIP;
}
void FireAlarmUser::BreakLongRule(CString sLongRule)
{
	// change long rule string to each variables
	CString tmpString;
	sLongRule.TrimLeft();	//removes newline, space, and tab characters
	sLongRule.TrimRight();	//removes newline, space, and tab characters

	for ( int i=0; i<7; i++ ) 
	{
		int pos = sLongRule.Find(' ');
		tmpString = sLongRule.Left(pos);
		sLongRule.Delete(0, pos+1);

		switch(i)
		{
			case 0 :
				sSrcAddress = tmpString;
				break;
			case 1 :
				sSrcMask = tmpString;
				break;
			case 2 :
				sSrcPort = tmpString;
				break;
			case 3 :
				sDstAddress = tmpString;
				break;
			case 4 :
				sDstMask = tmpString;
				break;
			case 5 :
				sDstPort = tmpString;
				break;
			case 6 :
				sProtocol = tmpString;
				break;
		}

	}

	sAction = sLongRule;
}
void FireAlarmUser::IPStringToIPBYTE(CString sIP)
{
	CString tmpString;
	sIP.TrimLeft();		//removes newline, space, and tab characters
	sIP.TrimRight();	//removes newline, space, and tab characters

	for ( int i = 0; i<3; i++ ) 
	{
		int pos = sIP.Find('.');
		tmpString = sIP.Left(pos);
		sIP.Delete(0, pos+1);		

		switch(i)
		{
			case 0 :
				ip01 = atoi(tmpString);
				break;
			case 1 :
				ip02 = atoi(tmpString);
				break;
			case 2 :
				ip03 = atoi(tmpString);
				break;
		}
	}
	ip04 = atoi(sIP);
}
void FireAlarmUser::UpdateList()
{
	// Update List Control
	m_cListRuleOfUser.DeleteAllItems();

	unsigned int i;
	for( i = 0;i < ruleManage->nRules ; i++)
	{
		AddRuleToList(ruleManage->rules[i].sourceIp,
					  ruleManage->rules[i].sourceMask,
					  ruleManage->rules[i].sourcePort,
					  ruleManage->rules[i].destinationIp,
					  ruleManage->rules[i].destinationMask,
					  ruleManage->rules[i].destinationPort,
					  ruleManage->rules[i].protocol,
					  ruleManage->rules[i].action);
	}
	
	m_sNumberOfRule.Format(" %d",ruleManage->nRules);
	UpdateData(FALSE);
}
void FireAlarmUser::AddRule()
{
	for( int i = iCountRule - 1; i >= 0; i--)
		{
		BreakLongRule(rmDistinguishedName.GetAt(i));

		int result;
		result = inet_addr(sSrcAddress, &srcIp);
		if(result == -1)
		{
			AfxMessageBox("Invalid source address");
			return;
		}

		result = inet_addr(sSrcMask, &srcMask);
		if(result == -1)
		{
			AfxMessageBox("Invalid source mask");
			return;
		}

		result = inet_addr(sDstAddress, &dstIp);
		if(result == -1)
		{
			AfxMessageBox("Invalid destination address");
			return;
		}
	
		result = inet_addr(sDstMask, &dstMask);
		if(result == -1)
		{
			AfxMessageBox("Invalid destination mask");
			return;
		}	
	
		if(sProtocol == "TCP")
			protocol = 6;
		else if(sProtocol == "UDP")
			protocol = 17;
		else if(sProtocol == "ICMP")
			protocol = 1;
		else
			protocol = 0;

		if(sAction == "")
		{
			AfxMessageBox("Please, fill action field.");
			return;
		}
		else
		{
			if(sAction == "ALLOW")
				iAction = 0;
			else
				iAction = 1;
		}

		srcPort = atoi(sSrcPort);
		dstPort = atoi(sDstPort);

	// check number of rules
		if(ruleManage->nRules < MAX_RULES )
		{
		// Add the rule to the rule lists			
			if(ruleManage->AddRule(	srcIp, 
								srcMask, 
								srcPort, 
								dstIp, 
								dstMask, 
								dstPort, 
								protocol, 
								iAction) != 0)
				AfxMessageBox("Error adding the rule.");
		}
	}
}
void FireAlarmUser::AddRuleToList(	unsigned long	srcIp   , 
									unsigned long	srcMask ,
									unsigned short	srcPort , 
									unsigned long	dstIp   , 
									unsigned long	dstMask ,
									unsigned short	dstPort , 
									unsigned int	protocol, 
									int				action   )
{
	char	ip[16];
	char	port[6];
	LVITEM	it;
	int		pos;

	
	it.mask		= LVIF_TEXT;
	it.iItem	= m_cListRuleOfUser.GetItemCount();
	it.iSubItem	= 0;
	it.pszText	= (srcIp == 0) ? "All" : IpToString(ip, srcIp);
	pos			= m_cListRuleOfUser.InsertItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 1;
	it.pszText	= IpToString(ip, srcMask);
	m_cListRuleOfUser.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 2;

	it.pszText	= (srcPort == 0) ? "All" : itoa(srcPort, port, 10);

	m_cListRuleOfUser.SetItem(&it);
	
	it.iItem	= pos;
	it.iSubItem	= 3;
	it.pszText	= (dstIp == 0) ? "All" : IpToString(ip, dstIp);
	m_cListRuleOfUser.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 4;
	it.pszText	= IpToString(ip, dstMask);
	m_cListRuleOfUser.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem = 5;

	it.pszText	= (dstPort == 0) ? "All" : itoa(dstPort, port, 10);

	m_cListRuleOfUser.SetItem(&it);


	it.iItem	= pos;
	it.iSubItem	= 6;

	if(protocol == 1)
		it.pszText = "ICMP";

	else if(protocol == 6)
		it.pszText = "TCP";

	else if(protocol == 17)
		it.pszText = "UDP";

	else
		it.pszText = "All";

	m_cListRuleOfUser.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 7;
	it.pszText = action ? "Drop" : "Forward";
	m_cListRuleOfUser.SetItem(&it);
}
int FireAlarmUser::SetPosition(int iOldPos)
{
	return ruleManage->nRules - iOldPos - 1;
}
void FireAlarmUser::OnAddRuleUser() 
{
	DWORD dwAddress;
	CString sSrcAddr,sSrcMask,sDstAddr,sDstMask,sLongRule;
	CString sDefaultRule;

	UpdateData(TRUE);
	
	m_cSrcAddr.GetAddress(dwAddress);
	sSrcAddr = dwAddressToString(dwAddress);

	m_cSrcMask.GetAddress(dwAddress);
	sSrcMask = dwAddressToString(dwAddress);
	
	m_cDstAddr.GetAddress(dwAddress);
	sDstAddr = dwAddressToString(dwAddress);

	m_cDstMask.GetAddress(dwAddress);
	sDstMask = dwAddressToString(dwAddress);

	sLongRule = sSrcAddr + " " + sSrcMask + " " + m_sSrcPort + " " + 
				sDstAddr + " " + sDstMask + " " + m_sDstPort + " " +
				m_sProtocol + " " + m_sAction;

	GetDataFromAD();

	if(iCountRule == 0){
		ADCon.SetNewRule(DistinguishedMember.GetAt(iMemberNo),sLongRule);	
	}else{
		sDefaultRule = rmDistinguishedName.GetAt(0);
		ADCon.SetDeleteRule(DistinguishedMember.GetAt(iMemberNo),0);
		ADCon.SetNewRule(DistinguishedMember.GetAt(iMemberNo),sDefaultRule);
		ADCon.SetNewRule(DistinguishedMember.GetAt(iMemberNo),sLongRule);
		
	}

	m_cSrcAddr.SetAddress(0,0,0,0);
	m_cSrcMask.SetAddress(255,255,255,255);
	m_cDstAddr.SetAddress(0,0,0,0);
	m_cDstMask.SetAddress(255,255,255,255);
	m_sSrcPort = "0";
	m_sDstPort = "0";
	m_sProtocol = "ALL";
	m_sAction = "DENY";
	UpdateData(FALSE);

	OnSelchangeListboxUser();	
}

void FireAlarmUser::OnClearRuleUser() 
{
	// Delete from AD
	GetDataFromAD();
	for (int i = 0 ; i < iCountRule ; i++)
		ADCon.SetDeleteRule(DistinguishedMember.GetAt(iMemberNo),i);
	OnSelchangeListboxUser();
}

void FireAlarmUser::OnDeleteRuleUser() 
{
	GetDataFromAD();

	// Get rule position
	POSITION pos = m_cListRuleOfUser.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		AfxMessageBox("No rule is selected.");
		return;
	}

	iRulePosition = SetPosition(m_cListRuleOfUser.GetNextSelectedItem(pos));
	
	// Delete from AD	
	ADCon.SetDeleteRule(DistinguishedMember.GetAt(iMemberNo),iRulePosition);
	OnSelchangeListboxUser();
}

void FireAlarmUser::OnEditRuleUser() 
{
	if (bEditRule)
	{
		DWORD dwAddress;
		CString sSrcAddr,sSrcMask,sDstAddr,sDstMask,sLongRule;

		UpdateData(TRUE);
	
		m_cSrcAddr.GetAddress(dwAddress);
		sSrcAddr = dwAddressToString(dwAddress);

		m_cSrcMask.GetAddress(dwAddress);
		sSrcMask = dwAddressToString(dwAddress);
	
		m_cDstAddr.GetAddress(dwAddress);
		sDstAddr = dwAddressToString(dwAddress);

		m_cDstMask.GetAddress(dwAddress);
		sDstMask = dwAddressToString(dwAddress);

		sLongRule = sSrcAddr + " " + sSrcMask + " " + m_sSrcPort + " " + 
					sDstAddr + " " + sDstMask + " " + m_sDstPort + " " +
					m_sProtocol + " " + m_sAction;
		
		int i;
		GetDataFromAD();
		rmDistinguishedName.SetAt(iRulePosition,sLongRule);		

		// Delete All Rule From AD.
		for( i = 0; i < iCountRule; i++)
		{
			ADCon.SetDeleteRule(DistinguishedMember.GetAt(iMemberNo),i);
		}

		// Add All and New Rule  To AD.
		for( i = iCountRule - 1; i >=0 ; i--)
		{
			ADCon.SetNewRule(DistinguishedMember.GetAt(iMemberNo),rmDistinguishedName.GetAt(i));
		}

		m_cSrcAddr.SetAddress(0,0,0,0);
		m_cSrcMask.SetAddress(255,255,255,255);
		m_cDstAddr.SetAddress(0,0,0,0);
		m_cDstMask.SetAddress(255,255,255,255);
		m_sSrcPort = "0";
		m_sDstPort = "0";
		m_sProtocol = "ALL";
		m_sAction = "DENY";
		UpdateData(FALSE);
		
		GetDlgItem( IDC_ADD_RULE_USER )->EnableWindow(TRUE);
		GetDlgItem( IDC_DELETE_RULE_USER )->EnableWindow(TRUE);
		GetDlgItem( IDC_CLEAR_RULE_USER )->EnableWindow(TRUE);
		SetDlgItemText( IDC_EDIT_RULE_USER , "Edit" ) ;

		bEditRule = FALSE;
		OnSelchangeListboxUser();	
		
	}
	else
	{
		GetDataFromAD();

		POSITION pos = m_cListRuleOfUser.GetFirstSelectedItemPosition();
		if (pos == NULL)
		{
			AfxMessageBox("No rule is selected.");
			return;
		}
	
		iRulePosition = SetPosition(m_cListRuleOfUser.GetNextSelectedItem(pos));

		BreakLongRule(rmDistinguishedName.GetAt(iRulePosition));
		
		IPStringToIPBYTE(sSrcAddress);
		m_cSrcAddr.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sSrcMask);
		m_cSrcMask.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sDstAddress);
		m_cDstAddr.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sDstMask);
		m_cDstMask.SetAddress(ip01,ip02,ip03,ip04);

		m_sSrcPort = sSrcPort;
		m_sDstPort = sDstPort;
		m_sProtocol = sProtocol;
		m_sAction = sAction;
		UpdateData(FALSE);

		GetDlgItem( IDC_ADD_RULE_USER )->EnableWindow(FALSE);	
		GetDlgItem( IDC_DELETE_RULE_USER )->EnableWindow(FALSE);
		GetDlgItem( IDC_CLEAR_RULE_USER )->EnableWindow(FALSE);
		SetDlgItemText( IDC_EDIT_RULE_USER , "Edit OK" ) ;

		bEditRule = TRUE;

	}
}
