// FireScreen.cpp : implementation file
//

#include "stdafx.h"
#include "Firewall Station.h"
#include "FireScreen.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define FireScreenURL "CN=FIRESCREEN,CN=Computers,DC=hephaestus,DC=com"
/////////////////////////////////////////////////////////////////////////////
// FireScreen dialog


FireScreen::FireScreen(CWnd* pParent /*=NULL*/)
	: CDialog(FireScreen::IDD, pParent)
{
	//{{AFX_DATA_INIT(FireScreen)
	m_sSrcPort = _T("-");
	m_sDstPort = _T("-");
	m_sTarget = _T("DROP");
	m_sNumberOfRule = _T("");
	m_sStatus = _T("TRUE");
	m_sZone = _T("DMZ-in");
	m_bNotDst = FALSE;
	m_sICMP_type = _T("-");
	m_bNotSrc = FALSE;
	m_sShowComment = _T("");
	m_sShowDstAddr = _T("");
	m_sShowDstMask = _T("");
	m_sShowDstPort = _T("");
	m_sShowICMP = _T("");
	m_sShowProtocol = _T("");
	m_sShowSrcAddr = _T("");
	m_sShowSrcMask = _T("");
	m_sShowSrcPort = _T("");
	m_sShowStatus = _T("");
	m_sShowTarget = _T("");
	m_sShowZone = _T("");
	m_sComment = _T("");
	//}}AFX_DATA_INIT
}


void FireScreen::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FireScreen)
	DDX_Control(pDX, IDC_COMBO_PROTOCOL_SCREEN, m_cProtocol);
	DDX_Control(pDX, IDC_FIRESCREEN_DST_MASK, m_cDstMask);
	DDX_Control(pDX, IDC_FIRESCREEN_DST_ADDR, m_cDstAddr);
	DDX_Control(pDX, IDC_FIRESCREEN_SRC_MASK, m_cSrcMask);
	DDX_Control(pDX, IDC_FIRESCREEN_SRC_ADDR, m_cSrcAddr);
	DDX_Control(pDX, IDC_LISTCTRL_RULE_OF_FIRESCREEN, m_cListRuleOfFireScreen);
	DDX_Text(pDX, IDC_FIRESCREEN_SRC_PORT, m_sSrcPort);
	DDX_Text(pDX, IDC_FIRESCREEN_DST_PORT, m_sDstPort);
	DDX_CBString(pDX, IDC_COMBO_TARGET, m_sTarget);
	DDX_Text(pDX, IDC_RULE_OF_FIRESCREEN, m_sNumberOfRule);
	DDX_CBString(pDX, IDC_COMBO_STATUS, m_sStatus);
	DDX_CBString(pDX, IDC_COMBO_ZONE, m_sZone);
	DDX_Check(pDX, IDC_NOT_DST, m_bNotDst);
	DDX_Text(pDX, IDC_EDIT_ICMPTYPE, m_sICMP_type);
	DDX_Check(pDX, IDC_NOT_SRC, m_bNotSrc);
	DDX_CBIndex(pDX, IDC_COMBO_PROTOCOL_SCREEN, m_sProtocol);
	DDX_Text(pDX, IDC_SHOW_COMMENT, m_sShowComment);
	DDX_Text(pDX, IDC_SHOW_DSTADDR, m_sShowDstAddr);
	DDX_Text(pDX, IDC_SHOW_DSTMASK, m_sShowDstMask);
	DDX_Text(pDX, IDC_SHOW_DSTPORT, m_sShowDstPort);
	DDX_Text(pDX, IDC_SHOW_ICMP, m_sShowICMP);
	DDX_Text(pDX, IDC_SHOW_PROTOCOL, m_sShowProtocol);
	DDX_Text(pDX, IDC_SHOW_SRCADDR, m_sShowSrcAddr);
	DDX_Text(pDX, IDC_SHOW_SRCMASK, m_sShowSrcMask);
	DDX_Text(pDX, IDC_SHOW_SRCPORT, m_sShowSrcPort);
	DDX_Text(pDX, IDC_SHOW_STATUS, m_sShowStatus);
	DDX_Text(pDX, IDC_SHOW_TARGET, m_sShowTarget);
	DDX_Text(pDX, IDC_SHOW_ZONE, m_sShowZone);
	DDX_Text(pDX, IDC_EDIT_COMMENT, m_sComment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FireScreen, CDialog)
	//{{AFX_MSG_MAP(FireScreen)
	ON_BN_CLICKED(IDC_FIRESCREEN_ADD_RULE, OnFirescreenAddRule)
	ON_BN_CLICKED(IDC_FIRESCREEN_DELETE_RULE, OnFirescreenDeleteRule)
	ON_BN_CLICKED(IDC_FIRESCREEN_EDIT_RULE, OnFirescreenEditRule)
	ON_BN_CLICKED(IDC_FIRESCREEN_CLEAR_RULE, OnFirescreenClearRule)
	ON_CBN_SELCHANGE(IDC_COMBO_PROTOCOL_SCREEN, OnSelchangeComboProtocolScreen)
	ON_NOTIFY(NM_CLICK, IDC_LISTCTRL_RULE_OF_FIRESCREEN, OnClickListctrlRuleOfFirescreen)
	ON_BN_CLICKED(IDC_BUTTON_POLICY, OnButtonPolicy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FireScreen message handlers

BOOL FireScreen::OnInitDialog() 
{
	CDialog::OnInitDialog();
	bEditRule = FALSE;
	// Add Column To ListControl
	m_cListRuleOfFireScreen.InsertColumn(1,"Source IP"		,LVCFMT_CENTER,100,1);
	m_cListRuleOfFireScreen.InsertColumn(2,"Destination IP"	,LVCFMT_CENTER,100,2);
	m_cListRuleOfFireScreen.InsertColumn(3,"Protocol"		,LVCFMT_CENTER,80,3);
	m_cListRuleOfFireScreen.InsertColumn(4,"Zone"			,LVCFMT_CENTER,100,4);
	m_cListRuleOfFireScreen.InsertColumn(5,"Target"			,LVCFMT_CENTER,70,5);

	m_cListRuleOfFireScreen.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);
	
	m_cSrcAddr.SetAddress(0,0,0,0);
	m_cSrcMask.SetAddress(255,255,255,255);
	m_cDstAddr.SetAddress(0,0,0,0);
	m_cDstMask.SetAddress(255,255,255,255);

	m_cListRuleOfFireScreen.DeleteAllItems();		// Clear All Item in List

	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 15;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_SCREEN1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_SCREEN2);
	Static2->SetFont(F1,TRUE);
	CStatic *Static3 = (CStatic*) GetDlgItem(IDC_STATIC_SCREEN3);
	Static3->SetFont(F1,TRUE);
	CFont *F2 = new CFont();
	LOGFONT lf2 = {0};
    _tcscpy(lf2.lfFaceName, _T("Arial"));
    lf2.lfHeight = 14;
    lf2.lfWeight = FW_BOLD;
//	lf2.lfItalic = 1;
    F2->CreateFontIndirect(&lf2);
	CStatic *Static4 = (CStatic*) GetDlgItem(IDC_STATIC_1);
	Static4->SetFont(F2,TRUE);
	CStatic *Static5 = (CStatic*) GetDlgItem(IDC_STATIC_2);
	Static5->SetFont(F2,TRUE);
	CStatic *Static6 = (CStatic*) GetDlgItem(IDC_STATIC_3);
	Static6->SetFont(F2,TRUE);
	CStatic *Static7 = (CStatic*) GetDlgItem(IDC_STATIC_4);
	Static7->SetFont(F2,TRUE);
	CStatic *Static8 = (CStatic*) GetDlgItem(IDC_STATIC_5);
	Static8->SetFont(F2,TRUE);
	CStatic *Static9 = (CStatic*) GetDlgItem(IDC_STATIC_7);
	Static9->SetFont(F2,TRUE);
	CStatic *Static11 = (CStatic*) GetDlgItem(IDC_STATIC_8);
	Static11->SetFont(F2,TRUE);
	CStatic *Static12 = (CStatic*) GetDlgItem(IDC_STATIC_9);
	Static12->SetFont(F2,TRUE);
	CStatic *Static14 = (CStatic*) GetDlgItem(IDC_STATIC_10);
	Static14->SetFont(F2,TRUE);
	CStatic *Static15 = (CStatic*) GetDlgItem(IDC_STATIC_11);
	Static15->SetFont(F2,TRUE);
	CStatic *Static16 = (CStatic*) GetDlgItem(IDC_STATIC_12);
	Static16->SetFont(F2,TRUE);
	CStatic *Static17 = (CStatic*) GetDlgItem(IDC_STATIC_13);
	Static17->SetFont(F2,TRUE);


	GetDlgItem( IDC_EDIT_ICMPTYPE		)->EnableWindow(FALSE);
	GetDlgItem( IDC_FIRESCREEN_SRC_PORT )->EnableWindow(FALSE);
	GetDlgItem( IDC_FIRESCREEN_DST_PORT )->EnableWindow(FALSE);


	m_cProtocol.SetCurSel(0);
	ruleManage = new CRuleFireScreen();
	GetDataFromAD();
	if (iCountRule != 0)
	{
//		AfxMessageBox("Test");
		ruleManage->ResetRules();
		AddRule();
		UpdateList();
	}else{
		m_sNumberOfRule.Format("%u",0);
	}

	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void FireScreen::GetDataFromAD()
{
	rmDistinguishedName.RemoveAll();
	ADCon.GetRule(FireScreenURL,rmDistinguishedName);
	iCountRule = rmDistinguishedName.GetSize();
}

void FireScreen::IPStringToIPBYTE(CString sIP)
{
	CString tmpString;
	sIP.TrimLeft();	//removes newline, space, and tab characters
	sIP.TrimRight();	//removes newline, space, and tab characters

	for ( int i = 0; i<3; i++ ) 
	{
		int pos = sIP.Find('.');
		tmpString = sIP.Left(pos);
		sIP.Delete(0, pos+1);		

		switch(i)
		{
			case 0 :
				ip01 = atoi(tmpString);
				break;
			case 1 :
				ip02 = atoi(tmpString);
				break;
			case 2 :
				ip03 = atoi(tmpString);
				break;
		}
	}
	ip04 = atoi(sIP);
}
void FireScreen::UpdateList()
{
	// Update List Control
	m_cListRuleOfFireScreen.DeleteAllItems();

	unsigned int i;
	for( i = 0;i < ruleManage->nRules ; i++)
	{
		AddRuleToList(ruleManage->rules[i].status,
					  ruleManage->rules[i].srcIp,
					  ruleManage->rules[i].srcMask,
					  ruleManage->rules[i].dstIp,
					  ruleManage->rules[i].dstMask,
					  ruleManage->rules[i].protocol,
					  ruleManage->rules[i].srcPort,
					  ruleManage->rules[i].dstPort,
					  ruleManage->rules[i].icmp_type,
					  ruleManage->rules[i].zone,
					  ruleManage->rules[i].target,
					  ruleManage->rules[i].comments,
					  ruleManage->rules[i].sNotSrc,
					  ruleManage->rules[i].sNotDst);
	}
	
	m_sNumberOfRule.Format(" %d",ruleManage->nRules);
	UpdateData(FALSE);
}

void FireScreen::BreakLongRule(CString sLongRule)
{
		// change long rule string to each variables
	CString tmpString;
	sLongRule.TrimLeft();	//removes newline, space, and tab characters
	sLongRule.TrimRight();	//removes newline, space, and tab characters
	int i,pos;
	for (  i=0; i<11; i++ ) 
	{
		pos = sLongRule.Find(':');
		tmpString = sLongRule.Left(pos);
		sLongRule.Delete(0, pos+1);
		
		switch(i)
		{
			case 0: 
				sStatus			= tmpString;
				break;
			case 1 :
				sSrcAddress		= tmpString;
				break;
			case 2 :
				sSrcMask		= tmpString;
				break;
			case 3 :
				sDstAddress		= tmpString;
				break;
			case 4 :
				sDstMask		= tmpString;
				break;
			case 5:
				sProtocol		= tmpString;
				break;
			case 6 :
				sSrcPort		= tmpString;
				break;	
			case 7 :
				sDstPort		= tmpString;
				break;
			case 8 :
				sICMP_Type		= tmpString;
				break;
			case 9 :
				sZone			= tmpString;
				break;
			case 10 :
				sTarget			= tmpString;
				break;
			case 11:
				sComment		= tmpString;
		}

	}
	
	tmpString="";
	pos = sSrcAddress	.Find(' ');
	tmpString = sSrcAddress	.Left(pos);
	sSrcAddress.Delete(0, pos+1);
	sNotSrc=tmpString;

	tmpString="";
	pos = sDstAddress.Find(' ');
	tmpString = sDstAddress.Left(pos);
	sDstAddress.Delete(0, pos+1);
	sNotDst=tmpString;

}
int FireScreen::SetPosition(int iOldPos)
{
	return ruleManage->nRules - iOldPos - 1;
}
void FireScreen::AddRule()
{
	for( int i = iCountRule - 1; i >= 0; i--)
		{

		BreakLongRule(rmDistinguishedName.GetAt(i));
	// check number of rule
		if(ruleManage->nRules < MAX_RULES )
		{
		// Add the rule to the rule lists			
			if(ruleManage->AddRule(	sStatus,
									sSrcAddress, 
									sSrcMask,
									sDstAddress,
									sDstMask,
									sProtocol,
									sSrcPort,
									sDstPort,
									sICMP_Type,
									sZone,
									sTarget,
									sComment,
									sNotSrc,
									sNotDst) != 0)
				AfxMessageBox("Error adding the rule.");
			else
			{
//				AfxMessageBox("Add rule OK");
			}
		}
	//	MessageBox(sZone,NULL,MB_OK);
	}
}
void FireScreen::AddRuleToList(	CString status  ,
				CString srcIp,	  
				CString srcMask, 
				CString dstIp,   
				CString dstMask, 
				CString protocol, 
				CString srcPort,
				CString	dstPort, 
				CString icmp_type,
				CString	zone ,	  
				CString target,
				CString comments,
				CString sNotSrc2,
				CString sNotDst2)
{

	LVITEM	it;
	int		pos;
	CString tmp;
	
	it.mask		= LVIF_TEXT;
	it.iItem	= m_cListRuleOfFireScreen.GetItemCount();
	it.iSubItem	= 0;
	if(sNotSrc2=="!")
	{
		tmp="! "+srcIp;
		it.pszText	= (srcIp == "0.0.0.0") ? "! All" : (LPTSTR)(LPCTSTR)tmp;
	}else
	{
		it.pszText	= (srcIp == "0.0.0.0") ? "All" : (LPTSTR)(LPCTSTR)srcIp;
	}
	pos			= m_cListRuleOfFireScreen.InsertItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 1;
	if(sNotDst2=="!")
	{
		tmp="! "+dstIp;
		it.pszText	= (dstIp == "0.0.0.0") ? "! All" : (LPTSTR)(LPCTSTR)tmp;
	}else{
		it.pszText	= (dstIp == "0.0.0.0") ? "All" : (LPTSTR)(LPCTSTR)dstIp;
	}
	m_cListRuleOfFireScreen.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 2;
	it.pszText = (LPTSTR)(LPCTSTR)protocol; 
	m_cListRuleOfFireScreen.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 3;
	it.pszText = (LPTSTR)(LPCTSTR)zone; 
	m_cListRuleOfFireScreen.SetItem(&it);

	it.iItem	= pos;
	it.iSubItem	= 4;
	it.pszText = (LPTSTR)(LPCTSTR)target;
	m_cListRuleOfFireScreen.SetItem(&it);
	
}
CString FireScreen::dwAddressToString(DWORD dwAddress)
{
	CString strIP,strF1,strF2,strF3,strF4;

	DWORD temp1,temp2,temp3,dwF1,dwF2,dwF3;
	temp1 = dwAddress%16777216;
	dwF1 = dwAddress/16777216;
	strF1.Format("%u",dwF1);
	temp2 = temp1%65536;
	dwF2 = temp1/65536;
	strF2.Format("%u",dwF2);
	temp3 = temp2%256;
	dwF3 = temp2/256;
	strF3.Format("%u",dwF3);
	strF4.Format("%u",temp3);

	strIP = strF1 + "." + strF2 + "." + strF3 + "." + strF4;

	return strIP;
}
void FireScreen::OnFirescreenAddRule() 
{
	// TODO: Add your control notification handler code here
	DWORD dwAddress;
	CString sSrcAddr,sSourceMask,sDstAddr,sDestinationMask,sLongRule;
	CString sDefaultRule;

	UpdateData(TRUE);
	
	m_cSrcAddr.GetAddress(dwAddress);
	sSrcAddr = dwAddressToString(dwAddress);

	m_cSrcMask.GetAddress(dwAddress);
	sSourceMask = dwAddressToString(dwAddress);
	
	m_cDstAddr.GetAddress(dwAddress);
	sDstAddr = dwAddressToString(dwAddress);

	m_cDstMask.GetAddress(dwAddress);
	sDestinationMask = dwAddressToString(dwAddress);

	if(m_bNotSrc==TRUE&&m_bNotDst==TRUE){
		sSrcAddr="! "+sSrcAddr;
		sDstAddr="! "+sDstAddr;
	}else if(m_bNotSrc==TRUE&&m_bNotDst==FALSE)
	{
		sSrcAddr="! "+sSrcAddr;
	}else if(m_bNotSrc==FALSE&&m_bNotDst==TRUE)
	{
		sDstAddr="! "+sDstAddr;
	}
	if(m_sSrcPort==""){
		m_sSrcPort="-";
	}
	if(m_sDstPort==""){
		m_sDstPort="-";
	}
	CString str;
	m_cProtocol.GetLBText( m_sProtocol, str );

	CString str2;
	GetDlgItemText(IDC_BUTTON_POLICY,str2);
	if(str2=="FireScreen Policy")
	{
		sLongRule = m_sStatus			+ ":" +  sSrcAddr		+ ":" + 
					sSourceMask			+ ":" +  sDstAddr		+ ":" +  
					sDestinationMask	+ ":" +  str			+ ":" +
					m_sSrcPort			+ ":" +  m_sDstPort		+ ":" +  
					m_sICMP_type		+ ":" +	 m_sZone		+ ":" +
					m_sTarget			+ ":" +	 m_sComment	 ;
	}else{
		if(m_sDstPort=="-"||m_sDstPort==""){
			AfxMessageBox("Please Insert Destination Port");
			return;
		}else{
			sLongRule = m_sStatus			+ ":" +  sSrcAddr		+ ":" + 
						sSourceMask			+ ":" +  sDstAddr		+ ":" +  
						sDestinationMask	+ ":" +  "tcp"			+ ":" +
						m_sSrcPort			+ ":" +  m_sDstPort		+ ":" +  
						m_sICMP_type		+ ":" +	 "LOCAL-in"		+ ":" +
						"ACCEPT"			+ ":" +	 m_sComment		 ;
		}
	}

	//MessageBox(sLongRule,NULL,MB_OK);
	GetDataFromAD();

	if(iCountRule == 0){
		ADCon.SetNewRule(FireScreenURL,sLongRule);	
	}else{
		sDefaultRule = rmDistinguishedName.GetAt(0);
		ADCon.SetDeleteRule(FireScreenURL,0);
		ADCon.SetNewRule(FireScreenURL,sDefaultRule);
		ADCon.SetNewRule(FireScreenURL,sLongRule);
		
	}
	
	ADCon.SetDeleteUpdate();
	ADCon.SetNewUpdate();

	m_cSrcAddr.SetAddress(0,0,0,0);
	m_cSrcMask.SetAddress(255,255,255,255);
	m_cDstAddr.SetAddress(0,0,0,0);
	m_cDstMask.SetAddress(255,255,255,255);
	m_sStatus	= "TRUE";
	m_sTarget	= "DROP";
	m_sZone		= "DMZ-in";
	m_bNotDst = FALSE;
	m_bNotSrc = FALSE;
	SetDlgItemText(IDC_EDIT_COMMENT,"");
	m_bNotSrc = FALSE;
	m_bNotDst = FALSE;
	m_cProtocol.SetCurSel(0);
	OnSelchangeComboProtocolScreen() ;

	m_sShowSrcAddr	="";
	m_sShowSrcMask	="";
	m_sShowSrcPort	="";
	m_sShowDstAddr	="";
	m_sShowDstMask	="";
	m_sShowDstPort	="";
	m_sShowZone		="";
	m_sShowProtocol	="";
	m_sShowTarget	="";
	m_sShowICMP		="";
	m_sShowStatus	="";
	m_sShowComment	="";



	UpdateData(FALSE);

	ListBoxShow();

}

void FireScreen::OnFirescreenDeleteRule() 
{
	// TODO: Add your control notification handler code here
	GetDataFromAD();
// Get rule position
	POSITION pos = m_cListRuleOfFireScreen.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		AfxMessageBox("No rule is selected.");
		return;
	}

	iRulePosition = SetPosition(m_cListRuleOfFireScreen.GetNextSelectedItem(pos));
	
	// Delete from AD	
	ADCon.SetDeleteRule(FireScreenURL,iRulePosition);
	ADCon.SetDeleteUpdate();
	ADCon.SetNewUpdate();

	ListBoxShow();
}

void FireScreen::OnFirescreenEditRule() 
{
	// TODO: Add your control notification handler code here
	if (bEditRule)
	{
		DWORD dwAddress;
		CString sSrcAddr,sSourceMask,sDstAddr,sDestinationMask,sLongRule;

		UpdateData(TRUE);
	
		m_cSrcAddr.GetAddress(dwAddress);
		sSrcAddr = dwAddressToString(dwAddress);

		m_cSrcMask.GetAddress(dwAddress);
		sSourceMask = dwAddressToString(dwAddress);
	
		m_cDstAddr.GetAddress(dwAddress);
		sDstAddr = dwAddressToString(dwAddress);

		m_cDstMask.GetAddress(dwAddress);
		sDestinationMask = dwAddressToString(dwAddress);

		if(m_bNotSrc==TRUE&&m_bNotDst==TRUE){
			sSrcAddr="! "+sSrcAddr;
			sDstAddr="! "+sDstAddr;
		}else if(m_bNotSrc==TRUE&&m_bNotDst==FALSE)
		{
			sSrcAddr="! "+sSrcAddr;
		}else if(m_bNotSrc==FALSE&&m_bNotDst==TRUE)
		{
			sDstAddr="! "+sDstAddr;
		}
		if(m_sSrcPort==""){
			m_sSrcPort="-";
		}
		if(m_sDstPort==""){
			m_sDstPort="-";
		}

		CString str;
		m_cProtocol.GetLBText( m_sProtocol, str );
		sLongRule = m_sStatus			+ ":" +  sSrcAddr		+ ":" + 
					sSourceMask			+ ":" +  sDstAddr		+ ":" +  
					sDestinationMask	+ ":" +  str			+ ":" +
					m_sSrcPort			+ ":" +  m_sDstPort		+ ":" +  
					m_sICMP_type		+ ":" +	 m_sZone		+ ":" +
					m_sTarget			+ ":" +	 m_sComment		;
		
		int i;
		GetDataFromAD();
		rmDistinguishedName.SetAt(iRulePosition,sLongRule);		

// Delete All Rule From AD.
		for( i = 0; i < iCountRule; i++)
		{
			ADCon.SetDeleteRule(FireScreenURL,i);
		}

// Add All and New Rule  To AD.
		for( i = iCountRule - 1; i >=0 ; i--)
		{
			ADCon.SetNewRule(FireScreenURL,rmDistinguishedName.GetAt(i));
		}

		ADCon.SetDeleteUpdate();
		ADCon.SetNewUpdate();

		m_cSrcAddr.SetAddress(0,0,0,0);
		m_cSrcMask.SetAddress(255,255,255,255);
		m_cDstAddr.SetAddress(0,0,0,0);
		m_cDstMask.SetAddress(255,255,255,255);
		m_sSrcPort	= "-";
		m_sDstPort	= "-";
		SetDlgItemText(IDC_EDIT_COMMENT,"");
		m_sStatus	= "TRUE";
		m_sTarget	= "DROP";
		m_sZone		= "DMZ-in";
		m_bNotDst = FALSE;
		m_bNotSrc = FALSE;
		m_sICMP_type = "-";
		m_cProtocol.SetCurSel(0);
		OnSelchangeComboProtocolScreen() ;
	
		UpdateData(FALSE);
		
		GetDlgItem( IDC_FIRESCREEN_ADD_RULE )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_DELETE_RULE)->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_CLEAR_RULE)->EnableWindow(TRUE);
		SetDlgItemText( IDC_FIRESCREEN_EDIT_RULE, "Edit" ) ;


		bEditRule = FALSE;
		ListBoxShow();	
		
	}
	else
	{
		GetDataFromAD();

		POSITION pos = m_cListRuleOfFireScreen.GetFirstSelectedItemPosition();
		if (pos == NULL)
		{
			AfxMessageBox("No rule is selected.");
			return;
		}
	
		iRulePosition = SetPosition(m_cListRuleOfFireScreen.GetNextSelectedItem(pos));

		BreakLongRule(rmDistinguishedName.GetAt(iRulePosition));
		
		IPStringToIPBYTE(sSrcAddress);
		m_cSrcAddr.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sSrcMask);
		m_cSrcMask.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sDstAddress);
		m_cDstAddr.SetAddress(ip01,ip02,ip03,ip04);
		IPStringToIPBYTE(sDstMask);
		m_cDstMask.SetAddress(ip01,ip02,ip03,ip04);

		m_sSrcPort	= sSrcPort;
		m_sDstPort	= sDstPort;
		
		m_sTarget	= sTarget;

		if(sProtocol=="any")
			m_cProtocol.SetCurSel(0);
		else if(sProtocol=="icmp")
			m_cProtocol.SetCurSel(1);
		else if(sProtocol=="tcp")
			m_cProtocol.SetCurSel(2);
		else if(sProtocol=="udp")
			m_cProtocol.SetCurSel(3);
		OnSelchangeComboProtocolScreen() ;

		m_sStatus	= sStatus;
		m_sZone		= sZone;

		if(sNotSrc=="")
			m_bNotSrc = FALSE;
		else
			m_bNotSrc = TRUE;

		if(sNotDst=="")
			m_bNotDst = FALSE;
		else
			m_bNotDst = TRUE;
		
		m_sComment = sComment;
		m_sICMP_type = sICMP_Type;

		m_sShowSrcAddr	="";
		m_sShowSrcMask	="";
		m_sShowSrcPort	="";
		m_sShowDstAddr	="";
		m_sShowDstMask	="";
		m_sShowDstPort	="";
		m_sShowZone		="";
		m_sShowProtocol	="";
		m_sShowTarget	="";
		m_sShowICMP		="";
		m_sShowStatus	="";
		m_sShowComment	="";

		UpdateData(FALSE);

		GetDlgItem( IDC_FIRESCREEN_ADD_RULE )->EnableWindow(FALSE);	
		GetDlgItem( IDC_FIRESCREEN_DELETE_RULE )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_CLEAR_RULE )->EnableWindow(FALSE);
		SetDlgItemText( IDC_FIRESCREEN_EDIT_RULE , "Edit OK" ) ;

		bEditRule = TRUE;

	}
}

void FireScreen::OnFirescreenClearRule() 
{
	// TODO: Add your control notification handler code here
	GetDataFromAD();
	for (int i = 0 ; i < iCountRule ; i++)
		ADCon.SetDeleteRule(FireScreenURL,i);

	ADCon.SetDeleteUpdate();
	ADCon.SetNewUpdate();

	ListBoxShow();
}
void FireScreen::ListBoxShow()
{
	GetDataFromAD();
	if (iCountRule != 0)
	{
//		AfxMessageBox("Test");
		ruleManage->ResetRules();
		AddRule();
		UpdateList();
	}else{
		m_cListRuleOfFireScreen.DeleteAllItems();
		m_sNumberOfRule.Format("%u",0);
		UpdateData(FALSE);
	}
}

void FireScreen::OnSelchangeComboProtocolScreen() 
{
	UpdateData(TRUE);

	if( m_sProtocol < 0 ) return;
	CString str;
	m_cProtocol.GetLBText( m_sProtocol, str );
	//MessageBox(str,NULL,MB_OK);
	if(str=="any")
	{
		GetDlgItem( IDC_EDIT_ICMPTYPE		)->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_SRC_PORT )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_DST_PORT )->EnableWindow(FALSE);
		m_sICMP_type	="-";
		m_sSrcPort		="-";
		m_sDstPort		="-";
	}else if(str=="icmp")
	{
		GetDlgItem( IDC_EDIT_ICMPTYPE		)->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_SRC_PORT )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_DST_PORT )->EnableWindow(FALSE);
		m_sSrcPort		="-";
		m_sDstPort		="-";
	}else if(str=="tcp"||str=="udp")
	{
		GetDlgItem( IDC_EDIT_ICMPTYPE		)->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_SRC_PORT )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_DST_PORT )->EnableWindow(TRUE);
		m_sICMP_type	="-";
	}	
	UpdateData(FALSE);
}


void FireScreen::OnClickListctrlRuleOfFirescreen(NMHDR* pNMHDR, LRESULT* pResult) 
{
	GetDataFromAD();
// Get rule position
	POSITION pos = m_cListRuleOfFireScreen.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		AfxMessageBox("No rule is selected.");
		return;
	}

	iRulePosition = SetPosition(m_cListRuleOfFireScreen.GetNextSelectedItem(pos));
		
	BreakLongRule(rmDistinguishedName.GetAt(iRulePosition));

	m_sShowSrcAddr	=	sNotSrc+sSrcAddress;
	m_sShowSrcMask	=	sSrcMask;
	m_sShowSrcPort	=	sSrcPort;
	m_sShowDstAddr	=	sNotDst+sDstAddress;
	m_sShowDstMask	=	sDstMask;
	m_sShowDstPort	=	sDstPort;
	m_sShowZone		=	sZone;
	m_sShowProtocol	=	sProtocol;
	m_sShowTarget	=	sTarget;
	m_sShowICMP		=	sICMP_Type;
	m_sShowStatus	=	sStatus;
	m_sShowComment	=	sComment;

	UpdateData(FALSE);
	*pResult = 0;
}

void FireScreen::OnButtonPolicy() 
{	
	UpdateData(TRUE);
	m_cProtocol.SetCurSel(2);
	OnSelchangeComboProtocolScreen() ;
	m_cSrcAddr.SetAddress(0,0,0,0);
	CString str;
	GetDlgItemText(IDC_BUTTON_POLICY,str);
	m_cSrcAddr.SetAddress(0,0,0,0);
	m_cSrcMask.SetAddress(255,255,255,255);
	m_cDstAddr.SetAddress(0,0,0,0);
	m_cDstMask.SetAddress(255,255,255,255);
	m_sSrcPort	= "-";
	m_sDstPort	= "-";
	SetDlgItemText(IDC_EDIT_COMMENT,"");
	m_sStatus	= "TRUE";
	m_sTarget	= "DROP";
	m_sZone		= "DMZ-in";
	m_sICMP_type = "-";
	m_bNotSrc = FALSE;
	m_bNotDst = FALSE;

	if(str=="FireScreen Rule")
	{	SetDlgItemText( IDC_BUTTON_POLICY , "FireScreen Policy" ) ;
		SetDlgItemText( IDC_STATIC_SCREEN2 ,"Assingment Rule Of FireScreen" ) ;
		SetDlgItemText( IDC_BUTTON_POLICY , "FireScreen Policy" ) ;
		GetDlgItem( IDC_FIRESCREEN_SRC_ADDR )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_DST_MASK )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_SRC_MASK )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_DST_ADDR )->EnableWindow(TRUE);
		GetDlgItem( IDC_NOT_DST				)->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_ZONE			)->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_PROTOCOL_SCREEN)->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_STATUS		)->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_TARGET		)->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_COMMENT		)->EnableWindow(TRUE);
	}else{
		SetDlgItemText( IDC_STATIC_SCREEN2 ,"Assingment Policy Of FireScreen" ) ;
		SetDlgItemText( IDC_BUTTON_POLICY , "FireScreen Rule" ) ;
		GetDlgItem( IDC_EDIT_ICMPTYPE		)->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_SRC_ADDR )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_SRC_PORT )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_DST_PORT )->EnableWindow(TRUE);
		GetDlgItem( IDC_FIRESCREEN_DST_MASK )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_SRC_MASK )->EnableWindow(FALSE);
		GetDlgItem( IDC_FIRESCREEN_DST_ADDR )->EnableWindow(FALSE);
		GetDlgItem( IDC_NOT_DST				)->EnableWindow(FALSE);
		GetDlgItem( IDC_COMBO_ZONE			)->EnableWindow(FALSE);
		GetDlgItem( IDC_COMBO_PROTOCOL_SCREEN)->EnableWindow(FALSE);
		GetDlgItem( IDC_COMBO_STATUS		)->EnableWindow(FALSE);
		GetDlgItem( IDC_COMBO_TARGET		)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_COMMENT		)->EnableWindow(FALSE);
	}
	UpdateData(FALSE);
}
