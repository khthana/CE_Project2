// Firewall StationDlg.h : header file
//

#if !defined(AFX_FIREWALLSTATIONDLG_H__BCAED4BF_EFF0_4B0E_8C01_0CD46E382861__INCLUDED_)
#define AFX_FIREWALLSTATIONDLG_H__BCAED4BF_EFF0_4B0E_8C01_0CD46E382861__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include"FireAlarmUser.h"
#include"FireAlarmGroup.h"
#include"FireScreen.h"

/////////////////////////////////////////////////////////////////////////////
// CFireStationDlg dialog

class CFireStationDlg : public CDialog
{
// Construction
public:
	CFireStationDlg(CWnd* pParent = NULL);	// standard constructor

	FireAlarmGroup	m_dGroupDlg;
	FireAlarmUser	m_dUserDlg;
	FireScreen		m_dFireScreenDlg;

	void ShowWindowNumber(int number);

// Dialog Data
	//{{AFX_DATA(CFireStationDlg)
	enum { IDD = IDD_FIRESTATION_DIALOG };
	CTabCtrl	m_cTab;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireStationDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFireStationDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnAboutbox();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
     CRect m_rSettingsRect;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESTATIONDLG_H__BCAED4BF_EFF0_4B0E_8C01_0CD46E382861__INCLUDED_)
