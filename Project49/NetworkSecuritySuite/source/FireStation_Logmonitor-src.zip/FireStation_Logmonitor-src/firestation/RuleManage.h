#ifndef RULEMANAGE_H
#define RULEMANAGE_H

#define MAX_RULES 50
// Protocol Values
#define PROTO(ProtoId)   MAKELONG(MAKEWORD((ProtoId),0x00),0x00000)
#define ANY_PROTOCOL	 PROTO(0x00)
#define TCP_PROTOCOL	 PROTO(0x06)
#define UDP_PROTOCOL	 PROTO(0x17)
#define ICMP_PROTOCOL	 PROTO(0x01)

#pragma comment(lib, "Lib/WSock32.lib")
typedef struct _RuleInfo
{
	unsigned long	sourceIp;		// Source IP
	unsigned long	sourceMask;		// Source Mask
	unsigned short	sourcePort;		// Source Port
	
	unsigned long	destinationIp;	// Destination IP
	unsigned long	destinationMask;// Destination Mask
	unsigned short	destinationPort;// Destination Port
		
	unsigned int	protocol;		// Protocol Number

	int				action;			// 0 Drop 1 Forward
}RuleInfo ;


class CRuleManage  
{
public:
	CRuleManage();
	virtual ~CRuleManage();

// Attributes
public:
	unsigned int nRules;
	RuleInfo rules[MAX_RULES];
//	PFFORWARD_ACTION defaultAction;

// Implementation
public:
	void DeleteRule(unsigned int position);
	void ResetRules();
	int AddRule(unsigned long srcIp, 
				unsigned long srcMask,
				unsigned short srcPort, 
				unsigned long dstIp,
				unsigned long dstMask,
				unsigned short dstPort,
				unsigned int protocol,
				int action);

	static CString GetClientIP();
};


#endif