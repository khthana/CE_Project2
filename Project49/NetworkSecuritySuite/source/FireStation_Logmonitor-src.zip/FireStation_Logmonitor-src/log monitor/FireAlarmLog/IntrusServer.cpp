// IntrusServer.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarmLog.h"
#include "IntrusServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// IntrusServer

IntrusServer::IntrusServer()
{
}

IntrusServer::~IntrusServer()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(IntrusServer, CAsyncSocket)
	//{{AFX_MSG_MAP(IntrusServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// IntrusServer member functions
