#if !defined(AFX_INTRUSSERVER_H__3B5E8775_08B6_4CAA_91A9_CE87E71DE42E__INCLUDED_)
#define AFX_INTRUSSERVER_H__3B5E8775_08B6_4CAA_91A9_CE87E71DE42E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IntrusServer.h : header file
//
#include "IntrusionSocket.h"
#include <afxsock.h>


/////////////////////////////////////////////////////////////////////////////
// IntrusServer command target

class IntrusServer : public CAsyncSocket
{
// Attributes
public:
	bool active;
	CString ip;

private:
	IntrusionSocket *maindlg;
	
// Operations
public:
	void SetMainWindows(IntrusionSocket *dlg)
	{
		maindlg=dlg;
	}
	IntrusServer();
	virtual ~IntrusServer();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntrusion)
	public:
	virtual void OnAccept(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnSend(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CIntrusion)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTRUSSERVER_H__3B5E8775_08B6_4CAA_91A9_CE87E71DE42E__INCLUDED_)
