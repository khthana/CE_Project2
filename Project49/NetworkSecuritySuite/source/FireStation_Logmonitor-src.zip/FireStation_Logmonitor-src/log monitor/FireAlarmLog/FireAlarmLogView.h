// FireAlarmLogView.h : interface of the CFireAlarmLogView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIREALARMLOGVIEW_H__BB724CD1_E355_4569_BB5E_3F8A8682BC1D__INCLUDED_)
#define AFX_FIREALARMLOGVIEW_H__BB724CD1_E355_4569_BB5E_3F8A8682BC1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TIME_ELAP 5000
#include "ADConnect.h"
class CLogSet;

class CFireAlarmLogView : public CRecordView
{
protected: // create from serialization only
	CFireAlarmLogView();
	DECLARE_DYNCREATE(CFireAlarmLogView)

public:
	//{{AFX_DATA(CFireAlarmLogView)
	enum { IDD = IDD_FIREALARMLOG_FORM };
	CComboBox	m_cListTypeSub;
	CComboBox	m_cListType;
	CListCtrl	m_cListLog;
	CString	m_sNumberOfLog;
	CLogSet*	m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CFireAlarmLogDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmLogView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	int CountRecord();
	virtual ~CFireAlarmLogView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BOOL bLastRecord;

	void AddLogToList(int iAllRecord);
	void AddLogToDB(CString sLog);

	CString sAllRecord;
	int iAllRecord;
//	int iPageNumber;
	int iRecordPerPage;

	int iADGroupAll;
	int iADGroupNo;
	int iFWGroupAll;
	int iCountRule;

	CStringArray rmDistinguishedName;
	CStringArray gName;
	CStringArray gDistinguishedName;

	ADConnect ADCon;

	int iType;
	CStringArray saTmp;
	CStringArray saAllRecord;

// Generated message map functions
protected:
	//{{AFX_MSG(CFireAlarmLogView)
	afx_msg void OnButtonDelete();
	afx_msg void OnSelchangeCombotype();
	afx_msg void OnSelchangeCombosubtype();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FireAlarmLogView.cpp
inline CFireAlarmLogDoc* CFireAlarmLogView::GetDocument()
   { return (CFireAlarmLogDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMLOGVIEW_H__BB724CD1_E355_4569_BB5E_3F8A8682BC1D__INCLUDED_)
