// Intrusion.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarmLog.h"
#include "Intrusion.h"
#include "FireAlarmLogView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntrusion

CIntrusion::CIntrusion()
{
}

CIntrusion::~CIntrusion()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CIntrusion, CAsyncSocket)
	//{{AFX_MSG_MAP(CIntrusion)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CIntrusion member functions

void CIntrusion::OnAccept(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
//	if(nErrorCode==0)
//		((CIntrusionServerDlg*)maindlg)->OnAccept();
}

void CIntrusion::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
//	if(nErrorCode==0)
//		((CIntrusionServerDlg*)maindlg)->OnConnect();
}

void CIntrusion::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
//	if(nErrorCode==0)
//		((CIntrusionServerDlg*)maindlg)->OnClose();
}

void CIntrusion::OnSend(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
//	if(nErrorCode==0)
//		((CIntrusionServerDlg*)maindlg)->OnSend();
}

void CIntrusion::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
//	if(nErrorCode==0)
//		((CIntrusionServerDlg*)maindlg)->OnReceive();
}
