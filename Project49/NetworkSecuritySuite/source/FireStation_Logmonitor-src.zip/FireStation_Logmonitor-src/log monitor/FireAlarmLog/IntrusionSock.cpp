// IntrusionSock.cpp: implementation of the IntrusionSock class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FireAlarmLog.h"
#include "IntrusionSock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IntrusionSock::IntrusionSock()
{

}

IntrusionSock::~IntrusionSock()
{

}
