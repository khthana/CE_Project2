; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=IntrusServer
LastTemplate=CAsyncSocket
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FireAlarmLog.h"
LastPage=0

ClassCount=9
Class1=CFireAlarmLogApp
Class2=CFireAlarmLogDoc
Class3=CFireAlarmLogView
Class4=CMainFrame
Class6=CAboutDlg

ResourceCount=6
Resource1=IDD_ABOUTBOX
Resource2=IDD_FIREALARMLOG_FORM (English (U.S.))
Class5=CLogSet
Resource3=IDD_FIREALARMLOG_FORM
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDR_MAINFRAME (English (U.S.))
Class7=IntrusionServer
Class8=qqq
Class9=IntrusServer
Resource6=IDR_MAINFRAME

[CLS:CFireAlarmLogApp]
Type=0
HeaderFile=FireAlarmLog.h
ImplementationFile=FireAlarmLog.cpp
Filter=N

[CLS:CFireAlarmLogDoc]
Type=0
HeaderFile=FireAlarmLogDoc.h
ImplementationFile=FireAlarmLogDoc.cpp
Filter=N

[CLS:CFireAlarmLogView]
Type=0
HeaderFile=FireAlarmLogView.h
ImplementationFile=FireAlarmLogView.cpp
Filter=D
BaseClass=CRecordView
VirtualFilter=RVWC
LastObject=CFireAlarmLogView


[DB:CFireAlarmLogSet]
DB=1
DBType=ODBC
ColumnCount=16
Column1=[LogTable].[LogNo], 4, 4
Column2=[LogTable].[AttackType], 12, 100
Column3=[LogTable].[AttackSrc], 12, 100
Column4=[LogTable].[AttackDst], 12, 200
Column5=[LogTable].[AttackDate], 12, 200
Column6=[LogTable].[AttackTime], 12, 200
Column7=[LogTable].[User], 12, 100
Column8=[LogTable].[Group], 12, 200
Column9=[Paste Errors].[LogNo], 4, 4
Column10=[Paste Errors].[AttackType], 12, 510
Column11=[Paste Errors].[AttackSrc], 12, 510
Column12=[Paste Errors].[AttackDst], 12, 510
Column13=[Paste Errors].[AttackDate], 12, 510
Column14=[Paste Errors].[AttackTime], 12, 510
Column15=[Paste Errors].[Group], 12, 510
Column16=[Paste Errors].[User], 12, 510


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T




[CLS:CAboutDlg]
Type=0
HeaderFile=FireAlarmLog.cpp
ImplementationFile=FireAlarmLog.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_NEXT_PANE
Command10=ID_PREV_PANE
CommandCount=10

[DLG:IDD_FIREALARMLOG_FORM]
Type=1
Class=CFireAlarmLogView
ControlCount=12
Control1=IDC_STATIC,static,1342177294
Control2=IDC_STATIC_1,button,1342177287
Control3=IDC_LIST_LOG,SysListView32,1342242817
Control4=IDC_COMBOTYPE,combobox,1344339971
Control5=IDC_COMBOSUBTYPE,combobox,1344339971
Control6=IDC_STATIC_2,static,1342308352
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_NUMBEROFLOG,static,1342308354
Control10=IDC_BUTTON_DELETE,button,1342275584
Control11=IDC_BUTTON_CLEAR,button,1342275584
Control12=IDC_STATIC,static,1342177294

[DLG:IDD_FIREALARMLOG_FORM (English (U.S.))]
Type=1
Class=CFireAlarmLogView
ControlCount=12
Control1=IDC_STATIC,static,1342177294
Control2=IDC_STATIC_1,button,1342177287
Control3=IDC_LIST_LOG,SysListView32,1342242817
Control4=IDC_COMBOTYPE,combobox,1344339971
Control5=IDC_COMBOSUBTYPE,combobox,1344339971
Control6=IDC_STATIC_2,static,1342308352
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_NUMBEROFLOG,static,1342308354
Control10=IDC_BUTTON_DELETE,button,1342275584
Control11=IDC_BUTTON_CLEAR,button,1342275584
Control12=IDC_STATIC,static,1342177294

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_NEXT_PANE
Command10=ID_PREV_PANE
CommandCount=10

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[CLS:CLogSet]
Type=0
HeaderFile=LogSet.h
ImplementationFile=LogSet.cpp
BaseClass=CRecordset
Filter=N
VirtualFilter=r
LastObject=CLogSet

[DB:CLogSet]
DB=1
DBType=ODBC
ColumnCount=8
Column1=[LogNo], 4, 4
Column2=[AttackType], 12, 100
Column3=[AttackSrc], 12, 100
Column4=[AttackDst], 12, 200
Column5=[AttackDate], 12, 200
Column6=[AttackTime], 12, 200
Column7=[User], 12, 100
Column8=[Group], 12, 200

[MNU:IDR_MAINFRAME]
Type=1
Class=?
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[CLS:IntrusionServer]
Type=0
HeaderFile=IntrusionServer.h
ImplementationFile=IntrusionServer.cpp
BaseClass=CAsyncSocket
Filter=N

[CLS:qqq]
Type=0
HeaderFile=qqq.h
ImplementationFile=qqq.cpp
BaseClass=CAsyncSocket
Filter=N

[CLS:IntrusServer]
Type=0
HeaderFile=IntrusServer.h
ImplementationFile=IntrusServer.cpp
BaseClass=CAsyncSocket
Filter=N

