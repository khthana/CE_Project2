//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FireAlarmLog.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FIREALARMLOG_FORM           101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_FIREALTYPE                  129
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     135
#define IDC_LIST_LOG                    1000
#define IDC_COMBOTYPE                   1001
#define IDC_COMBOSUBTYPE                1002
#define IDC_BUTTON_DELETE               1003
#define IDC_BUTTON_CLEAR                1004
#define IDC_NUMBEROFLOG                 1005
#define IDC_STATIC_1                    1006
#define IDC_STATIC_2                    1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
