// FireAlarmLogDoc.cpp : implementation of the CFireAlarmLogDoc class
//

#include "stdafx.h"
#include "FireAlarmLog.h"

#include "LogSet.h"
#include "FireAlarmLogDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogDoc

IMPLEMENT_DYNCREATE(CFireAlarmLogDoc, CDocument)

BEGIN_MESSAGE_MAP(CFireAlarmLogDoc, CDocument)
	//{{AFX_MSG_MAP(CFireAlarmLogDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogDoc construction/destruction

CFireAlarmLogDoc::CFireAlarmLogDoc()
{
	// TODO: add one-time construction code here

}

CFireAlarmLogDoc::~CFireAlarmLogDoc()
{
}

BOOL CFireAlarmLogDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogDoc diagnostics

#ifdef _DEBUG
void CFireAlarmLogDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFireAlarmLogDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogDoc commands
