#if !defined(AFX_INTRUSION_H__DBF3DA6A_03AC_47A9_AF01_5FB8CA6D441C__INCLUDED_)
#define AFX_INTRUSION_H__DBF3DA6A_03AC_47A9_AF01_5FB8CA6D441C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Intrusion.h : header file
//
#include <afxsock.h>
//#include "FireAlarmLogView.h"

/////////////////////////////////////////////////////////////////////////////
// CIntrusion command target

class CIntrusion : public CAsyncSocket
{
public:
	bool active;
	CString ip;

private:
	CRecordView *maindlg;
	
// Operations
public:
	void SetMainWindows(CRecordView *dlg)
	{
		maindlg=dlg;
	}
	CIntrusion();
	virtual ~CIntrusion();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntrusion)
	public:
	virtual void OnAccept(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnSend(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CIntrusion)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTRUSION_H__DBF3DA6A_03AC_47A9_AF01_5FB8CA6D441C__INCLUDED_)
