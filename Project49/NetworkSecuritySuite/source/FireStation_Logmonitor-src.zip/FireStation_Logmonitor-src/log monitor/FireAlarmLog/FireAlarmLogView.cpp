// FireAlarmLogView.cpp : implementation of the CFireAlarmLogView class
//

#include "stdafx.h"
#include "FireAlarmLog.h"

#include "LogSet.h"
#include "FireAlarmLogDoc.h"
#include "FireAlarmLogView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogView

IMPLEMENT_DYNCREATE(CFireAlarmLogView, CRecordView)

BEGIN_MESSAGE_MAP(CFireAlarmLogView, CRecordView)
	//{{AFX_MSG_MAP(CFireAlarmLogView)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_CBN_SELCHANGE(IDC_COMBOTYPE, OnSelchangeCombotype)
	ON_CBN_SELCHANGE(IDC_COMBOSUBTYPE, OnSelchangeCombosubtype)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogView construction/destruction

CFireAlarmLogView::CFireAlarmLogView()
	: CRecordView(CFireAlarmLogView::IDD)
{
	//{{AFX_DATA_INIT(CFireAlarmLogView)
	m_sNumberOfLog = _T("");
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	

}

CFireAlarmLogView::~CFireAlarmLogView()
{


}

void CFireAlarmLogView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFireAlarmLogView)
	DDX_Control(pDX, IDC_COMBOSUBTYPE, m_cListTypeSub);
	DDX_Control(pDX, IDC_COMBOTYPE, m_cListType);
	DDX_Control(pDX, IDC_LIST_LOG, m_cListLog);
	DDX_Text(pDX, IDC_NUMBEROFLOG, m_sNumberOfLog);
	//}}AFX_DATA_MAP
}

BOOL CFireAlarmLogView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CFireAlarmLogView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_fireAlarmLogSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 14;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_2);
	Static2->SetFont(F1,TRUE);

	// Add Column to list Control server rule
	m_cListLog.InsertColumn(1, "No.",LVCFMT_CENTER , 33, 0);
	m_cListLog.InsertColumn(2, "Destination IP",LVCFMT_CENTER , 78, 1);
	m_cListLog.InsertColumn(3, "Source IP",LVCFMT_CENTER ,78, 2);
	m_cListLog.InsertColumn(4, "Attack Type",LVCFMT_CENTER , 95, 3);
	m_cListLog.InsertColumn(5, "Attack Date",LVCFMT_CENTER ,70, 4);
	m_cListLog.InsertColumn(6, "Attack Time",LVCFMT_CENTER , 70, 5);
	m_cListLog.InsertColumn(7, "Group",LVCFMT_CENTER , 50, 6);
	m_cListLog.InsertColumn(8, "User",LVCFMT_CENTER , 65, 7);

	m_cListLog.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);

// Add data from database to List
	iAllRecord = CountRecord();
	if (iAllRecord > 1)
		bLastRecord = FALSE;
	else
		bLastRecord = TRUE;

	m_sNumberOfLog.Format(" %d",iAllRecord);
//	m_sPageNo.Format(" %d",iPageNumber + 1);
	UpdateData(FALSE);

	if (iAllRecord!=0)
	{
		CString sTmpLogNo;
		for (int i = 0 ; i < iAllRecord ; i++)
		{
			sTmpLogNo.Format("%d",m_pSet->m_LogNo);
			saAllRecord.Add((LPCTSTR)sTmpLogNo);
			m_pSet->MoveNext();
		}
		AddLogToList(iAllRecord);
	}

  SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=1000

	gDistinguishedName.RemoveAll();
	ADCon.GetList("group",gName,gDistinguishedName);
	
	iADGroupAll = gName.GetSize();
	iFWGroupAll = gName.GetSize() - 30;
//	iADGroupNo = iADGroupAll - iFWGroupAll;*/
// List 1
	m_cListType.AddString("All");
	m_cListType.AddString("Destination");
	m_cListType.AddString("Source");
	m_cListType.AddString("Type");
	m_cListType.AddString("User");
	m_cListType.AddString("Group");
	m_cListType.AddString("Date");
	m_cListType.SetCurSel(0);
	m_cListTypeSub.SetCurSel(0);
	GetDocument()->SetTitle("FireAlarmLog");
}

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogView diagnostics

#ifdef _DEBUG
void CFireAlarmLogView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CFireAlarmLogView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CFireAlarmLogDoc* CFireAlarmLogView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFireAlarmLogDoc)));
	return (CFireAlarmLogDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogView database support
CRecordset* CFireAlarmLogView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogView message handlers
int CFireAlarmLogView::CountRecord()
{
	int iCountRecord = 0;
	if (m_pSet->IsEOF())
		return 0;
	m_pSet->MoveFirst();
	while (!m_pSet->IsEOF())
	{
		iCountRecord++;
		m_pSet->MoveNext();
	}
	m_pSet->MoveFirst();
	return iCountRecord;
}

void CFireAlarmLogView::AddLogToList(int iAllRecord)
{
	CString sLogNo;
	LVITEM it;
	int pos;//, iFirstRecord = iPageNumber*10, iLastRecord = iFirstRecord + iRecordPerPage;

/*	if (iLastRecord > iAllRecord)
		iLastRecord = iAllRecord;*/

	m_cListLog.DeleteAllItems();
	m_pSet->MoveFirst();
//	m_pSet->Move(iFirstRecord);

	for(int i = 0;i<iAllRecord;i++)
	//for (int i = iFirstRecord; i < iLastRecord; i++)
	{
		sLogNo.Format("%d",m_pSet->m_LogNo);
		it.mask		= LVIF_TEXT;
		it.iItem	= m_cListLog.GetItemCount();
		it.iSubItem	= 0;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		pos			= m_cListLog.InsertItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 1;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_AttackDst;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 2;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_AttackSrc;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 3;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_AttackType;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 4;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_AttackDate;
		m_cListLog.SetItem(&it);
	
		it.iItem	= pos;
		it.iSubItem	= 5;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_AttackTime;
		m_cListLog.SetItem(&it);
	
		it.iItem	= pos;
		it.iSubItem	= 6;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Group;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 7;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_User;
		m_cListLog.SetItem(&it);

		m_pSet->MoveNext();
	}
	m_pSet->MoveFirst();
}
void CFireAlarmLogView::AddLogToDB(CString sLog)
{
	// change long log string to each variables
	CString tmpString,sLogNo,sAttackDst,sAttackSrc,sAttackType,sAttackDate,sAttackTime,sGroup,sUser;
	sLog.TrimLeft();	//removes newline, space, and tab characters
	sLog.TrimRight();	//removes newline, space, and tab characters

	for ( int i=0; i<7; i++ ) 
	{
		int pos = sLog.Find(',');
		tmpString = sLog.Left(pos);
		sLog.Delete(0, pos+1);

		switch(i)
		{
			case 0 :
				sAttackType = tmpString;
				break;
			case 1 :
				sAttackSrc = tmpString;
				break;
			case 2 :
				sAttackDst = tmpString;
				break;
			case 3 :
				sAttackDate = tmpString;
				break;
			case 4 :
				sAttackTime= tmpString;
				break;
			case 5 :
				sGroup = tmpString;
				break;
		}
	//	MessageBox(tmpString,NULL,MB_OK);
	}	
	sUser = sLog;
//	AfxMessageBox(sAttackDst+sAttackSrc+sAttackType+sAttackDate+sAttackTime+sGroup+sUser);
	m_pSet->Requery();
	iAllRecord = CountRecord();
	int iLogNo = iAllRecord + 1;
	m_pSet->AddNew();
	m_pSet->m_LogNo		 = iLogNo;			
	m_pSet->m_AttackDst  = sAttackDst;
	m_pSet->m_AttackSrc	 = sAttackSrc;		
	m_pSet->m_AttackTime = sAttackTime;
	m_pSet->m_AttackDate = sAttackDate;		
	m_pSet->m_AttackType = sAttackType;
	m_pSet->m_Group		 = sGroup;			
	m_pSet->m_User		 = sUser;
	m_pSet->Update();

}

void CFireAlarmLogView::OnButtonDelete() 
{
	// TODO: Add your control notification handler code here
	m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();

	POSITION pos = m_cListLog.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		AfxMessageBox("No rule is selected.");
		return;
	}

	int iLogNo1, iLogNo2, iPosition = m_cListLog.GetNextSelectedItem(pos);
//	iPosition = iPageNumber*10 + iPosition;

	m_pSet->Move(iPosition);
	m_pSet->Delete();

	m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();
	iAllRecord = CountRecord();

	if (iAllRecord == 0)
		bLastRecord = TRUE;
	else 
		bLastRecord = FALSE;

	m_cListLog.DeleteAllItems();

	if (bLastRecord != TRUE)
	{
		m_pSet->MoveFirst();		
	// Check delete first record ?
		iLogNo1 = m_pSet->m_LogNo;
		if (iLogNo1 != 1)
		{
			m_pSet->Edit();
			m_pSet->m_LogNo = 1;
			m_pSet->Update();
		}
	// Arrange new log number.
		for (int i = 1 ; i < iAllRecord ; i++)
		{
			iLogNo1 = m_pSet->m_LogNo;
			m_pSet->MoveNext();
			iLogNo2 = m_pSet->m_LogNo;
			if ((iLogNo1 + 1) != iLogNo2)
			{
				iLogNo2--;
				m_pSet->Edit();
				m_pSet->m_LogNo = iLogNo2;
				m_pSet->Update();
			}
		}
	// Show All record in DB
		m_sNumberOfLog.Format(" %d",iAllRecord);
		UpdateData(FALSE);

	// Update log list
		OnSelchangeCombosubtype();
	}
	else
	{
		m_sNumberOfLog.Format(" %d",iAllRecord);
		UpdateData(FALSE);
	}	
}

void CFireAlarmLogView::OnSelchangeCombotype() 
{
// TODO: Add your control notification handler code here
	m_pSet->Close(); 
	m_pSet->m_strFilter = "[User]";
	m_pSet->Open();
	iAllRecord = CountRecord();
	if (iAllRecord == 0)
		return;
	m_pSet->MoveFirst();
	int i, j, iEqual = 0, iSelected = m_cListType.GetCurSel();
	CString sTmp;
	m_cListTypeSub.ResetContent();
	saTmp.RemoveAll();
	switch (iSelected)
	{
		case 0 :
			AddLogToList(iAllRecord);
			iType = 0;
			m_cListTypeSub.AddString("---------Nothing--------");
			m_cListTypeSub.SetCurSel(0); 
			break;
		case 1 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_AttackDst;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_AttackDst)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_AttackDst);
					saTmp.Add((LPCTSTR)m_pSet->m_AttackDst);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}								
			iType = 1;
			break;
		case 2 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_AttackSrc;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_AttackSrc)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_AttackSrc);
					saTmp.Add((LPCTSTR)m_pSet->m_AttackSrc);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 2;
			break;
		case 3 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_AttackType;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_AttackType)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_AttackType);
					saTmp.Add((LPCTSTR)m_pSet->m_AttackType);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 3;
			break;
		case 4 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_User;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_User)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_User);
					saTmp.Add((LPCTSTR)m_pSet->m_User);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 4;
			break;
		case 5 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_Group;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_Group)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_Group);
					saTmp.Add((LPCTSTR)m_pSet->m_Group);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 5;
			break;
		case 6 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_AttackDate;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_AttackDate)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_AttackDate);
					saTmp.Add((LPCTSTR)m_pSet->m_AttackDate);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 6;
			break;
	}	
}

void CFireAlarmLogView::OnSelchangeCombosubtype() 
{
// TODO: Add your control notification handler code here
	m_cListLog.DeleteAllItems();
	int iSelected = m_cListTypeSub.GetCurSel();
	CString sTmp;
	m_pSet->Close();
	switch(iType)
	{
		case 1 :
			m_pSet->m_strFilter = "[AttackDst] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 2 :
			m_pSet->m_strFilter = "[AttackSrc] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 3 :
			m_pSet->m_strFilter = "[AttackType] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 4 :
			m_pSet->m_strFilter = "[User] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 5 :
			m_pSet->m_strFilter = "[Group] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 6 :
			m_pSet->m_strFilter = "[AttackDate] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 0 :
			m_pSet->m_strFilter = "[AttackDate]";
			break;
	}
	m_pSet->Open();
	iAllRecord = CountRecord();
	AddLogToList(iAllRecord);
// Show All record in DB
	m_sNumberOfLog.Format(" %d",iAllRecord);
	UpdateData(FALSE);	
}

void CFireAlarmLogView::OnTimer(UINT nIDEvent) 
{
// TODO: Add your message handler code here and/or call default
		for(int iCountGroup = 30 ; iCountGroup < iADGroupAll ; iCountGroup++)
		{	
		rmDistinguishedName.RemoveAll();
		ADCon.GetLog(gDistinguishedName.GetAt(iCountGroup),rmDistinguishedName);
//		AfxMessageBox("rmDistinguishedName");
		int iLogNumber = rmDistinguishedName.GetSize();
		if (iLogNumber > 0)
		{	
		// Add All Log to database
			for( int i = iLogNumber - 1; i >= 0; i--)
			{
				AddLogToDB(rmDistinguishedName.GetAt(i));
			}
		// Delete All Rule From AD.
			for( int j = 0; j < iLogNumber; j++)
			{
				ADCon.SetDeleteLog(gDistinguishedName.GetAt(iCountGroup),j);
			}
		// Show All record in DB
			m_pSet->Requery();
			iAllRecord = CountRecord();
			m_sNumberOfLog.Format(" %d",iAllRecord);
			UpdateData(FALSE);
		// Update Log List
			m_cListLog.DeleteAllItems();
			AddLogToList(iAllRecord);
		}
	}
	
	CRecordView::OnTimer(nIDEvent);
}

void CFireAlarmLogView::OnButtonClear() 
{
	// TODO: Add your control notification handler code here
	m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();

	iAllRecord = CountRecord();

	if (iAllRecord == 0)
		bLastRecord = TRUE;
	else 
		bLastRecord = FALSE;

	m_cListLog.DeleteAllItems();

	if (bLastRecord != TRUE)
	{
		m_pSet->MoveFirst();		
		for (int i = 1 ; i < iAllRecord ; i++)
		{
			m_pSet->Delete();
			m_pSet->MoveNext();
		}
		m_pSet->Delete();
	}

	m_pSet->Close();
	m_sNumberOfLog.Format(" %d",0);
	UpdateData(FALSE);
	m_cListTypeSub.ResetContent();
	m_cListTypeSub.AddString("---------Nothing--------");
	m_cListTypeSub.SetCurSel(0); 
}
