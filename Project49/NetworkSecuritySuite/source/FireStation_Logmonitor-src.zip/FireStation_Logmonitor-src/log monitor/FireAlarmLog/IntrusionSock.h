// IntrusionSock.h: interface for the IntrusionSock class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTRUSIONSOCK_H__5BC4512A_A08E_4760_9C66_495B072D440C__INCLUDED_)
#define AFX_INTRUSIONSOCK_H__5BC4512A_A08E_4760_9C66_495B072D440C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IntrusionSock  
{
public:
	IntrusionSock();
	virtual ~IntrusionSock();

};

#endif // !defined(AFX_INTRUSIONSOCK_H__5BC4512A_A08E_4760_9C66_495B072D440C__INCLUDED_)
