// FireAlarmLogDoc.h : interface of the CFireAlarmLogDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIREALARMLOGDOC_H__CA609BD0_7489_46B4_BF5B_68F86EDB3028__INCLUDED_)
#define AFX_FIREALARMLOGDOC_H__CA609BD0_7489_46B4_BF5B_68F86EDB3028__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "LogSet.h"


class CFireAlarmLogDoc : public CDocument
{
protected: // create from serialization only
	CFireAlarmLogDoc();
	DECLARE_DYNCREATE(CFireAlarmLogDoc)

// Attributes
public:
	CLogSet m_fireAlarmLogSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmLogDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFireAlarmLogDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFireAlarmLogDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMLOGDOC_H__CA609BD0_7489_46B4_BF5B_68F86EDB3028__INCLUDED_)
