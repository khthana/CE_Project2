// LogSet.cpp : implementation file
//

#include "stdafx.h"
#include "FireAlarmLog.h"
#include "LogSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogSet

IMPLEMENT_DYNAMIC(CLogSet, CRecordset)

CLogSet::CLogSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CLogSet)
	m_LogNo = 0;
	m_AttackType = _T("");
	m_AttackSrc = _T("");
	m_AttackDst = _T("");
	m_AttackDate = _T("");
	m_AttackTime = _T("");
	m_User = _T("");
	m_Group = _T("");
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CLogSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=FirewallLog");
}

CString CLogSet::GetDefaultSQL()
{
	return _T("[LogTable]");
}

void CLogSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CLogSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[LogNo]"), m_LogNo);
	RFX_Text(pFX, _T("[AttackType]"), m_AttackType);
	RFX_Text(pFX, _T("[AttackSrc]"), m_AttackSrc);
	RFX_Text(pFX, _T("[AttackDst]"), m_AttackDst);
	RFX_Text(pFX, _T("[AttackDate]"), m_AttackDate);
	RFX_Text(pFX, _T("[AttackTime]"), m_AttackTime);
	RFX_Text(pFX, _T("[User]"), m_User);
	RFX_Text(pFX, _T("[Group]"), m_Group);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CLogSet diagnostics

#ifdef _DEBUG
void CLogSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CLogSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
