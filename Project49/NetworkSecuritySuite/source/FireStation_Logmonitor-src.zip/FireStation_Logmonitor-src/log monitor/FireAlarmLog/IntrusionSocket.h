// IntrusionSocket.h: interface for the IntrusionSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTRUSIONSOCKET_H__BD0DE4B4_05B3_4C92_8E15_4BE9E7E59D28__INCLUDED_)
#define AFX_INTRUSIONSOCKET_H__BD0DE4B4_05B3_4C92_8E15_4BE9E7E59D28__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IntrusionSocket  
{
public:
	IntrusionSocket();
	virtual ~IntrusionSocket();

};

#endif // !defined(AFX_INTRUSIONSOCKET_H__BD0DE4B4_05B3_4C92_8E15_4BE9E7E59D28__INCLUDED_)
