// FireAlarmLog.h : main header file for the FIREALARMLOG application
//

#if !defined(AFX_FIREALARMLOG_H__D05A23D6_6CAB_47DC_8C70_386921CEC8EE__INCLUDED_)
#define AFX_FIREALARMLOG_H__D05A23D6_6CAB_47DC_8C70_386921CEC8EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFireAlarmLogApp:
// See FireAlarmLog.cpp for the implementation of this class
//

class CFireAlarmLogApp : public CWinApp
{
public:
	CFireAlarmLogApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireAlarmLogApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CFireAlarmLogApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREALARMLOG_H__D05A23D6_6CAB_47DC_8C70_386921CEC8EE__INCLUDED_)
