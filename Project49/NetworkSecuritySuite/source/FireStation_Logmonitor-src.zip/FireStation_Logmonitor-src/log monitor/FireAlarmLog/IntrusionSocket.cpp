// IntrusionSocket.cpp: implementation of the IntrusionSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FireAlarmLog.h"
#include "IntrusionSocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IntrusionSocket::IntrusionSocket()
{

}

IntrusionSocket::~IntrusionSocket()
{

}
