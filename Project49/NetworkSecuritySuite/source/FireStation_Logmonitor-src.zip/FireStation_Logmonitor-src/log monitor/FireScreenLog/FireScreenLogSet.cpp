// FireScreenLogSet.cpp : implementation of the CFireScreenLogSet class
//

#include "stdafx.h"
#include "FireScreenLog.h"
#include "FireScreenLogSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogSet implementation

IMPLEMENT_DYNAMIC(CFireScreenLogSet, CRecordset)

CFireScreenLogSet::CFireScreenLogSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CFireScreenLogSet)
	m_LogNo = 0;
	m_Date = _T("");
	m_Time = _T("");
	m_In = _T("");
	m_Out = _T("");
	m_Mac = _T("");
	m_Source = _T("");
	m_Destination = _T("");
	m_Protocol = _T("");
	m_Source_Port = _T("");
	m_Destination_Port = _T("");
	m_Type = _T("");
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}

CString CFireScreenLogSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=FireScreenLog");
}

CString CFireScreenLogSet::GetDefaultSQL()
{
	return _T("[LogTable]");
}

void CFireScreenLogSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CFireScreenLogSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[LogNo]"), m_LogNo);
	RFX_Text(pFX, _T("[Date]"), m_Date);
	RFX_Text(pFX, _T("[Time]"), m_Time);
	RFX_Text(pFX, _T("[In]"), m_In);
	RFX_Text(pFX, _T("[Out]"), m_Out);
	RFX_Text(pFX, _T("[Mac]"), m_Mac);
	RFX_Text(pFX, _T("[Source]"), m_Source);
	RFX_Text(pFX, _T("[Destination]"), m_Destination);
	RFX_Text(pFX, _T("[Protocol]"), m_Protocol);
	RFX_Text(pFX, _T("[Source Port]"), m_Source_Port);
	RFX_Text(pFX, _T("[Destination Port]"), m_Destination_Port);
	RFX_Text(pFX, _T("[Type]"), m_Type);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogSet diagnostics

#ifdef _DEBUG
void CFireScreenLogSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CFireScreenLogSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
