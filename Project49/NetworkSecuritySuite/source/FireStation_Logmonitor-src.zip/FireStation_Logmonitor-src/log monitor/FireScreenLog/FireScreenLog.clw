; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CFireScreenLogView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FireScreenLog.h"
LastPage=0

ClassCount=6
Class1=CFireScreenLogApp
Class2=CFireScreenLogDoc
Class3=CFireScreenLogView
Class4=CMainFrame
Class6=CAboutDlg

ResourceCount=10
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource7=IDD_FIRESCREENLOG_FORM
Resource8=IDD_ABOUTBOX (English (U.S.))
Resource9=IDR_MAINFRAME (English (U.S.))
Class5=CFireScreenLogSet
Resource10=IDD_FIRESCREENLOG_FORM (English (U.S.))

[CLS:CFireScreenLogApp]
Type=0
HeaderFile=FireScreenLog.h
ImplementationFile=FireScreenLog.cpp
Filter=N

[CLS:CFireScreenLogDoc]
Type=0
HeaderFile=FireScreenLogDoc.h
ImplementationFile=FireScreenLogDoc.cpp
Filter=N

[CLS:CFireScreenLogView]
Type=0
HeaderFile=FireScreenLogView.h
ImplementationFile=FireScreenLogView.cpp
Filter=D
LastObject=CFireScreenLogView
BaseClass=CRecordView
VirtualFilter=RVWC


[CLS:CFireScreenLogSet]
Type=0
HeaderFile=FireScreenLogSet.h
ImplementationFile=FireScreenLogSet.cpp
Filter=N

[DB:CFireScreenLogSet]
DB=1
DBType=ODBC
ColumnCount=12
Column1=[LogNo], 4, 4
Column2=[Date], 12, 100
Column3=[Time], 12, 100
Column4=[In], 12, 200
Column5=[Out], 12, 200
Column6=[Mac], 12, 200
Column7=[Source], 12, 100
Column8=[Destination], 12, 200
Column9=[Protocol], 12, 100
Column10=[Source Port], 12, 100
Column11=[Destination Port], 12, 100
Column12=[Type], 12, 100


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T




[CLS:CAboutDlg]
Type=0
HeaderFile=FireScreenLog.cpp
ImplementationFile=FireScreenLog.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command10=ID_RECORD_LAST
Command11=ID_APP_ABOUT
CommandCount=11
Command1=ID_FILE_MRU_FILE1
Command2=ID_APP_EXIT
Command3=ID_EDIT_UNDO
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_RECORD_FIRST
Command8=ID_RECORD_PREV
Command9=ID_RECORD_NEXT

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_NEXT_PANE
Command10=ID_PREV_PANE
CommandCount=10
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE

[DLG:IDD_FIRESCREENLOG_FORM]
Type=1
Class=CFireScreenLogView

[DLG:IDD_FIRESCREENLOG_FORM (English (U.S.))]
Type=1
Class=CFireScreenLogView
ControlCount=12
Control1=IDC_LIST_LOG,SysListView32,1342242817
Control2=IDC_BUTTON_DELETE,button,1342275584
Control3=IDC_BUTTON_CLEAR,button,1342275584
Control4=IDC_STATIC,static,1342308352
Control5=IDC_NUMBEROFLOG,static,1342308352
Control6=IDC_COMBOTYPE,combobox,1344339971
Control7=IDC_COMBOSUBTYPE,combobox,1344339971
Control8=IDC_STATIC,static,1342177294
Control9=IDC_STATIC,static,1342177294
Control10=IDC_STATIC_1,static,1342308352
Control11=IDC_STATIC_2,button,1342177287
Control12=IDC_STATIC,static,1342308352

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_NEXT_PANE
Command10=ID_PREV_PANE
CommandCount=10

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

