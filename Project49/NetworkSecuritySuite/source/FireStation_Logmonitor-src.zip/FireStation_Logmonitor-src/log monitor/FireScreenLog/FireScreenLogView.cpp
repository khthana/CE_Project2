// FireScreenLogView.cpp : implementation of the CFireScreenLogView class
//

#include "stdafx.h"
#include "FireScreenLog.h"

#include "FireScreenLogSet.h"
#include "FireScreenLogDoc.h"
#include "FireScreenLogView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogView

IMPLEMENT_DYNCREATE(CFireScreenLogView, CRecordView)

BEGIN_MESSAGE_MAP(CFireScreenLogView, CRecordView)
	//{{AFX_MSG_MAP(CFireScreenLogView)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_CBN_SELCHANGE(IDC_COMBOTYPE, OnSelchangeCombotype)
	ON_CBN_SELCHANGE(IDC_COMBOSUBTYPE, OnSelchangeCombosubtype)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogView construction/destruction

CFireScreenLogView::CFireScreenLogView()
	: CRecordView(CFireScreenLogView::IDD)
{
	//{{AFX_DATA_INIT(CFireScreenLogView)
	m_pSet = NULL;
	m_sNumberOfLog = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CFireScreenLogView::~CFireScreenLogView()
{
}

void CFireScreenLogView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFireScreenLogView)
	DDX_Control(pDX, IDC_COMBOSUBTYPE, m_cListTypeSub);
	DDX_Control(pDX, IDC_COMBOTYPE, m_cListType);
	DDX_Control(pDX, IDC_LIST_LOG, m_cListLog);
	DDX_Text(pDX, IDC_NUMBEROFLOG, m_sNumberOfLog);
	//}}AFX_DATA_MAP
}

BOOL CFireScreenLogView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CFireScreenLogView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_fireScreenLogSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 14;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_1);
	Static1->SetFont(F1,TRUE);
	CStatic *Static2 = (CStatic*) GetDlgItem(IDC_STATIC_2);
	Static2->SetFont(F1,TRUE);

	m_cListLog.InsertColumn(1, "No.",LVCFMT_CENTER , 33, 0);
	m_cListLog.InsertColumn(2, "Destination IP",LVCFMT_CENTER , 95, 1);
	m_cListLog.InsertColumn(3, "Source IP",LVCFMT_CENTER ,95, 2);
	m_cListLog.InsertColumn(4, "MAC Address" ,LVCFMT_CENTER ,200,3);
	m_cListLog.InsertColumn(5, "Date",LVCFMT_CENTER , 50, 4);
	m_cListLog.InsertColumn(6, "Time",LVCFMT_CENTER ,60, 5);
	m_cListLog.InsertColumn(7, "In",LVCFMT_CENTER , 40, 6);
	m_cListLog.InsertColumn(8, "Out",LVCFMT_CENTER , 40, 7);
	m_cListLog.InsertColumn(9, "Protocol",LVCFMT_CENTER , 65, 8);
	m_cListLog.InsertColumn(10, "Destination Port",LVCFMT_CENTER , 95, 9);
	m_cListLog.InsertColumn(11, "Source Port",LVCFMT_CENTER , 95, 10);
	m_cListLog.InsertColumn(12, "ICMP Type",LVCFMT_CENTER , 70, 11);

	m_cListLog.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);


	// Add data from database to List
	iAllRecord = CountRecord();
	if (iAllRecord > 1)
		bLastRecord = FALSE;
	else
		bLastRecord = TRUE;
//	m_sNumberOfLog.Format(" %d",iAllRecord);
	UpdateData(FALSE);

	if (iAllRecord!=0)
	{
		CString sTmpLogNo;
		for (int i = 0 ; i < iAllRecord ; i++)
		{
			sTmpLogNo.Format("%d",m_pSet->m_LogNo);
			saAllRecord.Add((LPCTSTR)sTmpLogNo);
			m_pSet->MoveNext();
		}
		AddLogToList(iAllRecord);
	}

   SetTimer(1,TIME_ELAP,NULL);//TIME_ELAP=10000


	m_cListType.AddString("All");
	m_cListType.AddString("Destination");
	m_cListType.AddString("Source");
	m_cListType.AddString("Date");
	m_cListType.AddString("Protocol");
	m_cListType.SetCurSel(0);
	m_cListTypeSub.SetCurSel(0);
	
  GetDocument()->SetTitle("FireScreenLog");
	

}

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogView diagnostics

#ifdef _DEBUG
void CFireScreenLogView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CFireScreenLogView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CFireScreenLogDoc* CFireScreenLogView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFireScreenLogDoc)));
	return (CFireScreenLogDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogView database support
CRecordset* CFireScreenLogView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogView message handlers

/////////////////////////////////////////////////////////////////////////////
// CFireScreenView functions

int CFireScreenLogView::CountRecord()
{
	int iCountRecord = 0;
	if (m_pSet->IsEOF())
		return 0;
	m_pSet->MoveFirst();
	while (!m_pSet->IsEOF())
	{
		iCountRecord++;
		m_pSet->MoveNext();
	}
	m_pSet->MoveFirst();
	return iCountRecord;
}

void CFireScreenLogView::AddLogToList(int iAllRecord)
{
	CString sLogNo;
	LVITEM it;
	int pos;

	m_cListLog.DeleteAllItems();
	m_pSet->MoveFirst();

	for(int i = 0;i<iAllRecord;i++)
	{
		sLogNo.Format("%d",m_pSet->m_LogNo);
		it.mask		= LVIF_TEXT;
		it.iItem	= m_cListLog.GetItemCount();
		it.iSubItem	= 0;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		pos			= m_cListLog.InsertItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 1;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Destination;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 2;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Source;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 3;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Mac;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 4;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Date;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 5;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Time;
		m_cListLog.SetItem(&it);
	
		it.iItem	= pos;
		it.iSubItem	= 6;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_In;
		m_cListLog.SetItem(&it);
	
		it.iItem	= pos;
		it.iSubItem	= 7;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Out;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 8;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Protocol;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 9;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Destination_Port;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 10;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Source_Port;
		m_cListLog.SetItem(&it);

		it.iItem	= pos;
		it.iSubItem	= 11;
		it.pszText	= (LPTSTR)(LPCTSTR)m_pSet->m_Type;
		m_cListLog.SetItem(&it);

		m_pSet->MoveNext();
	}
	m_pSet->MoveFirst();
}

void CFireScreenLogView::AddLogToDB(CString sLog)
{
	// change long log string to each variables
	CString tmpString,tmpString2,tmpString3,sLogNo,sDestination,sSource,sDate,sTime,sIn,sOut,sMAC,sProtocol,sSrcPort2,sDstPort2,sICMPType;
	sLog.TrimLeft();	//removes newline, space, and tab characters
	sLog.TrimRight();	//removes newline, space, and tab characters

	int pos2;
	for ( int i=0; i<20; i++ ) 
	{
		int pos = sLog.Find(' ');
		tmpString = sLog.Left(pos);
		sLog.Delete(0, pos+1);

		if(i<=7){
			switch(i)
			{
				case 0 :
					sDate = tmpString;
					break;
				case 1 :
					sDate += " "+tmpString;
					break;
				case 2 :
					sTime = tmpString;
					break;
				case 6:
					pos2 = tmpString.Find("=");
					tmpString2 = tmpString.Left(pos2);
					tmpString.Delete(0,pos2+1);
					tmpString3 = tmpString;
					if(tmpString3!="")
						sIn = tmpString3;
					else
						sIn = "-";
					break;
				case 7:
					pos2 = tmpString.Find("=");
					tmpString2 = tmpString.Left(pos2);
					tmpString.Delete(0,pos2+1);
					tmpString3 = tmpString;
					if(tmpString3!="")
						sOut = tmpString3;
					else
						sOut = "-";
					break;
			}
		}else{

				pos2 = tmpString.Find("=");
			
				tmpString3 = tmpString.Left(pos2);
				tmpString.Delete(0,pos2+1);
				tmpString2 = tmpString;
				
				if(tmpString3=="MAC"){
					if(tmpString2!="")
						sMAC = tmpString2;
					else
						sMAC = "-";
				}else if(tmpString3=="SRC"){
					sSource = tmpString2;
				}else if(tmpString3=="DST"){
					sDestination= tmpString2;
				}else if(tmpString3=="PROTO"){
					if(tmpString2!="")
						sProtocol = tmpString2;
					else
						sProtocol = "-";
				}else if(tmpString3=="SPT"){
					if(tmpString2!="")
						sSrcPort2 = tmpString2;
					else
						sSrcPort2 = "-";
				}else if(tmpString3=="DPT"){
					if(tmpString2!="")
						sDstPort2 = tmpString2;
					else
						sDstPort2 = "-";
				}else if(tmpString3=="TYPE"){
					if(tmpString2!="")
						sICMPType = tmpString2;
					else
						sICMPType = "-";
				}
		}
	}	

	if(sMAC=="")
		sMAC="-";
	if(sICMPType=="")
		sICMPType="-";
	if(sDstPort2=="")
		sDstPort2="-";
	if(sSrcPort2=="")
		sSrcPort2="-";
	if(sSource=="")
		sSource="-";
	if(sDestination=="")
		sDestination="-";

	m_pSet->Requery();
	iAllRecord = CountRecord();
	int iLogNo = iAllRecord + 1;
	m_pSet->AddNew();
	m_pSet->m_LogNo				= iLogNo;			
	m_pSet->m_Destination		= sDestination;
	m_pSet->m_Source			= sSource;		
	m_pSet->m_Date				= sDate;
	m_pSet->m_Time				= sTime;		
	m_pSet->m_In				= sIn;
	m_pSet->m_Out 				= sOut;			
	m_pSet->m_Protocol			= sProtocol;
	m_pSet->m_Mac				= sMAC;
	m_pSet->m_Source_Port		= sSrcPort2;
	m_pSet->m_Destination_Port	= sDstPort2;
	m_pSet->m_Type				= sICMPType;
	m_pSet->Update();

}


void CFireScreenLogView::OnTimer(UINT nIDEvent) 
{
	rmDistinguishedName.RemoveAll();
	ADCon.GetLog("CN=FireScreen,CN=Computers,DC=hephaestus,DC=com",rmDistinguishedName);
//MessageBox(rmDistinguishedName.GetAt(0));
	int iLogNumber = rmDistinguishedName.GetSize();
	if (iLogNumber > 0)
	{
		// Add All Log to database
		for( int i = iLogNumber - 1; i >= 0; i--)
		{
			AddLogToDB(rmDistinguishedName.GetAt(i));
		}
		// Delete All Rule From AD.
		for( int j = 0; j < iLogNumber; j++)
		{
			ADCon.SetDeleteLog("CN=FireScreen,CN=Computers,DC=hephaestus,DC=com",j);
		}
		// Show All record in DB
		m_pSet->Requery();
		iAllRecord = CountRecord();
		m_sNumberOfLog.Format(" %d",iAllRecord);
		UpdateData(FALSE);
		// Update Log List
		m_cListLog.DeleteAllItems();
		AddLogToList(iAllRecord);
	}
	
	CRecordView::OnTimer(nIDEvent);
}

void CFireScreenLogView::OnButtonDelete() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
	m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();

	POSITION pos = m_cListLog.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		AfxMessageBox("No rule is selected.");
		return;
	}

	int iLogNo1, iLogNo2, iPosition = m_cListLog.GetNextSelectedItem(pos);
//	iPosition = iPageNumber*10 + iPosition;

	m_pSet->Move(iPosition);
	m_pSet->Delete();

	m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();
	iAllRecord = CountRecord();

	if (iAllRecord == 0)
		bLastRecord = TRUE;
	else 
		bLastRecord = FALSE;

	m_cListLog.DeleteAllItems();

	if (bLastRecord != TRUE)
	{
		m_pSet->MoveFirst();		
	// Check delete first record ?
		iLogNo1 = m_pSet->m_LogNo;
		if (iLogNo1 != 1)
		{
			m_pSet->Edit();
			m_pSet->m_LogNo = 1;
			m_pSet->Update();
		}
	// Arrange new log number.
		for (int i = 1 ; i < iAllRecord ; i++)
		{
			iLogNo1 = m_pSet->m_LogNo;
			m_pSet->MoveNext();
			iLogNo2 = m_pSet->m_LogNo;
			if ((iLogNo1 + 1) != iLogNo2)
			{
				iLogNo2--;
				m_pSet->Edit();
				m_pSet->m_LogNo = iLogNo2;
				m_pSet->Update();
			}
		}
	// Show All record in DB
		m_sNumberOfLog.Format(" %d",iAllRecord);
		UpdateData(FALSE);

	// Update log list
		OnSelchangeCombosubtype();
	}
	else
	{
		m_sNumberOfLog.Format(" %d",iAllRecord);
		UpdateData(FALSE);
	}		
}

void CFireScreenLogView::OnButtonClear() 
{
	// TODO: Add your control notification handler code here
		m_pSet->Close();
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();

	iAllRecord = CountRecord();

	if (iAllRecord == 0)
		bLastRecord = TRUE;
	else 
		bLastRecord = FALSE;

	m_cListLog.DeleteAllItems();

	if (bLastRecord != TRUE)
	{
		m_pSet->MoveFirst();		
		for (int i = 1 ; i < iAllRecord ; i++)
		{
			m_pSet->Delete();
			m_pSet->MoveNext();
		}
		m_pSet->Delete();
	}

	m_pSet->Close();
	m_sNumberOfLog.Format(" %d",0);
	UpdateData(FALSE);
	m_cListTypeSub.ResetContent();
	m_cListTypeSub.AddString("---------Nothing--------");
	m_cListTypeSub.SetCurSel(0); 	
}

void CFireScreenLogView::OnSelchangeCombotype() 
{
	// TODO: Add your control notification handler code here
	m_pSet->Close(); 
	m_pSet->m_strFilter = "[LogNo]";
	m_pSet->Open();
	iAllRecord = CountRecord();
	if (iAllRecord == 0)
		return;
	m_pSet->MoveFirst();
	int i, j, iEqual = 0, iSelected = m_cListType.GetCurSel();
	CString sTmp;
	m_cListTypeSub.ResetContent();
	saTmp.RemoveAll();
	switch (iSelected)
	{
		case 0 :
			AddLogToList(iAllRecord);
			iType = 0;
			m_cListTypeSub.AddString("---------Nothing--------");
			m_cListTypeSub.SetCurSel(0); 
			break;
		case 1 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_Destination;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_Destination)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_Destination);
					saTmp.Add((LPCTSTR)m_pSet->m_Destination);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}								
			iType = 1;
			break;
		case 2 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_Source;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_Source)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_Source);
					saTmp.Add((LPCTSTR)m_pSet->m_Source);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 2;
			break;
		case 3 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_Date;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_Date)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_Date);
					saTmp.Add((LPCTSTR)m_pSet->m_Date);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 3;
			break;
		case 4 :
			m_cListTypeSub.AddString("----Please select----");
			m_cListTypeSub.SetCurSel(0); 
			m_cListTypeSub.DeleteString(0);
			for (i = 0 ; i < iAllRecord ; i++)
			{
				if (i > 0)
				{
					sTmp = m_pSet->m_Protocol;
					m_pSet->MoveFirst();
					for (j = 0 ; j < i ; j++)
					{
						if (sTmp == m_pSet->m_Protocol)
							iEqual = 1;
						m_pSet->MoveNext();
					}
				}
				if (iEqual == 0)
				{
					m_cListTypeSub.AddString(m_pSet->m_Protocol);
					saTmp.Add((LPCTSTR)m_pSet->m_Protocol);
				}
				iEqual = 0;
				m_pSet->MoveNext();
			}
			iType = 4;
			break;
	}		
}

void CFireScreenLogView::OnSelchangeCombosubtype() 
{
	// TODO: Add your control notification handler code here
		m_cListLog.DeleteAllItems();
	int iSelected = m_cListTypeSub.GetCurSel();
	CString sTmp;
	m_pSet->Close();
	switch(iType)
	{
		case 1 :
			m_pSet->m_strFilter = "[Destination] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 2 :
			m_pSet->m_strFilter = "[Source] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 3 :
			m_pSet->m_strFilter = "[Date] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 4 :
			m_pSet->m_strFilter = "[Protocol] = '" + saTmp.GetAt(iSelected) + "'";
			break;
		case 0 :
			m_pSet->m_strFilter = "[LogNo]";
			break;
	}
	m_pSet->Open();
	iAllRecord = CountRecord();
	AddLogToList(iAllRecord);
// Show All record in DB
	m_sNumberOfLog.Format(" %d",iAllRecord);
	UpdateData(FALSE);	
}
