// FireScreenLogView.h : interface of the CFireScreenLogView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIRESCREENLOGVIEW_H__357D6024_5D86_48E5_9D25_0A4446006C85__INCLUDED_)
#define AFX_FIRESCREENLOGVIEW_H__357D6024_5D86_48E5_9D25_0A4446006C85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TIME_ELAP 10000
#include "ADConnect.h"
class CFireScreenLogSet;

class CFireScreenLogView : public CRecordView
{
protected: // create from serialization only
	CFireScreenLogView();
	DECLARE_DYNCREATE(CFireScreenLogView)

public:
	//{{AFX_DATA(CFireScreenLogView)
	enum { IDD = IDD_FIRESCREENLOG_FORM };
	CComboBox	m_cListTypeSub;
	CComboBox	m_cListType;
	CListCtrl	m_cListLog;
	CFireScreenLogSet* m_pSet;
	CString	m_sNumberOfLog;
	//}}AFX_DATA

// Attributes
public:
	CFireScreenLogDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireScreenLogView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFireScreenLogView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFireScreenLogView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonDelete();
	afx_msg void OnButtonClear();
	afx_msg void OnSelchangeCombotype();
	afx_msg void OnSelchangeCombosubtype();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	
	int CountRecord();
	BOOL bLastRecord;

	void AddLogToList(int iAllRecord);
	void AddLogToDB(CString sLog);

	CString sAllRecord;
	int iAllRecord;

	int iCountRule;
	
	CStringArray rmDistinguishedName;
	//CStringArray cName;
	//CStringArray cDistinguishedName;

	ADConnect ADCon;

	int iType;
	CStringArray saTmp;
	CStringArray saAllRecord;

};

#ifndef _DEBUG  // debug version in FireScreenLogView.cpp
inline CFireScreenLogDoc* CFireScreenLogView::GetDocument()
   { return (CFireScreenLogDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESCREENLOGVIEW_H__357D6024_5D86_48E5_9D25_0A4446006C85__INCLUDED_)
