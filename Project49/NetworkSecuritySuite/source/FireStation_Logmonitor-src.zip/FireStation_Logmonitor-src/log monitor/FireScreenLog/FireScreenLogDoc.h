// FireScreenLogDoc.h : interface of the CFireScreenLogDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIRESCREENLOGDOC_H__649C973B_FCBD_4B5C_B22E_3BAB5641A7F8__INCLUDED_)
#define AFX_FIRESCREENLOGDOC_H__649C973B_FCBD_4B5C_B22E_3BAB5641A7F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "FireScreenLogSet.h"


class CFireScreenLogDoc : public CDocument
{
protected: // create from serialization only
	CFireScreenLogDoc();
	DECLARE_DYNCREATE(CFireScreenLogDoc)

// Attributes
public:
	CFireScreenLogSet m_fireScreenLogSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireScreenLogDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFireScreenLogDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFireScreenLogDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESCREENLOGDOC_H__649C973B_FCBD_4B5C_B22E_3BAB5641A7F8__INCLUDED_)
