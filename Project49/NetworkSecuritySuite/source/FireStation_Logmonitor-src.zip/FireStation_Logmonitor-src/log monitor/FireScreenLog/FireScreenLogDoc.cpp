// FireScreenLogDoc.cpp : implementation of the CFireScreenLogDoc class
//

#include "stdafx.h"
#include "FireScreenLog.h"

#include "FireScreenLogSet.h"
#include "FireScreenLogDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogDoc

IMPLEMENT_DYNCREATE(CFireScreenLogDoc, CDocument)

BEGIN_MESSAGE_MAP(CFireScreenLogDoc, CDocument)
	//{{AFX_MSG_MAP(CFireScreenLogDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogDoc construction/destruction

CFireScreenLogDoc::CFireScreenLogDoc()
{
	// TODO: add one-time construction code here

}

CFireScreenLogDoc::~CFireScreenLogDoc()
{
}

BOOL CFireScreenLogDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogDoc diagnostics

#ifdef _DEBUG
void CFireScreenLogDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFireScreenLogDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFireScreenLogDoc commands
