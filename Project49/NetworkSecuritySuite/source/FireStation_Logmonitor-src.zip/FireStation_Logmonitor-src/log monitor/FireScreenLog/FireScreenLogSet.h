// FireScreenLogSet.h : interface of the CFireScreenLogSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIRESCREENLOGSET_H__73E08AAF_55A5_4946_9589_1F6A51C0C880__INCLUDED_)
#define AFX_FIRESCREENLOGSET_H__73E08AAF_55A5_4946_9589_1F6A51C0C880__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFireScreenLogSet : public CRecordset
{
public:
	CFireScreenLogSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CFireScreenLogSet)

// Field/Param Data
	//{{AFX_FIELD(CFireScreenLogSet, CRecordset)
	long	m_LogNo;
	CString	m_Date;
	CString	m_Time;
	CString	m_In;
	CString	m_Out;
	CString	m_Mac;
	CString	m_Source;
	CString	m_Destination;
	CString	m_Protocol;
	CString	m_Source_Port;
	CString	m_Destination_Port;
	CString	m_Type;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFireScreenLogSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRESCREENLOGSET_H__73E08AAF_55A5_4946_9589_1F6A51C0C880__INCLUDED_)

