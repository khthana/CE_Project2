// LogsFirebreakDlg.h : header file
//

#if !defined(AFX_LOGSFIREBREAKDLG_H__ABBEB6E2_1010_4578_9E82_8ADA27616508__INCLUDED_)
#define AFX_LOGSFIREBREAKDLG_H__ABBEB6E2_1010_4578_9E82_8ADA27616508__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MySqlConnect.h"

/////////////////////////////////////////////////////////////////////////////
// CLogsFirebreakDlg dialog

class CLogsFirebreakDlg : public CDialog
{
// Construction
public:
	CLogsFirebreakDlg(CWnd* pParent = NULL);	// standard constructor
	
	CMySqlConnect SqlCon;

// Dialog Data
	//{{AFX_DATA(CLogsFirebreakDlg)
	enum { IDD = IDD_LOGSFIREBREAK_DIALOG };
	CListCtrl	m_cListLog;
	CString	m_sNumberOfLog;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogsFirebreakDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	void CLogsFirebreakDlg::AddLogToList(int numofrows);


	// Generated message map functions
	//{{AFX_MSG(CLogsFirebreakDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGSFIREBREAKDLG_H__ABBEB6E2_1010_4578_9E82_8ADA27616508__INCLUDED_)
