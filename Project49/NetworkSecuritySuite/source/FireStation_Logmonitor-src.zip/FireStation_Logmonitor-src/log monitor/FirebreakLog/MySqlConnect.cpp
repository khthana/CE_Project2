// MySqlConnect.cpp : implementation file
//
#include "stdafx.h"
#include "MySqlConnect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CMySqlConnect::CMySqlConnect()
{
	CoInitialize(0);
	m_csMySqlDb		=_T("");
	m_csMySqlServer	=_T("");
	m_csMySqlUser	=_T("");
	m_csMySqlPw		=_T("");
}

CMySqlConnect::~CMySqlConnect()
{
	CoUninitialize();
}

void CMySqlConnect::ExecuteQuery()
{    
	link = mysql_init(NULL);
 	mysql_real_connect(link,"localhost","root","","snort",0,NULL,0);
    mysql_query(link,"SELECT cid,hostname,sig_name,timestamp FROM event e,signature s,sensor ss where s.sig_id = e.signature and e.sid =ss.sid ");
    result = mysql_store_result(link);
	numofrows = mysql_num_rows(result);

/*	printf("Num of result = %d\n",numofrows);   
 
	while( row = mysql_fetch_row(result) ) 
    {
    	printf("%s %s %s %s \n",row[0],row[1],row[2],row[3]);
    }
*/
//	AfxMessageBox("Minimize");

    mysql_close(link);
}