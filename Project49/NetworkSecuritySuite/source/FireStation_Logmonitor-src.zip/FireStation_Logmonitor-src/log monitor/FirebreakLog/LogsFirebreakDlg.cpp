// LogsFirebreakDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LogsFirebreak.h"
#include "LogsFirebreakDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogsFirebreakDlg dialog

CLogsFirebreakDlg::CLogsFirebreakDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLogsFirebreakDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLogsFirebreakDlg)
	m_sNumberOfLog = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLogsFirebreakDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogsFirebreakDlg)
	DDX_Control(pDX, IDC_LIST1, m_cListLog);
	DDX_Text(pDX, IDC_NUMBEROFLOG, m_sNumberOfLog);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLogsFirebreakDlg, CDialog)
	//{{AFX_MSG_MAP(CLogsFirebreakDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogsFirebreakDlg message handlers

BOOL CLogsFirebreakDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cListLog.InsertColumn(1, "No.",LVCFMT_CENTER , 33, 0);
	m_cListLog.InsertColumn(2, "Source IP",LVCFMT_CENTER ,95, 1);
	m_cListLog.InsertColumn(3, "Attack Type",LVCFMT_CENTER , 250, 2);
	m_cListLog.InsertColumn(4, "Attack Time",LVCFMT_CENTER , 150, 3);

	m_cListLog.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES |LVS_EX_FLATSB);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	SqlCon.ExecuteQuery();

	AddLogToList(SqlCon.numofrows);

		CFont *F1 = new CFont();
	LOGFONT lf = {0};
    _tcscpy(lf.lfFaceName, _T("Arial"));
    lf.lfHeight = 14;
    lf.lfWeight = FW_BOLD;
    F1->CreateFontIndirect(&lf);
	CStatic *Static1 = (CStatic*) GetDlgItem(IDC_STATIC_1);
	Static1->SetFont(F1,TRUE);
	
	m_sNumberOfLog.Format(" %d",SqlCon.numofrows);
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLogsFirebreakDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLogsFirebreakDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLogsFirebreakDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLogsFirebreakDlg::AddLogToList(int numofrows)
{
	CString sLogNo;
	LVITEM it;
	int pos;
	m_cListLog.DeleteAllItems();
	while( SqlCon.row = mysql_fetch_row(SqlCon.result) ) 
	{
		sLogNo.Format("%s",SqlCon.row[0]);
		it.mask		= LVIF_TEXT;
		it.iItem	= m_cListLog.GetItemCount();
		it.iSubItem	= 0;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		pos			= m_cListLog.InsertItem(&it);

		sLogNo.Format("%s",SqlCon.row[1]);
		it.mask		= LVIF_TEXT;
		it.iItem	= pos;
		it.iSubItem	= 1;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		m_cListLog.SetItem(&it);

		sLogNo.Format("%s",SqlCon.row[2]);
		it.mask		= LVIF_TEXT;
		it.iItem	= pos;
		it.iSubItem	= 2;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		m_cListLog.SetItem(&it);

		sLogNo.Format("%s",SqlCon.row[3]);
		it.mask		= LVIF_TEXT;
		it.iItem	= pos;
		it.iSubItem	= 3;
		it.pszText	= (LPTSTR)(LPCTSTR)sLogNo;
		m_cListLog.SetItem(&it);
	}
}
