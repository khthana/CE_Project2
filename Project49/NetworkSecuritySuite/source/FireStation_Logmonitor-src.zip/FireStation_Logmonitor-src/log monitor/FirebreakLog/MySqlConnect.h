// MySqlConnect.h: interface for the CMySqlConnect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSQLCONNECT_H__9EF8A4AF_0CDD_49B6_BBAB_1D1CAD244346__INCLUDED_)
#define AFX_MYSQLCONNECT_H__9EF8A4AF_0CDD_49B6_BBAB_1D1CAD244346__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include "include/mysql.h"

#pragma comment(lib, "Lib/libmysql.lib")

class CMySqlConnect
{
public:
	void ExecuteQuery();
	CMySqlConnect();
	virtual ~CMySqlConnect();

	MYSQL *link;
    MYSQL_RES *result;
    MYSQL_ROW row;
	int numofrows;


	CString	m_csMySqlDb,
		m_csMySqlServer,
		m_csMySqlUser,
		m_csMySqlPw;

};

#endif // !defined(AFX_MYSQLCONNECT_H__9EF8A4AF_0CDD_49B6_BBAB_1D1CAD244346__INCLUDED_)
