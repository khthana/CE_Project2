// LogsFirebreak.h : main header file for the LOGSFIREBREAK application
//

#if !defined(AFX_LOGSFIREBREAK_H__E25B2E7E_12A2_4744_AAFC_B40109E46B97__INCLUDED_)
#define AFX_LOGSFIREBREAK_H__E25B2E7E_12A2_4744_AAFC_B40109E46B97__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLogsFirebreakApp:
// See LogsFirebreak.cpp for the implementation of this class
//

class CLogsFirebreakApp : public CWinApp
{
public:
	CLogsFirebreakApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogsFirebreakApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLogsFirebreakApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGSFIREBREAK_H__E25B2E7E_12A2_4744_AAFC_B40109E46B97__INCLUDED_)
