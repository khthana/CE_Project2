#/bin/bash

/etc/oinkmaster.pl -o /etc/snort_inline/rules

for file in $(ls  /etc/snort_inline/rules/*.rules)
do
	sed -e s:^alert:drop:g ${file} > ${file}.new
	mv ${file}.new ${file} -f
done
