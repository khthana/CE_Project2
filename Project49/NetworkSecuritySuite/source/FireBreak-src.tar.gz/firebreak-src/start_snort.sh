#/bin/bash

pkill snort_inline;
modprobe ip_queue;
lsmod | grep ip_queue;

#iptables -A OUTPUT -d 172.16.144.128 -j ACCEPT;
#iptables -A FORWARD -s 172.16.144.129 -d 172.16.144.131 -j ACCEPT;
#iptables -A FORWARD -s 172.16.144.131 -d 172.16.144.129 -j ACCEPT;

iptables -A INPUT -j QUEUE;
#iptables -A FORWARD -d 172.16.144.131 -j QUEUE;
#iptables -A OUTPUT -d 172.16.144.131 -j ACCEPT;
#iptables -A OUTPUT -d 172.16.144.129 -j ACCEPT;


snort_inline  -Q  -d -v -c /etc/snort_inline/snort_inline.conf -l /var/log/snort_inline/ -t /var/log/snort_inline/ -i eth0;


#echo 1 > /usr/local/start.txt
