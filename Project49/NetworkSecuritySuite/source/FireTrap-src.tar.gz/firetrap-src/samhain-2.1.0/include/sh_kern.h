
#ifndef SH_KERN_H
#define SH_KERN_H

#include "sh_modules.h"

#ifdef SH_USE_KERN
int sh_kern_init  (void);
int sh_kern_timer (time_t tcurrent);
int sh_kern_check (void);
int sh_kern_end   (void);
int sh_kern_null  (void);

int sh_kern_set_activate (char * c);
int sh_kern_set_severity (char * c);
int sh_kern_set_timer    (char * c);
int sh_kern_set_idt      (char * c);

/* FIXME: document these */
int sh_kern_set_sct_addr (char * c);
int sh_kern_set_sc_addr  (char * c);
int sh_kern_set_proc_root (char * c);
int sh_kern_set_proc_root_lookup (char * c);
int sh_kern_set_proc_root_iops (char * c);

extern sh_rconf sh_kern_table[];
#endif

/* #ifndef SH_UTMP_H */
#endif
