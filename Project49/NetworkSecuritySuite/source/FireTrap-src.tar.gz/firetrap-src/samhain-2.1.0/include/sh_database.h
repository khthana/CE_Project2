#ifndef SH_DATABASE_H
#define SH_DATABASE_H

void sh_database_reset();
int sh_database_insert (char * message);

int sh_database_use_persistent (char * str);

int sh_database_set_database (char * str);
int sh_database_set_table (char * str);
int sh_database_set_host (char * str);
int sh_database_set_user (char * str);
int sh_database_set_password (char * str);
int sh_database_add_to_hash  (char * str);
int set_enter_wrapper (char * str);
#endif
