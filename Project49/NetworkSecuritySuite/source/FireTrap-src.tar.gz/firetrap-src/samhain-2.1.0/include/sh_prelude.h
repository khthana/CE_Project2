#ifndef SH_PRELUDE_H
#define SH_PRELUDE_H

void sh_prelude_reset();
void sh_prelude_stop();
int  sh_prelude_init();

int sh_prelude_set_profile(char *arg);

int sh_prelude_alert (int priority, int class, char * message,
		      long msgflags, unsigned long msgid);

/* map severity levels
 */
int sh_prelude_map_info (char * str);
int sh_prelude_map_low (char * str);
int sh_prelude_map_medium (char * str);
int sh_prelude_map_high (char * str);

#endif
