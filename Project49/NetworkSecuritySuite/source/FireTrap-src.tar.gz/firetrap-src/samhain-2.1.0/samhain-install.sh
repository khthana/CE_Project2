#! /bin/sh 

purge=
verbose=
express=
force=
act=

prefix=
exec_prefix=${prefix}
sbindir=/usr/local/sbin
samhain=honey
mandir=/usr/local/man

sysconfdir=/etc
configfile=REQ_FROM_SERVER/etc/honeyrc

pid_file=/var/run/honey.pid
pid_dir=/var/run

data_root=/var/lib/honey
mydatafile=REQ_FROM_SERVER/var/lib/honey/honey_file

mylogfile=/var/log/honey_log
mylogdir=/var/log

myhtmlfile=/var/log/honey.html

INSTALL_SHELL="$0 --install-sh -m 700"
INSTALL_DATA="$0 --install-sh  -m 600"

mkinstalldirs="$0 --mkinstalldirs"


DESTDIR=
user=

#
# Only call rmdir with an absolute path
#
SH_RMDIR=echo
SPATH="/bin:/usr/bin:/sbin:/usr/sbin"
OLD_IFS=${IFS}
IFS=':'; export IFS
for ff in ${SPATH}; do
  if test -x $ff/rmdir; then
      SH_RMDIR=`eval echo ${ff}/rmdir`
  fi
done
IFS=${OLD_IFS}; export IFS

case `echo "testing\c"; echo 1,2,3`,`echo -n testing; echo 1,2,3` in
  *c*,-n*) ECHO_N= ECHO_C='
' ECHO_T='	' ;;
  *c*,*  ) ECHO_N=-n ECHO_C= ECHO_T= ;;
  *)       ECHO_N= ECHO_C='\c' ECHO_T= ;;
esac


if [ x"$1" = x ]
then
    echo 'samhain-install.sh [--destdir=DESTDIR][--verbose][--express][--force] action'
    echo 'action = install-boot|install-data|install-user'
    echo '         uninstall|purge|uninstall-boot'
    echo '         uninstall-data|uninstall-man|uninstall-program|uninstall-lkm'
    echo 'samhain-install.sh --print-config <item>'
    echo 'item = name | basekey | prefix | exec_prefix | sbin_dir | man_dir'
    echo '       config_dir | config_file | pid_dir | log_dir | log_file'
    echo '       data_dir | data_file'
    exit 1
fi

while [ x"$1" != x ]; do
    case $1 in
	-v|--verbose) verbose=yes
	    shift
	    continue;;

	-e|--express) express=yes
	    shift
	    continue;;

	-f|--force) force=yes
	    shift
	    continue;;

	-d) shift
	    DESTDIR="$1"
	    if test "x${DESTDIR}" = "x/"; then
		DESTDIR=
	    fi
	    shift
	    continue;;

	--destdir=*) DESTDIR=`echo "$1" | sed 's/[-_a-zA-Z0-9]*=//'` 
	    if test "x${DESTDIR}" = "x/"; then
		DESTDIR=
	    fi
	    shift
	    continue;;

	--install-sh)
	    shift
# install - install a program, script, or datafile
# This comes from X11R5 (mit/util/scripts/install.sh).
#
# Copyright 1991 by the Massachusetts Institute of Technology
#
# Permission to use, copy, modify, distribute, and sell this software and its
# documentation for any purpose is hereby granted without fee, provided that
# the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation, and that the name of M.I.T. not be used in advertising or
# publicity pertaining to distribution of the software without specific,
# written prior permission.  M.I.T. makes no representations about the
# suitability of this software for any purpose.  It is provided "as is"
# without express or implied warranty.
#
# Calling this script install-sh is preferred over install.sh, to prevent
# `make' implicit rules from creating a file called install from it
# when there is no Makefile.
#
# This script is compatible with the BSD install script, but was written
# from scratch.  It can only install one file at a time, a restriction
# shared with many OS's install programs.


# set DOITPROG to echo to test this script

# Don't use :- since 4.3BSD and earlier shells don't like it.
doit="${DOITPROG-}"


# put in absolute paths if you don't have them in your path; or use env. vars.

mvprog="${MVPROG-mv}"
cpprog="${CPPROG-cp}"
chmodprog="${CHMODPROG-chmod}"
chownprog="${CHOWNPROG-chown}"
chgrpprog="${CHGRPPROG-chgrp}"
stripprog="${STRIPPROG-strip}"
rmprog="${RMPROG-rm}"
mkdirprog="${MKDIRPROG-mkdir}"

transformbasename=""
transform_arg=""
instcmd="$mvprog"
chmodcmd="$chmodprog 0755"
chowncmd=""
chgrpcmd=""
stripcmd=""
rmcmd="$rmprog -f"
mvcmd="$mvprog"
src=""
dst=""
dir_arg=""

while [ x"$1" != x ]; do
    case $1 in
	-c) instcmd="$cpprog"
	    shift
	    continue;;

	-d) dir_arg=true
	    shift
	    continue;;

	-m) chmodcmd="$chmodprog $2"
	    shift
	    shift
	    continue;;

	-o) chowncmd="$chownprog $2"
	    shift
	    shift
	    continue;;

	-g) chgrpcmd="$chgrpprog $2"
	    shift
	    shift
	    continue;;

	-s) stripcmd="$stripprog"
	    shift
	    continue;;

	-t=*) transformarg=`echo $1 | sed 's/-t=//'`
	    shift
	    continue;;

	-b=*) transformbasename=`echo $1 | sed 's/-b=//'`
	    shift
	    continue;;

	*)  if [ x"$src" = x ]
	    then
		src=$1
	    else
		# this colon is to work around a 386BSD /bin/sh bug
		:
		dst=$1
	    fi
	    shift
	    continue;;
    esac
done

if [ x"$src" = x ]
then
	echo "install:	no input file specified"
	exit 1
else
	true
fi

if [ x"$dir_arg" != x ]; then
	dst=$src
	src=""
	
	if [ -d $dst ]; then
		instcmd=:
	else
		instcmd=mkdir
	fi
else

# Waiting for this to be detected by the "$instcmd $src $dsttmp" command
# might cause directories to be created, which would be especially bad 
# if $src (and thus $dsttmp) contains '*'.

	if [ -f $src -o -d $src ]
	then
		true
	else
		echo "install:  $src does not exist"
		exit 1
	fi
	
	if [ x"$dst" = x ]
	then
		echo "install:	no destination specified"
		exit 1
	else
		true
	fi

# If destination is a directory, append the input filename; if your system
# does not like double slashes in filenames, you may need to add some logic

	if [ -d $dst ]
	then
		dst="$dst"/`basename $src`
	else
		true
	fi
fi

## this sed command emulates the dirname command
dstdir=`echo $dst | sed -e 's,[^/]*$,,;s,/$,,;s,^$,.,'`

# Make sure that the destination directory exists.
#  this part is taken from Noah Friedman's mkinstalldirs script

# Skip lots of stat calls in the usual case.
if [ ! -d "$dstdir" ]; then
defaultIFS='	
'
IFS="${IFS-${defaultIFS}}"

oIFS="${IFS}"
# Some sh's can't handle IFS=/ for some reason.
IFS='%'
set - `echo ${dstdir} | sed -e 's@/@%@g' -e 's@^%@/@'`
IFS="${oIFS}"

pathcomp=''

while [ $# -ne 0 ] ; do
	pathcomp="${pathcomp}${1}"
	shift

	if [ ! -d "${pathcomp}" ] ;
        then
		$mkdirprog "${pathcomp}"
	else
		true
	fi

	pathcomp="${pathcomp}/"
done
fi

if [ x"$dir_arg" != x ]
then
	$doit $instcmd $dst &&

	if [ x"$chowncmd" != x ]; then $doit $chowncmd $dst; else true ; fi &&
	if [ x"$chgrpcmd" != x ]; then $doit $chgrpcmd $dst; else true ; fi &&
	if [ x"$stripcmd" != x ]; then $doit $stripcmd $dst; else true ; fi &&
	if [ x"$chmodcmd" != x ]; then $doit $chmodcmd $dst; else true ; fi
else

# If we're going to rename the final executable, determine the name now.

	if [ x"$transformarg" = x ] 
	then
		dstfile=`basename $dst`
	else
		dstfile=`basename $dst $transformbasename | 
			sed $transformarg`$transformbasename
	fi

# don't allow the sed command to completely eliminate the filename

	if [ x"$dstfile" = x ] 
	then
		dstfile=`basename $dst`
	else
		true
	fi

# Make a temp file name in the proper directory.

	dsttmp=$dstdir/#inst.$$#

# Move or copy the file name to the temp name

	$doit $instcmd $src $dsttmp &&

	trap "rm -f ${dsttmp}" 0 &&

# and set any options; do chmod last to preserve setuid bits

# If any of these fail, we abort the whole thing.  If we want to
# ignore errors from any of these, just make sure not to ignore
# errors from the above "$doit $instcmd $src $dsttmp" command.

	if [ x"$chowncmd" != x ]; then $doit $chowncmd $dsttmp; else true;fi &&
	if [ x"$chgrpcmd" != x ]; then $doit $chgrpcmd $dsttmp; else true;fi &&
	if [ x"$stripcmd" != x ]; then $doit $stripcmd $dsttmp; else true;fi &&
	if [ x"$chmodcmd" != x ]; then $doit $chmodcmd $dsttmp; else true;fi &&

# Now rename the file to the real destination.

	$doit $rmcmd -f $dstdir/$dstfile &&
	$doit $mvcmd $dsttmp $dstdir/$dstfile 

fi &&


exit 0
	    # ----- END OF INSTALL-SH -----
	    ;;

	--mkinstalldirs)
	    shift
	    # mkinstalldirs --- make directory hierarchy
	    # Author: Noah Friedman <friedman@prep.ai.mit.edu>
	    # Created: 1993-05-16
	    # Public domain
	    # $Id: mkinstalldirs,v 1.10 1996/05/03 07:37:52 friedman Exp $
	    errstatus=0
	    for file
	    do
		set fnord `echo ":$file" | sed -ne 's/^:\//#/;s/^://;s/\// /g;s/^#/\//;p'`
		shift
		pathcomp=
		for d
		do
		    pathcomp="$pathcomp$d"
		    case "$pathcomp" in
		    -* ) pathcomp=./$pathcomp ;;
		    esac

		    if test ! -d "$pathcomp"; then
			echo "mkdir $pathcomp" 1>&2

			mkdir "$pathcomp" || lasterr=$?

			if test ! -d "$pathcomp"; then
			    errstatus=$lasterr
			fi
		    fi

		    pathcomp="$pathcomp/"
		done
	    done
	    exit $errstatus
	    # mkinstalldirs ends here
	    ;;

	install-deploy)
	    if test -f ./samhainrc.USEME
	    then
		tmpconfigfile=`echo ${configfile} | sed 's%^REQ_FROM_SERVER%%'`
		if test x"${tmpconfigfile}" = x
		then
		    echo "  No local path for configfile defined."
		    exit 0
		else 
		    cp samhainrc.USEME "${tmpconfigfile}" && chmod 0600 "${tmpconfigfile}"
                fi
            fi
	    if test -f postinstall.USEME
	    then
		/bin/sh ./postinstall.USEME
	    fi
	    exit 0
	    ;;

	print-config|--print-config)
	    shift
	    pwhat=$1
	    if test x"$1" = x
	    then
		echo "$0: Missing argument to print-config" 
		exit 1
	    fi
	    case $pwhat in
	    basekey)
		echo "542474379,540655763"
		;;

	    prefix)
		echo $prefix
		;;

	    exec_prefix)
		echo $exec_prefix
		;;

	    sbin_dir)
		echo $sbindir
		;;

	    name)
		echo $samhain
		;;

	    man_dir)
		echo $mandir
		;;

	    config_dir)
		echo $sysconfdir
		;;

	    config_file)
		echo $configfile | sed 's%^REQ_FROM_SERVER%%'
		;;

	    pid_file)
		echo ${pid_file}
		;;

	    pid_dir)
		echo ${pid_dir}
		;;

	    data_dir)
		echo /var/lib/honey
		;;

	    data_file)
		echo REQ_FROM_SERVER/var/lib/honey/honey_file | sed 's%^REQ_FROM_SERVER%%'
		;;

	    log_file)
		echo /var/log/honey_log
		;;

	    log_dir)
		echo /var/log
		;;

	    *)
		echo "$0:  Unknown item \"$pwhat\"" 
		exit 1
		;;
	    esac
	    exit 0
	    ;;

	install-user)
	    act=user
	    shift
	    user=$1
	    break;;

	install-boot)
	    act=boot
	    break;;

	uninstall-boot)
	    act=uboot
	    break;;

	install-data)
	    act=data
	    break;;

	uninstall-data)
	    act=udata
	    break;;

	uninstall-man)
	    act=uman
	    break;;

	uninstall-program)
	    act=uprogram
	    break;;

	uninstall-lkm)
	    act=ulkm
	    break;;

	uninstall | remove | purge)
	    opts=
	    test x"$verbose" = "xyes" && opts="$opts --verbose"
	    test x"$express" = "xyes" && opts="$opts --express"
	    test x"$force" = "xyes" && opts="$opts --force"
	    test x"$DESTDIR" = "x" || opts="$opts --destdir=$DESTDIR"
	    test x"$1" = "xpurge" && purge=yes
	    echo "$0 $opts uninstall-lkm"
	    eval $0 $opts uninstall-lkm
	    echo "$0 $opts uninstall-program"
	    eval $0 $opts uninstall-program
	    echo "$0 $opts uninstall-man"
	    eval $0 $opts uninstall-man
	    if test x"$force" = "x"; then
		test "x$purge" = xyes && opts="$opts --force"
	    fi
	    echo "$0 $opts uninstall-data"
	    eval $0 $opts uninstall-data
	    echo
	    echo "  To uninstall the runlevel scripts, use $0 $opts uninstall-boot"
	    echo
	    exit 0
	    ;;
	*) 
	echo "Unknown option $1"
	exit 1
	;;

    esac
done

if test x"$act" = xuser
then

#   -- the routines for installing a new user are adapted from
#      the OpenPKG bootstrap installation script, which is distributed
#      under the following license:

##  Shell-based package for OpenPKG BINARY bootstrap installation
##  Copyright (c) 2000-2002 Cable & Wireless Deutschland GmbH
##  Copyright (c) 2000-2002 The OpenPKG Project <http://www.openpkg.org/>
##  Copyright (c) 2000-2002 Ralf S. Engelschall <rse@engelschall.com>
##
##  Permission to use, copy, modify, and distribute this software for
##  any purpose with or without fee is hereby granted, provided that
##  the above copyright notice and this permission notice appear in all
##  copies.
##
##  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
##  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
##  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
##  IN NO EVENT SHALL THE AUTHORS AND COPYRIGHT HOLDERS AND THEIR
##  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
##  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
##  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
##  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
##  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
##  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
##  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
##  SUCH DAMAGE.

    if test x"$user" = x
    then
	echo "**ERROR**: No username specified"
	exit 1
    fi

    s=`uname -s 2>/dev/null` || s='Unknown'
    r=`uname -r 2>/dev/null` || r='0.0'
    platform="${s}/${r}"

    if test x"$user" = xnobody; then
	case "$platform" in
	    HP-UX/* )
	    group="nogroup"
	    ;;
	    *)
	    group="nobody"
	    ;;
	esac
    else
	group="$user"
    fi
    shell=/bin/false
    if test -f /etc/shells
    then
     grep "^/usr/bin/false" /etc/shells >/dev/null 2>&1 && shell=/usr/bin/false
     grep "^/bin/nologin"   /etc/shells >/dev/null 2>&1 && shell=/bin/nologin
     grep "^/sbin/nologin"  /etc/shells >/dev/null 2>&1 && shell=/sbin/nologin
    fi
    home="${data_root}"

    xuid=`(cat /etc/passwd; ypcat passwd) 2>/dev/null |\
          grep "^${user}:" | awk -F: '{ print $3; }'`
    if test "x$xuid" = x
    then
        #   seek for a reasonable uid/gid pair
        xuid=1000
        ok=0
        while test "x$ok" = x0
	do
            eval "u_exists=\$u_exists_$xuid"
            if test "x$u_exists" = x
	    then
                u_exists=`(cat /etc/passwd; ypcat passwd) 2>/dev/null | grep "^[^:]*:[^:]*:$xuid:"`
            fi
            eval "g_exists=\$g_exists_$xuid"
            if test "x$g_exists" = x
	    then
                g_exists=`(cat /etc/group;  ypcat group)  2>/dev/null | grep "^[^:]*:[^:]*:$xuid:"`
            fi
            if [ "x$u_exists" = x -a "x$g_exists" = x ]; then
                ok=1
                break
            fi
            xuid=`expr $xuid + 1`
        done
        eval "u_exists_$xuid=yes"
        eval "g_exists_$xuid=yes"
    else
	# user exists
	xgid=`(cat /etc/passwd; ypcat passwd) 2>/dev/null |\
          grep "^${user}:" | awk -F: '{ print $4; }'`
    fi

    if test "x$xgid" = x
    then
        xgid=`(cat /etc/group; ypcat group) 2>/dev/null |\
              grep "^${group}:" | awk -F: '{ print $3; }'`
    fi
    
    if test "x$xgid" = x
    then
        xgid="$xuid"
	g_exists=no
    else
	g_exists=yes
    fi

    uid=$xuid
    gid=$xgid

    if test -f /etc/shells
    then
	exists=`cat /etc/shells 2>/dev/null | grep "^$shell"`
	if test "x$exists" = x; then
	    echo "${shell}" >>/etc/shells
	    test -z "$verbose" || echo "  Added ${shell} to /etc/shells"
	fi
    fi

    exists=`(cat /etc/passwd; ypcat passwd) 2>/dev/null | grep "^$user:"`
    if test x"$exists" = x; then
       #   add entry to passwd database
       realname="$user"
       case "$platform" in
           FreeBSD/* | NetBSD/* )
              file=/etc/master.passwd
              entry="${user}:*:${uid}:${gid}::0:0:${realname}:${home}:${shell}"
              update="(PATH=\$PATH:/usr/sbin; pwd_mkdb -p /etc/master.passwd)"
              break
	      ;;
           Linux/* )
               file=/etc/passwd
               entry="${user}:*:${uid}:${gid}:${realname}:${home}:${shell}"
               update="(PATH=\$PATH:/usr/sbin; pwconv)"
               break
               ;;
           SunOS/5.* )
               file=/etc/passwd
               entry="${user}:*:${uid}:${gid}:${realname}:${home}:${shell}"
               update="(PATH=\$PATH:/usr/sbin; pwconv)"
               break
	       ;;
           OSF1/V5.* )
               file=/etc/passwd
               entry="${user}:*:${uid}:${gid}:${realname}:${home}:${shell}"
               update="(PATH=\$PATH:/usr/sbin; mkpasswd /etc/passwd)"
               break
               ;;
           HP-UX/* )
               file=/etc/passwd
               entry="${user}:*:${uid}:${gid}:${realname}:${home}:${shell}"
               update=":"
               break
               ;;
           IRIX*/* )
               file=/etc/passwd
               entry="${user}:*:${uid}:${gid}:${realname}:${home}:${shell}"
               update=":"
               break
               ;;
	  *)
	       echo "install-user: Unsupported system $platform"
	       echo "Please add user $user / group $group manually"
	       echo " and re-run make install-user"
	       exit 1
	       ;;
       esac
       cp $file $file.bak && \
       (grep -v '^+:' $file.bak; echo $entry; grep '^+:' $file.bak) >$file
       rm -f $file.bak >/dev/null 2>&1
       eval $update
       test -z "$verbose" || echo "  Added user: ${user} uid: ${uid} shell: ${shell}"
    else
       test -z "$verbose" || echo "  User ${user} exists already"
    fi

    #    check whether group already exists
    #    FIXME
    exists=`(cat /etc/group; ypcat group) 2>/dev/null | grep "^$group:"`
    if test x"$exists" = x
    then
	#
	# user has a valid GID
	#
	if test g_exists = xyes; then
	    exists=yes
	fi
    fi
    if test x"$exists" = x
    then
        #   add entry to group database
        file=/etc/group
        entry="${group}:*:${gid}:${user}"
        cp $file $file.bak && \
        (grep -v '^+:' $file.bak; echo $entry; grep '^+:' $file.bak) >$file
        rm -f $file.bak >/dev/null 2>&1
	test -z "$verbose" || echo "  Added group: ${group} gid: ${gid} user: ${user}"
    fi

    exit 0
fi

if test x"$act" = xboot || test x"$act" = xuboot
then
    s=`uname -s 2>/dev/null` || s='Unknown'
    r=`uname -r 2>/dev/null` || r='0.0'
    platform="${s}/${r}"

    case "$platform" in
    IRIX*/*)
        DVER="IRIX"
	test -z "$verbose" || echo "  IRIX system detected"
	rc_main=${DESTDIR}/etc/init.d
	rc_dirz=
	rc_inst="chmod 755 /etc/init.d/honey; chown root /etc/init.d/honey; chkconfig -f honey on; (cd /etc; ln -f -s init.d/honey rc2.d/S99honey; ln -f -s init.d/honey rc0.d/K10honey; )"
	rc_uinst="rm -f /etc/init.d/honey; rm -f /etc/rc2.d/S99honey; rm -f /etc/rc0.d/K10honey; chkconfig honey off"
	;;

    AIX/*)
	DVER="AIX"
	test -z "$verbose" || echo "  AIX system detected"
	ln -f -s /usr/local/sbin/honey  samhain.startAIX
	rc_main=/usr/local/sbin
	rc_dirz=
	rc_inst="/usr/sbin/mkitab -i 'honey:2:wait:/usr/local/sbin/honey start >/dev/console 2>&1'"
	rc_uinst="/usr/sbin/rmitab honey"
	;;

    HP-UX/*)
	DVER="HPUX"
	test -z "$verbose" || echo "  HP-UX system detected"
	rc_main=${DESTDIR}/sbin/init.d
	rc_dirz=
	rc_inst="chmod 555 /sbin/init.d/honey; chown bin:bin /sbin/init.d/honey; (cd /sbin && ln -f -s /sbin/init.d/honey rc2.d/S900honey && ln -f -s /sbin/init.d/honey rc1.d/K100honey; )"
	rc_uinst="rm -f /sbin/init.d/honey; rm -f /sbin/rc2.d/S900honey; rm -f /sbin/rc1.d/K100honey"
	;;

    FreeBSD/* )
	DVER="FreeBSD"
	test -z "$verbose" || echo "  FreeBSD system detected"
	rc_main=${DESTDIR}/usr/local/etc/rc.d
	rc_dirz=
	rc_inst="mv /usr/local/etc/rc.d/honey /usr/local/etc/rc.d/honey.sh &&  chmod 755 /usr/local/etc/rc.d/honey.sh"
	rc_uinst="rm -f /usr/local/etc/rc.d/honey.sh; echo You may want to remove ${rc_main} from local_startup in /etc/rc.conf; echo if it is empty"
	if test x"$act" = xboot
	then
	    if [ ! -d ${rc_main} ]; then
		test x"$act" = xboot && mkdir ${rc_main}
	    fi
	    (   . /etc/defaults/rc.conf
                . /etc/rc.conf
                found=0
                for p in ${local_startup-x}; do
                    if test "x$p" = "x${rc_main}"; then
                        found=1
                        break
                    fi
                done
                if test "x$found" = x0; then
		    cp -p /etc/rc.conf /etc/rc.conf.bak
		    (
			grep -v local_startup /etc/rc.conf.bak
			echo "local_startup=\"${rc_main} $local_startup\""
                    ) >/etc/rc.conf
                fi
            )
       fi
	;;
    SunOS/5.* )
	DVER="Solaris"
	test -z "$verbose" || echo "  Solaris system detected"
	rc_dirz=
	rc_main=${DESTDIR}/etc/init.d
	rc_inst="chmod 755 ${DESTDIR}/etc/init.d/honey; chown root:sys ${DESTDIR}/etc/init.d/honey; (cd ${DESTDIR}/etc; ln init.d/honey rc3.d/S99honey; ln init.d/honey rc0.d/K10honey; ln init.d/honey rc1.d/K10honey; )"
	rc_uinst="rm -f ${DESTDIR}/etc/init.d/honey; rm -f ${DESTDIR}/etc/rc0.d/K10honey; rm -f ${DESTDIR}/etc/rc1.d/K10honey; rm -f ${DESTDIR}/etc/rc3.d/S99honey"
	;;
    Linux/*)
	rlv="2 3 4 5"
	linkopt="-f -s"
	# find rc directories
	if test -f /usr/lib/lsb/install_initd && test -d /etc/init.d
	then
	    test -z "$verbose" || echo "  Linux Standard Base system detected"
	    DVER=LSB
	    if test x"$DESTDIR" = x 
	    then
		rc_main=/etc/init.d
		rc_dirz=
		rc_inst="/usr/lib/lsb/install_initd /etc/init.d/honey"
		rc_uinst="/usr/lib/lsb/remove_initd /etc/init.d/honey"
	    else
		rc_inst=
		rc_uinst=
		rc_main=${DESTDIR}/etc/init.d
		rc_dirz=
		# test -d /etc/init.d/rc2.d && rc_dirz=${DESTDIR}/etc/init.d/rc
		# test -d /etc/rc.d/rc2.d && rc_dirz=${DESTDIR}/etc/rc.d/rc
		# test -d /etc/rc2.d && rc_dirz=${DESTDIR}/etc/rc
	    fi
	elif test -f /etc/SuSE-release
	then
	    test -z "$verbose" || echo "  SuSE system detected"
	    DVER="Linux"
	    rc_inst=
	    rc_uinst=
	    if test -d /sbin/init.d && test -d /sbin/init.d/rc2.d
	    then
		test -z "$verbose" || echo "  SuSE 6.x system detected"
		rc_main=${DESTDIR}/sbin/init.d
		rc_dirz=${DESTDIR}/sbin/init.d/rc
	    elif test -d /etc/init.d && test -d /etc/init.d/rc2.d
	    then
		test -z "$verbose" || echo "  SuSE 7.x or newer detected"
		rc_main=${DESTDIR}/etc/init.d
		rc_dirz=${DESTDIR}/etc/init.d/rc
	    else
		echo "${0}: unknown system"
		exit 1
	    fi
	elif test -d /sbin/init.d && test -d /sbin/init.d/rc2.d
	then
	    DVER="Linux"
	    rc_inst=
	    rc_uinst=
	    test -z "$verbose" || echo "  SuSE 5.x system detected"
	    rc_main=${DESTDIR}/sbin/init.d
	    rc_dirz=${DESTDIR}/sbin/init.d/rc
	elif test -f /etc/debian_version 
	then
	    DVER="Linux"
	    test -z "$verbose" || echo "  Debian based system detected"
	    if test x"$DESTDIR" = x 
	    then
		rc_main=/etc/init.d
		rc_dirz=
		rc_uinst="/usr/sbin/update-rc.d -f honey remove"
		rc_inst="/usr/sbin/update-rc.d honey defaults 99 10"
	    else
		rc_inst=
		rc_uinst=
		rc_main=${DESTDIR}/etc/init.d
		# rc_dirz=${DESTDIR}/etc/rc
		rc_dirz=
	    fi
	elif test -f /etc/redhat-release
	then
	    DVER="Linux"
	    test -z "$verbose" || echo "  Redhat based system detected"
	    rc_uinst=
	    rc_inst=
	    rc_main=${DESTDIR}/etc/rc.d/init.d
	    rc_dirz=${DESTDIR}/etc/rc.d/rc
	elif test -f /etc/mandrake-release
	then
	    DVER="Linux"
	    test -z "$verbose" || echo "  Mandrake based system detected"
	    rc_uinst=
	    rc_inst=
	    rc_main=${DESTDIR}/etc/rc.d/init.d
	    rc_dirz=${DESTDIR}/etc/rc.d/rc
	elif test -f /etc/yellowdog-release
	then
	    DVER="Linux"
	    test -z "$verbose" || echo "  Yellow Dog based system detected"
	    rc_uinst=
	    rc_inst=
	    rc_main=${DESTDIR}/etc/rc.d/init.d
	    rc_dirz=${DESTDIR}/etc/rc.d/rc
	elif test -f /etc/slackware-version && test -f /etc/rc.d/rc.sysvinit
	then
	    DVER="Linux"
	    test -z "$verbose" || echo "  Slackware based system detected"
	    rc_uinst=
	    rc_inst=
	    rc_main=${DESTDIR}/etc/rc.d
	    rc_dirz=${DESTDIR}/etc/rc.d/rc
	elif test -f  /etc/gentoo-release
	then
	    DVER="Gentoo"
	    test -z "$verbose" || echo "  Gentoo based system detected"
	    rc_uinst="/sbin/rc-update del honey"
	    rc_inst="/sbin/rc-update add honey default"
	    rc_main=${DESTDIR}/etc/init.d
	    rc_dirz=
	else
	    echo "${0}: unknown Linux distribution"
	    rc_uinst=
	    rc_inst=
	    rc_main=
	    rc_dirz=
	    for ff in /etc/rc.d/init.d /etc/init.d /sbin/init.d; do
		if test -d $ff; then
		    rc_main="$ff"
		    break
		fi
	    done
	    for fg in /etc/rc.d/rc2.d /etc/rc2.d /sbin/init.d/rc2.d; do
		if test -d $fg; then
		    rc_dirz="`echo $fg | sed -e 's,2.*,,'`"
		    break
		fi
	    done
	    if [ x"${rc_dirz}" = x ]; then
		echo "${0}: no install directory for runlevel scripts found"
		exit 1
	    fi
	    if [ x"${rc_main}" = x ]; then
	    	echo "${0}: no install directory for runlevel scripts found"
		exit 1
	    fi
	    DVER="Linux"
	    rc_main="${DESTDIR}${rc_main}"
	    rc_dirz="${DESTDIR}${rc_dirz}"
	fi
	;;

	*)
	echo "${0}: unsupported platform ${platform}"
	exit 1
	;;
    esac

    if test x"${rc_main}" = x
    then
	echo "${0}: no install directory for runlevel scripts found"
	exit 1
    fi

    if test x"${act}" = xboot 
    then

	startscript=NONE
        if test -f init/samhain.start${DVER}
	then
	    startscript=`eval echo init/samhain.start${DVER}`
	elif test -f samhain.start${DVER}
	then
	    startscript=`eval echo samhain.start${DVER}`
	else
	    echo "${0}: cannot find samhain.start${DVER} in ./ or ./init"
	    exit 1
        fi

	if test "x${startscript}" = xNONE; then
	    echo "${0}: cannot find samhain.start${DVER} in ./ or ./init"
	    exit 1
        else
	    if test -f ${rc_main}/${samhain} && test x"$force" != xyes
	    then
		echo "  ${rc_main}/${samhain} exists ... not overwritten (or use --force)"
	    else
	        if test x"$DESTDIR" = x
		then
		    :
		else
		    ${mkinstalldirs} ${rc_main}
		    #
		    if test x"$DVER" = xSolaris; then
			${mkinstalldirs} ${DESTDIR}/etc/rc0.d
			${mkinstalldirs} ${DESTDIR}/etc/rc1.d
			${mkinstalldirs} ${DESTDIR}/etc/rc3.d
		    fi
		    #
		fi
		test -z "$verbose" || echo "  ${INSTALL_SHELL}  ${startscript} ${rc_main}/${samhain}"
		if test -f "/usr/bin/install -c"; then
		    ${INSTALL_SHELL}  ${startscript} ${rc_main}/${samhain}
		else
		    cp ${startscript} ${rc_main}/${samhain} && chmod 0700 ${rc_main}/${samhain}
		fi
	    fi
        fi


        if test x"${rc_dirz}" != x
        then
	    for ff in $rlv
	    do
	        if test x"${DESTDIR}" = x
		then
		    rldir="${rc_dirz}${ff}.d/"
		    test -z "$verbose" || echo "  cd ${rldir} && ln ${linkopt} ${rc_main}/${samhain} S99${samhain}"
		    (cd ${rldir} && ln ${linkopt} ${rc_main}/${samhain} S99${samhain})
		    test -z "$verbose" || echo "  cd ${rldir} && ln ${linkopt} ${rc_main}/${samhain} K10${samhain}"
		    (cd ${rldir} && ln ${linkopt} ${rc_main}/${samhain} K10${samhain})
		else
		    : 
                    # ${mkinstalldirs} ${rc_dirz}${ff}.d
		fi


	    done
        fi

	if test x"${rc_inst}" != x
        then
	   if test x"${DESTDIR}" = x
	   then
	       test -z "$verbose" || echo "  ${rc_inst}"
	       eval ${rc_inst}
	   fi
 	fi
	echo "installing init scripts completed"
    fi

    if test x"${act}" = xuboot 
    then
	if test x"${rc_uinst}" != x
        then
	   test -z "$verbose" || echo "  ${rc_uinst}"
	   echo
	   eval ${rc_uinst}
 	fi

        if test x"${rc_dirz}" != x
        then
	    for ff in $rlv
	    do
	      test -z "$verbose" || echo "  rm -f  ${rc_dirz}${ff}.d/S99${samhain}"
	      rm -f  ${rc_dirz}${ff}.d/S99${samhain}
	      test -z "$verbose" || echo "  rm -f  ${rc_dirz}${ff}.d/S99${samhain}"
	      rm -f  ${rc_dirz}${ff}.d/K10${samhain}
	    done
        fi

	test -z "$verbose" || echo "  rm -f ${rc_main}/${samhain}"
	rm -f ${rc_main}/${samhain}

	echo "  uninstalling init scripts completed"
    fi

    # boot_install|boot_uninstall completed
    exit 0
fi

if test x"${act}" = xulkm
then
    RVER=`uname -r`
    if test "x" != "x"; then
        if test -d /lib/modules/$RVER; then 
	    MODDIR="/lib/modules/$RVER"
	elif test -d /lib/modules/misc; then 
	    MODDIR="/lib/modules/misc"
	elif test -d /lib/modules; then 
	    MODDIR="/lib/modules/misc"
	fi
        # -- NEW --
	ALLMODS=""
        for p in $ALLMODS; do
            test -z "$verbose" || echo "  rm -f ${DESTDIR}${MODDIR}/`echo $p|sed '
s%samhain%honey%'`"
            rm -f ${DESTDIR}${MODDIR}/`echo $p|sed 's%samhain%honey%'`
        done
    fi
fi

if test x"${act}" = xuprogram
then
    PROGRAMS="samhain_setpwd   samhain"
    for p in $PROGRAMS; do
	test -z "$verbose" || echo "  rm -f ${DESTDIR}${sbindir}/`echo $p|sed 's%samhain%honey%'|sed 's%yule%honey%'`"
	rm -f ${DESTDIR}${sbindir}/`echo $p|sed 's%samhain%honey%'|sed 's%yule%honey%'`
    done
    test -z "$verbose" || echo $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${sbindir} ... $ECHO_C"
    ${SH_RMDIR} ${DESTDIR}${sbindir} >/dev/null 2>&1
    if test x$? = x0; then
	test -z "$verbose" || echo "${ECHO_T}done"
    else
	test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
    fi
    exit 0
fi

if test x"${act}" = xuman
then
    test -z "$verbose" || echo "  rm -f ${DESTDIR}${mandir}/man8/honey.8"
    rm -f ${DESTDIR}${mandir}/man8/honey.8
    test -z "$verbose" || echo "  rm -f ${DESTDIR}${mandir}/man5/honeyrc.5"
    rm -f ${DESTDIR}${mandir}/man5/honeyrc.5

    OLD_IFS=${IFS}
    IFS=':'; export IFS
    for ff in ${MANPATH}; do
      if test x"$ff/man8" = x"${DESTDIR}${mandir}/man8"; then
 	echo "  man directory ${DESTDIR}${mandir} is in your MANPATH"
	echo "  -- will not try to remove"
        IFS=${OLD_IFS}; export IFS
        exit 0
      fi
    done
    IFS=${OLD_IFS}; export IFS

    test -z "$verbose" || echo  $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${mandir}/man8 ... $ECHO_C"
    ${SH_RMDIR} ${DESTDIR}${mandir}/man8 >/dev/null 2>&1
    if test x$? = x0; then
	test -z "$verbose" || echo "${ECHO_T}done"
    else
	test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
    fi

    test -z "$verbose" || echo  $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${mandir}/man5 ... $ECHO_C"
    ${SH_RMDIR} ${DESTDIR}${mandir}/man5 >/dev/null 2>&1
    if test x$? = x0; then
        test -z "$verbose" || echo "${ECHO_T}done"
    else
        test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
    fi

    test -z "$verbose" || echo  $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${mandir} ... $ECHO_C"
    ${SH_RMDIR} ${DESTDIR}${mandir} >/dev/null 2>&1 
    if test x$? = x0; then
        test -z "$verbose" || echo "${ECHO_T}done"
    else
        test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
    fi

    exit 0
fi

if test x"${act}" = xudata
then
	test -z "$verbose" || echo "  rm -f ${DESTDIR}`echo ${mydatafile}|sed s%REQ_FROM_SERVER%%`"
	rm -f ${DESTDIR}`echo ${mydatafile}|sed s%REQ_FROM_SERVER%%`
	test -z "$verbose" || echo "  rm -f ${DESTDIR}${pid_file}"
	rm -f ${DESTDIR}${pid_file}
	test -z "$verbose" || echo "  rm -f ${DESTDIR}${mylogfile}"
	rm -f ${DESTDIR}${mylogfile}
	test -z "$verbose" || echo "  rm -f ${DESTDIR}${myhtmlfile}"
	rm -f ${DESTDIR}${myhtmlfile}

	test -z "$verbose" || echo $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${pid_dir} ... $ECHO_C"
	${SH_RMDIR} ${DESTDIR}${pid_dir} >/dev/null 2>&1 
	if test x$? = x0; then
	    test -z "$verbose" || echo "${ECHO_T}done"
	else
	    test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
	fi

	test -z "$verbose" || echo $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${mylogdir} ... $ECHO_C"
	${SH_RMDIR} ${DESTDIR}${mylogdir} >/dev/null 2>&1
	if test x$? = x0; then
	    test -z "$verbose" || echo "${ECHO_T}done"
	else
	    test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
	fi

	test -z "$verbose" || echo $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${data_root} ... $ECHO_C"
	${SH_RMDIR} ${DESTDIR}${data_root} >/dev/null 2>&1
	if test x$? = x0; then
	    test -z "$verbose" || echo "${ECHO_T}done"
	else
	    test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
	fi

	if test x"$force" = "xyes"
	then
	    test -z "$verbose" || echo "  rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`" 
	    rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`
	elif test x"$purge" = "xyes"
	then
	    test -z "$verbose" || echo "  rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`" 
	    rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`
	elif test x"$express" = x; then
	    echo "  Do you want to remove the configuration file [y/n] ?"
	    while [ "1" = "1" ]; do
		read ff
		case "$ff" in
		Y* | y* )
		   test -z "$verbose" || echo "  rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`" 
		   rm -f ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%`
		   break
 		   ;;
		N* | n* )
		    test -z "$verbose" || echo "  ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%` NOT removed" 
		    break
		    ;;
		*)
		    echo "  Enter y[es] or n[o]"
		    ;;
		esac
	    done
	else
	    test -z "$verbose" || echo "  NOT REMOVED: config file ${DESTDIR}`echo ${configfile}|sed s%REQ_FROM_SERVER%%` (use --force to remove)"
	fi

	test -z "$verbose" || echo  $ECHO_N "  ${SH_RMDIR} ${DESTDIR}${sysconfdir} ... $ECHO_C"
	${SH_RMDIR} ${DESTDIR}${sysconfdir} >/dev/null 2>&1 
	if test x$? = x0; then
	    test -z "$verbose" || echo "${ECHO_T}done"
	else
	    test -z "$verbose" || echo "${ECHO_T}failed (not empty ?)"
	fi

	exit 0
fi

if test x"${act}" = xdata
then
    STEGIN=
    CONVERT=

    GPGPATH=

    NTEST=-DSH_WITH_CLIENT

    if test x"${NTEST}" = "x-DSH_WITH_SERVER"
    then
	RCFILE=yulerc
	if test -f $RCFILE
	then
	    :
	else
	    if test -f yulerc.template
	    then
		cp yulerc.template $RCFILE
	    fi
	fi
    else
	RCFILE=samhainrc
	IN_RCFILE=samhainrc.linux

	if test -f ${RCFILE}
	then
	    :
	else
	    if test -f ${IN_RCFILE}
	    then
		test -z "$verbose" || echo "  cp ${IN_RCFILE} ${RCFILE}"
		cp ${IN_RCFILE} ${RCFILE}
	    fi
	fi
    fi

    if test -f $RCFILE
    then
        :
    else
	echo "${0}: cannot find configuration file $RCFILE"
	exit 1
    fi

    if test x"${GPGPATH}" != x
    then
	echo
	echo "You need to sign the config file now"
	echo
	test -z "$verbose" || echo "  ${GPGPATH} -a --clearsign $RCFILE"
	if test x"${NTEST}" = "x-DSH_WITH_SERVER"
	then
	    myident_uid=`(cat /etc/passwd; ypcat passwd) 2>/dev/null |\
		  grep "^${samhain}:" | awk -F: '{ print $3; }'`
	    if test x"${myident_uid}" != x
	    then
		DOT_GNUPG=`eval echo ~${samhain}/.gnupg`
	        test -z "$verbose" || echo "  using --homedir ${DOT_GNUPG}"
		${GPGPATH} --homedir ${DOT_GNUPG} -a --clearsign $RCFILE
	    else
		${GPGPATH} -a --clearsign $RCFILE
	    fi
	else
	    ${GPGPATH} -a --clearsign $RCFILE
	fi

	if test -f ${RCFILE}.asc
	then
	    test -z "$verbose" || echo "  mv -f ${RCFILE}.asc samhainrc.pre"
	    mv -f ${RCFILE}.asc samhainrc.pre
	else
	    echo "**********************************************************"
	    echo
	    echo "${0}: ERROR: cannot find signed file ${RCFILE}.asc"
	    echo
	    echo "   --- You need to sign the configuration file ---"
	    echo
	    echo "**********************************************************"
	    cp ${RCFILE} samhainrc.pre
        fi
    else
	test -z "$verbose" || echo "  cp $RCFILE samhainrc.pre"
	cp $RCFILE samhainrc.pre
    fi

    if test x"${STEGIN}" != x
    then
	test -z "$verbose" || echo "  searching for ImageMagick convert utility"
	OPATH=${PATH}
	PATH="/usr/local/bin:/usr/X11R6/bin:"${PATH}

	OIFS=${IFS}
	IFS=":"

	for dd in ${PATH} 
	do
	    if test -f "${dd}/convert"
	    then
		"${dd}/convert" --help | grep  ImageMagick >/dev/null 2>&1 && \
 		CONVERT="${dd}/convert"
		test -z "$verbose" || echo "  CONVERT=${dd}/convert" 
	    fi
	done

	IFS=${OIFS}

	if test x"${CONVERT}" = x
	then
	    echo "${0}: cannot find ImageMagick convert utility in PATH=${PATH}"
	    exit 1
        fi

	PATH=${OPATH}

 	if test -f stealth_template.jpg
	then
	    test -z "$verbose" || echo "  ${CONVERT} +compress stealth_template.jpg stealth_template.ps"
	    "${CONVERT}" +compress stealth_template.jpg stealth_template.ps
	else
	    echo "${0}: cannot find file stealth_template.jpg"
	    exit 1
        fi


	if test -f stealth_template.ps
	then
	    :
	else
	    echo "${0}: file stealth_template.ps not created"
	    exit 1
        fi

	if test -f samhainrc.pre
	then
	    :
	else
	    echo "${0}: cannot find configuration file samhainrc.pre"
	    exit 1
        fi

	if test -f ./samhain_stealth
	then
	    :
	else
	    echo "${0}: cannot find utility ./samhain_stealth"
	    exit 1
        fi

	ccount=`./samhain_stealth -o samhainrc.pre 2>&1 | awk '{ print $1 }'`
	mcount=`./samhain_stealth -i stealth_template.ps 2>&1 | awk '{ print $7 }'`

	if test ${mcount} -lt ${ccount}
	then 
	    echo "${0}: configuration file samhainrc too big,"
	    echo "      need a larger image stealth_template.jpg to store"
	    exit 1
        fi
	
	test -z "$verbose" || echo "  ./samhain_stealth -s stealth_template.ps samhainrc.pre"
	./samhain_stealth -s stealth_template.ps samhainrc.pre

	test -z "$verbose" || echo "  mv -f stealth_template.ps samhainrc.install"
	mv -f stealth_template.ps samhainrc.install
    else
	test -z "$verbose" || echo "  mv -f samhainrc.pre samhainrc.install"
	mv -f samhainrc.pre samhainrc.install
    fi

    tmp_configfile=`echo ${configfile} | sed 's%^REQ_FROM_SERVER%%'`

    if test x"${tmp_configfile}" = x
    then
	echo "  No local configfile to install."
	exit 0
    fi

    if test -f ${DESTDIR}${tmp_configfile} && test x"$force" = x
    then
	echo "  ${DESTDIR}${tmp_configfile} exists ... not overwritten (or use --force)"
    else
	test -z "$verbose" || echo "  ${INSTALL_DATA} samhainrc.install ${DESTDIR}${tmp_configfile}"
	${INSTALL_DATA} samhainrc.install ${DESTDIR}${tmp_configfile}
    fi

    if test x"${NTEST}" = "x-DSH_WITH_SERVER"
    then
       test -z "$verbose" || echo "  chown daemon ${DESTDIR}${tmp_configfile}"
       chown daemon ${DESTDIR}${tmp_configfile}
    fi

    #
    # Changed: don't check if DESTDIR is set, as these are not 
    #          the true install locations anyway
    #
    if test -f trustfile && test x"${DESTDIR}" = x
    then
        test -z "$verbose" || echo "  checking whether paths are trustworthy"
	RESULT=`./trustfile ${DESTDIR}${tmp_configfile} 2>&1`
	if test x$? != x0
	then
	    echo 
	    ./trustfile ${DESTDIR}${tmp_configfile}
	    echo
	else
	    test -z "$verbose" || echo "  configuration file ${DESTDIR}${tmp_configfile} ... OK"
	fi

	RESULT=`./trustfile ${DESTDIR}${pid_dir} >/dev/null 2>&1`
	if test x$? != x0
	then
	    echo 
	    ./trustfile ${DESTDIR}${pid_dir}
	    echo
	else
	    test -z "$verbose" || echo "  state directory ${DESTDIR}${pid_dir} ... OK"
	fi

	RESULT=`./trustfile ${DESTDIR}${mylogdir} >/dev/null 2>&1`
	if test x$? != x0
	then
	    echo 
	    ./trustfile ${DESTDIR}${mylogdir}
	    echo
	else
	    test -z "$verbose" || echo "  state directory ${DESTDIR}${mylogdir} ... OK"
	fi

	RESULT=`./trustfile ${DESTDIR}${data_root} >/dev/null 2>&1`
	if test x$? != x0
	then
	    echo 
	    ./trustfile ${DESTDIR}${data_root}
	    echo
	else
	    test -z "$verbose" || echo "  data directory ${DESTDIR}${data_root} ... OK"
	fi
    fi
    # install_data
    exit 0
fi

	
