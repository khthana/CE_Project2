#ifndef _BIGNUM_INTERNAL_H_
#define _BIGNUM_INTERNAL_H_

#define BIGNUM_DIGIT unsigned short
#define BIGNUM_TWO_DIGITS unsigned long

#define BIG_CHARBITS 8
#define BIGNUM_DIGIT_BITS 16
#define BIGNUM_TWO_DIGITS_BITS 32

struct big_struct
{
    int sign;
    unsigned long dgs_alloc;
    unsigned long dgs_used;
    BIGNUM_DIGIT *dp;
};

#define BIG_RAND_A1 805
#define BIG_RAND_C1 345
#define BIG_RAND_A2 925
#define BIG_RAND_C2 767

#define MEMCPY_LONG_COUNTER

#endif
