#ifndef SH_MK_H
#define SH_MK_H
#define MKB_16 1
#define MKB_08 1
#define MKB_04 1
#define MKB_02 1
#define MKB_01 1
#define MKA_14 1
#define MKA_07 1
#define MKA_05 1
#define MKA_03 1
#define MKA_01 1
#define MKC_16 1
#define MKC_15 1
#define MKC_08 1
#define MKC_05 1
#define MKC_02 1
#define MKC_01 1
#define MKD_14 1
#define MKD_06 1
#define MKD_05 1
#define MKD_04 1
#define MKD_01 1
#endif
