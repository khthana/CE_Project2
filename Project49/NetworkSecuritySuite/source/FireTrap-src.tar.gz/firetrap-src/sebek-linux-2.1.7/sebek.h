/*
 * Copyright (C) 2001/2002 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#ifndef __SEBEK_H__
#define __SEBEK_H__

#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif



#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/list.h>
#include <linux/smp_lock.h>
#include <asm/unistd.h>
#include <linux/tty.h>
#include <linux/in.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/inetdevice.h>
#include <net/checksum.h>
#include <linux/time.h>
#include <linux/proc_fs.h>
#include <asm/processor.h>

#define BUFLEN  1400 
#define SPORT   1101
#define DPORT   1101
#define MAGIC   0xD0D0D0D0

#include "fudge.h"


//----- allow for repositioning of variables within variable length array

#ifndef BS
#define BS                     64
#endif

#ifndef DIP_OFFSET
#define DIP_OFFSET             0
#endif

#ifndef DPORT_OFFSET
#define DPORT_OFFSET           1
#endif

#ifndef SIP_OFFSET
#define SIP_OFFSET             2
#endif

#ifndef SPORT_OFFSET
#define SPORT_OFFSET           3
#endif

#ifndef KSO_OFFSET
#define KSO_OFFSET             4
#endif 

#ifndef MAGIC_OFFSET
#define MAGIC_OFFSET           5
#endif


#ifndef SMAC_0_OFFSET
#define SMAC_0_OFFSET          10
#define SMAC_1_OFFSET          11
#define SMAC_2_OFFSET          12
#define SMAC_3_OFFSET          13
#define SMAC_4_OFFSET          14
#define SMAC_5_OFFSET          15
#endif

#ifndef DMAC_0_OFFSET
#define DMAC_0_OFFSET          20
#define DMAC_1_OFFSET          21
#define DMAC_2_OFFSET          22
#define DMAC_3_OFFSET          23
#define DMAC_4_OFFSET          24
#define DMAC_5_OFFSET          25
#endif


u32      BLOCK[BS];


//-----------------------------------------------------------------------------
//----- input variables
//-----------------------------------------------------------------------------
char * INTERFACE; //char * interface;
char * DESTINATION_IP; //char * destination_ip;
char * DESTINATION_MAC; //char * destination_mac;

int    DESTINATION_PORT; //int    destination_port;
int    SOURCE_PORT; //int    source_port;    
int    KEYSTROKES_ONLY; //int    keystroke_only;
int    MAGIC_VALUE; //int    magic_value;
//-----------------------------------------------------------------------------
//----- internal config variables
//-----------------------------------------------------------------------------
u32 tx_bytes;
u32 tx_packets;
u32 s_bytes;
u32 s_packets;


struct net_device *output_dev;
get_info_t * old_get_info;

spinlock_t counter_lock = SPIN_LOCK_UNLOCKED;

struct sbk_h{
  u32  magic       __attribute__((packed)) ;
  u16  ver         __attribute__((packed)) ;
  u16  type        __attribute__((packed)) ;
  u32  counter     __attribute__((packed)) ;
  u32  time_sec    __attribute__((packed)) ;
  u32  time_usec   __attribute__((packed)) ;
  u32  pid         __attribute__((packed)) ;
  u32  uid         __attribute__((packed)) ;
  u32  fd          __attribute__((packed)) ;
  char com[12]     __attribute__((packed)) ;
  u32  length      __attribute__((packed)) ;
};



//----- data structure that holds system call table
unsigned long **sct;


//----- std module fuctions needed for every module.
int init_module();
int cleanup_module();

//----- ptr to the original sys_read call
int (*ord) (unsigned int,char *,size_t);

//----- proto for the new sebekified sys_read
inline int nrd(unsigned int,char *,size_t);




#endif
