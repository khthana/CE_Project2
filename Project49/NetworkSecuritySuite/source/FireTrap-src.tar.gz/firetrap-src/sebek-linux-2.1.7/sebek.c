/*
 * Copyright (C) 2001/2002 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#define MODULE 
#define __KERNEL__



#include "sebek.h"

//---- this is dumb
#include "af_packet.c"


//---- get parameters from insmod

MODULE_PARM(INTERFACE,"s");
MODULE_PARM(DESTINATION_IP,"s");
MODULE_PARM(DESTINATION_MAC,"s");

MODULE_PARM(DESTINATION_PORT,"i");
MODULE_PARM(SOURCE_PORT,"i");
MODULE_PARM(KEYSTROKES_ONLY,"i");
MODULE_PARM(MAGIC_VALUE,"i");


//------ ip address as text to integer

inline __u32 in_aton(const char *str)
{
  unsigned long l;
  unsigned int val;
  int i;
  

  if(!str)return 0;

  l = 0;
  for (i = 0; i < 4; i++)
    {
      l <<= 8;
      if (*str != '\0')
	{
	  val = 0;
	  while (*str != '\0' && *str != '.')
	    {
	      val *= 10;
	      val += *str - '0';
	      str++;
	    }
	  l |= val;
	  if (*str != '\0')
	    str++;
	}
    }
  return(htonl(l));
}



//------ converts string as a hexidecimal value to a unsigned octet
//------ the +48 nonsense is needed to offset into the lookup table.

inline __u8  hotou(char * str){

  //-----------------------------------------------------------------------------
  //----- ascii, but these are offset by 48.
  //-----------------------------------------------------------------------------

  char cvtIn[] = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9,               /* '0' - '9' */
    100, 100, 100, 100, 100, 100, 100,          /* punctuation */
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19,     /* 'A' - 'Z' */
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
    30, 31, 32, 33, 34, 35,
    100, 100, 100, 100, 100, 100,               /* punctuation */
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19,     /* 'a' - 'z' */
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
    30, 31, 32, 33, 34, 35
  };



  if(!str || strlen(str) != 2)return 0;

  return  (cvtIn[str[0]-48] << 4) +cvtIn[str[1]-48];
}
  



//----- generates internal values for parameters passed in at time of insmod.


inline int  parse_params(void){
  char octet[3];
  
  octet[2] = '\0';

  //------- read in keystroke only value
  if(KEYSTROKES_ONLY){
    BLOCK[KSO_OFFSET]   = KEYSTROKES_ONLY;
    KEYSTROKES_ONLY = 0;
  }

  //------- read in magic value
  if(MAGIC_VALUE){
    BLOCK[MAGIC_OFFSET] = MAGIC_VALUE;
    MAGIC_VALUE = 0;
  }

  //------- read in destination port
  if(DESTINATION_PORT){
    BLOCK[DPORT_OFFSET] = DESTINATION_PORT;
    DESTINATION_PORT = 0;
  }

  //------- read in source port
  if(SOURCE_PORT){
    BLOCK[SPORT_OFFSET] = SOURCE_PORT;
    SOURCE_PORT = 0;
  }

  if(!DESTINATION_IP || !DESTINATION_MAC){
    return 0;
  }

  //------ read in output interface
  if(INTERFACE){
    output_dev = __dev_get_by_name(INTERFACE);
    memset(INTERFACE,0,strlen(INTERFACE));
  }
  
  if(!output_dev)return 0;
  
  
  //------- read in dst ip
  BLOCK[DIP_OFFSET] = in_aton(DESTINATION_IP);
  memset(DESTINATION_IP,0,strlen(DESTINATION_IP)); 


  //------- read in dst mac
  if(DESTINATION_MAC && strnlen(DESTINATION_MAC,18) == 17){

    memcpy(octet,DESTINATION_MAC,2);
    BLOCK[DMAC_0_OFFSET] = hotou(octet);

    memcpy(octet,DESTINATION_MAC+3,2);
    BLOCK[DMAC_1_OFFSET] = hotou(octet);

    memcpy(octet,DESTINATION_MAC+6,2);
    BLOCK[DMAC_2_OFFSET] = hotou(octet);
    
    memcpy(octet,DESTINATION_MAC+9,2);
    BLOCK[DMAC_3_OFFSET] = hotou(octet);
    
    memcpy(octet,DESTINATION_MAC+12,2);
    BLOCK[DMAC_4_OFFSET] = hotou(octet);

    memcpy(octet,DESTINATION_MAC+15,2);
    BLOCK[DMAC_5_OFFSET] = hotou(octet);

    memset(DESTINATION_MAC,0,strlen(DESTINATION_MAC));
  }    
  
  return 1;
}




//----- this create a udp packet based on the parameters passed into the
//----- module at ismode time, payload is added later.

inline struct sk_buff *  gen_pkt(u_int32_t time_sec,
				 u_int32_t time_usec,
				 u_int32_t fd,
				 u_int32_t len, 
				 u_char *  buffer
				 ){




  struct sk_buff *skb;
  struct ethhdr  *eth;
  struct iphdr   *iph;
  struct udphdr  *udph;
  u_char         *payload;
  struct sbk_h   *header;


  static u_int32_t counter;


 int pktsize;
 int paysize;

 //------ size of sebek header + length of data is the payload
 paysize  = sizeof(struct sbk_h) + len;


 //----- packet length
 pktsize = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + paysize;


 
 skb = alloc_skb(pktsize, GFP_ATOMIC);

 if (!skb) {
   return 0;
 }
 
 //----- setup pointers
 skb_reserve(skb,sizeof(struct ethhdr));

 eth     = (struct ethhdr *) skb_push(skb,sizeof(struct ethhdr));
 iph     = (struct iphdr *)  skb_put(skb, sizeof(struct iphdr));
 udph    = (struct udphdr *) skb_put(skb, sizeof(struct udphdr));
 payload = (u_char *)        skb_put(skb, paysize);


 //----- fill udp header data
 udph->source  = htons(BLOCK[SPORT_OFFSET]);
 udph->dest    = htons(BLOCK[DPORT_OFFSET]);
 udph->len     = htons(paysize);
 udph->check   = 0; 
 

 //-----fill ip header data
 iph->ihl      = 5;
 iph->version  = 4;
 iph->ttl      = 32;
 iph->tos      = 13;
 iph->protocol = IPPROTO_UDP; 
 iph->saddr    = BLOCK[SIP_OFFSET];
 iph->daddr    = BLOCK[DIP_OFFSET];
 iph->frag_off = 0;
 iph->tot_len  = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + paysize );
 iph->check    = 0;
 

 //-----fill ethernet header data
 eth->h_proto = htons(ETH_P_IP);

 eth->h_source[0] = BLOCK[SMAC_0_OFFSET];
 eth->h_source[1] = BLOCK[SMAC_1_OFFSET];
 eth->h_source[2] = BLOCK[SMAC_2_OFFSET];
 eth->h_source[3] = BLOCK[SMAC_3_OFFSET];
 eth->h_source[4] = BLOCK[SMAC_4_OFFSET];
 eth->h_source[5] = BLOCK[SMAC_5_OFFSET];

 eth->h_dest[0] = BLOCK[DMAC_0_OFFSET];
 eth->h_dest[1] = BLOCK[DMAC_1_OFFSET];
 eth->h_dest[2] = BLOCK[DMAC_2_OFFSET];
 eth->h_dest[3] = BLOCK[DMAC_3_OFFSET];
 eth->h_dest[4] = BLOCK[DMAC_4_OFFSET];
 eth->h_dest[5] = BLOCK[DMAC_5_OFFSET];

 

 //-----fill sock buff header data
 skb->protocol = __constant_htons(ETH_P_IP);
 skb->mac.raw = ((u8 *)eth);
 skb->dev = output_dev;
 skb->pkt_type = PACKET_HOST;


 //----- fill in the sebek data
 header = (struct sbk_h *)payload;
 header->magic        = htonl(BLOCK[MAGIC_OFFSET]);
 header->ver          = htons(1);
 header->type         = htons(0);

 spin_lock(&counter_lock);
 header->counter      = htonl(counter++);
 spin_unlock(&counter_lock);

 header->time_sec     = htonl(time_sec);
 header->time_usec    = htonl(time_usec);
 header->pid          = htonl(current->pid);
 header->uid          = htonl(current->uid);
 header->fd           = htonl(fd);
 strncpy(header->com,current->comm,sizeof(header->com));
 header->length       = htonl(len);

 //----- copy over the goods.
 copy_from_user(payload + sizeof(struct sbk_h),buffer,len);

 //----- run the checksum
 iph->check    = ip_fast_csum((void *) iph, iph->ihl);

 return skb;
}


//------ tx:   a tasklet that services the packet buffer, thus decoupling packet TX from
//------       the read call a bit.

inline int tx(struct sk_buff *skb){

  struct net_device_stats *stats;    //----- interface stats ptr
  
  if(!skb){
    return -1;
  }
    
  //----- lock the output device
  spin_lock_bh(&output_dev->xmit_lock);  
  
  //------ if Interface ready, TX
  if(output_dev && !netif_queue_stopped(output_dev)){
    
    //------ need to synch on pbuf_end decrement
    if(!output_dev->hard_start_xmit(skb, output_dev)){
      //--- returnval of 0 == success
      s_packets++;
      s_bytes += skb->len;
    }
  }else{
    //----- drop the packet
    kfree_skb(skb);
  }

  spin_unlock_bh(&output_dev->xmit_lock);

  return 1;
     

}

//----- log:  network data log function.  Uses the same packet buffer repeatedly, overwriting
//-----       the payload each time.  There is no buffering, if the device is buisy log
//-----       data is lost.

inline int log(u_int32_t time_sec,
	       u_int32_t time_usec,
	       u_int32_t fd,
	       u_int32_t len, 
	       u_char *  buffer) {

  struct  sk_buff *skb;

  if(!output_dev){
    return -3;
  }

  //----- generate packet
  if(!(skb = gen_pkt(time_sec,time_usec,fd,len,buffer))){
    return -2;
  }

  //---- tx packet
  return tx(skb);
  
  
}




//----- nrd:  New Read, this calls the old read call then records all the
//-----       interesting data.  It uses the log function for recording.
 
inline int nrd (unsigned int fd, char *buf, size_t count) {

  int r;

  struct timeval tv;

  char * ptr;

  u_int32_t bufsize;

 
  //----- run original sys_read....
  r = ord(fd, buf, count);


  //----- check for error and interest
  if(r < 1 || (BLOCK[KSO_OFFSET] && r > 1))return r;

 
  //----- get timestamp
  do_gettimeofday(&tv);
 
 
  //----- log the read contents.  Including context data.    
  bufsize = BUFLEN - sizeof(struct sbk_h);

  if(r < bufsize){

    //----- data is less than buffer size, we can copy it in single step
    log(tv.tv_sec,tv.tv_usec,fd,r,buf);
    
  }else{

    //----- data is > buffer size, need to nibble at it
    for(ptr = buf; ptr + bufsize  <= buf + r ; ptr+= bufsize){
      log(tv.tv_sec,tv.tv_usec,fd,bufsize,ptr);
    }

    //----- dont forget the remainder
    log(tv.tv_sec,tv.tv_usec,fd,r % bufsize,ptr);
  }
  
  return r;  
}


//----- sprintf_stats: prints stats blob for output via proc/net/dev
//-----                in this case we are modifiying data to remove 
//-----                bytes and packets sent by sebek

static int sprintf_stats(char *buffer, struct net_device *dev)
{
  struct net_device_stats *stats = (dev->get_stats ? dev->get_stats(dev): NULL);
  int size;

  u32 bytes;
  u32 packets;


  if (stats){
   //----- still havent address counter rollover or poll based counters
   //----- which cause the counters to be correct on average but
   //----- still decrease in value periodically as
    if(dev == output_dev){
      //--- correct the counters this is the sebek interface
      bytes   = stats->tx_bytes   - s_bytes;
      packets = stats->tx_packets - s_packets;

      if(bytes > tx_bytes){
        tx_bytes = bytes;
      }else{
        bytes = tx_bytes;
      }

      if(packets > tx_packets){
        tx_packets = packets;
      }else{
        packets = tx_packets;
      }



    }else{
      bytes   = stats->tx_bytes;
      packets = stats->tx_packets;

    }
    size = sprintf(buffer, "%6s:%8lu %7lu %4lu %4lu %4lu %5lu %10lu %9lu %8lu %7lu %4lu %4lu %4lu %5lu %7lu %10lu\n",
                   dev->name,
                   stats->rx_bytes,
                   stats->rx_packets, stats->rx_errors,
                   stats->rx_dropped + stats->rx_missed_errors,
                   stats->rx_fifo_errors,
                   stats->rx_length_errors + stats->rx_over_errors
                   + stats->rx_crc_errors + stats->rx_frame_errors,
                   stats->rx_compressed, stats->multicast,
                   bytes,
                   packets, stats->tx_errors, stats->tx_dropped,
                   stats->tx_fifo_errors, stats->collisions,
                   stats->tx_carrier_errors + stats->tx_aborted_errors
                   + stats->tx_window_errors + stats->tx_heartbeat_errors,
                   stats->tx_compressed);
  }else{
    size = sprintf(buffer, "%6s: No statistics available.\n", dev->name);
  }
  return size;
}





//----- dev_get_info:  called when /proc/net/dev is accessed this calls 
//-----                the modified sprintf_stats.
static int dev_get_info(char *buffer, char **start, off_t offset, int length)
{
        int len = 0;
        off_t begin = 0;
        off_t pos = 0;
        int size;
        struct net_device *dev;


        size = sprintf(buffer,
                "Inter-|   Receive                                                |  Transmit\n"
                " face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n");

        pos += size;
        len += size;


        read_lock(&dev_base_lock);
        for (dev = dev_base; dev != NULL; dev = dev->next) {
                size = sprintf_stats(buffer+len, dev);
                len += size;
                pos = begin + len;

                if (pos < offset) {
                        len = 0;
                        begin = pos;
                }
                if (pos > offset + length)
                        break;
        }
        read_unlock(&dev_base_lock);

        *start = buffer + (offset - begin);     /* Start of wanted data */
        len -= (offset - begin);                /* Start slop */
        if (len > length)
                len = length;                   /* Ending slop */
        if (len < 0)
                len = 0;
        return len;
}








int init_module(void)
{

 struct module *mod_ptr; 
 unsigned long ptr;
 extern int loops_per_jiffy;

 struct proc_dir_entry * proc_ptr;

  //--- insmod will complain otherwise
#ifdef USE_MOD_LICENSE
  //----- we lie here to keep kernel happy.
  MODULE_LICENSE("GPL");
#endif
  
  EXPORT_NO_SYMBOLS;

  tx_packets = 0;
  tx_bytes   = 0;

  lock_kernel();

  if(!parse_params())goto out_unlock;

  
  //----- override the read call
  sct = NULL;
   
  for (ptr = (unsigned long)&loops_per_jiffy;
       ptr < (unsigned long)&boot_cpu_data; ptr += sizeof(void *)){
    
    unsigned long *p;
    p = (unsigned long *)ptr;
    //---- orig ver that looked for sys_exit didnt work on stock
    //---- kerns.
    if (p[__NR_close] == (unsigned long) sys_close){
      sct = (unsigned long **)p;
      break;
    }
  }
  
  if(sct){
    //----- replace the read call in the table
    (unsigned long *)ord = sct[__NR_read];
    sct[__NR_read] =  (unsigned long *)nrd;
  }else{
    goto out_unlock;
  }
  
  //----- Override AF_Packet code 
  remove_proc_entry("net/packet", 0);
  sock_unregister(PF_PACKET);       
  sock_register(&packet_family_ops);
  register_netdevice_notifier(&packet_netdev_notifier);
  create_proc_read_entry("net/packet", 0, 0, packet_read_proc, NULL);
  

  //------ Override /proc/net/dev, recording the old function 
  for(proc_ptr = proc_net->subdir;proc_ptr !=0;proc_ptr = proc_ptr->next){
    if(proc_ptr->namelen == 3 && !memcmp("dev",proc_ptr->name,3)){
      old_get_info = proc_ptr->get_info;
    }
  }

  proc_net_remove("dev");
  proc_net_create("dev",0,dev_get_info);


  //----- initialize data needed for packet output  
 if (!output_dev)goto out_unlock;
 if (output_dev->type != ARPHRD_ETHER)goto out_unlock;
 if (!netif_running(output_dev))goto out_unlock;


 //------ set up src MAC addr
 BLOCK[SMAC_0_OFFSET] = output_dev->dev_addr[0];
 BLOCK[SMAC_1_OFFSET] = output_dev->dev_addr[1];
 BLOCK[SMAC_2_OFFSET] = output_dev->dev_addr[2];
 BLOCK[SMAC_3_OFFSET] = output_dev->dev_addr[3];
 BLOCK[SMAC_4_OFFSET] = output_dev->dev_addr[4];
 BLOCK[SMAC_5_OFFSET] = output_dev->dev_addr[5];
 
 if (output_dev->ip_ptr){
  struct in_device *in_dev = output_dev->ip_ptr;

  if (in_dev->ifa_list)
    BLOCK[SIP_OFFSET] = in_dev->ifa_list->ifa_address;
 } 


  
out_unlock:
 spin_lock_init(&counter_lock);
  unlock_kernel(); 

  return 0;
}





int cleanup_module(void)
{

  
  lock_kernel();

  //----- reset the read call
  if(sct && ord){
    sct[__NR_read] = (unsigned long *)ord;
  }
 
  //----- what about the af_packet code?


  //----- remove /proc/net/dev 
  proc_net_remove("dev");
  proc_net_create("dev",0,old_get_info);

  unlock_kernel();

  return 0;
}
