/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

#define PACKAGE "sebek-linux"
#define VERSION "2.1.7"
/* #undef BSDI */
/* #undef FREEBSD */
#define LINUX 1
/* #undef OPENBSD */
/* #undef MACOS */
/* #undef SOLARIS */

/* Name of package */
#define PACKAGE "sebek-linux"

/* Version number of package */
#define VERSION "2.1.7"

