//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/sebek_collector/sbk_extract.c,v 1.6 2004/01/08 21:39:38 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include "sbk_extract.h"

pcap_t    *pcap_nic;
uint16_t  dst_port   = 1101;
uint32_t  last_lost  = 0;


uint32_t  pkt_head_sz = sizeof(struct eth_h) + sizeof(struct ip_h) + sizeof(struct udp_h) + sizeof(struct sbk_h); 

int main(int argc, char **argv)
{

  int buffsize   = 65535;	
  int promisc   = 1;
  int timeout   = 1000;
  int use_file  = 0;
	
  char pcap_err[PCAP_ERRBUF_SIZE];
  u_char buffer[255];	
  char pcap_file[255];
  char dev[255];
  char c;	

  


  while ((c = getopt(argc,argv,"hi:p:f:")) != EOF) {
    switch(c){
    case 'i':
      strncpy(dev,optarg,254);
      break;
    case 'p':
      dst_port = atoi(optarg);
      break;
    case 'h':
      help();
      break;
    case 'f':
      use_file = 1;
      strncpy(pcap_file,optarg,254);
      break;
      
    }
  }


  if(!use_file){
    if(!strlen(dev)){
      strncpy(dev,DEFAULT_IF,254);
    }
    //----- pull data off net
    if ((pcap_nic = pcap_open_live(dev, buffsize, promisc, timeout, pcap_err)) == NULL) {
      perror(pcap_err);
      exit(-1);
    }
    fprintf(stderr," monitoring %s: looking for UDP dst port %i\n",dev,dst_port);
  }else{
    //----- pull data from file
    if ((pcap_nic = pcap_open_offline(pcap_file, pcap_err)) == NULL) {
      perror(pcap_err);
      exit(-1);
    }
    fprintf(stderr," opening %s: looking for UDP dst port %i\n",pcap_file,dst_port);
  }
  
  
  while (pcap_loop(pcap_nic, -1, (pcap_handler)handler, buffer));
  
  return 0;
}





void handler (char *usr, const struct pcap_pkthdr *pcapheader, const u_char *pkt) {
	
	struct eth_h   *ethheader;
	struct ip_h    *ipheader;
	struct udp_h   *udpheader;
	struct sbk_h   *sbkheader;
	u_char         *data;
       	

	uint16_t dpt;
	uint32_t datalen;

	struct pcap_stat stats;

	
	//----- ignore packets that are just too short
	if(pcapheader->caplen < pkt_head_sz ){
	
	  return;
	}


	ethheader = (struct eth_h *) pkt;
	
	//----- IP Packet?
	if (ethheader->type == htons(0x0800)) {
	
	  ipheader = (struct ip_h *) (pkt + sizeof(struct eth_h));
         
	  //------ UDP Packet?
	  if (ipheader->proto == 0x11) {
	    
            udpheader = (struct udp_h *) ((u_char *)ipheader + sizeof(struct ip_h));
	   
	    dpt = ntohs(udpheader->dport);

	    //---- Sebek Packet?
	    if(dpt == dst_port){
	      
	      sbkheader =  (struct sbk_h *) ((u_char *)udpheader + sizeof(struct udp_h));	 
	
	      //----- only process version 1 records
	      if(ntohs(sbkheader->ver) == 1){
		
		datalen = ntohl(sbkheader->length); 
		
		data = (u_char *) ((u_char *)sbkheader + sizeof(struct sbk_h));
	     
		//----- check for valid data len
		if(datalen + pkt_head_sz  == pcapheader->caplen){

		  //----- header data seems ok
		  write(fileno(stdout),&(ipheader->src),4);		//----- write the SRC IP
		  write(fileno(stdout),sbkheader,sizeof(struct sbk_h));	//----- write the Sebek Header
		  write(fileno(stdout),data,datalen);			//----- write the Sebek data

		  //------ check libpcap for lost data
		  pcap_stats(pcap_nic,&stats);
		  if(last_lost && stats.ps_drop - last_lost != 0){ 
		    fprintf(stderr,"\nwarning RX %u   Lost %u\n\n",stats.ps_recv,stats.ps_drop);
		  }
		  last_lost = stats.ps_drop;

		  
		}else{
		  fprintf(stderr,"malformed sebek record: data length=%u  packet caplen=%u\n",datalen,pcapheader->caplen);
		}
		
	      }else{
		fprintf(stderr,"Unexpected Sebek version: %u\n",ntohs(sbkheader->ver));
	      }

	    }
	  }		
	}
	return;
}



void help(){

  printf("sbk_extract (%s %s)\n",PACKAGE,VERSION);
  printf("  -i <device> get packets from interface\n");
  printf("  -f <file> get packets from pcap file\n");
  printf("  -p <port> dest port to look for\n");
  printf("  -h  This screen\n");

  exit(0);

}
