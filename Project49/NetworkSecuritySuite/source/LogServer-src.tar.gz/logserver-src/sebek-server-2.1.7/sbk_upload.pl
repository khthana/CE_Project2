#!/usr/bin/perl
#
#--------------------------------------------------------------------
#----- $Header: /home/cvsroot/sebek/server/sebek_collector/sbk_upload.pl,v 1.5 2003/11/17 17:29:52 cvs Exp $
#--------------------------------------------------------------------
#
# Copyright (C) 2001-2003 The Honeynet Project.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. All advertising materials mentioning features or use of this software
#    must display the following acknowledgement:
#      This product includes software developed by The Honeynet Project.
# 4. The name "The Honeynet Project" may not be used to endorse or promote
#    products derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
#


use strict;
use 5.004;
use Getopt::Std;
use Time::gmtime;
use DBI;
use DBD::mysql;
use POSIX;
use FileHandle;
use Socket;



my $dbh;

my $database  = "sebek";
my $dbpasswd    = ""; 
my $dbuid       = "sebek";
my $dbserver    = "localhost";
my $dbport      = "3306";


sub main{ 
  
    my $old_counter = 0;
    my $total;
    my $lost;
    


    my $ip;
    my $magic;
    my $ver;
    my $type;
    my $counter;
    my $time_sec;
    my $time_usec;
    my $pid;
    my $uid;
    my $fd;
    my $com;
    my $len;
    my $data;
    my $return_code;



    eval{
	require DBI;
    };
    if($@){
	print STDERR " $0: needs DBI\n";
	exit 1;
    }

    #------- get user input
    my %opt;

    getopts("u:p:d:s:P:h",\%opt);

    if($opt{u}){
	$dbuid = $opt{u};
    }

    if($opt{p}){
	$dbpasswd = $opt{p};
    }
    
    if($opt{d}){
	$database = $opt{d};
    }

    if($opt{s}){
	$dbserver = $opt{s};
    }
    
    if($opt{P}){
	$dbport = $opt{P};
    }



    if($opt{h}){
	print "$0:(Loads Sebek records into specified mysql database)\n";
	print "\t-u  User ID\n";
	print "\t-p  Passwd\n";
	print "\t-d  Database Name\n";
	print "\t-s  Server Name or IP\n";
	print "\t-P  Port Number\n";
	print "\t-h  Help\n";
	exit;

    }

 
    $dbh = DBI->connect("DBI:mysql:database=$database;host=$dbserver;port=$dbport",$dbuid,$dbpasswd);

    if(!defined($dbh)){
	warn "Unable to get access to database\n";
	exit;
    }
    $dbh->{LongReadLen} = 16384;

    
    #----- only need to create query and prepare it once.
    my $sql  = "INSERT INTO read_data (ip_addr, time, counter, command, filed, pid, uid, length, data)";
    $sql .= "  VALUES ( ? ,? , ? , ? , ? ,  ? , ? , ? , ? ) ;";
    
    my $query = $dbh->prepare($sql);
    
    my $line;

    #---- take records from sebeksniff via STDIN
    while(read(STDIN,$line,52,0) > 0){


	($ip,$magic,$ver,$type,$counter,$time_sec,$time_usec,$pid,$uid,$fd,$com,$len) =
	    unpack("NNnnNNNNNNa12N",$line);

	read(STDIN,$data,$len,0);

	next if($type != 0);
	
	$total++;

	if($counter - $old_counter > 1){
	    $lost = $counter - ($old_counter +1 );
	    warn "   $lost records missing\n";
	}
	$old_counter = $counter;

	$com =~ s/\0//g;

	my $tm = gmtime($time_sec);
	my $datetime = strftime("%Y-%m-%d %H:%M:%S",$tm->sec,$tm->min,$tm->hour,$tm->mday,$tm->mon,$tm->year,$tm->wday,$tm->isdst);




	$query->bind_param( 1,$ip       );
	$query->bind_param( 2,$datetime );
	$query->bind_param( 3,$counter  );
	$query->bind_param( 4,$com      );
	$query->bind_param( 5,$fd       );
	$query->bind_param( 6,$pid      );
	$query->bind_param( 7,$uid      );
	$query->bind_param( 8,$len      );
	$query->bind_param( 9,$data     );

	$return_code = $query->execute;

        if(!$return_code){
	    sleep 2;
	    warn ("reconnecting to the datbase\n");
	    $dbh = DBI->connect("DBI:mysql:database=$database;host=$dbserver;port=$dbport",$dbuid,$dbpasswd);
	    $query = $dbh->prepare($sql);
	}

    }


}


main();
