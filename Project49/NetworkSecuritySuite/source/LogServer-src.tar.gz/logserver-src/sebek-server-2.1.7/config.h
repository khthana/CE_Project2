/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

#define PACKAGE "sebek-server"
#define VERSION "2.1.7"
/* #undef BSDI */
/* #undef FREEBSD */
#define LINUX 1
/* #undef OPENBSD */
/* #undef MACOS */
/* #undef SOLARIS */

/* Define if you have the pcap library (-lpcap).  */
#define HAVE_LIBPCAP 1

/* Name of package */
#define PACKAGE "sebek-server"

/* Version number of package */
#define VERSION "2.1.7"

