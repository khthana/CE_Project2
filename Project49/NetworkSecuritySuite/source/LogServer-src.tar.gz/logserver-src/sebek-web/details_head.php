<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/details_head.php,v 1.1 2003/07/26 17:51:16 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>
<HTML>
<HEAD>
  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
  
</HEAD>

<BODY>

<?php

include("sebek_utils.inc");

$ip_txt = $HTTP_GET_VARS["ip"];
$ip  = ip2long($HTTP_GET_VARS["ip"]);
$pid = $HTTP_GET_VARS["pid"]; 

if(!$ip_txt ||! $pid){
  exit;
}



//------ connect to the database
$hd = db_con();


//----- form the query
$query  = "select time, length, data, uid, command , filed ";
$query .= " from read_data where ip_addr = %u  and pid = %u order by filed, counter ;";

$query = sprintf($query,$ip,$pid);

//----- execute the query
$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$comlist = array();
$uidlist = array();
//----- load results into internal structure
while($line = mysql_fetch_array($result)){

  $len    = $line["length"];
  $uid    = $line["uid"];
  $com    = $line["command"];
  $time   = $line["time"];
  $fd     = $line["filed"];
  $dat    = $line["data"];

  $comlist[$com] = 1;
  $uidlist[$uid] = 1;
  
  if(!$data[$fd][$com][$uid]["start"]){
    $data[$fd][$com][$uid]["start"] = $time;
  }

  $data[$fd][$com][$uid]["end"] = $time;
  $data[$fd][$com][$uid]["contents"] .= $dat;
  $data[$fd][$com][$uid]["length"] += $len;
 
}	    


print_head("Details",1);

print "<table border=0 cellspacing=0 cellpadding=0>\n";
print "<tr>\n";

print "<td colspan=2 class=\"title\">\n";

$c  = "class=\"head2\"";
$c2 = "class=\"sum2\"";

print "<table border=0 cellspacing=0 cellpadding=0>\n";
print "<tr>\n";
print "<td width=\"65\" $c>IP:</td><td width=\"200\" $c2 >$ip_txt</td>\n";

foreach(array_keys($comlist) as $line){
  $com_txt .= " $line";
}

foreach(array_keys($uidlist)as $line){
  $uid_txt .= " $line";
}


print "<td width=\"65\" $c >Command:</td><td width=\"200\" $c2 >$com_txt</td>\n";
print "</tr>\n";
print "<tr>\n";
print "<td width=\"65\" $c >PID:</td><td width=\"200\" $c2>$pid</td>\n";
print "<td width=\"65\" $c >UID:</td><td width=\"200\" $c2>$uid_txt</td>\n";
print "</tr>\n";
print "</table>\n";


print "</td>\n";
print "</tr>\n<tr>\n<td>\n";


print "<table border=0 cellspacing=0 cellpadding=0>\n";
$x = 0;

$c = "class=\"head3\"";

print "<tr><td colspan=3 $c>View as:</td><td colspan=6  $c>sys_read Data Context</td></tr>\n";

$c = "class=\"head4\"";

print "<tr>";
print "<td $c>SCP File Transfer</td>";
print "<td $c>Text / Keystrokes</td>";
print "<td $c>Raw Data</td>";
print "<td $c>UID</td>";
print "<td $c>File Desc</td>";
print "<td $c>Command</td>";
print "<td $c>Start</td>";
print "<td $c>End</td>";
print "<td $c>Total Bytes</td></tr>\n";

if(is_array($data)){
  foreach(array_keys($data) as $fd){
    foreach(array_keys($data[$fd]) as $com){
      foreach(array_keys($data[$fd][$com]) as $uid){
	
	if($x++ % 2 == 0){
	  $odd = "even";
	}else{
	  $odd = "odd";
	}
      
	$start = $data[$fd][$com][$uid]["start"];
	$end   = $data[$fd][$com][$uid]["end"];
	$cont  = $data[$fd][$com][$uid]["contents"];
	$len   = $data[$fd][$com][$uid]["length"];
	$dat   = substr($data[$fd][$com][$uid]["contents"],0,80);

	if(ereg("^C[0-9]{4} [0-9]+ .+\n",$dat)){
	  $is_scp = 1;
	}else{
	  $is_scp = 0;
	}
	
	$query = "?ip=$ip_txt&pid=$pid&fd=$fd&com=$com&uid=$uid";
	
	print "<tr class=\"$odd\">";
	if($is_scp){
	  print "<td class=\"d1\"><a href=\"details_body.php$query&decode=scp\" target=\"body\">";
	  print "<img src=\"button.gif\" border=0></a></td>";
	}else{
	  print "<td class=\"d1\"></td>";
	}
	print "<td class=\"d1\"><a href=\"details_body.php$query&decode=ks\" target=\"body\">";
	print "<img src=\"button.gif\" border=0></a></td>";
	print "<td class=\"d1\"><a href=\"binary_download.php$query\" target=\"body\">";
	print "<img src=\"button.gif\" border=0></a></td>";
	print "<td class=\"d2\">$uid</td><td class=\"d1\">$fd</td><td class=\"d1\">$com</td>";
	print "<td class=\"d1\">$start</td><td class=\"d1\">$end</td><td class=\"d1\">$len bytes read</td></tr>\n";
    }

    }
    
  }
}
print "</table>\n";



print "</td>\n";

print "</tr>\n";

print "</table>\n";

?>

</BODY>

</HTML>