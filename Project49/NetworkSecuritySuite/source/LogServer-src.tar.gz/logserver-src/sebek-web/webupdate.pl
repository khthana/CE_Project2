#!/usr/bin/perl

#--------sebek web interface updater
#
# By Camilo H. viecco  <cviecco@indiana.edu>
#    Feb 17, 2004
#
#TODO: add error detection on sql statements.....
#---------------



#--- this is the main routine.. here just for convenience
sub main(){
#----------define globals
  use strict;
  use DBI();

  my $user    = "sebek";
  my $passwd  = "honeypot";
  my $query;

  my $dbh=DBI->connect("DBI:mysql:database=sebek",$user,$passwd);

#-------------------grab the inner limit and ip addresses
    $query  =" CREATE TEMPORARY TABLE eraseme2  ";
    $query .=" SELECT  ip_addr, min(time) AS time_min, max(time) AS time_max from read_data GROUP by ip_addr";
   my $sth1=$dbh->prepare($query);
   #print("$query \n");   
   $sth1->execute;


#-------------- Add new hosts to view_data_status
   $query =" CREATE TEMPORARY TABLE ip_selector SELECT * from eraseme2";
   $sth1=$dbh->prepare($query);
   $sth1->execute;  

   $query ="DELETE FROM ip_selector USING ip_selector, view_data_status WHERE ip_selector.ip_addr=view_data_status.ip_addr ";
   $sth1=$dbh->prepare($query);
   $sth1->execute;  

   $query ="INSERT INTO view_data_status(ip_addr, last_table_view_update)   SELECT ip_addr, time_min from ip_selector";
   $sth1=$dbh->prepare($query);
   $sth1->execute;  

   $sth1=$dbh->prepare(" DROP TABLE ip_selector");
   $sth1->execute;
    
#---------------------now update the table_view_data
   $query  =" CREATE TEMPORARY TABLE eraseme ";
   $query .= " SELECT read_data.ip_addr AS ip_addr, MIN(read_data.time) AS time_min, MAX(read_data.time) AS time_max,read_data.command AS command, read_data.pid AS pid,read_data.uid AS uid ";
   $query .= " FROM read_data,view_data_status,eraseme2  WHERE read_data.ip_addr=view_data_status.ip_addr AND read_data.time>=view_data_status.last_table_view_update AND read_data.ip_addr=eraseme2.ip_addr AND read_data.time<=eraseme2.time_max ";
   $query .= " GROUP BY ip_addr, pid, command, uid order by ip_addr, pid";
   $sth1=$dbh->prepare($query);  
   #print("$query \n");   
   $sth1->execute;

   $sth1=$dbh->prepare("UPDATE table_view_data, eraseme SET table_view_data.time_max = eraseme.time_max WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr");
   $sth1->execute;

   $sth1=$dbh->prepare( "DELETE FROM eraseme USING table_view_data, eraseme WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr");
   $sth1->execute;

   $sth1=$dbh->prepare("INSERT INTO table_view_data (ip_addr, time_min, time_max, command, pid, uid) SELECT * from eraseme");
   $sth1->execute;

   $sth1=$dbh->prepare(" DROP TABLE eraseme");
   $sth1->execute;

   #$sth1->finish;

#--update the view_data status
   $query ="UPDATE view_data_status,eraseme2 SET view_data_status.last_table_view_update=eraseme2.time_max WHERE view_data_status.ip_addr=eraseme2.ip_addr";
   $sth1=$dbh->prepare($query);
   $sth1->execute;  


$dbh->disconnect();
}

#---------just call the main routine
main();
