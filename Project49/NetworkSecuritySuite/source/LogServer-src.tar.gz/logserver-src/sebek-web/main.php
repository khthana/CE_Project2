<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/main.php,v 1.3 2004/03/29 19:22:35 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>
<HTML>
<HEAD>
  <META HTTP-EQUIV="REFRESH" CONTENT="60">

  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
  
</HEAD>

<BODY>

<?php

include("sebek_utils.inc");

print_head("System Overview",1);

//------ connect to the database
$hd = db_con();

//----- figure out when last update occured for each host
//#$query  = "select ip_addr, MAX(time), count(time) ";
//#$query .= " from read_data group by ip_addr ;";
$query  = "select ip_addr, last_update, counter ";
$query .= " from resume group by ip_addr ;"; 

$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$c = "class=\"head1\"";

print "<p><p>\n";
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">Monitored Hosts</td></tr>\n";
print "<tr ><td $c>Browse</td><td $c>Keystrokes</td><td $c>Host</td>";
print "<td $c>Last Update</td><td $c>Total Records</td></tr>\n";
$counter = 0;
while($line = mysql_fetch_array($result)){
  if($counter++ % 2 ==0){
    $odd = "even";
  }else{
    $odd = "odd";
  }
  $ip   = long2ip($line["ip_addr"]);
  $time = $line["last_update"];
  $recs = $line["counter"];

  print "<tr class=\"$odd\"><td class=\"nav\"><a href=\"table_view.php?ip=$ip\"><img src=\"button.gif\" border=0></a></td>";
  print "<td class=\"nav\"><a href=\"ks_act.php?ip=$ip\"><img src=\"button.gif\" border=0></a></td>";
  print "<td>$ip</td><td>$time</td><td>$recs</td></tr>\n";
}	    
print "</table>\n";




?>




  </TABLE>

</BODY>

</HTML>
