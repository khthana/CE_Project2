<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/binary_download.php,v 1.3 2003/09/03 18:29:00 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


include("sebek_utils.inc");

$ip_txt =   $HTTP_GET_VARS["ip"];
$ip     =   ip2long($HTTP_GET_VARS["ip"]);
$pid    =   $HTTP_GET_VARS["pid"];
$fd     =   $HTTP_GET_VARS["fd"];

$fname = sprintf("sebek.%s.%u.%u.dat",$ip_txt,$pid,$fd);

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=$fname");


//------ connect to the database
$hd = db_con();


//----- form the query
$query  = "select length, data, time ";
$query .= " from read_data where pid=%u and ip_addr=%u and filed=%u order by filed, counter ;";
  
$query = sprintf($query,$pid,$ip,$fd);
  
  

//----- execute the query
$result = mysql_query($query) or die("Query Failure: ".mysql_error());


//----- load results into internal structure
while($line = mysql_fetch_array($result)){
  $time     = $line["time"];
  $data     = $line["data"];
  $len      = $line["length"];
  
  print "$data";
  
}	    



?>