<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/scp_download.php,v 1.3 2004/03/29 19:22:35 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>
<?php



include("sebek_utils.inc");

$ip     =   $HTTP_GET_VARS["ip"];
$pid    =   $HTTP_GET_VARS["pid"];
$fd     =   $HTTP_GET_VARS["fd"];
$fname  =   $HTTP_GET_VARS["fname"];
$size  =   $HTTP_GET_VARS["size"];


//------ connect to the database
$hd = db_con();


//----- form the query
$query  = "select data  ";
$query .= " from read_data where ip_addr=%u and  pid=%u  and filed=%u and length > 1  ";
$query .= " order by counter ;";

$query = sprintf($query,$ip,$pid,$fd);

//print "$query\n";
 
//----- execute the query
$result = mysql_query($query) or die("Query Failure: ".mysql_error());


//----- load results into internal structure
while($line = mysql_fetch_array($result)){
  $data     .= $line["data"];
}	


$descriptors = array(
	0 => array("pipe","r"),
	1 => array("pipe","w"),
	2 => array("file","/tmp/error.txt","a")
);

$proc = proc_open("file -i - | sed -e 's/.*: *//'",$descriptors,$pipes);

if(is_resource($proc)){
  fwrite($pipes[0],$data);
  fclose($pipes[0]);

  $mimetype = fgets($pipes[1],1024);
  fclose($pipes[1]);

  proc_close($proc);

}else{
  $mimetype = "application/octetstream";
}



header("Content-type: $mimetype");
header("Content-Disposition: attachment; filename=$fname");
header('Content-Length: ' . $size);
    
print "$data";

?>
