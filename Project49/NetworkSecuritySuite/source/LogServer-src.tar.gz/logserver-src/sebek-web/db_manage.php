<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/db_manage.php,v 1.2 2004/03/31 16:10:23 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>

<?php
function db_synch(){
   $query = "CREATE TEMPORARY TABLE eraseme  SELECT ip_addr,MAX(time) AS last_update ,count(time) AS counter FROM read_data GROUP BY ip_addr ORDER BY ip_addr";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "UPDATE resume, eraseme SET resume.last_update = eraseme.last_update, resume.counter=eraseme.counter  WHERE resume.ip_addr=eraseme.ip_addr"; 
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "DELETE FROM eraseme USING resume, eraseme WHERE resume.ip_addr=eraseme.ip_addr";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query ="INSERT INTO resume (ip_addr, last_update, counter) SELECT * from eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query =" DROP TABLE eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
}

?>




<?php
function table_cleanup(){


 $ip_addr=$_POST['ip_addr'];
 $del_range=$_POST['del_range'];
 $del_range=$_POST['range'];

 $count = count($ip_addr);
 

 $time;
 $ip_limiter;
 switch ($del_range){

  case 'keep4hr':
    $time="DATE_SUB(NOW(), INTERVAL 4 HOUR)";
    break;

  case "keep24hr":
    $time="DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    break;

  case "keep72hr":
    $time="DATE_SUB(NOW(), INTERVAL 72 HOUR)";
    break;
  case "keepweek":
        $time="DATE_SUB(NOW(), INTERVAL 7 DAY)";
    break;
  case "keepmonth":
        $time="DATE_SUB(NOW(), INTERVAL 1 MONTH)";
    break;
  case "keepnothing":
        $time="NOW()";
    break;

  default:
    //do nothing
    break;
   }

 $ip_limiter;
 if ($count>0)
   {
   $x =0;
   foreach($ip_addr as $val){
     if(++$x < $count){
       $ip_limiter .= "ip_addr=".$val." OR ";
      }else{
       $ip_limiter .= " ip_addr=".$val;
         }
      }
    }


 if ($count>0)
   {
   $query="DELETE from read_data where ($ip_limiter) AND insert_time< $time";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
   //print "<p></p> $query";

   $query="DELETE from table_view_data where ($ip_limiter) AND time_max< $time";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query="DELETE from resume where ($ip_limiter) AND last_update< $time";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
   db_synch();
   }
 

 

}

?>



<HTML>
<HEAD>
  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
</HEAD>

<BODY>

<?php

include("sebek_utils.inc");


$ip    = $HTTP_GET_VARS["ip"];
$uid   = $HTTP_GET_VARS["uid"];
$pid   = $HTTP_GET_VARS["pid"];
$fd    = $HTTP_GET_VARS["fd"];
$com   = $HTTP_GET_VARS["com"];
$mgtcom=$_POST['mgtcom'];


$dhead = $HTTP_GET_VARS["drop_head"];

$title = "Database Management";

if(strlen($ip)){
  $title .= "  IP $ip";
  $ip = ip2long($ip);
  
  if(!$restrict){
    $restrict =  sprintf("where ip_addr = %u",$ip);
  }else{
    $restrict .= sprintf(" and ip_addr = %u",$ip);
  }
}

if(strlen($uid)){
  $title .= "  UID $uid";

  if(!$restrict){
    $restrict =  sprintf("where uid = %u",$uid);
  }else{
    $restrict .= sprintf(" and uid = %u",$uid);
  }
}

if(strlen($pid)){
  $title .= "  PID $pid";

  if(!$restrict){
    $restrict =  sprintf("where pid = %u",$pid);
  }else{
    $restrict .= sprintf(" and pid = %u",$pid);
  }
}

if(strlen($com)){
  $title .= "  Com $com";

   if(!$restrict){
    $restrict =  sprintf("where command = '%s'",$com);
  }else{
    $restrict .= sprintf(" and command = '%s'",$com);
  }
}


if(strlen($dhead)){
  print_head($title,0);
}else{
  print_head($title,1);
}

//------ get the raw data
$hd = db_con();

//manage db... if needed..
if(strlen($mgtcom)){
  //print "mgtcom found!! equals: $mgtcom";
  if ($mgtcom=="sync_db"){
      db_synch();
      } 
  else{
      table_cleanup($in_ip_addr,$del_range);
      }
}

?>


 <form action="" method=post>
 <input type="hidden" name="mgtcom" value="table_cleanup">

<?php

//----------------------deletion




$query  = "select ip_addr, last_update, counter ";
$query .= " from resume group by ip_addr ;"; 

$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$c = "class=\"head1\"";

print "<p><p>\n";
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">Table cleanup</td></tr>\n";
print "<tr ><td $c>Host</td>";
print "<td $c>Last Update</td><td $c>Total Records</td><td $c></td></tr>\n";
$counter = 0;
while($line = mysql_fetch_array($result)){
  if($counter++ % 2 ==0){
    $odd = "even";
  }else{
    $odd = "odd";
  }
  $ip   = long2ip($line["ip_addr"]);
  $ipnum = $line["ip_addr"];
  $time = $line["last_update"];
  $recs = $line["counter"];
  print "<tr class=\"$odd\"><td>$ip</td><td>$time</td><td>$recs</td>";
  print "<td><input type=\"checkbox\" name=\"ip_addr[]\" value=\"$ipnum\" ></td>";
  print "</tr>\n";
}	    
print "<tr><td $c>Data range to delete on selected hosts";
print " <select name=\"range\">";
print " <option value=\"keep4hr\">All but last  4 hours</option>";
print " <option value=\"keep24hr\">All but last 24 hours</option>";
print " <option value=\"keep72hr\">All but last 72 hours</option>";
print " <option value=\"keepweek\">All but last week </option>";
print " <option value=\"keepmonth\">All but last month</option>";
print " <option value=\"keepnothing\">All (Delete everything)</option></select>";
print "<td $c><input type=\"submit\" value=\"Delete\" name=\"del_range\"> </td>";
//print "</form>";
print " </tr>\n";
print "</table>\n";
?>
</form>

<p></p>

<form action="" method=post>
<input type="hidden" name="mgtcom" value="sync_db">
<?php
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">Sync Tables</td></tr>\n";
print "<tr><td $c>Press button to sync the database";
print "<td $c><input type=\"submit\" value=\"Sync_db\" name=\"sync_db\"> </td>";
print " </tr>\n";
print "</table>\n";
?>
</input>
</form>



<?php

//----------------------------------------- Now print the statistics...

print "<table>\n";
  print "<tr>\n";
  print "<td border=0 class=\"title2\" colspan=\"3\">Database Statistics</td>\n";
  print "</tr>\n";
print "</table>\n";



//-----------read_data
$query  = "select ip_addr,MIN(time), MAX(time), count(time) ";
$query .= " from read_data group by ip_addr ;";

$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$c = "class=\"head1\"";

print "<p><p>\n";
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">Read_data Status</td></tr>\n";
print "<tr ><td $c>Host</td>";
print "<td $c>First Update</td><td $c>Last Update</td><td $c>Total Records</td></tr>\n";
$counter = 0;
while($line = mysql_fetch_array($result)){
  if($counter++ % 2 ==0){
    $odd = "even";
  }else{
    $odd = "odd";
  }
  $ip   = long2ip($line["ip_addr"]);
  $start = $line["MIN(time)"];
  $end = $line["MAX(time)"];
  $recs = $line["count(time)"];

  print "<tr class=\"$odd\"><td>$ip</td><td>$start</td><td>$end</td><td>$recs</td></tr>\n";
}	    
print "</table>\n";


//--------resume
$query  = "select ip_addr, last_update, counter ";
$query .= " from resume group by ip_addr ;"; 

$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$c = "class=\"head1\"";

print "<p><p>\n";
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">Resume Table data</td></tr>\n";
print "<tr ><td $c>Host</td>";
print "<td $c>Last Update</td><td $c>Total Records</td></tr>\n";
$counter = 0;
while($line = mysql_fetch_array($result)){
  if($counter++ % 2 ==0){
    $odd = "even";
  }else{
    $odd = "odd";
  }
  $ip   = long2ip($line["ip_addr"]);
  $time = $line["last_update"];
  $recs = $line["counter"];
  print "<tr class=\"$odd\"><td>$ip</td><td>$time</td><td>$recs</td></tr>\n";
}	    
print "</table>\n";

//------------view_data status
$query  = "select ip_addr, last_table_view_update, last_ks_act_update";
$query .= " from view_data_status group by ip_addr ;"; 

$result = mysql_query($query) or die("Query Failure: ".mysql_error());

$c = "class=\"head1\"";

print "<p><p>\n";
print "<table border=0 cellspacing=0 cellpadding=0 class=\"summary\">\n";
print "<tr ><td class=\"title2\" colspan=\"5\">view table status</td></tr>\n";
print "<tr ><td $c>Host</td>";
print "<td $c>Last update table_view</td><td $c>Last update ks_view</td></tr>\n";
$counter = 0;
while($line = mysql_fetch_array($result)){
  if($counter++ % 2 ==0){
    $odd = "even";
  }else{
    $odd = "odd";
  }
  $ip   = long2ip($line["ip_addr"]);
  $last_tb = $line["last_table_view_update"];
  $rlast_kb = $line["last_ks_act_update"];

  print "<tr class=\"$odd\"><td>$ip</td><td>$last_tb</td><td>$last_kb</td></tr>\n";
}	    
print "</table>\n";

?>


</BODY>

</HTML>
