<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/ks_act.php,v 1.4 2004/03/29 19:22:35 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>

<HTML>
<HEAD>
  <META HTTP-EQUIV="REFRESH" CONTENT="60">

  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
  
</HEAD>

<BODY>


<?php

include("sebek_utils.inc");

print_head($title,1);

//------ connect to the database
$hd  = db_con();

$ip = $HTTP_GET_VARS["ip"];

$title = "Keystroke Summary View ";
if($ip){
  $title .= "for IP: $ip";
  $ip = ip2long($ip);
  $restrict = sprintf("and ip_addr = %u",$ip);
}

//----- form the query
$query  = "select ip_addr, command, pid, uid, time, filed, uid, length, data ";
$query .= " from read_data where length < 3 $restrict order by pid DESC, time ;";
//$query .= " from read_data where length < 3 $restrict order by time ;";



//----- execute the query
$result = mysql_query($query) or die("Query Failure: ".mysql_error());



//----- load results into internal structure
while($line = mysql_fetch_array($result)){
  $ip   = long2ip($line["ip_addr"]);
  $pid  = $line["pid"];
  $uid  = $line["uid"];
  $com  = $line["command"];
  $time = $line["time"];
  $fd   = $line["filed"];
  $uid  = $line["uid"];
  $txt  = $line["data"];

  if(!is_array($data[$ip][$pid][$uid][$com][$fd][$time])){
    $data[$ip][$pid][$uid][$com][$fd][$time] = array();
  }

  array_push($data[$ip][$pid][$uid][$com][$fd][$time],$txt) ;
}	    


$query2  = "select ip_addr, pid, uid, command, filed, MAX(time) from read_data ";
$query2 .= "where length < 3 $restrict group by ip_addr, pid, uid, command, filed order by 6 DESC;";

//print "$query2\n";

//----- execute the query
$result = mysql_query($query2) or die("Query Failure: ".mysql_error());


?>


  <TABLE border=0 cellspacing=0 cellpadding=0 class="main" >
    <TR>
      <TD class="head1" >Details</TD>
      <TD class="head1" >IP</TD>
      <TD class="head1" >PID</TD>
      <TD class="head1" >UID</TD>
      <TD class="head1" >COMMAND</TD>
      <TD class="head1" >FD</TD>
      <TD class="head1" >DATA</TD>
    </TR>


<?PHP

$counter = 0;

$old_ip  = 0;
$old_pid = 0;

//----- get list of sorted by last activity
while($line = mysql_fetch_array($result)){
  $ip   = long2ip($line["ip_addr"]);
  $pid  = $line["pid"];
  $uid  = $line["uid"];
  $com  = $line["command"];
  $time = $line["MAX(time)"];
  $fd   = $line["filed"];
  $uid  = $line["uid"];



  $log = keystroke_data_merge($data[$ip][$pid][$uid][$com][$fd]);

  if($old_ip != $ip || $old_pid != $pid){
    if($counter++ % 2 == 0){
      $odd = "even";
    }else{
      $odd = "odd";
    }
    
    $old_ip  = $ip;
    $old_pid = $pid;

    print_keystroke_log(1,$odd,$ip,$uid,$pid,$com,$fd,$log,5);
  }else{
    print_keystroke_log(0,$odd,$ip,$uid,$pid,$com,$fd,$log,5);
  }
  
    

}

?>

  </TABLE>

</BODY>

</HTML>
