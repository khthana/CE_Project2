<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/search_head.php,v 1.1 2003/07/26 17:51:16 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
?>
<HTML>
<HEAD>
  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
  
</HEAD>

<BODY>

<?php

include("sebek_utils.inc");

print_head("Search",1);

?>
<form action="table_view.php" method="get" target="body">
<table border=0 cellspacing=0 cellpadding=0 >
  <tr> 
    <td class="head2" >IP address</td><td class="sum2"><input type="text" name="ip" length=15></td>
    <td class="head2">PID</td><td class="sum2"><input type="text" name="pid" length=15></td>
  </tr>
  <tr>
    <td class="head2">UID</td><td class="sum2"><input type="text" name="uid" length=15></td>
    <td class="head2">Command</td><td class="sum2"><input type="text" name="com" length=15></td>
  </tr>
  
  <tr>
    <td class="head1"  colspan="4">
      <input  type="submit" value="Fire it up gene!">
    </td>
  </tr>
</table>
  <input type="hidden" name="drop_head" value=1>
</form>



</BODY>

</HTML>