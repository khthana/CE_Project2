<?php
//--------------------------------------------------------------------
//----- $Header: /home/cvsroot/sebek/server/html/table_view.php,v 1.3 2004/03/29 19:22:35 cvs Exp $
//--------------------------------------------------------------------
/*
 * Copyright (C) 2001 - 2003 The Honeynet Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by The Honeynet Project.
 * 4. The name "The Honeynet Project" may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* table_view cache usage and bugs added by Camilo Viecco <cviecco@indiana.edu>  Feb 17,2004*/

?>
<HTML>
<HEAD>
  <LINK rel="stylesheet" type="text/css" href="sebek_style.css">
</HEAD>

<BODY>

<?php

include("sebek_utils.inc");


$ip    = $HTTP_GET_VARS["ip"];
$uid   = $HTTP_GET_VARS["uid"];
$pid   = $HTTP_GET_VARS["pid"];
$fd    = $HTTP_GET_VARS["fd"];
$com   = $HTTP_GET_VARS["com"];
$page  = $HTTP_GET_VARS["page"];



$dhead = $HTTP_GET_VARS["drop_head"];

$title = "Summary View: ";

$reloader="";

if(strlen($ip)){
  $title .= "  IP $ip"; 
  $reloader .="ip=$ip";

  $ip = ip2long($ip);
    

  if(!$restrict){
    $restrict =  sprintf("where ip_addr = %u",$ip);
  }else{
    $restrict .= sprintf(" and ip_addr = %u",$ip);
  }
}

if(strlen($uid)){
  $title .= "  UID $uid";
  $reloader .="&uid=$uid";

  if(!$restrict){
    $restrict =  sprintf("where uid = %u",$uid);
  }else{
    $restrict .= sprintf(" and uid = %u",$uid);
  }
}

if(strlen($pid)){
  $title .= "  PID $pid";
  $reloader .="&pid=$pid";

  if(!$restrict){
    $restrict =  sprintf("where pid = %u",$pid);
  }else{
    $restrict .= sprintf(" and pid = %u",$pid);
  }
}

if(strlen($com)){
  $title .= "  Com $com";
  $reloader .="&com=$com";

   if(!$restrict){
    $restrict =  sprintf("where command = '%s'",$com);
  }else{
    $restrict .= sprintf(" and command = '%s'",$com);
  }
}





//------ get the raw data
$hd = db_con();

//---------------------------------NEW UPDATE SECTION
if(!strlen($ip)){
// with no ip given it updates for all ip... 
//---------create the secondary tables..
    $query  =" CREATE TEMPORARY TABLE eraseme2  ";
    $query .=" SELECT  ip_addr, min(time) AS time_min, max(time) AS time_max from read_data GROUP by ip_addr";
    //print "<p>query = $query  </p>";
    $result = mysql_query($query) or die("Query Failure: ".mysql_error());

//-------------- Add new hosts to view_data_status 

     $query =" CREATE TEMPORARY TABLE ip_selector SELECT * from eraseme2";
     $result = mysql_query($query) or die("Query Failure: ".mysql_error());

     $query ="DELETE FROM ip_selector USING ip_selector, view_data_status WHERE ip_selector.ip_addr=view_data_status.ip_addr ";
     $result = mysql_query($query) or die("Query Failure: ".mysql_error());

     $query ="INSERT INTO view_data_status(ip_addr, last_table_view_update)   SELECT ip_addr, time_min from ip_selector";
     $result = mysql_query($query) or die("Query Failure: ".mysql_error());
    

     $query =" DROP TABLE ip_selector";
     $result = mysql_query($query) or die("Query Failure: ".mysql_error());

//---------------

   $query  =" CREATE TEMPORARY TABLE eraseme ";
   $query .= " SELECT read_data.ip_addr AS ip_addr, MIN(read_data.time) AS time_min, MAX(read_data.time) AS time_max,read_data.command AS command, read_data.pid AS pid,read_data.uid AS uid ";
   $query .= " FROM read_data,view_data_status,eraseme2  WHERE read_data.ip_addr=view_data_status.ip_addr AND read_data.time>=view_data_status.last_table_view_update AND read_data.ip_addr=eraseme2.ip_addr AND read_data.time<=eraseme2.time_max ";
   $query .= " GROUP BY ip_addr, pid, command, uid order by ip_addr, pid";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "UPDATE table_view_data, eraseme SET table_view_data.time_max = eraseme.time_max WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr"; 
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "DELETE FROM eraseme USING table_view_data, eraseme WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query ="INSERT INTO table_view_data (ip_addr, time_min, time_max, command, pid, uid) SELECT * from eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query =" DROP TABLE eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   //---finally update the status table...

   $query = sprintf (" UPDATE view_data_status SET last_table_view_update='%s' where ip_addr=%u",$max_time,$ip_min);
   $query ="UPDATE view_data_status,eraseme2 SET view_data_status.last_table_view_update=eraseme2.time_max WHERE view_data_status.ip_addr=eraseme2.ip_addr";
   // print "query = $query";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query =" DROP TABLE eraseme2";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
}//en if !strlen ip... big

else
{
   //-------- get last update....on read _data
   $query = sprintf("select MAX(time) from read_data where ip_addr=%u",$ip);
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
   $line = mysql_fetch_array($result);
   $max_time   = $line["MAX(time)"];


   //-----get last update on cache data.....
   $query = sprintf("select ip_addr,last_table_view_update from view_data_status where ip_addr=%u" ,$ip);
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());  
   $line = mysql_fetch_array($result);
   if ($line)
	{
 	$ip_min    = $line["ip_addr"];
	$min_time=$line["last_table_view_update"];
	$ip_min=$ip;
	}
   	else
	{
	$ip_min=$ip;
	$min_time='2003-12-01';
   	$query = sprintf("INSERT INTO view_data_status (ip_addr,last_table_view_update ) VALUES (%u, '%s')", $ip,$min_time);
	$result = mysql_query($query) or die("Query Failure: ".mysql_error()); 
	}

    $restrict_new =  sprintf("WHERE time<= '%s' AND time>='%s'  AND ip_addr=%u",$max_time,$min_time,$ip);



   $query = "CREATE TEMPORARY TABLE eraseme  SELECT ip_addr,MIN(time) AS time_min, MAX(time) AS time_max,command, pid,uid FROM read_data $restrict_new GROUP BY ip_addr, pid, command, uid order by pid";
   //print "query = $query";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "UPDATE table_view_data, eraseme SET table_view_data.time_max = eraseme.time_max WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr"; 
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query = "DELETE FROM eraseme USING table_view_data, eraseme WHERE table_view_data.pid=eraseme.pid AND table_view_data.uid=eraseme.uid AND table_view_data.command=eraseme.command AND table_view_data.ip_addr=eraseme.ip_addr";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query ="INSERT INTO table_view_data (ip_addr, time_min, time_max, command, pid, uid) SELECT * from eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   $query =" DROP TABLE eraseme";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());

   //---finally update the status table...

   $query = sprintf (" UPDATE view_data_status SET last_table_view_update='%s' where ip_addr=%u",$max_time,$ip_min);
   // print "query = $query";
   $result = mysql_query($query) or die("Query Failure: ".mysql_error());
}


//----now with the data in place is time to print the header and select the tile according to the page number...

$page_size=100;
$num_pages=0;
$low_view=0;
$high_view=-1;

//print "page=$page";
//set page number equal to one if none is found..
if(!strlen($page)){
  $page="1";
}
//print "page = $page";
$next_page=$page;
$previous_page=$page;


//query the database to see the size of the table to extract
$query = "select ip_addr  from table_view_data $restrict group by ip_addr, pid, command, uid ";

$result = mysql_query($query) or die("Query Failure: ".mysql_error());




//-------------process the result

    $total_elements  = mysql_affected_rows();
    $num_pages=ceil($total_elements/$page_size);
    $high_view=($page*$page_size);
    $low_view=max(0,($page-1)*$page_size);
    $previous_page=max(1,$page-1);
    $next_page=min($num_pages,$page+1);
    $next_page=sprintf("%s&page=%s",$reloader,$next_page);
    $previous_page=sprintf("%s&page=%s",$reloader,$previous_page);
    $append= "\t Page  $page of $num_pages";
    $append .=" \t<a href=\"table_view.php?".$reloader."&page=1\"> first </a>";
    $append .=" \t<a href=\"table_view.php?".$previous_page."\"> prev </a>";
    $append .= "<a href=\"table_view.php?".$next_page."\"> next </a>" ;
    $append .= "<a href=\"table_view.php?".$reloader."&page=".$num_pages."\"> last </a>" ;
      $title .= " $append ";






if(strlen($dhead)){
  print_head($title,0);
}else{
  print_head($title,1);
}



//---------now the query to see tha actual data in the table...
$query = "select ip_addr,uid,command, pid, time_min, time_max  from table_view_data $restrict group by ip_addr, pid, command, uid ";
if ($high_view!=-1){
  $query .= "order by time_min DESC, time_max DESC LIMIT $low_view , $page_size ";
}
else{
  print "oops.. not high values";
  $query .= "order by time_min DESC";
}

$result = mysql_query($query) or die("Query Failure: ".mysql_error());


?>

  <TABLE border=0 cellspacing=0 cellpadding=0 class="main">

    <TR class="odd">
      <TD class="head1">Details</TD>
      <TD class="head1">IP Address</TD>
      <TD class="head1">PID</TD>
      <TD class="head1">UID</TD>
      <TD class="head1">COMMAND</TD>
      <TD class="head1">START</TD>
      <TD class="head1">END</TD>
    </TR>
<?php


$old_pid = 0;
$old_ip = 0;


$counter = 0;
while($line = mysql_fetch_array($result)){
  $ip    = long2ip($line["ip_addr"]);
  $uid   = $line["uid"];
  $pid   = $line["pid"];
  $com   = $line["command"];
  $start = $line["time_min"];
  $end   = $line["time_max"];
  

  $query = "?ip=$ip&pid=$pid&fd=$fd";
  
  
  if($old_ip != $ip || $old_pid != $pid){
	  
    if($counter++ % 2 == 0){
      $odd = "even";
    }else{
      $odd = "odd";
    }
	 
    $c = "class=\"d1\"";

    print "\t<TR class=\"$odd\">\n";
    print "\t\t<TD $c><a href=\"details.php$query\" target=\"_top\"><img src=\"button.gif\" border=0></a></TD>";
    print "<TD $c>$ip</TD><TD $c>$pid</TD><TD $c>$uid</TD><TD $c>$com</TD><TD $c>$start</TD><TD $c>$end</TD>\n";
    print "\t</TR>\n";
  }else{
    print "\t<TR class=\"$odd\">\n";
    print "<TD $c></TD><TD $c ></TD><TD $c></TD><TD $c>$uid</TD><TD $c>$com</TD><TD $c>$start</TD><TD $c>$end</TD>\n";
    print "\t</TR>\n";
  }
  $old_ip  = $ip;
  $old_pid = $pid;
 
}	    


?>
  </TABLE>

</BODY>

</HTML>
