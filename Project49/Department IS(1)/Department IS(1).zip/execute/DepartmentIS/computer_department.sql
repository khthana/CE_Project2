-- phpMyAdmin SQL Dump
-- version 2.9.0.2
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 17 ม.ค. 2007  น.
-- รุ่นของเซิร์ฟเวอร์: 5.0.24
-- รุ่นของ PHP: 4.4.4
-- 
-- ฐานข้อมูล: `computer_department`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `activity_person`
-- 

CREATE TABLE `activity_person` (
  `activity_id` int(11) NOT NULL auto_increment COMMENT 'รหัสของกิจกรรมทางวิชาการ',
  `activity_name` varchar(100) default NULL COMMENT 'ชื่อกิจกรรมทางวิชาการ',
  `activity_place` varchar(100) default NULL COMMENT 'สถานที่',
  `activity_date` date default NULL COMMENT 'วันที่',
  `activity_comm` varchar(100) default NULL COMMENT 'หมายเหตุ',
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`activity_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `activity_person`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `administrator`
-- 

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- dump ตาราง `administrator`
-- 

INSERT INTO `administrator` VALUES (2, 'root', '0c35c3d3695edbff');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `bookborrow`
-- 

CREATE TABLE `bookborrow` (
  `borrowid` int(11) NOT NULL auto_increment,
  `student_id` varchar(8) NOT NULL,
  `bookid` varchar(5) NOT NULL,
  `dborrow` date NOT NULL,
  `bstatus` varchar(1) NOT NULL,
  PRIMARY KEY  (`borrowid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=58 ;

-- 
-- dump ตาราง `bookborrow`
-- 

INSERT INTO `bookborrow` VALUES (55, '47015312', '0002', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (54, '47015312', '0002', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (53, '47015312', '0004', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (52, '47015323', '0010', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (51, '47015323', '0002', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (50, '47015323', '0001', '2007-01-08', '1');
INSERT INTO `bookborrow` VALUES (49, '47015312', '0007', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (48, '47015312', '0001', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (47, '47015312', '0003', '2007-01-08', '0');
INSERT INTO `bookborrow` VALUES (56, '47015323', '0008', '2007-01-12', '1');
INSERT INTO `bookborrow` VALUES (57, '47015323', '0004', '2007-01-12', '1');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `books`
-- 

CREATE TABLE `books` (
  `bookid` varchar(5) NOT NULL COMMENT 'รหัสหนังสือ',
  `bnamethai` varchar(100) NOT NULL COMMENT 'ชื่อโครงงานภาษาไทย',
  `bnameeng` varchar(100) NOT NULL COMMENT 'ชื่อโครงงานภาษาอังกฤษ',
  `advisor1` varchar(50) NOT NULL COMMENT 'อ.ที่ปรึกษา1',
  `advisor2` varchar(50) default NULL COMMENT 'อ.ที่ปรึกษา2',
  `advisor3` varchar(50) default NULL COMMENT 'อ.ที่ปรึกษา3',
  `student1` varchar(50) NOT NULL COMMENT 'ชื่อนักศึกษา1',
  `studentid1` varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา1',
  `email1` varchar(30) default NULL COMMENT 'อีเมลนักศึกษา1',
  `student2` varchar(50) default NULL COMMENT 'ชื่อนักศึกษา2',
  `studentid2` varchar(8) default NULL COMMENT 'รหัสนักศึกษา2',
  `email2` varchar(30) default NULL COMMENT 'อีเมลนักศึกษา2',
  `student3` varchar(50) default NULL COMMENT 'ชื่อนักศึกษา3',
  `studentid3` varchar(8) default NULL COMMENT 'รหัสนักศึกษา3',
  `email3` varchar(30) default NULL COMMENT 'อีเมลนักศึกษา3',
  `student4` varchar(50) default NULL COMMENT 'ชื่อนักศึกษา4',
  `studentid4` varchar(8) default NULL COMMENT 'รหัสนักศึกษา4',
  `email4` varchar(30) default NULL COMMENT 'อีเมลนักศึกษา4',
  `bookyear` int(11) default NULL COMMENT 'ปีการศึกษา',
  PRIMARY KEY  (`bookid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='ตารางเก็บข้อมูลของหน';

-- 
-- dump ตาราง `books`
-- 

INSERT INTO `books` VALUES ('0001', 'การจำแนกภาพรหัสแท่งแบบสองมิติ1', '2D-Barcode Image Recognition  ', 'ดร. วัชระ ฉัตรวิริยะ', NULL, NULL, 'นายพิภพ พรยั่งยืน', '46015359', 's6015359@kmitl.ac.th', 'นายสันติพล ครุธงาม', '46015377', 's6015377@kmitl.ac.th', NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0002', 'การพัฒนาเกม 3 มิติ', '3D GAME DEVELOPMENT ', 'ดร.วรวัฒน์ ลิ้มโภคา ', NULL, NULL, 'นางสาวสุกัญญา ดิลกธนกุล', '45010876', 's5010876@kmitl.ac.th', 'นางสาวสุคนธ์ สุตันทวงษ์', '45010843', 's5010843@kmitl.ac.th', 'นายสุรศักดิ์ จันทร์ศรีธัญโกส', '45010876', 's5010876@kmitl.ac.th', NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0003', 'เกมเอนจินสามมิติ', '3D Game Engine', 'ดร.สมศักดิ์ วลัยรัชต์', NULL, NULL, 'คณิต เมฆฤทธิไกร ', '45010081', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0004', 'เกม 3 มิติบนคอมพิวเตอร์แบบพกพา', '3D GAME ON POCKET PC', 'อาจารย์ที่ปรึกษา', NULL, NULL, 'ธีระยุทธ', '47015323', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0005', 'ระบบตรวจตราความปลอดภัยบนโทรศัพท์เคลื่อนที่', 'ACCESS MONITORING SYSTEM ON MOBILE', 'ดร. วรวัฒน์ ลิ้มโภคา', NULL, NULL, 'เอกพล อนันตพรกิจ', '41014548', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0006', 'ระบบต่อต้านการบุกรุกช่องโหว่ทางซอฟต์แวร์', 'ANTI-EXPLOIT CODE SYSTEM', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0007', 'ระบบเครือข่ายการควบคุมเครื่องใช้ไฟฟ้าบนโทรศัพท์เคลื่อนที่ผ่านบลูทูธ', 'APPLIANCE CONTROL NETWORK SYSTEM ON MOBILE PHONE VIA BLUETOOTH', 'อาจารย์ที่ปรึกษา', NULL, NULL, 'ทดสอบ', '47015323', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0008', 'ระบบสร้างภาพคอมพิวเตอร์แบบสามมิติโดยอาศัยข้อมูลระยะห่างกล้องกับวัตถุ', '3D Reconstruction from Range Data', 'ดร.สมศักดิ์ วลัยรัชต์', 'อ.สมเกียรติ วังศิริพิทักษ์', NULL, 'สิริโรจน์ เตชะนรราช', '44010535', NULL, 'ณัฐพงษ์ ลิ้มประภากรชัย', '44010152', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0009', 'การพัฒนาแอพพลิเคชั่นด้วยเว็บเซอร์วิส', 'Application Development with Web Service', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0010', 'โปรแกรมสร้างตัวอย่างเพื่อใช้ตรวจสอบซอฟต์แวร์', 'Automated Test-Case Generator for Software Testing', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0011', 'การตรวจสอบคุณสมบัติชิ้นงานโดยการประมวลผลภาพ', 'Automated Visual Inspection', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0012', 'โปรแกรมจัดการการจัดสอบอัตโนมัติ', 'Automatic Examination Management System', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0013', 'โปรแกรมนำเข้าข้อมูลคะแนนอัตโนมัติ', 'Automatic Score Importing Systems', 'ทดสอบ', NULL, NULL, 'ทดสอบ', '44015311', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2548);
INSERT INTO `books` VALUES ('0014', 'ระบบจำลองการเคลื่อนไหวตัวละคร 3 มิติ', '3D Character Animation Studio', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0015', 'การพัฒนาเกมสามมิติบนเครือข่าย', '3D Game Development(Online)', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0016', 'การพัฒนาเกมสามมิติบนเครือข่าย', '3D Game Development(Online)', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0017', 'เกม 3 มิติเพื่อการศึกษา 1(โครงสร้างของระบบปัญญาประดิษฐ์)', '3D Game for Edutainment I(Structure of Agent)', '', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0018', 'ระบบการออกแบบตกแต่งภายในแบบ 3 มิติ', '3D Interior Layout Design', 'ดร. อรัญญา วลัยรัชต์', NULL, NULL, 'นฤวัจน์ เพชรแสงงาม', '45015372', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);
INSERT INTO `books` VALUES ('0019', 'การพัฒนาเกม 3 มิติ (4)', '3D Game Development', 'ดร. วรวัฒน์ ลิ้มโภคา', NULL, NULL, 'เอกพล อนันตพรกิจ', '41014548', NULL, 'อนุสรณ์ กระสานติสุข', '41014511', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2547);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `category`
-- 

CREATE TABLE `category` (
  `category_id` varchar(2) NOT NULL COMMENT 'รหัสหมวดวิชาโครงสร้างหลักสูตร',
  `category` varchar(20) NOT NULL,
  `struct_id` varchar(2) NOT NULL COMMENT 'รหัสโครงสร้างหลักสูตร',
  `cprogram_unit1` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตของหมวดวิชาของหลักสูตรของโปรแกรมการศึกษาที่ 1',
  `cprogram_unit2` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตของหมวดวิชาของหลักสูตรของโปรแกรมการศึกษาที่ 2',
  PRIMARY KEY  (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `category`
-- 

INSERT INTO `category` VALUES ('1', 'หมวดวิชาศึกษาทั่วไป', '1', 31, 13);
INSERT INTO `category` VALUES ('2', 'หมวดวิชาเฉพาะ', '1', 101, 88);
INSERT INTO `category` VALUES ('3', 'หมวดวิชาเลือกเสรี', '1', 9, 6);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `edu_person`
-- 

CREATE TABLE `edu_person` (
  `degree` char(1) NOT NULL COMMENT 'ระดับ (0 ป.ตรี) (1 ป.โท) (2 ป.เอก)',
  `univ_name` varchar(50) default NULL COMMENT 'ชื่อสถาบัน',
  `country_name` varchar(50) default NULL COMMENT 'ชื่อประเทศ',
  `year_congrate` int(5) default NULL COMMENT 'ปีที่สำเร็จการศึกษา',
  `senior_degree` varchar(50) default NULL COMMENT 'วุฒิที่ได้รับ',
  `knowledge` varchar(50) default NULL COMMENT 'วิชาเอก',
  `grade` float default NULL COMMENT 'คะแนนเฉลี่ย',
  `thesis` varchar(100) default NULL,
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`degree`,`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `edu_person`
-- 

INSERT INTO `edu_person` VALUES ('0', 'มหาวิยาลัย ป.ตรี1', 'ประเทศไทย1', 2545, 'วศบ.1', 'คอมพิวเตอร์1', 3.95, 'ชื่อปริญญานิพนธ์1', 't0004');
INSERT INTO `edu_person` VALUES ('1', 'มหาวิยาลัย ป.โท1', 'ประเทศไทย1', 2549, 'ระดับป.โท1', 'วิชาเอกป.โท1', 3.99, 'ชื่อวิทยานิพนธ์1', 't0004');
INSERT INTO `edu_person` VALUES ('2', 'มหาวิยาลัย ป.เอก1', 'ประเทศไทย1', 2555, 'ระดับป.เอก1', 'วิชาเอกป.เอก1', 3.12, 'ชื่อวิทยานิพนธ์1', 't0004');
INSERT INTO `edu_person` VALUES ('0', 'มหาวิยาลัย ป.ตรี1', 'ประเทศไทย1', 2545, 'วศบ.1', 'คอมพิวเตอร์1', 3.95, 'ชื่อปริญญานิพนธ์1', 't0007');
INSERT INTO `edu_person` VALUES ('1', 'มหาวิยาลัย ป.โท1', 'ประเทศไทย1', 2549, 'ระดับป.โท1', 'วิชาเอกป.โท1', 3.99, 'ชื่อวิทยานิพนธ์1', 't0007');
INSERT INTO `edu_person` VALUES ('2', 'มหาวิยาลัย ป.เอก1', 'ประเทศไทย1', 2555, 'ระดับป.เอก1', 'วิชาเอกป.เอก1', 3.12, 'ชื่อวิทยานิพนธ์1', 't0007');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `groups`
-- 

CREATE TABLE `groups` (
  `gsubject_id` varchar(2) NOT NULL,
  `gsubject` varchar(100) NOT NULL COMMENT 'ชื่อกลุ่มวิชาของหลักสูตร',
  `gprogram_unit1` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 1',
  `gprogram_unit2` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 2',
  `gdetail` text NOT NULL COMMENT 'คำอธิบายกลุ่มวิชาของหลักสูตร',
  `category_id` varchar(2) NOT NULL,
  PRIMARY KEY  (`gsubject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `groups`
-- 

INSERT INTO `groups` VALUES ('1', 'กลุ่มวิชาสังคมศาสตร์', 2, 2, '', '1');
INSERT INTO `groups` VALUES ('2', 'กลุ่มวิชามนุษยศาสตร์', 2, 2, '', '1');
INSERT INTO `groups` VALUES ('3', 'กลุ่มวิชาภาษา', 6, 6, '', '1');
INSERT INTO `groups` VALUES ('4', 'กลุ่มวิชาวิทยาศาสตร์', 12, 0, '', '1');
INSERT INTO `groups` VALUES ('5', 'กลุ่มวิชาคณิตศาสตร์', 9, 3, '', '1');
INSERT INTO `groups` VALUES ('6', 'กลุ่มวิชาวิศวกรรมพื้นฐาน', 16, 3, '', '2');
INSERT INTO `groups` VALUES ('7', 'กลุ่มวิชาบังคับ', 49, 49, '', '2');
INSERT INTO `groups` VALUES ('8', 'กลุ่มวิชาบังคับเลือก', 21, 21, '', '2');
INSERT INTO `groups` VALUES ('9', 'กลุ่มวิชาเลือกเฉพาะสาขา', 15, 15, '', '2');
INSERT INTO `groups` VALUES ('10', 'กลุ่มวิชาเลือกเสรี', 9, 6, '', '3');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `intro`
-- 

CREATE TABLE `intro` (
  `course_year` int(10) NOT NULL COMMENT 'ปีการศึกษา',
  `th_name` varchar(100) NOT NULL COMMENT 'ชื่อหลักสูตรภาษาไทย',
  `en_name` varchar(100) NOT NULL COMMENT 'ชื่อหลักสูตรภาษาอังกฤษ',
  `th_fname` varchar(100) NOT NULL COMMENT 'ชื่อเต็มภาษาไทยของหลักสูตร',
  `th_sname` varchar(100) NOT NULL COMMENT 'ชื่อย่อภาษาไทยของหลักสูตร',
  `en_fname` varchar(100) NOT NULL COMMENT 'ชื่อเต็มภาษาอังกฤษของหลักสูตร',
  `en_sname` varchar(100) NOT NULL COMMENT 'ชื่อย่อภาษาอังกฤษของหลักสูตร',
  `accept` text COMMENT 'หน่วยงานที่รับผิดชอบ',
  `philosophy` text COMMENT 'ปรัชญาของหลักสูตร',
  `article` text COMMENT 'วัตถุประสงค์ของหลักสูตร',
  `program` text COMMENT 'กำหนดการเปิดสอนของหลักสูตร',
  `property` text COMMENT 'คุณสมบัติของผู้เข้าศึกษา',
  `ctest` text COMMENT 'การคัดเลือกผู้เข้าศึกษา',
  `csystem` text COMMENT 'ระบบการศึกษา',
  `ctime` text COMMENT 'ระยะเวลาการศึกษา',
  `register` text COMMENT 'ระบบการลงทะเบียนเรียน',
  `process` text COMMENT 'การวัดผลและการสำเร็จการศึกษา',
  `place` text COMMENT 'สถานที่',
  `tool` text COMMENT 'อุปกรณ์',
  PRIMARY KEY  (`course_year`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `intro`
-- 

INSERT INTO `intro` VALUES (2545, 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมคอมพิวเตอร์ ', 'Curriculum for Bachelor of Engineering Program in Computer', 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมคอมพิวเตอร์) ', 'วศ.บ. (วิศวกรรมคอมพิวเตอร์) ', 'Bachelor of Engineering (Computer Engineering) ', 'B.Eng. (Computer Engineering) ', 'ภาควิชาวิศวกรรมคอมพิวเตอร์ \r\nคณะวิศวกรรมศาสตร์\r\nสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง', 'ในปัจจุบันเป็นที่ทราบกันดีว่า วิศวกร เป็นวิชาชีพหนึ่งที่มีความสำคัญและมีบทบาทในสังคมไทย โดยเฉพาะในยุคที่ประเทศไทยจำเป็นต้องหันมาพึ่งตนเอง โดยการสร้างเทคโนโลยีขึ้นใช้เองภายในประเทศ วิศวกรคอมพิวเตอร์เป็นอาชีพหนึ่งที่มีหน้าที่สร้างสรรค์ และประยุกต์ใช้เทคโนโลยีคอมพิวเตอร์เพื่อความเป็นอยู่ที่ดีขึ้นของคนในสังคม ดังนั้นบุคคลที่สำเร็จการศึกษาเป็นวิศวกรคอมพิวเตอร์ ควรได้รับการฝึกฝนให้มีทั้งความรู้พื้นฐานในสาขา จัดระบบทั้งการคิดและการกระทำ ตลอดจนความคิดสร้างสรรค์ และความรับผิดชอบในวิชาชีพและสังคม ก่อนเข้าสู่การปฏิบัติงานจริง\r\nหลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิศวกรรมคอมพิวเตอร์นี้ได้ออกแบบขึ้นโดยมีเป้าหมายเพื่อสร้างวิศวกรคอมพิวเตอร์ ที่สามารถสำเร็จการศึกษาออกไปทำงานในสาขาต่าง ๆ ได้อย่างมีประสิทธิภาพ ไม่ว่าเป็นทางด้านคอมพิวเตอร์ซอฟต์แวร์ ด้านคอมพิวเตอร์ฮาร์ดแวร์ หรือด้านระบบเครือข่ายคอมพิวเตอร์ โดยหลักสูตรนี้จะให้นักศึกษาได้เรียนรู้ในรายวิชาที่เป็นพื้นฐานของสาขาวิชาต่าง ๆ และรายวิชาที่เป็นพื้นฐานที่     จำเป็นต้องใช้ในการศึกษาต่อในอนาคต นอกจากนั้นหลักสูตรนี้ได้เปิดโอกาสให้นักศึกษาได้เลือกเรียนในสาขาวิชาที่หลากหลายตามต้องการ ไม่ว่าจะเป็นการเรียนรู้ในทางกว้าง หรือการเรียนรู้ที่เจาะลึกเป็นพิเศษในบางสาขา \r\n      นักศึกษาที่สำเร็จการศึกษาจากหลักสูตรนี้ จะมีความรู้ความชำนาญในสาขาคอมพิวเตอร์ ทั้งด้านทฤษฎีและปฏิบัติ เพียงพอต่อการศึกษาในระดับสูงขึ้น และเพียงพอต่อการเข้าสู่ตลาดแรงงานได้อย่างมั่นใจ\r\n', '1.ผลิตบัณฑิตที่มีความรู้พื้นฐานทางคอมพิวเตอร์ทั้งทางทฤษฎีและปฏิบัติสำหรับตลาดแรงงานและพร้อมสำหรับการศึกษาในระดับสูงต่อไป\r\n2.ฝึกหัดและอบรมนักศึกษาในสาขาวิศวกรรมคอมพิวเตอร์ให้เป็นผู้มีวินัย ความคิด และการทำงานอย่างมีระบบ พร้อมด้วยคุณธรรม และจริยธรรมที่เหมาะสม\r\n', 'ปีการศึกษา 2545 เป็นต้นไป', '1.สำเร็จการศึกษาระดับมัธยมศึกษาตอนปลายหรือเทียบเท่าตามที่กระทรวงศึกษาธิการรับรอง\r\n2.สำเร็จการศึกษาประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.) ในสาขาไฟฟ้า อิเล็กทรอนิกส์ โทรคมนาคม คอมพิวเตอร์ หรือเทียบเท่าตามหลักสูตรที่กระทรวงศึกษาธิการรับรองสำหรับหลักสูตรเทียบโอน\r\n ', '1. สำหรับหลักสูตร 4 ปี จะต้องเป็นผู้ผ่านการคัดเลือกตามระเบียบของทบวงมหาวิทยาลัย\r\n2.สำหรับหลักสูตรเทียบโอน จะต้องเป็นผู้ผ่านการคัดเลือกตามระเบียบของคณะวิศวกรรมศาสตร์ สถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการรับนักศึกษาเข้าเรียนในระดับปริญญาตรี\r\n ', '1.ระบบการศึกษาใช้ระบบการศึกษาแบบทวิภาค โดย 1 ปีการศึกษาแบ่งออกเป็น 2 ภาคการศึกษาและใน 1 ภาคการศึกษาปกติมีระยะเวลาการศึกษาไม่น้อยกว่า 15 สัปดาห์\r\n2.การคิดหน่วยกิต\r\n      2.1รายวิชาภาคทฤษฎีที่ใช้เวลาบรรยายหรืออภิปรายปัญหา 1 ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติ หรือไม่น้อยกว่า 15 ชั่วโมงให้มีค่าเท่ากับ 1 หน่วยกิต\r\n2.2 รายวิชาภาคปฏิบัติ ที่ใช้เวลาฝึกหรือทดลอง  2  ถึง  3 ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติ หรือตั้งแต่ 30 ถึง 45 ชั่วโมงให้มีค่าเท่ากับ 1 หน่วยกิต  \r\n2.3 การฝึกงานหรือการฝึกภาคสนาม    ที่ใช้เวลาฝึกหรือทดลอง   3   ถึง   6  ชั่วโมงต่อสัปดาห์ตลอดหนึ่งภาคการศึกษาปกติตั้งแต่ 45 ถึง 90 ชั่วโมง ให้มีค่าเท่ากับ 1 หน่วยกิต\r\n', '1.สำหรับหลักสูตร 4 ปี ให้ใช้ระยะเวลาการศึกษาอย่างมากไม่เกิน 8 ปีการศึกษา \r\n2.สำหรับหลักสูตรเทียบโอน ให้ใช้ระยะเวลาการศึกษาอย่างมากไม่เกิน 6 ปีการศึกษา ', ' ให้ลงทะเบียนได้ไม่น้อยกว่า 9 หน่วยกิต และไม่เกิน 22 หน่วยกิต ในแต่ละภาคการศึกษาปกติ และไม่เกิน 10 หน่วยกิต สำหรับการศึกษาภาคฤดูร้อน โดยให้เป็นไปตามระเบียบการวัดผลของสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการวัดผลการศึกษาระดับปริญญาตรี \r\n ', 'การวัดผลให้เป็นไปตามระเบียบการวัดผลของสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ว่าด้วยการวัดผลการศึกษาระดับปริญญาตรี พ.ศ. 2534 ', 'ภาควิชาวิศวกรรมคอมพิวเตอร์\r\nคณะวิศวกรรมศาสตร์\r\nสถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง', 'ภาควิชาวิศวกรรมคอมพิวเตอร์ คณะวิศวกรรมศาสตร์ สถาบันเทคโนโลยีพระจอมเกล้าเจ้าคุณทหารลาดกระบัง ได้ดำเนินการสอนในระดับปริญญาตรีมาเป็นเวลานานกว่า 15 ปี มีอุปกรณ์สำหรับการเรียน การสอน และห้องปฏิบัติการคอมพิวเตอร์ที่มีความพร้อม โดยภาควิชาฯ มีเครื่องระดับมินิคอมพิวเตอร์ที่ใช้ระบบปฏิบัติการยูนิกซ์ จำนวน 2 เครื่อง มีเครื่องคอมพิวเตอร์แม่ข่ายที่ใช้ระบบปฏิบัติการตระกูลวินโดวส์และตระกูลเน็ตแวร์ จำนวน 4 เครื่อง ภาควิชาฯ ได้ติดตั้งบริการต่าง ๆ สำหรับนักศึกษา อาทิ บริการเว็บเพจ ทั้งเว็บเพจของภาควิชาฯ และเว็บเพจส่วนตัว บริการไฟล์ บริการจดหมายอิเล็กทรอนิกส์ และบริการงานพิมพ์ ซึ่งเครื่องคอมพิวเตอร์แม่ข่ายที่ให้บริการต่าง ๆ เหล่านี้จะช่วยให้อำนวยความสะดวกในการใช้งานของนักศึกษาได้เป็นอย่างดี\r\n       ทางด้านเครื่องคอมพิวเตอร์สำหรับใช้งานทั่วไป ภาควิชาฯ มีเครื่องคอมพิวเตอร์ลูกข่าย จำนวน 140 เครื่อง ทำหน้าที่ให้นักศึกษาทดลองในรายวิชาต่าง ๆ และให้นักศึกษาเข้ามาใช้งานทั่วไป ในช่วงที่ไม่มีการเรียน นอกจากนั้นนักศึกษาภาควิชาฯ ยังสามารถสืบค้นข้อมูลในเครือข่ายอินเตอร์เน็ต โดยสถาบันฯ มีความเร็วในการเชื่อมต่อกับเครือข่ายอินเตอร์เน็ตด้วยความเร็วถึง 4 เมกะบิตต่อวินาที นอกจากนั้นภาควิชาฯ ยังมีห้องปฏิบัติการดิจิตอล ห้องปฏิบัติการเชื่อมต่อด้วยไมโครโพรเซสเซอร์ที่ทันสมัย และห้องปฏิบัติการออกแบบวงจรดิจิตอลโดยใช้เทคโนโลยี FPGA สามารถให้นักศึกษาได้ทำการทดลองทางด้านฮาร์ดแวร์ตั้งแต่ระดับพื้นฐาน จนถึงการออกแบบวงจรดิจิตอลระดับสูง ');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `parent`
-- 

CREATE TABLE `parent` (
  `student_id` varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  `ptype` char(1) NOT NULL COMMENT 'ความสัมพันธ์กับนักศึกษา(0 = บิดา, 1 = มารดา, 2 = ผู้ปกครอง, 3 = ผู้อุปการะด้านการเงิน)',
  `relationship` varchar(15) default NULL COMMENT 'ความสัมพันธ์',
  `name_parent` varchar(50) default NULL COMMENT 'ชื่อของผู้ปกครอง',
  `surname_parent` varchar(50) default NULL COMMENT 'นามสกุลของผู้ปกครอง',
  `status_parent` varchar(50) default NULL COMMENT 'สถานะของผู้ปกครอง ',
  `age_parent` int(11) default NULL COMMENT 'อายุของผู้ปกครอง',
  `race_parent` varchar(50) default NULL COMMENT 'เชื้อชาติของผู้ปกครอง',
  `nationality_parent` varchar(50) default NULL COMMENT 'สัญชาติของผู้ปกครอง',
  `religion_parent` varchar(50) default NULL COMMENT 'ศาสนาของผู้ปกครอง ',
  `citizenid_parent` varchar(13) default NULL COMMENT 'หมายเลขประจำตัวประชาชนของผู้ปกครอง',
  `number_parent` varchar(10) default NULL COMMENT 'บ้านเลขที่ของผู้ปกครอง',
  `group_parent` varchar(10) default NULL COMMENT 'หมู่ที่ของผู้ปกครอง',
  `lane_parent` varchar(50) default NULL COMMENT 'ตรอก/ซอยของผู้ปกครอง',
  `road_parent` varchar(50) default NULL COMMENT 'ถนนของผู้ปกครอง',
  `district_parent` varchar(50) default NULL COMMENT 'ตำบล/แขวงของผู้ปกครอง',
  `region_parent` varchar(50) default NULL COMMENT 'อำเภอ/เขตของผู้ปกครอง',
  `province_parent` varchar(50) default NULL COMMENT 'จังหวัดของผู้ปกครอง',
  `postalcode_parent` varchar(10) default NULL COMMENT 'รหัสไปรษณีย์ของผู้ปกครอง',
  `tel_parent` varchar(15) default NULL COMMENT 'หมายเลขโทรศัพท์ของผู้ปกครอง',
  `educational_parent` varchar(50) default NULL COMMENT 'วุฒิสูงสุดของผู้ปกครอง',
  `work_parent` varchar(50) default NULL COMMENT 'อาชีพของผู้ปกครอง',
  `workplace_parent` varchar(100) default NULL COMMENT 'ชื่อสถานประกอบอาชีพของผู้ปกครอง',
  `provincework_parent` varchar(50) default NULL COMMENT 'จังหวัดสถานประกอบอาชีพของผู้ปกครอง',
  `postalcodework_parent` varchar(10) default NULL COMMENT 'รหัสไปรษณีย์สถานประกอบอาชีพของผู้ปกครอง',
  `telwork_parent` varchar(15) default NULL COMMENT 'โทรศัพท์สถานประกอบอาชีพของผู้ปกครอง',
  `salary_parent` int(11) default NULL COMMENT 'รายได้เฉลี่ย/เดือนของผู้ปกครอง',
  PRIMARY KEY  (`student_id`,`ptype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `parent`
-- 

INSERT INTO `parent` VALUES ('47015323', '0', NULL, 'สุพจน์', 'แสนหอม', 'Y', 52, 'จีน', 'จีน', 'คริสต์', '5485622445524', '10', '1', NULL, NULL, 'เมืองเก่า', 'เมือง', '6', '40000', '043324869', 'nbvn', 'เกษตรกร/ชาวประมง', 'บ้าน', '6', '40000', '043324869', 500);
INSERT INTO `parent` VALUES ('47015323', '1', 'แมงเม่า', 'สมพร', 'แสนหอม', 'Y', 30, 'ไทย', 'ไทย', 'พุทธ', '1235445556688', '12', '1', '-', '-', 'บ้านเหล่า', 'บ้านฝาง', '6', '10200', '043324869', 'ประถมศึกษา', 'พนักงานหรือลูกจ้างเอกชน', 'บ้าน', '6', '10100', '043324869', 500);
INSERT INTO `parent` VALUES ('47015312', '0', NULL, NULL, NULL, 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO `parent` VALUES ('47015312', '1', NULL, NULL, NULL, 'Y', NULL, 'ไทย', 'ไทย', 'พุทธ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ประถมศึกษา', 'รับราชการ', NULL, NULL, NULL, NULL, 0);
INSERT INTO `parent` VALUES ('47015328', '0', NULL, 'ศรเทพ', 'เทพพิทักษ์', 'Y', 50, 'ไทย', 'ไทย', 'พุทธ', '2345234523452', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 'มัธยมศึกษา', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บริษัทกรุงชลการค้า', '9', '20200', '038-987987', 50000);
INSERT INTO `parent` VALUES ('47015323', '2', 'แมงเม่า', 'ธำรงค์', 'แสนหอม', NULL, 30, 'ไทย', 'ไทย', 'พุทธ', '1235452112656', '10', '2', '-', '-', '-', '-', '24', '-', '-', 'ไม่มีวุฒิ', 'พนักงานหรือลูกจ้างเอกชน', 'โรงนา', '50', '20351', '2215485421', 0);
INSERT INTO `parent` VALUES ('47015323', '3', 'น้า', 'วสันต์', 'อัสนี', NULL, 12, 'ฝรั่ง', 'อิตาลี', 'คริสต์', '123456789231', '2', '1', 'ซอย', 'ถ.อ่อนด๋อย', '-', 'บ้านฝาง', '4', '20000', '1000000000000', 'ปริญญาเอก', 'รับจ้าง', 'วัด', '26', '10200', '11022156322', 500000);
INSERT INTO `parent` VALUES ('47015328', '1', NULL, 'อรพรรณ', 'เทพพิทักษ์', 'Y', 46, 'ไทย', 'ไทย', 'พุทธ', '4351523456262', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 'มัธยมศึกษา', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'บริษัทกรุงชลการค้า', '9', '20200', '038-987987', 30000);
INSERT INTO `parent` VALUES ('48015001', '0', NULL, 'สุพจน์', 'อนุรัตนวงศ์', 'Y', 55, 'ไทย', 'ไทย', 'พุทธ', '1023000405666', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', '0813748574', 'ปริญญาโท', 'รับราชการ', 'มหาวิทยาลัยเชียงใหม่', '13', '50500', '-', 27500);
INSERT INTO `parent` VALUES ('48015001', '1', NULL, 'อโนทัย', 'อนุรัตนวงศ์', 'Y', 44, 'ไทย', 'ไทย', 'พุทธ', '1087600054687', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', '0867656787', 'ปริญญาตรี', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', 'ที่บ้าน', '13', NULL, NULL, 15000);
INSERT INTO `parent` VALUES ('49015001', '0', NULL, 'สมชาย', 'สมวงศ์', 'Y', 52, 'ไทย', 'ไทย', 'คริสต์', '1003232525252', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', '65000', '0894543678', 'ปริญญาตรี', 'พนักงานรัฐวิสาหกิจ', 'การไฟฟ้าส่วนภูมิภาค', '38', '65000', '-', 17500);
INSERT INTO `parent` VALUES ('49015001', '1', NULL, 'วาสนา', 'สมวงศ์', 'Y', 45, 'ไทย', 'ไทย', 'พุทธ', '1008767689968', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', NULL, NULL, 'อนุปริญญาหรือเทียบเท่า', 'เจ้าของ/ประกอบการธุรกิจส่วนตัว/ค้าขาย', '-', NULL, NULL, NULL, 9000);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `performance_person`
-- 

CREATE TABLE `performance_person` (
  `performance_id` int(11) NOT NULL auto_increment COMMENT 'รหัสของผลงานทางวิชาการ',
  `performance_name` varchar(100) default NULL COMMENT 'ชื่อผลงานทางวิชาการ',
  `performance_place` varchar(100) default NULL COMMENT 'สถานที่',
  `performance_country` varchar(100) default NULL COMMENT 'ประเทศ',
  `performance_date` date default NULL COMMENT 'วันที่',
  `performance_comm` varchar(100) default NULL COMMENT 'หมายเหตุ',
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`performance_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- dump ตาราง `performance_person`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `person`
-- 

CREATE TABLE `person` (
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  `gender` varchar(10) NOT NULL COMMENT 'เพศ',
  `position` varchar(10) default NULL COMMENT 'ตำแหน่งทางวิชาการ',
  `level` varchar(10) default NULL COMMENT 'ระดับทางวิชาการ',
  `prename` varchar(10) default NULL COMMENT 'คำนำหน้าชื่อ',
  `th_name` varchar(50) NOT NULL COMMENT 'ชื่อภาษาไทย',
  `th_surname` varchar(50) NOT NULL COMMENT 'นามสกุลภาษาไทย',
  `en_name` varchar(30) default NULL COMMENT 'ชื่อภาษาอังกฤษ',
  `en_surname` varchar(30) default NULL COMMENT 'นามสกุลภาษาอังกฤษ',
  `type` varchar(1) NOT NULL COMMENT 'ประเภทบุคลากร',
  `citizenid` varchar(13) default NULL COMMENT 'รหัสประจำตัวประชาชน',
  `telephone` varchar(10) default NULL COMMENT 'เบอร์โทรศัพท์ภายใน',
  `mobile` varchar(10) default NULL COMMENT 'เบอร์โทรศัพท์มือถือ',
  `email` varchar(30) default NULL COMMENT 'อีเมล',
  `username` varchar(20) default NULL COMMENT 'ชื่อล็อกอิน',
  `password` varchar(20) default NULL COMMENT 'รหัสล็อกอิน',
  `number1` varchar(10) default NULL COMMENT 'บ้านเลขที่',
  `group1` varchar(5) default NULL COMMENT 'หมู่ที่',
  `lane1` varchar(50) default NULL COMMENT 'ตรอก/ซอย',
  `road1` varchar(50) default NULL COMMENT 'ถนน',
  `district1` varchar(50) default NULL COMMENT 'ตำบล/แขวง',
  `region1` varchar(50) default NULL COMMENT 'อำเภอ',
  `province1` varchar(2) default NULL COMMENT 'จังหวัด',
  `postalcode1` varchar(5) default NULL COMMENT 'รหัสไปรษณีย์',
  `telephone1` varchar(10) default NULL COMMENT 'โทรศัพท์',
  `number2` varchar(10) default NULL COMMENT 'บ้านเลขที่',
  `group2` varchar(5) default NULL COMMENT 'หมู่ที่',
  `lane2` varchar(50) default NULL COMMENT 'ตรอก/ซอย',
  `road2` varchar(50) default NULL COMMENT 'ถนน',
  `district2` varchar(50) default NULL COMMENT 'ตำบล/แขวง',
  `region2` varchar(50) default NULL COMMENT 'อำเภอ',
  `province2` varchar(2) default NULL COMMENT 'จังหวัด',
  `postalcode2` varchar(5) default NULL COMMENT 'รหัสไปรษณีย์',
  `telephone2` varchar(10) default NULL COMMENT 'โทรศัพท์',
  `father_name` varchar(20) default NULL COMMENT 'ชื่อของบิดา',
  `father_sname` varchar(30) default NULL COMMENT 'นามสกุลของบิดา',
  `father_age` int(11) default NULL COMMENT 'อายุของบิดา',
  `father_work` varchar(50) default NULL COMMENT 'อาชีพของบิดา',
  `father_nationality` varchar(20) default NULL COMMENT 'สัญชาติของบิดา',
  `father_workplace` varchar(50) default NULL COMMENT 'สถานที่ทำงานของบิดา',
  `father_phone` varchar(10) default NULL COMMENT 'โทรศัพท์ของบิดา',
  `mother_name` varchar(20) default NULL COMMENT 'ชื่อของมารดา',
  `mother_sname` varchar(30) default NULL COMMENT 'นามสกุลของมารดา ',
  `mother_age` int(3) default NULL COMMENT 'อายุของมารดา',
  `mother_work` varchar(50) default NULL COMMENT 'อาชีพของมารดา',
  `mother_nationality` varchar(20) default NULL COMMENT 'สัญชาติของมารดา',
  `mother_workplace` varchar(50) default NULL COMMENT 'สถานที่ทำงานของมารดา',
  `mother_phone` varchar(10) default NULL COMMENT 'โทรศัพท์ของมารดา',
  PRIMARY KEY  (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `person`
-- 

INSERT INTO `person` VALUES ('t0001', 'ชาย', 'รศ.', 'ระดับ1', 'นาย', 'ประทีป', 'บัญญัตินพรัตน์', 'PRATEEP', 'BUNYUDNOOPARUT', '0', '1234567891111', '021486528', '0861489657', 'kbprathe@kmitl.ac.th', 't0001', '5b552a155cd5c19a', '112', '10', 'ซอย1', 'ถนน1', 'ตำบล1', 'อำเภอ1', 'จั', 'รหัสไ', '0861523648', '114/2', '41', 'ซอย2', 'ถนน2', 'ตำบล2', 'อำเภอ2', 'จั', 'รหัสไ', '0861523648', 'ชื่อบิดา', 'ชื่อมารดา', 0, 'อาชีพบิดา', 'สัญชาติบิดา', 'ที่ทำงานบิดา', 'โทรศัพท์', 'ชื่อมารดา', 'นามสกุลมารดา', 0, 'อาชีพมารดา', 'สัญชาติมารดา', 'ที่ทำงานมารดา', 'โทรศัพท์');
INSERT INTO `person` VALUES ('t0002', 'หญิง', NULL, NULL, 'น.ส', 'ศิวพร', 'ทรัพย์เจริญไชย', 'SIWAPORN', 'SUPJAREONCHAI', '3', '-', '-', '-', '-', 't0002', '5b5529255cd5beaa', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0003', 'ชาย', NULL, NULL, 'นาย', 'ภัทรชัย', 'แซ่ตั้ง', 'PATTARACHAI', 'SAETANG', '2', '-', '-', '-', '-', 't0003', '5b5528355cd5bfba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0004', 'ชาย', 'ผศ.ดร.', 'ระดับ2', 'นาย', 'สุรินทร์', 'กิตติธรกุล', 'SURIN', 'KITTITONKUN', '1', '9876543211', '0234574511', '0862548886', 'kksurin@kmitl.ac.th1', 't0004', '5b552f455cd5bcca', '12/4', '52', 'ซอย1', 'ถนน1', 'ตำบล1', 'อำเภอ1', '14', '25012', '0845235654', '55/4', '4', 'ซอย2', 'ถนน2', 'ตำบล2', 'อำเภอ2', '15', '56324', '025845655', 'ชื่อบิดา1', 'นามสกุลบิดา1', 60, 'Consulting', 'จีน', 'ที่ทำงานบิดา1', '0582232323', 'ชื่อมารดา', 'นามสกุลมารดา', 60, 'รับราชการ', 'vb9k]uj', 'ที่ทำงานมารดา2', '0895332141');
INSERT INTO `person` VALUES ('t0005', 'หญิง', NULL, NULL, 'นาง', 'กนกทิพย์', 'มิตะถา', 'KANOKTIP', 'MITATHA', '5', '-', '-', '-', '-', 't0005', '5b552e555cd5bdda', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0006', 'หญิง', NULL, NULL, 'นาง', 'ฉวีวรรณ', 'มงคลลาภกิจ', 'CHAWEEWAN', 'MONGKONLABKIT', '4', '-', '-', '-', '-', 't0006', '5b552d655cd5baea', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0007', 'ชาย', 'ผศ.ดร.', 'ระดับ2', 'นาย', 'ศักดิ์ชัย', 'ทิพย์จักษุรัตน์', 'SAKCHAI', 'TIPJAKSURATH', '1', '1234567891021', '-', '-', '-', 't0007', '5b552c755cd5bbfa', '1', '1', NULL, NULL, NULL, NULL, '28', NULL, NULL, '1', '1', NULL, NULL, NULL, NULL, '25', NULL, NULL, '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0008', 'ชาย', 'ผศ.', 'ระดับ4', 'นาย', 'สมเกียรติ', 'วังศิริพิทักษ์', 'SOMKIAT', 'WANGSIRIPITAK', '1', '-', '-', '-', '-', 't0008', '5b5553855cd5e90a', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0009', 'หญิง', 'ผศ.ดร.', 'ระดับ6', 'นาง', 'อรฉัตร', 'จิตต์โสภักตร์', 'ORACHAT', 'JITSOPAK', '1', '-', '-', '-', '-', 't0009', '5b5552955cd5ea1a', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');
INSERT INTO `person` VALUES ('t0010', 'ชาย', NULL, 'ระดับ7', 'นาย', 'อำนาจ', 'ขาวเน', 'AMNACH', 'KAWNE', '1', '-', '-', '-', '-', 't0010', '5b520dd55ccf7c3a', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '-', '-', 0, '-', '-', '-', '-', '-', '-', 0, '-', '-', '-', '-');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `plan`
-- 

CREATE TABLE `plan` (
  `plan_id` varchar(1) NOT NULL COMMENT 'รหัสของโปรแกรมการศึกษา',
  `plan_name` varchar(50) NOT NULL COMMENT 'ชื่อโปรแกรมการศึกษา',
  PRIMARY KEY  (`plan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `plan`
-- 

INSERT INTO `plan` VALUES ('1', 'โปรแกรมการศึกษาที่ 1 (หลักสูตร 4 ปี)');
INSERT INTO `plan` VALUES ('2', 'โปรแกรมการศึกษาที่ 2 (หลักสูตรเทียบโอน)');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `plansubject`
-- 

CREATE TABLE `plansubject` (
  `plan_id` varchar(1) NOT NULL COMMENT 'รหัสโปรแกรมการศึกษา',
  `scode` varchar(8) NOT NULL COMMENT 'รหัสวิชาเรียน',
  `pyear` varchar(1) NOT NULL COMMENT 'ปีที่',
  `term` varchar(1) NOT NULL COMMENT 'เทอมที่',
  PRIMARY KEY  (`plan_id`,`scode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `plansubject`
-- 

INSERT INTO `plansubject` VALUES ('1', '05010101', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '05300121', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '05300122', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '05100193', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '05100194', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '01001009', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '01001012', '1', '1');
INSERT INTO `plansubject` VALUES ('1', '05010102', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '05300123', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '05300124', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '01001008', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '01001010', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '01001011', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '01001013', '1', '2');
INSERT INTO `plansubject` VALUES ('1', '05010103', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072111', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072112', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072113', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072114', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072115', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072116', '2', '1');
INSERT INTO `plansubject` VALUES ('1', '01072117', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072118', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072119', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072120', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072121', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072122', '2', '2');
INSERT INTO `plansubject` VALUES ('1', '01072123', '3', '1');
INSERT INTO `plansubject` VALUES ('1', '01072124', '3', '1');
INSERT INTO `plansubject` VALUES ('1', '01072125', '3', '1');
INSERT INTO `plansubject` VALUES ('1', '01072126', '3', '2');
INSERT INTO `plansubject` VALUES ('1', '01072127', '3', '2');
INSERT INTO `plansubject` VALUES ('1', '01072128', '3', '2');
INSERT INTO `plansubject` VALUES ('1', '01072129', '3', '2');
INSERT INTO `plansubject` VALUES ('1', '01003001', '3', '3');
INSERT INTO `plansubject` VALUES ('1', '01072130', '4', '1');
INSERT INTO `plansubject` VALUES ('1', '01072131', '4', '2');
INSERT INTO `plansubject` VALUES ('2', '05010101', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01001012', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01072113', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01072114', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01072115', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01072116', '1', '1');
INSERT INTO `plansubject` VALUES ('2', '01072111', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072112', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072117', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072118', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072119', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072120', '1', '2');
INSERT INTO `plansubject` VALUES ('2', '01072121', '2', '1');
INSERT INTO `plansubject` VALUES ('2', '01072122', '2', '1');
INSERT INTO `plansubject` VALUES ('2', '01072123', '2', '1');
INSERT INTO `plansubject` VALUES ('2', '01072124', '2', '1');
INSERT INTO `plansubject` VALUES ('2', '01072125', '2', '1');
INSERT INTO `plansubject` VALUES ('2', '01072126', '2', '2');
INSERT INTO `plansubject` VALUES ('2', '01072127', '2', '2');
INSERT INTO `plansubject` VALUES ('2', '01072128', '2', '2');
INSERT INTO `plansubject` VALUES ('2', '01072129', '2', '2');
INSERT INTO `plansubject` VALUES ('2', '01072130', '3', '1');
INSERT INTO `plansubject` VALUES ('2', '01072131', '3', '2');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `relations_person`
-- 

CREATE TABLE `relations_person` (
  `relations_id` int(11) NOT NULL auto_increment COMMENT 'รหัสของพี่น้อง',
  `relations_name` varchar(50) default NULL COMMENT 'ชื่อนามสกุล',
  `relation_age` int(11) default NULL COMMENT 'อายุ',
  `relation_status` char(10) default NULL COMMENT 'ความสัมพันธ์',
  `relation_work` varchar(30) default NULL COMMENT 'อาชีพ',
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`relations_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `relations_person`
-- 

INSERT INTO `relations_person` VALUES (1, 'ชื่อ พี่น้อง', 30, 'น้อง', 'รับราชการ', 't0004');
INSERT INTO `relations_person` VALUES (2, 'ชื่อ พี่น้อง', 35, 'พี่', 'รับราชการ', 't0004');
INSERT INTO `relations_person` VALUES (3, '11111', 111, '11111', '1111', 't0004');
INSERT INTO `relations_person` VALUES (4, 'ชื่อ-นามสกุลพี่น้อง', 30, 'น้อง', 'นักการเมือง', 't0007');
INSERT INTO `relations_person` VALUES (5, 'ชื่อ-นามสกุลพี่น้อง', 1, 'น้อง', 'นักการเมือง', 't0007');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `reward_person`
-- 

CREATE TABLE `reward_person` (
  `reward_id` int(11) NOT NULL auto_increment COMMENT 'รหัสของรางวัลหรือทุนที่เคยได้รับ',
  `reward_name` varchar(100) default NULL COMMENT 'ชื่อรางวัลหรือทุนที่เคยได้รับ',
  `reward_from` varchar(100) default NULL COMMENT 'ได้รับจาก',
  `reward_date` date default NULL COMMENT 'วันที่',
  `reward_comm` varchar(100) default NULL COMMENT 'หมายเหตุ',
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`reward_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- dump ตาราง `reward_person`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `structure`
-- 

CREATE TABLE `structure` (
  `struct_id` varchar(2) NOT NULL COMMENT 'รหัสโครงสร้างหลักสูตร',
  `course_year` int(10) NOT NULL COMMENT 'ปีการศึกษา',
  `detail` text NOT NULL COMMENT 'คำอธิบายโครงสร้างหลักสูตรปริญญาตรี',
  `program_unit1` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 1',
  `program_unit2` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตตลอดหลักสูตรของโปรแกรมการศึกษาที่ 2',
  PRIMARY KEY  (`struct_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `structure`
-- 

INSERT INTO `structure` VALUES ('1', 2545, 'การจัดการศึกษาแบ่งเป็นสองหลักสูตรตามพื้นฐานการศึกษาของนักศึกษา ในกรณีของนักศึกษาที่จบการศึกษาในระดับมัธยมศึกษาชั้นปีที่ 6 หรือเทียบเท่าใช้หลักสูตร 4 ปี ส่วนนักศึกษาที่มีพื้นฐานการศึกษาในระดับประกาศนียบัติวิชาชีพชั้นสูงจะใช้หลักสูตรเทียบโอนที่ใช้เวลาการศึกษา 3 ถึง 4 ปี', 141, 107);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `student`
-- 

CREATE TABLE `student` (
  `student_id` varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  `citizen_id` varchar(13) default NULL COMMENT 'หมายเลขประจำตัวประชาชน',
  `pre_name` varchar(10) default NULL COMMENT 'คำนำหน้าชื่อ',
  `gender` varchar(10) default NULL,
  `th_name` varchar(50) NOT NULL COMMENT 'ชื่อภาษาไทย',
  `th_surname` varchar(50) NOT NULL COMMENT 'นามสกุลภาษาไทย',
  `en_name` varchar(30) default NULL COMMENT 'ชื่อภาษาอังกฤษ',
  `en_surname` varchar(30) default NULL COMMENT 'นามสกุลภาษาอังกฤษ',
  `semester` int(11) NOT NULL COMMENT 'ปีการศึกษา',
  `username` varchar(20) default NULL COMMENT 'ชื่อล็อกอิน',
  `password` varchar(20) default NULL COMMENT 'รหัสล็อกอิน',
  `birthday` date default NULL COMMENT 'วันเกิด',
  `birth_place` varchar(50) default NULL COMMENT 'จังหวัดที่เกิด',
  `race` char(20) default NULL COMMENT 'เชื้อชาติ',
  `nationality` char(20) default NULL COMMENT 'สัญชาติ',
  `religion` char(20) default NULL COMMENT 'ศาสนา',
  `blood` char(10) default NULL COMMENT 'หมู่โลหิต',
  `number_static` varchar(10) default NULL COMMENT 'บ้านเลขที่ ตามทะเบียนบ้าน',
  `group_static` varchar(5) default NULL COMMENT 'หมู่ที่ ตามทะเบียนบ้าน',
  `lane_static` varchar(50) default NULL COMMENT 'ตรอก/ซอย ตามทะเบียนบ้าน ',
  `road_static` varchar(50) default NULL COMMENT 'ถนน ตามทะเบียนบ้าน',
  `district_static` varchar(50) default NULL COMMENT 'ตำบล/แขวง ตามทะเบียนบ้าน',
  `region_static` varchar(50) default NULL COMMENT 'อำเภอ/เขต ตามทะเบียนบ้าน',
  `province_static` varchar(2) default NULL COMMENT 'จังหวัด ตามทะเบียนบ้าน',
  `postalcode_static` varchar(5) default NULL COMMENT 'รหัสไปรษณีย์ ตามทะเบียนบ้าน',
  `telephone_static` varchar(10) default NULL COMMENT 'โทรศัพท์ ตามทะเบียนบ้าน',
  `number_contact` varchar(10) default NULL COMMENT 'บ้านเลขที่ ที่ติดต่อได้',
  `group_contact` varchar(5) default NULL COMMENT 'หมู่ที่ ที่ติดต่อได้ ',
  `lane_contact` varchar(50) default NULL COMMENT 'ตรอก/ซอย ที่ติดต่อได้ ',
  `road_contact` varchar(50) default NULL COMMENT 'ถนน ที่ติดต่อได้ ',
  `district_contact` varchar(50) default NULL COMMENT 'ตำบล/แขวง ที่ติดต่อได้ ',
  `region_contact` varchar(50) default NULL COMMENT 'อำเภอ/เขต ที่ติดต่อได้ ',
  `province_contact` varchar(2) default NULL COMMENT 'จังหวัด ที่ติดต่อได้ ',
  `postalcode_contact` varchar(5) default NULL COMMENT 'รหัสไปรษณีย์ ที่ติดต่อได้ ',
  `telephone_contact` varchar(10) default NULL COMMENT 'โทรศัพท์ ที่ติดต่อได้ ',
  `relatives` int(11) default NULL COMMENT 'นักศึกษาเป็นบุตรคนที่ในจำนวนพี่น้องบิดา-มารดาเดียวกัน ',
  `alive` int(11) default NULL COMMENT 'มีชีวิตอยู่',
  `studying` int(11) default NULL COMMENT 'อยู่ในระหว่างการศึกษา',
  `salary` int(11) default NULL COMMENT 'รายได้จากการทำงาน',
  `exam_pattern` char(20) default NULL COMMENT 'รูปแบการสอบผ่านทบวงมหาวิทยาลัย',
  `exam1` char(20) default NULL COMMENT 'การดำเนินการจัดสอบ/คัดเลือกหลักสูตร4-5ปี ',
  `habital` char(50) default NULL COMMENT 'อาศัยอยู่กับ',
  `status_parent` char(50) default NULL COMMENT 'สถานภาพสมรสของบิดา-มารดา',
  `education_status` char(1) default NULL COMMENT 'สถานะการจบการศึกษา (ม.6 – สอบเทียบ-ปวส) ',
  `fin_school` varchar(100) default NULL COMMENT 'สำเร็จการศึกษาจากโรงเรียน',
  `fin_province` varchar(50) default NULL COMMENT 'สำเร็จการศึกษาจากจังหวัด',
  `fin_year` int(11) default NULL COMMENT 'สำเร็จการศึกษาในปีการศึกษา',
  `fin_gpa` float default NULL COMMENT 'สำเร็จการศึกษาระดับคะแนนเฉลี่ยสะสม',
  `before_year` int(11) default NULL COMMENT 'ปีที่เคยเป็นนักศึกษาของสถาบันฯมาก่อน',
  `before_univ` varchar(100) default NULL COMMENT 'ชื่อมหาวิทยาลัย/สถาบันฯที่เคยศึกษามาก่อน ',
  `before_yuniv` int(11) default NULL COMMENT 'ปีการศึกษามหาวิทยาลัย/สถาบันฯที่เคยศึกษามาก่อน ',
  `s_parent` varchar(20) default NULL COMMENT 'ผู้ปกครอง',
  `sm_parent` varchar(20) default NULL COMMENT 'แหล่งอุดหนุนการศึกษา',
  PRIMARY KEY  (`student_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `student`
-- 

INSERT INTO `student` VALUES ('47015323', '1234567891234', 'นาย', 'ชาย', 'ธีระยุทธ', 'แสนหอม', 'TEERAYUTH', 'SANHOM', 2545, '47015323', '798ca9c76335054e', '1963-12-30', '28', 'จีน', 'จีน', 'คริสต์', 'ไม่มี', '47', '10', '-', '-', 'เมืองเก่า', 'เมือง', '6', '40000', '043324869', '124/53', '2', 'อ่อนนุช12', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10200', '021458795', 1, 2, 1, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'โรงแรม', 'แยกกันอยู่เพราะความจำเป็นทางอาชีพ', '3', 'สถาบันเทคโนโลยีราชมงคล', '33', 2534, 2.12, 2469, 'มหิดล', 2474, 'ลุง', 'ญาติ');
INSERT INTO `student` VALUES ('47015312', '1234567891234', 'นาย', 'ชาย', 'คมสัน', 'นาคนาวา', 'KOMSON', 'NAKNAWA', 2545, '47015312', '798ec62963318097', '1911-04-11', '5', 'ไทย', 'ไทย', 'อิสลาม', 'A', '12', '10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บ้านเช่า/ห้องเช่า', 'อยู่ด้วยกัน', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา');
INSERT INTO `student` VALUES ('47015328', '1234567890321', 'นาย', 'ชาย', 'ศรราม', 'เทพพิทักษ์', 'SONRAM', 'TAPPITAK', 2547, '47015328', '798ca2106334fb97', '1984-02-14', '1', 'ไทย', 'ไทย', 'พุทธ', 'B', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', '879', '2', '-', '-', 'สุรศักดิ์', 'ศรีราชา', '9', '20200', '038-987987', 1, 2, 2, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'หอพักเอกชน', 'อยู่ด้วยกัน', '3', 'stamford technical collage', '1', 2546, 3.5, NULL, NULL, NULL, 'บิดา-มารดา', 'บิดา-มารดา');
INSERT INTO `student` VALUES ('48015001', '3242351265346', 'นางสาว', 'หญิง', 'รัตนาภรณ์', 'อนุรัตนวงศ์', 'RATTANAPORN', 'ANURATTANAWONG', 2548, '48015001', '2e629c294295c2ae', '1985-05-25', '13', 'ไทย', 'ไทย', 'พุทธ', 'AB', '276', '3', '-', '-', 'ยางเนิ้ง', 'สารภี', '13', '50150', NULL, '32', '2', 'เกกีงาม1', NULL, 'ลาดกระบัง', 'ลาดกระบัง', '1', '20200', NULL, 3, 4, 2, 0, 'หลักสูตรปกติ', 'ต่อเนื่องปกติ', 'บิดา-มารดา', 'อยู่ด้วยกัน', '3', 'วิทยาลัยเทคนิคเชียงใหม่', NULL, NULL, NULL, NULL, NULL, NULL, 'มารดา', 'บิดา-มารดา');
INSERT INTO `student` VALUES ('49015001', '1253453645745', 'นาย', 'ชาย', 'เอกราช', 'สมวงศ์', 'AKERACH', 'SOMWONG', 2549, '49015001', '033423ca3eda4e51', '1985-04-23', '13', 'ไทย', 'ไทย', 'คริสต์', 'AB', '82/10 ', '4', '-', 'ศรีธรรมไตรปิฏก', '-', 'เมือง', '38', '65000', '0897676545', '76', '1', 'ริมสวน', 'อ่อนนุช', 'ลาดกระบัง', 'ลาดกระบัง', '1', '10320', '0897676545', 1, 1, 1, 0, 'หลักสูตรปกติ', 'หลักสูตรปกติ', 'หอพักเอกชน', 'อยู่ด้วยกัน', '1', 'พิษณุโลกราชูทิศ', '38', 2546, 2.43, NULL, NULL, NULL, 'บิดา', 'ทุนการศึกษา');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `subject`
-- 

CREATE TABLE `subject` (
  `scode` varchar(8) NOT NULL COMMENT 'รหัสวิชา',
  `th_name` varchar(100) NOT NULL COMMENT 'ชื่อวิชาภาษาไทย',
  `en_name` varchar(100) NOT NULL COMMENT 'ชื่อวิชาภาษาอังกฤษ',
  `unit` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตทั้งหมด',
  `unit_d` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตบรรยาย',
  `unit_o` int(11) NOT NULL COMMENT 'จำนวนหน่วยกิตปฏิบัติ',
  `unit1` int(11) NOT NULL COMMENT 'หน่วยกิตรวมของโปรแกรมที่2',
  `unit_d1` int(11) NOT NULL COMMENT 'หน่วยกิตทฤษฎีของโปรแกรมที่2',
  `unit_o1` int(11) NOT NULL COMMENT 'หน่วยกิตปฏิบัติของโปรแกรมที่2',
  `scode_to` varchar(50) default NULL COMMENT 'รหัสวิชาบังคับก่อน',
  `sdetail` text COMMENT 'คำอธิบายรายวิชา',
  `url` varchar(100) default NULL COMMENT 'URL ใช้ลิงค์ไปยังโฮมเพจรายวิชา',
  `gsubject_id` varchar(2) NOT NULL,
  PRIMARY KEY  (`scode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `subject`
-- 

INSERT INTO `subject` VALUES ('03100001', 'เศรษฐศาสตร์เบื้องต้น', 'INTRODUCTION TO ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100002', 'เศรษฐศาสตร์อุตสาหกรรม', 'INDUSTRIAL ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100003', 'เศรษฐศาสตร์อุตสาหกรรม', 'INDUSTRIAL ECONOMICS', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES (' 0310000', 'การเงินและการธนาคาร', 'MONEY AND BANKING', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100005', 'เศรษฐศาสตร์ผู้บริโภค', 'Consumer Economics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100006', 'เศรษฐศาสตร์อุตสาหกรรม', 'Industrial Economics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES (' 0310002', 'หลักการตลาด', ' Principles of Marketing', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100022', 'พฤติกรรมผู้บริโภค', 'Consumer Behaviour', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100031', 'การบริหารธุรกิจ ', 'Business Administration', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100032', 'การบริหารอุตสาหกรรม', ' Industrial Management, Industrial and Administration', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100033', 'การจัดองค์การและการบริหารทั่วไป', 'Organization and General Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100034', 'การบริหารอุตสาหกรรม', 'Industrial Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100035', 'การบริหารงานบุคคล', 'Personnel Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100037', 'การบริหารการเงิน', 'Financial Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100038', 'การจัดการธุรกิจขนาดย่อม', 'Small Business Management', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100051', 'หลักการบัญชี', 'Principles of Accounting', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100061', 'ความรู้เบื้องต้นเกี่ยวกับกฎหมายทั่วไป', 'Introduction to the Studies of Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100062', 'กฎหมายแพ่งและพาณิชย์', 'Civil and Commercial Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100063', 'กฎหมายแรงงาน', 'Labour Laws', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03100064', 'กฎหมายแรงงานและ พ.ร.บ.วิชาชีพวิศวกรรม', 'Labour Laws and the Engineering Profession Act', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '1');
INSERT INTO `subject` VALUES ('03150001', 'ปรัชญาพื้นฐาน', 'Fundamental Philosophy', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO `subject` VALUES ('03150002', 'ปรัชญาวิทยาศาสตร์', 'Philosophy of Science', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO `subject` VALUES ('03150003', 'พุทธปรัชญา', 'Philosophy of Buddhism', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO `subject` VALUES ('03150004', 'สุนทรียศาสตร์', 'Aesthetics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO `subject` VALUES ('03150005', 'จริยศาสตร์และสุนทรียศาสตร์', 'Ethics and Aesthetics', 2, 2, 0, 0, 0, 0, NULL, NULL, NULL, '2');
INSERT INTO `subject` VALUES ('03010026', 'ภาษาอังกฤษพื้นฐาน 1', 'Foundation English 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO `subject` VALUES ('03010027', 'ภาษาอังกฤษพื้นฐาน 2', 'Foundation English 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO `subject` VALUES ('03020001', 'ภาษาญี่ปุ่นพื้นฐาน 1', 'Elementary to Japanese 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO `subject` VALUES ('03020002', 'ภาษาญี่ปุ่นพื้นฐาน 2', 'Elementary to Japanese 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '3');
INSERT INTO `subject` VALUES ('01000010', 'ฟิสิกส์ทั่วไป 1', 'General Physics I', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('01000011', 'ปฏิบัติการฟิสิกส์ทั่วไป 1', 'General Physics Laboratory I', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('01000014', 'เคมีทั่วไป', 'General Chemistry', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('01000015', 'ปฏิบัติการเคมีทั่วไป', 'Practices in General Chemistry', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('01000001', 'คณิตศาสตร์ 1', 'Mathematics I', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('01000002', 'คณิตศาสตร์ 2', 'Mathematics II', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('01000003', 'คณิตศาสตร์ 3', 'Mathematics III', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('01001008', 'การทดลองทางวิศวกรรม', 'Engineering Practices', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01001009', 'เขียนแบบวิศวกรรม', 'Engineering Drawing', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01001010', 'กลศาสตร์วิศวกรรม', 'Engineering Mechanics', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01001011', 'วัสดุวิศวกรรม', 'Engineering Materials', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01001012', 'หลักการเขียนโปรแกรมคอมพิวเตอร์', 'Principle of Computer Programming', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01072001', 'การเขียนโปรแกรมคอมพิวเตอร์ 2', 'Computer Programming II', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072003', 'การออกแบบวงจรดิจิตอลและวงจรตรรก', 'Digital Circuit and Logic Design', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072004', 'ปฏิบัติการวงจรดิจิตอล', 'Digital Circuit Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072008', 'ปฏิบัติการโครงสร้างข้อมูลและอัลกอริทึม', 'Data Structure and Algorithm Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01073101', 'การออกแบบระบบดิจิตอลขั้นสูง', 'Advanced Digital System Design', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO `subject` VALUES ('01073102', 'ปฏิบัติการวงจรดิจิตอลขั้นสูง', 'Advanced Digital System Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO `subject` VALUES ('01073202', 'การพัฒนาซอฟต์แวร์ระบบ', 'System Software Development', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO `subject` VALUES ('01073301', 'ระบบเครือข่ายท้องถิ่น', 'Local Area Networks', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '8');
INSERT INTO `subject` VALUES ('01074107', 'การพัฒนาหุ่นยนต์ขนาดเล็ก', 'Micro Robot Development', 3, 1, 6, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO `subject` VALUES ('01074201', 'การเขียนโปรแกรมเครือข่าย', 'Network Programming', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO `subject` VALUES ('01074204', 'ปฏิบัติการเขียนโปรแกรมบนระบบยูนิกซ์ขั้นสูง', 'Advanced UNIX Programming Laboratory', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO `subject` VALUES ('01074220', 'ระบบฐานข้อมูลขั้นสูง', 'Advanced Database Systems', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '9');
INSERT INTO `subject` VALUES ('05010101', 'คณิตศาสตร์วิศวกรรม 1', 'ENGINEERING MATHEMATICS 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('05300121', 'ฟิสิกส์ทั่วไป 1', 'GENERAL PHYSICS 1', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('05100193', 'เคมีทั่วไป', 'GENERAL CHEMISTRY', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('05100194', 'ปฏิบัติการเคมีทั่วไป', 'PRACTICES IN GENERAL CHEMISTRY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('05300122', 'ปฏิบัติการฟิสิกส์ทั่วไป 1', 'GENERAL PHYSICS LABORATORY 1', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('05010102', 'คณิตศาสตร์วิศวกรรม 2', 'ENGINEERING MATHEMATICS 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('05300123', 'ฟิสิกส์ทั่วไป 2', 'GENERAL PHYSICS 2', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('05300124', 'ปฏิบัติการฟิสิกส์ทั่วไป 2', 'GENERAL PHYSICS LABORATORY 2', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '4');
INSERT INTO `subject` VALUES ('01001013', 'วิศวกรรมไฟฟ้า', 'ELECTRICAL ENGINEERING', 3, 3, 2, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('05010103', 'คณิตศาสตร์วิศวกรรม 3', 'ENGINEERING MATHEMATICS 3', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '5');
INSERT INTO `subject` VALUES ('01072111', 'การเขียนโปรแกรมคอมพิวเตอร์ 2', 'COMPUTER PROGRAMMING 2', 3, 3, 0, 0, 0, 0, '01001012', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072112', 'ปฏิบัติการโปรแกรมคอมพิวเตอร์ 2', 'COMPUTER PROGRAMMING LABORATORY 2', 1, 0, 3, 0, 0, 0, '01001012', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072113', 'การออกแบบวงจรดิจิตอลและวงจรตรรก', 'DIGITAL CIRCUIT AND LOGIC DESIGN', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072114', 'ปฏิบัติการวงจรดิจิตอล', 'DIGITAL CIRCUIT LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072115', 'อิเล็กทรอนิกส์พื้นฐานสำหรับวิศวกรรมคอมพิวเตอร์', 'BASIC ELECTRONICS FOR COMPUTER ENGINEER', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072116', 'ปฏิบัติการวิศวกรรมคอมพิวเตอร์', 'COMPUTER ENGINEERING LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072117', 'โครงสร้างข้อมูลและอัลกอริธึม', 'DATA STRUCTURE AND ALGORITHM', 3, 3, 0, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072118', 'ปฏิบัติการโครงสร้างข้อมูลและอัลกอริธึม', 'DATA STRUCTURE AND ALGORITHM LABORATORY', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072119', 'การสื่อสารข้อมูล', 'DATA COMMUNICATION', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072120', 'ปฏิบัติการสื่อสารข้อมูล', 'DATA COMMUNICATION LABORATORY', 1, 0, 3, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072121', 'องค์ประกอบคอมพิวเตอร์และภาษาแอสเซมบลี', 'COMPUTER ORGANIZATION AND ASSEMBLY LANGUAGE', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072122', 'ปฏิบัติการภาษาแอสเซมบลี', 'ASSEMBLY LANGUARE LABORATORY', 1, 0, 3, 0, 0, 0, '1072113', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072123', 'ทฤษฎีการคำนวณ', 'THEORY OF COMPUTATION', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072124', 'สถาปัตยกรรมคอมพิวเตอร์', 'COMPUTER ARCHITECTURE', 3, 3, 0, 0, 0, 0, '01072113', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072125', 'เครือข่ายคอมพิวเตอร์', 'COMPUTER NETWORK', 3, 3, 0, 0, 0, 0, '01072119', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072126', 'ระบบปฏิบัติการ', 'OPERATING SYSTEMS', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072127', 'ระบบฐานข้อมูล', 'DATABASE SYSTEMS', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072128', 'วิศวกรรมซอฟต์แวร์', 'SOFTWARE ENGINEERING', 3, 3, 0, 0, 0, 0, '01072117', NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072129', 'โครงงานคอมพิวเตอร์', 'COMPUTER PROJECT', 1, 0, 3, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01003001', 'การฝึกงานอุตสาหกรรมภาคฤดูร้อน', 'Industrial Training in Summer', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, '6');
INSERT INTO `subject` VALUES ('01072130', 'โครงงาน 1', 'PROJECT 1', 3, 0, 9, 0, 0, 0, NULL, NULL, NULL, '7');
INSERT INTO `subject` VALUES ('01072131', 'โครงงาน 2', 'PROJECT 2', 3, 0, 9, 0, 0, 0, '01072130', NULL, NULL, '7');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tool`
-- 

CREATE TABLE `tool` (
  `toolid` varchar(10) NOT NULL COMMENT 'รหัสอุปกรณ์',
  `toolname` varchar(50) NOT NULL COMMENT 'ชื่ออุปกรณ์',
  `price` int(11) default NULL COMMENT 'ราคา',
  `amount` int(11) default NULL COMMENT 'จำนวน',
  `tdate` date NOT NULL COMMENT 'วันที่ซื้อ',
  `brand` varchar(50) NOT NULL COMMENT 'ยี่ห้อ',
  `cid` int(11) default NULL COMMENT 'รหัสบริษัทของอุปกรณ์',
  PRIMARY KEY  (`toolid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `tool`
-- 

INSERT INTO `tool` VALUES ('48CE203001', 'ลำโพง NPE V-ST 302BT', 1000, 1, '2007-01-01', 'NPE', 1);
INSERT INTO `tool` VALUES ('48CE203002', 'ลำโพง NPE V-ST 302BT', 1000, 1, '2007-01-01', 'NPE', NULL);
INSERT INTO `tool` VALUES ('48CE203003', 'ลำโพง NPE V-ST 302BT', 1000, 1, '2007-01-01', 'NPE', 2);
INSERT INTO `tool` VALUES ('48CE203004', 'ลำโพง NPE V-ST 302BT', 1000, 1, '2007-01-01', 'NPE', 1);
INSERT INTO `tool` VALUES ('48CE203005', 'เครื่องขยายเสียง NPE PN48', 5000, 1, '2007-01-01', 'NPE', NULL);
INSERT INTO `tool` VALUES ('48CE203006', 'เครื่องขยายเสียง NPE PN48', 5000, 1, '2007-01-01', 'NPE', 3);
INSERT INTO `tool` VALUES ('48CE203007', 'เครื่องขยายเสียง NPE PN48', 5000, 1, '2007-01-01', 'NPE', 3);
INSERT INTO `tool` VALUES ('48CE203008', 'Wireless Microphone SB-51 VHB', 5000, 1, '2007-01-01', 'SB', 1);
INSERT INTO `tool` VALUES ('48CE203009', 'Wireless Microphone SB-51 VHB', 5000, 1, '2007-01-01', 'SB', 2);
INSERT INTO `tool` VALUES ('48CE203010', 'ปลั๊กพ่วงแบบกลม', 180, 1, '2007-01-01', 'KPV', NULL);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tool_company`
-- 

CREATE TABLE `tool_company` (
  `cid` int(11) NOT NULL auto_increment COMMENT 'รหัสบริษัทของอุปกรณ์',
  `cname` varchar(50) NOT NULL COMMENT 'ชื่อบริษัท',
  `address` varchar(100) default NULL COMMENT 'ที่อยู่',
  `phone` varchar(15) default NULL COMMENT 'หมายเลขโทรศัพท์',
  `fax` varchar(15) default NULL COMMENT 'หมายเลขแฟก',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `tool_company`
-- 

INSERT INTO `tool_company` VALUES (1, 'บริษัท EDL จำกัด', '17/86-87 หมู่ที่ 10 ถนน ลาดพร้าว-วังหิน แขวงลาดพร้าว เขตลาดพร้าว กรุงเทพ มหานคร 10230', '0-22936-8', '-');
INSERT INTO `tool_company` VALUES (2, 'บริษัท ELECTRONICS SOURCE CO.,LTD.', '17/86-87 หมู่ที่ 10 ถนน ลาดพร้าว-วังหิน แขวงลาดพร้าว เขตลาดพร้าว กรุงเทพ มหานคร 10230', '0-22936-8', 'ทดสอบการเปลี่ยน');
INSERT INTO `tool_company` VALUES (3, 'บริษัท ไทยอิเล็กทรอนิกส์ จำกัด', '17/86-87 หมู่ที่ 10 ถนน ลาดพร้าว-วังหิน แขวงลาดพร้าว เขตลาดพร้าว กรุงเทพ มหานคร 10230', '0236598-9', '0254318-9');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tool_sborrow`
-- 

CREATE TABLE `tool_sborrow` (
  `bid` int(11) NOT NULL auto_increment COMMENT 'ลำดับการยืม',
  `student_id` varchar(8) NOT NULL COMMENT 'รหัสนักศึกษา',
  `toolid` varchar(10) NOT NULL COMMENT 'รหัสอุปกรณ์',
  `bdate` date NOT NULL COMMENT 'วันที่ยืม',
  `total` int(11) NOT NULL COMMENT 'จำนวนอุปกรณ์',
  `status` varchar(1) NOT NULL COMMENT 'สถานะการยืม',
  `comment` text COMMENT 'หมายเหตุ',
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

-- 
-- dump ตาราง `tool_sborrow`
-- 

INSERT INTO `tool_sborrow` VALUES (21, '47015323', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (20, '47015323', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (19, '47015323', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (18, '47015323', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของนักศึกษา');
INSERT INTO `tool_sborrow` VALUES (17, '47015323', '48CE203008', '2007-01-07', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (16, '47015323', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (15, '47015323', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (14, '47015323', '48CE203008', '2007-01-07', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (22, '47015323', '48CE203008', '2007-01-07', 1, '1', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (23, '47015323', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของนักศึกษา');
INSERT INTO `tool_sborrow` VALUES (31, '47015323', '48CE203008', '2007-01-08', 1, '0', 'ตารางเก็บข้อมูลของนักศึกษา');
INSERT INTO `tool_sborrow` VALUES (30, '47015323', '48CE203008', '2007-01-08', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (26, '47015312', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (27, '47015312', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (28, '47015312', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (29, '47015312', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (32, '47015323', '48CE203008', '2007-01-08', 10, '0', 'ตารางเก็บข้อมูลของนักศึกษา');
INSERT INTO `tool_sborrow` VALUES (33, '47015323', '48CE203008', '2007-01-08', 90, '0', '90');
INSERT INTO `tool_sborrow` VALUES (34, '47015323', '48CE203008', '2007-01-08', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (35, '47015323', '48CE203008', '2007-01-08', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (36, '47015312', '48CE203008', '2007-01-08', 1, '1', NULL);
INSERT INTO `tool_sborrow` VALUES (37, '47015312', '48CE203001', '2007-01-08', 1, '1', NULL);
INSERT INTO `tool_sborrow` VALUES (38, '47015312', '48CE203002', '2007-01-08', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (39, '47015312', '48CE203010', '2007-01-08', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (40, '47015312', '48CE203009', '2007-01-08', 1, '1', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_sborrow` VALUES (41, '47015323', '48CE203009', '2007-01-09', 1, '1', NULL);
INSERT INTO `tool_sborrow` VALUES (42, '47015323', '48CE203009', '2007-01-09', 1, '1', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (43, '47015312', '48CE203001', '2007-01-09', 1, '1', NULL);
INSERT INTO `tool_sborrow` VALUES (44, '47015312', '48CE203004', '2007-01-11', 1, '0', NULL);
INSERT INTO `tool_sborrow` VALUES (45, '47015323', '48CE203010', '2007-01-11', 1, '1', 'ทดสอบ');
INSERT INTO `tool_sborrow` VALUES (46, '47015312', '48CE203008', '2007-01-13', 1, '1', '90');
INSERT INTO `tool_sborrow` VALUES (47, '47015312', '48CE203008', '2007-01-14', 1, '1', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_sborrow` VALUES (48, '47015323', '48CE203009', '2007-01-16', 1, '1', NULL);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tool_tborrow`
-- 

CREATE TABLE `tool_tborrow` (
  `bid` int(11) NOT NULL auto_increment COMMENT 'ลำดับการยืม',
  `person_id` varchar(13) NOT NULL COMMENT 'รหัสนักศึกษา',
  `toolid` varchar(10) NOT NULL COMMENT 'รหัสอุปกรณ์',
  `bdate` date NOT NULL COMMENT 'วันที่ยืม',
  `total` int(11) NOT NULL COMMENT 'จำนวนอุปกรณ์',
  `status` varchar(1) NOT NULL COMMENT 'สถานะการยืม',
  `comment` text COMMENT 'หมายเหตุ',
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- dump ตาราง `tool_tborrow`
-- 

INSERT INTO `tool_tborrow` VALUES (1, 't0004', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของนักศึกษา');
INSERT INTO `tool_tborrow` VALUES (2, 't0004', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_tborrow` VALUES (3, 't0004', '48CE203008', '2007-01-07', 1, '0', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_tborrow` VALUES (4, 't0004', '48CE203008', '2007-01-07', 1, '0', 'ตารางเก็บข้อมูลของหนังสือ');
INSERT INTO `tool_tborrow` VALUES (5, 't0004', '48CE203008', '2007-01-07', 1, '1', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_tborrow` VALUES (6, 't0004', '48CE203008', '2007-01-08', 1, '1', 'สวัสดีค๊าบบบ');
INSERT INTO `tool_tborrow` VALUES (7, 't0004', '48CE203008', '2007-01-08', 1, '1', 'ตารางเก็บข้อมูลของนักศึกษา');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `training_person`
-- 

CREATE TABLE `training_person` (
  `training_id` int(11) NOT NULL auto_increment COMMENT 'รหัสของประวัติการดูงานหรือฝึกอบรม',
  `training_name` varchar(100) default NULL COMMENT 'ชื่อประวัติการดูงานหรือฝึกอบรม',
  `training_place` varchar(100) default NULL COMMENT 'สถานที่',
  `training_date` date default NULL COMMENT 'วันที่',
  `training_comm` varchar(100) default NULL COMMENT 'หมายเหตุ',
  `person_id` varchar(5) NOT NULL COMMENT 'รหัสประจำตัว',
  PRIMARY KEY  (`training_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `training_person`
-- 

