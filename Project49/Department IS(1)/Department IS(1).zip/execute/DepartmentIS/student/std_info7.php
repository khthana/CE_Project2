<?
include("_CheckSession.php"); 
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س <?=$personname?> &nbsp;<?=$personlastname?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? 
									include ("_menu.php") ;
									 include ("_sql_info7.php");									
									?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="right">&nbsp;<a href="std_info7_edit.php">���</a></div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><STRONG>�͹��� 
                                                    3 ����ѵԺԴ�-��ô� ��黡��ͧ 
                                                    ��м���ػ���д�ҹ����Թ</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD align=left width=750 
      height=20>&nbsp;<STRONG>�����Թ�ش˹ع����֡�Ңͧ��ҹ��ҡ</STRONG><BR> 
                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            1. 
                                            <INPUT name=sponsor  type=radio id=sponsor value="�Դ�-��ô�" disabled <?=$sm_parent1?>>
                                            �Դ�-��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            2. 
                                            <INPUT id=sponsor  
      type=radio value="�Դ�" name=sponsor disabled <?=$sm_parent2?>>
                                            �Դ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            3. 
                                            <INPUT id=sponsor  type=radio value="��ô�" name=sponsor disabled <?=$sm_parent3?>>
                                            ��ô� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            4. 
                                            <INPUT id=sponsor  type=radio value="��黡��ͧ" name=sponsor disabled <?=$sm_parent4?>>
                                            ��黡��ͧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            5. 
                                            <INPUT id=sponsor 
       type=radio value="����ػ����" name=sponsor disabled <?=$sm_parent5?>>
                                            ����ػ���� <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            6. 
                                            <INPUT id=sponsor  type=radio value="�ҵ�" name=sponsor disabled <?=$sm_parent6?>>
                                            �ҵ� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            7. 
                                            <INPUT id=sponsor  type=radio value="�ӧҹ" name=sponsor disabled <?=$sm_parent7?>>
                                            �ӧҹ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            8. 
                                            <INPUT id=sponsor  type=radio value="�ع����֡��" name=sponsor  disabled <?=$sm_parent8?>>
                                            �ع����֡�� &nbsp;&nbsp;&nbsp;&nbsp; 
                                            9. 
                                            <INPUT id=sponsor  type=radio value="������" 
      name=sponsor  disabled <?=$sm_parent9?>>
                                            ������ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                            10. 
                                            <INPUT id=sponsor  type=radio value="other" name=sponsor  disabled <?=$sm_parent10?>>
                                            ���� (�к�)&nbsp;:&nbsp; <INPUT name=sponsor2 value="<?=$sm_parentstatus?>" size=16  maxLength=32 disabled> 
                                          </TD>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=1>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
            height=24>&nbsp;<STRONG>����ػ���д�ҹ����Թ�ͧ�ѡ�֡��</STRONG></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE cellSpacing=0 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;�óշ�����ػ���д�ҹ����Թ�ͧ�ѡ�֡��������ҧ����繹ѡ�֡�ҢͧʶҺѹ� 
                                                    <STRONG>����</STRONG>� �Դ�-��ô� 
                                                    ���ͧ ���ͺؤ�����ǡѺ��黡��ͧ 
                                                    (����к���������´) </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.29</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=o_name id=name3 value="<?=$name_parent?>" size=24  
            maxLength=25 disabled> &nbsp;&nbsp;<STRONG>���ʡ��</STRONG>&nbsp; 
                                                    <INPUT name=o_surname id=surname3 value="<?=$surname_parent?>" size=24  
            maxLength=25 disabled> &nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=o_age id=age3 value="<?=$age_parent?>" size=2  
            maxLength=2 disabled > &nbsp;�� &nbsp;&nbsp;<STRONG>����Ǣ�ͧ�Ѻ�ѡ�֡����</STRONG>&nbsp; 
                                                    <INPUT name=o_relationship 
            id=relationship2 value="<?=$relationship?>" size=16  maxLength=25 disabled> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.30</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>���ͪҵ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=o_race  type=radio id=radio16 value="��" disabled  <?=$race_parent1?> >
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT 
            id=radio16  type=radio value="�չ" name=o_race disabled <?=$race_parent2?>> 
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio16 
             type=radio value="other" name=o_race disabled <?=$race_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=o_race22 value="<?=$race_parentstatus?>" size=14  maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѭ�ҵ�</STRONG> 
                                                    &nbsp;&nbsp; <INPUT name=o_citizen  type=radio 
            id=radio17 value="��"  disabled <?=$nationality_parent1?>>
                                                    �� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio17  
            type=radio value="�չ"  disabled name=o_citizen <?=$nationality_parent2?>>
                                                    �չ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT id=radio17  
            type=radio value="other"  name=o_citizen  disabled <?=$nationality_parent3?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=o_citizen22 value="<?=$nationality_parentstatus?>" size=14 
             maxLength=20 disabled ></TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.31</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>��ʹ�</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. 
                                                    <INPUT 
            name=o_religion  type=radio id=radio18 value="�ط�"  disabled <?=$religion_parent1?>>
                                                    �ط� &nbsp;&nbsp;2. 
                                                    <INPUT id=radio18  
            type=radio value="���ʵ�" name=o_religion  disabled <?=$religion_parent2?>>
                                                    ���ʵ� &nbsp;3. 
                                                    <INPUT id=radio18 
             type=radio value="������" name=o_religion  disabled <?=$religion_parent3?>>
                                                    ������ &nbsp;&nbsp;4. 
                                                    <INPUT id=radio18  type=radio value="other"
            name=o_religion  disabled <?=$religion_parent4?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=o_religion22 value="<?=$religion_parentstatus?>" 
            size=16  maxLength=20 disabled > </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20 >&nbsp;<STRONG>3.32</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�����Ţ��Шӵ�ǻ�ЪҪ�</STRONG>&nbsp;&nbsp; 
                                                    <INPUT name=o_id 
            id=id4 value="<?=$citizenid_parent?>" size=16  maxLength=13 disabled> </TD>
                                                </TR>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.33</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�������Ѩ�غѹ</STRONG> 
                                                    &nbsp;&nbsp;&nbsp;<STRONG>��ҹ�Ţ���</STRONG>&nbsp; 
                                                    <input name=o_homeno value="<?=$number_parent?>" size=5  
            maxlength=10 disabled> &nbsp;&nbsp;&nbsp;<STRONG>����</STRONG>&nbsp; 
                                                    <INPUT name=o_moo value="<?=$group_parent?>" size=2  
            maxLength=2 disabled> &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>��͡/���</STRONG>&nbsp; 
                                                    <INPUT name=o_soi value="<?=$lane_parent?>" size=16 
             maxLength=20 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���</STRONG>&nbsp; 
                                                    <INPUT name=o_street value="<?=$road_parent?>" size=17  maxLength=20 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�Ӻ�/�ǧ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=o_tambon value="<?=$district_parent?>" size=21  maxLength=20 disabled> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�����/ࢵ</STRONG>&nbsp; 
                                                    <INPUT name=o_amphur value="<?=$region_parent?>" size=16  maxLength=20 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="o_province" id="o_province" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $province_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=o_zipcode value="<?=$postalcode_parent?>" size=10 
             maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    <INPUT name=o_telno value="<?=$tel_parent?>" size=16  maxLength=15 disabled> 
                                                  </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.34</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�ز��٧�ش�ͧ����ػ���д�ҹ����Թ</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=o_academic  type=radio id=radio19 value="��ж��֡��"  disabled <?=$educational_parent1?> >
                                                    ��ж��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio19  type=radio value="�Ѹ���֡��" 
            name=o_academic disabled  <?=$educational_parent2?>>
                                                    �Ѹ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio19  type=radio value="������ش��֡��" 
            name=o_academic disabled  <?=$educational_parent3?>>
                                                    ������ش��֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio19  type=radio value="�Ҫ���֡��" 
            name=o_academic  disabled <?=$educational_parent4?>>
                                                    �Ҫ���֡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT 
            id=radio19  type=radio value="͹ػ�ԭ��������º���" 
            name=o_academic  disabled <?=$educational_parent5?>>
                                                    ͹ػ�ԭ��������º��� <BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    6. 
                                                    <INPUT id=radio19  type=radio value="��ԭ�ҵ��" 
            name=o_academic  disabled <?=$educational_parent6?>>
                                                    ��ԭ�ҵ�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio19  type=radio value="��ԭ���"
            name=o_academic disabled  <?=$educational_parent7?>>
                                                    ��ԭ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio19  type=radio value="��ԭ���͡" 
            name=o_academic  disabled <?=$educational_parent8?>>
                                                    ��ԭ���͡ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT id=radio19  type=radio value="������ز�" 
            name=o_academic disabled  <?=$educational_parent9?>>
                                                    ������ز� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    10. 
                                                    <INPUT id=radio19  type=radio value="other"
            name=o_academic  disabled <?=$educational_parent10?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT name=o_academic2 value="<?=$educational_parentstatus?>" 
            size=16  maxLength=25 disabled> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.35</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>�Ҫվ�ͧ����ػ���д�ҹ����Թ</STRONG><BR> 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    1. 
                                                    <INPUT 
            name=o_occupation  type=radio id=radio20 value="�Ѻ�Ҫ���" disabled  <?=$work_parent1?>>
                                                    �Ѻ�Ҫ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    2. 
                                                    <INPUT id=radio20  type=radio value="��ѡ�ҹ�Ѱ����ˡԨ" 
            name=o_occupation  disabled <?=$work_parent2?>>
                                                    ��ѡ�ҹ�Ѱ����ˡԨ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    3. 
                                                    <INPUT id=radio20  
            type=radio value="��ѡ�ҹ�����١��ҧ�͡��" name=o_occupation  disabled <?=$work_parent3?>>
                                                    ��ѡ�ҹ�����١��ҧ�͡�� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    4. 
                                                    <INPUT id=radio20  type=radio value="��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң��"
            name=o_occupation  disabled <?=$work_parent4?>>
                                                    ��Ңͧ/��Сͺ��ø�áԨ��ǹ���/��Ң�� 
                                                    <BR> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    5. 
                                                    <INPUT id=radio20  type=radio value="�١��ҧ��ǹ�Ҫ���"
            name=o_occupation  disabled <?=$work_parent5?>>
                                                    �١��ҧ��ǹ�Ҫ��� &nbsp; 6. 
                                                    <INPUT id=radio20 
             type=radio value="�ɵá�/��ǻ����" name=o_occupation  disabled <?=$work_parent6?>>
                                                    �ɵá�/��ǻ���� &nbsp;&nbsp;&nbsp; 
                                                    7. 
                                                    <INPUT id=radio20  type=radio 
            value="�Ѻ��ҧ" name=o_occupation  disabled <?=$work_parent7?>>
                                                    �Ѻ��ҧ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    8. 
                                                    <INPUT id=radio20  type=radio value="����Сͺ�Ҫվ" 
            name=o_occupation  disabled <?=$work_parent8?>>
                                                    ����Сͺ�Ҫվ &nbsp;&nbsp;&nbsp; 
                                                    9. 
                                                    <INPUT 
            id=radio20  type=radio value="other" 
            name=o_occupation  disabled <?=$work_parent9?>>
                                                    ���� (�к�)&nbsp;:&nbsp; 
                                                    <INPUT 
            name=o_occupation2 value="<?=$work_parentstatus?>" size=16  
            maxLength=25 disabled  > </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.36</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����ʶҹ��Сͺ�Ҫվ</STRONG>&nbsp;&nbsp;&nbsp; 
                                                    <INPUT 
            name=o_workplace value="<?=$workplace_parent?>" size=24  maxLength=30 disabled>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>�ѧ��Ѵ</STRONG>&nbsp; 
                                                    <select name="o_workprovince" id="o_workprovince" disabled>
                                                      <?
														include("../resource/_array.php");
														 foreach (	$arrayprovince as $valueprovince => $province)
														{				
																if ($valueprovince == 0) {
																	$valueprovince = "";
																}
																if ($valueprovince == $provincework_parent){
																	$chk ="selected";
																	}		
																			
													  ?>
                                                      <option value="<?=$valueprovince?>" <?=$chk?>> 
                                                      <?=$province?>
                                                      </option>
                                                      <?
															$chk ="";
														}
														?>
                                                    </select> </TD>
                                                <TR> 
                                                  <TD align=left width=750 
            height=20>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                                                    &nbsp;&nbsp;&nbsp;&nbsp;<STRONG>������ɳ���</STRONG>&nbsp; 
                                                    <INPUT name=o_workzipcode value="<?=$postalcodework_parent?>" size=10 
             maxLength=5 disabled> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>���Ѿ��</STRONG>&nbsp; 
                                                    <INPUT 
            name=o_worktelno value="<?=$telwork_parent?>" size=16  maxLength=15 disabled> </TD>
                                                <TR> 
                                                  <TD align=left width=750 height=20>&nbsp;<STRONG>3.37</STRONG> 
                                                    &nbsp;&nbsp;<STRONG>����������/��͹�ͧ����ػ���д�ҹ����Թ</STRONG>&nbsp; 
                                                    1. 
                                                    <INPUT name=o_earn  type=radio id=radio21 value="N"  disabled <?=$salary_parent1?>>
                                                    ���������� &nbsp;&nbsp; 2. 
                                                    <INPUT id=radio21  type=radio value="Y "
            name=o_earn disabled  <?=$salary_parent2?>>
                                                    �� (�к�) �����&nbsp; <INPUT name=o_salary value="<?=$salary_parentstatus?>"  disabled size=7  maxLength=7> 
                                                    &nbsp;�ҷ/��͹ </TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD height=10><div align="right"><a href="std_info6.php">Back</a> 
                                              | <a href="std_info8.php">Next</a><br>
                                            </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
