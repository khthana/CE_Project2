<?
include("_CheckSession.php"); 
include ("_Startconnection.php");
include("../resource/_res_function.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<SCRIPT language=JavaScript 
src="CalendarPopup.js"></SCRIPT>

<SCRIPT language=JavaScript>
	var cal = new CalendarPopup();
	</SCRIPT>

<script type='text/javascript'>
</script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

<style type="text/css">
<!--
.style13 {font-weight: bold}
.style14 {font-weight: bold}
.style15 {font-weight: bold}
.style16 {font-weight: bold}
.style17 {font-weight: bold}
.style18 {font-weight: bold}
-->
</style>
</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� 
        <?=$position ?>
        <?=$personname ?>
        &nbsp; 
        <?=$personlastname ?>
      </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                      <? include ("_menu.php") ?>
                                    </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="right">&nbsp;&nbsp;&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">
								
								
								
								
								
								
								
								
								  <form name="form1" method="post" action="teacher_info8_add_ok.php">
								<TABLE width=750 border=0 align="center" cellPadding=2 cellSpacing=0>
                                      <TBODY>
                                        <TR> 
                                          <TD bgColor=#f8f8f8><TABLE width=750 height="30" border=1 cellPadding=0 cellSpacing=0>
                                              <TBODY>
                                                <TR> 
                                                  <TD align=middle width=750 height=24><div align="center"><STRONG>���ҧ�����šԨ�����ҧ�Ԫҡ��</STRONG></div></TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE></TD>
                                        </TR>
                                        <TR> 
                                          <TD valign="top" bgColor=#f8f8f8><TABLE cellSpacing=2 cellPadding=0 width=750 border=0>
                                              <TBODY>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=30 colspan="4" align=left><div align="center"></div>
                                                    <div align="center"></div>
                                                    <div align="center"></div>
                                                    <div align="center"><strong>���͢����šԨ�����ҧ�Ԫҡ��</strong></div></TD>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=20 colspan="4" align=left><table width="747" height="98" border="1">
                                                        <tr> 
                                                          <td width="36" height="24" class="style13"><div align="center">�ӴѺ</div></td>
                                                          <td width="152"><strong>����</strong></td>
                                                          <td width="254"><strong>˹��§ҹ</strong></td>
                                                          <td width="58"><strong>�ѹ���</strong></td>
                                                          <td width="145"><strong>�����˵�</strong></td>
                                                        </tr>
                                                        <?
													  $count =1;
													  $sql = "select * from activity_person where person_id = '$person_id' ";
													//  print $sql;
													  $table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");
			while ($row = mysql_fetch_array($table))
			{
					$activity_id = $row[activity_id];
					$activity_name = $row[activity_name];
					$activity_place = $row[activity_place];
					$activity_date = $row[activity_date];
					$th_date  = convert_thai_date_db($activity_date) ; //���¡�ѧ���� �ҡ��� resource 
					$activity_comm = $row[activity_comm];
					
												  
													  ?>
                                                        <tr> 
                                                          <td height="32" class="style13"> 
                                                            <?=$count?>
                                                          </td>
                                                          <td> 
                                                            <?=$activity_name?>
                                                          </td>
                                                          <td> 
                                                            <?=$activity_place?>
                                                          </td>
                                                          <td> 
                                                            <?=$th_date?>
                                                          </td>
                                                          <td> 
                                                            <?=$activity_comm?>
                                                          </td>
                                                        </tr>
                                                       
                                                        <?
													  ++$count;
									}				  
													  
													  ?>
													   <tr>
                                                          <td height="32" class="style13">
                                                            <?=$count?>
                                                          </td>
                                                          <td><input name="activity_name" type="text" size="30"></td>
                                                          <td><input type="text" name="activity_place"></td>
                                                          <td><input type="text" name="tdate" value="" size=7> 
                                                            <a href="#"
   onClick="cal.select(document.forms['form1'].tdate,'anchor1','yyyy-MM-dd'); return false;"
   name="anchor1" id="anchor1"><img src="../resource/img/b_calendar.png" width="16" height="16" border="0" ="../resource/img/b_calendar.png"></a> 
                                                          </td>
                                                          <td><textarea name="activity_comm"></textarea></td>
                                                        </tr>
                                                      </table></TD>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 colspan="4" align=left>&nbsp;</TD>
                                                <TR bordercolor="2"> 
                                                  <TD 
            height=20 colspan="4" align=left><div align="center">
                                                        <input type="submit" name="Submit" value="�׹�ѹ�������">
                                                      </div></TD>
                                                <TR bordercolor="2"> 
                                                  <TD height=9 colspan="4" align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD width="310" height=20>&nbsp;</TD>
                                                  <TD width="56" height=20>&nbsp;</TD>
                                                  <TD width="103" height=20>&nbsp;</TD>
                                                  <TD width="275" height=20>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                  <TD height=20>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                                <TR bordercolor="2"> 
                                                  <TD height=20 align=left><p>&nbsp;</p>
                                                    <p>&nbsp;</p>
                                                    <p><br>
                                                    </p></TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                  <TD height=20 align=left>&nbsp;</TD>
                                                </TR>
                                              </TBODY>
                                            </TABLE>                                            
                                              <div align="right">&nbsp;&nbsp; </div></TD>
                                        </TR>
                                      </TBODY>
                                    </TABLE>
                                    </form>
									
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
