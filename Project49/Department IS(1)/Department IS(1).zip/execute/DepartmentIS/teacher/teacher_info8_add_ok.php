<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//����
if ($activity_name == ""){
		$activity_name = "null";
}
else {
		$activity_name= "'".$activity_name."'";
}

//˹��§ҹ
if ($activity_place == ""){
		$activity_place = "null";
}
else {
		$activity_place= "'".$activity_place."'";
}
//�ѹ���
if ($tdate == ""){
		$tdate = "null";
}
else {
		$tdate= "'".$tdate."'";
}

// �����˵�
if ($activity_comm == ""){
		$activity_comm = "null";
}
else {
		$activity_comm= "'".$activity_comm."'";
}

$sql = "insert into activity_person values( '',$activity_name,$activity_place,$tdate,$activity_comm,'$person_id')";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info8.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>