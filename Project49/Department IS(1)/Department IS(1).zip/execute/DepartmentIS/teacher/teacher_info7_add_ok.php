<?
include("_CheckSession.php"); 
include ("_Startconnection.php");

//����
if ($performance_name == ""){
		$performance_name = "null";
}
else {
		$performance_name= "'".$performance_name."'";
}

//ʶҹ���
if ($performance_place == ""){
		$performance_place = "null";
}
else {
		$performance_place= "'".$performance_place."'";
}

//�����
if ($performance_country == ""){
		$performance_country = "null";
}
else {
		$performance_country= "'".$performance_country."'";
}

//�ѹ���
if ($tdate == ""){
		$tdate = "null";
}
else {
		$tdate= "'".$tdate."'";
}

// �����˵�
if ($performance_comm == ""){
		$performance_comm = "null";
}
else {
		$performance_comm= "'".$performance_comm."'";
}

$sql = "insert into performance_person
values( '',$performance_name,$performance_place,$performance_country,$tdate,$performance_comm,'$person_id')";

if( mysql_query($sql,$conn) )
			{
				//print "<div align ='center'>";
				//print "�ѹ�֡���º����";
				//print "<br>" . $sql;
				//print "</div>";
				header("Location: teacher_info7.php");
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "<br>" . $sql;
				print "</div>";
			}			

?>