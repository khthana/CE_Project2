<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Department Information System</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
</head>

<body class = "classbody" onLoad="document.loginForm.username.focus()" >
<div align="right">�к����ʹ���Ҥ�Ԫ��<br>
  Department Information System<br>
</div>
<hr> 
�к����ʹ���Ҩ����
<br>
<form name="loginForm" method="post" action=" teach_check_passwd.php">
<table class = "classbody" width="34%" height="80" border="0" align="center" cellpadding="1" cellspacing="2">
  <tr>
      <td width="26%">Username</td>
    <td width="74%">
        <input name="username" type="text" id="username">
      </td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input name="password" type="password" id="password"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit">
        <input type="reset" name="Submit2" value="Reset"></td>
  </tr>
</table></form>
</body>
</html>
