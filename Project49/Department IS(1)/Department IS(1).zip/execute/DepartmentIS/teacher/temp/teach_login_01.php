<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" onLoad="document.loginForm.username.focus()">
<table width="750" height="391" border="0" align="center">
  <tr>
    <th height="97" colspan="2" scope="col"><div align="right"><img src="../resource/img/head1.gif" width="103" height="95"></div></th>
    <th width="319" valign="middle" scope="col"><div align="left"><img src="../resource/img/logo_New.jpg" width="314" height="70"></div></th>
    <th width="104" scope="col"><img src="../resource/img/r4.gif" width="108" height="80"></th>
    <th scope="col"><img src="../resource/img/kingrama4-005.jpg" width="81" height="80"></th>
    <th scope="col"><img src="../resource/img/kingrama4-012.jpg" width="107" height="80"></th>
  </tr>
  <tr border color="#66FFFF" bgcolor="#66FFFF" >
    <td height="23" colspan="6" scope="col"><div align="left" >
        <div align="center">
          <DIV align=center>��͡�Թ�����ҹ�к� ����Ѻ�Ҩ����</DIV>
        </div>
    </div></td>
  </tr>
  <tr >
    <th width="81" height="31" scope="col">&nbsp;</th>
    <th width="22" scope="col">&nbsp;</th>
    <td colspan="3" align="left" valign="middle" scope="col"><br>
      <form name="loginForm" method="post" action=" teach_check_passwd.php">
        <table class = "classbody" width="43%" height="80" border="0" align="center" cellpadding="1" cellspacing="2">
          <tr>
            <td width="26%">���ͼ����</td>
            <td width="74%"><input name="username" type="text" id="username">
            </td>
          </tr>
          <tr>
            <td>���ʼ�ҹ</td>
            <td><input name="password" type="password" id="password"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="Submit" value="Submit">
                <input type="reset" name="Submit2" value="Reset"></td>
          </tr>
        </table>
    </form></td>
    <th width="110" align="left" valign="middle" scope="col">&nbsp;</th>
  </tr>
  <tr >
    <th height="28" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <td colspan="3" scope="col">&nbsp;</td>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr >
    <th height="32" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <td colspan="3" scope="col">&nbsp;</td>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr >
    <th height="28" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <td colspan="3" scope="col">&nbsp;</td>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr >
    <th height="41" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <th colspan="3" scope="col"><div align="left"></div></th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr >
    <th height="39" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
    <th width="88" scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td height="52" colspan="6" scope="col" class ="classinfo"><div align="center">
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
