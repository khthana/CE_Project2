<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
</head>

<body class= "classbody">

<div align="center">
  <table width="750" height="546" border="0">
    <tr>
      <th width="11" height="97" scope="col"><div align="right"></div></th>
      <th colspan="3" valign="middle" scope="col"><div align="left"><img src="../resource/img/head1.gif" width="103" height="95"><img src="../resource/img/logo_New.jpg" width="314" height="70"></div></th>
      <th width="108" scope="col"><img src="../resource/img/r4.gif" width="108" height="80"></th>
      <th width="81" scope="col"><img src="../resource/img/kingrama4-005.jpg" width="81" height="80"></th>
      <th width="110" scope="col"><img src="../resource/img/kingrama4-012.jpg" width="107" height="80"></th>
    </tr>
    <tr bordercolor="#66FFFF" bgcolor="#66FFFF">
      <td height="23" colspan="7" scope="col"><div align="left" class="style43"> 
        <div align="center"></div>
      </div></td>
    </tr>
    <tr>
      <td colspan="3" rowspan="12" align="left" valign="top" scope="col"><? include ("_menu_01.php") ?><br></td>
      <td height="26" colspan="4" align="left" valign="middle" scope="col">&nbsp;</td>
    </tr>
    <tr>
      <td height="21" colspan="4" scope="col">&nbsp;</td>
    </tr>
    <tr>
      <td width="299" height="26" scope="col">&nbsp;</td>
      <td scope="col">&nbsp;</td>
      <td scope="col">&nbsp;</td>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <td height="26" valign="middle" scope="col">&nbsp;</td>
      <td valign="middle" scope="col">&nbsp;</td>
      <td valign="middle" scope="col">&nbsp;</td>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <td height="24" valign="middle" scope="col">&nbsp;</td>
      <td valign="middle" scope="col">&nbsp;</td>
      <td valign="middle" scope="col">&nbsp;</td>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <td height="26" scope="col">&nbsp;</td>
      <td scope="col">&nbsp;</td>
      <td scope="col">&nbsp;</td>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="24" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="24" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="25" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="23" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="22" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="28" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th height="26" colspan="2" scope="col">&nbsp;</th>
      <th width="112" scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <td height="52" colspan="7" scope="col"><div align="center">
        <HR align=center width="95%" SIZE=2>
        <FONT face="Tahoma, Microsoft Sans Serif" size=1>Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</FONT></div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

</body>
</html>
