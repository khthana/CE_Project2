<?
include("_CheckSession.php"); 
include ("_StartConnection.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� <?=$position ?><?=$personname ?>&nbsp;<?=$personlastname ?>  </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                    <? include ("_menu.php") ?>
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
							  <td>
							  <table width="500">
							  <?
							  				$Tcode1 = $_POST["Tcode"];	
											$Tname = $_POST["Tname"];	
											$Tsname = $_POST["Tsname"];												
										   
		if(empty($Tcode1) AND empty($Tname) AND empty($Tsname)){$sql ="select * from student ";}
		if (!empty($Tcode1) AND empty($Tname) AND empty($Tsname)){$sql ="select * from student where student_id Like '".$Tcode1."%'";}
		if (empty($Tcode1) AND !empty($Tname) AND empty($Tsname)){$sql ="select * from student where th_name Like '".$Tname."%'";}											
		if (empty($Tcode1) AND empty($Tname) AND !empty($Tsname)){$sql ="select * from student where th_surname Like '".$Tsname."%'";}											
		//if (empty($Tcode) AND empty($Tname) AND empty($Tsname)!empty($Tgrade)){$sql ="select * from student where th_surname Like ".$Tgrade;}		
		
		if (empty($Tcode1) AND !empty($Tname) AND !empty($Tsname))
		    {$sql ="select * from student where th_name Like '".$Tname."%'"." AND th_surname Like '".$Tsname."%'";}											
							  ?>
							   <form name="form1" method="post" action="../mis/mis_student.php">
							  	<tr>
                                <td width="206" align="left" valign="top" ><input type="text" name="Tcode"></td>
								 <td width="206" align="left" valign="top" ><input type="text" name="Tname"></td>
								  <td width="206" align="left" valign="top" ><input type="text" name="Tsname"></td>
								   <td width="206" align="left" valign="top" ><input type="text" name="Tgrade"></td>
								   <td width="206" align="left" valign="top" ><input type="submit" name="Submit" value="����"></td>
				              </tr>
							    </form>
							  <tr>
                                <td width="206" align="left" valign="top"  bgcolor="#FFFFCC"><b>���ʹѡ�֡��</td>
								<td width="195" align="left" valign="top" bgcolor="#FFFFCC"><b>���͹ѡ�֡��</td>
								<td width="243" align="left" valign="top" bgcolor="#FFFFCC"><b>���ʡ��</td> 
								<td width="243" align="left" valign="top" bgcolor="#FFFFCC"><b>GPA</td> 
				              </tr>
							 <? 
									$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��");							 
							while ($row=mysql_fetch_array($table))
									{
												$semester= $row[semester];
												$student_id= $row[student_id];
												$citizen_id= $row[citizen_id];
												$pre_name= $row[pre_name];
												$gender= $row[gender];
												$th_name= $row[th_name];
												$th_surname= $row[th_surname];
												$en_name= $row[en_name];
												$en_surname= $row[en_surname];
												$exam_pattern= $row[exam_pattern];
												$exam1= $row[exam1];
												$exam2= $row[exam2];
											?>						  
                              <tr>
                                <td align="left" valign="top" bgcolor="#FFFFEA"><a href="../student/std_info1.php?Std_id=<? print($student_id) ?> " target="_blank"  </a><? print($student_id) ?></a></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_name) ?></td>
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print($th_surname) ?></td> 
								<td align="left" valign="top" bgcolor="#FFFFEA"><? print("Test = 3.5") ?></td> 
				              </tr>
							  <? } ?>
							  </table>
                              </td><tr>
							  
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
