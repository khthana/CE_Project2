<?
require("config.mee.php");
require("function.php");
$id=$_GET[id];

if($id!=NULL){  //����ͤ�� id �����ҡѺ NULL
$query="SELECT * FROM person where person_id='$id'";
$log=connectmysql($query); 
$arrx=mysql_fetch_array($log);
if($arrx[position]!=NULL){
	$person_name="$arrx[position] $arrx[th_name] $arrx[th_surname]";
}else {
	$person_name="$arrx[prename] $arrx[th_name] $arrx[th_surname]";
}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="resource/mystyle.css">
<title>����¹˹ѧ����Ѻ</title>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function moveOver()  
{
var boxLength = document.choiceForm.choiceBox.length;
var selectedItem = document.choiceForm.available.selectedIndex;
var selectedText = document.choiceForm.available.options[selectedItem].text;
var selectedValue = document.choiceForm.available.options[selectedItem].value;
var i;
var isNew = true;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
thisitem = document.choiceForm.choiceBox.options[i].text;
if (thisitem == selectedText) {
isNew = false;
break;
      }
   }
} 
if (isNew) {
newoption = new Option(selectedText, selectedValue, false, false);
document.choiceForm.choiceBox.options[boxLength] = newoption;
}
document.choiceForm.available.selectedIndex=-1;
}
function removeMe() {
var boxLength = document.choiceForm.choiceBox.length;
arrSelected = new Array();
var count = 0;
for (i = 0; i < boxLength; i++) {
if (document.choiceForm.choiceBox.options[i].selected) {
arrSelected[count] = document.choiceForm.choiceBox.options[i].value;
}
count++;
}
var x;
for (i = 0; i < boxLength; i++) {
for (x = 0; x < arrSelected.length; x++) {
if (document.choiceForm.choiceBox.options[i].value == arrSelected[x]) {
document.choiceForm.choiceBox.options[i] = null;
   }
}
boxLength = document.choiceForm.choiceBox.length;
   }
}
function saveMe() {
var strValues = "";
var boxLength = document.choiceForm.choiceBox.length;
var count = 0;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
if (count == 0) {
strValues = document.choiceForm.choiceBox.options[i].value;
}
else {
strValues = strValues + "," + document.choiceForm.choiceBox.options[i].value;
}
count++;
   }
}
if (strValues.length == 0) {
alert("You have not made any selections");
}
else {
alert("Here are the values you've selected:\r\n" + strValues);
   }
}
//  End -->
</script>

<SCRIPT LANGUAGE="JavaScript">
<!--
function small_window(myurl) {
var newWindow;
var props = 'scrollBars=yes,resizable=yes,toolbar=no,menubar=no,location=no,directories=no,width=300,height=200';
newWindow = window.open(myurl, "Add_from_Src_to_Dest", props);
}
// Adds the list of selected items selected in the child
// window to its list. It is called by child window to do so.  
function addToParentList(sourceList) {
destinationList = window.document.forms[0].parentList;
for(var count = destinationList.options.length - 1; count >= 0; count--) {
destinationList.options[count] = null;
}
for(var i = 0; i < sourceList.options.length; i++) {
if (sourceList.options[i] != null)
destinationList.options[i] = new Option(sourceList.options[i].text, sourceList.options[i].value );
   }
}
// Marks all the items as selected for the submit button.  
function selectList(sourceList) {
sourceList = window.document.forms[0].parentList;
for(var i = 0; i < sourceList.options.length; i++) {
if (sourceList.options[i] != null)
sourceList.options[i].selected = true;
}
return true;
}

// Deletes the selected items of supplied list.
function deleteSelectedItemsFromList(sourceList) {
var maxCnt = sourceList.options.length;
for(var i = maxCnt - 1; i >= 0; i--) {
if ((sourceList.options[i] != null) && (sourceList.options[i].selected == true)) {
sourceList.options[i] = null;
      }
   }
}
//  End -->

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type="text/css">
<!--
.classinfo {
	font-size: x-small;
	font-family: sans-serif;
}
.style24 {font-size: small}
.style25 {	font-family: "MS Sans Serif", Tahoma, sans-serif;
	font-size: small;
}
.style28 {font-family: "MS Sans Serif", Tahoma, sans-serif; font-weight: bold; font-size: small; }
-->
</style>
</head>

<body class = "classbody">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col">
     <img src="../resource/img/_newlogo.gif" width="750" height="95"></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <img src="../resource/img/bar_l.gif" width="10" height="23"></td>
    <td width="760" align="left" valign="center" background="../resource/img/bar_c.gif" scope="col"><div align="center"><span class="style24">�к����ʹ�����˹�ҷ���á�� ���ҧ��û�Ժѵԧҹ�ͧ�Ҩ���� <?=$person_name?></span></div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td width=8 height=8 valign=top><strong><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></strong></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></strong></td>
                            <td width=8 height=8 valign=top><strong><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></strong></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><strong><img 
                        src="../resource/img/border_footer04.jpg" 
                        width=8 
                        height=8></strong></td>
                            <td valign=top>
<?
if($id!=NULL){	
?>
							<table width="100%" border=1 cellpadding=1 cellspacing=0 bordercolor="#000000" bgcolor="#FFFFFF">
                              <form action="process.php" method="post" enctype="multipart/form-data" name="choiceForm" id="choiceForm">
                                <tbody>
                                  <tr>
                                    <td colspan="15" align="left" valign=middle><div align="center" class="style28">����</div></td>
                                  </tr>
                                  <tr>
                                    <td width="8%" height="31" valign=middle bgcolor="#FFF3CE"><div align="center" class="style25">
                                        <div align="center">8.00</div>
                                    </div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center" class="style25">
                                        <div align="center">9.00</div>
                                    </div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">10.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">11.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">12.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">13.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">14.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">15.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">16.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">17.00</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">17.30</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">18.30</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">19.30</span></div></td>
                                    <td width="7%" valign=middle bgcolor="#FFF3CE"><div align="center"><span class="style25">20.30</span></div></td>
                                  </tr>
<?
for($j=1;$j<=7;$j++){

switch($j){
	case 1: $newdate="�ѹ���"; break;
	case 2: $newdate="�ѧ���"; break;
	case 3: $newdate="�ظ"; break;
	case 4: $newdate="����ʺ��"; break;
	case 5: $newdate="�ء��"; break;
	case 6: $newdate="�����"; break;
	case 7: $newdate="�ҷԵ��"; break;
}

?> 
<tr>
                                    <td width="8%" height="38" align="left" valign=middle><span class="style28"> <?=$newdate?></span></td>
<?
$querytable="SELECT * FROM register_schedule where Person_ID='$id' AND Schedule_Date='$j' order by Schedule_Ftime";
$logtable=connectmysql($querytable); 
$numtable=mysql_num_rows($logtable);

if($numtable!=NULL){

for($i=1;$i<=$numtable;$i++){
$arrtable=mysql_fetch_array($logtable);


if($arrtable[Schedule_Ftime]<4){
	$showm[$j]='1';
	for($x=1;$x<$arrtable[Schedule_Ftime];$x++){
		echo "<td align=\"center\" valign=top>&nbsp;</td>";
	}
	
	$newtime1=($arrtable[Schedule_Ltime]-$arrtable[Schedule_Ftime])+1;
	switch($newtime1){
		case 2: $pra="--"; break;
		case 3: $pra="-------"; break;
		case 4: $pra="-------------"; break;
		case 5: $pra="------------------"; break;
	}
	echo "<td align=\"center\" valign=top colspan=$newtime1 bgcolor=#EAFFEA><font class=style24><$pra $arrtable[Schedule_IdSubject] $pra></font><br><font color=blue class=style24>$arrtable[Schedule_Subject]</font></td>";
	
		$ncount=4-$arrtable[Schedule_Ltime];
		for($nx=1;$nx<=$ncount;$nx++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	
}

if($arrtable[Schedule_Ftime]>'4' AND $arrtable[Schedule_Ftime]<'9'){
	$shown[$j]='1';
	
	if($showm[$j]=='1'){
		for($y=5;$y<$arrtable[Schedule_Ftime];$y++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	}else {
		for($y=1;$y<$arrtable[Schedule_Ftime];$y++){
		echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	}
	
	$newtime2=($arrtable[Schedule_Ltime]-$arrtable[Schedule_Ftime])+1;
		switch($newtime2){
		case 2: $pra="--"; break;
		case 3: $pra="-------"; break;
		case 4: $pra="-------------"; break;
		case 5: $pra="------------------"; break;
	}
	echo "<td align=\"center\" valign=top colspan=$newtime2 bgcolor=#EAFFEA><font class=style24><$pra $arrtable[Schedule_IdSubject] $pra></font><br><font color=blue class=style24>$arrtable[Schedule_Subject]</font></td>";

		$mcount=9-$arrtable[Schedule_Ltime];
		for($yx=1;$yx<=$mcount;$yx++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
		
}

if($arrtable[Schedule_Ftime]>'9'){
	
	if($showm[$j]=='1' && $shown[$j]=='1'){
		for($w=10;$w<$arrtable[Schedule_Ftime];$w++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	}else if($showm[$j]=='1'){
		for($w=5;$w<$arrtable[Schedule_Ftime];$w++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	}else {
		for($w=1;$w<$arrtable[Schedule_Ftime];$w++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
	}

	$newtime3=($arrtable[Schedule_Ltime]-$arrtable[Schedule_Ftime])+1;
	switch($newtime3){
		case 2: $pra="--"; break;
		case 3: $pra="--------"; break;
		case 4: $pra="-----------"; break;
		case 5: $pra="------------------"; break;
	}
	
	echo "<td align=\"center\" valign=top colspan=$newtime3 bgcolor=#EAFFEA><font class=style24><$pra $arrtable[Schedule_IdSubject] $pra></font><br><font color=blue class=style24>$arrtable[Schedule_Subject]</font></td>";

		$mcount=13-$arrtable[Schedule_Ltime];
		for($yx=1;$yx<=$mcount;$yx++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
}

} // end for loop

if($newtime2==NULL AND $newtime3==NULL){
			$allnewtime=$newtime2+$newtime3;
			echo "<td align=\"center\" valign=top>$allnewtime</td>";
}else if($newtime3==NULL){
			$allnewtime=$newtime3;
			echo "<td align=\"center\" valign=top>$allnewtime</td>";
}


}else {
		for($yx=1;$yx<=13;$yx++){
			echo "<td align=\"center\" valign=top>&nbsp;</td>";
		}
}
?>
</tr>
<?
}

?>
</form>
                            </table>
                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td class="style24">&gt; ��سҡ�͡�����ŵ��ҧŧ�����������´��ҹ��ҧ</td>
                                </tr>
                              </table>
                              <table width="100%" border="0" cellspacing="0" cellpadding="2">
<form action="table_add.php" method="post" enctype="multipart/form-data" name="webForm" id="webForm">
                                <tr>
                                  <td width="14%" align="right" class="style24">�ѹ ::</td>
                                  <td width="86%"><select name="Schedule_Date" id="Schedule_Date">
                                      <option value="1">�ѹ���</option>
                                      <option value="2">�ѧ���</option>
                                      <option value="3">�ظ</option>
                                      <option value="4">�����</option>
                                      <option value="5">�ء��</option>
                                      <option value="6">�����</option>
                                      <option value="7">�ҷԵ��</option>
                                    </select>                                  </td>
                                </tr>

                                <tr>
                                  <td align="right" class="style24">�Ԫ� ::</td>
                                  <td><input name="Schedule_Subject" type="text" id="Schedule_Subject" size="25">
                                    <input name="Person_ID" type="hidden" id="Person_ID" value="<?=$id?>"></td>
                                </tr>
                                <tr>
                                  <td align="right" class="style24">�����Ԫ� ::</td>
                                  <td><input name="Schedule_IdSubject" type="text" id="Schedule_IdSubject" size="25" maxlength="8"></td>
                                </tr>
                                <tr>
                                  <td align="right" class="style24">���� :: </td>
                                  <td><font color=#0000ff>
                                    <select name=Schedule_Ftime id="Schedule_Ftime">
                                      <option value="1">9:00</option>
                                      <option value="2">10:00</option>
                                      <option value="3">11:00</option>
                                      <option value="4">12:00</option>
                                      <option value="5">13:00</option>
                                      <option value="6">14:00</option>
                                      <option value="7">15:00</option>
                                      <option value="8">16:00</option>
                                      <option value="9">17:00</option>
                                      <option value="10">17:30</option>
                                      <option value="11">18:30</option>
                                      <option value="12">19:30</option>
                                      <option value="13">20:30</option>
                                      </select>
                                    <span class="style24">�֧</span>
                                    <select name=Schedule_Ltime id="Schedule_Ltime">
                                      <option value="1">9:00</option>
                                      <option value="2">10:00</option>
                                      <option value="3">11:00</option>
                                      <option value="4">12:00</option>
                                      <option value="5">13:00</option>
                                      <option value="6">14:00</option>
                                      <option value="7">15:00</option>
                                      <option value="8">16:00</option>
                                      <option value="9">17:00</option>
                                      <option value="10">17:30</option>
                                      <option value="11">18:30</option>
                                      <option value="12">19:30</option>
                                      <option value="13">20:30</option>
                                    </select>
                                  </font></td>
                                </tr>
                                <tr>
                                  <td align="right" class="style24">&nbsp;</td>
                                  <td><input type="submit" name="Submit" value="�������ҧ"></td>
                                </tr></form>
                              </table>
<script language="JavaScript" type="text/javascript">
function check()
{
      var v1 = document.webForm.Schedule_Subject.value;
      var v2 = document.webForm.Schedule_IdSubject.value;
	  if ( v1.length==0){
		    alert("��سҡ�͡������ԪҴ��¤���");
           document.webForm.Schedule_Subject.focus();           
           return false;
           }else if (v2.length==0){
           alert("��سҡ�͡�����ԪҴ��¤��");
           document.webForm.Schedule_IdSubject.focus();           
		   return false;
           }else
           return true;
}//-->
            </script>
                            <?
							}else {
							?>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td class="style24">&nbsp;&nbsp;&gt; ��س����͡�����Ҩ�������ͧ����������ҧ�͹</td>
                              </tr>
                            </table>
                            <table width="100%" border="0" cellspacing="0" cellpadding="2">
                              <tr>
                                <td width="14%" height="45" align="right" class="style24">��¹���Ҩ���� ::</td>
                                <td width="86%">
<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
<?
$query="SELECT * FROM person";
$log=connectmysql($query); 
$num=mysql_num_rows($log);
for($i=0;$i<$num;$i++){
$arr=mysql_fetch_array($log);
if($arr[position]!=NULL){
	$newname="$arr[position] $arr[th_name] $arr[th_surname]";
	echo "<option value='table.php?id=$arr[person_id]&name=$newname'>$arr[position] $arr[th_name] $arr[th_surname]</option>";
}else {
	$newname="$arr[prename] $arr[th_name] $arr[th_surname]";
	echo "<option value='table.php?id=$arr[person_id]&name=$newname'>$arr[prename] $arr[th_name] $arr[th_surname]</option>";
}
}
?>
</select></td>
                              </tr>
                            </table>
                            <?
							}
							?></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></strong></td>
                          </tr>
                          <tr> 
                            <td valign=top><strong><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></strong></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></strong></td>
                            <td valign=top><strong><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></strong></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=8 
            src="../resource/img/spacer.gif" width=8> </td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col">
        <HR align=center width="95%" SIZE=2>
        <div align="center"><span class="classinfo">Department of Computer Engineering Faculty of Engineering King Mongkut's 
          Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</span></div></td>
  </tr>
</table>
</body>
</html>
