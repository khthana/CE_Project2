<?
require("config.mee.php");
require("function.php");

$query1="SELECT * FROM register_checktime WHERE Time='$Config_totaldate'";
$log1=connectmysql($query1); 
$num1=mysql_num_rows($log1);

if($num1==NULL){
	$query3="INSERT INTO register_checktime(Time_ID,Time,Time_Status) values('','$Config_totaldate','1')";
	$log3=connectmysql($query3); 
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>
<style type="text/css">
<!--
.style23 {font-size: xx-small}
-->
</style>

</head>

<body class = "classbody">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="4" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="11" height="23" align="left" valign="top" bgcolor="ffffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="276" align="left" valign="center" background="../resource/img/bar_c.gif" class="classinfo style1" scope="col"><img src="../resource/img/bullet-blue.gif" width="9" height="11"> <a href="logout.php" class="style1">Logout</a></td>
    <td width="483" align="center" valign="center" background="../resource/img/bar_c.gif" scope="col"><div align="left" class="style1">�к����ʹ�����˹�ҷ���á��</div></td>
    <td width="10" background="../r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="4" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top> <table cellspacing=2 cellpadding=1 width="100%" 
border=0>
                                
                                <tbody>
                                  
                                  <tr> 
                                    <td width="104" height="11" valign=top>&nbsp; </td>
                                    <td width="313" height="11" align="left" valign=top><img src="../resource/img/arrowgreenright.gif" width="13" height="13"> <a href="bookIn1.php" class="style1">����¹˹ѧ����Ѻ��͹��������˹���Ҥ</a></td>
                                    <td width=333 rowspan="4" align="left" valign=top>&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td height="12" valign=top>&nbsp;</td>
                                    <td width="313" height="12" align="left" valign=top><img src="../resource/img/arrowgreenright.gif" width="13" height="13"> <a href="bookIn2.php" class="style1">����¹˹ѧ����Ѻ��ѧ�ҡ���˹���Ҥ�Ԩ�ó�����</a></td>
                                  </tr>
                                  <tr>
                                    <td height="25" valign=top>&nbsp;</td>
                                    <td height="25" align="left" valign=top><img src="../resource/img/arrowgreenright.gif" width="13" height="13"> <a href="bookOut.php" class="style1">����¹˹ѧ��</a></td>
                                  </tr>
                                  <tr> 
                                    <td width="104" height="25" valign=top>&nbsp;</td>
                                    <td width="313" height="25" align="left" valign=top><img src="../resource/img/arrowgreenright.gif" width="13" height="13"> <span class="style1"><a href="table.php">�ѹ�֡���ҧ��û�Ժѵԧҹ�ͧ�Ҩ���</a>�</span></td>
                                  </tr>
                                </tbody>
                              </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=8 
            src="../resource/img/spacer.gif" width=8></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="4" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        <span class="style18 classinfo"><span class="style23">Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</span></span></div></td>
  </tr>
</table>
</body>
</html>
