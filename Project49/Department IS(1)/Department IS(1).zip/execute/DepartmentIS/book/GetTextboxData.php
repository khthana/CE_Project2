<?php
    header("Content-Type: text/plain; charset=TIS-620");
	require("config.mee.php");
	require("function.php");
   
    //�Ѻ�����������㹵���ê��� sID
   $ID = $_GET["id"];

    //����觤��Ң�����
    $Query = "Select * from register_book where Book_Type_ID='$ID'";
          
    if($Result = connectmysql($Query) and mysql_num_rows($Result) > 0) {
        $Values = mysql_fetch_array($Result);

echo "<table align=left border=0 width=100%><tr><td width=110 height=\"25\" align=\"right\" valign=middle><span class=\"style1\">�Ţ���˹ѧ��� ::</span></td>"
."<td height=\"25\" align=\"left\" valign=middle><input name=\"Book_ID\" type=\"text\" id=\"Book_ID\" value='".$Values['Book_ID']."'>"
."</td>"
."</tr>"
."<tr>"
."<td height=\"25\" align=\"right\" valign=middle><span class=\"style1\">ŧ�ѹ��� :: </span></td>"
."<td height=\"25\" align=\"left\" valign=middle>"
."<input name=\"T1\" type=\"text\" id=\"T1\" value='".$Values['Book_Date']."'>"
."&nbsp;<span class=\"style1\">����<font color=#0000ff> ::</font></span>"
."<input name=\"SelectTime\" type=\"text\" id=\"SelectTime\" size=\"10\" value='".$Values['Book_Time']."'>"
."</a></td>"
."</tr>"
."<tr>"
."<td width=\"110\" height=\"25\" align=\"right\" valign=middle><span class=\"style1\">�ҡ ::  </span></td>"
."<td height=\"25\" align=\"left\" valign=middle><input name=\"Book_From\" type=\"text\" id=\"Book_From\" value='".$Values['Book_From']."'></td>"
."</tr>"
."<tr>"
."<td width=\"110\" height=\"25\" align=\"right\" valign=middle><span class=\"style1\">�֧ ::</span></td>"
."<td height=\"25\" align=\"left\" valign=middle><input name=\"Book_Send\" type=\"text\" id=\"Book_Send\" value=\"�Ҥ�Ԫ����ǡ�������������\"></td>"
."</tr>"
."<tr>"
."<td width=\"110\" height=\"25\" align=\"right\" valign=middle><span class=\"style1\">����ͧ ::</span></td>"
."<td height=\"25\" align=\"left\" valign=middle><input name=\"Book_Title\" type=\"text\" id=\"Book_Title\" value='".$Values['Book_Title']."'></td>"
."</tr>"
."</table>";
    } else {
        echo "��辺�����Ţͧ�Թ��ҷ����������ҡѺ  $ID ";
    }    
?>
