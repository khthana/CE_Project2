<?
########################################## function REDIRECT
function redirect($type,$link){
	if($link==NULL){
		$link="index.php";
	}
	if($type==0){
		echo "<meta http-equiv=\"refresh\" content=\"3;URL=$link\">";
	}else if($type==3){
		echo "<meta http-equiv=\"refresh\" content=\"0;URL=$link\">";
	}else {
		header("Location:$link");
	}
}
##########################################
//mysql connect
function connectmysql($query) {
require("config.mee.php"); 
$conn=mysql_connect($Config_host,$Config_username,$Config_password);  
mysql_select_db($Config_dbname,$conn);      
mysql_query("SET NAMES tis620");     
$logquery = mysql_query($query);    
return $logquery;
//return $conn;
}
##########################################
//mysql connect
function connectmysql2($query) {
require("config.mee.php");  
$conn=mysql_connect($Config_host,$Config_username,$Config_password);  
mysql_select_db($Config_dbname,$conn);  
//mysql_query("SET NAMES tis620");  
$logquery = mysql_query($query); 
return $logquery;
//return $conn;
}
#####################################
function reversedate($datetime){
	$nday=split("-",$datetime);
	$newdatetime="$nday[2]/$nday[1]/$nday[0]";
	return $newdatetime;
}
######################################
function closedb($log) {
				mysql_free_result($log);
                mysql_close();
        }
########################################
function sendmail(){
	require("config.mee.php"); 
	$checktime=$Config_date-1;
	$allchecktime="$checktime/$Config_month/$Config_year"; 
	//echo $allchecktime;

	//��Ǩ�ͺ����ѹ����������ѧ
	$query1="SELECT * FROM register_checktime WHERE Time='$allchecktime' AND Time_Status='1'";
	$log1=connectmysql($query1); 
	$num1=mysql_num_rows($log1);
	if($num1!=NULL){

			$query="SELECT * FROM register_book_mail WHERE Book_Date='$allchecktime'";
			$log=connectmysql($query); 
			$num=mysql_num_rows($log);
			for($i=0;$i<$num;$i++){
				$arr=mysql_fetch_array($log);
				echo $arr[person_id];
					//�觨��������Ҩ����
					$query2="SELECT * FROM register_book WHERE Book_ID='$arr[Book_ID]' AND Book_Date='$allchecktime'";
					$log2=connectmysql($query2); 
					$num2=mysql_num_rows($log2);
					for($j=1;$j<=$num2;$j++){
						$arr2=mysql_fetch_array($log2);
						$text = "˹ѧ����Ѻ �Ţ��� $arr2[Book_Type_ID] � �ѹ��� $arr2[Book_Date] ����ͧ $arr2[Book_Title]<br>";
						$newtext="$newtext $text";
					}
					$mailme="ideamix@gmail.com";
					$subject="˹ѧ����Ѻ������Ѻ�ͺ����";
					$xtext="���ʴդ�� �س���Ѻ˹ѧ����Ѻ������Ѻ�ͺ���´ѧ����� $newtext";
					$from="From: info@ideamixhost.com";
					if(!$num=mail($mailme,$subject,$xtext,$from)){
						echo "<font class=\"style3\">�������ö�����������</font>";
					}else{
 						echo "<font class=\"style3\">�����������¡���Թ�����ѧ <font class=\"style4\">email : $mCustomer_Email</font></font>";
					}
			
			}

	$query3="UPDATE register_checktime SET Time_Status='2' WHERE Time='$allchecktime'";
	$log3=connectmysql($query3); 

	}

}


?>