<?
ob_start();
require("config.mee.php");
require("function.php");

//$strValues=$_POST[strValues];
$Book_Type_ID=$_POST[Book_Type_ID];
$Book_ID=$_POST[Book_ID];
$T1=$_POST[T1];
$Book_From=$_POST[Book_From];
$Book_Send=$_POST[Book_Send];
$Book_Title=$_POST[Book_Title];
$Book_File=$HTTP_POST_FILES['Book_File']['name']; 
$Book_Status1=$_POST[Book_Status1];
$Book_Status2=$_POST[Book_Status2];
$Book_Status3=$_POST[Book_Status3];
$checkbox2=$_POST[checkbox2];
$parentList=$_POST[parentList];
$Book_Type=$_POST[Book_Type];
$varperson=$_POST[varperson];
$Book_Time=$_POST[SelectTime];

$T2=split("-",$T1);
$T2[0]=$T2[0]+543;
$Book_Date="$T2[2]/$T2[1]/$T2[0]";

if($Book_Status1==1 AND $Book_Status2==1){
	$Book_Status="4";
}else if($Book_Status1==1 AND $Book_Status3==1){
	$Book_Status="5";
}else if($Book_Status2==1 AND $Book_Status3==1){
	$Book_Status="6";
}else if($Book_Status1==1){
	$Book_Status="1";
}else if($Book_Status1==1){
	$Book_Status="2";
}else if($Book_Status3==1){
	$Book_Status="3";
}else if($Book_Status4==1){
	$Book_Status="7";
}

if($Book_Type=='1'){

copy($HTTP_POST_FILES['Book_File']['tmp_name'],"file/$Book_File_name");

$query="Insert into register_book( Book_ID,Book_Type,Book_Type_ID,Book_Date,Book_From,Book_Send,Book_Title,Book_File,Book_Status,Book_Comment,Book_Time) values('$Book_ID','$Book_Type','$Book_Type_ID','$Book_Date','$Book_From','$Book_Send','$Book_Title','$Book_File','$Book_Status','$Book_Comment','$Book_Time')";
$log=connectmysql($query);

}

if($Book_Type=='2'){
	copy($HTTP_POST_FILES['Book_File']['tmp_name'],"file/$Book_File_name");
	$exp=split(",",$varperson);
	$query="Insert into register_book( Book_ID,Book_Type,Book_Type_ID,Book_Date,Book_From,Book_Send,Book_Title,Book_File,Book_Status,Book_Comment,Book_Time) values('$Book_ID','$Book_Type','$Book_Type_ID','$Book_Date','$Book_From','$Book_Send','$Book_Title','$Book_File','$Book_Status','$Book_Comment','$Book_Time')";
	$log=connectmysql($query);

if($Book_Status='1' OR $Book_Status='3' OR $Book_Status='4' OR $Book_Status='5' OR $Book_Status='6' ){
	//ǹ�ٻ import �����Ҩ����������ҹ������
	for($i=0;$i<count($exp);$i++){
		$query1="Insert into register_book_mail( Book_ID,person_id,Book_Date) values('$Book_ID','$exp[$i]','$Book_Date')";
		$log1=connectmysql($query1);
	}
}//end if

}
echo "<center class=style25>�Ѿ��Ŵ������º�������Ǥ��</center>";
redirect(0,"bookin.php");

ob_end_flush();
?>