<?
require("config.mee.php");
require("function.php");

//�ʴ���������ǹ������ͧ���� user
$query="SELECT * FROM person";
$log = connectmysql($query);  //exec data
$num=mysql_num_rows($log);
if($num==0){
	echo "����բ������Ҩ����";
	exit();
}else {
?>
<html>
<head>
<script language="JavaScript">
 Begin
<!--
// Add the selected items in the parent by calling method of parent
function addSelectedItemsToParent() {
self.opener.addToParentList(window.document.forms[0].destList);
window.close();
}
// Fill the selcted item list with the items already present in parent.
function fillInitialDestList() {
var destList = window.document.forms[0].destList; 
var srcList = self.opener.window.document.forms[0].parentList;
for (var count = destList.options.length - 1; count >= 0; count--) {
destList.options[count] = null;
}
for(var i = 0; i < srcList.options.length; i++) { 
if (srcList.options[i] != null)
destList.options[i] = new Option(srcList.options[i].text);
   }
}
// Add the selected items from the source to destination list
function addSrcToDestList() {
destList = window.document.forms[0].destList;
srcList = window.document.forms[0].srcList; 
var len = destList.length;
for(var i = 0; i < srcList.length; i++) {
if ((srcList.options[i] != null) && (srcList.options[i].selected)) {
//Check if this value already exist in the destList or not
//if not then add it otherwise do not add it.
var found = false;
for(var count = 0; count < len; count++) {
if (destList.options[count] != null) {
if (srcList.options[i].text == destList.options[count].text) {
found = true;
break;
      }
   }
}
if (found != true) {
destList.options[len] = new Option(srcList.options[i].text); 
len++;
         }
      }
   }
}
// Deletes from the destination list.
function deleteFromDestList() {
var destList  = window.document.forms[0].destList;
var len = destList.options.length;
for(var i = (len-1); i >= 0; i--) {
if ((destList.options[i] != null) && (destList.options[i].selected == true)) {
destList.options[i] = null;
      }
   }
}
// End -->
</SCRIPT>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	color: #3366CC;
}
-->
</style>
<title>����¹˹ѧ����Ѻ</title><meta http-equiv="Content-Type" content="text/html; charset=windows-874"></head>
<body onLoad="javascript:fillInitialDestList();">
<center>
<form method="POST">
<table cellpadding="3" cellspacing="3" bgcolor="#EEEEEE">
<tr>
<td width="76" class="style1">�������Ҫԡ</td>
<td> </td>
<td width="92" class="style1">���������ͧ�����</td>
</tr>
<tr>
<td width="76" align="left">
<select size="6" name="srcList" multiple>
<? for($i=1;$i<=$num;$i++){ 
	  $arr=mysql_fetch_array($log);

if($arr[position]!=NULL){
	echo "<option value='id=$arr[person_id]'>$arr[position] $arr[th_name] $arr[th_surname]</option>";
}else {
	$newname="$arr[prename] $arr[th_name] $arr[th_surname]";
	echo "<option value='id=$arr[person_id]'>$arr[prename] $arr[th_name] $arr[th_surname]</option>";
}

 } ?>
</select></td>
<td width="75" align="center">
<input type="button" value=" >> " onClick="javascript:addSrcToDestList()">
<br><br>
<input type="button" value=" << " onClick="javascript:deleteFromDestList();">
</td>
<td width="92">
<select size="6" name="destList" multiple>
</select></td>
</tr>
<tr>
<td colspan=3 align="center">
<input type="button" value="��ŧ" onClick = "javascript:addSelectedItemsToParent()">
</td>
</tr>
</table>
</form>
</body>
</html>
<?
}
?>
