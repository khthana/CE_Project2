<?
ob_start();
require("config.mee.php");
require("function.php");

$Schedule_ID=$_POST[Schedule_ID];
$Person_ID=$_POST[Person_ID];
$Schedule_Date=$_POST[Schedule_Date];
$Schedule_Subject=$_POST[Schedule_Subject];
$Schedule_IdSubject=$_POST[Schedule_IdSubject];
$Schedule_Ftime=$_POST[Schedule_Ftime];
$Schedule_Ltime=$_POST[Schedule_Ltime];

$query="Insert into register_schedule( Schedule_ID,Person_ID,Schedule_Date,Schedule_Subject,Schedule_IdSubject,Schedule_Ftime,Schedule_Ltime) values('$Schedule_ID','$Person_ID','$Schedule_Date','$Schedule_Subject','$Schedule_IdSubject','$Schedule_Ftime','$Schedule_Ltime')";
$log=connectmysql($query);

echo "<center class=style25>�Ѿ��Ŵ������º�������Ǥ��</center>";
redirect(1,"table.php?id=$Person_ID");

ob_end_flush();
?>