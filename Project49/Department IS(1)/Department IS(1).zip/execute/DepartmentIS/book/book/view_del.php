<?
ob_start();
require("config.mee.php");
require("function.php");
$id=$_GET[id];

$query="DELETE FROM register_book_mail WHERE Book_ID='$id' AND person_id='$_SESSION[person_id]'";
$log=connectmysql($query);
redirect(1,"view.php");
ob_end_flush();
?>