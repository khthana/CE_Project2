<?
require("config.mee.php");
require("function.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="resource/mystyle.css">
<title>����¹˹ѧ����Ѻ</title>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function moveOver()  
{
var boxLength = document.choiceForm.choiceBox.length;
var selectedItem = document.choiceForm.available.selectedIndex;
var selectedText = document.choiceForm.available.options[selectedItem].text;
var selectedValue = document.choiceForm.available.options[selectedItem].value;
var i;
var isNew = true;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
thisitem = document.choiceForm.choiceBox.options[i].text;
if (thisitem == selectedText) {
isNew = false;
break;
      }
   }
} 
if (isNew) {
newoption = new Option(selectedText, selectedValue, false, false);
document.choiceForm.choiceBox.options[boxLength] = newoption;
}
document.choiceForm.available.selectedIndex=-1;
}
function removeMe() {
var boxLength = document.choiceForm.choiceBox.length;
arrSelected = new Array();
var count = 0;
for (i = 0; i < boxLength; i++) {
if (document.choiceForm.choiceBox.options[i].selected) {
arrSelected[count] = document.choiceForm.choiceBox.options[i].value;
}
count++;
}
var x;
for (i = 0; i < boxLength; i++) {
for (x = 0; x < arrSelected.length; x++) {
if (document.choiceForm.choiceBox.options[i].value == arrSelected[x]) {
document.choiceForm.choiceBox.options[i] = null;
   }
}
boxLength = document.choiceForm.choiceBox.length;
   }
}
function saveMe() {
var strValues = "";
var boxLength = document.choiceForm.choiceBox.length;
var count = 0;
if (boxLength != 0) {
for (i = 0; i < boxLength; i++) {
if (count == 0) {
strValues = document.choiceForm.choiceBox.options[i].value;
}
else {
strValues = strValues + "," + document.choiceForm.choiceBox.options[i].value;
}
count++;
   }
}
//if (strValues.length == 0) {
//alert("You have not made any selections");
//}
//else {
//alert("Here are the values you've selected:\r\n" + strValues);
//   }
return strValues;
}
//  End -->
</script>

<SCRIPT LANGUAGE="JavaScript">
function small_window(myurl) {
var newWindow;
var props = 'scrollBars=yes,resizable=yes,toolbar=no,menubar=no,location=no,directories=no,width=300,height=200';
newWindow = window.open(myurl, "Add_from_Src_to_Dest", props);
}
// Adds the list of selected items selected in the child
// window to its list. It is called by child window to do so.  
function addToParentList(sourceList) {
destinationList = window.document.forms[0].parentList;
for(var count = destinationList.options.length - 1; count >= 0; count--) {
destinationList.options[count] = null;
}
for(var i = 0; i < sourceList.options.length; i++) {
if (sourceList.options[i] != null)
destinationList.options[i] = new Option(sourceList.options[i].text, sourceList.options[i].value );
   }
}
// Marks all the items as selected for the submit button.  
function selectList(sourceList) {
sourceList = window.document.forms[0].parentList;
for(var i = 0; i < sourceList.options.length; i++) {
if (sourceList.options[i] != null)
sourceList.options[i].selected = true;
}
return true;
}

// Deletes the selected items of supplied list.
function deleteSelectedItemsFromList(sourceList) {
var maxCnt = sourceList.options.length;
for(var i = maxCnt - 1; i >= 0; i--) {
if ((sourceList.options[i] != null) && (sourceList.options[i].selected == true)) {
sourceList.options[i] = null;
      }
   }
}
//  End -->
</script>
<style type="text/css">
<!--
.classinfo {
	font-size: x-small;
	font-family: sans-serif;
}
.style15 {font-size: 12px; font-family: Geneva, Arial, Helvetica, sans-serif; }
.style16 {color: #0066CC}
.style17 {font-size: 12px; font-family: Geneva, Arial, Helvetica, sans-serif; color: #0066CC; }
-->
</style>
</head>

<body class = "classbody">
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col">
     <img src="../resource/img/_newlogo.gif" width="750" height="95"></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="ffffff" scope="col"> <img src="../resource/img/bar_l.gif" width="10" height="23"></td>
    <td width="760" align="left" valign="center" background="../resource/img/bar_c.gif" scope="col"><div align="center"></div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td width=8 height=8 valign=top><strong><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></strong></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></strong></td>
                            <td width=8 height=8 valign=top><strong><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></strong></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><strong><img 
                        src="../resource/img/border_footer04.jpg" 
                        width=8 
                        height=8></strong></td>
                            <td valign=top>
                              <table width="100%" height="70" border=0 cellpadding=1 cellspacing=2>
<form action="process.php" method="post" enctype="multipart/form-data" name="choiceForm" id="choiceForm" onSubmit="saveMe();">
								 <tr>
                                  <td height="31" align="right" valign=middle><div align="center">�ӴѺ</div></td>
                                  <td width="528" align="left" valign=middle><div align="center">��¡��˹ѧ����Ѻ</div></td>
                                  <td width="82" align="left" valign=middle><div align="center">�ѹ/��͹/��</div></td>
                                  <td width="83" align="left" valign=middle><div align="center">��Ҵ</div></td>
								 </tr>
                                <tbody>
                                  <tr>
                                    <td width=51 height="25" align="right" valign=middle>&nbsp;</td>
                                    <td height="25" align="left" valign=middle>&nbsp;</td>
                                    <td height="25" align="left" valign=middle>&nbsp;</td>
                                    <td height="25" align="left" valign=middle>&nbsp;</td>
                                  </tr>
                                </form>
                              </table>
                                                        
                            </td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></strong></td>
                          </tr>
                          <tr> 
                            <td valign=top><strong><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></strong></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><strong><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></strong></td>
                            <td valign=top><strong><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></strong></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=8 
            src="../resource/img/spacer.gif" width=8> </td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col">
        <HR align=center width="95%" SIZE=2>
        <div align="center"><span class="classinfo">Department of Computer Engineering Faculty of Engineering King Mongkut's 
          Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</span> <a href="../Admin/admin_login.php"></a> 
        </div></td>
  </tr>
</table>
</body>
</html>
