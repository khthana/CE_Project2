<?
srand(time());
$random = (rand()%9);
srand(time());
$randagain = (rand()%9);
while ($random == $randagain)
{
	srand(time());
	$randagain = (rand()%9);
}
print "<img src = pics/" . $random . ".gif border =0>";
print "<img src = pics/" . $randagain . ".gif border =0>";
print
?>