<?
	include ("_checksessionteacher.php");
	print "Login Success";
	print " you are " . $type ;
	



?>
<br>
<a href = "teacher_login.php"> LOGIN AGAIN </a>
<br>
<a href = "indexmenu.php"> MENU </a>
<br>
<a href = "_logout.php"> LOGOUT</a>
