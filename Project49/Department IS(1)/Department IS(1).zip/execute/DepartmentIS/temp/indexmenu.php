<html>
<body>
<div align ="center">

<a href ="std_login.php"> STUDENT </a>
<br>
<a href = "teacher_login.php"> TEACHER </a>

</div>

</body>
</html>
