<?
	session_start();
	session_destroy();
	header("Location: indexmenu.php");		
?>