<?
session_start();
print "<br>" .  $_SESSION["a1"] . "<br>";
print "<br>" .  $_SESSION["a2"] . "<br>";
?>