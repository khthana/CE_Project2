<?
	//Check session register 
	session_start();		

	if(!(isset($_SESSION["username"]) and isset($_SESSION["password"])))
	{
		header("Location: teach_fail.php");
	}
	
		$username = $_SESSION["username"] ;
		$password = $_SESSION["password"] ;
		$personname = $_SESSION["personname"]; 
		$personlastname = $_SESSION["personlastname"]; 
		$type = $_SESSION["type"];
		$person_id = $_SESSION["person_id"];
		$position = $_SESSION["position"];

		
?>