<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>���ͺ��Ѻ</title>
</head>

<body>
<u>���������Źѡ�֡�� <br>
<br>
</u>
<form name="form1" method="post" action="confirm.php">
  <table width="100%" border="0" cellspacing="1" cellpadding="2">
    <tr> 
      <td width="17%">���ʹѡ�֡��</td>
      <td width="83%"><input type="text" name="sid"></td>
    </tr>
    <tr> 
      <td>�ӹ�˹�Ҫ���</td>
      <td><input type="text" name="prename"></td>
    </tr>
    <tr> 
      <td>����</td>
      <td><input type="text" name="name"></td>
    </tr>
    <tr> 
      <td>���ʡ��</td>
      <td><input type="text" name="surname"></td>
    </tr>
    <tr> 
      <td>���Ѿ��</td>
      <td><input type="text" name="tel"></td>
    </tr>
    <tr> 
      <td>����</td>
      <td><input type="text" name="age"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Submit"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<u><br>
</u> 
</body>
</html>
