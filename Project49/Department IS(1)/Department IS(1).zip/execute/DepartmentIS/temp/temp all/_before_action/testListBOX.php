
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>���ͺ��Ѻ</title>
</head>

<body>
<select name="province">
    <?
	include("../../resource/_array.php");
 	 foreach (	$arrayprovince as $valueprovince => $province)
	{				
			if ($valueprovince == 0) {
				$valueprovince = "";
			}
			if ($valueprovince == $province_static){
				$chk ="selected";
				}		
						
  ?>
    <option value="<?=$valueprovince?>" <?=$chk?>>
    <?=$province?>
    </option>
    <?
		$chk ="";
	}
	?>
  </select>
<br>
<br>
<select name="select">
  <?
	$var_day = range(0,31);
 	foreach ($var_day as $theday) {	
		if ($theday == 0) {
			$theday = "";
		}
		if ($theday == $date) {
			$chk = "selected";
		}
		
	?>				
  <option value="<?=$theday?>" <?=$chk?>>
     <?=$theday?>  
	  </option>
  <?		
  		$chk = "";
	}
	?>
</select>
<br>
<br>
<u><br>
</u> 
</body>
</html>
