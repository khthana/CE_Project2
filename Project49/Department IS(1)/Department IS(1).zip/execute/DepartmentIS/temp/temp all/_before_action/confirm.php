<?
include ("_StartConnection.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>���ͺ��Ѻ</title>
</head>

<body>
<u>�׹�ѹ������</u> <br>
<br>
<?
			//print $sid . $prename. $name . $surname . $tel . $age;
		
		if ($tel == "") {
			$tel = "null";
		}
		else {
			$tel = "'".$tel."'";
		}

		if ($age == ""){
			$age = "null";
		}
		$sql ="insert into student values('$sid','$prename','$name','$surname',$tel,$age) ";		
		print $sql;
		if( mysql_query($sql,$conn) )
			{
				print "<div align ='center'>";
				print "�ѹ�֡���º����";
				print "</div>";
			}
			else
			{
				print "<div align ='center'>";
				print "�ջѭ��㹡�úѹ�֡";
				print "</div>";
			}


?>

</body>
</html>
