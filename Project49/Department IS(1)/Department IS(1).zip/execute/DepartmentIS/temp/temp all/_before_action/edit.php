<?
include ("_StartConnection.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>���ͺ��Ѻ</title>
</head>

<body>
[<a href="edit.php">Edit</a>] <br>
<br>
<?
		$sql = "SELECT * FROM student where sid = '47015323'";	
		//print $sql;
		$table = mysql_query($sql,$conn) or die ("�������ö���¡������㹵��ҧ��"); 
		$row=mysql_fetch_array($table);

		$sid = $row[sid];
		$prename = $row[prename];
		$th_name = $row[th_name];
		$th_surname = $row[th_surname];
		$tel = $row[tel];
		$age = $row[age];

?>
<form name="form1" method="post" action="confirm_edit.php">
  <table width="100%" border="0" cellspacing="1" cellpadding="2">
    <tr> 
      <td width="17%">���ʹѡ�֡��</td>
      <td width="83%"><input type="text" name="sid" value ="<?=$sid?>" ></td>
    </tr>
    <tr> 
      <td>�ӹ�˹�Ҫ���</td>
      <td><input type="text" name="prename" value= "<?=$prename?>" ></td>
    </tr>
    <tr> 
      <td>����</td>
      <td><input type="text" name="name" value ="<?=$th_name?>"  ></td>
    </tr>
    <tr> 
      <td>���ʡ��</td>
      <td><input type="text" name="surname" value ="<?=$th_surname?>" ></td>
    </tr>
    <tr> 
      <td>���Ѿ��</td>
      <td><input type="text" name="tel" value ="<?=$tel?>" ></td>
    </tr>
    <tr> 
      <td>����</td>
      <td><input type="text" name="age" value ="<?=$age?>"  ></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="�׹�ѹ�������¹�ŧ"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<u><br>
</u> 
</body>
</html>
