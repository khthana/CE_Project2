
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>���ͺ��Ѻ</title>
</head>

<body>
<br>
<?
		print $province;
		print "<br><a href = 'testlistbox.php'> back</a>";
?>
<br>
<u><br>
</u> 
</body>
</html>
