<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body>
<br>
<?
		$value = 4;
		
?>
<form name="form1" method="post" action="">

  <input type="radio" name="radiobutton" value="radiobutton" <? if ($value == 1) print "checked";?> disabled >  ���<br>
  <input type="radio" name="radiobutton" value="radiobutton" <? if ($value == 2) print "checked";?>disabled>  �ѧ�ش <br>
  <input name="radiobutton" type="radio" value="radiobutton"  <? if ($value == 3) print "checked";?>disabled>  ���С�<br>
  <input name="radiobutton" type="radio" value="radiobutton" <? if ($value == 4) print "checked";?> disabled>  ����ǧ <br>

  <br>
  <input type="submit" name="Submit" value="Submit">
  <input type="reset" name="Submit2" value="Reset">
</form>
</body>
</html>
