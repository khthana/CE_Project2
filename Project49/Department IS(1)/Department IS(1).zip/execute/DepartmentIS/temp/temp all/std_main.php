<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<script type='text/javascript'>

function formValidator1(){
	// Make quick references to our fields
	var name = document.getElementById('name');
	var surname = document.getElementById('surname');
	var sid = document.getElementById('sid');
	var years = document.getElementById('years');
	var telephone = document.getElementById('telephone');

	
	// Check each input in the order that it appears in the form!
	if(isAlphabet(name, "��سһ�͹����")){
		if(isAlphabet(surname, "��سһ�͹���ʡ��")){
			if(isAlphabet(sid, "��سһ�͹����")){
				if(isAlphabet(years, "��سһ�͹�ա���֡��")){
					if(isAlphabet(telephone, "��سһ�͹�����Ţ���Ѿ��")){
						var r=confirm("Press a button")
						if (r==true){
								return true;
						 }
						else{
								return false;
						}						
					}
				}
			}
		}
	}
				
	return false;
	
}

function formValidator(){
	// Make quick references to our fields
	var firstname = document.getElementById('firstname');
	var addr = document.getElementById('addr');
	var zip = document.getElementById('zip');
	var state = document.getElementById('state');
	var username = document.getElementById('username');
	var email = document.getElementById('email');
	
	// Check each input in the order that it appears in the form!
	if(isAlphabet(firstname, "Please enter only letters for your name")){
		if(isAlphanumeric(addr, "Numbers and Letters Only for Address")){
			if(isNumeric(zip, "Please enter a valid zip code")){
				if(madeSelection(state, "Please Choose a State")){
					if(lengthRestriction(username, 6, 8)){
						if(emailValidator(email, "Please enter a valid email address")){
							return true;
						}
					}
				}
			}
		}
	}	
	return false;	
}
function disp_confirm() {
  var r=confirm("Press a button")
  if (r==true){
		document.write("You pressed OK!");
    }
  else{
		document.write("You pressed Cancel!");
    }
  }

function isEmpty(elem, helperMsg){
	if(elem.value.length == 0){
		alert(helperMsg);
		elem.focus(); // set the focus to this input
		return true;
	}
	return false;
}

function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function lengthRestriction(elem, min, max){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		return true;
	}else{
		alert("Please enter between " +min+ " and " +max+ " characters");
		elem.focus();
		return false;
	}
}

function madeSelection(elem, helperMsg){
	if(elem.value == "Please Choose"){
		alert(helperMsg);
		elem.focus();
		return false;
	}else{
		return true;
	}
}

function emailValidator(elem, helperMsg){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
</script>







<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" type="text/css" href="../resource/mystyle.css">
<title>�к����ʹ���Ҥ�Ԫ���ȡ�������������</title>

</head>

<body class = "classbody" >
<table width="750" height="221" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <th height="97" colspan="3" scope="col"><div align="right"></div>
      <div align="left"><img src="../resource/img/newlogo.gif" width="750" height="95"></div></th>
  </tr>
  <tr> 
    <td width="10" height="23" align="left" valign="top" bgcolor="66ffff" scope="col"> <div align="right"><img src="../resource/img/bar_l.gif" width="10" height="23"></div></td>
    <td width="771" align="left" valign="middle" background="../resource/img/bar_c.gif" scope="col"><div align="left"><img src="../resource/img/titre-menu-user.gif" width="16" height="16"> 
        ������к� �س   </div></td>
    <td width="10" background="r" scope="col"><img src="../resource/img/bar_r.gif" width="10" height="23"></td>
  </tr>
  <tr> 
    <td height="39" colspan="3" scope="col"><table cellspacing=0 cellpadding=0 width="100%" border=0>
        <tbody>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width=780 border=0>
                <tbody>
                  <tr> </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                <tbody>
                  <tr> 
                    <td valign=top> <table cellspacing=0 cellpadding=0 width="100%" border=0>
                        <tbody>
                          <tr> 
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer01.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer02.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer02.jpg" 
                        width=8></td>
                            <td valign=top width=8 height=8><img height=8 
                        src="../resource/img/border_footer03.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top 
                      background="../resource/img/border_footer04.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer04.jpg" 
                        width=8></td>
                            <td valign=top><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td align="left" valign="top"><div align="left">
                                 
                                </div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><div align="left">&nbsp;</div></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top"><br>


<!--onsubmit='return formValidator1()' -->
                                    <form name="form1" method="post" action="std_temp.php" onsubmit='return formValidator1()' >
                                      <table width="200" border="1" align="center">
                                        <tr>
                                          <td width="40">����</td>
                                          <td width="144"><input type="text" id = "name" name ="name"></td>
                                        </tr>
                                        <tr>
                                          <td>���ʡ��</td>
                                          <td><input type="text" id="surname"></td>
                                        </tr>
                                        <tr>
                                          <td>����</td>
                                          <td><input type="text" id="sid"></td>
                                        </tr>
                                        <tr>
                                          <td>�ա���֡��</td>
                                          <td><input type="text" id="years"></td>
                                        </tr>
                                        <tr>
                                          <td>�����Ţ���Ѿ��</td>
                                          <td><input type="text" id="telephone"></td>
                                        </tr>
                                      </table>
                                      <div align="center"><br>
                                        <input type="submit" name="Submit" value="�׹�ѹ">
                                        <input type="reset" name="Submit" value="������">
                                      </div>
                                    </form>



                                    <br>

<!--
									<form  method="post" action="std_temp.php" onsubmit='return formValidator()'>
								First Name: <input type='text' id='firstname' /><br />
								Address: <input type='text' id='addr' /><br />
								Zip Code: <input type='text' id='zip' /><br />
								State: <select id='state'>
									<option>Please Choose</option>
									<option>AL</option>
									<option>CA</option>
									<option>TX</option>
									<option>WI</option>
								</select><br />
								Username(6-8 characters): <input type='text' id='username' /><br />
								Email: <input type='text' id='email' /><br />
								<input type='submit' value='Check Form' />
								</form>
	-->
                                    <br>
                                    <br>
                                    <br>
                                    <br>
                                </td>
                              </tr>
                              <tr>
                                <td align="left" valign="top">&nbsp;</td>
                              </tr>
                            </table></td>
                            <td valign=top 
                      background="../resource/img/border_footer05.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer05.jpg" 
                        width=8></td>
                          </tr>
                          <tr> 
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer06.jpg" 
                        width=8></td>
                            <td valign=top 
                      background="../resource/img/border_footer07.jpg"><img 
                        height=8 
                        src="../resource/img/border_footer07.jpg" 
                        width=8></td>
                            <td valign=top><img height=8 
                        src="../resource/img/border_footer08.jpg" 
                        width=8></td>
                          </tr>
                        </tbody>
                      </table></td>
                  </tr>
                </tbody>
              </table></td>
          </tr>
          <tr> 
            <td valign=top height=8><img height=1 
            src="../resource/img/spacer.gif" width=1></td>
          </tr>
        </tbody>
      </table></td>
  </tr>
  <tr> 
    <td height="52" colspan="3" class ="classinfo" scope="col"><div align="center"> 
        <HR align=center width="95%" SIZE=2>
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<BR>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</div></td>
  </tr>
</table>
</body>
</html>
