<?php
			
	include("StartConnection.php");
	$sql ="SELECT * FROM student ";
	$table = mysql_query($sql,$conn) or die ("�������ö�֧������� ������");  
?>
<html>
<head>
<body>
<table width="473" height="58" border="1">
  <tr>
    <td>���ʹѡ�֡��</td>
    <td>����</td>
    <td>���ʡ��</td>
    <td>username</td>
    <td>password</td>
    <td>status</td>
  </tr>
  
  <?  while ($row = mysql_fetch_array($table))
	{
		$sid = $row[0];
		$ssex = $row[1];
		$sname = $row[2];
		$surname = $row[3];
		$susername = $row[4];
		$spassword = $row[5];
		$sstatus = $row[6];		
	
  ?>
 <tr>
	<td><?=$sid?></td>
    <td><?=$ssex . $sname?></td>
    <td><?=$surname?></td>
    <td><?=$susername ?></td>
    <td><?=$spassword?></td>
    <td><?=$sstatus?></td>
  </tr>
  <?
	}
  include("Endconnection.php");
  ?>
</table>			
</body>
</html>