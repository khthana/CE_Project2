<?
session_register( 'a1');
session_register( 'a2');

$_SESSION["a1"] = "Teerayuth";
$_SESSION["a2"] = "Sanhom";

print "<br>" .  $_SESSION["a1"] . "<br>";
print "<br>" .  $_SESSION["a2"] . "<br>";
?>
<a href ="page2.php"> Link </a>
