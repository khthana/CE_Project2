<?
	include ("../resource/_res_function.php");

	$d = "1";
	$m = "1";
	$y = "2550";

	print stringtodate($d,$m,$y);

	$a = date("Y-m-d");
	print "<br>";	
	
	print datetostring($a);

?>