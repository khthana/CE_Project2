<?
$a= date(j); // , 1 to 31
$b = date(a); // am,
$c = date(A); // AM,
$d = date(B); // Swatch Internet time 000 -999
$e = date(d); // , 01 to 31
$f = date(D); // , sat
$g = date(F); // , November
$h = date(g); // , 1 through 12
$hh = date(G); // , 0 through 23
$i = date(h); // , 01 through 12
$j = date(H); // , 00 through 23
$k = date(i); // , 00 to 59
$l = date(I); // 0, 1 if Daylight Savings Time, 0 otherwise.
$m = date(l); // , Sunday through Saturday
$n = date(L); // 0, 1 if it is a leap year, 0 otherwise.
$o = date(m); // , 01 through 12
$p = date(M); // , Jan through Dec
$q = date(n); // , 1 through 12
$r = date(o); // Example: +0200
$s = date(r); // Example: Thu, 21 Dec 2000 16:01:07 +0200
$t = date(s); // 00 through 59
$u = date(S); // st, nd, rd or th. Works well with j
$v = date(t); // 28 through 31
$w = date(T); // time zoneseting Examples: EST, MDT ...
$x = date(u); // See also time()
$y = date(w); // 0 (for Sunday) through 6 (for Saturday)
$z = date(W); // Example: 42 (the 42nd week in the year)
$aa = date(y); // Examples: 99 or 03
$bb = date(Y); // Examples: 1999 or 2003
$cc = date(z);
$dd = date(Z);

if(!$mon){
$mon = $o ;
}else{
$mon = $mon ;

}
if(!$year){
$year = $bb ;
}else{
$year = $year;
}
$firstday = mktime(0,0,0,$mon,1,$bb);
$firstdays = date('w',$firstday);
$lastdays = date('t',$firstday);
$year_view = date('Y',$firstday);
$mon_view = date('m',$firstday);
echo"
<script>
function d_s( su , mnp){
if(mnp == 'm'){
document.dat_form.mon.value = su - 1 ;
}else{
document.dat_form.mon.value = su + 1 ;
}
document.dat_form.submit();
}
</script>
<form name=dat_form action='$PHP_SELF' method=post>
<input type=hidden name=mon value=''>

<table border=1 width=140 cellpadding=0 cellspacing=0 bordercolor=pink>
<tr bgcolor=pink>
<td colspan=7 align=center><a href=\"javascript:d_s($mon,'m')\"><</a>&nbsp;$year_view - $mon_view <a href=\"javascript:d_s($mon,'p')\">></a></td>
</tr>
</form>
<tr align=center><td><font color=red>��</a></td><td>�</td><td>�</td><td>�</td><td>��</td><td>�</td><td><font color=blue>�</font></td></tr>
<tr align=right>";
////
for($i = 0; $i < 7 ; $i++){
if($firstdays == $i){
break;
}
else{
echo"<td width=8>&nbsp;</td>";
}
$week++;
}

for($i=1; $i<=$lastdays ;$i++){
if($week % 7 == 0){
echo"</tr><tr align=right>";
}
if($a == $i){
$bgcolor = "bgcolor=pink";
}else{
$bgcolor = '';
}

if($week%7==0){
echo"<td $bgcolor><font size=2 color=red>$i</font></td>";
}else if($week%7==6){
echo"<td $bgcolor><font size=2 color=blue>$i</font></td>";
}else{ //
echo"<td $bgcolor><font size=2>$i</font></td>";
}
$week++;
}

while($week%7!=0){
echo"<td>&nbsp;</td>";
$week++;
}
echo"</tr>
</table>
";
?>