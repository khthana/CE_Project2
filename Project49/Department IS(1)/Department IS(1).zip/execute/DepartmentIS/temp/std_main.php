<?
	include ("_checksession.php");
	print "Login Success";
	print " you are " . $type ;
	



?>
<br>
<a href = "std_login.php"> LOGIN AGAIN </a>
<br>
<a href = "indexmenu.php"> MENU </a>
<br>
<a href = "_logout.php"> LOGOUT</a>
