/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created: Thu Feb 1 19:39:59 2007
**      by: The Qt Meta Object Compiler version 59 (Qt 4.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MainWindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

static const uint qt_meta_data_MainWindow[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      22,   11,   11,   11, 0x0a,
      37,   11,   11,   11, 0x0a,
      57,   11,   11,   11, 0x0a,
      71,   11,   11,   11, 0x0a,
      86,   11,   11,   11, 0x0a,
     100,   11,   11,   11, 0x0a,
     107,   11,   11,   11, 0x0a,
     120,   11,   11,   11, 0x0a,
     132,   11,   11,   11, 0x0a,
     140,   11,   11,   11, 0x0a,
     150,   11,   11,   11, 0x0a,
     169,   11,   11,   11, 0x0a,
     188,   11,   11,   11, 0x0a,
     206,   11,   11,   11, 0x0a,
     217,   11,   11,   11, 0x0a,
     227,   11,   11,   11, 0x0a,
     250,   11,   11,   11, 0x0a,
     261,   11,   11,   11, 0x0a,
     279,   11,  274,   11, 0x0a,
     303,   11,   11,   11, 0x0a,
     323,   11,   11,   11, 0x0a,
     344,   11,   11,   11, 0x0a,
     360,   11,   11,   11, 0x0a,
     372,   11,   11,   11, 0x0a,
     383,   11,   11,   11, 0x0a,
     394,   11,   11,   11, 0x0a,
     418,  413,  405,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0trigger()\0takesnapshot()\0check_kernel_name()\0"
    "show_result()\0startprocess()\0stopprocess()\0read()\0setAdvance()\0"
    "setSilent()\0about()\0s_alert()\0hideSilentResult()\0showSilentResult()\0"
    "resetBeforeScan()\0writeLog()\0showLog()\0refresh_syscall_page()\0"
    "activate()\0deactivate()\0bool\0check_daemon_function()\0"
    "check_daemon_slot()\0check_trigger_slot()\0check_trigger()\0writename()\0"
    "writemap()\0writepre()\0writecur()\0QString\0path\0"
    "check_date_time_filename(QString)\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

const QMetaObject *MainWindow::metaObject() const
{
    return &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
	return static_cast<void*>(const_cast<MainWindow*>(this));
    if (!strcmp(_clname, "Ui::MainWindow"))
	return static_cast<Ui::MainWindow*>(const_cast<MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: trigger(); break;
        case 1: takesnapshot(); break;
        case 2: check_kernel_name(); break;
        case 3: show_result(); break;
        case 4: startprocess(); break;
        case 5: stopprocess(); break;
        case 6: read(); break;
        case 7: setAdvance(); break;
        case 8: setSilent(); break;
        case 9: about(); break;
        case 10: s_alert(); break;
        case 11: hideSilentResult(); break;
        case 12: showSilentResult(); break;
        case 13: resetBeforeScan(); break;
        case 14: writeLog(); break;
        case 15: showLog(); break;
        case 16: refresh_syscall_page(); break;
        case 17: activate(); break;
        case 18: deactivate(); break;
        case 19: { bool _r = check_daemon_function();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 20: check_daemon_slot(); break;
        case 21: check_trigger_slot(); break;
        case 22: check_trigger(); break;
        case 23: writename(); break;
        case 24: writemap(); break;
        case 25: writepre(); break;
        case 26: writecur(); break;
        case 27: { QString _r = check_date_time_filename((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        }
        _id -= 28;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::trigger()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
