#ifndef MAINWINDOWS_H
#define MAINWINDOWS_H

#include <QMainWindow>
#include <QProcess>

#include "ui_MainWindow.h"

class MainWindow : public QMainWindow, public Ui::MainWindow
{
    Q_OBJECT
public:
	MainWindow(QWidget *parent = 0);
	QProcess *Rootkit_Scan; // Process for scan rootkit
	QString TextBrowserString ;
	QStringList list;
	

	QString kernel_name ;
	QString writename_str ;
	QString writemap_str ;
	QString writepre_str ;
	QString writecur_str ;
	QString guard_result_text ;
	
	
	// Rootkit - Guard
	QProcess *Rootkit_Guard; // Process for guard rootkit.
	QProcess *temp_process; // Process for start, stop daemons.
	QProcess *writename_process; // Process for write name to syscall table.
	QProcess *writemap_process; // Process for write map address to syscall table.	
	QProcess *writepre_process; // Process for write pre map address to syscall table.	
	QProcess *writecur_process; // Process for write cur map address to syscall table.	

	QProcess *check_date_time_filename_process ;
	QProcess *show_result_process;
	
	QStringList SystemCall_StringList;
	QString tempstr;
	bool isdaemonstart;
	
	QProcess *trigger_process;	// process for get time signal
	QString check_trigger_str;

	
	int status ; //  status for System call 0 ok , 1 map error , 2 kernel error;
	
	// syscall table index.
	int iname,imap,icur,ipre ;
	int incrow;
	
	
	
public slots:
	void takesnapshot();
	void check_kernel_name();
	void show_result();
	// Scan
	void startprocess();
	void stopprocess();
	void read();
	void setAdvance();
	void setSilent();
	void about();
	void s_alert();
	void hideSilentResult();
	void showSilentResult();
	void resetBeforeScan();
	void writeLog();
	void showLog();
	
	// refresh_syscall_page every 5s. From sec signals.
	void refresh_syscall_page();
	
	// Guard
	void activate();
	void deactivate();
	
	
	bool check_daemon_function();	// check daemon function.
	void check_daemon_slot();	// check daemon slot.

	void check_trigger_slot();	
	void check_trigger();
	
	
	void writename();
	void writemap();
	void writepre();
	void writecur();
	
	QString check_date_time_filename(QString path);
	
	
	
	
signals :
	void trigger();	

		
};

#endif

