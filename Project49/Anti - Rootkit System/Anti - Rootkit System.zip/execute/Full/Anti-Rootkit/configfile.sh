#!/bin/sh

rm /Anti-Rootkit/Rootkit-Guard/bin/map
rm /Anti-Rootkit/Rootkit-Guard/bin/map.cur
rm /Anti-Rootkit/Rootkit-Guard/bin/maperror

chmod 744 /Anti-Rootkit/Anti-Rootkit
chmod 744 /Anti-Rootkit/Rootkit-Scan/check_wtmpx
chmod 744 /Anti-Rootkit/Rootkit-Scan/Rootkit-Scan
chmod 744 /Anti-Rootkit/Rootkit-Scan/chklastlog
chmod 744 /Anti-Rootkit/Rootkit-Scan/chkutmp
chmod 744 /Anti-Rootkit/Rootkit-Scan/ifpromisc
chmod 744 /Anti-Rootkit/Rootkit-Scan/strings-static
chmod 744 /Anti-Rootkit/Rootkit-Scan/chkwtmp
chmod 744 /Anti-Rootkit/Rootkit-Scan/chkproc
chmod 744 /Anti-Rootkit/Rootkit-Scan/chkdirs

echo "System.map-`uname -r`" > /Anti-Rootkit/kernel_name.txt

chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/Rootkit-Guard
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/kernelcheck
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/mapcheck
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/namecheck
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/syscall
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/wrapper
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/get_date_time.sh

# make_map.sh
echo "#!/bin/sh
/Anti-Rootkit/Rootkit-Guard/bin/./kernelcheck -v /boot/System.map-`uname -r` > /Anti-Rootkit/Rootkit-Guard/bin/map" > /Anti-Rootkit/Rootkit-Guard/bin/make_map.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/make_map.sh

# warning.sh
echo "#!/bin/sh
/Anti-Rootkit/Rootkit-Guard/bin/./syscall -v /boot/System.map-`uname -r` | grep WARN > /Anti-Rootkit/Rootkit-Guard/bin/warning"  > /Anti-Rootkit/Rootkit-Guard/bin/warning.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/warning.sh

# syserror.sh
echo "#!/bin/sh
echo syserror > syserror" > /Anti-Rootkit/Rootkit-Guard/bin/syserror.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/syserror.sh

# maperror.sh
echo "#!/bin/sh
echo maperror > maperror" > /Anti-Rootkit/Rootkit-Guard/bin/maperror.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/maperror.sh

# check_premap.sh
echo "#!/bin/sh
cat /Anti-Rootkit/Rootkit-Guard/bin/map" > /Anti-Rootkit/Rootkit-Guard/bin/check_premap.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/check_premap.sh

# check_curmap.sh
echo "/Anti-Rootkit/Rootkit-Guard/bin/./kernelcheck -v /boot/System.map-`uname -r` > /Anti-Rootkit/Rootkit-Guard/bin/map.cur
cat /Anti-Rootkit/Rootkit-Guard/bin/map.cur" > /Anti-Rootkit/Rootkit-Guard/bin/check_curmap.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/check_curmap.sh

# check_sysmap.sh
echo "#!/bin/sh
/Anti-Rootkit/Rootkit-Guard/bin/./syscall -v /boot/System.map-`uname -r` | grep WARNING" > /Anti-Rootkit/Rootkit-Guard/bin/check_sysmap.sh
chmod 744 /Anti-Rootkit/Rootkit-Guard/bin/check_sysmap.sh

# asdaemon.sh
echo "#!/bin/sh
ln -s /Anti-Rootkit/Rootkit-Guard/bin/Rootkit-Guard /etc/init.d/Rootkit-Guard
cd /etc/init.d
update-rc.d Rootkit-Guard defaults" > /Anti-Rootkit/asdaemon.sh
chmod 744 /Anti-Rootkit/asdaemon.sh















