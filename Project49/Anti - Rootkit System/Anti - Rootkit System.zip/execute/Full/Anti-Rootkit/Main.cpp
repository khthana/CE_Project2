#include <QApplication>
#include "MainWindow.cpp"
int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	
	QSplashScreen *splash = new QSplashScreen;
	splash->setPixmap(QPixmap("splash.png"));
	splash->show();
	Qt::Alignment topRight = Qt::AlignRight | Qt::AlignTop;
	
	for (int i = 0 ; i < 20 ; i++){
	splash->showMessage(QObject::tr("Setting up the main window.  "), topRight, Qt::darkGray);}
	for (int i = 0 ; i < 15 ; i++){
	splash->showMessage(QObject::tr("Setting up the main window.. "), topRight, Qt::darkGray);}
	for (int i = 0 ; i < 25 ; i++){
	splash->showMessage(QObject::tr("Setting up the main window..."), topRight, Qt::darkGray);}

	//MainWindow *mainwindow = new MainWindow;
	//MainWindow mainwindow;
	MainWindow mainWin;
	
	for (int i = 0 ; i < 20 ; i++){
	splash->showMessage(QObject::tr("Loading Modules.  "), topRight, Qt::darkGray);}
	for (int i = 0 ; i < 15 ; i++){
	splash->showMessage(QObject::tr("Loading Modules.. "), topRight, Qt::darkGray);}
	for (int i = 0 ; i < 25 ; i++){
	splash->showMessage(QObject::tr("Loading Modules..."), topRight, Qt::darkGray);}


	//mainwindow->show();
	
	mainWin.show();
	splash->finish(&mainWin);
	delete splash;
	return app.exec();
}

