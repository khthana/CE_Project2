#!/bin/sh
ln -s /Anti-Rootkit/Rootkit-Guard/bin/Rootkit-Guard /etc/init.d/Rootkit-Guard
cd /etc/init.d
update-rc.d Rootkit-Guard defaults
