#include <QtGui>
#include "MainWindow.h"
#include <QMessageBox>
#include <iostream>

int command_row = 0;
int default_row = 0;
int nextpage = 0;
int progress = 0;
int scanAlert = 0;
int totalInfectedCommand = 0;
int totalRootkitDefault = 0;
int lastscan = 0;
int log_row = 0;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
	check_kernel_name();
	iname = 0 ;
	imap = 0 ;
	icur = 0 ;
	ipre = 0 ;
	status = 0;
	incrow = 0 ;
	setupUi(this);
	scan_result->hide();
	scan_progress->hide();
	guard_result->hide();
	guard_result_tab->hide();
	hideSilentResult();
	showLog();
	
	connect(Scan_QPushButton,SIGNAL(clicked()),this,SLOT(startprocess())); 
	connect(Stop_QPushButton,SIGNAL(clicked()),this,SLOT(stopprocess())); 
	connect(actionAdvance_Mode2,SIGNAL(triggered()),this,SLOT(setAdvance()));
	connect(actionSilent_Mode2,SIGNAL(triggered()),this,SLOT(setSilent()));
	connect(actionExit,SIGNAL(triggered()),qApp,SLOT(closeAllWindows()));
	connect(actionAbout,SIGNAL(triggered()),this,SLOT(about()));	
	
	
	
//-------------------------- Rootkit - Guard  ----------------------------------------//
	
	
	connect(takesnapshot_button,SIGNAL(clicked()),this,SLOT(takesnapshot()));
	
	// Check daemon is started ?
	isdaemonstart = check_daemon_function();
	if (isdaemonstart) // Daemon is running. disable Activate
	{	System_Call_groupBox->show();
		Activate_QPushButton->setEnabled(0); // 0 is disable , 1 enable 
		Deactivate_QPushButton->setEnabled(1);
		activate();
	}
	else	// enable Activate
	{	System_Call_groupBox->hide();
		Activate_QPushButton->setEnabled(1);
		Deactivate_QPushButton->setEnabled(0);
		
	}
	
	connect(Activate_QPushButton,SIGNAL(clicked()),this,SLOT(activate())); 
	connect(Deactivate_QPushButton,SIGNAL(clicked()),this,SLOT(deactivate())); 
	connect(action_activate,SIGNAL(triggered()),this,SLOT(activate())); 
	connect(action_deactivate,SIGNAL(triggered()),this,SLOT(deactivate())); 

//-------------------------- End Rootkit - Guard code ----------------------------------------//


}
// check kernel name 
void MainWindow::check_kernel_name()
{
	temp_process = new QProcess();
	temp_process->start(QString("cat")
			,QStringList() <<"/Anti-Rootkit/kernel_name.txt");
	temp_process->setReadChannelMode(QProcess::MergedChannels); 
	temp_process->setReadChannel(QProcess::StandardOutput);
	temp_process->waitForFinished(-1);
	kernel_name = temp_process->readAllStandardOutput();
	kernel_name.remove(kernel_name.length()-1,1);
	
	std::cout << "check_kernel_name" << std::endl;
	//QMessageBox::information( 0, "signals", kernel_name );
	//QMessageBox::information( 0, "length", QString::number(kernel_name.length(),10) );
}

void MainWindow::activate()
{	// Activate Rootkit-Guard
	if (!isdaemonstart)
	{	
		temp_process = new QProcess();
		temp_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./Rootkit-Guard")
			,QStringList() <<"start");
		isdaemonstart = true;
	}
	
	// show box and disable activated button.
	System_Call_groupBox->show();
	Activate_QPushButton->setEnabled(0);
	Deactivate_QPushButton->setEnabled(1);
	logo_guard->hide();
	guard_info->show();
	guard_result->show();
	guard_result_tab->show();
	
	// run for get trigger time; Then draw syscall table.
	connect(this,SIGNAL(trigger()),this,SLOT(refresh_syscall_page())); 
	check_trigger();
	refresh_syscall_page();
	
}


void MainWindow::takesnapshot()
{
	temp_process = new QProcess();
	temp_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./make_map.sh")
		,QStringList() <<"status");
	temp_process->waitForFinished(-1);

}
// check_daemon is started?
bool MainWindow::check_daemon_function()
{
	bool isstarted;
	temp_process = new QProcess();
	temp_process->setReadChannelMode(QProcess::MergedChannels); 
	temp_process->setReadChannel(QProcess::StandardOutput);
	connect(temp_process,SIGNAL(readyReadStandardOutput()),this,SLOT(check_daemon_slot())); 
	
	temp_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./Rootkit-Guard")
		,QStringList() <<"status");
	temp_process->waitForFinished(-1);
	if (tempstr.indexOf("not") == -1)
		isstarted = true;
	else
		isstarted = false;
	return isstarted;
}
// Check daemon slot
void MainWindow::check_daemon_slot()
{
	tempstr.append(temp_process->readAllStandardOutput());	
}

// Deactivate Daemon.
void MainWindow::deactivate()
{
	temp_process = new QProcess();
	temp_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./Rootkit-Guard")
		,QStringList() <<"stop");
	isdaemonstart = false;
	Activate_QPushButton->setEnabled(1);
	Deactivate_QPushButton->setEnabled(0);
	System_Call_groupBox->hide();
	logo_guard->show();
	guard_info->show();
	guard_result->hide();
	guard_result_tab->hide();
	trigger_process->kill();
}

// Refresh table from trigger signals
void MainWindow::refresh_syscall_page()
{	

	//QMessageBox::about(this, tr("netstat -an"),tr("AA"));
	
	iname = 0 ;
	imap = 0 ;
	icur = 0 ;
	ipre = 0 ;
	
// ------------------ write name and system_map to table. ----------------- //
	// write name.
	writename_process = new QProcess();
	writename_process->setReadChannelMode(QProcess::MergedChannels); 
	writename_process->setReadChannel(QProcess::StandardOutput);	

	connect(writename_process,SIGNAL(readyReadStandardOutput()),this,SLOT(writename())); 	
	writename_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./namecheck"),QStringList() <<"-v" << "/boot/" + kernel_name);
	//QMessageBox::information( 0, "signals", "/boot/" + kernel_name );
	writename_process->waitForFinished(-1);
	incrow = 1 ;
	
	// write map.
	writemap_process = new QProcess();
	writemap_process->setReadChannelMode(QProcess::MergedChannels); 
	writemap_process->setReadChannel(QProcess::StandardOutput);	
	connect(writemap_process,SIGNAL(readyReadStandardOutput()),this,SLOT(writemap())); 
	writemap_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./mapcheck"),QStringList() <<"-v" << 		"/boot/" + kernel_name);

	writemap_process->waitForFinished(-1);
	// write pre.
	writepre_process = new QProcess();
	writepre_process->setReadChannelMode(QProcess::MergedChannels); 
	writepre_process->setReadChannel(QProcess::StandardOutput);	
	connect(writepre_process,SIGNAL(readyReadStandardOutput()),this,SLOT(writepre())); 
	writepre_process->start(QString("cat"),QStringList() <<"/Anti-Rootkit/Rootkit-Guard/bin/map");
	writepre_process->waitForFinished(-1);
	
	// write cur.
	writecur_process = new QProcess();
	writecur_process->setReadChannelMode(QProcess::MergedChannels); 
	writecur_process->setReadChannel(QProcess::StandardOutput);	
	connect(writecur_process,SIGNAL(readyReadStandardOutput()),this,SLOT(writecur())); 
	writecur_process->start(QString("cat"),QStringList() <<"/Anti-Rootkit/Rootkit-Guard/bin/map.cur");
	writecur_process->waitForFinished(-1);
	
	
	
	if (status == 0) // ok
	{	guard_result1->setText("Your system is reliable.");
		
		QString str = check_date_time_filename(QString("/Anti-Rootkit/Rootkit-Guard/bin/map"));
		str = QString("Snapshot1 on :") + str ;
		guard_result2->setText(str);
		Result_Guard->setText(" Your system is ok.");
	//	QMessageBox::information( 0, "signals1", str );
	}
	if (status == 1) // map <> cur
	{
		guard_result1->setText(tr("Caution : Your system is <b>not reliable</b>.<br/> System call miss match."));
	//	QMessageBox::information( 0, "signals", "refresh_syscall_page 1 " );
		QString str = check_date_time_filename(QString("/Anti-Rootkit/Rootkit-Guard/bin/map"));
		str = QString("Snapshot2 on :") + str ;
		guard_result2->setText(str);
		
		show_result_process = new QProcess();
		//connect(show_result_process,SIGNAL(readyReadStandardOutput()),this,SLOT(show_result())); 
		show_result_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./warning.sh"));
		show_result_process->waitForFinished(-1);
		show_result_process = new QProcess();
		show_result_process->setReadChannelMode(QProcess::MergedChannels); 
		show_result_process->setReadChannel(QProcess::StandardOutput);	
		show_result_process->start(QString("cat"),QStringList() << "/Anti-Rootkit/Rootkit-Guard/bin/warning");
		show_result_process->waitForFinished(-1);
		show_result();
		
	//	QMessageBox::information( 0, "signals2", str );
	}
	if (status == 2) // cur <> pre
	{
		guard_result1->setText(tr("Caution : Your system is <b>not reliable</b>.<br/> System call miss match."));
	//	QMessageBox::information( 0, "signals", "refresh_syscall_page 2 " );
		QString str = check_date_time_filename(QString("/Anti-Rootkit/Rootkit-Guard/bin/map"));
		str = QString("Snapshot3 on :") + str ;
		guard_result2->setText(str);
	//	QMessageBox::information( 0, "signals3", str );
	}
}
void MainWindow::show_result()
{
	//QString str = show_result_process->readAllStandardOutput();
//	QString str = show_result_process->readAllStandardOutput();
	//QString str = " Possible rootkit :\n Adore - Ng detected.\n Different systemcall :\n inode_operations";
	guard_result_text = show_result_process->readAllStandardOutput() ;
	if (guard_result_text.indexOf("sys_getdents64") != -1)
	{
		guard_result_text = guard_result_text + "\n ls command is infected." ;
	}
	Result_Guard->setText(guard_result_text);
	
}

// ls -la map | (read i j k l m n o p; echo $n $o)  -- get date and time file name
// Input path of file name return Date and time of filename.
QString MainWindow::check_date_time_filename(QString path)
{
	check_date_time_filename_process = new QProcess();
	check_date_time_filename_process->start(QString("/Anti-Rootkit/Rootkit-Guard/bin/./get_date_time.sh")
			,QStringList() << path);
	check_date_time_filename_process->setReadChannelMode(QProcess::MergedChannels); 
	check_date_time_filename_process->setReadChannel(QProcess::StandardOutput);
	check_date_time_filename_process->waitForFinished(-1);
		
	QString str = check_date_time_filename_process->readAllStandardOutput();
	str.remove(str.length()-1,1);
		
	return str;

}
void MainWindow::writename()
{	
	writename_str.append(writename_process->readAllStandardOutput());
	while(writename_str.indexOf("]") != -1)
	{		
		if (incrow == 0)
			syscalltableWidget->insertRow(iname);
		
		writename_str.remove(0,1);
		QString str = writename_str.left(writename_str.indexOf("]"));
		writename_str.remove(0,writename_str.indexOf("]")+2);
		QTableWidgetItem *item = new QTableWidgetItem;
		item->setText(str);
		syscalltableWidget->setVerticalHeaderItem(iname, item);
		iname++;
	}
//	QMessageBox::information( 0, "writename", "writename" );
}

void MainWindow::writemap()
{
	writemap_str.append(writemap_process->readAllStandardOutput());
	//QMessageBox::information( 0, "signals", writemap_str);
	while(writemap_str.indexOf("]") != -1)
	{		
		writemap_str.remove(0,1);
		QString str = writemap_str.left(writemap_str.indexOf("]"));
		writemap_str.remove(0,writemap_str.indexOf("]")+2);
		QTableWidgetItem *item = new QTableWidgetItem;
		item->setText(str);
		syscalltableWidget->setItem(imap,0,item);
		imap++;
	}
//	QMessageBox::information( 0, "writemap" , "writemap" );

}

void MainWindow::writepre()
{
	writepre_str.append(writepre_process->readAllStandardOutput());
	//QMessageBox::information( 0, "signals", writepre_str);
	while(writepre_str.indexOf("]") != -1)
	{		
		writepre_str.remove(0,1);
		QString str = writepre_str.left(writepre_str.indexOf("]"));
		writepre_str.remove(0,writepre_str.indexOf("]")+2);
		QTableWidgetItem *item = new QTableWidgetItem;
		item->setText(str);
		syscalltableWidget->setItem(ipre,1,item);
		ipre++;
	}

//	QMessageBox::information( 0, "writepre" , "writepre" );
}

void MainWindow::writecur()
{
	writecur_str.append(writecur_process->readAllStandardOutput());
	
	while(writecur_str.indexOf("]") != -1)
	{		
		writecur_str.remove(0,1);
		QString str = writecur_str.left(writecur_str.indexOf("]"));
		writecur_str.remove(0,writecur_str.indexOf("]")+2);
		QTableWidgetItem *item = new QTableWidgetItem;
		item->setText(str);
		syscalltableWidget->setItem(icur,2,item);
		icur++;
	}
	
//	QMessageBox::information( 0, "writecur" , "writecur" );

}

void MainWindow::check_trigger()
{
	trigger_process = new QProcess();
	trigger_process->setReadChannelMode(QProcess::MergedChannels); 
	trigger_process->setReadChannel(QProcess::StandardOutput);
	connect(trigger_process,SIGNAL(readyReadStandardOutput()),this,SLOT(check_trigger_slot())); 
	trigger_process->start(QString("java"),QStringList() <<"-classpath" << "/Anti-Rootkit/Rootkit-Guard/bin" << "sec_signals");
	
}

void MainWindow::check_trigger_slot()
{
	
	//check_trigger_str.append(trigger_process->readAllStandardOutput());
	check_trigger_str = trigger_process->readAllStandardOutput();
	//QMessageBox::information( 0, "FIRST", "FIRST" );
	if (check_trigger_str.indexOf("maperror") != -1) // map <> current system call.
	{
	//	check_trigger_str.remove(0,10);
		status = 1 ;	// map error
	//	QMessageBox::information( 0, "maperror", check_trigger_str );
		emit trigger();
		
	}
	
	if (check_trigger_str.indexOf("syserror") != -1)	// previous system call <> current system call.
	{
	//	check_trigger_str.remove(0,10);
		status = 2 ;
	//	QMessageBox::information( 0, "syserror", check_trigger_str );
		emit trigger();
	}
	
	if (check_trigger_str.indexOf("trigger]") != -1)	// OK.
	{
		//QMessageBox::information( 0, "trigger]", check_trigger_str );
	//	check_trigger_str.remove(0,10);
		status = 0 ;
	//	status++;
	//	itemx->setText(QString::number(status,10));
		//syscalltableWidget->setVerticalHeaderItem(0,itemx);
		//QMessageBox::information( 0, "QString::number(status,10)", QString::number(status,10) );
	//	syscalltableWidget->setItem(0,2,itemx);
		//syscalltableWidget->setCurrentIndex(0,QItemSelectionModel::Current);
		emit trigger();
	}
	
	
}

//-------------------------------- Start Rootkit-Scan Function ------------------------------ //

void MainWindow::read()
{
	//------------------ Read value from Rootkit Scan ----------------------//
	QTableWidgetItem *infected_item = new QTableWidgetItem;
	QTableWidgetItem *infected_item_r = new QTableWidgetItem;
	TextBrowserString.append(Rootkit_Scan->readAllStandardOutput());
	progressBar->setValue(progress);
	++progress;
	while (TextBrowserString.indexOf("]") != -1)
	{	
		// Separate outout into 2 tabs
		if(TextBrowserString.indexOf("AAAAA") > -1) 
		{
			nextpage = 1;
			TextBrowserString.remove(TextBrowserString.indexOf("AAAAA"),6);
		}
		
		// if nextpage < 1, show result at infected_command tab
		if (nextpage < 1) {
			if (Advance->checkState() != 0) {
			// show result in Advanced Mode
				if (TextBrowserString.indexOf("not") == -1){
					++totalInfectedCommand;
				}
				infected_command->insertRow(command_row);
				infected_item->setText(TextBrowserString.left(TextBrowserString.indexOf("[")));
				infected_command->setItem(command_row,0,infected_item);
				TextBrowserString.remove(0,TextBrowserString.indexOf("[")+1);
				
				// show status of command
				infected_item_r->setText(TextBrowserString.left(TextBrowserString.indexOf("]")));
				infected_command->setItem(command_row,1,infected_item_r);
				TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
				++command_row;
			}
			else {
			// show Infected command result (Silent Mode)
				if (TextBrowserString.indexOf("not") == -1){
					infected_command->insertRow(command_row);
					
					infected_item->setText(TextBrowserString.left(TextBrowserString.indexOf("[")));
					infected_command->setItem(command_row,0,infected_item);
					TextBrowserString.remove(0,TextBrowserString.indexOf("[")+1);
					
					// show status of command
					infected_item_r->setText(TextBrowserString.left(TextBrowserString.indexOf("]")));
					infected_command->setItem(command_row,1,infected_item_r);
					TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
					++command_row;
					++totalInfectedCommand;
					}
				else{
					TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
				}
			}
		}else{
			// show result in Advanced Mode	
			if(Advance->checkState() != 0) {
				if (TextBrowserString.indexOf("not") == -1){
					++totalRootkitDefault;
				}
				default_file->insertRow(default_row);
				infected_item->setText(TextBrowserString.left(TextBrowserString.indexOf("[")));
				default_file->setItem(default_row,0,infected_item);
				TextBrowserString.remove(0,TextBrowserString.indexOf("[")+1);
				
				// show status of scanning rootkit default file
				infected_item_r->setText(TextBrowserString.left(TextBrowserString.indexOf("]")));
				default_file->setItem(default_row,1,infected_item_r);
				TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
				++default_row;
			}
			else{
				// show result of rootkit's default file tab (silent Mode)
				if (TextBrowserString.indexOf("not") == -1){
					default_file->insertRow(default_row);
					infected_item->setText(TextBrowserString.left(TextBrowserString.indexOf("[")));
					default_file->setItem(default_row,0,infected_item);
					TextBrowserString.remove(0,TextBrowserString.indexOf("[")+1);
					
					// show status of scanning rootkit default file
					infected_item_r->setText(TextBrowserString.left(TextBrowserString.indexOf("]")));
					default_file->setItem(default_row,1,infected_item_r);
					TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
					++default_row;
					++totalRootkitDefault;
				} else {
					// if not found any files, cross out current string
					TextBrowserString.remove(0,TextBrowserString.indexOf("]")+2);
				}
			}
		}
	}
	infected_command->resizeColumnsToContents();
	default_file->resizeColumnsToContents();
	
	if ((progress > 99) and (totalInfectedCommand < 1) and (totalRootkitDefault < 1 ) and (Advance->checkState() == 0))
	{
		// Complete Scan but not found any infected command and rootkit's default files.
		showSilentResult();
	} 
	
	if (scanAlert < 1)
	{
		connect(Rootkit_Scan, SIGNAL(finished(int, QProcess::ExitStatus)),this,SLOT(s_alert()));
	}
	
}

void MainWindow::startprocess()
{	// Start New Scan-Rootkit Process
	TextBrowserString = "";
	Rootkit_Scan = new QProcess() ;
	Rootkit_Scan->setReadChannelMode(QProcess::MergedChannels);
	Rootkit_Scan->setReadChannel(QProcess::StandardOutput);
	
	infected_command->clearContents();
	infected_command->setRowCount(0);
	default_file->clearContents();
	default_file->setRowCount(0);
	Stop_QPushButton->setEnabled(1);
	
	scan_result->show();
	scan_progress->show();
	progressBar->show();
	infected_command->show();
	default_file->show();
	
	rootkitScan_label->hide();
	logo->hide();
	stop->hide();
	
	hideSilentResult();
	// reset every related variable before next scan
	resetBeforeScan();
	connect(Rootkit_Scan,SIGNAL(readyReadStandardOutput()),this,SLOT(read())); 
	Rootkit_Scan->start(QString("sh"),QStringList() << "./Rootkit-Scan/Rootkit-Scan" );
}
void MainWindow::stopprocess()
{
	// Stop Scan-Rootkit Process
	Rootkit_Scan->kill();
	if (progress < 100){
		progressBar->hide();
		stop->show();	// show "stop scanning" text
	}
}

void MainWindow::setAdvance()
{
	Advance->setChecked(1);  // Activate Advanced Mode
}

void MainWindow::setSilent()
{
	Advance->setChecked(0);  // Activate Silent Mode
}

void MainWindow::about()
{
	QMessageBox::about(this, tr("About Anti-Rootkit System"),
		tr("<h3>Loki</h3>"
		   "<p>Copyright &copy; 2006-2007"
		   "<p>Created by: <br>Kamon Laohasukpaisan <br>Jaroonchai Thampipat"
		   "<p>Information Security Advisory Group (ISAG)"
		   "<br>Computer Engineering Department"
		   "<br>King Mongkut's Institute of Technology Ladkrabang"));
}

//void MainWindow::s_alert(int exitCode,QProcess::ExitStatus exitStatus)
void MainWindow::s_alert()
{
	//if (exitStatus == QProcess::CrashExit){
	//} else if (exitCode != 0) {
	//} else 
	if ((scanAlert < 1) and ((totalInfectedCommand >= 1) or (totalRootkitDefault > 1 ))) {
		QMessageBox::warning( this, tr("Warning: System Modification found !"),
			tr("<p>Your system has been modified"
			"<p>total infected command found: ")
			+ QString::number(totalInfectedCommand,10) + // number of infected command variable
			tr("<p>total rootkit's default files found: ")
			+ QString::number(totalRootkitDefault,10)); // number of rootkit default files variable
	}
	Stop_QPushButton->setEnabled(0);
	if(scanAlert < 1 and progress > 99)
	{
		writeLog();
	}
	++scanAlert;
}

void MainWindow::hideSilentResult()
{
	info_label->hide();
	infected_result1->hide();
	infected_result2->hide();
	default_result2->hide();
}

void MainWindow::showSilentResult()
{
	infected_command->hide();
	default_file->hide();
	infected_result1->show();
	if (totalInfectedCommand < 1) {
		infected_result2->show();
	}
	if (totalRootkitDefault < 1 ) {
		default_result2->show();
	}
	info_label->show();
}

void MainWindow::resetBeforeScan()
{
	progressBar->reset();
	command_row = 0;
	default_row = 0;
	nextpage = 0;
	progress = 0;	
	scanAlert = 0;
	totalInfectedCommand = 0;
	totalRootkitDefault = 0;
}

void MainWindow::writeLog()
{
	// ----------------- Test Writing File -------------------------- //
	QFile file("in.txt");
	if (!file.open(QIODevice::Append)) {
		std::cout << "Cannot open file for writing: ";
		return;
	}
	QDate cDate = QDate::currentDate();
	QTime cTime = QTime::currentTime();
	QString saveLog;
	QTextStream out(&file);
	
	if((totalInfectedCommand == 0) and (totalRootkitDefault <= 1))
	{
		saveLog = cDate.toString() + " " + cTime.toString() + "[ok]";
	}
	else {
		saveLog = cDate.toString() + " " + cTime.toString() +  "[" + QString::number(totalInfectedCommand,10) + " infected command, " + QString::number(totalRootkitDefault-1,10) + " default rootkit files]";
	}
	out << saveLog << endl;
	file.close();
	// -------------------------------------------------------------- //
}

void MainWindow::showLog()
{
	// -------------------- view Scan's log file ---------------------- //
	QFile file("in.txt");
	
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
		return;
	QTextStream in(&file);
	QString line;
	while (!in.atEnd()) {
		line.append(in.readLine());
	}
	file.close();
	
	while (line.indexOf("[") != -1)
	{
		log_table->insertRow(log_row++);
		QTableWidgetItem *log_date = new QTableWidgetItem;
		log_date->setText(line.left(line.indexOf("[")));
		last_scan->setText(line.left(line.indexOf("[")));
		log_table->setItem(log_row - 1 , 0, log_date);
		line.remove(0, line.indexOf("[") + 1);
		
		QTableWidgetItem *log_status = new QTableWidgetItem;
		log_status->setText(line.left(line.indexOf("]")));	
		log_table->setItem(log_row - 1, 1, log_status);
		line.remove(0, line.indexOf("]") + 1);
	}
	log_table->resizeColumnsToContents();
	total_scan->setText(QString::number(log_table->rowCount(),10) + " times");
	// ------------------------------------------------------------- //
}

