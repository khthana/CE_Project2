/********************************************************************************
** Form generated from reading ui file 'MainWindow.ui'
**
** Created: Thu Feb 1 19:39:48 2007
**      by: Qt User Interface Compiler version 4.2.1
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGroupBox>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QWidget>

class Ui_MainWindow
{
public:
    QAction *actionExit;
    QAction *actionAbout;
    QAction *actionNormal_Mode;
    QAction *actionSilent_Mode;
    QAction *actionAdvance_Mode;
    QAction *action_deactivate;
    QAction *action_activate;
    QAction *actionAdvance_Mode_2;
    QAction *actionSilent_Mode2;
    QAction *actionAdvance_Mode2;
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *logo;
    QLabel *rootkitScan_label;
    QGroupBox *scan_progress;
    QLabel *stop;
    QProgressBar *progressBar;
    QTabWidget *scan_result;
    QWidget *tab_5;
    QLabel *infected_result2;
    QLabel *label;
    QTableWidget *infected_command;
    QWidget *tab_6;
    QLabel *default_result2;
    QLabel *label_4;
    QTableWidget *default_file;
    QPushButton *Stop_QPushButton;
    QPushButton *Scan_QPushButton;
    QCheckBox *Advance;
    QLabel *infected_result1;
    QLabel *info_label;
    QWidget *tab_4;
    QPushButton *Deactivate_QPushButton;
    QPushButton *Activate_QPushButton;
    QLabel *guard_info;
    QLabel *logo_guard;
    QGroupBox *System_Call_groupBox;
    QGroupBox *groupBox_6;
    QTableWidget *syscalltableWidget;
    QPushButton *takesnapshot_button;
    QTabWidget *guard_result_tab;
    QWidget *tab_3;
    QGroupBox *guard_result;
    QLabel *guard_result1;
    QLabel *guard_result2;
    QLabel *guard_result_icon;
    QWidget *tab_7;
    QLabel *Result_Guard;
    QWidget *tab_2;
    QGroupBox *groupBox;
    QTableWidget *log_table;
    QGroupBox *groupBox_3;
    QLabel *last_scan;
    QLabel *label_3;
    QLabel *total_scan;
    QLabel *label_2;
    QLabel *label_6;
    QLabel *label_5;
    QMenuBar *menubar;
    QMenu *menuHelp;
    QMenu *menuFile;
    QMenu *menuOption;
    QMenu *menuRootkit_Scan_2;
    QMenu *menuRootkit_Guard;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
    MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
    MainWindow->setWindowIcon(QIcon(QString::fromUtf8("icon/logo.png")));
    actionExit = new QAction(MainWindow);
    actionExit->setObjectName(QString::fromUtf8("actionExit"));
    actionExit->setMenuRole(QAction::TextHeuristicRole);
    actionAbout = new QAction(MainWindow);
    actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
    actionNormal_Mode = new QAction(MainWindow);
    actionNormal_Mode->setObjectName(QString::fromUtf8("actionNormal_Mode"));
    actionSilent_Mode = new QAction(MainWindow);
    actionSilent_Mode->setObjectName(QString::fromUtf8("actionSilent_Mode"));
    actionAdvance_Mode = new QAction(MainWindow);
    actionAdvance_Mode->setObjectName(QString::fromUtf8("actionAdvance_Mode"));
    action_deactivate = new QAction(MainWindow);
    action_deactivate->setObjectName(QString::fromUtf8("action_deactivate"));
    action_activate = new QAction(MainWindow);
    action_activate->setObjectName(QString::fromUtf8("action_activate"));
    actionAdvance_Mode_2 = new QAction(MainWindow);
    actionAdvance_Mode_2->setObjectName(QString::fromUtf8("actionAdvance_Mode_2"));
    actionSilent_Mode2 = new QAction(MainWindow);
    actionSilent_Mode2->setObjectName(QString::fromUtf8("actionSilent_Mode2"));
    actionAdvance_Mode2 = new QAction(MainWindow);
    actionAdvance_Mode2->setObjectName(QString::fromUtf8("actionAdvance_Mode2"));
    centralwidget = new QWidget(MainWindow);
    centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
    tabWidget = new QTabWidget(centralwidget);
    tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
    tabWidget->setGeometry(QRect(10, 10, 551, 511));
    tab = new QWidget();
    tab->setObjectName(QString::fromUtf8("tab"));
    logo = new QLabel(tab);
    logo->setObjectName(QString::fromUtf8("logo"));
    logo->setGeometry(QRect(60, 110, 151, 161));
    logo->setPixmap(QPixmap(QString::fromUtf8("icon/logo.png")));
    rootkitScan_label = new QLabel(tab);
    rootkitScan_label->setObjectName(QString::fromUtf8("rootkitScan_label"));
    rootkitScan_label->setGeometry(QRect(200, 150, 331, 111));
    scan_progress = new QGroupBox(tab);
    scan_progress->setObjectName(QString::fromUtf8("scan_progress"));
    scan_progress->setGeometry(QRect(100, 330, 351, 51));
    stop = new QLabel(scan_progress);
    stop->setObjectName(QString::fromUtf8("stop"));
    stop->setGeometry(QRect(120, 20, 101, 19));
    progressBar = new QProgressBar(scan_progress);
    progressBar->setObjectName(QString::fromUtf8("progressBar"));
    progressBar->setGeometry(QRect(50, 20, 241, 22));
    progressBar->setValue(24);
    progressBar->setOrientation(Qt::Horizontal);
    scan_result = new QTabWidget(tab);
    scan_result->setObjectName(QString::fromUtf8("scan_result"));
    scan_result->setGeometry(QRect(30, 20, 491, 311));
    scan_result->setIconSize(QSize(10, 10));
    tab_5 = new QWidget();
    tab_5->setObjectName(QString::fromUtf8("tab_5"));
    infected_result2 = new QLabel(tab_5);
    infected_result2->setObjectName(QString::fromUtf8("infected_result2"));
    infected_result2->setGeometry(QRect(90, 170, 311, 19));
    label = new QLabel(tab_5);
    label->setObjectName(QString::fromUtf8("label"));
    label->setGeometry(QRect(20, 10, 251, 19));
    infected_command = new QTableWidget(tab_5);
    infected_command->setObjectName(QString::fromUtf8("infected_command"));
    infected_command->setGeometry(QRect(20, 30, 451, 241));
    infected_command->setEditTriggers(QAbstractItemView::NoEditTriggers);
    infected_command->setGridStyle(Qt::DotLine);
    infected_command->setSortingEnabled(false);
    scan_result->addTab(tab_5, QApplication::translate("MainWindow", "Infected Command", 0, QApplication::UnicodeUTF8));
    tab_6 = new QWidget();
    tab_6->setObjectName(QString::fromUtf8("tab_6"));
    default_result2 = new QLabel(tab_6);
    default_result2->setObjectName(QString::fromUtf8("default_result2"));
    default_result2->setGeometry(QRect(70, 170, 341, 19));
    label_4 = new QLabel(tab_6);
    label_4->setObjectName(QString::fromUtf8("label_4"));
    label_4->setGeometry(QRect(20, 10, 231, 19));
    default_file = new QTableWidget(tab_6);
    default_file->setObjectName(QString::fromUtf8("default_file"));
    default_file->setGeometry(QRect(20, 30, 451, 241));
    default_file->setAutoFillBackground(false);
    default_file->setEditTriggers(QAbstractItemView::NoEditTriggers);
    default_file->setAlternatingRowColors(false);
    default_file->setGridStyle(Qt::DotLine);
    default_file->setSortingEnabled(false);
    scan_result->addTab(tab_6, QApplication::translate("MainWindow", "Rootkit's default files", 0, QApplication::UnicodeUTF8));
    Stop_QPushButton = new QPushButton(tab);
    Stop_QPushButton->setObjectName(QString::fromUtf8("Stop_QPushButton"));
    Stop_QPushButton->setEnabled(false);
    Stop_QPushButton->setGeometry(QRect(370, 390, 81, 71));
    Stop_QPushButton->setIcon(QIcon(QString::fromUtf8("icon/stop.png")));
    Stop_QPushButton->setIconSize(QSize(50, 50));
    Scan_QPushButton = new QPushButton(tab);
    Scan_QPushButton->setObjectName(QString::fromUtf8("Scan_QPushButton"));
    Scan_QPushButton->setGeometry(QRect(270, 390, 81, 71));
    Scan_QPushButton->setIcon(QIcon(QString::fromUtf8("icon/scan.png")));
    Scan_QPushButton->setIconSize(QSize(50, 50));
    Scan_QPushButton->setFlat(false);
    Advance = new QCheckBox(tab);
    Advance->setObjectName(QString::fromUtf8("Advance"));
    Advance->setGeometry(QRect(110, 410, 131, 24));
    Advance->setChecked(true);
    infected_result1 = new QLabel(tab);
    infected_result1->setObjectName(QString::fromUtf8("infected_result1"));
    infected_result1->setGeometry(QRect(200, 130, 154, 19));
    info_label = new QLabel(tab);
    info_label->setObjectName(QString::fromUtf8("info_label"));
    info_label->setGeometry(QRect(80, 60, 150, 150));
    info_label->setMinimumSize(QSize(0, 0));
    info_label->setBaseSize(QSize(0, 0));
    info_label->setPixmap(QPixmap(QString::fromUtf8("icon/info.png")));
    info_label->setScaledContents(true);
    tabWidget->addTab(tab, QApplication::translate("MainWindow", "Rootkit-Scan", 0, QApplication::UnicodeUTF8));
    tab_4 = new QWidget();
    tab_4->setObjectName(QString::fromUtf8("tab_4"));
    Deactivate_QPushButton = new QPushButton(tab_4);
    Deactivate_QPushButton->setObjectName(QString::fromUtf8("Deactivate_QPushButton"));
    Deactivate_QPushButton->setGeometry(QRect(410, 430, 121, 41));
    Deactivate_QPushButton->setLayoutDirection(Qt::LeftToRight);
    Deactivate_QPushButton->setAutoFillBackground(false);
    Deactivate_QPushButton->setIcon(QIcon(QString::fromUtf8("icon/disable.png")));
    Deactivate_QPushButton->setIconSize(QSize(22, 22));
    Deactivate_QPushButton->setFlat(false);
    Activate_QPushButton = new QPushButton(tab_4);
    Activate_QPushButton->setObjectName(QString::fromUtf8("Activate_QPushButton"));
    Activate_QPushButton->setEnabled(true);
    Activate_QPushButton->setGeometry(QRect(270, 430, 121, 41));
    Activate_QPushButton->setIcon(QIcon(QString::fromUtf8("icon/Activate.png")));
    Activate_QPushButton->setIconSize(QSize(22, 22));
    guard_info = new QLabel(tab_4);
    guard_info->setObjectName(QString::fromUtf8("guard_info"));
    guard_info->setGeometry(QRect(196, 120, 331, 131));
    logo_guard = new QLabel(tab_4);
    logo_guard->setObjectName(QString::fromUtf8("logo_guard"));
    logo_guard->setGeometry(QRect(59, 85, 211, 191));
    logo_guard->setPixmap(QPixmap(QString::fromUtf8("icon/logo_guard.png")));
    System_Call_groupBox = new QGroupBox(tab_4);
    System_Call_groupBox->setObjectName(QString::fromUtf8("System_Call_groupBox"));
    System_Call_groupBox->setGeometry(QRect(20, 0, 511, 291));
    groupBox_6 = new QGroupBox(System_Call_groupBox);
    groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
    groupBox_6->setGeometry(QRect(340, 100, 120, 80));
    syscalltableWidget = new QTableWidget(System_Call_groupBox);
    syscalltableWidget->setObjectName(QString::fromUtf8("syscalltableWidget"));
    syscalltableWidget->setGeometry(QRect(10, 30, 491, 221));
    syscalltableWidget->setLineWidth(1);
    syscalltableWidget->setMidLineWidth(0);
    syscalltableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    syscalltableWidget->setAlternatingRowColors(true);
    syscalltableWidget->setSortingEnabled(false);
    syscalltableWidget->setRowCount(0);
    syscalltableWidget->setColumnCount(3);
    takesnapshot_button = new QPushButton(System_Call_groupBox);
    takesnapshot_button->setObjectName(QString::fromUtf8("takesnapshot_button"));
    takesnapshot_button->setGeometry(QRect(410, 260, 91, 21));
    guard_result_tab = new QTabWidget(tab_4);
    guard_result_tab->setObjectName(QString::fromUtf8("guard_result_tab"));
    guard_result_tab->setGeometry(QRect(20, 300, 511, 121));
    tab_3 = new QWidget();
    tab_3->setObjectName(QString::fromUtf8("tab_3"));
    guard_result = new QGroupBox(tab_3);
    guard_result->setObjectName(QString::fromUtf8("guard_result"));
    guard_result->setGeometry(QRect(-10, -20, 531, 121));
    guard_result1 = new QLabel(guard_result);
    guard_result1->setObjectName(QString::fromUtf8("guard_result1"));
    guard_result1->setGeometry(QRect(120, 20, 371, 61));
    guard_result2 = new QLabel(guard_result);
    guard_result2->setObjectName(QString::fromUtf8("guard_result2"));
    guard_result2->setGeometry(QRect(120, 80, 361, 21));
    guard_result_icon = new QLabel(guard_result);
    guard_result_icon->setObjectName(QString::fromUtf8("guard_result_icon"));
    guard_result_icon->setGeometry(QRect(-10, -10, 150, 150));
    guard_result_icon->setPixmap(QPixmap(QString::fromUtf8("icon/guard.png")));
    guard_result_tab->addTab(tab_3, QApplication::translate("MainWindow", "Summary", 0, QApplication::UnicodeUTF8));
    tab_7 = new QWidget();
    tab_7->setObjectName(QString::fromUtf8("tab_7"));
    Result_Guard = new QLabel(tab_7);
    Result_Guard->setObjectName(QString::fromUtf8("Result_Guard"));
    Result_Guard->setGeometry(QRect(10, 10, 491, 71));
    guard_result_tab->addTab(tab_7, QApplication::translate("MainWindow", "Result", 0, QApplication::UnicodeUTF8));
    tabWidget->addTab(tab_4, QApplication::translate("MainWindow", "Rootkit-Guard", 0, QApplication::UnicodeUTF8));
    tab_2 = new QWidget();
    tab_2->setObjectName(QString::fromUtf8("tab_2"));
    groupBox = new QGroupBox(tab_2);
    groupBox->setObjectName(QString::fromUtf8("groupBox"));
    groupBox->setGeometry(QRect(40, 160, 471, 311));
    log_table = new QTableWidget(groupBox);
    log_table->setObjectName(QString::fromUtf8("log_table"));
    log_table->setGeometry(QRect(30, 30, 421, 261));
    groupBox_3 = new QGroupBox(tab_2);
    groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
    groupBox_3->setGeometry(QRect(150, 60, 361, 81));
    last_scan = new QLabel(groupBox_3);
    last_scan->setObjectName(QString::fromUtf8("last_scan"));
    last_scan->setGeometry(QRect(110, 30, 171, 21));
    label_3 = new QLabel(groupBox_3);
    label_3->setObjectName(QString::fromUtf8("label_3"));
    label_3->setGeometry(QRect(20, 50, 77, 19));
    total_scan = new QLabel(groupBox_3);
    total_scan->setObjectName(QString::fromUtf8("total_scan"));
    total_scan->setGeometry(QRect(110, 50, 63, 19));
    label_2 = new QLabel(groupBox_3);
    label_2->setObjectName(QString::fromUtf8("label_2"));
    label_2->setGeometry(QRect(20, 30, 71, 16));
    label_6 = new QLabel(tab_2);
    label_6->setObjectName(QString::fromUtf8("label_6"));
    label_6->setGeometry(QRect(160, 30, 351, 21));
    label_5 = new QLabel(tab_2);
    label_5->setObjectName(QString::fromUtf8("label_5"));
    label_5->setGeometry(QRect(30, 20, 128, 128));
    label_5->setPixmap(QPixmap(QString::fromUtf8("icon/log.png")));
    tabWidget->addTab(tab_2, QApplication::translate("MainWindow", "Scan Log", 0, QApplication::UnicodeUTF8));
    MainWindow->setCentralWidget(centralwidget);
    menubar = new QMenuBar(MainWindow);
    menubar->setObjectName(QString::fromUtf8("menubar"));
    menubar->setGeometry(QRect(0, 0, 570, 31));
    menuHelp = new QMenu(menubar);
    menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
    menuFile = new QMenu(menubar);
    menuFile->setObjectName(QString::fromUtf8("menuFile"));
    menuOption = new QMenu(menubar);
    menuOption->setObjectName(QString::fromUtf8("menuOption"));
    menuRootkit_Scan_2 = new QMenu(menuOption);
    menuRootkit_Scan_2->setObjectName(QString::fromUtf8("menuRootkit_Scan_2"));
    menuRootkit_Guard = new QMenu(menuOption);
    menuRootkit_Guard->setObjectName(QString::fromUtf8("menuRootkit_Guard"));
    MainWindow->setMenuBar(menubar);
    statusbar = new QStatusBar(MainWindow);
    statusbar->setObjectName(QString::fromUtf8("statusbar"));
    MainWindow->setStatusBar(statusbar);
    QWidget::setTabOrder(Scan_QPushButton, tabWidget);
    QWidget::setTabOrder(tabWidget, Stop_QPushButton);

    menubar->addAction(menuFile->menuAction());
    menubar->addAction(menuOption->menuAction());
    menubar->addAction(menuHelp->menuAction());
    menuHelp->addAction(actionAbout);
    menuFile->addAction(actionExit);
    menuOption->addAction(menuRootkit_Scan_2->menuAction());
    menuOption->addAction(menuRootkit_Guard->menuAction());
    menuRootkit_Scan_2->addAction(actionSilent_Mode2);
    menuRootkit_Scan_2->addAction(actionAdvance_Mode2);
    menuRootkit_Guard->addAction(action_deactivate);
    menuRootkit_Guard->addAction(action_activate);

    retranslateUi(MainWindow);

    QSize size(570, 581);
    size = size.expandedTo(MainWindow->minimumSizeHint());
    MainWindow->resize(size);


    tabWidget->setCurrentIndex(0);
    scan_result->setCurrentIndex(0);
    guard_result_tab->setCurrentIndex(0);


    QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
    MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Loki", "Version 1.0", QApplication::UnicodeUTF8));
    actionExit->setText(QApplication::translate("MainWindow", "Exit", 0, QApplication::UnicodeUTF8));
    actionExit->setToolTip(QApplication::translate("MainWindow", "Exit Anti-Rootkit System", 0, QApplication::UnicodeUTF8));
    actionAbout->setText(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
    actionNormal_Mode->setText(QApplication::translate("MainWindow", "Normal Mode", 0, QApplication::UnicodeUTF8));
    actionSilent_Mode->setText(QApplication::translate("MainWindow", "Silent Mode", 0, QApplication::UnicodeUTF8));
    actionAdvance_Mode->setText(QApplication::translate("MainWindow", "Silent Mode", 0, QApplication::UnicodeUTF8));
    action_deactivate->setText(QApplication::translate("MainWindow", "Deactivate", 0, QApplication::UnicodeUTF8));
    action_activate->setText(QApplication::translate("MainWindow", "Activate", 0, QApplication::UnicodeUTF8));
    actionAdvance_Mode_2->setText(QApplication::translate("MainWindow", "Advance Mode", 0, QApplication::UnicodeUTF8));
    actionSilent_Mode2->setText(QApplication::translate("MainWindow", "Silent Mode", 0, QApplication::UnicodeUTF8));
    actionAdvance_Mode2->setText(QApplication::translate("MainWindow", "Advanced Mode", 0, QApplication::UnicodeUTF8));
    logo->setText(QString());
    rootkitScan_label->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Rootkit Scan </span>is a Signature based</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">scanning tool which can scan</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">for infected or changed binary files</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">and command in your system, and</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px"
        "; -qt-block-indent:0; text-indent:0px;\">detect User-Mode Rootkits.</p></body></html>", 0, QApplication::UnicodeUTF8));
    scan_progress->setTitle(QApplication::translate("MainWindow", "Scanning Progress", 0, QApplication::UnicodeUTF8));
    stop->setText(QApplication::translate("MainWindow", "Stop Scanning", 0, QApplication::UnicodeUTF8));
    infected_result2->setText(QApplication::translate("MainWindow", "Every command in library are not changed.", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("MainWindow", "Scanning for infected command", 0, QApplication::UnicodeUTF8));
    if (infected_command->columnCount() < 2)
        infected_command->setColumnCount(2);

    QTableWidgetItem *__colItem = new QTableWidgetItem();
    __colItem->setText(QApplication::translate("MainWindow", "Command", 0, QApplication::UnicodeUTF8));
    infected_command->setHorizontalHeaderItem(0, __colItem);

    QTableWidgetItem *__colItem1 = new QTableWidgetItem();
    __colItem1->setText(QApplication::translate("MainWindow", "status", 0, QApplication::UnicodeUTF8));
    infected_command->setHorizontalHeaderItem(1, __colItem1);
    scan_result->setTabText(scan_result->indexOf(tab_5), QApplication::translate("MainWindow", "Infected Command", 0, QApplication::UnicodeUTF8));
    default_result2->setText(QApplication::translate("MainWindow", "No rootkit's default files and folder in your system.", 0, QApplication::UnicodeUTF8));
    label_4->setText(QApplication::translate("MainWindow", "Scanning for rootkit's default files", 0, QApplication::UnicodeUTF8));
    if (default_file->columnCount() < 2)
        default_file->setColumnCount(2);

    QTableWidgetItem *__colItem2 = new QTableWidgetItem();
    __colItem2->setText(QApplication::translate("MainWindow", "Rootkit's title", 0, QApplication::UnicodeUTF8));
    default_file->setHorizontalHeaderItem(0, __colItem2);

    QTableWidgetItem *__colItem3 = new QTableWidgetItem();
    __colItem3->setText(QApplication::translate("MainWindow", "status", 0, QApplication::UnicodeUTF8));
    default_file->setHorizontalHeaderItem(1, __colItem3);
    scan_result->setTabText(scan_result->indexOf(tab_6), QApplication::translate("MainWindow", "Rootkit's default files", 0, QApplication::UnicodeUTF8));
    Stop_QPushButton->setToolTip(QApplication::translate("MainWindow", "Stop Rootkit-Scan", 0, QApplication::UnicodeUTF8));
    Stop_QPushButton->setText(QString());
    Scan_QPushButton->setToolTip(QApplication::translate("MainWindow", "Start Scaning", 0, QApplication::UnicodeUTF8));
    Scan_QPushButton->setText(QString());
    Advance->setText(QApplication::translate("MainWindow", "Advanced Mode", 0, QApplication::UnicodeUTF8));
    infected_result1->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Scanning Complete !</span></p></body></html>", 0, QApplication::UnicodeUTF8));
    info_label->setText(QString());
    tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Rootkit-Scan", 0, QApplication::UnicodeUTF8));
    Deactivate_QPushButton->setToolTip(QApplication::translate("MainWindow", "Stop Rootkit-Guard", 0, QApplication::UnicodeUTF8));
    Deactivate_QPushButton->setText(QApplication::translate("MainWindow", "  Deactivate", 0, QApplication::UnicodeUTF8));
    Activate_QPushButton->setToolTip(QApplication::translate("MainWindow", "Start Rootkit-Guard run as Daemon", 0, QApplication::UnicodeUTF8));
    Activate_QPushButton->setText(QApplication::translate("MainWindow", "  Activate", 0, QApplication::UnicodeUTF8));
    guard_info->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Rootkit-Guard </span>is a system call integrity </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">checking tool which can detect system call table</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">modification from Kernel-Mode Rootkits and </p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">run as daemon, consequence if you activated</p>\n"
"<p style=\" margin-top:0px; margi"
        "n-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Rootkit-Guard and closed application.</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Rootkit-Guard is still working for your system.</p></body></html>", 0, QApplication::UnicodeUTF8));
    logo_guard->setText(QString());
    System_Call_groupBox->setTitle(QApplication::translate("MainWindow", "System Call Analyzer", 0, QApplication::UnicodeUTF8));
    groupBox_6->setTitle(QApplication::translate("MainWindow", "GroupBox", 0, QApplication::UnicodeUTF8));
    if (syscalltableWidget->columnCount() < 3)
        syscalltableWidget->setColumnCount(3);

    QTableWidgetItem *__colItem4 = new QTableWidgetItem();
    __colItem4->setText(QApplication::translate("MainWindow", "System", 0, QApplication::UnicodeUTF8));
    syscalltableWidget->setHorizontalHeaderItem(0, __colItem4);

    QTableWidgetItem *__colItem5 = new QTableWidgetItem();
    __colItem5->setText(QApplication::translate("MainWindow", "Previous", 0, QApplication::UnicodeUTF8));
    syscalltableWidget->setHorizontalHeaderItem(1, __colItem5);

    QTableWidgetItem *__colItem6 = new QTableWidgetItem();
    __colItem6->setText(QApplication::translate("MainWindow", "Current", 0, QApplication::UnicodeUTF8));
    syscalltableWidget->setHorizontalHeaderItem(2, __colItem6);
    takesnapshot_button->setText(QApplication::translate("MainWindow", "Snapshot", 0, QApplication::UnicodeUTF8));
    guard_result->setTitle(QApplication::translate("MainWindow", "Result", 0, QApplication::UnicodeUTF8));
    guard_result1->setText(QApplication::translate("MainWindow", "Result", 0, QApplication::UnicodeUTF8));
    guard_result2->setText(QApplication::translate("MainWindow", "Snapshot on:", 0, QApplication::UnicodeUTF8));
    guard_result_icon->setText(QString());
    guard_result_tab->setTabText(guard_result_tab->indexOf(tab_3), QApplication::translate("MainWindow", "Summary", 0, QApplication::UnicodeUTF8));
    Result_Guard->setText(QString());
    guard_result_tab->setTabText(guard_result_tab->indexOf(tab_7), QApplication::translate("MainWindow", "Result", 0, QApplication::UnicodeUTF8));
    tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "Rootkit-Guard", 0, QApplication::UnicodeUTF8));
    groupBox->setTitle(QApplication::translate("MainWindow", "Rootkit Scan History", 0, QApplication::UnicodeUTF8));
    if (log_table->columnCount() < 2)
        log_table->setColumnCount(2);

    QTableWidgetItem *__colItem7 = new QTableWidgetItem();
    __colItem7->setText(QApplication::translate("MainWindow", "Date & Time", 0, QApplication::UnicodeUTF8));
    log_table->setHorizontalHeaderItem(0, __colItem7);

    QTableWidgetItem *__colItem8 = new QTableWidgetItem();
    __colItem8->setText(QApplication::translate("MainWindow", "Status", 0, QApplication::UnicodeUTF8));
    log_table->setHorizontalHeaderItem(1, __colItem8);
    groupBox_3->setTitle(QApplication::translate("MainWindow", "Summary", 0, QApplication::UnicodeUTF8));
    last_scan->setText(QApplication::translate("MainWindow", "no scan", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("MainWindow", "Total Scans:", 0, QApplication::UnicodeUTF8));
    total_scan->setText(QApplication::translate("MainWindow", "0 time", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("MainWindow", "Last Scan:", 0, QApplication::UnicodeUTF8));
    label_6->setText(QApplication::translate("MainWindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-weight:600;\">Rootkit-Scan Log </span>is a record of Rootkit-Scan results.</p></body></html>", 0, QApplication::UnicodeUTF8));
    label_5->setText(QString());
    tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Scan Log", 0, QApplication::UnicodeUTF8));
    menuHelp->setTitle(QApplication::translate("MainWindow", "Help", 0, QApplication::UnicodeUTF8));
    menuFile->setTitle(QApplication::translate("MainWindow", "File", 0, QApplication::UnicodeUTF8));
    menuOption->setTitle(QApplication::translate("MainWindow", "Option", 0, QApplication::UnicodeUTF8));
    menuRootkit_Scan_2->setTitle(QApplication::translate("MainWindow", "Rootkit-Scan", 0, QApplication::UnicodeUTF8));
    menuRootkit_Guard->setTitle(QApplication::translate("MainWindow", "Rootkit-Guard", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

#endif // UI_MAINWINDOW_H
