using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace bus_server
{
    class Program
    {
        static void Main()
        {
            string busXml = "bus.xml";
            string stationXml = "station.xml";
            
            XmlGenerater xmlGen = new XmlGenerater(busXml, stationXml);
            xmlGen.CreateStationXml();
            xmlGen.CreateBusXml();

            LatLonReceiver latlonReceiver = new LatLonReceiver(xmlGen);
            Thread latlonThread = new Thread(new ThreadStart(latlonReceiver.RunReceiver));
            latlonThread.Start();

            SendUpdate sendUpdater = new SendUpdate();
            Thread updateThread = new Thread(new ThreadStart(sendUpdater.RunSendUpdate));
            updateThread.Start();

            Console.ReadLine();

            latlonThread.Abort();
            updateThread.Abort();
        }
    }
}
