using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace bus_server
{
    class LatLonReceiver
    {
        const int LISTEN_PORT = 9999;
        private XmlGenerater xmlGen;

        public LatLonReceiver(XmlGenerater xmlGenArgs)
        {
            this.xmlGen = xmlGenArgs;
        }

        public void RunReceiver()
        {
            try
            {
                // create socket
                IPEndPoint RemoteEndPoint = new IPEndPoint(IPAddress.Any, LISTEN_PORT);
                UdpClient busClient = new UdpClient(RemoteEndPoint);

                Console.WriteLine("Lat & Lon Receiver: Waiting for connections...");
                char[] delimiterChars = { ',' };

                while (true)
                {
                    IPEndPoint BusEndPoint = new IPEndPoint(IPAddress.Any, 0);
                    byte[] data = busClient.Receive(ref BusEndPoint);

                    Console.WriteLine("Message received from {0} at {1}", BusEndPoint.Address, BusEndPoint.Port);
                    string message = Encoding.ASCII.GetString(data);

                    if (message.StartsWith("$START"))
                    {
                        string[] start = message.Split(delimiterChars);
                        Console.WriteLine(start[1]);
                    }
                    else if (message.StartsWith("$END"))
                    {
                        string[] end = message.Split(delimiterChars);
                        Console.WriteLine(end[1]);
                    }
                    else if (message.StartsWith("$LATLON"))
                    {
                        string[] latlon = message.Split(delimiterChars);
                        string busId = latlon[1];
                        string lat = latlon[2];
                        string lon = latlon[3];

                        Console.WriteLine("Latitude : {0}", lat);
                        Console.WriteLine("Longitude : {0}", lon);

                        this.xmlGen.updateLatLng(busId, lat, lon);
                    }

                    Thread.Sleep(100);
                }

                busClient.Close();
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }
    }
}
