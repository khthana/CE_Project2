using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using MySql.Data.MySqlClient;

namespace bus_server
{
    class XmlGenerater
    {
        private XmlTextWriter xmlTw;
        private XmlDocument xmlDoc;
        public  string busXmlFileName;
        public string stationXmlFileName;

        public XmlGenerater(string busFileName, string stationFileName)
        {
            this.busXmlFileName = busFileName;
            this.stationXmlFileName = stationFileName;
        }

        public void CreateStationXml()
        {
            this.xmlTw = new XmlTextWriter(this.stationXmlFileName, null);

            // Specify SQL Server-specific connection string
            MySqlConnection mySqlConnection = new MySqlConnection("Database=gps;Data Source=localhost;User Id=root;Password=pek");

            // Open connection
            mySqlConnection.Open();

            // Create command for mySQL connection
            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = "SET NAMES 'utf8'";
            mySqlCommand.ExecuteNonQuery();

            // Specify SQL query for mySQL command
            mySqlCommand.CommandText = "SELECT * FROM station ORDER BY STATION_ID";

            // Execute DataReader for specified command
            MySqlDataReader mySqlReader = mySqlCommand.ExecuteReader();

            this.xmlTw.Formatting = Formatting.Indented;

            this.xmlTw.WriteStartElement("markers");

            while (mySqlReader.Read())
            {
                string station_id = mySqlReader["STATION_ID"].ToString();
                string station_name = mySqlReader["STATION_NAME"].ToString();
                string address = mySqlReader["ADDRESS"].ToString();
                string telephone = mySqlReader["TELEPHONE"].ToString();
                string lat = mySqlReader["LATITUDE"].ToString();
                string lng = mySqlReader["LONGITUDE"].ToString();

                this.xmlTw.WriteStartElement("marker");
                this.xmlTw.WriteAttributeString("id", station_id);
                this.xmlTw.WriteElementString("lat", lat);
                this.xmlTw.WriteElementString("lng", lng);
                this.xmlTw.WriteElementString("label", station_name);
                string html = "ʶҹ�" + station_name + "<br />�������: " + address + "<br />���Ѿ��: " + telephone;
                this.xmlTw.WriteElementString("html", html);
                
                this.xmlTw.WriteEndElement();
            }

            this.xmlTw.WriteEndElement();

            this.xmlTw.Flush();
            this.xmlTw.Close();
        }

        public void CreateBusXml()
        {
            this.xmlTw = new XmlTextWriter(this.busXmlFileName, null);

            // Specify SQL Server-specific connection string
            MySqlConnection mySqlConnection = new MySqlConnection("Database=gps;Data Source=localhost;User Id=root;Password=pek");

            // Open connection
            mySqlConnection.Open();

            // Create command for mySQL connection
            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText = "SET NAMES 'utf8'";
            mySqlCommand.ExecuteNonQuery();

            // Specify SQL query for mySQL command
            mySqlCommand.CommandText = "SELECT BUS_ID,LATITUDE,LONGITUDE FROM bus ORDER BY BUS_ID";

            // Execute DataReader for specified command
            MySqlDataReader mySqlReader = mySqlCommand.ExecuteReader();

            this.xmlTw.Formatting = Formatting.Indented;

            this.xmlTw.WriteStartElement("markers");

            while (mySqlReader.Read())
            {
                string busId = mySqlReader["BUS_ID"].ToString();
                string lat = mySqlReader["LATITUDE"].ToString();
                string lng = mySqlReader["LONGITUDE"].ToString();

                this.xmlTw.WriteStartElement("marker");
                this.xmlTw.WriteAttributeString("id", busId);
                this.xmlTw.WriteElementString("lat", lat);
                this.xmlTw.WriteElementString("lng", lng);
                string label = "Bus No: " + busId;
                this.xmlTw.WriteElementString("label", label);
                string html = "Bus No: " + busId + "<br />Latitude: " + lat + "<br />Longitude: " + lng;
                this.xmlTw.WriteElementString("html", html);
                this.xmlTw.WriteEndElement();
            }

            this.xmlTw.WriteEndElement();

            this.xmlTw.Flush();
            this.xmlTw.Close();
        }

        public void updateLatLng(string busId, string lat, string lng)
        {
            xmlDoc = new XmlDocument();
            xmlDoc.Load(this.busXmlFileName);

            Console.WriteLine(busId);
            XmlNodeList markers = xmlDoc.GetElementsByTagName("marker");

            for (int i = 0; i != markers.Count; i++)
            {
                if (markers[i].Attributes["id"].Value == busId)
                {
                    XmlNodeList childNodeList = markers[i].ChildNodes;
                    childNodeList.Item(0).InnerText = lat;
                    childNodeList.Item(1).InnerText = lng;
                    childNodeList.Item(3).InnerText = "Bus No: " + busId + "<br />Latitude: " + lat + "<br />Longitude: " + lng;
                }
            }

            this.xmlTw = new XmlTextWriter(this.busXmlFileName, null);
            this.xmlTw.Formatting = Formatting.Indented;

            xmlDoc.WriteContentTo(this.xmlTw);
            this.xmlTw.Flush();
            this.xmlTw.Close();
        }
    }
}
