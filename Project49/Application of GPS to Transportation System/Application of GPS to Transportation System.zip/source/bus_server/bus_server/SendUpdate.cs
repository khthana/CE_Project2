using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using MySql.Data.MySqlClient;

namespace bus_server
{
    class ClientHandler
    {
        public TcpClient clientSocket;
        public static int nClient = 0;

        public void runClient()
        {
            try
            {
                // creating the stream classes
                StreamReader readerStream = new StreamReader(this.clientSocket.GetStream());
                NetworkStream writerStream = this.clientSocket.GetStream();

                nClient++;
                Console.WriteLine("Client connected: {0} active connections", nClient);

                IPEndPoint newSock = (IPEndPoint)this.clientSocket.Client.RemoteEndPoint;
                Console.WriteLine("Connected with {0} at port {1}", newSock.Address, newSock.Port);

                char[] delimiterChars = { ',' };

                string message = readerStream.ReadLine();
                Console.WriteLine(message);

                if (message.StartsWith("$CHECKRESERV"))
                {
                    string[] requestMessage = message.Split(delimiterChars);

                    // Specify SQL Server-specific connection string
                    MySqlConnection mySqlConnection = new MySqlConnection("Database=gps;Data Source=localhost;User Id=root;Password=pek");

                    // Open connection
                    mySqlConnection.Open();

                    // Create command for mySQL connection
                    MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

                    mySqlCommand.CommandText = "SET NAMES 'utf8'";
                    mySqlCommand.ExecuteNonQuery();

                    DateTime date = DateTime.Now;
                    string dateStr = Convert.ToString(date.Year) + "-0" + Convert.ToString(date.Month) + "-" + Convert.ToString(date.Day);

                    // Specify SQL query for mySQL command
                    mySqlCommand.CommandText = 
                        "SELECT COUNT(*) " +
                        "FROM reservation " +
                        "WHERE BUS_ID = '" + requestMessage[1] + "' " +
                        "AND CHECK_UPDATE = 0 " +
                        "AND DATE_TRAVEL <= '" + dateStr + "'";

                    // Execute DataReader for specified command
                    MySqlDataReader mySqlReader = mySqlCommand.ExecuteReader();

                    // read data
                    mySqlReader.Read();
                    string reserveAmount = mySqlReader["COUNT(*)"].ToString();

                    // Close reader
                    mySqlReader.Close();
                    
                    mySqlCommand.CommandText =
                        "SELECT COUNT(*) " +
                        "FROM reservation " +
                        "WHERE BUS_ID = '" + requestMessage[1] + "' " +
                        "AND CHECK_UPDATE = 3 " +
                        "AND DATE_TRAVEL <= '" + dateStr + "'";

                    mySqlReader = mySqlCommand.ExecuteReader();

                    // read data
                    mySqlReader.Read();
                    string cancelAmount = mySqlReader["COUNT(*)"].ToString();

                    // Close reader
                    mySqlReader.Close();

                    // Is there update if have do in this scope
                    if (int.Parse(reserveAmount) > 0 || int.Parse(cancelAmount) > 0)
                    {
                        message = "$UPDATE," + reserveAmount + "," + cancelAmount + "\r\n";
                        byte[] data = Encoding.UTF8.GetBytes(message);
                        writerStream.Write(data, 0, data.Length);

                        // Is there reserve update if have do in this scope
                        if (int.Parse(reserveAmount) > 0)
                        {
                            mySqlCommand.CommandText =
                                "SELECT RESERV_NUMBER, C_NAME, C_SURNAME, SOURCE_STATION, DESTINATION_STATION, SEAT_NO, BUS_ID " +
                                "FROM reservation, customer, trip " +
                                "WHERE reservation.C_NUMBER = customer.C_NUMBER " +
                                "AND reservation.TRIP_ID = trip.TRIP_ID " +
                                "AND reservation.BUS_ID = '" + requestMessage[1] + "' " +
                                "AND CHECK_UPDATE = 0 " +
                                "AND DATE_TRAVEL <= '" + dateStr + "'";

                            mySqlReader = mySqlCommand.ExecuteReader();

                            Console.WriteLine("Number of reserve: {0}", reserveAmount);

                            while (mySqlReader.Read())
                            {
                                // Get Station Name
                                string sStationName = GetStationName(mySqlReader["SOURCE_STATION"].ToString());
                                string dStationName = GetStationName(mySqlReader["DESTINATION_STATION"].ToString());

                                // Output columns
                                Console.WriteLine("\tRESERV_NUMBER\t{0}", mySqlReader["RESERV_NUMBER"]);
                                Console.WriteLine("\tCUSTOMER_NAME\t{0}", mySqlReader["C_NAME"]);
                                Console.WriteLine("\tCUSTOMER_SURNAME\t{0}", mySqlReader["C_SURNAME"]);
                                Console.WriteLine("\tSOURCE_STATION\t{0}", sStationName);
                                Console.WriteLine("\tDESTINATION_STATION\t{0}", dStationName);
                                Console.WriteLine("\tSEAT_NO\t{0}", mySqlReader["SEAT_NO"]);

                                message = "$RESERV," + mySqlReader["RESERV_NUMBER"] + "," +
                                    mySqlReader["C_NAME"] + " " + mySqlReader["C_SURNAME"] + "," +
                                    sStationName + "-" + dStationName + "," + mySqlReader["SEAT_NO"] + "\r\n";
                                data = Encoding.UTF8.GetBytes(message);
                                writerStream.Write(data, 0, data.Length);
                            }

                            // Close reader
                            mySqlReader.Close();
                        }

                        // Is there cancel update if have do in this scope
                        if (int.Parse(cancelAmount) > 0)
                        {
                            mySqlCommand.CommandText =
                                "SELECT RESERV_NUMBER " +
                                "FROM reservation, customer, trip " +
                                "WHERE reservation.C_NUMBER = customer.C_NUMBER " +
                                "AND reservation.TRIP_ID = trip.TRIP_ID " +
                                "AND reservation.BUS_ID = '" + requestMessage[1] + "' " +
                                "AND CHECK_UPDATE = 3 " +
                                "AND DATE_TRAVEL <= '" + dateStr + "'";

                            mySqlReader = mySqlCommand.ExecuteReader();

                            Console.WriteLine("Number of cancel: {0}", cancelAmount);
                            message = "$CANCEL";
                            while (mySqlReader.Read())
                            {
                                message = message + "," + mySqlReader["RESERV_NUMBER"];
                                Console.WriteLine("Reserve number: {0}", mySqlReader["RESERV_NUMBER"]);
                            }
                            message = message + "\r\n";

                            if (int.Parse(cancelAmount) > 0)
                            {
                                data = Encoding.UTF8.GetBytes(message);
                                writerStream.Write(data, 0, data.Length);
                            }

                            // Close reader
                            mySqlReader.Close();
                        }

                        message = readerStream.ReadLine();
                        Console.WriteLine(message);

                        if (message.StartsWith("$UPDATED"))
                        {
                            string[] updated = message.Split(delimiterChars);

                            Console.WriteLine("START CHECK UPDATED");
                            for (int i = 1; i != updated.Length; i++)
                            {
                                mySqlCommand.CommandText =
                                    "UPDATE reservation SET CHECK_UPDATE = CHECK_UPDATE + 1 " +
                                    "WHERE RESERV_NUMBER = " + updated[i];

                                mySqlCommand.ExecuteNonQuery();
                                Console.WriteLine("{0} CHECK UPDATED", updated[i]);
                            }
                            Console.WriteLine("FINISH CHECK UPDATED");
                        }

                        mySqlReader.Close();
                    }
                    // if have not update do in this scope
                    else
                    {
                        message = "$UNUPDATE\r\n";
                        byte[] data = Encoding.UTF8.GetBytes(message);
                        writerStream.Write(data, 0, data.Length);

                        message = readerStream.ReadLine();
                        Console.WriteLine(message);
                    }

                    // Close connection
                    mySqlConnection.Close();
                }

                clientSocket.Close();
                Console.WriteLine("Client disconnected: {0} active connections", nClient);                
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }

        public static string GetStationName(string stationId)
        {
            // Specify SQL Server-specific connection string
            MySqlConnection mySqlConnection = new MySqlConnection("Database=gps;Data Source=localhost;User Id=root;Password=pek");

            // Open connection
            mySqlConnection.Open();

            // Create command for mySQL connection
            MySqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            // Specify SQL query for mySQL command
            mySqlCommand.CommandText = "SELECT STATION_NAME FROM station WHERE STATION_ID = '" + stationId + "'";

            // Execute DataReader for specified command
            MySqlDataReader mySqlReader = mySqlCommand.ExecuteReader();

            mySqlReader.Read();
            string stationName = mySqlReader["STATION_NAME"].ToString();

            mySqlReader.Close();
            mySqlConnection.Close();

            return stationName;
        }
    }

    class SendUpdate
    {
        const int LISTEN_PORT = 10000;

        public void RunSendUpdate()
        {
            try
            {
                // binding the server to the local port
                IPEndPoint RemoteEndPoint = new IPEndPoint(IPAddress.Any, LISTEN_PORT);
                TcpListener clientListener = new TcpListener(RemoteEndPoint);

                // starting to listen
                clientListener.Start();

                Console.WriteLine("Send Update: Waiting for connections...");

                Thread clientThread;

                while (true)
                {
                    // accepting the connection
                    TcpClient client = clientListener.AcceptTcpClient();
                    Console.WriteLine("Accepting the new connection");

                    ClientHandler cHandler = new ClientHandler();
                    // passing value to the thread class
                    cHandler.clientSocket = client;

                    // creating a new thread for the client
                    clientThread = new Thread(new ThreadStart(cHandler.runClient));
                    clientThread.Start();
                    Thread.Sleep(100);
                }

                clientListener.Stop();
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }
    }
}
