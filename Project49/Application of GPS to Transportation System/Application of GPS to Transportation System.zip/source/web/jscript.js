// JavaScript Document
function checkDate() {
	var date = parseInt(document.getElementById("date").value);
	var month = parseInt(document.getElementById("month").value);
	var year = parseInt(document.getElementById("year").value);
	
	var toDay = new Date();
	if(year <= toDay.getFullYear()) {
		if (month <= toDay.getMonth()+1) {
			if (date <= toDay.getDate()) {
				document.getElementById("station_select_frm").reset();
				alert("โปรดระบุวันที่ต้องการจองล่วงหน้าให้ถูกต้อง");
			} else {
				document.getElementById("station_select_frm").submit();
			}
		} else {
			document.getElementById("station_select_frm").submit();
		}
	} else {
		document.getElementById("station_select_frm").submit();
	}
}

function setParam(trip_id,travel_time,blank_seat,drive_number) {
	document.getElementById("trip_id").value = trip_id;
	document.getElementById("travel_time").value = travel_time;
	document.getElementById("blank_seat").value = blank_seat;
	document.getElementById("drive_number").value = drive_number;
}

function checkUnselect() {
	if (document.getElementById("trip_id").value == "") {
		alert("คุณยังไม่ได้ทำการเลือกรถที่ต้องการ");
	} else {
		document.getElementById("car_select_frm").submit();
	}
}

function checkForm() {	
	if (document.getElementById("customer_name").value == "" || document.getElementById("customer_surname").value == "" || document.getElementById("customer_telephone").value == "") {
		alert("กรุณากรองข้อมูลผู้โดยสารให้ครบถ้วน");
	} else {
		document.getElementById("seat_select_frm").submit();
		window.location.assign("index.php");
	}
}

function checkTicketId() {
	if (document.getElementById("ticket_id").value == "") {
		alert("กรุณากรองหมายเลขตั๋วโดยสารก่อนทำการยืนยัน");
	} else {
		document.getElementById("get_ticket_id").submit();
	}
}

function checkCustomerInfo() {
	if (document.getElementById("customer_name").value == "" || document.getElementById("customer_surname").value == "") {
		alert("กรุณากรองชื่อนามสกุลผู้จองใ้ห้ครบถ้วน");
	} else {
		document.getElementById("search_reservation").submit();
	}
}

function selectStation() {
	document.getElementById("select_station_frm").submit();
}

function selectBus() {
	document.getElementById("select_bus_frm").submit();
}

function CreateMarker(point, label, html, markerIcon) {
	var marker = new GMarker(point, {icon:markerIcon, title:label});
	
	// Listen click marker event
	GEvent.addListener(marker, "click", function() {marker.openInfoWindowHtml(html);});
				
	return marker;
}

function AGTSmap(lat, lon) {
	// Create Map Object
	this.map = new GMap2(document.getElementById("map"));
	this.map.addControl(new GLargeMapControl());
	this.map.addControl(new GMapTypeControl());
	this.map.setCenter(new GLatLng(lat, lon), 6, G_HYBRID_MAP);
	
	// Create station icon
	this.stationIcon = new GIcon();
	//this.stationIcon.image = "http://labs.google.com/ridefinder/images/mm_20_red.png";
	//this.stationIcon.shadow = "http://labs.google.com/ridefinder/images/mm_20_shadow.png";
	this.stationIcon.image = "http://161.246.5.107/picture/station.png";
	this.stationIcon.iconSize = new GSize(30, 25);
	//this.stationIcon.shadowSize = new GSize(22, 20);
	this.stationIcon.iconAnchor = new GPoint(15, 12);
	this.stationIcon.infoWindowAnchor = new GPoint(15, 0);
	
	// Create bus icon
	this.busIcon = new GIcon();
	this.busIcon.image = "http://161.246.5.107/picture/bus.png";
	this.busIcon.iconSize = new GSize(25,23);
	this.busIcon.iconAnchor = new GPoint(12, 12);
	this.busIcon.infoWindowAnchor = new GPoint(15, 0);
	
	this.stations = new Array();
	this.stationHtml = new Array();
	this.stationLabel = new Array();
	this.bus = new Array();
	this.busXml = "";
	this.busHtml = new Array();
	this.busLabel = new Array();
	this.pathXml = "";
	
	// Define method
	this.ShowBus = DisplayBus;
	this.ShowPath = DisplayPath;
	this.ShowStation = DisplayStation;
	this.BusClick = BusInfoWindowHtml;
	this.StationClick = StationInfoWindowHtml;
	this.MoveBusPoint = SetBusPoint;
	
	return (this);
}

function DisplayPath()
{
	var map = this.map;
	
	GDownloadUrl(this.pathXml, function(data, responseCode)
	{
		var xml = GXml.parse(data);
		
		// obtain the array of markers and loop through it
		// ========= Now process the polylines ===========
		var lines = xml.documentElement.getElementsByTagName("line");
		
		// read each line
		for (var a = 0; a < lines.length; a++) {
			// get any line attributes
			var colour = lines[a].getAttribute("colour");
			var width  = parseFloat(lines[a].getAttribute("width"));
			
			// read each point on that line
			var points = lines[a].getElementsByTagName("point");
			var pts = [];
			
			for (var i = 0; i < points.length; i++) {
				pts[i] = new GLatLng(parseFloat(points[i].getAttribute("lat")),
				parseFloat(points[i].getAttribute("lng")));
			}
			
			map.addOverlay(new GPolyline(pts,colour,width));
		}
	});
}

function DisplayStation() {
	var map = this.map;
	var icon = this.stationIcon;
	var stations = this.stations;
	var htmls = this.stationHtml;
	
	// Read the data from station.xml
	GDownloadUrl("http://161.246.5.107/GPS/XML/station.xml", function(data, responseCode) {
		var xml = GXml.parse(data);
		var markers = xml.documentElement.getElementsByTagName("marker");
		var station_side_bar = "";
		
		for (var i = 0; i < markers.length; i++) {
			// Read data from xml
			var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
			var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
			var point = new GLatLng(lat,lng);
			htmls[i] = markers[i].getElementsByTagName("html")[0].firstChild.nodeValue;
			var label = markers[i].getElementsByTagName("label")[0].firstChild.nodeValue;
			
			// Create Station Marker
			stations[i] = CreateMarker(point, label, htmls[i], icon);	
			
			// Add link into station_side_bar
			station_side_bar += '<a href="javascript:loadMap.StationClick(\'' + htmls[i] + '\', ' + i + ')">' + label + '</a><br>';
			map.addOverlay(stations[i]);
		}
		
		if (document.getElementById("station_side_bar") != null)
			document.getElementById("station_side_bar").innerHTML = station_side_bar;
	});
}

function DisplayBus() {
	var map = this.map;
	var icon = this.busIcon;
	var bus = this.bus;
	var htmls = this.busHtml;
	var bus_side_bar = "";
	//var busXml = this.busXml;
	
	GDownloadUrl(this.busXml, function(data, responseCode) {
		var xml = GXml.parse(data);
		var markers = xml.documentElement.getElementsByTagName("marker");
		
		for (var i = 0; i < markers.length; i++) {
			// Read data from xml
			var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
			var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
			var point = new GLatLng(lat,lng);
			htmls[i] = markers[i].getElementsByTagName("html")[0].firstChild.nodeValue;
			var label = markers[i].getElementsByTagName("label")[0].firstChild.nodeValue;
				
			// Create Bus Marker	
			bus[i] = CreateMarker(point, label, htmls[i], icon);	
			
			// Add link into bus_side_bar
			bus_side_bar += '<a href="javascript:loadMap.BusClick(\'' + htmls[i] + '\', ' + i + ')">' + label + '</a><br>';
			
			map.addOverlay(bus[i]);
		}
			
		if (document.getElementById("bus_side_bar") != null)
			document.getElementById("bus_side_bar").innerHTML = bus_side_bar;
	});
}

function StationInfoWindowHtml(html, i) {
	this.stations[i].openInfoWindowHtml(html);
}

function BusInfoWindowHtml(html, count) {
	this.bus[count].openInfoWindowHtml(html);
}

function SetBusPoint(thaiMap) {
	var bus = thaiMap.bus;
	var htmls = thaiMap.busHtml;
		
	GDownloadUrl(thaiMap.busXml, function(data, responseCode) {
		var xml = GXml.parse(data);
		var markers = xml.documentElement.getElementsByTagName("marker");
		
		for (var i = 0; i < markers.length; i++) {
			// Read data from xml
			var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
			var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
			var point = new GLatLng(lat,lng);
				
			bus[i].setPoint(point);
		}
	});
}
