<?php
	function station($station_id) {
		include("./db_connection.php");
		$sql = "SELECT STATION_NAME FROM station WHERE STATION_ID = '" . $station_id . "'";
		$result = mysql_query($sql);
		$station = mysql_fetch_array($result);
		mysql_close($db);
		return $station['STATION_NAME'];
	}
	
	function bus_plan($bus_id,$trip_id,$date,$time) {
?>
		  <table width="300" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="125" background="../Picture/bus_plan_01.gif">&nbsp;</td>
            </tr>
            <tr>
              <td>
			  <table width="300" border="0" cellpadding="5" cellspacing="0" background="../Picture/bus_plan_02.gif">
<?php
		include("./db_connection.php");
		//Get amount of reserved seat of each bus
		if ($_SESSION['ss_This_Station'] < $_SESSION['ss_destination']) {
			$sql = "SELECT DISTINCT SEAT_NO FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $bus_id . "' " .
			       "AND DATE_TRAVEL = '" . $date . "' " .
				// "AND TIME_TRAVEL <= '" . $time . "' " .
			       "AND SOURCE_STATION < '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION > '" . $_SESSION['ss_This_Station'] . "' " .
				   "ORDER BY SEAT_NO";
		} else {
			$sql = "SELECT DISTINCT SEAT_NO FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $bus_id . "' " .
			       "AND DATE_TRAVEL = '" . $date . "' " .
				// "AND TIME_TRAVEL <= '" . $time . "' " .
			       "AND SOURCE_STATION > '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION < '" . $_SESSION['ss_This_Station'] . "' " .
				   "ORDER BY SEAT_NO";
		}
		$result = mysql_query($sql);
		$seat = mysql_fetch_array($result);
		for($i = 0; $i < 40; $i++) {
			if($i % 4 == 0) print "\t\t\t<tr>\n";
			if(($i+1) == $seat['SEAT_NO']) {
				print "\t\t\t\t<td width=\"50\" height=\"60\" background=\"../Picture/served_seat.gif\" align=\"center\"  class=\"seat\">\n\t\t\t\t\t";
				print ($i+1) . "<br />\n";
				print "\t\t\t\t\t<input name=\"seat_no_" . ($i+1) . "\" id=\"seat_no_" . ($i+1) . "\" type=\"checkbox\" disabled value=\"" . ($i+1) . "\" />\n\t\t\t\t</td>\n";
				$seat = mysql_fetch_array($result);
			} else {
				print "\t\t\t\t<td width=\"50\" height=\"60\" background=\"../Picture/no_served_seat.gif\" align=\"center\"  class=\"seat\">\n\t\t\t\t\t";
				print ($i+1) . "<br />\n";
				print "\t\t\t\t\t<input name=\"seat_no_" . ($i+1) . "\" id=\"seat_no_" . ($i+1) . "\" type=\"checkbox\" value=\"" . ($i+1) . "\" />\n\t\t\t\t</td>\n";
			}
			if($i % 4 == 1) print "\t\t\t\t<td width=\"50\" height=\"60\">&nbsp;</td>\n";
			if($i % 4 == 3) print "\t\t\t</tr>\n";
		}
		mysql_close($db);
?>
		  	  </table>
		  	  </td>
            </tr>
			<tr>
              <td height="25" background="../Picture/bus_plan_03.gif">&nbsp;</td>
            </tr>
          </table>
<?php
	}
	
	function bus_plan2($bus_id,$trip_id,$date,$time) {
?>
		  <table width="300" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="125" background="../Picture/bus_plan_01.gif">&nbsp;</td>
            </tr>
            <tr>
              <td>
			  <table width="300" border="0" cellpadding="5" cellspacing="0" background="../Picture/bus_plan_02.gif">
<?php
		include("./db_connection.php");
		//Get amount of reserved seat of each bus
		if ($_SESSION['ss_source'] < $_SESSION['ss_destination']) {
			$sql = "SELECT DISTINCT SEAT_NO FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $bus_id . "' " .
			       "AND DATE_TRAVEL = '" . $date . "' " .
			       "AND SOURCE_STATION < '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION > '" . $_SESSION['ss_source'] . "'" .
				   "ORDER BY SEAT_NO";
		} else {
			$sql = "SELECT DISTINCT SEAT_NO FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $bus_id . "' " .
			       "AND DATE_TRAVEL = '" . $date . "' " .
			       "AND SOURCE_STATION > '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION < '" . $_SESSION['ss_source'] . "'" .
				   "ORDER BY SEAT_NO";
		}
		
		$result = mysql_query($sql);
		$seat = mysql_fetch_array($result);
		for($i = 0; $i < 40; $i++) {
			if($i % 4 == 0) print "\t\t\t<tr>\n";
			if(($i+1) == $seat['SEAT_NO']) {
				print "\t\t\t\t<td width=\"50\" height=\"60\" background=\"../Picture/served_seat.gif\" align=\"center\"  class=\"seat\">\n\t\t\t\t\t";
				print ($i+1) . "<br />\n";
				print "\t\t\t\t\t<input name=\"seat_no_" . ($i+1) . "\" id=\"seat_no_" . ($i+1) . "\" type=\"checkbox\" disabled value=\"" . ($i+1) . "\" />\n\t\t\t\t</td>\n";
				$seat = mysql_fetch_array($result);
			} else {
				print "\t\t\t\t<td width=\"50\" height=\"60\" background=\"../Picture/no_served_seat.gif\" align=\"center\"  class=\"seat\">\n\t\t\t\t\t";
				print ($i+1) . "<br />\n";
				print "\t\t\t\t\t<input name=\"seat_no_" . ($i+1) . "\" id=\"seat_no_" . ($i+1) . "\" type=\"checkbox\" value=\"" . ($i+1) . "\" />\n\t\t\t\t</td>\n";
			}
			if($i % 4 == 1) print "\t\t\t\t<td width=\"50\" height=\"60\">&nbsp;</td>\n";
			if($i % 4 == 3) print "\t\t\t</tr>\n";
		}
		mysql_close($db);
?>
		  	  </table>
		  	  </td>
            </tr>
			<tr>
              <td height="25" background="../Picture/bus_plan_03.gif">&nbsp;</td>
            </tr>
          </table>
<?php
	}
	
	function UTF8toiso8859_11($string) {
 
		if ( ! ereg("[\241-\377]", $string) )
        	return $string;
 
		$UTF8 = array(
			"\xe0\xb8\x81" => "\xa1",
			"\xe0\xb8\x82" => "\xa2",
			"\xe0\xb8\x83" => "\xa3",
			"\xe0\xb8\x84" => "\xa4",
			"\xe0\xb8\x85" => "\xa5",
			"\xe0\xb8\x86" => "\xa6",
			"\xe0\xb8\x87" => "\xa7",
			"\xe0\xb8\x88" => "\xa8",
			"\xe0\xb8\x89" => "\xa9",
			"\xe0\xb8\x8a" => "\xaa",
			"\xe0\xb8\x8b" => "\xab",
			"\xe0\xb8\x8c" => "\xac",
			"\xe0\xb8\x8d" => "\xad",
			"\xe0\xb8\x8e" => "\xae",
			"\xe0\xb8\x8f" => "\xaf",
			"\xe0\xb8\x90" => "\xb0",
			"\xe0\xb8\x91" => "\xb1",
			"\xe0\xb8\x92" => "\xb2",
			"\xe0\xb8\x93" => "\xb3",
			"\xe0\xb8\x94" => "\xb4",
			"\xe0\xb8\x95" => "\xb5",
			"\xe0\xb8\x96" => "\xb6",
			"\xe0\xb8\x97" => "\xb7",
			"\xe0\xb8\x98" => "\xb8",
			"\xe0\xb8\x99" => "\xb9",
			"\xe0\xb8\x9a" => "\xba",
			"\xe0\xb8\x9b" => "\xbb",
			"\xe0\xb8\x9c" => "\xbc",
			"\xe0\xb8\x9d" => "\xbd",
			"\xe0\xb8\x9e" => "\xbe",
			"\xe0\xb8\x9f" => "\xbf",
			"\xe0\xb8\xa0" => "\xc0",
			"\xe0\xb8\xa1" => "\xc1",
			"\xe0\xb8\xa2" => "\xc2",
			"\xe0\xb8\xa3" => "\xc3",
			"\xe0\xb8\xa4" => "\xc4",
			"\xe0\xb8\xa5" => "\xc5",
			"\xe0\xb8\xa6" => "\xc6",
			"\xe0\xb8\xa7" => "\xc7",
			"\xe0\xb8\xa8" => "\xc8",
			"\xe0\xb8\xa9" => "\xc9",
			"\xe0\xb8\xaa" => "\xca",
			"\xe0\xb8\xab" => "\xcb",
			"\xe0\xb8\xac" => "\xcc",
			"\xe0\xb8\xad" => "\xcd",
			"\xe0\xb8\xae" => "\xce",
			"\xe0\xb8\xaf" => "\xcf",
			"\xe0\xb8\xb0" => "\xd0",
			"\xe0\xb8\xb1" => "\xd1",
			"\xe0\xb8\xb2" => "\xd2",
			"\xe0\xb8\xb3" => "\xd3",
			"\xe0\xb8\xb4" => "\xd4",
			"\xe0\xb8\xb5" => "\xd5",
			"\xe0\xb8\xb6" => "\xd6",
			"\xe0\xb8\xb7" => "\xd7",
			"\xe0\xb8\xb8" => "\xd8",
			"\xe0\xb8\xb9" => "\xd9",
			"\xe0\xb8\xba" => "\xda",
			"\xe0\xb8\xbf" => "\xdf",
			"\xe0\xb9\x80" => "\xe0",
			"\xe0\xb9\x81" => "\xe1",
			"\xe0\xb9\x82" => "\xe2",
			"\xe0\xb9\x83" => "\xe3",
			"\xe0\xb9\x84" => "\xe4",
			"\xe0\xb9\x85" => "\xe5",
			"\xe0\xb9\x86" => "\xe6",
			"\xe0\xb9\x87" => "\xe7",
			"\xe0\xb9\x88" => "\xe8",
			"\xe0\xb9\x89" => "\xe9",
			"\xe0\xb9\x8a" => "\xea",
			"\xe0\xb9\x8b" => "\xeb",
			"\xe0\xb9\x8c" => "\xec",
			"\xe0\xb9\x8d" => "\xed",
			"\xe0\xb9\x8e" => "\xee",
			"\xe0\xb9\x8f" => "\xef",
			"\xe0\xb9\x90" => "\xf0",
			"\xe0\xb9\x91" => "\xf1",
			"\xe0\xb9\x92" => "\xf2",
			"\xe0\xb9\x93" => "\xf3",
			"\xe0\xb9\x94" => "\xf4",
			"\xe0\xb9\x95" => "\xf5",
			"\xe0\xb9\x96" => "\xf6",
			"\xe0\xb9\x97" => "\xf7",
			"\xe0\xb9\x98" => "\xf8",
			"\xe0\xb9\x99" => "\xf9",
			"\xe0\xb9\x9a" => "\xfa",
			"\xe0\xb9\x9b" => "\xfb",
		);
 
		$string = strtr($string,$UTF8);
		return $string;
	}
	
	function createTicket($pdf,$ticket_no,$station,$source,$destination,$date_travel,$time_travel,$path,$bus_id,$seat_no,$price) {
		$pdf->AddPage();

		$pdf->Image("../Picture/ticket_bg.jpg",10,4);
		$pdf->SetFont('AngsanaNew','B',16);
		$pdf->SetTextColor(0,0,0);
		$str = UTF8toiso8859_11("บริษัท ขนส่งมวลชน จำกัด");
		$pdf->Text(28,14,$str);

		$pdf->SetFont('AngsanaNew','',12);
		$pdf->SetTextColor(0,0,0);

		$str = UTF8toiso8859_11("เลขที่   $ticket_no");
		$pdf->Text(2,5,$str);
		$str = UTF8toiso8859_11("สถานี$station");
		$pdf->Text(70,5,$str);
		$str = UTF8toiso8859_11("ต้นทาง   $source");
		$pdf->Text(5,22,$str);
		$str = UTF8toiso8859_11("ปลายทาง   $destination");
		$pdf->Text(60,22,$str);
		$str = UTF8toiso8859_11("วันที่เดินทาง   $date_travel");
		$pdf->Text(5,28,$str);
		$str = UTF8toiso8859_11("เวลา   $time_travel");
		$pdf->Text(60,28,$str);
		$str = UTF8toiso8859_11("รถสาย   $path");
		$pdf->Text(5,34,$str);
		$str = UTF8toiso8859_11("หมายเลขรถ   $bus_id");
		$pdf->Text(60,34,$str);
		$str = UTF8toiso8859_11("หมายเลขที่นั่ง   $seat_no");
		$pdf->Text(5,40,$str);
		$str = UTF8toiso8859_11("ราคา   $price");
		$pdf->Text(60,40,$str);
		$datestr = date("d-F-Y");
		list($day,$mon,$year) = explode("-",$datestr);
		$str = UTF8toiso8859_11("ออกเมื่อวันที่    $day $mon $year");
		$pdf->Text(5,46,$str);
		$timestr = date("G:i:s");
		list($hour,$min,$sec) = explode(":",$timestr);
		$str = UTF8toiso8859_11("เวลา    $hour:$min:$sec");
		$pdf->Text(60,46,$str);
	}
	
	function getMonth($numMonth) {
		$month = array(
			"1" => "มกราคม",
			"2" => "กุมภาพันธ์",
			"3" => "มีนาคม",
			"4" => "เมษายน",
			"5" => "พฤษภาคม",
			"6" => "มิุถุนายน",
			"7" => "กรกฎาคม",
			"8" => "สิงหาคม",
			"9" => "กันยายน",
			"10" => "ตุลาคม",
			"11" => "พฤศจิกายน",
			"12" => "ธันวาคม"
		);
		
		return $month[$numMonth];
	}
	
	function previousday($thisday)
	{
		switch($thisday) {
			case "Monday":
				$preday = "Sunday";
				break;
			case "Tuesday":
				$preday = "Monday";
				break;
			case "Wednesday":
				$preday = "Tuesday";
				break;
			case "Thursday":
				$preday = "Wednesday";
				break;
			case "Friday":
				$preday = "Thursday";
				break;
			case "Saturday":
				$preday = "Friday";
				break;
			case "Sunday":
				$preday = "Saturday";
				break;
		}
		return $preday;
	}
	
	function getTime($bus_id, $station_id, $day) {
		include("./db_connection.php");
		
		$sql = "SELECT TIME FROM schedule,driving_table " .
			   "WHERE BUS_ID = '" . $bus_id . "' " .
			   "AND STATION_ID = '" . $station_id . "' " .
			   "AND DAY = '" . $day . "' " .
			   "AND schedule.DRIVE_NUMBER = driving_table.DRIVE_NUMBER";
			   
		$time = mysql_fetch_array(mysql_query($sql));
		mysql_close($db);
		
		return $time['TIME'];
	}
	function getTime2($bus_id, $station_id) {
		include("./db_connection.php");
		
		$sql = "SELECT TIME FROM schedule,driving_table " .
			   "WHERE BUS_ID = '" . $bus_id . "' " .
			   "AND STATION_ID = '" . $station_id . "' " .
			   "AND schedule.DRIVE_NUMBER = driving_table.DRIVE_NUMBER";
			   
		$time = mysql_fetch_array(mysql_query($sql));
		mysql_close($db);
		
		return $time['TIME'];
	}
?>
