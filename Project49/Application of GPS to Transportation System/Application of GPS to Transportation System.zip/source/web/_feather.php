		<td width="150" align="center" valign="top" >
		<table width="150" border="0" align="center" cellpadding="0" cellspacing="5" bgcolor="#FFFFFF">
		  <tr>
		  	<td height="25" align="center" bgcolor="#FFCCCC"><strong>:: รายการ ::</strong></td>
		  </tr>
          <tr>
            <td height="25" align="center" bgcolor="#FFFFCC"><p><a href="./schedular.php">ตารางการเดินรถ<br />และอัตราค่าโดยสาร</a></p></td>
          </tr>
          <tr>
            <td height="25" align="center" bgcolor="#FFFFCC"><a href="./searchcar.php">ค้นหารถ</a></td>
          </tr>
          <tr>
            <td height="25" align="center" bgcolor="#FFFFCC"><a href="./checkreservation.php">ตรวจสอบการจอง</a></td>
          </tr>
		  <tr>
            <td height="25" align="center" bgcolor="#FFFFCC"><a href="./cancelreservation.php">ยกเลิกการจอง</a></td>
          </tr>
		  <tr>
            <td height="25" align="center" bgcolor="#FFFFCC"><a href="./stationaddress.php">ที่ทำการสถานี</a></td>
          </tr>
        </table>		
		</td>
