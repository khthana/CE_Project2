<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

include("./function.php");

if (isset($bus_id))
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>ตำแหน่งรถโดยสารหมายเลข&nbsp;<?php print $bus_id; ?></title>
	<link href="./style.css" rel="stylesheet" type="text/css" />
	<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAgnkK1Dxg0-Jj8YDBWZCmXhSGEvUsQCnxNsP_IGn1Gs7UatBXDBTtR1bCfRlycKPuf2k13cqSUXstEw" type="text/javascript"></script>
	<script src="./jscript.js" type="text/javascript" language="javascript"></script>
	<script type="text/javascript">
    //<![CDATA[
		
	function LoadGMap() {
		if (GBrowserIsCompatible())
		{	
			this.thaiMap = new AGTSmap(13.5, 100.5);
			
			this.thaiMap.pathXml = "http://161.246.5.107/GPS/XML/path.xml";
			this.thaiMap.busXml = "http://161.246.5.107/GPS/XML/bus.xml";

			this.thaiMap.ShowPath();
			this.thaiMap.ShowStation();
			this.thaiMap.ShowBus();
			setInterval(this.thaiMap.MoveBusPoint, 1000, this.thaiMap);
			
			this.stations = this.thaiMap.stations;
			this.StationClick = this.thaiMap.StationClick;
			
			this.bus = this.thaiMap.bus;
			this.BusClick = this.thaiMap.BusClick;
			
			function moveCenter(thaiMap) {
				// Read the data from station.xml
				GDownloadUrl(thaiMap.busXml, function(data, responseCode) {
					var xml = GXml.parse(data);
					var markers = xml.documentElement.getElementsByTagName("marker");							
												
					// Read data from xml
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].getAttribute("id") == "<?php print $bus_id; ?>") {
							var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
							var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
							var html = markers[i].getElementsByTagName("html")[0].firstChild.nodeValue;
							
							thaiMap.map.setCenter(new GLatLng(lat, lng), 9, G_HYBRID_MAP);
							thaiMap.bus[i].openInfoWindowHtml(html);
						}
					}
				});
			}
			
			window.setTimeout(moveCenter, 1000, this.thaiMap);
			
			function distance(thaiMap) {
				var busLatLng;
				var stationLatLng;
				
				// Read the data from station.xml
				GDownloadUrl("http://161.246.5.107/GPS/XML/bus.xml", function(data, responseCode) {
					var xml = GXml.parse(data);
					var markers = xml.documentElement.getElementsByTagName("marker");							
												
					// Read data from xml
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].getAttribute("id") == "<?php print $bus_id; ?>") {
							var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
							var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
							busLatLng = new GLatLng(lat, lng);
							
							var bound = thaiMap.map.getBounds();
			
							if (!bound.contains(busLatLng)) {
								thaiMap.map.panTo(busLatLng);
							}
						}
					}
				});
				
				GDownloadUrl("http://161.246.5.107/GPS/XML/station.xml", function(data, responseCode) {
					var xml = GXml.parse(data);
					var markers = xml.documentElement.getElementsByTagName("marker");
					
					for (var i = 0; i < markers.length; i++) {
						if (markers[i].getAttribute("id") == "<?php print $_SESSION['ss_This_Station']; ?>") {
							var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
							var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
							stationLatLng = new GLatLng(lat, lng);
							
							var distance = stationLatLng.distanceFrom(busLatLng);
							var info = "Bus No:&nbsp;<?php print $bus_id; ?>&nbsp;&nbsp;Latitude: " + busLatLng.lat() + "&nbsp;&nbsp;Longitude: " + busLatLng.lng() + "&nbsp;&nbsp;Distance from this station: " + Math.round(distance)/1000 + " km.";
							document.getElementById("info").innerHTML = info;
						}
					}
				});
			}
			
			setInterval(distance, 100, this.thaiMap);
		}
	}
	
    //]]>
    </script>
</head>

<body onload="loadMap = new LoadGMap();" onunload="GUnload()">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div id="map" align="center" style="width: 600px; height: 470px;"></div></td>
  </tr>
  <tr>
    <td height="30" align="center" bgcolor="#E2E2E2"><div id="info" align="center"></div></td>
  </tr>
</table>
</body>
</html>
<?php
}
?>
