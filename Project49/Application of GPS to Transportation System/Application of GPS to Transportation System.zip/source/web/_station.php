<?php
	include("./db_connection.php");
	$sql = "SELECT * FROM station ORDER BY STATION_NAME";
	$result = mysql_query($sql);
	$i = 0;
	while($station = mysql_fetch_array($result)) {
		print "\t\t\t\t<option value=\"" . $station['STATION_ID'] . "\" "; 
		if ($i = 0) { print "selected=\"selected\""; $i++; }
		print ">" . $station['STATION_NAME'] . "</option>\n";
	}
	mysql_close();
?>