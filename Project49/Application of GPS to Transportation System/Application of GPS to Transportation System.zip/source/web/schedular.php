<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

include("_header.php");
?>
  <tr>
    <td align="center" valign="top">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" >
      <tr>
		<?php include("_feather.php"); ?>
		<td align="center" valign="top">
		<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
          <tr>
            <td height="30" class="header"><div align="center">ตารางการเดินรถ<?php if (isset($_POST['search'])) print station($_POST['source']) . "-" . station($_POST['destination']); ?></div></td>
          </tr>
		  <tr>
            <td>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
  			  <tr>
            	<td>
				<form id="form1" name="form1" method="post" action="schedular.php">
			  	  <table width="100%" height="25" border="0" align="center" cellpadding="5" cellspacing="0">				  
					<tr>
					  <td width="5%">&nbsp;</td>
                  	  <td width="20%" height="25" align="left">
					    <label>สถานีต้นทาง : 
                          <select name="source" id="source" class="jump">
                            <?php include("_station.php"); ?>
                          </select>
                        </label>
					  </td>
					  <td width="22%" align="left">
					    <label>สถานีปลายทาง :
                          <select name="destination" id="destination" class="jump">
						    <?php include("_station.php"); ?>
                          </select>
					    </label>			
					  </td>
                      <td width="28%" align="left">
					    <label>ระดับชั้นรถ : 
                          <select name="typecar" id="typecar" class="jump">
						  	<option value="all" selected="selected">ทุกประเภท</option>
                            <option value="A">ระดับ A</option>
                            <option value="B">ระดับ B</option>
                          </select>
                        </label>					  
					  </td>
					  <td width="25%" height="25" align="left">
						<!--<label>
						  <input name="go-back" type="checkbox" id="go-back" value="go-back" />
						  ไป-กลับ
						</label> -->
						&nbsp;
						<input name="search" type="submit" id="search" value="ค้นหา" class="button" />
					  </td>
					</tr>
               	  </table>
                </form>
                </td>
              </tr>
		    </table>
		    </td>
          </tr>
		  <tr>
		    <td align="center" valign="top">
			  <table width="98%" border="0" cellpadding="0" cellspacing="0">
              <tr align="center" valign="middle" class="table_header">
            	<td width="21%" height="40">สายรถ</td>
				<td width="6%">ชั้น</td>
				<td width="10%">หมายเลขรถ</td>
            	<td width="11%">อัตราค่าโดยสาร<br />
            	  (บาท)</td>
            	<td width="6%">ระยะทาง<br />
            	  (กม.)</td>
				<td width="11%">วัน</td>
            	<td width="11%">ระยะเวลา<br />
            	  (ชม.)</td>
            	<td width="12%">รถเข้า<?php print station($_POST['source']); ?></td>
            	<td width="12%">รถถึง<?php print station($_POST['destination']); ?></td>
              </tr>
<?php
	include("./db_connection.php");
	$sql = "SELECT START_STATION, FINAL_STATION,SOURCE_STATION,DESTINATION_STATION, CLASS, BUS_ID, PRICE, DISTANCE, DAY, DURATION " .
		   "FROM path, trip, trip_in_path, driving_table " .
		   "WHERE path.PATH_ID = trip_in_path.PATH_ID " .
		   "AND trip_in_path.TRIP_ID = trip.TRIP_ID " .
		   "AND path.PATH_ID = driving_table.PATH_ID " .
		   "AND SOURCE_STATION = '" . $_POST['source'] . "' " .
		   "AND DESTINATION_STATION = '" . $_POST['destination'] . "' ";
		   
	if ($_POST['typecar'] != "all") {
		$sql .= "AND CLASS = '" . $_POST['typecar'] . "' ";
	}
	$sql .= "ORDER BY START_STATION, FINAL_STATION, CLASS,BUS_ID";
	
	$result = mysql_query($sql);
	mysql_close($db);
	
	$i = 0;
	while($row = mysql_fetch_array($result)) {
?>
              <tr align="center" bgcolor="<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF"; ?>" onmouseover="this.bgColor='#FA991C';" onmouseout="this.bgColor='<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF";?>';">
                <td height="25" align="center">
				  <?php print station($row['START_STATION']) . "-" . station($row['FINAL_STATION']); ?>
				</td>
				<td align="center"><?php print $row['CLASS']; ?></td>
				<td align="center"><?php print $row['BUS_ID']; ?></td>
            	<td align="center"><?php print $row['PRICE']; ?></td>
            	<td align="center"><?php print $row['DISTANCE']; ?></td>
				<td align="center"><?php print $row['DAY']; ?></td>
            	<td align="center"><?php print $row['DURATION']; ?></td>
            	<td align="center"><?php print getTime($row['BUS_ID'], $row['SOURCE_STATION'], $row['DAY']); ?></td>
            	<td align="center"><?php print getTime($row['BUS_ID'], $row['DESTINATION_STATION'], $row['DAY']); ?></td>
		<!--		<td align="center"><?php print getTime($row['BUS_ID'], $row['START_STATION'], $row['DAY']); ?></td>
            	<td align="center"><?php print getTime($row['BUS_ID'], $row['FINAL_STATION'], $row['DAY']); ?></td> -->
          	  </tr>
<?php
		$i++;
	}
?>
        	</table>
			</td>
		  </tr>
        </table>
		</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</body>
</html>
