<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

if ($_POST['select_seat'] == "confirm")
{
	$bus_id = $_SESSION['ss_bus_id'];
	$trip_id = $_SESSION['ss_trip_id'];
	$date = $_SESSION['ss_travel_date'];
	$time = $_SESSION['ss_travel_time'];
	$c_name = $_POST['customer_name'];
	$c_surname = $_POST['customer_surname'];
	$c_telephone = $_POST['customer_telephone'];
	unset($_POST['customer_name'],$_POST['customer_surname'],$_POST['customer_telephone'],$_POST['select_seat']);
	
	include("./function.php");
	require("./thaipdfclass.php");
	
	//create ticket pdf
	$ticket = new thaiPDF("Landscape","mm","ticket");
	$ticket->SetDisplayMode("real");
	$ticket->SetThaiFont();
	
	include("./db_connection.php");
	$sql = "SELECT COUNT(*) FROM customer WHERE C_NAME = '" . $c_name . "' AND C_SURNAME = '" . $c_surname . "'";
	$result = mysql_fetch_array(mysql_query($sql));
	
	if ($result['COUNT(*)'] == "0") {
		$sql = "INSERT INTO customer " .
			   "SET C_NAME = '" . $c_name . "', " .
			   "C_SURNAME = '" . $c_surname . "', " .
			   "C_TELEPHONE = '" . $c_telephone . "'";
		mysql_query($sql);
	} elseif ($result['COUNT(*)'] == "1") {
		$sql = "SELECT C_TELEPHONE FROM customer " .
			   "WHERE C_NAME = '" . $c_name . "' AND C_SURNAME = '" . $c_surname . "'";
		$result = mysql_fetch_array(mysql_query($sql));
		if ($result['C_TELEPHONE'] != $c_telephone) {
			$sql = "UPDATE customer SET C_TELEPHONE = '" . $c_telephone . "'";
			mysql_query($sql);
		}
	}
	
	$sql = "SELECT C_NUMBER FROM customer WHERE C_NAME = '" . $c_name . "' AND C_SURNAME = '" . $c_surname . "'";
	$customer = mysql_fetch_array(mysql_query($sql));
	
	while($post = each($_POST)) {
		include("./db_connection.php");
		$sql = "INSERT INTO reservation " .
			   "SET BUS_ID = '" . $bus_id . "', " .
			   "TRIP_ID = '" . $trip_id . "', " .
			   "SEAT_NO = '" . $post['value'] . "', " .
			   "DATE_TRAVEL = '" . $date . "', " .
			   "TIME_TRAVEL = '" . $time . "', " .
			   "C_NUMBER = '" . $customer['C_NUMBER'] . "'";
		mysql_query($sql);
		
		$sql = "SELECT RESERV_NUMBER, r.BUS_ID, DATE_TRAVEL, TIME_TRAVEL, SOURCE_STATION, DESTINATION_STATION, START_STATION, FINAL_STATION, PRICE, SEAT_NO " .
			   "FROM reservation r,trip t,path p,trip_in_path tip " .
			   "WHERE r.TRIP_ID = t.TRIP_ID " .
			   "AND r.TRIP_ID = tip.TRIP_ID " .
			   "AND tip.PATH_ID = p.PATH_ID " .
			   "AND RESERV_NUMBER = (SELECT MAX(RESERV_NUMBER) FROM reservation)";
		$reserve = mysql_fetch_array(mysql_query($sql));
		
		$sql = "SELECT DATE_FORMAT('" . $reserve['DATE_TRAVEL'] . "', '%d %M %Y')";
		$date_travel = mysql_fetch_array(mysql_query($sql));
		$sql = "SELECT DATE_FORMAT('" . $reserve['DATE_TRAVEL'] . " " . $reserve['TIME_TRAVEL'] . "', '%T')";
		$time_travel = mysql_fetch_array(mysql_query($sql));
		$path = station($reserve['START_STATION']) . " - " . station($reserve['FINAL_STATION']);
		
		createTicket($ticket,$reserve['RESERV_NUMBER'],station($_SESSION['ss_This_Station']),
					 station($reserve['SOURCE_STATION']),station($reserve['DESTINATION_STATION']),
					 $date_travel["DATE_FORMAT('" . $reserve['DATE_TRAVEL'] . "', '%d %M %Y')"],
					 $time_travel["DATE_FORMAT('" . $reserve['DATE_TRAVEL'] . " " . $reserve['TIME_TRAVEL'] . "', '%T')"],
					 $path,$reserve['BUS_ID'],$reserve['SEAT_NO'],$reserve['PRICE']);
	}
		
	$ticket->output();
	
	session_unregister("ss_bus_id");
	session_unregister("ss_trip_id");
	session_unregister("ss_date_travel");
	session_unregister("ss_time_travel");
	
	mysql_close($db);
}
?>