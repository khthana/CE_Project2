<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

	include("./function.php");
	$station_name = station($_SESSION['ss_This_Station']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="th" lang="th" dir="ltr" >
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>ระบบ GPS เพื่อขนส่งมวลชน</title>
	<link href="./style.css" rel="stylesheet" type="text/css" />
	<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAgnkK1Dxg0-Jj8YDBWZCmXhSGEvUsQCnxNsP_IGn1Gs7UatBXDBTtR1bCfRlycKPuf2k13cqSUXstEw" type="text/javascript"></script>
	<script src="./jscript.js" type="text/javascript"></script>
	<script type="text/javascript">
    //<![CDATA[
		
	function LoadGMap() {
		if (GBrowserIsCompatible())
		{
			document.getElementById("station").value = "<?php print $_POST['station']; ?>";
			
			this.thaiMap = new AGTSmap(13.72915, 100.77562);
			
			this.thaiMap.pathXml = "http://161.246.5.107/GPS/XML/path.xml";
			this.thaiMap.busXml = "http://161.246.5.107/GPS/XML/bus.xml";

			this.thaiMap.ShowPath();
			this.thaiMap.ShowStation();
			this.thaiMap.ShowBus();
			setInterval(this.thaiMap.MoveBusPoint, 1000, this.thaiMap);
			
			this.stations = this.thaiMap.stations;
			this.StationClick = this.thaiMap.StationClick;
			
			this.bus = this.thaiMap.bus;
			this.BusClick = this.thaiMap.BusClick;
			
			function moveCenter(thaiMap) {
				var map = thaiMap.map;
				var station = thaiMap.stations;
				
				// Read the data from station.xml
				GDownloadUrl("http://161.246.5.107/GPS/XML/station.xml", function(data, responseCode) {
					var xml = GXml.parse(data);
					var markers = xml.documentElement.getElementsByTagName("marker");
					var first = true;
		
					for (var i = 0; i < markers.length; i++) {
						// Read data from xml
						if (markers[i].getAttribute("id") == "<?php print $_POST['station']; ?>") {
							var lat = parseFloat(markers[i].getElementsByTagName("lat")[0].firstChild.nodeValue);
							var lng = parseFloat(markers[i].getElementsByTagName("lng")[0].firstChild.nodeValue);
							var html = markers[i].getElementsByTagName("html")[0].firstChild.nodeValue;
							map.setCenter(new GLatLng(lat, lng), 9);
							station[i].openInfoWindowHtml(html);
							first = false;
						}
					}
					
					if (first) {
						var lat = parseFloat(markers[0].getElementsByTagName("lat")[0].firstChild.nodeValue);
						var lng = parseFloat(markers[0].getElementsByTagName("lng")[0].firstChild.nodeValue);
						var html = markers[0].getElementsByTagName("html")[0].firstChild.nodeValue;
						map.setCenter(new GLatLng(lat, lng), 9);
						station[0].openInfoWindowHtml(html);
					}
				});
			}
			
			window.setTimeout(moveCenter, 1000, this.thaiMap);
		}
	}
    //]]>
    </script>
</head>

<body onload="loadMap = new LoadGMap();" onunload="GUnload()">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="65" align="center" valign="top">
	<table width="100%" height="65" border="0" align="center" cellpadding="5" cellspacing="0" background="../Picture/banner.gif">
      <tr valign="top">
        <td height="0" align="right" valign="bottom">
		  <p><b><font color="#FFCC33">สถานี</font> : <?php echo $station_name; ?>&nbsp;&nbsp;<font color="#FFCC33">พนักงานที่ใช้ระบบ</font> : <?php echo $_SESSION['ss_Uname'] . " " .  $_SESSION['ss_Usurname']; ?></b></p>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  <tr>
    <td height="25" align="center">
	<table width="100%" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr class="nav">
        <td height="25" align="center" class="nav"><a href="./index.php">หน้าแรก</a></td>
        <td height="25" align="center" class="nav"><a href="./buyticket.php">จำหน่ายตั๋ว</a></td>
        <td height="25" align="center" class="nav"><a href="./reservation.php">จองตั๋วล่วงหน้า</a></td>
        <td height="25" align="center" class="nav"><a href="./login.php">ออกจากระบบ</a></td>
      </tr>
    </table>
	</td>
  </tr>
  <tr>
    <td align="center" valign="top">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" >
      <tr>
<?php include("_feather.php"); ?>
		<td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="30" align="center" class="header">ที่ทำการสถานีขนส่ง</td>
          </tr>
          <tr>
            <td align="center"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
              <tr>
                <td width="50%" align="center">
				<table width="400" border="1" cellpadding="0" cellspacing="0" class="borderThin">
                  <tr class="table_header2">
                    <td height="25" align="center">ที่ทำการสถานีขนส่ง<?php if (!isset($_POST['station'])) print station("0001"); else print station($_POST['station']); ?></td>
                  </tr>
                  <tr>
                    <td><div id="map" style="height: 350px"></div></td>
                  </tr>
                </table>
				</td>
                <td width="50%" align="center"><table width="300" height="25" border="0" cellpadding="5" cellspacing="0">
                  <tr>
                    <td>
                      <form id="select_station_frm" method="post" action="stationaddress.php">
                        สถานีขนส่ง&nbsp;
                        <select name="station" size="1" class="jump" id="station" onchange="selectStation()">
<?php include("_station.php"); ?>
                        </select>
                      </form>
                      </td>
                  </tr>
<?php
if (isset($_POST['station']))
	$station_id = $_POST['station'];
else
	$station_id = "0001";
	
include("./db_connection.php");
	
$sql = "SELECT ADDRESS, TELEPHONE FROM station WHERE STATION_ID = '" . $station_id . "'";
$station_info = mysql_fetch_array(mysql_query($sql));
echo mysql_error();
?>
                  <tr>
                    <td>ที่อยู่&nbsp;<?php echo $station_info['ADDRESS']; ?></td>
                  </tr>
                  <tr>
                    <td>เบอร์โทรศัพท์&nbsp;<?php echo $station_info['TELEPHONE']; ?></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table>
	</td>
  </tr>
</table>
</body>
</html>
