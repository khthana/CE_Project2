<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

include("_header.php");
?>
  <tr>
    <td align="center" valign="top">
	<table width="100%" cellpadding="0" cellspacing="0" >
      <tr>
<?php include("_feather.php"); ?>
		<td valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td height="30" class="header"><div align="center">ยกเลิกการจองตั๋ว</div></td>
          </tr>
<?php 
if ($_POST['getTicket'] != "OK" && !isset($_POST['ticket_id'])) {
?>
          <tr>
            <td align="center" valign="middle">
			<form name="get_ticket_id" id="get_ticket_id" action="cancelreservation.php" method="post">
              <table width="300" border="0" cellpadding="0" cellspacing="5">
                <tr>
                  <td valign="bottom"><div align="center">กรุณากรอกหมายเลขรหัสการจอง</div></td>
                </tr>
                <tr>
                  <td>
				    <div align="center">
					  <input name="ticket_id" type="text" class="text" id="ticket_id" size="6" maxlength="6">
					</div>
				  </td>
                </tr>
                <tr>
                  <td valign="top">
				    <div align="center">
					  <input name="OK" type="button" class="button" id="OK" value="ยืนยัน" onclick="checkTicketId()">
					  <input name="getTicket" type="hidden" id="getTicket" value="OK" />
                      &nbsp;
                      <input name="cancel" type="reset" class="button" id="cancel" value="ยกเลิก" />
                  	</div>
				  </td>
                </tr>
              </table>
            </form>
            </td>
          </tr>
<?php
} elseif ($_POST['getTicket'] == "OK") {
	include("./db_connection.php");
	
	$sql = "SELECT COUNT(*) FROM reservation WHERE RESERV_NUMBER = " . $_POST['ticket_id'];
	$result = mysql_fetch_array(mysql_query($sql));
	
	if ($result['COUNT(*)'] > 0) {
		$sql = "SELECT RESERV_NUMBER, BUS_ID, CLASS, START_STATION, FINAL_STATION, SOURCE_STATION, DESTINATION_STATION, DATE_TRAVEL, TIME_TRAVEL, PRICE, C_NAME, C_SURNAME, C_TELEPHONE " .
		   	   "FROM reservation r, trip t, trip_in_path tip, path, customer  c " .
		       "WHERE r.TRIP_ID = t.TRIP_ID " .
		       "AND r.TRIP_ID = tip.TRIP_ID " .
		       "AND r.C_NUMBER = c.C_NUMBER " .
		       "AND RESERV_NUMBER = " . $_POST['ticket_id'];

		$info = mysql_fetch_array(mysql_query($sql));
		
		mysql_close($db);
?>
		  <tr>
		  	<td align="center">
			<table width="300" border="0" cellspacing="0" cellpadding="5">
			  <tr class="table_header">
			    <td height="40" align="center">ข้อมูลการจอง</td>
			  </tr>
              <tr>
                <td>หมายเลขรหัสการจอง : <?php print $info['RESERV_NUMBER']; ?></td>
              </tr>
              <tr>
                <td>หมายเลขรถโดยสาร : <?php print $info['BUS_ID']; ?></td>
              </tr>
              <tr>
                <td>
				  สาย : <?php print station($info['START_STATION']) . "-" . station($info['FINAL_STATION']); ?>
				  &nbsp;&nbsp;
				  ระดับชั้นรถ : <?php print $info['CLASS']; ?></td>
              </tr>
              <tr>
                <td>
				  ขึ้นจากสถานี : <?php print station($info['SOURCE_STATION']); ?>
				  &nbsp;&nbsp;
				  ไปยังสถานี : <?php print station($info['DESTINATION_STATION']); ?>				</td>
              </tr>
			  <tr>
			    <td>
				  วันที่เดินทาง : <?php print date("j F Y",strtotime($info['DATE_TRAVEL'])); ?>
				  &nbsp;&nbsp;
				  เวลา : <?php print $info['TIME_TRAVEL']; ?> น.				</td>
			  </tr>
              <tr>
                <td>ราคาค่าโดยสาร : <?php print $info['PRICE']; ?> บาท </td>
              </tr>
              <tr class="table_header">
                <td height="40" align="center">ข้อมูลผู้จอง</td>
              </tr>
              <tr>
                <td>ชื่อ : <?php print $info['C_NAME']; ?>&nbsp;&nbsp;นามสกุล : <?php print $info['C_SURNAME']; ?></td>
              </tr>
              <tr>
                <td>เบอร์โทรศัพท์ : <?php print $info['C_TELEPHONE']; ?></td>
              </tr>
<?php
		include("./db_connection.php");
	
		$sql = "SELECT COUNT(*) FROM reservation " .
		       "WHERE (CHECK_UPDATE = 3 OR CHECK_UPDATE = 4) " .
		       "AND RESERV_NUMBER = " . $_POST['ticket_id'];
		$count = mysql_fetch_array(mysql_query($sql));
	
		if ($count['COUNT(*)'] == 0) {
?>
			  <tr>
			  	<td>
				  <div align="center">
			  	  <form name="form2" method="post" action="">
			  	    <input name="cancelticket" type="submit" id="cancelticket" value="ยกเลิกตั๋ว" class="button" />
			  	    <input name="ticket_id" type="hidden" id="ticket_id" value="<?php echo $ticket_id; ?>">
					&nbsp;&nbsp;
                    <input name="nocancel" type="button" id="nocancel" value="ไม่ยกเลิก" class="button" onclick="javascript:window.location.assign('index.php');">
			  	  </form>
			  	  </div>				
				</td>
			  </tr>
<?php
		} else {
?>
		      <tr>
		        <td height="60" align="center">
			      <font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif" size="4">
			        <b>การจองถูกยกเลิกไปแล้ว</b>
			      </font>
			    </td>
		      </tr>
<?php
		}
	
		mysql_close($db);
?>
            </table>
			</td>
		  </tr>
<?php
	} else {
?>
		  <tr>
		    <td height="60" align="center">
			  <font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif" size="4">
			    <b>ไม่สามารถค้นพบการจองที่ระบุได้</b>
			  </font>
			</td>
		  </tr>
<?php
	}
} elseif (isset($_POST['ticket_id'])) {
	include("./db_connection.php");
	
	$sql = "UPDATE reservation SET CHECK_UPDATE = 3 WHERE RESERV_NUMBER = " . $_POST['ticket_id'];
	if (mysql_query($sql)) {
?>
		  <tr>
		    <td height="60" align="center">
			  <font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif" size="4">
			    <b>การจองถูกยกเลิกแล้ว</b>
			  </font>
			</td>
		  </tr>
<?php
	} else {
?>
		  <tr>
		    <td height="60" align="center">
			  <font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif" size="4">
			    <b>ไม่สามารถทำการยกเลิกการจองได้</b>
			  </font>
			</td>
		  </tr>
<?php
	}
	mysql_close($db);
}
?>
        </table>
		</td>
      </tr>
    </table>
	</td>
  </tr>
</table>
</body>
</html>
