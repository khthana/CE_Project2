<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

include("_header.php");

if ($_POST['select_station'] != "confirm" && $_POST['select_car'] != "confirm") {
?>
  <tr>
    <td height="100%" align="center" valign="top"> 
	<form id=station_select_frm name="station_select_frm" method="post" action="reservation.php">
      <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="30" align="center" class="header">ระบบการจองตั๋วล่วงหน้า</td>
        </tr>
        <tr>
          <td align="center" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0">
			<tr>
              <td width="35%" height="25">&nbsp;</td>
              <td width="65%" align="left">วันที่เดินทาง&nbsp;
                <select name="date" size="1" class="jump" id="date">
                  <option value="1" selected="selected">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9">9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="17">17</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
                &nbsp;เดือน&nbsp;
                <select name="month" size="1" class="jump" id="month">
                  <option value="1" selected="selected">January</option>
                  <option value="2">February</option>
                  <option value="3">March</option>
                  <option value="4">April</option>
                  <option value="5">May</option>
                  <option value="6">June</option>
                  <option value="7">July</option>
                  <option value="8">August</option>
                  <option value="9">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
				&nbsp;พ.ศ.&nbsp;
                <select name="year" size="1" class="jump" id="year">
                  <option value="2007">2007</option>
				  <option value="2008">2008</option>
                </select>
              </td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td align="left">สถานีต้นทาง&nbsp;
                <select name="source" size="1" class="jump" id="source">
                  <?php include("_station.php"); ?>
                </select>
                </td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td align="left">สถานีปลายทาง&nbsp;
                <select name="destination" size="1" class="jump" id="destination">
                  <?php include("_station.php"); ?>
                </select>
                </td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td align="left">จำนวนที่นั่ง&nbsp;
                <input name="seat" type="text" class="rtext" id="seat" value="1" size="1" maxlength="2" />
                &nbsp;ที่
			  </td>
            </tr>
          </table>
		  </td>
        </tr>
        <tr>
          <td align="center" valign="top">
		  <table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="50%" height="30" align="right">
			  	<input name="button1" type="button" class="button" id="button1" value="ยืนยัน" onclick="checkDate()" />
				<input name="select_station" type="hidden" id="select_station" value="confirm" />
			  </td>
              <td width="50%" align="left"><input name="cancel" type="reset" class="button" id="cancel" value="ยกเลิก" /></td>
            </tr>
          </table>
		  </td>
        </tr>
      </table>
    </form>
	</td>
  </tr>
<?php
} elseif ($_POST['select_station'] == "confirm" && $_POST['select_car'] != "confirm") {
	if (!session_is_registered("ss_source")) session_register("ss_source");
	if (!session_is_registered("ss_destination")) session_register("ss_destination");
	if (!session_is_registered("ss_travel_date")) session_register("ss_travel_date");
	
	$_SESSION['ss_source'] = $_POST['source'];
	$_SESSION['ss_destination'] = $_POST['destination'];
	$_SESSION['ss_travel_date'] = $_POST['year'] . "-" . $_POST['month'] . "-" . $_POST['date'];
?>
  <tr>
    <td height="100%" align="center" valign="top">
	<form id="car_select_frm" name="car_select_frm" method="post" action="reservation.php">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="30" align="center" class="header">สายและรอบรถที่ผ่านเส้นทางระหว่าง<?php print "<font color=\"#FFCC33\"> " . station($source) . " </font>ถึง<font color=\"#FFCC33\"> " . station($destination) . " </font>ในวันที่ " . $_POST['date'] . " " . getMonth($_POST['month']) . " พ.ศ. " . $_POST['year']; ?> ที่สามารถจองล่วงหน้าได้</td>
        </tr>
        <tr>
          <td align="center">
		  <table width="100%" border="0" cellpadding="5" cellspacing="0">
            <tr align="center" valign="middle" class="table_header">
              <td width="4%" height="40">&nbsp;</td>
              <td width="11%">สายรถ</td>
              <td width="5%">ชั้น</td>
              <td width="13%">หมายเลขรถ</td>
              <td width="12%">เวลาออก<br />
                จากต้นทาง</td>
			  <td width="12%">เวลาเข้าสถานี</td>
			  <td width="12%">ถึง<?php print station($_POST['destination']); ?><br />
			    เวลา</td>
			  <td width="9%">จำนวนที่นั่ง<br />
			    ที่ว่าง</td>
              <td width="12%">ราคาต่อที่นั่ง<br />
                (บาท)</td>
				<td width="10%">หมายเหตุ</td>
            </tr>
<?php
	//Query information of buses that pass this station and go to the destination station
	include("./db_connection.php");
	
	$sql = "SELECT b.BUS_ID,SOURCE_STATION,DESTINATION_STATION,t.TRIP_ID,CLASS,PRICE,START_STATION,FINAL_STATION,d.DRIVE_NUMBER " .
	       "FROM trip t, path p, trip_in_path tip,bus b,driving_table d,schedule s " .
		   "WHERE tip.PATH_ID = p.PATH_ID " .
		   "AND tip.TRIP_ID = t.TRIP_ID " .
		   "AND p.PATH_ID = d.PATH_ID " .
		   "AND d.BUS_ID = b.BUS_ID " .
		   "AND s.DRIVE_NUMBER = d.DRIVE_NUMBER " .
		   "AND s.STATION_ID = '" . $_SESSION['ss_source'] . "' " .
		   "AND SOURCE_STATION = '" . $_SESSION['ss_source'] . "' " .
		   "AND DESTINATION_STATION = '" . $_SESSION['ss_destination'] . "' " .
		   "AND d.DAY = '" . date("l",strtotime($_SESSION['ss_travel_date'])) . "' " .
		   "ORDER BY p.PATH_ID,CLASS,TIME";
	$result = mysql_query($sql);
	//echo date("l",strtotime($_SESSION['ss_travel_date']));
		$tomorrow  = mktime(0, 0, 0, date("m",strtotime($_SESSION['ss_travel_date']))  , date("d",strtotime($_SESSION['ss_travel_date']))+1, date("Y",strtotime($_SESSION['ss_travel_date'])));
	mysql_close($db);

	//Add row loop
	$i = 0;
	while($row = mysql_fetch_array($result)) {
		//Get leaved time of the first station
		$start_time = getTime($row['BUS_ID'], $row['START_STATION'],date("l",strtotime($_SESSION['ss_travel_date'])));
		
		//Get arrived time to this station
		$source_time = getTime($row['BUS_ID'], $row['SOURCE_STATION'],date("l",strtotime($_SESSION['ss_travel_date'])));
		
		//Get arrived time to the destination station
		$destination_time = getTime($row['BUS_ID'], $row['DESTINATION_STATION'],date("l",strtotime($_SESSION['ss_travel_date'])));
		
		include("./db_connection.php");
		
		//Get amount of seat of each bus
		$sql = "SELECT SEAT_AMOUNT FROM bus WHERE BUS_ID = '" . $row['BUS_ID'] . "'";
		$seat_amount = mysql_fetch_array(mysql_query($sql));
		
		//Get amount of reserved seat of each bus
		if ($_SESSION['ss_source'] < $_SESSION['ss_destination']) {
			$sql = "SELECT COUNT(DISTINCT SEAT_NO, DATE_TRAVEL) FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $row['BUS_ID'] . "' " .
			       "AND DATE_TRAVEL = '" . $_SESSION['ss_travel_date'] . "' " .
			       "AND SOURCE_STATION < '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION > '" . $_SESSION['ss_source'] . "'";
		} else {
			$sql = "SELECT COUNT(DISTINCT SEAT_NO, DATE_TRAVEL) FROM reservation,trip " .
			   	   "WHERE reservation.TRIP_ID = trip.TRIP_ID " .
			       "AND BUS_ID = '" . $row['BUS_ID'] . "' " .
			       "AND DATE_TRAVEL = '" . $_SESSION['ss_travel_date'] . "' " .
			       "AND SOURCE_STATION > '" . $_SESSION['ss_destination'] . "' " .
		   	       "AND DESTINATION_STATION < '" . $_SESSION['ss_source'] . "'";
		}
		$reserved_seat = mysql_fetch_array(mysql_query($sql));
		
		$surplus = $seat_amount['SEAT_AMOUNT'] - $reserved_seat['COUNT(DISTINCT SEAT_NO, DATE_TRAVEL)'];
		mysql_close($db);
		
		if ($surplus >= $_POST['seat']) {
		
		//Add information into field
?>
            <tr align="center" bgcolor="<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF"; ?>" onmouseover="this.bgColor='#FA991C';" onmouseout="this.bgColor='<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF";  ?>';">
              <td height="25"><input name="bus_id" id="bus_id" type="radio" onclick="setParam('<?php print $row['TRIP_ID']; ?>','<?php print $source_time; ?>','<?php print $surplus; ?>','<?php print $row['DRIVE_NUMBER']; ?>')" value="<?php print $row['BUS_ID']; ?>" /></td>
			  <td align="center"><?php print station($row['START_STATION']) . ' - ' . station($row['FINAL_STATION']); ?></td>
			  <td><?php print $row['CLASS']; ?></td>
			  <td><?php print $row['BUS_ID']; ?></td>
			  <td><?php print $start_time; ?></td>
			  <td><?php print $source_time; ?></td>
			  <td><?php print $destination_time; ?></td>
			  <td><?php print $surplus; ?></td>
			  <td><?php print $row['PRICE']; ?></td>
			  <td><?php if ($row['OVER_NIGHT'] == 1) {
				$tomorrow  = mktime(0, 0, 0, date("m",strtotime($_SESSION['ss_travel_date']))  , date("d",strtotime($_SESSION['ss_travel_date']))+1, date("Y",strtotime($_SESSION['ss_travel_date'])));
				// print "เข้าสถานีเช้าวันที่ " .date("j",$tomorrow);
				print "ถึง".station($row['FINAL_STATION']) . "เช้าวันที่" .date("j",$tomorrow);
				  }
				  else{
					  print "-";}
					  ?>
					  </td>
			</tr>
<?php
			++$i;
		}
	}
?>
          </table>
		  </td>
        </tr>
        <tr>
          <td align="center"><table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="50%" height="25" align="right">
			    <input name="submit2" type="button" class="button" id="submit2" value="ยืนยัน" onclick="checkUnselect()" />
				<input name="select_car" type="hidden" id="select_car" value="confirm" />
				<input name="trip_id" type="hidden" id="trip_id" />
				<input name="travel_time" type="hidden" id="travel_time" />
				<input name="blank_seat" type="hidden" id="blank_seat" />
				<input name="drive_number" type="hidden" id="drive_number" />
			  </td>
              <td width="50%" align="left"><input name="cancel2" type="reset" class="button" id="cancel2" value="ยกเลิก" /></td>
            </tr>
          </table></td>
        </tr>
      </table>
    </form>
    </td>
  </tr>
<?php
} else {
	if (!session_is_registered("ss_bus_id")) session_register("ss_bus_id");
	if (!session_is_registered("ss_trip_id")) session_register("ss_trip_id");
	if (!session_is_registered("ss_travel_time")) session_register("ss_travel_time");
	
	$_SESSION['ss_bus_id'] = $_POST['bus_id'];
	$_SESSION['ss_trip_id'] = $_POST['trip_id'];
	$_SESSION['ss_travel_time'] = $_POST['travel_time'];
	
	$travel_date = date("j F Y", strtotime($_SESSION['ss_travel_date']));
		
	include("./db_connection.php");
	$sql = "SELECT START_STATION,FINAL_STATION,CLASS,SOURCE_STATION,DESTINATION_STATION,PRICE " .
		   "FROM bus, path, trip, driving_table " .
		   "WHERE bus.BUS_ID = '" . $_SESSION['ss_bus_id'] . "' " .
		   "AND trip.TRIP_ID = '" . $_SESSION['ss_trip_id'] . "' " .
		   "AND bus.BUS_ID = driving_table.BUS_ID " .
		   "AND driving_table.PATH_ID = path.PATH_ID " .
		   "AND driving_table.DRIVE_NUMBER = '" . $_POST['drive_number'] . "'";
	$busInfo = mysql_fetch_array(mysql_query($sql));
	
	//Get leaved time of the first station
	$sql = "SELECT TIME FROM schedule,driving_table " .
		   "WHERE BUS_ID = '" . $_SESSION['ss_bus_id'] . "' " .
		   "AND STATION_ID = '" . $busInfo['START_STATION'] . "' " .
		   "AND schedule.DRIVE_NUMBER = driving_table.DRIVE_NUMBER";
	$start_time = mysql_fetch_array(mysql_query($sql));
				
	//Get arrived time to the destination station
	$sql = "SELECT TIME FROM schedule,driving_table " .
		   "WHERE BUS_ID = '" . $_SESSION['ss_bus_id'] . "' " .
		   "AND STATION_ID = '" . $busInfo['DESTINATION_STATION'] . "' " .
		   "AND schedule.DRIVE_NUMBER = driving_table.DRIVE_NUMBER";
	$destination_time = mysql_fetch_array(mysql_query($sql));
	mysql_close($db);
?>
  <tr>
  	<td height="100%" align="center" valign="top">
	<form action="ticket.php" method="post" name="seat_select_frm" target="_blank" id="seat_select_frm">
	  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  		<tr>
    	  <td height="30" align="center" class="header">เลือกที่นั่ง</td>
  		</tr>
  		<tr>
    	  <td align="center"><table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td width="469" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="5">
                <tr>
                  <td align="center">
				  <table width="400" border="1" cellpadding="5" cellspacing="0" bordercolor="#6699FF" class="borderThin">
                    <tr class="table_header2">
                      <td align="center" colspan="2">ข้อมูลรถโดยสาร</td>
                    </tr>
                    <tr>
                      <td width="175" align="left">สาย&nbsp;:&nbsp;<?php print station($busInfo['START_STATION']) . "-" . station($busInfo['FINAL_STATION']); ?></td>
                      <td width="199" align="left">ชั้น&nbsp;:&nbsp;<?php print $busInfo['CLASS']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;หมายเลขรถ&nbsp;:&nbsp;<?php print $_SESSION['ss_bus_id']; ?></td>
                    </tr>
					<tr>
					  <td align="left">วันที่เดินทาง&nbsp;:&nbsp;<?php print $travel_date;?></td>
					  <td align="left">เวลาออกจากสถานีต้นทาง&nbsp;:&nbsp;<?php print $start_time['TIME'];?>&nbsp;น.</td>
					</tr>
					<tr>
                      <td align="left">เวลาเข้าสถานี&nbsp;:&nbsp;<?php print $_SESSION['ss_travel_time']; ?>&nbsp;น.</td>
                      <td align="left">ถึงสถานี<?php print station($_SESSION['ss_destination']); ?>เวลา&nbsp;:&nbsp;<?php print $destination_time['TIME'];?>&nbsp;น.</td>
					</tr>
					<tr>
                      <td align="left">จำนวนที่นั่งที่ว่าง&nbsp;:&nbsp;<?php print $_POST['blank_seat']; ?>&nbsp;ที่</td>
                      <td align="left">ราคาค่าโดยสารต่อที่นั่ง&nbsp;:&nbsp;<?php print $busInfo['PRICE']; ?>&nbsp;บาท</td>
					</tr>
                  </table>
				  </td>
                </tr>
                <tr>
                  <td align="center">
				  <table width="400" border="1" cellpadding="5" cellspacing="0" bordercolor="#6699FF" class="borderThin">
				  	<tr class="table_header2">
					  <td colspan="2" align="center">ข้อมูลผู้โดยสาร</td>
					</tr>
                    <tr>
                      <td align="center">
					    ชื่อ&nbsp;:&nbsp;
						<input name="customer_name" type="text" class="text" id="customer_name" size="20" maxlength="20" />
                        &nbsp;&nbsp;นามสกุล&nbsp;:&nbsp;
                        <input name="customer_surname" type="text" class="text" id="customer_surname" size="20" maxlength="30" />
					  </td>
                    </tr>
                    <tr>
                      <td align="center">
					    เบอร์โทรศัพท์&nbsp;:&nbsp;
					    <input name="customer_telephone" type="text" class="text" id="customer_telephone" size="10" maxlength="10" />					 
					  </td>
                    </tr>		  
                  </table>
				  <table width="307" border="0" cellpadding="5" cellspacing="0">
            		<tr>
              		  <td width="50%" height="25" align="right">
			    	   <input name="button3" type="button" class="button" id="button3" value="ยืนยัน" onclick="checkForm()" />
			    	   <input name="select_seat" type="hidden" value="confirm" />
					  </td>
              		  <td width="50%" align="left">
						<input name="cancel3" type="reset" class="button" id="cancel3" value="ยกเลิก" />					  </td>
			         </tr>
          		  </table>
				  </td>
                </tr>
              </table></td>
              <td width="470" align="center"><?php bus_plan2($_POST['bus_id'],$_POST['trip_id'],$_SESSION['ss_travel_date'],$_SESSION['ss_travel_time']); ?></td>
            </tr>
          </table></td>
  		</tr>
	  </table>
	</form>
	</td>
  </tr>
<?php
}
?>    
</table>
</body>
</html>
