<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

include("_header.php");
?>
  <tr>
    <td align="center" valign="top">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" >
      <tr>
		<?php include("_feather.php"); ?>
		<td align="center" valign="top">
		  <table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td height="30" align="center" class="header">ระบบตรวจสอบการจอง</td>
          	</tr>
<?php
if ($_POST['ok'] != "search") {
?>
			<form id="search_reservation" name="search_reservation" method="post" action="checkreservation.php">
          	<tr>
              <td align="center">
			  <table width="400" border="1" cellpadding="5" cellspacing="0" bordercolor="#6699FF" class="borderThin">
				<tr class="table_header2">
				  <td colspan="2" align="center">กรอกข้อมูลผู้จอง</td>
				</tr>
                <tr>
                  <td align="center">
					ชื่อ&nbsp;:&nbsp;
					<input name="customer_name" type="text" class="text" id="customer_name" size="20" maxlength="20" />
                    &nbsp;&nbsp;นามสกุล&nbsp;:&nbsp;
                    <input name="customer_surname" type="text" class="text" id="customer_surname" size="20" maxlength="30" />
				  </td>
                </tr>
              </table>
			  </td>
			</tr>
			<tr>
			  <td align="center">
			  <table width="300" border="0" cellspacing="0" cellpadding="5">
                <tr>
                  <td width="150" align="right">
				    <input name="search" type="button" id="search" class="button" value="ค้นหา" onclick="checkCustomerInfo()" />
				    <input name="ok" type="hidden" id="ok" value="search" />				  
				  </td>
                  <td width="150" align="left"><input name="cancel" type="reset" id="cancel" class="button" value="ยกเลิก" /></td>
                </tr>
              </table>
			  </td>
			</tr>
			</form>
<?php
} else {
	include("./db_connection.php");
	
	$sql = "SELECT COUNT(*) " .
		   "FROM reservation, customer " .
		   "WHERE reservation.C_NUMBER = customer.C_NUMBER " .
		   "AND C_NAME = '" . $_POST['customer_name'] . "' " .
		   "AND C_SURNAME = '" . $_POST['customer_surname'] . "'";
	
	$count = mysql_fetch_array(mysql_query($sql));
	
	if ($count['COUNT(*)'] > 0) {
		$sql = "SELECT DISTINCT C_TELEPHONE " .
			   "FROM reservation, customer " .
			   "WHERE reservation.C_NUMBER = customer.C_NUMBER " .
			   "AND C_NAME = '" . $_POST['customer_name'] . "' " .
		   	   "AND C_SURNAME = '" . $_POST['customer_surname'] . "'";
			   
		$customer = mysql_fetch_array(mysql_query($sql));
?>
			<tr>
			  <td>
			  <table width="398" border="0" cellspacing="0" cellpadding="10">
                <tr>
                  <td colspan="2">ค้นพบการจองจำนวน <?php print $count['COUNT(*)']; ?> รายการ</td>
                </tr>
                <tr>
				  <td width="20">&nbsp;</td>
                  <td width="338">โดยคุณ <?php print $_POST['customer_name'] . "&nbsp;&nbsp;" . $_POST['customer_surname']; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>เบอร์โทรศัพท์ <?php print $customer['C_TELEPHONE']; ?></td>
                </tr>
              </table>
			  </td>
			</tr>
			<tr>
			  <td align="center">
			  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr align="center" class="table_header">
                  <td width="8%" height="40">หมายเลขตั๋ว</td>
                  <td width="20%">สถานีขึ้น-ลง</td>
                  <td width="20%">สายรถ</td>
                  <td width="5%">ชั้น</td>
                  <td width="9%">หมายเลขรถ</td>
                  <td width="12%">วันเดินทาง</td>
                  <td width="9%">เวลา</td>
                  <td width="7%">ค่าโดยสาร<br />
                    (บาท)</td>
                  <td width="10%">สถานะ</td>
                </tr>
<?php
		$sql = "SELECT RESERV_NUMBER, BUS_ID, CLASS, START_STATION, FINAL_STATION, SOURCE_STATION, DESTINATION_STATION, DATE_TRAVEL, TIME_TRAVEL, PRICE, C_NAME, C_SURNAME, C_TELEPHONE, CHECK_UPDATE " .
		   "FROM reservation r, trip t, trip_in_path tip, path p, customer  c " .
		   "WHERE r.TRIP_ID = t.TRIP_ID " .
		   "AND r.TRIP_ID = tip.TRIP_ID " .
		   "AND p.PATH_ID = tip.PATH_ID " .
		   "AND r.C_NUMBER = c.C_NUMBER " .
		   "AND c.C_NAME = '" . $_POST['customer_name'] . "' " .
		   "AND c.C_SURNAME = '" . $_POST['customer_surname'] . "' " .
		   "ORDER BY RESERV_NUMBER DESC";
		   
		$result = mysql_query($sql);
		echo mysql_error();
		mysql_close($db);
		
		$i = 0;
		while ($row = mysql_fetch_array($result)) {
?>
                <tr align="center" bgcolor="<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF"; ?>" onmouseover="this.bgColor='#FA991C';" onmouseout="this.bgColor='<?php ($i%2 != 0) ? print "#CCCCCC" : print "#FFFFFF";?>';">
                  <td height="25" align="center"><?php print $row['RESERV_NUMBER']; ?></td>
                  <td align="center"><?php print station($row['SOURCE_STATION']) . "-" . station($row['DESTINATION_STATION']); ?></td>
                  <td align="center"><?php print station($row['START_STATION']) . "-" . station($row['FINAL_STATION']); ?></td>
                  <td align="center"><?php print $row['CLASS']; ?></td>
                  <td align="center"><?php print $row['BUS_ID']; ?></td>
                  <td align="center"><?php print date("j F Y",strtotime($row['DATE_TRAVEL'])); ?></td>
                  <td align="center"><?php print $row['TIME_TRAVEL']; ?></td>
                  <td align="center"><?php print $row['PRICE']; ?></td>
                  <td align="center"><?php if($row['CHECK_UPDATE'] < 2) echo "จอง"; else echo "ยกเลิก"; ?></td>
                </tr>
<?php
			$i++;
		}
?>
              </table>
			  </td>
			</tr>
<?php
	} else {
?>
			<tr>
			  <td height="60" align="center">
			    <font color="#FF0000" face="Geneva, Arial, Helvetica, sans-serif" size="4">
			      <b>ไม่พบการจอง</b>
				</font>
			  </td>
			</tr>
<?php
	}
}
?>
          </table>
		</td>
      </tr>
    </table>
	</td>
  </tr>
</table>
</body>
</html>