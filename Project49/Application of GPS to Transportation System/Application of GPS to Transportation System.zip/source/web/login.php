<?php
session_start();
session_unset();
session_destroy();

if (!session_is_registered("ss_UID")) session_register("ss_UID");
if (!session_is_registered("ss_Permission")) session_register("ss_Permission");
if (!session_is_registered("ss_Uname")) session_register("ss_Uname");
if (!session_is_registered("ss_Usurname")) session_register("ss_Usurname");
if (!session_is_registered("ss_This_Station")) session_register("ss_This_Station");

include("./db_connection.php");

if (isset($_POST['Submit'])) {
	$sql = "SELECT * FROM user WHERE USER_ID = '" . $_POST['uid'] . "' AND PASSWORD = PASSWORD('" . $_POST['password'] . "')";
	$userrow = mysql_query($sql);
	
	//Define session variable
	if ($userprofile = mysql_fetch_array($userrow)) {
		$_SESSION['ss_UID'] = $userprofile['USER_ID'];
		$_SESSION['ss_Permission'] = $userprofile['PERMISSION'];
		$_SESSION['ss_Uname'] = $userprofile['USER_NAME'];
		$_SESSION['ss_Usurname'] = $userprofile['USER_SURNAME'];
		$_SESSION['ss_This_Station'] = $_POST['this_station'];
	}
	
	switch($_SESSION['ss_Permission']) {
		case "admin" : header("Location:./admincontroller.php");
					 break;
		case "staff" : header("Location:./index.php");
					 break;
		default :
?>
<script language="javascript">alert("User ID or Password is incorrect")</script>
<?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>เข้าสู่ระบบ GPS เพื่อขนส่งมวลชน</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body >
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" height="65" background="../Picture/banner.gif">&nbsp;</td>
  </tr>
  <tr>
    <td height="30" class="header"><div align="center">เข้าสู่ระบบ</div></td>
  </tr>
  <tr>
  	<td height="25">&nbsp;</td>
  </tr>
  <tr>
    <td height="25">
	<table border="0" align="center" cellpadding="5" cellspacing="0">
	  <form id="form1" name="form1" method="post" action="./login.php">	
      <tr>
        <td width="50%" align="right">สถานี :</td>
        <td width="50%" align="left">
		  <select name="this_station" class="jump" id="this_station">
            <?php include("_station.php"); ?>
          </select></td>
      </tr>
      <tr>
        <td align="right">หมายเลขพนักงาน :</td>
        <td align="left"><input name="uid" type="text" class="text" id="uid" size="10" /></td>
      </tr>
      <tr>
        <td align="right">รหัสผ่าน :</td>
        <td align="left"><input name="password" type="password" class="text" id="password" size="10" /></td>
      </tr>
	  <tr>
	  	<td align="right">
		  <input name="Submit" type="submit" class="button" value="ตกลง" />
          <input name="status" type="hidden" value="login" />&nbsp;		
		</td>
        <td align="left">
		  &nbsp;
		  <input name="cancel" type="reset" class="button" id="cancel" value="ยกเลิก" /></td>
	  </tr>
 	  </form>
    </table>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
