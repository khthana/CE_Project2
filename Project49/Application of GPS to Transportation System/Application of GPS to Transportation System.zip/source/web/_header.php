<?php
	include("./function.php");
	$station_name = station($_SESSION['ss_This_Station']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="th" lang="th" dir="ltr" >
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>ระบบ GPS เพื่อขนส่งมวลชน</title>
	<link href="./style.css" rel="stylesheet" type="text/css" />
	<script src="./jscript.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="65" align="center" valign="top">
	<table width="100%" height="65" border="0" align="center" cellpadding="5" cellspacing="0" background="../Picture/banner.gif">
      <tr valign="top">
        <td height="0" align="right" valign="bottom">
		  <p><b><font color="#FFCC33">สถานี</font> : <?php echo $station_name; ?>&nbsp;&nbsp;<font color="#FFCC33">พนักงานที่ใช้ระบบ</font> : <?php echo $_SESSION['ss_Uname'] . " " .  $_SESSION['ss_Usurname']; ?></b></p>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  <tr>
    <td height="25" align="center">
	<table width="100%" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr class="nav">
        <td height="25" align="center" class="nav"><a href="./index.php">หน้าแรก</a></td>
        <td height="25" align="center" class="nav"><a href="./buyticket.php">จำหน่ายตั๋ว</a></td>
        <td height="25" align="center" class="nav"><a href="./reservation.php">จองตั๋วล่วงหน้า</a></td>
        <td height="25" align="center" class="nav"><a href="./login.php">ออกจากระบบ</a></td>
      </tr>
    </table>
	</td>
  </tr>
