<?php
session_start();

if (!session_is_registered("ss_Permission") || $_SESSION['ss_Permission'] != "staff") {
	header("Location:./login.php");
}

	include("./function.php");
	$station_name = station($_SESSION['ss_This_Station']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="th" lang="th" dir="ltr" >
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>ระบบ GPS เพื่อขนส่งมวลชน</title>
	<link href="./style.css" rel="stylesheet" type="text/css" />
	<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAgnkK1Dxg0-Jj8YDBWZCmXhSGEvUsQCnxNsP_IGn1Gs7UatBXDBTtR1bCfRlycKPuf2k13cqSUXstEw" type="text/javascript"></script>
	<script src="./jscript.js" type="text/javascript" language="javascript"></script>
	<script type="text/javascript">
    //<![CDATA[
		
	function LoadGMap() {
		if (GBrowserIsCompatible())
		{	
			this.thaiMap = new AGTSmap(13.5, 100.5);
			
			this.thaiMap.pathXml = "http://161.246.5.107/GPS/XML/path.xml";
			this.thaiMap.busXml = "http://161.246.5.107/GPS/XML/bus.xml";
			
			this.thaiMap.ShowPath();
			this.thaiMap.ShowStation();
			this.thaiMap.ShowBus();
			setInterval(this.thaiMap.MoveBusPoint, 1000, this.thaiMap);
			
			this.stations = this.thaiMap.stations;
			this.StationClick = this.thaiMap.StationClick;
			
			this.bus = this.thaiMap.bus;
			this.BusClick = this.thaiMap.BusClick;
		}
	}
    //]]>
    </script>
</head>

<body onload="loadMap = new LoadGMap();" onunload="GUnload()">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="65" align="center" valign="top">
	<table width="100%" height="65" border="0" align="center" cellpadding="5" cellspacing="0" background="../Picture/banner.gif">
      <tr valign="top">
        <td height="0" align="right" valign="bottom">
		  <p><b><font color="#FFCC33">สถานี</font> : <?php echo $station_name; ?>&nbsp;&nbsp;<font color="#FFCC33">พนักงานที่ใช้ระบบ</font> : <?php echo $_SESSION['ss_Uname'] . " " .  $_SESSION['ss_Usurname']; ?></b></p>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  <tr>
    <td height="25" align="center">
	<table width="100%" height="25" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr class="nav">
        <td height="25" align="center" class="nav"><a href="./index.php">หน้าแรก</a></td>
        <td height="25" align="center" class="nav"><a href="./buyticket.php">จำหน่ายตั๋ว</a></td>
        <td height="25" align="center" class="nav"><a href="./reservation.php">จองตั๋วล่วงหน้า</a></td>
        <td height="25" align="center" class="nav"><a href="./login.php">ออกจากระบบ</a></td>
      </tr>
    </table>
	</td>
  </tr>
  <tr>
    <td align="center" valign="top">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" >
      <tr>
		<?php include("_feather.php"); ?>
		<td align="center">
		<table width="100%" border="1" cellpadding="5" cellspacing="0" bgcolor="#E6ECEC" class="borderThin">
  		  <tr  class="table_header">
    		<td height="25" align="center" colspan="3">แผนที่ประเทศไทย</td>
		  </tr>
		  <tr>
    		<td><div id="map" style="height: 750px"></div></td>
			<td width = 150 align="left" valign="top" style="text-decoration: underline; color: #4444ff;">
			  <div id="station_side_bar"  style="overflow:auto; height:750px;"></div>
        	</td>
			<td width = 150 align="left" valign="top" style="text-decoration: underline; color: #4444ff;">
			  <div id="bus_side_bar"  style="overflow:auto; height:750px;"></div>
        	</td>
		  </tr>
		</table>
		</td>
      </tr>
    </table>
	</td>
  </tr>
</table>
</body>
</html>
