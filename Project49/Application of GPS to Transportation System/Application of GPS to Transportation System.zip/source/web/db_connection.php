<?php
		$db = @mysql_connect("localhost","root","pek" );
		mysql_select_db("gps", $db);
		mysql_query("SET NAMES 'utf8'");
?>