using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace bus_client
{
    class ReserveManager
    {
        private Thread receiverThread;
        private bool finish;
        public OutputManager outputManager;
        public IPEndPoint ServerEndPoint;
        public string busId;

        public void StartUpdate()
        {
            this.finish = false;
            this.receiverThread = new Thread(new ThreadStart(this.RunUpDate));
            this.receiverThread.Start();
        }

        public void StopUpdate()
        {
            this.finish = true;
            this.receiverThread.Abort();
        }

        private void RunUpDate()
        {
            try
            {
                while (!this.finish)
                {
                    // Create socket
                    Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    // Try connect to server
                    server.Connect(this.ServerEndPoint);

                    NetworkStream ns = new NetworkStream(server);
                    StreamReader readerStream = new StreamReader(ns, Encoding.UTF8);
                    StreamWriter writerStream = new StreamWriter(ns);

                    // Request update reservation to server
                    string message = "$CHECKRESERV," + this.busId;// +"\r\n";
                    writerStream.WriteLine(message);
                    writerStream.Flush();

                    // Set delimiter character
                    char[] delimiterChars = { ',' };

                    // Receive number of update from server
                    message = readerStream.ReadLine();

                    // if message start with "$UPDATE"
                    if (message.StartsWith("$UPDATE"))
                    {
                        string responseMessage = "$UPDATED";

                        // Split message with delimiter character
                        string[] update = message.Split(delimiterChars);

                        int reservAmount = int.Parse(update[1]);
                        int cancel = int.Parse(update[2]);
                        //string[] updated = new string[reservAmount];

                        for (int i = 0; i != reservAmount; i++)
                        {
                            // Receive update information from server
                            message = readerStream.ReadLine();

                            // if message start with "$RESERV"
                            if (message.StartsWith("$RESERV"))
                            {
                                // Split message with delimiter character
                                string[] reserv = message.Split(delimiterChars);

                                // Add new reservation to reserve list
                                this.outputManager.AddList(reserv[1], reserv[2], reserv[3], reserv[4]);

                                //updated[i] = reserv[1];
                                responseMessage += "," + reserv[1];
                            }
                        }

                        //updated = new string[cancel];
                        if (cancel > 0)
                        {
                            // Receive cancel information from server
                            message = readerStream.ReadLine();

                            // if message start with "$CANCEL"
                            if (message.StartsWith("$CANCEL"))
                            {
                                // Split message with delimiter character
                                string[] reserv = message.Split(delimiterChars);

                                for (int j = 1; j < reserv.Length; j++)
                                {
                                    // Remove reservation from reserve list
                                    this.outputManager.RemoveList(reserv[j]);

                                    //update[i] = reserv[1];
                                    responseMessage += "," + reserv[j];
                                }
                            }
                        }

                        writerStream.WriteLine(responseMessage);
                        writerStream.Flush();
                    }
                    else if (message.StartsWith("$UNUPDATE"))
                    {
                        message = "GOOD BYE\r\n";
                        writerStream.WriteLine(message);
                        writerStream.Flush();
                    }

                    // close socket
                    server.Close();

                    Thread.Sleep(3000);
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Exception: " + exp);
            }
        }
    }
}
