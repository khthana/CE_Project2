using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace bus_client
{
    class OutputManager
    {
        delegate void SetTextCallback(ref Label label, string text);
        delegate void AddLineCallback(string text);
        delegate void AddListCallback(string ticketNo, string pName, string station, string seatNo);
        delegate void RemoveListCallback(string reservNumber);

        private Thread updateThread;
        private Graphics g;
        private const int BUS_WIDTH = 280;
        private const int BUS_HEIGHT = 480;
        public Label[] sattelTextArray = new Label[12];
        public Label[] outputTextArray = new Label[13];
        public Panel busPlanPanel;
        public TextBox messageBox;
        public ListView reserveList;
        public string[] textSattelArray = new string[12];
        public string[] textOutputArray = new string[13];
        public string message = "";

        private void SetText(ref Label label, string text)
        {
            if (label.InvokeRequired)
            {
                SetTextCallback setTextDeleg = new SetTextCallback(this.SetText);
                label.Parent.Invoke(setTextDeleg, new object[] { label, text });
            }
            else
            {
                label.Text = text;
            }
        }

        private void AddLine(string text)
        {
            if (this.messageBox.InvokeRequired)
            {
                AddLineCallback addLineDeleg = new AddLineCallback(this.AddLine);
                this.messageBox.Parent.Invoke(addLineDeleg, new object[] { text });
            }
            else
            {
                text = "\r\n" + text;
                this.messageBox.AppendText(text);
            }
        }

        public void StartUpdate()
        {
            updateThread = new Thread(new ThreadStart(this.UpdateOutput));
            updateThread.Start();
        }

        public void StopUpdate()
        {
            updateThread.Abort();
        }

        public void ClearOutput()
        {
            // Clear text of output label
            for (int i = 0; i != 12; i++)
                this.SetText(ref this.outputTextArray[i], "");

            // Clear text of sattel label
            for (int i = 0; i != 12; i++)
                this.SetText(ref this.sattelTextArray[i], "");
        }

        public void UpdateOutput()
        {
            while (true)
            {
                for (int i = 0; i != 13; i++)
                {
                    // Check Update
                    if (this.outputTextArray[i].Text.CompareTo(this.textOutputArray[i]) != 0)
                        // Update text
                        this.SetText(ref this.outputTextArray[i], this.textOutputArray[i]);
                }

                for (int i = 0; i != 12; i++)
                {
                    // Check Update
                    if (this.sattelTextArray[i].Text.CompareTo(this.textSattelArray[i]) != 0)
                        // Update text
                        this.SetText(ref this.sattelTextArray[i], this.textSattelArray[i]);
                }

                // if there is new message
                if (this.message.CompareTo("") != 0)
                {
                    // Show new message
                    this.AddLine(this.message);

                    // Clear message
                    this.message = "";
                }

                Thread.Sleep(100);
            }
        }

        public void AddList(string ticketNo, string pName, string station, string seatNo)
        {
            if (this.reserveList.InvokeRequired)
            {
                AddListCallback addListDeleg = new AddListCallback(this.AddList);
                this.reserveList.Parent.Invoke(addListDeleg, new object[] { ticketNo, pName, station, seatNo });
            }
            else
            {
                try
                {
                    // Lock the ListView for updates
                    this.reserveList.BeginUpdate();

                    // Create the main ListViewItem
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = ticketNo;
                    lvi.Tag = ticketNo;

                    // Create the four ListViewSubItem
                    ListViewItem.ListViewSubItem lvsi = new ListViewItem.ListViewSubItem();
                    lvsi.Text = pName;
                    lvsi.Tag = pName;
                    // Add the sub item to the ListViewItem
                    lvi.SubItems.Add(lvsi);

                    lvsi = new ListViewItem.ListViewSubItem();
                    lvsi.Text = station;
                    lvsi.Tag = station;
                    // Add the sub item to the ListViewItem
                    lvi.SubItems.Add(lvsi);

                    lvsi = new ListViewItem.ListViewSubItem();
                    lvsi.Text = seatNo;
                    lvsi.Tag = seatNo;
                    // Add the sub item to the ListViewItem
                    lvi.SubItems.Add(lvsi);

                    // Add the ListViewItem to the Items collection of the ListVeiw
                    this.reserveList.Items.Add(lvi);

                    // be displayed
                    this.reserveList.EndUpdate();

                    this.DrawBus();
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Error: " + exp);
                }
            }
        }

        public void RemoveList(ListView lv)
        {
            lv.SelectedItems[0].Remove();
            this.DrawBus();
        }

        public void RemoveList(string reservNumber)
        {
            if (this.reserveList.InvokeRequired)
            {
                RemoveListCallback removeListDeleg = new RemoveListCallback(this.RemoveList);
                this.reserveList.Parent.Invoke(removeListDeleg, new object[] { reservNumber });
            }
            else
            {
                ListViewItem lvi = this.reserveList.FindItemWithText(reservNumber);
                if (lvi != null)
                {
                    lvi.Remove();
                    this.DrawBus();
                }
            }
        }

        public void DrawBus()
        {
            Graphics displayGraphics = this.busPlanPanel.CreateGraphics();
            Image image = new Bitmap(this.busPlanPanel.ClientRectangle.Width, this.busPlanPanel.ClientRectangle.Height);

            this.g = Graphics.FromImage(image);
            this.g.Clear(Color.White);

            int x = (this.busPlanPanel.Width - BUS_WIDTH) / 2;
            int y = (this.busPlanPanel.Height - BUS_HEIGHT) / 2;

            Size cSize = new Size(20, 20);
            Point cPoint1 = new Point(x, y);
            Point cPoint2 = new Point(BUS_WIDTH + x - 20, y);
            Point cPoint3 = new Point(x, BUS_HEIGHT + y - 20);
            Point cPoint4 = new Point(BUS_WIDTH + x - 20, BUS_HEIGHT + y - 20);
            this.g.FillEllipse(Brushes.Blue, new Rectangle(cPoint1, cSize));
            this.g.FillEllipse(Brushes.Blue, new Rectangle(cPoint2, cSize));
            this.g.FillEllipse(Brushes.Blue, new Rectangle(cPoint3, cSize));
            this.g.FillEllipse(Brushes.Blue, new Rectangle(cPoint4, cSize));

            Point rPoint1 = new Point(x + 10, y);
            Size rSize1 = new Size(BUS_WIDTH - 20, BUS_HEIGHT);
            Rectangle rec1 = new Rectangle(rPoint1, rSize1);
            Region region = new Region(rec1);

            Point rPoint2 = new Point(x, y + 10);
            Size rSize2 = new Size(BUS_WIDTH + 1, BUS_HEIGHT - 19);
            Rectangle rec2 = new Rectangle(rPoint2, rSize2);
            region.Union(rec2);

            this.g.FillRegion(Brushes.Blue, region);

            cPoint1 = new Point(x + 5, y + 5);
            cPoint2 = new Point(BUS_WIDTH + x - 25, y + 5);
            cPoint3 = new Point(x + 5, BUS_HEIGHT + y - 25);
            cPoint4 = new Point(BUS_WIDTH + x - 25, BUS_HEIGHT + y - 25);
            this.g.FillEllipse(Brushes.LightGray, new Rectangle(cPoint1, cSize));
            this.g.FillEllipse(Brushes.LightGray, new Rectangle(cPoint2, cSize));
            this.g.FillEllipse(Brushes.LightGray, new Rectangle(cPoint3, cSize));
            this.g.FillEllipse(Brushes.LightGray, new Rectangle(cPoint4, cSize));

            rPoint1 = new Point(x + 15, y + 5);
            rSize1 = new Size(BUS_WIDTH - 30, BUS_HEIGHT - 10);
            rec1 = new Rectangle(rPoint1, rSize1);
            region = new Region(rec1);

            rPoint2 = new Point(x + 5, y + 15);
            rSize2 = new Size(BUS_WIDTH - 9, BUS_HEIGHT - 29);
            rec2 = new Rectangle(rPoint2, rSize2);
            region.Union(rec2);

            this.g.FillRegion(Brushes.LightGray, region);

            Point doorPoint = new Point(x, y + 20);
            Size doorSize = new Size(5, 50);
            Rectangle door = new Rectangle(doorPoint, doorSize);
            this.g.FillRectangle(Brushes.DarkBlue, door);


            Pen pen = new Pen(Color.Black, 1);
            Point ladderPoint = new Point(doorPoint.X + doorSize.Width - doorSize.Height, doorPoint.Y);
            Size ladderSize = new Size(doorSize.Height * 2, doorSize.Height * 2);
            Rectangle ladRec = new Rectangle(ladderPoint, ladderSize);
            this.g.DrawArc(pen, ladRec, 0, -90);


            int ladderX = doorPoint.X + doorSize.Width + doorSize.Height;
            int ladderY = doorPoint.Y + doorSize.Height;
            for (int a = 0; a <= 90; a += 18)
            {
                this.g.DrawLine(pen, new Point(doorPoint.X + doorSize.Width, doorPoint.Y + doorSize.Height),
                        new Point(ladderX, ladderY));
                ladderX = Convert.ToInt32(Math.Floor((doorSize.Height) * Math.Cos(Math.PI * -a / 180.0))) + doorSize.Width + doorPoint.X;
                ladderY = Convert.ToInt32(Math.Floor((doorSize.Height) * Math.Sin(Math.PI * -a / 180.0))) + doorSize.Height + doorPoint.Y;
            }

            pen.Dispose();

            Point frontBarPoint = new Point(x + 110, y + 5);
            Size frontBarSize = new Size(BUS_WIDTH + x - 144, 10);
            Rectangle frontBar = new Rectangle(frontBarPoint, frontBarSize);
            Region region2 = new Region(frontBar);

            Point frontBarPoint2 = new Point(x + 110, y + 15);
            Size frontBarSize2 = new Size(BUS_WIDTH + x - 133, 20);
            Rectangle frontBar2 = new Rectangle(frontBarPoint2, frontBarSize2);
            region2.Union(frontBar2);

            this.g.FillRegion(Brushes.DarkGray, region2);
            this.g.FillEllipse(Brushes.DarkGray, new Rectangle(cPoint2, cSize));

            Point gearBarPoint = new Point(x + 110, y + 35);
            Size gearBarSize = new Size(60, 60);
            Rectangle gearBar = new Rectangle(gearBarPoint, gearBarSize);
            this.g.FillRectangle(Brushes.Black, gearBar);

            Point circlePoint = new Point(x + 220, y + 25);
            Size circleSize = new Size(20, 20);
            Rectangle circle = new Rectangle(circlePoint, circleSize);
            this.g.FillEllipse(Brushes.Yellow, circle);

            Point driverPoint = new Point(x + 200, y + 50);
            Size driverSize = new Size(60, 50);
            Rectangle driver = new Rectangle(driverPoint, driverSize);
            this.g.FillRectangle(Brushes.Orange, driver);

            Size seatSize = new Size(50, 30);
            Point seatPoint = new Point();
            Font numFont = new Font("Courier New", 12, FontStyle.Bold);
            Rectangle fontRect = new Rectangle();
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            int row = 122;
            for (int i = 0; i != 40; i++)
            {
                if (i % 4 == 1)
                {
                    seatPoint = new Point(x + 65, y + row);
                    fontRect = new Rectangle(seatPoint, seatSize);
                }
                else if (i % 4 == 2)
                {
                    seatPoint = new Point(x + 165, y + row);
                    fontRect = new Rectangle(seatPoint, seatSize);
                }
                else if (i % 4 == 3)
                {
                    seatPoint = new Point(x + 220, y + row);
                    fontRect = new Rectangle(seatPoint, seatSize);
                    row += 35;
                }
                else if (i % 4 == 0)
                {
                    seatPoint = new Point(x + 10, y + row);
                    fontRect = new Rectangle(seatPoint, seatSize);
                }

                Rectangle seat = new Rectangle(seatPoint, seatSize);
                this.g.FillRectangle(Brushes.LimeGreen, seat);

                for (int l = 0; l != this.reserveList.Items.Count; l++)
                {
                    if (this.reserveList.Items[l].SubItems[3].Text.CompareTo(Convert.ToString(i + 1)) == 0)
                    {
                        this.g.FillRectangle(Brushes.Red, seat);
                        break;
                    }
                }

                this.g.DrawString(Convert.ToString(i + 1), numFont, Brushes.White, fontRect, sf);
            }

            displayGraphics.DrawImage(image, this.busPlanPanel.ClientRectangle);
            image.Dispose();
        }
    }
}
