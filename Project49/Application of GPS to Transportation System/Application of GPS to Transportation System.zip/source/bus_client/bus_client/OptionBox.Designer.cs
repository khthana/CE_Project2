namespace bus_client
{
    partial class optionBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comPortBox = new System.Windows.Forms.ComboBox();
            this.comPortLabel = new System.Windows.Forms.Label();
            this.powerSaveBox = new System.Windows.Forms.CheckBox();
            this.waasEgnosBox = new System.Windows.Forms.CheckBox();
            this.timeZoneLabel = new System.Windows.Forms.Label();
            this.timeZoneBox = new System.Windows.Forms.ComboBox();
            this.hotButton = new System.Windows.Forms.Button();
            this.warmButton = new System.Windows.Forms.Button();
            this.coldButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.baudRateLabel = new System.Windows.Forms.Label();
            this.baudRateBox = new System.Windows.Forms.ComboBox();
            this.latErrorBox = new System.Windows.Forms.NumericUpDown();
            this.latErrorLabel = new System.Windows.Forms.Label();
            this.lonErrorLabel = new System.Windows.Forms.Label();
            this.lonErrorBox = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.latErrorBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lonErrorBox)).BeginInit();
            this.SuspendLayout();
            // 
            // comPortBox
            // 
            this.comPortBox.FormattingEnabled = true;
            this.comPortBox.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3"});
            this.comPortBox.Location = new System.Drawing.Point(71, 12);
            this.comPortBox.Name = "comPortBox";
            this.comPortBox.Size = new System.Drawing.Size(77, 21);
            this.comPortBox.TabIndex = 0;
            // 
            // comPortLabel
            // 
            this.comPortLabel.AutoSize = true;
            this.comPortLabel.Location = new System.Drawing.Point(12, 15);
            this.comPortLabel.Name = "comPortLabel";
            this.comPortLabel.Size = new System.Drawing.Size(53, 13);
            this.comPortLabel.TabIndex = 1;
            this.comPortLabel.Text = "COM Port";
            // 
            // powerSaveBox
            // 
            this.powerSaveBox.AutoSize = true;
            this.powerSaveBox.Location = new System.Drawing.Point(157, 14);
            this.powerSaveBox.Name = "powerSaveBox";
            this.powerSaveBox.Size = new System.Drawing.Size(85, 17);
            this.powerSaveBox.TabIndex = 2;
            this.powerSaveBox.Text = "Power Save";
            this.powerSaveBox.UseVisualStyleBackColor = true;
            // 
            // waasEgnosBox
            // 
            this.waasEgnosBox.AutoSize = true;
            this.waasEgnosBox.Location = new System.Drawing.Point(157, 41);
            this.waasEgnosBox.Name = "waasEgnosBox";
            this.waasEgnosBox.Size = new System.Drawing.Size(102, 17);
            this.waasEgnosBox.TabIndex = 3;
            this.waasEgnosBox.Text = "WAAS/EGNOS";
            this.waasEgnosBox.UseVisualStyleBackColor = true;
            // 
            // timeZoneLabel
            // 
            this.timeZoneLabel.AutoSize = true;
            this.timeZoneLabel.Location = new System.Drawing.Point(12, 98);
            this.timeZoneLabel.Name = "timeZoneLabel";
            this.timeZoneLabel.Size = new System.Drawing.Size(58, 13);
            this.timeZoneLabel.TabIndex = 4;
            this.timeZoneLabel.Text = "Time Zone";
            // 
            // timeZoneBox
            // 
            this.timeZoneBox.FormattingEnabled = true;
            this.timeZoneBox.Items.AddRange(new object[] {
            "(GMT-12:00) International Date Line West",
            "(GMT-11:00) Midway Island, Samoa",
            "(GMT-10:00) Hawaii",
            "(GMT-09:00) Alaska",
            "(GMT-08:00) Pacific Time (US & Canada); Tijuana",
            "(GMT-07:00) Arizona",
            "(GMT-07:00) Chihuahua, La Paz, Mazatlan",
            "(GMT-07:00) Mountain Time (US & Canada)",
            "(GMT-06:00) Central America",
            "(GMT-06:00) Central Time (US & Canada)",
            "(GMT-06:00) Guadalajara, Mexico City, Monterrey",
            "(GMT-06:00) Saskatchewan",
            "(GMT-05:00) Bogota, Lima, Quito",
            "(GMT-05:00) Eastern Time (US & Canada)",
            "(GMT-05:00) Indiana (East)",
            "(GMT-04:00) Atlantic Time (Canada)",
            "(GMT-04:00) Caracas, La Paz",
            "(GMT-04:00) Santiago",
            "(GMT-03:30) Newfoundland",
            "(GMT-03:00) Brasilia",
            "(GMT-03:00) Buenos Aires, Georgetown",
            "(GMT-03:00) Greenland",
            "(GMT-02:00) Mid-Atlantic",
            "(GMT-01:00) Azores",
            "(GMT-01:00) Cape Verde Is.",
            "(GMT) Casablanca, Monrovia",
            "(GMT) Greenwich Mean Time : Dublin, Edinburgh, Lisbon, London",
            "(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna",
            "(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague",
            "(GMT+01:00) Brussels, Copenhagen, Madrid, Paris",
            "(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb",
            "(GMT+01:00) West Central Africa",
            "(GMT+02:00) Athens, Beirut, Istanbul, Minsk",
            "(GMT+02:00) Bucharest",
            "(GMT+02:00) Cairo",
            "(GMT+02:00) Harare, Pretoria",
            "(GMT+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius",
            "(GMT+02:00) Jerusalem",
            "(GMT+03:00) Baghdad",
            "(GMT+03:00) Kuwait, Riyadh",
            "(GMT+03:00) Moscow, St. Petersburg, Volgograd",
            "(GMT+03:00) Nairobi",
            "(GMT+03:30) Tehran",
            "(GMT+04:00) Abu Dhabi, Muscat",
            "(GMT+04:00) Baku, Tbilisi, Yerevan",
            "(GMT+04:30) Kabul",
            "(GMT+05:00) Ekaterinburg",
            "(GMT+05:00) Islamabad, Karachi, Tashkent",
            "(GMT+05:30) Chennai, Kalkata, Mumbai, New Delhi",
            "(GMT+05:45) Kathmandu",
            "(GMT+06:00) Almaty, Novosibisk",
            "(GMT+06:00) Astana, Dhaka",
            "(GMT+06:00) Sri Jayawardenepura",
            "(GMT+06:30) Rangoon",
            "(GMT+07:00) Bangkok, Hanoi, Jakarta",
            "(GMT+07:00) Krasnoyarsk",
            "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
            "(GMT+08:00) Irkutsk, Ulaan Bataar",
            "(GMT+08:00) Kuala Lumpur, Singapore",
            "(GMT+08:00) Perth",
            "(GMT+08:00) Taipei",
            "(GMT+09:00) Osaka, Sapporo, Tokyo",
            "(GMT+09:00) Seoul",
            "(GMT+09:00) Yakutsk",
            "(GMT+09:30) Adelaide",
            "(GMT+09:30) Darwin",
            "(GMT+10:00) Brisbane",
            "(GMT+10:00) Canberra, Melbourne, Sydney",
            "(GMT+10:00) Guam, Port Moresby",
            "(GMT+10:00) Hobart",
            "(GMT+10:00) Vladivostok",
            "(GMT+11:00) Magadan, Solomon Is., New Caledonia",
            "(GMT+12:00) Auckland, Wellington",
            "(GMT+12:00) Fiji, Kamchatka, Marshall Is.",
            "(GMT+13:00) Nuku\'alofa"});
            this.timeZoneBox.Location = new System.Drawing.Point(76, 95);
            this.timeZoneBox.Name = "timeZoneBox";
            this.timeZoneBox.Size = new System.Drawing.Size(352, 21);
            this.timeZoneBox.TabIndex = 5;
            // 
            // hotButton
            // 
            this.hotButton.Location = new System.Drawing.Point(54, 66);
            this.hotButton.Name = "hotButton";
            this.hotButton.Size = new System.Drawing.Size(74, 23);
            this.hotButton.TabIndex = 6;
            this.hotButton.Text = "Hot Start";
            this.hotButton.UseVisualStyleBackColor = true;
            this.hotButton.Click += new System.EventHandler(this.hotButton_Click);
            // 
            // warmButton
            // 
            this.warmButton.Location = new System.Drawing.Point(316, 66);
            this.warmButton.Name = "warmButton";
            this.warmButton.Size = new System.Drawing.Size(74, 23);
            this.warmButton.TabIndex = 7;
            this.warmButton.Text = "Warm Start";
            this.warmButton.UseVisualStyleBackColor = true;
            this.warmButton.Click += new System.EventHandler(this.warmButton_Click);
            // 
            // coldButton
            // 
            this.coldButton.Location = new System.Drawing.Point(184, 66);
            this.coldButton.Name = "coldButton";
            this.coldButton.Size = new System.Drawing.Size(75, 23);
            this.coldButton.TabIndex = 8;
            this.coldButton.Text = "Cold Start";
            this.coldButton.UseVisualStyleBackColor = true;
            this.coldButton.Click += new System.EventHandler(this.coldButton_Click);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(118, 122);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 9;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(248, 122);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 10;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // baudRateLabel
            // 
            this.baudRateLabel.AutoSize = true;
            this.baudRateLabel.Location = new System.Drawing.Point(12, 42);
            this.baudRateLabel.Name = "baudRateLabel";
            this.baudRateLabel.Size = new System.Drawing.Size(50, 13);
            this.baudRateLabel.TabIndex = 11;
            this.baudRateLabel.Text = "Baudrate";
            // 
            // baudRateBox
            // 
            this.baudRateBox.FormattingEnabled = true;
            this.baudRateBox.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.baudRateBox.Location = new System.Drawing.Point(71, 39);
            this.baudRateBox.Name = "baudRateBox";
            this.baudRateBox.Size = new System.Drawing.Size(77, 21);
            this.baudRateBox.TabIndex = 12;
            // 
            // latErrorBox
            // 
            this.latErrorBox.DecimalPlaces = 6;
            this.latErrorBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            393216});
            this.latErrorBox.Location = new System.Drawing.Point(347, 13);
            this.latErrorBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.latErrorBox.Name = "latErrorBox";
            this.latErrorBox.Size = new System.Drawing.Size(81, 20);
            this.latErrorBox.TabIndex = 13;
            this.latErrorBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // latErrorLabel
            // 
            this.latErrorLabel.AutoSize = true;
            this.latErrorLabel.Location = new System.Drawing.Point(262, 15);
            this.latErrorLabel.Name = "latErrorLabel";
            this.latErrorLabel.Size = new System.Drawing.Size(70, 13);
            this.latErrorLabel.TabIndex = 14;
            this.latErrorLabel.Text = "Latitude Error";
            // 
            // lonErrorLabel
            // 
            this.lonErrorLabel.AutoSize = true;
            this.lonErrorLabel.Location = new System.Drawing.Point(262, 42);
            this.lonErrorLabel.Name = "lonErrorLabel";
            this.lonErrorLabel.Size = new System.Drawing.Size(79, 13);
            this.lonErrorLabel.TabIndex = 15;
            this.lonErrorLabel.Text = "Longitude Error";
            // 
            // lonErrorBox
            // 
            this.lonErrorBox.DecimalPlaces = 6;
            this.lonErrorBox.Increment = new decimal(new int[] {
            1,
            0,
            0,
            393216});
            this.lonErrorBox.Location = new System.Drawing.Point(347, 40);
            this.lonErrorBox.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.lonErrorBox.Name = "lonErrorBox";
            this.lonErrorBox.Size = new System.Drawing.Size(81, 20);
            this.lonErrorBox.TabIndex = 16;
            this.lonErrorBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // optionBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 152);
            this.ControlBox = false;
            this.Controls.Add(this.lonErrorBox);
            this.Controls.Add(this.lonErrorLabel);
            this.Controls.Add(this.latErrorLabel);
            this.Controls.Add(this.latErrorBox);
            this.Controls.Add(this.baudRateBox);
            this.Controls.Add(this.baudRateLabel);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.coldButton);
            this.Controls.Add(this.warmButton);
            this.Controls.Add(this.hotButton);
            this.Controls.Add(this.timeZoneBox);
            this.Controls.Add(this.timeZoneLabel);
            this.Controls.Add(this.waasEgnosBox);
            this.Controls.Add(this.powerSaveBox);
            this.Controls.Add(this.comPortLabel);
            this.Controls.Add(this.comPortBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "optionBox";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Option";
            this.Load += new System.EventHandler(this.optionBox_Load);
            ((System.ComponentModel.ISupportInitialize)(this.latErrorBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lonErrorBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comPortBox;
        private System.Windows.Forms.Label comPortLabel;
        private System.Windows.Forms.CheckBox powerSaveBox;
        private System.Windows.Forms.CheckBox waasEgnosBox;
        private System.Windows.Forms.Label timeZoneLabel;
        private System.Windows.Forms.ComboBox timeZoneBox;
        private System.Windows.Forms.Button hotButton;
        private System.Windows.Forms.Button warmButton;
        private System.Windows.Forms.Button coldButton;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Label baudRateLabel;
        private System.Windows.Forms.ComboBox baudRateBox;
        private System.Windows.Forms.NumericUpDown latErrorBox;
        private System.Windows.Forms.Label latErrorLabel;
        private System.Windows.Forms.Label lonErrorLabel;
        private System.Windows.Forms.NumericUpDown lonErrorBox;
    }
}