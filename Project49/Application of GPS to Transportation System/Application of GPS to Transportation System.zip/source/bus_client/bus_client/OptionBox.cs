using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace bus_client
{
    public partial class optionBox : Form
    {
        private string comPort, startMode, oldStartMode;
        private bool powerSave, waasEgnos, portIsOpen;
        private int timeZoneIndex, baudRate;
        private double timeZone, latError, lonError;

        public optionBox()
        {
            InitializeComponent();
            this.comPort = "COM2";
            this.baudRate = 4800;
            this.timeZone = 7;
            this.timeZoneBox.SelectedIndex = 54;
            this.latError = 0.255633;
            this.lonError = 0.31012;
        }

        private void optionBox_Load(object sender, EventArgs e)
        {
            this.comPortBox.Text = this.comPort;
            this.baudRateBox.Text = System.Convert.ToString(this.baudRate);
            this.powerSaveBox.Checked = this.powerSave;
            this.waasEgnosBox.Checked = this.waasEgnos;
            this.latErrorBox.Value = Convert.ToDecimal(this.latError);
            this.lonErrorBox.Value = Convert.ToDecimal(this.lonError);
            this.timeZoneIndex = this.timeZoneBox.SelectedIndex;
            this.oldStartMode = this.startMode;

            this.powerSaveBox.Enabled = this.portIsOpen;
            this.waasEgnosBox.Enabled = this.portIsOpen;
            this.hotButton.Enabled = this.portIsOpen;
            this.warmButton.Enabled = this.portIsOpen;
            this.coldButton.Enabled = this.portIsOpen;

            this.comPortBox.Enabled = !this.portIsOpen;
            this.baudRateBox.Enabled = !this.portIsOpen;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.comPort = this.comPortBox.Text;
            this.baudRate = int.Parse(this.baudRateBox.Text);
            this.latError = Convert.ToDouble(this.latErrorBox.Value);
            this.lonError = Convert.ToDouble(this.lonErrorBox.Value);
            this.powerSave = this.powerSaveBox.Checked;
            this.waasEgnos = this.waasEgnosBox.Checked;
            this.timeZone = this.timeIndexToTimeZone(this.timeZoneBox.SelectedIndex);
            this.Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.timeZone = this.timeIndexToTimeZone(this.timeZoneIndex);
            this.timeZoneBox.SelectedIndex = this.timeZoneIndex;
            this.startMode = this.oldStartMode;
            this.Close();
        }

        private void hotButton_Click(object sender, EventArgs e)
        {
            this.startMode = "$PSRF104,0,0,0,96000,237759,922,12,1*2B\r\n";
        }

        private void warmButton_Click(object sender, EventArgs e)
        {
            this.startMode = "$PSRF104,0,0,0,96000,237759,922,12,2*28\r\n";
        }

        private void coldButton_Click(object sender, EventArgs e)
        {
            this.startMode = "$PSRF104,0,0,0,96000,237759,922,12,2*2E\r\n";
        }

        // Convert Index of Time Zone ComboBox to Time Zone Value
        private double timeIndexToTimeZone(int index)
        {
            double timezone = 0;

            switch (index)
            {
                case 0: timezone = -12; break;
                case 1: timezone = -11; break;
                case 2: timezone = -10; break;
                case 3: timezone = -9; break;
                case 4: timezone = -8; break;
                case 5:
                case 6:
                case 7: timezone = -7; break;
                case 8:
                case 9:
                case 10:
                case 11: timezone = -6; break;
                case 12:
                case 13:
                case 14: timezone = -5; break;
                case 15:
                case 16:
                case 17: timezone = -4; break;
                case 18: timezone = -3.30; break;
                case 19:
                case 20:
                case 21: timezone = -3; break;
                case 22: timezone = -2; break;
                case 23:
                case 24: timezone = -1; break;
                case 25:
                case 26: timezone = 0; break;
                case 27:
                case 28:
                case 29:
                case 30:
                case 31: timezone = 1; break;
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37: timezone = 2; break;
                case 38:
                case 39:
                case 40:
                case 41: timezone = 3; break;
                case 42: timezone = 3.30; break;
                case 43:
                case 44: timezone = 4; break;
                case 45: timezone = 4.30; break;
                case 46:
                case 47: timezone = 5; break;
                case 48: timezone = 5.30; break;
                case 49: timezone = 5.45; break;
                case 50:
                case 51:
                case 52: timezone = 6; break;
                case 53: timezone = 6.30; break;
                case 54:
                case 55: timezone = 7; break;
                case 56:
                case 57:
                case 58:
                case 59:
                case 60: timezone = 8; break;
                case 61:
                case 62:
                case 63: timezone = 9; break;
                case 64: timezone = 9.30; break;
                case 65:
                case 66:
                case 67:
                case 68:
                case 69: timezone = 10; break;
                case 70: timezone = 11; break;
                case 71:
                case 72: timezone = 12; break;
                case 73: timezone = 13; break;
            }

            return timezone;
        }

        public string getComPort()
        {
            return this.comPort;
        }

        public int getBaudRate()
        {
            return this.baudRate;
        }
        
        public double getTimeZone()
        {
            return this.timeZone;
        }
        
        public bool getPowerSave()
        {
            return this.powerSave;
        }

        public bool getWaasEgnos()
        {
            return this.waasEgnos;
        }

        public string getStartMode()
        {
            return this.startMode;
        }

        public double getLatError()
        {
            return this.latError;
        }

        public double getLonError()
        {
            return this.lonError;
        }

        public void setPortIsOpen(bool portStatus)
        {
            this.portIsOpen = portStatus;
        }
    }
}