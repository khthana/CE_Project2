using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace bus_client
{
    public partial class setInfoBox : Form
    {
        private string busId;
        private string classBus;
        private string path;
        private string dName, hName;
        private int totalSeat;

        public setInfoBox()
        {
            InitializeComponent();
        }

        private void setInfoBox_Load(object sender, EventArgs e)
        {
            this.busIdBox.Text = this.busId;
            this.classBox.Text = this.classBus;
            this.dNameBox.Text = this.dName;
            this.hNameBox.Text = this.hName;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.busId = this.busIdBox.Text;
            this.classBus = this.classBox.Text;
            this.dName = this.dNameBox.Text;
            this.hName = this.hNameBox.Text;
            this.path = this.busNoToPath(this.busId);
            this.totalSeat = this.classToSeat(this.classBus);

            this.Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.path = this.busNoToPath(this.busId);
            this.totalSeat = this.classToSeat(this.classBus);
            this.Close();
        }

        //Convert Bus ID to Path
        private string busNoToPath(string busNo)
        {
            string pathStr = "";
            int pathNum = 0;
            if (busNo != "")
                pathNum = int.Parse(busNo.Substring(0,busNo.IndexOf('-')));

            switch (pathNum)
            {
                case 13:
                    pathStr = "��ا෾�-��§����";
                    break;
            }

            return pathStr;
        }

        //Convert Bus Class to Sum of Seat
        private int classToSeat(string classParam)
        {
            int seat = 0;

            if (classParam.CompareTo("A") == 0)
                seat = 24;
            else if (classParam.CompareTo("B") == 0)
                seat = 32;
            else if (classParam.CompareTo("C") == 0)
                seat = 40;
            else if (classParam.CompareTo("D") == 0)
                seat = 60;

            return seat;
        }

        public string getBusId()
        {
            return this.busId;
        }

        public string getClass()
        {
            return this.classBus;
        }

        public string getPath()
        {
            return this.path;
        }

        public string getDriverName()
        {
            return this.dName;
        }

        public string getHostessName()
        {
            return this.hName;
        }

        public int getTotalSeat()
        {
            return this.totalSeat;
        }
    }
}