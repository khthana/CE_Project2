using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace bus_client
{
    class LatLonSender
    {
        private Thread senderThread;
        private bool finish;
        public IPEndPoint ServerEndPoint;
        public string busId;
        public double lat;
        public double lon;

        public void StartSender()
        {
            this.finish = false;
            this.senderThread = new Thread(new ThreadStart(this.RunSender));
            this.senderThread.Start();
        }

        public void StopSender()
        {
            this.finish = true;
            this.senderThread.Abort();
        }

        private void RunSender()
        {
            try
            {
                // create socket
                UdpClient server = new UdpClient();
                server.Connect(this.ServerEndPoint);

                // send start message
                string message = "$START,Start sending latitude & longitude from bus no. " + this.busId;
                byte[] data = Encoding.ASCII.GetBytes(message);
                server.Send(data, data.Length);

                while (!this.finish)
                {
                    message = "$LATLON," + this.busId + "," + System.Convert.ToString(this.lat) + "," + System.Convert.ToString(this.lon);
                    data = Encoding.ASCII.GetBytes(message);
                    server.Send(data, data.Length);

                    Thread.Sleep(500);
                }

                // send end message
                message = "$END,Finish sending latitude & longitude from bus no. " + this.busId;
                data = Encoding.ASCII.GetBytes(message);
                server.Send(data, data.Length);

                // Close socket
                server.Close();
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }
    }
}
