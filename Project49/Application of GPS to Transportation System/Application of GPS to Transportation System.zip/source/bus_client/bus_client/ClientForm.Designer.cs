namespace bus_client
{
    partial class clientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuBar = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectGPSItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectGPSItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectServerItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectServerItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setInfoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.busPlanPanel = new System.Windows.Forms.Panel();
            this.reserveList = new System.Windows.Forms.ListView();
            this.ticketNo = new System.Windows.Forms.ColumnHeader();
            this.passenger = new System.Windows.Forms.ColumnHeader();
            this.station = new System.Windows.Forms.ColumnHeader();
            this.seatNo = new System.Windows.Forms.ColumnHeader();
            this.busInfoPanel = new System.Windows.Forms.Panel();
            this.hNameText = new System.Windows.Forms.Label();
            this.dNameText = new System.Windows.Forms.Label();
            this.totalSeatText = new System.Windows.Forms.Label();
            this.classText = new System.Windows.Forms.Label();
            this.pathText = new System.Windows.Forms.Label();
            this.busIdText = new System.Windows.Forms.Label();
            this.totalSeatLabel = new System.Windows.Forms.Label();
            this.classLabel = new System.Windows.Forms.Label();
            this.hNameLabel = new System.Windows.Forms.Label();
            this.dNameLabel = new System.Windows.Forms.Label();
            this.pathLabel = new System.Windows.Forms.Label();
            this.busIdLabel = new System.Windows.Forms.Label();
            this.gpsInfoPanel = new System.Windows.Forms.Panel();
            this.s11 = new System.Windows.Forms.Label();
            this.s10 = new System.Windows.Forms.Label();
            this.s9 = new System.Windows.Forms.Label();
            this.s8 = new System.Windows.Forms.Label();
            this.s7 = new System.Windows.Forms.Label();
            this.s6 = new System.Windows.Forms.Label();
            this.s5 = new System.Windows.Forms.Label();
            this.s4 = new System.Windows.Forms.Label();
            this.s3 = new System.Windows.Forms.Label();
            this.s2 = new System.Windows.Forms.Label();
            this.s1 = new System.Windows.Forms.Label();
            this.s0 = new System.Windows.Forms.Label();
            this.messageBox = new System.Windows.Forms.TextBox();
            this.satillitesViewText = new System.Windows.Forms.Label();
            this.directionText = new System.Windows.Forms.Label();
            this.speedText = new System.Windows.Forms.Label();
            this.lonText = new System.Windows.Forms.Label();
            this.latText = new System.Windows.Forms.Label();
            this.timeText = new System.Windows.Forms.Label();
            this.dateText = new System.Windows.Forms.Label();
            this.satelliteIdLabel = new System.Windows.Forms.Label();
            this.satelliteViewLabel = new System.Windows.Forms.Label();
            this.directLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.lonLabel = new System.Windows.Forms.Label();
            this.latLabel = new System.Windows.Forms.Label();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.menuBar.SuspendLayout();
            this.busInfoPanel.SuspendLayout();
            this.gpsInfoPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuBar
            // 
            this.menuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem,
            this.toolsMenuItem,
            this.helpMenuItem});
            this.menuBar.Location = new System.Drawing.Point(0, 0);
            this.menuBar.Name = "menuBar";
            this.menuBar.Size = new System.Drawing.Size(792, 24);
            this.menuBar.TabIndex = 0;
            this.menuBar.Text = "Menu Bar";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitMenuItem});
            this.fileMenuItem.Name = "fileMenuItem";
            this.fileMenuItem.Size = new System.Drawing.Size(38, 20);
            this.fileMenuItem.Text = "File";
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Name = "exitMenuItem";
            this.exitMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitMenuItem.Size = new System.Drawing.Size(141, 22);
            this.exitMenuItem.Text = "Exit";
            this.exitMenuItem.Click += new System.EventHandler(this.exitMenuItem_Click);
            // 
            // toolsMenuItem
            // 
            this.toolsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectGPSItem,
            this.disconnectGPSItem,
            this.connectServerItem,
            this.disconnectServerItem,
            this.setInfoMenuItem,
            this.optionToolStripMenuItem});
            this.toolsMenuItem.Name = "toolsMenuItem";
            this.toolsMenuItem.Size = new System.Drawing.Size(50, 20);
            this.toolsMenuItem.Text = "Tools";
            // 
            // connectGPSItem
            // 
            this.connectGPSItem.Name = "connectGPSItem";
            this.connectGPSItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.connectGPSItem.Size = new System.Drawing.Size(251, 22);
            this.connectGPSItem.Text = "Connect GPS";
            this.connectGPSItem.Click += new System.EventHandler(this.connectGPSItem_Click);
            // 
            // disconnectGPSItem
            // 
            this.disconnectGPSItem.Enabled = false;
            this.disconnectGPSItem.Name = "disconnectGPSItem";
            this.disconnectGPSItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.disconnectGPSItem.Size = new System.Drawing.Size(251, 22);
            this.disconnectGPSItem.Text = "Disconnect GPS";
            this.disconnectGPSItem.Click += new System.EventHandler(this.disconnectGPSItem_Click);
            // 
            // connectServerItem
            // 
            this.connectServerItem.Name = "connectServerItem";
            this.connectServerItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.C)));
            this.connectServerItem.Size = new System.Drawing.Size(251, 22);
            this.connectServerItem.Text = "Connect Server";
            this.connectServerItem.Click += new System.EventHandler(this.connectServerItem_Click);
            // 
            // disconnectServerItem
            // 
            this.disconnectServerItem.Enabled = false;
            this.disconnectServerItem.Name = "disconnectServerItem";
            this.disconnectServerItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.D)));
            this.disconnectServerItem.Size = new System.Drawing.Size(251, 22);
            this.disconnectServerItem.Text = "Disconnect Server";
            this.disconnectServerItem.Click += new System.EventHandler(this.disconnectServerItem_Click);
            // 
            // setInfoMenuItem
            // 
            this.setInfoMenuItem.Name = "setInfoMenuItem";
            this.setInfoMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.setInfoMenuItem.Size = new System.Drawing.Size(251, 22);
            this.setInfoMenuItem.Text = "Set Info";
            this.setInfoMenuItem.Click += new System.EventHandler(this.setInfoMenuItem_Click);
            // 
            // optionToolStripMenuItem
            // 
            this.optionToolStripMenuItem.Name = "optionToolStripMenuItem";
            this.optionToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.optionToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.optionToolStripMenuItem.Text = "Option";
            this.optionToolStripMenuItem.Click += new System.EventHandler(this.optionToolStripMenuItem_Click);
            // 
            // helpMenuItem
            // 
            this.helpMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutMenuItem});
            this.helpMenuItem.Name = "helpMenuItem";
            this.helpMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpMenuItem.Text = "Help";
            // 
            // aboutMenuItem
            // 
            this.aboutMenuItem.Name = "aboutMenuItem";
            this.aboutMenuItem.Size = new System.Drawing.Size(109, 22);
            this.aboutMenuItem.Text = "About";
            this.aboutMenuItem.Click += new System.EventHandler(this.aboutMenuItem_Click);
            // 
            // statusBar
            // 
            this.statusBar.Location = new System.Drawing.Point(0, 548);
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(792, 22);
            this.statusBar.TabIndex = 1;
            this.statusBar.Text = "Status Bar";
            // 
            // busPlanPanel
            // 
            this.busPlanPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.busPlanPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.busPlanPanel.Location = new System.Drawing.Point(470, 27);
            this.busPlanPanel.Name = "busPlanPanel";
            this.busPlanPanel.Size = new System.Drawing.Size(318, 518);
            this.busPlanPanel.TabIndex = 2;
            // 
            // reserveList
            // 
            this.reserveList.Activation = System.Windows.Forms.ItemActivation.TwoClick;
            this.reserveList.CheckBoxes = true;
            this.reserveList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ticketNo,
            this.passenger,
            this.station,
            this.seatNo});
            this.reserveList.FullRowSelect = true;
            this.reserveList.Location = new System.Drawing.Point(3, 340);
            this.reserveList.Name = "reserveList";
            this.reserveList.Size = new System.Drawing.Size(462, 205);
            this.reserveList.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.reserveList.TabIndex = 3;
            this.reserveList.UseCompatibleStateImageBehavior = false;
            this.reserveList.View = System.Windows.Forms.View.Details;
            this.reserveList.ItemActivate += new System.EventHandler(this.reserveList_ItemActivate);
            // 
            // ticketNo
            // 
            this.ticketNo.Text = "Ticket No.";
            this.ticketNo.Width = 67;
            // 
            // passenger
            // 
            this.passenger.Text = "Passenger Name";
            this.passenger.Width = 216;
            // 
            // station
            // 
            this.station.Text = "Station";
            this.station.Width = 115;
            // 
            // seatNo
            // 
            this.seatNo.Text = "Seat No.";
            // 
            // busInfoPanel
            // 
            this.busInfoPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.busInfoPanel.Controls.Add(this.hNameText);
            this.busInfoPanel.Controls.Add(this.dNameText);
            this.busInfoPanel.Controls.Add(this.totalSeatText);
            this.busInfoPanel.Controls.Add(this.classText);
            this.busInfoPanel.Controls.Add(this.pathText);
            this.busInfoPanel.Controls.Add(this.busIdText);
            this.busInfoPanel.Controls.Add(this.totalSeatLabel);
            this.busInfoPanel.Controls.Add(this.classLabel);
            this.busInfoPanel.Controls.Add(this.hNameLabel);
            this.busInfoPanel.Controls.Add(this.dNameLabel);
            this.busInfoPanel.Controls.Add(this.pathLabel);
            this.busInfoPanel.Controls.Add(this.busIdLabel);
            this.busInfoPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.busInfoPanel.Location = new System.Drawing.Point(3, 27);
            this.busInfoPanel.Name = "busInfoPanel";
            this.busInfoPanel.Size = new System.Drawing.Size(462, 101);
            this.busInfoPanel.TabIndex = 4;
            // 
            // hNameText
            // 
            this.hNameText.AutoSize = true;
            this.hNameText.Location = new System.Drawing.Point(102, 80);
            this.hNameText.Name = "hNameText";
            this.hNameText.Size = new System.Drawing.Size(71, 13);
            this.hNameText.TabIndex = 11;
            this.hNameText.Text = "hNameText";
            // 
            // dNameText
            // 
            this.dNameText.AutoSize = true;
            this.dNameText.Location = new System.Drawing.Point(91, 56);
            this.dNameText.Name = "dNameText";
            this.dNameText.Size = new System.Drawing.Size(71, 13);
            this.dNameText.TabIndex = 10;
            this.dNameText.Text = "dNameText";
            // 
            // totalSeatText
            // 
            this.totalSeatText.AutoSize = true;
            this.totalSeatText.Location = new System.Drawing.Point(280, 32);
            this.totalSeatText.Name = "totalSeatText";
            this.totalSeatText.Size = new System.Drawing.Size(83, 13);
            this.totalSeatText.TabIndex = 9;
            this.totalSeatText.Text = "totalSeatText";
            // 
            // classText
            // 
            this.classText.AutoSize = true;
            this.classText.Location = new System.Drawing.Point(51, 32);
            this.classText.Name = "classText";
            this.classText.Size = new System.Drawing.Size(61, 13);
            this.classText.TabIndex = 8;
            this.classText.Text = "classText";
            // 
            // pathText
            // 
            this.pathText.AutoSize = true;
            this.pathText.Location = new System.Drawing.Point(247, 8);
            this.pathText.Name = "pathText";
            this.pathText.Size = new System.Drawing.Size(57, 13);
            this.pathText.TabIndex = 7;
            this.pathText.Text = "pathText";
            // 
            // busIdText
            // 
            this.busIdText.AutoSize = true;
            this.busIdText.Location = new System.Drawing.Point(66, 8);
            this.busIdText.Name = "busIdText";
            this.busIdText.Size = new System.Drawing.Size(63, 13);
            this.busIdText.TabIndex = 6;
            this.busIdText.Text = "busIdText";
            // 
            // totalSeatLabel
            // 
            this.totalSeatLabel.AutoSize = true;
            this.totalSeatLabel.Location = new System.Drawing.Point(208, 32);
            this.totalSeatLabel.Name = "totalSeatLabel";
            this.totalSeatLabel.Size = new System.Drawing.Size(66, 13);
            this.totalSeatLabel.TabIndex = 5;
            this.totalSeatLabel.Text = "Total Seat";
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(8, 32);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(37, 13);
            this.classLabel.TabIndex = 4;
            this.classLabel.Text = "Class";
            // 
            // hNameLabel
            // 
            this.hNameLabel.AutoSize = true;
            this.hNameLabel.Location = new System.Drawing.Point(8, 80);
            this.hNameLabel.Name = "hNameLabel";
            this.hNameLabel.Size = new System.Drawing.Size(88, 13);
            this.hNameLabel.TabIndex = 3;
            this.hNameLabel.Text = "Hostess Name";
            // 
            // dNameLabel
            // 
            this.dNameLabel.AutoSize = true;
            this.dNameLabel.Location = new System.Drawing.Point(8, 56);
            this.dNameLabel.Name = "dNameLabel";
            this.dNameLabel.Size = new System.Drawing.Size(77, 13);
            this.dNameLabel.TabIndex = 2;
            this.dNameLabel.Text = "Driver Name";
            // 
            // pathLabel
            // 
            this.pathLabel.AutoSize = true;
            this.pathLabel.Location = new System.Drawing.Point(208, 8);
            this.pathLabel.Name = "pathLabel";
            this.pathLabel.Size = new System.Drawing.Size(33, 13);
            this.pathLabel.TabIndex = 1;
            this.pathLabel.Text = "Path";
            // 
            // busIdLabel
            // 
            this.busIdLabel.AutoSize = true;
            this.busIdLabel.Location = new System.Drawing.Point(8, 8);
            this.busIdLabel.Name = "busIdLabel";
            this.busIdLabel.Size = new System.Drawing.Size(52, 13);
            this.busIdLabel.TabIndex = 0;
            this.busIdLabel.Text = "Bus No.";
            // 
            // gpsInfoPanel
            // 
            this.gpsInfoPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gpsInfoPanel.Controls.Add(this.s11);
            this.gpsInfoPanel.Controls.Add(this.s10);
            this.gpsInfoPanel.Controls.Add(this.s9);
            this.gpsInfoPanel.Controls.Add(this.s8);
            this.gpsInfoPanel.Controls.Add(this.s7);
            this.gpsInfoPanel.Controls.Add(this.s6);
            this.gpsInfoPanel.Controls.Add(this.s5);
            this.gpsInfoPanel.Controls.Add(this.s4);
            this.gpsInfoPanel.Controls.Add(this.s3);
            this.gpsInfoPanel.Controls.Add(this.s2);
            this.gpsInfoPanel.Controls.Add(this.s1);
            this.gpsInfoPanel.Controls.Add(this.s0);
            this.gpsInfoPanel.Controls.Add(this.messageBox);
            this.gpsInfoPanel.Controls.Add(this.satillitesViewText);
            this.gpsInfoPanel.Controls.Add(this.directionText);
            this.gpsInfoPanel.Controls.Add(this.speedText);
            this.gpsInfoPanel.Controls.Add(this.lonText);
            this.gpsInfoPanel.Controls.Add(this.latText);
            this.gpsInfoPanel.Controls.Add(this.timeText);
            this.gpsInfoPanel.Controls.Add(this.dateText);
            this.gpsInfoPanel.Controls.Add(this.satelliteIdLabel);
            this.gpsInfoPanel.Controls.Add(this.satelliteViewLabel);
            this.gpsInfoPanel.Controls.Add(this.directLabel);
            this.gpsInfoPanel.Controls.Add(this.speedLabel);
            this.gpsInfoPanel.Controls.Add(this.timeLabel);
            this.gpsInfoPanel.Controls.Add(this.dateLabel);
            this.gpsInfoPanel.Controls.Add(this.lonLabel);
            this.gpsInfoPanel.Controls.Add(this.latLabel);
            this.gpsInfoPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.gpsInfoPanel.Location = new System.Drawing.Point(3, 134);
            this.gpsInfoPanel.Name = "gpsInfoPanel";
            this.gpsInfoPanel.Size = new System.Drawing.Size(462, 200);
            this.gpsInfoPanel.TabIndex = 5;
            // 
            // s11
            // 
            this.s11.AutoSize = true;
            this.s11.Location = new System.Drawing.Point(360, 104);
            this.s11.Name = "s11";
            this.s11.Size = new System.Drawing.Size(27, 13);
            this.s11.TabIndex = 29;
            this.s11.Text = "s11";
            // 
            // s10
            // 
            this.s10.AutoSize = true;
            this.s10.Location = new System.Drawing.Point(328, 104);
            this.s10.Name = "s10";
            this.s10.Size = new System.Drawing.Size(27, 13);
            this.s10.TabIndex = 28;
            this.s10.Text = "s10";
            // 
            // s9
            // 
            this.s9.AutoSize = true;
            this.s9.Location = new System.Drawing.Point(304, 104);
            this.s9.Name = "s9";
            this.s9.Size = new System.Drawing.Size(20, 13);
            this.s9.TabIndex = 27;
            this.s9.Text = "s9";
            // 
            // s8
            // 
            this.s8.AutoSize = true;
            this.s8.Location = new System.Drawing.Point(280, 104);
            this.s8.Name = "s8";
            this.s8.Size = new System.Drawing.Size(20, 13);
            this.s8.TabIndex = 26;
            this.s8.Text = "s8";
            // 
            // s7
            // 
            this.s7.AutoSize = true;
            this.s7.Location = new System.Drawing.Point(256, 104);
            this.s7.Name = "s7";
            this.s7.Size = new System.Drawing.Size(20, 13);
            this.s7.TabIndex = 25;
            this.s7.Text = "s7";
            // 
            // s6
            // 
            this.s6.AutoSize = true;
            this.s6.Location = new System.Drawing.Point(232, 104);
            this.s6.Name = "s6";
            this.s6.Size = new System.Drawing.Size(20, 13);
            this.s6.TabIndex = 24;
            this.s6.Text = "s6";
            // 
            // s5
            // 
            this.s5.AutoSize = true;
            this.s5.Location = new System.Drawing.Point(208, 104);
            this.s5.Name = "s5";
            this.s5.Size = new System.Drawing.Size(20, 13);
            this.s5.TabIndex = 23;
            this.s5.Text = "s5";
            // 
            // s4
            // 
            this.s4.AutoSize = true;
            this.s4.Location = new System.Drawing.Point(184, 104);
            this.s4.Name = "s4";
            this.s4.Size = new System.Drawing.Size(20, 13);
            this.s4.TabIndex = 22;
            this.s4.Text = "s4";
            // 
            // s3
            // 
            this.s3.AutoSize = true;
            this.s3.Location = new System.Drawing.Point(160, 104);
            this.s3.Name = "s3";
            this.s3.Size = new System.Drawing.Size(20, 13);
            this.s3.TabIndex = 21;
            this.s3.Text = "s3";
            // 
            // s2
            // 
            this.s2.AutoSize = true;
            this.s2.Location = new System.Drawing.Point(136, 104);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(20, 13);
            this.s2.TabIndex = 20;
            this.s2.Text = "s2";
            // 
            // s1
            // 
            this.s1.AutoSize = true;
            this.s1.Location = new System.Drawing.Point(112, 104);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(20, 13);
            this.s1.TabIndex = 19;
            this.s1.Text = "s1";
            // 
            // s0
            // 
            this.s0.AutoSize = true;
            this.s0.Location = new System.Drawing.Point(88, 104);
            this.s0.Name = "s0";
            this.s0.Size = new System.Drawing.Size(20, 13);
            this.s0.TabIndex = 18;
            this.s0.Text = "s0";
            // 
            // messageBox
            // 
            this.messageBox.Location = new System.Drawing.Point(0, 120);
            this.messageBox.MaxLength = 50;
            this.messageBox.Multiline = true;
            this.messageBox.Name = "messageBox";
            this.messageBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.messageBox.Size = new System.Drawing.Size(462, 80);
            this.messageBox.TabIndex = 17;
            // 
            // satillitesViewText
            // 
            this.satillitesViewText.AutoSize = true;
            this.satillitesViewText.Location = new System.Drawing.Point(118, 80);
            this.satillitesViewText.Name = "satillitesViewText";
            this.satillitesViewText.Size = new System.Drawing.Size(105, 13);
            this.satillitesViewText.TabIndex = 15;
            this.satillitesViewText.Text = "satillitesViewText";
            // 
            // directionText
            // 
            this.directionText.AutoSize = true;
            this.directionText.Location = new System.Drawing.Point(280, 56);
            this.directionText.Name = "directionText";
            this.directionText.Size = new System.Drawing.Size(81, 13);
            this.directionText.TabIndex = 14;
            this.directionText.Text = "directionText";
            // 
            // speedText
            // 
            this.speedText.AutoSize = true;
            this.speedText.Location = new System.Drawing.Point(57, 56);
            this.speedText.Name = "speedText";
            this.speedText.Size = new System.Drawing.Size(66, 13);
            this.speedText.TabIndex = 13;
            this.speedText.Text = "speedText";
            // 
            // lonText
            // 
            this.lonText.AutoSize = true;
            this.lonText.Location = new System.Drawing.Point(285, 32);
            this.lonText.Name = "lonText";
            this.lonText.Size = new System.Drawing.Size(49, 13);
            this.lonText.TabIndex = 12;
            this.lonText.Text = "lonText";
            // 
            // latText
            // 
            this.latText.AutoSize = true;
            this.latText.Location = new System.Drawing.Point(67, 32);
            this.latText.Name = "latText";
            this.latText.Size = new System.Drawing.Size(46, 13);
            this.latText.TabIndex = 11;
            this.latText.Text = "latText";
            // 
            // timeText
            // 
            this.timeText.AutoSize = true;
            this.timeText.Location = new System.Drawing.Point(256, 8);
            this.timeText.Name = "timeText";
            this.timeText.Size = new System.Drawing.Size(55, 13);
            this.timeText.TabIndex = 10;
            this.timeText.Text = "timeText";
            // 
            // dateText
            // 
            this.dateText.AutoSize = true;
            this.dateText.Location = new System.Drawing.Point(48, 8);
            this.dateText.Name = "dateText";
            this.dateText.Size = new System.Drawing.Size(57, 13);
            this.dateText.TabIndex = 9;
            this.dateText.Text = "dateText";
            // 
            // satelliteIdLabel
            // 
            this.satelliteIdLabel.AutoSize = true;
            this.satelliteIdLabel.Location = new System.Drawing.Point(8, 104);
            this.satelliteIdLabel.Name = "satelliteIdLabel";
            this.satelliteIdLabel.Size = new System.Drawing.Size(70, 13);
            this.satelliteIdLabel.TabIndex = 7;
            this.satelliteIdLabel.Text = "Satellite ID";
            // 
            // satelliteViewLabel
            // 
            this.satelliteViewLabel.AutoSize = true;
            this.satelliteViewLabel.Location = new System.Drawing.Point(8, 80);
            this.satelliteViewLabel.Name = "satelliteViewLabel";
            this.satelliteViewLabel.Size = new System.Drawing.Size(104, 13);
            this.satelliteViewLabel.TabIndex = 6;
            this.satelliteViewLabel.Text = "Satellites in View";
            // 
            // directLabel
            // 
            this.directLabel.AutoSize = true;
            this.directLabel.Location = new System.Drawing.Point(216, 56);
            this.directLabel.Name = "directLabel";
            this.directLabel.Size = new System.Drawing.Size(58, 13);
            this.directLabel.TabIndex = 5;
            this.directLabel.Text = "Direction";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(8, 56);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(43, 13);
            this.speedLabel.TabIndex = 4;
            this.speedLabel.Text = "Speed";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(216, 8);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(34, 13);
            this.timeLabel.TabIndex = 3;
            this.timeLabel.Text = "Time";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(8, 8);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(34, 13);
            this.dateLabel.TabIndex = 2;
            this.dateLabel.Text = "Date";
            // 
            // lonLabel
            // 
            this.lonLabel.AutoSize = true;
            this.lonLabel.Location = new System.Drawing.Point(216, 32);
            this.lonLabel.Name = "lonLabel";
            this.lonLabel.Size = new System.Drawing.Size(63, 13);
            this.lonLabel.TabIndex = 1;
            this.lonLabel.Text = "Longitude";
            // 
            // latLabel
            // 
            this.latLabel.AutoSize = true;
            this.latLabel.Location = new System.Drawing.Point(8, 32);
            this.latLabel.Name = "latLabel";
            this.latLabel.Size = new System.Drawing.Size(53, 13);
            this.latLabel.TabIndex = 0;
            this.latLabel.Text = "Latitude";
            // 
            // serialPort
            // 
            this.serialPort.PortName = "COM2";
            this.serialPort.ReadBufferSize = 1024;
            this.serialPort.WriteBufferSize = 512;
            this.serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort_DataReceived);
            this.serialPort.ErrorReceived += new System.IO.Ports.SerialErrorReceivedEventHandler(this.serialPort_ErrorReceived);
            // 
            // clientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 570);
            this.Controls.Add(this.gpsInfoPanel);
            this.Controls.Add(this.busInfoPanel);
            this.Controls.Add(this.reserveList);
            this.Controls.Add(this.busPlanPanel);
            this.Controls.Add(this.statusBar);
            this.Controls.Add(this.menuBar);
            this.MainMenuStrip = this.menuBar;
            this.Name = "clientForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Application of GPS to Transportation System";
            this.Resize += new System.EventHandler(this.clientForm_Resize);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.clientForm_FormClosing);
            this.ResizeEnd += new System.EventHandler(this.clientForm_ResizeEnd);
            this.Load += new System.EventHandler(this.clientForm_Load);
            this.menuBar.ResumeLayout(false);
            this.menuBar.PerformLayout();
            this.busInfoPanel.ResumeLayout(false);
            this.busInfoPanel.PerformLayout();
            this.gpsInfoPanel.ResumeLayout(false);
            this.gpsInfoPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuBar;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setInfoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.Panel busPlanPanel;
        private System.Windows.Forms.ListView reserveList;
        private System.Windows.Forms.ColumnHeader ticketNo;
        private System.Windows.Forms.ColumnHeader passenger;
        private System.Windows.Forms.ColumnHeader station;
        private System.Windows.Forms.ColumnHeader seatNo;
        private System.Windows.Forms.Panel busInfoPanel;
        private System.Windows.Forms.Label busIdLabel;
        private System.Windows.Forms.Label pathLabel;
        private System.Windows.Forms.Label totalSeatLabel;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.Label hNameLabel;
        private System.Windows.Forms.Label dNameLabel;
        private System.Windows.Forms.Panel gpsInfoPanel;
        private System.Windows.Forms.Label latLabel;
        private System.Windows.Forms.Label lonLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label satelliteViewLabel;
        private System.Windows.Forms.Label directLabel;
        private System.Windows.Forms.Label satelliteIdLabel;
        private System.Windows.Forms.Label totalSeatText;
        private System.Windows.Forms.Label classText;
        private System.Windows.Forms.Label pathText;
        private System.Windows.Forms.Label busIdText;
        private System.Windows.Forms.Label hNameText;
        private System.Windows.Forms.Label dNameText;
        private System.Windows.Forms.Label lonText;
        private System.Windows.Forms.Label latText;
        private System.Windows.Forms.Label timeText;
        private System.Windows.Forms.Label dateText;
        private System.Windows.Forms.Label satillitesViewText;
        private System.Windows.Forms.Label directionText;
        private System.Windows.Forms.Label speedText;
        private System.Windows.Forms.TextBox messageBox;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.ToolStripMenuItem connectGPSItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectGPSItem;
        private System.Windows.Forms.Label s0;
        private System.Windows.Forms.Label s4;
        private System.Windows.Forms.Label s3;
        private System.Windows.Forms.Label s2;
        private System.Windows.Forms.Label s1;
        private System.Windows.Forms.Label s10;
        private System.Windows.Forms.Label s9;
        private System.Windows.Forms.Label s8;
        private System.Windows.Forms.Label s7;
        private System.Windows.Forms.Label s6;
        private System.Windows.Forms.Label s5;
        private System.Windows.Forms.Label s11;
        private System.Windows.Forms.ToolStripMenuItem connectServerItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectServerItem;
    }
}

