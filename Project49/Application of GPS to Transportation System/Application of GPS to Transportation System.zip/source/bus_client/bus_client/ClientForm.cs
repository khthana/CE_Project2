using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace bus_client
{
    public partial class clientForm : Form
    {
        private string message;
        private string startMode;
        private string[] satelUse = new string[12];
        private bool powerSave, waasEgnos;
        private int gpgsvMsgNum = 0;
        private double lat, lon;
        private double latError, lonError;
        private double timeZone;
        private DateTime dateTime = new DateTime();
        private LatLonSender llsender = new LatLonSender();
        private GpsReceiver gpsReceiver = new GpsReceiver();
        private ReserveManager reservManager = new ReserveManager();
        private OutputManager outputManager = new OutputManager();
        private setInfoBox setInfoDialog = new setInfoBox();
        private optionBox optionDialog = new optionBox();
        private AboutBox aboutBoxDialoag = new bus_client.AboutBox();

        public clientForm()
        {
            InitializeComponent();
        }

        private void clientForm_Load(object sender, EventArgs e)
        {
            this.outputManager.messageBox = this.messageBox;
            this.outputManager.reserveList = this.reserveList;
            this.outputManager.busPlanPanel = this.busPlanPanel;

            this.outputManager.outputTextArray[0] = this.busIdText;
            this.outputManager.outputTextArray[1] = this.pathText;
            this.outputManager.outputTextArray[2] = this.classText;
            this.outputManager.outputTextArray[3] = this.totalSeatText;
            this.outputManager.outputTextArray[4] = this.dNameText;
            this.outputManager.outputTextArray[5] = this.hNameText;
            this.outputManager.outputTextArray[6] = this.dateText;
            this.outputManager.outputTextArray[7] = this.timeText;
            this.outputManager.outputTextArray[8] = this.latText;
            this.outputManager.outputTextArray[9] = this.lonText;
            this.outputManager.outputTextArray[10] = this.speedText;
            this.outputManager.outputTextArray[11] = this.directionText;
            this.outputManager.outputTextArray[12] = this.satillitesViewText;

            this.outputManager.sattelTextArray[0] = this.s0;
            this.outputManager.sattelTextArray[1] = this.s1;
            this.outputManager.sattelTextArray[2] = this.s2;
            this.outputManager.sattelTextArray[3] = this.s3;
            this.outputManager.sattelTextArray[4] = this.s4;
            this.outputManager.sattelTextArray[5] = this.s5;
            this.outputManager.sattelTextArray[6] = this.s6;
            this.outputManager.sattelTextArray[7] = this.s7;
            this.outputManager.sattelTextArray[8] = this.s8;
            this.outputManager.sattelTextArray[9] = this.s9;
            this.outputManager.sattelTextArray[10] = this.s10;
            this.outputManager.sattelTextArray[11] = this.s11;

            // Clear output's text
            this.outputManager.ClearOutput();

            // Start update output
            this.outputManager.StartUpdate();

            this.gpsReceiver.PortHandler = this.serialPort;
            // Get port's name from Option Dialog
            this.gpsReceiver.PortHandler.PortName = this.optionDialog.getComPort();
            // Get baud rate from Option Dialog
            this.gpsReceiver.PortHandler.BaudRate = this.optionDialog.getBaudRate();
            // Get time zone from Option Dialog
            this.timeZone = this.optionDialog.getTimeZone();

            // Set default error value
            this.latError = this.optionDialog.getLatError();
            this.lonError = this.optionDialog.getLonError();
        }

        private void clientForm_ResizeEnd(object sender, EventArgs e)
        {
            resizeForm();
        }

        private void clientForm_Resize(object sender, EventArgs e)
        {
            resizeForm();
        }

        private void clientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            closeForm();
        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            closeForm();
        }

        private void connectGPSItem_Click(object sender, EventArgs e)
        {
            this.gpsReceiver.StartReceiver();                   // Start GPS Receiver
            this.outputManager.message = "GPS Open...\r\n";     // Show message on message box
            this.connectGPSItem.Enabled = false;                // Enable connect gps menu item
            this.disconnectGPSItem.Enabled = true;              // Disable disconnect gps menu item
        }

        private void disconnectGPSItem_Click(object sender, EventArgs e)
        {
            this.gpsReceiver.StopReceiver();                    // Stop GPS Receiver
            this.outputManager.message = "GPS Close...\r\n";    // Show message on message box
            this.connectGPSItem.Enabled = true;                 // Enable disconnect gps menu item
            this.disconnectGPSItem.Enabled = false;             // Disable connect gps menu item
        }

        private void connectServerItem_Click(object sender, EventArgs e)
        {
            // start latitude & longitude sender
            this.llsender.ServerEndPoint = new IPEndPoint(IPAddress.Parse("161.246.5.107"), 9999);
            this.llsender.busId = this.setInfoDialog.getBusId();
            this.llsender.StartSender();

            // start reserve manager
            this.reservManager.ServerEndPoint = new IPEndPoint(IPAddress.Parse("161.246.5.107"), 10000);
            this.reservManager.outputManager = this.outputManager;
            this.reservManager.busId = this.setInfoDialog.getBusId();
            this.reservManager.StartUpdate();

            //Disable Connect Server Menu
            this.connectServerItem.Enabled = false;
            //Enable Disconnect Server Menu
            this.disconnectServerItem.Enabled = true;
        }

        private void disconnectServerItem_Click(object sender, EventArgs e)
        {
            this.llsender.StopSender();                         // stop latitude & longitude sender
            this.reservManager.StopUpdate();                    // stop reserve manager
            this.connectServerItem.Enabled = true;              // Enable Connect Server Menu
            this.disconnectServerItem.Enabled = false;          // Disconnect Server Menu
        }

        private void setInfoMenuItem_Click(object sender, EventArgs e)
        {
            //Show Set Information Dialog
            this.setInfoDialog.ShowDialog();

            //Get bus id from Set Information Dialog
            this.outputManager.textOutputArray[0] = this.setInfoDialog.getBusId();

            //Get path from Set Information Dialog
            this.outputManager.textOutputArray[1] = this.setInfoDialog.getPath();

            //Get class from Set Information Dialog
            this.outputManager.textOutputArray[2] = this.setInfoDialog.getClass();

            //Get total seat from Set Information Dialog
            this.outputManager.textOutputArray[3] = Convert.ToString(this.setInfoDialog.getTotalSeat());

            //Get driver's name from Set Information Dialog
            this.outputManager.textOutputArray[4] = this.setInfoDialog.getDriverName();

            //Get hostess's name from Set Information Dialog
            this.outputManager.textOutputArray[5] = this.setInfoDialog.getHostessName();
        }

        private void optionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Set portIsOpen in Option Dialog
            this.optionDialog.setPortIsOpen(this.gpsReceiver.PortHandler.IsOpen);
            
            // Show Option Dialog
            this.optionDialog.ShowDialog();

            // if port is opened and port's name is changed
            if (this.gpsReceiver.PortHandler.PortName.CompareTo(this.optionDialog.getComPort()) != 0 && !this.gpsReceiver.PortHandler.IsOpen)
            {
                // Get port's name from Option Dialog
                this.gpsReceiver.PortHandler.PortName = this.optionDialog.getComPort();

                // Show message on message box
                this.outputManager.message = "Change Port is \"" + this.gpsReceiver.PortHandler.PortName + "\"\r\n";
            }

            // if port is opened and baud rate is changed
            if (this.gpsReceiver.PortHandler.BaudRate != this.optionDialog.getBaudRate() && !this.gpsReceiver.PortHandler.IsOpen)
            {
                // Get baud rate from Option Dialog
                this.gpsReceiver.PortHandler.BaudRate = this.optionDialog.getBaudRate();

                // Show message on message box
                this.outputManager.message = "Change BaudRate is " + this.gpsReceiver.PortHandler.BaudRate + "\r\n";
            }

            // if latitude error is changed
            if (this.latError != this.optionDialog.getLatError())
            {
                // Get latitude error from Option Dialog
                this.latError = this.optionDialog.getLatError();
            }

            // if longitude error is changed
            if (this.lonError != this.optionDialog.getLonError())
            {
                // Get longitude error from Option Dialog
                this.lonError = this.optionDialog.getLonError();
            }

            // if time zone is changed
            if (this.timeZone != this.optionDialog.getTimeZone())
            {
                // Get time zone from Option Dialog
                this.timeZone = this.optionDialog.getTimeZone();
            }

            // if start mode is changed
            if (this.startMode != this.optionDialog.getStartMode())
            {
                // Get start mode command from Option Dialog
                this.startMode = this.optionDialog.getStartMode();

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = this.startMode;

                // Send start mode command to gps module
                this.gpsReceiver.PortHandler.Write(this.startMode);

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = "Done...\r\n";
            }

            // if power save status is changed
            if (this.powerSave != this.optionDialog.getPowerSave())
            {
                // Get power save status from Option Dialog
                this.powerSave = this.optionDialog.getPowerSave();

                // if power save status is on
                if (this.powerSave)
                    // Set power save on command into message
                    this.message = "$PSRF107,0,400,1000*08\r\n";
                else
                    // Set power save off command into message
                    this.message = "$PSRF107,0,1000,1000,*3D\r\n";

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = this.message;

                // Send power save command to gps module
                this.gpsReceiver.PortHandler.Write(this.message);

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = "Done...\r\n";
            }

            // if WAAS/EGNOS status is changed
            if (this.waasEgnos != this.optionDialog.getWaasEgnos())
            {
                // Get WAAS/EGNOS status from Option Dialog
                this.waasEgnos = this.optionDialog.getWaasEgnos();

                // if WAAS/EGNOS status is on
                if (this.waasEgnos)
                    // Set WAAS/EGNOS on command into message
                    this.message = "$PSRF108,01*03\r\n";
                else
                    // Set WAAS/EGNOS off command into message
                    this.message = "$PSRF108,00*02\r\n";

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = this.message;

                // Send WAAS/EGNOS command to gps module
                this.gpsReceiver.PortHandler.Write(this.message);

                // if port is opened
                if (this.gpsReceiver.PortHandler.IsOpen)
                    // Show message on message box
                    this.outputManager.message = "Done...\r\n";
            }
        }

        private void aboutMenuItem_Click(object sender, EventArgs e)
        {
            this.aboutBoxDialoag.ShowDialog();
        }

        private void serialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            // if gps port is not break
            if (!this.gpsReceiver.PortHandler.BreakState)
            {
                // Receive NMEA sentence from gps module
                this.message = this.gpsReceiver.GetNmeaSentence();

                // Show NMEA sentence into message box
                this.outputManager.message = this.message;

                // Show all information
                this.ShowInfo();

                Thread.Sleep(250);
            }
        }

        private void serialPort_ErrorReceived(object sender, System.IO.Ports.SerialErrorReceivedEventArgs e)
        {
            MessageBox.Show("Serial Port is Received Error");
        }

        private void reserveList_ItemActivate(object sender, EventArgs e)
        {
            this.outputManager.RemoveList((ListView)sender);
        }

        private void resizeForm()
        {
            // if width of form is more or equal 800
            if (this.Size.Width >= 800)
            {
                // Move Position of Bus Plan Panel go to right
                this.busPlanPanel.Location = new Point(this.Size.Width - this.busPlanPanel.Width - 10, this.busPlanPanel.Location.Y);

                // Add Width of Bus Information Panel
                this.busInfoPanel.Size = new Size(this.Size.Width - 336, this.busInfoPanel.Height);

                // Add Width of GPS Information Panel
                this.gpsInfoPanel.Size = new Size(this.Size.Width - 336, this.gpsInfoPanel.Height);

                // Add Width of Message Box
                this.messageBox.Size = new Size(this.Size.Width - 336, this.messageBox.Height);

                // Add Width of Reserve List
                this.reserveList.Size = new Size(this.Size.Width - 336, this.reserveList.Height);

                // Add Width of Passenger Column in Reserve List
                this.passenger.Width = this.Size.Width - 584;
            }
            // if width of form is less 800
            else if (this.Size.Width < 800)
            {
                // Fix Position of Bus Plan Panel is static
                this.busPlanPanel.Location = new Point(470, this.busPlanPanel.Location.Y);

                // Fix Width of Bus Information Panel is static
                this.busInfoPanel.Size = new Size(462, this.busInfoPanel.Height);

                // Fix Width of GPS Information Panel is static
                this.gpsInfoPanel.Size = new Size(462, this.gpsInfoPanel.Height);

                // Fix Width of Message Box is static
                this.messageBox.Size = new Size(462, this.messageBox.Height);

                // Fix Width of Reserve List is static
                this.reserveList.Size = new Size(462, this.reserveList.Height);

                // Fix Width of Passenger Column in Reserve List is static
                this.passenger.Width = 216;
            }

            // if height of form is less 184
            if (this.Size.Height < 184)
            {
                // Reduce Height of Bus Information Panel
                this.busInfoPanel.Size = new Size(this.busInfoPanel.Width, this.Size.Height - 82);
            }
            // if height of form is less 389
            else if (this.Size.Height < 389)
            {
                // Fix Height of Bus Information Panel is static
                this.busInfoPanel.Size = new Size(this.busInfoPanel.Width, 101);

                // Reduce Height of GPS Information Panel
                this.gpsInfoPanel.Size = new Size(this.gpsInfoPanel.Width, this.Size.Height - 189);
            }
            else
            {
                // Fix Height of Bus And GPS Information Panel is static
                this.busInfoPanel.Size = new Size(this.busInfoPanel.Width, 101);
                this.gpsInfoPanel.Size = new Size(this.gpsInfoPanel.Width, 200);
            }

            // Fix Height of Reserve List And Bus Plan Panel is less Height of Form, is static value
            this.reserveList.Size = new Size(this.reserveList.Width, this.Size.Height - 395);
            this.busPlanPanel.Size = new Size(this.busPlanPanel.Size.Width, this.Size.Height - 82);
        }

        private void closeForm()
        {
            // if Latitude & Longitude sender has worked
            if (this.disconnectServerItem.Enabled)
                // Stop sender
                this.llsender.StopSender();

            // if gps port has opened
            if (this.gpsReceiver.PortHandler.IsOpen)
                // Stop GPS receiver
                this.gpsReceiver.StopReceiver();

            // Stop update of output manager
            this.outputManager.StopUpdate();

            // Exit Program
            Application.Exit();
        }

        private void ShowInfo()
        {
            // Set delimiter character
            char[] delimiterChars = { ',', '*' };

            // if message start with "$GPGGA"
            if (this.message.StartsWith("$GPGGA"))
            {
                // Split message with delimiter character
                string[] gpgga = this.message.Split(delimiterChars);

                if (gpgga.Length >= 6)
                {
                    // Show local time
                    this.outputManager.textOutputArray[7] = UTC2LocalTime(gpgga[1], this.timeZone);

                    // Convert latitude from string value to double value
                    this.lat = this.convertToLatLon(gpgga[2], this.latError);

                    // Show latitude value
                    this.outputManager.textOutputArray[8] = this.convertLatLonFormat(gpgga[2], gpgga[3], this.latError);

                    // Convert longitude from string value to double value
                    this.lon = this.convertToLatLon(gpgga[4], this.lonError);

                    // Show longitude value
                    this.outputManager.textOutputArray[9] = this.convertLatLonFormat(gpgga[4], gpgga[5], this.lonError);

                    // Set latitude & longitude to Latitude & Longitude sender
                    this.llsender.lat = this.lat;
                    this.llsender.lon = this.lon;
                }
            }
            // if message start with "$GPGSA"
            else if (this.message.StartsWith("$GPGSA"))
            {
                // Split message with delimiter character
                string[] gpgsa = this.message.Split(delimiterChars);

                for (int i = 0; i != 12; i++)
                    // Get satellite number that gps module is using
                    if (gpgsa.Length > i+3) this.satelUse[i] = gpgsa[i + 3];
            }
            // if message start with "$GPGSV"
            else if (this.message.StartsWith("$GPGSV"))
            {
                // Split message with delimiter character
                string[] gpgsv = this.message.Split(delimiterChars);

                int msgNo = 0;
                int satelliteNum = 0;

                // Convert string to integer
                int.TryParse(gpgsv[1], out gpgsvMsgNum);
                int.TryParse(gpgsv[2], out msgNo);
                int.TryParse(gpgsv[3], out satelliteNum);

                if (gpgsv.Length >= 4)
                {
                    // Show number of satellite that gps module view
                    this.outputManager.textOutputArray[12] = gpgsv[3];

                    // Show satellite number that gps module view
                    switch (msgNo)
                    {
                        case 1:
                            if (gpgsv.Length > 5)
                                this.outputManager.textSattelArray[0] = gpgsv[4];
                            if (gpgsv.Length > 9)
                                this.outputManager.textSattelArray[1] = gpgsv[8];
                            if (gpgsv.Length > 13)
                                this.outputManager.textSattelArray[2] = gpgsv[12];
                            if (gpgsv.Length > 17)
                                this.outputManager.textSattelArray[3] = gpgsv[16];
                            break;
                        case 2:
                            if (gpgsv.Length > 5)
                                this.outputManager.textSattelArray[4] = gpgsv[4];
                            if (gpgsv.Length > 9)
                                this.outputManager.textSattelArray[5] = gpgsv[8];
                            if (gpgsv.Length > 13)
                                this.outputManager.textSattelArray[6] = gpgsv[12];
                            if (gpgsv.Length > 17)
                                this.outputManager.textSattelArray[7] = gpgsv[16];
                            break;
                        case 3:
                            if (gpgsv.Length > 5)
                                this.outputManager.textSattelArray[8] = gpgsv[4];
                            if (gpgsv.Length > 9)
                                this.outputManager.textSattelArray[9] = gpgsv[8];
                            if (gpgsv.Length > 13)
                                this.outputManager.textSattelArray[10] = gpgsv[12];
                            if (gpgsv.Length > 17)
                                this.outputManager.textSattelArray[11] = gpgsv[16];
                            break;
                    }
                }            

                if (this.gpgsvMsgNum == msgNo)
                {
                    // Clear satellite number that gps module viewed
                    for (int i = satelliteNum; i != this.outputManager.textSattelArray.Length; i++)
                        this.outputManager.textSattelArray[i] = "";

                    // Set colour of satellite number that gps module is using
                    for (int i = 0; i != satelliteNum; i++)
                    {
                        for (int j = 0; j != this.satelUse.Length; j++)
                        {
                            if (this.outputManager.textSattelArray[i].CompareTo(this.satelUse[j]) == 0)
                            {
                                this.outputManager.sattelTextArray[i].ForeColor = System.Drawing.Color.Red;
                                break;
                            }
                            else
                                this.outputManager.sattelTextArray[i].ForeColor = System.Drawing.Color.Black;
                        }
                    }
                }
            }
            // if message start with "$GPRMC"
            else if (this.message.StartsWith("$GPRMC"))
            {
                // Split message with delimiter character
                string[] gprmc = this.message.Split(delimiterChars);

                if (gprmc.Length >= 10)
                {
                    // Set lacol datetime
                    this.dateTime = UTC2LocalTime(gprmc[1], gprmc[9], this.timeZone);

                    // Convert latitude from string value to double value
                    this.lat = this.convertToLatLon(gprmc[3], this.latError);

                    // Show latitude value
                    this.outputManager.textOutputArray[8] = this.convertLatLonFormat(gprmc[3], gprmc[4], this.latError);

                    // Convert longitude from string value to double value
                    this.lon = this.convertToLatLon(gprmc[5], this.lonError);

                    // Show longitude value
                    this.outputManager.textOutputArray[9] = this.convertLatLonFormat(gprmc[5], gprmc[6], this.lonError);

                    // Show speed of bus in kilometer per hour unit
                    this.outputManager.textOutputArray[10] = this.knotToKph(gprmc[7]) + " km/hr";

                    // Show direct of bus
                    this.outputManager.textOutputArray[11] = gprmc[8];

                    // Show lacal date
                    this.outputManager.textOutputArray[6] = this.dateTime.ToString("d MMMM yyyy");

                    // Show local time
                    this.outputManager.textOutputArray[7] = this.dateTime.ToString("T");

                    // Set latitude & longitude to Latitude & Longitude sender
                    this.llsender.lat = this.lat;
                    this.llsender.lon = this.lon;
                }
            }
        }

        private string UTC2LocalTime(string utcStr, double tz)
        {
            double utc;
            int hh = 0;
            int mm = 0;
            int ss = 0;
            int ms = 0;

            if (double.TryParse(utcStr, out utc))
            {
                hh = System.Convert.ToInt32(Math.Floor(utc / 10000));
                double temp = utc - (hh * 10000);
                mm = System.Convert.ToInt32(Math.Floor(temp / 100));
                temp -= (mm * 100);
                ss = System.Convert.ToInt32(Math.Floor(temp));
                temp -= ss;
                ms = System.Convert.ToInt32(temp * 100);
            }

            int hour = System.Convert.ToInt32(Math.Floor(tz));
            int min = System.Convert.ToInt32((tz - hour) * 100);
            
            if (this.dateTime != null)
            {
                this.dateTime = new DateTime(this.dateTime.Year, this.dateTime.Month, this.dateTime.Day, hh, mm, ss, ms);
            }
            this.dateTime = this.dateTime.AddHours(hour);
            this.dateTime = this.dateTime.AddMinutes(min);

            return dateTime.ToString("T");
        }

        private DateTime UTC2LocalTime(string utcStr, string dateStr, double tz)
        {
            double utc;
            int date, hh, mm, ss, ms, year, month, day;

            if (this.dateTime != null)
            {
                year = this.dateTime.Year;
                month = this.dateTime.Month;
                day = this.dateTime.Day;
                hh = this.dateTime.Hour;
                mm = this.dateTime.Minute;
                ss = this.dateTime.Second;
                ms = this.dateTime.Millisecond;
            }
            else
            {
                hh = 0;
                mm = 0;
                ss = 0;
                ms = 0;
                year = 1;
                month = 1;
                day = 1;
            }

            if (double.TryParse(utcStr, out utc))
            {
                hh = System.Convert.ToInt32(Math.Floor(utc / 10000));
                double tempT = utc - (hh * 10000);
                mm = System.Convert.ToInt32(Math.Floor(tempT / 100));
                tempT -= (mm * 100);
                ss = System.Convert.ToInt32(Math.Floor(tempT));
                tempT -= ss;
                ms = System.Convert.ToInt32(tempT * 100);
            }

            int hour = System.Convert.ToInt32(Math.Floor(tz));
            int min = System.Convert.ToInt32((tz - hour) * 100);

            if (int.TryParse(dateStr, out date))
            {
                day = System.Convert.ToInt32(date / 10000);
                double tempD = date - (day * 10000);
                month = System.Convert.ToInt32(tempD / 100);
                tempD = tempD - (month * 100) + 2000;
                year = System.Convert.ToInt32(tempD);
            }

            this.dateTime = new DateTime(year, month, day, hh, mm, ss, ms);
            this.dateTime = this.dateTime.AddHours(hour);
            this.dateTime = this.dateTime.AddMinutes(min);

            return dateTime;
        }

        private double convertToLatLon(string lStr, double error)
        {
            double lvalue = 0;
            double.TryParse(lStr, out lvalue);
 
            lvalue *= 0.01;
            return lvalue += error;
        }

        private string convertLatLonFormat(string lStr, string direction, double error)
        {
            double lValue;
            int degree = 0;
            int lipda = 0;
            double philipda = 0;

            if (double.TryParse(lStr, out lValue))
            {
                lValue += (error * 100);
                degree = System.Convert.ToInt32(Math.Floor(lValue / 100));
                double temp = lValue - (degree * 100);
                lipda = System.Convert.ToInt32(Math.Floor(temp));
                temp -= lipda;
                philipda = Math.Round(temp * 10000 / 3600, 2);
            }

            string degreeStr = System.Convert.ToString(degree);
            string lipdaStr = System.Convert.ToString(lipda);
            string philipdaStr = System.Convert.ToString(philipda);
            string str = degreeStr + " � " + lipdaStr + "' " + philipdaStr + "\" " + direction;

            return str;
        }

        private string knotToKph(string knotSpeed)
        {
            double speed = 0;
            double.TryParse(knotSpeed,out speed);
            speed *= 1.852;
            return System.Convert.ToString(speed);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (this.setInfoDialog.getTotalSeat() > 0)
            {
                this.outputManager.DrawBus();
            }
        }
    }
}