﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Application of GPS to Transportation System")]
[assembly: AssemblyDescription("Develop By\t\t\t\t\t\t\tMr. Parse Pattamabenjakun\t\t\t\t\tMr. Visanu Tantrajin\t\t\t\t\t\t\t\t\t\t\tAdviser\t\t\t\t\t\t\t\tDr. Sakchai Thipchaksurat\t\t\t\t\t\t\t\t\t\tUniversity\t\t\t\t\t\t\t\tComputer Engineering Department\t\t\t\tEngineer Faculty\t\t\t\t\t\tKing Mongkut's Institute of Technology Ladkrabang")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Network Laboratory")]
[assembly: AssemblyProduct("Application of GPS to Transportation System")]
[assembly: AssemblyCopyright("Copyright © CE.KMITL 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("78617429-6ff9-4af5-bc91-b6a9eb2011aa")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
