namespace bus_client
{
    partial class setInfoBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.busIdLabel = new System.Windows.Forms.Label();
            this.busIdBox = new System.Windows.Forms.TextBox();
            this.classLabel = new System.Windows.Forms.Label();
            this.dNameLabel = new System.Windows.Forms.Label();
            this.dNameBox = new System.Windows.Forms.TextBox();
            this.hNameBox = new System.Windows.Forms.TextBox();
            this.hNameLabel = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.classBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // busIdLabel
            // 
            this.busIdLabel.AutoSize = true;
            this.busIdLabel.Location = new System.Drawing.Point(12, 15);
            this.busIdLabel.Name = "busIdLabel";
            this.busIdLabel.Size = new System.Drawing.Size(45, 13);
            this.busIdLabel.TabIndex = 0;
            this.busIdLabel.Text = "Bus No.";
            // 
            // busIdBox
            // 
            this.busIdBox.Location = new System.Drawing.Point(63, 12);
            this.busIdBox.Name = "busIdBox";
            this.busIdBox.Size = new System.Drawing.Size(71, 20);
            this.busIdBox.TabIndex = 1;
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(140, 15);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(32, 13);
            this.classLabel.TabIndex = 4;
            this.classLabel.Text = "Class";
            // 
            // dNameLabel
            // 
            this.dNameLabel.AutoSize = true;
            this.dNameLabel.Location = new System.Drawing.Point(12, 41);
            this.dNameLabel.Name = "dNameLabel";
            this.dNameLabel.Size = new System.Drawing.Size(66, 13);
            this.dNameLabel.TabIndex = 6;
            this.dNameLabel.Text = "Driver Name";
            // 
            // dNameBox
            // 
            this.dNameBox.Location = new System.Drawing.Point(84, 38);
            this.dNameBox.Name = "dNameBox";
            this.dNameBox.Size = new System.Drawing.Size(173, 20);
            this.dNameBox.TabIndex = 7;
            // 
            // hNameBox
            // 
            this.hNameBox.Location = new System.Drawing.Point(94, 64);
            this.hNameBox.Name = "hNameBox";
            this.hNameBox.Size = new System.Drawing.Size(163, 20);
            this.hNameBox.TabIndex = 8;
            // 
            // hNameLabel
            // 
            this.hNameLabel.AutoSize = true;
            this.hNameLabel.Location = new System.Drawing.Point(12, 67);
            this.hNameLabel.Name = "hNameLabel";
            this.hNameLabel.Size = new System.Drawing.Size(76, 13);
            this.hNameLabel.TabIndex = 9;
            this.hNameLabel.Text = "Hostess Name";
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(48, 90);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 10;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(152, 90);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 11;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // classBox
            // 
            this.classBox.FormattingEnabled = true;
            this.classBox.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.classBox.Location = new System.Drawing.Point(178, 11);
            this.classBox.Name = "classBox";
            this.classBox.Size = new System.Drawing.Size(79, 21);
            this.classBox.TabIndex = 12;
            // 
            // setInfoBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(266, 116);
            this.ControlBox = false;
            this.Controls.Add(this.classBox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.hNameLabel);
            this.Controls.Add(this.hNameBox);
            this.Controls.Add(this.dNameBox);
            this.Controls.Add(this.dNameLabel);
            this.Controls.Add(this.classLabel);
            this.Controls.Add(this.busIdBox);
            this.Controls.Add(this.busIdLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "setInfoBox";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Set Information";
            this.Load += new System.EventHandler(this.setInfoBox_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label busIdLabel;
        private System.Windows.Forms.TextBox busIdBox;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.Label dNameLabel;
        private System.Windows.Forms.TextBox dNameBox;
        private System.Windows.Forms.TextBox hNameBox;
        private System.Windows.Forms.Label hNameLabel;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ComboBox classBox;
    }
}