using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace bus_client
{
    class GpsReceiver
    {
        private Thread receiverThread;
        private string nmeaSentence = "";
        private bool finish;
        public SerialPort PortHandler;

        public void StartReceiver()
        {
            try
            {
                if (!this.PortHandler.IsOpen)
                    this.PortHandler.Open();
                this.PortHandler.DiscardInBuffer();
                this.PortHandler.DiscardOutBuffer();
                if (this.PortHandler.BreakState)
                    this.PortHandler.BreakState = false;
                this.finish = false;
                this.receiverThread = new Thread(new ThreadStart(this.RunReceiver));
                this.receiverThread.Start();
            }
            catch (InvalidOperationException invaOperEx)
            {
                MessageBox.Show("The specified port is open." + invaOperEx);
            }
            catch (ArgumentOutOfRangeException arguOutRanEx)
            {
                MessageBox.Show("One or more of the properties for this instance are invalid." +
                                "For example, the Parity, DataBits, or Handshake properties" +
                                "are not valid values; the BaudRate is less than or equal to zero;" +
                                "the ReadTimeout or WriteTimeout property is less than zero and" +
                                "is not InfiniteTimeout." + arguOutRanEx);
            }
            catch (ArgumentException arguEx)
            {
                MessageBox.Show("The port name does not begin with \"COM\".\n\n- or -\n\n" +
                                "The file type of the port is not supported." + arguEx);
            }
            catch (System.IO.IOException ioEx)
            {
                MessageBox.Show("The port is in an invalid state.\n\n- or -\n\n" +
                                "An attempt to set the state of the underlying port failed. For example,\n" +
                                "the parameters passed from this SerialPort object were invalid." + ioEx);
            }
            catch (UnauthorizedAccessException unauthAcceEx)
            {
                MessageBox.Show("Access is denied to the port." + unauthAcceEx);
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }

        public void StopReceiver()
        {
            try
            {
                this.finish = true;
                if (!this.PortHandler.BreakState)
                    this.PortHandler.BreakState = true;
                this.PortHandler.DiscardInBuffer();
                this.PortHandler.DiscardOutBuffer();
                this.PortHandler.Close();
                this.receiverThread.Abort();
            }
            catch (System.IO.IOException ioEx)
            {
                MessageBox.Show("The port is in an invalid state.\n\n- or -\n\n" +
                                "An attempt to set the state of the underlying port failed. For example,\n" +
                                "the parameters passed from this SerialPort object were invalid." + ioEx);
            }
            catch (InvalidOperationException invaOperEx)
            {
                MessageBox.Show("The specified port is open.\n" + invaOperEx);
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception: " + exp);
            }
        }

        private void RunReceiver()
        {
            try
            {
                while (!this.finish)
                {
                    if (this.PortHandler.IsOpen)
                        this.nmeaSentence = this.PortHandler.ReadLine();
                    Thread.Sleep(250);
                }
            }
            catch (InvalidOperationException invaOperEx)
            {
                MessageBox.Show("The specified port is not open." + invaOperEx);
            }
            catch (TimeoutException timeOutEx)
            {
                MessageBox.Show("The operation did not complete before the time-out period ended.\n\n" +
                                "- or -\n\nNo bytes were read." + timeOutEx);
            }
            catch (System.IO.IOException ioEx)
            {
                MessageBox.Show("Exception :" + ioEx);
            }
        }

        public string GetNmeaSentence()
        {
            return this.nmeaSentence;
        }
    }
}
