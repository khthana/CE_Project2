-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 18, 2007 at 05:18 AM
-- Server version: 5.0.24
-- PHP Version: 5.2.0RC4-dev
-- 
-- Database: `gps`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bus`
-- 

CREATE TABLE `bus` (
  `BUS_ID` varchar(5) collate utf8_unicode_ci NOT NULL,
  `SEAT_AMOUNT` varchar(3) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`BUS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `bus`
-- 

INSERT INTO `bus` (`BUS_ID`, `SEAT_AMOUNT`) VALUES ('13-05', '40'),
('14-01', '40');

-- --------------------------------------------------------

-- 
-- Table structure for table `customer`
-- 

CREATE TABLE `customer` (
  `C_NUMBER` int(5) NOT NULL auto_increment,
  `C_NAME` varchar(30) collate utf8_unicode_ci NOT NULL,
  `C_SURNAME` varchar(30) collate utf8_unicode_ci NOT NULL,
  `C_TELEPHONE` varchar(12) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`C_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `customer`
-- 

INSERT INTO `customer` (`C_NUMBER`, `C_NAME`, `C_SURNAME`, `C_TELEPHONE`) VALUES (1, 'เต้', 'เน็ตเวิร์ก', '089-0116230');

-- --------------------------------------------------------

-- 
-- Table structure for table `driving_table`
-- 

CREATE TABLE `driving_table` (
  `DRIVE_SEQ` int(11) NOT NULL auto_increment,
  `DRIVE_NUMBER` varchar(4) collate utf8_unicode_ci NOT NULL,
  `BUS_ID` varchar(5) collate utf8_unicode_ci NOT NULL,
  `DAY` varchar(10) collate utf8_unicode_ci NOT NULL,
  `PATH_ID` varchar(2) collate utf8_unicode_ci NOT NULL,
  `OVER_NIGHT` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`DRIVE_SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `driving_table`
-- 

INSERT INTO `driving_table` (`DRIVE_SEQ`, `DRIVE_NUMBER`, `BUS_ID`, `DAY`, `PATH_ID`, `OVER_NIGHT`) VALUES (1, '1301', '13-05', 'Sunday', '13', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `path`
-- 

CREATE TABLE `path` (
  `PATH_ID` varchar(2) collate utf8_unicode_ci NOT NULL,
  `START_STATION` varchar(4) collate utf8_unicode_ci NOT NULL,
  `FINAL_STATION` varchar(4) collate utf8_unicode_ci NOT NULL,
  `DURATION` time NOT NULL,
  PRIMARY KEY  (`PATH_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `path`
-- 

INSERT INTO `path` (`PATH_ID`, `START_STATION`, `FINAL_STATION`, `DURATION`) VALUES ('13', 'C001', 'N090', '07:00:00'),
('14', 'N090', 'C001', '07:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `reservation`
-- 

CREATE TABLE `reservation` (
  `RESERV_NUMBER` int(10) NOT NULL auto_increment,
  `C_NUMBER` int(10) NOT NULL,
  `DATE_TRAVEL` date NOT NULL,
  `TIME_TRAVEL` time NOT NULL,
  `BUS_ID` varchar(5) collate utf8_unicode_ci NOT NULL,
  `SEAT_NO` varchar(3) collate utf8_unicode_ci NOT NULL,
  `TRIP_ID` varchar(6) collate utf8_unicode_ci NOT NULL,
  `CHECK_UPDATE` int(1) NOT NULL,
  PRIMARY KEY  (`RESERV_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `reservation`
-- 

INSERT INTO `reservation` (`RESERV_NUMBER`, `C_NUMBER`, `DATE_TRAVEL`, `TIME_TRAVEL`, `BUS_ID`, `SEAT_NO`, `TRIP_ID`, `CHECK_UPDATE`) VALUES (1, 1, '2007-03-18', '06:00:00', '13-05', '1', 'N0011A', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `schedule`
-- 

CREATE TABLE `schedule` (
  `DRIVE_NUMBER` varchar(4) collate utf8_unicode_ci NOT NULL,
  `STATION_ID` varchar(4) collate utf8_unicode_ci NOT NULL,
  `TIME` time NOT NULL,
  PRIMARY KEY  (`DRIVE_NUMBER`,`STATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `schedule`
-- 

INSERT INTO `schedule` (`DRIVE_NUMBER`, `STATION_ID`, `TIME`) VALUES ('1301', 'C001', '06:00:00'),
('1301', 'C015', '07:00:00'),
('1301', 'C020', '07:50:00'),
('1301', 'N025', '08:30:00'),
('1301', 'N030', '09:15:00'),
('1301', 'N035', '10:00:00'),
('1301', 'N040', '10:50:00'),
('1301', 'N045', '11:50:00'),
('1301', 'N050', '13:10:00'),
('1301', 'N080', '15:40:00'),
('1301', 'N085', '16:45:00'),
('1301', 'N090', '17:30:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `station`
-- 

CREATE TABLE `station` (
  `STATION_ID` varchar(4) collate utf8_unicode_ci NOT NULL,
  `STATION_NAME` varchar(20) collate utf8_unicode_ci NOT NULL,
  `ADDRESS` varchar(100) collate utf8_unicode_ci NOT NULL default 'ไม่ได้ระบุไว้',
  `TELEPHONE` varchar(12) collate utf8_unicode_ci NOT NULL default '-',
  `STATION_LAT` varchar(10) collate utf8_unicode_ci NOT NULL,
  `STATION_LONG` varchar(10) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`STATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `station`
-- 

INSERT INTO `station` (`STATION_ID`, `STATION_NAME`, `ADDRESS`, `TELEPHONE`, `STATION_LAT`, `STATION_LONG`) VALUES ('C001', 'กรุงเทพ', 'จตุจักร', '0-2391-2504', '13.72915', '100.77562'),
('C015', 'ปทุมธานี', 'none', 'none', '14.03296', '100.61647'),
('C020', 'อยุธยา', '55/5 หมู่ 1 สถานีอยุธยา<br />ต.ธนู อ.อุทัย<br />จ. พระนครศรีอยุธยา', '0-3533-5304', '14.36745', '100.58889'),
('N025', 'อ่างทอง', '1/4 ถ.สายเอเซีย<br />ต. บ้านอิฐ อ. เมือง<br />จ. อ่างทอง', '0-3561-1344', '14.59541', '100.45837'),
('N030', 'สิงห์บุรี', 'ถ.นายแท่น ต.บางพุทรา<br />อ. เมือง<br />จ. สิงห์บุรี', '0-3651-1064', '14.91182', '100.40722'),
('N035', 'ชัยนาท', '53/46 ซ. รร.บ้านกล้วย<br />ถ.วงษโต อ.เมือง<br />จ. ชัยนาท', '0-5641-1125', '15.17649', '100.15583'),
('N040', 'นครสวรรค์', '605/90-91 ถ.เอกมหาชัย<br />ต.นครสวรรค์ตก<br />อ.เมือง จ.นครสวรรค์', '0-5622-2169', '15.70891', '100.13424'),
('N045', 'กำแพงเพชร', '243/33 ต.นครชุม<br />อ. เมือง<br />จ. กำแพงเพชร', '0-5579-9273', '16.49036', '99.52734'),
('N050', 'ตาก', '6/10-11 ถ.พหลโยธิน<br />ต.หนองหลวง อ.เมือง<br />จ. ตาก', '0-5551-7345', '16.88768', '99.13697'),
('N080', 'ลำปาง', '101/17 ถ.จันทร์สุรินทร์<br />ต.สบตุ๋ย อ.เมือง<br />จ.ลำปาง', '0-5421-7852', '18.27443', '99.54501'),
('N085', 'ลำพูน', '56/7-8 ถ.สนามกีฬา<br />ต.ในเมือง อ.เมือง<br />จ.ลำพูน', '0-5351-1173', '18.57981', '99.03818'),
('N090', 'เชียงใหม่', '165 ซอย 5 (ในขนส่งอาเขต) ถ. แก้ววรัฐ<br />ต.วัดเกต อ. เมือง<br />จ. เชียงใหม่', '0-5324-1449', '18.79273', '98.99345');

-- --------------------------------------------------------

-- 
-- Table structure for table `trip`
-- 

CREATE TABLE `trip` (
  `TRIP_ID` varchar(6) collate utf8_unicode_ci NOT NULL,
  `SOURCE_STATION` varchar(4) collate utf8_unicode_ci NOT NULL,
  `DESTINATION_STATION` varchar(4) collate utf8_unicode_ci NOT NULL,
  `DISTANCE` int(4) unsigned NOT NULL default '0',
  `CLASS` varchar(1) collate utf8_unicode_ci NOT NULL,
  `PRICE` varchar(5) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`TRIP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `trip`
-- 

INSERT INTO `trip` (`TRIP_ID`, `SOURCE_STATION`, `DESTINATION_STATION`, `DISTANCE`, `CLASS`, `PRICE`) VALUES ('N0001A', 'C001', 'C015', 30, 'A', '50'),
('N0002A', 'C001', 'C020', 71, 'A', '100'),
('N0003A', 'C001', 'N025', 0, 'A', '150'),
('N0004A', 'C001', 'N030', 142, 'A', '200'),
('N0005A', 'C001', 'N035', 199, 'A', '250'),
('N0006A', 'C001', 'N040', 237, 'A', '300'),
('N0007A', 'C001', 'N045', 358, 'A', '350'),
('N0008A', 'C001', 'N050', 420, 'A', '400'),
('N0009A', 'C001', 'N080', 610, 'A', '450'),
('N0010A', 'C001', 'N085', 669, 'A', '500'),
('N0011A', 'C001', 'N090', 713, 'A', '550');

-- --------------------------------------------------------

-- 
-- Table structure for table `trip_in_path`
-- 

CREATE TABLE `trip_in_path` (
  `PATH_ID` varchar(2) collate utf8_unicode_ci NOT NULL,
  `TRIP_SEQ` varchar(2) collate utf8_unicode_ci NOT NULL,
  `TRIP_ID` varchar(6) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`PATH_ID`,`TRIP_SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `trip_in_path`
-- 

INSERT INTO `trip_in_path` (`PATH_ID`, `TRIP_SEQ`, `TRIP_ID`) VALUES ('13', '01', 'N0001A'),
('13', '02', 'N0002A'),
('13', '03', 'N0003A'),
('13', '04', 'N0004A'),
('13', '05', 'N0005A'),
('13', '06', 'N0006A'),
('13', '07', 'N0007A'),
('13', '08', 'N0008A'),
('13', '09', 'N0009A'),
('13', '10', 'N0010A'),
('13', '11', 'N0011A');

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `USER_ID` varchar(10) collate utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) collate utf8_unicode_ci NOT NULL,
  `PERMISSION` varchar(5) collate utf8_unicode_ci NOT NULL,
  `USER_NAME` varchar(20) collate utf8_unicode_ci NOT NULL,
  `USER_SURNAME` varchar(40) collate utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`USER_ID`, `PASSWORD`, `PERMISSION`, `USER_NAME`, `USER_SURNAME`) VALUES ('admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'admin', 'พาศน์', 'ปัทมเบญจกุล'),
('s6010514', '*CE4805F4065BA882516D0B773C0CA075079BC7B0', 'staff', 'พาศน์', 'ปัทมเบญจกุล'),
('pek', '*53F1E4C69B25E77053E05F325A3AFBA452963583', 'staff', 'วิศณุ', 'ตันตราจิณ');
