#pragma once
#include <cstdlib>
#include <string>
#include <time.h>
#include "grid.h"

class Obstacle :
	public Grid
{
	int		point;
	int		width;
	int		height;
	int		osize;
	int*	plain;
public:
	Obstacle(void);
	Obstacle(int p,int w, int h);
	~Obstacle(void);
	int* GetPlain();
	int GetPoint();
	int GetWidth();
	int GetHeight();
	int	GetSize();
////////////FORD MODIFY/////////////
	void CopyObstacle(Obstacle *ob)
	{
		point = ob->GetPoint();
		width = ob->GetWidth();
		height = ob->GetHeight();
		delete []plain;

		plain = GetArea(point,width,height);
		osize = width*height;
	}
////////////����ҹ��///////////////	
};
