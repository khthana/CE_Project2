// pr_1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "pr_1.h"
#include "pr_1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// Cpr_1Dlg dialog




Cpr_1Dlg::Cpr_1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(Cpr_1Dlg::IDD, pParent)
	, outbox_value(_T(""))
	, stpoint(0)
	, sppoint(255)
	, poplmt(110)
	, maxgen(1000)
	, stoptime(100)
	, maxgnmlen(0)
	, crosspb(0.4)
	, swappb(0.2)
	, mutatepb(0.2)
	, linereppb(0.5)
	, deletepb(0.5)
	, improvepb(0.7)
	, in_nrun(10)
	, in_showgen(0)
	, out_gen(0)
	, out_fit(0)
	, runtime(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Cpr_1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT5, stpoint);
	DDX_Text(pDX, IDC_EDIT6, sppoint);
	DDX_Text(pDX, IDC_EDIT7, poplmt);
	DDX_Text(pDX, IDC_EDIT8, maxgen);
	DDX_Text(pDX, IDC_EDIT9, stoptime);
	DDX_Text(pDX, IDC_EDIT10, maxgnmlen);
	DDX_Text(pDX, IDC_EDIT11, crosspb);
	DDX_Text(pDX, IDC_EDIT12, swappb);
	DDX_Text(pDX, IDC_EDIT13, mutatepb);
	DDX_Text(pDX, IDC_EDIT14, linereppb);
	DDX_Text(pDX, IDC_EDIT15, deletepb);
	DDX_Text(pDX, IDC_EDIT16, improvepb);
	DDX_Text(pDX, IDC_EDIT2, in_nrun);
	DDX_Text(pDX, IDC_EDIT3, in_showgen);
	DDX_Text(pDX, IDC_EDIT4, out_gen);
	DDX_Text(pDX, IDC_EDIT18, out_fit);
	DDX_Text(pDX, IDC_EDIT17, runtime);
	DDX_Text(pDX, IDC_EDIT1, outbox_value);
	DDX_Control(pDX, IDC_EDIT1, outbox);
}

BEGIN_MESSAGE_MAP(Cpr_1Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &Cpr_1Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Cpr_1Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Cpr_1Dlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &Cpr_1Dlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &Cpr_1Dlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &Cpr_1Dlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &Cpr_1Dlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &Cpr_1Dlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &Cpr_1Dlg::OnBnClickedButton9)
	ON_EN_KILLFOCUS(IDC_EDIT5, &Cpr_1Dlg::OnEnKillfocusEdit5)
	ON_EN_KILLFOCUS(IDC_EDIT6, &Cpr_1Dlg::OnEnKillfocusEdit6)
END_MESSAGE_MAP()


// Cpr_1Dlg message handlers

BOOL Cpr_1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	srand( (unsigned)time( NULL ) );

	init_chk = false;
	mapchange_chk = false;
	ground.AddObstacle(226,3,3);
	ground.AddObstacle(200,8,2);
	ground.AddObstacle(128,3,1);
	ground.AddObstacle(134,4,2);
	ground.AddObstacle(142,1,4);
	ground.AddObstacle(48,8,2);	
	ground.AddObstacle(58,3,3);

/*	ground.AddObstacle(209,11,2);
	ground.AddObstacle(177,2,9);
	ground.AddObstacle(186,2,9);
*/
/*	ground.AddObstacle(251,2,3);
	ground.AddObstacle(216,2,6);
	ground.AddObstacle(180,2,5);
	ground.AddObstacle(172,2,6);
	ground.AddObstacle(81,2,4);
	ground.AddObstacle(88,3,3);
	ground.AddObstacle(69,2,5);
*/
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Cpr_1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cpr_1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cpr_1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void Cpr_1Dlg::DrawMap(CDC* dc)
{
	CDC dcMem;
	dcMem.CreateCompatibleDC(dc);
	CBitmap bmp1;
	bmp1.LoadBitmap(IDB_BITMAP1);
	CBitmap* pbmpOld = dcMem.SelectObject(&bmp1);
//	dc->BitBlt(10,10,50,50,&dcMem,0,0,SRCCOPY);
//	dcMem.SelectObject(pbmpOld);

	int x,y,sx,sy,width,gx,gy;
	Obstacle *t_ob;

	sx = 10; sy = 10; gx = ground.GetGridX(); gy = ground.GetGridY();
	if (gx > gy) width = 320/gx; else width = 320/gy;
//draw FreeGrid grid by grid
/*	for (int i = 0; i < ground.GetFreeGrid().size(); i++)
	{
		x = GetX(ground.GetFreeGrid()[i]) *20;
		y = (15 - GetY(ground.GetFreeGrid()[i])) *20;
		dc->Rectangle(sx+x,sy+y,sx+x+20,sy+y+20);
	}
*/
/*	dc->SelectObject(br1);
	for (int i = 0; i < ground.GetNumObs(); i++)
	{
		t_ob = &(ground.GetObstacle()[i]);
		x = ground.GetX(t_ob->GetPoint()) *width;
		y = (gy-1 -  ground.GetY(t_ob->GetPoint())) *width;
		dc->Rectangle(sx+x,sy+y,sx+x+(t_ob->GetWidth()*width),sy+y+(t_ob->GetHeight()*width));
	}
*/
	//draw Obstacle grid by grid
	dc->Rectangle(sx,sy,sx+width*gx,sy+width*gy);
	for (int i = 0; i < ground.GetNumObs(); i++)
	{
		t_ob = &(ground.GetObstacle()[i]);
		for (int j = 0; j < t_ob->GetSize(); j++)
		{
			x = ground.GetX(t_ob->GetPlain()[j]) *width;
			y = (gy-1 - ground.GetY(t_ob->GetPlain()[j])) *width;
			dc->StretchBlt(sx+x,sy+y,width,width,&dcMem,0,0,50,50,SRCCOPY);
		}
	}

	for (int i = 1; i < gy; i++)
	{
		dc->MoveTo(sx			,sy+(i*width));
		dc->LineTo(sx+(gx*width),sy+(i*width));
	}
	for (int i = 1; i < gx; i++)
	{
		dc->MoveTo(sx+(i*width)	,sy);
		dc->LineTo(sx+(i*width)	,sy+(gy*width));
	}
}
void Cpr_1Dlg::DrawPath(CDC *dc, std::vector<int> *tmp)
{
	int x,y,sx,sy,width,gx,gy;
	HBRUSH br,br_old;
	HPEN pn,pn_old;

	sx = 10; sy = 10; gx = ground.GetGridX(); gy = ground.GetGridY();
	if (gx > gy) width = 320/gx; else width = 320/gy;

	br_old = CreateSolidBrush(dc->GetDCBrushColor());
	pn_old = CreatePen(0,0,dc->GetDCPenColor());
	br = CreateSolidBrush(RGB(255,0,0));
	pn = CreatePen(4,2,RGB(255,64,123));

	dc->SelectObject(br);

	x = ground.GetX((*tmp)[0]) *width;
	x += width/2;
	y = (gy-1 - ground.GetY((*tmp)[0])) *width;
	y += width/2;
	dc->MoveTo(sx+x,sy+y);
	for (int i = 1; i < (*tmp).size(); i++)
	{
		x = ground.GetX((*tmp)[i]) *width;
		x += width/2;
		y = (gy-1 - ground.GetY((*tmp)[i])) *width;	
		y += width/2;
		dc->SelectObject(pn);
		dc->LineTo(sx+x,sy+y);
		dc->SelectObject(pn_old);
		dc->Ellipse(sx+x-3,sy+y-3,sx+x+4,sy+y+4);
	}
	dc->SelectObject(br_old);
	dc->SelectObject(pn_old);
}
void Cpr_1Dlg::DrawStSpPoint(CDC *dc)
{
	int x,y,width,gx,gy;
	HBRUSH br,br_old;
	HPEN pn,pn_old;

	gx = ground.GetGridX(); gy = ground.GetGridY();
	if (gx > gy) width = 320/gx; else width = 320/gy;

	br_old = CreateSolidBrush(dc->GetDCBrushColor());
	pn_old = CreatePen(0,0,dc->GetDCPenColor());
	pn = CreatePen(0,2,RGB(0,0,255));
	br = CreateSolidBrush(RGB(255,0,0));

	dc->SelectObject(br);
	dc->SelectObject(pn);
	x = ground.GetX(stpoint) *width;
	x += 10 + width/2;
	y = (gy-1 - ground.GetY(stpoint)) *width;
	y += 10 + width/2;
	dc->Ellipse(x-5,y-5,x+5,y+5);
	x = ground.GetX(sppoint) *width;
	x += 10 + width/2;
	y = (gy-1 - ground.GetY(sppoint)) *width;
	y += 10 + width/2;
	dc->Ellipse(x-5,y-5,x+5,y+5);
	dc->SelectObject(br_old);
	dc->SelectObject(pn_old);
}
void Cpr_1Dlg::AddGenomePath(vector<int> *tmp)
{
	int length = tmp->size();
	char str[10];
	outbox_value += "|";
	for (int i = 0; i < length; i++)
	{
		sprintf(str,"%d",(*tmp)[i]);
		outbox_value += str;
		if (i+1 < length) outbox_value += ".";
	}
	outbox_value += "|";
}
//Reinitial Population
void Cpr_1Dlg::OnBnClickedButton5()
{
	char str[32];
	float rt = 0;
	clock_t clk,clk_old;

	if (ground.GetGrid()[sppoint] == 1 || ground.GetGrid()[stpoint] == 1)
	{
		CString cstr;
		cstr = "Selected start/stop point is in the obstacle.";
		MessageBox(cstr,0,0);
		return;
	}
	SetstatusControl(0,0);
	SetstatusControl(1,1);
	UpdateData(1);
	stop_count = 1;
	BestHistory.clear();
	BestFitHistory.clear();
	clk_old = clock();

	TestPop.SetAttribute(poplmt,crosspb,swappb,mutatepb,linereppb,deletepb,improvepb);
	TestPop.DoInitialize(stpoint,sppoint,maxgnmlen,ground.GetGrid());
	clk = clock();
	rt = clk - clk_old;
	runtime = rt/CLOCKS_PER_SEC;
	init_chk = true;

	BestHistory.push_back(TestPop.GetBestGenome().GetGenesList());
	BestFitHistory.push_back(TestPop.GetBestGenome().GetFitness());

	out_gen = TestPop.GetGenNumber();
	in_showgen = out_gen;
	out_fit = TestPop.GetBestGenome().GetFitness();
	sprintf(str,"Generation %d Fitness %d ",out_gen,out_fit);
	outbox_value = str;
	AddGenomePath(&(BestHistory[0]));
	outbox_value += "\r\n";
	UpdateData(FALSE);
	outbox.LineScroll(outbox.GetLineCount(),0);
	CDC *dc = GetDC();
	DrawMap(dc);
	DrawPath(dc,&(BestHistory[0]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
//Run a RUN
void Cpr_1Dlg::OnBnClickedButton1()
{
	char str[32];
	float rt = 0;
	clock_t clk,clk_old;
	Genome tmp = TestPop.GetBestGenome();
	clk_old = clock();

		TestPop.DoSelection();
		TestPop.DoLineRepair(ground.GetObstacle(),ground.GetNumObs());
		TestPop.DoCrossover();
		TestPop.DoMutation();
		TestPop.DoSwap();
		TestPop.DoDeletion();
		TestPop.DoImprovement();
		TestPop.DoEvaluation();
		TestPop.DoRepresentation();
		
		if(tmp == TestPop.GetBestGenome())
		{	stop_count++; }
		else {
			stop_count =1;
			tmp = TestPop.GetBestGenome();
		};
		clk = clock();
		rt = clk - clk_old;
		runtime += rt/CLOCKS_PER_SEC;

		BestHistory.push_back(tmp.GetGenesList());
		BestFitHistory.push_back(TestPop.GetBestGenome().GetFitness());

		out_gen = TestPop.GetGenNumber();
		in_showgen = out_gen;
		out_fit = tmp.GetFitness();
		sprintf(str,"Generation %d Fitness %d ",out_gen,out_fit);
		outbox_value += str;
		AddGenomePath(&(BestHistory[out_gen-1]));
		outbox_value += "\r\n";
		UpdateData(FALSE);
		outbox.LineScroll(outbox.GetLineCount(),0);
		CDC *dc = GetDC();
		DrawMap(dc);
		DrawPath(dc,&(BestHistory[out_gen-1]));
		DrawStSpPoint(dc);
		ReleaseDC(dc);
}
//Run n RUNs
void Cpr_1Dlg::OnBnClickedButton2()
{
	char str[32];
	int count = 0;
	float rt = 0;
	clock_t clk,clk_old;
	CDC *dc = GetDC();

	Genome tmp = TestPop.GetBestGenome();

	UpdateData(TRUE);
	while(count < in_nrun)
	{
		clk_old = clock();

		TestPop.DoSelection();
		TestPop.DoLineRepair(ground.GetObstacle(),ground.GetNumObs());
		TestPop.DoCrossover();
		TestPop.DoMutation();
		TestPop.DoSwap();
		TestPop.DoDeletion();
		TestPop.DoImprovement();
		TestPop.DoEvaluation();
		TestPop.DoRepresentation();

		if(tmp == TestPop.GetBestGenome())
		{	stop_count++; }
		else {
			stop_count =1;
			tmp = TestPop.GetBestGenome();
		};
		clk = clock();
		rt = clk - clk_old;
		runtime += rt/CLOCKS_PER_SEC;
		
		BestHistory.push_back(tmp.GetGenesList());
		BestFitHistory.push_back(TestPop.GetBestGenome().GetFitness());

		if (stop_count == 1 || count == in_nrun-1)
		{
			out_gen = TestPop.GetGenNumber();
			in_showgen = out_gen;
			out_fit = tmp.GetFitness();
			sprintf(str,"Generation %d Fitness %d ",out_gen,out_fit);
			outbox_value += str;
			AddGenomePath(&(BestHistory[out_gen-1]));
			outbox_value += "\r\n";
			UpdateData(FALSE);
			outbox.LineScroll(outbox.GetLineCount(),0);
			DrawMap(dc);
			DrawPath(dc,&(BestHistory[out_gen-1]));
			DrawStSpPoint(dc);
		}
		count++;
	}
	ReleaseDC(dc);
}
//Run til Fin
void Cpr_1Dlg::OnBnClickedButton3()
{
	char str[32];
	float rt = 0;
	clock_t clk,clk_old;
	CDC *dc = GetDC();

	Genome tmp = TestPop.GetBestGenome();

	UpdateData(TRUE);
	while(stop_count < stoptime)
	{
		clk_old = clock();

		TestPop.DoSelection();
		TestPop.DoLineRepair(ground.GetObstacle(),ground.GetNumObs());
		TestPop.DoCrossover();
		TestPop.DoMutation();
		TestPop.DoSwap();
		TestPop.DoDeletion();
		TestPop.DoImprovement();
		TestPop.DoEvaluation();
		TestPop.DoRepresentation();

		if(tmp == TestPop.GetBestGenome())
		{	stop_count++; }
		else {
			stop_count =1;
			tmp = TestPop.GetBestGenome();
		};
		clk = clock();
		rt = clk - clk_old;
		runtime += rt/CLOCKS_PER_SEC;

		BestHistory.push_back(tmp.GetGenesList());
		BestFitHistory.push_back(TestPop.GetBestGenome().GetFitness());

		if (stop_count == 1 || stop_count == 100)
		{
			out_gen = TestPop.GetGenNumber();
			in_showgen = out_gen;
			out_fit = tmp.GetFitness();
			sprintf(str,"Generation %d Fitness %d ",out_gen,out_fit);
			outbox_value += str;
			AddGenomePath(&(BestHistory[out_gen-1]));
			outbox_value += "\r\n";
			UpdateData(FALSE);
			outbox.LineScroll(outbox.GetLineCount(),0);
			DrawMap(dc);
			DrawPath(dc,&(BestHistory[out_gen-1]));
			DrawStSpPoint(dc);
		}
	}
	ReleaseDC(dc);
}
//Show Best Genome in specific Generation
void Cpr_1Dlg::OnBnClickedButton9()
{
	UpdateData(TRUE);
	if (in_showgen <= 0 || in_showgen > BestHistory.size()) return;
	CDC *dc = GetDC();
	DrawMap(dc);
	DrawPath(dc,&(BestHistory[in_showgen-1]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
//Stop running
void Cpr_1Dlg::OnBnClickedButton6()
{
	ground.GetGrid()[sppoint] = 0;
	ground.GetGrid()[stpoint] = 0;
	SetstatusControl(0,1);
	SetstatusControl(1,0);
	CDC *dc = GetDC();
	DrawMap(dc);
	DrawPath(dc,&(BestHistory[out_gen-1]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
//Show history Best Gemone
void Cpr_1Dlg::OnBnClickedButton4()
{
	CDC *dc = GetDC();
	UpdateData(TRUE);
	int sz;
	if (stop_count >= stoptime)
		sz = BestHistory.size()-99;
	else sz = BestHistory.size();

	for (int i = 0; i < sz; i++)
	{
		DrawMap(dc);
		DrawPath(dc,&(BestHistory[i]));
		DrawStSpPoint(dc);
		Sleep(in_showgen);
	}
	ReleaseDC(dc);
}
//Environment editor
void Cpr_1Dlg::OnBnClickedButton7()
{
	Mapplan mapDlg;
	mapDlg.ground_old = &ground;
	Ground ground_new;
	mapDlg.ground = &ground_new;
	if (mapDlg.DoModal() == IDOK)
	{
		if (mapDlg.ground->GetSize() < mapDlg.gridx_old*mapDlg.gridy_old)
		{
			int x,y;
			x = ground_new.GetGridX();
			y = ground_new.GetGridY();
			ground.SetGridX(mapDlg.gridx_old);
			ground.SetGridY(mapDlg.gridy_old);
			ground.ResetEnvironment();
			ground.SetGridX(x);
			ground.SetGridY(y);
			ground.CopyGround(&ground_new);
		}else
		{
		ground.CopyGround(&ground_new);
		}
		sppoint = ground.GetSize()-1;
		UpdateData(FALSE);
	}else
	{
		ground.SetGridX(mapDlg.gridx_old);
		ground.SetGridY(mapDlg.gridy_old);
	}
	CDC *dc = GetDC();
	DrawMap(dc);
	if (init_chk) DrawPath(dc,&(BestHistory[out_gen-1]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
//Graph view
void Cpr_1Dlg::OnBnClickedButton8()
{
	ViewGraph *graphDlg = new ViewGraph();
	graphDlg->BestFit = &BestFitHistory;
	if (stop_count >= stoptime)
		graphDlg->fin = true;
	else graphDlg->fin = false;
	graphDlg->ShowWindow(SW_SHOW);
}
//Local Fn for enable/disable control of app
void Cpr_1Dlg::SetstatusControl(int grp,bool chk)
{
	switch (grp){
		case 0 :	GetDlgItem(IDC_EDIT5)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT6)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT7)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT8)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT9)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT10)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT11)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT12)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT13)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT14)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT15)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT16)->EnableWindow(chk);
					GetDlgItem(IDC_BUTTON5)->EnableWindow(chk);
					GetDlgItem(IDC_BUTTON7)->EnableWindow(chk);
					break;

		case 1 :	GetDlgItem(IDC_BUTTON1)->EnableWindow(chk);
					GetDlgItem(IDC_BUTTON2)->EnableWindow(chk);
					GetDlgItem(IDC_BUTTON3)->EnableWindow(chk);
					GetDlgItem(IDC_BUTTON6)->EnableWindow(chk);
					GetDlgItem(IDC_EDIT2)->EnableWindow(chk);
					break;
	}
}
void Cpr_1Dlg::OnEnKillfocusEdit5()
{
	UpdateData(TRUE);
	if (stpoint >= ground.GetSize())
	{
		stpoint = ground.GetSize()-1;
		UpdateData(FALSE);
	}
	CDC *dc = GetDC();
	DrawMap(dc);
	if (init_chk) DrawPath(dc,&(BestHistory[out_gen-1]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
void Cpr_1Dlg::OnEnKillfocusEdit6()
{
	UpdateData(TRUE);
	if (sppoint >= ground.GetSize())
	{
		sppoint = ground.GetSize()-1;
		UpdateData(FALSE);
	}
	CDC *dc = GetDC();
	DrawMap(dc);
	if (init_chk) DrawPath(dc,&(BestHistory[out_gen-1]));
	DrawStSpPoint(dc);
	ReleaseDC(dc);
}
