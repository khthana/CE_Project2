#include "StdAfx.h"
#include "Obstacle.h"

Obstacle::Obstacle(void)
{
////////////FORD MODIFY/////////////
	plain = new int[];
////////////����ҹ��///////////////	
}

Obstacle::Obstacle(int p,int w, int h)
{
	point = p;
	width = w;
	height = h;

	if ((GetX(point) + (width-1)) > (gridX-1))
	{ width = gridX - GetX(point);};
	if ((point - (gridX *(height-1))) < 0)
	{ height = GetY(point)+ 1 ;};
		
	plain = GetArea(p,w,h);
	osize = w*h;
}

Obstacle::~Obstacle(void)
{
////////////FORD MODIFY/////////////
	delete []plain;
////////////����ҹ��///////////////	
}

int* Obstacle::GetPlain()
{	return plain;};
int Obstacle::GetPoint()
{	return point;};
int Obstacle::GetWidth()
{	return width;};
int Obstacle::GetHeight()
{	return height;};
int Obstacle::GetSize()
{	return osize;};
