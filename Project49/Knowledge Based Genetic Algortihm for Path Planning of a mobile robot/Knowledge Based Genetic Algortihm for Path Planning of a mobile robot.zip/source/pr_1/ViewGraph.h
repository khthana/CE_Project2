#pragma once
#include "Population.h"

using namespace std;

// ViewGraph dialog

class ViewGraph : public CDialog
{
	DECLARE_DYNAMIC(ViewGraph)

public:
	ViewGraph(CWnd* pParent = NULL);   // standard constructor
	virtual ~ViewGraph();

// Dialog Data
	enum { IDD = IDD_GraphDlg };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL DestroyWindow();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	vector<int> *BestFit;
	bool fin;
};
