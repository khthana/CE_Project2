//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pr_1.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PR_1_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_MapPlanDlg                  129
#define IDD_GraphDlg                    130
#define IDB_BITMAP1                     131
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_BUTTON2                     1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_BUTTON3                     1006
#define IDC_BUTTON4                     1007
#define IDC_BUTTON5                     1008
#define IDC_EDIT5                       1009
#define IDC_EDIT6                       1010
#define IDC_EDIT7                       1011
#define IDC_EDIT8                       1012
#define IDC_EDIT9                       1013
#define IDC_EDIT10                      1014
#define IDC_EDIT11                      1015
#define IDC_EDIT12                      1016
#define IDC_EDIT13                      1017
#define IDC_EDIT14                      1018
#define IDC_BUTTON6                     1019
#define IDC_BUTTON7                     1020
#define IDC_BUTTON8                     1021
#define IDC_EDIT15                      1022
#define IDC_EDIT16                      1023
#define IDC_EDIT17                      1024
#define IDC_BUTTON9                     1025
#define IDC_EDIT18                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
