#pragma once
#include <vector>
#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

class Grid
{
protected:
	static int gridX;
	static int gridY;
	static int size;
public:
	Grid(void);
	~Grid(void);
	static int GetGridX()
	{	return gridX;	};
	static int GetGridY()
	{	return gridY;	};
	static int GetSize()
	{	return size;	};
	static void SetGridX(int x)
	{	gridX = x;
		size = gridX*gridY;	};
	static void SetGridY(int y)
	{	gridY = y;	
		size = gridX*gridY;};
	
	static void show();
	static int	GetX(int);
	static int GetY(int);
////////////FORD MODIFY/////////////
//	static int GetDistance(int , int );
	static float GetDistance(int , int );
////////////����ҹ��///////////////	
	static vector<int> GetLineVector(int , int);
	static vector<int> GetNeighbor(int );
	static int* GetArea(int , int, int);
};

