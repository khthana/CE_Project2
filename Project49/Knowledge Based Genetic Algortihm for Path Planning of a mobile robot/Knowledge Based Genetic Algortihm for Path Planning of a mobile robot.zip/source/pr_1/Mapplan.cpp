// Mapplan.cpp : implementation file
//

#include "stdafx.h"
#include "pr_1.h"
#include "pr_1Dlg.h"
#include "Mapplan.h"


// Mapplan dialog

IMPLEMENT_DYNAMIC(Mapplan, CDialog)

Mapplan::Mapplan(CWnd* pParent /*=NULL*/)
	: CDialog(Mapplan::IDD, pParent)
	, obpoint(0)
	, obwidth(0)
	, obheight(0)
	, gridx(ground_old->GetGridX())
	, gridy(ground_old->GetGridY())
	, gridx_old(ground_old->GetGridX())
	, gridy_old(ground_old->GetGridY())
{

}

Mapplan::~Mapplan()
{
}

void Mapplan::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, obpoint);
	DDX_Text(pDX, IDC_EDIT2, obwidth);
	DDX_Text(pDX, IDC_EDIT3, obheight);
	DDX_Text(pDX, IDC_EDIT4, gridx);
	DDX_Text(pDX, IDC_EDIT5, gridy);
}

BEGIN_MESSAGE_MAP(Mapplan, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &Mapplan::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Mapplan::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Mapplan::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &Mapplan::OnBnClickedButton4)
END_MESSAGE_MAP()


// Mapplan message handlers

void Mapplan::DrawMap(CDC* dc)
{
	int x,y,sx,sy,width,gx,gy;
	HBRUSH br;
	Obstacle *t_ob;

	sx = 10; sy = 10; gx = ground->GetGridX(); gy = ground->GetGridY();
	if (gx > gy) width = 160/gx; else width = 160/gy;

	dc->Rectangle(sx,sy,sx+width*gx,sy+width*gy);

	br = CreateSolidBrush(RGB(255,127,0));
	dc->SelectObject(br);
	for (int i = 0; i < ground->GetNumObs(); i++)
	{
		t_ob = &(ground->GetObstacle()[i]);
		x = ground->GetX(t_ob->GetPoint()) *width;
		y = (gy-1 - ground->GetY(t_ob->GetPoint())) *width;
		dc->Rectangle(sx+x,sy+y,sx+x+(t_ob->GetWidth()*width),sy+y+(t_ob->GetHeight()*width));
	}
	for (int i = 1; i < gy; i++)
	{
		dc->MoveTo(sx			,sy+(i*width));
		dc->LineTo(sx+(gx*width),sy+(i*width));
	}
	for (int i = 1; i < gx; i++)
	{
		dc->MoveTo(sx+(i*width)	,sy);
		dc->LineTo(sx+(i*width)	,sy+(gy*width));
	}
	br = CreateSolidBrush(RGB(255,255,255));
	dc->SelectObject(br);
}
//Add obstacle
void Mapplan::OnBnClickedButton1()
{
	UpdateData(TRUE);
	ground->AddObstacle(obpoint,obwidth,obheight);
	CDC *dc = GetDC();
	DrawMap(dc);
	ReleaseDC(dc);
}
//Clear Map
void Mapplan::OnBnClickedButton2()
{
	ground->ResetEnvironment();
	CDC *dc = GetDC();
	DrawMap(dc);
	ReleaseDC(dc);
}
//Use old Map
void Mapplan::OnBnClickedButton3()
{
	ground->ResetEnvironment();
	ground->SetGridX(gridx_old);
	ground->SetGridY(gridy_old);
	ground->CopyGround(ground_old);
	gridx = ground->GetGridX();
	gridy = ground->GetGridY();
	UpdateData(FALSE);
	CDC *dc = GetDC();
	DrawMap(dc);
	ReleaseDC(dc);
}
//set Map size
void Mapplan::OnBnClickedButton4()
{
	UpdateData(TRUE);
	ground->ResetEnvironment();
	ground->SetGridX(gridx);
	ground->SetGridY(gridy);
//	GetDlgItem(IDC_BUTTON3)->EnableWindow(0);
	CDC *dc = GetDC();
	DrawMap(dc);
	ReleaseDC(dc);
}
