#include "StdAfx.h"
#include "Genome.h"
#include "Population.h"

Genome::Genome(void)
{
	Fitness = 0;
	linealfa = 0;
	constant = 20;
	LineSegment[0] = 0;
	LineSegment[1] = 0;
}

Genome::~Genome(void)
{
}

int		Genome::CheckLine(int point1, int point2,bool* Grid)//check whether the line is produced by point1 and point2 is intersectd obstacle
{
		int fit = 0; 
		if(point1==point2)
		{return fit;};

		const vector<int> &temp=GetLineVector(point1,point2);
		if(temp.size() == 0)
		{	return 0;};
		
		for(int j = 0; j<temp.size(); j++)
		{
			if(Grid[temp[j]] == 1)
			{	fit++;	};
		};
		return fit;
	};
int		Genome::CheckLine(int point1,bool* Grid)//check whether point1 is intersected obstacle
	{
		int	temp = 0;
		int point0,point2;
		point0 = GenesList[point1-1];
		point2 = GenesList[point1+1];
		point1 = GenesList[point1];

		temp = CheckLine(point0,point1,Grid) + CheckLine(point1,point2,Grid);

		return temp;
	};
void	Genome::GetGenomeValue()
	{
		cout<<"|";
		for (int i = 0;i < length;i++)
		{
			cout << GenesList[i] ;
			if (i+1 < length){	cout << ".";};
		};
		cout<<"| length = "<< length <<"; fitness = "<<Fitness<<" ; line alfa = "<< linealfa<<endl;
	};
////////////FORD MODIFY/////////////
char*	Genome::GetGenomeString()
{
	char str[512],tmp[10];
	strcpy(str,"|");
	for (int i = 0; i < length; i++)
	{
		sprintf(tmp,"%d",GenesList[i]);
		strcat(str,tmp);
		if (i+1 < length) strcat(str,".");
	}
	strcat(str,"|");
	return str;
}
////////////����ҹ��///////////////	
int		Genome::GetLength()
	{	return length;};
int		Genome::GetFitness()
	{	return Fitness;	};
int		Genome::GetLineSegment()
	{	return linealfa; };
vector<int> Genome::GetGenesList()
	{	return	GenesList;	};
void	Genome::Initialize(int start, int end,int msize,bool* Grid)
	{
		int gene,countFree = 0;
		bool* FreeGrid = new bool[Grid::size];
		for(int i = 0; i<Grid::size; i++)
		{	
			FreeGrid[i] = Grid[i];
			if(Grid[i] == 0)
			{	countFree++;	};
		};
		if(msize == 0)
		{	countFree = int(countFree/4);}
		else { countFree = msize;};
		//cout<<countFree<<endl;
		//cout<<"prepare random"<<endl;
		length = (rand() % (countFree-1)) + 2 ;//random genome's length
		GenesList.push_back(start);
		//cout<<length<<endl;
			
		for (int i = 1;i < (length-1);i++)
		{		//cout<<countFree<< " "<<length<<endl;	
			int tmp = 0;
			do{	if(tmp>(length*2)){break;};
				gene = rand() % Grid::size;	
				tmp++;
			}while(FreeGrid[gene] == 1);
			if(tmp>(length*2)){length = GenesList.size(); break;};
			GenesList.push_back(gene);
			FreeGrid[gene] = 1;//delete selected value
		};
		GenesList.push_back(end);
		delete []FreeGrid;
	};	
int		Genome::CalculateFitness(bool* Grid)
	{
		float	distance=0;
		int one,two,tmp=0;
		Fitness = 0;
		linealfa = 0;
		SectionFitness = 0;
		LineSegment[0] = 0;
		LineSegment[1] = 0;
		
		//cout<<"check fitness"<<endl;
		for (int i = 1; i<length; i++)
		{	
			if(GenesList[i-1]<GenesList[i])
			{
				one = GenesList[i-1];
				two = GenesList[i]; }
			else {	one = GenesList[i];
					two = GenesList[i-1]; };
			distance += GetDistance(one,two); //distance between 2 points
			//cout<<"gene "<<GenesList[i-1]<<" and "<<GenesList[i]<<" has distance = "<< distance<<endl;
			
			tmp = CheckLine(one,two,Grid);
			if ((LineSegment[0] == LineSegment[1])&&(tmp!=0))
			{
				//cout<<" stuck at "<<i;
				LineSegment[0] = (i-1);
				LineSegment[1]= (i);
				SectionFitness = GetDistance(one,two) + (tmp * constant);
			};
			linealfa += tmp;				
		};

		//cout<<" linealfa = "<<linealfa<<endl;
		Fitness= distance + (linealfa *constant);
		//cout<<"Calculated..."<<endl;
		return Fitness;
	};
void	Genome::Mutate(int point,bool* Grid)
	{	
		//GetGenomeValue();
		//cout<<"point "<<point<<endl;
		int	num;
		bool* FreeGrid = new bool[Grid::size];
		for(int i = 0; i<Grid::size; i++)
		{	FreeGrid[i] = Grid[i];}; 
		for (int j = 1; j<(length-1); j++)
		{	FreeGrid[GenesList[j]] = 1	;};
		int tmp = 0;
		do{
			if(tmp>(length*2)){break;};
			num = rand() % Grid::size;
			tmp++;}				
		while(FreeGrid[num] == 1);
		if(tmp>(length*2)){return;};
		GenesList[point] =num;
		//cout<<FreeGrid[num]<<endl;
		delete []FreeGrid;
		//GetGenomeValue();

		//cout<<"Mutation genome complete..."<<endl<<endl;
	};
void	Genome::Crossover(int point1,int point2,Genome parent)
	{
		GenesList.erase(GenesList.begin() + point1 ,GenesList.end());
		GenesList.insert(GenesList.end(),(parent.GenesList.begin()+point2), parent.GenesList.end());
		length = GenesList.size();
		
		for(int i = 0; i<length; i++)//delete path between two same nodes
		{
			for (int j = i+1; j<length; j++)
			{
				if (GenesList[i] == GenesList[j])
				{	
					if((j+1)!=length)
					{	GenesList.erase(GenesList.begin() + j);}
					else {GenesList.erase(GenesList.begin()+ i);};
					length = GenesList.size();
					i--;
					break;
				}				
			};
		};
		
		//cout<<"Crossover genomes complete..."<<endl<<endl;
	};
void	Genome::Linerepair(Obstacle* obs,int numobs,bool* Grid)
		// cut 2 genes that intersect with obstacle off
		// insert the result from GA instead
	{
		//GetGenomeValue();
		int x1=0,x2,y1,y2,node1,node2,node3,node4,start,end;
		node1 = GenesList[LineSegment[0]];
		node2 = GenesList[LineSegment[1]];
		
		const vector<int> &tmp=GetLineVector(node1,node2);
		for(int i =  0; i<numobs; i++)
		{
			int* plain = obs[i].GetPlain();
			for(int j = 0; j<tmp.size(); j++)
			{
				if(plain[i] == tmp[j])
				{	x1 = 1;
					break;	};					
			};
			if(x1 != 0)
			{	x1= i;
				break;};
		};
		
		node3 = obs[x1].GetPoint();
		node4 = node3 -((obs[x1].GetHeight()-1) * gridX)+ obs[x1].GetWidth()-1;	
		
		if(GetX(node1)<=GetX(node2))
		{	x1 = GetX(node1);	x2 = GetX(node2);}
		else {x1 = GetX(node2) ;	x2 = GetX(node1);};
		if(x1>GetX(node3))
		{	x1 = GetX(node3)-2;};
		if(x2 < GetX(node4))
		{	x2 = GetX(node4)+2;};
		if(GetY(node1)<=GetY(node2))
		{	y1 = GetY(node1);	y2 = GetY(node2);}
		else {y1 = GetY(node2) ;	y2 = GetY(node1);};
		if(y1>GetY(node4))
		{	y1 = GetY(node4)-2;};
		if(y2 < GetY(node3))
		{	y2 = GetY(node3)+2;};

		if(x1<0){x1 = 0;};
		if(y1<0){y1 = 0;};
		if(x2>=gridX){x2 = gridX-1;};
		if(y2>=gridY){y2 = gridY-1;};
		//cout<<node1<<" "<<node2<<" "<<node3<<" "<<node4;
		node3 =(abs(x1-x2)+1)*(abs(y1-y2)+1);
		//cout<<" "<<x1<<" "<< x2<<" "<<y1<<" "<<y2<<" "<<node3<<endl;
		bool* tempGrid = new bool[Grid::size];
		for(int i = 0; i< Grid::size; i++)
		{	tempGrid[i] = Grid[i];};
		for(int i = 1; i< length-1; i++)
		{	tempGrid[GenesList[i]] = 1;};
		//cout<<"tt"<<endl;
		bool* FreeGrid = new bool[node3];
		node4 = 0;
		
		//cout<<"node1 = "<<node1<<" node2 = "<<node2<<endl;
		for(int i = y1; i<= y2;i++)
		{
			int k;
			for(int j = x1; j<=x2; j++)
			{	
				k = (i*Grid::gridX) + j;
				if(k == node1)	{	start = node4;	};
				if(k == node2)	{	end = node4;	};
				FreeGrid[node4] = tempGrid[k];
				node4++;
			};
		};
		//cout<<endl;
		delete []tempGrid;
		node1 = gridX;
		node2 = gridY;
		Grid::SetGridX(abs(x1-x2)+1);
		Grid::SetGridY(abs(y1-y2)+1);
		Genome temp = NewLocalSearch(start,end,FreeGrid);
				
		Grid::SetGridX(node1);
		Grid::SetGridY(node2);
		//cout<<"temp's fitness = "<<temp.GetFitness()<<" section fitness = "<<SectionFitness<<endl;
		if(temp.GetFitness()<SectionFitness)
		{
			int sz = temp.GetLength();
			vector<int> genes = temp.GetGenesList();
			for(int l = 0; l<sz; l++)
			{
				int value = 0;
				node3 = 0;
				for(int i = y1; i<= y2;i++)
				{
					for(int j = x1; j<=x2; j++)
					{
						if(value == genes[l])
						{	
							node3 = 1;
							genes[l] = (i*gridX) + j;	
							//cout<<genes[l]<<" - "<<Grid[genes[l]]<<" ;";
							break;
						};
						value++;
					};
					if(node3 == 1)
					{	break;	};
				};
			};
			GenesList.erase(GenesList.begin() + LineSegment[0],GenesList.begin() + LineSegment[1] +1);
			GenesList.insert(GenesList.begin() + LineSegment[0],genes.begin(),genes.end());
			length = GenesList.size();
			//cout<<" i "<<endl;
			delete []FreeGrid;
		};
		//cout<<"Linerepair genome complete..."<<endl<<endl;
		
		//GetGenomeValue();
	};
void	Genome::Deletion(int point,bool* Grid)
	{
		int	tmp1,tmp2,node1,node2;
		
		if(GenesList[point+1] < GenesList[point-1])
		{
			node1 = GenesList[point+1];
			node2 = GenesList[point-1];
		} else {
			node1 = GenesList[point-1];
			node2 = GenesList[point+1]; 
		};

		tmp1 = GetDistance(GenesList[point],node1) + GetDistance(GenesList[point],node2);
		tmp2 = GetDistance(node1,node2);
		tmp1 += (CheckLine(GenesList[point],node1,Grid)+CheckLine(GenesList[point],node2,Grid))*10;
		tmp2 += (CheckLine(node1,node2,Grid)*10);

		if(tmp1>tmp2)
		{	
			GenesList.erase(GenesList.begin() + point);
			length = GenesList.size();
		};
		//cout<<"Deletion genome complete..."<<endl<<endl;
	};
void	Genome::Improve(int point,bool* Grid)
	{
		int tmp,rank=0;
		vector<int> neighbor;
		bool* FreeGrid = new bool[Grid::size];
		for(int i = 0; i<Grid::size; i++)
		{	FreeGrid[i] = Grid[i];}; 
		for (int i = 1; i<(length-1); i++)
		{	FreeGrid[GenesList[i]]=1;	};

		neighbor = GetNeighbor(GenesList[point]);
		tmp = GetDistance(GenesList[point],GenesList[point+1]) + GetDistance(GenesList[point],GenesList[point-1]);
		tmp += (CheckLine(GenesList[point],GenesList[point+1],FreeGrid)+CheckLine(GenesList[point],GenesList[point-1],FreeGrid))*10;
		
		for (int i = 0; i<neighbor.size(); )
		{
			if (FreeGrid[neighbor[i]] == 1)
			{
				neighbor.erase(neighbor.begin() + i);
				continue;
			};
			rank = (GetDistance(neighbor[i],GenesList[point+1]) + GetDistance(neighbor[i],GenesList[point-1]));
			rank += (CheckLine(neighbor[i],GenesList[point+1],FreeGrid)+CheckLine(neighbor[i],GenesList[point-1],FreeGrid))*10;
			if(rank < tmp)
			{	
				GenesList[point] = neighbor[i];	
				tmp = rank;
			};
			i++;
		};
		
		delete []FreeGrid;		
		//cout<<"Improve genome complete..."<<endl<<endl;
	};
void	Genome::Swap(int point1, int point2)
	{
		//cout<<"point1 = "<<point1<<" point2 = "<<point2<<endl;
		if (point1 == point2)
		{	return;};
		int	num = GenesList[point1];
		GenesList[point1] = GenesList[point2];
		GenesList[point2] = num;
		//cout<<"swap genome complete..."<<endl<<endl;
	};


bool	operator<(Genome& one, Genome& two) {
    return one.GetFitness() < two.GetFitness();
};
bool	operator>(Genome& one, Genome& two) {
    return one.GetFitness() > two.GetFitness();
};
bool	operator==(Genome& one, Genome& two) {
	if(one.GetLength() != two.GetLength())
	{	return false;};
	if(one.GetFitness() != two.GetFitness())
	{	return false;};
	return true;
};

Genome	NewLocalSearch(int start,int end,bool* freegrid)
{
	int count = 0;
	Population	utopia;
	utopia.SetAttribute(6,0.9,0.5,0.5,0.9,0.9,0.9);
	//cout<<"start"<<endl;
	utopia.DoInitialize(start,end,5,freegrid);
	Genome tmp = utopia.GetBestGenome();
	//tmp.GetGenomeValue();
	while((count<3)&&(utopia.GetGenNumber()<5))
	{
		//utopia.GetCurrPopulation();
		//cout<<"selection..."<<endl;
		utopia.DoSelection();
		//cout<<"Crossover..."<<endl;
		utopia.DoCrossover();
		//cout<<"Mutation..."<<endl;
		utopia.DoMutation();
		//cout<<"Evaluation..."<<endl;
		utopia.DoEvaluation();
		//cout<<"Representation..."<<endl;
		utopia.DoRepresentation();
		//cout<<"iterate..."<<endl;
		
		if(tmp == utopia.GetBestGenome())
		{	count++; }
		else {
			count =1;
			tmp = utopia.GetBestGenome();
		};
		//tmp.GetGenomeValue();
		//cout<<tmp.GetFitness()<<" ";
		//cout<<"count = "<<count<<" ; Utopia Generation = "<<utopia.GetGenNumber()<<endl;
	}
	//utopia.GetCurrPopulation();
	//cout<<"Solutions from "<<start<<" to "<<end<<" is ";
	//tmp.GetGenomeValue();
	return tmp;
};