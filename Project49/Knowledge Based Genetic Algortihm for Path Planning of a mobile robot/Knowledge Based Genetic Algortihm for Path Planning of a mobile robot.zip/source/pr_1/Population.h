#pragma once
#include "Genome.h"
////////////FORD MODIFY/////////////
////////////����ҹ��///////////////	

class Population :
	public Grid
{
	int		PopulationLimit;
	int		Generation;
	int		BestGen;	
	bool*	FreeGrid;
	float	CrossoverProb;
	float	SwapProb;
	float	MutationProb;
	float	LineRepProb;
	float	DeleteProb;
	float	ImproveProb;
	Genome	BestInGeneration;	
	Genome	BestSofar;
	Genome*	Genomes;
	Genome*	ResultGenomes;
public:
	//must set grid size before call Population's constructor
	Population();
	~Population(void);
	int		GetGenNumber();
	void	GetCurrPopulation();
	void	GetResPopulation();
	void	GetFitnessMin();
	void	GetFitnessMax();
	Genome	GetBestGenome();
	void	SetAttribute(int poplmt,float crosspb,float swappb,float mutatepb,float linereppb,float deletepb,float improvepb);
	void	DoInitialize(int ,int ,int,bool* );
	void	DoLineRepair(Obstacle* obs,int numobs);
	void	DoDeletion();
	void	DoImprovement();
	void	DoCrossover();
	void	DoSwap();
	void	DoMutation();
	void	DoCurrRanking();
	void	DoResRanking();
	void	DoSelection();
	void	DoEvaluation();
	void	DoRepresentation();
};
