#include "StdAfx.h"
#include "Grid.h"

int Grid::gridX = 16;
int Grid::gridY = 16;
int Grid::size = 256;


Grid::Grid(void)
{	
}

Grid::~Grid(void)
{
}

void Grid::show()
{
	cout<<"x = "<<gridX<<" y = "<<gridY<<endl;
};

int	Grid::GetX(int point)//convert interger to co-ordinate x
{ return point % gridX;};
int Grid::GetY(int point)//convert interger to co-ordinate y
{	float x = point/gridX;
	return floor(x);};
////////////FORD MODIFY/////////////
//int Grid::GetDistance(int point1, int point2)
float Grid::GetDistance(int point1, int point2)
////////////����ҹ��///////////////	
{
	float sum,dx,dy;
	if (point1 == point2)
	{	return 0;};
	dx = GetX(point1)-GetX(point2);
	dy = GetY(point1)- GetY(point2);
	sum = sqrt((dx*dx)+(dy*dy));
	return sum;
};
vector<int> Grid::GetLineVector(int point1, int point2)//return vector contained with co-ordinate along path from point1 to point2
{
	vector<int> result;
	if(point1==point2)
	{	
		result.clear();
		return result; 
	}; 

	float x1,x2,y1,y2,m,c,dx,dy,tmp1,tmp2,k;
	x1 =GetX(point1);
	x2 =GetX(point2);
				
	if(x2<x1)
	{
		tmp1 = x2;		x2 = x1;		x1 = tmp1;
		tmp1 = point2;	point2 = point1; point1 = tmp1;
	}
	y1 =GetY(point1);
	y2 =GetY(point2);
	dx = x1-x2 ;
	dy = y1-y2;
	
	if(dx == 0)//point on vertical path
	{
		if(dy<0)
		{
			for(int i = 0; 0 !=(dy+1) + i; i++)
			{ result.push_back(point1 + (gridX *(i+1)));};
		} else {
			for(int i = 0; 0 !=(dy-1)-i; i++)
			{ result.push_back(point1 - (gridX *(i+1)));};
		};
		return result;
	};
	if(dy == 0)//point on horizontal path
	{
		for(int i = 1; 0 !=dx + i; i++)
		{ result.push_back(point1 + i);};
		return result;
	};

	m = dy/dx; //m of y = mx + c
	c = y1-(m * x1); // c 0f y = mx + c
	result.push_back(point1);
	
	float *tempX = new float[abs(dx)+1];
	for(int i = 0; dx+ i <= 0; i++)
	{	tempX[i] = x1 + (i+0.5);	};
	
	for(int i = 0; i<abs(dx); i++)
	{
		k = (m * tempX[i]) + c; // show range from path
		tmp2 = result[result.size()-1];
		if(k == 1) {k -=0.1;};
		if(fmod(k,1)!= 0.5)//fmod -> calculate floating point remainder
		{
			if (fmod(k,1) > 0.5)
			{	tmp1 =(ceil(k)* gridX)+(tempX[i]-0.5);} //ceil -> returns the smallest integer that is greater than or equal to x
			else { tmp1 =(floor(k)* gridX)+(tempX[i]-0.5);};//floor -> returns the largest integer that is less than or equal to x
			
			if( m>0)
			{	
				for(int i = 0;tmp2!= tmp1 - i; )
				{	result.push_back(tmp1-i);
					i += gridX;
				};
			}else{
				for(int i = 0;tmp2!= tmp1 + i; i )
				{	result.push_back(tmp1+i);
					i += gridX;
				};
			};
			result.push_back(tmp1+1);
		}else {
			if(m>0)
			{	
				tmp1 =(floor(k)*gridX)+(tempX[i]-0.5);
				for(int i = 1;tmp2+(i*gridX) <= tmp1 ; i++ )
				{	result.push_back(tmp2+(i*gridX));};
				tmp1 +=gridX;
			}else { 
				tmp1 =(ceil(k)*gridX)+(tempX[i]-0.5);
				for(int i = 1;tmp2-(i*gridX) >=tmp1; i++)
				{	result.push_back(tmp2-(i*gridX) );};
				tmp1 -=gridX;
			};	
			result.push_back(tmp1+1);
		};
		
	};
	
	delete []tempX;
	tmp1 = result[result.size()-1];
	
	if(( tmp1-point2) != 0) 
	{	
		if(m>0)
		{	for(int i = 1; tmp1 + (i*gridX)<= point2; i++)
			{	result.push_back(tmp1 + (i*gridX));};
		} else {
			for(int i = 1; tmp1 - (i*gridX)>= point2; i++)
			{	result.push_back(tmp1 -(i*gridX));};
		};
	};
	
	result.erase(result.begin());
	if(find(result.begin(),result.end(),point2) != result.end())
	{	result.erase(result.end()-1);};
	
	return result;//without point1 and point 2
};

vector<int> Grid::GetNeighbor(int point)
{
	vector<int> result;
	int x,y;

	x = GetX(point);
	y = GetY(point);

	if(x - 1 >= 0)
	{	result.push_back(point-1);		};
	if(x + 1 < gridX)
	{	result.push_back(point+1);		};
	if(y - 1 >=0)
	{
		result.push_back(point-gridX);
		if(x - 1 >= 0)
		{	result.push_back(point-gridX-1);		};
		if(x + 1 < gridX)
		{	result.push_back(point-gridX+1);		};
	};
	if(y + 1 < gridY)
	{
		result.push_back(point+gridX);
		if(x - 1 >= 0)
		{	result.push_back(point+gridX-1);		};
		if(x + 1 < gridX)
		{	result.push_back(point+gridX+1);		};
	};

	return result;
};
int* Grid::GetArea(int point, int width, int height)
{
	int* tmp = new int[width*height];
	int k = 0;
	for (int i = 0; i<width; i++)
	{	
		tmp[k]=(point+i);
		k++;
		for (int j = 1; j<height; j++)
		{	
			tmp[k]=(point+i)-(gridX*j);
			k++;
		};
	};
	return tmp;
};
