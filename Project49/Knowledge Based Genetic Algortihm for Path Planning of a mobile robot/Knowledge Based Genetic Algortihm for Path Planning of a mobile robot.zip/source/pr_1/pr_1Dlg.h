// pr_1Dlg.h : header file
//

#pragma once
#include "Population.h"
#include "Ground.h"
#include "Mapplan.h"
#include "ViewGraph.h"
#include "afxwin.h"

// Cpr_1Dlg dialog
class Cpr_1Dlg : public CDialog
{
// Construction
public:
	Cpr_1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_PR_1_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnEnKillfocusEdit5();
	afx_msg void OnEnKillfocusEdit6();
	int stpoint;
	int sppoint;
	int poplmt;
	int maxgen;
	int stoptime;
	int maxgnmlen;
	float crosspb;
	float swappb;
	float mutatepb;
	float linereppb;
	float deletepb;
	float improvepb;
	CEdit outbox;
	CString outbox_value;
	int in_nrun;
	int in_showgen;
	int out_gen;
	int out_fit;
	float runtime;

	Population TestPop;
	Ground ground;
	int	stop_count;
	bool init_chk;
	bool mapchange_chk;
	vector<vector<int>> BestHistory;
	vector<int> BestFitHistory;
	void DrawMap(CDC* dc);
	void DrawPath(CDC* dc,vector<int>* tmp);
	void SetstatusControl(int grp,bool chk);
	void DrawStSpPoint(CDC* dc);
	void AddGenomePath(vector<int>* tmp);
};
