#pragma once
#include "Obstacle.h"

class Ground :
	public Grid
{
	int countObs;
	bool*	Grid;
	Obstacle*	ObsGrid;
public:
	Ground(void);
	~Ground(void);
	void	AddObstacle(int point, int width, int height);
	bool*	GetGrid();
	int		GetNumObs();
	Obstacle*	GetObstacle();
	void	ResetEnvironment();
////////////FORD MODIFY/////////////
	void	CopyGround(Ground *gnd)
	{
		ResetEnvironment();
		SetGridX(gnd->GetGridX());
		SetGridY(gnd->GetGridY());
		Obstacle *t_ob;
		for (int i = 0; i < gnd->GetNumObs(); i++)
		{
			t_ob = &(gnd->GetObstacle()[i]);
			AddObstacle(t_ob->GetPoint(),t_ob->GetWidth(),t_ob->GetHeight());
		}
	}
////////////����ҹ��///////////////	
};
