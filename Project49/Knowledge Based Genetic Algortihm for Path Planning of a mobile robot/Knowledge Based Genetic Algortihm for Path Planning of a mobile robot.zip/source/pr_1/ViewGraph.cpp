// ViewGraph.cpp : implementation file
//

#include "stdafx.h"
#include "pr_1.h"
#include "ViewGraph.h"


// ViewGraph dialog

IMPLEMENT_DYNAMIC(ViewGraph, CDialog)

ViewGraph::ViewGraph(CWnd* pParent /*=NULL*/)
	: CDialog(ViewGraph::IDD, pParent)
{
	Create(IDD_GraphDlg,pParent);
}

ViewGraph::~ViewGraph()
{
}

void ViewGraph::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ViewGraph, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &ViewGraph::OnBnClickedButton1)
END_MESSAGE_MAP()


// ViewGraph message handlers

BOOL ViewGraph::DestroyWindow()
{
	delete(this);
	return CDialog::DestroyWindow();
}

void ViewGraph::OnBnClickedButton1()
{
	if (BestFit->size() <= 2)
		return;
	int sx,sy,x,y,mx,my,i;
	sx = 20; sy = 10; mx = 2; my = 2;

	int a,max,min,range,xrange;
	max = 0; min = 10000;

	CDC *dc = GetDC();
	HPEN pn;
	CString str;
	char ss[10];

	for (i = 0; i<BestFit->size(); i++)
	{
		if ((*BestFit)[i] > max)
		{
			max = (*BestFit)[i];
		}
		if ((*BestFit)[i] < min)
		{
			min = (*BestFit)[i];
		}
	}
	min = 0;
	range = max-min;
	xrange = BestFit->size();
	if (fin) xrange -= 99;

	HFONT fnt;
	fnt = CreateFont(10,4,0,0,700,
		FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH,NULL);
	dc->SelectObject(fnt);
	dc->FillSolidRect(sx-15,sy-5,sx+205*mx,sy+10+100*my,RGB(255,255,255));
	dc->MoveTo(sx,sy);
	dc->LineTo(sx,sy+100*my);
	dc->LineTo(sx+200*mx,sy+100*my);
	pn = CreatePen(0,1,RGB(0,127,255));
	dc->SelectObject(pn);
	x = sx;
	y = (((*BestFit)[0]-min)*my)*100/range;
	y = 100*my -1-y;
	y += sy;
	sprintf(ss,"%d",1);
	str = ss;
	dc->MoveTo(x,sy+5+100*my);
	dc->TextOutW(x,sy+5+100*my,str);
	dc->SetTextAlign(2);
	sprintf(ss,"%d",(*BestFit)[0]);
	str = ss;
	dc->MoveTo(sx,y);
	dc->TextOutW(sx,y,str);
	dc->MoveTo(x,y);
	a = (*BestFit)[0];
	for (i = 0; i<xrange; i++)
	{
		x = i*mx*200/xrange;
		x += sx;
		y = (((*BestFit)[i]-min)*my)*100/range;
		y = 100*my -1-y;
		y += sy;
		dc->LineTo(x,y);
		if((*BestFit)[i] != a)
		{
			dc->SetTextAlign(0);
			dc->SetTextColor(RGB(255,0,0));
			str = "*";
			dc->TextOutW(x,y,str);
			dc->SetTextAlign(2);
			dc->SetTextColor(RGB(0,0,0));
			sprintf(ss,"%d",i+1);
			str = ss;
			dc->MoveTo(x,sy+5+100*my);
			dc->TextOutW(x,sy+5+100*my,str);
			sprintf(ss,"%d",(*BestFit)[i]);
			str = ss;
			dc->MoveTo(sx,y);
			dc->TextOutW(sx,y,str);
			dc->MoveTo(x,y);
		}
		a = (*BestFit)[i];
	}
	sprintf(ss,"%d",xrange);
	str = ss;
	dc->MoveTo(x,sy+5+100*my);
	dc->TextOutW(x,sy+5+100*my,str);

	ReleaseDC(dc);

/*	vector<int> vec;
	int sx,sy,x,y,mx;
	sx = 90; sy = 7; mx = 4;
	int a,max,imax,min,imin,range;
	max = 0; min = 10000;
	double b;
	for (int i = 0; i<100; i++)
	{
		b = i;
		a = pow(b,3)-80*pow(b,2)+3*i-2;
		//a = i;
		vec.push_back(a);
		if (a > max)
		{
			max = a;
			imax = i;
		}
		if (a < min)
		{
			min = a;
			imin = i;
		}
	}
	range = max-min;

	CDC *dc = GetDC();
	dc->Rectangle(sx,sy,sx+100*mx,sy+100*mx);
	x = sx;
	y = ((vec[0]-min)*mx)*100/range;
	y = 100*mx -1-y;
	y += sy;
	dc->MoveTo(x,y);
	//dc->MoveTo(x,sy + 100*mx -1-(((vec[0]-min)*mx)*100/range));
	for (int i = 0; i<100; i++)
	{
		x = i*mx;
		x += sx;
		y = ((vec[i]-min)*mx)*100/range;
		y = 100*mx -1-y;
		y += sy;
		dc->LineTo(x,y);
		//dc->LineTo(sx+i*mx,sy + 100*mx -1-(((vec[i]-min)*mx)*100/range));
	}
	ReleaseDC(dc);
*/
}
