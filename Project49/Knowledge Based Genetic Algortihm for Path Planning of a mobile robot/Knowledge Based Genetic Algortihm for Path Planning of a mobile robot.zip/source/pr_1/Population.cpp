#include "StdAfx.h"
#include "Population.h"

Population::Population()
{
		PopulationLimit = 50;
		CrossoverProb = 0.9;
		SwapProb = 0.5;
		MutationProb = 0.5;
		LineRepProb = 0.9;
		DeleteProb = 0.9;
		ImproveProb = 0.9;
		Genomes = new Genome[PopulationLimit];
		ResultGenomes = new Genome[PopulationLimit];
		
}

Population::~Population(void)
{
	delete	[]Genomes;
	delete	[]ResultGenomes;
}

	int		Population::GetGenNumber()
	{	return Generation;};
	void	Population::GetCurrPopulation()
	{	
		cout<<"show current population :"<<endl;
		for (int i = 0; i < PopulationLimit; i++)
		{
			Genomes[i].GetGenomeValue();
		};
	};
	void	Population::GetResPopulation()
	{	
		cout<<"show result population :"<<endl;
		for (int i = 0; i < PopulationLimit; i++)
		{
			cout<<i<<endl;
			ResultGenomes[i].GetGenomeValue();
		};
	};
	void	Population::GetFitnessMin()
	{
		min_element(Genomes,Genomes+PopulationLimit)->GetGenomeValue();
	};
	void	Population::GetFitnessMax()
	{
		max_element(Genomes,Genomes+PopulationLimit)->GetGenomeValue();
	};
	Genome	Population::GetBestGenome()
	{
		//BestSofar.GetGenomeValue();
		return BestSofar;
	};
	void	Population::SetAttribute(int poplmt,float crosspb,float swappb,float mutatepb,float linereppb,float deletepb,float improvepb)
	{
	PopulationLimit = poplmt;
	CrossoverProb = crosspb;
	SwapProb = swappb;
	MutationProb = mutatepb;
	LineRepProb = linereppb;
	DeleteProb = deletepb;
	ImproveProb = improvepb;
	delete []Genomes;
	delete []ResultGenomes;
	Genomes = new Genome[PopulationLimit];
	ResultGenomes = new Genome[PopulationLimit];
	}
	void	Population::DoInitialize(int start,int end,int msize,bool* Grid)
	{
		//cout<<"Intialize Progress start..."<<endl;
		//cout<<"start init"<<endl;
		//cout<<start<<" "<<end<<" "<<PopulationLimit<<" "<<Grid::size<<endl;
		FreeGrid = Grid; 
		FreeGrid[start] = 1;
		FreeGrid[end] = 1;
		Generation = 1;
		//cout<<"into loop"<<endl;
		for(int i = 0; i<PopulationLimit; i++)
		{
			Genome trial;//initialize new genome
			//cout<<i<<endl;
			trial.Initialize(start,end,msize,FreeGrid);
			Genomes[i] = trial;
			Genomes[i].CalculateFitness(FreeGrid) ;
		};
		//cout<<"end of loop"<<endl;
		BestSofar = *min_element(Genomes,Genomes+PopulationLimit);
		BestInGeneration = BestSofar;
		BestGen = Generation;
		//cout<<"pass min"<<endl;
		//cout<<endl<<"Initialization progress accomplished..."<<endl;
	};
	void	Population::DoLineRepair(Obstacle* obs,int numobs)
	{
		//cout<<"LineRepair Progress start..."<<endl;
		int Lvalue = LineRepProb * 100;
		
		for(int i = 0; i<PopulationLimit; i++)
		{
			if(ResultGenomes[i].GetLineSegment())
			{
				if((rand() %100 +1) <= Lvalue)
				{
					//cout<<"line rep prob passed"<<endl;
					ResultGenomes[i].Linerepair(obs,numobs,FreeGrid);
				};
			};
		};
		//cout<<endl<<"LineRepair progress accomplished..."<<endl;
	};
	void	Population::DoDeletion()
	{
		//cout<<"Delete Progress start..."<<endl;
		int Dvalue = DeleteProb * 100;
		
		for(int i = 0; i<PopulationLimit; i++)
		{
			if(ResultGenomes[i].GetLength()>2)
			{
				if((rand() %100 +1) <= Dvalue)
				{
					ResultGenomes[i].Deletion(rand() % (ResultGenomes[i].GetLength()-2) +1,FreeGrid);
				};
			};
		};
		//cout<<endl<<"Deletion progress accomplished..."<<endl;	
	};
	void	Population::DoImprovement()
	{
		//cout<<"Improve Progress start...";
		int Ivalue = ImproveProb * 100;
		for(int i = 0; i<PopulationLimit; i++)
		{
			if(ResultGenomes[i].GetLength()!=2)
			{
				if(ResultGenomes[i].GetLineSegment())
				{
					if((rand() %100 +1) <= Ivalue)
					{
						ResultGenomes[i].Improve(rand() % (ResultGenomes[i].GetLength()-2) +1,FreeGrid);
					};
				};
			};
		};
		//cout<<endl<<endl<<"Improvement progress accomplished..."<<endl;	         
	};
	void	Population::DoCrossover()
	{
		//cout<<"Crossover Progress start..."<<endl;
		int Cvalue = CrossoverProb * 100;
		int point1,point2,tmp;

		for(int i = 0; i<PopulationLimit;)
		{	
			if(ResultGenomes[i].GetLength()+ResultGenomes[i+1].GetLength()>4)
			{
				tmp = rand()%100+1;
				if(tmp <= Cvalue)
				{
					//cout<<tmp<<" "<<ResultGenomes[i].GetLength()<<" "<<ResultGenomes[i+1].GetLength()<<endl;
					if((ResultGenomes[i].GetLength()>2)&&(ResultGenomes[i+1].GetLength()>2))
					{	
						Genome temp = ResultGenomes[i];	
						point1 = rand() % (ResultGenomes[i].GetLength()-2) +1;
						point2 = rand() % (ResultGenomes[i+1].GetLength()-2) + 1;
						ResultGenomes[i].Crossover(point1,point2,ResultGenomes[i+1]);
						ResultGenomes[i+1].Crossover(point2,point1,temp);					
					}else if(ResultGenomes[i].GetLength()==2)
						{
							point2 = rand() % (ResultGenomes[i+1].GetLength()-2) + 1;
							ResultGenomes[i].Crossover(1,point2,ResultGenomes[i+1]);
					}else if(ResultGenomes[i+1].GetLength()==2){
						point1 = rand() % (ResultGenomes[i].GetLength()-2) +1;
						ResultGenomes[i+1].Crossover(1,point1,ResultGenomes[i]);	};
				};
			};
			i += 2;
		};
		//cout<<endl<<"Crossover progress accomplished..."<<endl;
	};
	void	Population::DoSwap()
	{
		//cout<<"Swap Progress start..."<<endl;
		int Cvalue = SwapProb * 100;
		int point1,point2,tmp;

		for(int i = 0; i<PopulationLimit;i++)
		{
			if(ResultGenomes[i].GetLength()>3)
			{
				tmp = rand()%100+1;
				if(tmp <= Cvalue)
				{
					point1 = rand() % (ResultGenomes[i].GetLength()-2) +1;
					point2 = rand() % (ResultGenomes[i].GetLength()-2) +1;
					ResultGenomes[i].Swap(point1,point2);
				};
			};
		};
		//cout<<endl<<"Swap progress accomplished..."<<endl;
	};
	void	Population::DoMutation()
	{
		//cout<<"Mutate Progress start..."<<endl;
		int	Mvalue = MutationProb * 100;
		int Mpoint;

		for (int i = 0; i < PopulationLimit; i++)
		{
			if(ResultGenomes[i].GetLength()>2)
			{
				if((rand() % 100 + 1) < Mvalue)
				{
					Mpoint = rand() % (ResultGenomes[i].GetLength()-2) +1;
					ResultGenomes[i].Mutate(Mpoint,FreeGrid);
				};
			};
		};
		//cout<<endl<<endl<<"Mutate progress accomplished..."<<endl;
	};
	void	Population::DoCurrRanking()
	{
		sort(Genomes,Genomes+PopulationLimit);
	};
	void	Population::DoResRanking()
	{
		sort(ResultGenomes,ResultGenomes+PopulationLimit);
	};
	void	Population::DoSelection()
	{
		//cout<<"Select Progress start..."<<endl;
		int index = 0;
		int temp;
		while(index < PopulationLimit)
		{
			temp = rand() % PopulationLimit;
			ResultGenomes[index] = Genomes[temp];
			++index;
		};
		//cout<<endl<<"Selection progress accomplished..."<<endl;
	};     
	void	Population::DoEvaluation()
	{
		//cout<<"Evaluate Progress start..."<<endl;
		int	fit = 0;
		for (int i = 0; i < PopulationLimit; i++)
		{
			ResultGenomes[i].CalculateFitness(FreeGrid);
		};
		//cout<<endl<<"Evaluation progress accomplished..."<<endl;
	};
	void	Population::DoRepresentation()
	{
		//cout<<"Represent Progress start..."<<endl;
		int i,tmp;
		DoCurrRanking();
		DoResRanking();/*
		GetCurrPopulation();
		GetResPopulation();*/
		//cout<<"before create new gen"<<endl;
		for(i = 0; i<PopulationLimit; i++)
		{		
			if(Genomes[i]>ResultGenomes[i])
			{ break;};
		};
		tmp = 0;
		for(; i<PopulationLimit; i++, tmp++)
		{	Genomes[i] = ResultGenomes[tmp];};
		//cout<<"increase generation"<<endl;
		++Generation;

		BestInGeneration = (*min_element(Genomes, Genomes+PopulationLimit));
		if(BestSofar>BestInGeneration)
		{	
			BestSofar = BestInGeneration;
			BestGen = Generation;
		};
		//cout<<endl<<"Representation progress accomplished..."<<endl;
	};	
	