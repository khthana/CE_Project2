#pragma once
#include "Obstacle.h"

class Genome :
	public Grid
{
	int		constant; //multiple obstacle caused
	int		length;
	int		Fitness;
	int     linealfa;
	int		SectionFitness;
	int		LineSegment[2];
	vector<int> 	GenesList;

	int		CheckLine(int point1, int point2,bool* Grid);
	int		CheckLine(int point1,bool* Grid);
public:
	Genome(void);
	~Genome(void);
	void	GetGenomeValue();
	char*	GetGenomeString();
	int		GetLength();
	int		GetFitness();
	int		GetLineSegment();
	vector<int> GetGenesList();
	void	SetGridSize(int ,int );
	void	Initialize(int start, int end,int msize,bool* Grid);
	int		CalculateFitness(bool* Grid);
	void	Mutate(int point,bool* Grid);
	void	Crossover(int point1,int point2,Genome parent);
	void	Linerepair(Obstacle* obs,int numobs,bool* Grid);
	void	Deletion(int point,bool* Grid);
	void	Improve(int point,bool* Grid);
	void	Swap(int point1, int point2);
};


bool operator<(Genome& , Genome& ) ;
bool operator>(Genome& , Genome& ) ;
bool operator==(Genome& , Genome& );
Genome NewLocalSearch(int start,int end,bool* freegrid);
