#include "StdAfx.h"
#include "Ground.h"

Ground::Ground(void)
{
	countObs = 0;
	//ObsGrid.clear();
	Grid = new bool[Grid::size];
	for (int i = 0; i < Grid::size; i++)
	{	Grid[i] = 0;};
}

Ground::~Ground()
{
	if(countObs>0)
	{	delete []ObsGrid; };
	delete []Grid;
};

void	Ground::AddObstacle(int point, int width, int height)
//must add obstacle from highest position first
{
	countObs +=1;	
	Obstacle* tmpa = new Obstacle[countObs];
	
	if(countObs > 1)
	{		
		for(int i = 0;i<countObs-1; i++)
////////////FORD MODIFY/////////////
//		{	tmpa[i] = ObsGrid[i];	};
		{	tmpa[i].CopyObstacle(&(ObsGrid[i]));	};
////////////����ҹ��///////////////	
		delete []ObsGrid;
	};
	ObsGrid = tmpa; 
	Obstacle tmp(point,width,height);
	
////////////FORD MODIFY/////////////
//	ObsGrid[countObs-1] = tmp;
	ObsGrid[countObs-1].CopyObstacle(&tmp);
////////////����ҹ��///////////////	
	int* temp = tmp.GetPlain();
	int osize = tmp.GetSize();
	for (int i = 0; i < osize;i++)
	{	Grid[temp[i]] = 1;	};
};
bool*	Ground::GetGrid()
{
	return Grid;
};
Obstacle* Ground::GetObstacle()
{	return ObsGrid;};

int		Ground::GetNumObs()
{
	return countObs;
};

void	Ground::ResetEnvironment()
{
	delete []Grid;
	Grid = new bool[Grid::size];
	for (int i = 0; i < Grid::size; i++)
	{	Grid[i] = 0;}
////////////FORD MODIFY/////////////
	if (countObs == 0) return;
////////////����ҹ��///////////////	
	countObs= 0;
	delete []ObsGrid;

};
