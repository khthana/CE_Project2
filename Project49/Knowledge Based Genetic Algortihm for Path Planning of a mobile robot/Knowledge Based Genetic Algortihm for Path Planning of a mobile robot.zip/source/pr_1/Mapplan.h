#pragma once
#include "Ground.h"

// Mapplan dialog

class Mapplan : public CDialog
{
	DECLARE_DYNAMIC(Mapplan)

public:
	Mapplan(CWnd* pParent = NULL);   // standard constructor
	virtual ~Mapplan();

// Dialog Data
	enum { IDD = IDD_MapPlanDlg };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	int obpoint;
	int obwidth;
	int obheight;
	int gridx;
	int gridy;

	Ground *ground,*ground_old;
	int gridx_old,gridy_old;
	void DrawMap(CDC* dc);
};
