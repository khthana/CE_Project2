#include ".\controller.h"

CController::CController(void)
: g_pDI(NULL)
, g_pMouse(NULL)
, g_pKeyboard(NULL)
, _scrn(NULL)
{
}

CController::~CController(void)
{
    // Unacquire the device one last time just in case 
    // the app tried to exit while the device is still acquired.
    // Release any DirectInput objects.
	if(g_pMouse != NULL) {
        g_pMouse->Unacquire();
		g_pMouse->Release();
	}

	if(g_pKeyboard != NULL) {
        g_pKeyboard->Unacquire();
		g_pKeyboard->Release();
	}

	if (g_pDI != NULL) {
		g_pDI->Release();
	}
}

bool CController::initKeyboard(HWND hWnd)
{
	// Create a DInput object
    if( FAILED(DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
		IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) ) {
        return false;
	}
    
    // Obtain an interface to the system keyboard device.
	if( FAILED(g_pDI->CreateDevice( GUID_SysKeyboard, &g_pKeyboard, NULL ) ) ) {
        return false;
	}

    // Set the data format to "keyboard format" - a predefined data format 
    //
    // A data format specifies which controls on a device we
    // are interested in, and how they should be reported.
    //
    // This tells DirectInput that we will be passing an array
    // of 256 bytes to IDirectInputDevice::GetDeviceState.
	if( FAILED(g_pKeyboard->SetDataFormat( &c_dfDIKeyboard ) ) ) {
        return false;
	}

    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications.
    g_pKeyboard->SetCooperativeLevel( hWnd, DISCL_NONEXCLUSIVE );

    // Acquire the newly created device
    g_pKeyboard->Acquire();

	readKeyboard();

	return true;
}

bool CController::initMouse(HWND hWnd)
{
	// Create a DInput object
    if( FAILED(DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                                         IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) )
    {
        return false;
    }
    
    // Obtain an interface to the system mouse device.
    if( FAILED(g_pDI->CreateDevice( GUID_SysMouse, &g_pMouse, NULL ) ) )
    {
        return false;
    }

	if( FAILED(g_pMouse->SetDataFormat( &c_dfDIMouse2 ) ) )
        return false;
    
    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications.
    g_pMouse->SetCooperativeLevel( hWnd, DISCL_NONEXCLUSIVE );

    // Acquire the newly created device
	g_pMouse->Acquire();

	readMouse();

	return true;
}

void CController::setScreen(CScreen* scrn)
{
	_scrn = scrn;
}

bool CController::initialize(HWND hWnd, CScreen* scrn)
{
	setScreen(scrn);
	return initKeyboard(hWnd) && initMouse(hWnd);
}

void CController::readKeyboard(void)
{
	//Copy to Buffer
	for (int i = 0; i < 256; i++) {
	    _kybrB[i] = _kybr[i];
	}
    // Get the input's device state, and put the state in dims
    ZeroMemory( &_kybr, sizeof(_kybr) );
    g_pKeyboard->GetDeviceState( sizeof(_kybr), &_kybr );
}

void CController::readMouse()
{
	//Copy to Buffer
	_mousB = _mous;
    // Get the input's device state, and put the state in dims
    ZeroMemory( &_mous, sizeof(_mous) );
    g_pMouse->GetDeviceState( sizeof(DIMOUSESTATE2), &_mous );
}

void CController::update(void)
{
	readKeyboard();
	readMouse();
	//Move Eye
	if (mouseButton(1)) {
		_scrn->moveEye(mouseX() * -0.01, mouseY() * -0.01, mouseWheel() * -0.01);
	}
	//Move Look
	if (keyboardButton(DIK_LCONTROL)) {
		_scrn->moveLook(mouseX() * -0.01, mouseY() * 0.01, mouseWheel() * 0.01);
	}
}

bool CController::keyboardButton(int butn)
{
	return _kybr[butn] & 0x80;
}

int CController::mouseX(void)
{
	return _mous.lX;
}

int CController::mouseY(void)
{
	return _mous.lY;
}

int CController::mouseWheel(void)
{
	return _mous.lZ;
}

bool CController::mouseButton(int butn)
{
	return _mous.rgbButtons[butn] & 0x80;
}

bool CController::mouseDown(int butn)
{
	return _mous.rgbButtons[butn] & 0x80 && !(_mousB.rgbButtons[butn] & 0x80);
}

int CController::keyboardDown(int butn)
{
	return _kybr[butn] & 0x80 && !(_kybrB[butn] & 0x80);
}
