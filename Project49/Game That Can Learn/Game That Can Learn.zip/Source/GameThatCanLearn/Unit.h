#pragma once

#ifndef PJ4D_UNIT
#define PJ4D_UNIT
//Action
#define UNIT_STOP 0
#define UNIT_MOVE 1
#define UNIT_ATCK 2
//Mode
#define UNIT_PLAYER 0
#define UNIT_AI 1
//Team
#define UNIT_NTRL 0
#define UNIT_ALLY 1
#define UNIT_ENMY 2

class CUnit;

#include "global.h"
#include "world.h"
#include "ai.h"
#include "screen.h"
#include <fstream>
using std::ifstream;
using std::ofstream;

class CUnit {
	string _name;
	int _type;
	double _strn, _aglt, _intl;	//Parameter
	double _strnX, _agltX, _intlX;	//Extension
	double _strnB, _agltB, _intlB;	//Bluff
	double _hit, _mana;	//Power
	double _hitR, _manaR;	//Regeneration
	double _pstnX, _pstnY;	//Position
	double _trgtX, _trgtY;	//Target
	int _team;
	int _actn;
	int _dely;
	int _mode;
	int _dlyM;
	int _dlyA;

	CWorld* _wrld;
	CAi* _ai;
	CScreen* _scrn;
	CUnit* _trgt;
public:
	CUnit();
	~CUnit();

	void setName(string name);
	void setType(int type);
	void setParameter(double strn, double aglt, double intl);
	void setExtension(double strn, double aglt, double intl);
	void setBluff(double strn, double aglt, double intl);
	void setPower(double hit, double mana);
	void setRegeneration(double hit, double mana);
	void setPosition(double x, double y);
	void setTarget(double x, double y);
	void setTeam(int team);
	void setAction(int actn);
	void setWorld(CWorld* wrld);

	string name();
	int type();
	double strength();
	double agility();
	double intelligent();
	double positionX();
	double positionY();
	double targetX();
	double targetY();
	int team();
	int action();
	int frame();
	double range();

	void save();
	void load(string name);
	void move(int time);
	void attack(int time);
	void update(int time);
	void setScreen(CScreen* scrn);
	void setMode(int mode);
	int mode(void);
	void stop(void);
	void setAi(CAi* ai);
	void setTarget(CUnit* trgt);
private:
public:
	void damage(double damg);
};

#endif
