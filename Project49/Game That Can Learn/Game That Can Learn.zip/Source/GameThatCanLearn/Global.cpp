#include "global.h"

double random() {
	srand((unsigned)time(NULL) + rand());
	return rand() / 32767.1;	//range [0, 1)
}

double distance(double x1, double y1, double x2, double y2) {
	return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

double curve(double valu, double degr) {
	return pow(valu, degr);
}

string toString(double dobl) {
	ostringstream ostr;
	ostr << dobl;
	return ostr.str();
}

string toString(char* chrs) {
	return string(chrs);
}

double toDouble(string strn) {
	istringstream istr(strn);
	double dobl;
	if (istr >> dobl) {
		return dobl;
	}

	return 0;
}
