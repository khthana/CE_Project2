#pragma once

#ifndef PJ4D_SCRN
#define PJ4D_SCRN

class CScreen;
class CMesh;
class CVertex;
class CSprite;

#include "global.h"
#include "controller.h"
#include "world.h"
#include <d3dx9.h>
#include <strsafe.h>
#include <vector>
using std::vector;

class CScreen
{
	LPDIRECT3D9 g_pD3D;	// Used to create the D3DDevice
	LPDIRECT3DDEVICE9 g_pd3dDevice;	// Our rendering device
	LPD3DXFONT g_lp3dxfont;
	double _lokX, _lokY, _lokZ;
	double _eyeH, _eyeV, _eyeD;
	double _crsX, _crsY, _crsZ;
	int _pntX, _pntY;
	CVertex* _crsr;
	CSprite* _pntr;
	vector<CMesh*> _mesh;
	vector<CVertex*> _vrtx;
	vector<CSprite*> _sprt;
	vector<string> _mesg;

	CController* _cntr;
	CWorld* _wrld;
public:
	CScreen(void);
	~CScreen(void);

	bool initD3D(HWND hWnd);
	bool initFont(void);
	bool initialize(HWND hWnd, CController* cntr, CWorld* wrld);
	void setLook(double x, double y, double z);
	void moveLook(double x, double y, double z);
	void setEye(double h, double v, double d);
	void moveEye(double h, double v, double d);
	void setCursor(double x, double y, double z);
	void moveCursor(double x, double y, double z);
	void setPointer(int x, int y);
	void movePointer(int x, int y);
	void setController(CController* cntr);
	void setWorld(CWorld* wrld);

	double eyeX(void);
	double eyeY(void);
	double eyeZ(void);
	double cursorX(void);
	double cursorY(void);
	double cursorZ(void);

	void newMesh(char* file, bool mode = true);
	void newVertex(char* file);
	void newSprite(char* file);
	void message(string mesg);
	void printText(string text, int left = 0, int top = 0, int r = 0, int g = 0, int b = 0);
	void render(void);
	void update(void);
};

class CMesh
{
	LPDIRECT3DDEVICE9 g_pd3dDevice; // Our rendering device
	LPD3DXMESH g_pMesh; // Our mesh object in sysmem
	D3DMATERIAL9* g_pMeshMaterials; // Materials for our mesh
	LPDIRECT3DTEXTURE9* g_pMeshTextures; // Textures for our mesh
	DWORD g_dwNumMaterials;   // Number of mesh materials

	double _pstX;
	double _pstY;
	double _pstZ;
	double _angX;
	double _angY;
	double _angZ;
	double _scal;
public:
	CMesh(void);
	~CMesh(void);

	void setDevice(LPDIRECT3DDEVICE9 devc);
	HRESULT load(const char* xFile);
	void render(double pX = 0, double pY = 0, double pZ = 0, double aX = 0, double aY = 0, double aZ = 0, double s = 1);
	void loadConfig(char* file);
};

class CVertex
{
	struct CUSTOMVERTEX
	{
		FLOAT x, y, z; //Position
		FLOAT normalX, normalY, normalZ; //Normal
		FLOAT tu, tv; //Texture
	};

	LPDIRECT3DDEVICE9       g_pd3dDevice;	// Our rendering device
	LPDIRECT3DVERTEXBUFFER9 g_pVB;
	LPDIRECT3DTEXTURE9		g_Texture;
	LPDIRECT3DINDEXBUFFER9	g_pIndexBuffer;
public:
	CVertex(void);
	~CVertex(void);

	void setDevice(LPDIRECT3DDEVICE9 devc);
	HRESULT load(const char* file);
	void render(double pX = 0, double pY = 0, double pZ = 0, double aX = 0, double aY = 0, double aZ = 0, double s = 1);
};

class CSprite
{
	LPDIRECT3DDEVICE9 g_pd3dDevice;	// Our rendering device
	LPD3DXSPRITE g_Sprite;
	LPDIRECT3DTEXTURE9 g_Texture;
public:
	CSprite(void);
	~CSprite(void);

	void setDevice(LPDIRECT3DDEVICE9 devc);
	HRESULT load(const char* file);
	void render(int left = 0, int top = 0);
};

#endif
