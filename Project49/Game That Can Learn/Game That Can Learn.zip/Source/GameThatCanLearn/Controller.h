#pragma once

#ifndef PJ4D_CNTR
#define PJ4D_CNTR

class CController;

#include "global.h"
#include "screen.h"
#include <dinput.h>

class CController
{
	LPDIRECTINPUT8 g_pDI;
	LPDIRECTINPUTDEVICE8 g_pKeyboard;
    BYTE _kybr[256];   // Keyboard State
    BYTE _kybrB[256];   // Buffer
	LPDIRECTINPUTDEVICE8 g_pMouse;
	DIMOUSESTATE2 _mous;	//Mouse State
	DIMOUSESTATE2 _mousB;	//Buffer

	CScreen* _scrn;
public:
	CController(void);
	~CController(void);

	bool initKeyboard(HWND hWnd);
	bool initMouse(HWND hWnd);
	void setScreen(CScreen* scrn);
	bool initialize(HWND hWnd, CScreen* scrn);
	void readKeyboard(void);
	void readMouse();
	void update(void);
	bool keyboardButton(int butn);
	int mouseX(void);
	int mouseY(void);
	int mouseWheel(void);
	bool mouseButton(int butn);
	bool mouseDown(int butn);
	int keyboardDown(int butn);
};

#endif
