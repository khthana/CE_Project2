#pragma once

#ifndef PJ4D_AI
#define PJ4D_AI

class CAi;

#include "world.h"
#include "unit.h"
#include <fstream>
#include <vector>
using std::ifstream;
using std::ofstream;
using std::vector;

class CAi
{
	class CLog {
	public:
		double inpt[53];	//48 world + 2 (action | target) + 1 threshold
		double otpA[2];	//2 action
		double otpT[2];	//2 target
	};

	//Neural Network
	double _wgAH[25][51];
	double _wgAO[2][26];
	double _wgTH[25][51];
	double _wgTO[2][26];

	double _otAH[26];
	double _otAO[2];
	double _otTH[26];
	double _otTO[2];

	vector<CLog> _log;	//51 + 2

	CWorld* _wrld;
public:
	CAi(void);
	~CAi(void);
	void activate(double inpt[51]);
	void load(const char* file);
	void save(const char* file);
	void setWorld(CWorld* wrld);
	void active(CUnit* unit);
	void passive(CUnit* unit);
	void log(CUnit* unit, int actn, int trgX, int trgY);
	void learn(void);
private:
	int _actn;
	double _trgX;
	double _trgY;
public:
	void control(CUnit* unit);
};

#endif
