#ifndef PJ4D_GLBL
#define PJ4D_GLBL

#include <windows.h>
#include <time.h>
#include <math.h>
#include <sstream>
using std::string;
using std::istringstream;
using std::ostringstream;

double random();	//[0-1]
double distance(double x1, double y1, double x2, double y2);
double curve(double valu, double degr = 0.5);	//valu = [0, 100] > return [0, 100]

string toString(double dobl);
string toString(char* chrs);
double toDouble(string strn);

#endif
