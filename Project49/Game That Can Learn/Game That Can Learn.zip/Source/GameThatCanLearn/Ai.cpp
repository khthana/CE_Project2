#include ".\ai.h"

CAi::CAi(void)
: _wrld(NULL)
, _actn(0)
, _trgX(0)
, _trgY(0)
{
}

CAi::~CAi(void)
{
}

void CAi::activate(double inpt[51])
{
	//Action
	//Process
	for (int n = 0; n < 25; n++) {
		_otAH[n] = 0;
		for (int w = 0; w < 51; w++) {
			_otAH[n] += inpt[n] * _wgAH[n][w];
		}
		_otAH[n] = 1 / (1 + pow(2.71828182845904523536, -_otAH[n]));	////e = 2.71828182845904523536
	}
	_otAH[25] = -1;
	for (int n = 0; n < 2; n++) {
		_otAO[n] = 0;
		for (int w = 0; w < 26; w++) {
			_otAO[n] += _otAH[w] * _wgAO[n][w];
		}
		_otAO[n] = 1 / (1 + pow(2.71828182845904523536, -_otAO[n]));	////e = 2.71828182845904523536
	}
	//Set decision
	if (_otAO[0] > _otAO[1]) {
		_actn = UNIT_MOVE;
	} else {
		_actn = UNIT_ATCK;
	}
	//Target
	inpt[48] = (_actn == UNIT_MOVE);	//action move
	inpt[49] = (_actn == UNIT_ATCK);	//action attack
	//Process
	for (int n = 0; n < 25; n++) {
		_otTH[n] = 0;
		for (int w = 0; w < 51; w++) {
			_otTH[n] += inpt[n] * _wgTH[n][w];
		}
		_otTH[n] = 1 / (1 + pow(2.71828182845904523536, -_otAH[n]));	////e = 2.71828182845904523536
	}
	_otTH[25] = -1;
	for (int n = 0; n < 2; n++) {
		_otTO[n] = 0;
		for (int w = 0; w < 26; w++) {
			_otTO[n] += _otTH[w] * _wgTO[n][w];
		}
		_otTO[n] = 1 / (1 + pow(2.71828182845904523536, -_otAO[n]));	////e = 2.71828182845904523536
	}
	//Set decision
	_trgX = _otTO[0];
	_trgY = _otTO[1];
}

void CAi::load(const char* file)
{
	ifstream ifst(file);
	for (int n = 0; n < 25; n++) {
		for (int w = 0; w < 51; w++) {
			ifst >> _wgAH[n][w];
			ifst >> _wgTH[n][w];
		}
	}
	for (int n = 0; n < 2; n++) {
		for (int w = 0; w < 26; w++) {
			ifst >> _wgAO[n][w];
			ifst >> _wgTO[n][w];
		}
	}
}

void CAi::save(const char* file)
{
	ofstream ofst(file);
	for (int n = 0; n < 25; n++) {
		for (int w = 0; w < 51; w++) {
			ofst << _wgAH[n][w] << " ";
			ofst << _wgTH[n][w] << " ";
		}
	}
	for (int n = 0; n < 2; n++) {
		for (int w = 0; w < 26; w++) {
			ofst << _wgAO[n][w] << " ";
			ofst << _wgTO[n][w] << " ";
		}
	}
}

void CAi::setWorld(CWorld* wrld)
{
	_wrld = wrld;
}

void CAi::active(CUnit* unit)
{
	//Arrange
	double inpt[51];
	int x = unit->positionX() - 3;
	int y = unit->positionY() - 3;
	int pstn = 0;
	CUnit* trgt;
	for (int i = 0; i < 48; i++) {
		if (pstn == 24) {
			pstn++;
		}
		trgt = _wrld->unitAt(pstn % 7 + x, pstn / 7 + y);
		if (trgt == NULL) {
			inpt[pstn] = 0;
		} else if (trgt->team() == UNIT_NTRL) {
			inpt[pstn] = 0;
		} else if (trgt->team() == unit->team()) {
			inpt[pstn] = 1;
		} else {
			inpt[pstn] = -1;
		}
		pstn++;
	}
	inpt[48] = (unit->action() == UNIT_MOVE);
	inpt[49] = (unit->action() == UNIT_ATCK);
	inpt[50] = -1;	//Threshold

	activate(inpt);

	unit->setAction(_actn);
	x = _trgX * 7 - 3 + (int)unit->positionX();
	y = _trgY * 7 - 3 + (int)unit->positionY();
	if (_actn == UNIT_MOVE) {
		unit->setTarget(x, y);
	} else {
		unit->setTarget(_wrld->unitAt(x, y));
	}
}

void CAi::passive(CUnit* unit)
{
	if (unit->action() == UNIT_STOP) {
		unit->setAction(UNIT_MOVE);
		double x = random() * 7 - 3 + (int)unit->positionX();
		double y = random() * 7 - 3 + (int)unit->positionY();
		unit->setTarget(x, y);
	}
}

void CAi::log(CUnit* unit, int actn, int trgX, int trgY)
{
	//Arrange
	CLog log;
	int x = unit->positionX() - 3;
	int y = unit->positionY() - 3;
	int pstn = 0;
	CUnit* trgt;
	for (int i = 0; i < 48; i++) {
		if (pstn == 24) {
			pstn++;
		}
		trgt = _wrld->unitAt(pstn % 7 + x, pstn / 7 + y);
		if (trgt == NULL) {
			log.inpt[pstn] = 0;
		} else if (trgt->team() == UNIT_NTRL) {
			log.inpt[pstn] = 0;
		} else if (trgt->team() == unit->team()) {
			log.inpt[pstn] = 1;
		} else {
			log.inpt[pstn] = -1;
		}
		pstn++;
	}
	log.inpt[48] = (unit->action() == UNIT_MOVE);
	log.inpt[49] = (unit->action() == UNIT_ATCK);
	log.inpt[50] = -1;	//Threshold
	log.otpA[0] = (actn == UNIT_MOVE);	//Output action move
	log.otpA[1] = (actn == UNIT_ATCK);	//Output action attack
	double tX = (trgX - unit->positionX() + 3) / 7;
	if (tX < 0) {
		tX = 0;
	}
	if (tX > 1) {
		tX = 1;
	}
	double tY = (trgY - unit->positionY() + 3) / 7;
	if (tY < 0) {
		tY = 0;
	}
	if (tY > 1) {
		tY = 1;
	}
	log.otpT[0] = tX;	//Output target x
	log.otpT[1] = tY;	//Output target y
	//Save
	_log.push_back(log);
}

void CAi::learn(void)
{
	double errO[2];
	double errH[26];
	for (int i = 0; i < _log.size(); i++) {
		//Activate
		activate(_log[i].inpt);
		//Action
		//Error
		errO[0] = _log[i].otpA[0] - (double)(_actn == UNIT_MOVE);
		errO[1] = _log[i].otpA[1] - (double)(_actn == UNIT_ATCK);
		//Learn
		for (int n = 0; n < 2; n++) {
			for (int w = 0; w < 26; w++) {
				errH[w] = 0;
			}
			for (int w = 0; w < 26; w++) {
				errH[w] += errO[n] * _wgAO[n][w];
				_wgAO[n][w] += _otAH[w] * errO[n] * 0.1;
			}
			for (int w = 0; w < 26; w++) {
				errH[w] = 1 / (1 + pow(2.71828182845904523536, -errH[w]));
				errH[w] = errH[w] * (1 - errH[w]);
			}
		}
		for (int n = 0; n < 25; n++) {
			for (int w = 0; w < 51; w++) {
				_wgAH[n][w] += _log[i].inpt[w] * errH[n] * 0.1;
			}
		}
		//Target
		//Error
		_log[i].inpt[48] = _log[i].inpt[51];
		_log[i].inpt[49] = _log[i].inpt[52];
		errO[0] = _trgX - _log[i].otpT[0];
		errO[1] = _trgY - _log[i].otpT[1];
		//Learn
		for (int n = 0; n < 2; n++) {
			for (int w = 0; w < 26; w++) {
				errH[w] = 0;
			}
			for (int w = 0; w < 26; w++) {
				errH[w] += errO[n] * _wgTO[n][w];
				_wgTO[n][w] += _otTH[w] * errO[n] * 0.1;
			}
			for (int w = 0; w < 26; w++) {
				errH[w] = 1 / (1 + pow(2.71828182845904523536, -errH[w]));
				errH[w] = errH[w] * (1 - errH[w]);
			}
		}
		for (int n = 0; n < 25; n++) {
			for (int w = 0; w < 51; w++) {
				_wgTH[n][w] += _log[i].inpt[w] * errH[n] * 0.1;
			}
		}
	}
}

void CAi::control(CUnit* unit)
{
	bool mode = false;
	vector<CUnit*> list = _wrld->unit();
	for (int i = 0; i < list.size(); i++) {
		if (list[i]->team() != unit->team() && list[i]->team() != UNIT_NTRL && distance((int)unit->positionX(), (int)unit->positionY(), (int)list[i]->positionX(), (int)list[i]->positionY()) < 3) {
			mode = true;
		}
	}
	if (mode) {
		active(unit);
	} else {
		passive(unit);
	}
}
