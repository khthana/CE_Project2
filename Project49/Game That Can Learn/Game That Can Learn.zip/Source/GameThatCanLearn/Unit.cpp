#include ".\unit.h"
//Unit
CUnit::CUnit()
: _wrld(NULL)
, _scrn(NULL)
, _dely(0)
, _mode(UNIT_AI)
, _ai(NULL)
, _trgt(NULL)
, _dlyM(0)
, _dlyA(0)
{
	setName("Neutral");
	setType(0);
	setParameter(1, 1, 1);
	setExtension(0, 0, 0);
	setBluff(0, 0, 0);
	setPower(100, 100);
	setRegeneration(0, 0);
	setPosition(0, 0);
	setTarget(0, 0);
	setTeam(0);
	setAction(0);
}

CUnit::~CUnit() {
}

void CUnit::setName(string name) {
	_name = name;
}

void CUnit::setType(int type) {
	_type = type;
}

void CUnit::setParameter(double strn, double aglt, double intl) {
	_strn = strn;
	_aglt = aglt;
	_intl = intl;
}

void CUnit::setExtension(double strn, double aglt, double intl) {
	_strnX = strn;
	_agltX = aglt;
	_intlX = intl;
}

void CUnit::setBluff(double strn, double aglt, double intl) {
	_strnB = strn;
	_agltB = aglt;
	_intlB = intl;
}

void CUnit::setPower(double hit, double mana) {
	_hit = hit;
	_mana = mana;
}

void CUnit::setRegeneration(double hit, double mana) {
	_hitR = hit;
	_manaR = mana;
}

void CUnit::setPosition(double x, double y) {
	_pstnX = x;
	_pstnY = y;
}

void CUnit::setTarget(double x, double y) {
	_trgtX = x;
	_trgtY = y;
}

void CUnit::setTeam(int team) {
	_team = team;
}

void CUnit::setAction(int actn) {
	_actn = actn;
}

void CUnit::setWorld(CWorld* wrld)
{
	_wrld = wrld;
}

string CUnit::name() {
	return _name;
}

int CUnit::type() {
	return _type;
}

double CUnit::strength() {
	return _strn + _strnX + _strnB;
}

double CUnit::agility() {
	return _aglt + _agltX + _agltB;
}

double CUnit::intelligent() {
	return _intl + _intlX + _intlB;
}

double CUnit::positionX() {
	return _pstnX;
}

double CUnit::positionY() {
	return _pstnY;
}

double CUnit::targetX() {
	return _trgtX;
}

double CUnit::targetY() {
	return _trgtY;
}

int CUnit::team() {
	return _team;
}

int CUnit::action() {
	return _actn;
}

int CUnit::frame()
{
	if (_actn == UNIT_MOVE) {
		return _dlyM / 400;
	}
	if (_actn == UNIT_ATCK) {
		if (_dlyA < 200) {
			return 1;
		}
		return 0;
	}
	//Stop
	return 0;
}

double CUnit::range() {
	return curve(intelligent() / 100) * 2 + 1.2;	//1.2
}

void CUnit::save() {
	ofstream ofst((_name + ".unt").data());
	ofst << _type << " ";
	ofst << _strn << " ";
	ofst << _aglt << " ";
	ofst << _intl << " ";
}

void CUnit::load(string name)
{
	_name = name;
	ifstream ifst((name + ".unt").data());
	ifst >> _type;
	ifst >> _strn;
	ifst >> _aglt;
	ifst >> _intl;
	_ai = _wrld->ai()[_type];
}

void CUnit::move(int time)
{
	if (_dlyM <= 0) {
		_dlyM += 800;
	}
	if ((int)_pstnX != (int)_trgtX || (int)_pstnY != (int)_trgtY) {
		double dX = _trgtX - _pstnX;
		double dY = _trgtY - _pstnY;
		double dT = distance(_pstnX, _pstnY, _trgtX, _trgtY);
		dX = _pstnX + dX / dT * time / 1000.0 * (curve(agility() / 100) + 1);
		dY = _pstnY + dY / dT * time / 1000.0 * (curve(agility() / 100) + 1);
		CUnit* unit = _wrld->unitAt(dX, dY);
		if ((unit == NULL || unit == this) && dX >= 0 && dX < 16 && dY >= 0 && dY < 16) {
			_pstnX = dX;
			_pstnY = dY;
		} else {
			stop();
		}
	} else {
		stop();
	}
}

void CUnit::attack(int time)
{
	if (_trgt == NULL || _trgt == this) {
		stop();
		return;
	}

	_trgtX = _trgt->positionX();
	_trgtY = _trgt->positionY();
	if (distance((int)_pstnX, (int)_pstnY, (int)_trgtX, (int)_trgtY) <= range()) {
		//Do damage
		if (_dlyA <= 0) {
			_dlyA = 1000;
			int damg = curve(strength() / 100) * 100;
			_trgt->damage(damg);
			_scrn->message(_name + " �������ҧ����������� " + toString(damg));
		} else if (_dlyA < 200) {
			//_scrn->message(_name + ": AttackHit (" + toString((int)_pstnX) + ", " + toString((int)_pstnY) + ") > (" + toString((int)_trgtX) + ", " + toString((int)_trgtY) + ")");
		}
	} else {
		move(time);
	}
}

void CUnit::update(int time)
{
	//Die
	if (_hit <= 0) {
		_hit = 100;
		_pstnX = random() * 16;
		_pstnY = random() * 16;
		_scrn->message(_name + " ���");
	}
	//AI decision
	if (_mode == UNIT_AI && _ai != NULL) {
		_ai->control(this);
	}
	//Do action
	_dlyM -= time;
	_dlyA -= time;
	if (_actn == UNIT_MOVE) {
		move(time);
	} else if (_actn == UNIT_ATCK) {
		attack(time);
	}
	if (_dlyM < 0) {
		_dlyM = 0;
	}
	if (_dlyA < 0) {
		_dlyA = 0;
	}
}

void CUnit::setScreen(CScreen* scrn)
{
	_scrn = scrn;
}

void CUnit::setMode(int mode)
{
	_mode = mode;
}

int CUnit::mode(void)
{
	return _mode;
}

void CUnit::stop()
{
	_actn = UNIT_STOP;
}

void CUnit::setAi(CAi* ai)
{
	_ai = ai;
}

void CUnit::setTarget(CUnit* trgt)
{
	_trgt = trgt;
	if (trgt != NULL) {
		_trgtX = trgt->positionX();
		_trgtY = trgt->positionY();
	}
}

void CUnit::damage(double damg)
{
	_hit -= damg;
}
