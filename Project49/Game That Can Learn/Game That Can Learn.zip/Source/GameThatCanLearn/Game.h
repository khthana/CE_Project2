#pragma once

#ifndef PJ4D_GAME
#define PJ4D_GAME

class CGame;

#include "controller.h"
#include "screen.h"
#include "world.h"

class CGame
{
	CController _cntr;
	CScreen _scrn;
	CWorld _wrld;

	int _actn;
public:
	CGame(void);
	~CGame(void);

	bool initialize(HWND hWnd);
	void update(void);
	void save(const char* file);
};

#endif
