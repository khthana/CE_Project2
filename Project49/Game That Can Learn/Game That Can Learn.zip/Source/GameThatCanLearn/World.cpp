#include ".\world.h"

CWorld::CWorld()
: _slctUnit(NULL)
, _scrn(NULL)
{
	_time = timeGetTime();
}

CWorld::~CWorld() {
	clearUnit();
	clearAi();
}

vector<CUnit*> CWorld::unit() {
	return _unit;
}

CUnit* CWorld::unitAt(double x, double y) {
	for (int i = 0; i < _unit.size(); i++) {
		if ((int)x == (int)_unit[i]->positionX() && (int)y == (int)_unit[i]->positionY()) {
			return _unit[i];
		}
	}
	return NULL;
}

CUnit* CWorld::newUnit() {
	double x, y;
	do {
		x = random() * 16;
		y = random() * 16;
	} while (unitAt(x, y) != NULL);

	CUnit* unit = new CUnit;
	unit->setWorld(this);
	unit->setScreen(_scrn);
	unit->setPosition(x, y);
	unit->setTarget(x, y);
	_unit.push_back(unit);
	return unit;
}

CAi* CWorld::newAi(const char* file)
{
	CAi* ai = new CAi;
	ai->setWorld(this);
	ai->load(file);
	_ai.push_back(ai);
	return ai;
}

void CWorld::update(void)
{
	int time_ = timeGetTime();
	int time = time_ - _time;
	if (time < 0) {
		time = 0;
	}
	_time = time_;

	for (int i = 0; i < _unit.size(); i++) {
		_unit[i]->update(time);
	}
}

CUnit* CWorld::selectedUnit(void)
{
	return _slctUnit;
}

void CWorld::setScreen(CScreen* scrn)
{
	_scrn = scrn;
}

bool CWorld::initialize(CScreen* scrn)
{
	setScreen(scrn);
	return true;
}

void CWorld::select(CUnit* unit)
{
	if (unit != NULL) {
		if (unit->team() == UNIT_ALLY) {
			if (_slctUnit != NULL) {
				_slctUnit->setMode(UNIT_AI);
			}
			_slctUnit = unit;
			_slctUnit->setMode(UNIT_PLAYER);
		}
	} else {
		if (_slctUnit != NULL) {
			_slctUnit->setMode(UNIT_AI);
		}
		_slctUnit = unit;
	}
}

void CWorld::clearUnit(void)
{
	CUnit* unit;
	for (int i = 0; i < _unit.size(); i++) {
		unit = _unit[i];
		delete unit;
	}
}

void CWorld::clearAi(void)
{
	CAi* ai;
	for (int i = 0; i < _ai.size(); i++) {
		ai = _ai[i];
		delete ai;
	}
}

vector<CAi*> CWorld::ai(void)
{
	return _ai;
}
