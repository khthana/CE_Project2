#include ".\screen.h"

//Screen
CScreen::CScreen(void)
: g_pD3D(NULL)	// Used to create the D3DDevice
, g_pd3dDevice(NULL)	// Our rendering device
, g_lp3dxfont(NULL)
, _lokX(0)
, _lokY(0)
, _lokZ(0)
, _eyeH(0)
, _eyeV(0)
, _eyeD(0)
, _crsX(0)
, _crsY(0)
, _crsZ(0)
, _pntX(0)
, _pntY(0)
, _crsr(NULL)
, _pntr(NULL)
, _cntr(NULL)
, _wrld(NULL)
{
}

CScreen::~CScreen(void)
{
	if( g_pd3dDevice != NULL )
        g_pd3dDevice->Release();

    if( g_pD3D != NULL )
        g_pD3D->Release();
}

bool CScreen::initD3D(HWND hWnd)
{
    // Create the D3D object.
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return false;

    // Set up the structure used to create the D3DDevice. Since we are now
    // using more complex geometry, we will create a device with a zbuffer.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    // Create the D3DDevice
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return false;
    }

    // Turn on the zbuffer
    g_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

    // Turn on ambient lighting 
    g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0xffffffff );

	// Turn off culling, so we see the front and back of the triangle
    //g_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

    // Turn off D3D lighting, since we are providing our own vertex colors
    g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, true );
	
	//Transparent
	g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
	g_pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	g_pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

    return true;
}

bool CScreen::initFont(void)
{

	//Create LPD3DXFONT interface   
	HDC hDC = GetDC( NULL );
	if(FAILED(D3DXCreateFont(g_pd3dDevice,16,0,FW_NORMAL,0,FALSE,DEFAULT_CHARSET
						,OUT_DEFAULT_PRECIS,ANTIALIASED_QUALITY,VARIABLE_PITCH
						,"Microsoft sans serif",&g_lp3dxfont)))
	{
		MessageBox(NULL,"Couldn't create LPD3DXFONT interface",
		"ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}
	ReleaseDC( NULL, hDC );

	return true;
}

bool CScreen::initialize(HWND hWnd, CController* cntr, CWorld* wrld)
{
	if (!initD3D(hWnd)) {
		return false;
	}

	if (!initFont()) {
		return false;
	}

	//Load Cursor
	_crsr = new CVertex;
	_crsr->setDevice(g_pd3dDevice);
	_crsr->load("cursor.png");

	//Load Pointer
	_pntr = new CSprite;
	_pntr->setDevice(g_pd3dDevice);
	_pntr->load("pointer.png");

	setLook(8, 8, 0.5);
	setEye(D3DX_PI / -2, D3DX_PI / -4, 8);
	setPointer(512, 384);

	setController(cntr);
	setWorld(wrld);

	return true;
}

void CScreen::setLook(double x, double y, double z)
{
	_lokX = x;
	_lokY = y;
	_lokZ = z;
}

void CScreen::moveLook(double x, double y, double z)
{
	_lokX += x;
	_lokY += y;
	_lokZ += z;
}

void CScreen::setEye(double h, double v, double d)
{
	_eyeH = h;
	_eyeV = v;
	_eyeD = d;

	_eyeH -= (int)(_eyeH / D3DX_PI / 2) * D3DX_PI * 2;
	_eyeV -= (int)(_eyeV / D3DX_PI / 2) * D3DX_PI * 2;
	if (_eyeH < 0) {
		_eyeH += D3DX_PI * 2;
	}
	if (_eyeV < 0) {
		_eyeV += D3DX_PI * 2;
	}
	if (_eyeV > D3DX_PI * 23 / 12) {
		_eyeV = D3DX_PI * 23 / 12;
	} else if (_eyeV < D3DX_PI * 5 / 3) {
		_eyeV = D3DX_PI * 5/ 3;
	}
	if (_eyeD < 2) {
		_eyeD = 2;
	}
}

void CScreen::moveEye(double h, double v, double d)
{
	_eyeH += h;
	_eyeV += v;
	_eyeD += d;

	setEye(_eyeH, _eyeV, _eyeD);
}

void CScreen::setCursor(double x, double y, double z)
{
	_crsX = x;
	_crsY = y;
	_crsZ = z;
}

void CScreen::moveCursor(double x, double y, double z)
{
	_crsX += x;
	_crsY += y;
	_crsZ += z;
}

void CScreen::setPointer(int x, int y)
{
	_pntX = x;
	_pntY = y;
	if (_pntX < 0) {
		_pntX = 0;
	} else if (_pntX > 1023) {
		_pntX = 1023;
	}
	if (_pntY < 0) {
		_pntY = 0;
	} else if (_pntY > 767) {
		_pntY = 767;
	}
}

void CScreen::movePointer(int x, int y)
{
	_pntX += x;
	_pntY += y;
	setPointer(_pntX, _pntY);
}

void CScreen::setController(CController* cntr)
{
	_cntr = cntr;
}

void CScreen::setWorld(CWorld* wrld)
{
	_wrld = wrld;
}

double CScreen::eyeX(void)
{
	return cos(_eyeH) * cos(_eyeV) * _eyeD + _lokX;
}

double CScreen::eyeY(void)
{
	return sin(_eyeH) * cos(_eyeV) * _eyeD + _lokY;
}

double CScreen::eyeZ(void)
{
	return sin(-_eyeV) * _eyeD + _lokZ;
}

double CScreen::cursorX(void)
{
	return _crsX;
}

double CScreen::cursorY(void)
{
	return _crsY;
}

double CScreen::cursorZ(void)
{
	return _crsZ;
}

void CScreen::newMesh(char* file, bool mode)
{
	CMesh* mesh = new CMesh;
	mesh->setDevice(g_pd3dDevice);
	if (mode) {
		mesh->load(file);
	} else {
		mesh->loadConfig(file);
	}
	_mesh.push_back(mesh);
}

void CScreen::newVertex(char* file)
{
	CVertex* vrtx = new CVertex;
	vrtx->setDevice(g_pd3dDevice);
	vrtx->load(file);
	_vrtx.push_back(vrtx);
}

void CScreen::newSprite(char* file)
{
	CSprite* sprt = new CSprite;
	sprt->setDevice(g_pd3dDevice);
	sprt->load(file);
	_sprt.push_back(sprt);
}

void CScreen::message(string mesg)
{
	if (_mesg.size() >= 11) {
		_mesg.erase(_mesg.begin());
	}
	_mesg.push_back(mesg);
}

void CScreen::printText(string text, int left, int top, int r, int g, int b)
{
	RECT Rect;
	Rect.left=left;
	Rect.top=top;
	Rect.right=left;
	Rect.bottom=top;
	g_lp3dxfont->DrawText(NULL,text.data(),-1,&Rect, DT_TOP | DT_LEFT | DT_NOCLIP ,D3DCOLOR_XRGB(r, g, b));
}

void CScreen::render(void)
{
	// Clear the backbuffer and the zbuffer
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 
                         D3DCOLOR_XRGB(32,64,0), 1.0f, 0 );
    
    // Begin the scene
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
		//Map
		if (0 < _mesh.size()) {
			_mesh[0]->render();
		}

		//Cursor
		double cX = _crsX;
		double cY = _crsY;
		if (cX < 0) {
			cX -= 1;
		}
		if (cY < 0) {
			cY -= 1;
		}
		_crsr->render((int)cX, (int)cY, 0.01, D3DX_PI / -2, 0, 0);

		//Unit
		vector<CUnit*> unit = _wrld->unit();
		double uX, uY, uX_, uY_, uD, uV, uH, uH_;
		double tX, tY, tX_, tY_, tD, tH, tH_;
		int drct = 0;
		for (int i = unit.size() - 1; i >= 0; i--) {
			uX = unit[i]->positionX();
			uY = unit[i]->positionY();
			//Face to Eye Point
			uX_ = uX - eyeX();
			uY_ = uY - eyeY();
			uD = sqrt(uX_ * uX_ + uY_ * uY_);
			uV = -atan(eyeZ() / uD);
			uH = _eyeH - D3DX_PI * 3 / 2;
			//Direction Frame
			uH_ = atan(uY_ / uX_) - _eyeH + D3DX_PI / 2;
			if (uX_ < 0) {
				uH_ += D3DX_PI;
			}
			uX_ = uD * -cos(uH_);
			uY_ = uD * -sin(uH_);
			
			tX = unit[i]->targetX();
			tY = unit[i]->targetY();
			tX_ = tX - eyeX();
			tY_ = tY - eyeY();
			tD = sqrt(tX_ * tX_ + tY_ * tY_);
			tH = atan(tY_ / tX_) - _eyeH + D3DX_PI / 2;
			if (tX_ < 0) {
				tH += D3DX_PI;
			}
			tX_ = tD * -cos(tH);
			tY_ = tD * -sin(tH);

			tH_ = atan((tY_ - uY_) / (tX_ - uX_));
			if (tY_ < uY_) {
				tH_ += D3DX_PI;
			}
			tH_ -= (int)(tH_ / (D3DX_PI * 2)) * D3DX_PI * 2;
			if (tH_ < 0) {
				tH_ += D3DX_PI * 2;
			}
			drct = tH_ / (D3DX_PI / 2);

			uX -= cos(uH) / 2;
			uY -= sin(uH) / 2;
			_vrtx[8 * unit[i]->type() + 2 * drct + unit[i]->frame()]->render(uX, uY, 0, uV, 0, uH);
			//_vrtx[24 * unit[i]->type() + 8 * unit->action() + 2 * drct + unit->frame()]->render(uX, uY, 0, uV, 0, uH);
		}

		//Console
		_sprt[0]->render(0, 0);

		//Message
		int y = 768 - _mesg.size() * 16;
		for (int i = 0; i <_mesg.size(); i++) {
			printText(_mesg[i], 16, i * 16 + y - 10 , 255, 255, 255);
		}

		//Pointer
		_pntr->render(_pntX, _pntY);

		//Set View & Projection
		// Set up our view matrix. A view matrix can be defined given an eye point,
		// a point to lookat, and a direction for which way is up. Here, we set the
		// eye five units back along the z-axis and up three units, look at the 
		// origin, and define "up" to be in the y-direction.
		D3DXVECTOR3 vLookatPt(_lokX, _lokZ, _lokY);
		D3DXVECTOR3 vEyePt(eyeX(), eyeZ(), eyeY());
		D3DXVECTOR3 vUpVec(0, 1, 0);
		D3DXMATRIXA16 matView;
		D3DXMatrixLookAtLH( &matView, &vEyePt, &vLookatPt, &vUpVec );
		g_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

		// For the projection matrix, we set up a perspective transform (which
		// transforms geometry from 3D view space to 2D viewport space, with
		// a perspective divide making objects smaller in the distance). To build
		// a perpsective transform, we need the field of view (1/4 pi is common),
		// the aspect ratio, and the near and far clipping planes (which define at
		// what distances geometry should be no longer be rendered).
		D3DXMATRIXA16 matProj;
		D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, 4.0 / 3, 1.0f, 100.0f );
		g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

        // End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}

void CScreen::update(void)
{
	//Update Pointer
	movePointer(_cntr->mouseX(), _cntr->mouseY());
	//Update Cursor
	double dZ = 927;	//927?
	double dX = _pntX - 512;
	double dY = _pntY - 384;
	double cV_ = atan(dY / dZ);
	double cV = _eyeV - cV_;
	double cY_ = _eyeD * sin(_eyeV) * cos(cV) / sin(cV);
	double cX = dX * cY_ * cos(cV_) / dZ / cos(cV);
	double cY = cY_ - _eyeD * cos(_eyeV);
	_crsX = cX * sin(-_eyeH) - cY * cos(_eyeH) + _lokX;
	_crsY = cX * cos(_eyeH) + cY * sin(-_eyeH) + _lokY;
	//Update Look
	CUnit* unit = _wrld->selectedUnit();
	if (unit != NULL) {
		setLook(unit->positionX(), unit->positionY(), 0.5);
	}
	//Refresh Screen
	render();
}
//Model
CMesh::CMesh(void)
: g_pd3dDevice(NULL)
, g_pMesh(NULL)	// Our mesh object in sysmem
, g_pMeshMaterials(NULL)	// Materials for our mesh
, g_pMeshTextures(NULL)	// Textures for our mesh
, g_dwNumMaterials(0)	// Number of mesh materials
, _pstX(0)
, _pstY(0)
, _pstZ(0)
, _angX(0)
, _angY(0)
, _angZ(0)
, _scal(1)
{
}

CMesh::~CMesh(void)
{
	if( g_pMeshMaterials != NULL ) 
        delete[] g_pMeshMaterials;

    if( g_pMeshTextures )
    {
        for( DWORD i = 0; i < g_dwNumMaterials; i++ )
        {
            if( g_pMeshTextures[i] )
                g_pMeshTextures[i]->Release();
        }
        delete[] g_pMeshTextures;
    }
    if( g_pMesh != NULL )
        g_pMesh->Release();
}

void CMesh::setDevice(LPDIRECT3DDEVICE9 devc)
{
	g_pd3dDevice = devc;
}

HRESULT CMesh::load(const char* xFile)
{
    LPD3DXBUFFER pD3DXMtrlBuffer;

    // Load the mesh from the specified file
    if( FAILED( D3DXLoadMeshFromX( xFile, D3DXMESH_SYSTEMMEM, 
                                   g_pd3dDevice, NULL, 
                                   &pD3DXMtrlBuffer, NULL, &g_dwNumMaterials, 
                                   &g_pMesh ) ) )
    {
		MessageBox(NULL, xFile, "Error: loadModel()", MB_OK);
        return E_FAIL;
    }

    // We need to extract the material properties and texture names from the 
    // pD3DXMtrlBuffer
    D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
    g_pMeshMaterials = new D3DMATERIAL9[g_dwNumMaterials];
    if( g_pMeshMaterials == NULL )
        return E_OUTOFMEMORY;
    g_pMeshTextures  = new LPDIRECT3DTEXTURE9[g_dwNumMaterials];
    if( g_pMeshTextures == NULL )
        return E_OUTOFMEMORY;

    for( DWORD i=0; i<g_dwNumMaterials; i++ )
    {
        // Copy the material
        g_pMeshMaterials[i] = d3dxMaterials[i].MatD3D;

        // Set the ambient color for the material (D3DX does not do this)
        g_pMeshMaterials[i].Ambient = g_pMeshMaterials[i].Diffuse;

        g_pMeshTextures[i] = NULL;
        if( d3dxMaterials[i].pTextureFilename != NULL && 
            lstrlen(d3dxMaterials[i].pTextureFilename) > 0 )
        {
            // Create the texture
            if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, 
                                                d3dxMaterials[i].pTextureFilename, 
                                                &g_pMeshTextures[i] ) ) )
            {
                // If texture is not in current folder, try parent folder
                const TCHAR* strPrefix = TEXT("..\\");
                TCHAR strTexture[MAX_PATH];
                StringCchCopy( strTexture, MAX_PATH, strPrefix );
                StringCchCat( strTexture, MAX_PATH, d3dxMaterials[i].pTextureFilename );
                // If texture is not in current folder, try parent folder
                if( FAILED( D3DXCreateTextureFromFile( g_pd3dDevice, 
                                                    strTexture, 
                                                    &g_pMeshTextures[i] ) ) )
                {
                    MessageBox(NULL, "Could not find texture map", "Meshes.exe", MB_OK);
                }
            }
        }
    }

    // Done with the material buffer
    pD3DXMtrlBuffer->Release();

    return S_OK;
}

void CMesh::loadConfig(char* file)
{
	ifstream ifst(file);
	string xFil;
	ifst >> xFil;
	load(xFil.data());
	ifst >> _pstX;
	ifst >> _pstY;
	ifst >> _pstZ;
	ifst >> _angX;
	ifst >> _angY;
	ifst >> _angZ;
	ifst >> _scal;
}

void CMesh::render(double pX, double pY, double pZ, double aX, double aY, double aZ, double s)
{
	pX += _pstX;
	pY += _pstY;
	pZ += _pstZ;
	aX += _angX;
	aY += _angY;
	aZ += _angZ;
	s *= _scal;
    // Set up world matrix
    D3DXMATRIXA16 pstn, angX, angY, angZ, scal;
	D3DXMatrixTranslation(&pstn, pX, pZ, pY);
    D3DXMatrixRotationX(&angX, -aX);
    D3DXMatrixRotationY(&angZ, -aZ);
    D3DXMatrixRotationZ(&angY, -aY);
	D3DXMatrixScaling(&scal, s, s, s);
	scal *= angX * angY * angZ * pstn;
    g_pd3dDevice->SetTransform( D3DTS_WORLD, &scal );

	// Meshes are divided into subsets, one for each material. Render them in
    // a loop
    for( DWORD i=0; i<g_dwNumMaterials; i++ )
    {
        // Set the material and texture for this subset
        g_pd3dDevice->SetMaterial( &g_pMeshMaterials[i] );
        g_pd3dDevice->SetTexture( 0, g_pMeshTextures[i] );
    
        // Draw the mesh subset
        g_pMesh->DrawSubset( i );
    }
}
//Sprite
CVertex::CVertex(void)
: g_pd3dDevice(NULL)
, g_pVB(NULL)
, g_Texture(NULL)
, g_pIndexBuffer(NULL)
{
}

CVertex::~CVertex(void)
{
	if(g_pVB)
		g_pVB->Release();

	if(g_Texture)
		g_Texture->Release();

	if(g_pIndexBuffer)
		g_pIndexBuffer->Release();
}

void CVertex::setDevice(LPDIRECT3DDEVICE9 devc)
{
	g_pd3dDevice = devc;
}

HRESULT CVertex::load(const char* file)
{
    // Initialize three vertices for rendering a triangle
	CUSTOMVERTEX g_Vertices[] =
    {
        {0, 0, 0, 0, 0, 0, 0, 1},
        {0, 1, 0, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 0, 0, 1, 0},
        {1, 0, 0, 0, 0, 0, 1, 1}
    };

    // Create the vertex buffer.
    if( FAILED( g_pd3dDevice->CreateVertexBuffer( 4*sizeof(CUSTOMVERTEX),
                                                  0, (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1),
                                                  D3DPOOL_DEFAULT, &g_pVB, NULL ) ) )
    {
        return E_FAIL;
    }

    // Fill the vertex buffer.
    VOID* pVertices;
    if( FAILED( g_pVB->Lock( 0, sizeof(g_Vertices), (void**)&pVertices, 0 ) ) )
        return E_FAIL;
    memcpy( pVertices, g_Vertices, sizeof(g_Vertices) );
    g_pVB->Unlock();

	//Create index buffer
	if(FAILED(g_pd3dDevice->CreateIndexBuffer(sizeof(short)*6,
		0, D3DFMT_INDEX16,
		D3DPOOL_DEFAULT, &g_pIndexBuffer, NULL)))
	{
		return E_FAIL;
	}

	//Fill index buffer
	short Indices[6] = {0, 1, 2, 3, 0, 2};
	VOID* IndexData = NULL;
	if(SUCCEEDED(g_pIndexBuffer->Lock(0, 0, &IndexData, 0)))
	{
		memcpy(IndexData, (void*) &Indices, sizeof(Indices));
		g_pIndexBuffer->Unlock();
	}

	D3DXCreateTextureFromFile(g_pd3dDevice, file, &g_Texture);

    return S_OK;
}

void CVertex::render(double pX, double pY, double pZ, double aX, double aY, double aZ, double s)
{	
    // Set up world matrix
    D3DXMATRIXA16 pstn, angX, angY, angZ, scal;
	D3DXMatrixTranslation(&pstn, pX, pZ, pY);
    D3DXMatrixRotationX(&angX, -aX);
    D3DXMatrixRotationY(&angZ, -aZ);
    D3DXMatrixRotationZ(&angY, -aY);
	D3DXMatrixScaling(&scal, s, s, s);
	scal *= angX * angY * angZ * pstn;
    g_pd3dDevice->SetTransform( D3DTS_WORLD, &scal );

	//Light
	D3DMATERIAL9 mtrl;
	ZeroMemory( &mtrl, sizeof(mtrl) );
	mtrl.Diffuse.r = mtrl.Ambient.r = 1.0f;
	mtrl.Diffuse.g = mtrl.Ambient.g = 1.0f;
	mtrl.Diffuse.b = mtrl.Ambient.b = 1.0f;
	mtrl.Diffuse.a = mtrl.Ambient.a = 1.0f;
	g_pd3dDevice->SetMaterial( &mtrl );

	D3DXVECTOR3 vecDir;
	D3DLIGHT9 light;
	ZeroMemory( &light, sizeof(light) );
	light.Type = D3DLIGHT_DIRECTIONAL;

	light.Diffuse.r = 1.0f;
	light.Diffuse.g = 1.0f;
	light.Diffuse.b = 1.0f;

	light.Direction = D3DXVECTOR3(1,0,0);

	light.Range = 1000.0f;
	
	g_pd3dDevice->SetLight( 0, &light );
	g_pd3dDevice->LightEnable( 0, TRUE);
	//Sprite & Texture
	g_pd3dDevice->SetTexture(0, g_Texture);

    g_pd3dDevice->SetStreamSource( 0, g_pVB, 0, sizeof(CUSTOMVERTEX) );
	g_pd3dDevice->SetIndices(g_pIndexBuffer);
    g_pd3dDevice->SetFVF( D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1 );
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 4, 0, 2);
}

CSprite::CSprite(void)
: g_pd3dDevice(NULL)
, g_Sprite(NULL)
, g_Texture(NULL)
{
}

CSprite::~CSprite(void)
{
}

void CSprite::setDevice(LPDIRECT3DDEVICE9 devc)
{
	g_pd3dDevice = devc;
}

HRESULT CSprite::load(const char* file)
{
	D3DXCreateSprite(g_pd3dDevice, &g_Sprite);

	D3DXCreateTextureFromFile(g_pd3dDevice, file, &g_Texture);

    return S_OK;
}

void CSprite::render(int left, int top)
{
	D3DXMATRIX Matrix;
	D3DXVECTOR2 Translation(0,0);

	D3DXMatrixTransformation2D(&Matrix, NULL, NULL, NULL, NULL, 0, &Translation);

	D3DXVECTOR3 cntr( 0.0f, 0.0f, 0.0f );
	D3DXVECTOR3 pstn( left, top, 0);

	g_Sprite->Begin(0);
	g_Sprite->SetTransform(&Matrix);
	g_Sprite->Draw(g_Texture, NULL, &cntr, &pstn, 0xFFFFFFFF);
	g_Sprite->End();
}
