#include ".\game.h"

CGame::CGame(void)
: _actn(0)
{
}

CGame::~CGame(void)
{
}

bool CGame::initialize(HWND hWnd)
{
	if (!_cntr.initialize(hWnd, &_scrn) || !_scrn.initialize(hWnd, &_cntr, &_wrld) || !_wrld.initialize(&_scrn)) {
		return false;
	}
	//Load resource
	_scrn.newSprite("console.png");

	_scrn.newMesh("plane2.msh", 0);
	//Player Melee
	_scrn.newVertex("Knight_M07.png");	//BR
	_scrn.newVertex("Knight_M08.png");
	_scrn.newVertex("Knight_M06.png");	//FR
	_scrn.newVertex("Knight_M05.png");
	_scrn.newVertex("Knight_M01.png");	//FL
	_scrn.newVertex("Knight_M02.png");
	_scrn.newVertex("Knight_M04.png");	//BL
	_scrn.newVertex("Knight_M03.png");
	//Player Range
	_scrn.newVertex("Creator_M07.png");	//BR
	_scrn.newVertex("Creator_M08.png");
	_scrn.newVertex("Creator_M05.png");	//FR
	_scrn.newVertex("Creator_M06.png");
	_scrn.newVertex("Creator_M02.png");	//FL
	_scrn.newVertex("Creator_M01.png");
	_scrn.newVertex("Creator_M04.png");	//BL
	_scrn.newVertex("Creator_M03.png");
	//Monster
	_scrn.newVertex("mon1_M07.png");
	_scrn.newVertex("mon1_M08.png");
	_scrn.newVertex("mon1_M06.png");
	_scrn.newVertex("mon1_M05.png");
	_scrn.newVertex("mon1_M01.png");
	_scrn.newVertex("mon1_M02.png");
	_scrn.newVertex("mon1_M04.png");
	_scrn.newVertex("mon1_M03.png");

	_scrn.newVertex("cursor.png");	//For bug

	_wrld.newAi("ai0.ai");
	_wrld.newAi("ai1.ai");
	_wrld.newAi("ai2.ai");
	//Load Character
	CUnit* unit;

	unit = _wrld.newUnit();
	unit->load("PlyrMele");
	unit->setTeam(1);
	unit->setPosition(7.5, 7.5);
	
	unit = _wrld.newUnit();
	unit->load("PlyrRang");
	unit->setTeam(1);
	unit->setPosition(8.5, 8.5);

	unit = _wrld.newUnit();
	unit->load("MnstMele");
	unit->setTeam(2);

	unit = _wrld.newUnit();
	unit->load("MnstMele");
	unit->setTeam(2);

	unit = _wrld.newUnit();
	unit->load("MnstMele");
	unit->setTeam(2);

	unit = _wrld.newUnit();
	unit->load("MnstMele");
	unit->setTeam(2);

	//Initial unit
	_wrld.select(_wrld.unit()[0]);

	return true;
}

void CGame::update(void)
{
	//Controller
	_cntr.update();
	//Player action
	for (int i = 0; i < 256; i++) {
		if (_cntr.keyboardDown(i)) {
			_actn = i;
		}
	}
	//Quit
	if (_cntr.keyboardDown(DIK_ESCAPE)) {
		save("save.sav");
		PostQuitMessage(0);
	}
	//Select unit
	if (_cntr.keyboardDown(DIK_F1)) {
		_wrld.select(_wrld.unit()[0]);
	} else if (_cntr.keyboardDown(DIK_F2)) {
		_wrld.select(_wrld.unit()[1]);
	} else if (_cntr.keyboardDown(DIK_F3)) {
		_wrld.select(_wrld.unit()[2]);
	} else if (_cntr.keyboardDown(DIK_F4)) {
		_wrld.select(_wrld.unit()[3]);
	}
	//Left mouse click
	if (_cntr.mouseDown(0)) {
		if (_actn == 0) {
			//Unit command
			CUnit* unit = _wrld.selectedUnit();
			CUnit* trgt = _wrld.unitAt(_scrn.cursorX(), _scrn.cursorY());
			if (unit != NULL) {
				if (trgt == NULL) {
					//Move
					_wrld.ai()[unit->type()]->log(unit, UNIT_MOVE, _scrn.cursorX(), _scrn.cursorY());
					unit->setTarget(_scrn.cursorX(), _scrn.cursorY());
					unit->setAction(UNIT_MOVE);
				} else if (trgt != unit) {
					//Attack
					_wrld.ai()[unit->type()]->log(unit, UNIT_ATCK, trgt->positionX(), trgt->positionY());
					unit->setTarget(trgt);
					unit->setAction(UNIT_ATCK);
				}
			}
		} else if (_actn == DIK_S) {
			//Select
			_wrld.select(_wrld.unitAt(_scrn.cursorX(), _scrn.cursorY()));
		} else if (_actn == DIK_M && _wrld.selectedUnit() != NULL) {
			//Move
			CUnit* unit = _wrld.selectedUnit();
			_wrld.ai()[unit->type()]->log(unit, UNIT_MOVE, _scrn.cursorX(), _scrn.cursorY());
			unit->setTarget(_scrn.cursorX(), _scrn.cursorY());
			unit->setAction(UNIT_MOVE);
		} else if (_actn == DIK_A && _wrld.selectedUnit() != NULL) {
			//Attack
			CUnit* unit = _wrld.selectedUnit();
			CUnit* trgt = _wrld.unitAt(_scrn.cursorX(), _scrn.cursorY());
			if (trgt != NULL) {
				_wrld.ai()[unit->type()]->log(unit, UNIT_ATCK, trgt->positionX(), trgt->positionY());
				unit->setTarget(trgt);
				unit->setAction(UNIT_ATCK);
			}
		}
		_actn = 0;
	}
	//World
	_wrld.update();
	//Screen
	_scrn.update();
}

void CGame::save(const char* file)
{
	vector<CAi*> ai = _wrld.ai();
	for (int i = 0; i < ai.size(); i++) {
		//learn
		ai[i]->learn();
		ai[i]->save(("ai" + toString(i) + ".ai").data());
	}
}
