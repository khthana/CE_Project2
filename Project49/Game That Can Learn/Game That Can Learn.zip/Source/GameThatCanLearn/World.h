#pragma once

#ifndef PJ4D_WRLD
#define PJ4D_WRLD

class CWorld;

#include "global.h"
#include "unit.h"
#include "ai.h"
#include "screen.h"
#include <vector>
using std::vector;

class CWorld {
	vector<CUnit*> _unit;
	vector<CAi*> _ai;
	int _time;
	CUnit* _slctUnit;
	CScreen* _scrn;
public:
	CWorld();
	~CWorld();

	vector<CUnit*> unit();
	CUnit* unitAt(double x, double y);

	CUnit* newUnit();
	CAi* newAi(const char* file);
	void update(void);
	CUnit* selectedUnit(void);
	void setScreen(CScreen* scrn);
	bool initialize(CScreen* scrn);
	void select(CUnit* unit);
	void clearUnit(void);
	void clearAi(void);
	vector<CAi*> ai(void);
};

#endif
