<?php
//connect to db
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "123qwe";
$dbname = "mis";

$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
mysql_select_db($dbname);

//thai font
//$charset = "SET character_set_results=tis620"; 
$charset = "SET NAMES tis620"; 
mysql_query($charset) or die('Invalid query: ' . mysql_error());
//get from url
$result = mysql_query("select data from savedata where filename = '$id'");
while ($array = mysql_fetch_array($result)) 
	{ 
				$datadb = $array[0];
	}
 list($dat,$ttable) = explode("|",$datadb);
 $etable =str_replace(":;",":",$ttable);
  $intable = explode(":", $etable);

  $arrcell = array();
 //explode string to array 
  foreach ($intable as $value) 
	{
	list($r,$c,$da) = explode("/",$value);
    $arrcell[$r][$c] = $da;
	//echo $r;
	}
// fix bug
array_pop($arrcell);

//get data from db and send to array
$totalrow = count($arrcell);
//echo $totalrow;
$countrow = 0;
 foreach($arrcell as $row)
{
	$countrow = $countrow+1;
	//echo  $countrow;
	$countcol = 0;
	foreach($row as $thecell)
	{
		$countcol = $countcol+1;
		//echo $countcol;
		// explode thecell
		list($data,$bgcol,$colsp,$rowsp,$tcol,$tbold,$titalic) = explode(",",$thecell);
		
		//test data or sql
		list($sql,$from) = explode(" ",$data);
		if($sql == "select")
		{
			$arr = array();
			//list($command,$name) = explode("@",$data);
			//echo $command;
			$newcommand = str_replace("\\","",$data);
			$result = mysql_query($newcommand);
			//$result = mysql_query($data);
			$rowcount = mysql_num_rows($result);
			//$colname = mysql_field_name($result,0);
			$temp = $arrcell[$countrow][$countcol] ;
			list($data,$tem) = explode(",",$temp,2);
			$arrcell[$countrow][$countcol] = $name.",".$tem;
			//$arrcell[$countrow][$countcol] = $name;

			while ($array = mysql_fetch_array($result)) 
			{ 
				$test = array_push($arr,$array[0]);
				
			}
			for($i=1;$i<($totalrow-$countrow+2);$i++)//2 fix bug
			{
				$arrcell[$countrow+$i-1][$countcol] = $arr[$i-1].$arrcell[$countrow+$i-1][$countcol];
			}
		}    
	}
}
//echo  $countrow;

 //show table
 $caption = $dat;
 list($cdata,$ccol,$cbold,$citalic) = explode(",",$dat);
$font =" Angsana New";
echo "<div align='center'><font face=$font style='color:$ccol' style='font-weight:$cbold' style='font-style:$citalic'>".$cdata."</font></div>";
echo "</br>";
//echo "<caption>$cdata</caption>";

echo "<table border='1' align='center' CELLPADDING='5'>";
foreach($arrcell as $row)
{

	echo "<tr>";
	foreach($row as $thecell)
	{
		// explode thecell
		list($data,$bgcol,$colsp,$rowsp,$tcol,$tbold,$titalic) = explode(",",$thecell);
		echo "<td style='background-color:$bgcol'  colspan='$colsp' rowspan='$rowsp' align='center'>";
		echo "<font font face=$font style='color:$tcol' style='font-weight:$tbold' style='font-style:$titalic'>".$data."</font>";
		echo "</td>";
	}
	echo "</tr>";
}

echo "</table>";

        
?>





