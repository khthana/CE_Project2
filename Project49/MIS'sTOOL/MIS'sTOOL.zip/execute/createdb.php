<?php
require_once("xajax_0.2.4/xajax.inc.php");
$xajax = new xajax();
$xajax->registerFunction("myDB");
function myDB($ct)
{
	$objResponse = new xajaxResponse();
	
	$Stringtest = $ct;
	list($tablename,$num,$data) = explode(":",$Stringtest );
	$dataarr = explode(",",$data);
	$con = mysql_connect("localhost","root","123qwe");
	if (!$con)
	{
		die('Could not connect: ' . mysql_error());
	 }
	 mysql_select_db("mis", $con);
	//thai font
	$charset = "SET NAMES utf8"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());

	// Create table in database
	$sumfield = "";
	for ($i=0; $i<$num; $i++)
	{
		if ($i != $num-1)
		{
			$sumfield=$sumfield.$dataarr[$i];
			$sumfield=$sumfield.",";
		}
		else
			$sumfield=$sumfield.$dataarr[$i];
	}
	
	$sumtable = "CREATE TABLE $tablename(" .$sumfield.')';
	 if ( mysql_query($sumtable))
	{
		$objResponse->addScript("alert('create table complete !!!');");
		return $objResponse;
	}
	else
	{
	$objResponse->addScript("alert('Table already exists !!!');");
    return $objResponse;
	}
	 mysql_close($con);
	}
$xajax->processRequests();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php $xajax->printJavascript("xajax_0.2.4/"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>MIS'sTOOL</title>
<script LANGUAGE="JavaScript" TYPE="text/javascript">

function createfield()
{
	var numfield = document.getElementById("dbfield").value;
	if(numfield <= "0" || isNaN(numfield)){
		alert("Please enter positive value.")
		return;}
	var strtext = '<span class="style1">';
	for(var i=0;i<numfield;i++)
		strtext += 'Name of text field'+(i+1)+ ': <input type="text" width="50" id="field'+ i+'" align="right">  Attribute type :<input type="text" width="50" id="fieldtype'+ i+'" align="right"><br>';
	strtext += '</span>';
	var place = document.getElementById("numfield");
	place.innerHTML = strtext;
	var butt = document.getElementById('createdb');
	butt.disabled = false;
	
}
function buttfunc()
{
if(document.getElementById('dbname').value != null){
	var butt2 = document.getElementById('okbutt');
	butt2.disabled = false;}
}
function sendDB()
{
	var str5 = "";
	var ti = document.getElementById('dbname').value;
	var numfield = document.getElementById("dbfield").value;
	str5 += ti+":"+numfield+":";
	for(var j=0;j<numfield;j++)
	{
		var fi = document.getElementById('field'+j).value;
		var ft = document.getElementById('fieldtype'+j).value;
		str5 += fi+" "+ft;
		if(j != (numfield-1))
			str5 += ",";
	}
	//alert(str5);
	xajax_myDB(str5);
}
function clearInput()
{
	var dbname = document.getElementById("dbname");
	var field = document.getElementById("dbfield");
	dbname.value = "";
	field.value = "";
}


//AJAX functions
function createXMLHttpRequest()
{
    if (window.ActiveXObject) 
	{
       xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest) 
	{
       xmlHttp = new XMLHttpRequest();                
    }
}

function initVars() 
{
  inputField = document.getElementById("txtnames");            
  nameTable = document.getElementById("name_table");
  completeDiv = document.getElementById("popup");
  nameTableBody = document.getElementById("name_table_body");
}

function findNames() 
{
	initVars();
    if (inputField.value.length > 0) 
	{
      createXMLHttpRequest();            
      var url = "CompleteData.php?names=" + inputField.value;                        
      xmlHttp.open("GET", url, true);
      xmlHttp.onreadystatechange = callback;
      xmlHttp.send(null);
    } 
	else 
	{
     clearNames();
    }
}

function callback() 
{
  if (xmlHttp.readyState == 4) 
  {
    if (xmlHttp.status == 200)
		{
		  name =  document.getElementById("popup").innerHTML = xmlHttp.responseText;
		  setNames();
        }
	else if (xmlHttp.status == 204)
			{
              clearNames();
            }
  }
}
        
function setNames() 
{         
  p = name.split(",");  
  clearNames();
  var size = p.length;
  setOffsets();
  var rowj, cellj, txtNode;
  for (var i = 0; i < size; i++) 
	  {
        var nextNode =p[i] 
        rowj = document.createElement("tr");
        cellj = document.createElement("td");
                
        cellj.onmouseout = function() {this.className='mouseOver';};
        cellj.onmouseover = function() {this.className='mouseOut';};
        cellj.setAttribute("bgcolor", "#FFFAFA");
        cellj.setAttribute("border", "0");
        cellj.onclick = function() { populateName(this); } ;                             

        txtNode = document.createTextNode(nextNode);
        cellj.appendChild(txtNode);
        rowj.appendChild(cellj);
        nameTableBody.appendChild(rowj);
				
      }
}

function setOffsets() 
{
  var end = inputField.offsetWidth;
  var left = calculateOffsetLeft(inputField);
  var top = calculateOffsetTop(inputField) + inputField.offsetHeight;

  nameTable.style.border = "black 1px solid";
  nameTable.style.left = left + "px";
  nameTable.style.top = top + "px";
  nameTable.style.width = end + "px";
}
        
function calculateOffsetLeft(field) 
{
  return calculateOffset(field, "offsetLeft");
}

function calculateOffsetTop(field) 
{
  return calculateOffset(field, "offsetTop");
}

function calculateOffset(field, attr) 
{
 var offset = 0;
 while(field) {
	offset += field[attr]; 
	field = field.offsetParent;
	}
  return offset;
}

function populateName(cell) 
{
  inputField.value = cell.firstChild.nodeValue;
  clearNames();
}

function clearNames() 
{
  var ind = nameTableBody.childNodes.length;
  for (var i = ind-1;i >= 0;i--) 
	  {
        nameTableBody.removeChild(nameTableBody.childNodes[i]);
      }
        completeDiv.style.border = "none";
}

</script>

<style type="text/css">
<!--
table {margin-left: 10%:}
tr {vertical-align: top;}
td span {
 text-decoration: underline;
	cursor: pointer;
	cursor: hand;
}
img{
	cursor: hand;
}
.mouseOut {
    background: #708090;
    color: #FFFAFA;
}

    .mouseOver {
    background: #FFFAFA;
    color: #000000;
}
.style1 {color: #0099FF}
.style2 {color: #FF0000}
#Layer1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	width:397px;
	height:176px;
	z-index:1;
	left: 386px;
	top: 229px;
}
#Layer3 {
	position:absolute;
	width:219px;
	height:608px;
	z-index:2;
	left: 815px;
	top: 209px;
}
.style3 {
	color: #0000FF;
	font-weight: bold;
}
.style4 {color: #330099}
#Layer4 {
	position:absolute;
	width:420px;
	height:209px;
	z-index:3;
	left: 374px;
	top: 449px;
}
.style6 {color: #330099; font-weight: bold; }
#Layer5 {
	position:absolute;
	width:221px;
	height:160px;
	z-index:4;
	left: 801px;
	top: 826px;
}
.style7 {color: #0000FF; font-weight: bold; font-size: x-large; }
-->
</style>
<!-- TemplateBeginEditable name="head" --><!-- TemplateEndEditable -->
</head>
<body background="bodybg.gif">
<table width="100" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="images/mis_01.gif" width="505" height="134" /><img src="images/mis_02.gif" width="296" height="134" /><img src="images/mis_03.gif" width="225" height="134" /></td>
  </tr>
  <tr>
    <td><img src="images/mis_04.gif" width="506" height="61" border="0" usemap="#Map" /></td>
    <td><img src="images/mis_05.gif" width="520" height="61" border="0" usemap="#Map2" /></td>
  </tr>
</table>
<p>&nbsp;</p>

<map name="Map" id="Map"><area shape="rect" coords="28,18,119,44" href="index.html" />
<area shape="rect" coords="138,18,359,44" href="createreport.php" />
<area shape="rect" coords="375,18,541,43" href="createdb.php" />
</map>
<map name="Map2" id="Map2"><area shape="rect" coords="1,18,25,44" href="createdb.html" />
<area shape="rect" coords="42,18,195,44" href="updatedb2.php" />
<area shape="rect" coords="215,19,337,44" href="manual.html" target="_blank" />
<area shape="rect" coords="358,19,496,43" href="contact.html" />
</map>

<div id="yoursql" align="left">
 <input type="hidden" id="stringDB" name="stringDB">
  <p class="style3">Build your own DB.</p>
	<span class="style1">Create table name:</span> 
<input type="text" width="150" id="dbname" onkeypress="buttfunc()"><br>
	<span class="style1">How many fields?</span> 
<input type="text" width="50" id="dbfield"> <input type="button" value="ok" id="okbutt" onclick="createfield();"disabled><input type="button" value="Clear" onClick="clearInput()">
	<input type="button" value="Create DB" id="createdb" onClick="sendDB() ;"disabled><div id="numfield">
</div>
</body>
</html>
