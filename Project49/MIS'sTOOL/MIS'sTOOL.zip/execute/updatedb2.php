<?php
require_once("xajax_0.2.4/xajax.inc.php");
$xajax = new xajax();
$xajax->registerFunction("updatedb");
$xajax->registerFunction("todb");

function updatedb($tablename)
{
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "123qwe";
	$dbname = "mis";
	$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	mysql_select_db($dbname);
	
	//thai font
	$charset = "SET NAMES utf8"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());
	$result = mysql_query("Select * from $tablename");
	$numfield = mysql_num_fields($result);
	$strfield = "";
	$typefield = "";
	for ($i=0;$i <$numfield;$i++)
	{
		if ($i != $numfield-1)
		{
			$fieldname = mysql_field_name($result,$i);
			$strfield = $strfield.$fieldname.",";
			$fieldname2 = mysql_field_type($result,$i);
			$typefield = $typefield.$fieldname2.",";
		}
		else
		{
			$fieldname = mysql_field_name($result,$i);
			$strfield = $strfield.$fieldname;
			$fieldname = mysql_field_name($result,$i);
			$typefield = $typefield.$fieldname2;
		}
	}
   
	//$numfield;
    $objResponse = new xajaxResponse();
	$objResponse->addScript("exfunc('$strfield','$typefield');");
   // $objResponse->addScript("alert('$numfield')");
	  //$objResponse->addScript("alert('$strfield')");
    return $objResponse;
}
function todb($Stringtest)
{
	$objResponse = new xajaxResponse();
	list($tablename,$num,$fieldname,$data) = explode(":",$Stringtest );
	$fieldarr = explode(",",$fieldname);
	$dataarr = explode(",",$data);
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "123qwe";
	$dbname = "mis";
	$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	mysql_select_db($dbname);
	
	//thai font
	$charset = "SET NAMES utf8"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());
	// Create table in database
		$sumfield = "";
		for ($i=0; $i<$num; $i++)
		{
			list($sql,$from) = explode(" ",$dataarr[$i]);
				if($sql == "select")
				{
					$result = mysql_query($dataarr[$i]);
						while ($array = mysql_fetch_array($result)) 
					{ 
						$dataarr[$i] = $array[0];
					}
				}
				if ($i != $num-1)
					{
						$sumfield=$sumfield."'".$dataarr[$i]."'";
						$sumfield=$sumfield.",";
					}
				else
					$sumfield=$sumfield."'".$dataarr[$i]."'";
		}
		$fieldname ="(";
		for ($i=0; $i<$num; $i++)
		{
			if ($i != $num-1)
			{
				$fieldname=$fieldname.$fieldarr[$i];
				$fieldname=$fieldname.",";
			}
			else
			{
				$fieldname=$fieldname.$fieldarr[$i];
				$fieldname=$fieldname.")";
			}
		}
		mysql_query("INSERT INTO $tablename $fieldname VALUES ($sumfield)");
		$objResponse->addScript("alert('insert data complete !!!');");
			mysql_close($conn);
    return $objResponse;
}
$xajax->processRequests();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php $xajax->printJavascript("xajax_0.2.4/"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>MIS'sTOOL</title>
<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
var aa ="";
var numfield = 0;
function exfunc(a,b)
{
	aa=a;
	var place = document.getElementById('dbupdate3');
	var str ="";
	var strArr = a.split(",");
	var str2 ="";
	var strArr2 = b.split(",");
	numfield = strArr.length;
	for(var i=0;i<numfield;i++)
		{
			str+= "Field "+strArr[i]+"("+strArr2[i]+"):";
			str+=  ' <input type="text" width="50" id="sqlfield'+ i+'" align="right"><br>';
		}
		//str += '<input type="button" value="Update" onclick="alert(numfield)";>';
	var butt = document.getElementById('updatedb5');
	butt.disabled = false;
	place.innerHTML = str;
}
function tophp()
{
	var str2 = "";
	var ti = document.getElementById('updateDB2').value;
	str2 += ti+":"+numfield+":"+aa+":";
	for(var i=0;i<numfield;i++)
	{
		var fi = document.getElementById('sqlfield'+i).value;
		if(i != (numfield-1))
			str2 += fi+",";
		else
			str2 += fi;
	}
//	alert(str2);
	xajax_todb(str2);
}
</SCRIPT>
<style type="text/css">
<!--
.style1 {color: #0099FF}
.style2 {color: #FF0000}
#Layer1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	width:397px;
	height:176px;
	z-index:1;
	left: 386px;
	top: 229px;
}
#Layer3 {
	position:absolute;
	width:219px;
	height:608px;
	z-index:2;
	left: 815px;
	top: 209px;
}
.style3 {
	color: #0000FF;
	font-weight: bold;
}
.style4 {color: #330099}
#Layer4 {
	position:absolute;
	width:420px;
	height:209px;
	z-index:3;
	left: 374px;
	top: 449px;
}
.style6 {color: #330099; font-weight: bold; }
#Layer5 {
	position:absolute;
	width:221px;
	height:160px;
	z-index:4;
	left: 801px;
	top: 826px;
}
.style7 {color: #0000FF; font-weight: bold; font-size: x-large; }
-->
</style>
<!-- TemplateBeginEditable name="head" --><!-- TemplateEndEditable -->
</head>
<body background="bodybg.gif">
<table width="100" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="images/mis_01.gif" width="505" height="134" /><img src="images/mis_02.gif" width="296" height="134" /><img src="images/mis_03.gif" width="225" height="134" /></td>
  </tr>
  <tr>
    <td><img src="images/mis_04.gif" width="506" height="61" border="0" usemap="#Map" /></td>
    <td><img src="images/mis_05.gif" width="520" height="61" border="0" usemap="#Map2" /></td>
  </tr>
</table>
<p>&nbsp;</p>

<map name="Map" id="Map"><area shape="rect" coords="28,18,119,44" href="index.html" />
<area shape="rect" coords="138,18,359,44" href="createreport.php" />
<area shape="rect" coords="375,18,541,43" href="createdb.php" />
</map>
<map name="Map2" id="Map2"><area shape="rect" coords="1,18,25,44" href="createdb.html" />
<area shape="rect" coords="42,18,195,44" href="updatedb2.php" />
<area shape="rect" coords="215,19,337,44" href="manual.html" target="_blank" />
<area shape="rect" coords="358,19,496,43" href="contact.html" />
</map>
<div id="updateDB">
<p class="style3">Update DB.</p>
<span class="style1">Enter table name:<input type="text" id="updateDB2" style="height:20;"/><input type="button" name="Update Table" value="Update Table" onClick="xajax_updatedb(document.getElementById('updateDB2').value);"><input type="button" value="Update DB" id="updatedb5" onClick="tophp();"disabled><div id="numfield">
</div>
<table id="name_table2" bgcolor="#FFFAFA" border="0" cellspacing="0" cellpadding="0" />            
            <tbody id="name_table_body2"></tbody>
    </table>
    <div style="visibility:hidden;" id="popup2">
    </div></br>
<div id="dbupdate3">
</div>
</div>
	</span>
</body>
</html>
