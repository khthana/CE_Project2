<?php
require_once("xajax_0.2.4/xajax.inc.php");
$xajax = new xajax();
$xajax->registerFunction("myFunction");
$xajax->registerFunction("mySave");

function myFunction($a)
{
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "123qwe";
	$dbname = "mis";
	$where = $a;
	$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	mysql_select_db($dbname);
	//thai font
	$charset = "SET NAMES utf8"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());
	$result = mysql_query("Select DATA from savedata where FILENAME = '$where' ");
	$arr =array();
	while ($array = mysql_fetch_array($result)) 
			{ 
				$test = array_push($arr,$array[0]);
			}

	mysql_close($conn);
    $objResponse = new xajaxResponse();
    
	$objResponse->addAssign("savehid","value",$arr[0]);
	$objResponse->addAssign("savehid2","value",$arr[0]);
    $objResponse->addScript("loadfile();");
    return $objResponse;
}

function mySave($b,$g,$ti)
{
	$objResponse = new xajaxResponse();
	if($ti == ""){
		$objResponse->addScript("alert('Please enter save file name...');");
		return $objResponse;
		return;}
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "123qwe";
	$dbname = "mis";
	$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	mysql_select_db($dbname);
	//thai font
	$charset = "SET NAMES utf8"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());
	//$result = mysql_query("INSERT INTO savedata (FILENAME, DATA) VALUES ('$ti', '$b')");
	if ( mysql_query("INSERT INTO savedata (FILENAME, DATA,DATA2) VALUES ('$ti', '$b','$g')"))
	{
		$objResponse->addScript("alert('save complete !!!');");
		return $objResponse;
	}
	else
	{
		mysql_query("UPDATE savedata SET DATA = '$b' WHERE FILENAME = '$ti'");
		mysql_query("UPDATE savedata SET DATA2 = '$g' WHERE FILENAME = '$ti'");
		$objResponse->addScript("alert('File Overwrite !!!');");
    return $objResponse;
	}
	mysql_close($conn);
    
	//$objResponse->addScript("alert('save complete !!!');");
    return $objResponse;
}

$xajax->processRequests();
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php $xajax->printJavascript("xajax_0.2.4/"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>MIS'sTOOL</title>
<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
var theTable;

var xmlHttp;
var completeDiv;
var inputField;
var nameTable;
var nameTableBody;
var p;
var name=new String();

var FontCArray = new Array(100);
for(var a = 0;a < 100;a++)
{	
	FontCArray[a] = new Array(100);
	for(var a1=0;a1<100;a1++)
		FontCArray[a][a1] = "#000000";
}
var BgCArray = new Array(100);
for(var b = 0;b < 100;b++)
{
	BgCArray[b] = new Array(100);
	for(var b1 = 0;b1 < 100;b1++)
		BgCArray[b][b1] = "#FFFFCC";
}
var BoldArray = new Array(100);
for(var c = 0;c < 100;c++)
{
	BoldArray[c] = new Array(100);
	for(var c1 = 0;c1 < 100;c1++)
		BoldArray[c][c1] = "notbold";
}
var ItalicArray = new Array(100);
for(var d = 0;d < 100;d++)
{
	ItalicArray[d] = new Array(100);
	for(var d1 = 0;d1 < 100;d1++)
		ItalicArray[d][d1] = "notitalic";
}
var SpanColArray = new Array(100);
for(var e = 0;e < 100;e++)
{
	SpanColArray[e] = new Array(100);
	for(var e1 = 0;e1 < 100;e1++)
		SpanColArray[e][e1] = "1";
}
var SpanRowArray = new Array(100);
for(var e2 = 0;e2 < 100;e2++)
{
	SpanRowArray[e2] = new Array(100);
	for(var e3 = 0;e3 < 100;e3++)
		SpanRowArray[e2][e3] = "1";
}
var ExistArray = new Array(100);
for(var g = 0;g < 100;g++)
{
	ExistArray[g] = new Array(100);
	for(var g1 = 0;g1 < 100;g1++)
		ExistArray[g][g1] = "notexist";
}
var SendArray = new Array();
for(var h = 0;h < 100;h++)
{
	SendArray[h] = new Array(100);
	for(var h1 = 0;h1 < 100;h1++)
		SendArray[h][h1] = null;
}
var DataArray = new Array();
for(var m =0;m<100;m++)
{
	DataArray[m] = new Array(100);
	for(var p =0;p<100;p++)
		DataArray[m][p] = "";
}

var theCell = document.createElement('TD');
var temp1 = theCell.appendChild(document.createElement('SPAN'));
/*temp1.appendChild(document.createTextNode('Insert Cell'));*/
var cell_but = temp1.appendChild(document.createElement('BUTTON'));  // insert cell is a button
cell_but.appendChild(document.createTextNode('Insert Cell'));
theCell.appendChild(document.createElement('BR'));
var temp2 = theCell.appendChild(document.createElement('BUTTON'));
temp2.appendChild(document.createTextNode('Delete Row'));
theCell.style.backgroundColor = "#FFFFCC"

var titlecolour = "#000000";
var titlebold = "notbold";
var titleitalic = "notitalic";

function init()
{
	if (document.getElementById)
	{
		theTable = document.getElementsByTagName('TABLE')[2];
		var y = document.getElementsByTagName('TD');
		for (var i =0;i<y.length;i++)
		{
			 if (y[i].className == 'header')
				y[i].getElementsByTagName('SPAN')[0].onclick = function () {inserttheRow(this)}
		}
	}
	else if (document.all)
		theTable = document.all.tags('TABLE')[1];

	var ti = document.getElementById('tabletitle').insertRow(0);
	var a = ti.insertCell();
	a.style.backgroundColor = "#FFFFCC"
	var in_field = document.createElement('TEXTAREA');
	
	a.appendChild(in_field);
	a.appendChild(document.createElement('BR'));
	
	var textcolor = document.createElement('IMG');
	textcolor.setAttribute("src","images/textcolor.gif");
	a.appendChild(textcolor);
	textcolor.setAttribute("alt","Set textcolor");
	textcolor.onclick = function () {titlecol(this);};
	var bold = document.createElement('IMG');
	bold.setAttribute("src","images/bold.gif");
	a.appendChild(bold);
	bold.setAttribute("alt","Bold text");
	bold.onclick = function () {titleBold(this);};
	var italic = document.createElement('IMG');
	italic.setAttribute("src","images/italic.gif");
	a.appendChild(italic);
	italic.setAttribute("alt","Italic text");
	italic.onclick = function () {titleItalic(this);};
	a.setAttribute("align","center")
}
function delCell(obj)
{
	var row = obj.parentNode.rowIndex; //TR row index
	var cell = obj.parentNode.getElementsByTagName("TD").length-1;
	var delcell = obj.cellIndex;
	alert('theTable.rows[' + row + '].deleteCell(' + obj.cellIndex + ')');
	theTable.rows[row].deleteCell(obj.cellIndex);
	ExistArray[row][delcell] = "notexist";
	while(delcell < cell)
	{
			if(ExistArray[row][delcell+1] == "exist"){
				ExistArray[row][delcell] = ExistArray[row][delcell+1];
				++delcell;}
	}
	ExistArray[row][delcell] = "notexist";
}
function delRow(obj)
{
	obj = obj.parentNode.parentNode;
	var index = obj.rowIndex;
	var numrows = document.getElementsByTagName("TR").length-1;
	alert('theTable.deleteRow(' + index + ')');
	theTable.deleteRow(index);
	for(var i=0;i<100;i++)
		ExistArray[index][i] = "notexist";
		while(index < numrows)
		{
			for(var j=1;j<100;j++)
			ExistArray[index][j] = ExistArray[index+1][j];
			++index;
		}
		if(index == numrows){ //the last row have problem
			for(var u=0;u<100;u++)
			ExistArray[index][u] = "notexist";}
}
function inserttheCell(obj)
{
	obj = obj.parentNode;//b
	var theRow = obj.parentNode.rowIndex;
	var a = theTable.rows[theRow].insertCell(); //a is the new cell
	a.style.backgroundColor = "#FFFFCC"
	var in_field = document.createElement('TEXTAREA');
	var cellID = a.cellIndex;
	var rowID = theRow;
	ExistArray[rowID][cellID] = "exist";
	a.appendChild(in_field);
	a.appendChild(document.createElement('BR'));
	var del = document.createElement('IMG');
	del.setAttribute("src","images/delete.gif");
	del.setAttribute("alt","Delete cell");
	a.appendChild(del);
	del.onclick = function () {delCell(a);};
	var prop = document.createElement('IMG');
	prop.setAttribute("src","images/table.gif");
	a.appendChild(prop);
	prop.setAttribute("alt","Set property");
	prop.onclick = function () {showprop(this);};   //correct !!!
	var textcolor = document.createElement('IMG');
	textcolor.setAttribute("src","images/textcolor.gif");
	a.appendChild(textcolor);
	textcolor.setAttribute("alt","Set textcolor");
	textcolor.onclick = function () {textcol(this);};
	var bgcolor = document.createElement('IMG');
	bgcolor.setAttribute("src","images/bgcolor.gif");
	a.appendChild(bgcolor);
	bgcolor.setAttribute("alt","Set BGcolor");
	bgcolor.onclick = function () {bgcol(this);};  // correct !!!
	var bold = document.createElement('IMG');
	bold.setAttribute("src","images/bold.gif");
	a.appendChild(bold);
	bold.setAttribute("alt","Bold text");
	bold.onclick = function () {setBold(this);};
	var italic = document.createElement('IMG');
	italic.setAttribute("src","images/italic.gif");
	a.appendChild(italic);
	italic.setAttribute("alt","Italic text");
	italic.onclick = function () {setItalic(this);};
	a.setAttribute("align","center")
}
function showprop(cell)//this = cell
{
	var dialogArguments = new Object();
	var obj = window.showModalDialog('prop.html',self , "dialogWidth:200px; dialogHeight:180px; status:no; center:yes");
	if ("undefined" != typeof(obj))
		{
		if(obj.rowspan){Rowspan = obj.rowspan;}
		else Rowspan = 1;
		if(obj.colspan){Colspan = obj.colspan;}
		else Colspan = 1;	
	var a = cell.parentNode;  // a is the cell(father of prop)
	a.setAttribute("colSpan",Colspan); /// initialize individually
	a.setAttribute("rowSpan",Rowspan);
	var tableCell = a.cellIndex;
	var tableRow = a.parentNode.rowIndex;
	SpanColArray[tableRow][tableCell] = Colspan;
	SpanRowArray[tableRow][tableCell] = Rowspan;
	Colspan = 1;
	Rowspan = 1;
		}
}
function textcol(cell)
{
	var newcolor = window.showModalDialog('select_color.html',self , "dialogWidth:250px; dialogHeight:200px; status:no; center:yes");
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	if(newcolor == null)
		newcolor = "#000000";
	tArea.style.color = newcolor;
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	FontCArray[tableRow][tableCell] = newcolor;
	}
function titlecol(cell)
{
	var newcolor = window.showModalDialog('select_color.html',self , "dialogWidth:250px; dialogHeight:200px; status:no; center:yes");
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	if(newcolor == null)
		newcolor = "#000000";
	tArea.style.color = newcolor;
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	titlecolour = newcolor;
	}
function bgcol(cell)
{
	var newcolor = window.showModalDialog('select_color.html',"self" , "dialogWidth:250px; dialogHeight:200px; status:no; center:yes");
	var a = cell.parentNode;  // a is the cell
	if(newcolor == "")
		newcolor = "#FFFFCC";
	a.style.backgroundColor = newcolor;
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	BgCArray[tableRow][tableCell] = newcolor;
}
function setBold(cell)
{
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	if(BoldArray[tableRow][tableCell] == "notbold"){
	tArea.style.fontWeight = "bold";
	BoldArray[tableRow][tableCell] = "bold";
	}
	else if (BoldArray[tableRow][tableCell] == "bold"){
	tArea.style.fontWeight = "normal";
	BoldArray[tableRow][tableCell] = "notbold";
	}
}
function titleBold(cell)
{
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	if(titlebold == "notbold"){
	tArea.style.fontWeight = "bold";
	titlebold = "bold";
	}
	else if (titlebold == "bold"){
	tArea.style.fontWeight = "normal";
	titlebold = "notbold";
	}
}
function setItalic(cell)
{
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	if(ItalicArray[tableRow][tableCell] == "notitalic"){
	tArea.style.fontStyle = "italic";
	ItalicArray[tableRow][tableCell] = "italic";
	}
	else if (ItalicArray[tableRow][tableCell] == "italic"){
	tArea.style.fontStyle = "normal";
	ItalicArray[tableRow][tableCell] = "notitalic";
	}
}

function titleItalic(cell)
{
	var a = cell.parentNode;  // a is the cell
	var tArea = a.getElementsByTagName('TEXTAREA')[0];
	var tableCell = cell.parentNode.cellIndex;
	var tableRow = cell.parentNode.parentNode.rowIndex;
	if(titleitalic == "notitalic"){
	tArea.style.fontStyle = "italic";
	titleitalic = "italic";
	}
	else if (titleitalic == "italic"){
	tArea.style.fontStyle = "normal";
	titleitalic = "notitalic";
	}
}
function inserttheRow(obj)
{
	obj = obj.parentNode;
	appendObject = obj.parentNode.parentNode;
	var a = appendObject.insertRow();
	var b = a.appendChild(theCell.cloneNode(true));
	b.firstChild.onclick = function () {inserttheCell(this)}
	b.lastChild.onclick = function() {delRow(this)}
}
function insertCell(index,arr)
{
	var a = theTable.rows[index].insertCell();
	var in_field = document.createElement('TEXTAREA');
	in_field.value = arr[0];
	var cellID = a.cellIndex; // chk index again
	var rowID = index;
	ExistArray[rowID][cellID] = "exist";
	a.appendChild(in_field);
	a.appendChild(document.createElement('BR'));
	var del = document.createElement('IMG');
	del.setAttribute("src","images/delete.gif");
	del.setAttribute("alt","Delete cell");
	a.appendChild(del);
	del.onclick = function () {delCell(a);};
	var prop = document.createElement('IMG');
	prop.setAttribute("src","images/table.gif");
	a.appendChild(prop);
	prop.setAttribute("alt","Set property");
	a.setAttribute("colSpan",arr[2]); /// new
	a.setAttribute("rowSpan",arr[3]);
	prop.onclick = function () {showprop(this);};
	SpanColArray[index][cellID] = arr[2];
	SpanRowArray[index][cellID] = arr[3];
	var textcolor = document.createElement('IMG');
	textcolor.setAttribute("src","images/textcolor.gif");
	a.appendChild(textcolor);
	in_field.style.color = arr[4];/// new
	FontCArray[index][cellID] = arr[4];
	textcolor.setAttribute("alt","Set textcolor");
	textcolor.onclick = function () {textcol(this);};
	var bgcolor = document.createElement('IMG');
	bgcolor.setAttribute("src","images/bgcolor.gif");
	a.appendChild(bgcolor);
	bgcolor.setAttribute("alt","Set BGcolor");
	a.style.backgroundColor = arr[1];/// new
	BgCArray[index][cellID] = arr[1];
	bgcolor.onclick = function () {bgcol(this);};
	var bold = document.createElement('IMG');
	bold.setAttribute("src","images/bold.gif");
	a.appendChild(bold);
	bold.setAttribute("alt","Bold text");
	if(arr[6] == "bold")
		in_field.style.fontWeight = arr[5];/// new
	else in_field.style.fontWeight = "normal";
	BoldArray[index][cellID] = arr[5];
	bold.onclick = function () {setBold(this);};
	var italic = document.createElement('IMG');
	italic.setAttribute("src","images/italic.gif");
	a.appendChild(italic);
	italic.setAttribute("alt","Italic text");
	if(arr[6] == "italic")
		in_field.style.fontStyle = arr[6];
	else in_field.style.fontStyle = "normal";
	ItalicArray[index][cellID] = arr[6];
	italic.onclick = function () {setItalic(this);};
	a.setAttribute("align","center")
}
function prove()
{
	var savename = prompt("Please enter your save form name","");
	if(savename == null && savename == ""){
		alert("!!! Please enter a save name !!!");
		return ;}
	var freddy = document.getElementById('hidtitle');
	freddy.value = savename;
	var SendText = "";
	var ROW = document.getElementById('data').getElementsByTagName("TR");
	var realrow = ROW.length-1;
	for(var y =1;y<ROW.length;y++)
	{
		var CELL = ROW[y].getElementsByTagName("TD");
		if(CELL.length == "1")
			continue;
		var realcell = CELL.length-1;
		for(var t =1;t<CELL.length;t++)
		{		
				if(ExistArray[y][t] == "exist")
				{
					var inner = CELL[t].getElementsByTagName("TEXTAREA")[0];
					DataArray[y][t] = inner.innerHTML;
				}
		}	
	}
	var title = document.getElementById("tabletitle");
	var innertitle = title.getElementsByTagName("TEXTAREA")[0];
	SendText += innertitle.value+","+titlecolour+","+titlebold+","+titleitalic+"|";
	for(var i=1;i<100;i++)
	{
		for(var j=1;j<100;j++)
		{
			if(ExistArray[i][j] == "exist")
				{
						var str = "";
						str += i+"/"+j+"/"+DataArray[i][j]+","+BgCArray[i][j]+",";
						str += SpanColArray[i][j]+","+SpanRowArray[i][j]+","+FontCArray[i][j]+","+BoldArray[i][j]+","+ItalicArray[i][j]+":";
						SendText += str;	
				}
		}
		SendText += ";";
	}
	var TextIndex = SendText.indexOf(";;");
	SendText = SendText.substring(0,TextIndex);
	var sendvar = document.getElementById("hid");
	sendvar.value = SendText;
}
function prove2()
{
	var SendText = "";
	var ROW = document.getElementById('data').getElementsByTagName("TR");
	var realrow = ROW.length-1; // all row including row of years 2545,46,47
	var graphrow = realrow-1;
	for(var y =1;y<ROW.length;y++)
	{
		var CELL = ROW[y].getElementsByTagName("TD");
		if(CELL.length == "1")
			continue;
		var realcell = CELL.length-1;
		for(var t =1;t<CELL.length;t++)
		{		
				if(ExistArray[y][t] == "exist")
				{
					var inner = CELL[t].getElementsByTagName("TEXTAREA")[0];
					DataArray[y][t] = inner.innerHTML;
				}
		}	
	}
	var title = document.getElementById("tabletitle");
	var innertitle = title.getElementsByTagName("TEXTAREA")[0];
	SendText += innertitle.value+","+titlecolour+","+titlebold+","+titleitalic+"|";
	
	var juncell = ROW[1].getElementsByTagName("TD");
	var numjuncell = juncell.length;
	if(ExistArray[1][1] != "exist")
	{
		alert("Please fill in the form.");
		return false;
	}
	SendText += DataArray[1][1] +"@";
	for(var i = 2;i < numjuncell;++i)
	{
		SendText += DataArray[1][i];
		if(ExistArray[1][i+1] == "exist")
			SendText += ",";
	}
	SendText += "@" + graphrow + "@";
	for(var i = 2;i<100;i++) //starts from widwa/color which is row 2
	{
		for(var j=1;j<100;j++) //starts from widwa/color which is col 1
		{
			if(ExistArray[i][j] == "exist")
				{
						var str = "";
						if(j == "1")
							str += DataArray[i][j]+","+BgCArray[i][j]+",";
						else
						{
							str += DataArray[i][j];
							if(ExistArray[i][j+1] == "exist")
								str += ",";
						}
						SendText += str;	
				}
		}
		SendText += ":";
	}
	var TextIndex = SendText.indexOf("::");
	SendText = SendText.substring(0,TextIndex);
	var sendvar = document.getElementById("hidgraph");
	sendvar.value = SendText;
}

//for gen table with prove
function prove3()
{
	/*var savename = prompt("Please enter your save form name","");
	if(savename == null && savename == ""){
		alert("!!! Please enter a save name !!!");
		return ;}
	var freddy = document.getElementById('hidtitle');
	freddy.value = savename;*/
	var SendText = "";
	var ROW = document.getElementById('data').getElementsByTagName("TR");
	var realrow = ROW.length-1;
	for(var y =1;y<ROW.length;y++)
	{
		var CELL = ROW[y].getElementsByTagName("TD");
		if(CELL.length == "1")
			continue;
		var realcell = CELL.length-1;
		for(var t =1;t<CELL.length;t++)
		{		
				if(ExistArray[y][t] == "exist")
				{
					var inner = CELL[t].getElementsByTagName("TEXTAREA")[0];
					DataArray[y][t] = inner.innerHTML;
				}
		}	
	}
	var title = document.getElementById("tabletitle");
	var innertitle = title.getElementsByTagName("TEXTAREA")[0];
	SendText += innertitle.value+","+titlecolour+","+titlebold+","+titleitalic+"|";
	for(var i=1;i<100;i++)
	{
		for(var j=1;j<100;j++)
		{
			if(ExistArray[i][j] == "exist")
				{
						var str = "";
						str += i+"/"+j+"/"+DataArray[i][j]+","+BgCArray[i][j]+",";
						str += SpanColArray[i][j]+","+SpanRowArray[i][j]+","+FontCArray[i][j]+","+BoldArray[i][j]+","+ItalicArray[i][j]+":";
						SendText += str;	
				}
		}
		SendText += ";";
	}
	var TextIndex = SendText.indexOf(";;");
	SendText = SendText.substring(0,TextIndex);
	var sendvar = document.getElementById("hid");
	sendvar.value = SendText;
}
function prove4()
{
	var SendText = "";
	var list = document.getElementsByTagName("select")[0];
	SendText+=list.value+"%";
	var ROW = document.getElementById('data').getElementsByTagName("TR");
	var realrow = ROW.length-1; // all row including row of years 2545,46,47
	var graphrow = realrow-1;
	for(var y =1;y<ROW.length;y++)
	{
		var CELL = ROW[y].getElementsByTagName("TD");
		if(CELL.length == "1")
			continue;
		var realcell = CELL.length-1;
		for(var t =1;t<CELL.length;t++)
		{		
				if(ExistArray[y][t] == "exist")
				{
					var inner = CELL[t].getElementsByTagName("TEXTAREA")[0];
					DataArray[y][t] = inner.innerHTML;
				}
		}	
	}
	var title = document.getElementById("tabletitle");
	var innertitle = title.getElementsByTagName("TEXTAREA")[0];
	SendText += innertitle.value+","+titlecolour+","+titlebold+","+titleitalic+"|";
	
	var juncell = ROW[1].getElementsByTagName("TD");
	var numjuncell = juncell.length;
	if(ExistArray[1][1] != "exist")
	{
		alert("Please fill in the form.");
		return false;
	}
	SendText += DataArray[1][1] +"@";
	for(var i = 2;i < numjuncell;++i)
	{
		SendText += DataArray[1][i];
		if(ExistArray[1][i+1] == "exist")
			SendText += ",";
	}
	SendText += "@" + graphrow + "@";
	for(var i = 2;i<100;i++) //starts from widwa/color which is row 2
	{
		for(var j=1;j<100;j++) //starts from widwa/color which is col 1
		{
			if(ExistArray[i][j] == "exist")
				{
						var str = "";
						if(j == "1")
							str += DataArray[i][j]+","+BgCArray[i][j]+",";
						else
						{
							str += DataArray[i][j];
							if(ExistArray[i][j+1] == "exist")
								str += ",";
						}
						SendText += str;	
				}
		}
		SendText += ":";
	}
	var TextIndex = SendText.indexOf("::");
	SendText = SendText.substring(0,TextIndex);
	var sendvar = document.getElementById("hidgraphs");
	sendvar.value = SendText;

}

function loadfile()
{
	//*********************************    load function ********** NEW ******************************
	var tttt = document.getElementById("txtnames").value;
	if(tttt == "")
	{
		alert("Please specify filename to load");
		return false;
	}
	clearolddata();
	var thistable = document.getElementsByTagName('TABLE')[2];
	var y = thistable.getElementsByTagName('TD');
	var loaddata =  document.getElementById('savehid2').value;
	var titleindex = loaddata.indexOf("|");
	var name = loaddata.substring(0,titleindex);    // the title
	loaddata =  loaddata.substr(titleindex);    // the data of cells

	var arrRow = loaddata.split(";"); // arrRow is all the row in the doc
	var numrow = arrRow.length; //must inserttheRow equal this total
	var newrow = y[0].getElementsByTagName('SPAN')[0]; //place to insert the row
	var theTitle = document.getElementById("tabletitle");
	var innertitle = theTitle.getElementsByTagName('TEXTAREA')[0];
	var arrname = name.split(",");
	innertitle.value = arrname[0];
	innertitle.style.color = arrname[1];
	titlecolour = arrname[1];
	if(arrname[2] == "bold"){
		innertitle.style.fontWeight = arrname[2];
		titlebold = arrname[2];}
	else innertitle.style.fontWeight = "normal";
	if(arrname[3] == "italic"){
		innertitle.style.fontStyle = arrname[3];
	titleitalic = arrname[3];}
	else innertitle.style.fontStyle = "normal";
	for(var i=0;i<numrow;i++)
	{
		inserttheRow(newrow);
		var arrCell = arrRow[i].split(":"); //arrCell is all the cell in one row 
		var numcell = arrCell.length-1;	// must create this number of cell
			for(var j=0;j<numcell;j++)
			{
				if(i == 0 && j ==0)
				{
					var xxx = arrCell[j].indexOf("/");
					arrCell[j] = arrCell[j].substr(xxx+1);
					var yyy = arrCell[j].indexOf("/");
					arrCell[j] = arrCell[j].substr(yyy+1)
					var eachdata = arrCell[j].split(",");
					insertCell(i+1,eachdata);
				}
				else
				{
					var noslash = arrCell[j].lastIndexOf("/");
					arrCell[j] = arrCell[j].substr(noslash+1);
					var eachdata = arrCell[j].split(","); // eachdata will have members of attribute for one cell [[[[    it will be 8 element in one cell    ]]]]
						insertCell(i+1,eachdata);
				}
			}
		}
}
function clearolddata()
{
	var thetable1 = document.getElementsByTagName('TABLE')[2];
	var rowjun = thetable1.rows;
	var allrow = (rowjun.length)-1;
	for(var i = allrow;i  != 0;i--)
	{
		thetable1.deleteRow(i);
	}
	for(var i=1;i<100;i++)
	{
		for(var j=1;j<100;j++)
			ExistArray[i][j] = "notexist";
	}
}
//AJAX functions
function createXMLHttpRequest()
{
    if (window.ActiveXObject) 
	{
       xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest) 
	{
       xmlHttp = new XMLHttpRequest();                
    }
}

function initVars() 
{
  inputField = document.getElementById("txtnames");            
  nameTable = document.getElementById("name_table");
  completeDiv = document.getElementById("popup");
  nameTableBody = document.getElementById("name_table_body");
}

function findNames() 
{
	initVars();
    if (inputField.value.length > 0) 
	{
      createXMLHttpRequest();            
      var url = "CompleteData.php?names=" + inputField.value;                        
      xmlHttp.open("GET", url, true);
      xmlHttp.onreadystatechange = callback;
      xmlHttp.send(null);
    } 
	else 
	{
     clearNames();
    }
}

function callback() 
{
  if (xmlHttp.readyState == 4) 
  {
    if (xmlHttp.status == 200)
		{
		  name =  document.getElementById("popup").innerHTML = xmlHttp.responseText;
		  setNames();
        }
	else if (xmlHttp.status == 204)
			{
              clearNames();
            }
  }
}
        
function setNames() 
{         
  p = name.split(",");  
  clearNames();
  var size = p.length;
  setOffsets();
  var rowj, cellj, txtNode;
  for (var i = 0; i < size; i++) 
	  {
        var nextNode =p[i] 
        rowj = document.createElement("tr");
        cellj = document.createElement("td");
                
        cellj.onmouseout = function() {this.className='mouseOver';};
        cellj.onmouseover = function() {this.className='mouseOut';};
        cellj.setAttribute("bgcolor", "#FFFAFA");
        cellj.setAttribute("border", "0");
        cellj.onclick = function() { populateName(this); } ;                             

        txtNode = document.createTextNode(nextNode);
        cellj.appendChild(txtNode);
        rowj.appendChild(cellj);
        nameTableBody.appendChild(rowj);
				
      }
}

function setOffsets() 
{
  var end = inputField.offsetWidth;
  var left = calculateOffsetLeft(inputField);
  var top = calculateOffsetTop(inputField) + inputField.offsetHeight;

  nameTable.style.border = "black 1px solid";
  nameTable.style.left = left + "px";
  nameTable.style.top = top + "px";
  nameTable.style.width = end + "px";
}
        
function calculateOffsetLeft(field) 
{
  return calculateOffset(field, "offsetLeft");
}

function calculateOffsetTop(field) 
{
  return calculateOffset(field, "offsetTop");
}

function calculateOffset(field, attr) 
{
 var offset = 0;
 while(field) {
	offset += field[attr]; 
	field = field.offsetParent;
	}
  return offset;
}

function populateName(cell) 
{
  inputField.value = cell.firstChild.nodeValue;
  clearNames();
}

function clearNames() 
{
  var ind = nameTableBody.childNodes.length;
  for (var i = ind-1;i >= 0;i--) 
	  {
        nameTableBody.removeChild(nameTableBody.childNodes[i]);
      }
        completeDiv.style.border = "none";
}

</SCRIPT>
<style type="text/css">
<!--
table {margin-left: 10%:}
tr {vertical-align: top;}
td span {
	cursor: pointer;
	cursor: hand;
}
img{
	cursor: hand;
}
.mouseOut {
    background: #708090;
    color: #FFFAFA;
}

    .mouseOver {
    background: #FFFAFA;
    color: #000000;
}
.style1 {color: #0099FF}
.style2 {color: #FF0000}
#Layer1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
}
#Layer2 {
	position:absolute;
	width:397px;
	height:176px;
	z-index:1;
	left: 386px;
	top: 229px;
}
#Layer3 {
	position:absolute;
	width:219px;
	height:608px;
	z-index:2;
	left: 815px;
	top: 209px;
}
.style3 {
	color: #0000FF;
	font-weight: bold;
}
.style4 {color: #330099}
#Layer4 {
	position:absolute;
	width:420px;
	height:209px;
	z-index:3;
	left: 374px;
	top: 449px;
}
.style6 {color: #330099; font-weight: bold; }
#Layer5 {
	position:absolute;
	width:221px;
	height:160px;
	z-index:4;
	left: 801px;
	top: 826px;
}
.style7 {color: #0000FF; font-weight: bold; font-size: x-large; }
-->
</style>
<!-- TemplateBeginEditable name="head" --><!-- TemplateEndEditable -->
</head>
<body background="bodybg.gif" onLoad="init()">
<table width="100" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="images/mis_01.gif" width="505" height="134" /><img src="images/mis_02.gif" width="296" height="134" /><img src="images/mis_03.gif" width="225" height="134" /></td>
  </tr>
  <tr>
    <td><img src="images/mis_04.gif" width="506" height="61" border="0" usemap="#Map" /></td>
    <td><img src="images/mis_05.gif" width="520" height="61" border="0" usemap="#Map2" /></td>
  </tr>
</table>


<map name="Map" id="Map"><area shape="rect" coords="28,18,119,44" href="index.html" />
<area shape="rect" coords="138,18,359,44" href="createreport.php" />
<area shape="rect" coords="375,18,541,43" href="createdb.php" />
</map>
<map name="Map2" id="Map2"><area shape="rect" coords="1,18,25,44" href="createdb.php" />
<area shape="rect" coords="42,18,195,44" href="updatedb2.php" />
<area shape="rect" coords="215,19,337,44" href="manual.html" target="_blank" />
<area shape="rect" coords="358,19,496,43" href="contact.html" />
</map>

<form method="post" onSubmit="prove3()" action="newgen.php" target="_blank">
<div align="center">
<span class="style3">Title:
<TABLE BORDER=1 id="tabletitle" bordercolor="#ffcc33">
</table>
<TABLE BORDER=1 id="data" bordercolor="#ffcc33">
		<TR>
			<TD CLASS="header" COLSPAN=10 bgcolor = "#FFFFCC" align="center" ><span class="style1">Table Form<BR />
			<SPAN ><input type="button" value="Insert Row"></SPAN></TD>
			<SPAN id="firstrow">
		</TR>
</TABLE>
<br/>
<div id="content">
<input type="submit" value="Generate table">
<input type="hidden" name="hid" id="hid">
<input type="hidden" name="hidtitle" id="hidtitle">
 </form>
 <form  method="post" name="formgraph" onSubmit="prove2()" action="newgraph.php" target="_blank">
Graph type :
<select name="selectgraph">
              <option value="line">line</option>
              <option value="pie">pie</option>
              <option value="bar">bar chart</option>
          </select>
<input type="submit" value="Generate Graph">
<input type="hidden" name="hidgraphs" id="hidgraphs">
<input type="hidden" name="hidgraph" id="hidgraph"><br><br>
</form>
<form method="post" name="saveform">
 <input type="button" value="Save form" onClick="prove();prove4();xajax_mySave(document.getElementById('hid').value,document.getElementById('hidgraphs').value,document.getElementById('hidtitle').value)";><input type="hidden" name="savehid" id="savehid">
 </form>
 <form name="form1">
Form Name:<input type="text" id="txtnames" onkeyup="findNames();" style="height:20;"/><input type="button" name="loadform" value="loadform" onClick="xajax_myFunction(document.getElementById('txtnames').value);">
<input type="hidden" name="savehid2" id="savehid2">
<table id="name_table" bgcolor="#FFFAFA" border="0" cellspacing="0" cellpadding="0" />            
            <tbody id="name_table_body"></tbody>
    </table>
    <div style="visibility:hidden;" id="popup">
    </div>
</form>
</body>
</html>
