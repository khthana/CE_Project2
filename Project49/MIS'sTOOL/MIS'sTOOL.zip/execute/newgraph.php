<?php
include ("C:\AppServ\www\mis_dewya\jpgraph-2.1.4\src\jpgraph.php");
include ("C:\AppServ\www\mis_dewya\jpgraph-2.1.4\src\jpgraph_line.php");
include ("C:\AppServ\www\mis_dewya\jpgraph-2.1.4\src\jpgraph_bar.php");
include ("C:\AppServ\www\mis_dewya\jpgraph-2.1.4\src\jpgraph_pie.php");
include ("C:\AppServ\www\mis_dewya\jpgraph-2.1.4\src\jpgraph_pie3d.php");

//connect to db
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "123qwe";
$dbname = "mis";

$conn = mysql_pconnect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
mysql_select_db($dbname);

//thai font
//$charset = "SET character_set_results=tis620"; 
$charset = "SET NAMES tis620"; 
mysql_query($charset) or die('Invalid query: ' . mysql_error());


switch ($selectgraph)
{
case "line":
	  //get title and graph from user
	 $ugraph = $_POST['hidgraph'];
	 list($dat,$graph) = explode("|",$ugraph);
	 //title
	 list($gtitle,$ccol,$cbold,$citalic) = explode(",",$dat);
	 //
	 list($xy,$xname,$graphrow,$ingraph) = explode("@",$graph);
	 list($x,$y) = explode("/",$xy);
	 $xdata = explode(",",$xname);
	 
	$datarow = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($datarow[$i],$dib)= explode(":",$ingraph,2);
		$ingraph = $dib;
	}
	//print_r($datarow);

	$data = array();
	$datacell = array();
	$plotname = array();
	$linecol = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($plotname[$i],$linecol[$i],$data[$i])= explode(",",$datarow[$i],3);
	}

	for ($i=0; $i<$graphrow; $i++)
	{
		$datacell[$i] = explode(",",$data[$i]);
	}
	
	$r = 0;
	foreach($datacell as $row)
	{
		$c = 0;
		foreach($row as $thecell)
		{
			list($sql,$from) = explode(" ",$thecell);
			if($sql == "select")
			{
				$newcommand = str_replace("\\","",$thecell);
				//echo $newcommand;
				$result = mysql_query($newcommand);
				while ($array = mysql_fetch_array($result)) 
				{ 
					$datacell[$r][$c] = $array[0];
				}
			}
		$c = $c+1;
		}
	$r = $r+1;
	}
	//$ydata = array(11,3,8,12,5,1,9,13,5,7);
	//print_r($datacell);
	// Create the graph. These two calls are always required
	$graph = new Graph(600,400,"auto");    
	$graph->SetScale("textlin");

	// Create the linear plot
	//$lineplot=new LinePlot($ydata);
	$lineplot = array();
	for ($i=0; $i<=$graphrow-1; $i++)
	{
	$lineplot[$i]=new LinePlot($datacell[$i]);
	$lineplot[$i]->SetColor($linecol[$i]);
	$lineplot[$i]->SetWeight(2);
	$graph->Add($lineplot[$i]);
	//$lineplot[$i]->mark->SetType(MARK_UTRIANGLE);
	// Set the legends for the plots
	$lineplot[$i]->SetLegend($plotname[$i]);

	}

	// Setup X-scale
	$graph->xaxis->SetTickLabels($xdata);
	//$graph->xaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
	//$graph->xaxis->SetLabelAngle(45);

	// Add the plot to the graph


	$graph->img->SetMargin(40,140,20,40);
	$graph->title->Set($gtitle);
	$graph->title->SetColor($ccol);
	$graph->xaxis->title->Set($x);
	$graph->yaxis->title->Set($y);
//font
	$graph->title->SetFont(FF_CORDIA,FS_BOLD,20);
	$graph->yaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->xaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->legend->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->xaxis->SetFont(FF_CORDIA,FS_BOLD,16);

	$graph->SetShadow();


	// Adjust the legend position
	$graph->legend->Pos(0.05,0.5,"right","center");



	// Display the graph
	$graph->Stroke();
  break;
case "bar":
	  //get title and graph from user
	 $ugraph = $_POST['hidgraph'];
	 
	 list($dat,$graph) = explode("|",$ugraph);
	  //title
	 list($gtitle,$ccol,$cbold,$citalic) = explode(",",$dat);
	 //
	 list($xy,$xname,$graphrow,$ingraph) = explode("@",$graph);
	 list($x,$y) = explode("/",$xy);
	 $xdata = explode(",",$xname);
	 
	$datarow = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($datarow[$i],$dib)= explode(":",$ingraph,2);
		$ingraph = $dib;
	}
	//print_r($datarow);

	$data = array();
	$datacell = array();
	$plotname = array();
	$linecol = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($plotname[$i],$linecol[$i],$data[$i])= explode(",",$datarow[$i],3);
	}

	for ($i=0; $i<$graphrow; $i++)
	{
		$datacell[$i] = explode(",",$data[$i]);
	}
	
	$r = 0;
	foreach($datacell as $row)
	{
		$c = 0;
		foreach($row as $thecell)
		{
			list($sql,$from) = explode(" ",$thecell);
			if($sql == "select")
			{
				$newcommand = str_replace("\\","",$thecell);
				//echo $newcommand;
				$result = mysql_query($newcommand);
				while ($array = mysql_fetch_array($result)) 
				{ 
					$datacell[$r][$c] = $array[0];
				}
			}
		$c = $c+1;
		}
	$r = $r+1;
	}


	//$ydata = array(11,3,8,12,5,1,9,13,5,7);
	//print_r($ydata);
	// Create the graph. These two calls are always required
	$graph = new Graph(600,300,"auto");    
	$graph->SetScale("textlin");

	// Create the linear plot
	//$lineplot=new LinePlot($ydata);
	$bplot = array();
	$bg = array();
	for ($i=0; $i<=$graphrow-1; $i++)
	{
	// Create the bar plots
	$bplot[$i] = new BarPlot($datacell[$i]);
	$bplot[$i]->SetFillColor($linecol[$i]);

	$bplot[$i]->SetLegend($xdata[$i]);
	$test = array_push($bg,$bplot[$i]);
	$bplot[$i]->SetLegend($plotname[$i]);
	}

	// Create the grouped bar plot
	$gbplot = new GroupBarPlot($bg);

	// ...and add it to the graPH
	$graph->Add($gbplot);

	// Setup X-scale
	$graph->xaxis->SetTickLabels($xdata);
	$graph->xaxis->SetFont(FF_CORDIA,FS_BOLD,16);
	//$graph->xaxis->SetLabelAngle(45);

	// Add the plot to the graph


	$graph->img->SetMargin(40,140,20,40);
	$graph->title->Set($gtitle);
	$graph->title->SetColor($ccol);
	$graph->xaxis->title->Set($x);
	$graph->yaxis->title->Set($y);

	//font
	$graph->title->SetFont(FF_CORDIA,FS_BOLD,20);
	$graph->yaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->xaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->legend->SetFont(FF_CORDIA,FS_BOLD,16);


	$graph->SetShadow();


	// Adjust the legend position
	$graph->legend->Pos(0.05,0.5,"right","center");



	// Display the graph
	$graph->Stroke();

case "pie":
	  //get title and graph from user
	 $ugraph = $_POST['hidgraph'];
	 
	 list($dat,$graph) = explode("|",$ugraph);
	  //title
	 list($gtitle,$ccol,$cbold,$citalic) = explode(",",$dat);
	 //
	 list($xy,$xname,$graphrow,$ingraph) = explode("@",$graph);
	 list($x,$y) = explode("/",$xy);
	 $xdata = explode(",",$xname);
	 
	$datarow = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($datarow[$i],$dib)= explode(":",$ingraph,2);
		$ingraph = $dib;
	}
	//print_r($datarow);

	$data = array();
	$datacell = array();
	$plotname = array();
	$linecol = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		list($plotname[$i],$linecol[$i],$data[$i])= explode(",",$datarow[$i],3);
	}

	$piedata = array();
	for ($i=0; $i<$graphrow; $i++)
	{
		$datacell[$i] = explode(",",$data[$i]);
		//$test = array_push($piedata,$datacell[$i][0]);
	}
	
	$r = 0;
	foreach($datacell as $row)
	{
		$c = 0;
		foreach($row as $thecell)
		{
			list($sql,$from) = explode(" ",$thecell);
			if($sql == "select")
			{
				$newcommand = str_replace("\\","",$thecell);
				//echo $newcommand;
				$result = mysql_query($newcommand);
				while ($array = mysql_fetch_array($result)) 
				{ 
					$datacell[$r][$c] = $array[0];
				}
			}
		$c = $c+1;
		$test = array_push($piedata,$datacell[$r][0]);
		}
	$r = $r+1;
	}
	//print_r($piedata);
	//$data = array(40,60,21,33);

	$graph = new PieGraph(600,400,"auto");
	$graph->SetShadow();

	$graph->title->Set($gtitle);
	//font
	$graph->title->SetFont(FF_CORDIA,FS_BOLD,20);
	$graph->title->SetColor($ccol);
	//$graph->yaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	//$graph->xaxis->title->SetFont(FF_CORDIA,FS_BOLD,16);
	$graph->legend->SetFont(FF_CORDIA,FS_BOLD,16);


	$p1 = new PiePlot3D($piedata);
	//$p1->SetAngle(20);
	$p1->SetSize(0.5);
	$p1->SetCenter(0.45);
	$p1->SetLegends($plotname);

	$graph->Add($p1);
	$graph->Stroke();
  break;
default:
  echo "No graph for you";
}




        
?>





