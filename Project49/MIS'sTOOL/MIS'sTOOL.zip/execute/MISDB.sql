-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 13 มี.ค. 2007  น.
-- รุ่นของเซิร์ฟเวอร์: 5.0.22
-- รุ่นของ PHP: 5.1.4
-- 
-- ฐานข้อมูล: `mis`
-- 
CREATE DATABASE `mis` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `mis`;

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `computer`
-- 

CREATE TABLE `computer` (
  `id` int(11) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `name` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `surname` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `computer`
-- 

INSERT INTO `computer` VALUES (1, 'Mr', 'aaa', 'ขขข');
INSERT INTO `computer` VALUES (2, 'Mr', 'aaa', 'งงง');
INSERT INTO `computer` VALUES (3, 'Miss', 'aaa', 'งงง');
INSERT INTO `computer` VALUES (4, 'Mr', 'ททท', 'มมม');
INSERT INTO `computer` VALUES (5, 'Mr', 'ลลล', 'สสส');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `it`
-- 

CREATE TABLE `it` (
  `id` int(11) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `it`
-- 

INSERT INTO `it` VALUES (1, 'Mr', 'กกก', 'ขขข');
INSERT INTO `it` VALUES (2, 'Mr', 'คคค', 'งงง');
INSERT INTO `it` VALUES (3, 'Miss', 'ววว', 'งงง');
INSERT INTO `it` VALUES (4, 'Miss', 'ททท', 'มมม');
INSERT INTO `it` VALUES (5, 'Miss', 'ลลล', 'สสส');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `monthlystu`
-- 

CREATE TABLE `monthlystu` (
  `month` varchar(20) collate utf8_bin default NULL,
  `computer` int(11) default NULL,
  `it` int(11) default NULL,
  `power` int(11) default NULL,
  `telecom` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 
-- dump ตาราง `monthlystu`
-- 

INSERT INTO `monthlystu` VALUES (0xe0b881e0b8b8e0b8a1e0b8a0e0b8b2e0b89ee0b8b1e0b899e0b898e0b98c, 3, 2, 7, 5);
INSERT INTO `monthlystu` VALUES (0xe0b8a1e0b881e0b8a3e0b8b2e0b884e0b8a1, 4, 5, 6, 4);
INSERT INTO `monthlystu` VALUES (0xe0b8a1e0b8b5e0b899e0b8b2e0b884e0b8a1, 5, 5, 5, 5);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `power`
-- 

CREATE TABLE `power` (
  `id` int(11) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `power`
-- 

INSERT INTO `power` VALUES (1, 'Miss', 'aaa', 'ขขข');
INSERT INTO `power` VALUES (2, 'Miss', 'aaa', 'งงง');
INSERT INTO `power` VALUES (3, 'Miss', 'aaa', 'งงง');
INSERT INTO `power` VALUES (4, 'Mr', 'ททท', 'มมม');
INSERT INTO `power` VALUES (5, 'Mr', 'ลลล', 'สสส');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `savedata`
-- 

CREATE TABLE `savedata` (
  `FILENAME` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DATA` varchar(5000) character set utf8 collate utf8_unicode_ci NOT NULL,
  `DATA2` varchar(5000) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`FILENAME`)
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `savedata`
-- 

INSERT INTO `savedata` VALUES ('table1', 'ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายปี45-47,#FF6600,bold,notitalic|1/1/ภาควิชา,#66CCFF,1,1,#FFFFFF,notbold,notitalic:1/2/ปี 2545,#00FFFF,1,1,#000000,notbold,italic:1/3/ปี 2546,#00FFFF,1,1,#000000,notbold,italic:1/4/ปี 2547,#00FFFF,1,1,#000000,notbold,italic:;2/1/select fac from y2545,#66FFCC,1,1,#000000,notbold,notitalic:2/2/select m from y2545,#99FF00,1,1,#000000,notbold,notitalic:2/3/select m from y2546,#66FFCC,1,1,#000000,notbold,notitalic:2/4/select m from y2547,#99FF00,1,1,#000000,notbold,notitalic:;3/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:3/2/,#33FFCC,1,1,#000000,notbold,notitalic:3/3/,#99FF00,1,1,#000000,notbold,notitalic:3/4/,#33FFCC,1,1,#000000,notbold,notitalic:;4/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:4/2/,#33FFCC,1,1,#000000,notbold,notitalic:4/3/,#99FF00,1,1,#000000,notbold,notitalic:4/4/,#33FFCC,1,1,#000000,notbold,notitalic:;5/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:5/2/,#33FFCC,1,1,#000000,notbold,notitalic:5/3/,#99FF00,1,1,#000000,notbold,notitalic:5/4/,#33FFCC,1,1,#000000,notbold,notitalic:;6/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:6/2/,#33FFCC,1,1,#000000,notbold,notitalic:6/3/,#99FF00,1,1,#000000,notbold,notitalic:6/4/,#33FFCC,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายปี45-47,#FF6600,bold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547@5@select fac from y2545,#66FFCC,select m from y2545,select m from y2546,select m from y2547:,#66CCFF,,,:,#66CCFF,,,:,#66CCFF,,,:,#66CCFF,,,');
INSERT INTO `savedata` VALUES ('ตาราง2', 'ตารางแสดงจำนวนนักศึกษาคณะวิศวกรรมศาสตร์แยกตามภาควิชา,#000000,bold,notitalic|1/1/คณะ,#CCFF00,1,1,#000000,bold,notitalic:1/2/โทรคมนาคม,#FFFFCC,1,1,#000000,notbold,italic:1/3/สารสนเทศ,#FFFFCC,1,1,#000000,notbold,italic:1/4/ไฟฟ้า,#FFFFCC,1,1,#000000,notbold,italic:1/5/โยธา,#FFFFCC,1,1,#000000,notbold,italic:;2/1/ชาย,#CCFF00,1,1,#000000,bold,notitalic:2/2/70,#FFFFCC,1,1,#FF0000,notbold,notitalic:2/3/150,#FFFFCC,1,1,#FF0000,notbold,notitalic:2/4/120,#FFFFCC,1,1,#FF0000,notbold,notitalic:2/5/80,#FFFFCC,1,1,#FF0000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาคณะวิศวกรรมศาสตร์แยกตามภาควิชา,#000000,bold,notitalic|คณะ@โทรคมนาคม,สารสนเทศ,ไฟฟ้า,โยธา@1@ชาย,#CCFF00,70,150,120,80');
INSERT INTO `savedata` VALUES ('กราฟ1', 'กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,bold,notitalic|1/1/ปีการศึกษา/คน,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/2545,#FFFFCC,1,1,#000000,notbold,notitalic:1/3/2546,#FFFFCC,1,1,#000000,notbold,notitalic:1/4/2547,#FFFFCC,1,1,#000000,notbold,notitalic:1/5/2548,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/คอมพิวเตอร์,#66FF66,1,1,#000000,notbold,notitalic:2/2/select m from y2545 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/3/select m from y2546 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/4/select m from y2547 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/5/select m from y2548 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/สารสนเทศ,#66FFFF,1,1,#000000,notbold,notitalic:3/2/select m from y2545 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/3/select m from y2546 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/4/select m from y2547 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/5/select m from y2548 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/โทรคมนาคม,#FF9900,1,1,#000000,notbold,notitalic:4/2/select m from y2545 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/3/select m from y2546 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/4/select m from y2547 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/5/select m from y2548 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:', 'line%กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,bold,notitalic|ปีการศึกษา/คน@2545,2546,2547,2548@3@คอมพิวเตอร์,#66FF66,select m from y2545 where fac = "คอมพิวเตอร์",select m from y2546 where fac = "คอมพิวเตอร์",select m from y2547 where fac = "คอมพิวเตอร์",select m from y2548 where fac = "คอมพิวเตอร์":สารสนเทศ,#66FFFF,select m from y2545 where fac = "สารสนเทศ",select m from y2546 where fac = "สารสนเทศ",select m from y2547 where fac = "สารสนเทศ",select m from y2548 where fac = "สารสนเทศ":โทรคมนาคม,#FF9900,select m from y2545 where fac = "โทรคมนาคม",select m from y2546 where fac = "โทรคมนาคม",select m from y2547 where fac = "โทรคมนาคม",select m from y2548 where fac = "โทรคมนาคม"');
INSERT INTO `savedata` VALUES ('ตาราง1', 'ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF6600,bold,notitalic|1/1/ภาควิชา,#66CCFF,1,2,#FFFFFF,notbold,notitalic:1/2/ปี 2545,#00FFFF,2,1,#000000,notbold,italic:1/3/ปี 2546,#00FFFF,2,1,#000000,notbold,italic:1/4/ปี 2547,#00FFFF,2,1,#000000,notbold,italic:;2/1/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/2/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/3/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/4/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/5/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/6/หญิง,#99FF00,1,1,#000000,notbold,notitalic:;3/1/select fac from y2545,#66CCFF,1,1,#FFFFFF,notbold,notitalic:3/2/select m from y2545,#33FFCC,1,1,#000000,notbold,notitalic:3/3/select f from y2545,#99FF00,1,1,#000000,notbold,notitalic:3/4/select m from y2546,#33FFCC,1,1,#000000,notbold,notitalic:3/5/select f from y2546,#99FF00,1,1,#000000,notbold,notitalic:3/6/select m from y2547,#33FFCC,1,1,#000000,notbold,notitalic:3/7/select f from y2547,#99FF00,1,1,#000000,notbold,notitalic:;4/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:4/2/,#33FFCC,1,1,#000000,notbold,notitalic:4/3/,#99FF00,1,1,#000000,notbold,notitalic:4/4/,#33FFCC,1,1,#000000,notbold,notitalic:4/5/,#99FF00,1,1,#000000,notbold,notitalic:4/6/,#33FFCC,1,1,#000000,notbold,notitalic:4/7/,#99FF00,1,1,#000000,notbold,notitalic:;5/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:5/2/,#33FFCC,1,1,#000000,notbold,notitalic:5/3/,#99FF00,1,1,#000000,notbold,notitalic:5/4/,#33FFCC,1,1,#000000,notbold,notitalic:5/5/,#99FF00,1,1,#000000,notbold,notitalic:5/6/,#33FFCC,1,1,#000000,notbold,notitalic:5/7/,#99FF00,1,1,#000000,notbold,notitalic:;6/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:6/2/,#33FFCC,1,1,#000000,notbold,notitalic:6/3/,#99FF00,1,1,#000000,notbold,notitalic:6/4/,#33FFCC,1,1,#000000,notbold,notitalic:6/5/,#99FF00,1,1,#000000,notbold,notitalic:6/6/,#33FFCC,1,1,#000000,notbold,notitalic:6/7/,#99FF00,1,1,#000000,notbold,notitalic:;7/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:7/2/,#33FFCC,1,1,#000000,notbold,notitalic:7/3/,#99FF00,1,1,#000000,notbold,notitalic:7/4/,#33FFCC,1,1,#000000,notbold,notitalic:7/5/,#99FF00,1,1,#000000,notbold,notitalic:7/6/,#33FFCC,1,1,#000000,notbold,notitalic:7/7/,#99FF00,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF6600,bold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547@6@ชาย,#66FFCC,หญิง,ชาย,หญิง,ชาย,หญิง:select fac from y2545,#66CCFF,select m from y2545,select f from y2545,select m from y2546,select f from y2546,select m from y2547,select f from y2547:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,');
INSERT INTO `savedata` VALUES ('form3', 'ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF3300,notbold,notitalic|1/1/ภาควิชา,#66CCFF,1,2,#FFFFFF,notbold,notitalic:1/2/ปี 2545,#00FFFF,2,1,#000000,notbold,italic:1/3/ปี 2546,#00FFFF,2,1,#000000,notbold,italic:1/4/ปี 2547,#00FFFF,2,1,#000000,notbold,italic:;2/1/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/2/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/3/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/4/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/5/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/6/หญิง,#99FF00,1,1,#000000,notbold,notitalic:;3/1/select fac from y2545,#66CCFF,1,1,#FFFFFF,notbold,notitalic:3/2/select m from y2545,#33FFCC,1,1,#000000,notbold,notitalic:3/3/select f from y2545,#99FF00,1,1,#000000,notbold,notitalic:3/4/select m from y2546,#33FFCC,1,1,#000000,notbold,notitalic:3/5/select f from y2546,#99FF00,1,1,#000000,notbold,notitalic:3/6/select m from y2547,#33FFCC,1,1,#000000,notbold,notitalic:3/7/select f from y2547,#99FF00,1,1,#000000,notbold,notitalic:;4/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:4/2/,#33FFCC,1,1,#000000,notbold,notitalic:4/3/,#99FF00,1,1,#000000,notbold,notitalic:4/4/,#33FFCC,1,1,#000000,notbold,notitalic:4/5/,#99FF00,1,1,#000000,notbold,notitalic:4/6/,#33FFCC,1,1,#000000,notbold,notitalic:4/7/,#99FF00,1,1,#000000,notbold,notitalic:;5/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:5/2/,#33FFCC,1,1,#000000,notbold,notitalic:5/3/,#99FF00,1,1,#000000,notbold,notitalic:5/4/,#33FFCC,1,1,#000000,notbold,notitalic:5/5/,#99FF00,1,1,#000000,notbold,notitalic:5/6/,#33FFCC,1,1,#000000,notbold,notitalic:5/7/,#99FF00,1,1,#000000,notbold,notitalic:;6/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:6/2/,#33FFCC,1,1,#000000,notbold,notitalic:6/3/,#99FF00,1,1,#000000,notbold,notitalic:6/4/,#33FFCC,1,1,#000000,notbold,notitalic:6/5/,#99FF00,1,1,#000000,notbold,notitalic:6/6/,#33FFCC,1,1,#000000,notbold,notitalic:6/7/,#99FF00,1,1,#000000,notbold,notitalic:;7/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:7/2/,#33FFCC,1,1,#000000,notbold,notitalic:7/3/,#99FF00,1,1,#000000,notbold,notitalic:7/4/,#33FFCC,1,1,#000000,notbold,notitalic:7/5/,#99FF00,1,1,#000000,notbold,notitalic:7/6/,#33FFCC,1,1,#000000,notbold,notitalic:7/7/,#99FF00,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF3300,notbold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547@6@ชาย,#66FFCC,หญิง,ชาย,หญิง,ชาย,หญิง:select fac from y2545,#66CCFF,select m from y2545,select f from y2545,select m from y2546,select f from y2546,select m from y2547,select f from y2547:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,');
INSERT INTO `savedata` VALUES ('ตาราง3', 'ตารางจำนวนนักศึกษาวิศวกรรมแยกชายหญิงแบ่งตามภาค,#000000,notbold,notitalic|1/1/ภาควิชา,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/คอมพิวเตอร์,#FFFFCC,1,1,#000000,notbold,notitalic:1/3/สารสนเทศ,#FFFFCC,1,1,#000000,notbold,notitalic:1/4/โทรคมนาคม,#FFFFCC,1,1,#000000,notbold,notitalic:1/5/ไฟฟ้า,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/ชาย,#FFFFCC,1,1,#000000,notbold,notitalic:2/2/select count(*) from computer where sex = "Mr",#FFFFCC,1,1,#000000,notbold,notitalic:2/3/select count(*) from it where sex = "Mr",#FFFFCC,1,1,#000000,notbold,notitalic:2/4/select count(*) from telecom where sex = "Mr",#FFFFCC,1,1,#000000,notbold,notitalic:2/5/select count(*) from power where sex = "Mr",#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/หญิง,#FFFFCC,1,1,#000000,notbold,notitalic:3/2/select count(*) from computer where sex = "Miss",#FFFFCC,1,1,#000000,notbold,notitalic:3/3/select count(*) from it where sex = "Miss",#FFFFCC,1,1,#000000,notbold,notitalic:3/4/select count(*) from telecom where sex = "Miss",#FFFFCC,1,1,#000000,notbold,notitalic:3/5/select count(*) from power where sex = "Miss",#FFFFCC,1,1,#000000,notbold,notitalic:', 'pie%ตารางจำนวนนักศึกษาวิศวกรรมแยกชายหญิงแบ่งตามภาค,#000000,notbold,notitalic|ภาควิชา@คอมพิวเตอร์,สารสนเทศ,โทรคมนาคม,ไฟฟ้า@2@ชาย,#FFFFCC,select count(*) from computer where sex = "Mr",select count(*) from it where sex = "Mr",select count(*) from telecom where sex = "Mr",select count(*) from power where sex = "Mr":หญิง,#FFFFCC,select count(*) from computer where sex = "Miss",select count(*) from it where sex = "Miss",select count(*) from telecom where sex = "Miss",select count(*) from power where sex = "Miss"');
INSERT INTO `savedata` VALUES ('from3', 'ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF0000,notbold,notitalic|1/1/ภาควิชา,#66CCFF,1,2,#FFFFFF,notbold,notitalic:1/2/ปี 2545,#00FFFF,2,1,#000000,notbold,italic:1/3/ปี 2546,#00FFFF,2,1,#000000,notbold,italic:1/4/ปี 2547,#00FFFF,2,1,#000000,notbold,italic:;2/1/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/2/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/3/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/4/หญิง,#99FF00,1,1,#000000,notbold,notitalic:2/5/ชาย,#66FFCC,1,1,#000000,notbold,notitalic:2/6/หญิง,#99FF00,1,1,#000000,notbold,notitalic:;3/1/select fac from y2545,#66CCFF,1,1,#FFFFFF,notbold,notitalic:3/2/select m from y2545,#33FFCC,1,1,#000000,notbold,notitalic:3/3/select f from y2545,#99FF00,1,1,#000000,notbold,notitalic:3/4/select m from y2546,#33FFCC,1,1,#000000,notbold,notitalic:3/5/select f from y2546,#99FF00,1,1,#000000,notbold,notitalic:3/6/select m from y2547,#33FFCC,1,1,#000000,notbold,notitalic:3/7/select f from y2547,#99FF00,1,1,#000000,notbold,notitalic:;4/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:4/2/,#33FFCC,1,1,#000000,notbold,notitalic:4/3/,#99FF00,1,1,#000000,notbold,notitalic:4/4/,#33FFCC,1,1,#000000,notbold,notitalic:4/5/,#99FF00,1,1,#000000,notbold,notitalic:4/6/,#33FFCC,1,1,#000000,notbold,notitalic:4/7/,#99FF00,1,1,#000000,notbold,notitalic:;5/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:5/2/,#33FFCC,1,1,#000000,notbold,notitalic:5/3/,#99FF00,1,1,#000000,notbold,notitalic:5/4/,#33FFCC,1,1,#000000,notbold,notitalic:5/5/,#99FF00,1,1,#000000,notbold,notitalic:5/6/,#33FFCC,1,1,#000000,notbold,notitalic:5/7/,#99FF00,1,1,#000000,notbold,notitalic:;6/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:6/2/,#33FFCC,1,1,#000000,notbold,notitalic:6/3/,#99FF00,1,1,#000000,notbold,notitalic:6/4/,#33FFCC,1,1,#000000,notbold,notitalic:6/5/,#99FF00,1,1,#000000,notbold,notitalic:6/6/,#33FFCC,1,1,#000000,notbold,notitalic:6/7/,#99FF00,1,1,#000000,notbold,notitalic:;7/1/,#66CCFF,1,1,#FFFFFF,notbold,notitalic:7/2/,#33FFCC,1,1,#000000,notbold,notitalic:7/3/,#99FF00,1,1,#000000,notbold,notitalic:7/4/,#33FFCC,1,1,#000000,notbold,notitalic:7/5/,#99FF00,1,1,#000000,notbold,notitalic:7/6/,#33FFCC,1,1,#000000,notbold,notitalic:7/7/,#99FF00,1,1,#000000,notbold,notitalic:', 'pie%ตารางแสดงจำนวนนักศึกษาของคณะวิศวกรรมศาสตร์แยกตามภาคแบ่งชายหญิง,#FF0000,notbold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547@6@ชาย,#66FFCC,หญิง,ชาย,หญิง,ชาย,หญิง:select fac from y2545,#66CCFF,select m from y2545,select f from y2545,select m from y2546,select f from y2546,select m from y2547,select f from y2547:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,:,#66CCFF,,,,,,');
INSERT INTO `savedata` VALUES ('example1', 'ตารางแสดงจำนวนนักศึกษาชายแยกคณะวิศวกรรมศาสตร์ปี45-48,#000000,notbold,notitalic|1/1/ภาควิชา,#009966,1,1,#FFFFFF,bold,notitalic:1/2/ปี 2545,#66CC00,1,1,#FFFFFF,bold,notitalic:1/3/ปี 2546,#66CC33,1,1,#FFFFFF,bold,notitalic:1/4/ปี 2547,#66CC66,1,1,#FFFFFF,bold,notitalic:1/5/ปี 2548,#66CC99,1,1,#FFFFFF,bold,notitalic:;2/1/select fac from y2545,#FFFFCC,1,1,#0000FF,notbold,notitalic:2/2/select m from y2545,#CCCC00,1,1,#000000,notbold,notitalic:2/3/select m from y2546,#FFCC33,1,1,#000000,notbold,notitalic:2/4/select m from y2547,#FFFF99,1,1,#000000,notbold,notitalic:2/5/select m from y2548,#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:3/2/,#CCCC33,1,1,#000000,notbold,notitalic:3/3/,#FFCC33,1,1,#000000,notbold,notitalic:3/4/,#FFFF99,1,1,#000000,notbold,notitalic:3/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:4/2/,#CCCC33,1,1,#000000,notbold,notitalic:4/3/,#FFCC33,1,1,#000000,notbold,notitalic:4/4/,#FFFF99,1,1,#000000,notbold,notitalic:4/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;5/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:5/2/,#CCCC33,1,1,#000000,notbold,notitalic:5/3/,#FFCC33,1,1,#000000,notbold,notitalic:5/4/,#FFFF99,1,1,#000000,notbold,notitalic:5/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;6/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:6/2/,#CCCC33,1,1,#000000,notbold,notitalic:6/3/,#FFCC33,1,1,#000000,notbold,notitalic:6/4/,#FFFF99,1,1,#000000,notbold,notitalic:6/5/,#FFFFCC,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาชายแยกคณะวิศวกรรมศาสตร์ปี45-48,#000000,notbold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547,ปี 2548@5@select fac from y2545,#FFFFCC,select m from y2545,select m from y2546,select m from y2547,select m from y2548:,#FFFFCC,,,,:,#FFFFCC,,,,:,#FFFFCC,,,,:,#FFFFCC,,,,');
INSERT INTO `savedata` VALUES ('กราฟ2', 'กราฟแสดงจำนวนนักศึกษาวิศวกรรมศาสตร์แยกตามภาค,#000000,notbold,notitalic|1/1/,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/คอมพิวเตอร์,#FFFFCC,1,1,#000000,notbold,notitalic:2/2/select count(*) from computer,#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/สารสนเทศ,#FFFFCC,1,1,#000000,notbold,notitalic:3/2/select count(*) from it,#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/ไฟฟ้า,#FFFFCC,1,1,#000000,notbold,notitalic:4/2/select count(*) from power,#FFFFCC,1,1,#000000,notbold,notitalic:;5/1/โทรคมนาคม,#FFFFCC,1,1,#000000,notbold,notitalic:5/2/select count(*) from telecom,#FFFFCC,1,1,#000000,notbold,notitalic:', 'pie%กราฟแสดงจำนวนนักศึกษาวิศวกรรมศาสตร์แยกตามภาค,#000000,notbold,notitalic|@@4@คอมพิวเตอร์,#FFFFCC,select count(*) from computer:สารสนเทศ,#FFFFCC,select count(*) from it:ไฟฟ้า,#FFFFCC,select count(*) from power:โทรคมนาคม,#FFFFCC,select count(*) from telecom');
INSERT INTO `savedata` VALUES ('จัน', 'ตารางแสดงจำนวนนักศึกษาแยกชายหญิงปีการศึกษา45-46,#0000CC,notbold,notitalic|1/1/คณะ,#FFFFCC,1,2,#000000,notbold,notitalic:1/2/ปี 2545,#FFCC66,2,1,#000000,bold,notitalic:1/3/ปี 2546,#FF9933,21,1,#000000,bold,notitalic:;2/1/ชาย,#FFCC99,1,1,#666666,notbold,italic:2/2/หญิง,#FFFF99,1,1,#666666,notbold,italic:2/3/ชาย,#FFCC99,1,1,#666666,notbold,italic:2/4/หญิง,#FFFF99,1,1,#666666,notbold,italic:;3/1/select fac from y2545,#FFCC00,1,1,#000000,notbold,notitalic:3/2/select m from y2545,#FFCC99,1,1,#000000,notbold,notitalic:3/3/select f from y2545,#FFFF99,1,1,#000000,notbold,notitalic:3/4/select m from y2546,#FFCC99,1,1,#000000,notbold,notitalic:3/5/select f from y2546,#FFFF99,1,1,#000000,notbold,notitalic:;4/1/,#FFCC00,1,1,#000000,notbold,notitalic:4/2/,#FFCC99,1,1,#000000,notbold,notitalic:4/3/,#FFFF99,1,1,#000000,notbold,notitalic:4/4/,#FFCC99,1,1,#000000,notbold,notitalic:4/5/,#FFFF99,1,1,#000000,notbold,notitalic:;5/1/,#FFCC00,1,1,#000000,notbold,notitalic:5/2/,#FFCC99,1,1,#000000,notbold,notitalic:5/3/,#FFFF99,1,1,#000000,notbold,notitalic:5/4/,#FFCC99,1,1,#000000,notbold,notitalic:5/5/,#FFFF99,1,1,#000000,notbold,notitalic:;6/1/,#FFCC00,1,1,#000000,notbold,notitalic:6/2/,#FFCC99,1,1,#000000,notbold,notitalic:6/3/,#FFFF99,1,1,#000000,notbold,notitalic:6/4/,#FFCC99,1,1,#000000,notbold,notitalic:6/5/,#FFFF99,1,1,#000000,notbold,notitalic:;7/1/,#FFCC00,1,1,#000000,notbold,notitalic:7/2/,#FFCC99,1,1,#000000,notbold,notitalic:7/3/,#FFFF99,1,1,#000000,notbold,notitalic:7/4/,#FFCC99,1,1,#000000,notbold,notitalic:7/5/,#FFFF99,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาแยกชายหญิงปีการศึกษา45-46,#0000CC,notbold,notitalic|คณะ@ปี 2545,ปี 2546@6@ชาย,#FFCC99,หญิง,ชาย,หญิง:select fac from y2545,#FFCC00,select m from y2545,select f from y2545,select m from y2546,select f from y2546:,#FFCC00,,,,:,#FFCC00,,,,:,#FFCC00,,,,:,#FFCC00,,,,');
INSERT INTO `savedata` VALUES ('กราฟ4', 'กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,notbold,notitalic|1/1/ปีการศึกษา/คน,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/2545,#FFFFCC,1,1,#000000,notbold,notitalic:1/3/2546,#FFFFCC,1,1,#000000,notbold,notitalic:1/4/2547,#FFFFCC,1,1,#000000,notbold,notitalic:1/5/2548,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/คอมพิวเตอร์,#66FF66,1,1,#000000,notbold,notitalic:2/2/select m from y2545 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/3/select m from y2546 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/4/select m from y2547 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/5/select m from y2548 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/สารสนเทศ,#66FFFF,1,1,#000000,notbold,notitalic:3/2/select m from y2545 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/3/select m from y2546 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/4/select m from y2547 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/5/select m from y2548 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/โทรคมนาคม,#FF9900,1,1,#000000,notbold,notitalic:4/2/select m from y2545 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/3/select m from y2546 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/4/select m from y2547 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/5/select m from y2548 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:', 'line%กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,notbold,notitalic|ปีการศึกษา/คน@2545,2546,2547,2548@3@คอมพิวเตอร์,#66FF66,select m from y2545 where fac = "คอมพิวเตอร์",select m from y2546 where fac = "คอมพิวเตอร์",select m from y2547 where fac = "คอมพิวเตอร์",select m from y2548 where fac = "คอมพิวเตอร์":สารสนเทศ,#66FFFF,select m from y2545 where fac = "สารสนเทศ",select m from y2546 where fac = "สารสนเทศ",select m from y2547 where fac = "สารสนเทศ",select m from y2548 where fac = "สารสนเทศ":โทรคมนาคม,#FF9900,select m from y2545 where fac = "โทรคมนาคม",select m from y2546 where fac = "โทรคมนาคม",select m from y2547 where fac = "โทรคมนาคม",select m from y2548 where fac = "โทรคมนาคม"');
INSERT INTO `savedata` VALUES ('form1', 'ตารางแสดงจำนวนนักศึกษาคณะวิศวกรรมศาสตร์แยกตามภาควิชา,#000000,notbold,notitalic|1/1/คอมพิวเตอร์,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/โทรคมนาคม,#FFFFCC,1,1,#000000,notbold,notitalic:1/3/สารสนเทศ,#FFFFCC,1,1,#000000,notbold,notitalic:1/4/ไฟฟ้า,#FFFFCC,1,1,#000000,notbold,notitalic:1/5/โยธา,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/120,#FFFFCC,1,1,#000000,notbold,notitalic:2/2/70,#FFFFCC,1,1,#000000,notbold,notitalic:2/3/150,#FFFFCC,1,1,#000000,notbold,notitalic:2/4/120,#FFFFCC,1,1,#000000,notbold,notitalic:2/5/80,#FFFFCC,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาคณะวิศวกรรมศาสตร์แยกตามภาควิชา,#000000,notbold,notitalic|คอมพิวเตอร์@โทรคมนาคม,สารสนเทศ,ไฟฟ้า,โยธา@1@120,#FFFFCC,70,150,120,80');
INSERT INTO `savedata` VALUES ('example2', 'ตารางแสดงจำนวนนักศึกษาหญิงแยกคณะวิศวกรรมศาสตร์ปี45-48,#000000,notbold,notitalic|1/1/ภาควิชา,#009966,1,1,#FFFFFF,bold,notitalic:1/2/ปี 2545,#66CC00,1,1,#FFFFFF,bold,notitalic:1/3/ปี 2546,#66CC33,1,1,#FFFFFF,bold,notitalic:1/4/ปี 2547,#66CC66,1,1,#FFFFFF,bold,notitalic:1/5/ปี 2548,#66CC99,1,1,#FFFFFF,bold,notitalic:;2/1/select fac from y2545,#FFFFCC,1,1,#0000FF,notbold,notitalic:2/2/select f from y2545,#CCCC00,1,1,#000000,notbold,notitalic:2/3/select f from y2546,#FFCC33,1,1,#000000,notbold,notitalic:2/4/select f from y2547,#FFFF99,1,1,#000000,notbold,notitalic:2/5/select f from y2548,#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:3/2/,#CCCC33,1,1,#000000,notbold,notitalic:3/3/,#FFCC33,1,1,#000000,notbold,notitalic:3/4/,#FFFF99,1,1,#000000,notbold,notitalic:3/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:4/2/,#CCCC33,1,1,#000000,notbold,notitalic:4/3/,#FFCC33,1,1,#000000,notbold,notitalic:4/4/,#FFFF99,1,1,#000000,notbold,notitalic:4/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;5/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:5/2/,#CCCC33,1,1,#000000,notbold,notitalic:5/3/,#FFCC33,1,1,#000000,notbold,notitalic:5/4/,#FFFF99,1,1,#000000,notbold,notitalic:5/5/,#FFFFCC,1,1,#000000,notbold,notitalic:;6/1/,#FFFFCC,1,1,#0000FF,notbold,notitalic:6/2/,#CCCC33,1,1,#000000,notbold,notitalic:6/3/,#FFCC33,1,1,#000000,notbold,notitalic:6/4/,#FFFF99,1,1,#000000,notbold,notitalic:6/5/,#FFFFCC,1,1,#000000,notbold,notitalic:', 'line%ตารางแสดงจำนวนนักศึกษาหญิงแยกคณะวิศวกรรมศาสตร์ปี45-48,#000000,notbold,notitalic|ภาควิชา@ปี 2545,ปี 2546,ปี 2547,ปี 2548@5@select fac from y2545,#FFFFCC,select f from y2545,select f from y2546,select f from y2547,select f from y2548:,#FFFFCC,,,,:,#FFFFCC,,,,:,#FFFFCC,,,,:,#FFFFCC,,,,');
INSERT INTO `savedata` VALUES ('กราฟ11', 'กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,bold,notitalic|1/1/ปีการศึกษา/คน,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/2545,#FFFFCC,1,1,#000000,notbold,notitalic:1/3/2546,#FFFFCC,1,1,#000000,notbold,notitalic:1/4/2547,#FFFFCC,1,1,#000000,notbold,notitalic:1/5/2548,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/คอมพิวเตอร์,#66FF66,1,1,#000000,notbold,notitalic:2/2/select m from y2545 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/3/select m from y2546 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/4/select m from y2547 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:2/5/select m from y2548 where fac = "คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/สารสนเทศ,#66FFFF,1,1,#000000,notbold,notitalic:3/2/select m from y2545 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/3/select m from y2546 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/4/select m from y2547 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:3/5/select m from y2548 where fac = "สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/โทรคมนาคม,#FF9900,1,1,#000000,notbold,notitalic:4/2/select m from y2545 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/3/select m from y2546 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/4/select m from y2547 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:4/5/select m from y2548 where fac = "โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:', 'bar%กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมตั้งแต่ปี45-48,#000000,bold,notitalic|ปีการศึกษา/คน@2545,2546,2547,2548@3@คอมพิวเตอร์,#66FF66,select m from y2545 where fac = "คอมพิวเตอร์",select m from y2546 where fac = "คอมพิวเตอร์",select m from y2547 where fac = "คอมพิวเตอร์",select m from y2548 where fac = "คอมพิวเตอร์":สารสนเทศ,#66FFFF,select m from y2545 where fac = "สารสนเทศ",select m from y2546 where fac = "สารสนเทศ",select m from y2547 where fac = "สารสนเทศ",select m from y2548 where fac = "สารสนเทศ":โทรคมนาคม,#FF9900,select m from y2545 where fac = "โทรคมนาคม",select m from y2546 where fac = "โทรคมนาคม",select m from y2547 where fac = "โทรคมนาคม",select m from y2548 where fac = "โทรคมนาคม"');
INSERT INTO `savedata` VALUES ('กราฟ3', 'กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมศาสตร์แยกตามภาคปี45,#000000,bold,notitalic|1/1/,#FFFFCC,1,1,#000000,notbold,notitalic:1/2/,#FFFFCC,1,1,#000000,notbold,notitalic:;2/1/คอมพิวเตอร์,#FFFFCC,1,1,#000000,notbold,notitalic:2/2/select m from y2545 where fac ="คอมพิวเตอร์",#FFFFCC,1,1,#000000,notbold,notitalic:;3/1/สารสนเทศ,#FFFFCC,1,1,#000000,notbold,notitalic:3/2/select m from y2545 where fac ="สารสนเทศ",#FFFFCC,1,1,#000000,notbold,notitalic:;4/1/ไฟฟ้า,#FFFFCC,1,1,#000000,notbold,notitalic:4/2/select m from y2545 where fac ="ไฟฟ้า",#FFFFCC,1,1,#000000,notbold,notitalic:;5/1/โทรคมนาคม,#FFFFCC,1,1,#000000,notbold,notitalic:5/2/select m from y2545 where fac ="โทรคมนาคม",#FFFFCC,1,1,#000000,notbold,notitalic:', 'pie%กราฟแสดงจำนวนนักศึกษาชายวิศวกรรมศาสตร์แยกตามภาคปี45,#000000,bold,notitalic|@@4@คอมพิวเตอร์,#FFFFCC,select m from y2545 where fac ="คอมพิวเตอร์":สารสนเทศ,#FFFFCC,select m from y2545 where fac ="สารสนเทศ":ไฟฟ้า,#FFFFCC,select m from y2545 where fac ="ไฟฟ้า":โทรคมนาคม,#FFFFCC,select m from y2545 where fac ="โทรคมนาคม"');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `telecom`
-- 

CREATE TABLE `telecom` (
  `id` int(11) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `telecom`
-- 

INSERT INTO `telecom` VALUES (1, 'Mr', 'กกก', 'ขขข');
INSERT INTO `telecom` VALUES (2, 'Mr', 'คคค', 'งงง');
INSERT INTO `telecom` VALUES (3, 'Mr', 'ววว', 'งงง');
INSERT INTO `telecom` VALUES (4, 'Mr', 'ททท', 'มมม');
INSERT INTO `telecom` VALUES (5, 'Mr', 'ลลล', 'สสส');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `test`
-- 

CREATE TABLE `test` (
  `name` varchar(20) collate utf8_bin default NULL,
  `surname` varchar(20) collate utf8_bin default NULL,
  `age` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 
-- dump ตาราง `test`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `y2545`
-- 

CREATE TABLE `y2545` (
  `Fac` varchar(200) NOT NULL,
  `M` int(11) NOT NULL,
  `F` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `y2545`
-- 

INSERT INTO `y2545` VALUES ('คอมพิวเตอร์', 82, 32);
INSERT INTO `y2545` VALUES ('โทรคมนาคม', 52, 13);
INSERT INTO `y2545` VALUES ('สารสนเทศ', 60, 46);
INSERT INTO `y2545` VALUES ('ไฟฟ้า', 94, 7);
INSERT INTO `y2545` VALUES ('โยธา', 56, 32);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `y2546`
-- 

CREATE TABLE `y2546` (
  `Fac` varchar(200) NOT NULL,
  `M` int(11) NOT NULL,
  `F` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `y2546`
-- 

INSERT INTO `y2546` VALUES ('คอมพิวเตอร์', 78, 29);
INSERT INTO `y2546` VALUES ('โทรคมนาคม', 64, 15);
INSERT INTO `y2546` VALUES ('สารสนเทศ', 61, 44);
INSERT INTO `y2546` VALUES ('ไฟฟ้า', 88, 12);
INSERT INTO `y2546` VALUES ('โยธา', 45, 40);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `y2547`
-- 

CREATE TABLE `y2547` (
  `Fac` varchar(200) NOT NULL,
  `M` int(11) NOT NULL,
  `F` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `y2547`
-- 

INSERT INTO `y2547` VALUES ('คอมพิวเตอร์', 85, 33);
INSERT INTO `y2547` VALUES ('โทรคมนาคม', 55, 15);
INSERT INTO `y2547` VALUES ('สารสนเทศ', 54, 50);
INSERT INTO `y2547` VALUES ('ไฟฟ้า', 84, 15);
INSERT INTO `y2547` VALUES ('โยธา', 50, 34);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `y2548`
-- 

CREATE TABLE `y2548` (
  `Fac` varchar(200) NOT NULL,
  `M` int(11) NOT NULL,
  `F` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=tis620;

-- 
-- dump ตาราง `y2548`
-- 

INSERT INTO `y2548` VALUES ('คอมพิวเตอร์', 81, 31);
INSERT INTO `y2548` VALUES ('โทรคมนาคม', 70, 5);
INSERT INTO `y2548` VALUES ('สารสนเทศ', 45, 48);
INSERT INTO `y2548` VALUES ('ไฟฟ้า', 87, 14);
INSERT INTO `y2548` VALUES ('โยธา', 49, 41);
