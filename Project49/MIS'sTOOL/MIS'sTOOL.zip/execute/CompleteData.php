<?php
    
	header("Content-Type: text/plain; charset=TIS-620");

    $DBServer = "localhost";
    $DBName = "mis";
    $DBUsername = "root";
    $DBPassword = "123qwe";

    $conn=mysql_connect( $DBServer, $DBUsername, $DBPassword ) or die( "�������ö�Դ��͡ѺMySQL��");
    mysql_select_db( $DBName ) or die( "�������ö���͡��ҹ������ $dbname ��" ); 

	//thai font
	$charset = "SET NAMES tis620"; 
	mysql_query($charset) or die('Invalid query: ' . mysql_error());
	$sql_select="select * from savedata where FILENAME like '%$names%' order by FILENAME";
    $result1= mysql_query( $sql_select, $conn );

   while ($result = mysql_fetch_array($result1))

   {	  		 
	    echo"$result[FILENAME],";	
   }
    
	mysql_close();
?>