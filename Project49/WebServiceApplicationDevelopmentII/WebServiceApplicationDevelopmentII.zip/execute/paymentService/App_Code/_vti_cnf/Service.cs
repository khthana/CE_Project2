vti_encoding:SR|utf8-nl
vti_author:SR|OLALA39\\oporinho
vti_modifiedby:SR|OLALA39\\oporinho
vti_timelastmodified:TR|07 Feb 2007 09:06:23 -0000
vti_timecreated:TR|07 Feb 2007 09:06:23 -0000
vti_lineageid:SR|{B9D2CC73-9D65-4763-82AB-C6EBBA261C92}
vti_cacheddtm:TX|07 Feb 2007 09:06:23 -0000
vti_filesize:IR|1219
vti_extenderversion:SR|5.0.2.6790
vti_backlinkinfo:VX|
