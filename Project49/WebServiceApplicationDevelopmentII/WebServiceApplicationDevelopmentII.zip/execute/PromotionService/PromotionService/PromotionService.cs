using System;
using System.ServiceModel;
using System.Collections.Generic;
using System.Workflow.Runtime;
using System.Threading;

namespace PromotionService
{
	[ServiceContract()]
	public interface IPromotionService
	{
		[OperationContract]
		string compute(string XMLOrder);
	}

	public class PromotionService : IPromotionService
	{
		public string compute(string XMLOrder)
		{
            try
            {
                double sum = 0.0;
                double point = 0;
                MapOrderXML map = new MapOrderXML(XMLOrder);

                using (WorkflowRuntime wr = new WorkflowRuntime())
                {
                    AutoResetEvent waitHandle = new AutoResetEvent(false);
                    wr.WorkflowCompleted +=
                       delegate(object sender, WorkflowCompletedEventArgs e)
                       {
                           sum = (double)e.OutputParameters["SUM"];
                           point = (double)e.OutputParameters["Point_update"];
                           waitHandle.Set();
                       };
                    //list<string>Id_product,Id_provider,list<double> Price,int Point_member,Point_update,double SUM
                    Dictionary<string, object> arguments = new Dictionary<string, object>();
                    arguments.Add("Id_product", map.getContentID());
                    arguments.Add("Id_provider", map.getProviderId());
                    arguments.Add("Price", map.getPrise());
                    arguments.Add("Point_member", map.getPoint());
                    arguments.Add("Point_update",point);
                    arguments.Add("SUM", sum);



                    WorkflowInstance wi = wr.CreateWorkflow(typeof(WorkflowConsoleApplication5.Workflow1), arguments);
                    
                    wi.Start();
                    waitHandle.WaitOne();
                }

                string ret = "<cart><totalCost>" + sum.ToString() + "</totalCost><pointUpdate>" + point.ToString() + "</pointUpdate></cart>";
                return ret;
            }
            catch ( Exception ex)
            {

                return ex.Message;
            }

		}
	}

}

