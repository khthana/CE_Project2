using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Collections;
using System.Collections.Generic;

namespace WorkflowConsoleApplication5
{
    public partial class Workflow1 : SequentialWorkflowActivity
    {
        private void SumMoney_ExecuteCode(object sender, EventArgs e)
        {

            //int a = Iter;
            //a = a + 1;
            ////Console.WriteLine("Round " + Iter);
            ////Console.WriteLine("Price  value is " + Price[Iter]);

            // //Console.WriteLine("Write value price  " + this.SUM);
            SUM = SUM + Price[Iter];
            ////Console.WriteLine("Sum Value is" + SUM);
            //Point_update = Point_update + SUM;
            ////Console.WriteLine("Write Point is " + this.Point_update);
            // ITER++;
            Iter++;

        }
     
        private int iter;

        public int Iter
        {
            get { return iter; }
            set { iter = value; }
        }

        private List<string> id_product;

        public List<string> Id_product
        {
            get { return id_product; }
            set { id_product = value; }
        }

        private List<string> id_provider;

        public List<string> Id_provider
        {
            get { return id_provider; }
            set { id_provider = value; }
        }

        private List<double> price;

        public List<double> Price
        {
            get { return price; }
            set { price = value; }
        }

        private double point_member;

        public double Point_member
        {
            get { return point_member; }
            set { point_member = value; }
        }

        // �ӡ�äԴ�Ҥ����������
        private double sum;

        public double SUM
        {
            get { return sum; }
            set { sum = value; }
        }

        private double point_update;

        public double Point_update
        {
            get { return point_update; }
            set { point_update = value; }
        }

        int count_pro1;

        public int Count_pro1
        {
            get { return count_pro1; }
            set { count_pro1 = value; }
        }

        private int count_pro2;

        public int Count_pro2
        {
            get { return count_pro2; }
            set { count_pro2 = value; }
        }

        private int count_pro3;

        public int Count_pro3
        {
            get { return count_pro3; }
            set { count_pro3 = value; }
        }

        private int count_pro4;

        public int Count_pro4
        {
            get { return count_pro4; }
            set { count_pro4 = value; }
        }

        private int count_pro5;

        public int Count_pro5
        {
            get { return count_pro5; }
            set { count_pro5 = value; }
        }

        //�Ҥ�����Թ��ҷ��ӡ��Ŵ�������������
        private double price_dis;

        public double Price_dis
        {
            get { return price_dis; }
            set { price_dis = value; }
        }
        //�Ҥ�����ͧ�Թ��� ��͹Ŵ�ҤҨҡ�������
        private double price_notdis;

        public double Price_notdis
        {
            get { return price_notdis; }
            set { price_notdis = value; }
        }
	
	
	

        private void SumTotal_ExecuteCode(object sender, EventArgs e)
        {            
            //Console.WriteLine("SUM value is = " + SUM);
            //Console.WriteLine("Price Discount = " + Price_dis );
            //Console.WriteLine("Price Not Discount = " + Price_notdis);
            SUM = SUM - Price_notdis + Price_dis;
            //Console.WriteLine("Total price = " + SUM);
        }

        private void Sum_Iter_ExecuteCode(object sender, EventArgs e)
        {            
            //Console.WriteLine("Iterator round = " + Iter);
            //Console.WriteLine("Count Promotion 1 = " + Count_pro1);
            //Console.WriteLine("Count Promotion 2 = " + Count_pro2);
            //Console.WriteLine("Count Promotion 3 = " + Count_pro3);
            //Console.WriteLine("Count Promotion 4 = " + Count_pro4);
            //Console.WriteLine("Count Promotion 5 = " + Count_pro5);
            SUM = price[Iter] +SUM;
            //Console.WriteLine("Count Money Total Wa = " + SUM);
            Iter = Iter + 1;
            //Console.ReadLine();
        }

        private void Total_Money_ExecuteCode(object sender, EventArgs e)
        {
            //Console.WriteLine("Total Money is = " + SUM);
            Point_member = Point_member + SUM;
            //Console.WriteLine("Point_member is = " + Point_member);
            //Console.ReadLine();
        }

        

    }
}