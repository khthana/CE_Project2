using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;


    class MapOrderXML
    {
        XmlDocument doc;
        
        private String xpathContentId;
        private String xpathProviderId;
        private String xpathUsername;
        private String xpathCost;
        private String xpathPoint;
        public MapOrderXML(string XMLString)
        {
            doc = new XmlDocument();
            doc.LoadXml(XMLString);

            xpathContentId = "//cart/content/@id";
            xpathProviderId = "//cart/content/@providerId";
            xpathUsername = "//cart/username";
            xpathCost = "//cart/content/cost";
            xpathPoint = "//cart/point";
        }
        public List<string> getContentID()
        {
            List<string> tmp = new List<string>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathContentId);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(tmpContentId.Item(i).FirstChild.Value);
            }
            return tmp;
        }
        public List<string> getProviderId()
        {
            List<string> tmp = new List<string>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathProviderId);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(tmpContentId.Item(i).FirstChild.Value);
            }
            return tmp;
        }
        public List<double> getPrise()
        {
            List<double> tmp = new List<double>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathCost);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(Convert.ToDouble(tmpContentId.Item(i).FirstChild.Value));
            }
            return tmp;
        }
        public double getPoint()
        {
            XmlNode tmp = doc.SelectSingleNode(xpathPoint);
            return Convert.ToInt32(tmp.FirstChild.Value);
        }

    
    }

