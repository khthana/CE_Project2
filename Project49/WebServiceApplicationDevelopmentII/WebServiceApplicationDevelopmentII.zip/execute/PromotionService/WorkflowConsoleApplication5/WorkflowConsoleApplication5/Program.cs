#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;

#endregion

namespace WorkflowConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            using(WorkflowRuntime workflowRuntime = new WorkflowRuntime())
            {
                AutoResetEvent waitHandle = new AutoResetEvent(false);
                workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) {waitHandle.Set();};
                workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                {
                    Console.WriteLine(e.Exception.Message);
                    waitHandle.Set();
                };


                Dictionary<string, Object> Dic = new Dictionary<string, object>();

                List<string> L1 = new List<string>();
                 L1.Add("1");
                 L1.Add("2");
                 L1.Add("3");
                 L1.Add("4");
                 L1.Add("5");
                 L1.Add("6");
                 L1.Add("7");
                 L1.Add("8");
                 L1.Add("9");
                 L1.Add("10");
                Dic.Add("Id_product", L1);

                List<string> L2 = new List<string>();
                L2.Add("46010320");    //a
                L2.Add("46010364");    //b
                L2.Add("46010396");    //c
                L2.Add("46010320");    //d
                L2.Add("46010396");    //e
                L2.Add("46010396");    //f
                L2.Add("46010396");    //g
                L2.Add("46010396");    //h
                L2.Add("46010396");    //i
                L2.Add("46010396");    //j
                Dic.Add("Id_provider", L2);

                List<double> L3 = new List<double>();
                L3.Add(100);
                L3.Add(150);
                L3.Add(200);
                L3.Add(250);
                L3.Add(300);
                L3.Add(350);
                L3.Add(300);
                L3.Add(400);
                L3.Add(450);
                L3.Add(500);
                Dic.Add("Price", L3);


                double point_member = 15000;
                Dic.Add("Point_member", point_member);

                double sum = 0;
                Dic.Add("SUM", sum);

                double price_dis= 0;
                Dic.Add("Price_dis", price_dis);

                double price_notdis = 0;
                Dic.Add("Price_notdis", price_notdis);

                double point_update = 0;
                Dic.Add("Point_update", point_update);

                int count_pro1 = 0;
                Dic.Add("Count_pro1",count_pro1);

                int count_pro2 = 0;
                Dic.Add("Count_pro2", count_pro2);

                int count_pro3 = 0;
                Dic.Add("Count_pro3", count_pro3);

                int count_pro4 = 0;
                Dic.Add("Count_pro4", count_pro4);

                int count_pro5 = 0;
                Dic.Add("Count_pro5", count_pro5);


                WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(WorkflowConsoleApplication5.Workflow1), Dic);
                instance.Start();

                waitHandle.WaitOne();
            }
        }
    }
}
