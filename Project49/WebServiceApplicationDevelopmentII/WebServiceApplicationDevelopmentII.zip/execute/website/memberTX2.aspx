<%@ Page Language="C#" AutoEventWireup="true" CodeFile="memberTX2.aspx.cs" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:olala_agentConnectionString %>"
            SelectCommand="SELECT [mctxid], [mdate], [mtime], [totalamount], [paymentid] FROM [member_content_transaction] WHERE ([memberid] = @memberid2)">
            <SelectParameters>
                <asp:QueryStringParameter DefaultValue="0" Name="memberid2" QueryStringField="memberid"
                    Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
    
    </div>
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4"
            DataKeyNames="mctxid" DataSourceID="SqlDataSource1" 
            ForeColor="#333333" GridLines="None" OnSelectedIndexChanged="GridView1_SelectedIndexChanged" AllowPaging="True" AllowSorting="True">
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <Columns>
            
                <asp:TemplateField
                        HeaderText="TransactionID">
                        <ItemTemplate>
                        <asp:LinkButton ID="LinkButton1" Runat="Server"
                          Text='<%# Eval("mctxid") %>'
                          CommandName="Select"/>
                        </ItemTemplate>
                    <HeaderStyle Width="60px" />
                      </asp:TemplateField>
                      
                <asp:BoundField DataField="mctxid" HeaderText="TransactionID" InsertVisible="False" ReadOnly="True"
                    SortExpression="mctxid" Visible="False" />
                <asp:BoundField DataField="mdate" HeaderText="mdate" SortExpression="mdate" />
                <asp:BoundField DataField="mtime" HeaderText="mtime" SortExpression="mtime" />
                <asp:BoundField DataField="totalamount" HeaderText="totalamount" SortExpression="totalamount" />
                <asp:BoundField DataField="paymentid" HeaderText="paymentid" SortExpression="paymentid" />
            </Columns>
            <RowStyle BackColor="#EFF3FB" />
            <EditRowStyle BackColor="#2461BF" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp;
        
        
        <asp:SqlDataSource ID="SqlDataSource2" runat="server" ConnectionString="<%$ ConnectionStrings:olala_agentConnectionString %>"
            SelectCommand="SELECT [cctxid], [line_no], [providerid], [contentid], [contentlink], [contenthashcode], [providertxid] FROM [contentitem] WHERE ([cctxid] = @cctxid)">
            <SelectParameters>
                <asp:ControlParameter ControlID="GridView1" Name="cctxid" PropertyName="SelectedValue"
                    Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
        
        
        <asp:GridView ID="GridView2" runat="server" AllowSorting="True" AutoGenerateColumns="False"
            CellPadding="4" DataKeyNames="cctxid,line_no" DataSourceID="SqlDataSource2" ForeColor="#333333"
            GridLines="None">
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <Columns>
                <asp:BoundField DataField="cctxid" HeaderText="cctxid" ReadOnly="True" SortExpression="cctxid" />
                <asp:BoundField DataField="line_no" HeaderText="line_no" ReadOnly="True" SortExpression="line_no" />
                <asp:BoundField DataField="providerid" HeaderText="providerid" SortExpression="providerid" />
                <asp:BoundField DataField="contentid" HeaderText="contentid" SortExpression="contentid" />
                <asp:BoundField DataField="contentlink" HeaderText="contentlink" SortExpression="contentlink" />
                <asp:BoundField DataField="contenthashcode" HeaderText="contenthashcode" SortExpression="contenthashcode" />
                <asp:BoundField DataField="providertxid" HeaderText="providertxid" SortExpression="providertxid" />
                <asp:HyperLinkField 
                        DataTextField="contentlink" 
                        DataNavigateUrlFields="contentlink,contenthashcode,providertxid"                         
                        DataNavigateUrlFormatString="~/?link={0}&amp;code={1}" />
                        <%--DataNavigateUrlFormatString="~/txdetail.aspx?txid={0}" />--%>
            </Columns>
            <RowStyle BackColor="#EFF3FB" />
            <EditRowStyle BackColor="#2461BF" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp;
    </form>
</body>
</html>
