using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ViewAddcart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string cart = Session["cart"].ToString();
            cart += CartItem.cartItemString(Session["AddContentId"].ToString(), Session["AddProviderId"].ToString());
            Session.Remove("AddContentId");
            Session.Remove("AddProviderId");
            Session["cart"] = cart;
            int size = cart.Length;
            double sizeXML = size / 65;
            Label1.Text = "You have " + Convert.ToInt32(sizeXML).ToString() + "items in cart";
        }
        catch (Exception ex)
        {
            Response.Redirect("home.aspx");
        }
        //Server.Transfer("hame.aspx");
    }
}
