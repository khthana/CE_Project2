<%@ Page Language="C#" AutoEventWireup="true" CodeFile="search.aspx.cs" Inherits="search" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body style="color: #3366ff">
    <form id="form1" runat="server">
    <div>
        <table border="0" cellpadding="0" cellspacing="0" style="padding-right: 0px; padding-left: 0px;
            border-left-color: #ffffff; border-bottom-color: #ffffff; padding-bottom: 0px;
            margin: 0px; width: 800px; border-top-color: #ffffff; padding-top: 0px; border-collapse: separate;
            border-right-color: #ffffff" summary="This table use for Header">
            <tr>
                <td colspan="2" style="border-top-width: 1px; font-weight: bolder; border-left-width: 1px;
                    font-size: x-large; border-left-color: #00ccff; border-bottom-width: 1px; border-bottom-color: #00ccff;
                    color: white; border-top-color: #00ccff; height: 100px; background-color: white;
                    text-align: left; border-right-width: 1px; font-variant: small-caps; border-right-color: #00ccff"
                    valign="top">
                    <br />
                    <img src="images/OnlineContentServiceHead.jpg" /></td>
            </tr>
            <tr>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 200px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: left; border-bottom-style: none"
                    valign="top">
                    <asp:Label ID="Label2" runat="server"></asp:Label></td>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 800px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: right; border-bottom-style: none"
                    valign="top">
                    <asp:HyperLink ID="HyperLink4" runat="server" BackColor="White" Font-Bold="True"
                        NavigateUrl="~/home.aspx" Style="color: #0033ff">home</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink5" runat="server" NavigateUrl="~/viewCart.aspx" Style="font-weight: bold;
                        color: #3366ff">viewcart</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink3" runat="server" EnableViewState="False" NavigateUrl="~/regist.aspx"
                        Style="font-weight: bold; color: #3366ff">register</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/search.aspx" Style="font-weight: bold;
                        color: #3366cc">Search</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/browse.aspx" Style="font-weight: bold;
                        color: #3366ff">browse</asp:HyperLink></td>
            </tr>
        </table>
    
    </div>
        <table style="border-right: #3366ff 2px solid; border-top: #3366ff 2px solid; border-left: #3366ff 2px solid;
            width: 800px; border-bottom: #3366ff 2px solid">
            <tr>
                <td style="width: 200px; height: 168px" align="center" valign="top">
                    <asp:Panel ID="Panel1" runat="server" BackColor="#FFFFC0" BorderColor="#8080FF" BorderStyle="Solid"
                        Height="200px" Width="210px">
                        <table style="width: 200px">
                            <tr>
                                <td style="width: 120px; height: 26px">
                                    username</td>
                                <td style="width: 120px; height: 26px">
                                    <asp:TextBox ID="username" runat="server" Width="120px"></asp:TextBox></td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 26px">
                                    password</td>
                                <td style="width: 100px; height: 26px">
                                    <asp:TextBox ID="password" runat="server" TextMode="Password" Width="120px"></asp:TextBox></td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 26px">
                                </td>
                                <td style="width: 100px; height: 26px">
                                    <asp:Button ID="Button1" runat="server" BackColor="#C0C0FF" ForeColor="Blue" OnClick="Button1_Click"
                                        Text="login" Width="72px" /></td>
                            </tr>
                        </table>
                        <asp:Label ID="Label1" runat="server" Height="26px" Width="205px"></asp:Label>
                        <br />
                    </asp:Panel>
                </td>
                <td align="center" rowspan="2" style="background-image: url(images/bg.jpg); width: 600px;
                    background-repeat: no-repeat; text-align: center" valign="top">
                    <br />
                    <table style="width: 400px">
                        <tr>
                            <td style="width: 100px; text-align: right">
                                <asp:Button ID="Button2" runat="server" OnClick="Button2_Click" Text="Search" BackColor="#FFE0C0" ForeColor="Blue" />
                                &nbsp;
                            </td>
                            <td style="width: 81px; text-align: left">
                                <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="height: 21px">
                                <asp:Xml ID="Xml1" runat="server" TransformSource="~/xslt/browse3.xsl"></asp:Xml></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="width: 200px;" valign="top">
                    <asp:Panel ID="Panel2" runat="server" Height="50px" Width="125px">
                        promotion</asp:Panel>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
