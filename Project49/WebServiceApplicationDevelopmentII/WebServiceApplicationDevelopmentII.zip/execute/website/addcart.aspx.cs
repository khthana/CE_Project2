using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

public partial class addcart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //add to cart
        try
        {
            //string cart = Session["cart"].ToString();
            Session["AddContentId"] = Request.QueryString["contentId"];
            Session["AddProviderId"] = Request.QueryString["providerId"];
            Response.Redirect("ViewAddcart.aspx");
            //cart += CartItem.cartItemString(Request.QueryString["contentId"], Request.QueryString["providerId"]);
            //Session["cart"] = cart;
            //int size = cart.Length;
            //double sizeXML=size/65;
            //Label1.Text ="You have "+ Convert.ToInt32(sizeXML).ToString() +"items in cart";
            //Server.Transfer("hame.aspx");
        }
        catch (Exception ex)
        {
            //Label1.Text = "No cart selected";
        }

        //Label1.Text = doc.GetElementsByTagName("contentId").Item(0).FirstChild.Value;

        //Label2.Text = ;
    }
}
