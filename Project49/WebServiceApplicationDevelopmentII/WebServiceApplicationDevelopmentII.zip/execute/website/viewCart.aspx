<%@ Page Language="C#" AutoEventWireup="true" CodeFile="viewCart.aspx.cs" Inherits="viewCart" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <table border="0" cellpadding="0" cellspacing="0" style="padding-right: 0px; padding-left: 0px;
            border-left-color: #ffffff; border-bottom-color: #ffffff; padding-bottom: 0px;
            margin: 0px; width: 800px; border-top-color: #ffffff; padding-top: 0px; border-collapse: separate;
            border-right-color: #ffffff" summary="This table use for Header">
            <tr>
                <td colspan="2" style="border-top-width: 1px; font-weight: bolder; border-left-width: 1px;
                    font-size: x-large; border-left-color: #00ccff; border-bottom-width: 1px; border-bottom-color: #00ccff;
                    color: white; border-top-color: #00ccff; height: 100px; background-color: white;
                    text-align: left; border-right-width: 1px; font-variant: small-caps; border-right-color: #00ccff"
                    valign="top">
                    <br />
                    <img src="images/OnlineContentServiceHead.jpg" /></td>
            </tr>
            <tr>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 200px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: left; border-bottom-style: none"
                    valign="top">
                    <asp:Label ID="Label2" runat="server"></asp:Label></td>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 800px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: right; border-bottom-style: none"
                    valign="top">
                    &nbsp;<asp:HyperLink ID="HyperLink4" runat="server" BackColor="White" Font-Bold="True"
                        NavigateUrl="~/home.aspx" Style="color: #0033ff">home</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink5" runat="server" NavigateUrl="~/viewCart.aspx" Style="font-weight: bold;
                        color: #3366ff">viewcart</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink3" runat="server" EnableViewState="False" NavigateUrl="~/regist.aspx"
                        Style="font-weight: bold; color: #3366ff">register</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/search.aspx" Style="font-weight: bold;
                        color: #3366cc">Search</asp:HyperLink>
                    <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/browse.aspx" Style="font-weight: bold;
                        color: #3366ff">browse</asp:HyperLink>&nbsp;
                </td>
            </tr>
        </table>
        <br />
        <table style="border-right: #3366ff 2px solid; border-top: #3366ff 2px solid; border-left: #3366ff 2px solid;
            width: 800px; border-bottom: #3366ff 2px solid">
            <tr>
                <td align="center" style="width: 202px; height: 168px; background-color: #ffffcc"
                    valign="top">
                    &nbsp;&nbsp;
                    <table>
                        <tr>
                            <td style="width: 100px">
                                email
                            </td>
                            <td style="width: 42px">
        <asp:TextBox ID="TextBox2" runat="server" Width="96px">email</asp:TextBox></td>
                        </tr>
                        <tr>
                            <td style="width: 100px">
                                password</td>
                            <td style="width: 42px">
        <asp:TextBox ID="TextBox1" runat="server" OnTextChanged="TextBox1_TextChanged" Width="93px" TextMode="Password">paypalpassword</asp:TextBox></td>
                        </tr>
                    </table>
                    <br />
        <asp:Button ID="Button1" runat="server" OnClick="Button1_Click" Text="buy this cart" /></td>
                <td align="center" rowspan="2" style="background-image: url(images/bg.jpg); width: 600px;
                    background-repeat: no-repeat; text-align: center" valign="top">
        <asp:Label ID="Label1" runat="server"></asp:Label><br />
        <asp:Xml ID="viewCartXML" runat="server" TransformSource="~/xslt/viewCart.xsl"></asp:Xml></td>
            </tr>
            <tr>
                <td style="width: 202px" valign="top">
                    &nbsp;</td>
            </tr>
        </table>
        <br />
        &nbsp;<br />
    </div>
        &nbsp;&nbsp;
    </form>
</body>
</html>
