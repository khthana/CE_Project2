<%@ Page Language="C#" AutoEventWireup="true" CodeFile="viewPage1.aspx.cs" Inherits="viewPage_viewPage1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body bgcolor="#006699">
    <form id="form1" runat="server">
    <div>
        <div style="text-align: center">
            <table style="width: 800px; height: 800px; padding-left: 0px; padding-bottom: 0px; margin: 0px; border-top-style: none; padding-top: 0px; border-right-style: none; border-left-style: none; border-bottom-style: none; border-collapse: collapse;">
                <tr>
                    <td style="background-image: url(../images/designViewPage_01.gif); width: 320px;
                        height: 80px; background-repeat: no-repeat;">
                        <asp:TextBox ID="TextBox1" runat="server" Width="97px"></asp:TextBox>&nbsp;
                        <asp:Button ID="Button_search" runat="server" Text="search" /></td>
                    <td style="background-image: url(../images/designViewPage_02.gif); width: 420px;
                        height: 80px">
                        </td>
                </tr>
                <tr>
                    <td style="width: 320px; height: 720px; background-image: url(../images/designViewPage_03.gif); background-repeat: no-repeat;" align="center" valign="top">
                        <br />
                        <table style="width: 284px; color: #ff9900">
                            <tr>
                                <td style="width: 100px; text-align: right">
                                    Wellcome :</td>
                                <td style="width: 100px">
                                    <asp:Label ID="Label_username" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 20px; text-align: right">
                                    &nbsp;Item in cart: :</td>
                                <td style="width: 100px; height: 20px">
                                    <asp:Label ID="Label_itemcart" runat="server"></asp:Label></td>
                            </tr>
                            <tr>
                                <td style="width: 100px">
                                </td>
                                <td style="width: 100px">
                                </td>
                            </tr>
                        </table>
                        <br />
                        <table style="width: 280px">
                            <tr>
                                <td style="width: 100px; background-color: #ffffcc">
                                    Promotion</td>
                                <td style="width: 100px; background-color: #ccffcc">
                                    ��������</td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 21px; text-align: left">
                                </td>
                                <td style="width: 100px; height: 21px">
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 21px">
                                </td>
                                <td style="width: 100px; height: 21px">
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 100px; height: 21px">
                                </td>
                                <td style="width: 100px; height: 21px">
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td style="width: 480px; height: 720px" align="left" valign="top">
                        <table style="width: 480px; height: 200px">
                            <tr>
                                <td style="background-image: url(../images/designViewPage_04.gif); width: 480px;
                                    background-repeat: no-repeat; height: 200px; text-align: center;">
                                    <table style="width: 438px; height: 169px">
                                        <tr>
                                            <td align="left" style="width: 100px; height: 13px">
                                                <strong>&nbsp;Music</strong></td>
                                            <td style="width: 100px; height: 13px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; height: 7px; text-align: left;">
                                                <asp:DropDownList ID="music_artist" runat="server" Width="114px">
                                                    <asp:ListItem>&lt;Select artist&gt;</asp:ListItem>
                                                    <asp:ListItem>bird</asp:ListItem>
                                                    <asp:ListItem>Loso</asp:ListItem>
                                                    <asp:ListItem>Bodyslam</asp:ListItem>
                                                </asp:DropDownList></td>
                                            <td align="left" rowspan="3" style="width: 100px" valign="top">
                                                NEW release!!!<br />
                                                <asp:ListBox ID="ListBox1" runat="server" Height="105px" Width="301px"></asp:ListBox></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; height: 20px; text-align: left;">
                                                <asp:DropDownList ID="Music_album" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select album&gt;</asp:ListItem>
                                                </asp:DropDownList></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; text-align: left;">
                                                <asp:DropDownList ID="Music_record" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select reccord&gt;</asp:ListItem>
                                                </asp:DropDownList>&nbsp;<asp:Button ID="Button_find" runat="server" Text="find"
                                                    Width="95px" /></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="background-image: url(../images/designViewPage_05.gif); width: 480px;
                                    background-repeat: no-repeat; height: 200px" align="center"><table style="width: 438px; height: 169px">
                                        <tr>
                                            <td align="left" style="width: 200px; height: 13px">
                                            </td>
                                            <td align="left" style="width: 100px; height: 13px; text-align: right;">
                                                <strong>Eletronic Book</strong></td>
                                        </tr>
                                        <tr>
                                            <td rowspan="3" style="width: 200px; text-align: left">
                                                New release!!<asp:ListBox ID="ListBox2" runat="server" Height="105px" Width="301px">
                                                </asp:ListBox></td>
                                            <td style="width: 100px; height: 7px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList1" runat="server" Width="114px">
                                                    <asp:ListItem>&lt;Select artist&gt;</asp:ListItem>
                                                    <asp:ListItem>bird</asp:ListItem>
                                                    <asp:ListItem>Loso</asp:ListItem>
                                                    <asp:ListItem>Bodyslam</asp:ListItem>
                                                </asp:DropDownList></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; height: 20px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList2" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select album&gt;</asp:ListItem>
                                                </asp:DropDownList></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList3" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select reccord&gt;</asp:ListItem>
                                                </asp:DropDownList>&nbsp;<asp:Button ID="Button1" runat="server" Text="find" Width="95px" /></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="background-image: url(../images/designViewPage_06.gif); width: 480px;
                                    background-repeat: no-repeat; height: 200px" align="center"><table style="width: 438px; height: 169px">
                                        <tr>
                                            <td align="left" style="width: 100px; height: 13px">
                                                <strong>&nbsp;Music video
                                                    <br />
                                                    &nbsp;&amp; Karaoke</strong></td>
                                            <td style="width: 100px; height: 13px">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; height: 7px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList4" runat="server" Width="114px">
                                                    <asp:ListItem>&lt;Select artist&gt;</asp:ListItem>
                                                    <asp:ListItem>bird</asp:ListItem>
                                                    <asp:ListItem>Loso</asp:ListItem>
                                                    <asp:ListItem>Bodyslam</asp:ListItem>
                                                </asp:DropDownList></td>
                                            <td align="left" rowspan="3" style="width: 100px" valign="top">
                                                NEW release!!!<br />
                                                <asp:ListBox ID="ListBox3" runat="server" Height="105px" Width="301px"></asp:ListBox></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; height: 20px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList5" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select album&gt;</asp:ListItem>
                                                </asp:DropDownList></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 100px; text-align: left;">
                                                <asp:DropDownList ID="DropDownList6" runat="server" Width="116px">
                                                    <asp:ListItem>&lt;Select reccord&gt;</asp:ListItem>
                                                </asp:DropDownList>&nbsp;<asp:Button ID="Button2" runat="server" Text="find" Width="95px" /></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    
    </div>
    </form>
</body>
</html>
