<%@ Page Language="C#" AutoEventWireup="true" CodeFile="testXML.aspx.cs" Inherits="viewPage_testXML" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        &nbsp;&nbsp;
        <asp:DetailsView ID="DetailsView1" runat="server" AutoGenerateRows="False" Height="50px"
            Width="125px">
        </asp:DetailsView>
    
    </div>
        &nbsp;
        <asp:XmlDataSource ID="XmlDataSource1" runat="server" DataFile="~/App_Data/XMLFile.xml">
        </asp:XmlDataSource>
    </form>
</body>
</html>
