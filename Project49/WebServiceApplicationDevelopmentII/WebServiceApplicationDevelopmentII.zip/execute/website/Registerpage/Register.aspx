<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Register.aspx.cs" Inherits="Register" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Register</title>
    <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#000066">
    <th colspan="3" scope="col"><span class="style1">header</span></th>
  </tr>
  <tr>
    <td width="50" bgcolor="#000066">&nbsp;</td>
    <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="25%" scope="col">&nbsp;</th>
        <th width="25%" scope="col">&nbsp;</th>
        <th width="50%" scope="col">&nbsp;</th>
      </tr>
      <tr>
        <td width="25%"><div align="right"></div></td>
        <td width="25%"><blockquote>Username</blockquote></td>
        <td width="50%">&nbsp;<asp:TextBox ID="username" runat="server" BackColor="#FFC0C0"></asp:TextBox>&nbsp;
            <asp:Button ID="Button1" runat="server" Text="Check " OnClick="Button1_Click" />&nbsp;<br />
            &nbsp;Please check username avaiable before register.&nbsp;</td>
      </tr>
      <tr>
        <td width="25%" style="height: 38px"><div align="right"></div></td>
        <td width="25%" style="height: 38px"><blockquote>
            Email dddress</blockquote></td>
        <td width="50%" style="height: 38px">&nbsp;<asp:TextBox ID="email" runat="server" BackColor="#FFC0C0" AutoPostBack="True" Enabled="False"></asp:TextBox></td>
      </tr>
      <tr>
        <td style="height: 19px">&nbsp;</td>
      <td width="25%" style="height: 19px">&nbsp;</td>
      <td width="50%" style="height: 19px">&nbsp;<asp:Button ID="Button2" runat="server" BorderStyle="Outset" Text="OK" Width="70px" /></td>
      </tr>
    </table></td>
    <td width="50" bgcolor="#000066">&nbsp;</td>
  </tr>
  <tr>
    <td width="50">&nbsp;</td>
    <td>&nbsp;</td>
    <td width="50">&nbsp;</td>
  </tr>
</table>
    
    </div>
    </form>
</body>
</html>
