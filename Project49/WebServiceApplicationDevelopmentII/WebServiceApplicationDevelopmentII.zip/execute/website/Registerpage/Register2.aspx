<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Register2.aspx.cs" Inherits="Register2" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
       <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#000066">
    <th colspan="3" scope="col"><span class="style1">header</span></th>
  </tr>
  <tr>
    <td width="50" bgcolor="#000066" style="height: 133px">&nbsp;</td>
    <td style="height: 133px"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <th width="25%" scope="col" style="height: 19px">&nbsp;</th>
        <th scope="col" style="height: 19px; width: 12%;">&nbsp;</th>
        <th width="50%" scope="col" style="height: 19px" align="left">&nbsp;</th>
      </tr>
      <tr>
        <td width="25%" style="height: 24px"><div align="right"></div></td>
        <td style="width: 12%; height: 24px">
            name</td>
        <td width="50%" style="height: 24px" align="left">
            <asp:TextBox ID="name" runat="server" AutoPostBack="True"></asp:TextBox>
            *</td>
      </tr>
      <tr>
        <td width="25%"><div align="right"></div></td>
        <td style="width: 12%">
            second name</td>
        <td width="50%" align="left">
            <asp:TextBox ID="secondName" runat="server"></asp:TextBox></td>
      </tr>
      <tr>
        <td style="height: 19px">&nbsp;</td>
      <td style="height: 19px; width: 12%;">
          address</td>
      <td width="50%" style="height: 19px" align="left">
          <asp:TextBox ID="address" runat="server"></asp:TextBox>
          *</td>
      </tr>
        <tr>
            <td style="height: 19px">
            </td>
            <td style="width: 12%; height: 19px">
                age</td>
            <td width="50%" style="height: 19px" align="left">
                <asp:TextBox ID="age" runat="server"></asp:TextBox>&nbsp;</td>
        </tr>
        <tr>
            <td style="height: 19px">
            </td>
            <td style="width: 12%; height: 19px">
                sex</td>
            <td width ="50%" style="height: 19px" align="left">
                <asp:RadioButton ID="female" runat="server" Text="Female" />
                <asp:RadioButton ID="Male" runat="server" Text="Male" /></td>
        </tr>
        <tr>
            <td style="height: 19px">
            </td>
            <td style="width: 12%; height: 19px">
            </td>
            <td align="left" style="height: 19px" width="50%">
            </td>
        </tr>
        <tr>
            <td style="height: 17px">
            </td>
            <td style="width: 12%; height: 17px">
                password</td>
            <td align="left" style="height: 17px" width="50%">
                <asp:TextBox ID="password" runat="server" TextMode="Password"></asp:TextBox>
                *</td>
        </tr>
        <tr>
            <td style="height: 19px">
            </td>
            <td style="width: 12%; height: 19px">
                retype password</td>
            <td align="left" style="height: 19px" width="50%">
                <asp:TextBox ID="rePassword" runat="server" TextMode="Password"></asp:TextBox>
                *<asp:Label ID="Label_Repass" runat="server"></asp:Label></td>
        </tr>
        <tr>
            <td style="height: 19px">
            </td>
            <td style="width: 12%; height: 19px">
            </td>
            <td align="left" style="height: 19px" width="50%">
                <br />
                <asp:Button ID="Button1" runat="server" Text="OK" Width="100px" OnClick="Button1_Click" /></td>
        </tr>
    </table></td>
    <td width="50" bgcolor="#000066" style="height: 133px">&nbsp;</td>
  </tr>
  <tr>
    <td width="50">&nbsp;</td>
    <td>&nbsp;</td>
    <td width="50">&nbsp;</td>
  </tr>
</table>
    
    </div>
    </form>
</body>
</html>
