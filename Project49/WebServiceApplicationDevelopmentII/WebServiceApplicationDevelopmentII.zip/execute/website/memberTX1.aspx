<%@ Page Language="C#" AutoEventWireup="true" CodeFile="memberTX1.aspx.cs" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
    <div>
        <table border="0" cellpadding="0" cellspacing="0" style="padding-right: 0px; padding-left: 0px;
            border-left-color: #ffffff; border-bottom-color: #ffffff; padding-bottom: 0px;
            margin: 0px; width: 800px; border-top-color: #ffffff; padding-top: 0px; border-collapse: separate;
            border-right-color: #ffffff" summary="This table use for Header">
            <tr>
                <td colspan="2" style="border-top-width: 1px; font-weight: bolder; border-left-width: 1px;
                    font-size: x-large; border-left-color: #00ccff; border-bottom-width: 1px; border-bottom-color: #00ccff;
                    color: white; border-top-color: #00ccff; height: 100px; background-color: white;
                    text-align: left; border-right-width: 1px; font-variant: small-caps; border-right-color: #00ccff"
                    valign="top">
                    <br />
                    <img src="images/OnlineContentServiceHead.jpg" /></td>
            </tr>
            <tr>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 200px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 11px; text-align: left; border-bottom-style: none"
                    valign="top">
                    <asp:Label ID="Label2" runat="server"></asp:Label></td>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 800px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 11px; text-align: right; border-bottom-style: none"
                    valign="top">
                    &nbsp;<asp:HyperLink ID="HyperLink4" runat="server" BackColor="White" Font-Bold="True"
                        NavigateUrl="~/home.aspx">home</asp:HyperLink>
                    &nbsp; &nbsp;<asp:HyperLink ID="HyperLink5" runat="server" NavigateUrl="~/viewCart.aspx"
                        Style="font-weight: bold; color: #3366ff">viewcart</asp:HyperLink>&nbsp; &nbsp;<asp:HyperLink
                            ID="HyperLink3" runat="server" EnableViewState="False" NavigateUrl="~/regist.aspx"
                            Style="font-weight: bold; color: #3366ff">register</asp:HyperLink>&nbsp;
                    <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/search.aspx" Style="font-weight: bold;
                        color: #3366cc">Search</asp:HyperLink>
                    &nbsp;<asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/browse.aspx" Style="font-weight: bold;
                        color: #3366ff">browse</asp:HyperLink>&nbsp;
                    <asp:HyperLink ID="HyperLink6" runat="server" NavigateUrl="~/txdetail.aspx" Style="font-weight: bold;
                        color: #3366cc">view transaction</asp:HyperLink>&nbsp;
                </td>
            </tr>
        </table>
        <asp:SqlDataSource ID="SqlDataSource1" runat="server" ConnectionString="<%$ ConnectionStrings:olala_agentConnectionString %>"
            SelectCommand="SELECT [mctxid], [mdate], [mtime], [totalamount], [paymentid] FROM [member_content_transaction] WHERE ([memberid] = @memberid2)">
            <SelectParameters>
                <asp:QueryStringParameter DefaultValue="0" Name="memberid2" QueryStringField="memberid"
                    Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
    
    </div>
        <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CellPadding="4"
            DataKeyNames="mctxid" DataSourceID="SqlDataSource1" 
            ForeColor="#333333" GridLines="None" OnSelectedIndexChanged="GridView1_SelectedIndexChanged" AllowPaging="True" AllowSorting="True">
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <Columns>
            
                <asp:TemplateField
                        HeaderText="TransactionID">
                        <ItemTemplate>
                        <asp:LinkButton ID="LinkButton1" Runat="Server"
                          Text='<%# Eval("mctxid") %>'
                          CommandName="Select"/>
                        </ItemTemplate>
                    <HeaderStyle Width="60px" />
                      </asp:TemplateField>
                      
                <asp:BoundField DataField="mctxid" HeaderText="TransactionID" InsertVisible="False" ReadOnly="True"
                    SortExpression="mctxid" Visible="False" />
                <asp:BoundField DataField="mdate" HeaderText="mdate" SortExpression="mdate" />
                <asp:BoundField DataField="mtime" HeaderText="mtime" SortExpression="mtime" />
                <asp:BoundField DataField="totalamount" HeaderText="totalamount" SortExpression="totalamount" />
                <asp:BoundField DataField="paymentid" HeaderText="paymentid" SortExpression="paymentid" />
            </Columns>
            <RowStyle BackColor="#EFF3FB" />
            <EditRowStyle BackColor="#2461BF" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp;
        
        
        <asp:SqlDataSource ID="SqlDataSource2" runat="server" ConnectionString="<%$ ConnectionStrings:olala_agentConnectionString %>"
            SelectCommand="SELECT [cctxid], [line_no], [providerid], [contentid], [contentlink], [contenthashcode], [providertxid] FROM [contentitem] WHERE ([cctxid] = @cctxid)">
            <SelectParameters>
                <asp:ControlParameter ControlID="GridView1" Name="cctxid" PropertyName="SelectedValue"
                    Type="Int32" />
            </SelectParameters>
        </asp:SqlDataSource>
        
        
        <asp:GridView ID="GridView2" runat="server" AllowSorting="True" AutoGenerateColumns="False"
            CellPadding="4" DataKeyNames="cctxid,line_no" DataSourceID="SqlDataSource2" ForeColor="#333333"
            GridLines="None">
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <Columns>
                <asp:BoundField DataField="cctxid" HeaderText="cctxid" ReadOnly="True" SortExpression="cctxid" />
                <asp:BoundField DataField="line_no" HeaderText="line_no" ReadOnly="True" SortExpression="line_no" />
                <asp:BoundField DataField="providerid" HeaderText="providerid" SortExpression="providerid" />
                <asp:BoundField DataField="contentid" HeaderText="contentid" SortExpression="contentid" />
                <asp:BoundField DataField="contentlink" HeaderText="contentlink" SortExpression="contentlink" />
                <asp:BoundField DataField="contenthashcode" HeaderText="contenthashcode" SortExpression="contenthashcode" />
                <asp:BoundField DataField="providertxid" HeaderText="providertxid" SortExpression="providertxid" />
                <asp:HyperLinkField 
                        DataTextField="providertxid" 
                        DataNavigateUrlFields="contentlink,providertxid"                         
                        DataNavigateUrlFormatString="~/txdetail.aspx?providertxid={1}"
                        HeaderText="Get Content"  />
                        <%--DataNavigateUrlFormatString="~/txdetail.aspx?txid={0}" />--%>
            </Columns>
            <RowStyle BackColor="#EFF3FB" />
            <EditRowStyle BackColor="#2461BF" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
        </asp:GridView>
        &nbsp;
    </form>
</body>
</html>
