<?xml version="1.0" encoding="utf-8"?>

<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">
    <html>
    <body>
      <table>
        <xsl:for-each select="/cart/content">
        <tr>
          <td style="width: 100px">
            <xsl:value-of select="@title"/>
          </td>
          <td style="width: 100px">
            <xsl:value-of select="./detail/artist"/>
            <xsl:value-of select="./detail/authur"/>
          </td>
          <td style="width: 100px">
            <xsl:value-of select="./type"/>
          </td>
          <td style="width: 100px">
           <xsl:value-of select="./d"/>
          </td>
          <td style="width: 100px">
            
          </td>
        </tr>
      </xsl:for-each>
      </table>
    </body>
    </html>
</xsl:template>

</xsl:stylesheet> 

