<?xml version="1.0" encoding="utf-8"?>

<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">
    <html>
    <body>
    <!--
        This is an XSLT template file. Fill in this area with the
        XSL elements which will transform your XML to XHTML.
    -->
      <xsl:for-each select="//data/content">
        <table style="width: 400px; border-collapse: separate; height: 100px; border-right: black 1px solid; table-layout: auto; border-top: black 1px solid; border-left: black 1px solid; border-bottom: black 1px solid; background-image: url(./images/bg.jpg);" border="2" cellpadding="1" cellspacing="2">
        <tr>
          <td rowspan="5" style="width: 100px; text-align: center;">
            <img height="100" width="100">
              <xsl:attribute name="src">
                <xsl:value-of select="./picture"/>
              </xsl:attribute>
            </img>
            <br />
          </td>
          <td style="width: 400px; height: 40px; background-color: #ffffff; border-right: #000000 2px solid; padding-right: 1px; border-top: #000000 2px solid; padding-left: 1px; font-weight: bolder; font-size: x-large; padding-bottom: 1px; margin: 1px; border-left: #000000 2px solid; color: white; padding-top: 1px; border-bottom: #000000 2px solid; text-align: center; font-variant: small-caps; background-image: url(./images/titleBG.jpg);">
            <xsl:value-of select="./@title"/>
          </td>
        </tr>
        <tr>
          <td style="width: 300px; height: 11px; background-color: #ffffff; border-right: #000000 2px solid; padding-right: 1px; border-top: #000000 2px solid; padding-left: 1px; padding-bottom: 1px; margin: 1px; border-left: #000000 2px solid; padding-top: 1px; border-bottom: #000000 2px solid; text-align: center;">
            <xsl:value-of select="./detail/artist"/>
            <xsl:value-of select="./detail/authur"/>
          </td>
        </tr>
        <tr>
          <td rowspan="2" style="width: 300px; height: 9px; border-right: #000000 2px solid; padding-right: 2px; border-top: #000000 2px solid; padding-left: 2px; padding-bottom: 2px; margin: 1px; border-left: #000000 2px solid; padding-top: 2px; border-bottom: #000000 2px solid; background-color: #ffffff; text-align: left;">detail:<br/>
            <xsl:value-of select="./detail/style"/>
            <br/>
            <xsl:value-of select="./detail/year"/>
            <br/>
            <xsl:value-of select="./detail/record"/>
            <xsl:value-of select="./detail/publishBy"/>
            <br/>
            <xsl:value-of select="./detail/album"/>
            <a target="_blank">
              <xsl:attribute name="href">addcart.aspx?contentId=<xsl:value-of select="@id"/>&amp;providerId=<xsl:value-of select="@providerId"/>
            </xsl:attribute>Add to cart</a>
          </td>
        </tr>
        <tr>
        </tr>
        <tr>
          <td rowspan="1" style="width: 300px; height: 9px; border-right: #000000 2px solid; padding-right: 2px; border-top: #000000 2px solid; padding-left: 2px; padding-bottom: 2px; margin: 1px; border-left: #000000 2px solid; padding-top: 2px; border-bottom: #000000 2px solid; background-color: navajowhite; text-align: center; background-image: url(images/bg.jpg); font-size: 20px; color: maroon;">
            <xsl:value-of select="./cost"/>
          </td>
        </tr>
      </table>
      </xsl:for-each>
    </body>
    </html>
</xsl:template>

</xsl:stylesheet> 

