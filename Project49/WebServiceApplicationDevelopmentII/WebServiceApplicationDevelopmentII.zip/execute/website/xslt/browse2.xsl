<?xml version="1.0" encoding="utf-8"?>

<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">
    <html>
    <body>
    <!--
        This is an XSLT template file. Fill in this area with the
        XSL elements which will transform your XML to XHTML.
    -->
      <table>
        <tr>
          <td style="width: 200px">
          </td>
        </tr>
        <xsl:for-each select="//data/value">
          <tr>
            <td style="width: 200px">
              <a>
                <xsl:attribute name="href">browse3.aspx?option=<xsl:value-of select="//data/option"/>&amp;key=<xsl:value-of select="."/>
                </xsl:attribute>
                <xsl:value-of select="."/>
              </a>
              
            </td>
          </tr>
        </xsl:for-each>
      </table>
    </body>
    </html>
</xsl:template>

</xsl:stylesheet> 

