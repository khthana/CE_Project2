using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class Registerpage_regist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button1.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        memberDB member = new memberDB();
        if (username.Text != "" && password.Text != "" && name.Text != "" && surname.Text != "" && email.Text != "" && address.Text != "")
        {
            member.registUser(username.Text, password.Text, name.Text, surname.Text, email.Text, address.Text);
            Server.Transfer("home.aspx");
        }
        else
        {
            Label2.Text = "Please try again!!!";
        }
    }
    protected void checkUsername_Click(object sender, EventArgs e)
    {
        memberDB member = new memberDB();
        if (member.checkUsername(username.Text))
        {
            Label1.Text = "OK";
            Button1.Visible = true;
        }
        else
        {
            Label1.Text = "not aviable";
        }
    }
}
