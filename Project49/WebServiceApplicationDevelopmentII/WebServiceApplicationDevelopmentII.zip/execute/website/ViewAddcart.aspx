<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ViewAddcart.aspx.cs" Inherits="ViewAddcart" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
    <div>
        <table border="0" cellpadding="0" cellspacing="0" style="padding-right: 0px; padding-left: 0px;
            border-left-color: #ffffff; border-bottom-color: #ffffff; padding-bottom: 0px;
            margin: 0px; width: 800px; border-top-color: #ffffff; padding-top: 0px; border-collapse: separate;
            border-right-color: #ffffff" summary="This table use for Header">
            <tr>
                <td colspan="2" style="border-top-width: 1px; font-weight: bolder; border-left-width: 1px;
                    font-size: x-large; border-left-color: #00ccff; border-bottom-width: 1px; border-bottom-color: #00ccff;
                    color: white; border-top-color: #00ccff; height: 100px; background-color: white;
                    text-align: left; border-right-width: 1px; font-variant: small-caps; border-right-color: #00ccff"
                    valign="top">
                    <br />
                    <img src="images/OnlineContentServiceHead.jpg" /></td>
            </tr>
            <tr>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 200px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 11px; text-align: left; border-bottom-style: none"
                    valign="top">
                    <asp:Label ID="Label2" runat="server"></asp:Label></td>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 800px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 11px; text-align: right; border-bottom-style: none"
                    valign="top">
                    &nbsp;<asp:HyperLink ID="HyperLink4" runat="server" BackColor="White" Font-Bold="True"
                        NavigateUrl="~/home.aspx">home</asp:HyperLink>
                    &nbsp; &nbsp;<asp:HyperLink ID="HyperLink5" runat="server" NavigateUrl="~/viewCart.aspx"
                        Style="font-weight: bold; color: #3366ff">viewcart</asp:HyperLink>&nbsp; &nbsp;<asp:HyperLink
                            ID="HyperLink3" runat="server" EnableViewState="False" NavigateUrl="~/regist.aspx"
                            Style="font-weight: bold; color: #3366ff">register</asp:HyperLink>&nbsp;
                    <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/search.aspx" Style="font-weight: bold;
                        color: #3366cc">Search</asp:HyperLink>
                    &nbsp;<asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/browse.aspx" Style="font-weight: bold;
                        color: #3366ff">browse</asp:HyperLink>&nbsp;
                    <asp:HyperLink ID="HyperLink6" runat="server" NavigateUrl="~/txdetail.aspx" Style="font-weight: bold;
                        color: #3366cc">view transaction</asp:HyperLink>&nbsp;
                </td>
            </tr>
        </table>
    
    </div>
        <asp:Label ID="Label1" runat="server"></asp:Label>
    </form>
</body>
</html>
