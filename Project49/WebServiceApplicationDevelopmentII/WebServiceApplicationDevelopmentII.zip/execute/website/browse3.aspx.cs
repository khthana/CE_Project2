using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

public partial class browse3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string specOption = Request.QueryString["option"];
        string specKey =Request.QueryString["key"];
        Label3.Text = specOption + " and " + specKey;

        InformationServiceClient px = new InformationServiceClient();
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(px.listAllContentsInSpecificOptionValue(specOption,specKey));
        browse3_.Document = doc;
        try
        {
            Label2.Text = "Wellcome " + Session["username"].ToString();
        }
        catch (Exception ex)
        {

            Label2.Text = "Please login";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        memberDB member = new memberDB();
        if (member.login(username.Text, password.Text))
        {
            Label1.Text = "login success";
            Session["username"] = username.Text;
            Label2.Text = "Wellcome " + Session["username"].ToString();
            Session["cart"] = "";
        }
        else
        {
            Label1.Text = "Please try again!!!";
            Session["isLogin"] = 0;
        }
    }
}
