using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Transactions;
//using PromomtionService;

public partial class viewCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IsLogin();
        //create CartItem
        CartItem cart = new CartItem(Session["cart"].ToString());
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(cart.getXMLString());
        viewCartXML.Document = doc; 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        using (AgentPaymentServiceClient px = new AgentPaymentServiceClient())
        {
            CartItem cart = new CartItem(Session["cart"].ToString());
            Order order = new Order(cart.getXMLString(), Session["username"].ToString(), TextBox1.Text, "100", TextBox2.Text);
            //Response.Write(Session["username"].ToString());
            //Response.Write(order.getXMLString());
            try
            {
                px.order(order.getXMLString());
                memberDB mem = new memberDB();
                string link = "membertx1.aspx?memberid=" + mem.getMemberID(Session["username"].ToString());
                Response.Redirect(link);
                /*using (MyServiceClient px = new MyServiceClient())
                {
                    using (TransactionScope txscope = new TransactionScope())
                    {
                        // pxPro = new Promotion.AgentPaymentServiceClient();
                        PromotionServiceClient pxPro = new PromotionServiceClient();
                        
                        //px(order.getXMLString());
                       
                        //string payID = px.doRequest("test2@test.com",TextBox2.Text,pxPro.compute(order.getXMLString()),"detailxxx","commentttt");
                        string payID = px.doRequest("test2@test.com",TextBox2.Text,"35","detailxxx","commentttt");
                        px.doPaid(payID);
                    }
                }*/

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                Label1.Text = "Sorry...\nThere are some problem.Please check your email and your password again";
                //throw;
            }
        }
    }
    protected void  TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    private void IsLogin()
    {
        try
        {
            Label2.Text = "Wellcome " + Session["username"].ToString();
        }
        catch (Exception ex)
        {

            //Label2.Text = "Please login";
            Response.Redirect("home.aspx");
        }
    }
}
