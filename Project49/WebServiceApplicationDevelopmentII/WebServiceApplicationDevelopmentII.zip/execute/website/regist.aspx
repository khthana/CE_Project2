<%@ Page Language="C#" AutoEventWireup="true" CodeFile="regist.aspx.cs" Inherits="Registerpage_regist" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body style="color: #3366ff">
    <form id="form1" runat="server">
    <div>
        <table border="0" cellpadding="0" cellspacing="0" style="padding-right: 0px; padding-left: 0px;
            border-left-color: #ffffff; border-bottom-color: #ffffff; padding-bottom: 0px;
            margin: 0px; width: 800px; border-top-color: #ffffff; padding-top: 0px; border-collapse: separate;
            border-right-color: #ffffff" summary="This table use for Header">
            <tr>
                <td colspan="2" style="border-top-width: 1px; font-weight: bolder; border-left-width: 1px;
                    font-size: x-large; border-left-color: #00ccff; border-bottom-width: 1px; border-bottom-color: #00ccff;
                    color: white; border-top-color: #00ccff; height: 100px; background-color: white;
                    text-align: left; border-right-width: 1px; font-variant: small-caps; border-right-color: #00ccff"
                    valign="top">
                    <br />
                    <img src="images/OnlineContentServiceHead.jpg" /></td>
            </tr>
            <tr>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 200px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: left; border-bottom-style: none"
                    valign="top">
                </td>
                <td style="padding-right: 2px; padding-left: 2px; padding-bottom: 0px; margin: 2px 2px 0px;
                    width: 800px; border-top-style: none; padding-top: 1px; border-right-style: none;
                    border-left-style: none; height: 10px; text-align: right; border-bottom-style: none"
                    valign="top">
                    &nbsp;<asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/browse.aspx">Browse</asp:HyperLink>&nbsp;
                    search&nbsp; register &nbsp;viewcart&nbsp;
                </td>
            </tr>
        </table>
        <table cellspacing="2" style="width: 800px; background-image: url(images/bg.jpg); background-repeat: no-repeat;">
            <tr>
                <td style="width: 100px; height: 26px">
                </td>
                <td style="width: 70px; height: 26px">
                </td>
                <td style="width: 63px; height: 26px">
                    <asp:Label ID="Label2" runat="server" Width="190px"></asp:Label></td>
                <td style="width: 100px; height: 26px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px">
                </td>
                <td style="width: 70px">
                    username:</td>
                <td style="width: 63px; height: 26px;">
                    <asp:TextBox ID="username" runat="server" ></asp:TextBox>&nbsp;
                    <asp:Button ID="checkUsername" runat="server" Text="Check" Width="104px" OnClick="checkUsername_Click" />
                    <asp:Label ID="Label1" runat="server" Width="225px"></asp:Label></td>
                <td style="width: 100px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 26px">
                </td>
                <td style="width: 70px; height: 26px; text-align: left">
                    passwod:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="password" runat="server"></asp:TextBox><span style="color: #ff6666">*</span></td>
                <td style="width: 100px; height: 26px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 26px">
                </td>
                <td style="width: 70px; height: 26px; text-align: left">
                    retype password:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="retypePassword" runat="server"></asp:TextBox><span style="color: #ff6666">*</span></td>
                <td style="width: 100px; height: 26px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 26px">
                </td>
                <td style="width: 70px; height: 26px; text-align: left">
                    email:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="email" runat="server"></asp:TextBox><span style="color: #ff6666">*</span></td>
                <td style="width: 100px; height: 26px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 21px">
                </td>
                <td style="width: 70px; height: 21px; text-align: left">
                    name:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="name" runat="server"></asp:TextBox><span style="color: #ff6666">*</span></td>
                <td style="width: 100px; height: 21px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 24px">
                </td>
                <td style="width: 70px; height: 24px; text-align: left">
                    surname:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="surname" runat="server"></asp:TextBox><span style="color: #ff6666">*</span></td>
                <td style="width: 100px; height: 24px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px; height: 26px">
                </td>
                <td style="width: 70px; height: 26px">
                    address:</td>
                <td style="width: 63px; height: 26px">
                    <asp:TextBox ID="address" runat="server" Height="130px" TextMode="MultiLine" Width="225px"></asp:TextBox></td>
                <td style="width: 100px; height: 26px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px">
                </td>
                <td style="width: 70px">
                </td>
                <td style="width: 63px; height: 26px;">
                    <asp:Button ID="Button1" runat="server" Text="register" Width="97px" OnClick="Button1_Click" /></td>
                <td style="width: 100px">
                </td>
            </tr>
            <tr>
                <td style="width: 100px">
                </td>
                <td style="width: 70px">
                </td>
                <td style="width: 63px; height: 26px;">
                </td>
                <td style="width: 100px">
                </td>
            </tr>
        </table>
    
    </div>
    </form>
</body>
</html>
