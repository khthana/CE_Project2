﻿<%@ Page Language="C#" AutoEventWireup="true"  CodeFile="Default.aspx.cs" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:HyperLink ID="HyperLink1" runat="server" NavigateUrl="~/Registerpage/Register.aspx">register page1</asp:HyperLink><br />
        <asp:HyperLink ID="HyperLink2" runat="server" NavigateUrl="~/Registerpage/Register2.aspx">register page2</asp:HyperLink>&nbsp;<br />
        <asp:HyperLink ID="HyperLink3" runat="server" NavigateUrl="~/viewPage/viewPage1.aspx">viewpage 1</asp:HyperLink></div>
    </form>
</body>
</html>
