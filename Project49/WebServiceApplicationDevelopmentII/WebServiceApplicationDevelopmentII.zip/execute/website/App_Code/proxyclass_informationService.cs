﻿[System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
[System.ServiceModel.ServiceContractAttribute(ConfigurationName = "IInformationService")]
public interface IInformationService
{

    [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IInformationService/searchBy", ReplyAction = "http://tempuri.org/IInformationService/searchByResponse")]
    string searchBy(string keys);

    [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IInformationService/listAllAviableOption", ReplyAction = "http://tempuri.org/IInformationService/listAllAviableOptionResponse")]
    string listAllAviableOption();

    [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IInformationService/listAllAviableValueInSpecificOption", ReplyAction = "http://tempuri.org/IInformationService/listAllAviableValueInSpecificOptionRespons" +
        "e")]
    string listAllAviableValueInSpecificOption(string specificOption);

    [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IInformationService/listAllContentsInSpecificOptionValue", ReplyAction = "http://tempuri.org/IInformationService/listAllContentsInSpecificOptionValueRespon" +
        "se")]
    string listAllContentsInSpecificOptionValue(string specificOption, string specificValue);

    [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IInformationService/getContentInformation", ReplyAction = "http://tempuri.org/IInformationService/getContentInformationResponse")]
    string getContentInformation(string contentId, string providerId);
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
public interface IInformationServiceChannel : IInformationService, System.ServiceModel.IClientChannel
{
}

[System.Diagnostics.DebuggerStepThroughAttribute()]
[System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "3.0.0.0")]
public partial class InformationServiceClient : System.ServiceModel.ClientBase<IInformationService>, IInformationService
{

    public InformationServiceClient()
    {
    }

    public InformationServiceClient(string endpointConfigurationName)
        :
            base(endpointConfigurationName)
    {
    }

    public InformationServiceClient(string endpointConfigurationName, string remoteAddress)
        :
            base(endpointConfigurationName, remoteAddress)
    {
    }

    public InformationServiceClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress)
        :
            base(endpointConfigurationName, remoteAddress)
    {
    }

    public InformationServiceClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress)
        :
            base(binding, remoteAddress)
    {
    }

    public string searchBy(string keys)
    {
        return base.Channel.searchBy(keys);
    }

    public string listAllAviableOption()
    {
        return base.Channel.listAllAviableOption();
    }

    public string listAllAviableValueInSpecificOption(string specificOption)
    {
        return base.Channel.listAllAviableValueInSpecificOption(specificOption);
    }

    public string listAllContentsInSpecificOptionValue(string specificOption, string specificValue)
    {
        return base.Channel.listAllContentsInSpecificOptionValue(specificOption, specificValue);
    }

    public string getContentInformation(string contentId, string providerId)
    {
        return base.Channel.getContentInformation(contentId, providerId);
    }
}