using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for memberDB
/// </summary>
public class memberDB
{
	public memberDB()
	{
    }

        private string connectionString()
        {
            return "Data Source=OPORINHO-CAA50C;Initial Catalog=olala_agent;User ID=sa;password=pakorn";
        }
		public bool login(string username,string password)
        {
            string query_string = "select count(*) from member where memberusername='" + username + "' "+" and memberpassword='"+password+"'";
            using (SqlConnection sCon = new SqlConnection())
            {
                sCon.ConnectionString = connectionString();
                sCon.Open();
                using (SqlCommand sCom = new SqlCommand())
                {
                    sCom.Connection = sCon;
                    sCom.CommandText = query_string;
                    string s = sCom.ExecuteScalar().ToString();
                    if (s == "0")
                        return false;
                    else
                        return true;
                }
            }
            return true;
        }
        public bool checkUsername(string username)
        {
            string query_string = "select count(*) from member where memberusername='"+username+"'";
            using (SqlConnection sCon = new SqlConnection())
            {
                sCon.ConnectionString = connectionString();
                sCon.Open();
                using (SqlCommand sCom = new SqlCommand())
                {
                    sCom.Connection = sCon;
                    sCom.CommandText = query_string;
                    string s = sCom.ExecuteScalar().ToString();
                    if (s == "0")
                        return true;
                    else
                        return false;

                }
            }
        }
        public void registUser(string username,string password,string name,string surname,string  email,string address)
        {
            string current_date = DateTime.Now.ToString("dd.MMM.yyyy");
            string query_string = "insert into member(membername,membersurname,memberaddress,memberusername,memberpassword,memberdateenter,memberemail,memberpoint) ";
            query_string = query_string + " values('"+name+"','"+surname+"','"+address+"','"+username+"','"+password+"','"+current_date+"','"+email+"','0')";
            using (SqlConnection sCon = new SqlConnection())
            {
                sCon.ConnectionString = connectionString();
                sCon.Open();
                using (SqlCommand sCom = new SqlCommand())
                {
                    sCom.Connection = sCon;
                    sCom.CommandText = query_string;
                    sCom.ExecuteNonQuery();
                }
            }

	    }
    public string getMemberID(string username)
    {
        string query_string = "select memberid from member where memberusername='" + username + "'";
        using (SqlConnection sCon = new SqlConnection())
        {
            sCon.ConnectionString = connectionString();
            sCon.Open();
            using (SqlCommand sCom = new SqlCommand())
            {
                sCom.Connection = sCon;
                sCom.CommandText = query_string;
                string s = sCom.ExecuteScalar().ToString();
                return s;
            }
        }
        
    }
}

