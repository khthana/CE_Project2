using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

/// <summary>
/// Summary description for CartItem
/// </summary>
public class CartItem
{
    private XmlDocument cart;
    private XmlDocument cartDetail;
    private string _cartItemString;
    /*private string[] contentId;
    private string[] providerId;
    private int count;
	public CartItem(string cartItemString)
	{
        cartItemString ="<cart>"+cartItemString+"</cart>";
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(cartItemString);
        XmlNodeList tmp = doc.GetElementsByTagName("item");
        count = tmp.Count;
        contentId = new string[count];
        providerId = new string[count];
        for(int i = 0;i<count;++i)
        {
            contentId[i] = tmp.Item(i).FirstChild.Value;
            providerId[i] = tmp.Item(i).LastChild.Value;
        }

	}
    public string getContentId(int index)
    {
        return contentId[index];
    }
    public string getProviderId(int index)
    {
        return providerId[index];
    }*/
    public CartItem(string cartItemString)
    {
        string xpathCart = "//cart/item";
        string xpathContentId = "//cart/item/contentId";
        string xpathProviderId = "//cart/item/providerId";
        cart = new XmlDocument();
        cartDetail = new XmlDocument();
        this._cartItemString = "<cart>" + cartItemString + "</cart>";
        string cartDetailString = "";
        cart.LoadXml(this._cartItemString);
        using (InformationServiceClient px = new InformationServiceClient())
        {
            XmlNodeList tmp =  cart.SelectNodes(xpathCart);
            XmlNodeList tmpContentId =  cart.SelectNodes(xpathContentId);
            XmlNodeList tmpProviderId =  cart.SelectNodes(xpathProviderId);
            for (int i = 0; i<tmp.Count; ++i)
            {
                cartDetailString += px.getContentInformation(tmpContentId.Item(i).FirstChild.Value,tmpProviderId.Item(i).FirstChild.Value);
            }
            cartDetailString = "<cart>" + cartDetailString + "</cart>";
        }
        cartDetail.LoadXml(cartDetailString);
    }
    public string getXMLString()
    {
        return cartDetail.OuterXml;
    }
    public static string cartItemString(string contentId, string providerId)
    {
        string s = "<item><contentId>"; 
        s+= contentId;
        s+= "</contentId><providerId>";
        s+=providerId;
        s+="</providerId></item>";
        return s;
    }
    public string getCartItemString()
    {
        return this._cartItemString;
    }
}
