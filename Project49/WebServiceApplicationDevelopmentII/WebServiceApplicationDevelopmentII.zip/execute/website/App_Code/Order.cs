using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    //private XmlDocument order;
    private string xmlString;
	public Order(string XMLCartString,string username,string paypalPassword,string point,string email)
	{
        using (InformationServiceClient px = new InformationServiceClient())
        {
        //order.LoadXml(XMLCartString);
            XMLCartString = XMLCartString.Replace("<?xml version=\"1.0\" encoding=\"utf-8\" ?>", "");
            XMLCartString = XMLCartString.Replace("<cart>", "");
            xmlString = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><cart><username>";
            xmlString += username+"</username><email>";
            xmlString += email+"</email><point>";
            xmlString += point+"</point><paypalPassword>";
            xmlString += paypalPassword + "</paypalPassword><paymentMethod>paypal</paymentMethod>";
            xmlString += XMLCartString;
        /*XmlNodeList tmpContent= order.GetElementsByTagName("content"); 
        for (int i = 0;i<tmpContent.Count;++i)
        {
            xmlString += tmpContent.Item(i).FirstChild.OuterXml;

        }
        xmlString += "</cart>";*/
        }
	}
    public string getXMLString()
    {
        return this.xmlString;
    }

}
