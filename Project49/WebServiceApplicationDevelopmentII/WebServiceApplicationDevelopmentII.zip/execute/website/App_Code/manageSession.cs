using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.SessionState;

/// <summary>
/// Summary description for manageSession
/// </summary>
public class manageSession
{
	public manageSession()
	{
	}
    public static bool isLogin()
    {
       
        return true;
    }
}
