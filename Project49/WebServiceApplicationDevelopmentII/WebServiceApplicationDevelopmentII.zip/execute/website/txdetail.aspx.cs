using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.Sql;
using System.Data.SqlClient;

public partial class txdetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string providerID = Request.QueryString[0];
        //Response.Write(providerID);
        string providerURL = "";
        string getLinkHash = "select contentlink,contenthashcode from contentitem where providertxid='"+providerID+"'";
        using (SqlConnection sqlcon = new SqlConnection())
        {
            sqlcon.ConnectionString = "Data Source=OPORINHO-CAA50C;Initial Catalog=olala_agent;User ID=sa;password=pakorn";
            sqlcon.Open();
            using (SqlCommand sqlcom = new SqlCommand())
            {
                sqlcom.Connection = sqlcon;
                sqlcom.CommandText = getLinkHash;
                using (SqlDataReader dataReader = sqlcom.ExecuteReader())
                {
                    dataReader.Read();
                    providerURL = dataReader.GetString(0) + "?code=" + dataReader.GetString(1)+"&txid="+providerID;
                    //providerURL.Replace(" ", "");
                }
            }
        }
        providerURL = providerURL.Replace(" ", "");
       //Response.Write(providerURL);
       Response.Redirect(providerURL);
    }
}
