using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session.Contents["username"].ToString() != null)
        //{
        //    string s = Session.Contents["username"].ToString(); ;
        //    Label1.Text = s;
        //}
        try
        {
            Label2.Text = "Wellcome "+Session["username"].ToString();
        }
        catch (Exception ex)
        {

            Label2.Text = "Please login";
        }
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        memberDB member = new memberDB();
        if (member.login(username.Text, password.Text))
        {
            Label1.Text = "login success";
            Session["username"] = username.Text;
            Label2.Text = "Wellcome " + Session["username"].ToString();
            Session["cart"] = "";
            HyperLink6.NavigateUrl = "memberTX1.aspx?memberid=" + member.getMemberID(username.Text);
            
        }
        else
        {
            Label1.Text = "Please try again!!!";
            Session["isLogin"] = 0;
        }
    }
}

