vti_encoding:SR|utf8-nl
vti_author:SR|OLALA39\\oporinho
vti_modifiedby:SR|OLALA39\\oporinho
vti_timelastmodified:TR|12 Feb 2007 07:24:03 -0000
vti_timecreated:TR|04 Feb 2007 18:18:51 -0000
vti_lineageid:SR|{1462AFFD-9B31-4818-B34B-50277CF8A455}
vti_extenderversion:SR|5.0.2.6790
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|10 Feb 2007 06:05:17 -0000
vti_cacheddtm:TX|12 Feb 2007 07:24:03 -0000
vti_filesize:IR|7937
