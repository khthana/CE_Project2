vti_encoding:SR|utf8-nl
vti_author:SR|OLALA39\\oporinho
vti_modifiedby:SR|OLALA39\\oporinho
vti_timelastmodified:TR|11 Feb 2007 23:02:08 -0000
vti_timecreated:TR|11 Feb 2007 23:00:38 -0000
vti_lineageid:SR|{26F7F620-A460-45F8-8D6B-42F6FB4D74AA}
vti_extenderversion:SR|5.0.2.6790
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|11 Feb 2007 23:00:38 -0000
vti_cacheddtm:TX|11 Feb 2007 23:00:38 -0000
vti_filesize:IR|2350
