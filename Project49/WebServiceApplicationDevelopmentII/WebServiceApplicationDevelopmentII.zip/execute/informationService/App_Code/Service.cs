using System;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Web.Management;
using System.Xml;
using System.IO;
using System.Collections.Generic;


// A WCF service consists of a contract (defined below as IMyService, DataContract1), 
// a class which implements that interface (see MyService), 
// and configuration entries that specify behaviors associated with 
// that implementation (see <system.serviceModel> in web.config)

[ServiceContract()]
public interface IInformationService
{
    [OperationContract]
    string searchBy(string keys);
    [OperationContract]
    string listAllAviableOption();
    [OperationContract]
    string listAllAviableValueInSpecificOption(string specificOption);
    [OperationContract]
    string listAllContentsInSpecificOptionValue(string specificOption, string specificValue);
    [OperationContract]
    string getContentInformation(string contentId, string providerId);
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
public class InformationService : IInformationService
{
    private DateTime lastestUpdateTime;
    private XmlDocument DataSource;
    private XmlDocument listOptions;
    //private string listOptions;
    public InformationService ()
	{
        lastestUpdateTime = DateTime.Now;
        listOptions = new XmlDocument();
        DataSource = new XmlDocument();
        IupdateContentInformationServiceClient px =new IupdateContentInformationServiceClient();
        DataSource.LoadXml(px.update().Trim());
        updateOptions();
        
	}
    private void updateOptions()
    {
        //StreamReader f = File.OpenText("c:\\agentConfig\\listOptions.xml");
        //String str = f.ReadToEnd();
        StreamReader f = File.OpenText("c:\\test\\agentConfig\\listOptions.xml");
        string ret = "";
        ret =  f.ReadToEnd();
        //FileStream f = new FileStream("c:\\test\\agentConfig\\listOptions.xml", FileMode.Open);
        listOptions.LoadXml(ret);
    }
    private void updateSource()
    {
        DateTime currentTime = DateTime.Now;
        TimeSpan differentTime = currentTime - lastestUpdateTime;
        //update data if a 
        if(differentTime.TotalMilliseconds > 24 )
        {
            IupdateContentInformationServiceClient px =new IupdateContentInformationServiceClient();
            DataSource.LoadXml(px.update());
            updateOptions();
        }
        //update options
    }


    #region IInformationService member
    public string searchBy(string keys)
    {
        //check for update------
        updateSource();
        return _searchBy(keys);
        //return DataSource.OuterXml;
    }
    public string listAllAviableOption()
    {
        string ret = "<?xml version=\"1.0\" encoding=\"utf-8\"?><data>";
        for (int i = 0; i < listOptions.GetElementsByTagName("option").Count; ++i)
        {
            ret = ret + "<option>"+listOptions.GetElementsByTagName("option").Item(i).Attributes["id"].Value+"</option>";
        }
        return ret + "</data>";
    }
    public string listAllAviableValueInSpecificOption(string specificOption)
    {
        string ret = "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><option>"+specificOption+"</option>";
        string selectNodeString = "//listOptions/option[@id='<!--replaceOptionHere-->']/xpath_noSpecific";
        selectNodeString = selectNodeString.Replace("<!--replaceOptionHere-->", specificOption);
        string specifyOptionString = listOptions.SelectSingleNode(selectNodeString).FirstChild.Value;
        XmlNodeList tmp = DataSource.SelectNodes(specifyOptionString);
        string value = "";
        List<string> tmpList = new List<string>();
      
        for (int i = 0; i < tmp.Count; ++i)
        {
            value = tmp.Item(i).FirstChild.Value;
            tmpList.Add(value);
        }
        tmpList = removeDuplicates(tmpList);
        tmpList.Sort();
        for (int i = 0; i < tmpList.Count; ++i)
        {
            ret = ret + "<value>" + tmpList[i] + "</value>";
        }
        return ret + "</data>";
        //return specifyOptionString;

    }
    public string listAllContentsInSpecificOptionValue(string specificOption, string specificValue)
    {
        string ret = "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><option>"+specificOption+"</option>";
        XmlNodeList tmp = listOptions.SelectNodes("//providers/provider/contents/content");
        
        string selectNodeString = "//listOptions/option[@id='<!--replaceOptionHere-->']/xpath_specific";
        selectNodeString = selectNodeString.Replace("<!--replaceOptionHere-->",specificOption);

        string specificOptionString = listOptions.SelectSingleNode(selectNodeString).FirstChild.Value;
        specificOptionString = specificOptionString.Replace("#option#",specificValue);
        XmlNodeList tmpList = DataSource.SelectNodes(specificOptionString);
        for(int i = 0;i<tmpList.Count;++i)
        {
            if (tmpList.Item(i).Name != "detail")
                ret = ret + tmpList.Item(i).OuterXml;
            else
                ret = ret + tmpList.Item(i).ParentNode.OuterXml;
        }
        return ret+"</data>";
        //return specificOptionString;


       
    }
    //
    public string getContentInformation(string contentId, string providerId)
    {
        string xpath = "//providers/provider[@id='";
        xpath+= providerId + "']/contents/content[@id='";
        xpath+= contentId + "']";
        return DataSource.SelectSingleNode(xpath).OuterXml;
        //return xpath;
    }
    #endregion
    private string _searchBy(string searchString)
    {
        searchString = searchString.ToLower();
        string ret = "<?xml version=\"1.0\" encoding=\"utf-8\"?><data>";
        bool checkMatch = false;
        bool loopBreak = false;
        int i = 0, j, k;
        XmlNodeList tmp = DataSource.SelectNodes("//providers/provider/contents/content");
        while (i < tmp.Count)
        {
            if (tmp.Item(i).Attributes["title"].Value.ToLower().IndexOf(searchString) >= 0)
            {
                checkMatch = true;
            }
            else
            {
                j = 0;
                while (!loopBreak && (j < tmp.Item(i).ChildNodes.Count))
                {
                    if (tmp.Item(i).ChildNodes.Item(j).Name == "detail")
                    {
                        k = 0;
                        while (!loopBreak && (k < tmp.Item(i).ChildNodes.Item(j).ChildNodes.Count))
                        {
                            if (tmp.Item(i).ChildNodes.Item(j).ChildNodes.Item(k).FirstChild.Value.ToLower().IndexOf(searchString) >= 0)
                            {
                                checkMatch = true;
                                loopBreak = true;
                            }
                            ++k;
                        }

                    }
                    ++j;
                }
            }
            //construct new XMLdoc
            if (checkMatch)
            {
                loopBreak = false;
                checkMatch = false;
                ret += tmp.Item(i).OuterXml;
            }
            ++i;
        }
        ret += "</data>";
        return ret;
    }

    static List<string> removeDuplicates(List<string> inputList)
    {
        Dictionary<string, int> uniqueStore = new Dictionary<string, int>();
        List<string> finalList = new List<string>();

        foreach (string currValue in inputList)
        {
            if (!uniqueStore.ContainsKey(currValue))
            {
                uniqueStore.Add(currValue, 0);
                finalList.Add(currValue);
            }
        }
        return finalList;
    }
}


