using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            /*using (agentPayment.AgentPaymentServiceClient px = new test.agentPayment.AgentPaymentServiceClient())
            {
                try
                {
                    StreamReader re = File.OpenText("G:\\WebServiceInProject\\AgentPaymentService\\test\\order.xml");
                    px.order(re.ReadToEnd());
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }*/

            using (payment.AgentPaymentServiceClient px = new test.payment.AgentPaymentServiceClient())
            {
                StreamReader re = File.OpenText("G:\\WebServiceInProject\\AgentPaymentService\\test\\order.xml");
                px.order(re.ReadToEnd());
            }
            /*using (informationService.InformationServiceClient px = new test.informationService.InformationServiceClient())
            {
                //Console.WriteLine(px.getContentInformation("5", "46010320"));
                Console.WriteLine(px.searchBy("oporinho"));
                Console.ReadLine();
            }*/
            Console.ReadLine();
        }
    }
}
