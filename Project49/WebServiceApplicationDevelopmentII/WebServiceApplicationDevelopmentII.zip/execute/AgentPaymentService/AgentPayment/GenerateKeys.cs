using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
namespace genkey
{
    [Serializable]
    class GenerateKeys
    {
        public GenerateKeys()
        {

        }
        public static string genkey(string init)
        {
            string password = DateTime.Now.ToLongTimeString() + init + DateTime.Now.Millisecond.ToString() ;
            
            System.Security.Cryptography.MD5CryptoServiceProvider x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(password);
            bs = x.ComputeHash(bs);
            System.Text.StringBuilder s = new System.Text.StringBuilder();
            foreach (byte b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            password = s.ToString();
            return password;
        }
    } 
}
   

