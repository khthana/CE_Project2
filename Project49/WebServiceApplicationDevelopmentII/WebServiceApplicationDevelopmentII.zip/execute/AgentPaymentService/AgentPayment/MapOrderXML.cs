using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

    [Serializable]
    class MapOrderXML
    {
        XmlDocument doc;
        
        private String xpathContentId;
        private String xpathProviderId;
        private String xpathUsername;
        private String xpathCost;
        private String xpathPoint;
        private String xpathEmail;
        private String xpathPaypalPassword;
        private String xpathPayMentMethod;

        public MapOrderXML(string XMLString)
        {
            doc = new XmlDocument();
            doc.LoadXml(XMLString);

            xpathContentId = "//cart/content/@id";
            xpathProviderId = "//cart/content/@providerId";
            xpathUsername = "//cart/username";
            xpathCost = "//cart/content/cost";
            xpathPoint = "//cart/point";
            xpathPaypalPassword = "//cart/paypalPassword";
            xpathPayMentMethod = "//cart/paymentMethod";
            xpathEmail = "//cart/email";
            
        }
        public List<string> getContentID()
        {
            List<string> tmp = new List<string>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathContentId);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(tmpContentId.Item(i).FirstChild.Value);
            }
            return tmp;
        }
        public List<string> getProviderId()
        {
            List<string> tmp = new List<string>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathProviderId);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(tmpContentId.Item(i).FirstChild.Value);
            }
            return tmp;
        }
        public List<double> getPrice()
        {
            List<double> tmp = new List<double>();
            XmlNodeList tmpContentId = doc.SelectNodes(xpathCost);
            for (int i = 0; i < tmpContentId.Count; ++i)
            {
                tmp.Add(Convert.ToDouble(tmpContentId.Item(i).FirstChild.Value));
            }
            return tmp;
        }
        public int itemCount()
        {
            return this.getContentID().Count;
        }
        public string getUsername()
        {
            return doc.SelectSingleNode(xpathUsername).FirstChild.Value;
        }
        public string getPaypalPassword()
        {
            return doc.SelectSingleNode(xpathPaypalPassword).FirstChild.Value;
        }
        public double getPoint()
        {
            //XmlNode tmp = doc.SelectSingleNode(xpathPoint);
            return Convert.ToDouble(doc.SelectSingleNode(xpathPoint).FirstChild.Value);
        }
        public string getEmail()
        {
            return doc.SelectSingleNode(xpathEmail).FirstChild.Value.ToString();
        }
        public string getPassword()
        {
            return doc.SelectSingleNode(xpathPaypalPassword).FirstChild.Value.ToString();
        }

    
    }

