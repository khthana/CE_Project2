using System;
using System.ServiceModel;
using System.Workflow.Runtime;
using System.Collections.Generic;
using System.Threading;
using System.Workflow.Runtime.Hosting;

namespace AgentPayment
{
	[ServiceContract()]
	public interface IAgentPaymentService
	{
		[OperationContract]
		void order(string XMLorder);
	}

	public class AgentPaymentService : IAgentPaymentService
	{
		public void order(string XMLorder)
		{
            try
            {
                using (WorkflowRuntime workflowRuntime = new WorkflowRuntime())
                {
                    String connectionString = "data source=oporinho-caa50c;initial catalog=wfDB;user id=sa;password=pakorn;";
                    //StreamReader re = File.OpenText("C:\\Documents and Settings\\por\\My Documents\\Visual Studio 2005\\Projects\\paymentService\\WorkflowPayment\\orderXML.xml");
                    Dictionary<string, Object> Dic = new Dictionary<string, object>();
                    Dic.Add("OrderXMLString", XMLorder);
                    AutoResetEvent waitHandle = new AutoResetEvent(false);

                    workflowRuntime.AddService(new SqlWorkflowPersistenceService(connectionString,
                       true,
                       TimeSpan.FromHours(1.0),
                       TimeSpan.FromSeconds(5.0)));

                    workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) {
                        waitHandle.Set(); 
                    };
                    workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                    {
                        //Console.WriteLine(e.Exception.Message);
                        throw e.Exception;
                        waitHandle.Set();
                    };
                    

                    WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(WorkflowPayment.PaymentAndOrderWorkflow), Dic);
                    instance.Start();

                    waitHandle.WaitOne();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

		}
	}
	
}

