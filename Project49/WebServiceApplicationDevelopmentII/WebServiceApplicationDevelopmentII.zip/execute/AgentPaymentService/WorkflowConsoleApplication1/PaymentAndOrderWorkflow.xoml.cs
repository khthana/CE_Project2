using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.ServiceModel;
using System.Collections.Generic;
using System.Xml;
using genkey;
using System.Transactions;
using System.Threading;
using WorkflowConsoleApplication1.promotion;


namespace WorkflowPayment
{
	public partial class PaymentAndOrderWorkflow : SequentialWorkflowActivity
    {
        #region property
        private List<string> keys;
        private MapOrderXML map;
        private string[] order;
        private double totalPrice;
        private double point;
        private string orderXMLString;
        private string paymentId;
        private string transactionId;
        public string OrderXMLString
        {
            get { return orderXMLString; }
            set { orderXMLString = value; }
        }
        

        private string username;
        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        private string contents;

        public string Contents
        {
            get { return contents; }
            set { contents = value; }
        }

        private string paymentMethod;

        public string PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }


        #endregion

        private void setting_ExecuteCode(object sender, EventArgs e)
        {
            map = new MapOrderXML(OrderXMLString);
        }

        private void computePriceAndPromotion_ExecuteCode(object sender, EventArgs e)
        {
            PaymentMethod = "paypal";
            //Console.WriteLine("promotion");
            using (PromotionServiceClient px = new PromotionServiceClient())
            {
                string s = px.compute(OrderXMLString);
                XmlDocument tmp = new XmlDocument();
                tmp.LoadXml(s);
                totalPrice = Convert.ToDouble(tmp.SelectSingleNode("//cart/totalCost").FirstChild.Value);
                point = Convert.ToDouble(tmp.SelectSingleNode("//cart/pointUpdate").FirstChild.Value);
            }
            //Console.WriteLine("promotion finish");
        }

        private void storeAgentDatabase_ExecuteCode(object sender, EventArgs e)
        {
            using (WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient px = new WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient())
            {
                //return txid
                //Console.WriteLine("store start");
                try
                {
                    string userID = px.getMEMBERID(map.getUsername());
                    transactionId = px.insertMEMBERTransaction(paymentId, userID, DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString(), Convert.ToString(totalPrice), "000", "7");
                    //Console.WriteLine(transactionId);
                    ////Console.WriteLine("store master finish");
                }
                catch (Exception ex)
                {

                    //Console.WriteLine(ex.Message);
                }
                //List<string> tmpContentId = map.getContentID();
                //List<string> tmpProviderId = map.getProviderId();
                //using (StoreTransactionInAgent.MyServiceClient px = new StoreTransactionInAgent.MyServiceClient())
                //try
                //{
                //for (int i = 0; i < map.itemCount(); ++i)
                //{
                //    px.insertCONTENTITEM(transactionId, "0", "1", "3", "asas", "dadssaadsas");
                //}
                //Console.WriteLine("store master finish");
            }
        }

        private void pay_ExecuteCode(object sender, EventArgs e)
        {
            //Console.WriteLine("payment");
            using (WorkflowConsoleApplication1.paypalService.MyServiceClient pClient = new WorkflowConsoleApplication1.paypalService.MyServiceClient())
            {
                try
                {
                    string Agent_mail = "test2@test.com";
                    string Agent_pwd = "password2";
                    string Cust_mail = "test1@test.com";
                    string Cust_pwd = "password1";
                    //System.//Console.WriteLine("start Calling...");
                    pClient.doValidate(Agent_mail, Agent_pwd);
                    pClient.doValidate(Cust_mail, Cust_pwd);

                    //System.//Console.WriteLine("Validate Complete ...");

                    paymentId = pClient.doRequest(Agent_mail, Cust_mail, totalPrice.ToString(), "tx Detail", "comment");
                    //System.//Console.WriteLine("doRequest Complete ...");

                    if (pClient.doPaid(paymentId))
                    {
                        //System.//Console.WriteLine("doPaid : paid Complete");
                    }
                    else
                    {
                        //System.//Console.WriteLine("doPaid : paid Processing Error");
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                    //System.//Console.WriteLine(e.ToString());
                }
                //Console.WriteLine("pay finish");
            }
        }

        private void genkey_ExecuteCode(object sender, EventArgs e)
        {
            keys = new List<string>();
            for (int i = 0; i < map.itemCount(); ++i)
            {
                keys.Add(GenerateKeys.genkey(i.ToString()));
                Thread.Sleep(15);
            }
            //Console.WriteLine("generate key finish");
        }

        private void storeContentIdAgentDB_ExecuteCode(object sender, EventArgs e)
        {
            List<string> tmpContentId = map.getContentID();
            List<string> tmpProviderId = map.getProviderId();
            //Console.WriteLine("txid = " + transactionId);
            using (WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient px = new WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient())
            {
                string tmpLink = "";
                //try
                //{
                //using (StoreAgentTX.MyServiceClient px = new WorkflowPayment.StoreAgentTX.MyServiceClient())
                using (TransactionScope tx = new TransactionScope())
                {
                    for (int i = 0; i < map.itemCount(); ++i)
                    {
                        if(tmpProviderId[i] == "46010396")
                        {
                            tmpLink = "http://161.246.6.129/providerA_download1/Default.aspx";
                        }else if(tmpProviderId[i] == "46010364")
                        {
                            tmpLink = "http://161.246.6.129/providerA_download1/Default.aspx";
                        }
                        else 
                        {
                            tmpLink = "http://161.246.6.129/providerA_download1/Default.aspx";
                        }
                        //Console.WriteLine(tmpProviderId[i]);
                        string n = px.getPROVIDERID(tmpProviderId[i]);
                        //px.insertCONTENTITEM(transactionId, i.ToString(),n, tmpContentId[i],, keys[i]);
                        // px.insertCONTENTITEM(transactionId,i.ToString(),"1",tmpContentId[i],"NA",keys[i]);
                        //px.insertCONTENTITEM(transactionId, i.ToString(),n, tmpContentId[i],tmpLink, keys[i]);
                        using (WorkflowConsoleApplication1.StoreAgentTX.MyServiceClient ptx = new WorkflowConsoleApplication1.StoreAgentTX.MyServiceClient())
                        {
                            ptx.insertCONTENTITEM(transactionId, i.ToString(), n, tmpContentId[i], tmpLink, keys[i], transactionId);
                        }
                        //tmpLink = "";
                    }
                    tx.Complete();
                }
            }
            //}
            //}
            //catch (Exception ex)
            //{

            //    //Console.WriteLine(ex.Message);
            //}
            //Console.WriteLine("store detail finish");
        }

        private void produceOrder_ExecuteCode(object sender, EventArgs e)
        {
            //order to provider
            //order[0] to 46010396
            //order[1] to 46010364
            //order[3] to 46010320 **** ���ա�Ը�˹��
           
            order = new string[10];
            
            List<string> tmp = new List<string>();
            tmp = map.getProviderId();
            for (int i = 0; i < map.itemCount();++i )
            {
                Console.Write(tmp[i]);
                //Console.WriteLine(i);
                if(tmp[i] == "46010396")       
                {
                    order[0] += "<content id=\"" + map.getContentID()[i] + "\">";
                    order[0] += "<key>" + keys[i] + "</key></content>";
                }else
                    if(tmp[i] == "46010364")
                    {
                            order[1] += "<content id=\"" + map.getContentID()[i] + "\">";
                            order[1] += "<key>" + keys[i] + "</key></content>";     
                     }
                    // case "46010320": { }
            }
            order[0] = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><order><transactionId>" + transactionId + "</transactionId>" + order[0] + "</order>";
            order[1] = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><order><transactionId>" + transactionId + "</transactionId>" + order[1] + "</order>";

            //Console.WriteLine(order[0]);
            //Console.WriteLine(order[1]);
   
        }

        private void invokeProvider46010396_ExecuteCode(object sender, EventArgs e)
        {
            using (WorkflowConsoleApplication1.providerA.OrderClient px = new WorkflowConsoleApplication1.providerA.OrderClient())
            {
                //Console.WriteLine("LLL");
                px.orderDownload(order[0]);
            }
        }

        private void invokeProvider46010364_ExecuteCode(object sender, EventArgs e)
        {
            using (WorkflowConsoleApplication1.providerB.OrderClient px = new WorkflowConsoleApplication1.providerB.OrderClient())
            {
                px.orderDownload(order[1]);
            }

        }

        private void invokeProvider46010320_ExecuteCode(object sender, EventArgs e)
        {
            using (WorkflowConsoleApplication1.providerCService.MyServiceClient px = new WorkflowConsoleApplication1.providerCService.MyServiceClient())
            {
               // px.AgentGetContent(transactionId,"804",
                List<string> tmp = new List<string>();
                tmp = map.getProviderId();
                using (TransactionScope scope = new TransactionScope())
                {
                    WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient st = new WorkflowConsoleApplication1.StoreTranSactionInAgentDB.MyServiceClient();
                    for (int i = 0; i < map.itemCount(); ++i)
                    {
                        Console.Write(tmp[i]);
                        //Console.WriteLine(i);
                        if (tmp[i] == "46010320")
                        {
                            //px.AgentGetContent(transactionId, "804", map.getContentID()[i],, keys[i]);
                            //Console.WriteLine("46010320 .......");
                            string providerTxId = px.AgentGetContent(transactionId, "804", map.getContentID()[i], "test", keys[i]);
                            st.updateProviderTxID(transactionId, i.ToString(), providerTxId);
                        }
                        // case "46010320": { }
                    } 
                    scope.Complete();
                }
            }
        }
    }
}
