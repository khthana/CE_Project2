#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.IO;

#endregion

namespace WorkflowConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            using(WorkflowRuntime workflowRuntime = new WorkflowRuntime())
            {
                String connectionString = "data source=oporinho-caa50c;initial catalog=wfDB;user id=sa;password=pakorn;";
                StreamReader re = File.OpenText("C:\\Documents and Settings\\por\\My Documents\\Visual Studio 2005\\Projects\\paymentService\\WorkflowPayment\\orderXML.xml");
                Dictionary<string, Object> Dic = new Dictionary<string, object>();
                Dic.Add("OrderXMLString",re.ReadToEnd());
                AutoResetEvent waitHandle = new AutoResetEvent(false);
                workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) {waitHandle.Set();};
                workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                {
                    Console.WriteLine(e.Exception.Message);
                    waitHandle.Set();
                };
                workflowRuntime.AddService(new SqlWorkflowPersistenceService(connectionString,
                       true,
                       TimeSpan.FromHours(1.0),
                       TimeSpan.FromSeconds(5.0)));
                WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(WorkflowPayment.PaymentAndOrderWorkflow),Dic);
                instance.Start();

                waitHandle.WaitOne();
            }
            Console.ReadLine();
        }
    }
}
