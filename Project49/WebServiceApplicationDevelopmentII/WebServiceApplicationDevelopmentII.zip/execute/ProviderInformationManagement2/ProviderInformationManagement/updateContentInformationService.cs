using System;
using System.ServiceModel;
using System.Workflow.Runtime;
using System.Threading;
using System.Workflow.Runtime.Hosting;

namespace ProviderManagementInformation
{

	// The following settings must be added to your configuration file in order for 
	// the new WCF service item added to your project to work correctly.

	// <system.serviceModel>
	//    <services>
	//      <!-- Before deployment, you should remove the returnFaults behavior configuration to avoid disclosing information in exception messages -->
	//      <service type="ProviderManagementInformation.updateContentInformationService" behaviorConfiguration="returnFaults">
	//        <endpoint contract="ProviderManagementInformation.IupdateContentInformationService" binding="wsHttpBinding"/>
	//      </service>
	//    </services>
	//    <behaviors>
        //      <serviceBehaviors>
        //        <behavior name="returnFaults" >
        //          <serviceDebug includeExceptionDetailInFaults="true" />
        //        </behavior>
        //       </serviceBehaviors>
	//    </behaviors>
	// </system.serviceModel>


	// A WCF service consists of a contract (defined below), 
	// a class which implements that interface, and configuration 
	// entries that specify behaviors and endpoints associated with 
	// that implementation (see <system.serviceModel> in your application
	// configuration file).

	[ServiceContract()]
	public interface IupdateContentInformationService
	{
		[OperationContract]
		string update();
	}

	public class updateContentInformationService : IupdateContentInformationService
	{
		public string update()
		{
            string content = "";
            String connectionString = "data source=oporinho-caa50c;initial catalog=wwf_sqlPersistanceService;user id=sa;password=pakorn;";

            using (WorkflowRuntime wr = new WorkflowRuntime())
            {
                AutoResetEvent waitHandle = new AutoResetEvent(false);
                wr.AddService(new SqlWorkflowPersistenceService(connectionString,
                   true,
                   TimeSpan.FromHours(1.0),
                   TimeSpan.FromSeconds(5.0)));

                wr.WorkflowCompleted +=
                   delegate(object sender, WorkflowCompletedEventArgs e)
                   {
                       content = (string)e.OutputParameters["Result"];
                       waitHandle.Set();
                   };


                WorkflowInstance wi = wr.CreateWorkflow(typeof(ProviderManagementInformation.manageProviderWorkFlow));
                wi.Start();
                

               waitHandle.WaitOne();
            }

            return content;

		}
	}

}

