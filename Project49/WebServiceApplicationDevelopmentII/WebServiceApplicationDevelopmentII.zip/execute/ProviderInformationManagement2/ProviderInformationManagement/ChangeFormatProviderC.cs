using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;


class ChangeFormatProviderC
{
    private string newFormat;
    public ChangeFormatProviderC(string XMLFromProviderC)
    {
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(XMLFromProviderC);
        string providerId = "";
        newFormat += "<contents>";
        foreach (XmlNode tmp in doc.FirstChild.ChildNodes)
        {
                //Console.WriteLine(tmp.Name);
                providerId = tmp.Attributes["id"].FirstChild.Value;
                
                foreach (XmlNode tmpC in tmp.ChildNodes)
                {
                    newFormat += "<content id=\"";
                    //Console.WriteLine(tmpC.Name);
                    newFormat += tmpC.FirstChild.ChildNodes.Item(0).OuterXml + "\"  providerId=\"" + providerId + "\" ";

                    newFormat += "title=\"" + tmpC.SelectSingleNode("./CONTENTNAME").FirstChild.OuterXml + "\"";
                    newFormat += " type=\"" + tmpC.SelectSingleNode("./CONTENTTYPE").FirstChild.OuterXml + "\">";
                    newFormat += "<description>" + tmpC.SelectSingleNode("./CONTENTDETAIL").FirstChild.OuterXml + "</description>";
                    newFormat += "<picture>" + tmpC.SelectSingleNode("./CONTENTPICTURE").FirstChild.OuterXml + "</picture>";
                    newFormat += "<cost>" + tmpC.SelectSingleNode("./CONTENTCOST").FirstChild.OuterXml + "</cost>";
                    newFormat += "<detail>";
                    newFormat += "<year>" + tmpC.SelectSingleNode("./CONTENTYEAR").FirstChild.OuterXml + "</year>";


                    if (tmpC.SelectSingleNode("./CONTENTTYPE").FirstChild.OuterXml == "mp3")
                    {
                        newFormat += "<album>" + tmpC.SelectSingleNode("./CONTENTALBUM").FirstChild.OuterXml + "</album>";
                        newFormat += "<artist>" + tmpC.SelectSingleNode("./CONTENTARTIST").FirstChild.OuterXml + "</artist>";
                        newFormat += "<record>" + tmpC.SelectSingleNode("./CONTENTRECORD").FirstChild.OuterXml + "</record>";
                        newFormat += "<style>" + tmpC.SelectSingleNode("./CONTENTSTYLE").FirstChild.OuterXml + "</style>";

                    }
                    else
                    {
                        newFormat += "<publishBy>" + tmpC.SelectSingleNode("./CONTENTPUBLISHBY").FirstChild.OuterXml + "</publishBy>";
                        // newFormat += "<style>" + tmpC.SelectSingleNode("./CONTENTSTYLE").FirstChild.OuterXml + "</style>";
                    }
                    newFormat += "</detail>";
                    newFormat += "</content>";
                    //Console.WriteLine(newFormat);
                   
                }
                
        }
        newFormat += "</contents>";
        newFormat = "<provider id=\"" + providerId + "\">" + newFormat + "</provider>";
    }
    public string getNewFormat()
    {
        return newFormat;
    }
}
