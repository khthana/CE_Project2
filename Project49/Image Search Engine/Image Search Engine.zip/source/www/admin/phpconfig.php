<?php
$ServerName="localhost";
$UserName="root";
$UserPassword="";
$DataBaseName="sample";
?>
