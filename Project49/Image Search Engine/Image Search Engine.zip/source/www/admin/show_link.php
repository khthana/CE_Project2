<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Show Link </TITLE>

<BODY>
<?php
	include("phpconfig.php");

	if(!$Show1){
		exit;
	}
	else{

		$conn=mysql_connect($ServerName,$UserName,$UserPassword);
		if(!$conn)
			die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö�Դ��͡Ѻ MySQL �� ::</FONT>");

		mysql_select_db($DataBaseName,$conn)
			or die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö���͡��ҹ�ҹ������ $DataBaseName �� ::</FONT>");

		if($Show=="0"){
			
			$sql = 'SELECT * '
			. ' FROM `table_link_web` ';
			$result=mysql_query($sql);
			
			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=4><FONT SIZE=5 COLOR=#3300FF>���ҧ�ԧ�����</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_Web</B>";
				echo "<td align=center><B>Url_Web</B> ";
				echo "<td align=center><B>Date_Web</B> ";
				echo "<td align=center><B>Id_Chis</B>";
				echo "<td align=center><B>Load_web</B>";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td>".$row[1]."</td>";
					echo "<td align=center>".$row[2]."</td>";
					echo "<td align=center>".$row[3]."</td>";
					echo "<td align=center>".$row[4]."</td>";
					echo "</tr>";
				}
			}
			else
				echo "<BR><BR><BR><FONT SIZE=3 COLOR=#FF0000><center>:: ������ԧ��㹵��ҧ�ԧ����� ::</center></FONT>";
		}
		else if($Show=="1"){

			$sql = 'SELECT * '
			. ' FROM `table_link_image` ';
			$result=mysql_query($sql);

			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=6><FONT SIZE=5 COLOR=#3300FF>���ҧ�ԧ���ٻ</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_Image</B>";
				echo "<td align=center><B>Url_Image</B> ";
				echo "<td align=center><B>Histogram</B> ";
				echo "<td align=center><B>File_Name</B>";
				echo "<td align=center><B>Date_Image</B>";
				echo "<td align=center><B>Id_Web_Chis</B>";
				echo "<td align=center><B>Load_image</B>";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td>".$row[1]."</td>";
					echo "<td align=center>".$row[2]."</td>";
					echo "<td align=center>".$row[3]."</td>";
					echo "<td align=center>".$row[4]."</td>";
					echo "<td align=center>".$row[5]."</td>";
					echo "<td align=center>".$row[6]."</td>";
					echo "</tr>";
				}
			}
			else
				echo "<BR><BR><BR><FONT SIZE=3 COLOR=#FF0000><center>:: ������ԧ��㹵��ҧ�ԧ���ٻ ::</center></FONT>";
		}
		else if($Show=="2"){

			$sql = 'SELECT * '
			. ' FROM `status_date` ';
			$result=mysql_query($sql);

			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=6><FONT SIZE=5 COLOR=#3300FF>���ҧ����</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_status</B>";
				echo "<td align=center><B>Day_start</B> ";
				echo "<td align=center><B>Month_start</B> ";
				echo "<td align=center><B>Year_start</B>";
				echo "<td align=center><B>Day_stop</B>";
				echo "<td align=center><B>Month_stop</B>";
				echo "<td align=center><B>Year_stop</B>";
				echo "<td align=center><B>Frequency_load</B>";
				echo "<td align=center><B>Status_load</B>";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td align=center>".$row[1]."</td>";
					echo "<td align=center>".$row[2]."</td>";
					echo "<td align=center>".$row[3]."</td>";
					echo "<td align=center>".$row[4]."</td>";
					echo "<td align=center>".$row[5]."</td>";
					echo "<td align=center>".$row[6]."</td>";
					echo "<td align=center>".$row[7]."</td>";
					echo "<td align=center>".$row[8]."</td>";
					echo "</tr>";
				}
			}
		}
		else if($Show=="3"){
				
			$sql = 'SELECT * '
			. ' FROM `status_thread` ';
			$result=mysql_query($sql);

			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=6><FONT SIZE=5 COLOR=#3300FF>���ҧ�ô</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_thread</B>";
				echo "<td align=center><B>Id_image_thread</B> ";
				echo "<td align=center><B>Status_thread</B> ";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td align=center>".$row[1]."</td>";
					echo "<td align=center>".$row[2]."</td>";
					echo "</tr>";
				}
			}
		}
	}
?>
</BODY>
</HTML>
