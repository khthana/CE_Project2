<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Login Check</TITLE>

</HEAD>

<BODY>
<BR><BR><BR>
<table align="center">
	<?php
		include("phpconfig.php");
		$check = 0;
	if($work){
		if(!$user||!$pass){
			if(!$user)
				echo "<FONT SIZE=3 COLOR=#FF0000>:: ��سһ�͹���� ::</FONT>";
			elseif(!$pass)
				echo "<FONT SIZE=3 COLOR=#FF0000>:: ��سһ�͹���ʼ�ҹ ::</FONT>";
			exit;
		}

		$conn=mysql_connect($ServerName,$UserName,$UserPassword);
		if(!$conn)
			die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö�Դ��͡Ѻ MySQL �� ::</FONT>");

		mysql_select_db($DataBaseName,$conn)
			or die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö���͡��ҹ�ҹ������ $DataBaseName �� ::</FONT>");
	
		$strSQL="SELECT * FROM login";
		$result=mysql_query($strSQL);

		while($row=mysql_fetch_row($result)){
			if($row[0] == $user && $row[1] == $pass){
				$check = 1;
			}
		}

		if($check==1){
			header( "Location: admin.php?check1=$work");
		}
		else{
			echo<<<HTML
<table width="100%" height="256" border="0" cellpadding="0" cellspacing="0">
<tr> 
<td bgcolor="#FFFFCC"><div align="center"><font color="#FF0000" size="5" face="Courier New, Courier, mono"><strong>USER 
OR PASSWORD INCORRECT</strong></font></div></td>
 </tr>
</table>
HTML;
			exit;
		}
	}
mysql_close($conn);
?>

</table>
</BODY>
</HTML>
