<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Admin Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body>
<table width="980" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="38" align="left" valign="top"><table width="100%" borderc="0" cellspacing="0" cellpadding="0" align="center">
        <tr align="center"> 
          <td width="21%" rowspan="5" background="shadow_hilight_left.gif" bgcolor="#FFFFFF"><div align="center"></td>
          <td width="63%" height="38" align="center" valign="top" bgcolor="#FFFFFF"><img src="underhead.jpg" width="615" height="38"></td>
          <td width="16%" rowspan="5" background="shadow_hilight.gif" bgcolor="#FFFFFF">&nbsp;</td>
        </tr>
        <tr> 
          <td height="41" bordercolor="#FFFFFF"><div align="center"><font color="#FF9900" size="6" face="Courier New, Courier, mono"><strong><font size="7">CE'KMITL</font></strong></font></div></td>
        </tr>
        <tr> 
          <td height="7"><div align="center"><strong><font color="#FF9933" size="6" face="Courier New, Courier, mono">Image 
              Search Engine</font></strong></div></td>
        </tr>
        <tr> 
          <td height="7"><div align="center"></div></td>
        </tr>
        <tr> 
          <td height="13" valign="top"><table width="100%" height="307" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td height="29"><img src="underhead1.jpg" width="615" height="20"> 
                  <div align="center"></div></td>
              </tr>
              <tr> 
                <td height="19" bgcolor="#FFFFCC"><div align="center"></div></td>
              </tr>
              <tr> 
                <td height="21" bgcolor="#FFFFCC"><div align="center"><font color="#FF0000" size="4" face="Courier New, Courier, mono"><b>Admin 
                    Configuration</b></font></div></td>
              </tr>
              <tr> 
                <td height="19" bgcolor="#FFFFCC"><div align="center" ><FONT SIZE="3" COLOR="#0033FF"></FONT></div></td>
              </tr>
			  <form method="post" action="check.php">
              <tr> 
                <td height="35" bgcolor="#FFFFCC"><div align="center"><font color="#FF0000" face="Courier New, Courier, mono"><strong>User</strong></font> 
                    <input type="text" name="user"  maxlength="10">
                  </div></td>
              </tr>
                <tr> 
                  <td height="35" bgcolor="#FFFFCC"> <div align="center"><font color="#FF0000" face="Courier New, Courier, mono"><strong>Pass</strong></font> 
                      <input type="Hidden" value="ok" name="work">
					  <input type="password" name="pass" maxlength="10">
                    </div></td>
                </tr>
                <tr> 
                  <td height="16" bgcolor="#FFFFCC"><div align="center"> 
                      <input type="submit"name="login"value="Login">
                    </div></td>
                </tr>
                <tr> 
                  <td height="16" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
                <tr> 
                  <td height="32" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
                <tr> 
                  <td height="32" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
                <tr> 
                  <td height="32" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
              <tr align="center"> 
                <td height="21"><img src="menu_top.jpg" width="615" height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td height="100" colspan="3">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
</table>
</form>
</body>
</html>
