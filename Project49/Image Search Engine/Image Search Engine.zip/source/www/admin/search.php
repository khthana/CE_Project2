<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> Search Link </TITLE>
</HEAD>

<BODY>

<?php
	
	include("phpconfig.php");

	if(!$search2){
		exit;
	}
	else{

		$conn=mysql_connect($ServerName,$UserName,$UserPassword);
		if(!$conn)
			die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö�Դ��͡Ѻ MySQL �� ::</FONT>");

		mysql_select_db($DataBaseName,$conn)
			or die("<FONT SIZE=3 COLOR=#FF0000>:: �������ö���͡��ҹ�ҹ������ $DataBaseName �� ::</FONT>");

		if($search=="0"){
			
			$sql = 'SELECT * '
			. ' FROM `table_link_web` '
			. ' WHERE 1 AND `Url_Web` '
			. ' LIKE \''.$search1.'\'';
			$result=mysql_query($sql);
			
			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=4><FONT SIZE=5 COLOR=#3300FF>���ҧ�ԧ�����</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_Web</B>";
				echo "<td align=center><B>Url_Web</B> ";
				echo "<td align=center><B>Date_Web</B> ";
				echo "<td align=center><B>Id_Chis</B>";
				echo "<td align=center><B>Load_web</B>";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td>".$row[1]."</td>";
					echo "<td align=center>".$row[2]."</td>";
					echo "<td align=center>".$row[3]."</td>";
					echo "<td align=center>".$row[4]."</td>";
					echo "</tr>";
				}
				echo "</table>";
			}
			else
				echo "<BR><BR><BR><FONT SIZE=3 COLOR=#FF0000><center>:: ������ԧ�����ͧ��ä���㹵��ҧ�ԧ����� ::</center></FONT>";
		}
		else{
			$sql = 'SELECT * '
			. ' FROM `table_link_image` '
			. ' WHERE 1 AND `Url_Image` '
			. ' LIKE \''.$search1.'\'';
			$result=mysql_query($sql);
			if(mysql_num_rows($result)!=0){
				echo "<BR>";
				echo "<table align=center width=950>";
				echo "<tr><td align=center colspan=6><FONT SIZE=5 COLOR=#3300FF>���ҧ�ԧ���ٻ</FONT><BR><BR></td></tr>";
				echo "<tr bgcolor=AA99DD>";
				echo "<td align=center><B>Id_Image</B>";
				echo "<td align=center><B>Url_Image</B> ";
				echo "<td align=center><B>Histogram</B> ";
				echo "<td align=center><B>File_Name</B>";
				echo "<td align=center><B>Date_Image</B>";
				echo "<td align=center><B>Id_Web_Chis</B>";
				echo "<td align=center><B>Load_image</B>";
				echo "</tr>";

				while($row=mysql_fetch_row($result)){
					echo "<tr bgcolor=EEEEEE>";
					echo "<td align=center>".$row[0]."</td>";
					echo "<td height=100>".$row[1]."</td>";
					echo "<td align=center >".$row[2]."</td>";
					echo "<td align=center>".$row[3]."</td>";
					echo "<td align=center>".$row[4]."</td>";
					echo "<td align=center>".$row[5]."</td>";
					echo "<td align=center>".$row[6]."</td>";
					echo "</tr>";
				}
				echo "</table>";
			}
			else
				echo "<BR><BR><BR><FONT SIZE=3 COLOR=#FF0000><center>:: ������ԧ�����ͧ��ä�����㹵��ҧ�ԧ���ٻ ::</center></FONT>";
		}
	}
?>

</BODY>
</HTML>
