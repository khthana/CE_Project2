#! C:\Python24\python.exe
# import MySQL module
print 'Content-type: text/html\n'

from urlparse import urlsplit, urljoin
from datetime import date
from httplib import HTTPConnection
from httplib import InvalidURL
from httplib import BadStatusLine
from urllib import urlretrieve
from urllib2 import URLError
from urllib2 import HTTPError
from errno import ECONNRESET
from sys import exitfunc
from time import sleep
from string import replace
import re
import string
import MySQLdb
import socket
import atexit
import cStringIO
import httplib
import codecs
import MySQLdb
import cgi, re
import cgi
import cgitb; cgitb.enable()
import os, sys
import Image
import cStringIO 
import urllib
import urllib2


def process_histo(filename,dif_mode):
    
    img = Image.open("C:/webs/up_file/"+filename)
    img.putdata(range(256))                         
    a = list(img.convert("RGB").getdata())

    histogram =list()
    histogram_db = list()
    id_buf = list()

    coutn_id=0
    num=0
    num1=0
    count=1
    
        
    k=1
    while k<=216:
        histogram.append(0)
        #histogram_db.append(0)
        k=k+1
            
    for i in a:
        red=i[0]/43##red
        green=i[1]/43##green
        blue=i[2]/43##blue

        histogram[(red*36)+(green*6)+blue] = histogram[(red*36)+(green*6)+blue]+1

    l=0
    while l<=215:
        histogram[l]=(histogram[l]*100)/len(a)
        l=l+1
    #print histogram
    # connect
    db = MySQLdb.connect(host="localhost", user="root", passwd="",db="sample")
    cursor = db.cursor()
    cursor.execute("SELECT Histogram FROM table_link_image")
    result = cursor.fetchall()
        
    for row1 in result:
        for row2 in row1:
            coutn_id = coutn_id + 1
            if row2[0] != '0':
                count=1
                while(row2[count] != ']'):
                    num = int(row2[count])
                    count=count+1
                    while(row2[count] != ',' and row2[count] != ']'):
                        buf = int(row2[count])
                        num = num*10
                        num = num+buf
                        count=count+1
                    if row2[count] != ']':
                        count=count+2
                        histogram_db.append(num)
                    else:
                        histogram_db.append(num)

                        count_chack = 0
                        count_histo=0
                        
                        dif1=0
                        dif2=0
                        if (dif_mode == "1"):
                            dif1=3
                            dif2=-3
                        if (dif_mode == "2"):
                            dif1=5
                            dif2=-5
                            
                        while(count_histo <= 215):
                            chack = histogram_db[count_histo]-histogram[count_histo]
                            
                            if chack < dif2 or chack > dif1:
                                count_chack = 1
                            count_histo = count_histo + 1
                        
                        if count_chack == 0:
                            id_buf.append(coutn_id)
                            
                        histogram_db=list()
    return id_buf
    cursor.close()
    db.close()
    
def page_show(filename,list_id):

    db = MySQLdb.connect(host="localhost", user="root", passwd="",db="sample")
    cursor = db.cursor()
    
    print
    print """<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
    <HTML>
    <HEAD>
    <TITLE>�š�ä����ٻ</TITLE>
    </HEAD>
    <BODY bgcolor="#FF9A35">
    <table align="center" border="1" width="900">
    <tr>
        <th colspan="2">�ٻ����ͧ��ä���</th>
    </tr>
    <tr>
        <th colspan="2"><img src="C:/webs/up_file/%s" width="100"/></th>
    </tr>
    <tr>
        <th>�ٻ�����</th>
        <th>�ԧ������</th>
    <tr>
    """%(
        filename
        )
    
    for row in list_id:
        cursor.execute("SELECT * FROM table_link_image WHERE Id_Image = %s",row)
        result = cursor.fetchall()
        for row1 in result:
            print """
    <tr>
        <th><img src="C:/image/%s" width="100"/></th>
        <th>%s</th>
    <tr>
        """%(
            row1[3],
            row1[1]
            )
    print """
    </table>
    </BODY>
    </HTML>"""
    cursor.close()
    db.close()


#----------Main-------------#

form=cgi.FieldStorage()
if form.has_key("filename"):
    filename=form["filename"].value
if form.has_key("dif_mode"):
    dif_mode=form["dif_mode"].value


list_id=list()

try:        
    list_id = process_histo(filename,dif_mode)
    page_show(filename,list_id)
    
except(IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine):
    print 'error file'

