<html>
<head>
<title>Welcome to CE Image Search Engine</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis620">
</head>

<body>
<table width="980" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="38" align="left" valign="top"><table width="100%" borderc="0" cellspacing="0" cellpadding="0" align="center">
        <tr align="center"> 
          <td width="21%" rowspan="5" background="shadow_hilight_left.gif" bgcolor="#FFFFFF"><div align="center"></td>
          <td width="63%" height="38" align="center" valign="top" bgcolor="#FFFFFF"><img src="underhead.jpg" width="615" height="38"></td>
          <td width="16%" rowspan="5" background="shadow_hilight.gif" bgcolor="#FFFFFF">&nbsp;</td>
        </tr>
        <tr> 
          <td height="41" bordercolor="#FFFFFF"><div align="center"><font color="#FF9900" size="6" face="Courier New, Courier, mono"><strong><font size="7">CE'KMITL</font></strong></font></div></td>
        </tr>
        <tr> 
          <td height="7"><div align="center"><strong><font color="#FF9933" size="6" face="Courier New, Courier, mono">Image 
              Search Engine</font></strong></div></td>
        </tr>
        <tr> 
          <td height="7"><div align="center"></div></td>
        </tr>
        <tr> 
          <td height="13" valign="top"><table width="100%" height="327" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td height="30"><img src="underhead1.jpg" width="615" height="20"> 
                  <div align="center"></div></td>
              </tr>
              <tr> 
                <td height="19" bgcolor="#FFFFCC"><div align="center"></div></td>
              </tr>
              <tr> 
                <td height="35" bgcolor="#FFFFCC"><div align="center" ><strong><font color="#FF6600" size="3">���͡�ѡɳТͧ�ٻ</font></strong></div></td>
              </tr>
              <tr> 
                <td height="19" bgcolor="#FFFFCC">&nbsp;</td>
              </tr>
              <form name="form1" enctype="multipart/form-data" method="post" action="result.php">
                <tr> 
                  <td height="27" bgcolor="#FFFFCC"> <div align="center"> 
                      <input type="radio" name="select" value="0" checked>
                      <FONT SIZE="3" COLOR="#FF6600">����͹<B> </B></FONT> 
                      <input type="radio" name="select" value="1">
                      <FONT SIZE="3" COLOR="#FF6600">����� </FONT> 
                      <input type="radio" name="select" value="2">
                      <FONT SIZE="3" COLOR="#FF6600">�����§</FONT> </div></td>
                </tr>
                <tr> 
                  <td height="19" bgcolor="#FFFFCC">&nbsp;</td>
                </tr>
                <tr> 
                  <td height="55" bgcolor="#FFFFCC"><div align="center"><font size="3" color="#FF6600"><b>��س����͡�ٻ����ͧ��ä���</b></font> 
                      <input type="file" name="uploadfile">
                      <input type="Hidden" value="up" name="work">
                    </div></td>
                </tr>
                <tr> 
                  <td height="24" bgcolor="#FFFFCC"><div align="center"> 
                      <input type="submit" name="search" value="Search">
                    </div></td>
                </tr>
              </form>
              <tr> 
                <td height="19" bgcolor="#FFFFCC">&nbsp;</td>
              </tr>
              <tr> 
                <td height="10" bgcolor="#FFFFCC">&nbsp;</td>
              </tr>
              <tr> 
                <td height="10" bgcolor="#FFFFCC"><div align="center"><font color="#FF0000" size="4" face="Courier New, Courier, mono"></font></div></td>
              </tr>
              <tr> 
                <td height="5" bgcolor="#FFFFCC">&nbsp;</td>
              </tr>
              <tr>
                <td height="5" bgcolor="#FFFFCC">&nbsp;</td>
              </tr>
              <tr> 
                <td height="10" bgcolor="#FFFFCC"><div align="center"><font color="#FF0000" size="4" face="Courier New, Courier, mono"><b><a href="admin/login.php">Admin 
                    Configuration</a></b></font></div></td>
              </tr>
              <tr> 
                <td height="20"><img src="menu_top.jpg" width="615" height="20"></td>
              </tr>
            </table>
            
          </td>
        </tr>
        <tr> 
          <td height="100" colspan="3">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
