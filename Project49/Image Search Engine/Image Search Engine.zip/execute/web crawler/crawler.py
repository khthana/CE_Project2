#! C:\Python24\python.exe
# import MySQL module
print 'Content-type: text/html\n'

from time import time, localtime, strftime
from urlparse import urlsplit, urljoin
from datetime import date
from httplib import HTTPConnection
from httplib import InvalidURL
from httplib import BadStatusLine
from urllib import urlretrieve
from urllib2 import URLError
from urllib2 import HTTPError
from errno import ECONNRESET
from sys import exitfunc
from time import sleep
from string import replace
from datetime import date
import datetime
import re
import string
import MySQLdb
import socket
import atexit
import cStringIO
import httplib
import codecs
import MySQLdb
import cgi, re
import cgi
import cgitb; cgitb.enable()
import os, sys
import Image
import cStringIO 
import urllib
import urllib2
import threading
import random
import time

class LoadThread( threading.Thread ):
    """Subclass of threading.Thread"""

    def __init__( self, threadName, sharedObject, amount):

        threading.Thread.__init__( self, name = threadName )
        self.web = sharedObject
        self.amount = amount

    def run( self ):
        try:
            #-set timeout-#
            timeout = 15
            defTimeOut=socket.getdefaulttimeout()
            socket.setdefaulttimeout(timeout)
            found=1
            
            urllib.urlretrieve( self.web, "c:/image/"+self.getName())
            #print self.getName(),"Ok finis"
            try:
                cursor.executemany("UPDATE table_link_image SET File_Name = %s WHERE Url_Image = %s", [(self.getName(),self.web)])
                #cursor.executemany("UPDATE status_thread SET Status_thread = 'Unload' WHERE Id_thread = %s", [(self.amount)])
                db.commit()
                histogram(self.getName())
                                                
            except(StandardError):
                print "Standard Error"
            
        
        except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
            socket.setdefaulttimeout(defTimeOut)
            print ": Web ",self.getName()," ERROR :"

        try:
            cursor.executemany("UPDATE status_thread SET Status_thread = 'Unload' WHERE Id_thread = %s", [(self.amount)])
            db.commit()
        except(StandardError):
            print "Standard Error"

def histogram(file_name):
    try:
        #-set timeout-#
        timeout = 5
        defTimeOut=socket.getdefaulttimeout()
        socket.setdefaulttimeout(timeout)

        filepart = "c:/image/"+str(file_name)
        img = Image.open(filepart)
        img.putdata(range(256))                         
        a = list(img.convert("RGB").getdata())

        histogram =list()
    
        k=1
        while k<=216:
            histogram.append(0)
            k=k+1
	
        for i in a:
            red=i[0]/43##red
            green=i[1]/43##green
            blue=i[2]/43##blue

            histogram[(red*36)+(green*6)+blue] = histogram[(red*36)+(green*6)+blue]+1

        l=0
        while l<=215:
            histogram[l]=(histogram[l]*100)/len(a)
            l=l+1

    except (IOError , TypeError , ValueError,RuntimeError):
        print 'his finished'
        pass

        
    try:
        cursor.execute ("UPDATE table_link_image SET Histogram = '%s' WHERE File_Name = '%s' "
                        %(histogram,file_name))
        
    except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
        found=0
        socket.setdefaulttimeout(defTimeOut)
        print 'his db duplicate'

def check_loadimage(url_image):
    if url_image:
        try:
            cursor.execute("SELECT MIN(Id_thread) FROM  status_thread WHERE Status_thread = 'Unload'")
            result = cursor.fetchall()
            for row in result :{}
            if row :
                if row[0]==1:
                    try:
                        cursor.execute ("UPDATE status_thread SET Id_image_thread = %s, Status_thread = 'load' WHERE Id_thread = 1 "%(url_image[0]))
                    except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                        print 'Error Udate'
                    try:                
                        cursor.execute ("UPDATE table_link_image SET Load_image = 'load' WHERE Id_Image = %s "%(url_image[0]))
                    except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                        print 'Error Udate'
                        
                    thread1 = LoadThread( "thread1_"+str(url_image[0])+".jpg", url_image[1], row[0])
                    thread1.start()
                    
         
                   
        except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
            print ''

def Update_control(num,status):
    Year = (int(num[0])*1000)+(int(num[1])*100)+(int(num[2])*10)+int(num[3])
    Month = (int(num[5])*10)+int(num[6])
    Day = (int(num[8])*10)+int(num[9])
    if status=="start":
        try:
            cursor.execute ("UPDATE status_date SET Day_start = %s, Month_start = %s, Year_start = %s WHERE Id_status = 1 "
                            %(Day,Month,Year))
        except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                   print 'Error'
    if status=="stop":
        try:
            cursor.execute ("UPDATE status_date SET Day_stop = %s, Month_stop = %s, Year_stop = %s WHERE Id_status = 1 "
                            %(Day,Month,Year))
        except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                   print 'Error'

def check_date():
    cursor.execute("SELECT * FROM status_date")
    result = cursor.fetchall()
    for row in result :{}
    
    if ((date.today()-datetime.date(row[3],row[2],row[1])>=datetime.timedelta(0)) and (date.today()-datetime.date(row[6],row[5],row[4]))<=datetime.timedelta(0)):
        return True
    else:
        if ((date.today()-datetime.date(row[6],row[5],row[4]))>datetime.timedelta(0)):
            start = datetime.date(row[6],row[5],row[4])+datetime.timedelta(row[7]+1)
            space = datetime.date(row[6],row[5],row[4])-datetime.date(row[3],row[2],row[1])
            stop = start+space
            Update_control(start.isoformat(),"start")
            Update_control(stop.isoformat(),"stop")
        return False

def check_start():
    cursor.execute("SELECT Status_load FROM status_date")
    result = cursor.fetchall()
    for row in result :{}
    if row[0] == "start":
        return True
    else:
        return False

#def cut_string(sub_web):
#    buf_count = sub_web.count("/")
#    count = 0
#    count1=0
#    string = ''
#    while(count<=buf_count-2):
#	string = str(a+text[count1])
#	count1=count1+1
#	if text[count1]=='/':
#		count=count+1
#    return string

#----------Main-------------#

try:
    db = MySQLdb.connect(host="localhost", user="root", passwd="",db="sample")
    cursor = db.cursor()
    
    LinkToHref1 = re.compile("""href=('|")[../]*[\S+]*[/\[a-zA-Z0-9-_]+]*(.php|.com|.shtml|.html|.htm|.cgi|.th|.xhtml)*[^.jpg][^.JPG]( |/)*('|")""",re.IGNORECASE)
    LinkToSrc1 = re.compile("""src=('|")[\S+]*[/\[a-zA-Z0-9-_]+]*(.jpg|.bmp)( |/)*('|")*""", re.IGNORECASE)
    LinkToSrc2 = re.compile("""src=('|")[../][\S+]*[/\[a-zA-Z0-9-_]+]*(.jpg|.bmp)( |/)*('|")*""", re.IGNORECASE)
    LinkToSrc3 = re.compile("""href=('|")[../]+[\S+]*[/\[a-zA-Z0-9-_]+]*(.jpg|.bmp)*[^.html]( |/)*('|")""",re.IGNORECASE)
    count_image=0
    try:
        cursor.execute ("UPDATE status_thread SET Status_thread = 'Unload' WHERE Status_thread = 'load'")
    except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
        print 'Error Unload image'
        
    while(check_start()):
        print '**������**'
        while(check_start() and check_date()):
            cursor.execute("SELECT * FROM table_link_web WHERE Id_web = (""SELECT MIN(Id_web) FROM table_link_web WHERE Load_web = 'Unload'"")")
            result = cursor.fetchall()
            for row in result :{}
            sub_web = row[1]
            Id_Chis = row[0]
            try:
                timeout = 25
                defTimeOut=socket.getdefaulttimeout()
                socket.setdefaulttimeout(timeout)
                print "\nOpenWeb :", row[0] ,":", row[1]
                
                try:
                   cursor.execute ("UPDATE table_link_web SET Load_web = 'Load' WHERE Id_web = '%s' "
                                  %(row[0]))
                except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                   print 'Error'
                
                for line in urllib2.urlopen(row[1]):
                    if '' in line :
                        x = line
                        a = re.search(LinkToHref1, x)
                        b = re.search(LinkToSrc1, x)
                        c = re.search(LinkToSrc2, x)
                        d = re.search(LinkToSrc3, x)
                        count_image = count_image+1
                        if count_image > 50:
                            try:
                                #print "**********count_image***********",count_image
                                cursor.execute("SELECT * FROM table_link_image WHERE Id_Image = (""SELECT MIN(Id_Image) FROM table_link_image WHERE Load_image = 'Unload'"")")
                                result_image = cursor.fetchall()
                                for image_ch in result_image :{}
                                check_loadimage(image_ch)
                                count_image = 0
                            except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                                print ''
                                count_image = 0
                        
                        if a:
                            match_href = a.group()
                            match_href = replace(match_href,"""href=""","""""")
                            match_href = replace(match_href,"""HREF=""","""""")
                            match_href = replace(match_href,"""\"""","""""")
                            match_href = replace(match_href,"""\'""","""""")

                            fullurl = urljoin(sub_web,match_href)
                            fullurl = replace(fullurl,""" ""","""""")
                            fullurl = replace(fullurl,""" ""","""""")
                            fullurl = replace(fullurl,"""\n""","""""")
                            #print "Web link : ",fullurl
                                
                            chack = 0
                            try:
                                cursor.execute("SELECT * FROM table_link_web WHERE Url_Web = %s",fullurl)
                                result = cursor.fetchall()
                                for row in result:
                                    chack = chack + 1
                            except(StandardError):
                                continue
                            if chack < 1:
                                try:
                                    cursor.executemany("INSERT INTO table_link_web (Url_Web,Date_Web,Id_Chis) VALUES (%s,%s,%s)", [(fullurl,date.today(),Id_Chis)])
                                    db.commit()
                                except(StandardError):
                                    continue
                        else:
                            if d:
                                match_src2 = d.group()
                                match_src2 = replace(match_src2,"""href=""","""""")
                                match_src2 = replace(match_src2,"""HREF=""","""""")
                                match_src2 = replace(match_src2,"""\"""","""""")
                                match_src2 = replace(match_src2,"""\'""","""""")

                                fullurl = urljoin(sub_web,match_src2)
                                fullurl = replace(fullurl,""" ""","""""")
                                fullurl = replace(fullurl,""" ""","""""")
                                fullurl = replace(fullurl,"""\n""","""""")
                                    
                                chack = 0
                                try:
                                    cursor.execute("SELECT * FROM table_link_image WHERE Url_Image = %s",fullurl)
                                    result = cursor.fetchall()
                                    for row in result:
                                        chack = chack + 1
                                except(StandardError):
                                    continue
                                if chack < 1:
                                    try:
                                        cursor.executemany("INSERT INTO table_link_image (Url_Image,Date_Image,Id_Web_Chis) VALUES (%s,%s,%s)", [(fullurl,date.today(),Id_Chis)])
                                        db.commit()
                                    except(StandardError):
                                        continue
                                
                        if b:
                            match_src = b.group()
                            match_src = replace(match_src,"""src=""","""""")
                            match_src = replace(match_src,"""SRC=""","""""")
                            match_src = replace(match_src,"""\"""","""""")
                            match_src = replace(match_src,"""\'""","""""")
                            fullurl = urljoin(sub_web,match_src)
                            fullurl = replace(fullurl,"""\n""","""""")
                                
                            #print "Web image : ",fullurl
                            chack = 0
                            try:
                                cursor.execute("SELECT * FROM table_link_image WHERE Url_Image = %s",fullurl)
                                result = cursor.fetchall()
                                for row in result:
                                    chack = chack + 1
                            except(StandardError):
                                continue
                            if chack < 1:
                                try:
                                    cursor.executemany("INSERT INTO table_link_image (Url_Image,Date_Image,Id_Web_Chis) VALUES (%s,%s,%s)", [(fullurl,date.today(),Id_Chis)])
                                    db.commit()
                                except(StandardError):
                                    continue
                        if c:
                            match_src1 = b.group()
                            match_src1 = replace(match_src1,"""\"""","""""")
                            match_src1 = replace(match_src1,"""src=..""","""""")
                            match_src1 = replace(match_src1,"""\'""","""""")
                            #web_cut = cut_string(sub_web)

                                    
            except(urllib2.HTTPError, urllib2.URLError,socket.error, socket.sslerror,ECONNRESET,IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine,HTTPError,URLError ):
                socket.setdefaulttimeout(defTimeOut)
                print'Webpage ERROR'
                continue
    
except(IOError , TypeError , ValueError,RuntimeError,StandardError,InvalidURL,BadStatusLine):
    print '********Program Error*******'

