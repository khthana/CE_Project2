from databaserule  import *
from checkrulebase import *

class display:

    def __init__(self):

        self.__database = None
        self.__checkrulebase = CheckRulebase()

    def Object(self,object_id):
        self.__database = DatabaseRule()
        object_name = self.__database.GetObjectNameFromObjectId(object_id)
        self.__database.Close()
        return object_name

    def Clause(self,clause_id):
        self.__database = DatabaseRule()
        clause = self.__database.GetClauseFromClauseId(clause_id)
        self.__database.Close()
        object_name = self.Object(clause[0])
        clause_string = "%s  %s  %s" % (object_name,clause[1],clause[2])
        return clause_string

    def Rule(self,rule_id):
        self.__database = DatabaseRule()
        premise = self.__database.GetClausePremiseFromId(rule_id)
        conclusion = self.__database.GetClauseConclusionFromId(rule_id)
        self.__database.Close()
        rule_string = ""
        begin = True
        for clause in premise:
            if begin :
                begin = False
                rule_string = rule_string + "IF   %s  " % self.Clause(clause[0])
            else:
                rule_string = rule_string + "AND  %s  " % self.Clause(clause[0])
        rule_string = rule_string + "THEN %s" % self.Clause(conclusion[0][0])
        return rule_string        

    def AllRule(self):
        self.__database = DatabaseRule()
        set_rule_id = self.__database.GetAllRuleId()
        self.__database.Close()
        for rule_id in set_rule_id:
            print rule_id,':'
            print self.Rule(rule_id)
