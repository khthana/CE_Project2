import MySQLdb
from rule import *
from databaserule import *


class drop:
    def __init__(self):

        db = MySQLdb.connect(host="localhost", user="root", passwd="root",db="validation")
        cursor = db.cursor()
        cursor.execute("""drop table RULE_CLAUSES_PREMISE """)

        cursor.execute("""drop table RULE """)

        cursor.execute("""drop table GOAL_CLAUSE """)

        cursor.execute("""drop table RELATION_CLAUSE """)

        cursor.execute("""drop table CLAUSE """)

        cursor.execute("""drop table VALUE """)

        cursor.execute("""drop table ASKABLE_OBJECT""")

        cursor.execute("""drop table OBJECT """)


        cursor.close()
        db.commit()
        db.close()

class create:
    def __init__(self):
        db = MySQLdb.connect(host="localhost", user="root", passwd="root",db="validation")
        cursor = db.cursor()
        cursor.execute("""create table RULE (RULE_ID VARCHAR(6) NOT NULL,
                                             PRIMARY KEY (RULE_ID),
                                             CLAUSE_CONCLUSION VARCHAR(7))""")

        cursor.execute("""create table CLAUSE (CLAUSE_ID VARCHAR(7) NOT NULL,
                                               PRIMARY KEY (CLAUSE_ID),
                                               OBJECT_ID VARCHAR(6),
                                               OPERATOR VARCHAR(15),
                                               VALUE VARCHAR(30))""")

        cursor.execute("""create table RULE_CLAUSES_PREMISE (RULE_ID VARCHAR(6),
                                                             CLAUSE_PREMISE VARCHAR(7),
                                                             PRIMARY KEY (RULE_ID,CLAUSE_PREMISE))""")

        cursor.execute("""create table OBJECT (OBJECT_ID VARCHAR(6) NOT NULL,
                                               PRIMARY KEY (OBJECT_ID),
                                               OBJECT_NAME VARCHAR(30),
                                               TYPE VARCHAR(15))""")

        cursor.execute("""create table VALUE (VALUE_ID VARCHAR(6) NOT NULL,
                                             PRIMARY KEY (VALUE_ID),
                                             VALUE_NAME VARCHAR(30),
                                             OBJECT_ID VARCHAR(6))""")

        cursor.execute("""create table RELATION_CLAUSE      (CLAUSE_IDONE VARCHAR(7),
                                                             CLAUSE_IDTWO VARCHAR(7),
                                                             TYPE_RELATION VARCHAR(30),
                                                             PRIMARY KEY (CLAUSE_IDONE,CLAUSE_IDTWO))""")

        cursor.execute("""create table GOAL_CLAUSE          (GOAL_ID VARCHAR(7),
                                                             CLAUSE_ID VARCHAR(7),
                                                             GOAL_NAME  VARCHAR(20),
                                                             PRIMARY KEY (GOAL_ID,CLAUSE_ID))""")

        cursor.execute("""create table ASKABLE_OBJECT       (ASK_ID VARCHAR(7),
                                                             OBJECT_ID VARCHAR(7),
                                                             ASK_NAME  VARCHAR(20),
                                                             PRIMARY KEY (ASK_ID,OBJECT_ID))""")


        cursor.execute("""alter table RULE add FOREIGN KEY (CLAUSE_CONCLUSION)
                                                references CLAUSE(CLAUSE_ID)""")

        cursor.execute("""alter table RULE_CLAUSES_PREMISE add FOREIGN KEY (CLAUSE_PREMISE)
                                                references CLAUSE(CLAUSE_ID)""")

        cursor.execute("""alter table RULE_CLAUSES_PREMISE add FOREIGN KEY (RULE_ID)
                                                references RULE(RULE_ID)""")

        cursor.execute("""alter table CLAUSE add FOREIGN KEY (OBJECT_ID)
                                                references OBJECT(OBJECT_ID)""")

        cursor.execute("""alter table VALUE add FOREIGN KEY (OBJECT_ID)
                                                references OBJECT(OBJECT_ID)""")

        cursor.execute("""alter table RELATION_CLAUSE add FOREIGN KEY (CLAUSE_IDONE)
                                                references CLAUSE(CLAUSE_ID)""")

        cursor.execute("""alter table RELATION_CLAUSE add FOREIGN KEY (CLAUSE_IDTWO)
                                                references CLAUSE(CLAUSE_ID)""")

        cursor.execute("""alter table GOAL_CLAUSE add FOREIGN KEY (CLAUSE_ID)
                                                references CLAUSE(CLAUSE_ID)""")

        cursor.execute("""alter table ASKABLE_OBJECT add FOREIGN KEY (OBJECT_ID)
                                                references OBJECT(OBJECT_ID)""")

        cursor.close()
        db.commit()
        db.close()

class test:
    def __init__(self):
        print "test"


    def testconflict(self):
        oa = Object('A','Set Value')
        oa.AddValueToSetOfObject('a')
        oa.AddValueToSetOfObject('a1')
        oa.AddValueToSetOfObject('a2')
        oa.AddValueToSetOfObject('a3')
        ob = Object('B','Set Value')
        ob.AddValueToSetOfObject('b')
        ob.AddValueToSetOfObject('b1')
        oc = Object('C','Set Value')
        oc.AddValueToSetOfObject('c')
        oc.AddValueToSetOfObject('z')
        od = Object('D','Set Value')
        od.AddValueToSetOfObject('d')
        od.AddValueToSetOfObject('d1')
        oe = Object('E','Set Value')
        oe.AddValueToSetOfObject('e')
        of = Object('F','Set Value')
        of.AddValueToSetOfObject('f')
        og = Object('G','Set Value')
        og.AddValueToSetOfObject('g')
        oh = Object('H','Set Value')
        oh.AddValueToSetOfObject('h')
        oi = Object('I','Set Value')
        oi.AddValueToSetOfObject('i')
        oj = Object('J','Set Value')
        oj.AddValueToSetOfObject('j')


        onX = Object('Nunber X','Set Number')
        onY = Object('Nunber Y','Set Number')
        onZ = Object('Nunber X','Set Number')

        Xone = Clause(onX,'=','1')
        Xtwo = Clause(onX,'=','2')
        Xthree = Clause(onX,'>','1')
        Xfour = Clause(onX,'>=','1')
        Xfive = Clause(onX,'<','2')
        Xsix = Clause(onX,'<=','3')

        Yone = Clause(onY,'<>','1')
        Ytwo = Clause(onY,'<>','2')
        Ythree = Clause(onY,'>','5')
        Yfour = Clause(onY,'>=','7')
        Yfive = Clause(onY,'<','-4')
        Ysix = Clause(onY,'<=','-5')

        Zone = Clause(onX,'=','6')
        Ztwo = Clause(onX,'<>','7')
        Zthree = Clause(onX,'>','3')
        Zfour = Clause(onX,'>=','3')
        Zfive = Clause(onX,'<','10')
        Zsix = Clause(onX,'<=','11')

        #------------------- Create Clause

        a = Clause(oa,'is','a')
        na = Clause(oa,'is not','a')
        a1 = Clause(oa,'is','a1')
        na1 = Clause(oa,'is not','a1')
        b = Clause(ob,'is','b')
        nb = Clause(ob,'is not','b')
        b1 = Clause(ob,'is','b1')
        nb1 = Clause(ob,'is not','b1')
        c = Clause(oc,'is','c')
        ncz = Clause(oc,'is not','z')
        d = Clause(od,'is','d')
        d1 = Clause(od,'is','d1')
        nd = Clause(od,'is not','d')
        nd1 = Clause(od,'is not','d1')
        e = Clause(oe,'is','e')
        f = Clause(of,'is','f')
        nf = Clause(of,'is not','f')
        nc = Clause(oc,'is','z')
        g = Clause(og,'is','g')
        ng = Clause(og,'is not','g')
        h = Clause(oh,'is','h')
        nh = Clause(oh,'is not','h')
        i = Clause(oh,'is','i')
        ni = Clause(oh,'is not','i')
        j = Clause(oh,'is','j')
        nj = Clause(oh,'is not','j')

        #----------------------- Create Rule

        r1 = Rule(a,b)
        r2 = Rule(a,c)
        r2.AddClauseToPremise(e)
        r3 = Rule(b,c)
        r3.AddClauseToPremise(e)
        r4 = Rule(b,nc)
        r4.AddClauseToPremise(e)
        r5 = Rule(a,b)
        r6 = Rule(e,c)
        r7 = Rule(b,f)
        r7.AddClauseToPremise(c)
        r7.AddClauseToPremise(d)
        r8 = Rule(d,f)
        r8.AddClauseToPremise(b)
        r8.AddClauseToPremise(c)
        r9 = Rule(d,f)
        r9.AddClauseToPremise(b)
        r9.AddClauseToPremise(c)
        r9.AddClauseToPremise(a)
        r10 = Rule(b,f)
        r10.AddClauseToPremise(d)
        r11 = Rule(a,g)
        r11.AddClauseToPremise(b)
        r12 = Rule(a,ng)
        r12.AddClauseToPremise(b)
        r13 = Rule(b,h)
        r13.AddClauseToPremise(d)
        r13.AddClauseToPremise(c)
        r14 = Rule(nc,nh)
        r14.AddClauseToPremise(d)
        r14.AddClauseToPremise(b)
        r15 = Rule(b,c)
        r15.AddClauseToPremise(e)
        r16 = Rule(d,f)
        r17 = Rule(nd,f)
        r18 = Rule(nb,f)
        r18.AddClauseToPremise(d)
        r19 = Rule(d,f)
        r19.AddClauseToPremise(b)
        r19.AddClauseToPremise(c)
        r19.AddClauseToPremise(na)
        r20 = Rule(d,f)
        r20.AddClauseToPremise(nb)
        r20.AddClauseToPremise(c)
        r20.AddClauseToPremise(na)
        r21 = Rule(f,b)
        r22 = Rule(h,g)
        r23 = Rule(g,ni)
        r23.AddClauseToPremise(a)
        r24 = Rule(ni,b)
        r24.AddClauseToPremise(j)
        r25 = Rule(g,e)
        r26 = Rule(j,c)
        r27 = Rule(b,h)
        r28 = Rule(a,h)
        r29 = Rule(a,b1)

        r30 = Rule(g,a1)
        r31 = Rule(g,na1)
        r32 = Rule(g,a)
        r33 = Rule(g,na)
        r34 = Rule(nd1,f)
        r34.AddClauseToPremise(nb1)
        r34.AddClauseToPremise(ncz)
        r34.AddClauseToPremise(a)
        r35 = Rule(f,h)
        r32 = Rule(h,a)

        rn1 = Rule(Zone,Xone)
        rn2 = Rule(Zone,Xtwo)
        rn3 = Rule(Zone,Xthree)
        rn4 = Rule(Zone,Xfour)
        rn5 = Rule(Zone,Xfive)
        rn6 = Rule(Zone,Xsix)

        rn7 = Rule(Xone,Yone)
        rn8 = Rule(Xone,Ytwo)
        rn9 = Rule(Xone,Ythree)
        rn10 = Rule(Xone,Yfour)
        rn11 = Rule(Xone,Yfive)
        rn12 = Rule(Xone,Ysix)

        rn13 = Rule(Xone,Zone)
        rn14 = Rule(Xone,Ztwo)
        rn15 = Rule(Xone,Zthree)
        rn16 = Rule(Xone,Zfour)
        rn17 = Rule(Xone,Zfive)
        rn18 = Rule(Xone,Zsix)
        # ------------------------ Create Database of Rule

        db = DatabaseRule()

        db.AskableObject(od)
        db.AskableObject(oh)
        
        db.AddRule(r1) #IF A is a  THEN  B is b
        db.AddRule(r2) #IF A is a  AND   E is e THEN  C is c
        db.AddRule(r3) #IF B is b  AND   E is e THEN  C is c
        db.AddRule(r4) #IF B is b  AND   E is e THEN  C is z
        db.AddRule(r5) #IF A is a  THEN  B is b
        db.AddRule(r6) #IF E is e  THEN  C is c
        db.AddRule(r7) #IF B is b  AND   C is c AND   D is d THEN  F is f
        db.AddRule(r8) #IF D is d  AND   B is b AND   C is c THEN  F is f
        db.AddRule(r9) #IF D is d  AND   B is b AND   C is c AND   A is a THEN  F is f
        db.AddRule(r10)#IF B is b  AND   D is d THEN  F is f
        db.AddRule(r11)#IF A is a  AND   B is b THEN  G is g
        db.AddRule(r12)#IF A is a  AND   B is b THEN  G is not g
        db.AddRule(r13)#IF B is b  AND   D is d AND   C is c  THEN  H is h
        db.AddRule(r14)#IF B is b  AND   D is d AND   C is not c  THEN  H is not h
        db.AddRule(r15)#IF B is b  AND   E is e THEN  C is not c
        db.AddRule(r16)#IF D is d THEN  F is f
        db.AddRule(r17)#IF D is not d THEN  F is f
        db.AddRule(r18)#IF B is not b  AND   D is d THEN  F is f
        db.AddRule(r19)#IF D is d  AND   B is b AND   C is c AND   A is not a THEN  F is f
        db.AddRule(r20)#IF D is d  AND   B is not b AND   C is c AND   A is not a THEN  F is f
        db.AddRule(r21)#IF F is f  THEN  B is b
        db.AddRule(r22)#IF H is h  THEN  G is g
        db.AddRule(r23)#IF A is a  AND   G is g     THEN  I is not i
        db.AddRule(r24)#IF J is j  AND   I is not i THEN  B is b
        db.AddRule(r25)#IF G is g  THEN  E is e
        db.AddRule(r26)#IF J is j  THEN  C is c
        db.AddRule(r27)#IF B is b  THEN  H is h
        db.AddRule(r28)#IF A is a  THEN  H is h
        db.AddRule(r29) #IF A is a  THEN  B is b1
        db.AddRule(r30) #IF G is g  THEN  A is a1
        db.AddRule(r31) #IF G is g  THEN  A is not a1
        db.AddRule(r32) #IF G is g  THEN  A is a
        db.AddRule(r33) #IF G is g  THEN  A is not a
        db.AddRule(r34)#IF D is not d1  AND   B is not b1 AND   C is not z AND   A is a THEN  F is f

        #---------------------- Close Database

        db.Close()

    def testcircular(self):
        # ------------------------ Create Database of Rule
        oa = Object('A','Set Value')
        oa.AddValueToSetOfObject('a')
        oa.AddValueToSetOfObject('a1')
        oa.AddValueToSetOfObject('a2')
        oa.AddValueToSetOfObject('a3')
        ob = Object('B','Set Value')
        ob.AddValueToSetOfObject('b')
        ob.AddValueToSetOfObject('b1')
        oc = Object('C','Set Value')
        oc.AddValueToSetOfObject('c')
        oc.AddValueToSetOfObject('z')
        od = Object('D','Set Value')
        od.AddValueToSetOfObject('d')
        od.AddValueToSetOfObject('d1')
        oe = Object('E','Set Value')
        oe.AddValueToSetOfObject('e')
        of = Object('F','Set Value')
        of.AddValueToSetOfObject('f')
        og = Object('G','Set Value')
        og.AddValueToSetOfObject('g')
        oh = Object('H','Set Value')
        oh.AddValueToSetOfObject('h')
        oi = Object('I','Set Value')
        oi.AddValueToSetOfObject('i')
        oj = Object('J','Set Value')
        oj.AddValueToSetOfObject('j')


        onX = Object('Nunber X','Set Number')
        onY = Object('Nunber Y','Set Number')
        onZ = Object('Nunber X','Set Number')

        Xone = Clause(onX,'=','1')
        Xtwo = Clause(onX,'=','2')
        Xthree = Clause(onX,'>','1')
        Xfour = Clause(onX,'>=','1')
        Xfive = Clause(onX,'<','2')
        Xsix = Clause(onX,'<=','3')

        Yone = Clause(onY,'<>','1')
        Ytwo = Clause(onY,'<>','2')
        Ythree = Clause(onY,'>','5')
        Yfour = Clause(onY,'>=','7')
        Yfive = Clause(onY,'<','-4')
        Ysix = Clause(onY,'<=','-5')

        Zone = Clause(onX,'=','6')
        Ztwo = Clause(onX,'<>','7')
        Zthree = Clause(onX,'>','3')
        Zfour = Clause(onX,'>=','3')
        Zfive = Clause(onX,'<','10')
        Zsix = Clause(onX,'<=','11')

        #------------------- Create Clause

        a = Clause(oa,'is','a')
        na = Clause(oa,'is not','a')
        a1 = Clause(oa,'is','a1')
        na1 = Clause(oa,'is not','a1')
        b = Clause(ob,'is','b')
        nb = Clause(ob,'is not','b')
        b1 = Clause(ob,'is','b1')
        nb1 = Clause(ob,'is not','b1')
        c = Clause(oc,'is','c')
        ncz = Clause(oc,'is not','z')
        d = Clause(od,'is','d')
        d1 = Clause(od,'is','d1')
        nd = Clause(od,'is not','d')
        nd1 = Clause(od,'is not','d1')
        e = Clause(oe,'is','e')
        f = Clause(of,'is','f')
        nf = Clause(of,'is not','f')
        nc = Clause(oc,'is','z')
        g = Clause(og,'is','g')
        ng = Clause(og,'is not','g')
        h = Clause(oh,'is','h')
        nh = Clause(oh,'is not','h')
        i = Clause(oh,'is','i')
        ni = Clause(oh,'is not','i')
        j = Clause(oh,'is','j')
        nj = Clause(oh,'is not','j')

        #----------------------- Create Rule

        r1 = Rule(a,b)
        r2 = Rule(a,c)
        r2.AddClauseToPremise(e)
        r3 = Rule(b,c)
        r3.AddClauseToPremise(e)
        r4 = Rule(b,nc)
        r4.AddClauseToPremise(e)
        r5 = Rule(a,b)
        r6 = Rule(e,c)
        r7 = Rule(b,f)
        r7.AddClauseToPremise(c)
        r7.AddClauseToPremise(d)
        r8 = Rule(d,f)
        r8.AddClauseToPremise(b)
        r8.AddClauseToPremise(c)
        r9 = Rule(d,f)
        r9.AddClauseToPremise(b)
        r9.AddClauseToPremise(c)
        r9.AddClauseToPremise(a)
        r10 = Rule(b,f)
        r10.AddClauseToPremise(d)
        r11 = Rule(a,g)
        r11.AddClauseToPremise(b)
        r12 = Rule(a,ng)
        r12.AddClauseToPremise(b)
        r13 = Rule(b,h)
        r13.AddClauseToPremise(d)
        r13.AddClauseToPremise(c)
        r14 = Rule(nc,nh)
        r14.AddClauseToPremise(d)
        r14.AddClauseToPremise(b)
        r15 = Rule(b,c)
        r15.AddClauseToPremise(e)
        r16 = Rule(d,f)
        r17 = Rule(nd,f)
        r18 = Rule(nb,f)
        r18.AddClauseToPremise(d)
        r19 = Rule(d,f)
        r19.AddClauseToPremise(b)
        r19.AddClauseToPremise(c)
        r19.AddClauseToPremise(na)
        r20 = Rule(d,f)
        r20.AddClauseToPremise(nb)
        r20.AddClauseToPremise(c)
        r20.AddClauseToPremise(na)
        r21 = Rule(f,b)
        r22 = Rule(h,g)
        r23 = Rule(g,ni)
        r23.AddClauseToPremise(a)
        r24 = Rule(ni,b)
        r24.AddClauseToPremise(j)
        r25 = Rule(g,e)
        r26 = Rule(j,c)
        r27 = Rule(b,h)
        r28 = Rule(a,h)
        r29 = Rule(a,b1)

        r30 = Rule(g,a1)
        r31 = Rule(g,na1)
        r32 = Rule(g,a)
        r33 = Rule(g,na)
        r34 = Rule(nd1,f)
        r34.AddClauseToPremise(nb1)
        r34.AddClauseToPremise(ncz)
        r34.AddClauseToPremise(a)
        r35 = Rule(f,h)
        r36 = Rule(h,a)

        rn1 = Rule(Zone,Xone)
        rn2 = Rule(Zone,Xtwo)
        rn3 = Rule(Zone,Xthree)
        rn4 = Rule(Zone,Xfour)
        rn5 = Rule(Zone,Xfive)
        rn6 = Rule(Zone,Xsix)

        rn7 = Rule(Xone,Yone)
        rn8 = Rule(Xone,Ytwo)
        rn9 = Rule(Xone,Ythree)
        rn10 = Rule(Xone,Yfour)
        rn11 = Rule(Xone,Yfive)
        rn12 = Rule(Xone,Ysix)

        rn13 = Rule(Xone,Zone)
        rn14 = Rule(Xone,Ztwo)
        rn15 = Rule(Xone,Zthree)
        rn16 = Rule(Xone,Zfour)
        rn17 = Rule(Xone,Zfive)
        rn18 = Rule(Xone,Zsix)
        db = DatabaseRule()

        #------------------------- Add Goal in database
        db.AddGoal(b)
        db.AddGoal(f)
        #db.AddGoal(g)

        db.AskableObject(od)
        db.AskableObject(oh)

        #---------------------- Add Rule in Database

        db.AddRule(r1) #IF A is a  THEN  B is b
        
        db.AddRule(r7) #IF B is b  AND   C is c AND   D is d THEN  F is f

        #db.AddRule(r13)#IF B is b  AND   D is d AND   C is c  THEN  H is h
        db.AddRule(r14)#IF B is b  AND   D is d AND   C is not c  THEN  H is not h
        db.AddRule(r15)#IF B is b  AND   E is e THEN  C is not c
        db.AddRule(r16)#IF D is d THEN  F is f
        #db.AddRule(r17)#IF D is not d THEN  F is f
        
        db.AddRule(r21)#IF F is f  THEN  B is b
        #db.AddRule(r22)#IF H is h  THEN  G is g
        db.AddRule(r23)#IF A is a  AND   G is g     THEN  I is not i
        db.AddRule(r24)#IF J is j  AND   I is not i THEN  B is b
        db.AddRule(r25)#IF G is g  THEN  E is e
        db.AddRule(r26)#IF J is j  THEN  C is c
        #db.AddRule(r27)#IF B is b  THEN  H is h
        #db.AddRule(r28)#IF A is a  THEN  H is h
        db.AddRule(r29) #IF A is a  THEN  B is b1
        #db.AddRule(r30) #IF G is g  THEN  A is a1
        #db.AddRule(r31) #IF G is g  THEN  A is not a1
        #db.AddRule(r32) #IF G is g  THEN  A is a
        db.AddRule(r33) #IF G is g  THEN  A is not a
        #db.AddRule(r34)#IF D is not d1  AND   B is not b1 AND   C is not z AND   A is a THEN  F is f
        db.AddRule(r35)#IF F is f  THEN  H is h
        db.AddRule(r36)#IF H is h  THEN  A is a
        #---------------------- Close Database

        db.Close()


    def testredundant(self):
        oa = Object('A','Set Value')
        oa.AddValueToSetOfObject('a')
        oa.AddValueToSetOfObject('a1')
        oa.AddValueToSetOfObject('a2')
        oa.AddValueToSetOfObject('a3')
        ob = Object('B','Set Value')
        ob.AddValueToSetOfObject('b')
        ob.AddValueToSetOfObject('b1')
        oc = Object('C','Set Value')
        oc.AddValueToSetOfObject('c')
        oc.AddValueToSetOfObject('z')
        od = Object('D','Set Value')
        od.AddValueToSetOfObject('d')
        od.AddValueToSetOfObject('d1')
        oe = Object('E','Set Value')
        oe.AddValueToSetOfObject('e')
        of = Object('F','Set Value')
        of.AddValueToSetOfObject('f')
        og = Object('G','Set Value')
        og.AddValueToSetOfObject('g')
        oh = Object('H','Set Value')
        oh.AddValueToSetOfObject('h')
        oi = Object('I','Set Value')
        oi.AddValueToSetOfObject('i')
        oj = Object('J','Set Value')
        oj.AddValueToSetOfObject('j')


        onX = Object('Nunber X','Set Number')
        onY = Object('Nunber Y','Set Number')
        onZ = Object('Nunber X','Set Number')

        Xone = Clause(onX,'=','1')
        Xtwo = Clause(onX,'=','2')
        Xthree = Clause(onX,'>','1')
        Xfour = Clause(onX,'>=','1')
        Xfive = Clause(onX,'<','2')
        Xsix = Clause(onX,'<=','3')

        Yone = Clause(onY,'<>','1')
        Ytwo = Clause(onY,'<>','2')
        Ythree = Clause(onY,'>','5')
        Yfour = Clause(onY,'>=','7')
        Yfive = Clause(onY,'<','-4')
        Ysix = Clause(onY,'<=','-5')

        Zone = Clause(onX,'=','6')
        Ztwo = Clause(onX,'<>','7')
        Zthree = Clause(onX,'>','3')
        Zfour = Clause(onX,'>=','3')
        Zfive = Clause(onX,'<','10')
        Zsix = Clause(onX,'<=','11')

        #------------------- Create Clause

        a = Clause(oa,'is','a')
        na = Clause(oa,'is not','a')
        a1 = Clause(oa,'is','a1')
        na1 = Clause(oa,'is not','a1')
        b = Clause(ob,'is','b')
        nb = Clause(ob,'is not','b')
        b1 = Clause(ob,'is','b1')
        nb1 = Clause(ob,'is not','b1')
        c = Clause(oc,'is','c')
        ncz = Clause(oc,'is not','z')
        d = Clause(od,'is','d')
        d1 = Clause(od,'is','d1')
        nd = Clause(od,'is not','d')
        nd1 = Clause(od,'is not','d1')
        e = Clause(oe,'is','e')
        f = Clause(of,'is','f')
        nf = Clause(of,'is not','f')
        nc = Clause(oc,'is','z')
        g = Clause(og,'is','g')
        ng = Clause(og,'is not','g')
        h = Clause(oh,'is','h')
        nh = Clause(oh,'is not','h')
        i = Clause(oh,'is','i')
        ni = Clause(oh,'is not','i')
        j = Clause(oh,'is','j')
        nj = Clause(oh,'is not','j')

        #----------------------- Create Rule

        r1 = Rule(a,b)
        r2 = Rule(a,c)
        r2.AddClauseToPremise(e)
        r3 = Rule(b,c)
        r3.AddClauseToPremise(e)
        r4 = Rule(b,nc)
        r4.AddClauseToPremise(e)
        r5 = Rule(a,b)
        r6 = Rule(e,c)
        r7 = Rule(b,f)
        r7.AddClauseToPremise(c)
        r7.AddClauseToPremise(d)
        r8 = Rule(d,f)
        r8.AddClauseToPremise(b)
        r8.AddClauseToPremise(c)
        r9 = Rule(d,f)
        r9.AddClauseToPremise(b)
        r9.AddClauseToPremise(c)
        r9.AddClauseToPremise(a)
        r10 = Rule(b,f)
        r10.AddClauseToPremise(d)
        r11 = Rule(a,g)
        r11.AddClauseToPremise(b)
        r12 = Rule(a,ng)
        r12.AddClauseToPremise(b)
        r13 = Rule(b,h)
        r13.AddClauseToPremise(d)
        r13.AddClauseToPremise(c)
        r14 = Rule(nc,nh)
        r14.AddClauseToPremise(d)
        r14.AddClauseToPremise(b)
        r15 = Rule(b,c)
        r15.AddClauseToPremise(e)
        r16 = Rule(d,f)
        r17 = Rule(nd,f)
        r18 = Rule(nb,f)
        r18.AddClauseToPremise(d)
        r19 = Rule(d,f)
        r19.AddClauseToPremise(b)
        r19.AddClauseToPremise(c)
        r19.AddClauseToPremise(na)
        r20 = Rule(d,f)
        r20.AddClauseToPremise(nb)
        r20.AddClauseToPremise(c)
        r20.AddClauseToPremise(na)
        r21 = Rule(f,b)
        r22 = Rule(h,g)
        r23 = Rule(g,ni)
        r23.AddClauseToPremise(a)
        r24 = Rule(ni,b)
        r24.AddClauseToPremise(j)
        r25 = Rule(g,e)
        r26 = Rule(j,c)
        r27 = Rule(b,h)
        r28 = Rule(a,h)
        r29 = Rule(a,nb1)

        r30 = Rule(g,a1)
        r31 = Rule(g,na1)
        r32 = Rule(g,a)
        r33 = Rule(g,na)
        r34 = Rule(nd1,f)
        r34.AddClauseToPremise(nb1)
        r34.AddClauseToPremise(ncz)
        r34.AddClauseToPremise(a)
        r35 = Rule(f,h)
        r32 = Rule(h,a)

        rn1 = Rule(Zone,Xone)
        rn2 = Rule(Zone,Xtwo)
        rn3 = Rule(Zone,Xthree)
        rn4 = Rule(Zone,Xfour)
        rn5 = Rule(Zone,Xfive)
        rn6 = Rule(Zone,Xsix)

        rn7 = Rule(Xone,Yone)
        rn8 = Rule(Xone,Ytwo)
        rn9 = Rule(Xone,Ythree)
        rn10 = Rule(Xone,Yfour)
        rn11 = Rule(Xone,Yfive)
        rn12 = Rule(Xone,Ysix)

        rn13 = Rule(Xone,Zone)
        rn14 = Rule(Xone,Ztwo)
        rn15 = Rule(Xone,Zthree)
        rn16 = Rule(Xone,Zfour)
        rn17 = Rule(Xone,Zfive)
        rn18 = Rule(Xone,Zsix)
        # ------------------------ Create Database of Rule

        db = DatabaseRule()
        db.AddRule(r1) #IF A is a  THEN  B is b
        db.AddRule(r2) #IF A is a  AND   E is e THEN  C is c
        db.AddRule(r3) #IF B is b  AND   E is e THEN  C is c
        db.AddRule(r4) #IF B is b  AND   E is e THEN  C is z
        db.AddRule(r5) #IF A is a  THEN  B is b
        db.AddRule(r6) #IF E is e  THEN  C is c
        db.AddRule(r7) #IF B is b  AND   C is c AND   D is d THEN  F is f
        db.AddRule(r8) #IF D is d  AND   B is b AND   C is c THEN  F is f
        db.AddRule(r9) #IF D is d  AND   B is b AND   C is c AND   A is a THEN  F is f
        db.AddRule(r10)#IF B is b  AND   D is d THEN  F is f
        db.AddRule(r11)#IF A is a  AND   B is b THEN  G is g
        db.AddRule(r12)#IF A is a  AND   B is b THEN  G is not g
        db.AddRule(r13)#IF B is b  AND   D is d AND   C is c  THEN  H is h
        db.AddRule(r14)#IF B is b  AND   D is d AND   C is not c  THEN  H is not h
        db.AddRule(r15)#IF B is b  AND   E is e THEN  C is not c
        db.AddRule(r16)#IF D is d THEN  F is f
        db.AddRule(r17)#IF D is not d THEN  F is f
        db.AddRule(r18)#IF B is not b  AND   D is d THEN  F is f
        db.AddRule(r19)#IF D is d  AND   B is b AND   C is c AND   A is not a THEN  F is f
        db.AddRule(r20)#IF D is d  AND   B is not b AND   C is c AND   A is not a THEN  F is f
        db.AddRule(r21)#IF F is f  THEN  B is b
        db.AddRule(r22)#IF H is h  THEN  G is g
        db.AddRule(r23)#IF A is a  AND   G is g     THEN  I is not i
        db.AddRule(r24)#IF J is j  AND   I is not i THEN  B is b
        db.AddRule(r25)#IF G is g  THEN  E is e
        db.AddRule(r26)#IF J is j  THEN  C is c
        db.AddRule(r27)#IF B is b  THEN  H is h
        db.AddRule(r28)#IF A is a  THEN  H is h
        db.AddRule(r29) #IF A is a  THEN  B is not b1
        db.AddRule(r30) #IF G is g  THEN  A is a1
        db.AddRule(r31) #IF G is g  THEN  A is not a1
        db.AddRule(r32) #IF G is g  THEN  A is a
        db.AddRule(r33) #IF G is g  THEN  A is not a
        db.AddRule(r34)#IF D is not d1  AND   B is not b1 AND   C is not z AND   A is a THEN  F is f

        #---------------------- Close Database

        db.Close()

    def testunachivable(self):
        # ------------------------ Create Database of Rule
        d  = drop()
        C = create()
        oa = Object('A','Set Value')
        oa.AddValueToSetOfObject('a')
        oa.AddValueToSetOfObject('a1')
        oa.AddValueToSetOfObject('a2')
        oa.AddValueToSetOfObject('a3')
        ob = Object('B','Set Value')
        ob.AddValueToSetOfObject('b')
        ob.AddValueToSetOfObject('b1')
        oc = Object('C','Set Value')
        oc.AddValueToSetOfObject('c')
        oc.AddValueToSetOfObject('z')
        od = Object('D','Set Value')
        od.AddValueToSetOfObject('d')
        od.AddValueToSetOfObject('d1')
        oe = Object('E','Set Value')
        oe.AddValueToSetOfObject('e')
        of = Object('F','Set Value')
        of.AddValueToSetOfObject('f')
        og = Object('G','Set Value')
        og.AddValueToSetOfObject('g')
        oh = Object('H','Set Value')
        oh.AddValueToSetOfObject('h')
        oi = Object('I','Set Value')
        oi.AddValueToSetOfObject('i')
        oj = Object('J','Set Value')
        oj.AddValueToSetOfObject('j')


        onX = Object('Nunber X','Set Number')
        onY = Object('Nunber Y','Set Number')
        onZ = Object('Nunber X','Set Number')

        Xone = Clause(onX,'=','1')
        Xtwo = Clause(onX,'=','2')
        Xthree = Clause(onX,'>','1')
        Xfour = Clause(onX,'>=','1')
        Xfive = Clause(onX,'<','2')
        Xsix = Clause(onX,'<=','3')

        Yone = Clause(onY,'<>','1')
        Ytwo = Clause(onY,'<>','2')
        Ythree = Clause(onY,'>','5')
        Yfour = Clause(onY,'>=','7')
        Yfive = Clause(onY,'<','-4')
        Ysix = Clause(onY,'<=','-5')

        Zone = Clause(onX,'=','6')
        Ztwo = Clause(onX,'<>','7')
        Zthree = Clause(onX,'>','3')
        Zfour = Clause(onX,'>=','3')
        Zfive = Clause(onX,'<','10')
        Zsix = Clause(onX,'<=','11')

        #------------------- Create Clause

        a = Clause(oa,'is','a')
        na = Clause(oa,'is not','a')
        a1 = Clause(oa,'is','a1')
        na1 = Clause(oa,'is not','a1')
        b = Clause(ob,'is','b')
        nb = Clause(ob,'is not','b')
        b1 = Clause(ob,'is','b1')
        nb1 = Clause(ob,'is not','b1')
        c = Clause(oc,'is','c')
        ncz = Clause(oc,'is not','z')
        d = Clause(od,'is','d')
        d1 = Clause(od,'is','d1')
        nd = Clause(od,'is not','d')
        nd1 = Clause(od,'is not','d1')
        e = Clause(oe,'is','e')
        f = Clause(of,'is','f')
        nf = Clause(of,'is not','f')
        nc = Clause(oc,'is','z')
        g = Clause(og,'is','g')
        ng = Clause(og,'is not','g')
        h = Clause(oh,'is','h')
        nh = Clause(oh,'is not','h')
        i = Clause(oh,'is','i')
        ni = Clause(oh,'is not','i')
        j = Clause(oh,'is','j')
        nj = Clause(oh,'is not','j')

        #----------------------- Create Rule

        r1 = Rule(a,b)
        r2 = Rule(a,c)
        r2.AddClauseToPremise(e)
        r3 = Rule(b,c)
        r3.AddClauseToPremise(e)
        r4 = Rule(b,nc)
        r4.AddClauseToPremise(e)
        r5 = Rule(a,b)
        r6 = Rule(e,c)
        r7 = Rule(b,f)
        r7.AddClauseToPremise(c)
        r7.AddClauseToPremise(d)
        r8 = Rule(d,f)
        r8.AddClauseToPremise(b)
        r8.AddClauseToPremise(c)
        r9 = Rule(d,f)
        r9.AddClauseToPremise(b)
        r9.AddClauseToPremise(c)
        r9.AddClauseToPremise(a)
        r10 = Rule(b,f)
        r10.AddClauseToPremise(d)
        r11 = Rule(a,g)
        r11.AddClauseToPremise(b)
        r12 = Rule(a,ng)
        r12.AddClauseToPremise(b)
        r13 = Rule(b,h)
        r13.AddClauseToPremise(d)
        r13.AddClauseToPremise(c)
        r14 = Rule(nc,nh)
        r14.AddClauseToPremise(d)
        r14.AddClauseToPremise(b)
        r15 = Rule(b,c)
        r15.AddClauseToPremise(e)
        r16 = Rule(d,f)
        r17 = Rule(nd,f)
        r18 = Rule(nb,f)
        r18.AddClauseToPremise(d)
        r19 = Rule(d,f)
        r19.AddClauseToPremise(b)
        r19.AddClauseToPremise(c)
        r19.AddClauseToPremise(na)
        r20 = Rule(d,f)
        r20.AddClauseToPremise(nb)
        r20.AddClauseToPremise(c)
        r20.AddClauseToPremise(na)
        r21 = Rule(f,b)
        r22 = Rule(h,g)
        r23 = Rule(g,ni)
        r23.AddClauseToPremise(a)
        r24 = Rule(ni,b)
        r24.AddClauseToPremise(j)
        r25 = Rule(g,e)
        r26 = Rule(j,c)
        r27 = Rule(b,h)
        r28 = Rule(a,h)
        r29 = Rule(a,b1)

        r30 = Rule(g,a1)
        r31 = Rule(g,na1)
        r32 = Rule(g,a)
        r33 = Rule(g,na)
        r34 = Rule(nd1,f)
        r34.AddClauseToPremise(nb1)
        r34.AddClauseToPremise(ncz)
        r34.AddClauseToPremise(a)
        r35 = Rule(f,h)
        r36 = Rule(h,a)

        rn1 = Rule(Zone,Xone)
        rn2 = Rule(Zone,Xtwo)
        rn3 = Rule(Zone,Xthree)
        rn4 = Rule(Zone,Xfour)
        rn5 = Rule(Zone,Xfive)
        rn6 = Rule(Zone,Xsix)

        rn7 = Rule(Xone,Yone)
        rn8 = Rule(Xone,Ytwo)
        rn9 = Rule(Xone,Ythree)
        rn10 = Rule(Xone,Yfour)
        rn11 = Rule(Xone,Yfive)
        rn12 = Rule(Xone,Ysix)

        rn13 = Rule(Xone,Zone)
        rn14 = Rule(Xone,Ztwo)
        rn15 = Rule(Xone,Zthree)
        rn16 = Rule(Xone,Zfour)
        rn17 = Rule(Xone,Zfive)
        rn18 = Rule(Xone,Zsix)
        db = DatabaseRule()

        #------------------------- Add Goal in database
        db.AddGoal(b)
        db.AddGoal(f)
        #db.AddGoal(g)

        db.AskableObject(od)
        db.AskableObject(oh)

        #---------------------- Add Rule in Database

        db.AddRule(r1) #IF A is a  THEN  B is b
        
        db.AddRule(r7) #IF B is b  AND   C is c AND   D is d THEN  F is f

        #db.AddRule(r13)#IF B is b  AND   D is d AND   C is c  THEN  H is h
        db.AddRule(r14)#IF B is b  AND   D is d AND   C is not c  THEN  H is not h
        db.AddRule(r15)#IF B is b  AND   E is e THEN  C is not c
        db.AddRule(r16)#IF D is d THEN  F is f
        #db.AddRule(r17)#IF D is not d THEN  F is f
        
        db.AddRule(r21)#IF F is f  THEN  B is b
        #db.AddRule(r22)#IF H is h  THEN  G is g
        db.AddRule(r23)#IF A is a  AND   G is g     THEN  I is not i
        db.AddRule(r24)#IF J is j  AND   I is not i THEN  B is b
        db.AddRule(r25)#IF G is g  THEN  E is e
        #db.AddRule(r26)#IF J is j  THEN  C is c
        #db.AddRule(r27)#IF B is b  THEN  H is h
        #db.AddRule(r28)#IF A is a  THEN  H is h
        db.AddRule(r29) #IF A is a  THEN  B is b1
        #db.AddRule(r30) #IF G is g  THEN  A is a1
        #db.AddRule(r31) #IF G is g  THEN  A is not a1
        #db.AddRule(r32) #IF G is g  THEN  A is a
        db.AddRule(r33) #IF G is g  THEN  A is not a
        db.AddRule(r34)#IF D is not d1  AND   B is not b1 AND   C is not z AND   A is a THEN  F is f
        db.AddRule(r35)#IF F is f  THEN  H is h
        db.AddRule(r36)#IF H is h  THEN  A is a
        #---------------------- Close Database

        db.Close()



