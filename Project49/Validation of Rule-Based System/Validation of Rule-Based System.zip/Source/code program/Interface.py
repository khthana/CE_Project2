import wx
import wx.grid
from   databaserule  import *
from   rule import *
from   checkrulebase import *


class DataRule:
    def __init__(self):
        self.database = DatabaseRule()
        self.data_rule = []
        self.data_object = []
        self.SetDataRule()

    def __del__(self):
        self.database.Close()

    def GetDataRule(self):
        return self.data_rule

    def GetDataObject(self):
        return self.data_object

    def SetDataRule(self):
        set_rule_id = self.database.GetAllRuleId()
        self.data_rule = self.SetData(set_rule_id)

    def SetDataObject(self):
        list_object_id = self.database.GetAllObjectId()
        self.data_object = []
        for object_id in list_object_id:
            data_object = self.GetEachObjectData(object_id)
            self.data_object.append(data_object)

    def GetEachObjectData(self, object_id):
        name = self.database.GetObjectNameFromObjectId(object_id)
        type_object = self.database.GetTypeVauleFromObjectId(object_id)
        list_value = self.database.GetSetValueFromObjectId(object_id)
        new_list = []
        for value in list_value:
            new_list.append(value[0])
        return [name, type_object, new_list]

    def SetData(self, list_rule_id):
        datarule = []
        for rule_id in list_rule_id:
            premise = self.database.GetClausePremiseFromId(rule_id)
            conclusion = self.database.GetClauseConclusionFromId(rule_id)
            name = rule_id
            premise_clause = []
            for clause in premise:
                premise_clause.append(self.Clause(clause[0]))
            conclusion_clause = self.Clause(conclusion[0][0])
            datarule.append([name, premise_clause, conclusion_clause])
        return datarule

    def Clause(self,clause_id):
        clause = self.database.GetClauseFromClauseId(clause_id)
        object_name = self.Object(clause[0])
        clause_string = "%s  %s  %s" % (object_name,clause[1],clause[2])
        return clause_string

    def Object(self,object_id):
        object_name = self.database.GetObjectNameFromObjectId(object_id)
        return object_name

    def RemoveRuleName(self, rule_name):
        self.database.DeleteRuleId(rule_name)
        self.database.Close()
        self.database = DatabaseRule()

    def SeparateDataClause(self, data_clause):
        list_word_data = data_clause.split()
        object_name = ""
        is_object_name = True
        value_name = ""
        operator_is_not = False
        for word_index in range(len(list_word_data)):
            if list_word_data[word_index] == 'is':
                is_object_name = False
                if list_word_data[word_index + 1] == 'not':
                    operator = 'is not'
                    operator_is_not = True
                else:
                    operator = 'is'
            else:
                if not operator_is_not:
                    if is_object_name == True:
                        object_name = object_name + list_word_data[word_index]+ " "
                    else:
                        value_name = value_name + list_word_data[word_index] + " "
                else:
                    operator_is_not = False
        return object_name[:-1], operator, value_name[:-1]

    def GetListOperator(self, type_operator):
        if type_operator == "Set Value":
            return ["is", "is not"]
        if type_operator == "Set Number":
            return ["=", "<>", ">", ">=", "<", "<="]

    def GetClauseIdFromDataClause(self, data_clause):
        data_clause = self.SeparateDataClause(data_clause)
        object_name =  "%s" % str(data_clause[0])
        operator = "%s" % str(data_clause[1])
        value = "%s" % str(data_clause[2])
        object_id = self.database.GetObjectIdFromObjectName(object_name)
        clause_id = self.database.GetClauseIdFromData(object_id, operator, value)
        return  clause_id

    def GetClauseFromDataClause(self, data_clause_new):
        data_clause = self.SeparateDataClause(data_clause_new)
        object_name = "%s" % str(data_clause[0])
        operator    = "%s" % str(data_clause[1])
        value       = "%s" % str(data_clause[2])
        object_id   = self.database.GetObjectIdFromObjectName(object_name)
        object_type = self.database.GetTypeVauleFromObjectId(object_id)
        new_object  = Object(object_name, object_type)
        new_clause  = Clause(new_object, operator, value)
        return new_clause

    def UpdateDataClause(self, rule_id, data_clause_old, data_clause_new, is_premise):
        clause_id     = self.GetClauseIdFromDataClause(data_clause_old)
        clause_id_new = self.GetClauseIdFromDataClause(data_clause_new)
        data_clause   = self.SeparateDataClause(data_clause_new)
        object_name = "%s" % str(data_clause[0])
        operator    = "%s" % str(data_clause[1])
        value       = "%s" % str(data_clause[2])
        object_id = self.database.GetObjectIdFromObjectName(object_name)
        self.database.DeleteClauseIdTableRelationClause(clause_id)
        self.database.Close()
        self.database = DatabaseRule()
        if clause_id_new == None:
            new_clause = self.GetClauseFromDataClause(data_clause_new)
            clause_id_new   = self.database.AddClause(new_clause)
            self.database.Close()
            self.database = DatabaseRule()
        self.database.AddClauseToRelationTable(clause_id_new, object_id, operator, value)
        self.database.Close()
        self.database = DatabaseRule()
        if is_premise:
            self.database.UpdateRulePremise(rule_id, clause_id, clause_id_new)
            self.database.Close()
            self.database = DatabaseRule()
            self.database.DeleteClauseId(clause_id)
            self.database.Close()
            self.database = DatabaseRule()
        else:
            self.database.UpdateRuleConclusion(rule_id, clause_id, clause_id_new)
            self.database.Close()
            self.database = DatabaseRule()
            self.database.DeleteClauseId(clause_id)
            self.database.Close()
            self.database = DatabaseRule()
            
    def UpdateDataRuleDeleteClause(self, rule_id, clause_id):
        data_rule = self.SetData([rule_id])
        list_premise = data_rule[0][1]
        if len(list_premise) == 1:
            self.RemoveRuleName(rule_id)
        else:
            self.database.UpdateRuleDeletePremiseClause(rule_id, clause_id)
        self.database.Close()
        self.database = DatabaseRule()

    def DataRuleDeleteClause(self, rule_id, data_clause):
        clause_id = self.GetClauseIdFromDataClause(data_clause)
        self.UpdateDataRuleDeleteClause(rule_id, clause_id)

    def DataAddNewRule(self, data_rule):
        data_premise = data_rule[1][0]
        data_conclusion = data_rule[2]
        new_clause_premise = self.GetClauseFromDataClause(data_premise)
        new_clause_conclusion = self.GetClauseFromDataClause(data_conclusion)
        new_rule = Rule(new_clause_premise, new_clause_conclusion)
        rule_id = self.database.AddRule(new_rule)
        self.database.Close()
        self.database = DatabaseRule()
        return rule_id

    def DataAddNewClauseToRule(self, rule_id, data_clause):
        clause_id_new = self.GetClauseIdFromDataClause(data_clause)
        if clause_id_new == None:
            new_clause = self.GetClauseFromDataClause(data_clause)
            clause_id_new   = self.database.AddClause(new_clause)
            self.database.Close()
            self.database = DatabaseRule()
        self.database.AddRuleClausePremiseToTable(rule_id, [clause_id_new])
        self.database.Close()
        self.database = DatabaseRule()

    def DataAddNewObject(self, data_object):
        name = data_object[0]
        type_object = data_object[1]
        list_value = data_object[2]
        object_new = Object(name, type_object)
        for value in list_value:
            object_new.AddValueToSetOfObject(value)
        self.database.AddObjectToTable(object_new)
        self.database.Close()
        self.database = DatabaseRule()

    def IsDataCanRemove(self, data):
        object_name = data[0]
        object_id   = self.database.GetObjectIdFromObjectName(object_name)
        if not self.database.IsObjectUseInClause(object_id):
            self.database.DeleteObjectId(object_id)
            self.database.Close()
            self.database = DatabaseRule()
            print "c"
            return True
        else:
            print "x"
            return False

    def UpdateAddGoalClause(self, data_clause):
        clause = self.GetClauseFromDataClause(data_clause)
        self.database.AddGoal(clause)
        self.database.Close()
        self.database = DatabaseRule()

    def UpdateAddObjectToQuery(self, data_clause):
        clause_data = self.SeparateDataClause(data_clause)
        object_name = "%s" % str(clause_data[0])
        object_id = self.database.GetObjectIdFromObjectName(object_name)
        object_type = self.database.GetTypeVauleFromObjectId(object_id)
        new_object  = Object(object_name, object_type)
        self.database.AskableObject(new_object)
        self.database.Close()
        self.database = DatabaseRule()
        
            
class Frame(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title = title, size = (600,600),
                          style = wx.DEFAULT_FRAME_STYLE^(wx.MAXIMIZE_BOX|wx.RESIZE_BORDER))
        self.data = DataRule()
        all_rule_data_list = self.data.GetDataRule()
        all_rule_data_list.insert(0,["SHOW   ALL   RULE"])
        self.MakeMenuBar()
        self.validate = CheckRulebase()
        self.font = wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD)
        self.grid_validation =  GridRule(self)
        self.gridrule =  GridRule(self)
        self.gridrule.SetDataToGrid(all_rule_data_list)
        self.gridrule.Show(False)
        self.have_validation = False
        self.gridrule.SetDependOtherGrid(self.grid_validation)
        self.grid_validation.SetDependOtherGrid(self.gridrule)
        self.object_grid = GridObject(self)
        self.object_grid.Show(False)
        self.grid_validation.Show(False)
        self.object_grid.Show(True)

    def Conflict(self):
        non_line = []
        conflict_result = self.validate.CheckConflict()
        conflict_flag = True
        title = "SHOW   CONFLICTION   RULE"
        data_conflict_grid = []
        data_conflict_grid.append([title])
        for list_data in conflict_result:
            header_rule_conflict = ""
            list_data_rule =  self.data.SetData(list(list_data))
            for index_data in range(len(list_data_rule)):
                if index_data == 0:
                    header_rule_conflict = header_rule_conflict + list_data_rule[index_data][0]
                else:
                    if index_data == len(list_data_rule) - 1:
                        header_rule_conflict = header_rule_conflict + " AND " +list_data_rule[index_data][0]
                    else:
                        header_rule_conflict = header_rule_conflict + ", " +list_data_rule[index_data][0]
            data_conflict_grid.append([header_rule_conflict])
            for data_rule in list_data_rule:
                data_conflict_grid.append(data_rule)
            data_conflict_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_conflict_grid)
        return data_conflict_grid

    def Circular(self):
        non_line = []
        title = "SHOW   CIRCULAR   RULE"
        circular_result = self.validate.CheckCircular()
        data_circular_grid = []
        data_circular_grid.append([title])
        for list_data in circular_result:
            header_rule_circular = ""
            list_data_rule =  self.data.SetData(list_data)
            for index_data in range(len(list_data_rule)):
                if index_data == 0:
                    header_rule_circular = header_rule_circular + list_data_rule[index_data][0]
                else:
                    if index_data == len(list_data_rule) - 1:
                        header_rule_circular = header_rule_circular + " -> " +list_data_rule[index_data][0]
                    else:
                        header_rule_circular = header_rule_circular + " -> " +list_data_rule[index_data][0]
            data_circular_grid.append([header_rule_circular])
            for data_rule_index in range(len(list_data_rule) - 1):#not use element last
                data_circular_grid.append(list_data_rule[data_rule_index])
            data_circular_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_circular_grid)

    def ValidationByHand(self):
        data_conflict_grid = self.Conflict()
        if len(data_conflict_grid) == 1:
            self.Circular()

    def Redundant(self):
        non_line = []
        data_redundant_grid = []
        list_remove_rule = []
        title = "SHOW   REDUNDANT   RULE"
        data_redundant_grid.append([title])
        redundant_result = self.validate.CheckRedundant()
        for list_data in redundant_result:
                header_rule_redundant = ""
                list_data_rule =  self.data.SetData(list(list_data))
                for index_data in range(len(list_data_rule)):
                    if index_data == 0:
                        header_rule_redundant = header_rule_redundant + list_data_rule[index_data][0]
                    else:
                        if index_data == len(list_data_rule) - 1:
                            header_rule_redundant = header_rule_redundant + " AND " +list_data_rule[index_data][0]
                        else:
                            header_rule_redundant = header_rule_redundant + ", " +list_data_rule[index_data][0]
                data_redundant_grid.append([header_rule_redundant])
                list_remove = ""
                for data_rule_index in range(len(list_data_rule)):
                    if not data_rule_index == 0:
                        list_remove = list_remove + list_data_rule[data_rule_index][0] + ", "
                        list_remove_rule.append(list_data_rule[data_rule_index][0])
                    data_redundant_grid.append(list_data_rule[data_rule_index])
                string_remove = "REMOVE  RULE   %s" % (list_remove[:-2])
                data_redundant_grid.append([string_remove])
                data_redundant_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_redundant_grid)
        list_remove_rule = set(list_remove_rule)
        for rule_id in list_remove_rule:
            data = self.data.SetData([rule_id])
            self.grid_validation.UpdateOtherGrid(self.gridrule, data[0])
            self.data.RemoveRuleName(rule_id)
        if list_remove_rule:
            return False
        else:
            return True

    def Subsume(self):
        non_line = []
        data_subsume_grid = []
        set_remove_rule = set([])
        title = "SHOW   SUBSUMED   RULE"
        data_subsume_grid.append([title])
        subsume_result = self.validate.CheckSubsume()
        for list_data in subsume_result:
            header_rule_subsume = ""
            list_data_rule =  self.data.SetData(list(list_data[1]))
            for index_data in range(len(list_data_rule)):
                if index_data == 0:
                    header_rule_subsume = header_rule_subsume + list_data_rule[index_data][0]
                else:
                    if index_data == len(list_data_rule) - 1:
                        header_rule_subsume = header_rule_subsume + " AND " +list_data_rule[index_data][0]
                    else:
                        header_rule_subsume = header_rule_subsume + ", " +list_data_rule[index_data][0]
            header_rule_subsume = header_rule_subsume + " SUBSUME BY "  +  list_data[0]  
            data_subsume_grid.append([header_rule_subsume])
            string_remove = "REMOVE  RULE "
            data_subsume_grid.append([string_remove])
            for data_rule_index in range(len(list_data_rule)):
                set_remove_rule.add(list_data_rule[data_rule_index][0])
                data_subsume_grid.append(list_data_rule[data_rule_index])
            rule_subsume = self.data.SetData([list_data[0]])
            string_subsume = "SUBSUME  BY  RULE   %s" % rule_subsume[0][0]
            data_subsume_grid.append([string_subsume])
            data_subsume_grid.append(rule_subsume[0])
            data_subsume_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_subsume_grid)
        for rule_id in set_remove_rule:
            data = self.data.SetData([rule_id])
            self.grid_validation.UpdateOtherGrid(self.gridrule, data[0])
            self.data.RemoveRuleName(rule_id)

    def UnnecessaryPremise(self):
        non_line = []
        data_unnecessary_grid = []
        set_remove_rule = set([])
        list_rule_remove_clause = []
        title = "SHOW   UNNECESSARY   PREMISE   CLAUSE   RULE"
        data_unnecessary_grid.append([title])
        unnecessary_result = self.validate.CheckUnnecessaryPremise()
        for list_data in unnecessary_result:
            header_rule_unnecessary = ""
            list_data_rule =  self.data.SetData(list(list_data[1]))
            for index_data in range(len(list_data_rule)):
                if index_data == 0:
                    header_rule_unnecessary = header_rule_unnecessary + list_data_rule[index_data][0]
                else:
                    if index_data == len(list_data_rule) - 1:
                        header_rule_unnecessary = header_rule_unnecessary + " AND " +list_data_rule[index_data][0]
                    else:
                        header_rule_unnecessary = header_rule_unnecessary + ", " +list_data_rule[index_data][0]
            header_rule_unnecessary = list_data[0] + " UNNECESSARY PREMISE CLAUSE WITH RULE "  +  header_rule_unnecessary
            data_unnecessary_grid.append([header_rule_unnecessary])
            rule_necessary = self.data.SetData([list_data[0]])
            set_remove_rule.add(list_data[0])
            string_necessary = "REMOVE  RULE   %s" % rule_necessary[0][0]
            data_unnecessary_grid.append([string_necessary])
            data_unnecessary_grid.append(rule_necessary[0])
            string_remove = "UNNECESSARY PREMISE CLAUSE WITH RULE "
            data_unnecessary_grid.append([string_remove])
            for data_rule_index in range(len(list_data_rule)):
                data_unnecessary_grid.append(list_data_rule[data_rule_index])
                for rule_clause in list_data[2]:
                    if not rule_clause in list_rule_remove_clause:
                        list_rule_remove_clause.append(rule_clause)
                    rule_name = rule_clause[0]
                    clause_id = rule_clause[1]
                    if rule_name == list_data_rule[data_rule_index][0]:
                        string_clause_remove = "REMOVE  PREMISE  CLAUSE :  %s  IN RULE  %s" % (
                            self.data.Clause(clause_id), rule_name)
                        data_unnecessary_grid.append([string_clause_remove])
                data_unnecessary_grid.append(non_line)  
            data_unnecessary_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_unnecessary_grid)
        for rule_clause_id in  list_rule_remove_clause:
            data = self.data.SetData([rule_clause_id[0]])
            data_clause = self.data.Clause(rule_clause_id[1])
            if len(data[0][1]) == 1:
                self.grid_validation.UpdateOtherGrid(self.gridrule, data[0])
                self.data.RemoveRuleName(rule_clause_id[0])
                break 
            index = data[0][1].index(data_clause)
            data = [data[0], index+1]
            self.grid_validation.UpdateOtherGridClauseDelete(self.gridrule, data, data_clause)
            self.data.UpdateDataRuleDeleteClause(
                             rule_clause_id[0], rule_clause_id[1])
        for rule_id in set_remove_rule:
            data = self.data.SetData([rule_id])
            self.grid_validation.UpdateOtherGrid(self.gridrule, data[0])
            self.data.RemoveRuleName(rule_id)

    def UnachieveIntermediateConclusions(self):
        non_line = []
        data_intermediate_grid = []
        set_remove_rule = set([])
        list_rule_remove_clause = []
        title = "SHOW   UNACHIEVABLE   INTERMEDIATE   CONCLUSIONS"
        data_intermediate_grid.append([title])
        intermediate_result = self.validate.CheckUnachievableIntermediateConclusion()
        list_data_rule =  self.data.SetData(intermediate_result)
        for data_rule_index in range(len(list_data_rule)):
            data_intermediate_grid.append(list_data_rule[data_rule_index])
        self.grid_validation.SetDataToGrid(data_intermediate_grid)

    def UnachieveFinalConclusion(self):
        non_line = []
        data_final_grid = []
        set_remove_rule = set([])
        list_rule_remove_clause = []
        title = "SHOW   UNACHIEVABLE   FINAL(GOAL)   CONCLUSIONS"
        data_final_grid.append([title])
        final_result = self.validate.CheckUnachievableGoal()
        for data in final_result:
            list_data_rule =  self.data.SetData([data[0]])
            for data_rule_index in range(len(list_data_rule)):
                data_final_grid.append(list_data_rule[data_rule_index])
        self.grid_validation.SetDataToGrid(data_final_grid)

    def UnachievePremise(self):
        non_line = []
        data_premise_grid = []
        set_remove_rule = set([])
        list_rule_remove_clause = []
        title = "SHOW   UNACHIEVABLE   PREMISE"
        data_premise_grid.append([title])
        premise_result = self.validate.CheckUnachievablePremise()
        for data in premise_result:
            list_data_rule =  self.data.SetData([data[0]])
            for data_rule_index in range(len(list_data_rule)):
                data_premise_grid.append(list_data_rule[data_rule_index])
            for clause in data[1]:
                data_clause = self.data.Clause(clause)
                string_clause_premise = "UNACHIEVABLE  PREMISE  CLAUSE :  %s  IN RULE  %s" % (
                            data_clause, data[0])
                data_premise_grid.append([string_clause_premise])
            data_premise_grid.append(non_line)
        self.grid_validation.SetDataToGrid(data_premise_grid)
        
    def ValidationAuto(self):
        self.Redundant()
        self.Subsume() 
        self.UnnecessaryPremise()
        self.UnachieveIntermediateConclusions()
        self.UnachieveFinalConclusion()
        self.UnachievePremise()

    def ValidationDisplay(self):
        self.object_grid.Show(False)
        self.gridrule.Show(False)
        self.grid_validation.Show(True)
                
    def DataMenuBar(self):
        listmenufile = [["&Open", self.MenuFileOpen],
                       ["&Save", self.MenuFileSave],
                       [None,None],
                       ["E&xit", self.MenuExit]]
        listmenuview = [["&Rule", self.MenuViewRule],
                       ["&Object", self.MenuViewObject]]
        listmenuvalidation = [["&Validation",self.MenuVailation]]

        listmenuhelp = [["He&lp",self.MenuHelpHelp],
                        ["&About",self.MenuHelpAbout]]               
        return [["&File",listmenufile],["V&iew",listmenuview],
                ["&Validation",listmenuvalidation],["&Help",listmenuhelp]] 
    
    def MakeMenuBar(self):
        menubar = wx.MenuBar()
        for datamenu in self.DataMenuBar():
            menu = self.CreateMenu(datamenu[1])
            menubar.Append(menu,datamenu[0])
        self.SetMenuBar(menubar)

    def CreateMenu(self ,listmenu):
        menu = wx.Menu()
        for data_list_menu in listmenu:
            if not data_list_menu[0]:
                menu.AppendSeparator()
                continue
            if data_list_menu[0] == "&Validation":
                submenu = wx.Menu()
                menu_r = submenu.Append(-1, "Redundant")
                menu_c = submenu.Append(-1, "Conflict")
                menu_s = submenu.Append(-1, "Subsumed")
                menu_upr = submenu.Append(-1, "Unnecessay Premise")
                menu_crc = submenu.Append(-1, "Circular Rule Chain")
                menu_uic = submenu.Append(-1, "Unachivable Intermidate Conclusions")
                menu_ufc = submenu.Append(-1, "Unachivable Final Conclusions")
                menu_up = submenu.Append(-1, "Unachivable Premise")
                menu_item = menu.AppendMenu(-1,"&Validation Manual",submenu)
                self.Bind(wx.EVT_MENU, self.MenuRedundant, menu_r)
                self.Bind(wx.EVT_MENU, self.MenuConflict, menu_c)
                self.Bind(wx.EVT_MENU, self.MenuSubsumed, menu_s)
                self.Bind(wx.EVT_MENU, self.MenuUnnecessayPremise, menu_upr)
                self.Bind(wx.EVT_MENU, self.MenuCircular, menu_crc)
                self.Bind(wx.EVT_MENU, self.MenuUnachivableIntermidateConclusions, menu_uic)
                self.Bind(wx.EVT_MENU, self.MenuUnachivableFinalConclusions, menu_ufc)
                self.Bind(wx.EVT_MENU, self.MenuUnachivablePremise, menu_up)
            else:
                menu_item = menu.Append(-1,data_list_menu[0])
                self.Bind(wx.EVT_MENU, data_list_menu[1], menu_item)
        return menu
        
    def MenuFileOpen(self):
        pass

    def MenuFileSave(self):
        pass

    def MenuViewRule(self, event):
        self.grid_validation.Show(False)
        self.object_grid.Show(False)
        self.gridrule.Show(True)

    def MenuViewObject(self, event):
        self.grid_validation.Show(False)
        self.gridrule.Show(False)
        self.object_grid.Show(True)

    def MenuVailation(self, event):
        self.object_grid.Show(False)
        self.gridrule.Show(False)
        #self.ValidationByHand()
        self.ValidationAuto()
        self.grid_validation.Show(True)

    def MenuRedundant(self, event):
        self.Redundant()
        self.ValidationDisplay()

    def MenuConflict(self, event):
        self.Conflict()
        self.ValidationDisplay()

    def MenuSubsumed(self, event):
        self.Subsume()
        self.ValidationDisplay()

    def MenuUnnecessayPremise(self, event):
        self.UnnecessaryPremise()
        self.ValidationDisplay()

    def MenuCircular(self, event):
        self.Circular()
        self.ValidationDisplay()

    def MenuUnachivableIntermidateConclusions(self, event):
        self.UnachieveIntermediateConclusions()
        self.ValidationDisplay()

    def MenuUnachivableFinalConclusions(self, event):
        self.UnachieveFinalConclusion()
        self.ValidationDisplay()

    def MenuUnachivablePremise(self, event):
        self.UnachievePremise()
        self.ValidationDisplay()

    def MenuHelpHelp(self):
        pass

    def MenuHelpAbout(self):
        pass
    
    def MenuExit(self, event):
        self.Destroy()


class GridRule(wx.grid.Grid):
    def __init__(self, parent):
        self.parent = parent
        wx.grid.Grid.__init__(self, self.parent, size = (595,570), style = wx.VSCROLL)
        self.SetColLabelSize(0)
        self.SetRowLabelSize(0)
        self.CreateGrid(0,4)
        self.SetColSize(0, 35)
        self.SetColSize(1, 255)
        self.SetColSize(2, 35)
        self.SetColSize(3, 255)
        attrc = wx.grid.GridCellAttr()
        attrc.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.SetColAttr(2, attrc)
        self.SetColAttr(0, attrc)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_CLICK, self.RightClick)
        self.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK, self.LeftDoubleClick)
        self.list_row_rule = []
        self.lenght_row_rule = []
        self.rule_del_data = 0
        self.rule_edit_data = 0
        self.rule_clause_del_data = 0
        self.datalist = []
        self.list_row_data = []
        self.other_grid_depend = None
        self.clause_edit = None
        self.clause_del = None
        self.row = 0
        self.current_row_col_rule = [0, 0]

    def SetDependOtherGrid(self, grid):
        self.other_grid_depend = grid

    def SetDataList(self, data_list):
        self.datalist = data_list

    def GetDataList(self):
        return self.datalist
    
    def GetRowDataList(self):
        return self.list_row_data

    def SetRowDataList(self, data_list):
        self.list_row_data = data_list

    def SetDataRuleDelete(self, data):
        self.rule_del_data = data

    def SetDataRuleEdit(self, data):
        self.rule_edit_data = data

    def SetDataRuleClauseDelete(self, data):
        self.rule_clause_del_data = data

    def SetClauseEdit(self, clause):
        self.clause_edit = clause

    def SetClauseDelete(self, clause):
        self.clause_del = clause

    def SetCurrentRowCol(self, Row_Col):
        self.current_row_col_rule = Row_Col

    def GetDataRuleDelete(self):
        return self.rule_del_data

    def GetDataRuleEdit(self):
        return self.rule_edit_data

    def GetDataRuleClauseDelete(self):
        return self.rule_clause_del_data

    def GetClauseEdit(self):
        return self.clause_edit
    
    def GetClauseDelete(self):
        return self.clause_del
        
    def GetRowRule(self):
        return self.list_row_rule

    def GetLenghtRule(self):
        return self.lenght_row_rule

    def GetCurrentRowCol(self):
        return self.current_row_col_rule
    
    def AppendRowDataList(self, row):
        self.list_row_data.append(row)

    def AppendRowRule(self, row):
        self.list_row_rule.append(row)

    def AppendLenghtRule(self, lenght):
        self.lenght_row_rule.append(lenght)

    def UpdateListRow(self, row_list, row, deta):
        for value in range(len(row_list)):
            if row_list[value] > row :
                row_list[value] = row_list[value] - deta

    def GetDataList(self):
        return self.datalist

    def SetDataToGrid(self, data_list):
        self.SetDataList(data_list)
        if self.row <> 0:
            self.DeleteRows(0, self.row, True)
        self.row = 0
        self.SetRowDataList([])
        for data in data_list:
            self.AppendRowDataList(self.row)
            if len(data) == 0:
                self.InsertRows(self.row, 1,True)
                self.SetCellSize(self.row,0,1,4)
                self.row = self.row + 1
            else:
                if len(data) == 1:
                    self.SetTitle(self.row, data[0])
                    self.row = self.row + 1
                else:
                    self.AppendRowRule(self.row)
                    self.AppendLenghtRule(len(data[1]))
                    self.row = self.AddDataRuleToGrid(self.row, data)

    def SetTitle(self, row,  text):
        attr = wx.grid.GridCellAttr()
        attr.SetBackgroundColour(wx.Colour(220, 220, 220))
        attr.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.InsertRows(row, 1, True)
        self.SetReadOnly(row, 0, True)
        self.SetReadOnly(row, 1, True)
        self.SetReadOnly(row, 2 ,True)
        self.SetReadOnly(row, 3, True)
        self.SetCellValue(row, 0, text)
        self.SetCellSize(row, 0, 1, 4)
        self.SetRowAttr(row, attr)

    def AddDataRuleToGrid(self, row, data):
        name_rule = data[0]
        premise_clause    = data[1]
        conclusion_clause = data[2]
        number_line_use   = len(premise_clause) + 1
        for line in range(number_line_use):
            if line == 0:
                self.SetTitle(row, name_rule)
            else:
                self.InsertRows(row, 1, True)
                attr1 = wx.grid.GridCellAttr()
                attr1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
                self.SetReadOnly(row, 0, True)
                self.SetReadOnly(row, 1, True)
                self.SetReadOnly(row, 2, True)
                self.SetReadOnly(row, 3, True)
                if line == 1:
                    self.SetCellValue(row,0,"IF")
                    self.SetCellAlignment(row, 0, wx.RIGHT, -1)
                    self.SetCellSize(row,  2, number_line_use-1, 1)
                    self.SetCellValue(row, 2, "THEN")
                    self.SetCellSize(row,  3, number_line_use-1, 1)
                    self.SetCellValue(row, 1, premise_clause[0])
                    self.SetCellValue(row, 3, conclusion_clause)
                else:
                    self.SetCellValue(row, 0, "AND")
                    self.SetCellValue(row, 1, premise_clause[line - 1])
            row = row + 1
        self.InsertRows(row, 1, True)
        self.SetCellSize(row, 0, 1, 4)
        row = row + 1
        return row

    def IsCanEditCell(self, row, col):
        index_use = len(self.GetRowRule()) - 1
        for row_index in range(len(self.GetRowRule())):
            if row < self.GetRowRule()[row_index]:
                index_use = row_index - 1
                break
        row_ref = self.GetRowRule()[index_use]
        index_data = self.GetRowDataList().index(row_ref)
        data = self.GetDataList()[index_data]
        self.SetDataRuleEdit([data, col, (row - row_ref)])
        rule_lenght =  self.GetLenghtRule()[index_use]
        if (row - row_ref) <= rule_lenght and \
           (col == 1 or col == 3):
            return True
        else:
            return False

    def IsCanDeleteClauseCell(self, row, col):
        index_use = len(self.GetRowRule()) - 1
        for row_index in range(len(self.GetRowRule())):
            if row < self.GetRowRule()[row_index]:
                index_use = row_index - 1
                break
        row_ref = self.GetRowRule()[index_use]
        index_data = self.GetRowDataList().index(row_ref)
        data = list(self.GetDataList()[index_data])
        self.SetDataRuleClauseDelete([data, (row - row_ref)])
        rule_lenght =  self.GetLenghtRule()[index_use]
        if rule_lenght == 1:
            return False
        else:
            if (row - row_ref) <= rule_lenght and col == 1:
                return True
            else:
                return False

    def UpdateDataClause(self, row, col, new_data_clause):
        data_clause = self.GetClauseEdit()
        save_index = len(self.GetRowRule()) - 1
        for index_rule in range(len(self.GetRowRule())):
            if self.GetRowRule()[index_rule] > row:
                save_index = index_rule - 1        
                break
        row_rule = self.GetRowRule()[save_index]
        index_data = self.GetRowDataList().index(row_rule)
        data = self.GetDataList()[index_data]
        rule_id = data[0]
        if rule_id == "NEW RULE":
            if col == 1:
                data[1][0] = new_data_clause
                data[3] = True
            else:
                data[2] = new_data_clause
                data[4] = True
            if data[3] == True and data[4] == True:
                data.remove(True)
                data.remove(True)
                rule_id = self.parent.data.DataAddNewRule(data)
                self.SetCellValue(row - 1, 0, rule_id)
                self.GetDataList()[index_data][0] = rule_id
        else:
            is_in_premise = False
            if col == 1:
                is_in_premise = True
            self.parent.data.UpdateDataClause(rule_id, data_clause, new_data_clause, is_in_premise)

    def RightClick(self, event):
        row = event.GetRow()
        col = event.GetCol()
        self.SetGridCursor(row, col)
        if (row in self.GetRowRule()) or row == 0:
            self.popupID2 = wx.NewId()
            menu = wx.Menu()
            index_data = self.GetRowDataList().index(row)
            data = self.GetDataList()[index_data]
            self.SetDataRuleDelete(data)
            self.SetCurrentRowCol([row,col])
            if row <> 0:
                self.popupID1 = wx.NewId()
                self.Bind(wx.EVT_MENU, self.OnPopupDelete, id=self.popupID1)
                item = wx.MenuItem(menu, self.popupID1, "Delete This Rule")
                menu.AppendItem(item)
            item_add_rule = wx.MenuItem(menu, self.popupID2, "Add New Rule")
            self.Bind(wx.EVT_MENU, self.OnPopupAddNewRule, id=self.popupID2)
            menu.AppendItem(item_add_rule)
            self.PopupMenu(menu)
            menu.Destroy()
        else:
            menu = wx.Menu()
            if self.IsCanEditCell(row, col):
                data_clause = self.GetCellValue(row, col)
                self.SetClauseEdit(data_clause)
                self.popupID1 = wx.NewId()
                self.popupID2 = wx.NewId()
                self.popupID3 = wx.NewId()
                self.Bind(wx.EVT_MENU, self.OnPopupEdit, id = self.popupID1)
                item = wx.MenuItem(menu, self.popupID1, "Edit Clause")
                item_object_query = False
                if col == 1:
                    self.Bind(wx.EVT_MENU, self.OnPopupAddClause, id = self.popupID2)
                    item_new_clause = wx.MenuItem(menu, self.popupID2, "Add Clause")
                    self.Bind(wx.EVT_MENU, self.OnPopupAddObjectQuery, id = self.popupID3)
                    item_object_query = wx.MenuItem(menu, self.popupID3, "Add Object in Clause to Query")
                else:
                    self.Bind(wx.EVT_MENU, self.OnPopupAddGoalClause, id = self.popupID2)
                    item_new_clause = wx.MenuItem(menu, self.popupID2, "Add Goal Clause")
                menu.AppendItem(item)
                menu.AppendItem(item_new_clause)
                if item_object_query:
                    menu.AppendItem(item_object_query)
            if self.IsCanDeleteClauseCell(row, col):
                data_clause = self.GetCellValue(row, col)
                self.SetClauseDelete(data_clause)
                self.popupID2 = wx.NewId()
                self.Bind(wx.EVT_MENU, self.OnPopupDeleteClause, id = self.popupID2)
                item = wx.MenuItem(menu, self.popupID2, "Delete Clause")
                menu.AppendItem(item)
            self.PopupMenu(menu)
            menu.Destroy() 

    def LeftDoubleClick(self, event):
        row = event.GetRow()
        col = event.GetCol()
        self.SetGridCursor(row, col)
        if self.IsCanEditCell(row, col):
            self.SetReadOnly(row, col, False)
            
    def OnPopupDelete(self, event):
        self.DeleteRuleDisplay() 
        rule_name = self.GetDataRuleDelete()[0]
        self.parent.data.RemoveRuleName(rule_name)
        data_update = self.GetDataRuleDelete()
        self.UpdateOtherGrid(self.other_grid_depend, data_update)

    def OnPopupAddNewRule(self,  event):
        self.DisplayNewRule()

    def OnPopupEdit(self, event):
        data_clause = self.GetClauseEdit()
        dialog_clause = ClauseDialog(self.parent, data_clause)
        result = dialog_clause.ShowModal()
        if result == wx.ID_OK:
            new_data_clause = dialog_clause.GetValue()
            col = self.GetGridCursorCol()
            row = self.GetGridCursorRow()
            self.EditRuleDisplay(new_data_clause)
            self.UpdateDataClause(row, col, new_data_clause)
            self.UpdateOtherGridEdit(self.other_grid_depend, new_data_clause)
            dialog_clause.Destroy()
            return 0
        dialog_clause.Destroy()

    def OnPopupAddClause(self, ecent):
        data_clause = "0 is 0" 
        dialog_clause = ClauseDialog(self.parent, data_clause)
        result = dialog_clause.ShowModal()
        if result == wx.ID_OK:
            new_data_clause = dialog_clause.GetValue()
            col = self.GetGridCursorCol()
            row = self.GetGridCursorRow()
            rule_id,data_clause = self.DisplayAddNewClauseRule(row, col, new_data_clause)
            self.parent.data.DataAddNewClauseToRule(rule_id, data_clause)
            dialog_clause.Destroy()
            return 0
        dialog_clause.Destroy()
        col = self.GetGridCursorCol()
        row = self.GetGridCursorRow()
        self.SetCellValue(row, col, data_clause)

    def OnPopupAddGoalClause(self, event):
        data_clause = self.GetClauseEdit()
        self.parent.data.UpdateAddGoalClause(data_clause)

    def OnPopupAddObjectQuery(self, event):
        data_clause = self.GetClauseEdit()
        self.parent.data.UpdateAddObjectToQuery(data_clause)

    def OnPopupDeleteClause(self, event):
        self.DeleteClauseRuleDisplay()
        data = list(self.GetDataRuleClauseDelete())
        data_clause = self.GetClauseDelete()
        data[0][1].insert(data[1]-1, str(data_clause))
        rule_id = data[0][0]
        self.parent.data.DataRuleDeleteClause(rule_id, data_clause)
        self.UpdateOtherGridClauseDelete(self.other_grid_depend, data, data_clause)
        data[0][1].remove(data[0][1][data[1]-1]) 
        
    def DeleteRuleDisplay(self):
        while self.GetDataRuleDelete() in self.GetDataList():
            index_data = self.GetDataList().index(self.GetDataRuleDelete())
            row = self.GetRowDataList()[index_data]
            index_rule = self.GetRowRule().index(row)
            lenght_row = self.GetLenghtRule()[index_rule]
            self.DeleteRows(row, lenght_row + 2, True)
            self.UpdateListRow(self.GetRowRule(), row, lenght_row + 2)
            self.UpdateListRow(self.GetRowDataList(), row, lenght_row + 2)
            self.GetDataList().remove(self.GetDataRuleDelete())
            self.GetRowDataList().remove(row)
            self.GetRowRule().remove(row)
            self.GetLenghtRule()[index_rule] = -1
            self.GetLenghtRule().remove(-1)

    def DisplayNewRule(self):
        new_data_rule = ["NEW RULE", ["0 is 0"], "0 is 0", False, False]
        row = self.GetCurrentRowCol()[0]
        col = self.GetCurrentRowCol()[1]
        if row <>  0 or len(self.GetDataList()) <> 1:
            if row == 0:
                row = 1
            index_data = self.GetRowDataList().index(row)
            self.GetDataList().insert(index_data, new_data_rule)
            index_rule = self.GetRowRule().index(row)
            self.UpdateListRow(self.GetRowRule(), row - 1, -3)
            self.UpdateListRow(self.GetRowDataList(), row - 1, -3)
            self.GetRowDataList().insert(index_data, row)
            self.GetRowRule().insert(index_rule, row)
            self.GetLenghtRule().insert(index_rule, 1)
            self.AddDataRuleToGrid(row, new_data_rule)
        else:
            self.GetDataList().append(new_data_rule)
            self.GetRowRule().append(1)
            self.GetRowDataList().append(1)
            self.GetLenghtRule().append(1)
            self.AddDataRuleToGrid(1, new_data_rule)

    def EditRuleDisplay(self, new_data_clause):
        col = self.GetDataRuleEdit()[1]
        inc_row = self.GetDataRuleEdit()[2]
        data_clause = self.GetClauseEdit()
        for data_list_index in range(len(self.GetDataList())):
            rule_mane = self.GetDataRuleEdit()[0][0]
            if len(self.GetDataList()[data_list_index]) <= 1:
                continue
            if self.GetDataList()[data_list_index][0] == rule_mane:
                row = self.GetRowDataList()[data_list_index]
                if col == 3:
                    self.GetDataList()[data_list_index][2] = new_data_clause
                if col == 1:
                    for data in self.GetDataList()[data_list_index][1]:
                        if data == data_clause:
                            index = self.GetDataList()[data_list_index][1].index(data)
                            self.GetDataList()[data_list_index][1][index] = new_data_clause
                self.SetCellValue(row + inc_row, col, new_data_clause)

    def DisplayAddNewClauseRule(self, row, col, data_clause):
        save_index = len(self.GetRowRule()) - 1
        for index_rule in range(len(self.GetRowRule())):
            if self.GetRowRule()[index_rule] > row:
                save_index = index_rule - 1        
                break
        row_rule = self.GetRowRule()[save_index]
        inc_row = row - row_rule
        index_data = self.GetRowDataList().index(row_rule)
        data_rule = self.GetDataList()[index_data]
        rule_name = data_rule[0]
        for index_datalist in range(len(self.GetDataList())):
            if len(self.GetDataList()[index_datalist]) <= 1:
                continue
            rule_name_compare = self.GetDataList()[index_datalist][0]
            if rule_name_compare == rule_name:
                if len(self.GetDataList()[index_datalist][1]) == 0:
                    self.GetDataList()[index_datalist][1].append(data_clause)
                else:
                    self.GetDataList()[index_datalist][1].insert(inc_row, data_clause)
                row_rule_add = self.GetRowDataList()[index_datalist]
                row_index = self.GetRowRule().index(row_rule_add)
                self.InsertRows(row_rule_add + inc_row + 1, 1, True)
                self.SetCellValue(row_rule_add + inc_row + 1, 0, "AND")
                self.GetLenghtRule()[row_index] = self.GetLenghtRule()[row_index] + 1
                self.SetCellSize(row_rule_add + 1, 2,
                                 self.GetLenghtRule()[row_index], 1)
                self.SetCellSize(row_rule_add + 1, 3,
                                 self.GetLenghtRule()[row_index], 1)
                self.SetCellValue(row_rule_add + inc_row + 1, 1, data_clause)
                self.UpdateListRow(self.GetRowRule(), row_rule_add, -1)
                self.UpdateListRow(self.GetRowDataList(), row_rule_add, -1)
        return rule_name, data_clause

    def DeleteClauseRuleDisplay(self):
        data_rule = self.GetDataRuleClauseDelete()[0]
        list_premise = list(self.GetDataRuleClauseDelete()[0][1])
        lenght = len(list_premise)
        pos_premise =  self.GetDataRuleClauseDelete()[1]
        rule_mane = data_rule[0]
        for data_list_index in range(len(self.GetDataList())):
            if len(self.GetDataList()[data_list_index]) <= 1:
                continue
            if self.GetDataList()[data_list_index][0] == rule_mane:
                row = self.GetRowDataList()[data_list_index]
                for index_premise in range(lenght):
                    if pos_premise == index_premise + 1:
                        for index in range(lenght - pos_premise):
                            data = self.GetCellValue(row +index + pos_premise + 1, 1)
                            self.SetCellValue(row + index + pos_premise, 1, data)
                        break
                self.DeleteRows(row + lenght, 1, True)
                self.SetCellSize(row+1, 2, lenght - 1, 1)
                self.SetCellSize(row+1, 3, lenght - 1, 1)
                self.GetDataList()[data_list_index][1].remove(self.GetClauseDelete())
                index_lenght = self.GetRowRule().index(row)
                self.GetLenghtRule()[index_lenght] = self.GetLenghtRule()[index_lenght] - 1
                self.UpdateListRow(self.GetRowRule(), row, 1)
                self.UpdateListRow(self.GetRowDataList(), row, 1)

    def UpdateOtherGrid(self, grid, data):
        data = [data[0], data[1], data[2]]
        grid.SetDataRuleDelete(data)
        grid.DeleteRuleDisplay()

    def UpdateOtherGridEdit(self, grid, new_data_clause):
        data = self.GetDataRuleEdit()
        grid.SetDataRuleEdit(data)
        data_clause = self.GetClauseEdit()
        grid.SetClauseEdit(data_clause)
        grid.EditRuleDisplay(new_data_clause)

    def UpdateOtherGridClauseDelete(self, grid, data, data_clause):
        print data, data_clause
        grid.SetDataRuleClauseDelete(data)
        grid.SetClauseDelete(data_clause)
        grid.DeleteClauseRuleDisplay()


class ClauseDialog(wx.Dialog):
    def __init__(self, parent, data_clause):
        self.parent = parent
        wx.Dialog.__init__(self, parent, -1, 'Choose Clause', size=(500,150))
        self.SetBackgroundColour(wx.Colour(220, 220, 220))
        parent.data.SetDataObject()
        self.list_data_object = []
        if not data_clause == '0 is 0':
            object_defaut, opeator_defaut, value_defaut = \
                           parent.data.SeparateDataClause(data_clause)
        else:
            object_defaut = '0'
            opeator_defaut = 'is'
            value_defaut ='0'
        self.list_data_object = parent.data.GetDataObject()
        objectList = []
        operatorList = []
        valueList = []
        type_defaut = "Set Value"
        for object_data in self.list_data_object:
            objectList.append(object_data[0])
            if object_data[0].split() == object_defaut.split():
                type_defaut = object_data[1]
                valueList = object_data[2]
        operatorList = parent.data.GetListOperator(type_defaut)
        self.combobox1 = wx.ComboBox(self, -1, object_defaut, (50, 30), (100,-1),
                                     objectList, wx.CB_DROPDOWN|wx.CB_SORT)
        self.combobox2 = wx.ComboBox(self, -1, opeator_defaut, (200, 30), (100,-1),
                                     operatorList, wx.CB_DROPDOWN)
        self.combobox3 = wx.ComboBox(self, -1, value_defaut, (350, 30), (100,-1),
                                     valueList, wx.CB_DROPDOWN)
        okButton = wx.Button(self, wx.ID_OK, "OK", pos = (150,75))
        cancelButton = wx.Button(self, wx.ID_CANCEL, "Cancel", pos = (250,75))
        self.combobox1.Bind(wx.EVT_COMBOBOX, self.UpdateSelect)

    def UpdateSelect(self, event):
        object_data_select = self.combobox1.GetValue()
        for object_data in self.list_data_object:
            if object_data[0].split() == object_data_select.split():
                type_data = object_data[1]
                operatorList = self.parent.data.GetListOperator(type_data)
                valueList = object_data[2]
                break
        self.combobox2.SetItems(operatorList)
        self.combobox3.SetItems(valueList)

    def GetValue(self):
        return str(self.combobox1.GetValue()+"  "+ self.combobox2.GetValue()+"  "+
               self.combobox3.GetValue())

    

class GridObject(wx.grid.Grid):
    def __init__(self, parent):
        self.parent = parent
        wx.grid.Grid.__init__(self, self.parent, size = (595,570), style = wx.VSCROLL)
        self.SetColLabelSize(0)
        self.SetRowLabelSize(0)
        self.CreateGrid(0,3)
        self.SetColSize(0, 100)
        self.SetColSize(1, 100)
        self.SetColSize(2, 380)
        attrc = wx.grid.GridCellAttr()
        attrc.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.SetColAttr(0, attrc)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_CLICK, self.RightClick)
        #self.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK, self.LeftDoubleClick)
        self.SetTitle(0, "ALL OBJECT", "", "")
        self.SetCellSize(0, 0, 1, 3)
        self.SetTitle(1, "    OBJECT   NAME   ","|       TYPE   ", "| LIST   VALUE   NAME")
        self.parent.data.SetDataObject()
        self.data_object = self.parent.data.GetDataObject()
        self.row_object = []
        self.SetDataToGrid(self.data_object)
        self.current_row_col = [0,0]

    def SetCurrentRowCol(self, row_col):
        self.current_row_col = row_col

    def GetCurrentRowCol(self):
        return self.current_row_col

    def SetTitle(self, row,  text1, text2, text3):
        attr = wx.grid.GridCellAttr()
        attr.SetBackgroundColour(wx.Colour(220, 220, 220))
        attr.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
        self.InsertRows(row, 1, True)
        self.SetReadOnly(row, 0, True)
        self.SetReadOnly(row, 1, True)
        self.SetReadOnly(row, 2, True)
        self.SetCellValue(row, 0, text1)
        self.SetCellValue(row, 1, text2)
        self.SetCellValue(row, 2, text3)
        self.SetRowAttr(row, attr)

    def AddDataObjectToGrid(self, row, data):
        name_object = data[0]
        type_object = data[1]
        list_value =  data[2]
        number_line_use   = len(list_value)
        for line in range(number_line_use):
            self.InsertRows(row, 1, True)
            attr1 = wx.grid.GridCellAttr()
            attr1.SetFont(wx.Font(8, wx.SWISS, wx.NORMAL, wx.BOLD))
            self.SetReadOnly(row, 0, True)
            self.SetReadOnly(row, 1, True)
            self.SetReadOnly(row, 2, True)
            self.SetCellValue(row, 2, list_value[line])
            row = row + 1
        self.SetCellSize(row-number_line_use, 0, number_line_use, 1)
        self.SetCellValue(row-number_line_use, 0, name_object)
        self.SetCellAlignment(row-number_line_use, 0, wx.RIGHT, -1)
        self.SetCellSize(row-number_line_use, 1, number_line_use, 1)
        self.SetCellValue(row-number_line_use, 1 , type_object)
        self.InsertRows(row, 1, True)
        self.SetCellSize(row, 0, 1, 3)
        row = row + 1
        return row

    def SetDataToGrid(self, list_object):
        self.row_object = []
        row = 2
        for data in list_object:
            self.row_object.append(row)
            self.AddDataObjectToGrid(row, data)
            row = row + len(data[2]) + 1

    def IsCanDeleteObject(self, row):
        if row >= 2:
            if not row + 1 in  self.row_object:
                return True
            else:
                return False
        else:
            return False

    def RightClick(self, event):
        row = event.GetRow()
        col = event.GetCol()
        self.SetGridCursor(row, col)
        self.SetCurrentRowCol([row, col])
        menu = wx.Menu()
        self.popupID1 = wx.NewId()
        self.Bind(wx.EVT_MENU, self.OnPopupAddNew, id=self.popupID1)
        item = wx.MenuItem(menu, self.popupID1, "Add New Object")
        menu.AppendItem(item)
        if self.IsCanDeleteObject(row):
            self.popupID2 = wx.NewId()
            self.Bind(wx.EVT_MENU, self.OnPopupDeleteObject, id=self.popupID2)
            item_delete = wx.MenuItem(menu, self.popupID2, "Delete This Object")
            menu.AppendItem(item_delete)
        self.PopupMenu(menu)
        menu.Destroy()

    def OnPopupAddNew(self, event):
        row = self.GetCurrentRowCol()[0]
        object_dialog = ObjectDialog(self.parent)
        result = object_dialog.ShowModal()
        if result == wx.ID_OK:
            data_object = object_dialog.GetValue()
            object_dialog.Destroy()
            self.DisplayAddNew(row, data_object)
            self.parent.data.DataAddNewObject(data_object)
            return 0
        object_dialog.Destroy()

    def OnPopupDeleteObject(self, event):
        row = self.GetCurrentRowCol()[0]
        self.DisplayDeleteObject(row)

    def UpdateListRow(self, index, value):
        for index_row in range(len(self.row_object)):
            if index < index_row:
                self.row_object[index_row] = self.row_object[index_row] + value

    def DisplayAddNew(self, row, data_object):
        rowobject = 0
        save_index = 0
        if row <= 1:
            rowobject = 2
        else:
            if len(self.row_object) == 1:
                rowobject = 2
            else:
                save_index = len(self.row_object) - 1
                for index_row in range(len(self.row_object)):  
                    if row <  self.row_object[index_row]:
                        save_index = index_row - 1
                        break
                rowobject = self.row_object[save_index]      
        lenght = len(data_object[2])
        self.row_object.insert(save_index, rowobject)
        self.UpdateListRow(save_index, lenght + 1)
        self.data_object.insert(save_index, data_object)
        self.AddDataObjectToGrid(rowobject, data_object)

    def DisplayDeleteObject(self, row):
        if len(self.row_object) == 1:
                rowobject = 2
                save_index = 0
        else:
            save_index = len(self.row_object) - 1
            for index_row in range(len(self.row_object)):  
                if row <  self.row_object[index_row]:
                    save_index = index_row - 1
                    rowobject = self.row_object[save_index]
                    break
        data = self.data_object[save_index]
        if self.parent.data.IsDataCanRemove(data):
            lenght =  len(self.data_object[save_index][2])
            self.DeleteRows(rowobject, lenght + 1, True)
            self.data_object.remove(self.data_object[save_index])
            for index_row in range(len(self.row_object)):  
                if index_row >=  save_index:
                    self.row_object[index_row] = self.row_object[index_row] - lenght - 1
            self.row_object.remove(self.row_object[save_index])
        
        
                    
class ObjectDialog(wx.Dialog):
    def __init__(self, parent):
        self.parent = parent
        wx.Dialog.__init__(self, parent, -1, 'New  Object', size=(400,250))
        self.SetBackgroundColour(wx.Colour(220, 220, 220))
        wx.StaticText(self, -1 , "Name : ",pos = (125,30))
        self.textName = wx.TextCtrl(self, -1, "", size = (100,-1),pos = (175,30))
        wx.StaticText(self, -1 , "Select Type : ",pos = (100,80))
        typeList = ["Set Value", "Set Number" , "Boolean"]
        self.comboboxtype = wx.ComboBox(self, -1, "Set Value", (175, 80), (100,-1),
                                     typeList, wx.CB_DROPDOWN|wx.CB_SORT)
        wx.StaticText(self, -1 , "List Value : ",pos = (110,130))
        self.textListValue = wx.TextCtrl(self, -1, "", size = (150,-1),pos = (175,130))
        wx.StaticText(self, -1 , "separetor by , ex. 1, 2, 3",pos = (175,155))
        okButton = wx.Button(self, wx.ID_OK, "OK", pos = (100,175))
        cancelButton = wx.Button(self, wx.ID_CANCEL, "Cancel", pos = (200,175))

    def GetValue(self):
        list_value = str(self.textListValue.GetValue()).split (',')
        for index_value in range(len(list_value)):
            list_value[index_value] = list_value[index_value].split()
        for index_value in range(len(list_value)):
            value = ""
            for index_in_value in range(len(list_value[index_value])):
                if index_in_value == 0:
                    value = value + list_value[index_value][index_in_value]
                else:
                    value = value + " " + list_value[index_value][index_in_value]
            list_value[index_value] = value
        while "" in list_value:
            list_value.remove("")
        return [str(self.textName.GetValue()) ,str(self.comboboxtype.GetValue()),list_value]

            

if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = Frame(parent = None, title = "Rule - Based   Validation")
    frame.Show()
    app.MainLoop()
