from checking import *
from databaserule import *

class CheckRulebase:

    def __init__(self):

        self.__database = DatabaseRule()
        self.__check = Check(self.__database)

    def Commit(self):
        self.__database.Close()
        self.__database = DatabaseRule()
        self.__check = Check(self.__database)
    
    def CheckRedundant(self):
        self.Commit()
        setrule_id = set(self.__database.GetAllRuleId())
        setrule_idcopy = setrule_id.copy()
        listresult = []
        for rule_id in setrule_id:
            if rule_id in setrule_idcopy:
                setrule_idcopy.remove(rule_id)
		result = set()
		result.add(rule_id)
		has_redundant = False
		for rule_idcopy in setrule_idcopy:
		    if self.__check.SamePremise(rule_id,rule_idcopy) and \
                       self.__check.SameConclusion(rule_id,rule_idcopy):
			result.add(rule_idcopy)
			has_redundant = True
		if has_redundant == True:
		    listresult.append(result)
	indexremove = set()
        for index in range(len(listresult)):
            for indexsecound in range(len(listresult)):
                if index <> indexsecound:
                    if listresult[index].issubset(listresult[indexsecound]):
                        indexremove.add(index)
        index = 0
        for value in indexremove:
            listresult.remove(listresult[value - index])
            index = index + 1
	return listresult

    def CheckConflict(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        listresult = []
        for rule_id in setrule_id:
	    result = set()
	    has_conflict = False
	    for rule_idsecound in setrule_id:
                if rule_id <> rule_idsecound:
                    if self.__check.SamePremise(rule_id,rule_idsecound) and \
                       self.__check.ConflictConclusion(rule_id,rule_idsecound):
                        result.add(rule_idsecound)
                        has_conflict = True
	    if has_conflict == True:
                result.add(rule_id)
                listresult.append(result)
	indexremove = set()
        for index in range(len(listresult)):
            for indexsecound in range(len(listresult)):
                if index <> indexsecound:
                    if listresult[index].issubset(listresult[indexsecound]):
                        indexremove.add(index)
                        if listresult[index] == listresult[indexsecound]:
                            if indexsecound in indexremove:
                                indexremove.remove(index)
        index = 0
        for value in indexremove:
            listresult.remove(listresult[value - index])
            index = index + 1
	return listresult

    def CheckSubsume(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        listresult = []
        for rule_id in setrule_id:
	    result = set()
	    has_subsume = False
	    for rule_idsecound in setrule_id:
                if rule_id <> rule_idsecound:
                    if self.__check.SubsumePremise(rule_id,rule_idsecound) and \
                       self.__check.SameConclusion(rule_id,rule_idsecound):
                        result.add(rule_idsecound)
                        has_subsume = True
	    if has_subsume == True:
                listresult.append([rule_id,result])
        indexremove = set()
        for index in range(len(listresult)):
            for indexsecound in range(len(listresult)):
                if index <> indexsecound:
                    if listresult[index][1].issubset(listresult[indexsecound][1]):
                        indexremove.add(index)
                    if len(listresult[indexsecound][1]) == 1 and \
                       len(listresult[index][1]) == 1 and \
                       listresult[index][0] in listresult[indexsecound][1] and\
                       listresult[indexsecound][0] in listresult[index][1]:
                        if not indexsecound in indexremove:
                            indexremove.add(index)
        index = 0
        for value in indexremove:
            listresult.remove(listresult[value - index])
            index = index + 1
	return listresult

    def CheckUnnecessaryPremise(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        listresult = []
        for rule_id in setrule_id:
	    result = set()
	    list_result = []
	    has_subsume = False
	    for rule_idsecound in setrule_id:
                if rule_id <> rule_idsecound:
                    clause = self.__check.UnnecessaryPremise(rule_id,rule_idsecound)
                    if clause and \
                       self.__check.SameConclusion(rule_id,rule_idsecound):
                        result.add(rule_idsecound)
                        list_result.append([rule_idsecound, clause])
                        has_subsume = True
	    if has_subsume == True:
                listresult.append([rule_id, result, list_result])
        indexremove = set()
        for index in range(len(listresult)):
            for indexsecound in range(len(listresult)):
                if index <> indexsecound:
                    if listresult[index][1].issubset(listresult[indexsecound][1]):
                        indexremove.add(index)
                    if listresult[index][0] in listresult[indexsecound][1] and\
                       listresult[indexsecound][0] in listresult[index][1]:
                        if len(listresult[indexsecound][1]) == 1 and \
                           len(listresult[index][1]) == 1 :
                            if not indexsecound in indexremove:
                                indexremove.add(index)
                        else:
                            if len(listresult[indexsecound][1]) > len(listresult[index][1]):
                                indexremove.add(index)
                            else:
                                indexremove.add(indexsecound)
        index = 0
        for value in indexremove:
            listresult.remove(listresult[value - index])
            index = index + 1
	return listresult

    def CheckCircular(self):
        self.Commit()
        goal_clause  =  self.__database.GetClauseGoalId()
        set_rule = set() 
        for clause in goal_clause:
            result = self.__database.GetRuleFromConclusionId(clause[0])
            set_rule = set_rule.union(set(result))    
        listresult = []
        for rule_id in set_rule:
            list_circular = self.__check.Circular([rule_id[0]])
            if list_circular:
                listresult = listresult + list_circular
        inc = 0
        for index in range(len(listresult)):
            if len(listresult[index - inc]) <= 1:
                listresult.remove(listresult[index - inc])
                inc = inc + 1
        return listresult

    def CheckUnachievableIntermediateConclusion(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        goal_clause  =  set(self.__database.GetClauseGoalId())
        listresult = []
        for rule_id in setrule_id:
            clause = self.__database.GetClauseConclusionFromId(rule_id)[0]
            if not clause in goal_clause:
                rule = self.__database.GetRuleFromPremiseId(clause[0])
                if not rule:
                    listresult.append(rule_id)
        return listresult

    def CheckUnachievablePremise(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        all_conclusion = self.__database.GetAllConclusionId()
        askable_object = set(self.__database.GetAskableObjectId())
        listresult = []
    	for rule_id in setrule_id:
            premise_clauses = self.__database.GetClausePremiseFromId(rule_id)
            listunachievable_premise = []
            unachievable_premise = False
            for clause in premise_clauses:
                if not clause[0] in all_conclusion:
                    object_id =  self.__database.GetObjectIdFromClauseId(clause[0])
                    if not object_id in askable_object:
                        unachievable_premise = True
                        listunachievable_premise.append(clause[0])
            if unachievable_premise == True:
                listresult.append([rule_id,listunachievable_premise])            
        return listresult

    def CheckUnachievableGoal(self):
        self.Commit()
        setrule_id = self.__database.GetAllRuleId()
        all_conclusion = self.__database.GetAllConclusionId()
        askable_object = set(self.__database.GetAskableObjectId())
        goal_clause  =  set(self.__database.GetClauseGoalId())
        listresult = []
    	for rule_id in setrule_id:
            clause = self.__database.GetClauseConclusionFromId(rule_id)[0]
            if  clause in goal_clause:
                premise_clauses = self.__database.GetClausePremiseFromId(rule_id)
                for clause in premise_clauses:
                    unachievable_premise = False
                    listunachievable_premise = []
                    if not clause[0] in all_conclusion:
                        object_id =  self.__database.GetObjectIdFromClauseId(clause[0])
                        if not object_id in askable_object:
                            unachievable_premise = True
                            listunachievable_premise.append(clause[0])
                    if unachievable_premise == True:
                        listresult.append([rule_id,listunachievable_premise])            
        return listresult

    def CheckIllegalObjectValue(self):
        self.Commit()
        set_clause = set(self.__database.GetAllClauseFromTable())
        listresult = []
        for clause in set_clause:
            type_value = self.__database.GetTypeValueFromObjectId(clause[1])
            if type_value == 'Set Value':
                set_value = self.__database.GetSetValueFromObjectId(clause[1])
                value = (clause[2],)
                listrule = []
                if not value in set(set_value):
                    set_rule_id = self.__database.GetRuleFromConclusionId(clause[0])
                    for rule_id in set_rule_id:
                        listrule.append(rule_id[0])    
                    set_rule_id = self.__database.GetRuleFromPremiseId(clause[0])
                    for rule_id in set_rule_id:
                        listrule.append(rule_id[0])
                    listresult.append([clause[0],listrule])
        return listresult

    def CheckUnreferencedObjectValue(self):
        self.Commit()
        set_object_id = self.__database.GetAllObjectIdTypeSetValueFromTable()
        listresult = []
        for object_id in set_object_id:
            set_value = self.__database.GetSetValueFromObjectId(object_id[0])
            set_value_in_clause = \
                self.__database.GetValueFromObjectIdClauseTable(object_id[0])
            unreference = set(set_value) - set(set_value_in_clause)
            if unreference :
                listresult.append([object_id[0],unreference])
        return listresult
