import MySQLdb
from rule import *
class  DatabaseRule:

    def __init__(self):
        #---------------------  valid host,user,passwd,db
        self.__database = MySQLdb.connect(host="localhost", user="root",
                             passwd="root",db="validation")
        self.__cursor = self.__database.cursor()
        self.count_object_id = 0
        self.count_clause_id = 0
        self.count_value_id = 1
        self.count_rule_id = 0

    def AddRule(self,arule):
        conclusion_id = self.AddConclusion(arule.GetConclusion())
        premise_id = self.AddPremise(arule.GetPremise())
        rule_id = self.AddRuleToTable(conclusion_id)
        self.AddRuleClausePremiseToTable(rule_id,premise_id)
        return  rule_id

    def AddConclusion(self,aconclusion):
        return self.AddClause(aconclusion)

    def AddPremise(self,apremise):
        premise_id = []
        for clause in apremise:
            premise_id.append(self.AddClause(clause))
        return premise_id

    def AddClause(self,aclause):
        object_id = self.AddObject(aclause.GetObjectClause())
        query = """select CLAUSE_ID from clause where OBJECT_ID = '%s'
                and OPERATOR = '%s' and VALUE = '%s'""" % (
                       object_id,
                       aclause.GetOperatorClause(),
                       aclause.GetValueClause())
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        if result:
            return result[0][0]
        else:
            return self.AddClauseToTable(object_id,aclause)
        
    def AddObject(self,aobject):
        query = """select OBJECT_ID from object where OBJECT_NAME = '%s'
                and TYPE = '%s' """ % (
                       aobject.GetName(),
                       aobject.GetType())
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        if result:
            return result[0][0]
        else:
            return self.AddObjectToTable(aobject)

    def GetMaxPrimaryKeyId(self, col_name, table):
        query = """select max(%s) from %s """  % (col_name, table)
        self.ExecuteSql(query)
        return self.__cursor.fetchall()

    def GetNewId(self, col_name, table):
        max_value = self.GetMaxPrimaryKeyId(col_name, table)
        if not max_value[0][0]:
            return "00001"
        else:
            max_value = max_value[0][0]
            max_value = max_value[-5:]
            max_value = int(max_value)
            max_value = max_value + 1
            max_value = str(max_value)
            while len(max_value)< 5:
                max_value = "0" + max_value
            return max_value

    def AddObjectToTable(self,aobject):
        key = self.GetNewId("object_id","object")
        object_id = "O%s" % (key)
        query = """insert into object value ('%s','%s','%s')
                """ % (object_id,
                       aobject.GetName(),
                       aobject.GetType())
        self.ExecuteSql(query)
        self.AddValueToTable(aobject.GetSetValue(),object_id)
        return object_id

    def AddValueToTable(self,setvalue,object_id):
        for value in setvalue:
            key = self.GetNewId("value_id","value")
            value_id = "V%s" % (key)
            query = """insert into value value ('%s','%s','%s')
                """ % (value_id,
                       value,
                       object_id)
            self.ExecuteSql(query)
            self.count_value_id  = self.count_value_id + 1
        
    def AddClauseToTable(self,aobject_id,aclause):
        key = self.GetNewId("clause_id","clause")
        clause_id = "CL%s" % (key)
        query = """insert into clause value ('%s','%s','%s','%s')
                """ % (clause_id,
                       aobject_id,
                       aclause.GetOperatorClause(),
                       aclause.GetValueClause())
        self.ExecuteSql(query)
        self.AddClauseToRelationTable(clause_id,aobject_id,aclause.GetOperatorClause(),aclause.GetValueClause())
        return clause_id

    def AddRuleToTable(self,aconclusion_id):
        key = self.GetNewId("rule_id","rule")
        rule_id = "R%s" % (key)
        query = """insert into rule value ('%s','%s')
                """ % (rule_id,aconclusion_id)
        self.ExecuteSql(query)
        return rule_id

    def AddRuleClausePremiseToTable(self,arule_id,apremise_id):
        for id_premise in apremise_id:
            query = """insert into rule_clauses_premise value ('%s','%s')
                    """ % (arule_id,id_premise)
            self.ExecuteSql(query)

    def AddClauseToRelationTable(self,clause_id,object_id,operator,value):
        query = """select TYPE from object
                where OBJECT_ID = '%s'""" % (object_id)
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        type_object = result[0][0]
        query = """select CLAUSE_ID,OPERATOR,VALUE from clause
                where OBJECT_ID = '%s' and CLAUSE_ID <> '%s'""" % (object_id,clause_id)
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        
        for record in result:
            type_relation = None
            conflict = False
            if type_object == 'Set Number':
                value = int(value)
                if operator == '=':
                    if record[1] == '=':
                        if not int(record[2]) == value:
                            conflict = True
                    if record[1] == '<>':
                        if int(record[2]) == value:
                            conflict = True
                    if record[1] == '>':
                        if int(record[2]) >= value:
                            conflict = True
                    if record[1] == '>=':
                        if int(record[2]) > value:
                            conflict = True
                    if record[1] == '<':
                        if int(record[2]) <= value:
                            conflict = True
                    if record[1] == '<=':
                        if int(record[2]) < value:
                            conflict = True
                if operator == '<>':
                    if record[1] == '=':
                        if int(record[2]) == value:
                            conflict = True
                if operator == '>':
                    if record[1] == '=':
                        if int(record[2]) >=  value:
                            conflict = True
                    if record[1] == '<' or record[1] == '<=':
                        if int(record[2]) <=  value : 
                            conflict = True
                if operator == '>=':
                    if record[1] == '=':
                        if int(record[2]) >  value:
                            conflict = True
                    if record[1] == '<' or record[1] == '<=':
                        if int(record[2]) <  value : 
                            conflict = True
                if operator == '<':
                    if record[1] == '=':
                        if int(record[2]) <=  value:
                            conflict = True
                    if record[1] == '>' or record[1] == '>=':
                        if int(record[2]) >=  value : 
                            conflict = True
                if operator == '<=':
                    if record[1] == '=':
                        if int(record[2]) <  value:
                            conflict = True
                    if record[1] == '>' or record[1] == '>=':
                        if int(record[2]) >  value : 
                            conflict = True
            else:# set value
                if type_object == 'Set Value':
                    len_set_value = len(self.GetSetValueFromObjectId(object_id))
                    if len_set_value <= 2:
                        if operator == 'is':
                            if record[1] == 'is':
                                if not record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                            if record[1] == 'is not':
                                if  record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                                else:
                                    type_relation = "Redundant"
                                    conflict = True
                        if operator == 'is not':
                            if record[1] == 'is':
                                if  record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                                else:
                                    type_relation = "Redundant"
                                    conflict = True
                            else:
                                if not record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                                
                    else:# set value len > 2 
                        if operator == 'is':
                            if record[1] == 'is not':
                                if  record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                                else:
                                    type_relation = "Subsume"
                                    conflict = True
                        if operator == 'is not':
                            if record[1] == 'is':
                                if  record[2] == value:
                                    type_relation = "Conflict"
                                    conflict = True
                                else:
                                    type_relation = "Subsume Of"
                                    conflict = True
            
                else:#Boolean
                    if not record[2] == value:
                        type_relation = "Conflict"
                        conflict = True

            query = """select * from relation_clause where clause_idone = "%s"
                    and clause_idtwo = "%s"   """ % (clause_id,record[0])
            self.ExecuteSql(query)
            result = self.__cursor.fetchall()
            if not result:
                if  conflict == True:
                    query = """insert into relation_clause value ('%s','%s','%s')
                        """ % (clause_id,record[0],type_relation)
                    self.ExecuteSql(query)

    def AddGoal(self,clause):
        clause_id = self.AddClause(clause)
        query = """select * from goal_clause  where clause_id = '%s'""" % (clause_id)
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        if not result:
            query = """insert into goal_clause value ('G1','%s','Goal Project')
                    """ % clause_id
            self.ExecuteSql(query)

    def AskableObject(self,aobject):
        object_id = self.AddObject(aobject)
        
        query = """insert into askable_object value ('ASK1','%s','Project')
                """ % object_id
        self.ExecuteSql(query)

    def GetAllRuleId(self):
        self.ExecuteSql("""select RULE_ID from rule""")
        result = self.__cursor.fetchall()
        rule_id_set = set()
        for row in result:
             rule_id_set.add(row[0])
        return rule_id_set

    def GetAllObjectId(self):
        self.ExecuteSql("""select OBJECT_ID from object""")
        result = self.__cursor.fetchall()
        list_object_id = []
        for row in result:
             list_object_id.append(row[0])
        return list_object_id

    def GetAllConclusionId(self):
        self.ExecuteSql("""select CLAUSE_CONCLUSION from rule""")
        result = self.__cursor.fetchall()
        conclusion_id_set = set()
        for row in result:
             conclusion_id_set.add(row[0])
        return conclusion_id_set

    def GetAllClauseFromTable(self):
        query = """select CLAUSE_ID,OBJECT_ID,VALUE from clause"""
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetObjectIdFromClauseId(self,clause_id):
        query = """select OBJECT_ID from clause
                where CLAUSE_ID = '%s'""" % clause_id  
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()[0]

    def GetClauseGoalId(self):
        query = """select CLAUSE_ID from goal_clause
                where GOAL_ID = 'G1'""" 
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetAskableObjectId(self):
        query = """select OBJECT_ID from askable_object
                where ASK_ID = 'ASK1'""" 
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetClausePremiseFromId(self,rule_id):
        query = """select CLAUSE_PREMISE from rule_clauses_premise
                where RULE_ID = '%s'""" % rule_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetRuleFromPremiseId(self,premise_id):
        query = """select RULE_ID from rule_clauses_premise
                where CLAUSE_PREMISE = '%s'""" % premise_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetRuleFromConclusionId(self,conclusion_id):
        query = """select RULE_ID from rule
                where CLAUSE_CONCLUSION = '%s'""" % conclusion_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetClauseConclusionFromId(self,rule_id):
        query = """select CLAUSE_CONCLUSION from rule
                where RULE_ID = '%s'""" % rule_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetConflictClause(self,fristclause_id,secoundclause_id):
        query = """select CLAUSE_IDONE,CLAUSE_IDTWO from relation_clause
                where (CLAUSE_IDTWO = '%s' and CLAUSE_IDONE = '%s' and TYPE_RELATION = 'Conflict') or
                      (CLAUSE_IDONE = '%s' and CLAUSE_IDTWO = '%s' and TYPE_RELATION = 'Conflict')""" %(
                    fristclause_id,secoundclause_id,
                    fristclause_id,secoundclause_id)
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetRedundantClause(self,fristclause_id,secoundclause_id):
        query = """select CLAUSE_IDONE,CLAUSE_IDTWO from relation_clause
                where (CLAUSE_IDTWO = '%s' and CLAUSE_IDONE = '%s' and TYPE_RELATION = 'Redundant') or
                      (CLAUSE_IDONE = '%s' and CLAUSE_IDTWO = '%s' and TYPE_RELATION = 'Redundant')""" %(
                    fristclause_id,secoundclause_id,
                    fristclause_id,secoundclause_id)
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetSubsumeClause(self,fristclause_id,secoundclause_id):
        query =  """select * from relation_clause
                where (CLAUSE_IDTWO = '%s' and CLAUSE_IDONE = '%s' and (TYPE_RELATION = 'Subsume Of' or TYPE_RELATION = 'Subsume' )) or
                      (CLAUSE_IDONE = '%s' and CLAUSE_IDTWO = '%s' and (TYPE_RELATION = 'Subsume Of' or TYPE_RELATION = 'Subsume' ))""" %(
                    fristclause_id,secoundclause_id,
                    fristclause_id,secoundclause_id)
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()

    def GetTypeVauleFromObjectId(self,object_id):
        query = """select TYPE from object
                where OBJECT_ID = '%s'""" % object_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()[0][0]

    def GetSetValueFromObjectId(self,object_id):
        query = """select VALUE_NAME from value
                where OBJECT_ID = '%s'""" % object_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()
    #------------------------------- For Interface ----------------------------------

    def GetObjectNameFromObjectId(self,object_id):
        query = """select OBJECT_NAME from object
                where OBJECT_ID = '%s'""" % object_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()[0][0]

    def GetObjectIdFromObjectName(self,object_name):
        query = """select OBJECT_ID from object
                where OBJECT_NAME = '%s'""" % object_name
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()[0][0]

    def GetClauseFromClauseId(self,clause_id):
        query = """select OBJECT_ID,OPERATOR,VALUE from clause
                where CLAUSE_ID = '%s'""" % clause_id
        self.ExecuteSql(query)
        return  self.__cursor.fetchall()[0]

    def GetClauseIdFromData(self, object_id, operator, value):
        query = """select CLAUSE_ID from clause
                where OBJECT_ID = '%s' and OPERATOR = '%s'and VALUE = '%s' """ % (object_id, operator, value)
        self.ExecuteSql(query)
       
        result = self.__cursor.fetchall()
        if result:
            return  result[0][0]
        else :
            return None

    def DeleteRuleId(self, rule_id):
        list_clause =  self.GetClausePremiseFromId(rule_id) + self.GetClauseConclusionFromId(rule_id)
        query = """delete from rule_clauses_premise
                    where rule_id = '%s'""" % rule_id
        self.ExecuteSql(query)
        query = """delete from rule
                    where rule_id = '%s'""" % rule_id
        self.ExecuteSql(query)
        for clause in list_clause:
            self.DeleteClauseId(clause[0])
            
    def DeleteClauseId(self, clause_id):
        list_in_rule =  self.GetRuleFromConclusionId(clause_id)+self.GetRuleFromPremiseId(clause_id)
        if len(list_in_rule) == 0:
            query = """delete from goal_clause
                    where clause_id = '%s'""" % clause_id
            self.ExecuteSql(query)
            query = """delete from relation_clause
                    where clause_idone = '%s' or clause_idtwo = '%s'""" % (clause_id, clause_id)
            self.ExecuteSql(query)        
            query = """delete from clause
                    where clause_id = '%s'""" % clause_id
            self.ExecuteSql(query)

    def UpdateRulePremise(self, rule_id, clause_id_old, clause_id_new):
        query = """ select * 
                    from rule_clauses_premise
                    where rule_id = '%s' and clause_premise = '%s'""" % (
                    rule_id, clause_id_new )
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        if not result:
            query = """update rule_clauses_premise
                        set clause_premise = '%s'
                        where rule_id = '%s' and clause_premise = '%s'""" % (
                        clause_id_new, rule_id, clause_id_old)
            self.ExecuteSql(query)

    def UpdateRuleConclusion(self, rule_id, clause_id_old, clause_id_new):
        query = """ update rule
                    set clause_conclusion = '%s'
                    where rule_id = '%s' and clause_conclusion= '%s'""" % (
                    clause_id_new, rule_id, clause_id_old)
        self.ExecuteSql(query)

    def UpdateRuleDeletePremiseClause(self, rule_id, clause_id):
        query = """delete from rule_clauses_premise
                    where rule_id = '%s' and clause_premise = '%s'""" % (
                        rule_id, clause_id)
        self.ExecuteSql(query)
        self.DeleteClauseId(clause_id)

    def IsObjectUseInClause(self, object_id):
        query = """select * from clause
                    where object_id = '%s' """ % object_id
        self.ExecuteSql(query)
        result = self.__cursor.fetchall()
        if not result:
            return False
        else:
            return True

    def DeleteClauseIdTableRelationClause(self, clause_id):
        query = """delete from relation_clause
                    where clause_idone = '%s' or clause_idtwo = '%s'""" % (
                        clause_id, clause_id)
        self.ExecuteSql(query)

    def DeleteObjectId(self, object_id):
        query = """delete from value
                    where object_id = '%s'""" % (
                        object_id)
        self.ExecuteSql(query)
        query = """delete from object
                    where object_id = '%s'""" % (
                        object_id)
        self.ExecuteSql(query)
        
        
    def ExecuteSql(self,aquery):
        self.__cursor.execute(aquery)

    def Close(self):
        self.__cursor.close()
        self.__database.commit()
        self.__database.close()

