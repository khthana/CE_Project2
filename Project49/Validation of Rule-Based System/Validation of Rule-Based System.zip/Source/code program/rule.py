class  Object:
    
    def  __init__(self,aname,atype):

        self.__name = aname
        self.__type = atype
        self.__setvalue = set([])

    def GetName(self):
        return  self.__name

    def SetName(self,aname):
        self.__name = aname

    def GetType(self):
        return  self.__type

    def SetType(self,atype):
        self.__type = atype

    def AddValueToSetOfObject(self,avalue):
        self.__setvalue.add(avalue)

    def GetSetValue(self):
        return  self.__setvalue

    
class  Clause:

    def  __init__(self,aobject,aoperator,avalue):

        self.__object = aobject
        self.__operator = aoperator
        self.__value = avalue

    def  GetObjectClause(self):
        return  self.__object
        
    def  GetOperatorClause(self):
        return  self.__operator

    def  GetValueClause(self):
        return  self.__value

    def  SetObjectClause(self,aobject):
        self.__object = aobject
        
    def  SetOperatorClause(self,aoperator):
        self.__operator = aoperator

    def  SetValueClause(self,avalue):
        self.__value = avalue


    
class  Rule:

    def  __init__(self,apremiseclause,aconclusionclause):

        self.__premise = [apremiseclause]
        self.__conclusion = aconclusionclause

    def  GetPremise(self):
        return  self.__premise

    def  GetConclusion(self):
        return  self.__conclusion

    def  AddClauseToPremise(self,apremiseclause):
        self.__premise.append(apremiseclause)

    def  SetConclusion(self,aconclusionclause):
        self.__conclusion = aconclusionclause


