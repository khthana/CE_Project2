from databaserule import *

class  Check:

    def __init__(self, database):
        self.__database = database

    def SameConclusion(self,fristrule_id,secondrule_id):
        fristresult = self.__database.GetClauseConclusionFromId(fristrule_id)
        secoundresult = self.__database.GetClauseConclusionFromId(secondrule_id)
        if set(fristresult) == set(secoundresult):
            return True
        else:
            return self.RedundantClause(fristresult[0][0],secoundresult[0][0])

    def SamePremise(self,fristrule_id,secondrule_id):
        fristresult = self.__database.GetClausePremiseFromId(fristrule_id)
        secoundresult = self.__database.GetClausePremiseFromId(secondrule_id)
        if set(fristresult) == set(secoundresult):
            return True
        else:
            if len(set(fristresult)) == len(set(secoundresult)):
                test_clause = set(fristresult) - set(secoundresult)
                test_clause_two = set(secoundresult) - set(fristresult)
                same_premise = True
                for clause in test_clause:
                    same_premise = False
                    for clause_two in test_clause_two:
                        if self.RedundantClause(clause_two[0],clause[0]):
                            same_premise = True
                            break
                    if same_premise == False:
                        break
                return same_premise
            else:
                return False
                

    def SubsumePremise(self,fristrule_id,secondrule_id):
        fristresult = self.__database.GetClausePremiseFromId(fristrule_id)
        secoundresult = self.__database.GetClausePremiseFromId(secondrule_id)
        if len(set(fristresult)) > len(set(secoundresult)):
            return False
        test_clause = set(fristresult) - set(secoundresult)
        test_clause_two = set(secoundresult) - set(fristresult)
        if not len(set(fristresult)) == len(set(secoundresult)):
            subsume_premise = True
        else:
            subsume_premise = False
        for clause in test_clause:
            subsume_premise = False
            same_premise = False
            for clause_two in test_clause_two:
                clause_subsume = self.SubsumeClause(clause_two[0],clause[0])   
                if clause_subsume :
                    subsume_premise = True
                    if clause_subsume == clause_two[0]:
                        return False

                if self.RedundantClause(clause_two[0],clause[0]):
                    same_premise = True
                    break
            if same_premise == False:     
                if subsume_premise == False:
                    break
        return subsume_premise            
            
        
    def ConflictConclusion(self,fristrule_id,secondrule_id):
        fristresult = self.__database.GetClauseConclusionFromId(fristrule_id)
        secoundresult = self.__database.GetClauseConclusionFromId(secondrule_id)
        return self.ConflictClause(fristresult[0][0],secoundresult[0][0])

    def UnnecessaryPremise(self,fristrule_id,secondrule_id) :
        fristresult = self.__database.GetClausePremiseFromId(fristrule_id)
        secoundresult = self.__database.GetClausePremiseFromId(secondrule_id)
        has_unnecessary_clause = False
        if len(set(fristresult)) == len(set(secoundresult)):
            test_clause = set(fristresult) - set(secoundresult)
            test_clause_two = set(secoundresult) - set(fristresult)
            if not test_clause:
                return False
            frist = False
            save_clause = None
            for clause in test_clause:
                same_premise = False
                unnecessay_premise = False
                for clause_two in test_clause_two:
                    if self.ConflictClause(clause_two[0],clause[0]):
                        if frist == False:
                            frist = True
                            save_clause = clause_two[0]
                            unnecessay_premise = True
                        else:
                            return False
                    if self.RedundantClause(clause_two[0],clause[0]):
                        same_premise = True
                    break
                if same_premise == False:     
                    if unnecessay_premise == False:
                        break
            if unnecessay_premise == True:
                return save_clause
        else:
            return False

    def Circular(self,list_rule_id):
        index = len(list_rule_id) - 1
        conclusion_clause = self.__database.GetClauseConclusionFromId(list_rule_id[index])
        result = self.__database.GetRuleFromPremiseId(conclusion_clause[0][0])
        for rule_id in list_rule_id:
            primise_clause = self.__database.GetClausePremiseFromId(rule_id)
            if  conclusion_clause[0] in primise_clause:
                list_rule_id.append(rule_id)
                return [list_rule_id]
        if  len(result) == 0 :
            return False
        else:
            listresult = []
            for rule_id in result:
                list_input = list_rule_id+[rule_id[0]]
                result_circular = self.Circular(list_input)
                if not result_circular == False:
                    for result_data in result_circular:
                        listresult.append(result_data)
            return listresult

    def ConflictClause(self,fristclause_id,secoundclause_id):
        result = self.__database.GetConflictClause(fristclause_id,secoundclause_id)
        if result :
            return True
        else:
            return False

    def RedundantClause(self,fristclause_id,secoundclause_id):
        result = self.__database.GetRedundantClause(fristclause_id,secoundclause_id)
        if result :
            return True
        else:
            return False

    def SubsumeClause(self,fristclause_id,secoundclause_id):
        result = self.__database.GetSubsumeClause(fristclause_id,secoundclause_id)
        if result :
            if result[0][2] == 'Subsume Of':
                return result[0][1]
            else:
                return result[0][0]
        else:
            return False
    
