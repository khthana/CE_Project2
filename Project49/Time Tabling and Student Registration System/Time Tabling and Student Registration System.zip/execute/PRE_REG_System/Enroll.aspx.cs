using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class Enroll : System.Web.UI.Page
    {
        protected DataSet dsetEnroll = new DataSet();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else if (Convert.ToInt32(Application["EnrollStatus"]) == 0)
            {
                Session["ResultMessage"] = "�к��ѧ����Դ���ӡ��ŧ����¹...";
                Response.Redirect("Result.aspx");
            }

            String studentCode = Session["StudentCode"].ToString();
            int checkRegis = WebUtility.GetRegisStatus(studentCode);

            if (checkRegis == 1)
            {
                Session["ResultMessage"] = "�س��ӡ��ŧ����¹���º��������...";
                Response.Redirect("Result.aspx");
            }

            // Manual Set Session and Application
            /*Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���оѲ�� �ѧ�����";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "2";
            Application["CurrentYear"] = "2549";*/

            lbStudentCode.Text = "���ʹѡ�֡�� : " + Session["StudentCode"].ToString();
            lbStudentName.Text = "���� - ���ʡ�� : " + Session["StudentName"].ToString();
            lbStudentYear.Text = "��鹻շ�� : " + Session["StudentYear"].ToString();
            lbCurrentTerm.Text = "�Ҥ���¹��� : " + Application["CurrentTerm"].ToString();

            if (!IsPostBack)
            {
                int studentYear = Convert.ToInt32(Session["StudentYear"].ToString());
                int currentTerm = Convert.ToInt32(Application["CurrentTerm"].ToString());

                DataTable dtbEnroll = WebUtility.SetEnrollData(studentYear, currentTerm);
                gvEnroll.DataSource = dtbEnroll;
                gvEnroll.DataBind();

                dsetEnroll.Tables.Add(dtbEnroll);
                Session["Enroll"] = dsetEnroll;

                Application["MTH"] = WebUtility.LoadSubjectData("MTH");
                Application["LS"] = WebUtility.LoadSubjectData("LS");
                Application["CC"] = WebUtility.LoadSubjectData("CC");

                DataTable dtbCEC = WebUtility.LoadSubjectData("CEC");
                dtbCEC.Columns.Add("��ṹ��ǵ", System.Type.GetType("System.String"));

                DataTable dtbEC = WebUtility.LoadSubjectData("EC");
                dtbEC.Columns.Add("��ṹ��ǵ", System.Type.GetType("System.String"));

                DataTable dtbPoll = WebUtility.LoadPollData();
                DataTable dtbSummary = WebUtility.SummaryData(dtbPoll, "NOTCUT");

                foreach (DataRow drow in dtbSummary.Rows)
                {
                    String subjectCode = drow["SubjectCode"].ToString();
                    int count = Convert.ToInt32(drow["Count"]);

                    foreach (DataRow dr in dtbCEC.Rows)
                    {
                        String scode = dr["�����Ԫ�"].ToString();
                        if (subjectCode == scode)
                        {
                            dr["��ṹ��ǵ"] = count;
                        }
                    }
                    foreach (DataRow dr in dtbEC.Rows)
                    {
                        String scode = dr["�����Ԫ�"].ToString();
                        if (subjectCode == scode)
                        {
                            dr["��ṹ��ǵ"] = count;
                        }
                    }
                }

                foreach (DataRow dr in dtbCEC.Rows)
                {
                    if (dr["��ṹ��ǵ"] == DBNull.Value)
                    {
                        dr["��ṹ��ǵ"] = 0;
                    }
                }
                foreach (DataRow dr in dtbEC.Rows)
                {
                    if (dr["��ṹ��ǵ"] == DBNull.Value)
                    {
                        dr["��ṹ��ǵ"] = 0;
                    }
                }

                Application["CEC"] = dtbCEC;
                Application["EC"] = dtbEC;

                ddlSubjectGroup.SelectedIndex = 3;
                gvSubject.DataSource = (DataTable)Application["CEC"];
                gvSubject.DataBind();

                mwEnroll.SetActiveView(viewSubject);
            }
            else
            {
                dsetEnroll = (DataSet)Session["Enroll"];
                gvEnroll.DataSource = dsetEnroll.Tables["Enroll"];
                gvEnroll.DataBind();
            }
        }

        protected void gvEnroll_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            dsetEnroll = (DataSet)Session["Enroll"];

            int index = Convert.ToInt32(e.RowIndex);
            GridViewRow deleteRow = gvEnroll.Rows[index];

            String subjectCode = deleteRow.Cells[1].Text;
            for (int i = 0; i < gvSubject.Rows.Count; i++)
            {
                if (gvSubject.Rows[i].Cells[1].Text == subjectCode)
                {
                    gvSubject.Rows[i].Enabled = true;
                }
            }

            dsetEnroll.Tables["Enroll"].Rows[index].Delete();
            Session["Enroll"] = dsetEnroll;

            lbErrorMsg.Text = "";
            int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["Enroll"]);
            lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";

            gvEnroll.DataSource = dsetEnroll.Tables["Enroll"];
            gvEnroll.DataBind();
        }

        protected void gvEnroll_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Width = 50;
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[1].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;

                e.Row.Cells[3].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
        }

        protected void gvSubject_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow selectedRow = gvSubject.Rows[index];

                dsetEnroll = (DataSet)Session["Enroll"];

                DataRow drow = dsetEnroll.Tables["Enroll"].NewRow();
                drow["�����Ԫ�"] = selectedRow.Cells[1].Text;
                drow["�����Ԫ�"] = selectedRow.Cells[2].Text;
                drow["˹��¡Ե"] = selectedRow.Cells[3].Text;

                dsetEnroll.Tables["Enroll"].Rows.Add(drow);

                Session["Enroll"] = dsetEnroll;
                selectedRow.Enabled = false;

                int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["Enroll"]);
                lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";

                gvEnroll.DataSource = dsetEnroll.Tables["Enroll"];
                gvEnroll.DataBind();
            }
        }

        protected void gvSubject_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Width = 50;
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[1].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;

                e.Row.Cells[3].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }

            dsetEnroll = (DataSet)Session["Enroll"];

            // Disable �Ԫҷ��١���͡
            foreach (DataRow drow in dsetEnroll.Tables["Enroll"].Rows)
            {
                String subjectCode = drow["�����Ԫ�"].ToString();
                for (int i = 0; i < gvSubject.Rows.Count; i++)
                {
                    if (gvSubject.Rows[i].Cells[1].Text == subjectCode)
                    {
                        gvSubject.Rows[i].Enabled = false;
                    }
                }
            }
        }
        protected void gvSubject_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells.Count == 5)
                {
                    e.Row.Cells[4].Font.Bold = true;
                    int count = Convert.ToInt32(e.Row.Cells[4].Text);

                    if( count == 0)
                        e.Row.Cells[4].ForeColor = System.Drawing.Color.Red;
                    else if (count < 10)
                        e.Row.Cells[4].ForeColor = System.Drawing.Color.DarkOrange;
                    else if (count < 15)
                        e.Row.Cells[4].ForeColor = System.Drawing.Color.DarkOrange;
                    else
                        e.Row.Cells[4].ForeColor = System.Drawing.Color.LimeGreen;
                }
            }
        }

        protected void gvSubject_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (ddlSubjectGroup.SelectedItem.Value == "MTH")
            {
                gvSubject.DataSource = (DataTable)Application["MTH"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "LS")
            {
                gvSubject.DataSource = (DataTable)Application["LS"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CC")
            {
                gvSubject.DataSource = (DataTable)Application["CC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = (DataTable)Application["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = (DataTable)Application["EC"];
            }

            gvSubject.PageIndex = e.NewPageIndex;
            gvSubject.DataBind();
        }

        protected void ddlSubjectGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSubjectGroup.SelectedItem.Value == "MTH")
            {
                gvSubject.DataSource = (DataTable)Application["MTH"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "LS")
            {
                gvSubject.DataSource = (DataTable)Application["LS"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CC")
            {
                gvSubject.DataSource = (DataTable)Application["CC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = (DataTable)Application["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = (DataTable)Application["EC"];
            }

            gvSubject.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["Enroll"]);

            if (sumUnit > 22)
            {
                lbErrorMsg.Text = "�س�������öŧ����¹�Թ 22 ˹��¡Ե";
            }
            else if(sumUnit < 9)
            {
                lbErrorMsg.Text = "�س�������öŧ����¹���¡��� 9 ˹��¡Ե";
            }
            else
            {
                btnNext.Visible = false;
                gvEnroll.Enabled = false;
                mwEnroll.SetActiveView(ViewEmpty);

                btnBack.Visible = true;
                btnEnroll.Visible = true;
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            btnNext.Visible = true;
            gvEnroll.Enabled = true;
            mwEnroll.SetActiveView(viewSubject);

            btnBack.Visible = false;
            btnEnroll.Visible = false;
        }

        protected void btnEnroll_Click(object sender, EventArgs e)
        {
            String studentCode = Session["StudentCode"].ToString();
            String currentTerm = Application["CurrentTerm"].ToString();
            String currentYear = Application["CurrentYear"].ToString();

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand cmd = connection.CreateCommand();

            foreach (DataRow drow in dsetEnroll.Tables["Enroll"].Rows)
            {
                String subjectCode = drow["�����Ԫ�"].ToString();

                String commandText = "INSERT INTO ENROLL (SCODE,SUB_CODE,GRADE,TERM,YEAR)" +
                    "VALUES ('" + studentCode + "','" + subjectCode + "',' ','" + currentTerm + "','" + currentYear + "')";

                cmd.CommandText = commandText;
                cmd.ExecuteNonQuery();
            }

            cmd.CommandText = "UPDATE STUDENT SET CK_REGIS=1 WHERE SCODE='" + studentCode + "'";
            cmd.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();

            // Delete Session
            Session.Remove("Enroll");

            Session["ResultMessage"] = "�ӡ��ŧ����¹���º��������...";
            Response.Redirect("Result.aspx");
        }
    }
}
