using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace PRE_REG_System
{
    public partial class EnrollResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ResultMessage"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            // Manual Set Session and Application
            /*Session["ResultMessage"] = "���ͺ����ʴ���...";
            Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���ͺ �к�";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "2";
            Application["CurrentYear"] = "2549";*/

            lbStudentCode.Text = "���ʹѡ�֡�� : " + Session["StudentCode"].ToString();
            lbStudentName.Text = "���� - ���ʡ�� : " + Session["StudentName"].ToString();
            lbStudentYear.Text = "��鹻շ�� : " + Session["StudentYear"].ToString();
            lbCurrentTerm.Text = "�Ҥ���¹��� : " + Application["CurrentTerm"].ToString();

            lbResult.Text = Session["ResultMessage"].ToString();
            Session.Remove("ResultMessage");
        }
    }
}
