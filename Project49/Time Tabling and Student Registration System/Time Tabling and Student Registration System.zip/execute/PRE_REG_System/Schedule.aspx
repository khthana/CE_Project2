<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Schedule.aspx.cs" Inherits="PRE_REG_System.Schedule" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1"  method="post" runat="server">
    <div style="text-align: center">
                <table align="center" cellspacing="0" width="750">
                    <tr>
                        <td align="center" bgcolor="#507cd1" colspan="3" style="height: 25px">
                            <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma"><strong>��èѴ���ҧ���¹</strong></span></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="3" style="height: 20px">
                        </td>
                    </tr>
                    <tr>
                        <td align="left" bgcolor="#dcdcdc" style="width: 240px; height: 20px">
                            &nbsp;<asp:Image ID="Image2" runat="server" ImageAlign="AbsMiddle" ImageUrl="~/pic/ExcelIcon.JPG" />
                            <asp:LinkButton ID="lnkDownloadTable" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                Font-Overline="False" Font-Size="Small" Font-Underline="False" ForeColor="#333333"
                                Height="15px" OnClick="lnkDownloadTable_Click">��ǹ���Ŵ</asp:LinkButton></td>
                        <td align="center" bgcolor="#dcdcdc" style="height: 20px; width: 240px;">
                            <span style="font-family: Tahoma"><strong>&nbsp;<span style="color: #333333">���ҧ���¹</span></strong></span></td>
                        <td align="right" bgcolor="#dcdcdc" style="height: 20px">
                            <asp:DropDownList ID="ddlManage" runat="server" AutoPostBack="True" OnSelectedIndexChanged="ddlManage_SelectedIndexChanged">
                                <asp:ListItem Value="ManageByVote">�Ѵ��������Ǩ</asp:ListItem>
                                <asp:ListItem Value="ManageDistribute">�ѴẺ��Ш��</asp:ListItem>
                            </asp:DropDownList></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="3" style="height: 174px">
        <asp:Table ID="tblSchedule" runat="server" BorderColor="DarkGray" BorderStyle="Solid"
            BorderWidth="1px" CellPadding="1" CellSpacing="0" Font-Names="Tahoma" Font-Size="Small"
            GridLines="Both" Width="750px">
            <asp:TableRow runat="server" BackColor="#507CD1" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px" Font-Bold="False">
                <asp:TableCell runat="server" BackColor="White" BorderColor="DarkGray" BorderStyle="Solid"
                    BorderWidth="1px" HorizontalAlign="Center" Width="50px">-----</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">09.00 - 12.00</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">13.00 - 16.00</asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFFFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѹ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0FF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѧ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ظ</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFE0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">����ʺ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFFF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ء��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0C0FF" BorderColor="DarkGray" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�����</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ҷԵ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
        </asp:Table>
                        </td>
                    </tr>
                </table>
        &nbsp; &nbsp;&nbsp;
        <asp:MultiView ID="mwSchedule" runat="server">
            <asp:View ID="viewSummary" runat="server">
        <table align="center" cellspacing="0" width="750">
            <tr>
                <td align="left" bgcolor="#dcdcdc" style="width: 698px; height: 21px">
                    &nbsp;<asp:Image ID="Image1" runat="server" ImageAlign="AbsMiddle" ImageUrl="~/pic/ExcelIcon.JPG" />
                    <asp:LinkButton ID="lnkDownloadData" runat="server" Font-Bold="True" Font-Names="Tahoma"
                        Font-Overline="False" Font-Size="Small" Font-Underline="False" ForeColor="#333333"
                        Height="15px" OnClick="lnkDownloadData_Click">��ǹ���Ŵ</asp:LinkButton><span style="color: #333333; font-family: Tahoma"></span></td>
                <td align="center" bgcolor="#dcdcdc" style="width: 698px; height: 21px; font-family: Times New Roman;">
                    <span style="color: #333333; font-family: Tahoma"><strong>��������ػ</strong></span></td>
                <td align="right" bgcolor="#dcdcdc" style="width: 725px; height: 21px; font-size: 10pt;" valign="middle">
                    </td>
            </tr>
            <tr style="font-size: 10pt">
                <td style="width: 698px; height: 175px" colspan="3">
        
        <asp:GridView ID="gvSummaryData" runat="server" Font-Names="Tahoma" Font-Size="Small" BackColor="#CCCCCC" BorderColor="#999999" BorderStyle="Solid" BorderWidth="1px" CellPadding="4" ForeColor="Black" OnRowCreated="gvSummaryData_RowCreated" Width="750px">
            <FooterStyle BackColor="#CCCCCC" />
            <RowStyle BackColor="White" />
            <SelectedRowStyle BackColor="#000099" Font-Bold="True" ForeColor="White" />
            <PagerStyle BackColor="#CCCCCC" ForeColor="Black" HorizontalAlign="Left" />
            <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" />
        </asp:GridView>
        </td>
            </tr>
            <tr>
                <td align="left" bgcolor="#cccccc" bordercolor="#999999" style="height: 20px; width: 698px;" colspan="3">
                    <span style="font-size: 10pt; color: #ffffff; font-family: Tahoma"><strong>&nbsp;<span
                        style="color: #333333">*M = Morning (09.00-12.00)<br />
                        &nbsp;*A = Afternoon (13.00-16.00)</span></strong></span></td>
            </tr>
        </table>
            </asp:View>
            <asp:View ID="viewEmpty" runat="server">
            </asp:View>
        </asp:MultiView><br />
        </div>
    </form>
</body>
</html>
