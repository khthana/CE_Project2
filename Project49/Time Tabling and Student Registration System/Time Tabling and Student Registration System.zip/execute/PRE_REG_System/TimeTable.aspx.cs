using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace PRE_REG_System
{
    public partial class TimeTable : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Manual set Session and Application
            Session["StudentYear"] = "4";

            String studentYear = Session["StudentYear"].ToString();

            // �ʴ����ҧ���¹
            DataTable dtbTimeTable = WebUtility.LoadTimeTable(studentYear);
            WebUtility.DisplayTimeTable(dtbTimeTable, tblTimeTable);

            DataTable dtbPoll = WebUtility.LoadPollData();
            DataTable dtbSummary = WebUtility.SummaryData(dtbPoll, "CUT");
        }
    }
}
