<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="StudentMenu.aspx.cs" Inherits="PRE_REG_System.MainMenu" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
        <table cellspacing="0" width="750" align="center" border="1" bordercolor="#507cd1" cellpadding="0">
            <tr>
                <td align="center" bgcolor="#507cd1" colspan="2" style="vertical-align: top; height: 25px;
                    text-align: center" width="150">
                    <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="14pt"
                        Text="�к��Ѵ���ҧ�͹��С��ŧ����¹" ForeColor="White" Width="745px"></asp:Label></td>
            </tr>
            <tr>
                <td align="left" style="vertical-align: top; text-align: left" width="150" bordercolor="#ffffff">
                    <asp:Menu ID="mnStudent" runat="server" BackColor="#B5C7DE" DynamicHorizontalOffset="2"
                        Font-Names="Tahoma" Font-Size="Small" ForeColor="#284E98" OnMenuItemClick="mnStudent_MenuItemClick"
                        StaticSubMenuIndent="10px" Width="150px">
                        <StaticMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" />
                        <DynamicHoverStyle BackColor="#284E98" ForeColor="White" />
                        <DynamicMenuStyle BackColor="#B5C7DE" />
                        <StaticSelectedStyle BackColor="#507CD1" />
                        <DynamicSelectedStyle BackColor="#507CD1" />
                        <DynamicMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" />
                        <Items>
                            <asp:MenuItem Text="��������ǹ���" Value="StudentInfo"></asp:MenuItem>
                            <asp:MenuItem Text="�к�ŧ����¹" Value="�к�ŧ����¹">
                                <asp:MenuItem Text="ŧ����¹" Value="Enroll" NavigateUrl="~/Enroll.aspx" Target="_blank"></asp:MenuItem>
                                <asp:MenuItem Text="��������Ԫ�" Value="AddEnroll" NavigateUrl="~/AddEnroll.aspx" Target="_blank"></asp:MenuItem>
                                <asp:MenuItem Text="�͹����Ԫ�" Value="DropEnroll" NavigateUrl="~/DropEnroll.aspx" Target="_blank"></asp:MenuItem>
                            </asp:MenuItem>
                            <asp:MenuItem Text="�к����Ǩ�����Դ���" Value="�к����Ǩ�����Դ���">
                                <asp:MenuItem Text="ŧ��ṹ" Value="Poll" NavigateUrl="~/Poll.aspx" Target="_blank"></asp:MenuItem>
                                <asp:MenuItem Text="�ټ����Ǩ" Value="ViewPoll" NavigateUrl="~/ViewPoll.aspx" Target="_blank"></asp:MenuItem>
                            </asp:MenuItem>
                            <asp:MenuItem Text="�ٵ��ҧ���¹" Value="ViewSchedule" NavigateUrl="~/Schedule.aspx" Target="_blank"></asp:MenuItem>
                            <asp:MenuItem Text="�ټš�����¹" Value="ViewGrade" NavigateUrl="~/ViewGrade.aspx" Target="_blank"></asp:MenuItem>
                            <asp:MenuItem Text="��͡��ҷ�" Value="Logout"></asp:MenuItem>
                        </Items>
                        <StaticHoverStyle BackColor="#284E98" ForeColor="White" />
                        <LevelSubMenuStyles>
                            <asp:SubMenuStyle Font-Underline="False" Width="100px" />
                        </LevelSubMenuStyles>
                    </asp:Menu>
                </td>
                <td style="width: 688px; vertical-align: top; text-align: left;" bordercolor="#ffffff">
                        <table cellspacing="0" style="font-size: 10pt; font-family: Tahoma; width: 585px;">
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label3" runat="server" Font-Bold="False" Font-Names="Tahoma" Font-Size="Small"
                                        Text="���ʻ�Шӵ�� :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbStudentID" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label4" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�ӹ�˹�Ҫ��� (��) :"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbPrefixNameTH" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label5" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="����-���ʡ�� (��) :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbNameTH" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 24px">
                                    <asp:Label ID="Label6" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�ӹ�˹�Ҫ��� (Eng.) :"></asp:Label></td>
                                <td style="height: 24px; width: 150px;">
                                    <asp:Label ID="lbPrefixNameENG" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td style="height: 24px; width: 150px;">
                                </td>
                                <td style="height: 24px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 19px">
                                    <asp:Label ID="Label7" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="����-���ʡ�� (Eng.) :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 19px; width: 150px;">
                                    <asp:Label ID="lbNameENG" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 19px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 19px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label8" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�ѹ-��͹-���Դ :"></asp:Label>
                                </td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbBirthDay" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td align="right" style="height: 20px; width: 150px;">
                                    <asp:Label ID="Label9" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�� :"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbSex" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label10" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="ʶҹ�Ҿ�ѡ�֡�� :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbStatus" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label11" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="����������Ѻ��� :"></asp:Label>
                                </td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbType" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label12" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�շ������֡�� :"></asp:Label>
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbInComingYear" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td align="right" bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="Label13" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�շ������稡���֡�� :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbOutGoingYear" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label14" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="��� :"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbFaculty" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label15" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�Ҥ�Ԫ� :"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbDepartment" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" style="width: 150px; height: 20px">
                                    <asp:Label ID="Label16" runat="server" Font-Names="Tahoma" Font-Size="Small" Text="�Ң��Ԫ� :"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                    <asp:Label ID="lbBranch" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                                <td style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="width: 150px; height: 20px">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                                <td bgcolor="#eff3fb" style="height: 20px; width: 150px;">
                                </td>
                            </tr>
                        </table>
                </td>
            </tr>
        </table>
        <br />
        <br />
    </form>
</body>
</html>
