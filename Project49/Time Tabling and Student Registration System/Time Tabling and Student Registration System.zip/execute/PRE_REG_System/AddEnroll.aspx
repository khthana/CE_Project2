<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AddEnroll.aspx.cs" Inherits="PRE_REG_System.AddEnroll" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <div style="text-align: center">
            <asp:ScriptManager ID="smEnroll" runat="server">
            </asp:ScriptManager>
            <table cellspacing="0" width="750" align="center">
                <tr>
                    <td align="center" bgcolor="#507cd1" colspan="4" style="width: 605px; height: 25px;
                        text-align: center">
                        <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma">
                            <asp:Label ID="Label1" runat="server" Font-Bold="True" Text="��������Ԫ�" Width="750px"></asp:Label></span></td>
                </tr>
                <tr>
                    <td align="left" bgcolor="#eff3fb" style="height: 20px" width="350">
                        &nbsp;<asp:Label ID="lbStudentCode" runat="server" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="#333333"></asp:Label></td>
                    <td align="left" bgcolor="#eff3fb" style="width: 1054px; height: 20px">
                        <asp:Label ID="lbStudentName" runat="server" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="#333333"></asp:Label></td>
                    <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                        <asp:Label ID="lbStudentYear" runat="server" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="#333333"></asp:Label></td>
                    <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                        <asp:Label ID="lbCurrentTerm" runat="server" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="#333333"></asp:Label>&nbsp;</td>
                </tr>
            </table>
            <br />
            <asp:UpdatePanel ID="upEnrollTable" runat="server">
                <ContentTemplate>
                    <table cellspacing="0" width="750" align="center">
                        <tr>
                            <td align="left" bgcolor="#dcdcdc" style="height: 20px">
                                &nbsp;<span style="color: #333333; font-family: Tahoma"><strong>����Ԫҷ��ŧ����¹</strong></span></td>
                        </tr>
                        <tr>
                            <td align="center" style="height: 20px">
                    <asp:GridView ID="gvEnroll" runat="server" BackColor="White" BorderColor="#6B696B"
                        BorderStyle="Solid" BorderWidth="1px" CellPadding="4" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="Black" GridLines="None" OnRowCreated="gvEnroll_RowCreated" OnRowDeleting="gvEnroll_RowDeleting"
                        Width="750px">
                        <FooterStyle BackColor="#CCCC99" />
                        <Columns>
                            <asp:CommandField ButtonType="Button" DeleteText="¡��ԡ.." ShowDeleteButton="True">
                                <ControlStyle BackColor="White" BorderColor="#6B696B" BorderStyle="Solid" BorderWidth="1px"
                                    Width="55px" />
                            </asp:CommandField>
                        </Columns>
                        <RowStyle BackColor="#F7F7DE" />
                        <SelectedRowStyle BackColor="#CE5D5A" Font-Bold="False" ForeColor="White" />
                        <PagerStyle BackColor="#F7F7DE" ForeColor="Black" HorizontalAlign="Right" />
                        <HeaderStyle BackColor="#6B696B" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
                        <AlternatingRowStyle BackColor="White" />
                    </asp:GridView>
                            </td>
                        </tr>
                    </table>
                    <table cellspacing="0" width="750" align="center">
                        <tr>
                            <td align="left" bgcolor="#cccc99" style="height: 20px">
                                &nbsp;<asp:Label ID="lbErrorMsg" runat="server" Font-Names="Tahoma" Font-Size="Small"
                                    ForeColor="Red"></asp:Label></td>
                            <td align="right" bgcolor="#cccc99" style="height: 20px">
                                <asp:Label ID="lbSumUnit" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label>&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="left" style="height: 20px">
                                <asp:Button ID="btnBack" runat="server" OnClick="btnBack_Click" Text="< ��͹��Ѻ"
                                    Visible="False" Width="120px" /></td>
                            <td align="right" style="height: 20px">
                                <asp:Button ID="btnEnroll" runat="server" OnClick="btnEnroll_Click" Text="��������Ԫ�"
                                    Visible="False" Width="120px" /><asp:Button ID="btnNext" runat="server" OnClick="btnNext_Click"
                                        Text="��鹵͹���� >" Width="120px" /></td>
                        </tr>
                    </table>
                </ContentTemplate>
            </asp:UpdatePanel>
            &nbsp;&nbsp;<br />
            <asp:UpdatePanel ID="upSubjectTable" runat="server">
                <ContentTemplate>
                    <asp:MultiView ID="mwEnroll" runat="server">
                        <asp:View ID="viewSubject" runat="server">
                            <table cellspacing="0" width="750" align="center">
                                <tr>
                                    <td align="left" bgcolor="gainsboro" style="height: 20px; width: 480px;">
                                        &nbsp;<span style="color: #333333; font-family: Tahoma"><strong>��ª����Ԫ�</strong></span></td>
                                    <td align="right" bgcolor="gainsboro" style="height: 20px;" width="350">
                                        <asp:DropDownList ID="ddlSubjectGroup" runat="server" AutoPostBack="True" OnSelectedIndexChanged="ddlSubjectGroup_SelectedIndexChanged">
                                            <asp:ListItem Value="MTH">�ԪҤ�Ե��ʵ��</asp:ListItem>
                                            <asp:ListItem Value="LS">�Ԫ�����</asp:ListItem>
                                            <asp:ListItem Value="CC">�ԪҺѧ�Ѻ</asp:ListItem>
                                            <asp:ListItem Value="CEC">�ԪҺѧ�Ѻ���͡</asp:ListItem>
                                            <asp:ListItem Value="EC">�Ԫ����͡੾���Ң�</asp:ListItem>
                                        </asp:DropDownList></td>
                                </tr>
                            </table>
                            <table align="center" cellspacing="0" width="750">
                                <tr>
                                    <td>
                            <asp:GridView ID="gvSubject" runat="server" AllowPaging="True" BorderColor="#507CD1"
                                BorderStyle="Solid" BorderWidth="1px" CellPadding="4" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="#333333" GridLines="None" OnPageIndexChanging="gvSubject_PageIndexChanging"
                                OnRowCommand="gvSubject_RowCommand" OnRowCreated="gvSubject_RowCreated" PageSize="7"
                                Width="750px">
                                <FooterStyle Font-Bold="True" ForeColor="White" Height="5px" />
                                <Columns>
                                    <asp:CommandField ButtonType="Button" HeaderText="����" SelectText="����.." ShowSelectButton="True">
                                        <ControlStyle BackColor="White" BorderColor="#507CD1" BorderStyle="Solid" BorderWidth="1px"
                                            ForeColor="#284E98" Width="55px" />
                                    </asp:CommandField>
                                </Columns>
                                <RowStyle BackColor="#EFF3FB" />
                                <EditRowStyle BackColor="#2461BF" />
                                <SelectedRowStyle Font-Bold="False" ForeColor="#333333" />
                                <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Right" />
                                <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
                                <AlternatingRowStyle BackColor="White" />
                            </asp:GridView>
                                    </td>
                                </tr>
                            </table>
                        </asp:View>
                        <asp:View ID="ViewEmpty" runat="server">
                        </asp:View>
                    </asp:MultiView>
                </ContentTemplate>
            </asp:UpdatePanel>
            &nbsp; &nbsp; &nbsp;&nbsp;
        </div>
    
    </div>
    </form>
</body>
</html>
