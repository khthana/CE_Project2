using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class EditGrade : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveTeacher"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            // Manual Set Session and Application
            /*Application["CurrentTerm"] = "1";
            Application["CurrentYear"] = "2549";*/

            if (!IsPostBack)
            {
                DataTable dtbStatus = WebUtility.LoadCurrentStatus();
                Application["CurrentTerm"] = dtbStatus.Rows[0]["CurrentTerm"].ToString();
                Application["CurrentYear"] = dtbStatus.Rows[0]["CurrentYear"].ToString();

                mwEditGrade.SetActiveView(viewSelectSubject);
            }
        }

        protected String GetLoadGradeCommand(String subjectCode, int currentTerm, int currentYear)
        {
            String commandText = "SELECT ENROLL.SCODE, SPROFILE.PREFIX_SNAME_TH, SPROFILE.SNAME_TH, " +
                "ENROLL.MID, ENROLL.FINAL, ENROLL.TOTAL, ENROLL.GRADE, " +
                "ENROLL.HW1, ENROLL.HW2, ENROLL.HW3, ENROLL.HW4, ENROLL.HW5 " +
                "FROM SPROFILE,ENROLL " +
                "WHERE SPROFILE.SCODE=ENROLL.SCODE AND ENROLL.SUB_CODE='" + subjectCode + "' " +
                "AND ENROLL.TERM=" + currentTerm + " AND ENROLL.YEAR=" + currentYear;

            return commandText;
        }
        protected String GetUpdateGradeCommand(String studentCode, String subjectCode,
            int HW1, int HW2, int HW3, int HW4, int HW5, int mid, int final, int total, String grade)
        {
            String commandText = "UPDATE ENROLL " +
                "SET HW1=" + HW1 +
                ",HW2=" + HW2 +
                ",HW3=" + HW3 +
                ",HW4=" + HW4 +
                ",HW5=" + HW5 +
                ",MID=" + mid +
                ",FINAL=" + final +
                ",TOTAL=" + total +
                ",GRADE='" + grade + "'" +
                " WHERE SCODE='" + studentCode + "' AND SUB_CODE='" + subjectCode + "'";

            return commandText;
        }

        protected String GetLoadGradeHeaderCommand(String subjectCode)
        {
            String commandText = "SELECT MAX_HW1, MAX_HW2, MAX_HW3, MAX_HW4, MAX_HW5, MAX_MID, MAX_FINAL " +
                "FROM SUBJECT " +
                "WHERE SUB_CODE='" + subjectCode + "'";

            return commandText;
        }
        protected String GetUpdateGradeHeaderCommand(String subjectCode, int maxHW1, int maxHW2, int maxHW3, int maxHW4, int maxHW5,
            int maxMid, int maxFinal)
        {
            String commandText = "UPDATE SUBJECT " +
                "SET MAX_HW1=" + maxHW1 +
                ",MAX_HW2=" + maxHW2 +
                ",MAX_HW3=" + maxHW3 +
                ",MAX_HW4=" + maxHW4 +
                ",MAX_HW5=" + maxHW5 +
                ",MAX_MID=" + maxMid +
                ",MAX_FINAL=" + maxFinal +
                " WHERE SUB_CODE='" + subjectCode + "'";

            return commandText;
        }
        protected String GetSubjectName(String subjectCode)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT SUB_NAME FROM SUBJECT WHERE SUB_CODE='" + subjectCode +"'";

            OracleCommand command = new OracleCommand(commandText);
            command.Connection = connection;
            command.CommandType = CommandType.Text;

            OracleDataReader reader = command.ExecuteReader();

            String subjectName = "";

            if (reader.Read())
            {
                subjectName = reader.GetString(0);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return subjectName;
        }
        protected void menuTeacher_MenuItemClick(object sender, MenuEventArgs e)
        {
            if (e.Item.Value == "Logout")
            {
                Session.RemoveAll();
                Response.Redirect("Default.aspx");
            }
        }
        protected void gvEditGrade_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            }
        }
        protected void btnConfirmGrade_Click(object sender, EventArgs e)
        {
            String subjectCode = Session["SubjectCode"].ToString();

            foreach (GridViewRow gvrow in gvEditGrade.Rows)
            {
                String studentCode = gvrow.Cells[0].Text;

                int HW1 = Convert.ToInt32(gvrow.Cells[2].Text);
                int HW2 = Convert.ToInt32(gvrow.Cells[3].Text);
                int HW3 = Convert.ToInt32(gvrow.Cells[4].Text);
                int HW4 = Convert.ToInt32(gvrow.Cells[5].Text);
                int HW5 = Convert.ToInt32(gvrow.Cells[6].Text);
                int mid = Convert.ToInt32(gvrow.Cells[7].Text);
                int final = Convert.ToInt32(gvrow.Cells[8].Text);
                int total = HW1 + HW2 + HW3 + HW4 + HW5 + mid + final;

                String grade = gvrow.Cells[10].Text;

                String updateCommandText = GetUpdateGradeCommand(studentCode,
                    subjectCode,HW1,HW2,HW3,HW4,HW5,mid,final,total,grade);

                sqldsEditGrade.UpdateCommand = updateCommandText;
                sqldsEditGrade.Update();
            }

            gvEditGrade.Enabled = true;
            btnNext.Visible = true;
            btnCancel.Visible = true;
            btnBack.Visible = false;
            btnConfirmGrade.Visible = false;

            txtSubjectCode.Text = "";
            lbResult.ForeColor = System.Drawing.Color.LimeGreen;
            lbResult.Text = "�ӡ�úѹ�֡���������º��������...";
            
            Session.Remove("SubjectCode");

            mwEditGrade.SetActiveView(viewSelectSubject);
        }
        protected void btnNext_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow gvrow in gvEditGrade.Rows)
            {
                TextBox txtHW1 = (TextBox)gvrow.Cells[2].FindControl("txtHW1");
                TextBox txtHW2 = (TextBox)gvrow.Cells[3].FindControl("txtHW2");
                TextBox txtHW3 = (TextBox)gvrow.Cells[4].FindControl("txtHW3");
                TextBox txtHW4 = (TextBox)gvrow.Cells[5].FindControl("txtHW4");
                TextBox txtHW5 = (TextBox)gvrow.Cells[6].FindControl("txtHW5");
                TextBox txtMid = (TextBox)gvrow.Cells[7].FindControl("txtMid");
                TextBox txtFinal = (TextBox)gvrow.Cells[8].FindControl("txtFinal");
                DropDownList ddlGrade = (DropDownList)gvrow.Cells[10].FindControl("ddlGrade");

                int HW1 = Convert.ToInt32(txtHW1.Text);
                int HW2 = Convert.ToInt32(txtHW2.Text);
                int HW3 = Convert.ToInt32(txtHW3.Text);
                int HW4 = Convert.ToInt32(txtHW4.Text);
                int HW5 = Convert.ToInt32(txtHW5.Text);
                int mid = Convert.ToInt32(txtMid.Text);
                int final = Convert.ToInt32(txtFinal.Text);
                int total = HW1 + HW2 + HW3 + HW4 + HW5 + mid + final;

                gvrow.Cells[2].Text = txtHW1.Text;
                gvrow.Cells[3].Text = txtHW2.Text;
                gvrow.Cells[4].Text = txtHW3.Text;
                gvrow.Cells[5].Text = txtHW4.Text;
                gvrow.Cells[6].Text = txtHW5.Text;
                gvrow.Cells[7].Text = txtMid.Text;
                gvrow.Cells[8].Text = txtFinal.Text;
                gvrow.Cells[9].Text = total.ToString();
                gvrow.Cells[10].Text = ddlGrade.SelectedItem.Text;
            }

            gvEditHeader.Rows[0].Cells[0].Enabled = false;
            
            btnNext.Visible = false;
            btnCancel.Visible = false;

            btnBack.Visible = true;
            btnConfirmGrade.Visible = true;
        }
        protected void btnBack_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow gvrow in gvEditGrade.Rows)
            {
                TextBox txtHW1 = (TextBox)gvrow.Cells[2].FindControl("txtHW1");
                TextBox txtHW2 = (TextBox)gvrow.Cells[3].FindControl("txtHW2");
                TextBox txtHW3 = (TextBox)gvrow.Cells[4].FindControl("txtHW3");
                TextBox txtHW4 = (TextBox)gvrow.Cells[5].FindControl("txtHW4");
                TextBox txtHW5 = (TextBox)gvrow.Cells[6].FindControl("txtHW5");
                TextBox txtMid = (TextBox)gvrow.Cells[7].FindControl("txtMid");
                TextBox txtFinal = (TextBox)gvrow.Cells[8].FindControl("txtFinal");
                DropDownList ddlGrade = (DropDownList)gvrow.Cells[10].FindControl("ddlGrade");

                txtHW1.Text = gvrow.Cells[2].Text;
                txtHW2.Text = gvrow.Cells[3].Text;
                txtHW3.Text = gvrow.Cells[4].Text;
                txtHW4.Text = gvrow.Cells[5].Text;
                txtHW5.Text = gvrow.Cells[6].Text;
                txtMid.Text = gvrow.Cells[7].Text;
                txtFinal.Text = gvrow.Cells[8].Text;

                String grade = gvrow.Cells[10].Text;

                if (grade == "-") ddlGrade.SelectedIndex = 0;
                else if (grade == "A") ddlGrade.SelectedIndex = 1;
                else if (grade == "B+") ddlGrade.SelectedIndex = 2;
                else if (grade == "B") ddlGrade.SelectedIndex = 3;
                else if (grade == "C+") ddlGrade.SelectedIndex = 4;
                else if (grade == "C") ddlGrade.SelectedIndex = 5;
                else if (grade == "D+") ddlGrade.SelectedIndex = 6;
                else if (grade == "D") ddlGrade.SelectedIndex = 7;
                else if (grade == "F") ddlGrade.SelectedIndex = 8;
                else if (grade == "Fa") ddlGrade.SelectedIndex = 9;
                else if (grade == "Fe") ddlGrade.SelectedIndex = 10;
                else if (grade == "Fw") ddlGrade.SelectedIndex = 11;
                else if (grade == "W") ddlGrade.SelectedIndex = 12;
                else if (grade == "I") ddlGrade.SelectedIndex = 13;
                else if (grade == "S") ddlGrade.SelectedIndex = 14;
                else if (grade == "U") ddlGrade.SelectedIndex = 15;

                txtHW1.Style.Add("text-align", "right");
                txtHW2.Style.Add("text-align", "right");
                txtHW3.Style.Add("text-align", "right");
                txtHW4.Style.Add("text-align", "right");
                txtHW5.Style.Add("text-align", "right");
                txtMid.Style.Add("text-align", "right");
                txtFinal.Style.Add("text-align", "right");
            }

            gvEditHeader.Rows[0].Cells[0].Enabled = true;

            btnNext.Visible = true;
            btnCancel.Visible = true;
            btnBack.Visible = false;
            btnConfirmGrade.Visible = false;
        }
        protected void btnOK_Click(object sender, EventArgs e)
        {
            lbResult.Text = "";

            String subjectCode = txtSubjectCode.Text;
            String subjectName = GetSubjectName(subjectCode);
            
            if (subjectName != "")
            {
                Session["SubjectCode"] = subjectCode;

                int currentTerm = Convert.ToInt32(Application["CurrentTerm"]);
                int currentYear = Convert.ToInt32(Application["CurrentYear"]);
                
                String selectCommandText = GetLoadGradeCommand(subjectCode, currentTerm, currentYear);

                lbSubjectCode.Text = "�����Ԫ� : " + subjectCode;
                lbSubjectName.Text = "�����Ԫ� : " + subjectName;

                sqldsEditGrade.SelectCommand = selectCommandText;
                sqldsEditGrade.Select(DataSourceSelectArguments.Empty);
                gvEditGrade.DataSource = sqldsEditGrade;
                gvEditGrade.DataBind();

                //--------------------------------------------------------
                selectCommandText = GetLoadGradeHeaderCommand(subjectCode);
                sqldsEditHeader.SelectCommand = selectCommandText;
                sqldsEditHeader.Select(DataSourceSelectArguments.Empty);
                gvEditHeader.DataSource = sqldsEditHeader;
                gvEditHeader.DataBind();
                //--------------------------------------------------------

                mwEditGrade.SetActiveView(viewEditGrade);
            }
            else 
            {
                lbResult.ForeColor = System.Drawing.Color.Red;
                lbResult.Text = "�����Ԫ����١��ͧ...";
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtSubjectCode.Text = "";
            mwEditGrade.SetActiveView(viewSelectSubject);
        }

        protected void gvEditGrade_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TextBox txtHW1 = (TextBox)e.Row.Cells[2].FindControl("txtHW1");
                TextBox txtHW2 = (TextBox)e.Row.Cells[3].FindControl("txtHW2");
                TextBox txtHW3 = (TextBox)e.Row.Cells[4].FindControl("txtHW3");
                TextBox txtHW4 = (TextBox)e.Row.Cells[5].FindControl("txtHW4");
                TextBox txtHW5 = (TextBox)e.Row.Cells[6].FindControl("txtHW5");
                TextBox txtMID = (TextBox)e.Row.Cells[7].FindControl("txtMID");
                TextBox txtFinal = (TextBox)e.Row.Cells[8].FindControl("txtFinal");

                txtHW1.Style.Add("text-align", "right");
                txtHW2.Style.Add("text-align", "right");
                txtHW3.Style.Add("text-align", "right");
                txtHW4.Style.Add("text-align", "right");
                txtHW5.Style.Add("text-align", "right");
                txtMID.Style.Add("text-align", "right");
                txtFinal.Style.Add("text-align", "right");
            }
        }

        protected void gvEditHeader_RowEditing(object sender, GridViewEditEventArgs e)
        {
            int index = e.NewEditIndex;
            gvEditHeader.EditIndex = index;

            String subjectCode = Session["SubjectCode"].ToString();

            String selectCommandText = GetLoadGradeHeaderCommand(subjectCode);
            sqldsEditHeader.SelectCommand = selectCommandText;
            sqldsEditHeader.Select(DataSourceSelectArguments.Empty);
            gvEditHeader.DataSource = sqldsEditHeader;
            gvEditHeader.DataBind();

            foreach (GridViewRow gvrow in gvEditHeader.Rows)
            {
                TextBox txtHW1 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW1");
                TextBox txtHW2 = (TextBox)gvrow.Cells[3].FindControl("txtMaxHW2");
                TextBox txtHW3 = (TextBox)gvrow.Cells[4].FindControl("txtMaxHW3");
                TextBox txtHW4 = (TextBox)gvrow.Cells[5].FindControl("txtMaxHW4");
                TextBox txtHW5 = (TextBox)gvrow.Cells[6].FindControl("txtMaxHW5");
                TextBox txtMid = (TextBox)gvrow.Cells[7].FindControl("txtMaxMID");
                TextBox txtFinal = (TextBox)gvrow.Cells[8].FindControl("txtMaxFinal");

                txtHW1.Style.Add("text-align", "right");
                txtHW2.Style.Add("text-align", "right");
                txtHW3.Style.Add("text-align", "right");
                txtHW4.Style.Add("text-align", "right");
                txtHW5.Style.Add("text-align", "right");
                txtMid.Style.Add("text-align", "right");
                txtFinal.Style.Add("text-align", "right");
            }

            btnNext.Enabled = false;
        }

        protected void gvEditHeader_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvEditHeader.EditIndex = -1;

            String subjectCode = Session["SubjectCode"].ToString();

            String selectCommandText = GetLoadGradeHeaderCommand(subjectCode);
            sqldsEditHeader.SelectCommand = selectCommandText;
            sqldsEditHeader.Select(DataSourceSelectArguments.Empty);
            gvEditHeader.DataSource = sqldsEditHeader;
            gvEditHeader.DataBind();

            btnNext.Enabled = true;
        }

        protected void gvEditHeader_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            String subjectCode = Session["SubjectCode"].ToString();

            foreach (GridViewRow gvrow in gvEditHeader.Rows)
            {
                TextBox txtMaxHW1 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW1");
                TextBox txtMaxHW2 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW2");
                TextBox txtMaxHW3 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW3");
                TextBox txtMaxHW4 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW4");
                TextBox txtMaxHW5 = (TextBox)gvrow.Cells[2].FindControl("txtMaxHW5");
                TextBox txtMaxMid = (TextBox)gvrow.Cells[2].FindControl("txtMaxMid");
                TextBox txtMaxFinal = (TextBox)gvrow.Cells[2].FindControl("txtMaxFinal");

                int maxHW1 = Convert.ToInt32(txtMaxHW1.Text);
                int maxHW2 = Convert.ToInt32(txtMaxHW2.Text);
                int maxHW3 = Convert.ToInt32(txtMaxHW3.Text);
                int maxHW4 = Convert.ToInt32(txtMaxHW4.Text);
                int maxHW5 = Convert.ToInt32(txtMaxHW5.Text);
                int maxMid = Convert.ToInt32(txtMaxMid.Text);
                int maxFinal = Convert.ToInt32(txtMaxFinal.Text);

                String updateCommandText = GetUpdateGradeHeaderCommand(subjectCode, 
                    maxHW1, maxHW2, maxHW3, maxHW4, maxHW5, maxMid, maxFinal);

                sqldsEditGrade.UpdateCommand = updateCommandText;
                sqldsEditGrade.Update();
            }

            String selectCommandText = GetLoadGradeHeaderCommand(subjectCode);
            sqldsEditHeader.SelectCommand = selectCommandText;
            sqldsEditHeader.Select(DataSourceSelectArguments.Empty);
            
            gvEditHeader.EditIndex = -1;
            gvEditHeader.DataSource = sqldsEditHeader;
            gvEditHeader.DataBind();

            btnNext.Enabled = true;
        }

        protected void gvEditHeader_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].Font.Bold = true;
                e.Row.Cells[9].Font.Bold = true;

                e.Row.Cells[1].Text = "��ṹ���";
                e.Row.Cells[9].Text = "100%";
            }
        }
    }
}
