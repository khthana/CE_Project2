using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class AddEnroll : System.Web.UI.Page
    {
        protected DataSet dsetEnroll = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else if (Convert.ToInt32(Application["AddStatus"]) == 0)
            {
                Session["ResultMessage"] = "�к��ѧ����Դ���ӡ����������Ԫ�...";
                Response.Redirect("Result.aspx");
            }

            // Manual Set Session and Application
            /*Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���оѲ�� �ѧ�����";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "2";
            Application["CurrentYear"] = "2549";*/

            lbStudentCode.Text = "���ʹѡ�֡�� : " + Session["StudentCode"].ToString();
            lbStudentName.Text = "���� - ���ʡ�� : " + Session["StudentName"].ToString();
            lbStudentYear.Text = "��鹻շ�� : " + Session["StudentYear"].ToString();
            lbCurrentTerm.Text = "�Ҥ���¹��� : " + Application["CurrentTerm"].ToString();

            if (!IsPostBack)
            {
                String studentCode = Session["StudentCode"].ToString();
                String currentTerm = Application["CurrentTerm"].ToString();
                String currentYear = Application["CurrentYear"].ToString();

                DataTable dtbEnroll = WebUtility.LoadEnrollData(studentCode, currentTerm, currentYear);

                dsetEnroll.Tables.Add(dtbEnroll);
                Session["AddEnroll"] = dsetEnroll;

                Application["MTH"] = WebUtility.LoadSubjectData("MTH");
                Application["LS"] = WebUtility.LoadSubjectData("LS");
                Application["CC"] = WebUtility.LoadSubjectData("CC");
                Application["CEC"] = WebUtility.LoadSubjectData("CEC");
                Application["EC"] = WebUtility.LoadSubjectData("EC");

                ddlSubjectGroup.SelectedIndex = 3;
                gvSubject.DataSource = (DataTable)Application["CEC"];
                gvSubject.DataBind();

                mwEnroll.SetActiveView(viewSubject);

                dsetEnroll = (DataSet)Session["AddEnroll"];
                gvEnroll.DataSource = dsetEnroll.Tables["EnrollData"];
                gvEnroll.DataBind();

                Session["RowCount"] = gvEnroll.Rows.Count;
            }
            
            dsetEnroll = (DataSet)Session["AddEnroll"];
            gvEnroll.DataSource = dsetEnroll.Tables["EnrollData"];
            gvEnroll.DataBind();

            int rowCount = Convert.ToInt32(Session["RowCount"].ToString());
            DisableEnrollRow(rowCount);
        }
        protected void DisableEnrollRow(int rowCount)
        {
            for (int i = 0; i < rowCount; i++)
            {
                gvEnroll.Rows[i].Enabled = false;
            }
        }
        protected void gvEnroll_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            dsetEnroll = (DataSet)Session["AddEnroll"];

            int index = Convert.ToInt32(e.RowIndex);
            GridViewRow deleteRow = gvEnroll.Rows[index];

            String subjectCode = deleteRow.Cells[1].Text;
            for (int i = 0; i < gvSubject.Rows.Count; i++)
            {
                if (gvSubject.Rows[i].Cells[1].Text == subjectCode)
                {
                    gvSubject.Rows[i].Enabled = true;
                }
            }

            dsetEnroll.Tables["EnrollData"].Rows[index].Delete();
            Session["AddEnroll"] = dsetEnroll;

            lbErrorMsg.Text = "";
            int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["EnrollData"]);
            lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";

            gvEnroll.DataSource = dsetEnroll.Tables["EnrollData"];
            gvEnroll.DataBind();

            int rowCount = Convert.ToInt32(Session["RowCount"].ToString());
            DisableEnrollRow(rowCount);
        }

        protected void gvEnroll_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Width = 50;
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[1].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;

                e.Row.Cells[3].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
        }

        protected void gvSubject_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow selectedRow = gvSubject.Rows[index];

                dsetEnroll = (DataSet)Session["AddEnroll"];

                DataRow drow = dsetEnroll.Tables["EnrollData"].NewRow();
                drow["�����Ԫ�"] = selectedRow.Cells[1].Text;
                drow["�����Ԫ�"] = selectedRow.Cells[2].Text;
                drow["˹��¡Ե"] = selectedRow.Cells[3].Text;

                dsetEnroll.Tables["EnrollData"].Rows.Add(drow);

                Session["AddEnroll"] = dsetEnroll;
                selectedRow.Enabled = false;

                int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["EnrollData"]);
                lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";

                gvEnroll.DataSource = dsetEnroll.Tables["EnrollData"];
                gvEnroll.DataBind();

                int rowCount = Convert.ToInt32(Session["RowCount"].ToString());
                DisableEnrollRow(rowCount);
            }
        }

        protected void gvSubject_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Width = 50;
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[1].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;

                e.Row.Cells[3].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }

            dsetEnroll = (DataSet)Session["AddEnroll"];

            foreach (DataRow drow in dsetEnroll.Tables["EnrollData"].Rows)
            {
                String subjectCode = drow["�����Ԫ�"].ToString();

                for (int i = 0; i < gvSubject.Rows.Count; i++)
                {
                    if (gvSubject.Rows[i].Cells[1].Text == subjectCode)
                    {
                        gvSubject.Rows[i].Enabled = false;
                    }
                }
            }
        }

        protected void gvSubject_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (ddlSubjectGroup.SelectedItem.Value == "MTH")
            {
                gvSubject.DataSource = (DataTable)Application["MTH"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "LS")
            {
                gvSubject.DataSource = (DataTable)Application["LS"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CC")
            {
                gvSubject.DataSource = (DataTable)Application["CC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = (DataTable)Application["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = (DataTable)Application["EC"];
            }

            gvSubject.PageIndex = e.NewPageIndex;
            gvSubject.DataBind();
        }

        protected void ddlSubjectGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSubjectGroup.SelectedItem.Value == "MTH")
            {
                gvSubject.DataSource = (DataTable)Application["MTH"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "LS")
            {
                gvSubject.DataSource = (DataTable)Application["LS"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CC")
            {
                gvSubject.DataSource = (DataTable)Application["CC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = (DataTable)Application["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = (DataTable)Application["EC"];
            }

            gvSubject.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            int sumUnit = WebUtility.CalculateSumUnit(dsetEnroll.Tables["EnrollData"]);

            if (sumUnit > 22)
            {
                lbErrorMsg.Text = "�س�������öŧ����¹�Թ 22 ˹��¡Ե";
            }
            else
            {
                btnNext.Visible = false;
                gvEnroll.Enabled = false;
                mwEnroll.SetActiveView(ViewEmpty);

                btnBack.Visible = true;
                btnEnroll.Visible = true;
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            btnNext.Visible = true;
            gvEnroll.Enabled = true;
            mwEnroll.SetActiveView(viewSubject);

            btnBack.Visible = false;
            btnEnroll.Visible = false;
        }

        protected void btnEnroll_Click(object sender, EventArgs e)
        {
            String studentCode = Session["StudentCode"].ToString();
            String currentTerm = Application["CurrentTerm"].ToString();
            String currentYear = Application["CurrentYear"].ToString();

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand cmd = connection.CreateCommand();

            // Get number row to delete
            int rowCount = Convert.ToInt32(Session["RowCount"].ToString());

            // Delete enrolled data 
            for (int i = 0; i < rowCount; i++)
            {
                dsetEnroll.Tables["EnrollData"].Rows[0].Delete();
            }

            // Insert new enroll data
            foreach (DataRow drow in dsetEnroll.Tables["EnrollData"].Rows)
            {
                String subjectCode = drow["�����Ԫ�"].ToString();

                String commandText = "INSERT INTO ENROLL (SCODE,SUB_CODE,GRADE,TERM,YEAR)" +
                    "VALUES ('" + studentCode + "','" + subjectCode + "',' ','" + currentTerm + "','" + currentYear + "')";

                cmd.CommandText = commandText;
                cmd.ExecuteNonQuery();
            }

            transaction.Commit();
            connection.Close();

            // Delete Session
            Session.Remove("RowCount");
            Session.Remove("AddEnroll");

            Session["ResultMessage"] = "�ӡ����������Ԫ����º��������...";
            Response.Redirect("Result.aspx");
        }
    }
}
