<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ViewPoll.aspx.cs" Inherits="PRE_REG_System.ViewPoll" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body>
    <form id="form1" runat="server">
    <div style="text-align: center">
        <table cellspacing="0" style="text-align: center" width="750" align="center">
            <tr>
                <td bgcolor="#507cd1" style="height: 25px" colspan="2">
                    <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma"><strong>�š�����Ǩ����ش</strong></span></td>
            </tr>
            <tr>
                <td style="height: 20px" align="left" bgcolor="whitesmoke">
                    &nbsp;</td>
                <td align="right" bgcolor="whitesmoke" style="height: 20px">
                    <asp:Label ID="lbDate" runat="server" Font-Bold="False" Font-Names="Tahoma" Font-Size="Small"></asp:Label>
                    <asp:Label ID="lbTime" runat="server" Font-Bold="False" Font-Names="Tahoma" Font-Size="Small"></asp:Label>&nbsp;</td>
            </tr>
            <tr>
                <td style="height: 25px" colspan="2">
        <asp:Table ID="tblSchedule" runat="server" BorderColor="DarkGray" BorderStyle="Solid"
            BorderWidth="1px" CellPadding="1" CellSpacing="0" Font-Names="Tahoma" Font-Size="Small"
            GridLines="Both" Width="750px" ForeColor="#333333">
            <asp:TableRow runat="server" BackColor="#507CD1" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px" Font-Bold="False">
                <asp:TableCell runat="server" BackColor="White" BorderColor="DarkGray" BorderStyle="Solid"
                    BorderWidth="1px" HorizontalAlign="Center" Width="50px">-----</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">09.00 - 12.00</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">13.00 - 16.00</asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFFFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѹ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0FF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѧ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ظ</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFE0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">����ʺ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFFF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ء��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0C0FF" BorderColor="DarkGray" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�����</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ҷԵ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
        </asp:Table>
                </td>
            </tr>
            <tr>
                <td align="right" colspan="2" style="height: 25px">
                    <asp:Button ID="btnUpdate" runat="server" Text="�٢���������ش" Width="120px" /></td>
            </tr>
        </table>
        &nbsp; &nbsp;</div>
    </form>
</body>
</html>
