using System;
using System.Data;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class Poll : System.Web.UI.Page
    {
        protected DataSet dsetPoll = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            int studentYear = Convert.ToInt32(Session["StudentYear"]);
            int currentTerm = Convert.ToInt32(Application["CurrentTerm"]);

            if ((studentYear == 1) || ((studentYear == 2) && (currentTerm == 1)))
            {
                Session["ResultMessage"] = "�ѡ�֡���ѧ�������öŧ��ṹ��...";
                Response.Redirect("Result.aspx");
            }

            if (Convert.ToInt32(Application["PollStatus"]) == 0)
            {
                Session["ResultMessage"] = "�к��ѧ����Դ���ӡ��ŧ��ṹ...";
                Response.Redirect("Result.aspx");
            }


            String studentCode = Session["StudentCode"].ToString();
            int checkVote = WebUtility.GetVoteStatus(studentCode);

            if (checkVote == 1)
            {
                Session["ResultMessage"] = "�س��ӡ��ŧ��ṹ���º��������...";
                Response.Redirect("Result.aspx");
            }

            // Manual Set Session and Application
            /*Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���ͺ �к�";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "1";
            Application["CurrentYear"] = "2549";*/

            lbStudentCode.Text = "���ʹѡ�֡�� : " + Session["StudentCode"].ToString();
            lbStudentName.Text = "���� - ���ʡ�� : " + Session["StudentName"].ToString();
            lbStudentYear.Text = "��鹻շ�� : " + Session["StudentYear"].ToString();
            lbCurrentTerm.Text = "�Ҥ���¹��� : " + Application["CurrentTerm"].ToString();

            if (!IsPostBack)
            {
                DataTable dtbPoll = new DataTable();
                dtbPoll.TableName = "Poll";
                dtbPoll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
                dtbPoll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
                dtbPoll.Columns.Add("�ѹ", System.Type.GetType("System.String"));
                dtbPoll.Columns.Add("����", System.Type.GetType("System.String"));
                dtbPoll.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));
                dsetPoll.Tables.Add(dtbPoll);

                /*int studentYear = Convert.ToInt32(Session["StudentYear"].ToString());
                int currentTerm = Convert.ToInt32(Application["CurrentTerm"].ToString());*/

                // Load CEC subject data
                DataTable dtbCEC = WebUtility.LoadSubjectData("CEC");
                ArrayList cuttinglistCEC = CreateCuttingListCEC(studentYear, currentTerm);
                dtbCEC = CutSelectedSubject(dtbCEC, cuttinglistCEC);
                dsetPoll.Tables.Add(dtbCEC);

                // Load EC subject data
                DataTable dtbEC = WebUtility.LoadSubjectData("EC");
                ArrayList cuttinglistEC = CreateCuttingListEC(studentYear, currentTerm);
                dtbEC = CutSelectedSubject(dtbEC, cuttinglistEC);
                dsetPoll.Tables.Add(dtbEC);

                // Load poll data
                DataTable dtbPollData = WebUtility.LoadPollData();
                dsetPoll.Tables.Add(dtbPollData);

                Session["Poll"] = dsetPoll;
                ddlSubjectGroup.SelectedIndex = 0;
                mviewPoll.SetActiveView(viewPollSelect);

                gvSubject.DataSource = dsetPoll.Tables["CEC"];
                gvSubject.DataBind();
            }
            
            WebUtility.DisplayPollData(dsetPoll.Tables["PollData"], tblSchedule);
        }
        protected int SettingVoteUnit(int studentYear, int currentTerm)
        {
            int voteUnit = 0;

            if ((studentYear == 2) && (currentTerm == 1))
            {
                voteUnit = 0;
            }
            else if ((studentYear == 2) && (currentTerm == 2))
            {
                voteUnit = 7;
            }
            else if ((studentYear == 3) && (currentTerm == 1))
            {
                voteUnit = 13;
            }
            else if ((studentYear == 3) && (currentTerm == 2))
            {
                voteUnit = 12;
            }
            else if ((studentYear == 4) && (currentTerm == 1))
            {
                voteUnit = 19;
            }
            else if ((studentYear == 4) && (currentTerm == 2))
            {
                voteUnit = 19;
            }

            return voteUnit;
        }
        
        protected ArrayList CreateCuttingListCEC(int studentYear, int currentTerm)
        {
            ArrayList cuttingList = new ArrayList();

            if ((studentYear == 2) && (currentTerm == 1))
            {

            }
            else if ((studentYear == 2) && (currentTerm == 2))
            {
                cuttingList.Add("01073301");
                cuttingList.Add("01073302");
                cuttingList.Add("01073303");
                cuttingList.Add("01073304");
                cuttingList.Add("01073305");
                cuttingList.Add("01073306");
                cuttingList.Add("01073307");
                cuttingList.Add("01073402");
                cuttingList.Add("01073403");
                cuttingList.Add("01073404");
                cuttingList.Add("01073405");
                cuttingList.Add("01073501");
            }
            else if ((studentYear == 3) && (currentTerm == 1))
            {
                cuttingList.Add("01073304");
                cuttingList.Add("01073305");
                cuttingList.Add("01073402");
                cuttingList.Add("01073403");
                cuttingList.Add("01073404");
                cuttingList.Add("01073405");
            }
            else if ((studentYear == 3) && (currentTerm == 2))
            {
                cuttingList.Add("01073304");
                cuttingList.Add("01073305");
            }

            return cuttingList;
        }
        protected ArrayList CreateCuttingListEC(int studentYear, int currentTerm)
        {
            ArrayList cuttingList = new ArrayList();

            if ((studentYear == 2) && (currentTerm == 1))
            {

            }
            else if ((studentYear == 2) && (currentTerm == 2))
            {
                // HW subject
                cuttingList.Add("01074101");
                cuttingList.Add("01074102");
                cuttingList.Add("01074103");
                cuttingList.Add("01074104");
                cuttingList.Add("01074105");
                cuttingList.Add("01074107");
                // SW subject
                cuttingList.Add("01074201");
                cuttingList.Add("01074202");
                cuttingList.Add("01074203");
                cuttingList.Add("01074204");
                cuttingList.Add("01074205");
                cuttingList.Add("01074206");
                cuttingList.Add("01074207");
                cuttingList.Add("01074208");
                cuttingList.Add("01074209");
                cuttingList.Add("01074210");
                cuttingList.Add("01074211");
                cuttingList.Add("01074212");
                cuttingList.Add("01074213");
                cuttingList.Add("01074214");
                cuttingList.Add("01074215");
                cuttingList.Add("01074216");
                cuttingList.Add("01074217");
                cuttingList.Add("01074218");
                cuttingList.Add("01074219");
                cuttingList.Add("01074220");
                cuttingList.Add("01074221");
                cuttingList.Add("01074222");
                cuttingList.Add("01074223");
                cuttingList.Add("01074224");
                cuttingList.Add("01074225");
                cuttingList.Add("01074226");
                cuttingList.Add("01074227");
                cuttingList.Add("01074228");
                // NW subject
                cuttingList.Add("01074301");
                cuttingList.Add("01074302");
                cuttingList.Add("01074303");
                cuttingList.Add("01074304");
                cuttingList.Add("01074305");
                cuttingList.Add("01074306");
                cuttingList.Add("01074307");
                cuttingList.Add("01074310");
                cuttingList.Add("01074311");
                // AI subject
                cuttingList.Add("01074403");
                cuttingList.Add("01074404");
                cuttingList.Add("01074405");
                cuttingList.Add("01074407");
                cuttingList.Add("01074408");
                cuttingList.Add("01074409");
                cuttingList.Add("01074410");
                cuttingList.Add("01074411");
                cuttingList.Add("01074412");
                cuttingList.Add("01074414");
                cuttingList.Add("01074415");
            }
            else if ((studentYear == 3) && (currentTerm == 1))
            {
                // HW subject
                cuttingList.Add("01074103");
                // SW subject
                cuttingList.Add("01074201");
                cuttingList.Add("01074202");
                cuttingList.Add("01074203");
                cuttingList.Add("01074204");
                cuttingList.Add("01074209");
                cuttingList.Add("01074210");
                cuttingList.Add("01074211");
                cuttingList.Add("01074212");
                cuttingList.Add("01074214");
                cuttingList.Add("01074216");
                cuttingList.Add("01074218");
                cuttingList.Add("01074219");
                cuttingList.Add("01074220");
                cuttingList.Add("01074221");
                cuttingList.Add("01074222");
                cuttingList.Add("01074223");
                cuttingList.Add("01074226");
                // NW subject
                cuttingList.Add("01074302");
                cuttingList.Add("01074303");
                cuttingList.Add("01074304");
                cuttingList.Add("01074305");
                cuttingList.Add("01074306");
                cuttingList.Add("01074307");
                cuttingList.Add("01074310");
                cuttingList.Add("01074311");
                // AI subject
                cuttingList.Add("01074405");
                cuttingList.Add("01074407");
                cuttingList.Add("01074408");
                cuttingList.Add("01074409");
                cuttingList.Add("01074411");
                cuttingList.Add("01074412");
            }
            else if ((studentYear == 3) && (currentTerm == 2))
            {
                // SW subject
                cuttingList.Add("01074203");
                cuttingList.Add("01074204");
                cuttingList.Add("01074214");
                cuttingList.Add("01074216");
                cuttingList.Add("01074218");
                cuttingList.Add("01074220");
                cuttingList.Add("01074221");
                cuttingList.Add("01074222");
                cuttingList.Add("01074223");
                cuttingList.Add("01074226");
                // NW subject
                cuttingList.Add("01074303");
                cuttingList.Add("01074304");
                cuttingList.Add("01074306");
                cuttingList.Add("01074307");
            }

            return cuttingList;
        }
        protected DataTable CutSelectedSubject(DataTable dtbSubject, ArrayList cuttingList)
        {
            foreach (String sid in cuttingList)
            {
                for (int i = 0; i < dtbSubject.Rows.Count; i++)
                {
                    if (dtbSubject.Rows[i]["�����Ԫ�"].ToString() == sid)
                    {
                        dtbSubject.Rows[i].Delete();
                    }
                }
            }
            
            return dtbSubject;
        }
        
        protected void FilterDay(DropDownList ddlDay)
        {
            int studentYear = Convert.ToInt32(Session["StudentYear"].ToString());
            int term = Convert.ToInt32(Application["CurrentTerm"].ToString());

            if ((studentYear == 2) && (term == 1))
            {
                ddlDay.Items[2].Enabled = false;
                ddlDay.Items[3].Enabled = false;
                ddlDay.Items[4].Enabled = false;
                ddlDay.Items[5].Enabled = false;
                ddlDay.Items[6].Enabled = false;
            }
            else if ((studentYear == 2) && (term == 2))
            {
                ddlDay.Items[3].Enabled = false;
                ddlDay.Items[4].Enabled = false;
                ddlDay.Items[5].Enabled = false;
                ddlDay.Items[6].Enabled = false;
            }
            else if ((studentYear == 3) && (term == 1))
            {
                ddlDay.Items[2].Enabled = false;
                ddlDay.Items[5].Enabled = false;
            }
            else if ((studentYear == 4))
            {
                ddlDay.Items[6].Enabled = false;
            }
        }
        protected void gvSubject_RowCreated(object sender, GridViewRowEventArgs e)
        {
            // Create Controls and add in row
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                CheckBox cbSelect = new CheckBox();
                cbSelect.ID = e.Row.RowIndex.ToString();
                cbSelect.AutoPostBack = true;
                cbSelect.CheckedChanged += new EventHandler(cbSelect_CheckedChanged);

                TableCell cellSelect = new TableCell();
                cellSelect.Controls.Add(cbSelect);

                DropDownList ddlDay = new DropDownList();
                ddlDay.ID = "ddlDay" + e.Row.RowIndex.ToString();
                ddlDay.AutoPostBack = true;
                ddlDay.EnableViewState = true;
                ddlDay.Items.Add("- ���͡�ѹ -");
                ddlDay.Items.Add("�ѹ���");
                ddlDay.Items.Add("�ѧ���");
                ddlDay.Items.Add("�ظ");
                ddlDay.Items.Add("����ʺ��");
                ddlDay.Items.Add("�ء��");
                ddlDay.Items.Add("�����");
                ddlDay.Items.Add("�ҷԵ��");

                // Filter Sunday and Monday
                ddlDay.Items[1].Enabled = false;
                ddlDay.Items[7].Enabled = false;

                ddlDay.SelectedIndexChanged += new EventHandler(ddlDay_SelectedIndexChanged);
                ddlDay.Enabled = false;

                // For fix slot
                /*FilterDay(ddlDay);*/

                TableCell cellDay = new TableCell();
                cellDay.HorizontalAlign = HorizontalAlign.Center;
                cellDay.Controls.Add(ddlDay);

                DropDownList ddlPeriod = new DropDownList();
                ddlPeriod.ID = "ddlPeriod" + e.Row.RowIndex.ToString();
                ddlPeriod.AutoPostBack = true;
                ddlPeriod.EnableViewState = true;
                ddlPeriod.Items.Add("- ���͡���� -");
                ddlPeriod.Items.Add("09.00-12.00");
                ddlPeriod.Items.Add("13.00-16.00");
                ddlPeriod.SelectedIndexChanged += new EventHandler(ddlPeriod_SelectedIndexChanged);
                ddlPeriod.Enabled = false;

                TableCell cellPeriod = new TableCell();
                cellPeriod.HorizontalAlign = HorizontalAlign.Right;
                cellPeriod.Controls.Add(ddlPeriod);

                e.Row.Cells.AddAt(0, cellSelect);
                e.Row.Cells.Add(cellDay);
                e.Row.Cells.Add(cellPeriod);

                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
            else if (e.Row.RowType == DataControlRowType.Header)
            {
                TableCell cellSelectHeader = new TableCell();
                e.Row.Cells.AddAt(0, cellSelectHeader);

                TableCell cellDayHeader = new TableCell();
                cellDayHeader.Text = "�ѹ";
                cellDayHeader.HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells.Add(cellDayHeader);

                TableCell cellPeriodHeader = new TableCell();
                cellPeriodHeader.Text = "����";
                cellPeriodHeader.HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells.Add(cellPeriodHeader);

                e.Row.Cells[1].Text = "�����Ԫ�";
                e.Row.Cells[2].Text = "�����Ԫ�";
                e.Row.Cells[3].Text = "˹��¡Ե";
            }
            else if(e.Row.RowType == DataControlRowType.Footer)
            {
                for (int i = 0; i < 3; i++)
                {
                    TableCell cellEmpty = new TableCell();
                    e.Row.Cells.AddAt(0, cellEmpty);
                }
            }
            else if (e.Row.RowType == DataControlRowType.Pager)
            {
                for (int i = 0; i < 3; i++)
                {
                    TableCell cellEmpty = new TableCell();
                    e.Row.Cells.AddAt(0, cellEmpty);
                }

                e.Row.HorizontalAlign = HorizontalAlign.Right;
            }

            dsetPoll = (DataSet)Session["Poll"];

            // Update Gridview Subject.
            foreach (DataRow drow in dsetPoll.Tables["Poll"].Rows)
            {
                String subjectCode = drow["�����Ԫ�"].ToString();

                for (int i = 0; i < gvSubject.Rows.Count; i++)
                {
                    if (gvSubject.Rows[i].Cells[1].Text == subjectCode)
                    {
                        GridViewRow gvrow = gvSubject.Rows[i];

                        CheckBox cb = (CheckBox)gvrow.Cells[0].Controls[0];
                        cb.Checked = true;

                        DropDownList ddlDay = (DropDownList)gvrow.Cells[4].Controls[0];
                        ddlDay.Enabled = true;

                        if(drow["�ѹ"].ToString() == "�ѹ���")
                        {
                            ddlDay.SelectedIndex = 1;
                        }
                        else if(drow["�ѹ"].ToString() == "�ѧ���")
                        {
                            ddlDay.SelectedIndex = 2;
                        }
                        else if(drow["�ѹ"].ToString() == "�ظ")
                        {
                            ddlDay.SelectedIndex = 3;
                        }
                        else if(drow["�ѹ"].ToString() == "����ʺ��")
                        {
                            ddlDay.SelectedIndex = 4;
                        }
                        else if(drow["�ѹ"].ToString() == "�ء��")
                        {
                            ddlDay.SelectedIndex = 5;
                        }
                        else if(drow["�ѹ"].ToString() == "�����")
                        {
                            ddlDay.SelectedIndex = 6;
                        }
                        else if (drow["�ѹ"].ToString() == "�ҷԵ��")
                        {
                            ddlDay.SelectedIndex = 7;
                        }

                        DropDownList ddlPeriod = (DropDownList)gvrow.Cells[5].Controls[0];
                        ddlPeriod.Enabled = true;

                        if (drow["����"].ToString() == "09.00-12.00")
                        {
                            ddlPeriod.SelectedIndex = 1;
                        }
                        else if (drow["����"].ToString() == "13.00-16.00")
                        {
                            ddlPeriod.SelectedIndex = 2;
                        }
                    }
                }
            }
        }

        protected void gvSubject_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            dsetPoll = (DataSet)Session["Poll"];

            if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = dsetPoll.Tables["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = dsetPoll.Tables["EC"];
            }

            gvSubject.PageIndex = e.NewPageIndex;
            gvSubject.DataBind();
        }

        protected void cbSelect_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cb = (CheckBox)sender;

            if (cb.Checked == true)
            {
                // Add row to Poll table
                int index = Convert.ToInt32(cb.ID);
                GridViewRow checkedRow = gvSubject.Rows[index];

                dsetPoll = (DataSet)Session["Poll"];

                DataRow drow = dsetPoll.Tables["Poll"].NewRow();
                drow["�����Ԫ�"] = checkedRow.Cells[1].Text;
                drow["�����Ԫ�"] = checkedRow.Cells[2].Text;
                drow["˹��¡Ե"] = checkedRow.Cells[3].Text;

                dsetPoll.Tables["Poll"].Rows.Add(drow);
                dsetPoll.Tables["Poll"].AcceptChanges();
                Session["Poll"] = dsetPoll;

                gvPoll.DataSource = dsetPoll.Tables["Poll"];
                gvPoll.DataBind();

                DropDownList ddlDay = (DropDownList)checkedRow.FindControl("ddlDay" + index);
                ddlDay.Enabled = true;

                DropDownList ddlPeriod = (DropDownList)checkedRow.FindControl("ddlPeriod" + index);
                ddlPeriod.Enabled = true;
            }
            else if(cb.Checked == false)
            {
                // Delete row from Poll table
                int index = Convert.ToInt32(cb.ID);
                GridViewRow unCheckedRow = gvSubject.Rows[index];

                dsetPoll = (DataSet)Session["Poll"];

                String subjectCode = unCheckedRow.Cells[1].Text;

                for (int i = dsetPoll.Tables["Poll"].Rows.Count - 1; i >= 0; i--)
                {
                    if (dsetPoll.Tables["Poll"].Rows[i]["�����Ԫ�"].ToString() == subjectCode)
                    {
                        dsetPoll.Tables["Poll"].Rows[i].Delete();
                    }
                }
                
                dsetPoll.Tables["Poll"].AcceptChanges();
                Session["Poll"] = dsetPoll;

                gvPoll.DataSource = dsetPoll.Tables["Poll"];
                gvPoll.DataBind();

                DropDownList ddlDay = (DropDownList)unCheckedRow.FindControl("ddlDay" + index);
                ddlDay.SelectedIndex = 0;
                ddlDay.Enabled = false;

                DropDownList ddlPeriod = (DropDownList)unCheckedRow.FindControl("ddlPeriod" + index);
                ddlPeriod.SelectedIndex = 0;
                ddlPeriod.Enabled = false;
            }
        }
        
        protected void ddlDay_SelectedIndexChanged(object sender, EventArgs e)
        {
            int studentYear = Convert.ToInt32(Session["StudentYear"].ToString());
            int term = Convert.ToInt32(Application["CurrentTerm"].ToString());

            dsetPoll = (DataSet)Session["Poll"];
            DataTable dtb = dsetPoll.Tables["Poll"];

            DropDownList ddlDay = (DropDownList)sender;

            String id = ddlDay.ID.ToString();
            int index = Convert.ToInt32(id.Substring(id.Length - 1));

            GridViewRow selectedRow = gvSubject.Rows[index];
            String subjectCode = selectedRow.Cells[1].Text;

            DropDownList ddlPeriod = (DropDownList)selectedRow.Cells[5].Controls[0];

            // For fix slot
            /*ddlPeriod.Items[1].Enabled = true;
            ddlPeriod.Items[2].Enabled = true;*/

            if (ddlDay.SelectedIndex > 0)
            {
                // For fix slot
                /*if ((studentYear == 2) && (term == 1))
                {

                }
                else if ((studentYear == 2) && (term == 2))
                {
                    if (ddlDay.SelectedIndex == 2)
                        ddlPeriod.Items[1].Enabled = false;
                }
                else if ((studentYear == 3) && (term == 1))
                {
                    if (ddlDay.SelectedIndex == 4)
                        ddlPeriod.Items[1].Enabled = false;
                    else if (ddlDay.SelectedIndex == 6)
                        ddlPeriod.Items[2].Enabled = false;
                }
                else if ((studentYear == 3) && (term == 2))
                {
                    if(ddlDay.SelectedIndex == 6)
                        ddlPeriod.Items[1].Enabled = false;
                    else if ((ddlDay.SelectedIndex == 2)
                    || (ddlDay.SelectedIndex == 3)
                    || (ddlDay.SelectedIndex == 5))
                        ddlPeriod.Items[2].Enabled = false;
                }
                else if ((studentYear == 4) && (term == 1))
                {
                    if (ddlDay.SelectedIndex == 3)
                        ddlPeriod.Items[2].Enabled = false;
                }
                else if ((studentYear == 4) && (term == 2))
                {
                    if (ddlDay.SelectedIndex == 5)
                        ddlPeriod.Items[1].Enabled = false;
                }
                ddlPeriod.Enabled = true;*/

                for (int i = 0; i < dtb.Rows.Count; i++)
                {
                    DataRow drow = dtb.Rows[i];
                    if (drow["�����Ԫ�"].ToString() == subjectCode)
                    {
                        drow["�ѹ"] = ddlDay.SelectedItem.Text;
                    }
                }
            }
            else
            {
                // For fix slot
                /*ddlPeriod.SelectedIndex = 0;
                ddlPeriod.Enabled = false;*/

                for (int i = 0; i < dtb.Rows.Count; i++)
                {
                    DataRow drow = dtb.Rows[i];
                    if (drow["�����Ԫ�"].ToString() == subjectCode)
                    {
                        drow["�ѹ"] = null;
                        drow["����"] = null;
                    }
                }
            }

            Session["Poll"] = dsetPoll;
        }

        protected void ddlPeriod_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlPeriod = (DropDownList)sender;

            String id = ddlPeriod.ID.ToString();
            int index = Convert.ToInt32(id.Substring(id.Length - 1));

            GridViewRow selectedRow = gvSubject.Rows[index];
            String subjectCode = selectedRow.Cells[1].Text;

            dsetPoll = (DataSet)Session["Poll"];

            DataTable dtb = dsetPoll.Tables["Poll"];
            for (int i = 0; i < dtb.Rows.Count; i++)
            {
                DataRow drow = dtb.Rows[i];
                if (drow["�����Ԫ�"].ToString() == subjectCode)
                {
                    if (ddlPeriod.SelectedIndex > 0)
                    {
                        drow["����"] = ddlPeriod.SelectedItem.Text;
                    }
                    else
                    {
                        drow["����"] = null;
                    }
                }
            }

            Session["Poll"] = dsetPoll;
        }
        protected void ddlSubjectGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSubjectGroup.SelectedItem.Value == "CEC")
            {
                gvSubject.DataSource = dsetPoll.Tables["CEC"];
            }
            else if (ddlSubjectGroup.SelectedItem.Value == "EC")
            {
                gvSubject.DataSource = dsetPoll.Tables["EC"];
            }

            gvSubject.PageIndex = 0;
            gvSubject.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            lbSumUnit.Text = "";
            dsetPoll = (DataSet)Session["Poll"];
            if (dsetPoll.Tables["Poll"].Rows.Count > 0)
            {
                gvPoll.DataSource = dsetPoll.Tables["Poll"];
                gvPoll.DataBind();

                int sumUnit = WebUtility.CalculateSumUnit(dsetPoll.Tables["Poll"]);
                lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";
            }

            mviewPoll.SetActiveView(viewPollSelected);
        }
        protected void btnBack_Click(object sender, EventArgs e)
        {
            lbErrorMsg.Text = "";
            mviewPoll.SetActiveView(viewPollSelect);
        }
        protected void btnVote_Click(object sender, EventArgs e)
        {
            dsetPoll = (DataSet)Session["Poll"];

            bool incompleteData = false;
            bool overVoteUnit = false;

            // Check complete data
            foreach (DataRow drow in dsetPoll.Tables["Poll"].Rows)
            {
                for (int i = 0; i < drow.ItemArray.Length; i++)
                {
                    if (drow[i].ToString() == "")
                    {
                        incompleteData = true;
                        break;
                    }
                }
            }

            int studentYear = Convert.ToInt32(Session["StudentYear"].ToString());
            int term = Convert.ToInt32(Application["CurrentTerm"].ToString());

            int voteUnit = SettingVoteUnit(studentYear, term);
            int sumUnit = WebUtility.CalculateSumUnit(dsetPoll.Tables["Poll"]);

            // Check vote unit
            if (sumUnit > voteUnit)
            {
                overVoteUnit = true;
            }

            if (incompleteData)
            {
                lbErrorMsg.Text = "�س��͡���������ú��ǹ ��سҵ�Ǩ�ͺ�ա����";
            }
            else if (overVoteUnit)
            {
                lbErrorMsg.Text = "�س�������öŧ��ṹ�Թ " + voteUnit + " ˹��¡Ե";
            }
            else
            {
                // Update poll data
                OracleConnection connection = new OracleConnection();
                connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
                connection.Open();

                OracleTransaction transaction = connection.BeginTransaction();
                OracleCommand cmd = connection.CreateCommand();

                foreach (DataRow drow in dsetPoll.Tables["Poll"].Rows)
                {
                    if(IsRowExist(drow))
                    {
                        cmd.CommandText = GetUpdateCommand(drow, studentYear);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        cmd.CommandText = GetInsertCommand(drow, studentYear);
                        cmd.ExecuteNonQuery();
                    }
                }
                
                String studentCode = Session["StudentCode"].ToString();
                cmd.CommandText = "UPDATE STUDENT SET CK_VOTE=1 WHERE SCODE='" + studentCode + "'";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                connection.Close();

                // Delete Session
                Session.Remove("Poll");

                Session["ResultMessage"] = "�ӡ��ŧ��ṹ���º��������...";
                Response.Redirect("Result.aspx");
            }
        }
        protected String GetUpdateCommand(DataRow drow, int studentYear)
        {
            String commandText = "";

            String subjectCode = drow["�����Ԫ�"].ToString();

            String day = drow["�ѹ"].ToString();
            day = WebUtility.ConvertDay(day);

            String period = drow["����"].ToString();
            period = WebUtility.ConvertPeriod(period);

            if (studentYear == 2)
            {
                commandText = "UPDATE POLL SET YEAR2=YEAR2+1 " +
                    "WHERE SUB_CODE='" + subjectCode +
                    "' AND DAY='" + day +
                    "' AND PERIOD='" + period + "'";
            }
            else if (studentYear == 3)
            {
                commandText = "UPDATE POLL SET YEAR3=YEAR3+1 " +
                    "WHERE SUB_CODE='" + subjectCode +
                    "' AND DAY='" + day +
                    "' AND PERIOD='" + period + "'";
            }
            else if (studentYear == 4)
            {
                commandText = "UPDATE POLL SET YEAR4=YEAR4+1 " +
                    "WHERE SUB_CODE='" + subjectCode +
                    "' AND DAY='" + day +
                    "' AND PERIOD='" + period + "'";
            }

            return commandText;
        }
        protected String GetInsertCommand(DataRow drow, int studentYear)
        {
            String commandText = "";

            String subjectCode = drow["�����Ԫ�"].ToString();

            String day = drow["�ѹ"].ToString();
            day = WebUtility.ConvertDay(day);

            String period = drow["����"].ToString();
            period = WebUtility.ConvertPeriod(period);

            if (studentYear == 2)
            {
                commandText = "INSERT INTO POLL (SUB_CODE,DAY,PERIOD,YEAR2,YEAR3,YEAR4)" +
                    "VALUES ('" + subjectCode + "','" + day + "','" + period + "', 1, 0, 0)";
            }
            else if (studentYear == 3)
            {
                commandText = "INSERT INTO POLL (SUB_CODE,DAY,PERIOD,YEAR2,YEAR3,YEAR4)" +
                    "VALUES ('" + subjectCode + "','" + day + "','" + period + "', 0, 1, 0)";
            }
            else if (studentYear == 4)
            {
                commandText = "INSERT INTO POLL (SUB_CODE,DAY,PERIOD,YEAR2,YEAR3,YEAR4)" +
                    "VALUES ('" + subjectCode + "','" + day + "','" + period + "', 0, 0, 1)";
            }

            return commandText;
        }
        protected bool IsRowExist(DataRow drow)
        {
            bool rowExist = false;

            String subjectCode = drow["�����Ԫ�"].ToString();

            String day = drow["�ѹ"].ToString();
            day = WebUtility.ConvertDay(day);

            String period = drow["����"].ToString();
            period = WebUtility.ConvertPeriod(period);

            OracleConnection conn = new OracleConnection();
            conn.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            conn.Open();

            String cmdQuery = "SELECT * FROM POLL WHERE SUB_CODE='" + subjectCode + "'" +
                " AND DAY='" + day + "' AND PERIOD='" + period + "'";

            OracleCommand cmd = new OracleCommand(cmdQuery);
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;

            OracleDataReader reader = cmd.ExecuteReader();

            if(reader.Read())
            {
                rowExist = true;
            }

            cmd.Dispose();
            conn.Close();
            conn.Dispose();

            return rowExist;
        }

        protected void gvPoll_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
            }
        }
    }
}
