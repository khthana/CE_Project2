using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class DropEnroll : System.Web.UI.Page
    {
        DataSet dsetDropEnroll = new DataSet(); 

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else if (Convert.ToInt32(Application["DropStatus"]) == 0)
            {
                Session["ResultMessage"] = "�к��ѧ����Դ���ӡ�ö͹����Ԫ�...";
                Response.Redirect("Result.aspx");
            }

            // Manual Set Session and Application
            /*Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���ͺ �к�";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "2";
            Application["CurrentYear"] = "2549";*/

            lbStudentCode.Text = "���ʹѡ�֡�� : " + Session["StudentCode"].ToString();
            lbStudentName.Text = "���� - ���ʡ�� : " + Session["StudentName"].ToString();
            lbStudentYear.Text = "��鹻շ�� : " + Session["StudentYear"].ToString();
            lbCurrentTerm.Text = "�Ҥ���¹��� : " + Application["CurrentTerm"].ToString();

            if (!IsPostBack)
            {
                String studentCode = Session["StudentCode"].ToString();
                String currentTerm = Application["CurrentTerm"].ToString();
                String currentYear = Application["CurrentYear"].ToString();

                DataTable dtbEnroll = WebUtility.LoadEnrollData(studentCode, currentTerm, currentYear);

                gvEnroll.DataSource = dtbEnroll;
                gvEnroll.DataBind();
            }
        }

        protected void gvEnroll_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Width = 50;
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[1].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;

                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;

                e.Row.Cells[3].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
        }

        protected void gvEnroll_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            GridViewRow dropRow = gvEnroll.Rows[index];

            if (dropRow.AccessKey == "D")
            {
                dropRow.Cells[1].Enabled = true;
                dropRow.Cells[2].Enabled = true;
                dropRow.Cells[3].Enabled = true;

                Button btn = (Button)dropRow.Cells[0].Controls[0];
                btn.Text = "�͹..";

                dropRow.AccessKey = "N";
            }
            else
            {
                dropRow.Cells[1].Enabled = false;
                dropRow.Cells[2].Enabled = false;
                dropRow.Cells[3].Enabled = false;

                Button btn = (Button)dropRow.Cells[0].Controls[0];
                btn.Text = "¡��ԡ..";

                dropRow.AccessKey = "D";
            }

            int sumUnit = 0;
            foreach (GridViewRow gvrow in gvEnroll.Rows)
            {
                if (gvrow.AccessKey != "D")
                {
                    int unit = Convert.ToInt32(gvrow.Cells[3].Text);
                    sumUnit += unit;
                }
            }

            lbSumUnit.Text = "��� " + sumUnit + " ˹��¡Ե";
        }

        protected void btnDrop_Click(object sender, EventArgs e)
        {
            ArrayList dropList = new ArrayList();
            int sumUnit = 0;

            foreach (GridViewRow gvrow in gvEnroll.Rows)
            {
                if (gvrow.AccessKey == "D")
                {
                    String subjectCode = gvrow.Cells[1].Text;
                    dropList.Add(subjectCode);
                }
                else
                {
                    int unit = Convert.ToInt32(gvrow.Cells[3].Text);
                    sumUnit += unit;
                }
            }

            if (sumUnit < 9)
            {
                lbErrorMsg.Text = "�س�������öŧ����¹���¡��� 9 ˹��¡Ե";
            }
            else
            {
                OracleConnection connection = new OracleConnection();
                connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
                connection.Open();

                OracleTransaction transaction = connection.BeginTransaction();
                OracleCommand cmd = connection.CreateCommand();

                String studentCode = Session["StudentCode"].ToString();

                foreach (String subjectCode in dropList)
                {
                    String commandText = "DELETE FROM ENROLL WHERE SCODE='" + studentCode +
                        "' AND SUB_CODE='" + subjectCode + "'";

                    cmd.CommandText = commandText;
                    cmd.ExecuteNonQuery();
                }

                transaction.Commit();
                connection.Close();

                Session["ResultMessage"] = "�ӡ�ö͹����Ԫ����º��������...";
                Response.Redirect("Result.aspx");
            }
        }
    }
}
