<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Poll.aspx.cs" Inherits="PRE_REG_System.Poll" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
        <strong><span style="font-size: 14pt; font-family: Tahoma"></span></strong>
        <asp:ScriptManager ID="smPoll" runat="server">
        </asp:ScriptManager>
        <table width="750" cellspacing="0" align="center">
            <tr>
                <td colspan="4" style="width: 605px; height: 25px;" bgcolor="#507cd1" align="center">
                    <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="14pt"
                        Text="�к����Ǩ�����Դ���" ForeColor="White" Width="750px"></asp:Label></td>
            </tr>
            <tr>
                <td style="height: 20px;" bgcolor="#eff3fb" align="left" width="350">
                    &nbsp;<asp:Label ID="lbStudentCode" runat="server" Font-Names="Tahoma" Font-Size="Small" ForeColor="#333333"></asp:Label></td>
                <td style="width: 1054px; height: 20px;" bgcolor="#eff3fb" align="left">
                    <asp:Label ID="lbStudentName" runat="server" Font-Names="Tahoma" Font-Size="Small" ForeColor="#333333"></asp:Label></td>
                <td width="250" align="right" bgcolor="#eff3fb" style="height: 20px">
                    <asp:Label ID="lbStudentYear" runat="server" Font-Names="Tahoma" Font-Size="Small" ForeColor="#333333"></asp:Label></td>
                <td width="250" align="right" bgcolor="#eff3fb" style="height: 20px">
                    <asp:Label ID="lbCurrentTerm" runat="server" Font-Names="Tahoma" Font-Size="Small" ForeColor="#333333"></asp:Label>&nbsp;</td>
            </tr>
        </table>
        <br />
        <span style="font-size: 14pt; font-family: Tahoma; color: #ffffff;">
            <table cellspacing="0" width="750" align="center">
                <tr>
                    <td align="left" bgcolor="#dcdcdc" style="height: 20px; width: 628px;">
                        <span style="color: #333333">&nbsp;<span style="font-size: 12pt"><strong>�����Ǩ����ش</strong></span></span></td>
                </tr>
                <tr>
                    <td align="center" style="width: 628px; height: 20px">
        <asp:Table ID="tblSchedule" runat="server" CellPadding="1" CellSpacing="0" Font-Names="Tahoma"
            Font-Size="Small" GridLines="Both" Width="750px" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px" ForeColor="#333333">
            <asp:TableRow runat="server" BackColor="#507CD1" Font-Bold="False" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" Width="50px" BackColor="White" HorizontalAlign="Center" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">-----</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Center" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px" Font-Bold="True" ForeColor="White">09.00 - 12.00</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Center" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px" Font-Bold="True" ForeColor="White">13.00 - 16.00</asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFFFC0" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѹ���</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0FF" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѧ���</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFC0" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ظ</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFE0C0" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">����ʺ��</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFFF" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ء��</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0C0FF" BorderColor="DarkGray" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�����</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0C0" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ҷԵ��</asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
                <asp:TableCell runat="server" HorizontalAlign="Justify" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"></asp:TableCell>
            </asp:TableRow>
        </asp:Table>
                    </td>
                </tr>
            </table>
        </span>
        <br />
        <asp:UpdatePanel ID="upSubject" runat="server">
            <ContentTemplate>
                <asp:MultiView ID="mviewPoll" runat="server">
                    <asp:View ID="viewPollSelect" runat="server">
        <table cellspacing="0" width="750" align="center">
            <tr>
                <td style="width: 375px; height: 20px;" bgcolor="#dcdcdc" align="left">
                    <span style="font-size: 14pt; font-family: Tahoma"><strong>&nbsp;<span style="color: #333333; font-size: 12pt;">ŧ��ṹ����Ԫ�</span></strong></span></td>
                <td align="right" bgcolor="#dcdcdc" style="height: 20px; font-size: 12pt;">
                    <asp:DropDownList ID="ddlSubjectGroup" runat="server" AutoPostBack="True" OnSelectedIndexChanged="ddlSubjectGroup_SelectedIndexChanged">
                        <asp:ListItem Value="CEC">�ԪҺѧ�Ѻ���͡</asp:ListItem>
                        <asp:ListItem Value="EC">�Ԫ����͡੾���Ң�</asp:ListItem>
                    </asp:DropDownList></td>
            </tr>
            <tr>
                <td align="center" colspan="2" style="width: 375px; height: 20px">
        <asp:GridView ID="gvSubject" runat="server" AllowPaging="True"
            CellPadding="4" ForeColor="#333333"
            GridLines="None" Width="750px" OnRowCreated="gvSubject_RowCreated" Font-Names="Tahoma" Font-Size="Small" OnPageIndexChanging="gvSubject_PageIndexChanging" PageSize="7" BorderColor="#507CD1" BorderStyle="Solid" BorderWidth="1px">
            <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <RowStyle BackColor="#EFF3FB" />
            <SelectedRowStyle BackColor="#D1DDF1" Font-Bold="True" ForeColor="#333333" />
            <PagerStyle BackColor="#2461BF" ForeColor="White" HorizontalAlign="Center" />
            <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
            <AlternatingRowStyle BackColor="White" />
            <EditRowStyle BackColor="#2461BF" />
        </asp:GridView>
                </td>
            </tr>
        </table>
        <table cellspacing="0" width="750" style="font-size: 12pt" align="center">
            <tr>
                <td style="height: 20px"></td>
                        <td align="right" style="height: 20px">
        <asp:Button
                                ID="btnNext" runat="server" OnClick="btnNext_Click" Text="��鹵͹���� >" Width="120px" /></td>
                    </tr>
        </table>
                    </asp:View>
                    <asp:View ID="viewPollSelected" runat="server">
                        <table cellspacing="0" width="750" align="center">
                            <tr>
                                <td bgcolor="#dcdcdc" style="height: 20px" align="left">
                                    <span style="font-size: 14pt; font-family: Tahoma"><strong>&nbsp;<span style="color: #333333; font-size: 12pt;">����Ԫҷ��ŧ��ṹ</span></strong></span></td>
                            </tr>
                            <tr>
                                <td align="center" style="height: 20px">
                        <asp:GridView
                    ID="gvPoll" runat="server" BackColor="White" BorderColor="#6B696B"
                    BorderWidth="1px" CellPadding="4" Font-Names="Tahoma" Font-Size="Small" ForeColor="Black" Width="750px" OnRowCreated="gvPoll_RowCreated" GridLines="None">
                    <FooterStyle BackColor="#CCCC99" />
                    <SelectedRowStyle BackColor="#CE5D5A" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="#F7F7DE" ForeColor="Black" HorizontalAlign="Right" />
                    <HeaderStyle BackColor="#6B696B" Font-Bold="True" ForeColor="White" />
                            <RowStyle BackColor="#F7F7DE" />
                            <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
                                </td>
                            </tr>
                        </table>
                        <table cellspacing="0" width="750" style="font-size: 12pt" align="center">
                    <tr>
                        <td align="left" bgcolor="#cccc99" style="height: 20px">
                            &nbsp;<asp:Label ID="lbErrorMsg" runat="server" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="Red"></asp:Label></td>
                        <td align="right" bgcolor="#cccc99" style="height: 20px">
                            <asp:Label ID="lbSumUnit" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label>&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="height: 20px" align="left">
                            <asp:Button ID="btnBack" runat="server" OnClick="btnBack_Click" Text="< ��͹��Ѻ" Width="120px" /></td>
                        <td align="right" style="height: 20px">
        <asp:Button ID="btnVote" runat="server" OnClick="btnVote_Click" Text="�׹�ѹ���ŧ��ṹ" Width="150px" /></td>
                    </tr>
                </table>
                    </asp:View>
                </asp:MultiView>
            </ContentTemplate>
        </asp:UpdatePanel>
    </form>
</body>
</html>
