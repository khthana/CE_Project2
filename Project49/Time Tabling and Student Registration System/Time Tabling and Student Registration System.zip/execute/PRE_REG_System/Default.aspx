<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="PRE_REG_System._Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
            <table cellspacing="0" width="750" align="center" bgcolor="floralwhite">
                <tr>
                    <td align="center" style="height: 100px" bgcolor="#f0f5ff">
            <asp:Image ID="Image1" runat="server" ImageAlign="Middle" ImageUrl="~/pic/title_modi750_73.png"
                Width="750px" /></td>
                </tr>
                <tr>
                    <td align="center" bgcolor="#f0f5ff">
                        <br />
                        <table style="width: 450px" cellspacing="0">
                <tr>
                    <td align="center" style="height: 22px">
                        <asp:Label ID="Label5" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="RoyalBlue" Text="�дѺ�����ҹ :"></asp:Label>
                        <asp:RadioButton ID="rdStudent" runat="server" Checked="True" Font-Bold="True" Font-Names="Tahoma"
                            Font-Size="Small" ForeColor="RoyalBlue" GroupName="LoginType" Text="�ѡ�֡��" />
                        <asp:RadioButton ID="rdTeacher" runat="server" Font-Bold="True" Font-Names="Tahoma"
                            Font-Size="Small" ForeColor="RoyalBlue" GroupName="LoginType" Text="�Ҩ����" />
                        <asp:RadioButton ID="rdAdmin" runat="server" Font-Bold="True" Font-Names="Tahoma"
                            Font-Size="Small" ForeColor="RoyalBlue" GroupName="LoginType" Text="�������к�" /></td>
                </tr>
            </table>
                        <br />
            <table style="width: 450px; height: 100px" cellspacing="0">
                <tr>
                    <td align="right" style="width: 225px; height: 26px;">
                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="RoyalBlue" Height="22px" Text="�����ҹ :" Width="80px"></asp:Label></td>
                    <td align="left" style="width: 250px; height: 26px;">
                        <asp:TextBox ID="txtUserID" runat="server" Width="120px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td align="right" style="width: 225px; height: 26px">
                        <asp:Label ID="Label2" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="RoyalBlue" Height="22px" Text="���ʼ�ҹ :" Width="80px"></asp:Label></td>
                    <td align="left" style="width: 250px; height: 26px">
                        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" Width="120px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td align="right" style="width: 225px; height: 29px;">
                        <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="RoyalBlue" Height="22px" Text="���ʵ�Ǩ�ͺ : " Width="118px"></asp:Label></td>
                    <td align="left" style="width: 250px; height: 29px;">
                        <asp:Image ID="imgCheckCode" runat="server" BorderWidth="1px"
                            Height="24px" ImageAlign="Middle" Width="100px" BorderStyle="Solid" /></td>
                </tr>
                <tr>
                    <td align="right" style="width: 225px">
                        <asp:Label ID="Label3" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                            ForeColor="RoyalBlue" Height="22px" Text="��͹���ʵ�Ǩ�ͺ :" Width="150px"></asp:Label></td>
                    <td align="left" style="width: 250px">
                        <asp:TextBox ID="txtCheckCode" runat="server" Width="120px"></asp:TextBox></td>
                </tr>
                <tr>
                    <td style="width: 225px">
                        </td>
                    <td align="left" style="width: 250px">
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
                        <asp:Button ID="btnLogin" runat="server" OnClick="btnLogin_Click" Text="��͡�Թ" Width="60px" /></td>
                </tr>
            </table>
                        <br />
            <asp:Label ID="lbErrorMsg" runat="server" Font-Names="Tahoma" Font-Size="Small" ForeColor="Red"></asp:Label></td>
                </tr>
            </table>
            <br />
    </form>
</body>
</html>
