using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class ViewPoll : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable dtbPollData = WebUtility.LoadPollData();
            WebUtility.DisplayPollData(dtbPollData, tblSchedule);
            
            lbDate.Text = "�ѹ��� " + DateTime.Now.ToLongDateString();
            lbTime.Text = "���� " + DateTime.Now.ToLongTimeString();
        }
    }
}
