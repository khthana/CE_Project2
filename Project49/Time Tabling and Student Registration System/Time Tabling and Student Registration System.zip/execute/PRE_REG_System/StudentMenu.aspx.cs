using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class MainMenu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            // Manual Set Session or Application
            /*Session["ActiveStudent"] = 1;
            Session["StudentCode"] = "47015330";*/

            DataTable dtbStatus = WebUtility.LoadCurrentStatus();
            Application["CurrentTerm"] = dtbStatus.Rows[0]["CurrentTerm"].ToString();
            Application["CurrentYear"] = dtbStatus.Rows[0]["CurrentYear"].ToString();
            Application["EnrollStatus"] = Convert.ToInt32(dtbStatus.Rows[0]["EnrollStatus"]);
            Application["PollStatus"] = Convert.ToInt32(dtbStatus.Rows[0]["PollStatus"]);
            Application["AddStatus"] = Convert.ToInt32(dtbStatus.Rows[0]["AddStatus"]);
            Application["DropStatus"] = Convert.ToInt32(dtbStatus.Rows[0]["DropStatus"]);

            String studentCode = Session["StudentCode"].ToString();
            LoadStudentData(studentCode);
        }
        private void LoadStudentData(String studentCode)
        {
            OracleConnection conn = new OracleConnection();
            conn.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            conn.Open();

            String cmdQuery = "SELECT SCODE,PREFIX_SNAME_TH,SNAME_TH,PREFIX_SNAME_ENG,SNAME_ENG," +
                "BIRTH_DAY,BIRTH_MONTH,BIRTH_YEAR,SEX,STATUS,INCOME_YEAR,FACULTY,DEPARTMENT,BRANCH " +
                "FROM SPROFILE WHERE SCODE='" + studentCode + "'";

            OracleCommand cmd = new OracleCommand(cmdQuery);
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;

            OracleDataReader reader = cmd.ExecuteReader();

            if(reader.Read())
            {
                lbStudentID.Text = studentCode;
                lbPrefixNameTH.Text = reader.GetString(1);
                lbNameTH.Text = reader.GetString(2);
                lbPrefixNameENG.Text = reader.GetString(3);
                lbNameENG.Text = reader.GetString(4);

                String dd = reader.GetString(5);
                String mm = reader.GetString(6);
                String yy = reader.GetString(7);

                lbBirthDay.Text = dd + " " + mm + " " + yy;
                lbSex.Text = reader.GetString(8);
                lbStatus.Text = reader.GetString(9);
                lbType.Text = "";
                lbInComingYear.Text = reader.GetString(10);
                lbOutGoingYear.Text = "";
                lbFaculty.Text = reader.GetString(11);
                lbDepartment.Text = reader.GetString(12);
                lbBranch.Text = reader.GetString(13);
            }

            int incomeYear = Convert.ToInt32(lbInComingYear.Text);
            int currentYear = Convert.ToInt32(Application["CurrentYear"].ToString());
            int studentYear = (currentYear - incomeYear) + 1;

            // Set Session
            Session["StudentName"] = lbNameTH.Text;
            Session["StudentYear"] = studentYear;
        }
        protected void mnStudent_MenuItemClick(object sender, MenuEventArgs e)
        {
            if (mnStudent.SelectedItem.Value == "Logout")
            {
                // Delete All Session
                Session.RemoveAll();
                Response.Redirect("Default.aspx");
            }
        }
    }
}
