using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Manual set Session
            //Session["ActiveAdmin"] = 1;

            if (Session["ActiveAdmin"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            if (!IsPostBack)
            {
                DataTable dtbStatus = WebUtility.LoadCurrentStatus();
                String currentTerm = dtbStatus.Rows[0]["CurrentTerm"].ToString();
                String currentYear = dtbStatus.Rows[0]["CurrentYear"].ToString();
                int enrollStatus = Convert.ToInt32(dtbStatus.Rows[0]["EnrollStatus"]);
                int addStatus = Convert.ToInt32(dtbStatus.Rows[0]["AddStatus"]);
                int dropStatus = Convert.ToInt32(dtbStatus.Rows[0]["DropStatus"]);
                int pollStatus = Convert.ToInt32(dtbStatus.Rows[0]["PollStatus"]);
                
                CheckCurrentStatus(currentTerm, currentYear);
                CheckEnrollStatus(enrollStatus);
                CheckAddEnrollStatus(addStatus);
                CheckDropEnrollStatus(dropStatus);
                CheckPollStatus(pollStatus);

                mvAdmin.SetActiveView(viewSetStatus);
            }
        }

        protected void CheckCurrentStatus(String currentTerm, String currentYear)
        {
            if (currentTerm == "1")
            {
                ddlTerm.SelectedIndex = 0;
            }
            else if (currentTerm == "2")
            {
                ddlTerm.SelectedIndex = 1;
            }
            lbYear.Text = currentYear;

            ddlTerm.Enabled = false;
            lbYear.Enabled = false;
            btnSet.Enabled = false;
            btnDecYear.Enabled = false;
            btnIncYear.Enabled = false;
            btnCancel.Visible = false;
        }

        protected void CheckEnrollStatus(int enrollStatus)
        {
            if (enrollStatus == 0)
            {
                btnCloseEnroll.Enabled = false;
                btnOpenEnroll.Enabled = true;

                lbEnrollStatus.ForeColor = System.Drawing.Color.Red;
                lbEnrollStatus.Text = "�Դ���ŧ����¹";
            }
            else if (enrollStatus == 1)
            {
                btnCloseEnroll.Enabled = true;
                btnOpenEnroll.Enabled = false;

                lbEnrollStatus.ForeColor = System.Drawing.Color.LimeGreen;
                lbEnrollStatus.Text = "�Դ���ŧ����¹";
            }
        }

        protected void CheckAddEnrollStatus(int addStatus)
        {
            if (addStatus == 0)
            {
                btnCloseAddEnroll.Enabled = false;
                btnOpenAddEnroll.Enabled = true;

                lbAddStatus.ForeColor = System.Drawing.Color.Red;
                lbAddStatus.Text = "�Դ�����������Ԫ�";
            }
            else if (addStatus == 1)
            {
                btnCloseAddEnroll.Enabled = true;
                btnOpenAddEnroll.Enabled = false;

                lbAddStatus.ForeColor = System.Drawing.Color.LimeGreen;
                lbAddStatus.Text = "�Դ�����������Ԫ�";
            }
        }

        protected void CheckDropEnrollStatus(int dropStatus)
        {
            if (dropStatus == 0)
            {
                btnCloseDropEnroll.Enabled = false;
                btnOpenDropEnroll.Enabled = true;

                lbDropStatus.ForeColor = System.Drawing.Color.Red;
                lbDropStatus.Text = "�Դ��ö͹����Ԫ�";
            }
            else if (dropStatus == 1)
            {
                btnCloseDropEnroll.Enabled = true;
                btnOpenDropEnroll.Enabled = false;

                lbDropStatus.ForeColor = System.Drawing.Color.LimeGreen;
                lbDropStatus.Text = "�Դ��ö͹����Ԫ�";
            }
        }

        protected void CheckPollStatus(int pollStatus)
        {
            if (pollStatus == 0)
            {
                btnClosePoll.Enabled = false;
                btnOpenPoll.Enabled = true;

                lbPollStatus.ForeColor = System.Drawing.Color.Red;
                lbPollStatus.Text = "�Դ���ŧ��ṹ";
            }
            else if (pollStatus == 1)
            {
                btnClosePoll.Enabled = true;
                btnOpenPoll.Enabled = false;

                lbPollStatus.ForeColor = System.Drawing.Color.LimeGreen;
                lbPollStatus.Text = "�Դ���ŧ��ṹ";
            }
        }

        protected void menuAdmin_MenuItemClick(object sender, MenuEventArgs e)
        {
            if (e.Item.Value == "SetStatus")
            {
                mvAdmin.SetActiveView(viewSetStatus);
            }
            else if (e.Item.Value == "SetEnroll")
            {
                mvAdmin.SetActiveView(viewSetEnroll);
            }
            else if (e.Item.Value == "SetPoll")
            {
                mvAdmin.SetActiveView(viewSetPoll);
            }
            else if (e.Item.Value == "Logout")
            {
                Session.RemoveAll();
                Response.Redirect("Default.aspx");
            }

            lbResult.Text = "";
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Session["BackTerm"] = ddlTerm.SelectedIndex;
            Session["BackYear"] = lbYear.Text;

            ddlTerm.Enabled = true;
            lbYear.Enabled = true;
            btnCancel.Visible = true;
            btnSet.Enabled = true;
            btnIncYear.Enabled = true;
            btnDecYear.Enabled = true;

            btnEdit.Visible = false;

            lbResult.Text = "";
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ddlTerm.SelectedIndex = Convert.ToInt32(Session["BackTerm"]);
            lbYear.Text = Session["BackYear"].ToString();

            ddlTerm.Enabled = false;
            lbYear.Enabled = false;
            btnCancel.Visible = false;
            btnSet.Enabled = false;
            btnIncYear.Enabled = false;
            btnDecYear.Enabled = false;

            btnEdit.Visible = true;
        }
        protected void btnSet_Click(object sender, EventArgs e)
        {
            String term = ddlTerm.SelectedItem.Value.ToString();
            String year = lbYear.Text;

            WebUtility.UpdateCurrentStatus(term, year);

            ddlTerm.Enabled = false;
            lbYear.Enabled = false;
            btnCancel.Visible = false;
            btnSet.Enabled = false;

            btnEdit.Visible = true;
            lbResult.Text = "�ѹ�֡��õ�駤�����º��������...";
        }

        // Enroll
        protected void btnCloseEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateEnrollStatus("OFF");

            btnCloseEnroll.Enabled = false;
            btnOpenEnroll.Enabled = true;

            lbEnrollStatus.ForeColor = System.Drawing.Color.Red;
            lbEnrollStatus.Text = "�Դ���ŧ����¹";

            lbResult.Text = "�Դ���ŧ����¹���º��������...";
        }
        protected void btnOpenEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateEnrollStatus("ON");

            btnCloseEnroll.Enabled = true;
            btnOpenEnroll.Enabled = false;

            lbEnrollStatus.ForeColor = System.Drawing.Color.LimeGreen;
            lbEnrollStatus.Text = "�Դ���ŧ����¹";

            lbResult.Text = "�Դ���ŧ����¹���º��������...";
        }
        protected void btnCloseAddEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateAddEnrollStatus("OFF");

            btnCloseAddEnroll.Enabled = false;
            btnOpenAddEnroll.Enabled = true;

            lbAddStatus.ForeColor = System.Drawing.Color.Red;
            lbAddStatus.Text = "�Դ�����������Ԫ�";

            lbResult.Text = "�Դ�����������Ԫ����º��������...";
        }
        protected void btnOpenAddEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateAddEnrollStatus("ON");

            btnCloseAddEnroll.Enabled = true;
            btnOpenAddEnroll.Enabled = false;

            lbAddStatus.ForeColor = System.Drawing.Color.LimeGreen;
            lbAddStatus.Text = "�Դ�����������Ԫ�";

            lbResult.Text = "�Դ�����������Ԫ����º��������...";
        }
        protected void btnCloseDropEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateDropEnrollStatus("OFF");

            btnCloseDropEnroll.Enabled = false;
            btnOpenDropEnroll.Enabled = true;

            lbDropStatus.ForeColor = System.Drawing.Color.Red;
            lbDropStatus.Text = "�Դ��ö͹����Ԫ�";

            lbResult.Text = "�Դ��ö͹����Ԫ����º��������...";
        }
        protected void btnOpenDropEnroll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdateDropEnrollStatus("ON");

            btnCloseDropEnroll.Enabled = true;
            btnOpenDropEnroll.Enabled = false;

            lbDropStatus.ForeColor = System.Drawing.Color.LimeGreen;
            lbDropStatus.Text = "�Դ��ö͹����Ԫ�";

            lbResult.Text = "�Դ��ö͹����Ԫ����º��������...";
        }

        // Poll
        protected void btnClosePoll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdatePollStatus("OFF");

            btnClosePoll.Enabled = false;
            btnOpenPoll.Enabled = true;

            lbPollStatus.ForeColor = System.Drawing.Color.Red;
            lbPollStatus.Text = "�Դ���ŧ��ṹ";

            lbResult.Text = "�Դ���ŧ��ṹ���º��������...";
        }
        protected void btnOpenPoll_Click(object sender, EventArgs e)
        {
            WebUtility.UpdatePollStatus("ON");

            btnClosePoll.Enabled = true;
            btnOpenPoll.Enabled = false;

            lbPollStatus.ForeColor = System.Drawing.Color.LimeGreen;
            lbPollStatus.Text = "�Դ���ŧ��ṹ";

            lbResult.Text = "�Դ���ŧ��ṹ���º��������...";
        }

        protected void btnIncYear_Click(object sender, EventArgs e)
        {
            int year = Convert.ToInt32(lbYear.Text);
            year++;
            lbYear.Text = year.ToString();
        }
        protected void btnDecYear_Click(object sender, EventArgs e)
        {
            int year = Convert.ToInt32(lbYear.Text);
            year--;
            lbYear.Text = year.ToString();
        }

        protected void btnClearSchedule_Click(object sender, EventArgs e)
        {
            WebUtility.ClearSchedule();
            lbResult.Text = "��ҧ�����š�èѴ���ҧ���¹���º��������...";
        }
        protected void btnClearPoll_Click(object sender, EventArgs e)
        {
            WebUtility.ClearPoll();
            lbResult.Text = "��ҧ�����ż����Ǩ���º��������...";
        }
    }
}
