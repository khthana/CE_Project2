<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Result.aspx.cs" Inherits="PRE_REG_System.EnrollResult" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
    <div style="text-align: center">
        <table cellspacing="0" style="text-align: center" width="750" align="center">
            <tr>
                <td align="center" bgcolor="#507cd1" colspan="4" style="width: 605px; height: 25px;
                    text-align: center">
                    <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma">
                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Text="�к��Ѵ���ҧ�͹��С��ŧ����¹" Width="750px"></asp:Label></span></td>
            </tr>
            <tr>
                <td align="left" bgcolor="#eff3fb" style="height: 20px" width="350">
                    &nbsp;<asp:Label ID="lbStudentCode" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="left" bgcolor="#eff3fb" style="width: 1054px; height: 20px">
                    <asp:Label ID="lbStudentName" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                    <asp:Label ID="lbStudentYear" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                    <asp:Label ID="lbCurrentTerm" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label>&nbsp;</td>
            </tr>
        </table>
    
    </div>
        <br />
        <asp:Label ID="lbResult" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Large"
            ForeColor="#00C000" Height="25px" Width="750px"></asp:Label>
    </form>
</body>
</html>
