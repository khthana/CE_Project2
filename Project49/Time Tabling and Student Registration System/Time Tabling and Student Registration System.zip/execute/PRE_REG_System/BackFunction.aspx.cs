using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace PRE_REG_System
{
    public partial class BackFunction : System.Web.UI.Page
    {
        protected void BuildBanner(string fileName)
        {
            int width = 120;
            int height = 25;

            Bitmap ObjBitmap = new Bitmap(width, height);
            Graphics ObjGraphics = Graphics.FromImage(ObjBitmap);

            ObjGraphics.FillRectangle(new SolidBrush(Color.Gray), 0, 0, width, height);
            ObjGraphics.FillRectangle(new SolidBrush(Color.LightGray), 5, 5, width - 10, height - 10);

            Font FontBanner = new Font("Verdana", 10, FontStyle.Bold | FontStyle.Italic);
            StringFormat StringPosition = new StringFormat();
            StringPosition.Alignment = StringAlignment.Center;
            StringPosition.LineAlignment = StringAlignment.Center;

            string detail = "test";

            ObjGraphics.DrawString(detail, FontBanner, new SolidBrush(Color.Black), new RectangleF(0, 0, width, height), StringPosition);
            ObjBitmap.Save(fileName, ImageFormat.Jpeg);

            ObjGraphics.Dispose();
            ObjBitmap.Dispose();
        }
        protected Bitmap CreateImage(string sTextToImg)
        {
            PixelFormat pxImagePattern = PixelFormat.Format32bppArgb;
            Bitmap bmpImage = new Bitmap(1, 1, pxImagePattern);

            Font fntImageFont = new Font("Comic Sans MS", 10, FontStyle.Bold);
            Graphics gdImageGrp = Graphics.FromImage(bmpImage);

            float iWidth = gdImageGrp.MeasureString(sTextToImg, fntImageFont).Width;
            float iHeight = gdImageGrp.MeasureString(sTextToImg, fntImageFont).Height;

            bmpImage = new Bitmap((int)iWidth, (int)iHeight, pxImagePattern);
            gdImageGrp = Graphics.FromImage(bmpImage);
            gdImageGrp.Clear(Color.White);
            gdImageGrp.TextRenderingHint = TextRenderingHint.AntiAlias;
            gdImageGrp.DrawString(sTextToImg, fntImageFont, new SolidBrush(Color.RoyalBlue), 0, 0);
            gdImageGrp.Flush();

            return bmpImage;
        }
        protected void HashPassword(String password)
        {
            String hashedPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "MD5");
            Response.Write(hashedPassword + "<br />");
        }
        protected void GetAllSubjectCode()
        {
            ulong hwCode = 1074101;
            ulong swCode = 1074201;
            ulong nwCode = 1074301;
            ulong aiCode = 1074401;

            for (ulong i = 0; i < 7; i++)
            {
                ulong code = hwCode + i;
                Response.Write("cuttingList.Add(\"");
                Response.Write("0" + code.ToString());
                Response.Write("\");");
                Response.Write("<br />");
            }
            Response.Write("<br />");
            for (ulong i = 0; i < 28; i++)
            {
                ulong code = swCode + i;
                Response.Write("cuttingList.Add(\"");
                Response.Write("0" + code.ToString());
                Response.Write("\");");
                Response.Write("<br />");
            }
            Response.Write("<br />");
            for (ulong i = 0; i < 7; i++)
            {
                ulong code = nwCode + i;
                Response.Write("cuttingList.Add(\"");
                Response.Write("0" + code.ToString());
                Response.Write("\");");
                Response.Write("<br />");
            }
            Response.Write("<br />");
            for (ulong i = 0; i < 15; i++)
            {
                ulong code = aiCode + i;
                Response.Write("cuttingList.Add(\"");
                Response.Write("0" + code.ToString());
                Response.Write("\");");
                Response.Write("<br />");
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            HashPassword("test02");
            HashPassword("test03");
            HashPassword("test04");
        }
    }
}
