<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Admin.aspx.cs" Inherits="PRE_REG_System.Admin" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
    <div style="text-align: center">
        <asp:ScriptManager ID="smAdmin" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="upAdmin" runat="server">
            <ContentTemplate>
        <table cellspacing="0" width="750" align="center" cellpadding="0">
            <tr>
                <td align="center" bgcolor="#507cd1" colspan="4" style="width: 605px; height: 25px;
                    text-align: center">
                    <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma">
                        <asp:Label ID="Label5" runat="server" Font-Bold="True" Text="�к��Ѵ���ҧ�͹��С��ŧ����¹"
                            Width="750px"></asp:Label></span></td>
            </tr>
            <tr>
                <td align="center" colspan="4" style="width: 605px; height: 25px; text-align: center">
                <asp:Menu ID="menuAdmin" runat="server" BackColor="#F7F6F3" DynamicHorizontalOffset="2"
                    Font-Names="Tahoma" Font-Size="Small" ForeColor="#7C6F57" OnMenuItemClick="menuAdmin_MenuItemClick"
                    Orientation="Horizontal" StaticSubMenuIndent="10px" Width="752px">
                    <StaticMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" Width="185px" />
                    <DynamicHoverStyle BackColor="#7C6F57" ForeColor="White" />
                    <DynamicMenuStyle BackColor="#F7F6F3" />
                    <StaticSelectedStyle BackColor="LightSteelBlue" ForeColor="#333333" />
                    <DynamicSelectedStyle BackColor="#5D7B9D" />
                    <DynamicMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" />
                    <Items>
                        <asp:MenuItem Selected="True" Text="��駤��ʶҹлѨ�غѹ" Value="SetStatus"></asp:MenuItem>
                        <asp:MenuItem Text="��駤���к�ŧ����¹" Value="SetEnroll"></asp:MenuItem>
                        <asp:MenuItem Text="��駤���к����Ǩ�����Դ���" Value="SetPoll"></asp:MenuItem>
                        <asp:MenuItem Text="��͡��ҷ�" Value="Logout"></asp:MenuItem>
                    </Items>
                    <StaticHoverStyle BackColor="#7C6F57" ForeColor="White" />
                </asp:Menu>
                </td>
            </tr>
        </table>
                <br />
                <asp:MultiView ID="mvAdmin" runat="server">
                    <asp:View ID="viewSetStatus" runat="server">
                        <table cellspacing="0" width="750" align="center">
                            <tr>
                                <td align="center" bgcolor="#dcdcdc" colspan="2" style="width: 375px; height: 20px;
                                    text-align: center">
                                    <span style="color: #333333; font-family: Tahoma"><strong>
                                        <asp:Label ID="Label6" runat="server" Text="��駤��ʶҹлѨ�غѹ" Width="750px"></asp:Label></strong></span></td>
                            </tr>
                            <tr>
                                <td bgcolor="#eff3fb" style="height: 25px" width="375">
                                    <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="�Ҥ���¹��� :"></asp:Label>
                                    <asp:DropDownList ID="ddlTerm" runat="server" Font-Names="Tahoma" Font-Size="Small"
                                        Width="40px">
                                        <asp:ListItem>1</asp:ListItem>
                                        <asp:ListItem>2</asp:ListItem>
                                    </asp:DropDownList></td>
                                <td bgcolor="#eff3fb" style="height: 25px" width="375">
                                    <asp:Label ID="Label2" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="�ա���֡�� :"></asp:Label>
                                    <asp:Label ID="lbYear" runat="server" BorderColor="Gray" BorderWidth="1px" Font-Names="Tahoma"
                                        Font-Size="Small" Width="50px"></asp:Label>&nbsp;<asp:Button ID="btnDecYear" runat="server"
                                            OnClick="btnDecYear_Click" Text="-" Width="20px" Height="21px" /><asp:Button ID="btnIncYear" runat="server"
                                                OnClick="btnIncYear_Click" Text="+" Width="20px" Height="21px" /></td>
                            </tr>
                            <tr>
                                <td align="left" colspan="1" style="height: 25px">
                                    <asp:Button ID="btnEdit" runat="server" OnClick="btnEdit_Click" Text="���" Width="80px" /><asp:Button ID="btnCancel" runat="server" OnClick="btnCancel_Click" Text="¡��ԡ"
                                        Width="80px" /></td>
                                <td align="right" colspan="2" style="height: 25px">
                                    &nbsp;<asp:Button ID="btnSet" runat="server" OnClick="btnSet_Click" Text="�ѹ�֡"
                                        Width="80px" /></td>
                            </tr>
                        </table>
                    </asp:View>
                    <asp:View ID="viewSetEnroll" runat="server">
                        <table cellspacing="0" width="750" align="center">
                            <tr>
                                <td bgcolor="#dcdcdc" colspan="2" style="height: 20px">
                                    <span style="color: #333333; font-family: Tahoma"><strong>��駤���к�ŧ����¹</strong></span></td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="height: 25px">
                                    <asp:Label ID="Label3" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="ʶҹлѨ�غѹ :"></asp:Label>
                                </td>
                                <td align="left" bgcolor="#eff3fb" style="height: 25px">
                                    &nbsp;<asp:Label ID="lbEnrollStatus" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                        Font-Size="Small"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                    <asp:Button ID="btnCloseEnroll" runat="server" OnClick="btnCloseEnroll_Click" Text="�Դ���ŧ����¹"
                                        Width="150px" /></td>
                                <td align="right" style="height: 25px">
                                    &nbsp;<asp:Button ID="btnOpenEnroll" runat="server" OnClick="btnOpenEnroll_Click"
                                        Text="�Դ���ŧ����¹" Width="150px" /></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                </td>
                                <td align="right" style="height: 25px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center" bgcolor="#dcdcdc" colspan="2" style="height: 25px">
                                    <span style="color: #333333; font-family: Tahoma"><strong>��������Ԫ�</strong></span></td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="height: 25px">
                                    <asp:Label ID="Label7" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="ʶҹлѨ�غѹ :"></asp:Label></td>
                                <td align="left" bgcolor="#eff3fb" style="height: 25px">
                                    &nbsp;<asp:Label ID="lbAddStatus" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                        Font-Size="Small"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                    <asp:Button ID="btnCloseAddEnroll" runat="server" OnClick="btnCloseAddEnroll_Click"
                                        Text="�Դ�����������Ԫ�" Width="150px" /></td>
                                <td align="right" style="height: 25px">
                                    <asp:Button ID="btnOpenAddEnroll" runat="server" OnClick="btnOpenAddEnroll_Click"
                                        Text="�Դ�����������Ԫ�" Width="150px" /></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                </td>
                                <td align="right" style="height: 25px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center" bgcolor="#dcdcdc" colspan="2" style="height: 25px">
                                    <span style="color: #333333; font-family: Tahoma"><strong>�͹����Ԫ�</strong></span></td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="height: 25px">
                                    <asp:Label ID="Label8" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="ʶҹлѨ�غѹ :"></asp:Label></td>
                                <td align="left" bgcolor="#eff3fb" style="height: 25px">
                                    &nbsp;<asp:Label ID="lbDropStatus" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                        Font-Size="Small"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                    <asp:Button ID="btnCloseDropEnroll" runat="server" OnClick="btnCloseDropEnroll_Click"
                                        Text="�Դ��ö͹����Ԫ�" Width="150px" /></td>
                                <td align="right" style="height: 25px">
                                    <asp:Button ID="btnOpenDropEnroll" runat="server" OnClick="btnOpenDropEnroll_Click"
                                        Text="�Դ��ö͹����Ԫ�" Width="150px" /></td>
                            </tr>
                        </table>
                    </asp:View>
                    <asp:View ID="viewSetPoll" runat="server">
                        <table cellspacing="0" width="750" align="center">
                            <tr>
                                <td bgcolor="#dcdcdc" colspan="2" style="height: 20px">
                                    <span style="color: #333333; font-family: Tahoma"><strong>��駤���к����Ǩ�����Դ���</strong></span></td>
                            </tr>
                            <tr>
                                <td align="right" bgcolor="#eff3fb" style="height: 25px">
                                    <asp:Label ID="Label4" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                        Text="ʶҹлѨ�غѹ :"></asp:Label></td>
                                <td align="left" bgcolor="#eff3fb" style="height: 25px">
                                    &nbsp;<asp:Label ID="lbPollStatus" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                        Font-Size="Small" Text="�Դ���ŧ��ṹ"></asp:Label></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                    <asp:Button ID="btnClosePoll" runat="server" OnClick="btnClosePoll_Click" Text="�Դ���ŧ��ṹ"
                                        Width="150px" /></td>
                                <td align="right" style="height: 25px">
                                    &nbsp;<asp:Button ID="btnOpenPoll" runat="server" OnClick="btnOpenPoll_Click" Text="�Դ���ŧ��ṹ"
                                        Width="150px" /></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                </td>
                                <td align="right" style="height: 25px">
                                </td>
                            </tr>
                            <tr>
                                <td align="center" bgcolor="#dcdcdc" colspan="2" style="height: 20px">
                                    <span style="color: #333333; font-family: Tahoma"><strong>�����Ǩ��С�èѴ���ҧ���¹</strong></span></td>
                            </tr>
                            <tr>
                                <td align="left" style="height: 25px">
                                    <asp:Button ID="btnClearSchedule" runat="server" Text="��ҧ��èѴ���ҧ���¹" Width="150px" OnClick="btnClearSchedule_Click" /></td>
                                <td align="right" style="height: 25px">
                                    <asp:Button ID="btnClearPoll" runat="server" Text="��ҧ�����Ǩ" Width="150px" OnClick="btnClearPoll_Click" /></td>
                            </tr>
                        </table>
                    </asp:View>
                </asp:MultiView>
                <table align="center" cellspacing="0" width="750">
                    <tr>
                        <td>
                <asp:Label ID="lbResult" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Large"
                    ForeColor="#333333" Height="25px" Width="750px"></asp:Label></td>
                    </tr>
                </table>
                &nbsp;
            </ContentTemplate>
        </asp:UpdatePanel>
    
    </div>
    </form>
</body>
</html>
