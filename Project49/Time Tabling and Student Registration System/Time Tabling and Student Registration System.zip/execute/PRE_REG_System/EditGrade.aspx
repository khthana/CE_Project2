<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EditGrade.aspx.cs" Inherits="PRE_REG_System.EditGrade" EnableEventValidation="false" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
        <asp:ScriptManager ID="smEditGrade" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="upEditGrade" runat="server">
            <ContentTemplate>
                <table align="center" cellpadding="0" cellspacing="0" width="750">
                    <tr>
                        <td align="center" bgcolor="#507cd1" colspan="4" style="width: 583px; height: 25px;
                            text-align: center">
                            <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma">
                                <asp:Label ID="Label5" runat="server" Font-Bold="True" Text="�к��Ѵ���ҧ�͹��С��ŧ����¹"
                                    Width="750px"></asp:Label></span></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="4" style="width: 583px; height: 25px; text-align: center">
                            <asp:Menu ID="menuTeacher" runat="server" BackColor="#F7F6F3" DynamicHorizontalOffset="2"
                                Font-Names="Tahoma" Font-Size="Small" ForeColor="#7C6F57" Height="20px" OnMenuItemClick="menuTeacher_MenuItemClick"
                                Orientation="Horizontal" StaticSubMenuIndent="10px" Width="752px">
                                <StaticMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" Width="185px" />
                                <DynamicHoverStyle BackColor="#7C6F57" ForeColor="White" />
                                <DynamicMenuStyle BackColor="#F7F6F3" />
                                <StaticSelectedStyle BackColor="LightSteelBlue" ForeColor="#333333" />
                                <DynamicSelectedStyle BackColor="#5D7B9D" />
                                <DynamicMenuItemStyle HorizontalPadding="5px" VerticalPadding="2px" />
                                <Items>
                                    <asp:MenuItem Selected="True" Text="��͡�š�����¹" Value="EditGrade"></asp:MenuItem>
                                    <asp:MenuItem NavigateUrl="~/Schedule.aspx" Target="_blank" Text="�ٵ��ҧ���¹" Value="ViewSchedule">
                                    </asp:MenuItem>
                                    <asp:MenuItem NavigateUrl="~/ViewPoll.aspx" Target="_blank" Text="�ټ����Ǩ" Value="SetPoll">
                                    </asp:MenuItem>
                                    <asp:MenuItem Text="��͡��ҷ�" Value="Logout"></asp:MenuItem>
                                </Items>
                                <StaticHoverStyle BackColor="#7C6F57" ForeColor="White" />
                            </asp:Menu>
                        </td>
                    </tr>
                </table>
                    <asp:MultiView ID="mwEditGrade" runat="server">
                        <asp:View ID="viewSelectSubject" runat="server">
                            <table align="center" cellspacing="0" width="750">
                                <tr>
                                    <td style="height: 20px">
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#dcdcdc" style="height: 20px">
                                        <span style="font-family: Tahoma"><strong>�к������Ԫ�</strong></span></td>
                                </tr>
                                <tr>
                                    <td align="center" bgcolor="#eff3fb" style="height: 25px">
                                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                            ForeColor="#333333" Text="�����Ԫ� :"></asp:Label>
                                        <asp:TextBox ID="txtSubjectCode" runat="server" Columns="10" MaxLength="8"></asp:TextBox>
                                        <asp:Button ID="btnOK" runat="server" OnClick="btnOK_Click" Text="��ŧ" Width="50px" />
                                        <cc1:FilteredTextBoxExtender ID="ftxtSubjectCode" runat="server" FilterType="Numbers"
                                            TargetControlID="txtSubjectCode">
                                        </cc1:FilteredTextBoxExtender>
                                    </td>
                                </tr>
                            </table>
                            <br />
                            <asp:Label ID="lbResult" runat="server" Font-Bold="True" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="Red" Height="20px" Width="750px"></asp:Label></asp:View>
                        <asp:View ID="viewEditGrade" runat="server">
                            <table align="center" cellspacing="0" width="750">
                                <tr>
                                    <td align="center" colspan="2" style="height: 20px">
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" bgcolor="#dcdcdc" colspan="2" style="height: 20px">
                                        <span style="font-family: Tahoma"><strong>�š�����¹</strong></span></td>
                                </tr>
                                <tr>
                                    <td align="left" bgcolor="#eff3fb" style="height: 12px">
                                        &nbsp;<asp:Label ID="lbSubjectCode" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                            Font-Size="Small"></asp:Label></td>
                                    <td align="right" bgcolor="#eff3fb" style="height: 12px">
                                        <asp:Label ID="lbSubjectName" runat="server" Font-Bold="True" Font-Names="Tahoma"
                                            Font-Size="Small"></asp:Label>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="center" colspan="2" style="height: 20px">
                                        <asp:GridView ID="gvEditHeader" runat="server" AutoGenerateColumns="False" BackColor="White"
                                            BorderColor="#CCCCCC" BorderStyle="None" BorderWidth="1px" CellPadding="4" Font-Names="Tahoma"
                                            Font-Size="Small" ForeColor="Black" GridLines="Vertical" OnRowCancelingEdit="gvEditHeader_RowCancelingEdit"
                                            OnRowCreated="gvEditHeader_RowCreated" OnRowEditing="gvEditHeader_RowEditing"
                                            OnRowUpdating="gvEditHeader_RowUpdating" Width="750px">
                                            <FooterStyle BackColor="#CCCC99" ForeColor="Black" />
                                            <Columns>
                                                <asp:CommandField CancelText="¡��ԡ" EditText="���" HeaderText="���ʹѡ�֡��"
                                                    ShowEditButton="True" UpdateText="�ѹ�֡">
                                                    <ItemStyle Width="80px" />
                                                </asp:CommandField>
                                                <asp:BoundField HeaderText="���͹ѡ�֡��" NullDisplayText="��ṹ���" ReadOnly="True" />
                                                <asp:TemplateField HeaderText="HW1">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxHW1" runat="server" MaxLength="3" Text='<%# Bind("MAX_HW1") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label1" runat="server" Text='<%# Bind("MAX_HW1") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="HW2">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxHW2" runat="server" MaxLength="3" Text='<%# Bind("MAX_HW2") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label2" runat="server" Text='<%# Bind("MAX_HW2") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="HW3">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxHW3" runat="server" MaxLength="3" Text='<%# Bind("MAX_HW3") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label3" runat="server" Text='<%# Bind("MAX_HW3") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="HW4">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxHW4" runat="server" MaxLength="3" Text='<%# Bind("MAX_HW4") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label4" runat="server" Text='<%# Bind("MAX_HW4") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="HW5">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxHW5" runat="server" MaxLength="3" Text='<%# Bind("MAX_HW5") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label5" runat="server" Text='<%# Bind("MAX_HW5") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="Mid">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxMid" runat="server" MaxLength="3" Text='<%# Bind("MAX_MID") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label6" runat="server" Text='<%# Bind("MAX_MID") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:TemplateField HeaderText="Final">
                                                    <EditItemTemplate>
                                                        <asp:TextBox ID="txtMaxFinal" runat="server" MaxLength="3" Text='<%# Bind("MAX_FINAL") %>'
                                                            Width="30px"></asp:TextBox>
                                                    </EditItemTemplate>
                                                    <ItemStyle Width="50px" />
                                                    <ItemTemplate>
                                                        <asp:Label ID="Label7" runat="server" Text='<%# Bind("MAX_FINAL") %>'></asp:Label>
                                                    </ItemTemplate>
                                                </asp:TemplateField>
                                                <asp:BoundField HeaderText="Total" ReadOnly="True">
                                                    <ItemStyle Width="50px" />
                                                </asp:BoundField>
                                                <asp:BoundField HeaderText="Grade" ReadOnly="True">
                                                    <ItemStyle Width="50px" />
                                                </asp:BoundField>
                                            </Columns>
                                            <SelectedRowStyle BackColor="#CC3333" Font-Bold="True" ForeColor="White" />
                                            <PagerStyle BackColor="White" ForeColor="Black" HorizontalAlign="Right" />
                                            <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" />
                                        </asp:GridView>
            <asp:GridView ID="gvEditGrade" runat="server" AutoGenerateColumns="False" CellPadding="4"
            Font-Names="Tahoma" Font-Size="Small" ForeColor="Black" OnRowCreated="gvEditGrade_RowCreated"
            Width="750px" BorderWidth="1px" AllowSorting="True" BackColor="#EFF3FB" BorderColor="#CCCCCC" BorderStyle="None" OnRowDataBound="gvEditGrade_RowDataBound" ShowHeader="False">
            <FooterStyle BackColor="#CCCC99" ForeColor="Black" />
            <Columns>
                <asp:BoundField DataField="SCODE" HeaderText="���ʹѡ�֡��" >
                    <ItemStyle Width="80px" />
                </asp:BoundField>
                <asp:BoundField DataField="SNAME_TH" HeaderText="���͹ѡ�֡��" />
                <asp:TemplateField HeaderText="HW1">
                    <EditItemTemplate>
                        &nbsp;
                    </EditItemTemplate>
                    <ItemTemplate>
                        <asp:TextBox ID="txtHW1" Text='<%# Bind("HW1") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="HW2">
                    <EditItemTemplate>
                        &nbsp;
                    </EditItemTemplate>
                    <ItemTemplate>
                        <asp:TextBox ID="txtHW2" Text='<%# Bind("HW2") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="HW3">
                    <EditItemTemplate>
                        &nbsp;
                    </EditItemTemplate>
                    <ItemTemplate>
                        <asp:TextBox ID="txtHW3" Text='<%# Bind("HW3") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="HW4">
                    <ItemTemplate>
                        <asp:TextBox ID="txtHW4" Text='<%# Bind("HW4") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="HW5">
                    <ItemTemplate>
                        <asp:TextBox ID="txtHW5" Text='<%# Bind("HW5") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Mid">
                    <ItemTemplate>
                        &nbsp;<asp:TextBox ID="txtMid" Text='<%# Bind("MID") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Final">
                    <ItemTemplate>
                        &nbsp;<asp:TextBox ID="txtFinal" Text='<%# Bind("FINAL") %>' runat="server" Columns="3" MaxLength="3" Width="30px"></asp:TextBox>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:BoundField DataField="TOTAL" HeaderText="Total" ReadOnly="True">
                    <ItemStyle Width="50px" />
                </asp:BoundField>
                <asp:TemplateField HeaderText="Grade">
                    <EditItemTemplate>
                        <asp:TextBox ID="TextBox1" runat="server" Columns="3" MaxLength="3"></asp:TextBox>
                    </EditItemTemplate>
                    <ItemTemplate>
                        <asp:DropDownList ID="ddlGrade" runat="server" Font-Names="Tahoma" Font-Size="Small">
                            <asp:ListItem Value="-">-</asp:ListItem>
                                        <asp:ListItem>A</asp:ListItem>
                                        <asp:ListItem>B+</asp:ListItem>
                                        <asp:ListItem>B</asp:ListItem>
                                        <asp:ListItem>C+</asp:ListItem>
                                        <asp:ListItem>C</asp:ListItem>
                                        <asp:ListItem>D+</asp:ListItem>
                                        <asp:ListItem>D</asp:ListItem>
                                        <asp:ListItem>F</asp:ListItem>
                                        <asp:ListItem>Fa</asp:ListItem>
                                        <asp:ListItem>Fe</asp:ListItem>
                                        <asp:ListItem>Fw</asp:ListItem>
                                        <asp:ListItem>W</asp:ListItem>
                                        <asp:ListItem>I</asp:ListItem>
                                        <asp:ListItem>S</asp:ListItem>
                                        <asp:ListItem>U</asp:ListItem>
                                    </asp:DropDownList>
                    </ItemTemplate>
                    <ItemStyle Width="50px" />
                </asp:TemplateField>
                <asp:ButtonField Text="Button" />
            </Columns>
            <SelectedRowStyle BackColor="#CC3333" Font-Bold="True" ForeColor="White" />
            <PagerStyle BackColor="White" ForeColor="Black" HorizontalAlign="Right" />
            <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" />
        </asp:GridView>
            </td>
                                </tr>
                                <tr>
                                    <td align="left">
                                        <asp:Button ID="btnCancel" runat="server" OnClick="btnCancel_Click" Text="¡��ԡ"
                                            Width="100px" /><asp:Button ID="btnBack" runat="server" OnClick="btnBack_Click" Text="< ��͹��Ѻ"
                                                Visible="False" Width="120px" /></td>
                                    <td align="right">
                                        <asp:Button ID="btnConfirmGrade" runat="server" OnClick="btnConfirmGrade_Click"
                                            Text="�ѹ�֡������" Visible="False" Width="125px" /><asp:Button ID="btnNext"
                                                runat="server" OnClick="btnNext_Click" Text="��鹵͹���� >" Width="120px" /></td>
                                </tr>
                            </table>
                            &nbsp;
                        </asp:View>
                        &nbsp;&nbsp;
                    </asp:MultiView>&nbsp;
            </ContentTemplate>
        </asp:UpdatePanel>
        &nbsp;<br />
        <asp:SqlDataSource ID="sqldsEditGrade" runat="server" ConnectionString="<%$ ConnectionStrings:Oracle10g %>"
            ProviderName="<%$ ConnectionStrings:Oracle10g.ProviderName %>"></asp:SqlDataSource>
        <asp:SqlDataSource ID="sqldsEditHeader" runat="server" ConnectionString="<%$ ConnectionStrings:Oracle10g %>"
            ProviderName="<%$ ConnectionStrings:Oracle10g.ProviderName %>"></asp:SqlDataSource>
    
    </form>
</body>
</html>
