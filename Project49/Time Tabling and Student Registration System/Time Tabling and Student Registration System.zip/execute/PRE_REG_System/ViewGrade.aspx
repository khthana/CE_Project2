<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ViewGrade.aspx.cs" Inherits="PRE_REG_System.ViewGrade" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
        <asp:ScriptManager ID="smViewGrade" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="upViewGrade" runat="server">
            <ContentTemplate>
                <table cellspacing="0" width="750" align="center">
                    <tr>
                        <td align="left" bgcolor="#507cd1" style="width: 320px; height: 25px;">
                            <strong><span style="font-size: 14pt">&nbsp;<asp:Label ID="Label1" runat="server" ForeColor="White" Text="��Ǩ�ͺ�š�����¹" Font-Bold="True" Font-Names="Tahoma" Font-Size="Large"></asp:Label></span></strong></td>
                        <td align="right" bgcolor="#507cd1" style="height: 25px; font-size: 12pt;">
                            <asp:Label ID="Label5" runat="server" BorderColor="Black" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="White" Height="19px" Text="�Ҥ���¹��� :"></asp:Label>&nbsp;<asp:DropDownList
                                    ID="ddlTerm" runat="server" Font-Names="Tahoma" Font-Size="Small" Width="49px" AutoPostBack="True">
                                    <asp:ListItem>2</asp:ListItem>
                                    <asp:ListItem>1</asp:ListItem>
                                </asp:DropDownList>
                            <asp:Label ID="Label6" runat="server" BorderColor="Black" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="White" Height="19px" Text="�ա���֡�� :"></asp:Label>&nbsp;
                                <asp:DropDownList
                                    ID="ddlYear" runat="server" Font-Names="Tahoma" Font-Size="Small" Width="70px" AutoPostBack="True" OnSelectedIndexChanged="ddlYear_SelectedIndexChanged" >
                                </asp:DropDownList></td>
                    </tr>
                    <tr style="font-size: 12pt">
                        <td align="left" bgcolor="#eff3fb" style="width: 320px; height: 20px;">
                            &nbsp;<asp:Label ID="lbStudentID" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label></td>
                        <td align="right" bgcolor="#eff3fb" style="height: 20px">
                            <asp:Label ID="lbStudentName" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label>&nbsp;</td>
                    </tr>
                </table>
                <br />
                <table cellspacing="0" width="750" style="font-size: 12pt" align="center">
                    <tr>
                        <td align="left" bgcolor="#dcdcdc" style="height: 22px">
                            &nbsp;<span style="color: #333333; font-family: Tahoma"><strong>�����żš�����¹</strong></span></td>
                    </tr>
                    <tr>
                        <td align="center" style="height: 22px">
                            <asp:MultiView ID="mwViewGrade" runat="server">
                                <asp:View ID="viewGrade" runat="server">
                <asp:GridView ID="gvGrade" runat="server" CellPadding="4" Font-Names="Tahoma" Font-Size="Small"
                    ForeColor="Black" OnRowCreated="gvGrade_RowCreated" ShowFooter="True"
                    Width="750px" BackColor="White" BorderColor="#CCCCCC" BorderWidth="1px" BorderStyle="None">
                    <FooterStyle BackColor="Silver" ForeColor="Black" />
                    <SelectedRowStyle BackColor="#CC3333" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="White" ForeColor="Black" HorizontalAlign="Right" />
                    <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" />
                </asp:GridView>
                                </asp:View>
                                <asp:View ID="viewAllGrade" runat="server">
                                    <asp:GridView ID="gvAllGrade" runat="server" BackColor="White" BorderColor="#CCCCCC"
                                        BorderStyle="None" BorderWidth="1px" CellPadding="4" Font-Names="Tahoma" Font-Size="Small"
                                        ForeColor="Black" OnRowDataBound="gvAllGrade_RowDataBound" ShowFooter="True"
                                        Width="750px">
                                        <FooterStyle BackColor="Silver" ForeColor="Black" />
                                        <SelectedRowStyle BackColor="#CC3333" Font-Bold="True" ForeColor="White" />
                                        <PagerStyle BackColor="White" ForeColor="Black" HorizontalAlign="Right" />
                                        <HeaderStyle BackColor="#333333" Font-Bold="True" ForeColor="White" />
                                    </asp:GridView>
                                </asp:View>
                            </asp:MultiView></td>
                    </tr>
                    <tr>
                        <td align="right" style="height: 22px">
                <asp:Button ID="btnViewGrade" runat="server" OnClick="btnViewGrade_Click" Text="�ټš�����¹" Width="110px" Visible="False" /></td>
                    </tr>
                </table>
                &nbsp;
            </ContentTemplate>
        </asp:UpdatePanel>
    </form>
</body>
</html>
