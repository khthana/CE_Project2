using System;
using System.Data;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Timeout = 60;
                RandomCheckCode();
            }
        }
        protected string CreateRandomCode(int codeCount)
        {
            string allChar = "0,1,2,3,4,5,6,7,8,9";
            string[] allCharArray = allChar.Split(',');
            string randomCode = "";
            int temp = -1;

            Random rand = new Random();
            for (int i = 0; i < codeCount; i++)
            {
                if (temp != -1)
                {
                    rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
                }
                int t = rand.Next(10);
                if (temp != -1 && temp == t)
                {
                    return CreateRandomCode(codeCount);
                }
                temp = t;
                randomCode += allCharArray[t];
            }
            return randomCode;
        }
        protected void RandomCheckCode()
        {
            string picID = CreateRandomCode(1);
            Session["PicID"] = picID;
            imgCheckCode.ImageUrl = "http://161.246.6.10/blob/blob" + picID + ".gif";
        }
        protected string GetCheckCode(string picID)
        {
            string code = "";
            if (picID == "0") code = "H9nNu3i8";
            else if (picID == "1") code = "3DpX32Ai";
            else if (picID == "2") code = "4zY8mp8j";
            else if (picID == "3") code = "6Eb77izW";
            else if (picID == "4") code = "8cR3zmq4";
            else if (picID == "5") code = "C3yV82A5";
            else if (picID == "6") code = "Tx43zN6i";
            else if (picID == "7") code = "Dx82HhA9";
            else if (picID == "8") code = "F8yD7i3W";
            else if (picID == "9") code = "Tm8Av4Z3";

            return code;
        }
        
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (Session["PicID"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            String userID = txtUserID.Text;

            OracleConnection conn = new OracleConnection();
            conn.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            conn.Open();

            String cmdQuery = "";

            if (rdStudent.Checked) cmdQuery = "SELECT SID,SPASSW,SCODE,CK_VOTE,CK_REGIS FROM STUDENT WHERE SID='" + userID + "'";
            else if (rdTeacher.Checked) cmdQuery = "SELECT TID,TPASSW FROM TEACHER WHERE TID='" + userID + "'";
            else if (rdAdmin.Checked) cmdQuery = "SELECT AID,APASSW FROM ADMIN WHERE AID='" + userID + "'";
            
            OracleCommand cmd = new OracleCommand(cmdQuery);
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;

            OracleDataReader reader = cmd.ExecuteReader();

            bool validUser = false;
            String inputUserID = txtUserID.Text;
            String inputPassword = txtPassword.Text;
            String inputCheckCode = txtCheckCode.Text;
            String hashedPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(inputPassword, "MD5");

            string picID = Session["PicID"].ToString();
            string checkCode = GetCheckCode(picID);

            String studentCode = "";
            
            if (reader.Read())
            {
                if ((reader.GetString(0) == inputUserID) && (reader.GetString(1) == hashedPassword)
                    && (checkCode == inputCheckCode))
                {
                    validUser = true;
                    if (rdStudent.Checked) studentCode = reader.GetString(2);
                }
            }

            if (validUser)
            {
                if (rdStudent.Checked)
                {
                    Session["ActiveStudent"] = 1;
                    Session["StudentCode"] = studentCode;
                    Response.Redirect("StudentMenu.aspx");
                }
                else if (rdTeacher.Checked) 
                {
                    Session["ActiveTeacher"] = 1;
                    Response.Redirect("EditGrade.aspx");
                }
                else if (rdAdmin.Checked)
                {
                    Session["ActiveAdmin"] = 1;
                    Response.Redirect("Admin.aspx");
                }
            }
            else
            {
                lbErrorMsg.Text = "����, ���� ���� ���ʵ�Ǩ�ͺ���١��ͧ, ��سҡ�͡�����ա����";
                txtCheckCode.Text = "";
                RandomCheckCode();
            }
            
            cmd.Dispose();
            conn.Close();
            conn.Dispose();
        }
    }
}

