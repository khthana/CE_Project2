using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class ViewGrade : System.Web.UI.Page
    {
        protected DataSet dsetGrade = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ActiveStudent"] == null)
            {
                Response.Redirect("Default.aspx");
            }

            // Manual Set Session and Application
            /*Session["StudentCode"] = "47015330";
            Session["StudentName"] = "���ͺ �к�";
            Session["StudentYear"] = "3";
            Application["CurrentTerm"] = "2";
            Application["CurrentYear"] = "2549";*/

            String studentCode = Session["StudentCode"].ToString();
            String studentName = Session["StudentName"].ToString();

            lbStudentID.Text = "���ʹѡ�֡�� : " + studentCode;
            lbStudentName.Text = "����-���ʡ�� : " + studentName;

            if (!IsPostBack)
            {
                int currentYear = Convert.ToInt32(Application["CurrentYear"]);
                int studentYear = Convert.ToInt32(Session["StudentYear"]);

                SetDropDownListYear(currentYear, studentYear);
                mwViewGrade.SetActiveView(viewGrade);
            }

            // Display Grade or All Grade
            if (ddlYear.SelectedItem.Text == "������")
            {
                DataTable dtbAllGrade = GetAllGradeData(studentCode);
                dtbAllGrade = AddSubHead(dtbAllGrade);

                gvAllGrade.DataSource = dtbAllGrade;
                gvAllGrade.DataBind();
            }
            else
            {
                String term = ddlTerm.SelectedItem.Text;
                String year = ddlYear.SelectedItem.Text;

                DataTable dtbGrade = GetGradeData(studentCode, term, year);

                gvGrade.DataSource = dtbGrade;
                gvGrade.DataBind();

                if (gvGrade.HasControls())
                {
                    float gps = CalculateGPS(dtbGrade);

                    gvGrade.FooterRow.Cells[3].Text = "GPS : " + gps.ToString("f");
                    gvGrade.FooterRow.Cells[3].Font.Bold = true;
                    gvGrade.FooterRow.Cells[3].HorizontalAlign = HorizontalAlign.Center;
                }
            }
        }
        protected DataTable GetAllGradeData(String studentCode)
        {
            DataTable dtbGrade = new DataTable();
            dtbGrade.TableName = "GradeAll";
            dtbGrade.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbGrade.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbGrade.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));
            dtbGrade.Columns.Add("�ô", System.Type.GetType("System.String"));
            dtbGrade.Columns.Add("TermYear", System.Type.GetType("System.String"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT SUBJECT.SUB_CODE, SUBJECT.SUB_NAME, SUBJECT.UNIT, ENROLL.GRADE," +
                " ENROLL.TERM, ENROLL.YEAR" +
                " FROM ENROLL,SUBJECT" +
                " WHERE ENROLL.SUB_CODE=SUBJECT.SUB_CODE" +
                " AND SCODE=" + studentCode +
                " ORDER BY ENROLL.YEAR, ENROLL.TERM, SUBJECT.SUB_CODE";

            OracleCommand command = new OracleCommand(commandText);
            command.Connection = connection;

            OracleDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                DataRow dr = dtbGrade.NewRow();
                dr["�����Ԫ�"] = reader.GetString(0);
                dr["�����Ԫ�"] = reader.GetString(1);
                dr["˹��¡Ե"] = reader.GetInt32(2);
                dr["�ô"] = reader.GetString(3);
                dr["TermYear"] = reader.GetString(4) + reader.GetString(5);

                dtbGrade.Rows.Add(dr);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return dtbGrade;
        }
        protected DataTable AddSubHead(DataTable dtbAllGrade)
        {
            String curTermYear = "";
            String prevTermYear = "";
            
            for (int i = 0; i < dtbAllGrade.Rows.Count; i++)
            {
                curTermYear = dtbAllGrade.Rows[i]["TermYear"].ToString();
                if(curTermYear != prevTermYear)
                {
                    prevTermYear = curTermYear;

                    DataRow dr = dtbAllGrade.NewRow();

                    String term = "�Ҥ���¹��� " + curTermYear.Substring(0,1) + " ";
                    String year = "�ա���֡�� " + curTermYear.Substring(1); 

                    dr["�����Ԫ�"] = term + year;
                    dr["�����Ԫ�"] = "SubHead";

                    dtbAllGrade.Rows.InsertAt(dr,i);
                    i++;
                }
            }

            dtbAllGrade.Columns.Remove("TermYear");
            return dtbAllGrade;
        }
        protected DataTable GetGradeData(String studentCode, String term, String year)
        {
            DataTable dtbGrade = new DataTable();
            dtbGrade.TableName = "Grade";
            dtbGrade.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbGrade.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbGrade.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));
            dtbGrade.Columns.Add("�ô", System.Type.GetType("System.String"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT SUBJECT.SUB_CODE, SUBJECT.SUB_NAME, SUBJECT.UNIT, ENROLL.GRADE" +
                " FROM ENROLL,SUBJECT" +
                " WHERE ENROLL.SUB_CODE=SUBJECT.SUB_CODE" +
                " AND SCODE=" + studentCode +
                " AND TERM=" + term +
                " AND YEAR=" + year +
                " ORDER BY SUBJECT.SUB_CODE";

            OracleCommand command = new OracleCommand(commandText);
            command.Connection = connection;
            command.CommandType = CommandType.Text;

            OracleDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                DataRow dr = dtbGrade.NewRow();
                dr["�����Ԫ�"] = reader.GetString(0);
                dr["�����Ԫ�"] = reader.GetString(1);
                dr["˹��¡Ե"] = reader.GetInt32(2);
                dr["�ô"] = reader.GetString(3);

                dtbGrade.Rows.Add(dr);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return dtbGrade;
        }
        protected float CalculateGPS(DataTable dtbGrade)
        {
            int sumOfUnit = 0;
            float sumOfPoint = 0.0f;

            foreach (DataRow dr in dtbGrade.Rows)
            {
                int unit = Convert.ToInt32(dr["˹��¡Ե"]);
                float grade = GetGradePoint(dr["�ô"].ToString());
                float point = grade * unit;

                sumOfUnit += unit;
                sumOfPoint += point;
            }

            float gps = sumOfPoint / sumOfUnit;

            return gps;
        }
        private float GetGradePoint(String grade)
        {
            if (grade == "A") return 4.0f;
            else if (grade == "B+") return 3.5f;
            else if (grade == "B") return 3.0f;
            else if (grade == "C+") return 2.5f;
            else if (grade == "C") return 2.0f;
            else if (grade == "D+") return 1.5f;
            else if (grade == "D") return 1.0f;
            else return 0.0f;
        }
        private void SetDropDownListYear(int currentYear, int studentYear)
        {
            for (int i = 0; i < studentYear; i++)
            {
                int item = currentYear - i;
                ddlYear.Items.Add(item.ToString());
            }

            ddlYear.Items.Add("������");
        }
        protected void btnViewGrade_Click(object sender, EventArgs e)
        {
            if (ddlYear.SelectedItem.Text == "������")
            {
                mwViewGrade.SetActiveView(viewAllGrade);
            }
            else
            {
                mwViewGrade.SetActiveView(viewGrade);
            }
        }
        protected void gvGrade_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[0].Width = 100;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[2].Width = 100;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[3].Width = 100;
            }
        }
        protected void gvAllGrade_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[1].Text == "SubHead")
                {
                    e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                    e.Row.Cells[0].ColumnSpan = 4;
                    e.Row.Cells[0].Font.Bold = true;
                    e.Row.Cells.RemoveAt(3);
                    e.Row.Cells.RemoveAt(2);
                    e.Row.Cells.RemoveAt(1);
                    e.Row.BackColor = System.Drawing.Color.WhiteSmoke;
                }
                else
                {
                    e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[0].Width = 100;
                    e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
                    e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[2].Width = 100;
                    e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[3].Width = 100;
                }
            }
        }
        protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlYear.SelectedItem.Text == "������")
            {
                ddlTerm.Enabled = false;
                mwViewGrade.SetActiveView(viewAllGrade);
            }
            else
            {
                ddlTerm.Enabled = true;
                mwViewGrade.SetActiveView(viewGrade);
            }
        }
    }
}
