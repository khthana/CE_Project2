using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public partial class Schedule : System.Web.UI.Page
    {
        const int maxSlot = 9;
        protected DataSet dsetSchedule = new DataSet();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Manual Set Session and Application
                /*Session["StudentCode"] = "47015330";
                Session["StudentName"] = "���оѲ�� �ѧ�����";
                Session["StudentYear"] = "3";
                Application["CurrentTerm"] = "2";
                Application["CurrentYear"] = "2549";*/

                DataTable dtbPollData = WebUtility.LoadPollData();
                dsetSchedule.Tables.Add(dtbPollData);

                DataTable dtbSummaryData = WebUtility.SummaryData(dtbPollData, "CUT");
                dsetSchedule.Tables.Add(dtbSummaryData);
                gvSummaryData.DataSource = dtbSummaryData;
                gvSummaryData.DataBind();

                if (gvSummaryData.HasControls())
                {
                    mwSchedule.SetActiveView(viewSummary);
                }
                else
                {
                    mwSchedule.SetActiveView(viewEmpty);
                }
                
                Session["Schedule"] = dsetSchedule;
                ManageSlotByVote(dtbSummaryData, tblSchedule);
            }
        }

        protected void ManageSlotDistribute(DataTable dtbSummaryData, Table tableToDisplay)
        {
            // Divide subject group
            DataRow[] subjectRowsHW = dtbSummaryData.Select("SubjectGroup='HW'", "Count DESC");
            DataRow[] subjectRowsSW = dtbSummaryData.Select("SubjectGroup='SW'", "Count DESC");
            DataRow[] subjectRowsNW = dtbSummaryData.Select("SubjectGroup='NW'", "Count DESC");
            DataRow[] subjectRowsAI = dtbSummaryData.Select("SubjectGroup='AI'", "Count DESC");
            
            ArrayList listAllSlotHW = new ArrayList();
            ArrayList listAllSlotSW = new ArrayList();
            ArrayList listAllSlotNW = new ArrayList();
            ArrayList listAllSlotAI = new ArrayList();
            
            // Create ArrayList in each group
            for (int i = 0; i < maxSlot; i++)
            {
                ArrayList listSubjectHW = new ArrayList();
                listAllSlotHW.Add(listSubjectHW);

                ArrayList listSubjectSW = new ArrayList();
                listAllSlotSW.Add(listSubjectSW);

                ArrayList listSubjectNW = new ArrayList();
                listAllSlotNW.Add(listSubjectNW);
                
                ArrayList listSubjectAI = new ArrayList();
                listAllSlotAI.Add(listSubjectAI);
            }

            // ��Ш���Ԫ�����С����ŧ� slot
            DistributeSubject(subjectRowsHW, listAllSlotHW);
            DistributeSubject(subjectRowsSW, listAllSlotSW);
            DistributeSubject(subjectRowsNW, listAllSlotNW);
            DistributeSubject(subjectRowsAI, listAllSlotAI);

            int currentTerm = Convert.ToInt32(Application["CurrentTerm"]);

            // ����Ԫ�����С����ŧ㹵��ҧ
            FillToTable(listAllSlotHW, currentTerm, tableToDisplay, "FW");
            FillToTable(listAllSlotSW, currentTerm, tableToDisplay, "FW");
            FillToTable(listAllSlotNW, currentTerm, tableToDisplay, "RW");
            FillToTable(listAllSlotAI, currentTerm, tableToDisplay, "RW");
        }
        protected void DistributeSubject(DataRow[] rows, ArrayList slot)
        {
            int round = 0;
            int subjectCount = 0;

            for (int i = 0; i < rows.Length; i++)
            {
                for (int ii = 0; ii < slot.Count; ii++)
                {
                    ArrayList listSubject = (ArrayList)slot[ii];
                    if (listSubject.Count == round)
                    {
                        listSubject.Add(rows[i]);
                        subjectCount++;
                        break;
                    }
                }

                if (subjectCount == maxSlot)
                {
                    round++;
                    subjectCount = 0;
                }
            }
        }
        protected void FillToTable(ArrayList listAllSlot, int term, Table tableToDisplay, String mode)
        {
            for (int i = 0; i < listAllSlot.Count; i++)
            {
                ArrayList list = (ArrayList)listAllSlot[i];
                DataRow[] subjectRows = (DataRow[])list.ToArray(typeof(DataRow));

                if (i == 0)
                {
                    if (term == 1)
                    {
                        if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 1);
                        else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 6, 1);
                    }
                    else if (term == 2)
                    {
                        if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 1);
                        else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 6, 2);
                    }
                }
                else if (i == 1)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 2);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 5, 2);
                }
                else if (i == 2)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 3, 1);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 5, 1);
                }
                else if (i == 3)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 3, 2);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 4, 2);
                }
                else if (i == 4)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 4, 1);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 4, 1);
                }
                else if (i == 5)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 4, 2);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 3, 2);
                }
                else if (i == 6)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 5, 1);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 3, 1);
                }
                else if (i == 7)
                {
                    if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 5, 2);
                    else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 2);
                }
                else if (i == 8)
                {
                    if (term == 1)
                    {
                        if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 6, 1);
                        else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 1);
                    }
                    else if (term == 2)
                    {
                        if (mode == "FW") WebUtility.FillData(subjectRows, tableToDisplay, 6, 2);
                        else if (mode == "RW") WebUtility.FillData(subjectRows, tableToDisplay, 2, 1);
                    }
                }
            }
        }

        protected void ManageSlotNew(DataTable dtbSummaryData, Table tableToDisplay)
        {
            DataRow[] listYear2 = dtbSummaryData.Select("Year=2", "Count DESC");
            DataRow[] listYear3 = dtbSummaryData.Select("Year=3", "Count DESC");
            DataRow[] listYear4 = dtbSummaryData.Select("Year=4", "Count DESC");
        }
        
        protected void ManageSlotByVote(DataTable dtbSummaryData, Table tableToDisplay)
        {
            DataRow[] subjectRows;

            subjectRows = dtbSummaryData.Select("Day='Mon' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 1, 1);

            subjectRows = dtbSummaryData.Select("Day='Mon' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 1, 2);

            subjectRows = dtbSummaryData.Select("Day='Tue' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 2, 1);

            subjectRows = dtbSummaryData.Select("Day='Tue' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 2, 2);

            subjectRows = dtbSummaryData.Select("Day='Wed' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 3, 1);

            subjectRows = dtbSummaryData.Select("Day='Wed' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 3, 2);

            subjectRows = dtbSummaryData.Select("Day='Thu' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 4, 1);

            subjectRows = dtbSummaryData.Select("Day='Thu' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 4, 2);

            subjectRows = dtbSummaryData.Select("Day='Fri' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 5, 1);

            subjectRows = dtbSummaryData.Select("Day='Fri' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 5, 2);

            subjectRows = dtbSummaryData.Select("Day='Sat' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 6, 1);

            subjectRows = dtbSummaryData.Select("Day='Sat' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 6, 2);

            subjectRows = dtbSummaryData.Select("Day='Sun' AND Period='M'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 7, 1);

            subjectRows = dtbSummaryData.Select("Day='Sun' AND Period='A'", "Count DESC");
            WebUtility.FillData(subjectRows, tableToDisplay, 7, 2);
        }
        
        protected void ddlManage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlManage.SelectedValue == "ManageByVote")
            {
                dsetSchedule = (DataSet)Session["Schedule"];
                DataTable dtbSummaryData = (DataTable)dsetSchedule.Tables["SummaryData"];

                ManageSlotByVote(dtbSummaryData, tblSchedule);
            }
            else if (ddlManage.SelectedValue == "ManageDistribute")
            {
                dsetSchedule = (DataSet)Session["Schedule"];
                DataTable dtbSummaryData = (DataTable)dsetSchedule.Tables["SummaryData"];

                ManageSlotDistribute(dtbSummaryData, tblSchedule);
            }
        }

        protected void gvSummaryData_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Cells[0].Text = "�����Ԫ�";
                e.Row.Cells[1].Text = "�����Ԫ�";
                e.Row.Cells[2].Text = "������Ԫ�";
                e.Row.Cells[3].Text = "�ѹ";
                e.Row.Cells[4].Text = "����";
                e.Row.Cells[5].Text = "��鹻�";
                e.Row.Cells[6].Text = "�ӹǹ���";
            }
            else if(e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Left;
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            // Confirms that an HtmlForm control is rendered for the
        }
        protected void lnkDownloadData_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=PollData.xls");
            Response.Charset = "";

            Response.ContentType = "application/vnd.xls";
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();

            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);

            gvSummaryData.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();
        }

        protected void lnkDownloadTable_Click(object sender, EventArgs e)
        {
            if (ddlManage.SelectedValue == "ManageByVote")
            {
                dsetSchedule = (DataSet)Session["Schedule"];
                DataTable dtbSummaryData = (DataTable)dsetSchedule.Tables["SummaryData"];

                ManageSlotByVote(dtbSummaryData, tblSchedule);
            }
            else if (ddlManage.SelectedValue == "ManageDistribute")
            {
                dsetSchedule = (DataSet)Session["Schedule"];
                DataTable dtbSummaryData = (DataTable)dsetSchedule.Tables["SummaryData"];

                ManageSlotDistribute(dtbSummaryData, tblSchedule);
            }

            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=Table.xls");
            Response.Charset = "";

            Response.ContentType = "application/vnd.xls";
            System.IO.StringWriter stringWrite = new System.IO.StringWriter();

            System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);

            tblSchedule.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();
        }
    }
}
