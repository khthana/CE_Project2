<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DropEnroll.aspx.cs" Inherits="PRE_REG_System.DropEnroll" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>�к��Ѵ���ҧ�͹��С��ŧ����¹</title>
</head>
<body style="text-align: center">
    <form id="form1" runat="server">
    <div style="text-align: center">
        <asp:ScriptManager ID="smDropEnroll" runat="server">
        </asp:ScriptManager>
        <table cellspacing="0" width="750" align="center">
            <tr>
                <td align="center" bgcolor="#507cd1" colspan="4" style="width: 605px; height: 25px;
                    text-align: center">
                    <span style="font-size: 14pt; color: #ffffff; font-family: Tahoma">
                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Text="�͹����Ԫ�" Width="750px"></asp:Label></span></td>
            </tr>
            <tr>
                <td align="left" bgcolor="#eff3fb" style="height: 20px" width="350">
                    &nbsp;<asp:Label ID="lbStudentCode" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="left" bgcolor="#eff3fb" style="width: 1054px; height: 20px">
                    <asp:Label ID="lbStudentName" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                    <asp:Label ID="lbStudentYear" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label></td>
                <td align="right" bgcolor="#eff3fb" style="height: 20px" width="250">
                    <asp:Label ID="lbCurrentTerm" runat="server" Font-Names="Tahoma" Font-Size="Small"
                        ForeColor="#333333"></asp:Label>&nbsp;</td>
            </tr>
        </table>
        <br />
        <asp:UpdatePanel ID="upDropEnroll" runat="server">
            <ContentTemplate>
                <table cellspacing="0" width="750" align="center">
                    <tr>
                        <td align="left" bgcolor="#dcdcdc" style="height: 20px">
                            &nbsp;<span style="color: #333333; font-family: Tahoma"><strong>����Ԫҷ��ŧ����¹</strong></span></td>
                    </tr>
                    <tr>
                        <td align="center" style="height: 20px">
                <asp:GridView ID="gvEnroll" runat="server" BackColor="White" BorderColor="#6B696B" BorderWidth="1px" CellPadding="4" Font-Names="Tahoma" Font-Size="Small"
                    ForeColor="Black" GridLines="None" OnRowCreated="gvEnroll_RowCreated" OnRowDeleting="gvEnroll_RowDeleting"
                    Width="750px">
                    <FooterStyle BackColor="#CCCC99" />
                    <Columns>
                        <asp:CommandField ButtonType="Button" CancelText="¡��ԡ.." DeleteText="�͹.." HeaderText="�͹"
                            ShowDeleteButton="True">
                            <ControlStyle BackColor="White" BorderColor="#6B696B" BorderStyle="Solid" BorderWidth="1px"
                                Width="55px" />
                        </asp:CommandField>
                    </Columns>
                    <RowStyle BackColor="#F7F7DE" />
                    <SelectedRowStyle BackColor="#CE5D5A" Font-Bold="False" ForeColor="White" />
                    <PagerStyle BackColor="#F7F7DE" ForeColor="Black" HorizontalAlign="Right" />
                    <HeaderStyle BackColor="#6B696B" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
                    <AlternatingRowStyle BackColor="White" />
                </asp:GridView>
                        </td>
                    </tr>
                </table>
                <table cellspacing="0" style="font-size: 12pt" width="750" align="center">
                    <tr>
                        <td align="left" bgcolor="#cccc99" style="height: 20px">
                            &nbsp;<asp:Label ID="lbErrorMsg" runat="server" Font-Names="Tahoma" Font-Size="Small"
                                ForeColor="Red"></asp:Label></td>
                        <td align="right" bgcolor="#cccc99" style="height: 20px">
                            <asp:Label ID="lbSumUnit" runat="server" Font-Names="Tahoma" Font-Size="Small"></asp:Label>&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="height: 20px" align="left">
                        </td>
                        <td align="right" style="height: 20px">
                            <asp:Button ID="btnDrop" runat="server" OnClick="btnDrop_Click" Text="�͹����Ԫ�"
                                Width="120px" /></td>
                    </tr>
                </table>
            </ContentTemplate>
        </asp:UpdatePanel>
    
    </div>
    </form>
</body>
</html>
