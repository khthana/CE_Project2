<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TimeTable.aspx.cs" Inherits="PRE_REG_System.TimeTable" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Table ID="tblTimeTable" runat="server" BorderColor="DarkGray" BorderStyle="Solid"
            BorderWidth="1px" CellPadding="1" CellSpacing="0" Font-Names="Tahoma" Font-Size="Small"
            GridLines="Both" Width="750px">
            <asp:TableRow runat="server" BackColor="#507CD1" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px" Font-Bold="False">
                <asp:TableCell runat="server" BackColor="White" BorderColor="DarkGray" BorderStyle="Solid"
                    BorderWidth="1px" HorizontalAlign="Center" Width="50px">-----</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">09.00 - 12.00</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    Font-Bold="True" ForeColor="White" HorizontalAlign="Center" Width="300px">13.00 - 16.00</asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFFFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѹ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0FF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ѧ���</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFC0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ظ</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFE0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">����ʺ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0FFFF" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ء��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#C0C0FF" BorderColor="DarkGray" BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�����</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
            <asp:TableRow runat="server" BackColor="#FFC0C0" BorderColor="DarkGray" BorderStyle="Solid"
                BorderWidth="1px">
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px">�ҷԵ��</asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
                <asp:TableCell runat="server" BorderColor="DarkGray" BorderStyle="Solid" BorderWidth="1px"
                    HorizontalAlign="Justify"></asp:TableCell>
            </asp:TableRow>
        </asp:Table>
    
    </div>
    </form>
</body>
</html>
