using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Text;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace PRE_REG_System
{
    public class WebUtility
    {
        public static void SessionTimeOut(Page page)
        {
            page.Response.Redirect("SessionTimeOut.aspx");
        }
        public static DataTable LoadTimeTable(String studentYear)
        {
            DataTable dtb = new DataTable();
            dtb.TableName = "TimeTable";
            dtb.Columns.Add("SubjectCode", System.Type.GetType("System.String"));
            dtb.Columns.Add("SubjectName", System.Type.GetType("System.String"));
            dtb.Columns.Add("SEC", System.Type.GetType("System.String"));
            dtb.Columns.Add("Day", System.Type.GetType("System.String"));
            dtb.Columns.Add("Period", System.Type.GetType("System.String"));
            dtb.Columns.Add("StudentYear", System.Type.GetType("System.String"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT SUBJECT.SUB_CODE, SUBJECT.SUB_NAME ," +
                "TTABLE.SEC ,TTABLE.DAY, TTABLE.PERIOD " +
                "FROM SUBJECT,TTABLE " +
                "WHERE SUBJECT.SUB_CODE=TTABLE.SUB_CODE " +
                "AND TTABLE.YEAR='" + studentYear + "'";

            OracleCommand command = new OracleCommand(commandText);
            command.Connection = connection;

            OracleDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                DataRow dr = dtb.NewRow();
                dr["SubjectCode"] = reader.GetString(0);
                dr["SubjectName"] = reader.GetString(1);
                dr["SEC"] = reader.GetString(2);
                dr["Day"] = reader.GetString(3);
                dr["Period"] = reader.GetString(4);
                dr["StudentYear"] = studentYear;

                dtb.Rows.Add(dr);
            }

            command.Dispose();
            connection.Close();
            connection.Close();

            return dtb;
        }
        public static void DisplayTimeTable(DataTable dtbSource, Table tableToDisplay)
        {
            DataRow[] subjectRows;

            subjectRows = dtbSource.Select("Day='Mon' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 1, 1);

            subjectRows = dtbSource.Select("Day='Mon' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 1, 2);

            subjectRows = dtbSource.Select("Day='Tue' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 2, 1);

            subjectRows = dtbSource.Select("Day='Tue' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 2, 2);

            subjectRows = dtbSource.Select("Day='Wed' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 3, 1);

            subjectRows = dtbSource.Select("Day='Wed' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 3, 2);

            subjectRows = dtbSource.Select("Day='Thu' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 4, 1);

            subjectRows = dtbSource.Select("Day='Thu' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 4, 2);

            subjectRows = dtbSource.Select("Day='Fri' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 5, 1);

            subjectRows = dtbSource.Select("Day='Fri' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 5, 2);

            subjectRows = dtbSource.Select("Day='Sat' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 6, 1);

            subjectRows = dtbSource.Select("Day='Sat' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 6, 2);

            subjectRows = dtbSource.Select("Day='Sun' AND Period='M'");
            FillTimeTable(subjectRows, tableToDisplay, 7, 1);

            subjectRows = dtbSource.Select("Day='Sun' AND Period='A'");
            FillTimeTable(subjectRows, tableToDisplay, 7, 2);
        }
        public static void FillTimeTable(DataRow[] subjectRows, Table tableToDisplay, int rowNumber, int cellNumber)
        {
            Table tbl = new Table();
            for (int i = 0; i < subjectRows.Length; i++)
            {
                String subjectName = subjectRows[i]["SubjectName"].ToString();
                String sec = subjectRows[i]["SEC"].ToString();

                TableCell cellSubjectName = new TableCell();
                cellSubjectName.Width = 335;
                cellSubjectName.HorizontalAlign = HorizontalAlign.Left;
                cellSubjectName.Text = subjectName;

                TableCell cellSEC = new TableCell();
                cellSEC.Width = 40;
                cellSEC.HorizontalAlign = HorizontalAlign.Right;
                cellSEC.Text = "SEC " + sec;

                TableRow row = new TableRow();
                row.Cells.Add(cellSubjectName);
                row.Cells.Add(cellSEC);
                row.HorizontalAlign = HorizontalAlign.Justify;

                tbl.Rows.Add(row);
            }
            
            tableToDisplay.Rows[rowNumber].Cells[cellNumber].Controls.Add(tbl);
        }
        public static DataTable LoadPollData()
        {
            DataTable dtbPollData = new DataTable();
            dtbPollData.TableName = "PollData";
            dtbPollData.Columns.Add("SubjectCode", System.Type.GetType("System.String"));
            dtbPollData.Columns.Add("SubjectName", System.Type.GetType("System.String"));
            dtbPollData.Columns.Add("SubjectGroup", System.Type.GetType("System.String"));
            dtbPollData.Columns.Add("Day", System.Type.GetType("System.String"));
            dtbPollData.Columns.Add("Period", System.Type.GetType("System.String"));
            dtbPollData.Columns.Add("Year2", System.Type.GetType("System.Int32"));
            dtbPollData.Columns.Add("Year3", System.Type.GetType("System.Int32"));
            dtbPollData.Columns.Add("Year4", System.Type.GetType("System.Int32"));
            dtbPollData.Columns.Add("Count", System.Type.GetType("System.Int32"));

            OracleConnection conn = new OracleConnection();
            conn.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            conn.Open();

            String cmdQuery = "SELECT POLL.SUB_CODE,SUBJECT.SUB_NAME,SUBJECT.SUB_GROUP," +
            "POLL.DAY,POLL.PERIOD," +
            "POLL.YEAR2,POLL.YEAR3," +
            "POLL.YEAR4 " +
            "FROM POLL,SUBJECT " +
            "WHERE POLL.SUB_CODE=SUBJECT.SUB_CODE";

            OracleCommand cmd = new OracleCommand(cmdQuery);
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;

            OracleDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                String subjectCode = reader.GetString(0);
                String subjectName = reader.GetString(1);
                String subjectGroup = reader.GetString(2);
                String day = reader.GetString(3);
                String period = reader.GetString(4);
                int year2 = reader.GetInt32(5);
                int year3 = reader.GetInt32(6);
                int year4 = reader.GetInt32(7);

                int count = year2 + year3 + year4;

                DataRow drow = dtbPollData.NewRow();
                drow["SubjectCode"] = subjectCode;
                drow["SubjectName"] = subjectName;
                drow["SubjectGroup"] = subjectGroup;
                drow["Day"] = day;
                drow["Period"] = period;
                drow["Year2"] = year2;
                drow["Year3"] = year3;
                drow["Year4"] = year4;
                drow["Count"] = count;

                dtbPollData.Rows.Add(drow);
            }

            cmd.Dispose();
            conn.Close();
            conn.Dispose();

            return dtbPollData;
        }
        public static DataTable SummaryData(DataTable dtbPollData, String filter)
        {
            // Insert table schema
            DataTable dtbSummaryData = new DataTable();
            dtbSummaryData.TableName = "SummaryData";
            dtbSummaryData.Columns.Add("SubjectCode", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("SubjectName", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("SubjectGroup", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("Day", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("Period", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("Year", System.Type.GetType("System.String"));
            dtbSummaryData.Columns.Add("Count", System.Type.GetType("System.Int32"));


            // ���͡�Ԫҷ���ӡѹ ���������� 1 row
            foreach (DataRow drowPoll in dtbPollData.Rows)
            {
                String subjectCode = drowPoll["SubjectCode"].ToString();
                String subjectName = drowPoll["SubjectName"].ToString();
                String subjectGroup = drowPoll["SubjectGroup"].ToString();

                if (!IsDuplicateSubject(subjectCode, dtbSummaryData))
                {
                    DataRow drowSummary = dtbSummaryData.NewRow();
                    drowSummary["SubjectCode"] = subjectCode;
                    drowSummary["SubjectName"] = subjectName;
                    drowSummary["SubjectGroup"] = subjectGroup;

                    dtbSummaryData.Rows.Add(drowSummary);
                }
            }

            // ���ѹ������ҷ���դ���ǵ�ҡ����ش������Ԫ�
            for (int i = 0; i < dtbSummaryData.Rows.Count; i++)
            {
                DataRow drow = dtbSummaryData.Rows[i]; // row ������������
                String subjectCode = drow["SubjectCode"].ToString();
                DataRow[] subjectRows = dtbPollData.Select("SubjectCode=" + subjectCode); // �֧������ 1 �ش�Ԫҵ�������Ԫ�

                int year2Count = 0; // �ӹǹ�����ǵ��Ԫҹ�鹷���� ��. �� 2
                int year3Count = 0; // �ӹǹ�����ǵ��Ԫҹ�鹷���� ��. �� 3
                int year4Count = 0; // �ӹǹ�����ǵ��Ԫҹ�鹷���� ��. �� 4

                int maxCount = 0; //���������ѹ������ҷ�褹��ǵ�ҡ����ش
                int voteCount = 0; // �ӹǹ�����ǵ��������Ԫҹ��

                // ��Ǩ�ͺ���� row �ͧ�ش�Ԫ�
                for (int ii = 0; ii < subjectRows.Length; ii++)
                {
                    int year2 = Convert.ToInt32(subjectRows[ii]["Year2"]);
                    year2Count += year2;

                    int year3 = Convert.ToInt32(subjectRows[ii]["Year3"]);
                    year3Count += year3;

                    int year4 = Convert.ToInt32(subjectRows[ii]["Year4"]);
                    year4Count += year4;

                    int count = Convert.ToInt32(subjectRows[ii]["Count"]);
                    voteCount += count;

                    if (count > maxCount)
                    {
                        maxCount = count;

                        String day = subjectRows[ii]["Day"].ToString();
                        String period = subjectRows[ii]["Period"].ToString();

                        dtbSummaryData.Rows[i]["Day"] = day; // ������ѹ��褹��ǵ�ҡ����ش
                        dtbSummaryData.Rows[i]["Period"] = period; // ��������ҷ�褹��ǵ�ҡ����ش
                    }
                }

                // ����һ��˹��ǵ�ҡ�ش
                int maxYear = 0;
                maxYear = Math.Max(year2Count, year3Count);
                maxYear = Math.Max(year4Count, maxYear);

                if (maxYear == year2Count) dtbSummaryData.Rows[i]["Year"] = 2;
                else if (maxYear == year3Count) dtbSummaryData.Rows[i]["Year"] = 3;
                else if (maxYear == year4Count) dtbSummaryData.Rows[i]["Year"] = 4;

                dtbSummaryData.Rows[i]["Count"] = voteCount;
            }

            if (filter == "CUT")
            {
                // �Ѵ�Ԫҷ�褹��ǵ���¡��� 15 ������˹��͡ (����Դ�͹)
                for (int i = dtbSummaryData.Rows.Count - 1; i >= 0; i--)
                {
                    if (Convert.ToInt32(dtbSummaryData.Rows[i]["Count"]) < 15)
                    {
                        dtbSummaryData.Rows[i].Delete();
                    }
                }
            }

            return dtbSummaryData;
        }
        private static bool IsDuplicateSubject(String subjectCode, DataTable dtb)
        {
            foreach (DataRow drowSelect in dtb.Rows)
            {
                if (drowSelect["SubjectCode"].ToString() == subjectCode)
                {
                    return true;
                }
            }
            return false;
        }
        public static void DisplayPollData(DataTable dtbSource, Table tableToDisplay)
        {
            DataRow[] subjectRows;

            subjectRows = dtbSource.Select("Day='Mon' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 1, 1);

            subjectRows = dtbSource.Select("Day='Mon' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 1, 2);

            subjectRows = dtbSource.Select("Day='Tue' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 2, 1);

            subjectRows = dtbSource.Select("Day='Tue' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 2, 2);

            subjectRows = dtbSource.Select("Day='Wed' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 3, 1);

            subjectRows = dtbSource.Select("Day='Wed' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 3, 2);

            subjectRows = dtbSource.Select("Day='Thu' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 4, 1);

            subjectRows = dtbSource.Select("Day='Thu' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 4, 2);

            subjectRows = dtbSource.Select("Day='Fri' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 5, 1);

            subjectRows = dtbSource.Select("Day='Fri' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 5, 2);

            subjectRows = dtbSource.Select("Day='Sat' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 6, 1);

            subjectRows = dtbSource.Select("Day='Sat' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 6, 2);

            subjectRows = dtbSource.Select("Day='Sun' AND Period='M'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 7, 1);

            subjectRows = dtbSource.Select("Day='Sun' AND Period='A'", "Count DESC");
            FillData(subjectRows, tableToDisplay, 7, 2);
        }
        public static void FillData(DataRow[] subjectRows, Table tableToDisplay, int rowNumber, int cellNumber)
        {
            Table tbl = new Table();
            for (int i = 0; i < subjectRows.Length; i++)
            {
                String subjectName = subjectRows[i]["SubjectName"].ToString();
                int count = (int)subjectRows[i]["Count"];

                TableCell cellSubjectName = new TableCell();
                cellSubjectName.Width = 350;
                cellSubjectName.HorizontalAlign = HorizontalAlign.Left;
                cellSubjectName.Text = subjectName;

                TableCell cellCount = new TableCell();
                cellCount.Width = 25;
                cellCount.HorizontalAlign = HorizontalAlign.Right;
                cellCount.Text = count.ToString();

                TableRow row = new TableRow();
                row.Cells.Add(cellSubjectName);
                row.Cells.Add(cellCount);
                row.HorizontalAlign = HorizontalAlign.Justify;

                tbl.Rows.Add(row);
            }
            tableToDisplay.Rows[rowNumber].Cells[cellNumber].Controls.Add(tbl);
        }
        public static DataTable LoadSubjectData(String subjectType)
        {
            DataTable dtbSubject = new DataTable();
            dtbSubject.TableName = subjectType;
            dtbSubject.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbSubject.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbSubject.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String query = "SELECT SUB_CODE,SUB_NAME,UNIT,T_UNIT,P_UNIT " +
                "FROM SUBJECT WHERE SUB_TYPE='" + subjectType + "'" +
                "ORDER BY SUB_CODE";

            OracleCommand command = new OracleCommand(query);
            command.Connection = connection;
            command.CommandType = CommandType.Text;

            OracleDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                DataRow drow = dtbSubject.NewRow();
                drow["�����Ԫ�"] = reader.GetString(0);
                drow["�����Ԫ�"] = reader.GetString(1);
                drow["˹��¡Ե"] = reader.GetInt32(2);

                dtbSubject.Rows.Add(drow);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return dtbSubject;
        }
        public static DataTable LoadEnrollData(String studentCode, String currentTerm, String currentYear)
        {
            DataTable dtbEnroll = new DataTable();
            dtbEnroll.TableName = "EnrollData";
            dtbEnroll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbEnroll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbEnroll.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT SUBJECT.SUB_CODE, SUBJECT.SUB_NAME, SUBJECT.UNIT" +
                " FROM ENROLL,SUBJECT" +
                " WHERE ENROLL.SUB_CODE=SUBJECT.SUB_CODE" +
                " AND SCODE=" + studentCode +
                " AND TERM=" + currentTerm +
                " AND YEAR=" + currentYear +
                " ORDER BY SUBJECT.SUB_CODE";

            OracleCommand command = new OracleCommand(commandText);
            command.CommandType = CommandType.Text;
            command.Connection = connection;

            OracleDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                DataRow drow = dtbEnroll.NewRow();
                drow["�����Ԫ�"] = reader.GetString(0);
                drow["�����Ԫ�"] = reader.GetString(1);
                drow["˹��¡Ե"] = reader.GetInt32(2);

                dtbEnroll.Rows.Add(drow);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return dtbEnroll;
        }
        public static DataTable SetEnrollData(int studentYear, int currentTerm)
        {
            DataTable dtbEnroll = new DataTable();
            dtbEnroll.TableName = "Enroll";
            dtbEnroll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbEnroll.Columns.Add("�����Ԫ�", System.Type.GetType("System.String"));
            dtbEnroll.Columns.Add("˹��¡Ե", System.Type.GetType("System.Int32"));

            ArrayList listCC = new ArrayList();

            if ((studentYear == 2) && (currentTerm == 1))
            {
                listCC.Add("05010103");
                listCC.Add("01072111");
                listCC.Add("01072112");
                listCC.Add("01072113");
                listCC.Add("01072114");
                listCC.Add("01072115");
                listCC.Add("01072116");
            }
            else if ((studentYear == 2) && (currentTerm == 2))
            {
                listCC.Add("01072117");
                listCC.Add("01072118");
                listCC.Add("01072119");
                listCC.Add("01072120");
                listCC.Add("01072121");
                listCC.Add("01072122");
            }
            else if ((studentYear == 3) && (currentTerm == 1))
            {
                listCC.Add("01072123");
                listCC.Add("01072124");
                listCC.Add("01072125");
            }
            else if ((studentYear == 3) && (currentTerm == 2))
            {
                listCC.Add("01072126");
                listCC.Add("01072127");
                listCC.Add("01072128");
                listCC.Add("01072129");
            }
            else if ((studentYear == 4) && (currentTerm == 1))
            {
                listCC.Add("01072130");
            }
            else if ((studentYear == 4) && (currentTerm == 2))
            {
                listCC.Add("01072131");
            }

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            foreach (String subjectCode in listCC)
            {
                String commandText = "SELECT SUB_CODE, SUB_NAME, UNIT" +
                    " FROM SUBJECT" +
                    " WHERE SUB_CODE='" + subjectCode + "'";

                OracleCommand command = new OracleCommand(commandText);
                command.CommandType = CommandType.Text;
                command.Connection = connection;

                OracleDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    DataRow drow = dtbEnroll.NewRow();
                    drow["�����Ԫ�"] = reader.GetString(0);
                    drow["�����Ԫ�"] = reader.GetString(1);
                    drow["˹��¡Ե"] = reader.GetInt32(2);

                    dtbEnroll.Rows.Add(drow);
                }

                command.Dispose();
            }

            connection.Close();
            connection.Dispose();

            return dtbEnroll;
        }
        public static DataTable LoadCurrentStatus()
        {
            DataTable dtbStatus = new DataTable();
            dtbStatus.TableName = "CurrentStatus";
            dtbStatus.Columns.Add("CurrentTerm", Type.GetType("System.String"));
            dtbStatus.Columns.Add("CurrentYear", Type.GetType("System.String"));
            dtbStatus.Columns.Add("EnrollStatus", Type.GetType("System.Int32"));
            dtbStatus.Columns.Add("PollStatus", Type.GetType("System.Int32"));
            dtbStatus.Columns.Add("AddStatus", Type.GetType("System.Int32"));
            dtbStatus.Columns.Add("DropStatus", Type.GetType("System.Int32"));

            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT TERM,YEAR,VAL_ENROLL,VAL_POLL,VAL_ADD,VAL_DROP FROM CURRENT_STATUS";

            OracleCommand command = new OracleCommand(commandText);
            command.Connection = connection;
            command.CommandType = CommandType.Text;

            OracleDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                DataRow drow = dtbStatus.NewRow();
                drow["CurrentTerm"] = reader.GetString(0);
                drow["CurrentYear"] = reader.GetString(1);
                drow["EnrollStatus"] = reader.GetInt32(2);
                drow["PollStatus"] = reader.GetInt32(3);
                drow["AddStatus"] = reader.GetInt32(4);
                drow["DropStatus"] = reader.GetInt32(5);

                dtbStatus.Rows.Add(drow);
            }

            command.Dispose();
            connection.Close();
            connection.Dispose();

            return dtbStatus;
        }
        public static void UpdateCurrentStatus(String term, String year)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "UPDATE CURRENT_STATUS SET TERM='" + term + "', YEAR='" + year + "'";

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();
            command.CommandText = commandText;
            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();
        }
        public static void UpdateEnrollStatus(String status)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            if (status == "ON")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_ENROLL=1";
                command.ExecuteNonQuery();

                command.CommandText = "UPDATE STUDENT SET CK_REGIS=0";
                command.ExecuteNonQuery();
            }
            else if (status == "OFF")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_ENROLL=0";
                command.ExecuteNonQuery();
            }

            transaction.Commit();
            connection.Close();
        }
        public static void UpdateAddEnrollStatus(String status)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            if (status == "ON")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_ADD=1";
            }
            else if (status == "OFF")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_ADD=0";
            }

            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();
        }
        public static void UpdateDropEnrollStatus(String status)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            if (status == "ON")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_DROP=1";
            }
            else if (status == "OFF")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_DROP=0";
            }

            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();
        }
        public static void UpdatePollStatus(String status)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            if (status == "ON")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_POLL=1";
                command.ExecuteNonQuery();

                command.CommandText = "UPDATE STUDENT SET CK_VOTE=0";
                command.ExecuteNonQuery();
            }
            else if (status == "OFF")
            {
                command.CommandText = "UPDATE CURRENT_STATUS SET VAL_POLL=0";
                command.ExecuteNonQuery();
            }

            transaction.Commit();
            connection.Close();
        }
        public static void ClearSchedule()
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            command.CommandText = "DELETE FROM TTABLE";
            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();
        }
        public static void ClearPoll()
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            OracleTransaction transaction = connection.BeginTransaction();
            OracleCommand command = connection.CreateCommand();

            command.CommandText = "DELETE FROM POLL";
            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();
        }
        public static int GetVoteStatus(String studentCode)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT CK_VOTE FROM STUDENT WHERE SCODE='" + studentCode + "'";

            OracleCommand command = new OracleCommand(commandText);
            command.CommandType = CommandType.Text;
            command.Connection = connection;

            OracleDataReader reader = command.ExecuteReader();

            int checkVote = 99;

            if (reader.Read())
            {
                checkVote = reader.GetInt32(0);
            }

            return checkVote;
        }
        public static int GetRegisStatus(String studentCode)
        {
            OracleConnection connection = new OracleConnection();
            connection.ConnectionString = WebConfigurationManager.ConnectionStrings["Oracle10g"].ConnectionString;
            connection.Open();

            String commandText = "SELECT CK_REGIS FROM STUDENT WHERE SCODE='" + studentCode + "'";

            OracleCommand command = new OracleCommand(commandText);
            command.CommandType = CommandType.Text;
            command.Connection = connection;

            OracleDataReader reader = command.ExecuteReader();

            int checkRegis = 99;

            if (reader.Read())
            {
                checkRegis = reader.GetInt32(0);
            }

            return checkRegis;
        }
        public static int CalculateSumUnit(DataTable dtb)
        {
            int sumUnit = 0;

            foreach (DataRow drow in dtb.Rows)
            {
                int unit = Convert.ToInt32(drow["˹��¡Ե"].ToString());
                sumUnit += unit;
            }

            return sumUnit;
        }
        public static String ConvertDay(String day)
        {
            String convertedDay = "";

            if(day == "�ѹ���") convertedDay = "Mon";
            else if(day == "�ѧ���") convertedDay = "Tue";
            else if(day == "�ظ") convertedDay = "Wed";
            else if(day == "����ʺ��") convertedDay = "Thu";
            else if(day == "�ء��") convertedDay = "Fri";
            else if(day == "�����") convertedDay = "Sat";
            else if (day == "�ҷԵ��") convertedDay = "Sun";

            return convertedDay;
        }
        public static String ConvertPeriod(String period)
        {
            String convertedPeriod = "";

            if (period == "09.00-12.00") convertedPeriod = "M";
            else if (period == "13.00-16.00") convertedPeriod = "A";

            return convertedPeriod;
        }
    }
}
