void run_countunit(unsigned char *data_unit)
{
	if(data_unit[8]<'9')
	{
		data_unit[8]++;
	}
	else if(data_unit[7]<'9')
	{
		data_unit[7]++;
		data_unit[8]='0';
	}
	else if((data_unit[6]<'4'&&data_unit[5]=='8')||(data_unit[6]<'9'&&data_unit[5]<'8'))
	{
		data_unit[6]++;
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[5]<'8')
	{
		data_unit[5]++;
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[4]<'9')
	{
		data_unit[4]++;
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[3]<'9')
	{
		data_unit[3]++;
		data_unit[4]='0'; 
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[2]<'9')
	{																	
		data_unit[2]++;
		data_unit[3]='0';
		data_unit[4]='0';
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[1]<'9')
	{		
		data_unit[1]++;															
		data_unit[2]='0';
		data_unit[3]='0';
		data_unit[4]='0';
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else if(data_unit[0]<'9')
	{		
		data_unit[0]++;
		data_unit[1]='0';															
		data_unit[2]='0';
		data_unit[3]='0';
		data_unit[4]='0';
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}
	else
	{
		data_unit[0]='0';
		data_unit[1]='0';															
		data_unit[2]='0';
		data_unit[3]='0';
		data_unit[4]='0';
		data_unit[5]='0';
		data_unit[6]='0';
		data_unit[7]='0';
		data_unit[8]='0';
	}	
}