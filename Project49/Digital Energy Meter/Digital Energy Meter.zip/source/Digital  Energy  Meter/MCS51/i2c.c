#define DS1307_ID	0xD0	// address DS1307
#define AT24C16_ID  0xA0    // address AT24C16
/*** Includes *****************************************************/
void i2c_init(void);
void i2c_clkH(void);
void i2c_clkL(void);
void i2c_clk(void);
void i2c_stop(void);
void i2c_start(void);
unsigned char i2c_read(void);
bit i2c_write(unsigned char output_data);
unsigned char ds1307_read(unsigned char addr);
void ds1307_write(unsigned char addr,unsigned char value);
unsigned char char_to_hex(unsigned char ascii);
unsigned char at24c16_read(unsigned char *address);


/*** Constants ****************************************************/
#define delay()	_nop_()

#define HIGH	1
#define LOW	0

sbit SDA = P1^0;		// NX-51 V2.0 Board
sbit SCL = P1^1;
unsigned char dat;		


/*** Start ** Module : I2C BUS Control ****************************/
void i2c_init(void) {

	SCL = LOW;	
	SDA = LOW;

	SCL = HIGH;	
	SDA = HIGH;			
}

void i2c_clkH(void) {

	SCL = HIGH;
	while(!SCL);
	delay();
}

void i2c_clkL(void) {

	SCL = LOW;
	delay();
}

void i2c_clk(void){

	SCL = HIGH;	
	delay();
	SCL = LOW;	
	delay();
}
	
void i2c_NACK()
{
	SDA = 1;				// Set SDA
	delay();		// Delay
	i2c_clk();			// Call for send data to i2c bus
	SCL = 1;				// Set SCL
}
// Stop Condition
void i2c_stop(void) {

	SDA = LOW;
	i2c_clkH();
	SDA = HIGH;
	delay();
}

// Start Condition
void i2c_Start(void) {
	
	SDA = HIGH;
	i2c_clkH();
	SDA = LOW;
	delay();
	i2c_clkL();
}

// Receive data from I2C BUS
unsigned char i2c_read(void) {
   unsigned char dat,i;

   dat = 0;
   for(i=0;i<8;i++) {
      dat <<= 1;
      i2c_clkH();
      if (SDA)
      	dat |= 1;
      i2c_clkL();
   }
   return dat;
}

// Send data to I2C BUS
bit i2c_write(unsigned char output_data) {
	unsigned char i;
    bit flag=0;

	for(i=0;i<8;i++) {	

		SDA = ((output_data & 0x80) ? 1 : 0);
	    output_data <<= 1;		
    	i2c_clk();
    }

    SDA = HIGH;
    i2c_clkH();

	if(SDA)
        flag = 1;

    i2c_clkL();
    return flag;
} 
/*** End ** Module : I2C BUS Control ******************************/ 