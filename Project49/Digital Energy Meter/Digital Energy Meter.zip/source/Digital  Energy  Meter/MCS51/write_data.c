void run_write(unsigned char *data_unit/*,unsigned char*date,unsigned char*time*/)
{
	unsigned char addr[3]={0x30,0x30,0x30};
	unsigned int i;
	for(i=0;i<9;i++)
	{
		at24c16_write(addr,data_unit[i]);
		add_addr(addr);
		LCD_delay(10);
	}
	/*
	for(i=0;i<6;i++)
	{
		at24c16_write(addr,date[i]);
		add_addr(addr);
		LCD_delay(10);
	}
	for(i=0;i<6;i++)
	{
		at24c16_write(addr,time[i]);
		add_addr(addr);
		LCD_delay(10);
	}	  */
}