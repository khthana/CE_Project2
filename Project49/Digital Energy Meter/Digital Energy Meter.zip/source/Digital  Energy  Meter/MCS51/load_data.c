void load_data_unit(unsigned char *data_unit)
{
	unsigned char addr_data[3]={0x30,0x30,0x30};
	unsigned int i;
	LCD_Sent_Byte(0,0xC7);
	for(i=0;i<9;i++)
	{
		data_unit[i] = at24c16_read(addr_data);
		add_addr(addr_data);
	}
} 
	/*
void load_date_time(unsigned char *date,unsigned char *time)
{
	unsigned char addr_data[3]={0x30,0x30,0x35};
	unsigned int i;
	for(i=0;i<6;i++)
	{
		date[i] = at24c16_read(addr_data);
		add_addr(addr_data);
	}
	for(i=0;i<6;i++)
	{
		time[i] = at24c16_read(addr_data);
		add_addr(addr_data);
	}
}  	 */