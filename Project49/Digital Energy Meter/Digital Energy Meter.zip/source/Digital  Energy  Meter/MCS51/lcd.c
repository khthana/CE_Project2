/*** Constants ****************************************************/
#define TRUE	1

#define LCD_DSP 	P0		// P0.0 = D0, P0.1 = D1 
							// P0.2 = D2, P0.3 = D3 
							// P0.4 = D4, P0.25= D5
							// P0.6 = D6, P0.7 = D7
							// P3.6 = E	, P3.7 = RS

//#define LCD_ADDR	0x30	// LCD Address
//#define LCD_ADD_1 	0x00;	// 0x00-0x0F 1st line
//#define LCD_ADD_2  	0x40;	// 0x40-0x4F 2nd line	

sbit LCD_EN = P3^6;			// LCD Module Enable (Active High)
sbit LCD_RS = P3^7;			// LCD Module Regidter Select


/*** Global variables *********************************************/
code unsigned char *msg[1] = {"Energy Meter"};


/*** Functions prototypes *****************************************/
void LCD_delay(int n);
void LCD_PUSLE_CLOCK(void);
//void LCD_ShiftLeft(void);
//void LCD_ShiftRight(void);
//void LCD_String(unsigned char *buf,int dly,unsigned char LR);
//void LCD_Show(void);
void LCD_Sent_Byte(bit cm, int n);
void LCD_Init(void);



/*** Functions ****************************************************/
// Function	  :	Delay
// Parameters : n - integer
// Returned   : nothing
// LCD Command +++++++++++++++++++++++++
// LCD Clear 						0x01
// cursor to home					0x02
// display move cursor to left		0x04
// move to right					0x05
// display move cursor to right		0x06
// move to left						0x07
// LCD Off & cursor off				0x08
// LCD Off & cursor on				0x0A
// LCD On, & cursor	off				0x0C
// LCD On, & cursor	on				0x0E
// LCD On, & cursor	blink			0x0F
// move cursor to left				0x10
// move cursor to right				0x14
// move new character to left		0x18
// move new character to right		0x1C
// LCD start 1st line       		0x80
// LCD start 2nd line       		0xC0
// LCD 2nd line       				0x38
// +++++++++++++++++++++++++++++++++++++

/*** Start ** Module : LCD Control ********************************/ 
// Function	  :	Delay
// Parameters : n - integer
// Returned   : nothing	

void LCD_delay(int n) {
	int i,j;
	for(i=0; i<n; i++)
	for(j=0; j<100; j++)	// P89C51RD2	
	  ;
} 

void LCD_PUSLE_CLOCK(void) {

	LCD_EN = 1;
	LCD_delay(1);	
	LCD_EN = 0;
	LCD_delay(1);	   
} 


void LCD_Sent_Byte(bit cm, int n) {

	LCD_RS = cm;		// cm=0 send command, cm=1 send data
	LCD_DSP = n;
	LCD_PUSLE_CLOCK();
}

void LCD_ShiftLeft(void) {

	LCD_Sent_Byte(0,0x18);
}

void LCD_ShiftRight(void) {

	LCD_Sent_Byte(0,0x1C);
} 	

void LCD_String(unsigned char *buf,int dly,unsigned char LR) {
	unsigned int len,i;

	len = strlen (buf);
	for(i=0; i<len; i++) { 
		if(LR == 1) { LCD_ShiftLeft(); }
		if(LR == 2) { LCD_ShiftRight();}
		LCD_Sent_Byte(1,buf[i]);
		LCD_delay(dly);
	}
}	

/*** End ** Module : LCD Control **********************************/
// Function	  :	Init LCD
// Parameters : nothing
// Returned   : nothing
void LCD_Init(void) {

	LCD_Sent_Byte(0,0x38);		// Two line size char 5x7 dot
	LCD_Sent_Byte(0,0x0E);		// Display & cursor
	LCD_Sent_Byte(0,0x01);		// Clear LCD
	LCD_Sent_Byte(0,0x06);		// move cursor to right
	LCD_Sent_Byte(0,0x0C);		// LCD On, & cursor	off
}

// Function	  :	LCD Show message
// Parameters : nothing
// Returned   : nothing
void LCD_Data_unit(unsigned char *data_unit)
{
	LCD_Sent_Byte(0,0x82);	 
	LCD_String(msg[0],1,0);
	LCD_Sent_Byte(0,0xC3);	 
	LCD_Sent_Byte(1,data_unit[0]);
	LCD_Sent_Byte(1,data_unit[1]);
	LCD_Sent_Byte(1,data_unit[2]);
	LCD_Sent_Byte(1,data_unit[3]);
	LCD_Sent_Byte(1,'.');
	LCD_Sent_Byte(1,data_unit[4]);
	LCD_Sent_Byte(1,data_unit[5]);
	LCD_Sent_Byte(1,data_unit[6]);
	LCD_Sent_Byte(1,data_unit[7]);
	LCD_Sent_Byte(1,data_unit[8]);
}	  