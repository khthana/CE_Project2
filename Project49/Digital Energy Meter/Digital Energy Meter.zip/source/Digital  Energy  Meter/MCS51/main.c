#include <reg51.h>		
#include <stdio.h>		
#include <intrins.h>	
#include <string.h>		
#include <absacc.h>		
#include "lcd.c"
#include "convert.c"
#include "serial.c"
#include "i2c.c"
#include "addr.c"
#include "at24c16.c"
//#include "ds1307.c"
#include "interrupt.c"
#include "load_data.c"
#include "count_unit.c"
#include "write_data.c"
unsigned char data_unit[9];
//unsigned char date[6];
//unsigned char time[6];
bit hook=0;
sbit power=P1^5;   
bit light=0;
unsigned char value;
/*** Main Functions ***********************************************/
void main(void){
	LCD_Init();
	init_serial();
	i2c_init();
	int0_init();
	load_data_unit(data_unit);
	//load_date_time(date,time);
	LCD_Data_unit(data_unit);
	while(1)
	{
	/*
		LCD_Sent_Byte(0,0xC8);	
		value=ds1307_read(0x02);
		time[0]=value&0xF0;
		time[0]=(time[0]>>4)|(0x30);
		LCD_Sent_Byte(1,time[0]);
		time[1]=value&0x0F;
		time[1]=time[1]|0x30;
		LCD_Sent_Byte(1,time[1]);
		LCD_Sent_Byte(1,':');	
		value=ds1307_read(0x01);
		time[2]=value&0xF0;
		time[2]=(time[2]>>4)|(0x30);
		LCD_Sent_Byte(1,time[2]);
		time[3]=value&0x0F;
		time[3]=time[3]|0x30;
		LCD_Sent_Byte(1,time[3]);
		LCD_Sent_Byte(1,':');	
		value=ds1307_read(0x00);
		time[4]=value&0xF0;
		time[4]=(time[4]>>4)|(0x30);
		LCD_Sent_Byte(1,time[4]);
		time[5]=value&0x0F;
		time[5]=time[5]|0x30;
		LCD_Sent_Byte(1,time[5]);  */
		if(power==1&&light==0)
		{
			printf("%c%c%c%c.%c\n",data_unit[0],data_unit[1],data_unit[2],data_unit[3],data_unit[4]);	
			light=1;
		}
		else if(power==0&&light==1)
		{
			run_write(data_unit);
			light=0;
		}
		if(hook==1)
		{
			run_countunit(data_unit);
			LCD_Data_unit(data_unit);
			printf("%c%c%c%c.%c\n",data_unit[0],data_unit[1],data_unit[2],data_unit[3],data_unit[4],data_unit[5]);
			hook=0;
		}  
	}
}
void int0_isr() interrupt 0 using 1
{
	hook=1;	
}