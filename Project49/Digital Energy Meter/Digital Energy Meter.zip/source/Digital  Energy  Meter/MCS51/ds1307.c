// Read data from DS1307
unsigned char ds1307_read(unsigned char addr) {
	unsigned char ret;
    i2c_start();
	i2c_write(DS1307_ID); 		// Addressing + R/W = 0
	i2c_write(addr);	  		// Control byte
    i2c_start();
	i2c_write(DS1307_ID+1);	// Send Address and R/W = 1
    ret = i2c_read(); 		// receive data

    SDA = HIGH;
    i2c_clk();
    i2c_stop();
    return ret;
}