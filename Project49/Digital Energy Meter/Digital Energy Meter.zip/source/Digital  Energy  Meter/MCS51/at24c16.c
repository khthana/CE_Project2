bit err = 0;						// Clear status bit flag Error
unsigned char at24c16_read(unsigned char *address)		 
{
	unsigned char dat = 0;				// For keep return value from read in EEPROM 
	unsigned char addr_h,addr_l,addr_l2;// For keep between convert address
	/*�������������Convert address from serial port ������*/
	addr_h = char_to_hex(address[0]);		// Convert address byte 1 from ascii to hex 
	addr_h = addr_h<<1;					// Shift bit Left 1 time
	addr_h = AT24C16_ID | addr_h;		// OR byte 1 with AT24C16 ID 
										// for send address byte 1
	addr_l = char_to_hex(address[1]);		// Convert address byte 2 from ascii to hex 
 	addr_l = addr_l<<4;					// Shift bit Left 4 time 
	addr_l2 = char_to_hex(address[2]);	// Convert address byte 3 from ascii to hex
	addr_l = addr_l | addr_l2;			// OR address byte 2 with byte 3

	i2c_start();				// i2c start condition 
	if(i2c_write(addr_h))		// Write AT24c16 ID with address byte 1 for connect
	{
		i2c_stop();				// If connect error stop
		err = 1;                // Set bit flag for Alarm by Post text
	}
	i2c_write(addr_l);			// Write address low byte 
	i2c_start();				// i2c start condition  
	i2c_write(addr_h+1);      	// Write AT24C16 ID for Read Mode connect	
	dat = i2c_read();			// Read data and keep to dat
	i2c_NACK();					// Send signal for stop read
	i2c_stop();               	// i2c stop condition 
	return(dat);				// return value 
}

void at24c16_write(unsigned char *address,unsigned char dat)			
{
	unsigned char addr_h,addr_l,addr_l2;	// For keep between convert address
	err = 0;											// Clear status bit flag Error
	//�������������Convert address from serial port ������//
	addr_h = char_to_hex(address[0]);		// Convert address byte 1 from ascii to hex 
	addr_h = addr_h<<1;					// Shift bit Left 1 time
	addr_h = AT24C16_ID | addr_h;		// OR byte 1 with AT24C16 ID 
												// for send address byte 1
	addr_l = char_to_hex(address[1]);		// Convert address byte 2 from ascii to hex 
 	addr_l = addr_l<<4;					// Shift bit Left 4 time 
	addr_l2 = char_to_hex(address[2]);		// Convert address byte 3 from ascii to hex
	addr_l = addr_l | addr_l2;			// OR address byte 2 with byte 3

	i2c_start();               						// i2c start condition 
	if(i2c_write(addr_h))		// Write AT24c16 ID with address byte 1 for connect
	{
		i2c_stop();					// If connect error stop
		err = 1;          						// Set bit flag for Alarm by Post text
	}
	i2c_write(addr_l);			// Write address low byte 
	i2c_write(dat);				// Write data in EEPROM
	i2c_stop();						// i2c stop condition
}	  
