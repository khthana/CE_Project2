void int0_init(void)
{
	IT0 = 1;
	EX0 = 1;
	EA  = 1;
}