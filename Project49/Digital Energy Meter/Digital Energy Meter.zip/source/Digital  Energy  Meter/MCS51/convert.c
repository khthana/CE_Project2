unsigned char char_to_hex(unsigned char ascii)  
{
	unsigned char ret;				
	switch(ascii)							
	{
		case	'0' :	ret = 0x00;   		 
						break;			
		case	'1' :	ret = 0x01;	
						break;		
		case	'2' :	ret = 0x02;		
						break;			
		case	'3' :	ret = 0x03;		
						break;       	
		case	'4' :	ret = 0x04;	
						break;         
		case	'5' :	ret = 0x05;		
						break;		
		case	'6' :	ret = 0x06;		
						break;			
		case	'7' :	ret = 0x07;		
						break;			
		case	'8' :	ret = 0x08;		
						break;		
		case	'9' :	ret = 0x09;	
						break; 			
		case	'A' :	ret = 0x0A;		
						break;			
		case	'B' :	ret = 0x0B;		
						break;			
		case	'C' :	ret = 0x0C;		
						break;			
		case	'D' :	ret = 0x0D;		
						break;			
		case	'E' :	ret = 0x0E;		
						break;			
		case	'F' :	ret = 0x0F;		
						break;			
	}
	return(ret);								
}