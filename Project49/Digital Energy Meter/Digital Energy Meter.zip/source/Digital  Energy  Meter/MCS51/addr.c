void add_addr(unsigned char *addr_temp);
void sub_addr(unsigned char *addr_temp);
void read_eep_init(unsigned char *addr);
void mov_addr(unsigned char *a,unsigned char *b);

void add_addr(unsigned char *addr_temp)
{
	if(addr_temp[2]<'F')
	{
		if(addr_temp[2]=='9')
			addr_temp[2]='A';				
		else
			addr_temp[2]++;
	}
	else if(addr_temp[1<'F'])
	{
		if(addr_temp[1]=='9')
			addr_temp[1]='A';																	
		else
			addr_temp[1]++;
			addr_temp[2]='0'; 
	}
	else
	{
		if(addr_temp[0]=='A')
			addr_temp[0]='9';																	
		else
			addr_temp[0]++;
			addr_temp[1]='0';
			addr_temp[2]='0';
	}
}