namespace energyApplication
{
    partial class Config_IP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IP_address = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.enable_check = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.IP_D = new System.Windows.Forms.TextBox();
            this.IP_C = new System.Windows.Forms.TextBox();
            this.IP_B = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.IP_A = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.IP_status = new System.Windows.Forms.Label();
            this.Portname = new System.Windows.Forms.Label();
            this.port = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // IP_address
            // 
            this.IP_address.AutoSize = true;
            this.IP_address.BackColor = System.Drawing.SystemColors.Control;
            this.IP_address.Enabled = false;
            this.IP_address.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IP_address.Location = new System.Drawing.Point(6, 39);
            this.IP_address.Name = "IP_address";
            this.IP_address.Size = new System.Drawing.Size(58, 13);
            this.IP_address.TabIndex = 0;
            this.IP_address.Text = "IP Address";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.port);
            this.groupBox1.Controls.Add(this.Portname);
            this.groupBox1.Controls.Add(this.enable_check);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.IP_D);
            this.groupBox1.Controls.Add(this.IP_C);
            this.groupBox1.Controls.Add(this.IP_B);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.IP_A);
            this.groupBox1.Controls.Add(this.IP_address);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(279, 142);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "��˹��;��ʹ���";
            // 
            // enable_check
            // 
            this.enable_check.AutoSize = true;
            this.enable_check.Location = new System.Drawing.Point(6, 19);
            this.enable_check.Name = "enable_check";
            this.enable_check.Size = new System.Drawing.Size(59, 17);
            this.enable_check.TabIndex = 9;
            this.enable_check.Text = "Enable";
            this.enable_check.UseVisualStyleBackColor = true;
            this.enable_check.CheckedChanged += new System.EventHandler(this.enable_check_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(107, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(194, 113);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "cancal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // IP_D
            // 
            this.IP_D.Enabled = false;
            this.IP_D.Location = new System.Drawing.Point(239, 36);
            this.IP_D.Name = "IP_D";
            this.IP_D.Size = new System.Drawing.Size(30, 20);
            this.IP_D.TabIndex = 8;
            this.IP_D.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IP_C
            // 
            this.IP_C.Enabled = false;
            this.IP_C.Location = new System.Drawing.Point(188, 36);
            this.IP_C.Name = "IP_C";
            this.IP_C.Size = new System.Drawing.Size(30, 20);
            this.IP_C.TabIndex = 7;
            this.IP_C.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IP_B
            // 
            this.IP_B.Enabled = false;
            this.IP_B.Location = new System.Drawing.Point(128, 36);
            this.IP_B.Name = "IP_B";
            this.IP_B.Size = new System.Drawing.Size(30, 20);
            this.IP_B.TabIndex = 6;
            this.IP_B.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label4.Location = new System.Drawing.Point(224, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = ".";
            // 
            // IP_A
            // 
            this.IP_A.Enabled = false;
            this.IP_A.Location = new System.Drawing.Point(70, 36);
            this.IP_A.Name = "IP_A";
            this.IP_A.Size = new System.Drawing.Size(30, 20);
            this.IP_A.TabIndex = 2;
            this.IP_A.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(106, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = ".";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(164, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = ".";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "status";
            // 
            // IP_status
            // 
            this.IP_status.AutoSize = true;
            this.IP_status.Location = new System.Drawing.Point(50, 157);
            this.IP_status.Name = "IP_status";
            this.IP_status.Size = new System.Drawing.Size(35, 13);
            this.IP_status.TabIndex = 4;
            this.IP_status.Text = "label5";
            // 
            // Portname
            // 
            this.Portname.AutoSize = true;
            this.Portname.Location = new System.Drawing.Point(6, 74);
            this.Portname.Name = "Portname";
            this.Portname.Size = new System.Drawing.Size(26, 13);
            this.Portname.TabIndex = 10;
            this.Portname.Text = "Port";
            // 
            // port
            // 
            this.port.Enabled = false;
            this.port.Location = new System.Drawing.Point(70, 71);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(54, 20);
            this.port.TabIndex = 11;
            // 
            // Config_IP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 179);
            this.Controls.Add(this.IP_status);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Config_IP";
            this.Text = "Configuration_IP";
            this.Load += new System.EventHandler(this.Config_IP_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label IP_address;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox IP_A;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IP_D;
        private System.Windows.Forms.TextBox IP_C;
        private System.Windows.Forms.TextBox IP_B;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private string room_number;
        private System.Windows.Forms.CheckBox enable_check;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label IP_status;
        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.Label Portname;
    }
}