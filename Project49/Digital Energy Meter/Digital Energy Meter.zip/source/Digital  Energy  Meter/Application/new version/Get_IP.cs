using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace energyApplication
{
    public partial class Get_IP : Form
    {
        public Get_IP()
        {
            InitializeComponent();         
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Get_IP_Load(object sender, EventArgs e)
        {
            string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=�;ѡ.mdb";
            OleDbConnection Conn = new OleDbConnection();
            OleDbDataAdapter daRoom;
            DataSet ds = new DataSet();
            Display dis = new Display();
            string sqlRoom = "SELECT * FROM ��ͧ���";
            try
            {
                Conn.ConnectionString = strConn;
                if (Conn.State == ConnectionState.Open)
                {
                    Conn.Close();
                }
                Conn.Open();
                daRoom = new OleDbDataAdapter(sqlRoom, Conn);
                daRoom.Fill(ds, "��ͧ���");

                DataViewManager dvm401 = new DataViewManager();
                dvm401.DataSet = ds;
                DataViewSetting dvs401;
                dvs401 = dvm401.DataViewSettings["��ͧ���"];
                dvs401.RowFilter = "��ͧ='401'";
                GetIPA401.DataBindings.Add("Text", dvm401, "��ͧ���.IP_A");
                GetIPB401.DataBindings.Add("Text", dvm401, "��ͧ���.IP_B");
                GetIPC401.DataBindings.Add("Text", dvm401, "��ͧ���.IP_C");
                GetIPD401.DataBindings.Add("Text", dvm401, "��ͧ���.IP_D");
                GETport401.DataBindings.Add("Text", dvm401, "��ͧ���.port");
                GetStatus401.DataBindings.Add("Text", dvm401, "��ͧ���.ʶҹ�");
                PORT401 = GETport401.Text;
                IP401 = GetIPA401.Text + "." + GetIPB401.Text + "." + GetIPC401.Text + "." + GetIPD401.Text;
                STATUS401 = GetStatus401.Text;

                DataViewManager dvm402 = new DataViewManager();
                dvm402.DataSet = ds;
                DataViewSetting dvs402;
                dvs402 = dvm402.DataViewSettings["��ͧ���"];
                dvs402.RowFilter = "��ͧ='402'";
                GetIPA402.DataBindings.Add("Text", dvm402, "��ͧ���.IP_A");
                GetIPB402.DataBindings.Add("Text", dvm402, "��ͧ���.IP_B");
                GetIPC402.DataBindings.Add("Text", dvm402, "��ͧ���.IP_C");
                GetIPD402.DataBindings.Add("Text", dvm402, "��ͧ���.IP_D");
                GETport402.DataBindings.Add("Text", dvm402, "��ͧ���.port");
                GetStatus402.DataBindings.Add("Text", dvm402, "��ͧ���.ʶҹ�");
                PORT402 = GETport402.Text;
                IP402 = GetIPA402.Text + "." + GetIPB402.Text + "." + GetIPC402.Text + "." + GetIPD402.Text;
                STATUS402 = GetStatus402.Text;

                DataViewManager dvm403 = new DataViewManager();
                dvm403.DataSet = ds;
                DataViewSetting dvs403;
                dvs403 = dvm403.DataViewSettings["��ͧ���"];
                dvs403.RowFilter = "��ͧ='403'";
                GetIPA403.DataBindings.Add("Text", dvm403, "��ͧ���.IP_A");
                GetIPB403.DataBindings.Add("Text", dvm403, "��ͧ���.IP_B");
                GetIPC403.DataBindings.Add("Text", dvm403, "��ͧ���.IP_C");
                GetIPD403.DataBindings.Add("Text", dvm403, "��ͧ���.IP_D");
                GETport403.DataBindings.Add("Text", dvm403, "��ͧ���.port");
                GetStatus403.DataBindings.Add("Text", dvm403, "��ͧ���.ʶҹ�");
                PORT403 = GETport403.Text;
                IP403 = GetIPA403.Text + "." + GetIPB403.Text + "." + GetIPC403.Text + "." + GetIPD403.Text;
                STATUS403 = GetStatus403.Text;

                DataViewManager dvm301 = new DataViewManager();
                dvm301.DataSet = ds;
                DataViewSetting dvs301;
                dvs301 = dvm301.DataViewSettings["��ͧ���"];
                dvs301.RowFilter = "��ͧ='301'";
                GetIPA301.DataBindings.Add("Text", dvm301, "��ͧ���.IP_A");
                GetIPB301.DataBindings.Add("Text", dvm301, "��ͧ���.IP_B");
                GetIPC301.DataBindings.Add("Text", dvm301, "��ͧ���.IP_C");
                GetIPD301.DataBindings.Add("Text", dvm301, "��ͧ���.IP_D");
                GETport301.DataBindings.Add("Text", dvm301, "��ͧ���.port");
                GetStatus301.DataBindings.Add("Text", dvm301, "��ͧ���.ʶҹ�");
                PORT301 = GETport301.Text;
                IP301 = GetIPA301.Text + "." + GetIPB301.Text + "." + GetIPC301.Text + "." + GetIPD301.Text;
                STATUS301 = GetStatus301.Text;

                DataViewManager dvm302 = new DataViewManager();
                dvm302.DataSet = ds;
                DataViewSetting dvs302;
                dvs302 = dvm302.DataViewSettings["��ͧ���"];
                dvs302.RowFilter = "��ͧ='302'";
                GetIPA302.DataBindings.Add("Text", dvm302, "��ͧ���.IP_A");
                GetIPB302.DataBindings.Add("Text", dvm302, "��ͧ���.IP_B");
                GetIPC302.DataBindings.Add("Text", dvm302, "��ͧ���.IP_C");
                GetIPD302.DataBindings.Add("Text", dvm302, "��ͧ���.IP_D");
                GETport302.DataBindings.Add("Text", dvm302, "��ͧ���.port");
                GetStatus302.DataBindings.Add("Text", dvm302, "��ͧ���.ʶҹ�");
                PORT302 = GETport302.Text;
                IP302 = GetIPA302.Text + "." + GetIPB302.Text + "." + GetIPC302.Text + "." + GetIPD302.Text;
                STATUS302 = GetStatus302.Text;

                DataViewManager dvm303 = new DataViewManager();
                dvm303.DataSet = ds;
                DataViewSetting dvs303;
                dvs303 = dvm303.DataViewSettings["��ͧ���"];
                dvs303.RowFilter = "��ͧ='303'";
                GetIPA303.DataBindings.Add("Text", dvm303, "��ͧ���.IP_A");
                GetIPB303.DataBindings.Add("Text", dvm303, "��ͧ���.IP_B");
                GetIPC303.DataBindings.Add("Text", dvm303, "��ͧ���.IP_C");
                GetIPD303.DataBindings.Add("Text", dvm303, "��ͧ���.IP_D");
                GETport303.DataBindings.Add("Text", dvm303, "��ͧ���.port");
                GetStatus303.DataBindings.Add("Text", dvm303, "��ͧ���.ʶҹ�");
                PORT303 = GETport303.Text;
                IP303 = GetIPA303.Text + "." + GetIPB303.Text + "." + GetIPC303.Text + "." + GetIPD303.Text;
                STATUS303 = GetStatus303.Text;

                DataViewManager dvm201 = new DataViewManager();
                dvm201.DataSet = ds;
                DataViewSetting dvs201;
                dvs201 = dvm201.DataViewSettings["��ͧ���"];
                dvs201.RowFilter = "��ͧ='201'";
                GetIPA201.DataBindings.Add("Text", dvm201, "��ͧ���.IP_A");
                GetIPB201.DataBindings.Add("Text", dvm201, "��ͧ���.IP_B");
                GetIPC201.DataBindings.Add("Text", dvm201, "��ͧ���.IP_C");
                GetIPD201.DataBindings.Add("Text", dvm201, "��ͧ���.IP_D");
                GETport201.DataBindings.Add("Text", dvm201, "��ͧ���.port");
                GetStatus201.DataBindings.Add("Text", dvm201, "��ͧ���.ʶҹ�");
                PORT201 = GETport201.Text;
                IP201 = GetIPA201.Text + "." + GetIPB201.Text + "." + GetIPC201.Text + "." + GetIPD201.Text;
                STATUS201 = GetStatus201.Text;

                DataViewManager dvm202 = new DataViewManager();
                dvm202.DataSet = ds;
                DataViewSetting dvs202;
                dvs202 = dvm202.DataViewSettings["��ͧ���"];
                dvs202.RowFilter = "��ͧ='202'";
                GetIPA202.DataBindings.Add("Text", dvm202, "��ͧ���.IP_A");
                GetIPB202.DataBindings.Add("Text", dvm202, "��ͧ���.IP_B");
                GetIPC202.DataBindings.Add("Text", dvm202, "��ͧ���.IP_C");
                GetIPD202.DataBindings.Add("Text", dvm202, "��ͧ���.IP_D");
                GETport202.DataBindings.Add("Text", dvm202, "��ͧ���.port");
                GetStatus202.DataBindings.Add("Text", dvm202, "��ͧ���.ʶҹ�");
                PORT202 = GETport202.Text;
                IP202 = GetIPA202.Text + "." + GetIPB202.Text + "." + GetIPC202.Text + "." + GetIPD202.Text;
                STATUS202 = GetStatus202.Text;

                DataViewManager dvm203 = new DataViewManager();
                dvm203.DataSet = ds;
                DataViewSetting dvs203;
                dvs203 = dvm203.DataViewSettings["��ͧ���"];
                dvs203.RowFilter = "��ͧ='203'";
                GetIPA203.DataBindings.Add("Text", dvm203, "��ͧ���.IP_A");
                GetIPB203.DataBindings.Add("Text", dvm203, "��ͧ���.IP_B");
                GetIPC203.DataBindings.Add("Text", dvm203, "��ͧ���.IP_C");
                GetIPD203.DataBindings.Add("Text", dvm203, "��ͧ���.IP_D");
                GETport203.DataBindings.Add("Text", dvm203, "��ͧ���.port");
                GetStatus203.DataBindings.Add("Text", dvm203, "��ͧ���.ʶҹ�");
                PORT203 = GETport203.Text;
                IP203 = GetIPA203.Text + "." + GetIPB203.Text + "." + GetIPC203.Text + "." + GetIPD203.Text;
                STATUS203 = GetStatus203.Text;
                
            }
            catch (Exception errToAccess)
            {
                MessageBox.Show("�������ö��ҹ�������� ���ͧ�ҡ " + errToAccess.Message, "��ͼԴ��ҴGet_IP");
            }
            finally
            {
                Conn.Close();
            }
        }
    }
}