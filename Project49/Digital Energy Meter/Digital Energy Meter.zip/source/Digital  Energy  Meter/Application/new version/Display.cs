using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace energyApplication
{
    public partial class Display : Form
    {
        delegate void SetTextCallback(string text);
        private string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=�;ѡ.mdb";
        private OleDbConnection Conn = new OleDbConnection();
        private DataSet ds = new DataSet();
        public Display()
        {
            InitializeComponent();
        }
        private void Room401_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room401 = new Room_detail("401");
            Room401.ShowDialog();
        }

        private void Room402_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room402 = new Room_detail("402");
            Room402.ShowDialog();
        }

        private void Room403_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room403 = new Room_detail("403");
            Room403.ShowDialog();
        }

        private void Room301_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room301 = new Room_detail("301");
            Room301.ShowDialog();
        }

        private void Room302_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room302 = new Room_detail("302");
            Room302.ShowDialog();
        }

        private void Room303_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room303 = new Room_detail("303");
            Room303.ShowDialog();
        }

        private void Room201_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room201 = new Room_detail("201");
            Room201.ShowDialog();
        }

        private void Room202_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room202 = new Room_detail("202");
            Room202.ShowDialog();
        }

        private void Room203_detail_Click(object sender, EventArgs e)
        {
            Room_detail Room203 = new Room_detail("203");
            Room203.ShowDialog();
        }

        private void Room401_config_Click(object sender, EventArgs e)
        {
            Config_IP Room401 = new Config_IP("401");
            Room401.ShowDialog();
        }

        private void Room402_cofig_Click(object sender, EventArgs e)
        {
            Config_IP Room402 = new Config_IP("402");
            Room402.ShowDialog();
        }

        private void Room403_config_Click(object sender, EventArgs e)
        {
            Config_IP Room403 = new Config_IP("403");
            Room403.ShowDialog();
        }

        private void Room301_config_Click(object sender, EventArgs e)
        {
            Config_IP Room301 = new Config_IP("301");
            Room301.ShowDialog();
        }

        private void Room302_config_Click(object sender, EventArgs e)
        {
            Config_IP Room302 = new Config_IP("302");
            Room302.ShowDialog();
        }

        private void Room303_config_Click(object sender, EventArgs e)
        {
            Config_IP Room303 = new Config_IP("303");
            Room303.ShowDialog();
        }

        private void Room201_config_Click(object sender, EventArgs e)
        {
            Config_IP Room201 = new Config_IP("201");
            Room201.ShowDialog();
        }

        private void Room202_config_Click(object sender, EventArgs e)
        {
            Config_IP Room202 = new Config_IP("202");
            Room202.ShowDialog();
        }

        private void Room203_config_Click(object sender, EventArgs e)
        {
            Config_IP Room203 = new Config_IP("203");
            Room203.ShowDialog();
        }
        private void Run_energy_Click(object sender, EventArgs e)
        {
            Get_IP getip = new Get_IP();

            Run_energy.Enabled = false;
            Stop_energy.Enabled = true;

            Room401_config.Enabled = false;
            Room402_config.Enabled = false;
            Room403_config.Enabled = false;
            Room301_config.Enabled = false;
            Room302_config.Enabled = false;
            Room303_config.Enabled = false;
            Room201_config.Enabled = false;
            Room202_config.Enabled = false;
            Room203_config.Enabled = false;

            Room401_detail.Enabled = false;
            Room402_detail.Enabled = false;
            Room403_detail.Enabled = false;
            Room301_detail.Enabled = false;
            Room302_detail.Enabled = false;
            Room303_detail.Enabled = false;
            Room201_detail.Enabled = false;
            Room202_detail.Enabled = false;
            Room203_detail.Enabled = false;

            getip.ShowDialog();

            if (getip.STATUS401 == "Connecting")
            {
                Room401_status.Text = "Active";
                Room401_connect.Text = getip.STATUS401;
                IP401 = getip.IP401;
                Room401_status.ForeColor = Color.Green;
                port401 = Convert.ToInt32(getip.PORT401);
                loop_401 = true;
                Thread nTH401 = new Thread(new ThreadStart(recv_room401));
                nTH401.Start();
            }
            else
            {
                Room401_status.Text = "Inactive";
                Room401_connect.Text = getip.STATUS401;
                Room401_status.ForeColor = Color.Red;
            }
            if (getip.STATUS402 == "Connecting")
            {
                Room402_status.Text = "Active";
                Room402_connect.Text = getip.STATUS402;
                IP402 = getip.IP402;
                Room402_status.ForeColor = Color.Green;
                port402 = Convert.ToInt32(getip.PORT402);
                loop_402 = true;
                Thread nTH402 = new Thread(new ThreadStart(recv_room402));
                nTH402.Start();
            }
            else
            {
                Room402_status.Text = "Inactive";
                Room402_connect.Text = getip.STATUS402;
                Room402_status.ForeColor = Color.Red;
            }
            if (getip.STATUS403 == "Connecting")
            {
                Room403_status.Text = "Active";
                Room403_connect.Text = getip.STATUS403;
                IP403 = getip.IP403;
                Room403_status.ForeColor = Color.Green;
                port403 = Convert.ToInt32(getip.PORT403);
                loop_403 = true;
                Thread nTH403 = new Thread(new ThreadStart(recv_room403));
                nTH403.Start();
            }
            else
            {
                Room403_status.Text = "Inactive";
                Room403_connect.Text = getip.STATUS403;
                Room403_status.ForeColor = Color.Red;
            }
            if (getip.STATUS301 == "Connecting")
            {
                Room301_status.Text = "Active";
                Room301_connect.Text = getip.STATUS301;
                IP301 = getip.IP301;
                Room301_status.ForeColor = Color.Green;
                port301 = Convert.ToInt32(getip.PORT301);
                loop_301 = true;
                Thread nTH301 = new Thread(new ThreadStart(recv_room301));
                nTH301.Start();
            }
            else
            {
                Room301_status.Text = "Inactive";
                Room301_connect.Text = getip.STATUS301;
                Room301_status.ForeColor = Color.Red;
            }
            if (getip.STATUS302 == "Connecting")
            {
                Room302_status.Text = "Active";
                Room302_connect.Text = getip.STATUS302;
                IP302 = getip.IP302;
                Room302_status.ForeColor = Color.Green;
                port302 = Convert.ToInt32(getip.PORT302);
                loop_302 = true;
                Thread nTH302 = new Thread(new ThreadStart(recv_room302));
                nTH302.Start();
            }
            else
            {
                Room302_status.Text = "Inactive";
                Room302_connect.Text = getip.STATUS302;
                Room302_status.ForeColor = Color.Red;
            }
            if (getip.STATUS303 == "Connecting")
            {
                Room303_status.Text = "Active";
                Room303_connect.Text = getip.STATUS303;
                IP303 = getip.IP303;
                Room303_status.ForeColor = Color.Green;
                port303 = Convert.ToInt32(getip.PORT303);
                loop_303 = true;
                Thread nTH303 = new Thread(new ThreadStart(recv_room303));
                nTH303.Start();
            }
            else
            {
                Room303_status.Text = "Inactive";
                Room303_connect.Text = getip.STATUS303;
                Room303_status.ForeColor = Color.Red;
            }
            if (getip.STATUS201 == "Connecting")
            {
                Room201_status.Text = "Active";
                Room201_connect.Text = getip.STATUS201;
                IP201 = getip.IP201;
                Room201_status.ForeColor = Color.Green;
                port201 = Convert.ToInt32(getip.PORT201);
                loop_201 = true;
                Thread nTH201 = new Thread(new ThreadStart(recv_room201));
                nTH201.Start();
            }
            else
            {
                Room201_status.Text = "Inactive";
                Room201_connect.Text = getip.STATUS201;
                Room201_status.ForeColor = Color.Red;
            }
            if (getip.STATUS202 == "Connecting")
            {
                Room202_status.Text = "Active";
                Room202_connect.Text = getip.STATUS202;
                IP202 = getip.IP202;
                Room202_status.ForeColor = Color.Green;
                port202 = Convert.ToInt32(getip.PORT202);
                loop_202 = true;
                Thread nTH202 = new Thread(new ThreadStart(recv_room202));
                nTH202.Start();
            }
            else
            {
                Room202_status.Text = "Inactive";
                Room202_connect.Text = getip.STATUS202;
                Room202_status.ForeColor = Color.Red;
            }
            if (getip.STATUS203 == "Connecting")
            {
                Room203_status.Text = "Active";
                Room203_connect.Text = getip.STATUS203;
                IP203 = getip.IP203;
                Room203_status.ForeColor = Color.Green;
                port203 = Convert.ToInt32(getip.PORT203);
                loop_203 = true;
                Thread nTH203 = new Thread(new ThreadStart(recv_room203));
                nTH203.Start();
            }
            else
            {
                Room203_status.Text = "Inactive";
                Room203_connect.Text = getip.STATUS203;
                Room203_status.ForeColor = Color.Red;
            }
        }

        public void recv_room401()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_401)
            {
                Socket Energy_room401 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room401.Connect(IPAddress.Parse(IP401), port401);
                }
                catch (SocketException e)
                {
                    SetText401f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText401f("Connect success.");
                recv = Energy_room401.Receive(data);
                Energy_room401.Shutdown(SocketShutdown.Both);
                Energy_room401.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText401(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'401')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText401f(string text)
        {
            if (Room401_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText401f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room401_connect.Text = text;
            }
        }

        private void SetText401(string text)
        {
            if (Room401_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText401);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room401_display.Text = text;
            }
        }

        private void recv_room402()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_402)
            {
                Socket Energy_room402 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room402.Connect(IPAddress.Parse(IP402), port402);
                }
                catch (SocketException e)
                {
                    SetText402f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText402f("Connect success.");
                recv = Energy_room402.Receive(data);
                Energy_room402.Shutdown(SocketShutdown.Both);
                Energy_room402.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText402(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'402')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText402f(string text)
        {
            if (Room402_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText402f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room402_connect.Text = text;
            }
        }

        private void SetText402(string text)
        {
            if (Room402_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText402);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room402_display.Text = text;
            }
        }

        private void recv_room403()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_403)
            {
                Socket Energy_room403 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room403.Connect(IPAddress.Parse(IP403), port403);
                }
                catch (SocketException e)
                {
                    SetText403f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText403f("Connect success.");
                recv = Energy_room403.Receive(data);
                Energy_room403.Shutdown(SocketShutdown.Both);
                Energy_room403.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText403(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'403')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText403f(string text)
        {
            if (Room403_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText403f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room403_connect.Text = text;
            }
        }

        private void SetText403(string text)
        {
            if (Room403_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText403);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room403_display.Text = text;
            }
        }

        private void recv_room301()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_301)
            {
                Socket Energy_room301 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room301.Connect(IPAddress.Parse(IP301), port301);
                }
                catch (SocketException e)
                {
                    SetText301f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText301f("Connect success.");
                recv = Energy_room301.Receive(data);
                Energy_room301.Shutdown(SocketShutdown.Both);
                Energy_room301.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText301(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'301')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText301f(string text)
        {
            if (Room301_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText301f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room301_connect.Text = text;
            }
        }

        private void SetText301(string text)
        {
            if (Room301_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText301);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room301_display.Text = text;
            }
        }

        private void recv_room302()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_302)
            {
                Socket Energy_room302 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room302.Connect(IPAddress.Parse(IP302), port302);
                }
                catch (SocketException e)
                {
                    SetText302f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText302f("Connect success.");
                recv = Energy_room302.Receive(data);
                Energy_room302.Shutdown(SocketShutdown.Both);
                Energy_room302.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText302(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'302')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText302f(string text)
        {
            if (Room302_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText302f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room302_connect.Text = text;
            }
        }

        private void SetText302(string text)
        {
            if (Room302_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText302);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room302_display.Text = text;
            }
        }

        private void recv_room303()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_303)
            {
                Socket Energy_room303 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room303.Connect(IPAddress.Parse(IP303), port303);
                }
                catch (SocketException e)
                {
                    SetText303f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText303f("Connect success.");
                recv = Energy_room303.Receive(data);
                Energy_room303.Shutdown(SocketShutdown.Both);
                Energy_room303.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText303(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'303')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText303f(string text)
        {
            if (Room303_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText303f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room303_connect.Text = text;
            }
        }

        private void SetText303(string text)
        {
            if (Room303_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText303);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room303_display.Text = text;
            }
        }

        private void recv_room201()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_201)
            {
                Socket Energy_room201 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room201.Connect(IPAddress.Parse(IP201), port201);
                }
                catch (SocketException e)
                {
                    SetText201f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText201f("Connect success.");
                recv = Energy_room201.Receive(data);
                Energy_room201.Shutdown(SocketShutdown.Both);
                Energy_room201.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText201(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'201')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText201f(string text)
        {
            if (Room201_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText201f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room201_connect.Text = text;
            }
        }

        private void SetText201(string text)
        {
            if (Room201_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText201);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room201_display.Text = text;
            }
        }

        private void recv_room202()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_202)
            {
                Socket Energy_room202 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room202.Connect(IPAddress.Parse(IP202), port202);
                }
                catch (SocketException e)
                {
                    SetText202f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText202f("Connect success.");
                recv = Energy_room202.Receive(data);
                Energy_room202.Shutdown(SocketShutdown.Both);
                Energy_room202.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText202(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'202')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText202f(string text)
        {
            if (Room202_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText202f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room202_connect.Text = text;
            }
        }

        private void SetText202(string text)
        {
            if (Room202_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText202);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room202_display.Text = text;
            }
        }

        private void recv_room203()
        {
            byte[] data = new byte[1024];
            string sqlAdd;
            long RowsAffect = 0;
            int recv;
            while (loop_203)
            {
                Socket Energy_room203 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    Energy_room203.Connect(IPAddress.Parse(IP203), port203);
                }
                catch (SocketException e)
                {
                    SetText203f("Connect failed.");
                    e.ToString();
                    return;
                }
                SetText203f("Connect success.");
                recv = Energy_room203.Receive(data);
                Energy_room203.Shutdown(SocketShutdown.Both);
                Energy_room203.Close();
                if (Encoding.ASCII.GetString(data, 0, recv).Length == 6)
                {
                    SetText203(Encoding.ASCII.GetString(data, 0, recv));
                    sqlAdd = "INSERT INTO ���俿��(�ѹ,����,������俿��,��͹,��,��ͧ) ";
                    sqlAdd += " VALUES('" + DateTime.Now.Date.ToLongDateString() + "'";
                    sqlAdd += ",'" + DateTime.Now.ToLongTimeString() + "'";
                    sqlAdd += ",'" + Encoding.ASCII.GetString(data, 0, recv) + "'";
                    sqlAdd += ",'" + DateTime.Now.Month.ToString() + "'";
                    sqlAdd += ",'" + DateTime.Now.Year.ToString() + "'";
                    sqlAdd += ",'203')";

                    OleDbCommand comAdd = new OleDbCommand();
                    try
                    {
                        Conn.ConnectionString = strConn;
                        if (Conn.State == ConnectionState.Open)
                        {
                            Conn.Close();
                        }
                        Conn.Open();

                        comAdd.CommandType = CommandType.Text;
                        comAdd.CommandText = sqlAdd;
                        comAdd.Connection = Conn;
                        RowsAffect = comAdd.ExecuteNonQuery();
                    }
                    catch (Exception errToAdd)
                    {
                        errToAdd.ToString();
                    }
                    finally
                    {
                        Conn.Close();
                    }
                }
            }
        }

        private void SetText203f(string text)
        {
            if (Room203_connect.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText203f);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room203_connect.Text = text;
            }
        }

        private void SetText203(string text)
        {
            if (Room203_display.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText203);
                Invoke(d, new object[] { text });
            }
            else
            {
                Room203_display.Text = text;
                Room203_connect.Text = "Connect success.";
            }
        }

        private void Stop_energy_Click(object sender, EventArgs e)
        {
            Run_energy.Enabled = true;
            Stop_energy.Enabled = false;
            Room401_config.Enabled = true;
            Room402_config.Enabled = true;
            Room403_config.Enabled = true;
            Room301_config.Enabled = true;
            Room302_config.Enabled = true;
            Room303_config.Enabled = true;
            Room201_config.Enabled = true;
            Room202_config.Enabled = true;
            Room203_config.Enabled = true;

            Room401_detail.Enabled = true;
            Room402_detail.Enabled = true;
            Room403_detail.Enabled = true;
            Room301_detail.Enabled = true;
            Room302_detail.Enabled = true;
            Room303_detail.Enabled = true;
            Room201_detail.Enabled = true;
            Room202_detail.Enabled = true;
            Room203_detail.Enabled = true;

            Room401_status.Text = "Inactive";
            Room401_status.ForeColor = Color.Red;
            Room402_status.Text = "Inactive";
            Room402_status.ForeColor = Color.Red;
            Room403_status.Text = "Inactive";
            Room403_status.ForeColor = Color.Red;
            Room301_status.Text = "Inactive";
            Room301_status.ForeColor = Color.Red;
            Room302_status.Text = "Inactive";
            Room302_status.ForeColor = Color.Red;
            Room303_status.Text = "Inactive";
            Room303_status.ForeColor = Color.Red;
            Room201_status.Text = "Inactive";
            Room201_status.ForeColor = Color.Red;
            Room202_status.Text = "Inactive";
            Room202_status.ForeColor = Color.Red;
            Room203_status.Text = "Inactive";
            Room203_status.ForeColor = Color.Red;

            Room401_connect.Text = "Ready";
            Room402_connect.Text = "Ready";
            Room403_connect.Text = "Ready";
            Room301_connect.Text = "Ready";
            Room302_connect.Text = "Ready";
            Room303_connect.Text = "Ready";
            Room201_connect.Text = "Ready";
            Room202_connect.Text = "Ready";
            Room203_connect.Text = "Ready";

            loop_401 = false;
            loop_402 = false;
            loop_403 = false;
            loop_301 = false;
            loop_302 = false;
            loop_303 = false;
            loop_201 = false;
            loop_202 = false;
            loop_203 = false;
        }

        private void Display_Load(object sender, EventArgs e)
        {
        }
    }
}