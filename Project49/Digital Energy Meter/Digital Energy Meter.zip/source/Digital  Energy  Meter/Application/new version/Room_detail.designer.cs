namespace energyApplication
{
    partial class Room_detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.fname_detail = new System.Windows.Forms.Label();
            this.lname_detail = new System.Windows.Forms.Label();
            this.date_detail = new System.Windows.Forms.Label();
            this.age_detail = new System.Windows.Forms.Label();
            this.ID_detail = new System.Windows.Forms.Label();
            this.nation1_detail = new System.Windows.Forms.Label();
            this.nation2_detail = new System.Windows.Forms.Label();
            this.group_detail = new System.Windows.Forms.Label();
            this.religion_detail = new System.Windows.Forms.Label();
            this.address_detail = new System.Windows.Forms.Label();
            this.fname1 = new System.Windows.Forms.TextBox();
            this.lname1 = new System.Windows.Forms.TextBox();
            this.date1 = new System.Windows.Forms.TextBox();
            this.age1 = new System.Windows.Forms.TextBox();
            this.ID1 = new System.Windows.Forms.TextBox();
            this.nation_law1 = new System.Windows.Forms.TextBox();
            this.nation_origin1 = new System.Windows.Forms.TextBox();
            this.grouptype1 = new System.Windows.Forms.TextBox();
            this.religion1 = new System.Windows.Forms.TextBox();
            this.address1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Delete1 = new System.Windows.Forms.Button();
            this.Update1 = new System.Windows.Forms.Button();
            this.sex1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.Insert1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Delete2 = new System.Windows.Forms.Button();
            this.sex2 = new System.Windows.Forms.TextBox();
            this.Update2 = new System.Windows.Forms.Button();
            this.Insert2 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.address2 = new System.Windows.Forms.TextBox();
            this.religion2 = new System.Windows.Forms.TextBox();
            this.grouptype2 = new System.Windows.Forms.TextBox();
            this.nation_origin2 = new System.Windows.Forms.TextBox();
            this.nation_law2 = new System.Windows.Forms.TextBox();
            this.ID2 = new System.Windows.Forms.TextBox();
            this.age2 = new System.Windows.Forms.TextBox();
            this.date2 = new System.Windows.Forms.TextBox();
            this.lname2 = new System.Windows.Forms.TextBox();
            this.fname2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Rooms = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Update3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.water_rate = new System.Windows.Forms.TextBox();
            this.electric_rate = new System.Windows.Forms.TextBox();
            this.Insure = new System.Windows.Forms.TextBox();
            this.last_date = new System.Windows.Forms.TextBox();
            this.fisrt_date = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.date = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.TextBox();
            this.data_unit = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.databefore = new System.Windows.Forms.TextBox();
            this.timebefore = new System.Windows.Forms.TextBox();
            this.datebefore = new System.Windows.Forms.TextBox();
            this.print = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // fname_detail
            // 
            this.fname_detail.AutoSize = true;
            this.fname_detail.Location = new System.Drawing.Point(16, 63);
            this.fname_detail.Name = "fname_detail";
            this.fname_detail.Size = new System.Drawing.Size(20, 13);
            this.fname_detail.TabIndex = 0;
            this.fname_detail.Text = "����";
            // 
            // lname_detail
            // 
            this.lname_detail.AutoSize = true;
            this.lname_detail.Location = new System.Drawing.Point(154, 63);
            this.lname_detail.Name = "lname_detail";
            this.lname_detail.Size = new System.Drawing.Size(46, 13);
            this.lname_detail.TabIndex = 0;
            this.lname_detail.Text = "���ʡ��";
            // 
            // date_detail
            // 
            this.date_detail.AutoSize = true;
            this.date_detail.Location = new System.Drawing.Point(16, 91);
            this.date_detail.Name = "date_detail";
            this.date_detail.Size = new System.Drawing.Size(26, 13);
            this.date_detail.TabIndex = 0;
            this.date_detail.Text = "�Դ";
            // 
            // age_detail
            // 
            this.age_detail.AutoSize = true;
            this.age_detail.Location = new System.Drawing.Point(154, 91);
            this.age_detail.Name = "age_detail";
            this.age_detail.Size = new System.Drawing.Size(25, 13);
            this.age_detail.TabIndex = 0;
            this.age_detail.Text = "����";
            // 
            // ID_detail
            // 
            this.ID_detail.AutoSize = true;
            this.ID_detail.Location = new System.Drawing.Point(15, 37);
            this.ID_detail.Name = "ID_detail";
            this.ID_detail.Size = new System.Drawing.Size(115, 13);
            this.ID_detail.TabIndex = 0;
            this.ID_detail.Text = "�����Ţ�ѵû�ЪҪ�";
            // 
            // nation1_detail
            // 
            this.nation1_detail.AutoSize = true;
            this.nation1_detail.Location = new System.Drawing.Point(15, 118);
            this.nation1_detail.Name = "nation1_detail";
            this.nation1_detail.Size = new System.Drawing.Size(41, 13);
            this.nation1_detail.TabIndex = 0;
            this.nation1_detail.Text = "�ѭ�ҵ�";
            // 
            // nation2_detail
            // 
            this.nation2_detail.AutoSize = true;
            this.nation2_detail.Location = new System.Drawing.Point(122, 118);
            this.nation2_detail.Name = "nation2_detail";
            this.nation2_detail.Size = new System.Drawing.Size(44, 13);
            this.nation2_detail.TabIndex = 0;
            this.nation2_detail.Text = "���ͪҵ�";
            // 
            // group_detail
            // 
            this.group_detail.AutoSize = true;
            this.group_detail.Location = new System.Drawing.Point(15, 148);
            this.group_detail.Name = "group_detail";
            this.group_detail.Size = new System.Drawing.Size(46, 13);
            this.group_detail.TabIndex = 0;
            this.group_detail.Text = "�������Ե";
            // 
            // religion_detail
            // 
            this.religion_detail.AutoSize = true;
            this.religion_detail.Location = new System.Drawing.Point(122, 148);
            this.religion_detail.Name = "religion_detail";
            this.religion_detail.Size = new System.Drawing.Size(39, 13);
            this.religion_detail.TabIndex = 0;
            this.religion_detail.Text = "��ʹ�";
            // 
            // address_detail
            // 
            this.address_detail.AutoSize = true;
            this.address_detail.Location = new System.Drawing.Point(15, 181);
            this.address_detail.Name = "address_detail";
            this.address_detail.Size = new System.Drawing.Size(27, 13);
            this.address_detail.TabIndex = 1;
            this.address_detail.Text = "�������";
            // 
            // fname1
            // 
            this.fname1.Location = new System.Drawing.Point(48, 60);
            this.fname1.Name = "fname1";
            this.fname1.Size = new System.Drawing.Size(100, 20);
            this.fname1.TabIndex = 2;
            this.fname1.Text = "-";
            // 
            // lname1
            // 
            this.lname1.Location = new System.Drawing.Point(206, 60);
            this.lname1.Name = "lname1";
            this.lname1.Size = new System.Drawing.Size(100, 20);
            this.lname1.TabIndex = 3;
            this.lname1.Text = "-";
            // 
            // date1
            // 
            this.date1.Location = new System.Drawing.Point(48, 88);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(100, 20);
            this.date1.TabIndex = 4;
            this.date1.Text = "-";
            this.date1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // age1
            // 
            this.age1.Location = new System.Drawing.Point(186, 88);
            this.age1.Name = "age1";
            this.age1.Size = new System.Drawing.Size(31, 20);
            this.age1.TabIndex = 5;
            this.age1.Text = "-";
            this.age1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ID1
            // 
            this.ID1.Location = new System.Drawing.Point(143, 34);
            this.ID1.Name = "ID1";
            this.ID1.Size = new System.Drawing.Size(163, 20);
            this.ID1.TabIndex = 6;
            this.ID1.Text = "-";
            this.ID1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nation_law1
            // 
            this.nation_law1.Location = new System.Drawing.Point(62, 115);
            this.nation_law1.Name = "nation_law1";
            this.nation_law1.Size = new System.Drawing.Size(54, 20);
            this.nation_law1.TabIndex = 7;
            this.nation_law1.Text = "-";
            this.nation_law1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nation_origin1
            // 
            this.nation_origin1.Location = new System.Drawing.Point(172, 115);
            this.nation_origin1.Name = "nation_origin1";
            this.nation_origin1.Size = new System.Drawing.Size(61, 20);
            this.nation_origin1.TabIndex = 8;
            this.nation_origin1.Text = "-";
            this.nation_origin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grouptype1
            // 
            this.grouptype1.Location = new System.Drawing.Point(67, 145);
            this.grouptype1.Name = "grouptype1";
            this.grouptype1.Size = new System.Drawing.Size(49, 20);
            this.grouptype1.TabIndex = 9;
            this.grouptype1.Text = "-";
            this.grouptype1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // religion1
            // 
            this.religion1.Location = new System.Drawing.Point(167, 145);
            this.religion1.Name = "religion1";
            this.religion1.Size = new System.Drawing.Size(66, 20);
            this.religion1.TabIndex = 10;
            this.religion1.Text = "-";
            this.religion1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // address1
            // 
            this.address1.Location = new System.Drawing.Point(48, 178);
            this.address1.Multiline = true;
            this.address1.Name = "address1";
            this.address1.Size = new System.Drawing.Size(258, 52);
            this.address1.TabIndex = 11;
            this.address1.Text = "-";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Delete1);
            this.groupBox1.Controls.Add(this.Update1);
            this.groupBox1.Controls.Add(this.sex1);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.Insert1);
            this.groupBox1.Controls.Add(this.address1);
            this.groupBox1.Controls.Add(this.religion1);
            this.groupBox1.Controls.Add(this.grouptype1);
            this.groupBox1.Controls.Add(this.nation_origin1);
            this.groupBox1.Controls.Add(this.nation_law1);
            this.groupBox1.Controls.Add(this.ID1);
            this.groupBox1.Controls.Add(this.age1);
            this.groupBox1.Controls.Add(this.date1);
            this.groupBox1.Controls.Add(this.lname1);
            this.groupBox1.Controls.Add(this.fname1);
            this.groupBox1.Controls.Add(this.address_detail);
            this.groupBox1.Controls.Add(this.religion_detail);
            this.groupBox1.Controls.Add(this.group_detail);
            this.groupBox1.Controls.Add(this.nation1_detail);
            this.groupBox1.Controls.Add(this.ID_detail);
            this.groupBox1.Controls.Add(this.nation2_detail);
            this.groupBox1.Controls.Add(this.date_detail);
            this.groupBox1.Controls.Add(this.age_detail);
            this.groupBox1.Controls.Add(this.lname_detail);
            this.groupBox1.Controls.Add(this.fname_detail);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(323, 286);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "������";
            // 
            // Delete1
            // 
            this.Delete1.Location = new System.Drawing.Point(231, 245);
            this.Delete1.Name = "Delete1";
            this.Delete1.Size = new System.Drawing.Size(75, 23);
            this.Delete1.TabIndex = 16;
            this.Delete1.Text = "ź";
            this.Delete1.UseVisualStyleBackColor = true;
            this.Delete1.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Update1
            // 
            this.Update1.Location = new System.Drawing.Point(18, 245);
            this.Update1.Name = "Update1";
            this.Update1.Size = new System.Drawing.Size(75, 23);
            this.Update1.TabIndex = 17;
            this.Update1.Text = "���";
            this.Update1.UseVisualStyleBackColor = true;
            this.Update1.Click += new System.EventHandler(this.Update1_Click);
            // 
            // sex1
            // 
            this.sex1.Location = new System.Drawing.Point(257, 88);
            this.sex1.Name = "sex1";
            this.sex1.Size = new System.Drawing.Size(48, 20);
            this.sex1.TabIndex = 13;
            this.sex1.Text = "-";
            this.sex1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(223, 91);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 13);
            this.label20.TabIndex = 12;
            this.label20.Text = "��";
            // 
            // Insert1
            // 
            this.Insert1.Location = new System.Drawing.Point(125, 245);
            this.Insert1.Name = "Insert1";
            this.Insert1.Size = new System.Drawing.Size(75, 23);
            this.Insert1.TabIndex = 15;
            this.Insert1.Text = "����";
            this.Insert1.UseVisualStyleBackColor = true;
            this.Insert1.Click += new System.EventHandler(this.Insert1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Delete2);
            this.groupBox2.Controls.Add(this.sex2);
            this.groupBox2.Controls.Add(this.Update2);
            this.groupBox2.Controls.Add(this.Insert2);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.address2);
            this.groupBox2.Controls.Add(this.religion2);
            this.groupBox2.Controls.Add(this.grouptype2);
            this.groupBox2.Controls.Add(this.nation_origin2);
            this.groupBox2.Controls.Add(this.nation_law2);
            this.groupBox2.Controls.Add(this.ID2);
            this.groupBox2.Controls.Add(this.age2);
            this.groupBox2.Controls.Add(this.date2);
            this.groupBox2.Controls.Add(this.lname2);
            this.groupBox2.Controls.Add(this.fname2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(341, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(323, 286);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "����������";
            // 
            // Delete2
            // 
            this.Delete2.Location = new System.Drawing.Point(231, 245);
            this.Delete2.Name = "Delete2";
            this.Delete2.Size = new System.Drawing.Size(75, 23);
            this.Delete2.TabIndex = 19;
            this.Delete2.Text = "ź";
            this.Delete2.UseVisualStyleBackColor = true;
            this.Delete2.Click += new System.EventHandler(this.Delete2_Click);
            // 
            // sex2
            // 
            this.sex2.Location = new System.Drawing.Point(258, 88);
            this.sex2.Name = "sex2";
            this.sex2.Size = new System.Drawing.Size(48, 20);
            this.sex2.TabIndex = 14;
            this.sex2.Text = "-";
            this.sex2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Update2
            // 
            this.Update2.Location = new System.Drawing.Point(18, 245);
            this.Update2.Name = "Update2";
            this.Update2.Size = new System.Drawing.Size(75, 23);
            this.Update2.TabIndex = 20;
            this.Update2.Text = "���";
            this.Update2.UseVisualStyleBackColor = true;
            this.Update2.Click += new System.EventHandler(this.Update2_Click);
            // 
            // Insert2
            // 
            this.Insert2.Location = new System.Drawing.Point(125, 245);
            this.Insert2.Name = "Insert2";
            this.Insert2.Size = new System.Drawing.Size(75, 23);
            this.Insert2.TabIndex = 18;
            this.Insert2.Text = "����";
            this.Insert2.UseVisualStyleBackColor = true;
            this.Insert2.Click += new System.EventHandler(this.Insert2_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(222, 91);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 13);
            this.label21.TabIndex = 13;
            this.label21.Text = "��";
            // 
            // address2
            // 
            this.address2.Location = new System.Drawing.Point(48, 178);
            this.address2.Multiline = true;
            this.address2.Name = "address2";
            this.address2.Size = new System.Drawing.Size(258, 52);
            this.address2.TabIndex = 11;
            this.address2.Text = "-";
            // 
            // religion2
            // 
            this.religion2.Location = new System.Drawing.Point(167, 145);
            this.religion2.Name = "religion2";
            this.religion2.Size = new System.Drawing.Size(66, 20);
            this.religion2.TabIndex = 10;
            this.religion2.Text = "-";
            this.religion2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grouptype2
            // 
            this.grouptype2.Location = new System.Drawing.Point(67, 145);
            this.grouptype2.Name = "grouptype2";
            this.grouptype2.Size = new System.Drawing.Size(49, 20);
            this.grouptype2.TabIndex = 9;
            this.grouptype2.Text = "-";
            this.grouptype2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nation_origin2
            // 
            this.nation_origin2.Location = new System.Drawing.Point(172, 115);
            this.nation_origin2.Name = "nation_origin2";
            this.nation_origin2.Size = new System.Drawing.Size(61, 20);
            this.nation_origin2.TabIndex = 8;
            this.nation_origin2.Text = "-";
            this.nation_origin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nation_law2
            // 
            this.nation_law2.Location = new System.Drawing.Point(62, 115);
            this.nation_law2.Name = "nation_law2";
            this.nation_law2.Size = new System.Drawing.Size(54, 20);
            this.nation_law2.TabIndex = 7;
            this.nation_law2.Text = "-";
            this.nation_law2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ID2
            // 
            this.ID2.Location = new System.Drawing.Point(143, 34);
            this.ID2.Name = "ID2";
            this.ID2.Size = new System.Drawing.Size(163, 20);
            this.ID2.TabIndex = 6;
            this.ID2.Text = "-";
            this.ID2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // age2
            // 
            this.age2.Location = new System.Drawing.Point(185, 88);
            this.age2.Name = "age2";
            this.age2.Size = new System.Drawing.Size(31, 20);
            this.age2.TabIndex = 5;
            this.age2.Text = "-";
            this.age2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // date2
            // 
            this.date2.Location = new System.Drawing.Point(48, 88);
            this.date2.Name = "date2";
            this.date2.Size = new System.Drawing.Size(100, 20);
            this.date2.TabIndex = 4;
            this.date2.Text = "-";
            this.date2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lname2
            // 
            this.lname2.Location = new System.Drawing.Point(206, 60);
            this.lname2.Name = "lname2";
            this.lname2.Size = new System.Drawing.Size(100, 20);
            this.lname2.TabIndex = 3;
            this.lname2.Text = "-";
            // 
            // fname2
            // 
            this.fname2.Location = new System.Drawing.Point(48, 60);
            this.fname2.Name = "fname2";
            this.fname2.Size = new System.Drawing.Size(100, 20);
            this.fname2.TabIndex = 2;
            this.fname2.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "�������";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "��ʹ�";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "�������Ե";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "�ѭ�ҵ�";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "�����Ţ�ѵû�ЪҪ�";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(122, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "���ͪҵ�";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "�Դ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(154, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "����";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(154, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "���ʡ��";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "����";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Rooms);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.Update3);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.water_rate);
            this.groupBox3.Controls.Add(this.electric_rate);
            this.groupBox3.Controls.Add(this.Insure);
            this.groupBox3.Controls.Add(this.last_date);
            this.groupBox3.Controls.Add(this.fisrt_date);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(12, 306);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(323, 190);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "��������´��ͧ";
            // 
            // Rooms
            // 
            this.Rooms.AutoSize = true;
            this.Rooms.Location = new System.Drawing.Point(122, 26);
            this.Rooms.Name = "Rooms";
            this.Rooms.Size = new System.Drawing.Size(68, 13);
            this.Rooms.TabIndex = 21;
            this.Rooms.Text = "�����Ţ��ͧ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(229, 103);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "�ҷ";
            // 
            // Update3
            // 
            this.Update3.Location = new System.Drawing.Point(231, 21);
            this.Update3.Name = "Update3";
            this.Update3.Size = new System.Drawing.Size(75, 23);
            this.Update3.TabIndex = 20;
            this.Update3.Text = "���";
            this.Update3.UseVisualStyleBackColor = true;
            this.Update3.Click += new System.EventHandler(this.Update3_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(229, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "�ҷ���˹���";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(229, 155);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 13);
            this.label17.TabIndex = 7;
            this.label17.Text = "�ҷ���˹���";
            // 
            // water_rate
            // 
            this.water_rate.Location = new System.Drawing.Point(123, 152);
            this.water_rate.Name = "water_rate";
            this.water_rate.Size = new System.Drawing.Size(100, 20);
            this.water_rate.TabIndex = 6;
            this.water_rate.Text = "-";
            this.water_rate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // electric_rate
            // 
            this.electric_rate.Location = new System.Drawing.Point(123, 126);
            this.electric_rate.Name = "electric_rate";
            this.electric_rate.Size = new System.Drawing.Size(100, 20);
            this.electric_rate.TabIndex = 5;
            this.electric_rate.Text = "-";
            this.electric_rate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Insure
            // 
            this.Insure.Location = new System.Drawing.Point(123, 100);
            this.Insure.Name = "Insure";
            this.Insure.Size = new System.Drawing.Size(100, 20);
            this.Insure.TabIndex = 4;
            this.Insure.Text = "-";
            this.Insure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // last_date
            // 
            this.last_date.Location = new System.Drawing.Point(123, 75);
            this.last_date.Name = "last_date";
            this.last_date.Size = new System.Drawing.Size(100, 20);
            this.last_date.TabIndex = 3;
            this.last_date.Text = "-";
            this.last_date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // fisrt_date
            // 
            this.fisrt_date.Location = new System.Drawing.Point(123, 49);
            this.fisrt_date.Name = "fisrt_date";
            this.fisrt_date.Size = new System.Drawing.Size(100, 20);
            this.fisrt_date.TabIndex = 2;
            this.fisrt_date.Text = "-";
            this.fisrt_date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 155);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "�ѵ�Ҥ�ҹ�ӻ�л�";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "�ѵ�Ҥ��俿��";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 78);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "�ѹ��������ѭ��";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "��������ͧ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 52);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "�ѹ�á����������";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "��ͧ�Ţ���";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(452, 355);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(100, 20);
            this.date.TabIndex = 15;
            this.date.Text = "-";
            this.date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(356, 358);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(28, 13);
            this.label22.TabIndex = 16;
            this.label22.Text = "�ѹ���";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(356, 384);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 13);
            this.label23.TabIndex = 16;
            this.label23.Text = "����";
            // 
            // time
            // 
            this.time.Location = new System.Drawing.Point(452, 381);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(100, 20);
            this.time.TabIndex = 15;
            this.time.Text = "-";
            this.time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // data_unit
            // 
            this.data_unit.Location = new System.Drawing.Point(452, 329);
            this.data_unit.Name = "data_unit";
            this.data_unit.Size = new System.Drawing.Size(100, 20);
            this.data_unit.TabIndex = 15;
            this.data_unit.Text = "-";
            this.data_unit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(356, 332);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 13);
            this.label24.TabIndex = 16;
            this.label24.Text = "���俿������ش";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(353, 409);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 13);
            this.label25.TabIndex = 20;
            this.label25.Text = "���俿����͹��͹";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(356, 461);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 13);
            this.label26.TabIndex = 21;
            this.label26.Text = "����";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(357, 435);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "�ѹ���";
            // 
            // databefore
            // 
            this.databefore.Location = new System.Drawing.Point(452, 406);
            this.databefore.Name = "databefore";
            this.databefore.Size = new System.Drawing.Size(100, 20);
            this.databefore.TabIndex = 17;
            this.databefore.Text = "-";
            this.databefore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timebefore
            // 
            this.timebefore.Location = new System.Drawing.Point(452, 458);
            this.timebefore.Name = "timebefore";
            this.timebefore.Size = new System.Drawing.Size(100, 20);
            this.timebefore.TabIndex = 18;
            this.timebefore.Text = "-";
            this.timebefore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // datebefore
            // 
            this.datebefore.Location = new System.Drawing.Point(452, 432);
            this.datebefore.Name = "datebefore";
            this.datebefore.Size = new System.Drawing.Size(100, 20);
            this.datebefore.TabIndex = 19;
            this.datebefore.Text = "-";
            this.datebefore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(572, 327);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(75, 23);
            this.print.TabIndex = 23;
            this.print.Text = "����������";
            this.print.UseVisualStyleBackColor = true;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // Room_detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 508);
            this.Controls.Add(this.print);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.databefore);
            this.Controls.Add(this.timebefore);
            this.Controls.Add(this.datebefore);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.data_unit);
            this.Controls.Add(this.time);
            this.Controls.Add(this.date);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Room_detail";
            this.Opacity = 0.5;
            this.Text = "Room";
            this.Load += new System.EventHandler(this.Room_detail_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fname_detail;
        private System.Windows.Forms.Label lname_detail;
        private System.Windows.Forms.Label date_detail;
        private System.Windows.Forms.Label age_detail;
        private System.Windows.Forms.Label ID_detail;
        private System.Windows.Forms.Label nation1_detail;
        private System.Windows.Forms.Label nation2_detail;
        private System.Windows.Forms.Label group_detail;
        private System.Windows.Forms.Label religion_detail;
        private System.Windows.Forms.Label address_detail;
        private System.Windows.Forms.TextBox fname1;
        private System.Windows.Forms.TextBox lname1;
        private System.Windows.Forms.TextBox date1;
        private System.Windows.Forms.TextBox age1;
        private System.Windows.Forms.TextBox ID1;
        private System.Windows.Forms.TextBox nation_law1;
        private System.Windows.Forms.TextBox nation_origin1;
        private System.Windows.Forms.TextBox grouptype1;
        private System.Windows.Forms.TextBox religion1;
        private System.Windows.Forms.TextBox address1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox address2;
        private System.Windows.Forms.TextBox religion2;
        private System.Windows.Forms.TextBox grouptype2;
        private System.Windows.Forms.TextBox nation_origin2;
        private System.Windows.Forms.TextBox nation_law2;
        private System.Windows.Forms.TextBox ID2;
        private System.Windows.Forms.TextBox age2;
        private System.Windows.Forms.TextBox date2;
        private System.Windows.Forms.TextBox lname2;
        private System.Windows.Forms.TextBox fname2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox water_rate;
        private System.Windows.Forms.TextBox electric_rate;
        private System.Windows.Forms.TextBox Insure;
        private System.Windows.Forms.TextBox last_date;
        private System.Windows.Forms.TextBox fisrt_date;
        private System.Windows.Forms.Button Insert1;
        private System.Windows.Forms.Button Delete1;
        private System.Windows.Forms.Button Update1;
        private System.Windows.Forms.Timer timer1;
        private string room_number;
        private System.Windows.Forms.TextBox sex1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox sex2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button Delete2;
        private System.Windows.Forms.Button Update2;
        private System.Windows.Forms.Button Insert2;
        private System.Windows.Forms.Button Update3;
        private System.Windows.Forms.Label Rooms;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox time;
        private System.Windows.Forms.TextBox data_unit;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox databefore;
        private System.Windows.Forms.TextBox timebefore;
        public System.Windows.Forms.TextBox datebefore;
        private System.Windows.Forms.Button print;
    }
}