using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace energyApplication
{
    public partial class Print_receipt : Form
    {
        public Print_receipt(string number)
        {
            InitializeComponent();
            printDocument.PrintPage += new PrintPageEventHandler(document_PrintPage);
            room_number = number;
        }

        private void Print_receipt_Load(object sender, EventArgs e)
        {
            OleDbConnection Conn = new OleDbConnection();
            string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=�;ѡ.mdb";
            string sqlPersonal1 = "SELECT * FROM ����ѵԼ����� WHERE ��ͧ='" + room_number + "'AND ʶҹ�='������'";
            string sqlPersonal2 = "SELECT * FROM ����ѵԼ����� WHERE ��ͧ='" + room_number + "'AND ʶҹ�='����������'";
            string sqlRoom = "SELECT * FROM ��ͧ��� WHERE ��ͧ='" + room_number + "'";
            string sqlData1 = "SELECT * FROM ���俿�� WHERE ��ͧ='" + room_number + "'AND ��͹='" + DateTime.Now.AddMonths(-1).Month.ToString() + "'AND ��='" + DateTime.Now.AddMonths(-1).Year.ToString() + "'ORDER BY ������俿�� DESC";
            string sqlData2 = "SELECT * FROM ���俿�� WHERE ��ͧ='" + room_number + "'AND ��͹='" + DateTime.Now.AddMonths(-2).Month.ToString() + "'AND ��='" + DateTime.Now.AddMonths(-2).Year.ToString() + "'ORDER BY ������俿�� DESC";
            OleDbDataAdapter daPerson1;
            OleDbDataAdapter daPerson2;
            OleDbDataAdapter daRoom;
            OleDbDataAdapter daData1;
            OleDbDataAdapter daData2;
            
            try
            {
                if (Conn.State == ConnectionState.Open)
                {
                    Conn.Close();
                }
                Conn.ConnectionString = strConn;
                Conn.Open();
                DataSet dsPerson1 = new DataSet();
                DataSet dsPerson2 = new DataSet();
                DataSet dsRoom = new DataSet();
                DataSet dsData1 = new DataSet();
                DataSet dsData2 = new DataSet();
                daPerson1 = new OleDbDataAdapter(sqlPersonal1, Conn);
                daPerson1.Fill(dsPerson1, "����ѵԼ�����");

                daPerson2 = new OleDbDataAdapter(sqlPersonal2, Conn);
                daPerson2.Fill(dsPerson2, "����ѵԼ�����");

                daRoom = new OleDbDataAdapter(sqlRoom, Conn);
                daRoom.Fill(dsRoom, "��ͧ���");

                daData1 = new OleDbDataAdapter(sqlData1, Conn);
                daData1.Fill(dsData1, "���俿��");

                daData2 = new OleDbDataAdapter(sqlData2, Conn);
                daData2.Fill(dsData2, "���俿��");

                proom.Text = room_number;
                pmonth.Text = DateTime.Today.ToLongDateString();
                pbeforem.DataBindings.Add("Text", dsData1, "���俿��.�ѹ");
                pbeforeu.DataBindings.Add("Text", dsData1, "���俿��.������俿��");
                string pbe = pbeforeu.Text;
                pafterm.DataBindings.Add("Text", dsData2, "���俿��.�ѹ");
                pafteru.DataBindings.Add("Text", dsData2, "���俿��.������俿��");
                string paf = pafteru.Text;
                name1.DataBindings.Add("Text", dsPerson1, "����ѵԼ�����.����");
                lname1.DataBindings.Add("Text", dsPerson1, "����ѵԼ�����.���ʡ��");
                name2.DataBindings.Add("Text", dsPerson2, "����ѵԼ�����.����");
                lname2.DataBindings.Add("Text", dsPerson2, "����ѵԼ�����.���ʡ��");
                prent.DataBindings.Add("Text", dsRoom, "��ͧ���.��һ�Сѹ");
                string rent = prent.Text;
                punit.DataBindings.Add("Text", dsRoom, "��ͧ���.�ѵ�Ҥ��俿��");
                string unit = punit.Text;
                if (pbe != "-" && paf != "-" && unit != "-")
                {
                    double data_unit = Convert.ToDouble(pbe) - Convert.ToDouble(paf);
                    pallunit.Text = Convert.ToInt32(data_unit).ToString();
                    int du = Convert.ToInt32(unit) * Convert.ToInt32(data_unit);
                    pallelectric.Text = du.ToString();
                    int all = Convert.ToInt32(rent) + du;
                    pallroom.Text = all.ToString();
                }
                
            }
            catch (Exception errToAccess)
            {
                MessageBox.Show("�������ö��ҹ�������� " + errToAccess.Message, "��ͼԴ��Ҵ");
            }
            finally
            {
                Conn.Close();
            }
        }

        private void button_print_Click(object sender, EventArgs e)
        {
            printDialog1.Document = printDocument;
            printDialog1.ShowDialog();
        }

        private void buttonpreview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument;
            try
            {
                printPreviewDialog1.ShowDialog();
            }
            catch(Exception err)
            {
                MessageBox.Show("Printer is not installed.","Error");
                err.ToString();
            }
        }

        private void document_PrintPage(object sender, PrintPageEventArgs e)
        {
            Room_detail room = new Room_detail(room_number);
            string text = "���˹��";
            Font printFont = new Font("Angsana New", 25, FontStyle.Bold);
            e.Graphics.DrawString(text, printFont, Brushes.Black, 370, 50);
            text = "��Ш��ѹ��� " + DateTime.Today.ToLongDateString() + "\t��ͧ  " + room_number;
            printFont = new Font("Angsana New", 18, FontStyle.Regular);
            e.Graphics.DrawString(text, printFont, Brushes.Black, 240, 100);
            text = "�����Ţ������俿���ѹ���\t" + pbeforem.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 200);
            text = "��ҡѺ\t" + pbeforeu.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 500, 200);
            text = "�����Ţ������俿���ѹ���\t" + pafterm.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 235);
            text = "��ҡѺ\t" + pafteru.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 500, 235);
            text = "������\t\t" + name1.Text.ToString() + "\t" + lname1.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 305);
            text = "����������\t\t" + name2.Text.ToString() + "\t" + lname2.Text.ToString();
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 340);
            text = "��������ͧ\t\t\t\t\t" + prent.Text.ToString()+"\t�ҷ";
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 415);
            text = "���俿��˹�����\t" + punit.Text.ToString() + "\t�ҷ";
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 450);
            text = "�������\t\t" + pallunit.Text.ToString() + "\t˹���";
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 485);
            text = "�繨ӹǹ�Թ\t\t\t\t" + pallelectric.Text.ToString() + "\t�ҷ";
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 520);
            text = "����繨ӹǹ�Թ������\t\t" + pallroom.Text.ToString() + "\t�ҷ";
            printFont = new Font("Angsana New", 18, FontStyle.Underline);
            e.Graphics.DrawString(text, printFont, Brushes.Black, 300, 650);
            
        }
    }
}