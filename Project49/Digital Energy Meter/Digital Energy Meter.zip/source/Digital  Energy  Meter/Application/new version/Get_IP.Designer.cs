namespace energyApplication
{
    partial class Get_IP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.GetStatus401 = new System.Windows.Forms.Label();
            this.GetStatus402 = new System.Windows.Forms.Label();
            this.GetStatus403 = new System.Windows.Forms.Label();
            this.GetStatus301 = new System.Windows.Forms.Label();
            this.GetStatus302 = new System.Windows.Forms.Label();
            this.GetStatus303 = new System.Windows.Forms.Label();
            this.GetStatus201 = new System.Windows.Forms.Label();
            this.GetStatus202 = new System.Windows.Forms.Label();
            this.GetStatus203 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GETport203 = new System.Windows.Forms.TextBox();
            this.GETport202 = new System.Windows.Forms.TextBox();
            this.GETport201 = new System.Windows.Forms.TextBox();
            this.GETport303 = new System.Windows.Forms.TextBox();
            this.GETport302 = new System.Windows.Forms.TextBox();
            this.GETport301 = new System.Windows.Forms.TextBox();
            this.GETport403 = new System.Windows.Forms.TextBox();
            this.GETport402 = new System.Windows.Forms.TextBox();
            this.GETport401 = new System.Windows.Forms.TextBox();
            this.GetIPD203 = new System.Windows.Forms.TextBox();
            this.GetIPC203 = new System.Windows.Forms.TextBox();
            this.GetIPB203 = new System.Windows.Forms.TextBox();
            this.GetIPA203 = new System.Windows.Forms.TextBox();
            this.GetIPD202 = new System.Windows.Forms.TextBox();
            this.GetIPC202 = new System.Windows.Forms.TextBox();
            this.GetIPB202 = new System.Windows.Forms.TextBox();
            this.GetIPA202 = new System.Windows.Forms.TextBox();
            this.GetIPD201 = new System.Windows.Forms.TextBox();
            this.GetIPC201 = new System.Windows.Forms.TextBox();
            this.GetIPB201 = new System.Windows.Forms.TextBox();
            this.GetIPA201 = new System.Windows.Forms.TextBox();
            this.GetIPD303 = new System.Windows.Forms.TextBox();
            this.GetIPC303 = new System.Windows.Forms.TextBox();
            this.GetIPB303 = new System.Windows.Forms.TextBox();
            this.GetIPA303 = new System.Windows.Forms.TextBox();
            this.GetIPD302 = new System.Windows.Forms.TextBox();
            this.GetIPC302 = new System.Windows.Forms.TextBox();
            this.GetIPB302 = new System.Windows.Forms.TextBox();
            this.GetIPA302 = new System.Windows.Forms.TextBox();
            this.GetIPD301 = new System.Windows.Forms.TextBox();
            this.GetIPC301 = new System.Windows.Forms.TextBox();
            this.GetIPD403 = new System.Windows.Forms.TextBox();
            this.GetIPB301 = new System.Windows.Forms.TextBox();
            this.GetIPC403 = new System.Windows.Forms.TextBox();
            this.GetIPD402 = new System.Windows.Forms.TextBox();
            this.GetIPA301 = new System.Windows.Forms.TextBox();
            this.GetIPC402 = new System.Windows.Forms.TextBox();
            this.GetIPB403 = new System.Windows.Forms.TextBox();
            this.GetIPD401 = new System.Windows.Forms.TextBox();
            this.GetIPB402 = new System.Windows.Forms.TextBox();
            this.GetIPC401 = new System.Windows.Forms.TextBox();
            this.GetIPA403 = new System.Windows.Forms.TextBox();
            this.GetIPB401 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.GetIPA402 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.GetIPA401 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(72, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(72, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "IP.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(72, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "IP.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label4.Location = new System.Drawing.Point(72, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "IP.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label5.Location = new System.Drawing.Point(72, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "IP.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label6.Location = new System.Drawing.Point(72, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "IP.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label7.Location = new System.Drawing.Point(72, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "IP.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label8.Location = new System.Drawing.Point(72, 184);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "IP.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label9.Location = new System.Drawing.Point(72, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "IP.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label10.Location = new System.Drawing.Point(384, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Status.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label11.Location = new System.Drawing.Point(384, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Status.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label12.Location = new System.Drawing.Point(384, 64);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Status.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label13.Location = new System.Drawing.Point(384, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Status.";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label14.Location = new System.Drawing.Point(384, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Status.";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label15.Location = new System.Drawing.Point(384, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Status.";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label16.Location = new System.Drawing.Point(384, 160);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Status.";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label17.Location = new System.Drawing.Point(384, 184);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Status.";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label18.Location = new System.Drawing.Point(384, 208);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Status.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label19.Location = new System.Drawing.Point(6, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Room401";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label20.Location = new System.Drawing.Point(6, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "Room402";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label21.Location = new System.Drawing.Point(6, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Room403";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label22.Location = new System.Drawing.Point(6, 88);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 13);
            this.label22.TabIndex = 1;
            this.label22.Text = "Room301";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label23.Location = new System.Drawing.Point(6, 112);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Room302";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label24.Location = new System.Drawing.Point(6, 136);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Room303";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label25.Location = new System.Drawing.Point(6, 160);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 13);
            this.label25.TabIndex = 1;
            this.label25.Text = "Room201";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label26.Location = new System.Drawing.Point(6, 184);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 13);
            this.label26.TabIndex = 1;
            this.label26.Text = "Room202";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label27.Location = new System.Drawing.Point(6, 208);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "Room203";
            // 
            // GetStatus401
            // 
            this.GetStatus401.AutoSize = true;
            this.GetStatus401.Location = new System.Drawing.Point(433, 16);
            this.GetStatus401.Name = "GetStatus401";
            this.GetStatus401.Size = new System.Drawing.Size(61, 13);
            this.GetStatus401.TabIndex = 0;
            this.GetStatus401.Text = "Disconnect";
            // 
            // GetStatus402
            // 
            this.GetStatus402.AutoSize = true;
            this.GetStatus402.Location = new System.Drawing.Point(433, 40);
            this.GetStatus402.Name = "GetStatus402";
            this.GetStatus402.Size = new System.Drawing.Size(61, 13);
            this.GetStatus402.TabIndex = 0;
            this.GetStatus402.Text = "Disconnect";
            // 
            // GetStatus403
            // 
            this.GetStatus403.AutoSize = true;
            this.GetStatus403.Location = new System.Drawing.Point(433, 64);
            this.GetStatus403.Name = "GetStatus403";
            this.GetStatus403.Size = new System.Drawing.Size(61, 13);
            this.GetStatus403.TabIndex = 0;
            this.GetStatus403.Text = "Disconnect";
            // 
            // GetStatus301
            // 
            this.GetStatus301.AutoSize = true;
            this.GetStatus301.Location = new System.Drawing.Point(433, 88);
            this.GetStatus301.Name = "GetStatus301";
            this.GetStatus301.Size = new System.Drawing.Size(61, 13);
            this.GetStatus301.TabIndex = 0;
            this.GetStatus301.Text = "Disconnect";
            // 
            // GetStatus302
            // 
            this.GetStatus302.AutoSize = true;
            this.GetStatus302.Location = new System.Drawing.Point(433, 112);
            this.GetStatus302.Name = "GetStatus302";
            this.GetStatus302.Size = new System.Drawing.Size(61, 13);
            this.GetStatus302.TabIndex = 0;
            this.GetStatus302.Text = "Disconnect";
            // 
            // GetStatus303
            // 
            this.GetStatus303.AutoSize = true;
            this.GetStatus303.Location = new System.Drawing.Point(433, 136);
            this.GetStatus303.Name = "GetStatus303";
            this.GetStatus303.Size = new System.Drawing.Size(61, 13);
            this.GetStatus303.TabIndex = 0;
            this.GetStatus303.Text = "Disconnect";
            // 
            // GetStatus201
            // 
            this.GetStatus201.AutoSize = true;
            this.GetStatus201.Location = new System.Drawing.Point(433, 160);
            this.GetStatus201.Name = "GetStatus201";
            this.GetStatus201.Size = new System.Drawing.Size(61, 13);
            this.GetStatus201.TabIndex = 0;
            this.GetStatus201.Text = "Disconnect";
            // 
            // GetStatus202
            // 
            this.GetStatus202.AutoSize = true;
            this.GetStatus202.Location = new System.Drawing.Point(433, 184);
            this.GetStatus202.Name = "GetStatus202";
            this.GetStatus202.Size = new System.Drawing.Size(61, 13);
            this.GetStatus202.TabIndex = 0;
            this.GetStatus202.Text = "Disconnect";
            // 
            // GetStatus203
            // 
            this.GetStatus203.AutoSize = true;
            this.GetStatus203.Location = new System.Drawing.Point(433, 208);
            this.GetStatus203.Name = "GetStatus203";
            this.GetStatus203.Size = new System.Drawing.Size(61, 13);
            this.GetStatus203.TabIndex = 0;
            this.GetStatus203.Text = "Disconnect";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.GETport203);
            this.groupBox1.Controls.Add(this.GETport202);
            this.groupBox1.Controls.Add(this.GETport201);
            this.groupBox1.Controls.Add(this.GETport303);
            this.groupBox1.Controls.Add(this.GETport302);
            this.groupBox1.Controls.Add(this.GETport301);
            this.groupBox1.Controls.Add(this.GETport403);
            this.groupBox1.Controls.Add(this.GETport402);
            this.groupBox1.Controls.Add(this.GETport401);
            this.groupBox1.Controls.Add(this.GetIPD203);
            this.groupBox1.Controls.Add(this.GetIPC203);
            this.groupBox1.Controls.Add(this.GetIPB203);
            this.groupBox1.Controls.Add(this.GetIPA203);
            this.groupBox1.Controls.Add(this.GetIPD202);
            this.groupBox1.Controls.Add(this.GetIPC202);
            this.groupBox1.Controls.Add(this.GetIPB202);
            this.groupBox1.Controls.Add(this.GetIPA202);
            this.groupBox1.Controls.Add(this.GetIPD201);
            this.groupBox1.Controls.Add(this.GetIPC201);
            this.groupBox1.Controls.Add(this.GetIPB201);
            this.groupBox1.Controls.Add(this.GetIPA201);
            this.groupBox1.Controls.Add(this.GetIPD303);
            this.groupBox1.Controls.Add(this.GetIPC303);
            this.groupBox1.Controls.Add(this.GetIPB303);
            this.groupBox1.Controls.Add(this.GetIPA303);
            this.groupBox1.Controls.Add(this.GetIPD302);
            this.groupBox1.Controls.Add(this.GetIPC302);
            this.groupBox1.Controls.Add(this.GetIPB302);
            this.groupBox1.Controls.Add(this.GetIPA302);
            this.groupBox1.Controls.Add(this.GetIPD301);
            this.groupBox1.Controls.Add(this.GetIPC301);
            this.groupBox1.Controls.Add(this.GetIPD403);
            this.groupBox1.Controls.Add(this.GetIPB301);
            this.groupBox1.Controls.Add(this.GetIPC403);
            this.groupBox1.Controls.Add(this.GetIPD402);
            this.groupBox1.Controls.Add(this.GetIPA301);
            this.groupBox1.Controls.Add(this.GetIPC402);
            this.groupBox1.Controls.Add(this.GetIPB403);
            this.groupBox1.Controls.Add(this.GetIPD401);
            this.groupBox1.Controls.Add(this.GetIPB402);
            this.groupBox1.Controls.Add(this.GetIPC401);
            this.groupBox1.Controls.Add(this.GetIPA403);
            this.groupBox1.Controls.Add(this.GetIPB401);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.GetIPA402);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.GetIPA401);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.GetStatus203);
            this.groupBox1.Controls.Add(this.label63);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.GetStatus202);
            this.groupBox1.Controls.Add(this.label62);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.GetStatus201);
            this.groupBox1.Controls.Add(this.label61);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.GetStatus303);
            this.groupBox1.Controls.Add(this.label60);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.GetStatus302);
            this.groupBox1.Controls.Add(this.label59);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.GetStatus301);
            this.groupBox1.Controls.Add(this.label58);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.GetStatus403);
            this.groupBox1.Controls.Add(this.label57);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.GetStatus402);
            this.groupBox1.Controls.Add(this.label56);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.GetStatus401);
            this.groupBox1.Controls.Add(this.label55);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(504, 233);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IP";
            // 
            // GETport203
            // 
            this.GETport203.Location = new System.Drawing.Point(325, 205);
            this.GETport203.Name = "GETport203";
            this.GETport203.ReadOnly = true;
            this.GETport203.Size = new System.Drawing.Size(53, 20);
            this.GETport203.TabIndex = 6;
            // 
            // GETport202
            // 
            this.GETport202.Location = new System.Drawing.Point(325, 181);
            this.GETport202.Name = "GETport202";
            this.GETport202.ReadOnly = true;
            this.GETport202.Size = new System.Drawing.Size(53, 20);
            this.GETport202.TabIndex = 6;
            // 
            // GETport201
            // 
            this.GETport201.Location = new System.Drawing.Point(325, 157);
            this.GETport201.Name = "GETport201";
            this.GETport201.ReadOnly = true;
            this.GETport201.Size = new System.Drawing.Size(53, 20);
            this.GETport201.TabIndex = 6;
            // 
            // GETport303
            // 
            this.GETport303.Location = new System.Drawing.Point(325, 133);
            this.GETport303.Name = "GETport303";
            this.GETport303.ReadOnly = true;
            this.GETport303.Size = new System.Drawing.Size(53, 20);
            this.GETport303.TabIndex = 6;
            // 
            // GETport302
            // 
            this.GETport302.Location = new System.Drawing.Point(325, 109);
            this.GETport302.Name = "GETport302";
            this.GETport302.ReadOnly = true;
            this.GETport302.Size = new System.Drawing.Size(53, 20);
            this.GETport302.TabIndex = 6;
            // 
            // GETport301
            // 
            this.GETport301.Location = new System.Drawing.Point(325, 85);
            this.GETport301.Name = "GETport301";
            this.GETport301.ReadOnly = true;
            this.GETport301.Size = new System.Drawing.Size(53, 20);
            this.GETport301.TabIndex = 6;
            // 
            // GETport403
            // 
            this.GETport403.Location = new System.Drawing.Point(325, 61);
            this.GETport403.Name = "GETport403";
            this.GETport403.ReadOnly = true;
            this.GETport403.Size = new System.Drawing.Size(53, 20);
            this.GETport403.TabIndex = 6;
            // 
            // GETport402
            // 
            this.GETport402.Location = new System.Drawing.Point(325, 37);
            this.GETport402.Name = "GETport402";
            this.GETport402.ReadOnly = true;
            this.GETport402.Size = new System.Drawing.Size(53, 20);
            this.GETport402.TabIndex = 6;
            // 
            // GETport401
            // 
            this.GETport401.Location = new System.Drawing.Point(325, 13);
            this.GETport401.Name = "GETport401";
            this.GETport401.ReadOnly = true;
            this.GETport401.Size = new System.Drawing.Size(53, 20);
            this.GETport401.TabIndex = 6;
            // 
            // GetIPD203
            // 
            this.GetIPD203.Location = new System.Drawing.Point(251, 205);
            this.GetIPD203.Name = "GetIPD203";
            this.GetIPD203.ReadOnly = true;
            this.GetIPD203.Size = new System.Drawing.Size(28, 20);
            this.GetIPD203.TabIndex = 5;
            this.GetIPD203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC203
            // 
            this.GetIPC203.Location = new System.Drawing.Point(201, 205);
            this.GetIPC203.Name = "GetIPC203";
            this.GetIPC203.ReadOnly = true;
            this.GetIPC203.Size = new System.Drawing.Size(28, 20);
            this.GetIPC203.TabIndex = 5;
            this.GetIPC203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB203
            // 
            this.GetIPB203.Location = new System.Drawing.Point(151, 205);
            this.GetIPB203.Name = "GetIPB203";
            this.GetIPB203.ReadOnly = true;
            this.GetIPB203.Size = new System.Drawing.Size(28, 20);
            this.GetIPB203.TabIndex = 5;
            this.GetIPB203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA203
            // 
            this.GetIPA203.Location = new System.Drawing.Point(101, 205);
            this.GetIPA203.Name = "GetIPA203";
            this.GetIPA203.ReadOnly = true;
            this.GetIPA203.Size = new System.Drawing.Size(28, 20);
            this.GetIPA203.TabIndex = 5;
            this.GetIPA203.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD202
            // 
            this.GetIPD202.Location = new System.Drawing.Point(251, 181);
            this.GetIPD202.Name = "GetIPD202";
            this.GetIPD202.ReadOnly = true;
            this.GetIPD202.Size = new System.Drawing.Size(28, 20);
            this.GetIPD202.TabIndex = 5;
            this.GetIPD202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC202
            // 
            this.GetIPC202.Location = new System.Drawing.Point(201, 181);
            this.GetIPC202.Name = "GetIPC202";
            this.GetIPC202.ReadOnly = true;
            this.GetIPC202.Size = new System.Drawing.Size(28, 20);
            this.GetIPC202.TabIndex = 5;
            this.GetIPC202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB202
            // 
            this.GetIPB202.Location = new System.Drawing.Point(151, 181);
            this.GetIPB202.Name = "GetIPB202";
            this.GetIPB202.ReadOnly = true;
            this.GetIPB202.Size = new System.Drawing.Size(28, 20);
            this.GetIPB202.TabIndex = 5;
            this.GetIPB202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA202
            // 
            this.GetIPA202.Location = new System.Drawing.Point(101, 181);
            this.GetIPA202.Name = "GetIPA202";
            this.GetIPA202.ReadOnly = true;
            this.GetIPA202.Size = new System.Drawing.Size(28, 20);
            this.GetIPA202.TabIndex = 5;
            this.GetIPA202.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD201
            // 
            this.GetIPD201.Location = new System.Drawing.Point(251, 157);
            this.GetIPD201.Name = "GetIPD201";
            this.GetIPD201.ReadOnly = true;
            this.GetIPD201.Size = new System.Drawing.Size(28, 20);
            this.GetIPD201.TabIndex = 5;
            this.GetIPD201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC201
            // 
            this.GetIPC201.Location = new System.Drawing.Point(201, 157);
            this.GetIPC201.Name = "GetIPC201";
            this.GetIPC201.ReadOnly = true;
            this.GetIPC201.Size = new System.Drawing.Size(28, 20);
            this.GetIPC201.TabIndex = 5;
            this.GetIPC201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB201
            // 
            this.GetIPB201.Location = new System.Drawing.Point(151, 157);
            this.GetIPB201.Name = "GetIPB201";
            this.GetIPB201.ReadOnly = true;
            this.GetIPB201.Size = new System.Drawing.Size(28, 20);
            this.GetIPB201.TabIndex = 5;
            this.GetIPB201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA201
            // 
            this.GetIPA201.Location = new System.Drawing.Point(101, 157);
            this.GetIPA201.Name = "GetIPA201";
            this.GetIPA201.ReadOnly = true;
            this.GetIPA201.Size = new System.Drawing.Size(28, 20);
            this.GetIPA201.TabIndex = 5;
            this.GetIPA201.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD303
            // 
            this.GetIPD303.Location = new System.Drawing.Point(251, 133);
            this.GetIPD303.Name = "GetIPD303";
            this.GetIPD303.ReadOnly = true;
            this.GetIPD303.Size = new System.Drawing.Size(28, 20);
            this.GetIPD303.TabIndex = 5;
            this.GetIPD303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC303
            // 
            this.GetIPC303.Location = new System.Drawing.Point(201, 133);
            this.GetIPC303.Name = "GetIPC303";
            this.GetIPC303.ReadOnly = true;
            this.GetIPC303.Size = new System.Drawing.Size(28, 20);
            this.GetIPC303.TabIndex = 5;
            this.GetIPC303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB303
            // 
            this.GetIPB303.Location = new System.Drawing.Point(151, 133);
            this.GetIPB303.Name = "GetIPB303";
            this.GetIPB303.ReadOnly = true;
            this.GetIPB303.Size = new System.Drawing.Size(28, 20);
            this.GetIPB303.TabIndex = 5;
            this.GetIPB303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA303
            // 
            this.GetIPA303.Location = new System.Drawing.Point(101, 133);
            this.GetIPA303.Name = "GetIPA303";
            this.GetIPA303.ReadOnly = true;
            this.GetIPA303.Size = new System.Drawing.Size(28, 20);
            this.GetIPA303.TabIndex = 5;
            this.GetIPA303.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD302
            // 
            this.GetIPD302.Location = new System.Drawing.Point(251, 109);
            this.GetIPD302.Name = "GetIPD302";
            this.GetIPD302.ReadOnly = true;
            this.GetIPD302.Size = new System.Drawing.Size(28, 20);
            this.GetIPD302.TabIndex = 5;
            this.GetIPD302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC302
            // 
            this.GetIPC302.Location = new System.Drawing.Point(201, 109);
            this.GetIPC302.Name = "GetIPC302";
            this.GetIPC302.ReadOnly = true;
            this.GetIPC302.Size = new System.Drawing.Size(28, 20);
            this.GetIPC302.TabIndex = 5;
            this.GetIPC302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB302
            // 
            this.GetIPB302.Location = new System.Drawing.Point(151, 109);
            this.GetIPB302.Name = "GetIPB302";
            this.GetIPB302.ReadOnly = true;
            this.GetIPB302.Size = new System.Drawing.Size(28, 20);
            this.GetIPB302.TabIndex = 5;
            this.GetIPB302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA302
            // 
            this.GetIPA302.Location = new System.Drawing.Point(101, 109);
            this.GetIPA302.Name = "GetIPA302";
            this.GetIPA302.ReadOnly = true;
            this.GetIPA302.Size = new System.Drawing.Size(28, 20);
            this.GetIPA302.TabIndex = 5;
            this.GetIPA302.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD301
            // 
            this.GetIPD301.Location = new System.Drawing.Point(251, 85);
            this.GetIPD301.Name = "GetIPD301";
            this.GetIPD301.ReadOnly = true;
            this.GetIPD301.Size = new System.Drawing.Size(28, 20);
            this.GetIPD301.TabIndex = 5;
            this.GetIPD301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC301
            // 
            this.GetIPC301.Location = new System.Drawing.Point(201, 85);
            this.GetIPC301.Name = "GetIPC301";
            this.GetIPC301.ReadOnly = true;
            this.GetIPC301.Size = new System.Drawing.Size(28, 20);
            this.GetIPC301.TabIndex = 5;
            this.GetIPC301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD403
            // 
            this.GetIPD403.Location = new System.Drawing.Point(251, 61);
            this.GetIPD403.Name = "GetIPD403";
            this.GetIPD403.ReadOnly = true;
            this.GetIPD403.Size = new System.Drawing.Size(28, 20);
            this.GetIPD403.TabIndex = 5;
            this.GetIPD403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB301
            // 
            this.GetIPB301.Location = new System.Drawing.Point(151, 85);
            this.GetIPB301.Name = "GetIPB301";
            this.GetIPB301.ReadOnly = true;
            this.GetIPB301.Size = new System.Drawing.Size(28, 20);
            this.GetIPB301.TabIndex = 5;
            this.GetIPB301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC403
            // 
            this.GetIPC403.Location = new System.Drawing.Point(201, 61);
            this.GetIPC403.Name = "GetIPC403";
            this.GetIPC403.ReadOnly = true;
            this.GetIPC403.Size = new System.Drawing.Size(28, 20);
            this.GetIPC403.TabIndex = 5;
            this.GetIPC403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD402
            // 
            this.GetIPD402.Location = new System.Drawing.Point(251, 37);
            this.GetIPD402.Name = "GetIPD402";
            this.GetIPD402.ReadOnly = true;
            this.GetIPD402.Size = new System.Drawing.Size(28, 20);
            this.GetIPD402.TabIndex = 5;
            this.GetIPD402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA301
            // 
            this.GetIPA301.Location = new System.Drawing.Point(101, 85);
            this.GetIPA301.Name = "GetIPA301";
            this.GetIPA301.ReadOnly = true;
            this.GetIPA301.Size = new System.Drawing.Size(28, 20);
            this.GetIPA301.TabIndex = 5;
            this.GetIPA301.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC402
            // 
            this.GetIPC402.Location = new System.Drawing.Point(201, 37);
            this.GetIPC402.Name = "GetIPC402";
            this.GetIPC402.ReadOnly = true;
            this.GetIPC402.Size = new System.Drawing.Size(28, 20);
            this.GetIPC402.TabIndex = 5;
            this.GetIPC402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB403
            // 
            this.GetIPB403.Location = new System.Drawing.Point(151, 61);
            this.GetIPB403.Name = "GetIPB403";
            this.GetIPB403.ReadOnly = true;
            this.GetIPB403.Size = new System.Drawing.Size(28, 20);
            this.GetIPB403.TabIndex = 5;
            this.GetIPB403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPD401
            // 
            this.GetIPD401.Location = new System.Drawing.Point(251, 13);
            this.GetIPD401.Name = "GetIPD401";
            this.GetIPD401.ReadOnly = true;
            this.GetIPD401.Size = new System.Drawing.Size(28, 20);
            this.GetIPD401.TabIndex = 5;
            this.GetIPD401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB402
            // 
            this.GetIPB402.Location = new System.Drawing.Point(151, 37);
            this.GetIPB402.Name = "GetIPB402";
            this.GetIPB402.ReadOnly = true;
            this.GetIPB402.Size = new System.Drawing.Size(28, 20);
            this.GetIPB402.TabIndex = 5;
            this.GetIPB402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPC401
            // 
            this.GetIPC401.Location = new System.Drawing.Point(201, 13);
            this.GetIPC401.Name = "GetIPC401";
            this.GetIPC401.ReadOnly = true;
            this.GetIPC401.Size = new System.Drawing.Size(28, 20);
            this.GetIPC401.TabIndex = 5;
            this.GetIPC401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPA403
            // 
            this.GetIPA403.Location = new System.Drawing.Point(101, 61);
            this.GetIPA403.Name = "GetIPA403";
            this.GetIPA403.ReadOnly = true;
            this.GetIPA403.Size = new System.Drawing.Size(28, 20);
            this.GetIPA403.TabIndex = 5;
            this.GetIPA403.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GetIPB401
            // 
            this.GetIPB401.Location = new System.Drawing.Point(151, 13);
            this.GetIPB401.Name = "GetIPB401";
            this.GetIPB401.ReadOnly = true;
            this.GetIPB401.Size = new System.Drawing.Size(28, 20);
            this.GetIPB401.TabIndex = 5;
            this.GetIPB401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(235, 208);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(10, 13);
            this.label54.TabIndex = 2;
            this.label54.Text = ".";
            // 
            // GetIPA402
            // 
            this.GetIPA402.Location = new System.Drawing.Point(101, 37);
            this.GetIPA402.Name = "GetIPA402";
            this.GetIPA402.ReadOnly = true;
            this.GetIPA402.Size = new System.Drawing.Size(28, 20);
            this.GetIPA402.TabIndex = 5;
            this.GetIPA402.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(185, 208);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(10, 13);
            this.label45.TabIndex = 2;
            this.label45.Text = ".";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(235, 184);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(10, 13);
            this.label53.TabIndex = 2;
            this.label53.Text = ".";
            // 
            // GetIPA401
            // 
            this.GetIPA401.Location = new System.Drawing.Point(101, 13);
            this.GetIPA401.Name = "GetIPA401";
            this.GetIPA401.ReadOnly = true;
            this.GetIPA401.Size = new System.Drawing.Size(28, 20);
            this.GetIPA401.TabIndex = 5;
            this.GetIPA401.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(185, 184);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(10, 13);
            this.label44.TabIndex = 2;
            this.label44.Text = ".";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(235, 160);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(10, 13);
            this.label52.TabIndex = 2;
            this.label52.Text = ".";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(135, 208);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(10, 13);
            this.label36.TabIndex = 2;
            this.label36.Text = ".";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(185, 160);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(10, 13);
            this.label43.TabIndex = 2;
            this.label43.Text = ".";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(235, 136);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(10, 13);
            this.label51.TabIndex = 2;
            this.label51.Text = ".";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(135, 184);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(10, 13);
            this.label35.TabIndex = 2;
            this.label35.Text = ".";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(185, 136);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(10, 13);
            this.label42.TabIndex = 2;
            this.label42.Text = ".";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(235, 112);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(10, 13);
            this.label50.TabIndex = 2;
            this.label50.Text = ".";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(135, 160);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(10, 13);
            this.label34.TabIndex = 2;
            this.label34.Text = ".";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(185, 112);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(10, 13);
            this.label41.TabIndex = 2;
            this.label41.Text = ".";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(235, 88);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(10, 13);
            this.label49.TabIndex = 2;
            this.label49.Text = ".";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(135, 136);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(10, 13);
            this.label33.TabIndex = 2;
            this.label33.Text = ".";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(185, 88);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(10, 13);
            this.label40.TabIndex = 2;
            this.label40.Text = ".";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(235, 64);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(10, 13);
            this.label48.TabIndex = 2;
            this.label48.Text = ".";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(135, 112);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(10, 13);
            this.label32.TabIndex = 2;
            this.label32.Text = ".";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(185, 64);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(10, 13);
            this.label39.TabIndex = 2;
            this.label39.Text = ".";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(235, 40);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(10, 13);
            this.label47.TabIndex = 2;
            this.label47.Text = ".";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(135, 88);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(10, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = ".";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(185, 40);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(10, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = ".";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(235, 16);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(10, 13);
            this.label46.TabIndex = 2;
            this.label46.Text = ".";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(135, 64);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(10, 13);
            this.label30.TabIndex = 2;
            this.label30.Text = ".";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(185, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(10, 13);
            this.label37.TabIndex = 2;
            this.label37.Text = ".";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(135, 40);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(10, 13);
            this.label29.TabIndex = 2;
            this.label29.Text = ".";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(135, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(10, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = ".";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label63.Location = new System.Drawing.Point(285, 208);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(34, 13);
            this.label63.TabIndex = 0;
            this.label63.Text = "Port.";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label62.Location = new System.Drawing.Point(285, 184);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(34, 13);
            this.label62.TabIndex = 0;
            this.label62.Text = "Port.";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label61.Location = new System.Drawing.Point(285, 160);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(34, 13);
            this.label61.TabIndex = 0;
            this.label61.Text = "Port.";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label60.Location = new System.Drawing.Point(285, 136);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(34, 13);
            this.label60.TabIndex = 0;
            this.label60.Text = "Port.";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label59.Location = new System.Drawing.Point(285, 112);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(34, 13);
            this.label59.TabIndex = 0;
            this.label59.Text = "Port.";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label58.Location = new System.Drawing.Point(285, 88);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(34, 13);
            this.label58.TabIndex = 0;
            this.label58.Text = "Port.";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label57.Location = new System.Drawing.Point(285, 64);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(34, 13);
            this.label57.TabIndex = 0;
            this.label57.Text = "Port.";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label56.Location = new System.Drawing.Point(285, 40);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(34, 13);
            this.label56.TabIndex = 0;
            this.label56.Text = "Port.";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label55.Location = new System.Drawing.Point(285, 16);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(34, 13);
            this.label55.TabIndex = 0;
            this.label55.Text = "Port.";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(227, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Get_IP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 290);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Get_IP";
            this.Text = "Get_IP";
            this.Load += new System.EventHandler(this.Get_IP_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label GetStatus401;
        private System.Windows.Forms.Label GetStatus402;
        private System.Windows.Forms.Label GetStatus403;
        private System.Windows.Forms.Label GetStatus301;
        private System.Windows.Forms.Label GetStatus302;
        private System.Windows.Forms.Label GetStatus303;
        private System.Windows.Forms.Label GetStatus201;
        private System.Windows.Forms.Label GetStatus202;
        private System.Windows.Forms.Label GetStatus203;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox GetIPA401;
        private System.Windows.Forms.TextBox GetIPD203;
        private System.Windows.Forms.TextBox GetIPC203;
        private System.Windows.Forms.TextBox GetIPB203;
        private System.Windows.Forms.TextBox GetIPA203;
        private System.Windows.Forms.TextBox GetIPD202;
        private System.Windows.Forms.TextBox GetIPC202;
        private System.Windows.Forms.TextBox GetIPB202;
        private System.Windows.Forms.TextBox GetIPA202;
        private System.Windows.Forms.TextBox GetIPD201;
        private System.Windows.Forms.TextBox GetIPC201;
        private System.Windows.Forms.TextBox GetIPB201;
        private System.Windows.Forms.TextBox GetIPA201;
        private System.Windows.Forms.TextBox GetIPD303;
        private System.Windows.Forms.TextBox GetIPC303;
        private System.Windows.Forms.TextBox GetIPB303;
        private System.Windows.Forms.TextBox GetIPA303;
        private System.Windows.Forms.TextBox GetIPD302;
        private System.Windows.Forms.TextBox GetIPC302;
        private System.Windows.Forms.TextBox GetIPB302;
        private System.Windows.Forms.TextBox GetIPA302;
        private System.Windows.Forms.TextBox GetIPD301;
        private System.Windows.Forms.TextBox GetIPC301;
        private System.Windows.Forms.TextBox GetIPD403;
        private System.Windows.Forms.TextBox GetIPB301;
        private System.Windows.Forms.TextBox GetIPC403;
        private System.Windows.Forms.TextBox GetIPD402;
        private System.Windows.Forms.TextBox GetIPA301;
        private System.Windows.Forms.TextBox GetIPC402;
        private System.Windows.Forms.TextBox GetIPB403;
        private System.Windows.Forms.TextBox GetIPD401;
        private System.Windows.Forms.TextBox GetIPB402;
        private System.Windows.Forms.TextBox GetIPC401;
        private System.Windows.Forms.TextBox GetIPA403;
        private System.Windows.Forms.TextBox GetIPB401;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox GetIPA402;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label37;
        //int strToint(string num);
        
        public string IP401;
        public string IP402;
        public string IP403;
        public string IP301;
        public string IP302;
        public string IP303;
        public string IP201;
        public string IP202;
        public string IP203;
        public string STATUS401;
        public string STATUS402;
        public string STATUS403;
        public string STATUS301;
        public string STATUS302;
        public string STATUS303;
        public string STATUS201;
        public string STATUS202;
        public string STATUS203;
        public string PORT401;
        public string PORT402;
        public string PORT403;
        public string PORT301;
        public string PORT302;
        public string PORT303;
        public string PORT201;
        public string PORT202;
        public string PORT203;
        private System.Windows.Forms.TextBox GETport203;
        private System.Windows.Forms.TextBox GETport202;
        private System.Windows.Forms.TextBox GETport201;
        private System.Windows.Forms.TextBox GETport303;
        private System.Windows.Forms.TextBox GETport302;
        private System.Windows.Forms.TextBox GETport301;
        private System.Windows.Forms.TextBox GETport403;
        private System.Windows.Forms.TextBox GETport402;
        private System.Windows.Forms.TextBox GETport401;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
    }
}