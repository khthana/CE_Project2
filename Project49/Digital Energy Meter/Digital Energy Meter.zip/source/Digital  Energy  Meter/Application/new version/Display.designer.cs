namespace energyApplication
{
    partial class Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Room401_detail = new System.Windows.Forms.Button();
            this.Room401_config = new System.Windows.Forms.Button();
            this.Room401_display = new System.Windows.Forms.TextBox();
            this.Room401 = new System.Windows.Forms.GroupBox();
            this.Room401_connect = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Room401_status = new System.Windows.Forms.Label();
            this.Room402 = new System.Windows.Forms.GroupBox();
            this.Room402_connect = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Room402_status = new System.Windows.Forms.Label();
            this.Room402_display = new System.Windows.Forms.TextBox();
            this.Room402_config = new System.Windows.Forms.Button();
            this.Room402_detail = new System.Windows.Forms.Button();
            this.Room403 = new System.Windows.Forms.GroupBox();
            this.Room403_connect = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Room403_status = new System.Windows.Forms.Label();
            this.Room403_display = new System.Windows.Forms.TextBox();
            this.Room403_config = new System.Windows.Forms.Button();
            this.Room403_detail = new System.Windows.Forms.Button();
            this.Room301 = new System.Windows.Forms.GroupBox();
            this.Room301_connect = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Room301_status = new System.Windows.Forms.Label();
            this.Room301_display = new System.Windows.Forms.TextBox();
            this.Room301_config = new System.Windows.Forms.Button();
            this.Room301_detail = new System.Windows.Forms.Button();
            this.Room302 = new System.Windows.Forms.GroupBox();
            this.Room302_connect = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Room302_status = new System.Windows.Forms.Label();
            this.Room302_display = new System.Windows.Forms.TextBox();
            this.Room302_config = new System.Windows.Forms.Button();
            this.Room302_detail = new System.Windows.Forms.Button();
            this.Room303 = new System.Windows.Forms.GroupBox();
            this.Room303_connect = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Room303_status = new System.Windows.Forms.Label();
            this.Room303_display = new System.Windows.Forms.TextBox();
            this.Room303_config = new System.Windows.Forms.Button();
            this.Room303_detail = new System.Windows.Forms.Button();
            this.Room201 = new System.Windows.Forms.GroupBox();
            this.Room201_connect = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Room201_status = new System.Windows.Forms.Label();
            this.Room201_display = new System.Windows.Forms.TextBox();
            this.Room201_config = new System.Windows.Forms.Button();
            this.Room201_detail = new System.Windows.Forms.Button();
            this.Room202 = new System.Windows.Forms.GroupBox();
            this.Room202_connect = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Room202_status = new System.Windows.Forms.Label();
            this.Room202_display = new System.Windows.Forms.TextBox();
            this.Room202_config = new System.Windows.Forms.Button();
            this.Room202_detail = new System.Windows.Forms.Button();
            this.Room203 = new System.Windows.Forms.GroupBox();
            this.Room203_connect = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Room203_status = new System.Windows.Forms.Label();
            this.Room203_display = new System.Windows.Forms.TextBox();
            this.Room203_config = new System.Windows.Forms.Button();
            this.Room203_detail = new System.Windows.Forms.Button();
            this.Run_energy = new System.Windows.Forms.Button();
            this.Stop_energy = new System.Windows.Forms.Button();
            this.Room401.SuspendLayout();
            this.Room402.SuspendLayout();
            this.Room403.SuspendLayout();
            this.Room301.SuspendLayout();
            this.Room302.SuspendLayout();
            this.Room303.SuspendLayout();
            this.Room201.SuspendLayout();
            this.Room202.SuspendLayout();
            this.Room203.SuspendLayout();
            this.SuspendLayout();
            // 
            // Room401_detail
            // 
            this.Room401_detail.Location = new System.Drawing.Point(18, 68);
            this.Room401_detail.Name = "Room401_detail";
            this.Room401_detail.Size = new System.Drawing.Size(45, 23);
            this.Room401_detail.TabIndex = 0;
            this.Room401_detail.Text = "detail";
            this.Room401_detail.UseVisualStyleBackColor = true;
            this.Room401_detail.Click += new System.EventHandler(this.Room401_detail_Click);
            // 
            // Room401_config
            // 
            this.Room401_config.Location = new System.Drawing.Point(69, 68);
            this.Room401_config.Name = "Room401_config";
            this.Room401_config.Size = new System.Drawing.Size(45, 23);
            this.Room401_config.TabIndex = 1;
            this.Room401_config.Text = "config";
            this.Room401_config.UseVisualStyleBackColor = true;
            this.Room401_config.Click += new System.EventHandler(this.Room401_config_Click);
            // 
            // Room401_display
            // 
            this.Room401_display.Location = new System.Drawing.Point(18, 27);
            this.Room401_display.Name = "Room401_display";
            this.Room401_display.ReadOnly = true;
            this.Room401_display.Size = new System.Drawing.Size(96, 20);
            this.Room401_display.TabIndex = 2;
            this.Room401_display.Text = "0000.0";
            this.Room401_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room401
            // 
            this.Room401.Controls.Add(this.Room401_connect);
            this.Room401.Controls.Add(this.label1);
            this.Room401.Controls.Add(this.Room401_status);
            this.Room401.Controls.Add(this.Room401_display);
            this.Room401.Controls.Add(this.Room401_config);
            this.Room401.Controls.Add(this.Room401_detail);
            this.Room401.Location = new System.Drawing.Point(14, 12);
            this.Room401.Name = "Room401";
            this.Room401.Size = new System.Drawing.Size(135, 132);
            this.Room401.TabIndex = 3;
            this.Room401.TabStop = false;
            this.Room401.Text = "Room401";
            // 
            // Room401_connect
            // 
            this.Room401_connect.AutoSize = true;
            this.Room401_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room401_connect.Location = new System.Drawing.Point(15, 116);
            this.Room401_connect.Name = "Room401_connect";
            this.Room401_connect.Size = new System.Drawing.Size(38, 13);
            this.Room401_connect.TabIndex = 3;
            this.Room401_connect.Text = "Ready";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(15, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Status>";
            // 
            // Room401_status
            // 
            this.Room401_status.AutoSize = true;
            this.Room401_status.ForeColor = System.Drawing.Color.Red;
            this.Room401_status.Location = new System.Drawing.Point(71, 94);
            this.Room401_status.Name = "Room401_status";
            this.Room401_status.Size = new System.Drawing.Size(45, 13);
            this.Room401_status.TabIndex = 3;
            this.Room401_status.Text = "Inactive";
            // 
            // Room402
            // 
            this.Room402.Controls.Add(this.Room402_connect);
            this.Room402.Controls.Add(this.label2);
            this.Room402.Controls.Add(this.Room402_status);
            this.Room402.Controls.Add(this.Room402_display);
            this.Room402.Controls.Add(this.Room402_config);
            this.Room402.Controls.Add(this.Room402_detail);
            this.Room402.Location = new System.Drawing.Point(155, 12);
            this.Room402.Name = "Room402";
            this.Room402.Size = new System.Drawing.Size(135, 132);
            this.Room402.TabIndex = 4;
            this.Room402.TabStop = false;
            this.Room402.Text = "Room402";
            // 
            // Room402_connect
            // 
            this.Room402_connect.AutoSize = true;
            this.Room402_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room402_connect.Location = new System.Drawing.Point(15, 116);
            this.Room402_connect.Name = "Room402_connect";
            this.Room402_connect.Size = new System.Drawing.Size(38, 13);
            this.Room402_connect.TabIndex = 3;
            this.Room402_connect.Text = "Ready";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(15, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Status>";
            // 
            // Room402_status
            // 
            this.Room402_status.AutoSize = true;
            this.Room402_status.ForeColor = System.Drawing.Color.Red;
            this.Room402_status.Location = new System.Drawing.Point(71, 94);
            this.Room402_status.Name = "Room402_status";
            this.Room402_status.Size = new System.Drawing.Size(45, 13);
            this.Room402_status.TabIndex = 3;
            this.Room402_status.Text = "Inactive";
            // 
            // Room402_display
            // 
            this.Room402_display.Location = new System.Drawing.Point(18, 27);
            this.Room402_display.Name = "Room402_display";
            this.Room402_display.ReadOnly = true;
            this.Room402_display.Size = new System.Drawing.Size(96, 20);
            this.Room402_display.TabIndex = 2;
            this.Room402_display.Text = "0000.0";
            this.Room402_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room402_config
            // 
            this.Room402_config.Location = new System.Drawing.Point(69, 68);
            this.Room402_config.Name = "Room402_config";
            this.Room402_config.Size = new System.Drawing.Size(45, 23);
            this.Room402_config.TabIndex = 1;
            this.Room402_config.Text = "config";
            this.Room402_config.UseVisualStyleBackColor = true;
            this.Room402_config.Click += new System.EventHandler(this.Room402_cofig_Click);
            // 
            // Room402_detail
            // 
            this.Room402_detail.Location = new System.Drawing.Point(18, 68);
            this.Room402_detail.Name = "Room402_detail";
            this.Room402_detail.Size = new System.Drawing.Size(45, 23);
            this.Room402_detail.TabIndex = 0;
            this.Room402_detail.Text = "detail";
            this.Room402_detail.UseVisualStyleBackColor = true;
            this.Room402_detail.Click += new System.EventHandler(this.Room402_detail_Click);
            // 
            // Room403
            // 
            this.Room403.Controls.Add(this.Room403_connect);
            this.Room403.Controls.Add(this.label3);
            this.Room403.Controls.Add(this.Room403_status);
            this.Room403.Controls.Add(this.Room403_display);
            this.Room403.Controls.Add(this.Room403_config);
            this.Room403.Controls.Add(this.Room403_detail);
            this.Room403.Location = new System.Drawing.Point(296, 12);
            this.Room403.Name = "Room403";
            this.Room403.Size = new System.Drawing.Size(135, 132);
            this.Room403.TabIndex = 4;
            this.Room403.TabStop = false;
            this.Room403.Text = "Room403";
            // 
            // Room403_connect
            // 
            this.Room403_connect.AutoSize = true;
            this.Room403_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room403_connect.Location = new System.Drawing.Point(15, 116);
            this.Room403_connect.Name = "Room403_connect";
            this.Room403_connect.Size = new System.Drawing.Size(38, 13);
            this.Room403_connect.TabIndex = 3;
            this.Room403_connect.Text = "Ready";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(15, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Status>";
            // 
            // Room403_status
            // 
            this.Room403_status.AutoSize = true;
            this.Room403_status.ForeColor = System.Drawing.Color.Red;
            this.Room403_status.Location = new System.Drawing.Point(71, 94);
            this.Room403_status.Name = "Room403_status";
            this.Room403_status.Size = new System.Drawing.Size(45, 13);
            this.Room403_status.TabIndex = 3;
            this.Room403_status.Text = "Inactive";
            // 
            // Room403_display
            // 
            this.Room403_display.Location = new System.Drawing.Point(18, 27);
            this.Room403_display.Name = "Room403_display";
            this.Room403_display.ReadOnly = true;
            this.Room403_display.Size = new System.Drawing.Size(96, 20);
            this.Room403_display.TabIndex = 2;
            this.Room403_display.Text = "0000.0";
            this.Room403_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room403_config
            // 
            this.Room403_config.Location = new System.Drawing.Point(69, 68);
            this.Room403_config.Name = "Room403_config";
            this.Room403_config.Size = new System.Drawing.Size(45, 23);
            this.Room403_config.TabIndex = 1;
            this.Room403_config.Text = "config";
            this.Room403_config.UseVisualStyleBackColor = true;
            this.Room403_config.Click += new System.EventHandler(this.Room403_config_Click);
            // 
            // Room403_detail
            // 
            this.Room403_detail.Location = new System.Drawing.Point(18, 68);
            this.Room403_detail.Name = "Room403_detail";
            this.Room403_detail.Size = new System.Drawing.Size(45, 23);
            this.Room403_detail.TabIndex = 0;
            this.Room403_detail.Text = "detail";
            this.Room403_detail.UseVisualStyleBackColor = true;
            this.Room403_detail.Click += new System.EventHandler(this.Room403_detail_Click);
            // 
            // Room301
            // 
            this.Room301.Controls.Add(this.Room301_connect);
            this.Room301.Controls.Add(this.label4);
            this.Room301.Controls.Add(this.Room301_status);
            this.Room301.Controls.Add(this.Room301_display);
            this.Room301.Controls.Add(this.Room301_config);
            this.Room301.Controls.Add(this.Room301_detail);
            this.Room301.Location = new System.Drawing.Point(14, 150);
            this.Room301.Name = "Room301";
            this.Room301.Size = new System.Drawing.Size(135, 132);
            this.Room301.TabIndex = 4;
            this.Room301.TabStop = false;
            this.Room301.Text = "Room301";
            // 
            // Room301_connect
            // 
            this.Room301_connect.AutoSize = true;
            this.Room301_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room301_connect.Location = new System.Drawing.Point(15, 116);
            this.Room301_connect.Name = "Room301_connect";
            this.Room301_connect.Size = new System.Drawing.Size(38, 13);
            this.Room301_connect.TabIndex = 5;
            this.Room301_connect.Text = "Ready";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label4.Location = new System.Drawing.Point(15, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Status>";
            // 
            // Room301_status
            // 
            this.Room301_status.AutoSize = true;
            this.Room301_status.ForeColor = System.Drawing.Color.Red;
            this.Room301_status.Location = new System.Drawing.Point(71, 94);
            this.Room301_status.Name = "Room301_status";
            this.Room301_status.Size = new System.Drawing.Size(45, 13);
            this.Room301_status.TabIndex = 3;
            this.Room301_status.Text = "Inactive";
            // 
            // Room301_display
            // 
            this.Room301_display.Location = new System.Drawing.Point(18, 27);
            this.Room301_display.Name = "Room301_display";
            this.Room301_display.ReadOnly = true;
            this.Room301_display.Size = new System.Drawing.Size(96, 20);
            this.Room301_display.TabIndex = 2;
            this.Room301_display.Text = "0000.0";
            this.Room301_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room301_config
            // 
            this.Room301_config.Location = new System.Drawing.Point(69, 68);
            this.Room301_config.Name = "Room301_config";
            this.Room301_config.Size = new System.Drawing.Size(45, 23);
            this.Room301_config.TabIndex = 1;
            this.Room301_config.Text = "config";
            this.Room301_config.UseVisualStyleBackColor = true;
            this.Room301_config.Click += new System.EventHandler(this.Room301_config_Click);
            // 
            // Room301_detail
            // 
            this.Room301_detail.Location = new System.Drawing.Point(18, 68);
            this.Room301_detail.Name = "Room301_detail";
            this.Room301_detail.Size = new System.Drawing.Size(45, 23);
            this.Room301_detail.TabIndex = 0;
            this.Room301_detail.Text = "detail";
            this.Room301_detail.UseVisualStyleBackColor = true;
            this.Room301_detail.Click += new System.EventHandler(this.Room301_detail_Click);
            // 
            // Room302
            // 
            this.Room302.Controls.Add(this.Room302_connect);
            this.Room302.Controls.Add(this.label5);
            this.Room302.Controls.Add(this.Room302_status);
            this.Room302.Controls.Add(this.Room302_display);
            this.Room302.Controls.Add(this.Room302_config);
            this.Room302.Controls.Add(this.Room302_detail);
            this.Room302.Location = new System.Drawing.Point(155, 150);
            this.Room302.Name = "Room302";
            this.Room302.Size = new System.Drawing.Size(135, 132);
            this.Room302.TabIndex = 4;
            this.Room302.TabStop = false;
            this.Room302.Text = "Room302";
            // 
            // Room302_connect
            // 
            this.Room302_connect.AutoSize = true;
            this.Room302_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room302_connect.Location = new System.Drawing.Point(15, 116);
            this.Room302_connect.Name = "Room302_connect";
            this.Room302_connect.Size = new System.Drawing.Size(38, 13);
            this.Room302_connect.TabIndex = 7;
            this.Room302_connect.Text = "Ready";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label5.Location = new System.Drawing.Point(15, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Status>";
            // 
            // Room302_status
            // 
            this.Room302_status.AutoSize = true;
            this.Room302_status.ForeColor = System.Drawing.Color.Red;
            this.Room302_status.Location = new System.Drawing.Point(71, 94);
            this.Room302_status.Name = "Room302_status";
            this.Room302_status.Size = new System.Drawing.Size(45, 13);
            this.Room302_status.TabIndex = 3;
            this.Room302_status.Text = "Inactive";
            // 
            // Room302_display
            // 
            this.Room302_display.Location = new System.Drawing.Point(18, 27);
            this.Room302_display.Name = "Room302_display";
            this.Room302_display.ReadOnly = true;
            this.Room302_display.Size = new System.Drawing.Size(96, 20);
            this.Room302_display.TabIndex = 2;
            this.Room302_display.Text = "0000.0";
            this.Room302_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room302_config
            // 
            this.Room302_config.Location = new System.Drawing.Point(69, 68);
            this.Room302_config.Name = "Room302_config";
            this.Room302_config.Size = new System.Drawing.Size(45, 23);
            this.Room302_config.TabIndex = 1;
            this.Room302_config.Text = "config";
            this.Room302_config.UseVisualStyleBackColor = true;
            this.Room302_config.Click += new System.EventHandler(this.Room302_config_Click);
            // 
            // Room302_detail
            // 
            this.Room302_detail.Location = new System.Drawing.Point(18, 68);
            this.Room302_detail.Name = "Room302_detail";
            this.Room302_detail.Size = new System.Drawing.Size(45, 23);
            this.Room302_detail.TabIndex = 0;
            this.Room302_detail.Text = "detail";
            this.Room302_detail.UseVisualStyleBackColor = true;
            this.Room302_detail.Click += new System.EventHandler(this.Room302_detail_Click);
            // 
            // Room303
            // 
            this.Room303.Controls.Add(this.Room303_connect);
            this.Room303.Controls.Add(this.label6);
            this.Room303.Controls.Add(this.Room303_status);
            this.Room303.Controls.Add(this.Room303_display);
            this.Room303.Controls.Add(this.Room303_config);
            this.Room303.Controls.Add(this.Room303_detail);
            this.Room303.Location = new System.Drawing.Point(296, 150);
            this.Room303.Name = "Room303";
            this.Room303.Size = new System.Drawing.Size(135, 132);
            this.Room303.TabIndex = 4;
            this.Room303.TabStop = false;
            this.Room303.Text = "Room303";
            // 
            // Room303_connect
            // 
            this.Room303_connect.AutoSize = true;
            this.Room303_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room303_connect.Location = new System.Drawing.Point(15, 116);
            this.Room303_connect.Name = "Room303_connect";
            this.Room303_connect.Size = new System.Drawing.Size(38, 13);
            this.Room303_connect.TabIndex = 9;
            this.Room303_connect.Text = "Ready";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label6.Location = new System.Drawing.Point(15, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Status>";
            // 
            // Room303_status
            // 
            this.Room303_status.AutoSize = true;
            this.Room303_status.ForeColor = System.Drawing.Color.Red;
            this.Room303_status.Location = new System.Drawing.Point(71, 94);
            this.Room303_status.Name = "Room303_status";
            this.Room303_status.Size = new System.Drawing.Size(45, 13);
            this.Room303_status.TabIndex = 3;
            this.Room303_status.Text = "Inactive";
            // 
            // Room303_display
            // 
            this.Room303_display.Location = new System.Drawing.Point(18, 27);
            this.Room303_display.Name = "Room303_display";
            this.Room303_display.ReadOnly = true;
            this.Room303_display.Size = new System.Drawing.Size(96, 20);
            this.Room303_display.TabIndex = 2;
            this.Room303_display.Text = "0000.0";
            this.Room303_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room303_config
            // 
            this.Room303_config.Location = new System.Drawing.Point(69, 68);
            this.Room303_config.Name = "Room303_config";
            this.Room303_config.Size = new System.Drawing.Size(45, 23);
            this.Room303_config.TabIndex = 1;
            this.Room303_config.Text = "config";
            this.Room303_config.UseVisualStyleBackColor = true;
            this.Room303_config.Click += new System.EventHandler(this.Room303_config_Click);
            // 
            // Room303_detail
            // 
            this.Room303_detail.Location = new System.Drawing.Point(18, 68);
            this.Room303_detail.Name = "Room303_detail";
            this.Room303_detail.Size = new System.Drawing.Size(45, 23);
            this.Room303_detail.TabIndex = 0;
            this.Room303_detail.Text = "detail";
            this.Room303_detail.UseVisualStyleBackColor = true;
            this.Room303_detail.Click += new System.EventHandler(this.Room303_detail_Click);
            // 
            // Room201
            // 
            this.Room201.Controls.Add(this.Room201_connect);
            this.Room201.Controls.Add(this.label7);
            this.Room201.Controls.Add(this.Room201_status);
            this.Room201.Controls.Add(this.Room201_display);
            this.Room201.Controls.Add(this.Room201_config);
            this.Room201.Controls.Add(this.Room201_detail);
            this.Room201.Location = new System.Drawing.Point(14, 288);
            this.Room201.Name = "Room201";
            this.Room201.Size = new System.Drawing.Size(135, 132);
            this.Room201.TabIndex = 0;
            this.Room201.TabStop = false;
            this.Room201.Text = "Room201";
            // 
            // Room201_connect
            // 
            this.Room201_connect.AutoSize = true;
            this.Room201_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room201_connect.Location = new System.Drawing.Point(15, 116);
            this.Room201_connect.Name = "Room201_connect";
            this.Room201_connect.Size = new System.Drawing.Size(38, 13);
            this.Room201_connect.TabIndex = 11;
            this.Room201_connect.Text = "Ready";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label7.Location = new System.Drawing.Point(15, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Status>";
            // 
            // Room201_status
            // 
            this.Room201_status.AutoSize = true;
            this.Room201_status.ForeColor = System.Drawing.Color.Red;
            this.Room201_status.Location = new System.Drawing.Point(71, 94);
            this.Room201_status.Name = "Room201_status";
            this.Room201_status.Size = new System.Drawing.Size(45, 13);
            this.Room201_status.TabIndex = 3;
            this.Room201_status.Text = "Inactive";
            // 
            // Room201_display
            // 
            this.Room201_display.Location = new System.Drawing.Point(18, 27);
            this.Room201_display.Name = "Room201_display";
            this.Room201_display.ReadOnly = true;
            this.Room201_display.Size = new System.Drawing.Size(96, 20);
            this.Room201_display.TabIndex = 2;
            this.Room201_display.Text = "0000.0";
            this.Room201_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room201_config
            // 
            this.Room201_config.Location = new System.Drawing.Point(69, 68);
            this.Room201_config.Name = "Room201_config";
            this.Room201_config.Size = new System.Drawing.Size(45, 23);
            this.Room201_config.TabIndex = 1;
            this.Room201_config.Text = "config";
            this.Room201_config.UseVisualStyleBackColor = true;
            this.Room201_config.Click += new System.EventHandler(this.Room201_config_Click);
            // 
            // Room201_detail
            // 
            this.Room201_detail.Location = new System.Drawing.Point(18, 68);
            this.Room201_detail.Name = "Room201_detail";
            this.Room201_detail.Size = new System.Drawing.Size(45, 23);
            this.Room201_detail.TabIndex = 0;
            this.Room201_detail.Text = "detail";
            this.Room201_detail.UseVisualStyleBackColor = true;
            this.Room201_detail.Click += new System.EventHandler(this.Room201_detail_Click);
            // 
            // Room202
            // 
            this.Room202.Controls.Add(this.Room202_connect);
            this.Room202.Controls.Add(this.label8);
            this.Room202.Controls.Add(this.Room202_status);
            this.Room202.Controls.Add(this.Room202_display);
            this.Room202.Controls.Add(this.Room202_config);
            this.Room202.Controls.Add(this.Room202_detail);
            this.Room202.Location = new System.Drawing.Point(155, 288);
            this.Room202.Name = "Room202";
            this.Room202.Size = new System.Drawing.Size(135, 132);
            this.Room202.TabIndex = 4;
            this.Room202.TabStop = false;
            this.Room202.Text = "Room202";
            // 
            // Room202_connect
            // 
            this.Room202_connect.AutoSize = true;
            this.Room202_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room202_connect.Location = new System.Drawing.Point(15, 116);
            this.Room202_connect.Name = "Room202_connect";
            this.Room202_connect.Size = new System.Drawing.Size(38, 13);
            this.Room202_connect.TabIndex = 13;
            this.Room202_connect.Text = "Ready";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label8.Location = new System.Drawing.Point(15, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Status>";
            // 
            // Room202_status
            // 
            this.Room202_status.AutoSize = true;
            this.Room202_status.ForeColor = System.Drawing.Color.Red;
            this.Room202_status.Location = new System.Drawing.Point(71, 94);
            this.Room202_status.Name = "Room202_status";
            this.Room202_status.Size = new System.Drawing.Size(45, 13);
            this.Room202_status.TabIndex = 3;
            this.Room202_status.Text = "Inactive";
            // 
            // Room202_display
            // 
            this.Room202_display.Location = new System.Drawing.Point(18, 27);
            this.Room202_display.Name = "Room202_display";
            this.Room202_display.ReadOnly = true;
            this.Room202_display.Size = new System.Drawing.Size(96, 20);
            this.Room202_display.TabIndex = 2;
            this.Room202_display.Text = "0000.0";
            this.Room202_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room202_config
            // 
            this.Room202_config.Location = new System.Drawing.Point(69, 68);
            this.Room202_config.Name = "Room202_config";
            this.Room202_config.Size = new System.Drawing.Size(45, 23);
            this.Room202_config.TabIndex = 1;
            this.Room202_config.Text = "config";
            this.Room202_config.UseVisualStyleBackColor = true;
            this.Room202_config.Click += new System.EventHandler(this.Room202_config_Click);
            // 
            // Room202_detail
            // 
            this.Room202_detail.Location = new System.Drawing.Point(18, 68);
            this.Room202_detail.Name = "Room202_detail";
            this.Room202_detail.Size = new System.Drawing.Size(45, 23);
            this.Room202_detail.TabIndex = 0;
            this.Room202_detail.Text = "detail";
            this.Room202_detail.UseVisualStyleBackColor = true;
            this.Room202_detail.Click += new System.EventHandler(this.Room202_detail_Click);
            // 
            // Room203
            // 
            this.Room203.Controls.Add(this.Room203_connect);
            this.Room203.Controls.Add(this.label9);
            this.Room203.Controls.Add(this.Room203_status);
            this.Room203.Controls.Add(this.Room203_display);
            this.Room203.Controls.Add(this.Room203_config);
            this.Room203.Controls.Add(this.Room203_detail);
            this.Room203.Location = new System.Drawing.Point(296, 288);
            this.Room203.Name = "Room203";
            this.Room203.Size = new System.Drawing.Size(135, 132);
            this.Room203.TabIndex = 4;
            this.Room203.TabStop = false;
            this.Room203.Text = "Room203";
            // 
            // Room203_connect
            // 
            this.Room203_connect.AutoSize = true;
            this.Room203_connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Room203_connect.Location = new System.Drawing.Point(15, 116);
            this.Room203_connect.Name = "Room203_connect";
            this.Room203_connect.Size = new System.Drawing.Size(38, 13);
            this.Room203_connect.TabIndex = 15;
            this.Room203_connect.Text = "Ready";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label9.Location = new System.Drawing.Point(15, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Status>";
            // 
            // Room203_status
            // 
            this.Room203_status.AutoSize = true;
            this.Room203_status.ForeColor = System.Drawing.Color.Red;
            this.Room203_status.Location = new System.Drawing.Point(71, 94);
            this.Room203_status.Name = "Room203_status";
            this.Room203_status.Size = new System.Drawing.Size(45, 13);
            this.Room203_status.TabIndex = 3;
            this.Room203_status.Text = "Inactive";
            // 
            // Room203_display
            // 
            this.Room203_display.Location = new System.Drawing.Point(18, 27);
            this.Room203_display.Name = "Room203_display";
            this.Room203_display.ReadOnly = true;
            this.Room203_display.Size = new System.Drawing.Size(96, 20);
            this.Room203_display.TabIndex = 2;
            this.Room203_display.Text = "0000.0";
            this.Room203_display.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Room203_config
            // 
            this.Room203_config.Location = new System.Drawing.Point(69, 68);
            this.Room203_config.Name = "Room203_config";
            this.Room203_config.Size = new System.Drawing.Size(45, 23);
            this.Room203_config.TabIndex = 1;
            this.Room203_config.Text = "config";
            this.Room203_config.UseVisualStyleBackColor = true;
            this.Room203_config.Click += new System.EventHandler(this.Room203_config_Click);
            // 
            // Room203_detail
            // 
            this.Room203_detail.Location = new System.Drawing.Point(18, 68);
            this.Room203_detail.Name = "Room203_detail";
            this.Room203_detail.Size = new System.Drawing.Size(45, 23);
            this.Room203_detail.TabIndex = 0;
            this.Room203_detail.Text = "detail";
            this.Room203_detail.UseVisualStyleBackColor = true;
            this.Room203_detail.Click += new System.EventHandler(this.Room203_detail_Click);
            // 
            // Run_energy
            // 
            this.Run_energy.Location = new System.Drawing.Point(143, 440);
            this.Run_energy.Name = "Run_energy";
            this.Run_energy.Size = new System.Drawing.Size(75, 23);
            this.Run_energy.TabIndex = 5;
            this.Run_energy.Text = "Run";
            this.Run_energy.UseVisualStyleBackColor = true;
            this.Run_energy.Click += new System.EventHandler(this.Run_energy_Click);
            // 
            // Stop_energy
            // 
            this.Stop_energy.Enabled = false;
            this.Stop_energy.Location = new System.Drawing.Point(224, 440);
            this.Stop_energy.Name = "Stop_energy";
            this.Stop_energy.Size = new System.Drawing.Size(75, 23);
            this.Stop_energy.TabIndex = 6;
            this.Stop_energy.Text = "Stop";
            this.Stop_energy.UseVisualStyleBackColor = true;
            this.Stop_energy.Click += new System.EventHandler(this.Stop_energy_Click);
            // 
            // Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 487);
            this.Controls.Add(this.Stop_energy);
            this.Controls.Add(this.Run_energy);
            this.Controls.Add(this.Room203);
            this.Controls.Add(this.Room202);
            this.Controls.Add(this.Room201);
            this.Controls.Add(this.Room303);
            this.Controls.Add(this.Room302);
            this.Controls.Add(this.Room301);
            this.Controls.Add(this.Room403);
            this.Controls.Add(this.Room402);
            this.Controls.Add(this.Room401);
            this.Name = "Display";
            this.Text = "Energy Meter Digital";
            this.Load += new System.EventHandler(this.Display_Load);
            this.Room401.ResumeLayout(false);
            this.Room401.PerformLayout();
            this.Room402.ResumeLayout(false);
            this.Room402.PerformLayout();
            this.Room403.ResumeLayout(false);
            this.Room403.PerformLayout();
            this.Room301.ResumeLayout(false);
            this.Room301.PerformLayout();
            this.Room302.ResumeLayout(false);
            this.Room302.PerformLayout();
            this.Room303.ResumeLayout(false);
            this.Room303.PerformLayout();
            this.Room201.ResumeLayout(false);
            this.Room201.PerformLayout();
            this.Room202.ResumeLayout(false);
            this.Room202.PerformLayout();
            this.Room203.ResumeLayout(false);
            this.Room203.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Room401_detail;
        private System.Windows.Forms.Button Room401_config;
        private System.Windows.Forms.TextBox Room401_display;
        private System.Windows.Forms.GroupBox Room401;
        private System.Windows.Forms.Label Room401_status;
        private System.Windows.Forms.GroupBox Room402;
        private System.Windows.Forms.Label Room402_status;
        private System.Windows.Forms.TextBox Room402_display;
        private System.Windows.Forms.Button Room402_config;
        private System.Windows.Forms.Button Room402_detail;
        private System.Windows.Forms.GroupBox Room403;
        private System.Windows.Forms.Label Room403_status;
        private System.Windows.Forms.TextBox Room403_display;
        private System.Windows.Forms.Button Room403_config;
        private System.Windows.Forms.Button Room403_detail;
        private System.Windows.Forms.GroupBox Room301;
        private System.Windows.Forms.Label Room301_status;
        private System.Windows.Forms.TextBox Room301_display;
        private System.Windows.Forms.Button Room301_config;
        private System.Windows.Forms.Button Room301_detail;
        private System.Windows.Forms.GroupBox Room302;
        private System.Windows.Forms.Label Room302_status;
        private System.Windows.Forms.TextBox Room302_display;
        private System.Windows.Forms.Button Room302_config;
        private System.Windows.Forms.Button Room302_detail;
        private System.Windows.Forms.GroupBox Room303;
        private System.Windows.Forms.Label Room303_status;
        private System.Windows.Forms.TextBox Room303_display;
        private System.Windows.Forms.Button Room303_config;
        private System.Windows.Forms.Button Room303_detail;
        private System.Windows.Forms.GroupBox Room201;
        private System.Windows.Forms.Label Room201_status;
        private System.Windows.Forms.TextBox Room201_display;
        private System.Windows.Forms.Button Room201_config;
        private System.Windows.Forms.Button Room201_detail;
        private System.Windows.Forms.GroupBox Room202;
        private System.Windows.Forms.Label Room202_status;
        private System.Windows.Forms.TextBox Room202_display;
        private System.Windows.Forms.Button Room202_config;
        private System.Windows.Forms.Button Room202_detail;
        private System.Windows.Forms.GroupBox Room203;
        private System.Windows.Forms.Label Room203_status;
        private System.Windows.Forms.TextBox Room203_display;
        private System.Windows.Forms.Button Room203_config;
        private System.Windows.Forms.Button Room203_detail;
        private System.Windows.Forms.Button Run_energy;
        private System.Windows.Forms.Button Stop_energy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Room401_connect;
        private System.Windows.Forms.Label Room402_connect;
        private System.Windows.Forms.Label Room403_connect;
        private System.Windows.Forms.Label Room301_connect;
        private System.Windows.Forms.Label Room302_connect;
        private System.Windows.Forms.Label Room303_connect;
        private System.Windows.Forms.Label Room201_connect;
        private System.Windows.Forms.Label Room202_connect;
        private System.Windows.Forms.Label Room203_connect;
        private string IP401;
        private string IP402;
        private string IP403;
        private string IP301;
        private string IP302;
        private string IP303;
        private string IP201;
        private string IP202;
        private string IP203;
        private int port401;
        private int port402; 
        private int port403; 
        private int port301; 
        private int port302; 
        private int port303; 
        private int port201; 
        private int port202; 
        private int port203;
        private bool loop_401 = true;
        private bool loop_402 = true;
        private bool loop_403 = true;
        private bool loop_301 = true;
        private bool loop_302 = true;
        private bool loop_303 = true;
        private bool loop_201 = true;
        private bool loop_202 = true;
        private bool loop_203 = true;
    }
}

