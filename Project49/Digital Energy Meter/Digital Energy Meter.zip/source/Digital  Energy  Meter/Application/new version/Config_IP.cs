using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace energyApplication
{
    public partial class Config_IP : Form
    {
        Display a = new Display();
        private string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=�;ѡ.mdb";
        private OleDbConnection Conn = new OleDbConnection();
        private int Effect = 0;

        public Config_IP(string a)
        {
            InitializeComponent();
            room_number = a;
        }
        private OleDbDataAdapter daRoom;
        private DataSet ds = new DataSet();
        private void Config_IP_Load(object sender, EventArgs e)
        {
            string sqlRoom = "SELECT * FROM ��ͧ���";
            try
            {
                if (Conn.State == ConnectionState.Open)
                {
                    Conn.Close();
                }
                Conn.ConnectionString = strConn;
                Conn.Open();

                daRoom = new OleDbDataAdapter(sqlRoom, Conn);
                daRoom.Fill(ds, "��ͧ���");

                DataViewManager dvm = new DataViewManager();
                dvm.DataSet = ds;
                DataViewSetting dvs;
                dvs = dvm.DataViewSettings["��ͧ���"];
                dvs.RowFilter = "��ͧ='" + room_number + "'";

                IP_status.DataBindings.Add("Text", dvm, "��ͧ���.ʶҹ�");
                if (IP_status.Text == "Connecting")
                {
                    enable_check.Checked = true;
                }
            }
            catch (Exception errToAccess)
            {
                MessageBox.Show("�������ö��ҹ�������� ���ͧ�ҡ " + errToAccess.Message, "��ͼԴ��Ҵ");
            }
            finally
            {
                Conn.Close();
            }
        }

        private void enable_check_CheckedChanged(object sender, EventArgs e)
        {
            if (enable_check.Checked == true)
            {
                IP_address.Enabled = true;        
                IP_A.Enabled = true;
                IP_B.Enabled = true;
                IP_C.Enabled = true;
                IP_D.Enabled = true;
                Portname.Enabled = true;
                port.Enabled = true;

                string sqlRoom = "SELECT * FROM ��ͧ���";
                try
                {
                    if (Conn.State == ConnectionState.Open)
                    {
                        Conn.Close();
                    }
                    Conn.ConnectionString = strConn;
                    Conn.Open();

                    daRoom = new OleDbDataAdapter(sqlRoom, Conn);
                    daRoom.Fill(ds, "��ͧ���");

                    DataViewManager dvm = new DataViewManager();
                    dvm.DataSet = ds;
                    DataViewSetting dvs;
                    dvs = dvm.DataViewSettings["��ͧ���"];
                    dvs.RowFilter = "��ͧ='" + room_number + "'";

                    if (Effect == 0)
                    {
                        IP_A.DataBindings.Add("Text", dvm, "��ͧ���.IP_A");
                        IP_B.DataBindings.Add("Text", dvm, "��ͧ���.IP_B");
                        IP_C.DataBindings.Add("Text", dvm, "��ͧ���.IP_C");
                        IP_D.DataBindings.Add("Text", dvm, "��ͧ���.IP_D");
                        port.DataBindings.Add("Text", dvm, "��ͧ���.port");
                        Effect = 1;
                    }
                    
                }
                catch (Exception errToAccess)
                {
                    MessageBox.Show("�������ö��ҹ�������� ���ͧ�ҡ " + errToAccess.Message, "��ͼԴ��Ҵ");
                }
                finally
                {
                    Conn.Close();
                }
            }
            else 
            {
                IP_address.Enabled = false;                
                IP_A.Enabled = false;
                IP_B.Enabled = false;
                IP_C.Enabled = false;
                IP_D.Enabled = false;
                Portname.Enabled = false;
                port.Enabled = false;
                IP_A.Text = "";
                IP_B.Text = "";
                IP_C.Text = "";
                IP_D.Text = "";
                port.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sqlEdit;
            string status;
            if (IP_A.Text == "")
                IP_A.Text = "0";
            if (IP_B.Text == "")
                IP_B.Text = "0";
            if (IP_C.Text == "")
                IP_C.Text = "0";
            if (IP_D.Text == "")
                IP_D.Text = "0";
            if (port.Text == "")
                port.Text = "0";
            if (enable_check.Checked == true)
            {
                status = "Connecting";
            }
            else 
            {
                status = "Disconnect";
            }
            
            sqlEdit = " UPDATE ��ͧ��� ";
            sqlEdit += " SET IP_A='" + IP_A.Text + "'";
            sqlEdit += " ,IP_B='" + IP_B.Text + "'";
            sqlEdit += " ,IP_C='" + IP_C.Text + "'";
            sqlEdit += " ,IP_D='" + IP_D.Text + "'";
            sqlEdit += " ,port='" + port.Text + "'";
            sqlEdit += " ,ʶҹ�='" + status + "'";
            sqlEdit += " WHERE(��ͧ='" + room_number + "')";


            OleDbCommand comEdit = new OleDbCommand();
            try
            {
                Conn.ConnectionString = strConn;
                if (Conn.State == ConnectionState.Open)
                {
                    Conn.Close();
                }
                Conn.Open();

                comEdit.CommandType = CommandType.Text;
                comEdit.CommandText = sqlEdit;
                comEdit.Connection = Conn;
                comEdit.ExecuteNonQuery();
            }
            catch (Exception errToEdit)
            {
                MessageBox.Show("Error!! ���ͧ�ҡ " + errToEdit.Message, "��ͼԴ��Ҵ");
            }
            finally
            {
                Conn.Close();
            }
            this.Close();
        }
    }
}