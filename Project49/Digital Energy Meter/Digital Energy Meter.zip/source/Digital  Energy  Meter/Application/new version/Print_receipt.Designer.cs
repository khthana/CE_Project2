namespace energyApplication
{
    partial class Print_receipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Print_receipt));
            System.Windows.Forms.Label label2;
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument = new System.Drawing.Printing.PrintDocument();
            this.button_print = new System.Windows.Forms.Button();
            this.buttonpreview = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.name1 = new System.Windows.Forms.Label();
            this.name2 = new System.Windows.Forms.Label();
            this.lname1 = new System.Windows.Forms.Label();
            this.lname2 = new System.Windows.Forms.Label();
            this.pbeforem = new System.Windows.Forms.Label();
            this.pafterm = new System.Windows.Forms.Label();
            this.pbeforeu = new System.Windows.Forms.Label();
            this.pafteru = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.proom = new System.Windows.Forms.Label();
            this.prent = new System.Windows.Forms.Label();
            this.pallunit = new System.Windows.Forms.Label();
            this.pallelectric = new System.Windows.Forms.Label();
            this.pallroom = new System.Windows.Forms.Label();
            this.punit = new System.Windows.Forms.Label();
            this.pmonth = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument;
            this.printDialog1.UseEXDialog = true;
            // 
            // button_print
            // 
            this.button_print.Location = new System.Drawing.Point(121, 469);
            this.button_print.Name = "button_print";
            this.button_print.Size = new System.Drawing.Size(75, 23);
            this.button_print.TabIndex = 0;
            this.button_print.Text = "�����";
            this.button_print.UseVisualStyleBackColor = true;
            this.button_print.Click += new System.EventHandler(this.button_print_Click);
            // 
            // buttonpreview
            // 
            this.buttonpreview.Location = new System.Drawing.Point(202, 469);
            this.buttonpreview.Name = "buttonpreview";
            this.buttonpreview.Size = new System.Drawing.Size(75, 23);
            this.buttonpreview.TabIndex = 1;
            this.buttonpreview.Text = "�ٵ�����ҧ";
            this.buttonpreview.UseVisualStyleBackColor = true;
            this.buttonpreview.Click += new System.EventHandler(this.buttonpreview_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(128, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "���˹�� ��ͧ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(131, 67);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(57, 13);
            label2.TabIndex = 3;
            label2.Text = "��Ш��ѹ���";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "�����Ţ������俿���ѹ���";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "������";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "����������";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "��������ͧ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "���俿��˹�����";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(192, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "�������";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(148, 307);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "������Թ�ӹǹ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "�����Ţ������俿���ѹ���";
            // 
            // name1
            // 
            this.name1.AutoSize = true;
            this.name1.Location = new System.Drawing.Point(99, 154);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(10, 13);
            this.name1.TabIndex = 4;
            this.name1.Text = "-";
            // 
            // name2
            // 
            this.name2.AutoSize = true;
            this.name2.Location = new System.Drawing.Point(99, 183);
            this.name2.Name = "name2";
            this.name2.Size = new System.Drawing.Size(10, 13);
            this.name2.TabIndex = 4;
            this.name2.Text = "-";
            // 
            // lname1
            // 
            this.lname1.AutoSize = true;
            this.lname1.Location = new System.Drawing.Point(199, 154);
            this.lname1.Name = "lname1";
            this.lname1.Size = new System.Drawing.Size(10, 13);
            this.lname1.TabIndex = 4;
            this.lname1.Text = "-";
            // 
            // lname2
            // 
            this.lname2.AutoSize = true;
            this.lname2.Location = new System.Drawing.Point(199, 183);
            this.lname2.Name = "lname2";
            this.lname2.Size = new System.Drawing.Size(10, 13);
            this.lname2.TabIndex = 4;
            this.lname2.Text = "-";
            // 
            // pbeforem
            // 
            this.pbeforem.AutoSize = true;
            this.pbeforem.Location = new System.Drawing.Point(169, 96);
            this.pbeforem.Name = "pbeforem";
            this.pbeforem.Size = new System.Drawing.Size(10, 13);
            this.pbeforem.TabIndex = 4;
            this.pbeforem.Text = "-";
            // 
            // pafterm
            // 
            this.pafterm.AutoSize = true;
            this.pafterm.Location = new System.Drawing.Point(169, 125);
            this.pafterm.Name = "pafterm";
            this.pafterm.Size = new System.Drawing.Size(10, 13);
            this.pafterm.TabIndex = 4;
            this.pafterm.Text = "-";
            // 
            // pbeforeu
            // 
            this.pbeforeu.AutoSize = true;
            this.pbeforeu.Location = new System.Drawing.Point(319, 96);
            this.pbeforeu.Name = "pbeforeu";
            this.pbeforeu.Size = new System.Drawing.Size(10, 13);
            this.pbeforeu.TabIndex = 5;
            this.pbeforeu.Text = "-";
            // 
            // pafteru
            // 
            this.pafteru.AutoSize = true;
            this.pafteru.Location = new System.Drawing.Point(319, 125);
            this.pafteru.Name = "pafteru";
            this.pafteru.Size = new System.Drawing.Size(10, 13);
            this.pafteru.TabIndex = 5;
            this.pafteru.Text = "-";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(322, 212);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "�ҷ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(322, 241);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "˹���";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(150, 241);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "�ҷ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(167, 274);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(78, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "���Թ�ӹǹ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(322, 274);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "�ҷ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(322, 307);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "�ҷ";
            // 
            // proom
            // 
            this.proom.AutoSize = true;
            this.proom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.proom.Location = new System.Drawing.Point(234, 31);
            this.proom.Name = "proom";
            this.proom.Size = new System.Drawing.Size(14, 20);
            this.proom.TabIndex = 6;
            this.proom.Text = "-";
            // 
            // prent
            // 
            this.prent.AutoSize = true;
            this.prent.Location = new System.Drawing.Point(275, 212);
            this.prent.Name = "prent";
            this.prent.Size = new System.Drawing.Size(10, 13);
            this.prent.TabIndex = 7;
            this.prent.Text = "-";
            // 
            // pallunit
            // 
            this.pallunit.AutoSize = true;
            this.pallunit.Location = new System.Drawing.Point(275, 241);
            this.pallunit.Name = "pallunit";
            this.pallunit.Size = new System.Drawing.Size(10, 13);
            this.pallunit.TabIndex = 7;
            this.pallunit.Text = "-";
            // 
            // pallelectric
            // 
            this.pallelectric.AutoSize = true;
            this.pallelectric.Location = new System.Drawing.Point(275, 274);
            this.pallelectric.Name = "pallelectric";
            this.pallelectric.Size = new System.Drawing.Size(10, 13);
            this.pallelectric.TabIndex = 7;
            this.pallelectric.Text = "-";
            // 
            // pallroom
            // 
            this.pallroom.AutoSize = true;
            this.pallroom.Location = new System.Drawing.Point(275, 307);
            this.pallroom.Name = "pallroom";
            this.pallroom.Size = new System.Drawing.Size(10, 13);
            this.pallroom.TabIndex = 7;
            this.pallroom.Text = "-";
            // 
            // punit
            // 
            this.punit.AutoSize = true;
            this.punit.Location = new System.Drawing.Point(129, 241);
            this.punit.Name = "punit";
            this.punit.Size = new System.Drawing.Size(10, 13);
            this.punit.TabIndex = 8;
            this.punit.Text = "-";
            // 
            // pmonth
            // 
            this.pmonth.AutoSize = true;
            this.pmonth.Location = new System.Drawing.Point(199, 67);
            this.pmonth.Name = "pmonth";
            this.pmonth.Size = new System.Drawing.Size(10, 13);
            this.pmonth.TabIndex = 9;
            this.pmonth.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(275, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "��ҡѺ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(275, 125);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "��ҡѺ";
            // 
            // Print_receipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 504);
            this.Controls.Add(this.pmonth);
            this.Controls.Add(this.punit);
            this.Controls.Add(this.pallroom);
            this.Controls.Add(this.pallelectric);
            this.Controls.Add(this.pallunit);
            this.Controls.Add(this.prent);
            this.Controls.Add(this.proom);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pafteru);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pbeforeu);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lname2);
            this.Controls.Add(this.pafterm);
            this.Controls.Add(this.pbeforem);
            this.Controls.Add(this.lname1);
            this.Controls.Add(this.name2);
            this.Controls.Add(this.name1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label3);
            this.Controls.Add(label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonpreview);
            this.Controls.Add(this.button_print);
            this.Name = "Print_receipt";
            this.Text = "Print";
            this.Load += new System.EventHandler(this.Print_receipt_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Button button_print;
        private System.Windows.Forms.Button buttonpreview;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument;
        private string room_number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label name1;
        private System.Windows.Forms.Label name2;
        private System.Windows.Forms.Label lname1;
        private System.Windows.Forms.Label lname2;
        private System.Windows.Forms.Label pbeforem;
        private System.Windows.Forms.Label pafterm;
        private System.Windows.Forms.Label pbeforeu;
        private System.Windows.Forms.Label pafteru;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label proom;
        private System.Windows.Forms.Label prent;
        private System.Windows.Forms.Label pallunit;
        private System.Windows.Forms.Label pallelectric;
        private System.Windows.Forms.Label pallroom;
        private System.Windows.Forms.Label punit;
        private System.Windows.Forms.Label pmonth;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
    }
}