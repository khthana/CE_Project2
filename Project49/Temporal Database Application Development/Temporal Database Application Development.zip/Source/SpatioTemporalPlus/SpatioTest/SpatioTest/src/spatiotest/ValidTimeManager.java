package spatiotest;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import java.awt.Panel;
import java.awt.Rectangle;

import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;

public class ValidTimeManager extends JDialog {
    private JTree DBTree = new JTree();
    private int AcctionSelect;
    private DatabaseAgent dbAgent;
    private EnableVersioning validTimeMang=new EnableVersioning();
    private Button ExitButt = new Button();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private Button ExecuteButt = new Button();
    private Panel panel1 = new Panel();
    private Checkbox EnableVersion = new Checkbox();
    private Checkbox DisableVersion = new Checkbox();
    private Checkbox SetValiTime = new Checkbox();

    public ValidTimeManager() {
        this(null, "", false);
    }

    public ValidTimeManager(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
        SpatioTestHome spHome=(SpatioTestHome) parent;
        this.dbAgent=spHome.dbAgent;
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setSize(new Dimension(733, 510));
        this.getContentPane().setLayout( null );
        this.setBackground(Color.white);
        this.setModal(true);
        this.setTitle("Valid Time Manager");
        validTimeMang.setBounds(new Rectangle(190, 35, 385, 305));
        validTimeMang.setBounds(new Rectangle(185, 35, 385, 305));
        ExitButt.setLabel("Exit");
        ExitButt.setBounds(new Rectangle(500, 415, 140, 45));
        ExitButt.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        ExitButt_mouseClicked(e);
                    }
                });
        jScrollPane1.setBounds(new Rectangle(20, 35, 150, 305));
        ExecuteButt.setLabel("Execute");
        ExecuteButt.setBounds(new Rectangle(305, 350, 145, 45));
        ExecuteButt.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        ExecuteButt_mouseClicked(e);
                    }
                });
        panel1.setBounds(new Rectangle(580, 30, 140, 310));
        panel1.setBackground(new Color(165, 198, 255));
        EnableVersion.setLabel("Enable  Versioning");
        EnableVersion.setBackground(new Color(165, 198, 255));
        EnableVersion.setFont(new Font("Tahoma", 1, 12));
        EnableVersion.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        EnableVersion_mouseClicked(e);
                    }
                });
        DisableVersion.setLabel("Disable  Version    ");
        DisableVersion.setBackground(new Color(165, 198, 255));
        DisableVersion.setFont(new Font("Tahoma", 1, 12));
        DisableVersion.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        DisableVersion_mouseClicked(e);
                    }
                });
        SetValiTime.setLabel("Set Valid Time       ");
        SetValiTime.setBackground(new Color(165, 198, 255));
        SetValiTime.setFont(new Font("Tahoma", 1, 12));
        SetValiTime.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        SetValiTime_mouseClicked(e);
                    }
                });
        jScrollPane1.getViewport().add(DBTree, null);
        panel1.add(EnableVersion, null);
        panel1.add(DisableVersion, null);
        panel1.add(SetValiTime, null);
        this.getContentPane().add(panel1, null);
        this.getContentPane().add(ExecuteButt, null);
        this.getContentPane().add(jScrollPane1, null);
        this.getContentPane().add(ExitButt, null);
        this.getContentPane().add(validTimeMang);
        AcctionSelect=0;
        jScrollPane1.setVisible(false);
    }
    
    public void AcctionSelect()throws Exception{
        switch(AcctionSelect){
        case 1:{DisableVersionTable(validTimeMang.TableNameTxt.getText(),validTimeMang.keppWM_Valid); break;}
        case 2:{EnableVersioningTable(validTimeMang.TableNameTxt.getText());break;}
        case 3:{SetValidTimeSession(validTimeMang.TableNameTxt.getText(),validTimeMang.ValidTillTxt.getText()); break;}
        default:{throw new IllegalStateException("Wrong operation !!!!! ");}
        }
    }
    public void EnableVersioningTable(String tableName){
        try {
            dbAgent.EnableVersioning(tableName);
        } catch (Exception e) {
            // TODO
             validTimeMang.ExecuteStatus.setText(e.getMessage());
        }
    }
    public void DisableVersionTable(String tableName,String keepWM_VALID){
        try {
            dbAgent.DisableVersion(tableName,keepWM_VALID);
        } catch (Exception e) {
            // TODO
             validTimeMang.ExecuteStatus.setText(e.getMessage());
        }
    }
    
    public void SetValidTimeSession(String validFrom,String validTill){
        try {
            dbAgent.SetValidTimeSession(validFrom,validTill);
        } catch (Exception e) {
            // TODO
             validTimeMang.ExecuteStatus.setText(e.getMessage());
        }
    }

   

    private void DisableVersion_mouseClicked(MouseEvent e) {
        validTimeMang.clearTestAll();
        AcctionSelect=1;
        validTimeMang.setVersion(true);
        SetValiTime.setState(false);
        EnableVersion.setState(false);
    }

    private void EnableVersion_mouseClicked(MouseEvent e) {
        validTimeMang.clearTestAll();
        AcctionSelect=2;
        validTimeMang.setVersion(false);
        SetValiTime.setState(false);
        DisableVersion.setState(false);
    }
    
    private void SetValiTime_mouseClicked(MouseEvent e) {
        validTimeMang.clearTestAll();
        AcctionSelect=3;
        validTimeMang.setValidTime();
        EnableVersion.setState(false);
        DisableVersion.setState(false);
    }

    private void ExecuteButt_mouseClicked(MouseEvent e) {
        try {
            AcctionSelect();
        } catch (Exception f) {
            // TODO
        }
    }

    private void ExitButt_mouseClicked(MouseEvent e) {
    validTimeMang.clearTestAll();
    this.dispose();
    }
}
