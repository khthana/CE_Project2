package spatiotest;

import java.awt.Dimension;
import java.awt.Toolkit;

import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.UIManager;

public class SpatioTest {
    private ValidTimeManager validTimeManager;
    public SpatioTest() {
        
        SpatioTestHome sptTesthome=new SpatioTestHome();
        //ConnectDlg connDlg=new ConnectDlg(sptTesthome,"Connect Dialog",true);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = sptTesthome.getSize();
        //Dimension loginFrameSize= loginFrame.getSize();
         
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        sptTesthome.setLocation( ( screenSize.width - frameSize.width ) / 2, ( screenSize.height - frameSize.height ) / 2 );
        sptTesthome.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        
        sptTesthome.setVisible(true);
        
        
        
    }
    
    public static void main(String[] args) throws ClassNotFoundException, 
                                                  SQLException {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new SpatioTest();
    
    }
    
}
