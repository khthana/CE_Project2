package spatiotest;

import java.sql.SQLException;


import java.sql.Timestamp;

import oracle.sql.STRUCT;

public class JWMPeriod {
    private Timestamp validFrom;
    private Timestamp validTill;
    private STRUCT timeST;
    public JWMPeriod(){
        this.timeST=null;
        this.validFrom=null;
        this.validTill=null;
    }
    public JWMPeriod(STRUCT inST) throws SQLException {
        if(inST.getSQLTypeName().equals("WMSYS.WM_PERIOD")){
            this.timeST=inST;
            Object[] tmpObj = inST.getAttributes();
            this.validFrom = (Timestamp)tmpObj[0];
            this.validTill = (Timestamp)tmpObj[1];
        }else
        throw new IllegalStateException("Data Type Error !!!!");
        
    }
    
    public Timestamp getValidFrom(){
        return validFrom;
    }
    public Timestamp getValidTill(){
        return validTill;
    }
    
    public void setTimeStamp(Timestamp inFrom,Timestamp inTill){
        this.validFrom=inFrom;
        this.validTill=inTill;
    }
    
    public void setValidFrom(Timestamp inFrom){
        this.validFrom=inFrom;
    }
    public void setValidTill(Timestamp inTill){
        this.validFrom=inTill;
    }
    
    public String toString(){
    
        String periodReturn="Period(";
        
        if(validFrom==null) periodReturn= periodReturn + "NULL,";
        else periodReturn= periodReturn + validFrom.toString() +",";
        
        if(validTill==null)periodReturn= periodReturn + "NULL)";
        else periodReturn= periodReturn + validTill.toString() +")";
        
        return periodReturn;
    }
}
