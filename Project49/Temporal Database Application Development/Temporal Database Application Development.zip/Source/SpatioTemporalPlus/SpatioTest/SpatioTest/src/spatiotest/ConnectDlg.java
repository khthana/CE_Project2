package spatiotest;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import java.awt.Label;
import java.awt.Rectangle;

import java.awt.TextField;

import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import java.sql.SQLException;

import javax.swing.JDialog;
import javax.swing.JPasswordField;

public class ConnectDlg extends JDialog {

    private Button CONNECTBUTT = new Button();
    private Button TESTCONNECT = new Button();
    private Button CLEAR = new Button();
    private JPasswordField Password = new JPasswordField();
    private TextField UserName = new TextField();
    private TextField sid = new TextField();
    private TextField PortNo = new TextField();
    private TextField Hostname = new TextField();
    private Label label1 = new Label();
    private Label label2 = new Label();
    private Label label3 = new Label();
    private Label label4 = new Label();
    private Label label5 = new Label();
    private Label ConnectStatus = new Label();
    private Button ExitBtt = new Button();
    
    public DatabaseAgent dbAgent;

    
    
    public ConnectDlg() {
        this(null, "", false);
    }  

    public ConnectDlg(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        try {
            SpatioTestHome spHome=(SpatioTestHome) parent;
            this.dbAgent=spHome.dbAgent;
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   
   
    private void jbInit() throws Exception {
        this.setSize(new Dimension(418, 449));
        this.getContentPane().setLayout( null );
        this.setTitle("Connect Dialog");
        CONNECTBUTT.setLabel("Connect");
        CONNECTBUTT.setBounds(new Rectangle(155, 325, 105, 35));
        CONNECTBUTT.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        CONNECTBUTT_mouseClicked(e);
                    }
                });
        TESTCONNECT.setLabel("Test Connection");
        TESTCONNECT.setBounds(new Rectangle(20, 325, 125, 35));
        TESTCONNECT.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        TESTCONNECT_mouseClicked(e);
                    }
                });
        CLEAR.setLabel("Clear");
        CLEAR.setBounds(new Rectangle(275, 325, 105, 35));
        CLEAR.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        CLEAR_mouseClicked(e);
                    }
                });
        Password.setBounds(new Rectangle(110, 245, 160, 30));
        Password.setFont(new Font("Tahoma", 0, 14));
        UserName.setBounds(new Rectangle(110, 190, 160, 30));
        UserName.setFont(new Font("Tahoma", 0, 14));
        sid.setBounds(new Rectangle(110, 135, 160, 30));
        sid.setFont(new Font("Tahoma", 0, 14));
        PortNo.setBounds(new Rectangle(285, 80, 55, 30));
        Hostname.setBounds(new Rectangle(110, 80, 160, 30));
        Hostname.setFont(new Font("Tahoma", 0, 14));
        label1.setText("Hostname");
        label1.setBounds(new Rectangle(110, 60, 85, 20));
        label2.setText("Port");
        label2.setBounds(new Rectangle(290, 60, 45, 20));
        label3.setText("SID");
        label3.setBounds(new Rectangle(110, 115, 85, 20));
        label4.setText("User Name");
        label4.setBounds(new Rectangle(110, 170, 85, 20));
        label5.setText("Password");
        label5.setBounds(new Rectangle(110, 225, 85, 20));
        ConnectStatus.setBounds(new Rectangle(20, 285, 360, 25));
        ConnectStatus.setFont(new Font("Tahoma", 0, 14));
        ExitBtt.setLabel("Exit");
        ExitBtt.setBounds(new Rectangle(300, 375, 105, 35));
        ExitBtt.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        ExitBtt_mouseClicked(e);
                    }
                });
        this.getContentPane().add(ExitBtt, null);
        this.getContentPane().add(ConnectStatus, null);
        this.getContentPane().add(label5, null);
        this.getContentPane().add(label4, null);
        this.getContentPane().add(label3, null);
        this.getContentPane().add(label2, null);
        this.getContentPane().add(label1, null);
        this.getContentPane().add(Hostname, null);
        this.getContentPane().add(PortNo, null);
        this.getContentPane().add(sid, null);
        this.getContentPane().add(UserName, null);
        this.getContentPane().add(Password, null);
        this.getContentPane().add(CLEAR, null);
        this.getContentPane().add(TESTCONNECT, null);
        this.getContentPane().add(CONNECTBUTT, null);
        PortNo.setText("1521");
         
    }

    private void CONNECTBUTT_mouseClicked(MouseEvent e) {
        ConnectStatus.setText("");
        try {
            if(isTextFull()){
                String passS= String.valueOf( Password.getPassword()); 
                dbAgent.Connect_To_Database(Hostname.getText(),PortNo.getText(),sid.getText(),UserName.getText(),passS);
                ConnectStatus.setText("Connected");
                this.dispose();
            }else
                ConnectStatus.setText("Plase enter infromation");
        } catch (Exception f) {
            // TODO
             ConnectStatus.setText(f.getMessage());
        }
    }

    private void TESTCONNECT_mouseClicked(MouseEvent e) {
        try {
            if(isTextFull()){
            String passS= String.valueOf( Password.getPassword()); 
            System.out.println(passS);
            System.out.println(Hostname.getText()+PortNo.getText()+sid.getText()+UserName.getText()+passS);
            dbAgent.TestConnect_To_DB(Hostname.getText(),PortNo.getText(),sid.getText(),UserName.getText(),passS);
            ConnectStatus.setText("Success");
            }else
                ConnectStatus.setText("Plase enter infromation");
        } catch (Exception f) {
            // TODO
            ConnectStatus.setText(f.getMessage());
        }
    }

    private void CLEAR_mouseClicked(MouseEvent e) {
    
    }
    public boolean isConnected(){
        return dbAgent.isConnected();
    }
    
    public DatabaseAgent getDatabaseAgent(){
        return new DatabaseAgent(dbAgent);
    }
    
    public String getSIDX(){
        return sid.getText();
    }
    
    public void setDatabaseAgent(DatabaseAgent dbIn){
        this.dbAgent=dbIn;
    }
    private boolean isTextFull(){
    if(Hostname.getText().equals("") || PortNo.getText().equals("") || sid.getText().equals("") || UserName.getText().equals("") || Password.toString().equals("")){
        return false;
    }else
        return true;
        }


    private void ExitBtt_mouseClicked(MouseEvent e) {
        try {
        if(dbAgent.isConnected())
            dbAgent.CloseConnection();
        } catch (SQLException f) {
            // TODO
        }
        this.dispose();
    }
}
