package spatiotest;

import java.awt.Dimension;

import java.awt.Font;
import java.awt.Label;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class EnableVersioning extends JPanel {
    public JTextField TableNameTxt = new JTextField();
    public JLabel TableLB_TimeFrom = new JLabel();
    public JPanel jPanel1 = new JPanel();
   
    public String keppWM_Valid="";
    public Label label1 = new Label();
    public Label ExecuteStatus = new Label();
    public JRadioButton KeeValidTime = new JRadioButton();
    public JRadioButton jRadioButton2 = new JRadioButton();
    public JTextField ValidTillTxt = new JTextField();
    private Label ValidFromLB = new Label();
    private Label ValidTillLB = new Label();
    public JLabel TimeTillLB = new JLabel();
    private JScrollPane jScrollPane1 = new JScrollPane();

    public EnableVersioning() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setLayout( null );
        this.setSize(new Dimension(387, 300));
        TableNameTxt.setBounds(new Rectangle(90, 55, 210, 35));
        TableLB_TimeFrom.setText("Please Enter Table Name");
        TableLB_TimeFrom.setBounds(new Rectangle(90, 20, 190, 30));
        TableLB_TimeFrom.setFont(new Font("Tahoma", 1, 11));
        jPanel1.setBounds(new Rectangle(80, 175, 245, 40));
        KeeValidTime.setText("Keep  WM_VALID");
        KeeValidTime.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {

                        KeeValidTime_actionPerformed(e);
                    }
                });
        jRadioButton2.setText("Delete  WM_VALID");
        jRadioButton2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        jRadioButton2_actionPerformed(e);
                    }
                });
        jPanel1.add(KeeValidTime, null);
        jPanel1.add(jRadioButton2, null);
        jScrollPane1.getViewport().add(ExecuteStatus, null);
        this.add(jScrollPane1, null);
        this.add(TimeTillLB, null);
        this.add(ValidTillLB, null);
        this.add(ValidFromLB, null);
        this.add(ValidTillTxt, null);
        this.add(label1, null);
        this.add(jPanel1, null);
        this.add(TableLB_TimeFrom, null);
        this.add(TableNameTxt, null);
        ValidTillTxt.setBounds(new Rectangle(90, 130, 210, 35));
        ValidTillTxt.setVisible(true);
        ValidFromLB.setText("Valid From");
        ValidFromLB.setBounds(new Rectangle(25, 55, 60, 35));
        ValidFromLB.setFont(new Font("Tahoma", 1, 11));
        ValidTillLB.setText("ValidTill");
        ValidTillLB.setBounds(new Rectangle(25, 130, 60, 35));
        ValidTillLB.setFont(new Font("Tahoma", 1, 11));
        TimeTillLB.setText("DD-MM-YYYY");
        TimeTillLB.setBounds(new Rectangle(90, 100, 190, 30));
        TimeTillLB.setFont(new Font("Tahoma", 1, 11));
        TimeTillLB.setVisible(true);
        jScrollPane1.setBounds(new Rectangle(35, 250, 325, 35));
        label1.setText("Execute  status:");
        label1.setBounds(new Rectangle(50, 225, 255, 25));
        label1.setFont(new Font("Tahoma", 1, 11));
        ExecuteStatus.setFont(new Font("Tahoma", 1, 12));
        TableNameTxt.setVisible(true);
        TableLB_TimeFrom.setVisible(true);
        ExecuteStatus.setVisible(true);
        setVersion(false);
        clearTestAll();
    }


    private void jRadioButton2_actionPerformed(ActionEvent e) {
        keppWM_Valid="FALSE";
        KeeValidTime.setSelected(false);
        
    }

    private void KeeValidTime_actionPerformed(ActionEvent e) {
        keppWM_Valid="TRUE";
        jRadioButton2.setSelected(false);
    }
    
    public void setVersion(boolean DisableVersion){
        TableLB_TimeFrom.setText("Please Enter Table Name");
        jPanel1.setVisible(DisableVersion);
        ValidFromLB.setVisible(false);
        ValidTillLB.setVisible(false);
        ValidTillTxt.setVisible(false);
        TimeTillLB.setVisible(false);
    }
    public void setValidTime(){
        TableLB_TimeFrom.setText("DD-MM-YYYY");
        jPanel1.setVisible(false);
        ValidFromLB.setVisible(true);
        ValidTillLB.setVisible(true);
        ValidTillTxt.setVisible(true);
        TimeTillLB.setVisible(true);
    }
    public void clearTestAll(){
        keppWM_Valid="";
        TableNameTxt.setText("");
        ValidTillTxt.setText("");
        TableNameTxt.setText("");
        ExecuteStatus.setText("");
        KeeValidTime.setSelected(false);
        jRadioButton2.setSelected(false);
    }
}
