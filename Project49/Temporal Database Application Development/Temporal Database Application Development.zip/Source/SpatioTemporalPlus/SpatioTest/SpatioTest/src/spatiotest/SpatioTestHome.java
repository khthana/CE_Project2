package spatiotest;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import java.sql.Statement;

import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.JTextArea;

import javax.swing.JTextField;

import javax.swing.JToggleButton;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.JTableHeader;

import oracle.jdbc.driver.*;
import java.sql.*;

import java.util.Calendar;






public class SpatioTestHome extends JFrame {

/************/
   
    public DatabaseAgent dbAgent=new DatabaseAgent();
    private JButton ExecuteButt = new JButton();
    private JTextField Connect_Status = new JTextField();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTable JTABLETEST = new JTable();
    private JScrollPane jScrollPane2 = new JScrollPane();
    private JTextArea geomShow = new JTextArea();
    private Button button1 = new Button();
    private JButton ClearButt = new JButton();
    private ValidTimeManager validTimeManager = new ValidTimeManager(this,"",true);
    private ConnectDlg connDlg=new ConnectDlg(this,"Connect Dialog",true);
    private JButton ConnectToDBButt = new JButton();
    private Label label1 = new Label();
    private Label label2 = new Label();
    
    private boolean connected=false;
    private JButton ValidTimeMang = new JButton();
    private Label showValidTimeLB = new Label();

    /************/

    public SpatioTestHome() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(840, 717));
        this.setResizable(false);
        this.setTitle("SpatioTemporalPluse");
        ExecuteButt.setText("Execute");
        ExecuteButt.setBounds(new Rectangle(220, 200, 120, 35));
        ExecuteButt.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                ExecuteButt_mouseClicked(e);
                    }
                });
        Connect_Status.setBounds(new Rectangle(20, 240, 795, 35));
        jScrollPane1.setBounds(new Rectangle(15, 285, 800, 340));
        jScrollPane1.setSize(new Dimension(800, 350));
        jScrollPane2.setBounds(new Rectangle(25, 55, 800, 130));
        geomShow.setLineWrap(true);
        geomShow.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
        button1.setLabel("button1");
        button1.setBounds(new Rectangle(910, 690, 100, 30));
        ClearButt.setText("Clear");
        ClearButt.setBounds(new Rectangle(370, 200, 120, 35));
        ClearButt.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                        ClearButt_mouseClicked(e);
                    }
                });
        ConnectToDBButt.setText("Connect");
        ConnectToDBButt.setBounds(new Rectangle(650, 200, 120, 35));
        ConnectToDBButt.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                        ConnectToDBShow_mouseClicked(e);
                    }
                });
        label1.setText("Enter SQL, PL/SQL and SQL*Plus statements");
        label1.setBounds(new Rectangle(30, 30, 230, 20));
        label1.setFont(new Font("Tahoma", 1, 11));
        label2.setText("Execute  Status");
        label2.setBounds(new Rectangle(20, 215, 135, 25));
        label2.setFont(new Font("Tahoma", 1, 11));
        ValidTimeMang.setText("Valid Tim Manager");
        ValidTimeMang.setBounds(new Rectangle(510, 200, 120, 35));
        ValidTimeMang.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                        ValidTimeMangButt_mouseClicked(e);
                    }
                });
        showValidTimeLB.setBounds(new Rectangle(280, 15, 375, 35));
        showValidTimeLB.setFont(new Font("Dialog", 1, 12));
        jScrollPane1.getViewport().add(JTABLETEST, null);
        jScrollPane2.getViewport().add(geomShow, null);
        this.getContentPane().add(showValidTimeLB, null);
        this.getContentPane().add(ValidTimeMang, null);
        this.getContentPane().add(label2, null);
        this.getContentPane().add(label1, null);
        this.getContentPane().add(ConnectToDBButt, null);
        this.getContentPane().add(ClearButt, null);
        this.getContentPane().add(button1, null);
        this.getContentPane().add(jScrollPane2, null);
        this.getContentPane().add(jScrollPane1, null);
        this.getContentPane().add(Connect_Status, null);
        this.getContentPane().add(ExecuteButt, null);
       // this.connDlg=new ConnectDlg(this,"Connect Dialog",true);
        this.SetAvailable(false);
    }
    

    private void ExecuteButt_mouseClicked(MouseEvent e) {
        try {
        if(connected){
            Connect_Status.setText("");
             dbAgent.passSQLCommand(geomShow.getText(),JTABLETEST);
             
             jScrollPane1.setVisible(true); 
        }
        }
        catch (Exception f) {
            // TODO
            Connect_Status.setText(f.getMessage());
            jScrollPane1.setVisible(false);
        }
    }


    private void ClearButt_mouseClicked(MouseEvent e) {
   
        geomShow.setText("");
        Connect_Status.setText("");
        jScrollPane1.setVisible(false);
        
        
    }

    private void ConnectToDBShow_mouseClicked(MouseEvent e) {
         try {
            if(connected){
                connected=false;
                ConnectToDBButt.setText("Connect");
                this.SetAvailable(false);
                dbAgent.CloseConnection();
            }else{
                connDlg.setVisible(true);
                if(dbAgent.isConnected()){
                    this.SetAvailable(true);
                    ConnectToDBButt.setText("Disconnect");
                    connected=true;
                }
            }
        } catch (SQLException f) {
            // TODO
        }
    }
    private void SetAvailable(boolean setEnable){
        ExecuteButt.setEnabled(setEnable);
        Connect_Status.setEnabled(setEnable);
        jScrollPane1.setEnabled(setEnable);
        JTABLETEST.setEnabled(setEnable);
        jScrollPane2.setEnabled(setEnable);
        geomShow.setEnabled(setEnable);
        button1.setEnabled(setEnable);
        ClearButt.setEnabled(setEnable);
        ValidTimeMang.setEnabled(setEnable);
    }

    private void ValidTimeMangButt_mouseClicked(MouseEvent e) {
    if(connected)
        validTimeManager.setVisible(true);
        try {
            showValidTimeLB.setText( dbAgent.getValidTime());
        } catch (Exception f) {
            // TODO
             Connect_Status.setText(f.getMessage());
        }
    }
}
