package spatiotest;

import java.sql.*;
import javax.swing.table.*;
import javax.swing.event.*;

import oracle.spatial.geometry.JGeometry;

import oracle.sql.STRUCT;

/**
 * This class takes a JDBC ResultSet object and implements the TableModel
 * interface in terms of it so that a Swing JTable component can display the
 * contents of the ResultSet.  Note that it requires a scrollable JDBC 2.0 
 * ResultSet.  Also note that it provides read-only access to the results
 **/
public class ResultSetTableModel implements TableModel {
    ResultSet results;             // The ResultSet to interpret
    ResultSetMetaData metadata;    // Additional information about the results
    int numcols, numrows;          // How many rows and columns in the table

    /**
     * This constructor creates a TableModel from a ResultSet.  It is package
     * private because it is only intended to be used by 
     * ResultSetTableModelFactory, which is what you should use to obtain a
     * ResultSetTableModel
     **/
     
  
    ResultSetTableModel(ResultSet results) throws SQLException {
	this.results = results;                 // Save the results
	metadata = results.getMetaData();       // Get metadata on them
	numcols = metadata.getColumnCount();    // How many columns?
	results.last();                         // Move to last row
	numrows = results.getRow();             // How many rows?
    }
    
    /** 
     * Call this when done with the table model.  It closes the ResultSet and
     * the Statement object used to create it.
     **/
    public void close() {
	try { results.getStatement().close(); }
	catch(SQLException e) {};
    }

    /** Automatically close when we're garbage collected */
    protected void finalize() { close(); }

    // These two TableModel methods return the size of the table
    public int getColumnCount() { return numcols; }
    public int getRowCount() { return numrows; }

    // This TableModel method returns columns names from the ResultSetMetaData
    public String getColumnName(int column) {
	try {
	    return metadata.getColumnLabel(column+1);
	} catch (SQLException e) { return e.toString(); }
    }

    // This TableModel method specifies the data type for each column.  
    // We could map SQL types to Java types, but for this example, we'll just
    // convert all the returned data to strings.
    public Class getColumnClass(int column) { return String.class; }
    
    /**
     * This is the key method of TableModel: it returns the value at each cell
     * of the table.  We use strings in this case.  If anything goes wrong, we
     * return the exception as a string, so it will be displayed in the table.
     * Note that SQL row and column numbers start at 1, but TableModel column
     * numbers start at 0.
     **/
    public Object getValueAt(int row, int column) {
	try {
	    results.absolute(row+1);                // Go to the specified row
	    Object o = results.getObject(column+1); // Get value of the column
            
	    if (o == null) return null;       
	    else if(o instanceof STRUCT ){              
                    STRUCT rsST=(STRUCT)o;
                    String sqlType=rsST.getSQLTypeName();
                    
                    if(sqlType.equals("MDSYS.SDO_GEOMETRY")){
                        return convertSTRUCTtoGeomString(rsST);
                    }
                    else if(sqlType.equals("WMSYS.WM_PERIOD")){return convertSTRUCTtoValidTime(rsST);}
                    else return o;
            }
            else return o; // Convert it to a string
            
	} catch (SQLException e) { return e.toString(); }
    }

    // Our table isn't editable
    public boolean isCellEditable(int row, int column) { return false; } 

    // Since its not editable, we don't need to implement these methods
    public void setValueAt(Object value, int row, int column) {}
    public void addTableModelListener(TableModelListener l) {}
    public void removeTableModelListener(TableModelListener l) {}
    
    private String convertSTRUCTtoGeomString(STRUCT inSTRUCT) throws SQLException {
        String stReturn;
        String elemInfo="ELEM_INFO_ARRAY(";
        String ordArryInfo="ORDINATE_ARRAY(";
        String pointType="POINT_TYPE(";
        String geomTypeDim;
        String geomSID="NULL";
        JGeometry j_geom;
        
        /*****This for get Ordinates Array *****/
     
        j_geom = JGeometry.load(inSTRUCT);
            
        geomTypeDim="Geom("+ j_geom.getDimensions() +"00"+ j_geom.getType()+"";
        if(j_geom.getSRID() !=0)
            geomSID= Integer.toString(j_geom.getSRID());
        
        double[] tmpPointType=j_geom.getPoint();
        if(tmpPointType==null){pointType="NULL";}
        else{
            int pointlength=tmpPointType.length;
            for(int ii=0; ii < pointlength; ii++){
            
                if(tmpPointType[ii]==0 ) pointType=pointType+ "NULL";
                else pointType=pointType + tmpPointType[ii];
  
                if(ii!=pointlength-1)
                    pointType=pointType+",";
                else
                    pointType=pointType+")";
            }
        }
        
        int[] eleinfo= j_geom.getElemInfo();
        if(eleinfo==null) elemInfo="NULL";
        else{
            int eleLength=eleinfo.length;
            for(int ii=0 ;ii < eleLength ; ii++){
                elemInfo=elemInfo +" " + eleinfo[ii];  // .toString() ;
                if(ii!=eleLength-1)
                    elemInfo=elemInfo+",";
                else
                    elemInfo=elemInfo+")";
            }
        }
        /*****This for get Ordinates Array *****/
        double[] ordInfo= j_geom.getOrdinatesArray();
        if(ordInfo==null)ordArryInfo="NULL";
        else{
            int ordLength=ordInfo.length;
            for(int ii=0 ;ii < ordLength ; ii++){
                ordArryInfo=ordArryInfo +" " + ordInfo[ii];  // .toString() ;
                          
                if(ii!=ordLength-1)
                    ordArryInfo=ordArryInfo+",";
                else
                    ordArryInfo=ordArryInfo+")";
            }
        }
        stReturn=geomTypeDim + ","+geomSID+", "+pointType +","+elemInfo+","+ordArryInfo+')';//j_geom.getElemInfo().toString()+ j_geom.getOrdinatesArray().toString();
        return stReturn;
        }
    private String convertSTRUCTtoValidTime(STRUCT inSTRUCT) throws SQLException {  
        JWMPeriod timePeriod=new JWMPeriod(inSTRUCT);
        return timePeriod.toString();
    }
    
}