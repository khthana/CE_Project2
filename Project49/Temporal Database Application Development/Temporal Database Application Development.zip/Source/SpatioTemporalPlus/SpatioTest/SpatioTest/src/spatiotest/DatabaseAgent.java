package spatiotest;

import java.awt.Dimension;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import javax.swing.JTable;

import oracle.dms.clock.Timestamp;

import oracle.jdbc.driver.OracleDriver;

import oracle.sql.STRUCT;

public class DatabaseAgent {

    private Connection SpatioConnection;
    private boolean connectionStatus;
    private Statement sqlStatment;
    
    
    public DatabaseAgent() {
       connectionStatus = false;
    }
    public DatabaseAgent(Connection spatioConnectionIn){
        SpatioConnection=spatioConnectionIn;
    }
    public DatabaseAgent(DatabaseAgent dbAin) {
        if(dbAin!=null){
            this.SpatioConnection=dbAin.SpatioConnection;
            this.sqlStatment=dbAin.sqlStatment;
            this.connectionStatus=dbAin.connectionStatus;
        }
    }
    
    public  ResultSet ExecuteQuery(String sqlStatement)throws Exception{ 
        if (SpatioConnection == null){
                    throw new IllegalStateException("Connection already closed.");
                   
        }
        else{
        Statement statement =SpatioConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        ResultSet executeQueryResultSet = statement.executeQuery(sqlStatement);
        return executeQueryResultSet;
        }
    }
    
    public boolean isConnected(){
            if (SpatioConnection == null)
                return false;
            else 
                return true;
    }
    
    public void updateQueryToTable(ResultSet updateResultSet,JTable qTableIn)throws Exception{
         if (SpatioConnection == null)
                     throw new IllegalStateException("Connection already closed.");
         else{
            qTableIn.setModel(this.getResultSetTableModel(updateResultSet));
            qTableIn.setVisible(true);
        }

    }
    
    /******
     *  Execute PL/SQL  Procedure
     ********/
     public int executeDDLandDML(String ddlDML)throws Exception{
        
         Statement statement =SpatioConnection.createStatement();
         return statement.executeUpdate(ddlDML);
     }
   
    
    /******
     *  Execute PL/SQL  Procedure
     ********/
    public void executeProcedure(String exeString) throws Exception{
        String exeProcedure="{Call "+ exeString +" }";
        if (SpatioConnection == null)
                    throw new IllegalStateException("Connection already closed.");
        else{
            if(!exeString.equals(null)){
                CallableStatement callStm=SpatioConnection.prepareCall(exeProcedure);
                callStm.execute();
                callStm.close();
            }
            
        }
    }
    
    public void EnableVersioning(String tableName) throws Exception{
        String exeProcedure="{Call DBMS_WM.EnableVersioning('"+ tableName +"', 'VIEW_WO_OVERWRITE', FALSE,TRUE) }";
        if (SpatioConnection == null)
                    throw new IllegalStateException("Connection already closed.");
        else{
            if(!tableName.equals("")){
                CallableStatement callStm=SpatioConnection.prepareCall(exeProcedure);
                callStm.execute();
                callStm.close();
                throw new IllegalStateException("Enable Versioning Completed.....");
            }else
                throw new IllegalStateException("Please Enter Table name");
            
        }
    }
    
    public void DisableVersion(String tableName,String keepWM_VALID) throws Exception{
        String exeProcedure="{Call DBMS_WM.DisableVersioning('"+ tableName +"',FALSE,FALSE,FALSE,"+ keepWM_VALID +")}";
        if (SpatioConnection == null)
                    throw new IllegalStateException("Connection already closed.");
        else{
            if(!tableName.equals("") && !keepWM_VALID.equals("")){
                CallableStatement callStm=SpatioConnection.prepareCall(exeProcedure);
                callStm.execute();
                callStm.close();
                throw new IllegalStateException("Disable Version Completed.....");
            }else{
                if(tableName.equals("")){
                    throw new IllegalStateException("Please Enter Table name");
                } 
                else if(keepWM_VALID.equals("")){
                    throw new IllegalStateException("Please select for keep or delete WM_VALID Column ");
                }
            }
            
        }
    }
    
    
    public void SetValidTimeSession(String validFrom,String validTill) throws Exception{
    
        String exeProcedure="{Call DBMS_WM.SetValidTime(TO_TIMESTAMP('"+ validFrom +"','DD-MM-YYYY'),TO_TIMESTAMP('"+ validTill +"','DD-MM-YYYY'))}";
        if (SpatioConnection == null)
                    throw new IllegalStateException("Connection already closed.");
        else{
            if(!validFrom.equals("") && !validTill.equals("")){
                CallableStatement callStm=SpatioConnection.prepareCall(exeProcedure);
                callStm.execute();
                callStm.close();
                throw new IllegalStateException("SetValidTime Completed.....");
            }else{
                if(validFrom.equals("")){
                    throw new IllegalStateException("Please Enter Valid From");
                } 
                else if(validTill.equals("")){
                    throw new IllegalStateException("Please Enter Valid Till ");
                }
            }
            
        }
    }
    
    
    private ResultSetTableModel getResultSetTableModel(ResultSet resultSetIn)throws SQLException {
        if (SpatioConnection == null)
                    throw new IllegalStateException("Connection already closed.");
        else
        return new ResultSetTableModel(resultSetIn);
    }
    
    
    /******
     * Mathod for to pass input text to select case DDL DML or EXECUTE 
     * *******/
    public void passSQLCommand(String sqlCommand,JTable resultTbl )throws Exception{
        if(sqlCommand.equals("")){
            throw new IllegalStateException("SP2-0866: Please enter statements in the input area");
        }
        else{
        String checkSQLCommand=sqlCommand.toUpperCase();
        String checkSQLReturn=checkSQLCommand.replace("\n"," ");
        String[] checkSQLArr= checkSQLReturn.split(";");
        
        
        String sqlReturn=sqlCommand.replace("\n"," ");
        String[] sqlArr=sqlReturn.split(";");
        
        int sqlArrLength=checkSQLArr.length;
        
        for(int ii=0;ii<sqlArrLength;++ii){
            if(checkSQLArr[ii].indexOf("SELECT")!=-1){          
                ResultSet exeResult=ExecuteQuery(sqlArr[ii]);
                updateQueryToTable(exeResult,resultTbl);
            }
            else  if(checkSQLArr[ii].indexOf("EXECUTE")!=-1) {
                String exeCommand=sqlArr[ii].toUpperCase();
                exeCommand=exeCommand.replaceFirst("EXECUTE","");
                executeProcedure(exeCommand);
                }
                
            else  if(checkSQLArr[ii].indexOf("TRIGGER")!=-1){
                executeDDLandDML(sqlArr[ii]+";");   
            }
            else
                executeDDLandDML(sqlArr[ii]);
            }
            }
    }
    
    public Connection getConnection(){
        return SpatioConnection;
    }
    
    public void CloseConnection() throws SQLException {
        SpatioConnection.close();
    }
    
    public String getValidTime() throws Exception {
    String validTime;
        if(this.isConnected()){
            String validTimeSQL="SELECT DBMS_WM.GetValidFrom,DBMS_WM.GetValidTill FROM DUAL";
            ResultSet validTimeResult= this.ExecuteQuery(validTimeSQL);
            
            validTimeResult.absolute(1);
           // System.out.println("ValidTill" + validTimeResult.getDate(1));
            Object objFrom =validTimeResult.getTimestamp(1);
           
            Timestamp TimeFrom=(Timestamp) objFrom;
            System.out.println("STRUCT TYPE ="+TimeFrom.toString());
            if(validTimeResult!=null){
            String validFromString="NULL";
            String validTillString="NULL";
            
            Date validFrom=(Date) validTimeResult.getDate(1);
            Date validTill=(Date) validTimeResult.getDate(1);
            System.out.println("ValidTill" + validFrom.toString());
                if(validFrom!=null)
                    validFromString=validFrom.toString();
                if(validTill!=null)
                    validTillString=validTill.toString();
                validTime="ValidTime("+ validFromString + "-" + validTillString + ")";
            }else{
                validTime="ValidTime(NULL-NULL)";
            }
        }
        else{
            throw new IllegalStateException("Connection already closed.");
        }
        return validTime;
    }
    
    public void setConnection(Connection connIn){
        SpatioConnection=connIn;
    }
    /********
     * 
     ***************/
    protected void Connect_To_Database(String hostName ,String port ,String sid,String username,String password)throws Exception{
            String connString;
            try{
                    connString="jdbc:oracle:thin:@"+hostName+":"+port +":"+sid ;
                    DriverManager.registerDriver(new OracleDriver());
                    SpatioConnection = DriverManager.getConnection(connString,username,password);
                    sqlStatment=SpatioConnection.createStatement();
            }
            catch(SQLException e){throw new Exception(e.getMessage());}
            catch(Exception e){throw new Exception(e.getMessage());}
        }
        
    protected void TestConnect_To_DB(String hostName ,String port ,String sid,String username,String password) throws Exception {
        Connection testConn;
        String connString;
        try{
                connString="jdbc:oracle:thin:@" + hostName + ":" + port  + ":" + sid ;
                DriverManager.registerDriver(new OracleDriver());
                testConn = (Connection)DriverManager.getConnection(connString,username,password);
                throw new Exception("Sucess.");
            }
        catch(Exception e){throw new Exception(e.getMessage());}
    }
}
