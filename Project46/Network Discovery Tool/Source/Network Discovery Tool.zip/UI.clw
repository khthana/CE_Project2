; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CWWait
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "UI.h"
LastPage=0

ClassCount=21
Class1=CUIApp
Class2=CUIDoc
Class3=CUIView
Class4=CMainFrame

ResourceCount=14
Resource1=IDD_MenuREFRESH
Resource2=IDD_SNMP
Class5=CAboutDlg
Class6=Newscan
Resource3=IDR_MAINFRAME
Resource4=IDD_StatusPing
Resource5=IDD_WHOIS
Class7=PingShow
Class8=TracerouteShow
Class9=WHOISShow
Resource6=IDD_Traceroute
Class10=TableIP
Class11=TableNetwork
Class12=TableAddressStep
Class13=TebleRouter
Class14=TableRouter
Resource7=IDD_CardInfo
Class15=SNMPShow
Resource8=IDD_WNetstat
Class16=CCardInfoShow
Resource9=IDD_Ping
Class17=WNetstatDlg
Resource10=IDD_Newscan
Class18=CMenuRefresh
Resource11=IDD_ABOUTBOX
Class19=CWWait
Resource12=IDR_Property
Class20=StatusPing
Resource13=IDD_Wait
Class21=StatusSystem
Resource14=IDD_StatusSystem

[CLS:CUIApp]
Type=0
HeaderFile=UI.h
ImplementationFile=UI.cpp
Filter=N

[CLS:CUIDoc]
Type=0
HeaderFile=UIDoc.h
ImplementationFile=UIDoc.cpp
Filter=N
BaseClass=CDocument
VirtualFilter=DC
LastObject=CUIDoc

[CLS:CUIView]
Type=0
HeaderFile=UIView.h
ImplementationFile=UIView.cpp
Filter=C
BaseClass=CScrollView
VirtualFilter=VWC
LastObject=IDD_StatusSystem


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
BaseClass=CFrameWnd
VirtualFilter=fWC
LastObject=ID_FILE_SAVE




[CLS:CAboutDlg]
Type=0
HeaderFile=UI.cpp
ImplementationFile=UI.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_PRINT
Command2=ID_FILE_PRINT_PREVIEW
Command3=ID_FILE_PRINT_SETUP
Command4=ID_APP_EXIT
Command5=IDD_Newscan
Command6=IDD_Ping
Command7=IDD_SNMP
Command8=IDD_Traceroute
Command9=IDD_WHOIS
Command10=IDD_CardInfo
Command11=IDD_WNetstat
Command12=ID_VIEW_TOOLBAR
Command13=ID_VIEW_STATUS_BAR
Command14=ID_OPTION_AUTOREFRESH_NONE
Command15=ID_OPTION_AUTOREFRESH_AUTO
Command16=IDD_MenuREFRESH
Command17=ID_OPTION_CLEARDATABASE
Command18=ID_APP_ABOUT
CommandCount=18

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[TB:IDR_MAINFRAME]
Type=1
Class=?
Command1=ID_FILE_PRINT
CommandCount=1

[DLG:IDD_Newscan]
Type=1
Class=Newscan
ControlCount=22
Control1=IDOK,button,1073807361
Control2=IDCANCEL,button,1342242816
Control3=IDC_SINGLEADDRESS,button,1342177289
Control4=IDC_RANGE,button,1342177289
Control5=IDC_SUBNET,button,1342177289
Control6=IDC_HOP,button,1342177289
Control7=IDC_TYPE,button,1342308359
Control8=IDC_IPADDRESSSTART,SysIPAddress32,1342242816
Control9=IDC_IPADDRESSEND,SysIPAddress32,1342242816
Control10=IDC_STATIC,static,1342308352
Control11=IDC_STATIC,static,1342308352
Control12=IDC_STATIC,static,1342308353
Control13=IDC_NUMHOP,edit,1350631552
Control14=IDC_STATIC,static,1342308352
Control15=IDC_ADVANCE,button,1342177289
Control16=IDC_BASIC,button,1342177289
Control17=IDC_OPTION,button,1342308359
Control18=IDC_CHECKPINGTRACERT,button,1342242819
Control19=IDC_CHECKRIP,button,1342242819
Control20=IDC_CHECKSNMP,button,1342242819
Control21=IDC_BUTTONSCAN,button,1342242816
Control22=IDC_STATIC,static,1342308352

[CLS:Newscan]
Type=0
HeaderFile=Newscan.h
ImplementationFile=Newscan.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_NUMHOP
VirtualFilter=dWC

[DLG:IDD_Ping]
Type=1
Class=PingShow
ControlCount=6
Control1=IDCANCEL,button,1342242817
Control2=IDPING,button,1342242816
Control3=IDC_EDITPing,edit,1350631552
Control4=IDC_STATIC,static,1342308352
Control5=IDC_CHECKRESOLVEHOSNAME,button,1342242819
Control6=IDC_PingRESULT,static,1342312448

[DLG:IDD_Traceroute]
Type=1
Class=TracerouteShow
ControlCount=5
Control1=IDTRACE,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_EDITTraceroute,edit,1350631552
Control5=IDC_TracerouteRESULT,static,1342312448

[DLG:IDD_WHOIS]
Type=1
Class=WHOISShow
ControlCount=5
Control1=IDWHOIS,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_WHOIS,static,1342308352
Control4=IDC_EDITWHOIS,edit,1350631552
Control5=IDC_ResultWHOIS,static,1342377984

[CLS:PingShow]
Type=0
HeaderFile=PingShow.h
ImplementationFile=PingShow.cpp
BaseClass=CDialog
Filter=D
LastObject=ID_APP_ABOUT
VirtualFilter=dWC

[CLS:TracerouteShow]
Type=0
HeaderFile=TracerouteShow.h
ImplementationFile=TracerouteShow.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_CHECK1
VirtualFilter=dWC

[CLS:WHOISShow]
Type=0
HeaderFile=WHOISShow.h
ImplementationFile=WHOISShow.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_EDITWHOIS

[DLG:IDD_MenuREFRESH]
Type=1
Class=CMenuRefresh
ControlCount=4
Control1=IDOK,button,1342242817
Control2=IDC_EDITREFRESH,edit,1350631552
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352

[CLS:TableIP]
Type=0
HeaderFile=TableIP.h
ImplementationFile=TableIP.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:TableIP]
DB=1
DBType=DAO
ColumnCount=3
Column1=[NetworkAddressFirst], 12, 50
Column2=[IPAddress], 12, 50
Column3=[Alive], -7, 1

[CLS:TableNetwork]
Type=0
HeaderFile=TableNetwork.h
ImplementationFile=TableNetwork.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:TableNetwork]
DB=1
DBType=DAO
ColumnCount=3
Column1=[NetworkAddressFirst], 12, 50
Column2=[NetworkAddressEnd], 12, 50
Column3=[Netmask], 12, 50

[CLS:TableAddressStep]
Type=0
HeaderFile=TableAddressStep.h
ImplementationFile=TableAddressStep.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:TableAddressStep]
DB=1
DBType=DAO
ColumnCount=2
Column1=[BeforeIP], 12, 50
Column2=[NextIP], 12, 50

[CLS:TebleRouter]
Type=0
HeaderFile=TebleRouter.h
ImplementationFile=TebleRouter.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:TebleRouter]
DB=1
DBType=DAO
ColumnCount=4
Column1=[ID], 4, 4
Column2=[Router_No], 4, 4
Column3=[IPAddress], 12, 50
Column4=[InterfaceNo], 4, 4

[CLS:TableRouter]
Type=0
HeaderFile=TableRouter.h
ImplementationFile=TableRouter.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:TableRouter]
DB=1
DBType=DAO
ColumnCount=4
Column1=[ID], 4, 4
Column2=[Router_No], 4, 4
Column3=[IPAddress], 12, 50
Column4=[InterfaceNo], 4, 4

[DLG:IDD_SNMP]
Type=1
Class=SNMPShow
ControlCount=11
Control1=ID_SNMP,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_SNMPComunityName,edit,1350631552
Control4=IDC_STATIC,static,1342308352
Control5=IDC_SNMPMethod,combobox,1344340226
Control6=IDC_SNMPIPADDRESS,SysIPAddress32,1342242816
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDCSNMPResult,edit,1352730820
Control11=IDC_SNMPOid,combobox,1344340226

[CLS:SNMPShow]
Type=0
HeaderFile=SNMPShow.h
ImplementationFile=SNMPShow.cpp
BaseClass=CDialog
Filter=D
LastObject=IDCSNMPResult
VirtualFilter=dWC

[DLG:IDD_CardInfo]
Type=1
Class=CCardInfoShow
ControlCount=3
Control1=IDOK,button,1342242817
Control2=ID_GetCardInfo,button,1342242816
Control3=IDC_CardInfoShow,edit,1353787588

[CLS:CCardInfoShow]
Type=0
HeaderFile=CardInfoShow.h
ImplementationFile=CardInfoShow.cpp
BaseClass=CDialog
Filter=D
LastObject=CCardInfoShow
VirtualFilter=dWC

[DLG:IDD_WNetstat]
Type=1
Class=WNetstatDlg
ControlCount=16
Control1=IDOK,button,1342242817
Control2=IDC_BUTTON_CHECK,button,1342242816
Control3=IDC_EDIT_STATS,edit,1353787524
Control4=IDC_COMBO_PROTOCOL,combobox,1344339971
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352
Control7=IDC_COMBO_FILTER,combobox,1344339971
Control8=IDC_CHECK_PORTFILTER,button,1342242819
Control9=IDC_EDIT_PORTFILTER,edit,1350631552
Control10=IDC_CHECK_IPFILTER,button,1342242819
Control11=IDC_EDIT_IPFILTER,edit,1350631552
Control12=IDC_CHECK_RESOLVE,button,1342242819
Control13=IDC_CHECK_LOG,button,1342242819
Control14=IDC_BUTTON_CLEAR,button,1342242816
Control15=IDC_BUTTON_SAVE,button,1342242816
Control16=IDC_Routing,button,1342242816

[MNU:IDR_Property]
Type=1
Class=CUIView
Command1=ID_MENURCLICK_HIDENODE
Command2=ID_MENURCLICK_CHECKSTATUS
Command3=IDD_StatusSystem
Command4=ID_MENURCLICK_CHECKSTATUS
Command5=IDD_StatusSystem
Command6=ID_MENURCLICK_EXPAND
Command7=ID_MENURCLICK_CHECKSTATUS
Command8=IDD_StatusSystem
CommandCount=8

[CLS:CMenuRefresh]
Type=0
HeaderFile=MenuRefresh.h
ImplementationFile=MenuRefresh.cpp
BaseClass=CDialog
Filter=D
LastObject=CMenuRefresh
VirtualFilter=dWC

[DLG:IDD_Wait]
Type=1
Class=CWWait
ControlCount=5
Control1=IDC_Change,static,1342308352
Control2=IDCANCEL,button,1073807360
Control3=IDOK,button,1073807360
Control4=IDC_PROGRESS1,msctls_progress32,1350565889
Control5=IDC_STATIC,static,1342308352

[CLS:CWWait]
Type=0
HeaderFile=\project4d\code p\sourcecode\netview\wwait.h
ImplementationFile=\project4d\code p\sourcecode\netview\wwait.cpp
BaseClass=CDialog
LastObject=CWWait

[DLG:IDD_StatusPing]
Type=1
Class=StatusPing
ControlCount=3
Control1=IDCANCEL,button,1342242816
Control2=IDC_PingRESULT,edit,1350633600
Control3=IDC_STATIC,static,1342308364

[CLS:StatusPing]
Type=0
HeaderFile=StatusPing.h
ImplementationFile=StatusPing.cpp
BaseClass=CDialog
Filter=D
LastObject=ID_APP_ABOUT
VirtualFilter=dWC

[DLG:IDD_StatusSystem]
Type=1
Class=StatusSystem
ControlCount=2
Control1=IDCANCEL,button,1342242816
Control2=IDC_ShowSystem,edit,1353779332

[CLS:StatusSystem]
Type=0
HeaderFile=StatusSystem.h
ImplementationFile=StatusSystem.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_ShowSystem
VirtualFilter=dWC

