// NetstatR.h: interface for the CNetstatR class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETSTATR_H__494C18DB_F1A1_4909_A71C_3DB2A1598ECC__INCLUDED_)
#define AFX_NETSTATR_H__494C18DB_F1A1_4909_A71C_3DB2A1598ECC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNetstatR  
{
public:
	void AddNetstatDB();
	CString Netstatshow();
	CNetstatR();
	virtual ~CNetstatR();

};

#endif // !defined(AFX_NETSTATR_H__494C18DB_F1A1_4909_A71C_3DB2A1598ECC__INCLUDED_)
