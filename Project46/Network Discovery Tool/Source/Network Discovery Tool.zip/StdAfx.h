// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__019AE6A7_B46E_48AA_99D4_3BB02226395D__INCLUDED_)
#define AFX_STDAFX_H__019AE6A7_B46E_48AA_99D4_3BB02226395D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <afxdao.h>			// MFC DAO database classes
#include <afxsock.h>		// MFC socket extensions
#include <afxpriv.h>
#include <afxtempl.h>
#include <afx.h>
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
//#include <gl\glu.h>			//Use OpenGL Utility Library
//#include <Iphlpapi.h>
#endif // _AFX_NO_AFXCMN_SUPPORT

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__019AE6A7_B46E_48AA_99D4_3BB02226395D__INCLUDED_)
