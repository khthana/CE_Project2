#if !defined(AFX_STATUSPING_H__EEED5B0A_936C_4862_917B_87304EFB756A__INCLUDED_)
#define AFX_STATUSPING_H__EEED5B0A_936C_4862_917B_87304EFB756A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatusPing.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// StatusPing dialog

class StatusPing : public CDialog
{
// Construction
public:
	bool PingStatus;
	CString IPPing;
	void ShowPingResult();
	StatusPing(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(StatusPing)
	enum { IDD = IDD_StatusPing };
	CString	m_PingResult;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StatusPing)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(StatusPing)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATUSPING_H__EEED5B0A_936C_4862_917B_87304EFB756A__INCLUDED_)
