// StatusSystem.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "StatusSystem.h"
#include "Redirect.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// StatusSystem dialog


StatusSystem::StatusSystem(CWnd* pParent /*=NULL*/)
	: CDialog(StatusSystem::IDD, pParent)
{
	//{{AFX_DATA_INIT(StatusSystem)
	m_ShowSystem = _T("");
	//}}AFX_DATA_INIT
}


void StatusSystem::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StatusSystem)
	DDX_Text(pDX, IDC_ShowSystem, m_ShowSystem);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StatusSystem, CDialog)
	//{{AFX_MSG_MAP(StatusSystem)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// StatusSystem message handlers

void StatusSystem::ShowSystemResult()
{
	//.1.3.6.1.1.2.1.1.1
	CString str_Buffer;
	CString Temp;
	Method = "walk";
	IP = IPSystem;;
	CommunityName = "public";

	//System Description
	m_ShowSystem = "System Description : ";
	ObjID = ".1.3.6.1.2.1.1.1";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	CRedirect Redirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("String",0) + 6);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);

	//System Object ID
	m_ShowSystem = m_ShowSystem + CString("System Object ID : ");
	ObjID = ".1.3.6.1.2.1.1.2";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("ObjectID ",0) + 10);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);

	//System Up Time
	m_ShowSystem = m_ShowSystem + CString("System Up Time : ");
	ObjID = ".1.3.6.1.2.1.1.3";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("TimeTicks",0) + 10);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	//////////////////////////////////////////////////////////////////
	int num = atoi(Temp);
	num = num/100;
	int num2 = num/(24*60*60);
	char chartemp[2];
	if(num2 !=0)
	{
		itoa(num2,chartemp,10);
		m_ShowSystem = m_ShowSystem + CString(chartemp);
		m_ShowSystem = m_ShowSystem + CString(" Days ");
	}
	num = num % (24*60*60);
	num2 = num/(60*60);
	if(num2 !=0)
	{
		itoa(num2,chartemp,10);
		m_ShowSystem = m_ShowSystem + CString(chartemp);
		m_ShowSystem = m_ShowSystem + CString(" Hrs ");
	}
	num = num % (60*60);
	num2 = num/60;
	if(num2 !=0)
	{
		itoa(num2,chartemp,10);
		m_ShowSystem = m_ShowSystem + CString(chartemp);
		m_ShowSystem = m_ShowSystem + CString(" Minutes ");
	}
	num = num % 60;
	num2 = num;
	if(num2 !=0)
	{
		itoa(num2,chartemp,10);
		m_ShowSystem = m_ShowSystem + CString(chartemp);
		m_ShowSystem = m_ShowSystem + CString(" Second \n");
	}
	//////////////////////////////////////////////////////////////////
	Temp.Delete(0,Temp.GetLength()-2);
	m_ShowSystem = m_ShowSystem + CString(Temp);
	m_ShowSystem = m_ShowSystem + CString(Temp);
	//System Contact
	m_ShowSystem = m_ShowSystem + CString("System Contact : ");
	ObjID = ".1.3.6.1.2.1.1.4";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("String",0) + 6);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);

	//System Name
	m_ShowSystem = m_ShowSystem + CString("System Name : ");
	ObjID = ".1.3.6.1.2.1.1.5";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("String",0) + 6);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);

	//System Location
	m_ShowSystem = m_ShowSystem + CString("System Location : ");
	ObjID = ".1.3.6.1.2.1.1.6";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("String",0) + 6);
	Temp.Delete(Temp.Find("End",0),Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);

	//System Service
	m_ShowSystem = m_ShowSystem + CString("System Service : ");
	ObjID = ".1.3.6.1.2.1.1.7";
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
	Redirect.SetRedirect(str_Buffer);
	Redirect.Run();
	Temp = Redirect.str_Output;
	Redirect.Stop();
	if(Temp.Find("error",0) != -1)
	{
		m_ShowSystem = "Error SNMP";
		return;
	}
	Temp.Delete(0,Temp.Find("Integer32",0) + 10);
	Temp.Delete(Temp.Find("End",0)-2,Temp.GetLength()-Temp.Find("End"));
	m_ShowSystem = m_ShowSystem + CString(Temp);
}
