#if !defined(AFX_TABLENETWORK_H__54DFE0E4_3B72_4C48_89DB_8A089332BB82__INCLUDED_)
#define AFX_TABLENETWORK_H__54DFE0E4_3B72_4C48_89DB_8A089332BB82__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableNetwork.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TableNetwork DAO recordset

class TableNetwork : public CDaoRecordset
{
public:
	TableNetwork(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(TableNetwork)

// Field/Param Data
	//{{AFX_FIELD(TableNetwork, CDaoRecordset)
	CString	m_NetworkAddressFirst;
	CString	m_NetworkAddressEnd;
	CString	m_Netmask;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TableNetwork)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLENETWORK_H__54DFE0E4_3B72_4C48_89DB_8A089332BB82__INCLUDED_)
