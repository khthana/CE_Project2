//	WhoIsClass.cpp

//
//	Module : WhoIsClass.cpp
//	Purpose: Performs WHOIS processing for web addresses and host names
//
//
//	Created: Ed Dixon  2/22/00
//	History: Version 1.0
//	
//	Copyright (c) 2000 by Ed Dixon.  
//	All rights reserved.
//
//


//	Inlcude used based on how code is integrated
//#include "WhoIsClass.h"
#include "StdAfx.h"
#include "WhoIsClass.h"

CWhoIsClass::CWhoIsClass()
{
//	Init variables
	m_iWhoIsPort = IPPORT_WHOIS;						//	defined in WINSOCK.H
	m_szWhoIsServer = "whois.internic.net";				//	Default server
	m_szWhoIsServerIP = GetIpFromHost(m_szWhoIsServer);	//	IP for default server
}


CWhoIsClass::~CWhoIsClass()
{
}


void CWhoIsClass::SetWhoIsServer(LPCSTR szServerName)
{
//	Set new server and associated IP address
	m_szWhoIsServer = szServerName;
	m_szWhoIsServerIP = GetIpFromHost(szServerName);
}


CString CWhoIsClass::WhoIs(LPCSTR szAddress)
{
	char	szQuery[512];
	char	szBuffer[128];
	CString szResult = "";

//	Set query string
	strcpy(szQuery, szAddress);
	strcat(szQuery, " \r\n");

//	Create socket
	CSocket socket;
	 BOOL t = socket.Create();

//	Connect to server
	int iResult = socket.Connect(m_szWhoIsServerIP, IPPORT_WHOIS);

//	Quit on error
	if (iResult <= 0)
		return szResult;

//	Send whois query
	iResult = socket.Send(szQuery, strlen(szQuery));

//	Quit on error
	if (iResult <= 0)
		return szResult;

//	Get result
	szResult = "";
	while (TRUE)
	{
	//	Clear buffer before each iteration
		memset(szBuffer, 0, 128);

	//	Try to receive some data
		iResult = socket.Receive(szBuffer, 100);

	//	Quit if no more data
		if (iResult <= 0)
			break;

	//	Add this data to the result string
		szResult += szBuffer;
		//szResult += CString('\n');
	}

//	Close socket
	socket.Close();

//	Return result
	return szResult;
}


CString CWhoIsClass::GetIpFromHost(LPCSTR szHostName)
{
	int i,j;
	CString szResult = "";

//	Convert host name to IP address
 	hostent* pHost = gethostbyname(szHostName);

	for(i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++)
 	{ 
 		for(j = 0; j < pHost->h_length; j++)
 		{
			CString addr;
 
 			if(j > 0)
 				szResult += ".";
 
 			addr.Format("%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
			szResult += addr;
 		}
 	}

	return szResult;
}

CString CWhoIsClass::CutWhoisString(CString tempWhois)
{
	CString whois_want;
	tempWhois.Delete(0,tempWhois.Find("NetRange"));
	whois_want = tempWhois.Mid(12,tempWhois.Find("\n")-12);
	tempWhois.Delete(0,tempWhois.Find("CIDR"));
	whois_want.Insert(whois_want.GetLength(),'\n');
	whois_want = whois_want + tempWhois.Mid(12,tempWhois.Find("\n")-12);
	return whois_want;
}
