// NetstatR.cpp: implementation of the CNetstatR class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UI.h"
#include "NetstatR.h"
#include "Redirect.h"
#include "StatusIP.h"
//Database
#include "TableNetwork.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetstatR::CNetstatR()
{

}

CNetstatR::~CNetstatR()
{

}

CString CNetstatR::Netstatshow()
{
	CString tempshow;
	CRedirect redirect(".\\netstat -r");
	redirect.Run();
	tempshow = redirect.str_Output;
	redirect.Stop();
	return tempshow;
}

void CNetstatR::AddNetstatDB()
{
	//Initial Value
	CString netstat = Netstatshow();
	CString Network,Netmask,Gateway,Interface,Metric;
	CString tempnetstat = netstat;
	StatusIP checknetwork;
	//Initial Database
	TableNetwork DBNetwork;
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));

	tempnetstat.Delete(0,tempnetstat.Find("Metric",0));
	tempnetstat.Delete(0,tempnetstat.Find(' ',0));
	while(tempnetstat.GetAt(1) !='G' && Interface !="Network" && tempnetstat != "Table\013")
	{
		while(tempnetstat.GetAt(0) ==' ')
		{
			tempnetstat.Delete(0,1);
		}
		Network = tempnetstat;				//Network Address
		Network.Delete(Network.Find(' ',0),Network.GetLength() - Network.Find(' ',0));
		tempnetstat.Delete(0,tempnetstat.Find(' ',0));
		while(tempnetstat.GetAt(0) ==' ')
		{
			tempnetstat.Delete(0,1);
		}
		Netmask = tempnetstat;				//Netmask
		Netmask.Delete(Netmask.Find(' ',0),Netmask.GetLength() - Netmask.Find(' ',0));
		tempnetstat.Delete(0,tempnetstat.Find(' ',0));
		if (tempnetstat.GetAt(0) == 'T')
			return;
		while(tempnetstat.GetAt(0) ==' ')
		{
			tempnetstat.Delete(0,1);
		}
		Gateway = tempnetstat;				//Gateway
		Gateway.Delete(Gateway.Find(' ',0),Gateway.GetLength() - Gateway.Find(' ',0));
		tempnetstat.Delete(0,tempnetstat.Find(' ',0));
		while(tempnetstat.GetAt(0) ==' ')
		{
			tempnetstat.Delete(0,1);
		}
		Interface= tempnetstat;				//Interface
		Interface.Delete(Interface.Find(' ',0),Interface.GetLength() - Interface.Find(' ',0));
		tempnetstat.Delete(0,tempnetstat.Find(' ',0));
		while(tempnetstat.GetAt(0) ==' ')
		{
			tempnetstat.Delete(0,1);
		}
		Metric = tempnetstat;				//Metric
		Metric.Delete(Metric.Find('\n',0),Metric.GetLength() - Metric.Find(' ',0));
		int i=0;
		while(Metric.GetAt(i) !='\n')
		{
			i++;
		}
		Metric.Delete(i-1,2);
		tempnetstat.Delete(0,tempnetstat.Find(' ',0));
		if(Network !="127.0.0.0" && Network != "255.255.255.255" && Network !="0.0.0.0" && Network !="Table" && Interface !="Network" && Netmask !="255.255.255.255" && Gateway !="127.0.0.1" && Network !="224.0.0.0" && Network !="127.0.0.1")//Check True IP
		{
			//Check DB
			if (DBNetwork.IsBOF())				//Check For Start Not Value
			{
				DBNetwork.AddNew();
				DBNetwork.m_NetworkAddressFirst = checknetwork.CalcIPStart(Network,Netmask);
				DBNetwork.m_NetworkAddressEnd = checknetwork.CalcIPEnd(Network,Netmask);
				DBNetwork.m_Netmask = Netmask;
				DBNetwork.Update();

			}
			else
			{
				DBNetwork.m_strFilter = "NetworkAddressFirst = '" + checknetwork.CalcIPStart(Network,Netmask) +"'";
				DBNetwork.MoveFirst();
				DBNetwork.Requery();
				if (DBNetwork.GetRecordCount() == 0)
				{
					DBNetwork.AddNew();
					DBNetwork.m_NetworkAddressFirst = checknetwork.CalcIPStart(Network,Netmask);
					DBNetwork.m_NetworkAddressEnd = checknetwork.CalcIPEnd(Network,Netmask);
					DBNetwork.m_Netmask = Netmask;
					DBNetwork.Update();
				}
			}
		}
	}
}
