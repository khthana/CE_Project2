// CardInfo.cpp: implementation of the CCardInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UI.h"
#include "CardInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCardInfo::CCardInfo()
{
	ErrMsg = _T( "" );

	macaddress = _T( "" );
	description = _T( "" );
	type = _T( "" );
	subnet = _T( "" );
	IpAddress = _T( "" );
	gateway = _T( "" );
	PrimaryWinsServer = _T( "" );
	dhcp = _T( "" );

	ZeroMemory( m_data,4096 );
	len = 0;
	pinfo = ( PIP_ADAPTER_INFO )m_data;

	GetInfo();
}

CCardInfo::~CCardInfo()
{

}
void CCardInfo::GetInfo()
{
	ErrMsg = _T( "Success!" );

	unsigned long nError;

	nError = GetAdaptersInfo( pinfo,&len );
	switch( nError ) {
		case 0:
			ParseData();
			break;
		case ERROR_NO_DATA:
			ErrMsg = _T( "No net device information!" );
			break;
		case ERROR_NOT_SUPPORTED:
			ErrMsg = _T( "The system not support GetAdaptersInfo API function!" );
			break;
		case ERROR_BUFFER_OVERFLOW:
			nError = GetAdaptersInfo( pinfo,&len );
			if( nError == 0 ) ParseData();
			else ErrMsg = _T("Unknow error!");
			break;
	}
}

void CCardInfo::ParseData()
{
	macaddress.Format( _T("%02X:%02X:%02X:%02X:%02X:%02X"),pinfo->Address[0],pinfo->Address[1],pinfo->Address[2],pinfo->Address[3],pinfo->Address[4],pinfo->Address[5] );
	description = pinfo->Description;
	type.Format(_T("%d"),pinfo->Type);

	PIP_ADDR_STRING pAddressList = &(pinfo->IpAddressList);
	IpAddress = _T("");
	do {
		IpAddress += pAddressList->IpAddress.String;
		pAddressList = pAddressList->Next;
		if( pAddressList != NULL ) IpAddress += _T( "\r\n" );
	}while( pAddressList != NULL );

	subnet.Format( _T("%s"),pinfo->IpAddressList.IpMask.String );
	gateway.Format( _T("%s"),pinfo->GatewayList.IpAddress.String );
	if( pinfo->HaveWins )
		PrimaryWinsServer.Format( _T("%s"),pinfo->PrimaryWinsServer.IpAddress.String );
	else
		PrimaryWinsServer.Format( _T("%s"),_T("N/A") );
	if( pinfo->DhcpEnabled )
		dhcp.Format( _T("%s"),pinfo->DhcpServer.IpAddress.String );
	else
		dhcp.Format( _T("%s"),_T("N/A") );
	pinfo = pinfo->Next;
}

CString CCardInfo::GetNetCardType()
{
	return type;
}

CString CCardInfo::GetNetCardIPAddress()
{
	return IpAddress;
}

CString CCardInfo::GetNetCardSubnetMask()
{
	return subnet;
}

CString CCardInfo::GetNetCardGateWay()
{
	return gateway;
}

CString CCardInfo::GetDHCPServer()
{
	return dhcp;
}

CString CCardInfo::GetNetCardMACAddress()
{
	return macaddress;
}

CString CCardInfo::GetNetCardDeviceName()
{
	return description;
}

CString CCardInfo::GetNetCardWINS()
{
	return PrimaryWinsServer;
}

CString CCardInfo::GetErrorMsg()
{
	return ErrMsg;
}