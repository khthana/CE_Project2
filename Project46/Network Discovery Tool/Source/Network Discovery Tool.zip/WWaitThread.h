#if !defined(AFX_WWAITTHREAD_H__43E3904A_E7F7_4C27_B72C_2B0BB04F882C__INCLUDED_)
#define AFX_WWAITTHREAD_H__43E3904A_E7F7_4C27_B72C_2B0BB04F882C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WWaitThread.h : header file
//

#include <afxmt.h>

/////////////////////////////////////////////////////////////////////////////
// CWWaitThread thread

class CWWaitThread : public CWinThread
{
	DECLARE_DYNCREATE(CWWaitThread)
protected:
	CWWaitThread();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
   CWWaitThread	    *m_Thread;
   CEvent			*m_Event;
   CString           m_Eventname;
   CString			 m_Text;
   bool				 m_bShowCancelButton;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWWaitThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWWaitThread();

	// Generated message map functions
	//{{AFX_MSG(CWWaitThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WWAITTHREAD_H__43E3904A_E7F7_4C27_B72C_2B0BB04F882C__INCLUDED_)
