//	WhoIsClass.h

//
//	Module : WhoIsClass.h
//	Purpose: Performs WHOIS processing for web addresses and host names
//
//
//	Created: Ed Dixon  2/22/00
//	History: Version 1.0
//	
//	Copyright (c) 2000 by Ed Dixon.  
//	All rights reserved.
//
//


class CWhoIsClass
{
public:
	CString CutWhoisString(CString tempWhois);
//	Constructors / Destructors
	CWhoIsClass();
	~CWhoIsClass();

//	Routines
	CString WhoIs(LPCSTR szAddress);
	void	SetWhoIsServer(LPCSTR szServerName);

protected:

	CString GetIpFromHost(LPCSTR szHostName);

//	Variables
	int			m_iWhoIsPort;
	CString		m_szWhoIsServer;
	CString		m_szWhoIsServerIP;
};

