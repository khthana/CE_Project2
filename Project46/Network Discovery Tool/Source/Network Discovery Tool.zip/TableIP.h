#if !defined(AFX_TABLEIP_H__C8A58DDF_A4EF_4D74_A6D8_6A8049405C92__INCLUDED_)
#define AFX_TABLEIP_H__C8A58DDF_A4EF_4D74_A6D8_6A8049405C92__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableIP.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TableIP DAO recordset

class TableIP : public CDaoRecordset
{
public:
	TableIP(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(TableIP)

// Field/Param Data
	//{{AFX_FIELD(TableIP, CDaoRecordset)
	CString	m_NetworkAddressFirst;
	CString	m_IPAddress;
	BOOL	m_Alive;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TableIP)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLEIP_H__C8A58DDF_A4EF_4D74_A6D8_6A8049405C92__INCLUDED_)
