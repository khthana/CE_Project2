// SNMP.h: interface for the SNMP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SNMP_H__56C8D0C0_6753_4921_AB22_534C7C75076B__INCLUDED_)
#define AFX_SNMP_H__56C8D0C0_6753_4921_AB22_534C7C75076B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class SNMP  
{
public:
	SNMP(CString s_Method,CString s_IP,CString s_CommunityName,CString s_ObjID);
	SNMP();
	virtual ~SNMP();


public:
	void SNMPRoutingTable(CString s_IP,CString s_CommunityName);
	void SNMPChange(CString s_Method,CString s_IP,CString s_CommunityName,CString  s_ObjID);
	CString Result_SNMP();
	CString Result_SNMP(CString s_Method,CString s_IP,CString s_CommunityName,CString s_ObjID);
	CString str_Display;

private:
	CString ObjID;			//Object ID
	CString Method;			//Method
	CString CommunityName;	//Commnuity Name
	CString IP;				//IP
	CString str_Buffer;		//Save Text For Redirect;
};

#endif // !defined(AFX_SNMP_H__56C8D0C0_6753_4921_AB22_534C7C75076B__INCLUDED_)
