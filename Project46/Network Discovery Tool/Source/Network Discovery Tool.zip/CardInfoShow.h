#if !defined(AFX_CARDINFOSHOW_H__46A204F1_A295_4DAA_A2E6_1DC004ED9C8C__INCLUDED_)
#define AFX_CARDINFOSHOW_H__46A204F1_A295_4DAA_A2E6_1DC004ED9C8C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CardInfoShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCardInfoShow dialog

class CCardInfoShow : public CDialog
{
// Construction
public:
	CCardInfoShow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCardInfoShow)
	enum { IDD = IDD_CardInfo };
	CString	m_strShowCardInfo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCardInfoShow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCardInfoShow)
	afx_msg void OnGetCardInfo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CARDINFOSHOW_H__46A204F1_A295_4DAA_A2E6_1DC004ED9C8C__INCLUDED_)
