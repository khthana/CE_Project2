// WWait.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "WWait.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WWait dialog


CWWait::CWWait(CWnd* pParent /*=NULL*/)
	: CDialog(CWWait::IDD, pParent)
{
	//{{AFX_DATA_INIT(WWait)
	m_Change = _T("");
	//}}AFX_DATA_INIT
}


void CWWait::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WWait)
	DDX_Control(pDX, IDC_PROGRESS1, m_PgBar);
	DDX_Text(pDX, IDC_Change, m_Change);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWWait, CDialog)
	//{{AFX_MSG_MAP(CWWait)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WWait message handlers

void CWWait::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	//CSingleLock lock(m_Thread->m_Event, FALSE);
	if(m_PgBar.GetPos() >= 1000)
		m_PgBar.SetPos(0);
	else
		m_PgBar.StepIt();
	UpdateData(FALSE);
	CSingleLock lock(m_Thread->m_Event, FALSE);

	if (lock.Lock(0))
	{
		CDialog::OnOK();
	}
	
	CDialog::OnTimer(nIDEvent);
}

BOOL CWWait::OnInitDialog() 
{
	CDialog::OnInitDialog();
	//m_Thread->m_Event->SetEvent();
	// TODO: Add extra initialization here
	SetTimer(1,1,NULL);
	m_PgBar.SetRange(0,1000);
	m_PgBar.SetStep(1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CWWait::OnOK() 
{
	// TODO: Add extra validation here
	if (m_bShowCancelButton)
      {
	   m_Thread->m_Event->SetEvent();
	   CDialog::OnOK();
      }
	CDialog::OnOK();
}