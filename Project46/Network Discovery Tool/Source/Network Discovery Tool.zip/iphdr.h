typedef struct iphdr
{
	unsigned int version : 4;	//IPv4
	unsigned int ihl : 4;		//Header Length = 4 bit
	unsigned char tos;			//Type of Service
	unsigned short int tot_len;	//Total Length include Header length
	unsigned short int id;		//Identification
	unsigned short int frag_off;//Flagment Offset and Flags
	unsigned char ttl;			//Time To Live
	unsigned char protocol;		//Protocol
	unsigned short int checksum;//Header Checksum
	unsigned long int saddr;	//Source IP Address
	unsigned long int daddr;	//Destination IP Address
};