// PingShow.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "PingShow.h"
#include "ping.h"
#include "StatusIP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// PingShow dialog
//Global Variable
CString temp;

PingShow::PingShow(CWnd* pParent /*=NULL*/)
	: CDialog(PingShow::IDD, pParent)
{
	//{{AFX_DATA_INIT(PingShow)
	m_strEditPing = _T("");
	//}}AFX_DATA_INIT
}


void PingShow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PingShow)
	DDX_Text(pDX, IDC_EDITPing, m_strEditPing);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PingShow, CDialog)
	//{{AFX_MSG_MAP(PingShow)
	ON_BN_CLICKED(IDPING, OnPing)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PingShow message handlers

void PingShow::OnPing() 
{
	// TODO: Add your control notification handler code here
	//CString temp;
	UpdateData(TRUE);
	StatusIP CheckPing;
	//m_strEditPing
	CPing p1;
	CPingReply pr;
	char temp2[3]="";
	if (!CheckPing.CheckIP(m_strEditPing))
	{
		temp = temp + CString("Invalid IP Address \n");
		return;
	}
	if (p1.Ping(m_strEditPing, pr))
	{
		_itoa(pr.Address.S_un.S_un_b.s_b1,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b2,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b3,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b4,temp2,10);
		temp = temp + CString(temp2);
		hostent* phostent = gethostbyaddr((char *)&pr.Address.S_un.S_addr, 4, PF_INET);
		if(((CButton*)GetDlgItem(IDC_CHECKRESOLVEHOSNAME))->GetCheck())
		{
			temp = temp + CString (" [");
			temp = temp + phostent->h_name;
			temp = temp + CString("] ");
		}
		temp = temp + CString (", replied in RTT: ");
		_itoa(pr.RTT,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString (" ms \n");
	}
	else
	{
		temp =temp + CString(m_strEditPing);
		temp = temp + CString(" Request time out \n");
	}
	SetDlgItemText(IDC_PingRESULT,temp);
	UpdateData(FALSE);
	//temp = "";
}

BOOL PingShow::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CheckDlgButton(IDC_Ping_ICMPPING,1);
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
