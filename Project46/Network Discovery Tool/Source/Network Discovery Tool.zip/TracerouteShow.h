#if !defined(AFX_TRACEROUTESHOW_H__FA3517C6_9780_44B0_925C_D0F044073179__INCLUDED_)
#define AFX_TRACEROUTESHOW_H__FA3517C6_9780_44B0_925C_D0F044073179__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TracerouteShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TracerouteShow dialog

class TracerouteShow : public CDialog
{
// Construction
public:
	TracerouteShow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(TracerouteShow)
	enum { IDD = IDD_Traceroute };
	CString	m_strEditTraceroute;
	CString	m_strShowTraceroute;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TracerouteShow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(TracerouteShow)
	afx_msg void OnTrace();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACEROUTESHOW_H__FA3517C6_9780_44B0_925C_D0F044073179__INCLUDED_)
