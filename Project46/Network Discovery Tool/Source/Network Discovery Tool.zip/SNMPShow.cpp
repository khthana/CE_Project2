// SNMPShow.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "SNMPShow.h"
#include "Redirect.h"
#include "SNMP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SNMPShow dialog


SNMPShow::SNMPShow(CWnd* pParent /*=NULL*/)
	: CDialog(SNMPShow::IDD, pParent)
{
	//{{AFX_DATA_INIT(SNMPShow)
	m_SNMPMethod = _T("walk");
	m_SNMPOid = _T(".1.3.6.1.2.1.1.1");
	m_SNMPComunityName = _T("public");
	m_SNMPResult = _T("");
	//}}AFX_DATA_INIT
}


void SNMPShow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SNMPShow)
	DDX_Control(pDX, IDC_SNMPIPADDRESS, m_SNMPIPAddress);
	DDX_CBString(pDX, IDC_SNMPMethod, m_SNMPMethod);
	DDX_Text(pDX, IDC_SNMPOid, m_SNMPOid);
	DDX_Text(pDX, IDC_SNMPComunityName, m_SNMPComunityName);
	DDX_Text(pDX, IDCSNMPResult, m_SNMPResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(SNMPShow, CDialog)
	//{{AFX_MSG_MAP(SNMPShow)
	ON_BN_CLICKED(ID_SNMP, OnSnmp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SNMPShow message handlers

void SNMPShow::OnSnmp() 
{
	// TODO: Add your control notification handler code here
	CString IPAddress;	//IP Address For SNMP
	UpdateData(TRUE);
	m_SNMPIPAddress.GetWindowText(IPAddress);
	//(CString s_Method,CString s_IP,CString s_CommunityName,CString s_ObjID)
	CString m_SNMPOidTemp;
	if(m_SNMPOid =="System")
		m_SNMPOidTemp = ".1.3.6.1.2.1.1";
	else
		if(m_SNMPOid =="Interface Table")
			m_SNMPOidTemp = ".1.3.6.1.2.1.2";
		else
			if(m_SNMPOid =="Address Translate Table")
				m_SNMPOidTemp = ".1.3.6.1.2.1.3";
			else
				if(m_SNMPOid =="IP Address Table")
					m_SNMPOidTemp = ".1.3.6.1.2.1.4.20";
				else
					if(m_SNMPOid =="IP Route Table")
						m_SNMPOidTemp = ".1.3.6.1.2.1.4.21";
					else	
						if(m_SNMPOid =="IP Network To Media Table")
							m_SNMPOidTemp = ".1.3.6.1.2.1.4.22";
						else
							m_SNMPOidTemp = m_SNMPOid;
	SNMP snmp(m_SNMPMethod,IPAddress,m_SNMPComunityName,m_SNMPOidTemp);
	m_SNMPResult = snmp.Result_SNMP();
	UpdateData(FALSE);
}
