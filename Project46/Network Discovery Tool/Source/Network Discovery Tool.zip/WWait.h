#if !defined(AFX_WWAIT_H__D558B4DA_8E36_4E04_9E03_D7FA031FE1FD__INCLUDED_)
#define AFX_WWAIT_H__D558B4DA_8E36_4E04_9E03_D7FA031FE1FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WWait.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// WWait dialog
#include "WWaitThread.h"
class CWWait : public CDialog
{
// Construction
public:
	CWWait(CWnd* pParent = NULL);   // standard constructor
	CWWaitThread	   *m_Thread;
// Dialog Data
	//{{AFX_DATA(WWait)
	enum { IDD = IDD_Wait };
	CProgressCtrl	m_PgBar;
	CString	m_Change;
	bool           m_bShowCancelButton;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WWait)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(WWait)
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WWAIT_H__D558B4DA_8E36_4E04_9E03_D7FA031FE1FD__INCLUDED_)
