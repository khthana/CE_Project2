# Microsoft Developer Studio Project File - Name="UI" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=UI - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "UI.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "UI.mak" CFG="UI - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "UI - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "UI - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "UI - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "UI - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "UI - Win32 Release"
# Name "UI - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\CardInfo.cpp
# End Source File
# Begin Source File

SOURCE=.\CardInfoShow.cpp
# End Source File
# Begin Source File

SOURCE=.\Linklist.cpp
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\MenuRefresh.cpp
# End Source File
# Begin Source File

SOURCE=.\NetstatR.cpp
# End Source File
# Begin Source File

SOURCE=.\Newscan.cpp
# End Source File
# Begin Source File

SOURCE=.\ping.cpp
# End Source File
# Begin Source File

SOURCE=.\PingShow.cpp
# End Source File
# Begin Source File

SOURCE=.\Redirect.cpp
# End Source File
# Begin Source File

SOURCE=.\SNMP.cpp
# End Source File
# Begin Source File

SOURCE=.\SNMPShow.cpp
# End Source File
# Begin Source File

SOURCE=.\StatusIP.cpp
# End Source File
# Begin Source File

SOURCE=.\StatusPing.cpp
# End Source File
# Begin Source File

SOURCE=.\StatusSystem.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\TableAddressStep.cpp
# End Source File
# Begin Source File

SOURCE=.\TableIP.cpp
# End Source File
# Begin Source File

SOURCE=.\TableNetwork.cpp
# End Source File
# Begin Source File

SOURCE=.\TableRouter.cpp
# End Source File
# Begin Source File

SOURCE=.\ThreadIP.cpp
# End Source File
# Begin Source File

SOURCE=.\tracer.cpp
# End Source File
# Begin Source File

SOURCE=.\TracerouteShow.cpp
# End Source File
# Begin Source File

SOURCE=.\TraceTemp.cpp
# End Source File
# Begin Source File

SOURCE=.\UI.cpp
# End Source File
# Begin Source File

SOURCE=.\UI.rc
# End Source File
# Begin Source File

SOURCE=.\UIDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\UIView.cpp
# End Source File
# Begin Source File

SOURCE=.\WhoIsClass.cpp
# End Source File
# Begin Source File

SOURCE=.\WHOISShow.cpp
# End Source File
# Begin Source File

SOURCE=.\WNetstatDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\WWait.cpp
# End Source File
# Begin Source File

SOURCE=.\WWaitTarget.cpp
# End Source File
# Begin Source File

SOURCE=.\WWaitThread.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\CardInfo.h
# End Source File
# Begin Source File

SOURCE=.\CardInfoShow.h
# End Source File
# Begin Source File

SOURCE=.\ip_icmp.h
# End Source File
# Begin Source File

SOURCE=.\iphdr.h
# End Source File
# Begin Source File

SOURCE=.\IPHlpApi.h
# End Source File
# Begin Source File

SOURCE=.\Iprtrmib.h
# End Source File
# Begin Source File

SOURCE=.\IPTypes.h
# End Source File
# Begin Source File

SOURCE=.\Linklist.h
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\MenuRefresh.h
# End Source File
# Begin Source File

SOURCE=.\NetstatR.h
# End Source File
# Begin Source File

SOURCE=.\Newscan.h
# End Source File
# Begin Source File

SOURCE=.\ping.h
# End Source File
# Begin Source File

SOURCE=.\PingShow.h
# End Source File
# Begin Source File

SOURCE=.\Redirect.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\SNMP.h
# End Source File
# Begin Source File

SOURCE=.\SNMPShow.h
# End Source File
# Begin Source File

SOURCE=.\StatusIP.h
# End Source File
# Begin Source File

SOURCE=.\StatusPing.h
# End Source File
# Begin Source File

SOURCE=.\StatusSystem.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TableAddressStep.h
# End Source File
# Begin Source File

SOURCE=.\TableIP.h
# End Source File
# Begin Source File

SOURCE=.\TableNetwork.h
# End Source File
# Begin Source File

SOURCE=.\TableRouter.h
# End Source File
# Begin Source File

SOURCE=.\ThreadIP.h
# End Source File
# Begin Source File

SOURCE=.\tracer.h
# End Source File
# Begin Source File

SOURCE=.\TracerouteShow.h
# End Source File
# Begin Source File

SOURCE=.\TraceTemp.h
# End Source File
# Begin Source File

SOURCE=.\UI.h
# End Source File
# Begin Source File

SOURCE=.\UIDoc.h
# End Source File
# Begin Source File

SOURCE=.\UIView.h
# End Source File
# Begin Source File

SOURCE=.\WhoIsClass.h
# End Source File
# Begin Source File

SOURCE=.\WHOISShow.h
# End Source File
# Begin Source File

SOURCE=.\wnetstatDlg.h
# End Source File
# Begin Source File

SOURCE=.\WWait.h
# End Source File
# Begin Source File

SOURCE=.\WWaitTarget.h
# End Source File
# Begin Source File

SOURCE=.\WWaitThread.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\res\bitmap1.bmp
# End Source File
# Begin Source File

SOURCE=.\freeBSD_hdd_unmount.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Toolbar.bmp
# End Source File
# Begin Source File

SOURCE=.\res\UI.ico
# End Source File
# Begin Source File

SOURCE=.\res\UI.rc2
# End Source File
# Begin Source File

SOURCE=.\res\UIDoc.ico
# End Source File
# Begin Source File

SOURCE=.\iphlpapi.lib
# End Source File
# End Group
# Begin Source File

SOURCE=.\res\manifest.xml
# End Source File
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
