// StatusIP.cpp: implementation of the StatusIP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UI.h"
#include "StatusIP.h"
#include "CardInfo.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
CCardInfo cardinfo;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StatusIP::StatusIP()
{
	IPAddress = "0.0.0.0";
	SubnetIP = "0.0.0.0";
}
StatusIP::StatusIP(CString IPAddresstemp,CString SubnetIPtemp)
{
	IPAddress = IPAddresstemp;
	SubnetIP = SubnetIPtemp;
	
}

StatusIP::~StatusIP()
{

}

CString StatusIP::IPIncrease(CString IPtemp)
{
	CString StringIPBegin;
	int ipbeginfield1,ipbeginfield2,ipbeginfield3,ipbeginfield4;	//IP Address Field Begin
	CString buff,buff1;
	char buff2[3];
	CString buff3;
	//m_IPAddressBegin.GetWindowText(StringIPBegin);
	StringIPBegin = IPtemp;
	buff = StringIPBegin;
	buff1 = buff.Left(buff.Find('.'));	//Begin Convert IP To Integer
	ipbeginfield4 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	buff1 = buff.Left(buff.Find('.'));
	ipbeginfield3 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	buff1 = buff.Left(buff.Find('.'));
	ipbeginfield2 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	ipbeginfield1 = atoi(buff);
	ipbeginfield1++;
	//End Convert IP To Integer
	if (ipbeginfield1 > 255)				//Begin Check 255
	{
		ipbeginfield2++;
		ipbeginfield1 = ipbeginfield1 - 255;

	}
	if (ipbeginfield2 > 255)
	{
		ipbeginfield3++;
		ipbeginfield2 = ipbeginfield2 - 255;
	}
	if (ipbeginfield3 > 255)
	{
		ipbeginfield4++;
		ipbeginfield3 = ipbeginfield3 - 255;
	}
	//Check 255
	itoa(ipbeginfield4,buff2,10);					//Begin Convert Int To String
	buff3 = buff2;
	itoa(ipbeginfield3,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(ipbeginfield2,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(ipbeginfield1,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;	//End Convert Int To String
	return buff3;
}

CString StatusIP::IPIncrease()
{
	return IPIncrease(IPAddress);

}

BOOL StatusIP::IPConvertInt(CString IPtemp)		//For IP = CString To Int
{
	CString temp;
	temp = IPtemp.Left(IPtemp.Find(".",0));
	IP_Field1 = atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	temp = IPtemp.Left(IPtemp.Find(".",0));
	IP_Field2= atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	temp = IPtemp.Left(IPtemp.Find(".",0));
	IP_Field3 = atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	IP_Field4 = atoi(IPtemp);
	if (IP_Field1 > 255)
		return FALSE;
	else
		if (IP_Field2 > 255)
			return FALSE;
		else
			if (IP_Field3 > 255)
				return FALSE;
			else
				if (IP_Field3 >= 255)
					return FALSE;
	return TRUE;
}

BOOL StatusIP::IPConvertInt()
{
	return IPConvertInt(IPAddress);

}

BOOL StatusIP::SubnetConvertInt(CString IPtemp)
{
	CString temp;
	temp = IPtemp.Left(IPtemp.Find(".",0));
	Subnet_Field1 = atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	temp = IPtemp.Left(IPtemp.Find(".",0));
	Subnet_Field2= atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	temp = IPtemp.Left(IPtemp.Find(".",0));
	Subnet_Field3 = atoi(temp);
	IPtemp.Delete(0,IPtemp.Find(".",0)+1);
	Subnet_Field4 = atoi(IPtemp);
	if (Subnet_Field1 > 255)
		return FALSE;
	else
		if (Subnet_Field2 > 255)
			return FALSE;
		else
			if (Subnet_Field3 > 255)
				return FALSE;
			else
				if (Subnet_Field3 >= 255)
					return FALSE;
	return TRUE;
}

BOOL StatusIP::SubnetConvertInt()
{
	return SubnetConvertInt(SubnetIP);
}

CString StatusIP::CalcIPStart(CString IPtemp, CString Subnettemp)
{
	int temp_subnet1,temp_subnet2,temp_subnet3,temp_subnet4;
	int temp_ip=0;
	IPConvertInt(IPtemp);
	SubnetConvertInt(Subnettemp);
	temp_subnet1= (255 - Subnet_Field1) * 255 * 255;
	temp_subnet2= (255 - Subnet_Field2) * 255 * 255;
	temp_subnet3= (255 - Subnet_Field3) * 255;
	temp_subnet4= 255 - Subnet_Field4;
	Hostnum = temp_subnet1 + temp_subnet2 + temp_subnet3 + temp_subnet4 - 2;
	if (Subnet_Field1 ==255)
		if (Subnet_Field2 == 255)
			if (Subnet_Field3 == 255)
				return IntConcatString(IP_Field1,IP_Field2,IP_Field3,CheckIntSubnet(Subnet_Field4,IP_Field4));
			else
				return IntConcatString(IP_Field1,IP_Field2,CheckIntSubnet(IP_Field3,IP_Field3),0);
		else
			return IntConcatString(IP_Field1,CheckIntSubnet(Subnet_Field2,IP_Field2),0,0);
	else
		return IntConcatString(CheckIntSubnet(Subnet_Field1,IP_Field1),0,0,0);
}

CString StatusIP::CalcIPStart()
{
	return CalcIPStart(IPAddress,SubnetIP);
}

CString StatusIP::IntConcatString(int field1, int field2, int field3, int field4)
{
	char buff2[3];
	CString buff3;
	itoa(field1,buff2,10);					//Begin Convert Int To String
	buff3 = buff2;
	itoa(field2,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(field3,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(field4,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;	//End Convert Int To String
	return buff3;
}

int StatusIP::CheckIntSubnet(int subnetfield,int ipfield)
{
	int iptemp=0;
	int checkstep = 0;
	if(subnetfield >= 128 && checkstep == 0)
	{
		iptemp =iptemp + 128;
		subnetfield = subnetfield - 128;
		checkstep++;
	}
	if (subnetfield >= 64 && checkstep == 1)
	{
		iptemp = iptemp + 64;
		subnetfield = subnetfield - 64;
		checkstep++;
	}
	if (subnetfield >= 32 && checkstep == 2)
	{
		iptemp = iptemp + 32;
		subnetfield = subnetfield - 32;
		checkstep++;
	}
	if (subnetfield >= 16 && checkstep == 3)
	{
		iptemp = iptemp + 16;
		subnetfield = subnetfield - 16;
		checkstep++;
	}
	if (subnetfield >= 8 && checkstep == 4)
	{
		iptemp = iptemp + 8;
		subnetfield = subnetfield - 8;
		checkstep++;
	}
	if (subnetfield >= 4 && checkstep == 5)
	{
		iptemp = iptemp + 4;
		subnetfield = subnetfield - 4;
		checkstep++;
	}
	int tempsubnet = 256-iptemp;
	checkstep = -1;
	while(TRUE)
	{
		if(ipfield<checkstep)
		{
			checkstep = checkstep - tempsubnet + 1;
			break;
		}
		else
			checkstep = checkstep + tempsubnet;
	}
	//iptemp = 0;
	//checkstep=0;
	
	/*if(ipfield <= 128) //&& checkstep <= 0)
	{
		ipfield = ipfield - 128;
		iptemp = iptemp - 128;
		//checkstep++;
	}
	if (ipfield <= 64)// && checkstep <= 1)
	{
		ipfield = ipfield - 64;
		iptemp = iptemp - 64;
		//checkstep++;
	}
	if (ipfield <= 32)// && checkstep <= 2)
	{
		ipfield = ipfield - 32;
		iptemp = iptemp - 32;
		//checkstep++;
	}
	if (ipfield <= 16)// && checkstep <= 3)
	{
		ipfield = ipfield - 16;
		iptemp = iptemp - 16;
		//checkstep++;
	}
	if (ipfield <= 8)// && checkstep >= 4)
	{
		ipfield = ipfield - 8;
		iptemp = iptemp - 8;
		//checkstep++;
	}
	if (ipfield <= 4)// && checkstep >= 5)
	{
		ipfield = ipfield - 4;
		iptemp = iptemp - 4;
		//checkstep++;
	}*/
	
	return checkstep;

}

CString StatusIP::CalcIPEnd(CString IPtemp, CString Subnettemp)
{
	CString IPBegin;
	int fieldtemp1 = 255;
	int fieldtemp2 = 255;
	int fieldtemp3 = 255;
	int fieldtemp4 = 255;
	IPBegin = CalcIPStart(IPtemp,Subnettemp);
	SubnetConvertInt(Subnettemp);
	IPConvertInt(IPtemp);
	fieldtemp1 = fieldtemp1 - Subnet_Field1;
	fieldtemp2 = fieldtemp2 - Subnet_Field2;
	fieldtemp3 = fieldtemp3 - Subnet_Field3;
	fieldtemp4 = fieldtemp4 - Subnet_Field4;
	if (fieldtemp1 == 0)
		if (fieldtemp2 == 0)
			if (fieldtemp3 == 0)
				if (fieldtemp4 ==0)
					return IPBegin;
				else
					return IPPlusN(IPBegin,fieldtemp4,4);
			else
				return IPPlusN(IPBegin,fieldtemp3,3);
		else
			return IPPlusN(IPBegin,fieldtemp2,2);
	else
		return IPPlusN(IPBegin,fieldtemp1,1);
}

CString StatusIP::IPPlusN(CString IPtemp, int NumIP,int field)
{
	IPConvertInt(IPtemp);
	if (field == 1)
		IP_Field1 = IP_Field1 + NumIP;
	if (field == 2)
		IP_Field2 = IP_Field2 + NumIP;
	if (field == 3)
		IP_Field3 = IP_Field3 + NumIP;
	if (field == 4)
		IP_Field4 = IP_Field4 + NumIP;
	return IntConcatString(IP_Field1,IP_Field2,IP_Field3,IP_Field4);
}

BOOL StatusIP::CheckIP(CString IPtemp)
{
	IPConvertInt(IPtemp);
	if (IP_Field1 == 127)
		return FALSE;
	if (IP_Field1 == 0 && IP_Field2 == 0 && IP_Field3 == 0 && IP_Field4 == 0)
		return FALSE;
	if (IP_Field1 == 255 && IP_Field2 == 255 && IP_Field3 == 255 && IP_Field4 == 255)
		return FALSE;
	if (IPtemp.GetAt(0)=='0' || IPtemp.GetAt(0)=='1' || IPtemp.GetAt(0)=='2' || 
		IPtemp.GetAt(0)=='3' || IPtemp.GetAt(0)=='4' || IPtemp.GetAt(0)=='5' ||
		IPtemp.GetAt(0)=='6' || IPtemp.GetAt(0)=='7' || IPtemp.GetAt(0)=='8' ||
		IPtemp.GetAt(0)=='9')
		return TRUE;
	return FALSE;
}

BOOL StatusIP::BetweenIP(CString IPTempBegin, CString IPTempEnd, CString BetweenIP)
{
	int beginfield1,beginfield2,beginfield3,beginfield4;
	int endfield1,endfield2,endfield3,endfield4;
	int betweenfield1,betweenfield2,betweenfield3,betweenfield4;
	IPConvertInt(IPTempBegin);//Convert Begin IP to Int
	beginfield1 = IP_Field1;
	beginfield2 = IP_Field2;
	beginfield3 = IP_Field3;
	beginfield4 = IP_Field4;
	IPConvertInt(IPTempEnd);//Convert End IP to Int
	endfield1 = IP_Field1;
	endfield2 = IP_Field2;
	endfield3 = IP_Field3;
	endfield4 = IP_Field4;
	IPConvertInt(BetweenIP);
	betweenfield1 = IP_Field1;
	betweenfield2 = IP_Field2;
	betweenfield3 = IP_Field3;
	betweenfield4 = IP_Field4;
	if(beginfield1<=betweenfield1)
	{
		if(beginfield2<=betweenfield2)
		{
			if(beginfield3<=betweenfield3)
			{
				if(beginfield4<=betweenfield4)
				{
					if(endfield1>=betweenfield1)
					{
						if(endfield2>=betweenfield2)
						{
							if(endfield3>=betweenfield3)
							{
								if(endfield4>=betweenfield4)
								{
									return TRUE;
								}
							}
						}
					}
				}
			}
		}

	}
	return FALSE;
}
CString StatusIP::GetNetCardType()
{
	return cardinfo.GetNetCardType();
}

CString StatusIP::GetNetCardIPAddress()
{
	return cardinfo.GetNetCardIPAddress();
}

CString StatusIP::GetNetCardSubnetMask()
{
	return cardinfo.GetNetCardSubnetMask();
}

CString StatusIP::GetNetCardGateWay()
{
	return cardinfo.GetNetCardGateWay();
}

CString StatusIP::GetDHCPServer()
{
	return cardinfo.GetDHCPServer();
}

CString StatusIP::GetNetCardMACAddress()
{
	return cardinfo.GetNetCardMACAddress();
}

CString StatusIP::GetNetCardDeviceName()
{
	return cardinfo.GetNetCardDeviceName();
}

CString StatusIP::GetNetCardWINS()
{
	return cardinfo.GetNetCardWINS();
}
CString StatusIP::GetErrorMsg()
{
	return cardinfo.GetErrorMsg();
}

BOOL StatusIP::CompareIP(CString IPTemp1, CString IPTemp2)
{
	//Initial Value
	int field1,field2,field3,field4;
	int field11,field12,field13,field14;
	IPConvertInt(IPTemp1);
	field1 = IP_Field1;
	field2 = IP_Field2;
	field3 = IP_Field3;
	field4 = IP_Field4;
	IPConvertInt(IPTemp2);
	field11 = IP_Field1;
	field12 = IP_Field2;
	field13 = IP_Field3;
	field14 = IP_Field4;
	if(field1>field11)
		return TRUE;
	else
		if(field1<field11)
			return FALSE;
		else//field1 == field11
			if(field2>field12)
				return TRUE;
			else
				if(field2<field12)
					return FALSE;
				else//field1 = field11 and field2 = field12
					if(field3>field13)
						return TRUE;
					else
						if(field3<field13)
							return FALSE;
						else//1,2,3 = 1,2,3
							if(field4>=field14)
								return TRUE;
							else
								if(field4<field14)
									return FALSE;
								else//Equal IPTemp1 = IPTemp2
									return TRUE;;
}

CString StatusIP::IPDecrease(CString IPTemp)
{
	CString StringIPBegin;
	int ipbeginfield1,ipbeginfield2,ipbeginfield3,ipbeginfield4;	//IP Address Field Begin
	CString buff,buff1;
	char buff2[3];
	CString buff3;
	//m_IPAddressBegin.GetWindowText(StringIPBegin);
	StringIPBegin = IPTemp;
	buff = StringIPBegin;
	buff1 = buff.Left(buff.Find('.'));	//Begin Convert IP To Integer
	ipbeginfield4 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	buff1 = buff.Left(buff.Find('.'));
	ipbeginfield3 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	buff1 = buff.Left(buff.Find('.'));
	ipbeginfield2 = atoi(buff1);
	buff.Delete(0,buff.Find('.')+1);
	ipbeginfield1 = atoi(buff);
	ipbeginfield1--;
	//End Convert IP To Integer
	if (ipbeginfield1 <= -1)				//Begin Check 255
	{
		ipbeginfield2--;
		ipbeginfield1 = 0;
	}
	if (ipbeginfield2 <= -1)
	{
		ipbeginfield3--;
		ipbeginfield2 = 0;
	}
	if (ipbeginfield3 <= -1)
	{
		ipbeginfield4--;
		ipbeginfield3 = 0;
	}
	if(ipbeginfield4 <=-1)
		ipbeginfield4 = 0;
	//Check 255
	itoa(ipbeginfield4,buff2,10);					//Begin Convert Int To String
	buff3 = buff2;
	itoa(ipbeginfield3,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(ipbeginfield2,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;
	itoa(ipbeginfield1,buff2,10);
	buff3 = CString(buff3) + CString('.') + buff2;	//End Convert Int To String
	return buff3;
}
