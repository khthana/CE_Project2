//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UI.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_UITYPE                      129
#define IDD_Newscan                     130
#define IDD_Ping                        131
#define IDD_Traceroute                  132
#define IDD_WHOIS                       134
#define IDD_MenuREFRESH                 135
#define IDD_SNMP                        136
#define IDB_Test                        143
#define IDD_CardInfo                    144
#define IDD_WNetstat                    145
#define IDR_Property                    146
#define IDD_Wait                        148
#define IDD_StatusPing                  149
#define IDD_StatusSystem                152
#define Program                         155
#define IDC_SINGLEADDRESS               1000
#define IDC_RANGE                       1001
#define IDC_SUBNET                      1002
#define IDC_HOP                         1003
#define IDC_TYPE                        1004
#define IDC_IPADDRESS1                  1005
#define IDC_IPADDRESSSTART              1005
#define IDC_SNMPIPADDRESS               1005
#define IDC_IPADDRESS2                  1006
#define IDC_IPADDRESSEND                1006
#define IDC_BASIC                       1007
#define IDC_NUMHOP                      1008
#define IDC_RADIO6                      1009
#define IDC_CHECKPINGTRACERT            1010
#define IDC_CHECKRIP                    1011
#define IDC_CHECKSNMP                   1012
#define IDC_OPTION                      1013
#define IDC_EDIT1                       1014
#define IDC_EDITPing                    1014
#define IDC_CardInfoShow                1014
#define IDC_EDIT_STATS                  1014
#define IDC_ShowSystem                  1014
#define IDPING                          1015
#define IDC_Ping_TCPPING                1016
#define IDC_Ping_ICMPPING               1017
#define IDC_Ping_TCPICMPPING            1018
#define IDC_Ping_OPTION                 1019
#define IDC_CHECKPingRESOLVEHOSNAME     1020
#define IDC_CHECKPingTTL                1021
#define IDC_PingRESULT                  1022
#define IDTRACE                         1023
#define IDC_EDITTraceroute              1024
#define IDC_CHECK1                      1025
#define IDC_CHECK_PORTFILTER            1025
#define IDC_TracerouteRESULT            1026
#define IDC_WHOIS                       1027
#define IDWHOIS                         1028
#define IDC_EDITWHOIS                   1029
#define IDC_ResultWHOIS                 1030
#define IDC_EDITREFRESH                 1031
#define IDC_ADVANCE                     1040
#define IDC_CHECKRESOLVEHOSNAME         1046
#define ID_SNMP                         1052
#define IDC_SNMPComunityName            1054
#define IDC_SNMPOid                     1055
#define IDC_SNMPMethod                  1057
#define IDCSNMPResult                   1059
#define ID_GetCardInfo                  1061
#define IDC_BUTTON_CHECK                1062
#define IDC_COMBO_PROTOCOL              1064
#define IDC_COMBO_FILTER                1065
#define IDC_EDIT_PORTFILTER             1066
#define IDC_CHECK_IPFILTER              1067
#define IDC_EDIT_IPFILTER               1068
#define IDC_CHECK_RESOLVE               1069
#define IDC_CHECK_LOG                   1073
#define IDC_BUTTON_CLEAR                1074
#define IDC_BUTTON_SAVE                 1075
#define IDC_Routing                     1082
#define IDC_PROGRESS1                   1085
#define IDC_Change                      1086
#define IDC_BUTTONSCAN                  1090
#define ID_VIEW_REFRESH                 32772
#define ID_OPTION_CLEARDATABASE         32774
#define ID_OPTION_AUTOREFRESH_NONE      32775
#define ID_OPTION_AUTOREFRESH_AUTO      32776
#define ID_OPTION_AUTOREFRESH_EDIT      32777
#define ID_TOOL_NAMESERVERLOOKUP        32782
#define ID_MENURCLICK_EXPAND            32783
#define ID_MENURCLICK_CHECKSTATUS       32784
#define ID_MENURCLICK_COLLAPSE          32785
#define ID_MENURCLICK_HIDENODE          32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1094
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
