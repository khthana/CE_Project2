#if !defined(AFX_NEWSCAN_H__703AA068_0C04_4E5A_AAEA_7DB403015F9B__INCLUDED_)
#define AFX_NEWSCAN_H__703AA068_0C04_4E5A_AAEA_7DB403015F9B__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Newscan.h : header file
//
#include "ping.h"
/////////////////////////////////////////////////////////////////////////////
// Newscan dialog
UINT ThreadFuncX(LPVOID pParam);

class Newscan : public CDialog
{
// Construction
public:
	void CheckSNMPHop();
	CString PingForHop(CString IPBegin,CString IPEnd);
	void HopBasic();
	BOOL PingTracert_Check;
	BOOL SNMP_Check;
	BOOL RIP_Check;
	int Type_scan;//1=Full Option,2=Ping + Traceroute, 3=Ping + Traceroute + RIP, 4=RIP, 5=Ping + Traceroute + SNMP, 6=SNMP + RIP, 7=SNMP
	CString IPAddressEnd;
	CString IPAddressBegin;
	void CheckSNMP(CString IPBegin,CString IPEnd);
	void CheckRIP();
	void PingTraceroute(CString IPBegin,CString IPEnd);
	Newscan(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Newscan)
	enum { IDD = IDD_Newscan };
	CIPAddressCtrl	m_IPAddressEnd;
	CIPAddressCtrl	m_IPAddressStart;
	int	m_NumHop;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Newscan)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Newscan)
	afx_msg void OnSingleaddress();
	afx_msg void OnRange();
	afx_msg void OnSubnet();
	afx_msg void OnHop();
	afx_msg void OnBasic();
	afx_msg void OnAdvance();
	virtual void OnOK();
	afx_msg void OnButtonscan();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CWinThread* CheckPingThread[ 9 ];
	UINT ThreadFunc( LPVOID pParam );
	CPing PingThread[ 9 ];

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWSCAN_H__703AA068_0C04_4E5A_AAEA_7DB403015F9B__INCLUDED_)
