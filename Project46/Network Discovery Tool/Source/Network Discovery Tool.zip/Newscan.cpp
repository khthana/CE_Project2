// Newscan.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "Newscan.h"
#include "WhoIsClass.h"
#include "SNMP.h"
#include "WWaitTarget.h"
//#include "tracer.h"
//#include "ping.h"
//#include "TracerouteShow.h"
#include "StatusIP.h"
#include "TraceTemp.h"
#include "NetstatR.h"
#include "ThreadIP.h"
//Databse Access97
#include "TableAddressStep.h"
#include "TableIP.h"
#include "TableNetwork.h"
#include "TableRouter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Newscan dialog
UINT ThreadFuncX(LPVOID pParam)
{	
	ThreadIP *IPTemp = (ThreadIP*) pParam;
	CPing pingflood;
	CPingReply pr;
	IPTemp->alive = pingflood.Ping(IPTemp->IP,pr);
	return 0;
}

Newscan::Newscan(CWnd* pParent /*=NULL*/)
	: CDialog(Newscan::IDD, pParent)
{
	//{{AFX_DATA_INIT(Newscan)
	m_NumHop = 0;
	PingTracert_Check = FALSE;
	RIP_Check = FALSE;
	SNMP_Check = FALSE;
	//}}AFX_DATA_INIT
}


void Newscan::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Newscan)
	DDX_Control(pDX, IDC_IPADDRESSEND, m_IPAddressEnd);
	DDX_Control(pDX, IDC_IPADDRESSSTART, m_IPAddressStart);
	DDX_Text(pDX, IDC_NUMHOP, m_NumHop);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Newscan, CDialog)
	//{{AFX_MSG_MAP(Newscan)
	ON_BN_CLICKED(IDC_SINGLEADDRESS, OnSingleaddress)
	ON_BN_CLICKED(IDC_RANGE, OnRange)
	ON_BN_CLICKED(IDC_SUBNET, OnSubnet)
	ON_BN_CLICKED(IDC_HOP, OnHop)
	ON_BN_CLICKED(IDC_BASIC, OnBasic)
	ON_BN_CLICKED(IDC_ADVANCE, OnAdvance)
	ON_BN_CLICKED(IDC_BUTTONSCAN, OnButtonscan)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Newscan message handlers

void Newscan::OnSingleaddress() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_IPADDRESSSTART)->EnableWindow(TRUE);
	GetDlgItem(IDC_IPADDRESSEND)->EnableWindow(FALSE);
	GetDlgItem(IDC_NUMHOP)->EnableWindow(FALSE);
	SetDlgItemText(IDC_IPADDRESSEND,"0.0.0.0");	
	GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(TRUE);
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck())
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
}

void Newscan::OnRange() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_IPADDRESSSTART)->EnableWindow(TRUE);
	GetDlgItem(IDC_IPADDRESSEND)->EnableWindow(TRUE);
	GetDlgItem(IDC_NUMHOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(TRUE);
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck())
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);	
}

void Newscan::OnSubnet() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_IPADDRESSSTART)->EnableWindow(TRUE);
	GetDlgItem(IDC_IPADDRESSEND)->EnableWindow(TRUE);
	GetDlgItem(IDC_NUMHOP)->EnableWindow(FALSE);
	SetDlgItemText(IDC_IPADDRESSEND,"255.255.255.0");
	GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(TRUE);
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck())
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
}

void Newscan::OnHop() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_IPADDRESSSTART)->EnableWindow(FALSE);
	GetDlgItem(IDC_IPADDRESSEND)->EnableWindow(FALSE);
	GetDlgItem(IDC_NUMHOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
	//GetDlgItem(IDC_ADVANCE)->EnableWindow(FALSE);
	SetDlgItemText(IDC_IPADDRESSSTART,"0.0.0.0");
	SetDlgItemText(IDC_IPADDRESSEND,"0.0.0.0");
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck())
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
	
}
void Newscan::OnBasic() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECKRIP)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECKSNMP)->EnableWindow(FALSE);
}

void Newscan::OnAdvance() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(((CButton*)GetDlgItem(IDC_ADVANCE))->GetCheck() && ((CButton*)GetDlgItem(IDC_HOP))->GetCheck())
	{
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_CHECKPINGTRACERT)->EnableWindow(TRUE);
	}
	GetDlgItem(IDC_CHECKRIP)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECKSNMP)->EnableWindow(TRUE);
	UpdateData(FALSE);
}
void Newscan::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	CDialog::OnOK();
	StatusIP statusip;
	//CString t1,t2,t3;
	CString temp_BeginAddress,temp_EndAddress,temp_Netmask;
	CString buff_address_start,buff_address_end;

	//ForTest
	/*SNMP test;
	test.SNMPRoutingTable("10.1.4.1","public");*/
	//End Test

	//Initial Variable
	int temp_hop=0;
	m_IPAddressStart.GetWindowText(buff_address_start);
	m_IPAddressEnd.GetWindowText(buff_address_end);
	statusip.IPConvertInt(buff_address_start);
	if(!statusip.CompareIP(buff_address_end,buff_address_start))//Check For Begin > End Always
	{
		CString temp=buff_address_start;
		buff_address_start = buff_address_end;
		buff_address_end = temp;
	}
	if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())	//IP Address For Whois (Single Address)
	{	//Whois Check Network Range For Ping
		CWhoIsClass whoIs;
		whoIs.SetWhoIsServer("whois.arin.net");
		CString szResult = whoIs.WhoIs(buff_address_start);
		szResult = whoIs.CutWhoisString(szResult);
		//Add Information to Database
		TableNetwork DBNetwork;
		DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
		//CDaoRecordsetStatus rStatus;
		temp_BeginAddress = szResult.Left(szResult.Find("-")-1);	//Network Address Begin
		szResult.Delete(0,szResult.Find("-")+2);
		temp_EndAddress = szResult.Left(szResult.Find("\n"));		//Network Address End
		szResult.Delete(0,szResult.Find("/")+1);
		temp_Netmask = szResult.Left(szResult.Find(" "));
		//DBNetwork.GetStatus(rStatus);
		if (DBNetwork.IsBOF())				//Check For Start Not Value
		{
			DBNetwork.AddNew();
			DBNetwork.m_NetworkAddressFirst = temp_BeginAddress;
			DBNetwork.m_NetworkAddressEnd = temp_EndAddress;
			DBNetwork.m_Netmask = temp_Netmask;
			DBNetwork.Update();
			DBNetwork.m_strFilter = "";
			DBNetwork.Requery();
		}
		else
		{
			DBNetwork.m_strFilter = "NetworkAddressFirst = '" + temp_BeginAddress +"'";
			DBNetwork.MoveFirst();
			DBNetwork.Requery();
			if (DBNetwork.GetRecordCount() == 0)
			{
				DBNetwork.AddNew();
				DBNetwork.m_NetworkAddressFirst = temp_BeginAddress;
				DBNetwork.m_NetworkAddressEnd = temp_EndAddress;
				DBNetwork.m_Netmask = temp_Netmask;
				DBNetwork.Update();
				DBNetwork.m_strFilter = "";
				DBNetwork.Requery();
			}
		}

	}
	if(((CButton*)GetDlgItem(IDC_RANGE))->GetCheck())	//IP Range
	{
		//Error Message Check IP
		temp_BeginAddress = buff_address_start;
		temp_EndAddress = buff_address_end;
	}

	if(((CButton*)GetDlgItem(IDC_SUBNET))->GetCheck())	//IP Subnet
	{
		//Error Message Check IP
		temp_EndAddress = statusip.IPDecrease(statusip.CalcIPEnd(buff_address_start,buff_address_end));
		temp_BeginAddress = statusip.IPIncrease(statusip.CalcIPStart(buff_address_start,buff_address_end));
	}
	if(((CButton*)GetDlgItem(IDC_HOP))->GetCheck())	//Hop
	{
		//Error Message
		temp_hop = m_NumHop;
	}
	//File For Global Variable
	IPAddressBegin = temp_BeginAddress;
	IPAddressEnd = temp_EndAddress;

	//Check Basic And Advance
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck() && temp_hop == 0)	//Option Basic None Hop
	{
		PingTracert_Check = TRUE;
		RIP_Check = TRUE;
		SNMP_Check = TRUE;
		PingTraceroute(temp_BeginAddress,temp_EndAddress);
		CheckRIP();
		CheckSNMP(temp_BeginAddress,temp_EndAddress);
		Type_scan = 1;
	}
	if(((CButton*)GetDlgItem(IDC_ADVANCE))->GetCheck() && temp_hop == 0)	//Option Advance None Hop
	{
		if(((CButton*)GetDlgItem(IDC_CHECKPINGTRACERT))->GetCheck())
		{
			PingTracert_Check = TRUE;
			PingTraceroute(temp_BeginAddress,temp_EndAddress);
		}
		if(((CButton*)GetDlgItem(IDC_CHECKRIP))->GetCheck())
		{
			RIP_Check = TRUE;
			CheckRIP();
		}
		if(((CButton*)GetDlgItem(IDC_CHECKSNMP))->GetCheck())
		{
			SNMP_Check = TRUE;
			CheckSNMP(temp_BeginAddress,temp_EndAddress);
		}
	}
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck() && temp_hop != 0)	//Option Basic Hop
	{
		Type_scan = 5;
		HopBasic();
		if(((CButton*)GetDlgItem(IDC_CHECKRIP))->GetCheck())
		{
			CheckRIP();
			RIP_Check = TRUE;
		}
		if(((CButton*)GetDlgItem(IDC_CHECKSNMP))->GetCheck())
		{
			SNMP_Check = TRUE;
			CheckSNMPHop();
		}
	}
	/*if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck() && temp_hop != 0)	//Option Advance Hop
	{
		if(((CButton*)GetDlgItem(IDC_CHECKPINGTRACERT))->GetCheck())
			PingTraceroute(temp_BeginAddress,temp_EndAddress);
		if(((CButton*)GetDlgItem(IDC_CHECKRIP))->GetCheck())
			CheckRIP();
		if(((CButton*)GetDlgItem(IDC_CHECKSNMP))->GetCheck())
			CheckSNMP(temp_BeginAddress,temp_EndAddress);
	}*/
}

void Newscan::PingTraceroute(CString IPBegin, CString IPEnd)
{
	WWaitTarget wait;
	wait.Show("Ping Sweep");
	//CPing pingflood;
	//CPingReply pr;
	StatusIP ipincrease;
	TableIP DBIP;
	TableAddressStep DBAddressStep;
	TraceTemp testtrace;
	//testtrace.Traceroute(IPBegin,IPEnd);
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	DBAddressStep.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));
	CString IPNetwork = IPBegin;
	int i=0;
	CString Temp1,Temp2;
	ThreadIP IPTemp[11];
	IPTemp[0].IP = IPBegin;
	HANDLE handle[11];
	while (ipincrease.CompareIP(IPEnd,IPTemp[i].IP))
	{
		Temp1 = IPTemp[0].IP;
		i=0;
		int j=0;
		while(i<10)//Begin Thread
		{
			CheckPingThread[i] = AfxBeginThread( ThreadFuncX, (LPVOID)&IPTemp[i]);
			IPTemp[++i].IP = ipincrease.IPIncrease(IPTemp[i].IP);
			if(!ipincrease.CompareIP(IPEnd,IPTemp[i].IP))
				break;
		}
		Temp2 = IPTemp[i].IP;

		for(j=0;j< i;j++)//Stop Thread
		{
			handle[j] = CheckPingThread[j]->m_hThread;
			::WaitForSingleObject (handle[j], INFINITE);
		}
		j=0;
		while(j<i)
		{
			if (DBIP.IsBOF())				//Check For Start Not Value
			{
				DBIP.AddNew();
				DBIP.m_IPAddress = IPTemp[j].IP;
				DBIP.m_Alive = IPTemp[j].alive;
				//if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
				//	DBIP.m_NetworkAddressFirst = IPNetwork;
				DBIP.Update();
			}
			else
			{
				DBIP.m_strFilter = "IPAddress = '" + IPTemp[j].IP +"'";
				DBIP.MoveFirst();
				DBIP.Requery();
				if (DBIP.GetRecordCount() == 0)
				{
					DBIP.AddNew();
					DBIP.m_IPAddress = IPTemp[j].IP;
					DBIP.m_Alive = IPTemp[j].alive;
					//if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
					//	DBIP.m_NetworkAddressFirst = IPNetwork;
					DBIP.Update();
				}	
				else
				{
					DBIP.Edit();
					DBIP.m_Alive = IPTemp[j].alive;
					//if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
					//	DBIP.m_NetworkAddressFirst = IPNetwork;
					DBIP.Update();
				}
			}
			j++;
		}
		IPTemp[0].IP = IPTemp[i].IP;

	}
/////////////////////////////////////////////////////////////////////////////////////
	/*CString IPTemp=IPBegin;
	while (ipincrease.CompareIP(IPEnd,IPTemp))
	{

		if (DBIP.IsBOF())				//Check For Start Not Value
		{
			DBIP.AddNew();
			DBIP.m_IPAddress = IPTemp;
			DBIP.m_Alive = pingflood.Ping(IPTemp,pr);
			if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
				DBIP.m_NetworkAddressFirst = IPNetwork;
			DBIP.Update();
		}
		else
		{
			DBIP.m_strFilter = "IPAddress = '" + IPTemp +"'";
			DBIP.MoveFirst();
			DBIP.Requery();
			if (DBIP.GetRecordCount() == 0)
			{
				DBIP.AddNew();
				DBIP.m_IPAddress = IPTemp;
				DBIP.m_Alive = pingflood.Ping(IPTemp,pr);
				if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
					DBIP.m_NetworkAddressFirst = IPNetwork;
				DBIP.Update();
			}
			else
			{
				DBIP.Edit();
				DBIP.m_Alive = pingflood.Ping(IPTemp,pr);
				if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
					DBIP.m_NetworkAddressFirst = IPNetwork;
				DBIP.Update();
			}
		}
		///////////////////////////////////
		//pingflood.Ping(IPBegin,pr);
		//PingThread[i].Ping(IPBegin);
		//CheckPingThread[i] = AfxBeginThread( ThreadFuncX, (LPVOID)&PingThread[i]);
		//Traceroute Compatible
		IPTemp = ipincrease.IPIncrease(IPTemp);
	}*/
////////////////////////////////////////////////////////////////////////////////////////////////
	wait.Close();
	DBIP.Close();
	DBAddressStep.Close();
	wait.Show("Traceroute");
	testtrace.Traceroute(IPBegin,IPEnd);
	Type_scan =2;
	wait.Close();

}

void Newscan::CheckRIP()
{
	WWaitTarget wait;
	wait.Show("Check Netstat");
	CNetstatR netstat;
	netstat.AddNetstatDB();
	TableNetwork DBNetwork;
	TableIP DBIP;
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	if(!DBIP.IsBOF())
	{
		DBIP.MoveFirst();
		while(!DBIP.IsEOF())//Check IP NetworkAddress
		{
			DBNetwork.m_strFilter = "NetworkAddressFirst = '" + DBIP.m_IPAddress + "'";
			DBNetwork.Requery();
			if(DBNetwork.GetRecordCount() != 0)
			{
				DBIP.Delete();
				DBNetwork.m_strFilter = "";
				DBNetwork.Requery();
			}
			else
			{
				DBNetwork.m_strFilter = "";
				DBNetwork.Requery();
				DBNetwork.m_strFilter = "NetworkAddressEnd = '" + DBIP.m_IPAddress + "'";
				DBNetwork.Requery();
				if(DBNetwork.GetRecordCount() != 0)
				{
					DBIP.Delete();
				}
				DBNetwork.m_strFilter = "";
				DBNetwork.Requery();
			}
			DBIP.MoveNext();
		}
	}
	if(Type_scan == 2)
		Type_scan = 3;
	else
		Type_scan = 4;
	wait.Close();
}

void Newscan::CheckSNMP(CString IPBegin, CString IPEnd)
{
	WWaitTarget wait;
	wait.Show("Check SNMP");
	SNMP snmp;
	StatusIP Increase;
	TableIP DBIP;
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	TableNetwork DBNetwork;
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	if(DBIP.IsBOF())
	{
		while(Increase.CompareIP(IPEnd,IPBegin))
			snmp.SNMPRoutingTable(IPBegin,"public");
	}
	else
		while(Increase.CompareIP(IPEnd,IPBegin))
		{
			DBIP.m_strFilter = "IPAddress = '" + IPBegin +"'";
			DBIP.MoveFirst();
			DBIP.Requery();
			if (DBIP.GetRecordCount() != 0)
			{
				if(DBIP.m_Alive == TRUE)
				{
						snmp.SNMPRoutingTable(IPBegin,"public");
				}
				/////Begin For Check For Used/////
				DBNetwork.m_strFilter = "NetworkAddressFirst = '" + IPBegin + "'";
				DBNetwork.Requery();
				if(DBNetwork.GetRecordCount() != 0)
				{
					DBIP.Delete();
					DBNetwork.m_strFilter = "";
					DBNetwork.Requery();
				}
				else
				{
					DBNetwork.m_strFilter = "";
					DBNetwork.Requery();
					DBNetwork.m_strFilter = "NetworkAddressEnd = '" + IPBegin + "'";
					DBNetwork.Requery();
					if(DBNetwork.GetRecordCount() != 0)
					{
						DBIP.Delete();
					}
					DBNetwork.m_strFilter = "";
					DBNetwork.Requery();
				}
			////End For Check For Use////
			}
			/*else
			{	
				snmp.SNMPRoutingTable(IPBegin,"public");
			}*/
			IPBegin = Increase.IPIncrease(IPBegin);
			DBIP.m_strFilter ="";
			DBIP.Requery();
		}

	if(Type_scan == 2)
		Type_scan = 5;
	else if(Type_scan == 3)
		Type_scan =1;
	else if(Type_scan == 4)
		Type_scan = 6;
	else
		Type_scan = 7;
	DBIP.Close();
	DBNetwork.Close();

	wait.Close();
}

void Newscan::OnButtonscan() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	StatusIP statusip,statusip2;
	CString buff_address_start,buff_address_end;
	m_IPAddressStart.GetWindowText(buff_address_start);
	m_IPAddressEnd.GetWindowText(buff_address_end);
	statusip.IPConvertInt(buff_address_start);
	statusip2.IPConvertInt(buff_address_end);
	if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())	//IP Address For Whois (Single Address)
	{
		if (statusip.IP_Field1 == 0 || statusip.IP_Field1 == 127)
			return;
		else
			OnOK();
	}
	else
	if(((CButton*)GetDlgItem(IDC_BASIC))->GetCheck() && m_NumHop != 0)
	{

	}
	else
	{
		if(statusip.IP_Field1 == 0 || statusip.IP_Field1 == 127 || statusip2.IP_Field1 == 0 || 
			statusip2.IP_Field1 == 127)
		{
			MessageBox("IP Invalid","Caution",MB_ICONERROR);
			return;
		}
		if(((CButton*)GetDlgItem(IDC_RANGE))->GetCheck())
		{
			if(statusip2.IP_Field1 == 255)
				if(statusip2.IP_Field2 == 255)
					if(statusip2.IP_Field3 == 255)
					{
						if(statusip2.IP_Field4 != 254 && statusip2.IP_Field4 != 252 && statusip2.IP_Field4 != 248 &&
							statusip2.IP_Field4 != 240 && statusip2.IP_Field4 != 224 && statusip2.IP_Field4 != 192 &&
							statusip2.IP_Field4 != 192)
						{
							MessageBox("IP Invalid","Caution",MB_ICONERROR);
							return;
						}
					}
					else
						if(statusip2.IP_Field3 != 0 && statusip.IP_Field4 != 0)
						{
							MessageBox("IP Invalid","Caution",MB_ICONERROR);
							return;
						}
				else
				{
					if(statusip.IP_Field2 != 0 && statusip2.IP_Field3 != 0 && statusip.IP_Field4 != 0)
					{
						MessageBox("IP Invalid","Caution",MB_ICONERROR);
						return;
					}
				}
			else
				{
				if(statusip.IP_Field1 != 0 && statusip.IP_Field2 != 0 && statusip2.IP_Field3 != 0 && statusip.IP_Field4 != 0)
				{
					MessageBox("IP Invalid","Caution",MB_ICONERROR);
					return;
				}
			}
		}
	}
	OnOK();	
}

BOOL Newscan::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CheckDlgButton(IDC_BASIC,1);
	CheckDlgButton(IDC_SINGLEADDRESS,1);
	OnSingleaddress();
	OnBasic();
	//UpdateData(FALSE);
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void Newscan::HopBasic()//For Hop Only and Class B Only
{
	TableAddressStep DBStep;
	DBStep.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));
	TableNetwork DBNetwork;
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	StatusIP statusip;
	CString Netcard,SubnetMask,NetworkStart,NetworkEnd,CheckAlive;
	Netcard = statusip.GetNetCardIPAddress();
	SubnetMask = statusip.GetNetCardSubnetMask();
	NetworkStart = statusip.CalcIPStart(Netcard,SubnetMask);
	NetworkEnd = statusip.CalcIPEnd(Netcard,SubnetMask);
	//PingTraceroute(NetworkStart,NetworkEnd);
	statusip.IPConvertInt(NetworkStart);
	int field3 = statusip.IP_Field3;
	int Hight=0;
	TraceTemp testtrace;
	CString NetworkTemp = NetworkStart;
	CString NetworkForEnd = NetworkEnd;
	/////////////////////////////////////////////////////////////////////////
	for(int i=0;i<=255;i++)
	{
		statusip.IPConvertInt(NetworkTemp);
		if(statusip.IP_Field3-i <= 0)
			break;
		NetworkStart = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3-i,statusip.IP_Field4);
		statusip.IPConvertInt(NetworkForEnd);
		NetworkEnd = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3-i,statusip.IP_Field4);
		//Working
		CString CheckAlive = PingForHop(NetworkStart,NetworkEnd);
		CString temp;
		if(CheckAlive != "0.0.0.0")
		{
			/////For LOOP Near Network Address/////////////////////
				testtrace.Traceroute(NetworkStart,NetworkEnd);
				while(TRUE)
				{
					DBStep.m_strFilter ="";
					DBStep.Requery();
					DBStep.m_strFilter = "NextIP = '" + CheckAlive + "'";
					DBStep.Requery();
					if(DBStep.GetRecordCount() != 0)
					{
						Hight++;
						CheckAlive = DBStep.m_BeforeIP;
						//DBStep.m_strFilter ="";
						//DBStep.Requery();
						//DBStep.m_strFilter ="NextIP = '" + CheckAlive + "'";
						//DBStep.Requery();
						//if(DBStep.GetRecordCount() == 0)
						//	break;
					}
					else
					{
						break;
					}
				}
				if(Hight<=m_NumHop)//Add Network Address For Hop
				{
					if(DBNetwork.IsBOF())
					{
						DBNetwork.AddNew();
						DBNetwork.m_NetworkAddressFirst = NetworkStart;
						DBNetwork.m_NetworkAddressEnd = NetworkEnd;
						DBNetwork.Update();
					}
					else
					{
						DBNetwork.m_strFilter = "NetworkAddressFirst = '" + NetworkStart + "'";
						DBNetwork.Requery();
						if (DBNetwork.GetRecordCount() == 0)
						{
							DBNetwork.AddNew();
							DBNetwork.m_NetworkAddressFirst = NetworkStart;
							DBNetwork.m_NetworkAddressEnd = NetworkEnd;
							DBNetwork.Update();
						}
					}
				}
				else
				{
					while(TRUE)//For Search Begin AddressStep
					{
						DBStep.m_strFilter ="";
						DBStep.Requery();
						DBStep.m_strFilter = "NextIP = '" + CheckAlive + "'";
						DBStep.Requery();
						if(DBStep.GetRecordCount() != 0)
						{
							CheckAlive = DBStep.m_BeforeIP;
							temp = DBStep.m_NextIP;
							//DBStep.m_strFilter ="";
							//DBStep.Requery();
							//DBStep.m_strFilter ="BeforeIP = '" + CheckAlive + "'";
							//DBStep.Requery();
							//if(DBStep.GetRecordCount() == 0)
							//	break;
						}
						else
							break;
					}
					Hight = 0;
					while(Hight>=m_NumHop)//For Search Hop Want
					{
						DBStep.m_strFilter ="";
						DBStep.Requery();
						DBStep.m_strFilter = "NextIP = '" + temp + "'";
						DBStep.Requery();
						if(DBStep.GetRecordCount() != 0)
						{
							Hight++;
							temp = DBStep.m_NextIP;
						}
						else
							break;
						
					}
					statusip.IPConvertInt(temp);//For Ping Tracert
					NetworkStart = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3,0);
					NetworkEnd = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3,255);
					if(DBNetwork.IsBOF())
					{
						DBNetwork.AddNew();
						DBNetwork.m_NetworkAddressFirst = NetworkStart;
						DBNetwork.m_NetworkAddressEnd = NetworkEnd;
						DBNetwork.Update();
					}
					else
					{
						DBNetwork.m_strFilter = "NetworkAddressFirst = '" + NetworkStart + "'";
						DBNetwork.Requery();
						if (DBNetwork.GetRecordCount() == 0)
						{
							DBNetwork.AddNew();
							DBNetwork.m_NetworkAddressFirst = NetworkStart;
							DBNetwork.m_NetworkAddressEnd = NetworkEnd;
							DBNetwork.Update();
						}
					}	
				}
				/////////////////////////////////////////////
			}
		}//For int i Decrease
		//NetworkTemp = NetworkForBegin;
		for(i=1;i<=255;i++)
		{
			statusip.IPConvertInt(NetworkTemp);
			if(statusip.IP_Field3+i >= 255)
				break;
			NetworkStart = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3+i,statusip.IP_Field4);
			statusip.IPConvertInt(NetworkForEnd);
			NetworkEnd = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3+i,statusip.IP_Field4);
			//Working
			CString CheckAlive = PingForHop(NetworkStart,NetworkEnd);
			CString temp;
			if(CheckAlive != "0.0.0.0")
			{
				/////For LOOP Near Network Address/////////////////////
					testtrace.Traceroute(NetworkStart,NetworkEnd);
					while(TRUE)
					{
						DBStep.m_strFilter ="";
						DBStep.Requery();
						DBStep.m_strFilter = "NextIP = '" + CheckAlive + "'";
						DBStep.Requery();
						if(DBStep.GetRecordCount() != 0)
						{
							Hight++;
							CheckAlive = DBStep.m_BeforeIP;
							//DBStep.m_strFilter ="";
							//DBStep.Requery();
							//DBStep.m_strFilter ="NextIP = '" + CheckAlive + "'";
							//DBStep.Requery();
							//if(DBStep.GetRecordCount() == 0)	
							//	break;
						}
						else
						{
							break;
						}
					}
					if(Hight<=m_NumHop)//Add Network Address For Hop
					{
						if(DBNetwork.IsBOF())
						{
							DBNetwork.AddNew();
							DBNetwork.m_NetworkAddressFirst = NetworkStart;
							DBNetwork.m_NetworkAddressEnd = NetworkEnd;
							DBNetwork.Update();
						}
						else
						{
							DBNetwork.m_strFilter = "NetworkAddressFirst = '" + NetworkStart + "'";
							DBNetwork.Requery();
							if (DBNetwork.GetRecordCount() == 0)
							{
								DBNetwork.AddNew();
								DBNetwork.m_NetworkAddressFirst = NetworkStart;
								DBNetwork.m_NetworkAddressEnd = NetworkEnd;
								DBNetwork.Update();
							}
						}
					}
					else
					{
						while(TRUE)//For Search Begin AddressStep
						{
							DBStep.m_strFilter ="";
							DBStep.Requery();
							DBStep.m_strFilter = "NextIP = '" + CheckAlive + "'";
							DBStep.Requery();
							if(DBStep.GetRecordCount() != 0)
							{
								CheckAlive = DBStep.m_BeforeIP;
								temp = DBStep.m_NextIP;
							}
							else
								break;
						}
						Hight = 0;
						while(Hight>=m_NumHop)//For Search Hop Want
						{
							DBStep.m_strFilter ="";
							DBStep.Requery();
							DBStep.m_strFilter = "NextIP = '" + temp + "'";
							DBStep.Requery();
							if(DBStep.GetRecordCount() != 0)
							{
								Hight++;
								temp = DBStep.m_NextIP;
							}
							else
								break;
							
						}
						statusip.IPConvertInt(temp);//For Ping Tracert
						NetworkStart = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3,0);
						NetworkEnd = statusip.IntConcatString(statusip.IP_Field1,statusip.IP_Field2,statusip.IP_Field3,255);
						if(DBNetwork.IsBOF())
						{
							DBNetwork.AddNew();
							DBNetwork.m_NetworkAddressFirst = NetworkStart;
							DBNetwork.m_NetworkAddressEnd = NetworkEnd;
							DBNetwork.Update();
						}
						else
						{
							DBNetwork.m_strFilter = "NetworkAddressFirst = '" + NetworkStart + "'";
							DBNetwork.Requery();
							if (DBNetwork.GetRecordCount() == 0)
							{
								DBNetwork.AddNew();
								DBNetwork.m_NetworkAddressFirst = NetworkStart;
								DBNetwork.m_NetworkAddressEnd = NetworkEnd;
								DBNetwork.Update();
							}
						}	
					}
					/////////////////////////////////////////////
				}
			}//For int i Increase
	/*for(int i=0;i<255;i++)
	{
		
	}*/

	//CheckRIP();
	//TableNetwork DBNetwork;
	//DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));

}

CString Newscan::PingForHop(CString IPBegin, CString IPEnd)
{
	CString Check="0.0.0.0";
	StatusIP ipincrease;
	TableIP DBIP;
	TableAddressStep DBAddressStep;
	TraceTemp testtrace;
	//testtrace.Traceroute(IPBegin,IPEnd);
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	DBAddressStep.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));
	CString IPNetwork = IPBegin;
	int i=0;
	CString Temp1,Temp2;
	ThreadIP IPTemp[11];
	IPTemp[0].IP = IPBegin;
	HANDLE handle[11];
	while (ipincrease.CompareIP(IPEnd,IPTemp[i].IP))
	{
		Temp1 = IPTemp[0].IP;
		i=0;
		int j=0;
		while(i<11)//Begin Thread
		{
			CheckPingThread[i] = AfxBeginThread( ThreadFuncX, (LPVOID)&IPTemp[i]);
			IPTemp[++i].IP = ipincrease.IPIncrease(IPTemp[i].IP);
			if(!ipincrease.CompareIP(IPEnd,IPTemp[i].IP))
				break;
		}
		Temp2 = IPTemp[i].IP;

		for(j=0;j< i;j++)//Stop Thread
		{
			handle[j] = CheckPingThread[j]->m_hThread;
			::WaitForSingleObject (handle[j], INFINITE);
		}
		j=0;
		while(j<i)
		{
			if (DBIP.IsBOF())				//Check For Start Not Value
			{
				DBIP.AddNew();
				DBIP.m_IPAddress = IPTemp[j].IP;
				DBIP.m_Alive = IPTemp[j].alive;
				if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
					DBIP.m_NetworkAddressFirst = IPNetwork;
				DBIP.Update();
				if(IPTemp[j].alive == TRUE)
					Check = IPTemp[j].IP;
			}
			else
			{
				DBIP.m_strFilter = "IPAddress = '" + IPTemp[j].IP +"'";
				DBIP.MoveFirst();
				DBIP.Requery();
				if (DBIP.GetRecordCount() == 0)
				{
					DBIP.AddNew();
					DBIP.m_IPAddress = IPTemp[j].IP;
					DBIP.m_Alive = IPTemp[j].alive;
					if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
						DBIP.m_NetworkAddressFirst = IPNetwork;
					DBIP.Update();
				}	
				else
				{
					DBIP.Edit();
					DBIP.m_Alive = IPTemp[j].alive;
					if(((CButton*)GetDlgItem(IDC_SINGLEADDRESS))->GetCheck())
						DBIP.m_NetworkAddressFirst = IPNetwork;
					DBIP.Update();
				}
				if(IPTemp[j].alive == TRUE)
					Check = IPTemp[j].IP;
			}
			j++;
		}
		IPTemp[0].IP = IPTemp[i].IP;

	}
	return Check;
}

void Newscan::CheckSNMPHop()
{
	SNMP snmp;
	TableNetwork DBNetwork;
	TableIP DBIP;
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	StatusIP statusip;
	CString IPTempBegin,IPTempEnd;
	while(!DBNetwork.IsEOF())//Loop For Network
	{
		IPTempBegin = DBNetwork.m_NetworkAddressFirst;
		IPTempEnd = DBNetwork.m_NetworkAddressEnd;
		while(statusip.CompareIP(IPTempEnd,IPTempBegin))//Each Network SNMP
		{
			DBIP.m_strFilter = "";
			DBIP.Requery();
			DBIP.m_strFilter = "IPAddress ='" + IPTempBegin + "'";
			DBIP.Requery();
			if(DBIP.GetRecordCount() != 0)//Found IPAddres
			{
				if(DBIP.m_Alive == TRUE)//For Alive
				{
					snmp.SNMPRoutingTable(IPTempBegin,"public");
				}
			}
			IPTempBegin = statusip.IPIncrease(IPTempBegin);
		}
		DBNetwork.MoveNext();
	}
		
}
