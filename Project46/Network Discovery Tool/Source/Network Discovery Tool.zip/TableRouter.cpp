// TableRouter.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TableRouter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TableRouter

IMPLEMENT_DYNAMIC(TableRouter, CDaoRecordset)

TableRouter::TableRouter(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(TableRouter)
	m_Router_No = 0;
	m_IPAddress = _T("");
	m_InterfaceNo = _T("");;
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString TableRouter::GetDefaultDBName()
{
	return _T("DBComplete97.mdb");
}

CString TableRouter::GetDefaultSQL()
{
	return _T("[Router]");
}

void TableRouter::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(TableRouter)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[Router_No]"), m_Router_No);
	DFX_Text(pFX, _T("[IPAddress]"), m_IPAddress);
	DFX_Text(pFX, _T("[InterfaceNo]"), m_InterfaceNo);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// TableRouter diagnostics

#ifdef _DEBUG
void TableRouter::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void TableRouter::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
