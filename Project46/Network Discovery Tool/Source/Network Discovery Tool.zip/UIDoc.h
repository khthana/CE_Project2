// UIDoc.h : interface of the CUIDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_UIDOC_H__0F574A99_735B_4089_B776_F51E79D0441A__INCLUDED_)
#define AFX_UIDOC_H__0F574A99_735B_4089_B776_F51E79D0441A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CUIDoc : public CDocument
{
protected: // create from serialization only
	CUIDoc();
	DECLARE_DYNCREATE(CUIDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUIDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	CSize m_sizeViewDoc;
	CSize GetViewDocSize();
	virtual ~CUIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CUIDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UIDOC_H__0F574A99_735B_4089_B776_F51E79D0441A__INCLUDED_)
