// WHOISShow.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "WHOISShow.h"
#include "WhoIsClass.h"
#include "StatusIP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// WHOISShow dialog


WHOISShow::WHOISShow(CWnd* pParent /*=NULL*/)
	: CDialog(WHOISShow::IDD, pParent)
{
	//{{AFX_DATA_INIT(WHOISShow)
	m_strWHOISEdit = _T("");
	m_strWHOISShow = _T("");
	//}}AFX_DATA_INIT
}


void WHOISShow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WHOISShow)
	DDX_Text(pDX, IDC_EDITWHOIS, m_strWHOISEdit);
	DDX_Text(pDX, IDC_ResultWHOIS, m_strWHOISShow);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(WHOISShow, CDialog)
	//{{AFX_MSG_MAP(WHOISShow)
	ON_BN_CLICKED(IDWHOIS, OnWhois)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WHOISShow message handlers

void WHOISShow::OnWhois() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	StatusIP checkIP;
	//	Get input address	

//	Create class instance
	CWhoIsClass whoIs;
//	Set WHOIS server to network solutions
	if (checkIP.CheckIP(m_strWHOISEdit))
	{
		whoIs.SetWhoIsServer("whois.arin.net");
		CString szResult = whoIs.WhoIs(m_strWHOISEdit);
		m_strWHOISShow = szResult;
	}
	else
	{
		whoIs.SetWhoIsServer("whois.networksolutions.com");
		CString szResult = whoIs.WhoIs(m_strWHOISEdit);
		szResult.Delete(0,szResult.Find("Registration",0));
		m_strWHOISShow = szResult;
	}
//	Call actual function
	
//	Set result in display
	//SetDlgItemText(IDC_ResultWHOIS,szResult);
	//CEdit* theOutput = (CEdit*)GetDlgItem(IDC_ResultWHOIS); //Pointer to output box
	//m_strWHOISShow.Format(szResult);
	//theOutput->SetWindowText(m_strWHOISShow);
	UpdateData(FALSE);	
}
