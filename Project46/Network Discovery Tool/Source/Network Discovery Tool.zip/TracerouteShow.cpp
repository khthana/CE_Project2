// TracerouteShow.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TracerouteShow.h"
#include "tracer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TracerouteShow dialog
//Global Variable
//BOOL g_bResolveAddresses;

TracerouteShow::TracerouteShow(CWnd* pParent /*=NULL*/)
	: CDialog(TracerouteShow::IDD, pParent)
{
	//{{AFX_DATA_INIT(TracerouteShow)
	m_strEditTraceroute = _T("");
	m_strShowTraceroute = _T("");
	//}}AFX_DATA_INIT
}


void TracerouteShow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TracerouteShow)
	DDX_Text(pDX, IDC_EDITTraceroute, m_strEditTraceroute);
	DDX_Text(pDX, IDC_TracerouteRESULT, m_strShowTraceroute);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TracerouteShow, CDialog)
	//{{AFX_MSG_MAP(TracerouteShow)
	ON_BN_CLICKED(IDTRACE, OnTrace)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// TracerouteShow message handlers

void TracerouteShow::OnTrace() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	//g_bResolveAddresses = TRUE;
	UCHAR nHops = 30;
	DWORD dwTimeout = 300;
	int nPings = 1;
	CString IPString1,IPString2;
	CTraceRouteReply trr;
	CTraceRoute tr;
	if (tr.Trace(m_strEditTraceroute, trr, nHops, dwTimeout, nPings))
	 {
		CStdioFile trace_temp("temptrace.txt",CFile::modeRead);
		trace_temp.ReadString(IPString1);
		if (IPString1 == "" || (IPString1 == "0.0.0.0"))
		{
			SetDlgItemText(IDC_TracerouteRESULT,"Request time out \n");
			UpdateData(FALSE);
			trace_temp.Close();
			trace_temp.Remove("temptrace.txt");
			return;
		}
		//trace_temp.ReadString(IPString1);
		CString test;
		while (!feof(trace_temp.m_pStream))
		{
			trace_temp.ReadString(IPString2);
			IPString1 = IPString1 + CString("\n");
			if(IPString2.Find("11010",0)!= -1)
			{
				IPString1 = IPString1 + CString("Request Time Out \n");
				break;
			}
			else
			{
				IPString1 = IPString1 + CString(IPString2);
			}
		}
		trace_temp.Close();
		//CString temp ="temp.txt";
		trace_temp.Remove("temptrace.txt");
	 }
	m_strShowTraceroute = IPString1;
	//SetDlgItemText(IDC_TracerouteRESULT,IPString1);
	UpdateData(FALSE);
	
}
