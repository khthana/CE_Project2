#if !defined(AFX_TEBLEROUTER_H__9B571B7C_F6C6_4340_8AA9_75D95E7468C9__INCLUDED_)
#define AFX_TEBLEROUTER_H__9B571B7C_F6C6_4340_8AA9_75D95E7468C9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TebleRouter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TebleRouter DAO recordset

class TebleRouter : public CDaoRecordset
{
public:
	TebleRouter(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(TebleRouter)

// Field/Param Data
	//{{AFX_FIELD(TebleRouter, CDaoRecordset)
	long	m_ID;
	long	m_Router_No;
	CString	m_IPAddress;
	long	m_InterfaceNo;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TebleRouter)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEBLEROUTER_H__9B571B7C_F6C6_4340_8AA9_75D95E7468C9__INCLUDED_)
