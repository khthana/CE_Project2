#if !defined(AFX_MENUREFRESH_H__7BFC49FD_FEAF_4FCA_8B07_398883050C73__INCLUDED_)
#define AFX_MENUREFRESH_H__7BFC49FD_FEAF_4FCA_8B07_398883050C73__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MenuRefresh.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMenuRefresh dialog

class CMenuRefresh : public CDialog
{
// Construction
public:
	int TimerRefresh;
	CMenuRefresh(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMenuRefresh)
	enum { IDD = IDD_MenuREFRESH };
	int		m_Refresh;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMenuRefresh)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMenuRefresh)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MENUREFRESH_H__7BFC49FD_FEAF_4FCA_8B07_398883050C73__INCLUDED_)
