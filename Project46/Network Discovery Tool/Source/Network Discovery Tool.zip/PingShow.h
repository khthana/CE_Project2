#if !defined(AFX_PINGSHOW_H__D6240F03_11B0_4B2C_83D9_68B93EE3CD58__INCLUDED_)
#define AFX_PINGSHOW_H__D6240F03_11B0_4B2C_83D9_68B93EE3CD58__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PingShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PingShow dialog

class PingShow : public CDialog
{
// Construction
public:
	PingShow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(PingShow)
	enum { IDD = IDD_Ping };
	CString	m_strEditPing;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PingShow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PingShow)
	afx_msg void OnPing();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PINGSHOW_H__D6240F03_11B0_4B2C_83D9_68B93EE3CD58__INCLUDED_)
