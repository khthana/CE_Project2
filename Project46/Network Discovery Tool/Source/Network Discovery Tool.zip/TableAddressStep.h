#if !defined(AFX_TABLEADDRESSSTEP_H__D3755C9B_C293_4ED0_A3D5_BB162C89D786__INCLUDED_)
#define AFX_TABLEADDRESSSTEP_H__D3755C9B_C293_4ED0_A3D5_BB162C89D786__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableAddressStep.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TableAddressStep DAO recordset

class TableAddressStep : public CDaoRecordset
{
public:
	TableAddressStep(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(TableAddressStep)

// Field/Param Data
	//{{AFX_FIELD(TableAddressStep, CDaoRecordset)
	CString	m_BeforeIP;
	CString	m_NextIP;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TableAddressStep)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLEADDRESSSTEP_H__D3755C9B_C293_4ED0_A3D5_BB162C89D786__INCLUDED_)
