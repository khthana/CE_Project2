// TraceTemp.h: interface for the TraceTemp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRACETEMP_H__EA12EBCF_1D71_4E25_8E45_500304FF7280__INCLUDED_)
#define AFX_TRACETEMP_H__EA12EBCF_1D71_4E25_8E45_500304FF7280__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class TraceTemp  
{
public:
	void Traceroute(CString IPBegin,CString IPEnd);
	TraceTemp();
	virtual ~TraceTemp();

private:
	CString IPAddressBegin;
	CString IPAddressEnd;
};

#endif // !defined(AFX_TRACETEMP_H__EA12EBCF_1D71_4E25_8E45_500304FF7280__INCLUDED_)
