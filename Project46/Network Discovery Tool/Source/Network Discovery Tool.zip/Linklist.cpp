// Linklist.cpp: implementation of the Linklist class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UI.h"
#include "Linklist.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Linklist::Linklist()
{
	Router_no =="";
}

Linklist::~Linklist()
{
	/*delete IP;
	delete PosX;
	delete PosY;*/
}

void Linklist::SetIP(CString IPAddress)
{
	IP = IPAddress;
}

void Linklist::SetPosX(int x)
{
	PosX = x;
}

void Linklist::SetPosY(int y)
{
	PosY = y;
}

void Linklist::SetAlive(bool alive)
{
	Alive = alive;
}

CString Linklist::GetIP()
{
	return IP;
}

int Linklist::GetPosX()
{
	return PosX;
}

int Linklist::GetPosY()
{
	return PosY;
}
bool Linklist::GetAlive()
{
	return Alive;
}
/*void Linklist::OnContextMenu(CWnd* pWnd, CPoint point)//Left Click mouse property 
{
	// TODO: Add your message handler code here
	CMenu m_lMenu, *m_lSubMenu;
	m_lMenu.LoadMenu( IDR_Property );
	m_lSubMenu = m_lMenu.GetSubMenu( 0 );
	m_lSubMenu->TrackPopupMenu( TPM_LEFTBUTTON, 
							 point.x, point.y, this);
	m_lSubMenu->DestroyMenu();
}*/
