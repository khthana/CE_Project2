// MenuRefresh.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "MenuRefresh.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMenuRefresh dialog


CMenuRefresh::CMenuRefresh(CWnd* pParent /*=NULL*/)
	: CDialog(CMenuRefresh::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMenuRefresh)
	m_Refresh = 0;
	//}}AFX_DATA_INIT
}


void CMenuRefresh::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMenuRefresh)
	DDX_Text(pDX, IDC_EDITREFRESH, m_Refresh);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMenuRefresh, CDialog)
	//{{AFX_MSG_MAP(CMenuRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuRefresh message handlers

void CMenuRefresh::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	TimerRefresh = m_Refresh;
	TimerRefresh = TimerRefresh*60*1000;
	
	CDialog::OnOK();
}
