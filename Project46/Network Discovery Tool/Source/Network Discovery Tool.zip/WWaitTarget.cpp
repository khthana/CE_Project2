// WWaitTarget.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "WWaitTarget.h"
#include "WWaitThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWWaitTarget

IMPLEMENT_DYNCREATE(WWaitTarget, CCmdTarget)

WWaitTarget::WWaitTarget()
{
	m_EventName = "";
	m_bShowCancelButton = false;
}

WWaitTarget::~WWaitTarget()
{
}


BEGIN_MESSAGE_MAP(WWaitTarget, CCmdTarget)
	//{{AFX_MSG_MAP(CWWaitTarget)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWWaitTarget message handlers

void WWaitTarget::Show(CString Text)
{
   m_Event = CreateEvent(NULL, TRUE, FALSE, m_EventName);
   m_Thread = (CWWaitThread *)AfxBeginThread(RUNTIME_CLASS(CWWaitThread), THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
   m_Thread->m_Eventname = m_EventName;
   m_Thread->m_Text = Text;
   m_Thread->m_bShowCancelButton = m_bShowCancelButton;
   m_Thread->ResumeThread();
}

void WWaitTarget::Close()
{
	int i;
	m_Thread->m_Event->SetEvent();
	i = GetLastError();
	CloseHandle(m_Event);
	//CloseHandle(m_Thread);
	i = GetLastError();
}

void WWaitTarget::ChangeText(CString TextTemp)
{
	m_Thread->m_Text = TextTemp;
}
