 // SNMP.cpp: implementation of the SNMP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SNMP.h"
#include "Redirect.h"
#include "StatusIP.h"
//Include DB"
#include "TableNetwork.h"
#include "TableRouter.h"
#include "TableAddressStep.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SNMP::SNMP()
{
	str_Display = "Invalid Input";
}

SNMP::SNMP(CString s_Method,CString s_IP,CString s_CommunityName,CString s_ObjID)
{
	//buf = ".\\snmputil.exe walk 161.246.5.50 public .1.3.6.1.2.1.1.2";
	Method = s_Method;
	IP = s_IP;
	CommunityName = s_CommunityName;
	ObjID = s_ObjID;
}

SNMP::~SNMP()
{
}

CString SNMP::Result_SNMP(CString s_Method, CString s_IP, CString s_CommunityName, CString s_ObjID)
{
	Method = s_Method;
	IP = s_IP;
	CommunityName = s_CommunityName;
	ObjID = s_ObjID;
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;//str_Buffer is Input to run Snmputil.exe
	CRedirect Redirect(str_Buffer);
	Redirect.Run();
	str_Display = Redirect.str_Output;
	Redirect.Stop();
	return str_Display;
}

CString SNMP::Result_SNMP()
{
	return Result_SNMP(Method,IP,CommunityName,ObjID);
}

void SNMP::SNMPChange(CString s_Method, CString s_IP, CString s_CommunityName, CString s_ObjID)
{
	Method = s_Method;
	IP = s_IP;
	CommunityName = s_CommunityName;
	ObjID = s_ObjID;
	str_Buffer = ".\\snmputil.exe " + Method + " " + IP + " "+ CommunityName+" "+ ObjID;
}

void SNMP::SNMPRoutingTable(CString s_IP,CString s_CommunityName)
{
	//Initial Value

	IP = s_IP;
	CommunityName = s_CommunityName;
	CString Operator;
	CString IPRouteDest,IPRouteNextHop,IPAdEntAddr,IPRouteMask,IPAdEntNetMask,IPAdEntIfIndex;
	StatusIP ConvertIP;
	//Initial DB
	TableNetwork DBNetwork;
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	TableRouter DBRouter;
	DBRouter.Open(dbOpenDynaset,_T("Select * from Router"));
	//TableAddressStep DBAddressStep;
	//DBAddressStep.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));


	//Save SNMP In CString
	Operator = ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.21.1.1";//Network ddress
	CRedirect Redirect(Operator);
	Redirect.Run();
	IPRouteDest = Redirect.str_Output;
	Redirect.Stop();
	if (IPRouteDest.Find("error",0) != -1 || IPRouteDest.GetAt(0) == 'E')
		return;
	Operator= ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.21.1.7";//Next Hop
	Redirect.SetRedirect(Operator);
	Redirect.Run();
	IPRouteNextHop = Redirect.str_Output;
	Redirect.Stop();
	if (IPRouteNextHop.Find("error",0) != -1 || IPRouteNextHop.GetAt(0) =='E')
		return;
	Operator= ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.21.1.11";//Next Hop
	Redirect.SetRedirect(Operator);
	Redirect.Run();
	IPRouteMask = Redirect.str_Output;
	Redirect.Stop();
	if (IPRouteMask.Find("error",0) != -1 || IPRouteMask.GetAt(0) == 'E')
		return;
	Operator = ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.20.1.1";//IP
	Redirect.SetRedirect(Operator);
	Redirect.Run();
	IPAdEntAddr = Redirect.str_Output;
	Redirect.Stop();
	if (IPAdEntAddr.Find("error",0) != -1 || IPAdEntAddr.GetAt(0) =='E')
		return;
	Operator = ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.22.1.2";//Index Interface
	Redirect.SetRedirect(Operator);
	Redirect.Run();
	IPAdEntIfIndex = Redirect.str_Output;
	Redirect.Stop();
	if (IPAdEntIfIndex.Find("error",0) != -1 || IPAdEntIfIndex.GetAt(0) =='E')
		return;
	Operator = ".\\snmputil.exe walk " + IP + " "+ CommunityName +" .1.3.6.1.2.1.4.20.1.3";//Netmask
	Redirect.SetRedirect(Operator);
	Redirect.Run();
	IPAdEntNetMask = Redirect.str_Output;
	Redirect.Stop();
	if (IPAdEntNetMask.Find("error",0) != -1 || IPAdEntNetMask.GetAt(0) =='E')
		return;
	//For Don't Read SNMP
	//Working Cut String
	CString temp1 = IPRouteDest,temp2=IPRouteNextHop,
		temp3=IPAdEntAddr,index = IPRouteDest,index2=IPAdEntAddr;
	//For Index First
	index.Delete(0,IPRouteDest.Find("Dest.") + 5);
	index.Delete(index.Find("V")-2,index.GetLength() - index.Find("V")+2);
	index2.Delete(0,index2.Find("r.") + 2);
	index2.Delete(index2.Find("V")-2,index2.GetLength() - index2.Find("V")+2);
	CString tempindex=index,tempindex2=index2;
	int countbug=0;
	//Pack IPRouting Table
	while(TRUE)
	{
		index = IPRouteDest;
		temp1 = IPRouteDest;
		temp2 = IPRouteNextHop;
		temp3 = IPRouteMask;
		if(countbug != 0)
		{
			index.Delete(0,index.Find(tempindex));
			if(index.Find("Dest.") ==(-1))
				break;
			index.Delete(0,index.Find("Dest.") + 5);
			index.Delete(index.Find("V"),index.GetLength() - index.Find("V"));
			index.Delete(index.GetLength()-2,2);
			tempindex=index;
		}
		temp1.Delete(0,temp1.Find(index));
		temp1.Delete(0,temp1.Find("s") + 3);
		temp1.Delete(temp1.Find('\n'),temp1.GetLength() - temp1.Find('\n'));
		temp1.Delete(temp1.GetLength()-1,1);
		if(temp1.Find(' ') !=(-1))
			temp1.Delete(temp1.Find(' '),temp1.GetLength() - temp1.Find(' '));
		//
		temp2.Delete(0,temp2.Find(index));
		temp2.Delete(0,temp2.Find("s") + 3);
		temp2.Delete(temp2.Find('\n'),temp2.GetLength() - temp2.Find('\n'));
		temp2.Delete(temp2.GetLength()-1,1);
		if(temp2.Find(' ') !=(-1))
			temp2.Delete(temp2.Find(' '),temp2.GetLength() - temp2.Find(' '));
		//
		temp3.Delete(0,temp3.Find(index));
		temp3.Delete(0,temp3.Find("s") + 3);
		temp3.Delete(temp3.Find('\n') ,temp3.GetLength() - temp3.Find('\n'));
		temp3.Delete(temp3.GetLength()-1,1);
		if(temp3.Find(' ') !=(-1))
			temp3.Delete(temp3.Find(' '),temp3.GetLength() - temp3.Find(' '));
		countbug++;
		//Add To Database
		if(index !="0.0.0.0" && index !="224.0.0.0" && index !="255.255.255.255" && temp2 !=s_IP && temp3 != "255.255.255.255" && index !="127.0.0.1")
		{
			//DBNetwork,DBRouter, DBAddressStep
			if(!DBNetwork.IsBOF())
			{
				DBNetwork.m_strFilter = "NetworkAddressFirst = '" + temp1 +"'";
				DBNetwork.Requery();
				if (DBNetwork.GetRecordCount() == 0)//Table Network
				{
					DBNetwork.AddNew();
					DBNetwork.m_NetworkAddressFirst = temp1;
					DBNetwork.m_NetworkAddressEnd = ConvertIP.CalcIPEnd(temp1,temp3);
					DBNetwork.m_Netmask = temp3;
					DBNetwork.Update();
				}
				/*DBAddressStep.m_strFilter = "NextIP = '" + s_IP +"'";
				DBAddressStep.Requery();
				if(DBAddressStep.GetRecordCount() == 0)//Table Address Step
				{
					DBAddressStep.AddNew();
					DBAddressStep.m_BeforeIP = temp2;
					DBAddressStep.m_NextIP = s_IP;
					DBAddressStep.Update();
				}*/
			}
			else
			{
				DBNetwork.AddNew();
				DBNetwork.m_NetworkAddressFirst = temp1;
				DBNetwork.m_NetworkAddressEnd = ConvertIP.CalcIPEnd(temp1,temp3);
				DBNetwork.m_Netmask = temp3;
				DBNetwork.Update();
			}
			DBNetwork.m_strFilter = "";
			DBNetwork.Requery();
			//DBAddressStep.m_strFilter = "";
			//DBAddressStep.Requery();
			
		}

	}
	//Pack IPAddrTable
	countbug =0;
	int Router_no=0;
	char a[3];
	CString test;
	while(TRUE)//Search Router_No 
	{
		if(DBRouter.IsBOF())
			break;
		_itoa(Router_no,a,10);
		test = "Router_No = " + CString(a);
		DBRouter.m_strFilter = test;
		DBRouter.Requery();
		if (DBRouter.GetRecordCount() != 0)
			Router_no++;
		else
			break;

	}

	while(TRUE)
	{
		temp1 = IPAdEntAddr;
		temp2 = IPAdEntIfIndex;
		temp3 = IPAdEntNetMask;
		index2 = IPAdEntAddr;
		if(countbug !=0)
		{
			index2.Delete(0,index2.Find(tempindex2));
			if(index2.Find("r.") == (-1))
				break;
			index2.Delete(0,index2.Find("r.") + 2);
			index2.Delete(index2.Find("V"),index2.GetLength() - index2.Find("V"));
			index2.Delete(index2.GetLength()-2,2);
			if(index2.Find(' ') !=(-1))
				index2.Delete(index2.Find(' '),index2.GetLength() - index2.Find(' '));
			tempindex2 = index2;	
		}
		else
		{
			index2.Delete(0,index2.Find("r.") + 2);
			index2.Delete(index2.Find("V"),index2.GetLength() - index2.Find("V"));
			index2.Delete(index2.GetLength()-2,2);
			if(index2.Find(' ') !=(-1))
				index2.Delete(index2.Find(' '),index2.GetLength() - index2.Find(' '));
		}
		temp1.Delete(0,temp1.Find(index2));
		temp1.Delete(0,temp1.Find("s") + 3);
		temp1.Delete(temp1.Find('\n') - 1,temp1.GetLength() - temp1.Find('\n'));
		temp1.Delete(temp1.GetLength()-1,1);
		if(temp1.Find(' ') !=(-1))
			temp1.Delete(temp1.Find(' '),temp1.GetLength() - temp1.Find(' '));
		//
		if(temp2.Find(index2) == (-1))
			temp2 = "Error";
		else
		{
			temp2.Delete(0,temp2.Find(index2));
			temp2.Delete(0,temp2.Find("ng") + 3);
			temp2.Delete(temp2.Find('\n') - 1,temp2.GetLength() - temp2.Find('\n'));
			temp2.Delete(temp2.GetLength()-1,1);
			if(temp2.Find(' ') !=(-1))
				temp2.Delete(temp2.Find(' '),temp2.GetLength() - temp2.Find(' '));
		}

		//
		temp3.Delete(0,temp3.Find(index2));
		temp3.Delete(0,temp3.Find("s") + 3);
		temp3.Delete(temp3.Find('\n') - 1,temp3.GetLength() - temp3.Find('\n'));
		temp3.Delete(temp3.GetLength()-1,1);
		if(temp3.Find(' ') !=(-1))
			temp3.Delete(temp3.Find(' '),temp3.GetLength() - temp3.Find(' '));
		countbug++;
		int bug=0;
		if(index2 !="0.0.0.0" && index2 !="224.0.0.0" && index2 !="255.255.255.255" && index2 !="127.0.0.1")
		{
			//DBNetwork,DBRouter, DBAddressStep
			DBRouter.m_strFilter ="";
			DBRouter.Requery();
			DBRouter.m_strFilter = "IPAddress = '" + temp1 +"'";
			DBRouter.Requery();
			if (DBRouter.GetRecordCount() == 0)//Table Network
			{
				DBRouter.AddNew();
				DBRouter.m_Router_No = Router_no;
				DBRouter.m_IPAddress = temp1;
				if(temp2 != "Error")
					DBRouter.m_InterfaceNo = temp2;
				DBRouter.Update();
			}
			else
			{
				int Router_Temp = DBRouter.m_Router_No;
				while(TRUE)
				{
					if(DBRouter.m_IPAddress =="")
						break;
					if(DBRouter.m_IPAddress != temp1)
					{
						DBRouter.AddNew();
						DBRouter.m_Router_No = Router_no;
						DBRouter.m_IPAddress = temp1;
						if(temp2 != "Error")
							DBRouter.m_InterfaceNo = temp2;
						DBRouter.Update();
						break;
					}
					else
					{
						if(Router_Temp == Router_no)
							break;
						DBRouter.MoveNext();
					}
				}
			}
			DBNetwork.m_strFilter = "NetworkAddressFirst = '" + ConvertIP.CalcIPStart(temp1,temp3) +"'";
			DBNetwork.Requery();
			if(DBNetwork.GetRecordCount() == 0)//Table Address Step
			{//ConvertIP
				DBNetwork.AddNew();
				DBNetwork.m_NetworkAddressFirst = ConvertIP.CalcIPStart(temp1,temp3);
				DBNetwork.m_NetworkAddressEnd = ConvertIP.CalcIPEnd(temp1,temp3);
				DBNetwork.m_Netmask = temp3;
				DBNetwork.Update();
			}
			DBRouter.m_strFilter ="";
			DBRouter.Requery();
			DBNetwork.m_strFilter = "";
			DBNetwork.Requery();
		}

	}
	DBNetwork.Close();
	DBRouter.Close();
	//DBAddressStep.Close();
}