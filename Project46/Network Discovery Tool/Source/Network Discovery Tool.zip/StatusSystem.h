#if !defined(AFX_STATUSSYSTEM_H__67C59D85_1B32_43D9_B124_31FFB9F6E580__INCLUDED_)
#define AFX_STATUSSYSTEM_H__67C59D85_1B32_43D9_B124_31FFB9F6E580__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatusSystem.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// StatusSystem dialog

class StatusSystem : public CDialog
{
// Construction
public:
	CString IPSystem;
	void ShowSystemResult();
	StatusSystem(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(StatusSystem)
	enum { IDD = IDD_StatusSystem };
	CString	m_ShowSystem;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StatusSystem)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(StatusSystem)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString ObjID;
	CString CommunityName;
	CString IP;
	CString Method;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATUSSYSTEM_H__67C59D85_1B32_43D9_B124_31FFB9F6E580__INCLUDED_)
