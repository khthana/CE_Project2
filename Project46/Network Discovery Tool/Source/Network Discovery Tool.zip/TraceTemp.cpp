// TraceTemp.cpp: implementation of the TraceTemp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UI.h"
#include "TraceTemp.h"
#include "tracer.h"
#include "StatusIP.h"
// DB Access 97
#include "TableAddressStep.h"
#include "TableIP.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//Global Variable
//BOOL ResolveAddresses;

TraceTemp::TraceTemp()
{

}

TraceTemp::~TraceTemp()
{

}

void TraceTemp::Traceroute(CString IPBegin, CString IPEnd)
{
	TableAddressStep DBTraceroute;
	TableIP DBPing;
	DBTraceroute.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));
	DBPing.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	//g_bResolveAddresses = TRUE;
	UCHAR nHops = 30;
	DWORD dwTimeout = 300;
	int nPings = 1;
	CString IPStep;
	CString IPLoop = IPBegin;
	CTraceRouteReply trr;
	CTraceRoute tr;
	StatusIP ipincrease;
	if(DBPing.IsBOF())//For Error Ping No Record in Database
		return;
	while (ipincrease.CompareIP(IPEnd,IPBegin))
	{
		IPLoop = IPBegin;
		DBPing.m_strFilter = "IPAddress = '" + IPLoop + "'";	//For Search Ping == Alive ???
		DBPing.MoveFirst();
		DBPing.Requery();
		if (DBPing.GetRecordCount() == 0)
		{
			//MessageBox("Error Traceroute IP.","Error",MB_OK | MB_ICONINFORMATION);
			//DBPing.m_strFilter = "";
			//DBPing.Requery();
		}
		else
			if (DBPing.m_Alive == TRUE)
				if (tr.Trace(IPBegin,trr, nHops, dwTimeout, nPings))
				{
					trr.RemoveAll();
					CStdioFile ab("temptrace.txt",CFile::modeRead);
					ab.ReadString(IPLoop);
					//IPLoop = IPBegin;
					IPLoop.Delete(0,IPLoop.Find(":") + 2);
					IPLoop =IPLoop.Left(IPLoop.Find("M")-1);
					//IPLoop.Delete(0,2);
					while (!feof(ab.m_pStream))
					{
						ab.ReadString(IPStep);
						if(IPLoop != IPStep)
						{
							IPStep.Delete(0,IPStep.Find(":"));
							IPStep =IPStep.Left(IPStep.Find("M")-1);
							IPStep.Delete(0,2);
						}
						else
							IPStep = "";
						if(IPStep == IPLoop)
							break;
						if (((IPLoop == "0.0.0.0") || (IPLoop =="")) || 
							((IPStep == "")))	//Check For Bug Enter And Request Time Out
						{
							break;
						}
						else
						{
							if(IPStep == "0.0.0.0")//For Ping Done, Trace Fault
							{
								DBPing.Edit();
								DBPing.m_Alive = FALSE;
								DBPing.Update();
								break;
							}
							if (DBTraceroute.IsBOF())				//Check For Start Not Value
							{
								DBTraceroute.AddNew();	
								DBTraceroute.m_BeforeIP = IPLoop;
								DBTraceroute.m_NextIP = IPStep;
								DBTraceroute.Update();
								DBTraceroute.m_strFilter = "";
								DBTraceroute.Requery();
							}
							else
							{
								DBTraceroute.m_strFilter = "BeforeIP = '" + IPLoop +"'";
								DBTraceroute.Requery();
								if (DBTraceroute.GetRecordCount() == 0)
								{							
									DBTraceroute.AddNew();
									DBTraceroute.m_BeforeIP = IPLoop;
									DBTraceroute.m_NextIP = IPStep;
									DBTraceroute.Update();
									DBTraceroute.m_strFilter = "";
									DBTraceroute.Requery();
								}
								else
								{
									DBTraceroute.m_strFilter = "NextIP = '" + IPStep +"'";
									DBTraceroute.Requery();
									if (DBTraceroute.GetRecordCount() == 0)
									{
										DBTraceroute.AddNew();
										DBTraceroute.m_BeforeIP = IPLoop;
										DBTraceroute.m_NextIP = IPStep;
										DBTraceroute.Update();
										DBTraceroute.m_strFilter = "";
										DBTraceroute.Requery();
									}
								}
							}
						}
						IPLoop = IPStep;
					}
					ab.Close();
					CString temp ="temptrace.txt";
					ab.Remove(temp);
				}
		IPBegin = ipincrease.IPIncrease(IPBegin);
	}
}
