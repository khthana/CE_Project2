// Linklist.h: interface for the Linklist class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINKLIST_H__F4DD5088_2336_4FD1_A857_A80A0CCF92D4__INCLUDED_)
#define AFX_LINKLIST_H__F4DD5088_2336_4FD1_A857_A80A0CCF92D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Linklist  
{

public:
	CString Router_no;
	Linklist *NextY;
	Linklist *NextX;
	Linklist *PreviousY;
	Linklist *PreviousX;
	bool GetAlive();
	int GetPosY();
	int GetPosX();
	CString GetIP();
	void SetAlive(bool alive);
	void SetPosY(int y);
	void SetPosX(int x);
	void SetIP(CString IPAddress);
	Linklist();
	virtual ~Linklist();
/*protected:
	//{{AFX_MSG(Linklist)
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()*/
private:
	bool Alive;
	int PosY;
	int PosX;
	CString IP;
};

#endif // !defined(AFX_LINKLIST_H__F4DD5088_2336_4FD1_A857_A80A0CCF92D4__INCLUDED_)
