// StatusPing.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "StatusPing.h"
#include "ping.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// StatusPing dialog


StatusPing::StatusPing(CWnd* pParent /*=NULL*/)
	: CDialog(StatusPing::IDD, pParent)
{
	//{{AFX_DATA_INIT(StatusPing)
	m_PingResult = _T("");
	//}}AFX_DATA_INIT
}


void StatusPing::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StatusPing)
	DDX_Text(pDX, IDC_PingRESULT, m_PingResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StatusPing, CDialog)
	//{{AFX_MSG_MAP(StatusPing)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// StatusPing message handlers

void StatusPing::ShowPingResult()
{
	CPing p1;
	CPingReply pr;
	CString temp="";
	char temp2[3]="";
	if (p1.Ping(m_PingResult, pr))
	{
		PingStatus = TRUE;
		_itoa(pr.Address.S_un.S_un_b.s_b1,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b2,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b3,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString(".");
		_itoa(pr.Address.S_un.S_un_b.s_b4,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString (", replied in RTT: ");
		_itoa(pr.RTT,temp2,10);
		temp = temp + CString(temp2);
		temp = temp + CString (" ms \n");
	}
	else
	{
		temp = temp + CString(m_PingResult);
		temp = temp + CString("Request time out \n");
		PingStatus = FALSE;
	}
	m_PingResult = temp;
}