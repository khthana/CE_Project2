// CardInfo.h: interface for the CCardInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CARDINFO_H__8D0C82D5_FE6E_4B55_8340_8125C8ACB461__INCLUDED_)
#define AFX_CARDINFO_H__8D0C82D5_FE6E_4B55_8340_8125C8ACB461__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "IPHlpApi.h"
#include "iprtrmib.h"
#include "IPTypes.h"
class CCardInfo  
{
public:
	CString GetErrorMsg();
	CString GetNetCardWINS();
	CString GetNetCardDeviceName();
	CString GetNetCardMACAddress();
	CString GetDHCPServer();
	CString GetNetCardGateWay();
	CString GetNetCardSubnetMask();
	CString GetNetCardIPAddress();
	CString GetNetCardType();

	CCardInfo();
	virtual ~CCardInfo();

private:
	void ParseData();
	void GetInfo();
	BYTE m_data[4096];
	CString ErrMsg;
	CString macaddress;
	CString description;
	CString type;
	CString subnet;
	CString IpAddress;
	CString gateway;
	CString PrimaryWinsServer;
	CString dhcp;

	unsigned long len;
	PIP_ADAPTER_INFO pinfo;

};

#endif // !defined(AFX_CARDINFO_H__8D0C82D5_FE6E_4B55_8340_8125C8ACB461__INCLUDED_)
