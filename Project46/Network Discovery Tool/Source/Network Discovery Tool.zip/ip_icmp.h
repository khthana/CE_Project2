// Type ICMP Packet
#ifndef ICMP_ECHOREPLY
	#define ICMP_ECHO_REPLY 0
#endif
#ifndef ICMP_DEST_UNREACH
	#define ICMP_DEST_UNREACH 3
#endif
#ifndef ICMP_SOURCE_QUENCH
	#define ICMP_SOURCE_QUENCE 4
#endif
#ifndef ICMP_REDIRECT
	#define ICMP_REDIRECT 5
#endif
#ifndef ICMP_ECHO
	#define ICMP_ECHO 8
#endif
#ifndef ICMP_ROUTER_ADVISE
	#define ICMP_ROUTER_ADVISE 9
#endif
#ifndef ICMP_ROUTER_SOLICIT
	#define ICMP_ROUTER_SOLICIT 10
#endif
#ifndef ICMP_TIME_EXCEEDED
	#define ICMP_TIME_EXCEEDED 11
#endif
#ifndef ICMP_PARA_PROBLEM
	#define ICMP_PARA_PROBLEM 12
#endif
#ifndef ICMP_TIME_REQ
	#define ICMP_TIME_REQ 13
#endif
#ifndef ICMP_TIME_REPLY
	#define ICMP_TIME_REPLY 14
#endif
#ifndef ICMP_INF_REQ
	#define ICMP_INF_REQ 15
#endif
#ifndef ICMP_INF_REPLY
	#define ICMP_INF_REPLY 16
#endif
#ifndef ICMP_ADDRESS_MASK_REQ
	#define ICMP_ADDRESS_MASK_REQ 17
#endif
#ifndef ICMP_ADDRESS_MASK_REPLY
	#define ICMP_ADDRESS_MASK_REPLY 18
#endif
struct icmphdr
{
	unsigned char type;		//Type ICMP
	unsigned char code;		//Code
	unsigned short int checksum;
	union
	{
		struct
		{
			unsigned short int id;			//ID
			unsigned short int sequence;	//
		}echo;
	}un;
};