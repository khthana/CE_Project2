// StatusIP.h: interface for the StatusIP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATUSIP_H__204098FC_038E_4D38_83FA_F07099202541__INCLUDED_)
#define AFX_STATUSIP_H__204098FC_038E_4D38_83FA_F07099202541__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "CardInfo.h"
class StatusIP  
{
	
public:
	CString IPDecrease(CString IPTemp);
	BOOL CompareIP(CString IPTemp1,CString IPTemp2);
	//Check Own IP
	CString GetErrorMsg();
	CString GetNetCardWINS();
	CString GetNetCardDeviceName();
	CString GetNetCardMACAddress();
	CString GetDHCPServer();
	CString GetNetCardGateWay();
	CString GetNetCardSubnetMask();
	CString GetNetCardIPAddress();
	CString GetNetCardType();
	//Status IP Address
	BOOL BetweenIP(CString IPTempBegin,CString IPTempEnd,CString BetweenIP);
	BOOL CheckIP(CString IPtemp);							//Check IP For LoopBack and Non IP
	CString IPPlusN(CString IPtemp,int NumIP,int field);	//IPAddress Plus N By Choice Field (1,2,3,4)
	CString CalcIPEnd(CString IPtemp,CString Subnettemp);	//Calculate IPEnd In Subnet (Include CalcIPBegin,IPConvertInt)
	StatusIP(CString IPAddresstemp,CString SubnetIPtemp);
	StatusIP();
	CString IntConcatString(int field1,int field2,int field3,int field4);	//Change Int (Field 1-4) to String
	CString CalcIPStart();
	CString CalcIPStart(CString IPtemp,CString Subnettemp);	//Calculate IPBegin In Subnet
	BOOL SubnetConvertInt();
	BOOL SubnetConvertInt(CString IPtemp);
	BOOL IPConvertInt();
	BOOL IPConvertInt(CString IPtemp);
	CString IPIncrease();
	CString IPIncrease(CString IPtemp);
	//For Change String to Int
	int IP_Field1;				//Value From IPConvertInt
	int IP_Field2;
	int IP_Field3;
	int IP_Field4;				
	int Subnet_Field1;			//Value From SubnetConvertInt
	int Subnet_Field2;
	int Subnet_Field3;
	int Subnet_Field4;
	int Hostnum;				//Value From CalcIPStart
	virtual ~StatusIP();
private:
	int CheckIntSubnet(int subnetfield,int ipfield);
	CString IPAddress;
	CString SubnetIP;
};

#endif // !defined(AFX_STATUSIP_H__204098FC_038E_4D38_83FA_F07099202541__INCLUDED_)
