#if !defined(AFX_TABLEROUTER_H__7E07FE4E_EBED_47AE_87D8_14DE94A86252__INCLUDED_)
#define AFX_TABLEROUTER_H__7E07FE4E_EBED_47AE_87D8_14DE94A86252__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TableRouter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TableRouter DAO recordset

class TableRouter : public CDaoRecordset
{
public:
	TableRouter(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(TableRouter)

// Field/Param Data
	//{{AFX_FIELD(TableRouter, CDaoRecordset)
	long	m_Router_No;
	CString	m_IPAddress;
	CString	m_InterfaceNo;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TableRouter)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABLEROUTER_H__7E07FE4E_EBED_47AE_87D8_14DE94A86252__INCLUDED_)
