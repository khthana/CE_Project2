#if !defined(AFX_WHOISSHOW_H__47774744_FF93_40C8_91D9_6484FC110947__INCLUDED_)
#define AFX_WHOISSHOW_H__47774744_FF93_40C8_91D9_6484FC110947__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WHOISShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// WHOISShow dialog

class WHOISShow : public CDialog
{
// Construction
public:
	WHOISShow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(WHOISShow)
	enum { IDD = IDD_WHOIS };
	CString	m_strWHOISEdit;
	CString	m_strWHOISShow;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WHOISShow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(WHOISShow)
	afx_msg void OnWhois();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHOISSHOW_H__47774744_FF93_40C8_91D9_6484FC110947__INCLUDED_)
