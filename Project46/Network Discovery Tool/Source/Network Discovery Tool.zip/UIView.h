// UIView.h : interface of the CUIView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_UIVIEW_H__FD2FDA62_6ACF_44A3_970B_449C46B6E9BA__INCLUDED_)
#define AFX_UIVIEW_H__FD2FDA62_6ACF_44A3_970B_449C46B6E9BA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Linklist.h"
#include "TableAddressStep.h"
#include "TableIP.h"
#include "TableNetwork.h"
class CUIView : public CScrollView
{
protected: // create from serialization only
	CUIView();
	DECLARE_DYNCREATE(CUIView)

// Attributes
public:
	CUIDoc* GetDocument();
	Linklist *root;
	Linklist *linklist;
	Linklist *temproot;
	Linklist *tempprevious;
	Linklist *temppreviousX;
	Linklist *templink;
	Linklist *templink2;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUIView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL
// Implementation
public:
	void ChangeDBSNMP();
	void AddlinklistForHOP(TableIP *DBIPAddress,TableAddressStep *DBIPStep,TableNetwork *DBNetwork);
	BOOL CheckExpand;
	void OnDrawForHost(CDC *pDC);
	void ChangeDBFromRIP(TableAddressStep *DBIPStep);
	bool ChecklinklistPos(CPoint point);
	void CheckNetwork(CString IPTempBegin,CString IPTempEnd,int *hight);
	bool CheckLinklistINDB(CString IPTempBegin,CString IPTempEnd,TableAddressStep *DBIPStep,TableIP *DBIPAddress);
	void CheckRIP();
	void CheckSNMP();
	void addlinklist(CString Stepfirst,CString Steptwo,bool Checkfirst,bool CheckTwo);
	void DrawNetwork(CDC* pDC,TableAddressStep *DBStep);
	virtual ~CUIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void PrintPageCover(CDC *pDC,CPrintInfo *pInfo, CString &sTitle);
// Generated message map functions
protected:
	//{{AFX_MSG(CUIView)
	afx_msg void OnNewscan();
	afx_msg void OnPing();
	afx_msg void OnTraceroute();
	afx_msg void OnWhois();
	afx_msg void OnSnmp();
	afx_msg void OnCardInfo();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnWNetstat();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMenuREFRESH();
	afx_msg void OnMenurclickHidenode();
	afx_msg void OnMenurclickExpand();
	afx_msg void OnMenurclickCheckstatus();
	afx_msg void OnOptionAutorefreshAuto();
	afx_msg void OnOptionAutorefreshNone();
	afx_msg void OnUpdateOptionAutorefreshNone(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOptionAutorefreshAuto(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuREFRESH(CCmdUI* pCmdUI);
	afx_msg void OnOptionCleardatabase();
	afx_msg void OnStatusSystem();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL SNMPCheck;
	BOOL RIPCheck;
	bool IsSetTimer;
	void DeleteChild();
	int SizeY;
	int SizeX;
	UINT m_nTimer;
	int TimerForRefresh;
	void Line(CDC *pDC);
	int Type_Scan;
	/*Option
		1 = Full
		2 = Ping + Traceroute
		3 = Ping + Traceroute + RIP
		4 = RIP
		5 = Ping + Traceroute + SNMP
		6 = RIP + SNMP
		7 = SNMP
		8 = HOP
	*/
	int CheckOnScan;
	CString IPAddressEnd;
	CString IPAddressBegin;
	//CBitmap bmCom;
	//CDC memdcCom;
};

#ifndef _DEBUG  // debug version in UIView.cpp
inline CUIDoc* CUIView::GetDocument()
   { return (CUIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UIVIEW_H__FD2FDA62_6ACF_44A3_970B_449C46B6E9BA__INCLUDED_)
