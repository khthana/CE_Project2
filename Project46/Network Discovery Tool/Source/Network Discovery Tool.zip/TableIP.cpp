// TableIP.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TableIP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TableIP

IMPLEMENT_DYNAMIC(TableIP, CDaoRecordset)

TableIP::TableIP(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(TableIP)
	m_NetworkAddressFirst = _T("");
	m_IPAddress = _T("");
	m_Alive = FALSE;
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString TableIP::GetDefaultDBName()
{
	return _T("DBComplete97.mdb");
}

CString TableIP::GetDefaultSQL()
{
	return _T("[IPAddr]");
}

void TableIP::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(TableIP)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[NetworkAddressFirst]"), m_NetworkAddressFirst);
	DFX_Text(pFX, _T("[IPAddress]"), m_IPAddress);
	DFX_Bool(pFX, _T("[Alive]"), m_Alive);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// TableIP diagnostics

#ifdef _DEBUG
void TableIP::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void TableIP::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
