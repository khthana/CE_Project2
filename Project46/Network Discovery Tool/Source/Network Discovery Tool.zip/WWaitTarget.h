#if !defined(AFX_WWAITTARGET_H__250FDFBB_6868_404F_B1A2_4AC7D39653E5__INCLUDED_)
#define AFX_WWAITTARGET_H__250FDFBB_6868_404F_B1A2_4AC7D39653E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WWaitTarget.h : header file
//

#include "WWaitThread.h"

/////////////////////////////////////////////////////////////////////////////
// WWaitTarget command target

class WWaitTarget : public CCmdTarget
{
	DECLARE_DYNCREATE(WWaitTarget)

	WWaitTarget();           // protected constructor used by dynamic creation

// Attributes
public:
   CWWaitThread	   *m_Thread;
   HANDLE            m_Event;
   CString           m_EventName;

// Operations
public:
	void Close();
	void Show(CString Text);
	bool m_bShowCancelButton;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(WWaitTarget)
	//}}AFX_VIRTUAL

// Implementation
public:
	void ChangeText(CString TextTemp);
	virtual ~WWaitTarget();

private:
	// Generated message map functions
	//{{AFX_MSG(WWaitTarget)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WWAITTARGET_H__250FDFBB_6868_404F_B1A2_4AC7D39653E5__INCLUDED_)
