// TebleRouter.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TebleRouter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TebleRouter

IMPLEMENT_DYNAMIC(TebleRouter, CDaoRecordset)

TebleRouter::TebleRouter(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(TebleRouter)
	m_ID = 0;
	m_Router_No = 0;
	m_IPAddress = _T("");
	m_InterfaceNo = 0;
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString TebleRouter::GetDefaultDBName()
{
	return _T("D:\\Temp\\UI\\DBComplete97.mdb");
}

CString TebleRouter::GetDefaultSQL()
{
	return _T("[Router]");
}

void TebleRouter::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(TebleRouter)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[ID]"), m_ID);
	DFX_Long(pFX, _T("[Router_No]"), m_Router_No);
	DFX_Text(pFX, _T("[IPAddress]"), m_IPAddress);
	DFX_Long(pFX, _T("[InterfaceNo]"), m_InterfaceNo);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// TebleRouter diagnostics

#ifdef _DEBUG
void TebleRouter::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void TebleRouter::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
