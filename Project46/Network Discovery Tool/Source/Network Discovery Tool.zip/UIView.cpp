// UIView.cpp : implementation of the CUIView class
//

#include "stdafx.h"
#include "UI.h"

#include "UIDoc.h"
#include "UIView.h"
#include "Newscan.h"
#include "PingShow.h"
#include "SNMPShow.h"
#include "TracerouteShow.h"
#include "WHOISShow.h"
#include "StatusIP.h"
#include "CardInfoShow.h"
#include "wnetstatDlg.h"
#include "MenuRefresh.h"
#include "WWaitTarget.h"
#include "StatusPing.h"
#include "StatusSystem.h"
//Databse Table
#include "TableNetwork.h"
#include "TableRouter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUIView

IMPLEMENT_DYNCREATE(CUIView, CScrollView)

BEGIN_MESSAGE_MAP(CUIView, CScrollView)
	//{{AFX_MSG_MAP(CUIView)
	ON_COMMAND(IDD_Newscan, OnNewscan)
	ON_COMMAND(IDD_Ping, OnPing)
	ON_COMMAND(IDD_Traceroute, OnTraceroute)
	ON_COMMAND(IDD_WHOIS, OnWhois)
	ON_COMMAND(IDD_SNMP, OnSnmp)
	ON_COMMAND(IDD_CardInfo, OnCardInfo)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDD_WNetstat, OnWNetstat)
	ON_WM_TIMER()
	ON_COMMAND(IDD_MenuREFRESH, OnMenuREFRESH)
	ON_COMMAND(ID_MENURCLICK_HIDENODE, OnMenurclickHidenode)
	ON_COMMAND(ID_MENURCLICK_EXPAND, OnMenurclickExpand)
	ON_COMMAND(ID_MENURCLICK_CHECKSTATUS, OnMenurclickCheckstatus)
	ON_COMMAND(ID_OPTION_AUTOREFRESH_AUTO, OnOptionAutorefreshAuto)
	ON_COMMAND(ID_OPTION_AUTOREFRESH_NONE, OnOptionAutorefreshNone)
	ON_UPDATE_COMMAND_UI(ID_OPTION_AUTOREFRESH_NONE, OnUpdateOptionAutorefreshNone)
	ON_UPDATE_COMMAND_UI(ID_OPTION_AUTOREFRESH_AUTO, OnUpdateOptionAutorefreshAuto)
	ON_UPDATE_COMMAND_UI(IDD_MenuREFRESH, OnUpdateMenuREFRESH)
	ON_COMMAND(ID_OPTION_CLEARDATABASE, OnOptionCleardatabase)
	ON_COMMAND(IDD_StatusSystem, OnStatusSystem)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUIView construction/destruction

CUIView::CUIView()
{
	// TODO: add construction code here
	//CheckOnScan = 0;
	SizeX = 3200;
	SizeY = 2400;
	CheckExpand = FALSE;
	root = new Linklist;
	IPAddressBegin ="0.0.0.0";
	IPAddressEnd = "0.0.0.0";
	//For Test
	//RIPCheck = TRUE;
	//SNMPCheck = TRUE;
	//IPAddressBegin ="192.168.1.0";
	//IPAddressEnd ="192.168.1.51";

}

CUIView::~CUIView()
{
}

BOOL CUIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CUIView drawing

void CUIView::OnDraw(CDC* pDC)
{
	CUIDoc* pDoc = GetDocument();
 	ASSERT_VALID(pDoc);
	CRect edgeRect;
	pDC->RectVisible(&edgeRect);
	//For Test
	/*if(CheckOnScan <0)
	{
		CheckOnScan = 1;
		//Type_Scan = 4;
	}*/

	int i;	//For Check Error
	int bug=0; //For First Value
	if(Type_Scan == 8)//For HOP Only
	{
		WWaitTarget wait;
		wait.Show("Export Database To View");
		TableIP DBIPAddress;
		TableAddressStep DBIPStep;
		TableNetwork DBNetwork;

		//Initial Variable
		StatusIP statusip;
		CString IPTemp = IPAddressBegin;
		CString IPAlive,IPNetworkTemp;
		int CheckStatusAddLinklist=0;
		int BUGBUG=0;
		linklist = new Linklist;
		temproot = new Linklist;
		tempprevious = new Linklist;
		temppreviousX = new Linklist;

		bool Test = TRUE;
		CString tempipbug;
		root->SetIP(statusip.GetNetCardIPAddress());
		root->SetPosX(10);
		root->SetPosY(-10);
		root->SetAlive(Test);
		root->NextX ='\0';
		root->NextY ='\0';
		root->PreviousX = '\0';
		root->PreviousY = '\0';
		linklist->PreviousY = root;
		linklist = root;
		tempprevious = root;

		DBIPAddress.Open(dbOpenDynaset,_T("Select * From IPAddr"));
		DBIPStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
		DBNetwork.Open(dbOpenDynaset,_T("Select * From NetworkAddress"));

		AddlinklistForHOP(&DBIPAddress,&DBIPStep,&DBNetwork);
		CheckOnScan = 3;
		DBIPAddress.Close();
		DBIPStep.Close();
		wait.Close();
	}
	else if (CheckOnScan == 1 && Type_Scan != 4 && Type_Scan != 6 && Type_Scan != 7)
	{
		WWaitTarget wait;
		wait.Show("Export Database To View");
		/*if(CheckOnScan == 1)
		{
			pDC->TextOut(1,1,"Loading...");
		}*/

		//Initial Database
 		TableIP DBIPAddress;
		TableAddressStep DBIPStep;

		//Initial Variable
		StatusIP statusip;
		CString IPTemp = IPAddressBegin;
		CString IPAlive,IPNetworkTemp;
		int CheckStatusAddLinklist=0;
		int BUGBUG=0;
		//root = new Linklist;
		linklist = new Linklist;
		temproot = new Linklist;
		tempprevious = new Linklist;
		temppreviousX = new Linklist;

		bool Test = TRUE;
		CString tempipbug;
		root->SetIP(statusip.GetNetCardIPAddress());
		root->SetPosX(10);
		root->SetPosY(-10);
		root->SetAlive(Test);
		root->NextX ='\0';
		root->NextY ='\0';
		root->PreviousX = '\0';
		root->PreviousY = '\0';
		linklist->PreviousY = root;
		linklist = root;
		tempprevious = root;
		
		//Open Databse For Use
		DBIPAddress.Open(dbOpenDynaset,_T("Select * From IPAddr"));
		DBIPStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));

 		while(statusip.CompareIP(IPAddressEnd,IPTemp))
		{
			DBIPAddress.m_strFilter = "IPAddress = '" + IPTemp +"'";
			DBIPAddress.Requery();
			if (DBIPAddress.GetRecordCount() != 0)
			{
				if (!DBIPStep.IsBOF())						//Check For Database Value
				{
					DBIPStep.m_strFilter = "BeforeIP = '" + IPTemp + "'";
					DBIPStep.Requery();
					if (DBIPStep.GetRecordCount()==0)		//Search ???? Yes Or No
					{
    					DBIPStep.m_strFilter = "NextIP = '" + IPTemp + "'";
						DBIPStep.Requery();
						if (DBIPStep.GetRecordCount()!= 0)//
						{
							DBIPAddress.m_strFilter = "IPAddress = '" + DBIPStep.m_BeforeIP + "'";
							DBIPAddress.Requery();
							if (DBIPAddress.m_Alive == TRUE)//Before IP Alive
							{
								DBIPAddress.m_strFilter = "IPAddress = '" + DBIPStep.m_NextIP + "'";
								DBIPAddress.Requery();
								if(DBIPAddress.m_Alive == TRUE)//After IP Alive
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep.m_BeforeIP,DBIPStep.m_NextIP,&DBIPStep,&DBIPAddress);
								}
								else
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep.m_BeforeIP,DBIPStep.m_NextIP,&DBIPStep,&DBIPAddress);//After IP Dead
								}
							}
							else//Before Dead
							{
								DBIPAddress.m_strFilter = "IPAddress = '" + DBIPStep.m_BeforeIP + "'";
								DBIPAddress.Requery();
								if(DBIPAddress.m_Alive == TRUE)//After IP Alive
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep.m_BeforeIP,DBIPStep.m_NextIP,&DBIPStep,&DBIPAddress);
								}
								else
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep.m_BeforeIP,DBIPStep.m_NextIP,&DBIPStep,&DBIPAddress);//After IP Dead
								}
							}
						}
						else//Before IP No
						{
							if (DBIPAddress.m_Alive == TRUE)
							{
								linklist = root;
								tempipbug = DBIPAddress.m_IPAddress;
								addlinklist(root->GetIP(),DBIPAddress.m_IPAddress,TRUE,TRUE);
							}
						}
					}
					else//Not Traceroute Solve OwnIP ->IPThat
					{
						linklist = root;
						if(DBIPStep.m_BeforeIP == DBIPStep.m_NextIP)//Bug Unknow
						{
							addlinklist(root->GetIP(),DBIPStep.m_BeforeIP,TRUE,TRUE);
						}
						else
							CheckLinklistINDB(DBIPStep.m_BeforeIP,DBIPStep.m_NextIP,&DBIPStep,&DBIPAddress);//After IP Dead
					}
				}
				else//Not Traceroute Solve OwnIP -> IPThat
				{
					if(DBIPAddress.m_Alive == TRUE)
					{
						linklist = root;
						tempipbug = DBIPAddress.m_IPAddress;
						addlinklist(root->GetIP(),tempipbug,TRUE,TRUE);
					}
				}
			}

			IPTemp =statusip.IPIncrease(IPTemp);
			BUGBUG =0;
			DBIPAddress.m_strFilter ="";
			DBIPAddress.Requery();
			DBIPStep.m_strFilter ="";
			DBIPStep.Requery();
			//CountTemp++;
		}
		CheckOnScan = 3;
		DBIPAddress.Close();
		DBIPStep.Close();
		wait.Close();
	}
	else
		if(CheckOnScan == 1)
		{
			StatusIP statusip;
			root = new Linklist;
			root->SetIP(statusip.GetNetCardIPAddress());
			root->SetPosX(10);
			root->SetPosY(-10);
			root->SetAlive(TRUE);
			root->NextX ='\0';
			root->NextY ='\0';
			root->PreviousX = '\0';
			root->PreviousY = '\0';
			CheckOnScan = 3;
		}
	if(CheckOnScan == 3)//Check Linklist Change For SNMP RIP
	{
		linklist = root;
		//Type_Scan = 4;
		//WWaitTarget wait;
		//wait.Show("Export Database To View");
		if(SNMPCheck == TRUE)
		{
			linklist = root;
			CheckSNMP();
		}
		if(RIPCheck == TRUE)
			CheckRIP();
		CheckOnScan = 4;
		TableAddressStep DBIPStep;
		DBIPStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
		DrawNetwork(pDC,&DBIPStep);
		DBIPStep.Close();
		//For Router Number No Hide////////////////////////////////////////////
		linklist = root;
		TableRouter DBRouter;
		DBRouter.Open(dbOpenDynaset,_T("Select * From Router"));
		if(linklist->NextY !='\0')
			linklist = linklist->NextY;
		while(TRUE)
		{
			DBRouter.m_strFilter = "IPAddress = '" + linklist->GetIP() + "'";
			DBRouter.Requery();
			if(DBRouter.GetRecordCount() != 0)
			{
				int TempForRouter = DBRouter.m_Router_No;
				while(DBRouter.m_Router_No == TempForRouter)
				{
					if(DBRouter.m_IPAddress =="127.0.0.1" || DBRouter.m_IPAddress == "127.0.0.0")
					{
						templink->Router_no = CString("S");// + CString(temp);
						break;
					}
					else
					{
						DBRouter.MoveNext();
					}
				}
				if(linklist->Router_no != "S")
				{
					char temp[10];
					_itoa(TempForRouter,temp,10);
					DBRouter.m_strFilter ="";
					DBRouter.Requery();
					DBRouter.m_strFilter = "IPAddress ='" + linklist->GetIP() + "'";
					DBRouter.Requery();
					if(DBRouter.m_InterfaceNo == "")
						linklist->Router_no = CString("R") + CString(temp);
					else
						linklist->Router_no = DBRouter.m_InterfaceNo;
				}
			}
			DBRouter.m_strFilter ="";
			DBRouter.Requery();
			if(linklist->NextX =='\0')
				break;
			linklist = linklist->NextX;
		}
		//////////////////////////////////////////////////////////////////////
		//wait.Close();
	}
	if(CheckOnScan == 4)//For Draw Network By Linklist
	{
		//UpdateAllViews(NULL);
		linklist = root;
		//if(CheckExpand == TRUE)
		
		//if(pDC->RectVisible(&edgeRect))
		//{
			OnDrawForHost(pDC);
		//}
		//else
		//{
		//	TableAddressStep DBIPStep;
		//	DBIPStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
		//	DrawNetwork(pDC,&DBIPStep);
		//	DBIPStep.Close();
		//}
		//pDoc->UpdateAllViews(NULL);
	}
		//bmCom.LoadBitmap(IDB_Test);
		//memdcCom.SelectObject(&bmCom);
		//pDC->BitBlt(20,20,50,50,&memdcCom,0,0,SRCCOPY);
	// TODO: add draw code for native data here
	//bmCom.DeleteObject();
	//memdcCom.DeleteDC();
}

/////////////////////////////////////////////////////////////////////////////
// CUIView printing

BOOL CUIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	pInfo->SetMaxPage(1);
	BOOL bPrint = DoPreparePrinting(pInfo);
	pInfo->m_nNumPreviewPages = 1;
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CUIView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CUIView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CUIView diagnostics

#ifdef _DEBUG
void CUIView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CUIView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CUIDoc* CUIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CUIDoc)));
	return (CUIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUIView message handlers

void CUIView::OnNewscan() 
{
	// TODO: Add your command handler code here
	Newscan NewscanDlg(this);
	if (NewscanDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
		CheckOnScan = 1;//Check Scan
		Type_Scan = NewscanDlg.Type_scan;
		if(Type_Scan == 8)
		{
			IPAddressBegin = CString(NewscanDlg.IPAddressBegin);
			IPAddressEnd = CString(NewscanDlg.IPAddressEnd);
		}
		else
		{
			IPAddressBegin = NewscanDlg.IPAddressBegin;
			IPAddressEnd = NewscanDlg.IPAddressEnd;
		}
		RIPCheck = NewscanDlg.RIP_Check;
		SNMPCheck = NewscanDlg.SNMP_Check;
	}	
}

void CUIView::OnPing() 
{
	// TODO: Add your command handler code here
	PingShow PingShowDlg(this);
	if (PingShowDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}	
}

void CUIView::OnTraceroute() 
{
	// TODO: Add your command handler code here
	TracerouteShow TracerouteShowDlg(this);
	if (TracerouteShowDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}	
}

void CUIView::OnWhois() 
{
	// TODO: Add your command handler code here
	WHOISShow WHOISShowDlg(this);
	if (WHOISShowDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}
}

void CUIView::OnSnmp() 
{
	// TODO: Add your command handler code here
	SNMPShow SNMpShowDlg(this);
	if (SNMpShowDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}
}

void CUIView::OnCardInfo() 
{
	// TODO: Add your command handler code here
	CCardInfoShow CardInfoShowDlg(this);
	if (CardInfoShowDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}
}

void CUIView::OnWNetstat() 
{
	// TODO: Add your command handler code here
	WnetstatDlg WNetStatDlg(this);
	if (WNetStatDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
	}
}

void CUIView::OnMenuREFRESH() 
{
	// TODO: Add your command handler code here
	CMenuRefresh MenuRefreshDlg(this);
	if (MenuRefreshDlg.DoModal() == IDOK)
	{
		AfxGetMainWnd()->m_hWnd;
		TimerForRefresh = MenuRefreshDlg.TimerRefresh;
		m_nTimer = SetTimer(1, TimerForRefresh, 0);
	}
}

void CUIView::OnInitialUpdate() 
{
	CSize viewSize;
	viewSize = GetDocument()->GetViewDocSize();
	viewSize.cx = SizeX;
	viewSize.cy = SizeY;
	SetScrollSizes(MM_LOENGLISH,viewSize);
	//CheckOnScan = TRUE;
	CScrollView::OnInitialUpdate();
	// TODO: Add your specialized code here and/or call the base class
}

void CUIView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class	
	
}

void CUIView::DrawNetwork(CDC *pDC,TableAddressStep *DBIPStep)
{
	CPen pen;
	pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
	if(linklist->NextY =='\0')
	{
		//if(linklist->PreviousX =='\0' && linklist->NextX !='\0')//Line Cuttting
		//	Line(pDC);
		pDC->SelectObject(&pen);
		templink =linklist;
		if(linklist->PreviousX !='\0')
		{
		//	linklist->SetPosY(linklist->PreviousX->GetPosY() + 25);
		}
		else
		{	
			templink = linklist;
			if(templink->PreviousY !='\0')
			{
				templink = templink->PreviousY;
				while(templink->PreviousX == '\0')
				{
					if(templink == root)
						break;
					templink = templink->PreviousY;
				}
				if(templink != root && templink->PreviousX !='\0')
				{
					templink = templink->PreviousX;
					while(templink->NextX !='\0')
						templink = templink->NextX;
					if(templink->NextX =='\0')
					{
						while(templink->NextY !='\0')
							templink = templink->NextY;
						if(templink->NextY =='\0')
						{
							//templink = templink->NextY;
							while(templink->NextX !='\0')
								templink = templink->NextX;
							//linklist->SetPosY(templink->GetPosY() + 25);
							//linklist->PreviousY->SetPosY(templink->GetPosY() + 25);
							if(linklist->PreviousX !='\0')
							{
								if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
									linklist->SetPosX(linklist->PreviousY->GetPosX()+25);
							}
							//if(linklist->PreviousY->PreviousX !='\0')
							//	if(linklist->PreviousY->PreviousX->GetPosX() == linklist->PreviousY->GetPosX() && linklist->PreviousY->PreviousX->GetPosY() == linklist->PreviousY->GetPosY())
							//		linklist->PreviousY->SetPosY(linklist->PreviousY->PreviousX->GetPosY()+25);
							
						}
					}
				}
			}						
		}
		//linklist = templink;
		DBIPStep->m_strFilter = "";
		DBIPStep->Requery();
		DBIPStep->m_strFilter = "NextIP = '" + linklist->GetIP() + "'";
		DBIPStep->Requery();
		if(linklist->NextY !='\0' && DBIPStep->GetRecordCount() == 0)//For Don't Show Host
		{
			if(linklist->PreviousY != '\0')
			{
				if(linklist->PreviousY->GetPosX() == linklist->GetPosX() && linklist->PreviousY->GetPosY() == linklist->GetPosY())
					linklist->SetPosX(linklist->PreviousY->GetPosX()+100);
				pDC->MoveTo(linklist->PreviousY->GetPosX() + 150,linklist->PreviousY->GetPosY() - 5);
				pDC->LineTo(linklist->GetPosX() - 5,linklist->GetPosY() - 5);
			}
			if(linklist->GetAlive() == TRUE)
				pDC->SetTextColor(RGB(0,0,255));
			else
				pDC->SetTextColor(RGB(255,0,0));
			if(linklist->NextY =='\0')//For Host
				pDC->SetTextColor(RGB(0,255,0));
			pDC->TextOut(linklist->GetPosX(),linklist->GetPosY(),linklist->GetIP());
			pDC->TextOut(linklist->GetPosX() + 120,linklist->GetPosY(),linklist->Router_no);
		}
		else
		{
			if(linklist->PreviousY != root)
				if(linklist->PreviousX == '\0')
				{
					linklist = linklist->PreviousY;
					if(linklist->PreviousY->NextX !='\0')
					{
						if(linklist->GetPosY() != linklist->NextY->GetPosY())
							linklist->NextX->SetPosY(linklist->NextY->GetPosY());
					}
					if(linklist->NextY !='\0')
						delete linklist->NextY;
					linklist->NextY = '\0';
					
				}
				else
				{
					linklist = linklist->PreviousX;
					if(linklist->NextX !='\0')
						delete linklist->NextX;
					linklist->NextX = '\0';
				}
		}
		if(linklist->NextX =='\0')
		{
			while(linklist->NextX == '\0')
			{
				if(linklist->PreviousY != '\0')
					linklist = linklist->PreviousY;
				else
					break;
			}
			if(linklist->NextX != '\0')
			{
				linklist = linklist->NextX;
				if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
					linklist->SetPosY(linklist->PreviousX->GetPosY()-25);
				DrawNetwork(pDC,DBIPStep);
			}
			return;
		}
		else
		{
			linklist = linklist->NextX;
			if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
				linklist->SetPosY(linklist->PreviousX->GetPosY()-25);
			DrawNetwork(pDC,DBIPStep);
		}
	}
	else
	{
		DBIPStep->m_strFilter = "";
		DBIPStep->Requery();
		DBIPStep->m_strFilter = "NextIP = '" + linklist->GetIP() + "'";
		DBIPStep->Requery();
		if(linklist->NextY !='\0' && DBIPStep->GetRecordCount() == 0)//For Don't Show Host
		{
			if(linklist->PreviousY != '\0')
			{
				if(linklist->PreviousY->GetPosX() == linklist->GetPosX() && linklist->PreviousY->GetPosY() == linklist->GetPosY())
					linklist->SetPosX(linklist->PreviousY->GetPosX()+100);
				//if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
				//	linklist->SetPosY(linklist->PreviousX->GetPosY()+25);
				pDC->MoveTo(linklist->PreviousY->GetPosX() + 150,linklist->PreviousY->GetPosY() - 5);
				pDC->LineTo(linklist->GetPosX() - 5,linklist->GetPosY() - 5);
			}
			if(linklist->GetAlive() == TRUE)
				pDC->SetTextColor(RGB(0,0,255));
			else
				pDC->SetTextColor(RGB(255,0,0));
			if(linklist->NextY =='\0')//For Host
				pDC->SetTextColor(RGB(0,255,0));
			pDC->TextOut(linklist->GetPosX(),linklist->GetPosY(),linklist->GetIP());
			pDC->TextOut(linklist->GetPosX() + 120,linklist->GetPosY(),linklist->Router_no);
		}
		else
		{
			if(linklist->PreviousY != root)
				if(linklist->PreviousX == '\0')
				{
					linklist = linklist->PreviousY;
					if(linklist->PreviousY->NextX !='\0')
					{
						if(linklist->GetPosY() != linklist->NextY->GetPosY())
							linklist->NextX->SetPosY(linklist->NextY->GetPosY());
					}
					if(linklist->NextY !='\0')
						delete linklist->NextY;
					linklist->NextY = '\0';
					
				}
				else
				{
					linklist = linklist->PreviousX;
					if(linklist->NextX !='\0')
						delete linklist->NextX;
					linklist->NextX = '\0';
				}
		}
		if(linklist->NextY != '\0')
			linklist = linklist->NextY;
		DrawNetwork(pDC,DBIPStep);
	}
}

void CUIView::addlinklist(CString Stepfirst,CString Steptwo,bool Checkfirst,bool CheckTwo)
{//templink for position
	Linklist *temptemp;
	int checkback=0;
	if(root->GetIP() == Steptwo)
		return;
	if(linklist->GetIP() == Stepfirst)//Step First == GetIP()
	{
		if(linklist->NextY =='\0')//Y Not linklist
		{
			temproot =new Linklist;
			linklist->NextY = temproot;
			temproot->PreviousY = linklist;
			temproot->PreviousX = '\0';;
			linklist = temproot;
			linklist->SetIP(Steptwo);
			if(linklist->PreviousX !='\0')
			{
					linklist->SetPosX(linklist->PreviousX->GetPosX());
					linklist->SetPosY(linklist->PreviousX->GetPosY() - 25);
			}
			else
			{
				templink = linklist;//For Position
				if(templink->PreviousY !='\0' || templink->PreviousY != root)
				{
					templink = templink->PreviousY;
					if(templink->PreviousX !='\0')
					{
						templink = templink->PreviousX;
						if(templink->NextY !='\0')
						{
							templink = templink->NextY;
							while(templink->NextX !='\0')
								templink = templink->NextX;
							linklist->SetPosY(templink->GetPosY() - 25);
							linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
							linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
						}
						else
						{
							linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
							linklist->SetPosY(linklist->PreviousY->GetPosY());
						}
					}
					else
					{
						linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
						linklist->SetPosY(linklist->PreviousY->GetPosY());
					}
				}
				else
				{
					linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
					linklist->SetPosY(linklist->PreviousY->GetPosY());
				}
			}
			linklist->SetAlive(CheckTwo);
			linklist->NextX = '\0';
			linklist->NextY = '\0';
			return;
		}
		else//Y IS linklist
		{
			temptemp = linklist;
			linklist = linklist->NextY;
			while(linklist->NextX !='\0')
			{
				//linklist = linklist->NextX;
				if(linklist->GetIP() == Steptwo)
					return;
				linklist = linklist->NextX;
			/*	else
				{
					if(linklist->NextX =='\0')
					{
						temproot = new Linklist;
						linklist->NextX = temproot;
						temproot->PreviousX = linklist;
						linklist = temproot;
						linklist->PreviousY =linklist->PreviousX->PreviousY;
						linklist->SetIP(Steptwo);
						linklist->SetAlive(CheckTwo);
						linklist->SetPosX(linklist->PreviousX->GetPosX());
						linklist->SetPosY(linklist->PreviousX->GetPosY()+25);
						linklist->NextX = '\0';
						linklist->NextY = '\0';
						return;
					}
					else
					{
						linklist = linklist->NextX;
						if(linklist->GetIP() == Steptwo)
							return;
						//addlinklist(Stepfirst,Steptwo);
					}
				}*/
			}
			if(linklist->GetIP() == Steptwo)
				return;
			if(linklist->NextX=='\0')
			{
				temproot = new Linklist;
				linklist->NextX = temproot;
				temproot->PreviousX = linklist;
				temproot->PreviousY = linklist->PreviousY;
				linklist = temproot;
				linklist->NextX = '\0';
				linklist->NextY ='\0';
				linklist->SetIP(Steptwo);
				linklist->SetPosY(linklist->PreviousX->GetPosY()-25);
				linklist->SetPosX(linklist->PreviousX->GetPosX());
				linklist->SetAlive(CheckTwo);
				return;
			}
		}
	}
	else
	{
		if(linklist->NextY =='\0')
		{
			if(linklist->NextX == '\0')
			{
				if(linklist == root)
				{
					temproot = new Linklist;
					linklist->NextY = temproot;
					temproot->PreviousY = linklist;
					linklist = temproot;
					linklist->PreviousX = '\0';
					linklist->SetIP(Stepfirst);
					linklist->SetAlive(Checkfirst);
					if(linklist->PreviousX !='\0')
					{
						linklist->SetPosX(linklist->PreviousX->GetPosX());
						linklist->SetPosY(linklist->PreviousX->GetPosY() - 10);
					}
					else
					{
						templink = linklist;//For Position
						if(templink->PreviousY !='\0' && templink->PreviousY != root)
						{
							templink = templink->PreviousY;
							if(templink->PreviousX !='\0')
							{
								templink = templink->PreviousX;
								if(templink->NextY !='\0')
								{
									templink = templink->NextY;
									while(templink->NextX !='\0')
										templink = templink->NextX;
									linklist->SetPosY(templink->GetPosY() - 25);
									linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
									linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
								}
								else
								{
									linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
									linklist->SetPosY(linklist->PreviousY->GetPosY());
								}
							}
							else
							{
								linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
								linklist->SetPosY(linklist->PreviousY->GetPosY());
							}
						}
						else
						{
							linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
							linklist->SetPosY(linklist->PreviousY->GetPosY());
						}
					}
					linklist->NextX = '\0';

					temproot = new Linklist;
					linklist->NextY = temproot;
					temproot->PreviousY = linklist;
					linklist = temproot;
					linklist->PreviousX ='\0';
					linklist->SetIP(Steptwo);
					linklist->SetAlive(CheckTwo);
					if(linklist->PreviousX !='\0')
					{
						linklist->SetPosX(linklist->PreviousX->GetPosX());
						linklist->SetPosY(linklist->PreviousX->GetPosY() - 10);
					}
					else
					{
						templink = linklist;//For Position
						if(templink->PreviousY !='\0')
						{
							templink = templink->PreviousY;
							if(templink->PreviousX !='\0' || templink->PreviousY !=root)
							{
								templink = templink->PreviousX;
								if(templink->NextY !='\0')
								{
									templink = templink->NextY;
									while(templink->NextX !='\0')
										templink = templink->NextX;
									linklist->SetPosY(templink->GetPosY() - 25);
									linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
									linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
								}
								else
								{
									linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
									linklist->SetPosY(linklist->PreviousY->GetPosY());
								}
							}
							else
							{
								linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
								linklist->SetPosY(linklist->PreviousY->GetPosY());
							}
						}
						else
						{
							linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
							linklist->SetPosY(linklist->PreviousY->GetPosY());
						}
					}
					linklist->NextX = '\0';
					linklist->NextY = '\0';
					return;
				}
				else
				{
					while(linklist->NextX =='\0')
					{
						if(linklist->PreviousY != '\0')
							linklist = linklist->PreviousY;
						else
						{
////////////////////////////////////////////////////////////////////////
						if(linklist == root)
						{
							if(linklist->NextY !='\0')
							{
								linklist = linklist->NextY;
								while(linklist->NextX !='\0')
									linklist = linklist->NextX;
								temproot = new Linklist;
								linklist->NextX = temproot;
								temproot->PreviousY = linklist->PreviousY;
								temproot->PreviousX = linklist;
								linklist = temproot;
								linklist->SetIP(Stepfirst);
								linklist->SetAlive(Checkfirst);
								linklist->NextX ='\0';
								linklist->NextY ='\0';
								if(linklist->PreviousX !='\0')
								{
									linklist->SetPosX(linklist->PreviousX->GetPosX());
									linklist->SetPosY(linklist->PreviousX->GetPosY() - 25);
								}
								else
								{
									templink = linklist;//For Position
									if(templink->PreviousY !='\0' || templink->PreviousY !=root)
									{
										templink = templink->PreviousY;
										if(templink->PreviousX !='\0')
										{
											templink = templink->PreviousX;
											if(templink->NextY !='\0')
											{
												templink = templink->NextY;
												while(templink->NextX !='\0')
													templink = templink->NextX;
												linklist->SetPosY(templink->GetPosY() - 25);
												linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
												linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
											}
											else
											{
												linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
												linklist->SetPosY(linklist->PreviousY->GetPosY());
											}
										}
										else
										{
											linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
											linklist->SetPosY(linklist->PreviousY->GetPosY());
										}
									}
									else
									{
										linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
										linklist->SetPosY(linklist->PreviousY->GetPosY());
									}
								}
							}
							else
							{
							//////////////////
								temproot = new Linklist;
								linklist->NextY = temproot;
								temproot->PreviousY = linklist;
								linklist = temproot;
								linklist->PreviousX = '\0';
								linklist->SetIP(Stepfirst);
								linklist->SetAlive(Checkfirst);
								if(linklist->PreviousX !='\0')
								{
									linklist->SetPosX(linklist->PreviousX->GetPosX());
									linklist->SetPosY(linklist->PreviousX->GetPosY() - 10);
								}
								else
								{
									templink = linklist;//For Position
									if(templink->PreviousY !='\0')
									{
										templink = templink->PreviousY;
										if(templink->PreviousX !='\0' || templink->PreviousY !=root)
										{
											templink = templink->PreviousX;
											if(templink->NextY !='\0')
											{
												templink = templink->NextY;
												while(templink->NextX !='\0')
													templink = templink->NextX;
												linklist->SetPosY(templink->GetPosY() - 25);
												linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
												linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
											}
											else
											{
												linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
												linklist->SetPosY(linklist->PreviousY->GetPosY());
											}
										}
										else
										{
											linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
											linklist->SetPosY(linklist->PreviousY->GetPosY());
										}
									}
									else
									{
										linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
										linklist->SetPosY(linklist->PreviousY->GetPosY());
									}
								}
							linklist->NextX = '\0';	
							}
							temproot = new Linklist;
							linklist->NextY = temproot;
							temproot->PreviousY = linklist;
							linklist = temproot;
							linklist->PreviousX ='\0';
							linklist->SetIP(Steptwo);
							linklist->SetAlive(CheckTwo);
							if(linklist->PreviousX !='\0')
							{
								linklist->SetPosX(linklist->PreviousX->GetPosX());
								linklist->SetPosY(linklist->PreviousX->GetPosY() - 10);
							}
							else
							{
								templink = linklist;//For Position
								if(templink->PreviousY !='\0' && templink->PreviousY != root)
								{
									templink = templink->PreviousY;
									if(templink->PreviousX !='\0' || templink->PreviousY !=root)
									{
										templink = templink->PreviousX;
										if(templink->NextY !='\0')
										{
											templink = templink->NextY;
											while(templink->NextX !='\0')
												templink = templink->NextX;
											linklist->SetPosY(templink->GetPosY() - 25);
											linklist->PreviousY->SetPosY(templink->GetPosY() - 25);
											linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
										}
										else
										{
											linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
											linklist->SetPosY(linklist->PreviousY->GetPosY());
										}
									}
									else
									{
										linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
										linklist->SetPosY(linklist->PreviousY->GetPosY());
									}
								}
								else
								{
									linklist->SetPosX(linklist->PreviousY->GetPosX() + 200);
									linklist->SetPosY(linklist->PreviousY->GetPosY());
								}
							}
							linklist->NextX = '\0';
							linklist->NextY = '\0';
							return;
						}
						}
//////////////////////////////////////////////////////////////////////////////////
					}
					linklist = linklist->NextX;
////////////////////////////////////////////////////////////////////////////////
					addlinklist(Stepfirst,Steptwo,Checkfirst,CheckTwo);
				}
			}
			else
			{
				linklist = linklist->NextX;
				addlinklist(Stepfirst,Steptwo,Checkfirst,CheckTwo);
			}
		}
		else
		{
			linklist = linklist->NextY;
			addlinklist(Stepfirst,Steptwo,Checkfirst,CheckTwo);
		}
		if(linklist == root)
		{
			linklist = linklist->NextY;
			while(linklist->NextX != '\0')
			{
				linklist = linklist->NextX;
			}
			temproot = new Linklist;
			linklist->NextX = temproot;
			temproot->PreviousX = linklist;
			linklist = temproot;
			linklist->PreviousY = linklist->PreviousX->PreviousY;
			linklist->SetIP(Stepfirst);
			linklist->SetAlive(Checkfirst);
			linklist->SetPosX(linklist->PreviousX->GetPosX() + 200);
			linklist->SetPosY(linklist->PreviousX->GetPosY());

			temproot = new Linklist;
			linklist->NextX = temproot;
			temproot->PreviousY = linklist;
			linklist = temproot;
			linklist->PreviousX ='\0';
			linklist->SetIP(Steptwo);
			linklist->SetAlive(CheckTwo);
			linklist->SetPosX(linklist->PreviousX->GetPosX() + 200);
			linklist->SetPosY(linklist->PreviousX->GetPosY());
			linklist->NextX = '\0';
			linklist->NextY = '\0';
		}

	}
}


void CUIView::OnContextMenu(CWnd* pWnd, CPoint point)//Left Click mouse property 
{
	// TODO: Add your message handler code here
	linklist = root;
	if(linklist->GetIP() =="")
		return;
	while(linklist->NextY !='\0')
		linklist = linklist->NextY;
	//this->ClientToScreen(&point);
	this->ScreenToClient(&point);
	CClientDC clientDC(this);
	OnPrepareDC(&clientDC);
	clientDC.DPtoLP(&point);
	TableAddressStep Check;
	Check.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
	if(ChecklinklistPos(point))
	{
		clientDC.LPtoDP(&point);
		Check.m_strFilter = "BeforeIP = '" + linklist->GetIP() + "'";
		Check.Requery();
		if(Check.GetRecordCount() != 0)
		{	
			if(linklist->NextY =='\0')
			{
				this->ClientToScreen(&point);
				CMenu m_lMenu, *m_lSubMenu;
				m_lMenu.LoadMenu( IDR_Property );
				m_lSubMenu = m_lMenu.GetSubMenu( 2 );
				m_lSubMenu->TrackPopupMenu( TPM_LEFTBUTTON, 
										point.x, point.y, this);
				m_lSubMenu->DestroyMenu();
			}
			else
			{
				this->ClientToScreen(&point);
				CMenu m_lMenu, *m_lSubMenu;
				m_lMenu.LoadMenu( IDR_Property );
				m_lSubMenu = m_lMenu.GetSubMenu( 0 );
				m_lSubMenu->TrackPopupMenu( TPM_LEFTBUTTON, 
										point.x, point.y, this);
				m_lSubMenu->DestroyMenu();
			}
		}
		else
		{
			this->ClientToScreen(&point);
			CMenu m_lMenu, *m_lSubMenu;
			m_lMenu.LoadMenu( IDR_Property );
			m_lSubMenu = m_lMenu.GetSubMenu( 1 );
			m_lSubMenu->TrackPopupMenu( TPM_LEFTBUTTON, 
									point.x, point.y, this);
			m_lSubMenu->DestroyMenu();
		}
	
	}
}

void CUIView::CheckRIP()
{
	TableNetwork DBIPNetwork;
	CString tempnetworkfirst,tempnetworkend;
	//Linklist *templinklist,*templinklistfirstX;
	linklist = root;
	Linklist *forpos;//For Position Good
	//linklist = linklist->NextY;
	StatusIP checkbetween;
	int *hight=0;
	DBIPNetwork.Open(dbOpenDynaset,_T("Select * From NetworkAddress"));
	if(DBIPNetwork.IsBOF())
	{
		DBIPNetwork.Close();
		return;
	}

	if(Type_Scan != 4 && Type_Scan != 6 && Type_Scan != 7)//Option HavePing + Traceroute
	{
		while(!DBIPNetwork.IsEOF())//Check Loop Data End
		{
			linklist =root;
			if(linklist->NextY == '\0')
				return;
			if(DBIPNetwork.m_NetworkAddressFirst == checkbetween.CalcIPStart(checkbetween.GetNetCardGateWay(),checkbetween.GetNetCardSubnetMask()))//Own Network
			{
				linklist = linklist->NextY;
				while(linklist->NextX != '\0')
				{
					if(linklist->GetIP() == checkbetween.GetNetCardGateWay())
					{
						temproot = linklist;
						//while(linklist->PreviousX !='\0')//For Begin X
						//	linklist = linklist->PreviousX;
						while(linklist->NextX !='\0')
							linklist = linklist->NextX;
						templink2 = linklist;
						while(linklist->PreviousX !='\0')//For Begin X
							linklist = linklist->PreviousX;
						while(linklist != templink2)//Check In Same Lan
						{
							templink = linklist;
							templink = templink->NextX;	
							if((checkbetween.BetweenIP(DBIPNetwork.m_NetworkAddressFirst,DBIPNetwork.m_NetworkAddressEnd,linklist->GetIP())) && (temproot->GetIP() != linklist->GetIP()))
							{
								if(linklist->NextX != '\0')
								{
									if(linklist->PreviousX !='\0')
									{
										linklist->PreviousX->NextX = linklist->NextX;
										linklist->NextX->PreviousX = linklist->PreviousX;
									}
									else
									{
										linklist->NextX->PreviousX = '\0';
									}
								}
								else
								{
									linklist->PreviousX = '\0';
								}
								if(temproot->NextY =='\0')
								{
									temproot->NextY = linklist;
									linklist->PreviousY = temproot;
									linklist->SetPosX(temproot->GetPosX()+100);
									linklist->SetPosY(temproot->GetPosY());
									linklist->NextX ='\0';
									linklist->PreviousX ='\0';
								}
								else
								{
									temproot = temproot->NextY;
									while(temproot->NextX!= '\0')
										temproot = temproot->NextX;
									temproot->NextX = linklist;
									linklist->PreviousX = temproot;
									linklist->PreviousY = temproot->PreviousY;
									linklist->SetPosX(temproot->GetPosX());
									linklist->SetPosY(temproot->GetPosY()-25);
									linklist->NextX = '\0';
									temproot = temproot->PreviousY;
								}
								//temproot = temproot->PreviousY;
								while(temproot->PreviousX !='\0')
									temproot = temproot->PreviousX;
								//linklist = templink;
							}
							if(templink->NextX !='\0')
							{
								//templink = linklist;
								//templink = templink->NextX;
								linklist = templink;
								if(linklist->PreviousX !='\0')
								{
									linklist->SetPosX(linklist->PreviousX->GetPosX());
									linklist->SetPosY(linklist->PreviousX->GetPosY()-25);
								}
							}
							else
							{
								/*if(templink->PreviousX !='\0')
								{
									templink->SetPosX(templink->PreviousX->GetPosX());
									templink->SetPosY(templink->PreviousX->GetPosY()+25);
								}*/
								//SizeX = linklist->GetPosX();//For Set Document
								//SizeY = linklist->GetPosY();
								if(linklist->PreviousY !='\0')
								{
									forpos =linklist->PreviousY;
									while(forpos->NextX !='\0')
										forpos = forpos->NextX;
									linklist->PreviousY->SetPosX(forpos->GetPosX());
									linklist->PreviousY->SetPosY(forpos->GetPosY()-25);
								}
								//linklist = templink;
								break;
							}
						}//while(linklist != templink2)
					}
					else
					{
						linklist = linklist->NextX;
					}
				}//while(linklist->NextX != '\0')
			}
			else
				CheckNetwork(DBIPNetwork.m_NetworkAddressFirst,DBIPNetwork.m_NetworkAddressEnd,hight);
			hight =0;
			DBIPNetwork.MoveNext();
		}
	}
	else//Option No Ping + Traceroute
	{
		while(!DBIPNetwork.IsEOF())//Loop
		{
			linklist=root;
			addlinklist(root->GetIP(),DBIPNetwork.m_NetworkAddressFirst,TRUE,TRUE);
			linklist = root;
			addlinklist(DBIPNetwork.m_NetworkAddressFirst,DBIPNetwork.m_NetworkAddressEnd,TRUE,TRUE);
			DBIPNetwork.MoveNext();
		}

	}//else Option Have Ping + Traceroute
	DBIPNetwork.Close();
	TableAddressStep DBStep;
	DBStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
	linklist = root->NextY;;
	ChangeDBFromRIP(&DBStep);//For Change Database From RIP For Expend and Hide
	DBStep.Close();
	return;
}

void CUIView::CheckSNMP()
{
	TableNetwork DBIPNetwork;
	TableRouter DBGetRouter;
	TableAddressStep DBStep;
	TableIP IPCheck; 
	int router=0;
	CString IP;
	DBIPNetwork.Open(dbOpenDynaset,_T("Select * From NetworkAddress"));
	DBGetRouter.Open(dbOpenDynaset,_T("Select * From Router"));
	DBStep.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
	IPCheck.Open(dbOpenDynaset,_T("Select * From IPAddr"));
	CString TrunkTemp;
	if(IPCheck.IsBOF())
		return;
	IPCheck.MoveFirst();
	if(DBGetRouter.IsBOF())
	{
		DBIPNetwork.Close();
		DBGetRouter.Close();
		DBStep.Close();
		return;
	}
	if(Type_Scan != 4 && Type_Scan != 6 && Type_Scan != 7)//Option Have Ping + Traceroute
	{
		while(!IPCheck.IsEOF())
		{
			DBGetRouter.m_strFilter ="";
			DBGetRouter.Requery();
			DBGetRouter.m_strFilter = "IPAddress = '" + IPCheck.m_IPAddress + "'";
			DBGetRouter.Requery();
			if(DBGetRouter.GetRecordCount() != 0)
			{
				if(DBGetRouter.m_Router_No != router)
				{
					DBStep.m_strFilter ="";
					DBStep.Requery();
					DBStep.m_strFilter = "NextIP = '" + IPCheck.m_IPAddress + "'";
					DBStep.Requery();
					if (DBStep.GetRecordCount() != 0)//
					{
						router = DBGetRouter.m_Router_No;
						IP = DBStep.m_BeforeIP;
						DBGetRouter.m_strFilter="";
						DBGetRouter.Requery();
						char temp[10];
						_itoa(router,temp,10);
						CString temp2;
						temp2 = CString("Router_No = ") + CString(temp);
						DBGetRouter.m_strFilter=temp2;
						DBGetRouter.Requery();
						while(DBGetRouter.m_Router_No == router)
						{
							linklist = root;
							if(DBStep.m_BeforeIP != DBGetRouter.m_IPAddress)
								addlinklist(DBStep.m_BeforeIP,DBGetRouter.m_IPAddress,TRUE,TRUE);
							linklist->Router_no = CString("R") + CString(temp);
							if(DBGetRouter.m_InterfaceNo !="" && DBGetRouter.m_InterfaceNo.GetAt(0) != 'R')
							{
								TrunkTemp =DBGetRouter.m_InterfaceNo;
								TrunkTemp.Delete(0,TrunkTemp.GetLength()-2);
								char num = TrunkTemp.GetAt(0);
								linklist->Router_no = linklist->Router_no + CString("/");
								linklist->Router_no = linklist->Router_no + CString(num);
								DBGetRouter.Edit();
								DBGetRouter.m_InterfaceNo = linklist->Router_no;
								DBGetRouter.Update();
							}
							DBGetRouter.MoveNext();
						}
					}
					else
						if(router == DBGetRouter.m_Router_No)
						{
							linklist = root;
							char temp[10];
							_itoa(router,temp,10);
							router = DBGetRouter.m_Router_No;
							if(DBStep.m_BeforeIP != DBGetRouter.m_IPAddress)
								addlinklist(IP,DBGetRouter.m_IPAddress,TRUE,TRUE);
							linklist->Router_no = CString("R") + CString(temp);
							if(DBGetRouter.m_InterfaceNo !="" && DBGetRouter.m_InterfaceNo.GetAt(0) != 'R')
							{
								TrunkTemp =DBGetRouter.m_InterfaceNo;
								TrunkTemp.Delete(0,TrunkTemp.GetLength()-2);
								char num = TrunkTemp.GetAt(0);
								linklist->Router_no = linklist->Router_no + CString("/");
								linklist->Router_no = linklist->Router_no + CString(num);
								DBGetRouter.Edit();
								DBGetRouter.m_InterfaceNo = linklist->Router_no;
								DBGetRouter.Update();
							}
						}
						else
						{
							linklist = root;
							router = DBGetRouter.m_Router_No;
							while(DBGetRouter.m_Router_No == router)
							{
								linklist = root;
								char temp[10];
								_itoa(router,temp,10);
								CString temp2;
								temp2 = CString("Router_No = ") + CString(temp);
								DBGetRouter.m_strFilter=temp2;
								DBGetRouter.Requery();
								while(DBGetRouter.m_Router_No == router)
								{
									linklist = root;
									if(DBStep.m_BeforeIP != DBGetRouter.m_IPAddress)
										addlinklist(root->GetIP(),DBGetRouter.m_IPAddress,TRUE,TRUE);
									linklist->Router_no = CString("R") + CString(temp);
									if(DBGetRouter.m_InterfaceNo !="" && DBGetRouter.m_InterfaceNo.GetAt(0) != 'R')
									{
										TrunkTemp =DBGetRouter.m_InterfaceNo;
										TrunkTemp.Delete(0,TrunkTemp.GetLength()-2);
										char num = TrunkTemp.GetAt(0);
										linklist->Router_no = linklist->Router_no + CString("/");
										linklist->Router_no = linklist->Router_no + CString(num);
										DBGetRouter.Edit();
										DBGetRouter.m_InterfaceNo = linklist->Router_no;
										DBGetRouter.Update();
									}
									DBGetRouter.MoveNext();
								}
							}
						}
				}
			}
			IPCheck.MoveNext();
		}
	}
	else//Option No Ping + Traceroute
	{
		while(!DBGetRouter.IsEOF())
		{
			linklist = root;
			DBStep.m_strFilter ="";
			DBStep.Requery();
			DBStep.m_strFilter = "NextIP = '" + DBGetRouter.m_IPAddress + "'";
			DBStep.Requery();
			if (DBStep.GetRecordCount() != 0)//
				addlinklist(DBStep.m_BeforeIP,DBGetRouter.m_IPAddress,TRUE,TRUE);
			else
				addlinklist(root->GetIP(),DBGetRouter.m_IPAddress,TRUE,TRUE);
			DBGetRouter.MoveNext();
		}
	}
	DBIPNetwork.Close();
	DBGetRouter.Close();
	DBStep.Close();
}

bool CUIView::CheckLinklistINDB(CString IPTempBegin,CString IPTempEnd,TableAddressStep *DBIPStep,TableIP *DBIPAddress)
{
	bool temp1=TRUE,temp2=TRUE;
	DBIPStep->m_strFilter ="";
	DBIPStep->Requery();
	//DBIPStep->MoveFirst();
	if(IPTempBegin==IPTempEnd)
	{
		return FALSE;
	}
	DBIPStep->m_strFilter = "NextIP = '" + IPTempBegin + "'";
	DBIPStep->Requery();
	if (DBIPStep->GetRecordCount()==0)
	{
		DBIPAddress->m_strFilter ="";
		DBIPAddress->Requery();
		DBIPAddress->m_strFilter = "IPAddress = '" + IPTempBegin + "'";
		DBIPAddress->Requery();
		if(DBIPAddress->GetRecordCount() == 0)
			temp1 = TRUE;
		else
			if(DBIPAddress->m_Alive == TRUE)
				temp1 = TRUE;
			else
				temp1 = FALSE;
		DBIPAddress->m_strFilter ="";
		DBIPAddress->Requery();
		//DBIPAddress->MoveFirst();
		DBIPAddress->m_strFilter = "IPAddress = '" + IPTempEnd + "'";
		DBIPAddress->Requery();
		if(DBIPAddress->GetRecordCount() == 0)
			temp2 = TRUE;
		else
			if(DBIPAddress->m_Alive == TRUE)
				temp2 = TRUE;
			else
				temp2 = FALSE;
		linklist = root;
		addlinklist(IPTempBegin,IPTempEnd,temp1,temp2);
		return TRUE;
	}
	else
	{
		CString DBTemp = DBIPStep->m_BeforeIP;
		CString DBTemp2 = DBIPStep->m_NextIP;
		if (CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress) == TRUE)
		{
			DBIPAddress->m_strFilter ="";
			DBIPAddress->Requery();
			DBIPAddress->m_strFilter = "IPAddress = '" + DBTemp + "'";
			DBIPAddress->Requery();
			if(DBIPAddress->GetRecordCount() == 0)
				temp1 = TRUE;
			else
				if(DBIPAddress->m_Alive == TRUE)
					temp1 = TRUE;
				else
					temp1 = FALSE;
			DBIPAddress->m_strFilter ="";
			DBIPAddress->Requery();
			DBIPAddress->m_strFilter = "IPAddress = '" + DBTemp2 + "'";
			DBIPAddress->Requery();
			if(DBIPAddress->GetRecordCount() == 0)
				temp2 = TRUE;
			else
				if(DBIPAddress->m_Alive == TRUE)
					temp2 = TRUE;
				else
					temp2 = FALSE;
			linklist =root;
			addlinklist(IPTempBegin,IPTempEnd,temp1,temp2);
		}
		else
		{
			addlinklist(IPTempBegin,IPTempEnd,temp1,temp2);
		}

	}
	return FALSE;
}

void CUIView::CheckNetwork(CString IPTempBegin, CString IPTempEnd,int *hight)//Move Linklist
{
	StatusIP checkbetween;
	int check=0;
	if(linklist->NextY != '\0')
	{
		hight++;
		linklist = linklist->NextY;
		if(IPTempBegin =="")
			return;
		if(IPTempEnd == "")
			return;
		CheckNetwork(IPTempBegin,IPTempEnd,hight);
	}
	else//Not Down Y
	{
		//DBIPStep->m_strFilter = "NextIP = '" + IPTempBegin + "'";
		//DBIPStep->Requery();
		while(linklist->PreviousX != '\0')
			linklist = linklist->PreviousX;
		//linklist->PreviousY->NextY = linklist;
		while(linklist->NextX != '\0' && linklist->GetIP() != "")
		{
		if(linklist->PreviousY != '\0')
		{
			templink = linklist;
			templink2 = templink;
			temproot = linklist;
			linklist = linklist->PreviousY;
			if((checkbetween.BetweenIP(IPTempBegin,IPTempEnd,templink->GetIP())) && (checkbetween.BetweenIP(IPTempBegin,IPTempEnd,linklist->GetIP())))
				;
			else
			while(templink2->NextX !='\0')
			{
				//templink = templink2;
				if(linklist->GetIP() != "")
				{
					if(checkbetween.BetweenIP(IPTempBegin,IPTempEnd,templink->GetIP()))
					{
						while(linklist->PreviousX !='\0')
						{
							linklist = linklist->PreviousX;
						}
						while(linklist->GetIP() !=" ")
						{
							if(checkbetween.BetweenIP(IPTempBegin,IPTempEnd,linklist->GetIP()))
							{
								templink->NextX->PreviousX = templink->PreviousX;
								if(templink->PreviousX != '\0')
								{
									templink->PreviousX->NextX = templink->NextX;
								}
								else
									templink->PreviousY->NextY = templink->NextX;
								if(linklist->NextY != '\0')
								{
									linklist = linklist->NextY;
									while(linklist->NextX != '\0')
									{
										linklist = linklist->NextX;
									}
									if(linklist->NextX =='\0')
									{
										linklist->NextX = templink;
										templink->PreviousX = linklist;
										templink2 = templink->NextX;
										templink->NextX = '\0';
										templink->PreviousY = linklist->PreviousY;
										linklist = linklist->PreviousY;
										templink = templink2;
										//return;
										break;
										check=1;
									}
								}
								else
								{
									linklist->NextY =templink;
									templink->PreviousY = linklist;
									templink->PreviousX = '\0';
									templink2 = templink->NextX;
									templink->NextX = '\0';
									templink = templink2;
									//return;
									break;
									check=1;
								}
								
							}
							else
							{
								if(linklist->NextX =='\0')
								{
									return;
								}
								else
									linklist = linklist->NextX;	
							}
						}//while(linklist->NextX !='\0')
					}
					else
					{
						templink = templink->NextX;
						templink2 = templink;
					}
				}//if(linklist->NextX != '\0')
				else
				{
					linklist = linklist->PreviousY;
					if(linklist->PreviousY != '\0')
					{
						linklist = linklist->PreviousY;
						if(linklist->NextX != '\0')
							linklist = linklist->NextX;
						else	
							while(linklist->NextX =='\0' && linklist->GetIP() != root->GetIP())
							{
								linklist=linklist->PreviousX;
							}
					}
					//CheckNetwork(IPTempBegin,IPTempEnd,hight);//Recursive
				}
			}
///////////////////////////////////////////////////////////////////////////////////
			if(templink2->NextX =='\0')
				if(linklist->GetIP() != "")
				{
					if(checkbetween.BetweenIP(IPTempBegin,IPTempEnd,templink->GetIP()))
					{
						while(linklist->PreviousX !='\0')
						{
							linklist = linklist->PreviousX;
						}
						while(linklist->NextX !='\0')
						{
							if(checkbetween.BetweenIP(IPTempBegin,IPTempEnd,linklist->GetIP()))
							{
								if(templink->NextX !='\0')
									templink->NextX->PreviousX = templink->PreviousX;
								if(templink->PreviousX != '\0')
								{
									templink->PreviousX->NextX = templink->NextX;
								}
								else
									templink->PreviousY->NextY = templink->NextX;
								if(linklist->NextY != '\0')
								{
									linklist = linklist->NextY;
									while(linklist->NextX != '\0')
									{
										linklist = linklist->NextX;
									}
									if(linklist->NextX =='\0')
									{
										linklist->NextX = templink;
										templink->PreviousX = linklist;
										templink2 = templink->NextX;
										templink->NextX = '\0';
										templink->PreviousY = linklist->PreviousY;
										linklist = linklist->PreviousY;
										templink = templink2;
										//return;
										break;
										check=1;
									}
								}
								else
								{
									linklist->NextY =templink;
									templink->PreviousY = linklist;
									templink->PreviousX = '\0';
									templink2 = templink->NextX;
									templink->NextX = '\0';
									templink = templink2;
									//return;
									break;
									check=1;
								}
								
							}
							else
							{
								linklist = linklist->NextX;
							}
						}//while(linklist->NextX !='\0')
						if(linklist->NextX =='\0')//Last Linklist = 
						{
							if(checkbetween.BetweenIP(IPTempBegin,IPTempEnd,linklist->GetIP()))
							{
								if(templink->NextX !='\0')
									templink->NextX->PreviousX = templink->PreviousX;
								if(templink->PreviousX != '\0')
								{
									templink->PreviousX->NextX = templink->NextX;
								}
								else
									templink->PreviousY->NextY = templink->NextX;
								if(linklist->NextY != '\0')
								{
									linklist = linklist->NextY;
									while(linklist->NextX != '\0')
									{
										linklist = linklist->NextX;
									}
									if(linklist->NextX =='\0')
									{
										linklist->NextX = templink;
										templink->PreviousX = linklist;
										templink2 = templink->NextX;
										templink->NextX = '\0';
										templink->PreviousY = linklist->PreviousY;
										linklist = linklist->PreviousY;
										templink = templink2;
										//return;
										break;
										check=1;
									}
								}
								else
								{
									linklist->NextY =templink;
									templink->PreviousY = linklist;
									templink->PreviousX = '\0';
									templink2 = templink->NextX;
									templink->NextX = '\0';
									templink = templink2;
									//return;
									break;
									check=1;
								}
								
							}
						}
					}
					else
					{
						templink = templink->NextX;
						templink2 = templink;
					}
				}//if(linklist->NextX != '\0')
				else
				{
					linklist = linklist->PreviousY;
					if(linklist->PreviousY != '\0')
					{
						linklist = linklist->PreviousY;
						if(linklist->NextX != '\0')
							linklist = linklist->NextX;
						else	
							while(linklist->NextX =='\0' && linklist->GetIP() != root->GetIP())
							{
								linklist=linklist->PreviousX;
							}
					}
				}
//////////////////////////////////////////////////////////////////////////////////
		}
		else
		{
			return;
		}
		if(linklist->NextX !='\0')
		{
			linklist = linklist->NextX;
		}
		else
			if(linklist == root)
				if(temproot->NextX != '\0')
					linklist = temproot->NextX;
		}
	}
	/*return;
	void Insideloop(void)
	{
	}*/

}

void CUIView::Line(CDC *pDC)
{
	CPen pen;
	pen.CreatePen(PS_SOLID,5,RGB(255,0,255));
	pDC->SelectObject(&pen);
	pDC->MoveTo(linklist->GetPosX()+95,linklist->GetPosY());
	pDC->LineTo(linklist->GetPosX()+2,linklist->GetPosY());
}

void CUIView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_nTimer == nIDEvent && CheckOnScan == 4)//Refresh
	{
		KillTimer(m_nTimer);
		CheckOnScan = 0;
		Newscan newscan;
		//Ping+Traceroute, RIP, SNMP
		if(Type_Scan ==1 || Type_Scan ==2 ||Type_Scan ==3)
			newscan.PingTraceroute(IPAddressBegin,IPAddressEnd);
		Type_Scan = newscan.Type_scan;
		if(Type_Scan == 1 || Type_Scan ==5 || Type_Scan ==6 ||Type_Scan ==7)
			newscan.CheckSNMP(IPAddressBegin,IPAddressEnd);
		Type_Scan = newscan.Type_scan;
		if(Type_Scan == 1 || Type_Scan ==3 || Type_Scan ==4 ||Type_Scan ==6)
			newscan.CheckRIP();
		if(Type_Scan == 8)
		{	
			TableIP DBIP;
			TableNetwork DBNetwork;
			CString IPTempBegin, IPTempEnd;
			DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
			DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
			StatusIP statusip;
			while(!DBNetwork.IsEOF())//Loop For Network
			{
				IPTempBegin = DBNetwork.m_NetworkAddressFirst;
				IPTempEnd = DBNetwork.m_NetworkAddressEnd;
				newscan.PingTraceroute(IPAddressBegin,IPAddressEnd);
				DBNetwork.MoveNext();
			}
		}
		//Start Value Again	
		m_nTimer = SetTimer(1, TimerForRefresh, 0);
		//Invalidate
		UpdateWindow();
		CheckOnScan = 1;
	}
	else
	{
		//if(m_nTimer == nIDEvent)
		//	m_nTimer = SetTimer(1, TimerForRefresh, 0);
	}

	CScrollView::OnTimer(nIDEvent);
}

bool CUIView::ChecklinklistPos(CPoint point)
{//Loop Pattern End to Begin
	while(linklist != root)
	{
		if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
		{
			return TRUE;
		}
		else
		{
			if(linklist->NextY =='\0')
			{
				if(linklist->NextX != '\0')
				{
					if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
						return TRUE;
					linklist = linklist->NextX;
				}
				else
				{
					if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
						return TRUE;
					while(linklist->NextX =='\0')
					{
						if(linklist->PreviousY != '\0')
						{
							linklist=linklist->PreviousY;
							if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
								return TRUE;
						}
						else
						{
							if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
								return TRUE;
							else
								return FALSE;
						}
					}
					if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
						return TRUE;
					linklist = linklist->NextX;
					//ChecklinklistPos(point);
				}
				if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
					return TRUE;
			}
			else
			{
				linklist = linklist->NextY;
				if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
					return TRUE;
			}
			ChecklinklistPos(point);
		}
	}
	if(linklist == root)
		if((linklist->GetPosX()<=point.x) && (linklist->GetPosX()+100>=point.x) && (linklist->GetPosY()>=point.y) && (linklist->GetPosY()-10<=point.y))//For Discovery
			return TRUE;
		else
			return FALSE;
	return FALSE;
}

void CUIView::OnMenurclickHidenode() 
{
	// TODO: Add your command handler code here
	//delete linklist->NextX;
	if(linklist != root)
	{
		if(linklist->NextY !='\0')
		{
			temproot=linklist;//For Delete
			templink = linklist->NextY;
			DeleteChild();
			linklist->NextY ='\0';
		}
		//For Position
		templink = linklist;
		temproot = linklist;
		while(linklist->NextX != '\0')
		{
			linklist = linklist->NextX;
			if(templink->NextY !='\0')
			{
				templink = templink->NextY;
				while(templink->NextX !='\0')
					templink = templink->NextX;
				linklist->SetPosY(templink->GetPosY()-25);
			}
			else
			{
				linklist->SetPosY(templink->GetPosY()-25);
				templink = templink->NextX;
			}
		}
		//////////////
		CDC *pDC;
		pDC = GetDC();
		CPen pen;
		CPoint point;
		OnPrepareDC(pDC);
		pDC->DPtoLP(&point);
		pen.CreatePen(PS_SOLID,1,RGB(255,255,255));
		pDC->SelectObject(pen);
		pDC->Rectangle(0,0,SizeX,-SizeY);
		OnDraw(pDC);
		linklist = root;
		OnDrawForHost(pDC);
		OnDraw(pDC);
	}
}

void CUIView::DeleteChild()//Delete Child For Command Hide
{//Used temproot,templink
	if(templink == linklist)
		return;
	if(templink->NextY =='\0')
	{
		//if(linklist->PreviousX =='\0' && linklist->NextX !='\0')//Line Cuttting
		//	Line(pDC);
		if(templink->NextX =='\0')
		{
			if(templink->PreviousX !='\0')
			{
				templink = templink->PreviousX;
				delete templink->NextX;
				templink->NextX ='\0';
				return;
			}
			else
				if(templink->PreviousY != '\0' && templink != linklist)
				{
					templink = templink->PreviousY;
					delete templink->NextY;
					templink->NextY ='\0';
					return;
				}
				else
					return;
		}
		else
		{
			templink = templink->NextX;
			DeleteChild();
		}
			
	}
	else
	{
		templink = templink->NextY;
		DeleteChild();
	}
	DeleteChild();
}

void CUIView::OnMenurclickExpand() //Check from Table Address Step
{
	// TODO: Add your command handler code here
	temproot = linklist;
	TableAddressStep Expendaddress;
	TableRouter DBRouter;
	TableIP DBIP;
	int TempForRouter;
	Expendaddress.Open(dbOpenDynaset,_T("Select * From IPAddrStep"));
	DBRouter.Open(dbOpenDynaset,_T("Select * From Router"));
	DBIP.Open(dbOpenDynaset,_T("Select * From IPAddr"));
	Expendaddress.m_strFilter = "BeforeIP = '" + linklist->GetIP() + "'";
	Expendaddress.Requery();
	if(Expendaddress.GetRecordCount() != 0)
	{
		DBRouter.m_strFilter = "";
		DBRouter.Requery();
		DBRouter.m_strFilter = "IPAddress = '" + Expendaddress.m_NextIP + "'";
		DBRouter.Requery();
		if(linklist->NextY =='\0')
		{
			CheckExpand = TRUE;
			templink = new Linklist;
			linklist->NextY = templink;
			templink->PreviousY = linklist;
			templink->PreviousX ='\0';
			templink->NextX = '\0';
			templink->NextY = '\0';
			templink->SetPosX(linklist->GetPosX() + 210);
			templink->SetPosY(linklist->GetPosY());
			templink->SetIP(Expendaddress.m_NextIP);
			DBIP.m_strFilter ="";
			DBIP.Requery();
			DBIP.m_strFilter = "IPAddress = '" + templink->GetIP() + "'";
			DBIP.Requery();
			if(DBIP.GetRecordCount() != 0)
				{
					if(DBIP.m_Alive ==TRUE)
						templink->SetAlive(TRUE);
					else
						templink->SetAlive(FALSE);
				}
			if(DBRouter.GetRecordCount() !=0)
			{	
				TempForRouter = DBRouter.m_Router_No;
				while(DBRouter.m_Router_No == TempForRouter)
				{
					if(DBRouter.m_IPAddress =="127.0.0.1" || DBRouter.m_IPAddress == "127.0.0.0")
					{
						templink->Router_no = CString("S");// + CString(temp);
						break;
					}
					else
					{
						DBRouter.MoveNext();
					}
				}
				if(templink->Router_no != "S")
				{
					char temp[10];
					_itoa(TempForRouter,temp,10);
					DBRouter.m_strFilter = "IPAddress ='" + templink->GetIP() + "'";
					DBRouter.Requery();
					if(DBRouter.m_InterfaceNo == "")
						templink->Router_no = CString("R") + CString(temp);
					else
						templink->Router_no = DBRouter.m_InterfaceNo;
				}
			}
		}
		linklist = linklist->NextY;
		templink = linklist;
		bool check=TRUE;
		while(Expendaddress.m_BeforeIP == temproot->GetIP())
		{
			linklist = templink;
			while(linklist->NextX != '\0')
			{
				if(linklist->GetIP() == Expendaddress.m_NextIP)
					check=FALSE;
				linklist = linklist->NextX;
			}
			if(linklist->GetIP() == Expendaddress.m_NextIP)
				check=FALSE;
			if(check == TRUE)
			{
				CheckExpand = TRUE;
				templink = new Linklist;
				linklist->NextX = templink;
				templink->PreviousX = linklist;
				templink->PreviousY = linklist->PreviousY;
				templink->NextX = '\0';
				templink->NextY ='\0';
				templink->SetPosX(linklist->GetPosX());
				templink->SetPosY(linklist->GetPosY() - 25);
				templink->SetIP(Expendaddress.m_NextIP);
				DBIP.m_strFilter ="";
				DBIP.Requery();
				DBIP.m_strFilter = "IPAddress = '" + templink->GetIP() + "'";
				DBIP.Requery();
				if(DBIP.GetRecordCount() != 0)
				{
					if(DBIP.m_Alive ==TRUE)
						templink->SetAlive(TRUE);
					else
						templink->SetAlive(FALSE);
				}
				DBRouter.m_strFilter = "";
				DBRouter.Requery();
				DBRouter.m_strFilter = "IPAddress = '" + Expendaddress.m_NextIP + "'";
				DBRouter.Requery();
				if(DBRouter.GetRecordCount() !=0)
				{	
					char temp[10];
					_itoa(DBRouter.m_Router_No,temp,10);
					CString temp2;
					temp2 = CString("Router_No = ") + CString(temp);
					DBRouter.m_strFilter = "";
					DBRouter.Requery();
					DBRouter.m_strFilter = temp2;
					DBRouter.Requery();
					TempForRouter = DBRouter.m_Router_No;
					while(DBRouter.m_Router_No == TempForRouter)
					{
						if(DBRouter.m_IPAddress =="127.0.0.1" || DBRouter.m_IPAddress == "127.0.0.0")
						{
							templink->Router_no = CString("S");// + CString(temp);
							break;
						}
						else
						{
							DBRouter.MoveNext();
						}
					}
					if(templink->Router_no != "S")
					{
						char temp[10];
						_itoa(TempForRouter,temp,10);
						DBRouter.m_strFilter = "IPAddress ='" + templink->GetIP() + "'";
						DBRouter.Requery();
						if(DBRouter.m_InterfaceNo == "")
							templink->Router_no = CString("R") + CString(temp);
						else
							templink->Router_no = DBRouter.m_InterfaceNo;
					}		
				}
			}
			else
				check = TRUE;
			Expendaddress.MoveNext();
		}
	}
	Expendaddress.Close();
	DBRouter.Close();
	BOOL CheckExpend=TRUE;
	//For Position
	while(linklist->NextX != '\0')
		linklist = linklist->NextX;
	templink = linklist->PreviousY;
	if(linklist->PreviousY !='\0')
	{
		while(templink->NextX !='\0')
		{
			templink->NextX->SetPosY(linklist->GetPosY() - 25);
			templink = templink->NextX;
			if(linklist->PreviousY !='\0')
			{
				if(CheckExpend == TRUE)
					linklist = linklist->PreviousY;
				if(linklist->NextX !='\0')
				{
					linklist = linklist->NextX;
					if(linklist->NextY !='\0')
					{
						linklist = linklist->NextY;
						while(linklist->NextX !='\0')
							linklist = linklist->NextX;
						CheckExpend = TRUE;
					}
					else
						CheckExpend = FALSE;
				}
			}
		}

	}
	//////////////
	CDC *pDC;
	pDC = GetDC();
	CPen pen;
	linklist = root;
	CPoint point;
	OnPrepareDC(pDC);
	pDC->DPtoLP(&point);
	pen.CreatePen(PS_SOLID,1,RGB(255,255,255));
	pDC->SelectObject(pen);
	OnDrawForHost(pDC);
	pDC->Rectangle(0,0,SizeX,-SizeY);
	OnDraw(pDC);
}

void CUIView::ChangeDBFromRIP(TableAddressStep *DBStep)
{
	if(linklist == root)
		return;
	else
	{
	if(linklist->NextY =='\0')
	{
		if(linklist->NextX =='\0')
		{
			DBStep->m_strFilter = "";
			DBStep->Requery();
			DBStep->m_strFilter = "NextIP = '" + linklist->GetIP() + "'";
			DBStep->Requery();
			if(DBStep->GetRecordCount() != 0)
			{
				DBStep->Edit();
				DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
				DBStep->Update();
			}
			else
			{
				if(root != linklist->PreviousY)
				{
					DBStep->AddNew();
					DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
					DBStep->m_NextIP = linklist->GetIP();
					DBStep->Update();
				}
			}
				linklist = linklist->PreviousY;
				while(linklist->NextX =='\0')
				{
					if(linklist->PreviousY != '\0')
						linklist = linklist->PreviousY;
					else
						return;
				}
				if(linklist->NextX !='\0')
					linklist = linklist->NextX;
			return;
		}
		else
		{
			DBStep->m_strFilter = "";
			DBStep->Requery();
			DBStep->m_strFilter = "NextIP = '" + linklist->GetIP() + "'";
			DBStep->Requery();
			if(DBStep->GetRecordCount() != 0)
			{
				DBStep->Edit();
				DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
				DBStep->Update();
			}
			else
			{
				if(root != linklist->PreviousY)
				{
					DBStep->AddNew();
					DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
					DBStep->m_NextIP = linklist->GetIP();
					DBStep->Update();
				}
			}
			linklist = linklist->NextX;
			ChangeDBFromRIP(DBStep);
		}
			
	}
	else
	{
		DBStep->m_strFilter = "";
		DBStep->Requery();
		DBStep->m_strFilter = "NextIP = '" + linklist->GetIP() + "'";
		DBStep->Requery();
		if(DBStep->GetRecordCount() != 0)
		{
			DBStep->Edit();
			DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
			DBStep->Update();
		}
		else
		{
			if(root != linklist->PreviousY)
			{
				DBStep->AddNew();
				DBStep->m_BeforeIP = linklist->PreviousY->GetIP();
				DBStep->m_NextIP = linklist->GetIP();
				DBStep->Update();
			}
		}
		linklist = linklist->NextY;
		ChangeDBFromRIP(DBStep);
	}
	ChangeDBFromRIP(DBStep);
	}
}

void CUIView::OnMenurclickCheckstatus() 
{
	// TODO: Add your command handler code here
	StatusPing pingcheckdlg(this);
	pingcheckdlg.m_PingResult = linklist->GetIP();
	pingcheckdlg.ShowPingResult();
	linklist->SetAlive(pingcheckdlg.PingStatus);
	TableIP DBIP;
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	CPoint point;
	CPen pen;
	CDC *pDC;
	pDC = GetDC();
	OnPrepareDC(pDC);
	pDC->DPtoLP(&point);
	pen.CreatePen(PS_SOLID,1,RGB(255,255,255));
	pDC->SelectObject(pen);
	//pDC->Rectangle(0,0,SizeX,SizeY);
	pDC->Rectangle(linklist->GetPosX()-10,linklist->GetPosY()+10,linklist->GetPosX()+100,linklist->GetPosY()-10);
	OnDraw(pDC);
	if(DBIP.IsBOF())
	{
		DBIP.AddNew();
		DBIP.m_IPAddress = linklist->GetIP();
		DBIP.m_Alive = pingcheckdlg.PingStatus;
		DBIP.Update();
	}
	else
	{
		DBIP.m_strFilter = "IPAddress = '" + linklist->GetIP() + "'";
		DBIP.Requery();
		if(DBIP.GetRecordCount() == 0)
		{
			DBIP.AddNew();
			DBIP.m_IPAddress = linklist->GetIP();
			DBIP.m_Alive = pingcheckdlg.PingStatus;
			DBIP.Update();
		}
		else
		{
			DBIP.Edit();
			DBIP.m_Alive = linklist->GetAlive();
			DBIP.Update();
		}
	}
	if (pingcheckdlg.DoModal() == IDCANCEL)
	{
		AfxGetMainWnd()->m_hWnd;
	}
	/*DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	if(DBIP.IsBOF())
	{
		DBIP.AddNew();
		DBIP.m_IPAddress = linklist->GetIP();
		DBIP.m_Alive = pingcheckdlg.PingStatus;
		DBIP.Update();
	}
	DBIP.m_strFilter = "IPAddress '" + linklist->GetIP() + "'";
	DBIP.Requery();
	if(DBIP.GetRecordCount() == 0)
	{
		DBIP.AddNew();
		DBIP.m_IPAddress = linklist->GetIP();
		DBIP.m_Alive = pingcheckdlg.PingStatus;
		DBIP.Update();
	}
	else
	{
		DBIP.Edit();
		DBIP.m_Alive = linklist->GetAlive();
		DBIP.Update();
	}*/
}

void CUIView::OnOptionAutorefreshAuto() 
{
	// TODO: Add your command handler code here
	IsSetTimer = TRUE;
	TimerForRefresh = 1000*60*60;//Auto 1 Hour
	m_nTimer = SetTimer(1, TimerForRefresh, 0);

	
}

void CUIView::OnOptionAutorefreshNone() 
{
	// TODO: Add your command handler code here
	if(IsSetTimer == TRUE)
	{
		IsSetTimer = FALSE;
		KillTimer(m_nTimer);
	}
	
}

void CUIView::OnUpdateOptionAutorefreshNone(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(IsSetTimer==FALSE)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);	
}

void CUIView::OnUpdateOptionAutorefreshAuto(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(IsSetTimer==TRUE)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);	
}

void CUIView::OnUpdateMenuREFRESH(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(IsSetTimer==TRUE)
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);	
}

void CUIView::OnOptionCleardatabase() 
{
	// TODO: Add your command handler code here
	//Declare Variable
	TableIP DBIP;
	TableAddressStep DBStep;
	TableNetwork DBNetwork;
	TableRouter DBRouter;
	//Initial Variable
	DBIP.Open(dbOpenDynaset,_T("Select * from IPAddr"));
	DBStep.Open(dbOpenDynaset,_T("Select * from IPAddrStep"));
	DBNetwork.Open(dbOpenDynaset,_T("Select * from NetworkAddress"));
	DBRouter.Open(dbOpenDynaset,_T("Select * from Router"));
	//Delete Database
	while(!DBIP.IsEOF())
	{
		DBIP.Delete();
		DBIP.MoveNext();
	}
	while(!DBStep.IsEOF())
	{
		DBStep.Delete();
		DBStep.MoveNext();
	}
	while(!DBNetwork.IsEOF())
	{
		DBNetwork.Delete();
		DBNetwork.MoveNext();
	}
	while(!DBRouter.IsEOF())
	{
		DBRouter.Delete();
		DBRouter.MoveNext();
	}
	DBIP.Close();
	DBStep.Close();
	DBNetwork.Close();
	DBRouter.Close();	
}

void CUIView::OnDrawForHost(CDC *pDC)
{
	CPen pen;
	pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
	if(linklist->NextY =='\0')
	{
		//if(linklist->PreviousX =='\0' && linklist->NextX !='\0')//Line Cuttting
		//	Line(pDC);
		pDC->SelectObject(&pen);
		templink =linklist;
		if(linklist->PreviousX !='\0')
		{
		//	linklist->SetPosY(linklist->PreviousX->GetPosY() + 25);
		}
		else
		{	
			templink = linklist;
			if(templink->PreviousY !='\0')
			{
				templink = templink->PreviousY;
				while(templink->PreviousX == '\0')
				{
					if(templink == root)
						break;
					templink = templink->PreviousY;
				}
				if(templink != root && templink->PreviousX !='\0')
				{
					templink = templink->PreviousX;
					while(templink->NextX !='\0')
						templink = templink->NextX;
					if(templink->NextX =='\0')
					{
						while(templink->NextY !='\0')
							templink = templink->NextY;
						if(templink->NextY =='\0')
						{
							//templink = templink->NextY;
							while(templink->NextX !='\0')
								templink = templink->NextX;
							//linklist->SetPosY(templink->GetPosY() + 25);
							//linklist->PreviousY->SetPosY(templink->GetPosY() + 25);
							if(linklist->PreviousX !='\0')
							{
								if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
									linklist->SetPosX(linklist->PreviousY->GetPosX()+25);
							}
							//if(linklist->PreviousY->PreviousX !='\0')
							//	if(linklist->PreviousY->PreviousX->GetPosX() == linklist->PreviousY->GetPosX() && linklist->PreviousY->PreviousX->GetPosY() == linklist->PreviousY->GetPosY())
							//		linklist->PreviousY->SetPosY(linklist->PreviousY->PreviousX->GetPosY()+25);
							
						}
					}
				}
			}						
		}
		//linklist = templink;
		//For Posiotion
		if(linklist->PreviousX =='\0')
			if(linklist->PreviousY !='\0')
				linklist->SetPosY(linklist->PreviousY->GetPosY());
		//End Position
		if(linklist->PreviousY != '\0')
		{
			if(linklist->PreviousY->GetPosX() == linklist->GetPosX() && linklist->PreviousY->GetPosY() == linklist->GetPosY())
				linklist->SetPosX(linklist->PreviousY->GetPosX()+100);
			pDC->MoveTo(linklist->PreviousY->GetPosX() + 150,linklist->PreviousY->GetPosY() - 5);
			pDC->LineTo(linklist->GetPosX() - 5,linklist->GetPosY() - 5);
		}
		if(linklist->GetAlive() == TRUE)
		{
			if(linklist->NextY =='\0')//For Host
				pDC->SetTextColor(RGB(0,255,0));
			else
				pDC->SetTextColor(RGB(0,0,255));
		}
		else
			pDC->SetTextColor(RGB(255,0,0));
		pDC->TextOut(linklist->GetPosX(),linklist->GetPosY(),linklist->GetIP());
		pDC->TextOut(linklist->GetPosX() + 120,linklist->GetPosY(),linklist->Router_no);
		if(linklist->NextX =='\0')
		{
			while(linklist->NextX == '\0')
			{
				if(linklist->PreviousY != '\0')
					linklist = linklist->PreviousY;
				else
					break;
			}
			if(linklist->NextX != '\0')
			{
				linklist = linklist->NextX;
				if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
					linklist->SetPosY(linklist->PreviousX->GetPosY()+25);
				OnDrawForHost(pDC);
			}
			return;
		}
		else
		{
			linklist = linklist->NextX;
			if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
				linklist->SetPosY(linklist->PreviousX->GetPosY() - 25);
			OnDrawForHost(pDC);
		}
	}
	else
	{
		//For Position
		if(linklist->PreviousX =='\0')
			if(linklist->PreviousY !='\0')
				linklist->SetPosY(linklist->PreviousY->GetPosY());
		//End Position
		if(linklist->PreviousY != '\0')
		{
			if(linklist->PreviousY->GetPosX() == linklist->GetPosX() && linklist->PreviousY->GetPosY() == linklist->GetPosY())
				linklist->SetPosX(linklist->PreviousY->GetPosX()+100);
			//if(linklist->PreviousX->GetPosX() == linklist->GetPosX() && linklist->PreviousX->GetPosY() == linklist->GetPosY())
			//	linklist->SetPosY(linklist->PreviousX->GetPosY()+25);
			pDC->MoveTo(linklist->PreviousY->GetPosX() + 150,linklist->PreviousY->GetPosY() - 5);
			pDC->LineTo(linklist->GetPosX() - 5,linklist->GetPosY() - 5);
		}
		if(linklist->GetAlive() == TRUE)
			pDC->SetTextColor(RGB(0,0,255));
		else
			pDC->SetTextColor(RGB(255,0,0));
		if(linklist->NextY =='\0')//For Host
			pDC->SetTextColor(RGB(0,255,0));
		pDC->TextOut(linklist->GetPosX(),linklist->GetPosY(),linklist->GetIP());
		pDC->TextOut(linklist->GetPosX() + 120,linklist->GetPosY(),linklist->Router_no);
		linklist = linklist->NextY;
		OnDrawForHost(pDC);
	}
}

void CUIView::AddlinklistForHOP(TableIP *DBIPAddress, TableAddressStep *DBIPStep,TableNetwork *DBNetwork)
{
	CString IPAddressEnd,IPTemp;
	StatusIP statusip;
	while(!DBNetwork->IsEOF())
	{
		IPAddressEnd = DBNetwork->m_NetworkAddressEnd;
		IPTemp = DBNetwork->m_NetworkAddressFirst;
 		while(statusip.CompareIP(IPAddressEnd,IPTemp))
		{
			DBIPAddress->m_strFilter = "IPAddress = '" + IPTemp +"'";
			DBIPAddress->Requery();
			if (DBIPAddress->GetRecordCount() != 0)
			{
				if (!DBIPStep->IsBOF())						//Check For Database Value
				{
					DBIPStep->m_strFilter = "BeforeIP = '" + IPTemp + "'";
					DBIPStep->Requery();
					if (DBIPStep->GetRecordCount()==0)		//Search ???? Yes Or No
					{
    					DBIPStep->m_strFilter = "NextIP = '" + IPTemp + "'";
						DBIPStep->Requery();
						if (DBIPStep->GetRecordCount()!= 0)//
						{
							DBIPAddress->m_strFilter = "IPAddress = '" + DBIPStep->m_BeforeIP + "'";
							DBIPAddress->Requery();
							if (DBIPAddress->m_Alive == TRUE)//Before IP Alive
							{
								DBIPAddress->m_strFilter = "IPAddress = '" + DBIPStep->m_NextIP + "'";
								DBIPAddress->Requery();
								if(DBIPAddress->m_Alive == TRUE)//After IP Alive
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress);
								}
								else
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress);//After IP Dead
								}
							}
							else//Before Dead
							{
								DBIPAddress->m_strFilter = "IPAddress = '" + DBIPStep->m_BeforeIP + "'";
								DBIPAddress->Requery();
								if(DBIPAddress->m_Alive == TRUE)//After IP Alive
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress);
								}
								else
								{
									linklist = root;
									CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress);//After IP Dead
								}
							}
						}
						else//Before IP No
						{
							if (DBIPAddress->m_Alive == TRUE)
							{
								linklist = root;
								addlinklist(root->GetIP(),DBIPAddress->m_IPAddress,TRUE,TRUE);
							}
						}
					}
					else//Not Traceroute Solve OwnIP ->IPThat
					{
						linklist = root;
						if(DBIPStep->m_BeforeIP == DBIPStep->m_NextIP)//Bug Unknow
						{
							addlinklist(root->GetIP(),DBIPStep->m_BeforeIP,TRUE,TRUE);
						}
						else
							CheckLinklistINDB(DBIPStep->m_BeforeIP,DBIPStep->m_NextIP,DBIPStep,DBIPAddress);//After IP Dead
					}
				}
				else//Not Traceroute Solve OwnIP -> IPThat
				{
					if(DBIPAddress->m_Alive == TRUE)
					{
						linklist = root;
						addlinklist(root->GetIP(),DBIPAddress->m_IPAddress,TRUE,TRUE);
					}
				}
			}

			IPTemp =statusip.IPIncrease(IPTemp);
			DBIPAddress->m_strFilter ="";
			DBIPAddress->Requery();
			DBIPStep->m_strFilter ="";
			DBIPStep->Requery();
		}
	}
		CheckOnScan = 3;
}

void CUIView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	CUIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CString strDocTitle = "Network Discovery";
	PrintPageCover(pDC, pInfo, strDocTitle);
	pDC->SetWindowOrg(pInfo->m_rectDraw.left,-pInfo->m_rectDraw.top);
	OnDraw(pDC);
	CScrollView::OnPrint(pDC, pInfo);
}

void CUIView::PrintPageCover(CDC *pDC, CPrintInfo *pInfo, CString &sTitle)
{
	pDC->SetTextAlign(TA_LEFT);
	pDC->TextOut(0, -15, sTitle);

	TEXTMETRIC textm;
	pDC->GetTextMetrics(&textm);
	int y = -15-textm.tmHeight;
	pDC->MoveTo(0, y);
	pDC->LineTo(pInfo->m_rectDraw.right, y);
	pDC->MoveTo(0, y-3);
	pDC->LineTo(pInfo->m_rectDraw.right, y-3);
	pInfo->m_rectDraw.top += y-20;
}

void CUIView::OnStatusSystem() 
{
	// TODO: Add your command handler code here
	WWaitTarget wait;
	wait.Show("Search System");
	StatusSystem Systemdlg(this);
	Systemdlg.IPSystem = linklist->GetIP();
	Systemdlg.ShowSystemResult();
	wait.Close();
	if (Systemdlg.DoModal() == IDCANCEL)
	{
		AfxGetMainWnd()->m_hWnd;
	}
	
}

void CUIView::ChangeDBSNMP()
{

}
