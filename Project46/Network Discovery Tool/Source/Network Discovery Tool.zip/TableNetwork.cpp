// TableNetwork.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TableNetwork.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TableNetwork

IMPLEMENT_DYNAMIC(TableNetwork, CDaoRecordset)

TableNetwork::TableNetwork(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(TableNetwork)
	m_NetworkAddressFirst = _T("");
	m_NetworkAddressEnd = _T("");
	m_Netmask = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString TableNetwork::GetDefaultDBName()
{
	return _T("DBComplete97.mdb");
}

CString TableNetwork::GetDefaultSQL()
{
	return _T("[NetworkAddress]");
}

void TableNetwork::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(TableNetwork)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[NetworkAddressFirst]"), m_NetworkAddressFirst);
	DFX_Text(pFX, _T("[NetworkAddressEnd]"), m_NetworkAddressEnd);
	DFX_Text(pFX, _T("[Netmask]"), m_Netmask);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// TableNetwork diagnostics

#ifdef _DEBUG
void TableNetwork::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void TableNetwork::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
