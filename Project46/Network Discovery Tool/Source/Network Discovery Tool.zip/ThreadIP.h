// ThreadIP.h: interface for the ThreadIP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THREADIP_H__E61EAE93_C406_4C17_BF07_8EFD16A8F87E__INCLUDED_)
#define AFX_THREADIP_H__E61EAE93_C406_4C17_BF07_8EFD16A8F87E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ThreadIP  
{
public:
	CString IP;
	BOOL alive;
	ThreadIP();
	virtual ~ThreadIP();

};

#endif // !defined(AFX_THREADIP_H__E61EAE93_C406_4C17_BF07_8EFD16A8F87E__INCLUDED_)
