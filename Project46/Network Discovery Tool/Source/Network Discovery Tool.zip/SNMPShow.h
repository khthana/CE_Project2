#if !defined(AFX_SNMPSHOW_H__7AAC16B3_82FC_4D1A_A3AC_5E0B6F184BA7__INCLUDED_)
#define AFX_SNMPSHOW_H__7AAC16B3_82FC_4D1A_A3AC_5E0B6F184BA7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SNMPShow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SNMPShow dialog

class SNMPShow : public CDialog
{
// Construction
public:
	SNMPShow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(SNMPShow)
	enum { IDD = IDD_SNMP };
	CIPAddressCtrl	m_SNMPIPAddress;
	CString	m_SNMPMethod;
	CString	m_SNMPOid;
	CString	m_SNMPComunityName;
	CString	m_SNMPResult;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SNMPShow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SNMPShow)
	afx_msg void OnSnmp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SNMPSHOW_H__7AAC16B3_82FC_4D1A_A3AC_5E0B6F184BA7__INCLUDED_)
