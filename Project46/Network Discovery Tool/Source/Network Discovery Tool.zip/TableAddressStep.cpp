// TableAddressStep.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "TableAddressStep.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TableAddressStep

IMPLEMENT_DYNAMIC(TableAddressStep, CDaoRecordset)

TableAddressStep::TableAddressStep(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(TableAddressStep)
	m_BeforeIP = _T("");
	m_NextIP = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString TableAddressStep::GetDefaultDBName()
{
	return _T("DBComplete97.mdb");
}

CString TableAddressStep::GetDefaultSQL()
{
	return _T("[IPAddrStep]");
}

void TableAddressStep::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(TableAddressStep)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[BeforeIP]"), m_BeforeIP);
	DFX_Text(pFX, _T("[NextIP]"), m_NextIP);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// TableAddressStep diagnostics

#ifdef _DEBUG
void TableAddressStep::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void TableAddressStep::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
