// CardInfoShow.cpp : implementation file
//

#include "stdafx.h"
#include "UI.h"
#include "CardInfoShow.h"
#include  "StatusIP.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCardInfoShow dialog


CCardInfoShow::CCardInfoShow(CWnd* pParent /*=NULL*/)
	: CDialog(CCardInfoShow::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCardInfoShow)
	m_strShowCardInfo = _T("");
	//}}AFX_DATA_INIT
}


void CCardInfoShow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCardInfoShow)
	DDX_Text(pDX, IDC_CardInfoShow, m_strShowCardInfo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCardInfoShow, CDialog)
	//{{AFX_MSG_MAP(CCardInfoShow)
	ON_BN_CLICKED(ID_GetCardInfo, OnGetCardInfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCardInfoShow message handlers

void CCardInfoShow::OnGetCardInfo() 
{
	// TODO: Add your control notification handler code here
	StatusIP NCI;

	m_strShowCardInfo += _T("NetCard type:\t") + NCI.GetNetCardType() + _T("\r\n");
	m_strShowCardInfo += _T("IP Address:\t") + NCI.GetNetCardIPAddress() + _T("\r\n" );
	m_strShowCardInfo += _T("Subnet Mask:\t") + NCI.GetNetCardSubnetMask() + _T("\r\n");
	m_strShowCardInfo += _T("Gateway:\t\t") + NCI.GetNetCardGateWay() + _T("\r\n");
	m_strShowCardInfo += _T("DHCP Server:\t") + NCI.GetDHCPServer() + _T("\r\n");
	m_strShowCardInfo += _T("MAC Address:\t") + NCI.GetNetCardMACAddress() + _T("\r\n");
	m_strShowCardInfo += _T("Device name:\t") + NCI.GetNetCardDeviceName() + _T("\r\n");
	m_strShowCardInfo += _T("Wins Server:\t") + NCI.GetNetCardWINS() + ("\r\n");
	m_strShowCardInfo += NCI.GetErrorMsg() + _T("\r\n");
	UpdateData(FALSE);
}
