//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Voice2Command.rc
//
#define IDCHECK                         3
#define ID_COMPLETE                     3
#define ID_RESET                        4
#define IDD_ABOUTBOX                    100
#define IDD_VOICE2COMMAND_FORM          101
#define IDD_DOITDIALOG_DIALOG           102
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_V2C                         128
#define IDR_VOICE2TYPE                  129
#define IDD_LOGIN                       131
#define IDD_TRAINING                    132
#define IDD_TESTING                     133
#define IDB_WH                          135
#define IDB_WV                          136
#define IDB_MAINLOGO                    137
#define IDB_LOGINLOGO                   138
#define IDB_TRAINING                    139
#define IDB_TEST                        147
#define IDB_TESTLOGO                    148
#define IDC_MSFLEXGRID1                 1000
#define IDC_USER                        1001
#define IDC_ADD                         1002
#define IDC_EDIT                        1003
#define IDC_USERNAME                    1003
#define IDC_REMOVE                      1004
#define IDC_PASSWD                      1004
#define IDC_TEST                        1008
#define IDC_RECOGNITION                 1009
#define IDBACK                          1010
#define IDC_WORD                        1011
#define IDC_DESCRIPTION                 1012
#define IDC_W_RECORD                    1013
#define IDC_W_RESET                     1014
#define IDC_TESTMODE                    1014
#define IDC_W_PLAY                      1015
#define IDC_TRAINMODE                   1015
#define IDC_H_RECORD                    1016
#define IDC_H_CLEAR                     1017
#define IDC_H_REPLAY                    1018
#define IDC_MMCONTROL                   1019
#define IDC_WAVESTATUS                  1020
#define IDC_TESTSTATUS                  1021
#define IDC_HOOKSTATUS                  1021
#define IDC_MMC                         1022
#define IDC_TIMER                       1022
#define IDC_TRAINALL                    1023
#define IDC_STATUS                      1024
#define IDC_NEWUSER                     1025
#define IDC_PROGRESS                    1027
#define IDC_PROGRESSX                   1028
#define IDC_COMMAND                     1029
#define IDC_LOAD                        1031
#define IDC_LOADED                      1032
#define IDC_OPEN                        1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
