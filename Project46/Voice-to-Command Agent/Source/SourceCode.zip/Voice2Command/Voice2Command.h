// Voice2Command.h : main header file for the VOICE2COMMAND application
//

#if !defined(AFX_VOICE2COMMAND_H__86816599_FFE8_4550_BE7A_8A2F67A4D7E3__INCLUDED_)
#define AFX_VOICE2COMMAND_H__86816599_FFE8_4550_BE7A_8A2F67A4D7E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandApp:
// See Voice2Command.cpp for the implementation of this class
//

class CVoice2CommandApp : public CWinApp
{
public:
	CVoice2CommandApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoice2CommandApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CVoice2CommandApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOICE2COMMAND_H__86816599_FFE8_4550_BE7A_8A2F67A4D7E3__INCLUDED_)
