// Voice2CommandSet.h : interface of the CVoice2CommandSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOICE2COMMANDSET_H__19473320_1A97_4170_8C41_1F9D957B53F6__INCLUDED_)
#define AFX_VOICE2COMMANDSET_H__19473320_1A97_4170_8C41_1F9D957B53F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVoice2CommandSet : public CRecordset
{
public:
	CVoice2CommandSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CVoice2CommandSet)

// Field/Param Data
	//{{AFX_FIELD(CVoice2CommandSet, CRecordset)
	long	m_id;
	long	m_no;
	CString	m_word;
	CString	m_description;
	CString	m_filename;
	CString	m_wavefile;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoice2CommandSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOICE2COMMANDSET_H__19473320_1A97_4170_8C41_1F9D957B53F6__INCLUDED_)

