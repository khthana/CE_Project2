#include "windows.h"
#include "iostream.h"
#include "fstream.h"

#include "string"
using std::string;
/*
#ifndef _NO_NAMESPACE
using namespace std;
#define STD std
#else
#define STD
#endif
*/

//#define FILENAME "Hook\\TestHooks.bin"

//Global name
	
	string HooksForPlay;	
	HHOOK hhookHooks;
	DWORD dwStartRecordTime;

	/*
typedef struct TAGEventNode{
	EVENTMSG	Event;
	struct TAGEventNode * lpNextEvent;
} EventNode;


EventNode *lpEventChain = NULL;
EventNode *lpLastEvent  = NULL;
EventNode *lpPlayEvent  = NULL;
*/

int m_Max = 0;
int m_Now = 0;

extern "C"{

LRESULT CALLBACK JournalRecordFunc (int nCode,WPARAM wParam,LPARAM lParam)
{
//	EventNode  *lpEventNode;
	LPEVENTMSG	lpEvent;
	
	if (nCode >=0)
	{
		lpEvent = (LPEVENTMSG) lParam;
		
		if (lpEvent->message == WM_KEYDOWN && LOBYTE(lpEvent->paramL)==VK_F2)
		{
			UnhookWindowsHookEx(hhookHooks);		//Remove Hook;
			return 0;
		}
/*
		if ((lpEventNode = (EventNode*)malloc(sizeof(EventNode))) == NULL)
		{
			UnhookWindowsHookEx(hhookHooks);		//Remove Hook
		}
*/
		//if (lpLastEvent==NULL)	// Not have events = It's first time must pass.
		if (m_Max == 0)
		{
			dwStartRecordTime = (DWORD) GetTickCount();
//			lpEventChain = lpEventNode;	// Set Head Chaining to ...(before add information)
		} else {
//			lpLastEvent->lpNextEvent = lpEventNode;		// Make linking... (Append at tail)
		}
/*
		lpLastEvent = lpEventNode;
		lpLastEvent->lpNextEvent = NULL;

		lpLastEvent->Event.message	= lpEvent->message;
		lpLastEvent->Event.paramL	= lpEvent->paramL;
		lpLastEvent->Event.paramH	= lpEvent->paramH;
		lpLastEvent->Event.time		= lpEvent->time;
*/
		
		ofstream file;

		// Initial name of file name for record
		HooksForPlay = "Hook\\TestHooks.bin";  // For use char strings with "HooksForPlay.c_str()"
		
			file.open (HooksForPlay.c_str(),ios::out|ios::app|ios::binary);
			file<<lpEvent->message<<endl;
			file<<lpEvent->paramL<<endl;
			file<<lpEvent->paramH<<endl;
			file<<lpEvent->time<<endl;
		file.close();
		m_Max++;

		return 0;
	}

	return (CallNextHookEx(hhookHooks,nCode,wParam,lParam));
}

LRESULT CALLBACK JournalPlaybackFunc (int nCode,WPARAM wParam,LPARAM lParam)
{
	static int		nRepeatRequests;
	static DWORD	dwTimeAdjust;
	static DWORD	dwLastEventTime;
	LPEVENTMSG		lpEvent;
	long			lReturnValue;

	if (nCode >= 0)
	{
			ifstream file;
			file.open (HooksForPlay.c_str(),ios::in);
		
			char buffer[64];
			m_Max = 0;

			file.getline(buffer,64);
			int  Res = atoi(buffer);

			while (!file.eof() && (Res > 0))
			{
				file.getline(buffer,64);
				file.getline(buffer,64);
				file.getline(buffer,64);
				
				if (m_Max == 0)	// Add by myself becoz it must initial
				{
					file.getline(buffer,8,'\n');	
					long time	= atol(buffer);
					dwStartRecordTime = time;
				}

				file.getline(buffer,64);
				Res = atoi(buffer);
				m_Max++;
			}
			file.close();

	if (m_Max == 0)
	//	if (lpEventChain == NULL)
	{
		//AfxMessageBox("Not have any events.",1,MB_OK);
		UnhookWindowsHookEx(hhookHooks);		//RemoveHook
		return 0; //((int) CallNextHookEx(WH_JOURNALPLAYBACK,nCode,wParam,lParam));
	}

	if (m_Now == 0)
	//if (lpPlayEvent == NULL)	// First set Playing pointer
	{
//		lpPlayEvent = lpEventChain;
//		lpLastEvent = NULL;
		//dwStartRecordTime = (DWORD) GetTickCount();	// Add by myself becoz it must initial

		dwTimeAdjust = GetTickCount() - dwStartRecordTime;
		dwLastEventTime = (DWORD) GetTickCount();
		nRepeatRequests = 1;
		m_Now++;
	}

	if (nCode == HC_SKIP){
		nRepeatRequests = 1;
		
		if (m_Now >= m_Max)
		//if (lpPlayEvent->lpNextEvent == NULL)		// End of Events
		{
			//free(lpEventChain);
			//lpEventChain = lpPlayEvent = NULL;
			m_Max = 0;
			m_Now = 0;
			UnhookWindowsHookEx(hhookHooks);		//Remove JOURNAL
		}
		else										// Case running playback...
		{
			ifstream file;
			file.open (HooksForPlay.c_str(), ios::in);

			char buffer[64];
			int  R = 0;
		
			while ((R < m_Now) && (!file.eof()))
			{
				file.getline(buffer,64);
				file.getline(buffer,64);
				file.getline(buffer,64);
				file.getline(buffer,64);
			}
			file.getline(buffer,64);
			file.getline(buffer,64);
			file.getline(buffer,64);
			file.getline(buffer,64);
			long time = atol(buffer);

			++m_Now;
			dwLastEventTime = time;
			file.close();

			//dwLastEventTime = lpPlayEvent->Event.time;
			//lpPlayEvent = lpPlayEvent->lpNextEvent;	// Skip to next node
			//free(lpEventChain);						// clear finished node
			//lpEventChain = lpPlayEvent;				// set head to next node
		}
	}
	else if (nCode == HC_GETNEXT) 
	{
		ifstream file;
		file.open (HooksForPlay.c_str(), ios::in);

		char buffer[64];
		int  R = 0;
		
		while ((R < m_Now) && (!file.eof()))
		{
			file.getline(buffer,64);
			file.getline(buffer,64);
			file.getline(buffer,64);
			file.getline(buffer,64);
			R++;
		}
		lpEvent = (LPEVENTMSG) lParam;
			
		file.getline(buffer,8,'\n');	int message = atoi(buffer);
		file.getline(buffer,8,'\n');	int paramL	= atoi(buffer);
		file.getline(buffer,8,'\n');	int paramH	= atoi(buffer);
		file.getline(buffer,8,'\n');	long time	= atol(buffer);

		lpEvent->paramH  = paramH;
		lpEvent->paramL  = paramL;
		lpEvent->message = message;
		lpEvent->time	 = (DWORD) GetTickCount(); //0; //time + dwTimeAdjust;
/*
		lpEvent->message = lpPlayEvent->Event.message;
		lpEvent->paramL  = lpPlayEvent->Event.paramL;
		lpEvent->paramH  = lpPlayEvent->Event.paramH;
		lpEvent->time	 = lpPlayEvent->Event.time + dwTimeAdjust;
*/
		file.close();

		//////////////////////// DEBUG Version... ///////////////////////
/*
		ofstream file2;
		file2.open ("C:\\CheckHooksInPlay.bin", ios::out | ios::app | ios::binary);
			file2<<lpEvent->message<<"\t"<<lpEvent->paramL<<"\t"<<lpEvent->paramH<<"\t"<<lpEvent->time<<endl;
		file2.close();
*/
		/////////////////////////////////////////////////////////////////

		lReturnValue = lpEvent->time - GetTickCount();
		if (lReturnValue < 0L )
		{ 
			lReturnValue = 0L;
			lpEvent->time = GetTickCount();
		}
		return ((DWORD) lReturnValue);
	}
	} // if nCode >= 0

	return (CallNextHookEx(hhookHooks,nCode,wParam,lParam));
}

} // end of C extern