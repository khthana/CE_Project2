// myCodeBook.h: interface for the myCodeBook class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCODEBOOK_H__82F22B4B_8F56_4B74_97AB_036879230D5F__INCLUDED_)
#define AFX_MYCODEBOOK_H__82F22B4B_8F56_4B74_97AB_036879230D5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class myCodeBook  
{
public:
	myCodeBook();
	virtual ~myCodeBook();
	float Buffer_Book[39][16];
	
	void GetArray(int ID);
	void SetArray(float x[39][16]);
	void SetArrays(float x[39][16],int ID);

private :
	float All_Books[10][39][16];
};

#endif // !defined(AFX_MYCODEBOOK_H__82F22B4B_8F56_4B74_97AB_036879230D5F__INCLUDED_)
