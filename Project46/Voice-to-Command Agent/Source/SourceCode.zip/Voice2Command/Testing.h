//{{AFX_INCLUDES()
#include "mci.h"
//}}AFX_INCLUDES
#if !defined(AFX_TESTING_H__B7DEE238_1B6A_4162_AF7E_A03F596B636A__INCLUDED_)
#define AFX_TESTING_H__B7DEE238_1B6A_4162_AF7E_A03F596B636A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Testing.h : header file
//

#include "Voice2CommandSet.h"
#include "myCodeBook.h"

/////////////////////////////////////////////////////////////////////////////
// Testing dialog

class Testing : public CDialog
{
// Construction
public:
	bool TimerRunning;
	Testing(CWnd* pParent = NULL);   // standard constructor
	void setUser(CString user,int ID,long MaxWave);
//	void Reloaded();

// Dialog Data
	//{{AFX_DATA(Testing)
	enum { IDD = IDD_TESTING };
	CProgressCtrl	m_Progess;
	CButton	m_Recog;
	CString	m_User;
	int		m_Id;
	myCodeBook m_CodeBook;
	CVoice2CommandSet *	m_pSet;
	CVoice2CommandSet	m_Set;
	Cmci	m_MCI2;
	CString	m_TestStatus;
	CString m_TempWave;
	CString m_WaveOGRfile;
	BOOL	m_Recording;
	long	MaxLengthWave;
	CString	m_Filename;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Testing)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void StartTimer();
	void ShowTimer();

	// Generated message map functions
	//{{AFX_MSG(Testing)
	afx_msg void OnRecognition();
	afx_msg void OnBack();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnLoaded();
	afx_msg void OnOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTING_H__B7DEE238_1B6A_4162_AF7E_A03F596B636A__INCLUDED_)
