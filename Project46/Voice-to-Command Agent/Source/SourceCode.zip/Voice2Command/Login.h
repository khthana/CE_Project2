#if !defined(AFX_LOGIN_H__50BCF1D4_D3A3_4681_91A7_098548CFCB6F__INCLUDED_)
#define AFX_LOGIN_H__50BCF1D4_D3A3_4681_91A7_098548CFCB6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Login.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLogin dialog

class CLogin : public CDialog
{
// Construction
public:
	CLogin(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLogin)
	enum { IDD = IDD_LOGIN };
	CString		m_User;
	CString		m_Pass;
	BOOL		m_CheckPermission;
	BOOL		m_TrainMode;
	int			m_id;
	BOOL	m_NewUser;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogin)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLogin)
	afx_msg void OnReset();
	afx_msg void OnCheck();
	afx_msg void OnClose();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGIN_H__50BCF1D4_D3A3_4681_91A7_098548CFCB6F__INCLUDED_)
