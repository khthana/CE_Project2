; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=Testing
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Voice2Command.h"
LastPage=0

ClassCount=12
Class1=CVoice2CommandApp
Class2=CVoice2CommandDoc
Class3=CVoice2CommandView
Class4=CMainFrame
Class6=CAboutDlg

ResourceCount=13
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Class5=CVoice2CommandSet
Resource3=IDD_VOICE2COMMAND_FORM
Resource4=IDR_MAINFRAME (English (U.S.))
Resource5=IDD_VOICE2COMMAND_FORM (Neutral)
Resource6=IDD_ABOUTBOX (Neutral)
Class7=CUserSet
Class8=CuserSet
Resource7=IDD_LOGIN (Neutral)
Class9=CLogin
Resource8=IDR_V2C (Neutral)
Resource9=IDR_MAINFRAME (Neutral)
Class10=Training
Class11=Testing
Resource10=IDD_DOITDIALOG_DIALOG
Resource11=IDD_TESTING (Neutral)
Resource12=IDD_TRAINING (Neutral)
Class12=DoitDialog
Resource13=IDR_V2C (English (U.S.))

[CLS:CVoice2CommandApp]
Type=0
HeaderFile=Voice2Command.h
ImplementationFile=Voice2Command.cpp
Filter=N

[CLS:CVoice2CommandDoc]
Type=0
HeaderFile=Voice2CommandDoc.h
ImplementationFile=Voice2CommandDoc.cpp
Filter=N
LastObject=CVoice2CommandDoc

[CLS:CVoice2CommandView]
Type=0
HeaderFile=Voice2CommandView.h
ImplementationFile=Voice2CommandView.cpp
Filter=D
BaseClass=CRecordView
VirtualFilter=RVWC
LastObject=CVoice2CommandView


[CLS:CVoice2CommandSet]
Type=0
HeaderFile=Voice2CommandSet.h
ImplementationFile=Voice2CommandSet.cpp
Filter=N

[DB:CVoice2CommandSet]
DB=1
DBType=ODBC
ColumnCount=7
Column1=[COMMANDS].[id], 4, 4
Column2=[no], 4, 4
Column3=[word], 12, 100
Column4=[description], 12, 100
Column5=[USERS].[id], 4, 4
Column6=[username], 12, 100
Column7=[password], 12, 20


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
LastObject=CMainFrame
BaseClass=CFrameWnd
VirtualFilter=fWC




[CLS:CAboutDlg]
Type=0
HeaderFile=Voice2Command.cpp
ImplementationFile=Voice2Command.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_LICENSE

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_MRU_FILE1
Command6=ID_APP_EXIT
Command10=ID_EDIT_PASTE
Command11=ID_RECORD_FIRST
Command12=ID_RECORD_PREV
Command13=ID_RECORD_NEXT
Command14=ID_RECORD_LAST
Command15=ID_APP_ABOUT
CommandCount=15
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command7=ID_EDIT_UNDO
Command8=ID_EDIT_CUT
Command9=ID_EDIT_COPY

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command5=ID_EDIT_CUT
Command6=ID_EDIT_COPY
Command7=ID_EDIT_PASTE
Command8=ID_EDIT_UNDO
Command9=ID_EDIT_CUT
Command10=ID_EDIT_COPY
Command11=ID_EDIT_PASTE
Command12=ID_NEXT_PANE
CommandCount=13
Command4=ID_EDIT_UNDO
Command13=ID_PREV_PANE

[DLG:IDD_VOICE2COMMAND_FORM]
Type=1
Class=CVoice2CommandView

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_COPY
Command2=ID_EDIT_PASTE
Command3=ID_EDIT_CUT
Command4=ID_EDIT_COPY
Command5=ID_EDIT_PASTE
Command6=ID_EDIT_CUT
Command7=ID_EDIT_UNDO
CommandCount=7

[DLG:IDD_VOICE2COMMAND_FORM (Neutral)]
Type=1
Class=CVoice2CommandView
ControlCount=14
Control1=IDC_ADD,button,1342242816
Control2=IDC_EDIT,button,1342242816
Control3=IDC_REMOVE,button,1342242816
Control4=IDC_TRAINALL,button,1342242816
Control5=IDC_TEST,button,1342242816
Control6=IDC_MSFLEXGRID1,{6262D3A0-531B-11CF-91F6-C2863C385E30},1342177280
Control7=IDC_STATIC,button,1342177287
Control8=IDC_USER,edit,1350568064
Control9=IDC_STATIC,static,1342308352
Control10=IDC_STATIC,static,1342177294
Control11=IDC_STATIC,button,1342177287
Control12=IDC_STATUS,edit,1350568065
Control13=IDC_STATIC,button,1342177287
Control14=IDC_PROGRESS,msctls_progress32,1350565888

[DLG:IDD_ABOUTBOX (Neutral)]
Type=1
Class=CAboutDlg
ControlCount=11
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,button,1342177287
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDC_STATIC,static,1342308352
Control11=IDC_STATIC,static,1342308352

[MNU:IDR_MAINFRAME (Neutral)]
Type=1
Class=CMainFrame
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[CLS:CUserSet]
Type=0
HeaderFile=UserSet.h
ImplementationFile=UserSet.cpp
BaseClass=CRecordset
Filter=N
VirtualFilter=r

[DB:CUserSet]
DB=1
DBType=ODBC
ColumnCount=3
Column1=[id], 4, 4
Column2=[username], 12, 100
Column3=[password], 12, 20

[CLS:CuserSet]
Type=0
HeaderFile=userSet.h
ImplementationFile=userSet.cpp
BaseClass=CRecordset
Filter=N
VirtualFilter=r

[DB:CuserSet]
DB=1
DBType=ODBC
ColumnCount=3
Column1=[id], 4, 4
Column2=[username], 12, 100
Column3=[password], 12, 20

[CLS:CLogin]
Type=0
HeaderFile=Login.h
ImplementationFile=Login.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=ID_FILE_LOGIN

[DLG:IDD_LOGIN (Neutral)]
Type=1
Class=CLogin
ControlCount=11
Control1=IDC_USERNAME,edit,1350631552
Control2=IDC_PASSWD,edit,1350631584
Control3=IDC_TRAINMODE,button,1342242825
Control4=IDC_TESTMODE,button,1342242825
Control5=IDCHECK,button,1342242817
Control6=ID_RESET,button,1342177280
Control7=IDC_NEWUSER,button,1342242819
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDC_STATIC,button,1342177287
Control11=IDC_STATIC,static,1342177294

[DLG:IDD_TRAINING (Neutral)]
Type=1
Class=Training
ControlCount=27
Control1=IDC_W_RECORD,button,1342242817
Control2=IDC_H_RECORD,button,1342242817
Control3=IDC_WORD,edit,1350631552
Control4=IDC_DESCRIPTION,edit,1350631552
Control5=ID_COMPLETE,button,1342242817
Control6=IDCANCEL,button,1342242816
Control7=IDC_STATIC,static,1342177294
Control8=IDC_STATIC,static,1342177294
Control9=IDC_USER,edit,1350568064
Control10=IDC_STATIC,static,1342308352
Control11=IDC_STATIC,static,1342177294
Control12=IDC_STATIC,button,1342177287
Control13=IDC_STATIC,button,1342177287
Control14=IDC_STATIC,button,1342177287
Control15=IDC_STATIC,static,1342308352
Control16=IDC_STATIC,static,1342308352
Control17=IDC_W_RESET,button,1342177280
Control18=IDC_W_PLAY,button,1342242816
Control19=IDC_H_CLEAR,button,1342177280
Control20=IDC_H_REPLAY,button,1342242816
Control21=IDC_STATIC,button,1342177287
Control22=IDC_MMCONTROL,{C1A8AF25-1257-101B-8FB0-0020AF039CA3},1073807360
Control23=IDC_STATIC,button,1342177287
Control24=IDC_WAVESTATUS,edit,1350568065
Control25=IDC_STATIC,button,1342177287
Control26=IDC_HOOKSTATUS,edit,1350568065
Control27=IDC_TIMER,edit,1350568065

[CLS:Training]
Type=0
HeaderFile=Training.h
ImplementationFile=Training.cpp
BaseClass=CDialog
Filter=D
LastObject=Training
VirtualFilter=dWC

[DLG:IDD_TESTING (Neutral)]
Type=1
Class=Testing
ControlCount=13
Control1=IDC_RECOGNITION,button,1342242817
Control2=IDBACK,button,1342242816
Control3=IDC_USER,edit,1350568064
Control4=IDC_STATIC,static,1342177294
Control5=IDC_TESTSTATUS,edit,1350633601
Control6=IDC_MMC,{C1A8AF25-1257-101B-8FB0-0020AF039CA3},1073741824
Control7=IDC_STATIC,static,1342177294
Control8=IDC_STATIC,button,1342177287
Control9=IDC_STATIC,static,1342308352
Control10=IDC_PROGRESSX,msctls_progress32,1350565889
Control11=IDC_LOAD,edit,1082196098
Control12=IDC_LOADED,button,1073807360
Control13=IDC_OPEN,button,1073807360

[CLS:Testing]
Type=0
HeaderFile=Testing.h
ImplementationFile=Testing.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=ID_APP_ABOUT

[MNU:IDR_V2C (Neutral)]
Type=1
Class=CLogin
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[ACL:IDR_V2C (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_COPY
Command2=ID_EDIT_PASTE
Command3=ID_EDIT_CUT
Command4=ID_EDIT_COPY
Command5=ID_EDIT_PASTE
Command6=ID_EDIT_CUT
Command7=ID_EDIT_UNDO
CommandCount=7

[DLG:IDD_DOITDIALOG_DIALOG]
Type=1
Class=DoitDialog
ControlCount=7
Control1=IDCANCEL,button,1342242817
Control2=IDOK,button,1073741824
Control3=IDC_STATIC,button,1342177287
Control4=IDC_COMMAND,edit,1350566017
Control5=IDC_TIMER,edit,1350568065
Control6=IDC_STATIC,static,1342308352
Control7=IDC_STATIC,static,1342308352

[CLS:DoitDialog]
Type=0
HeaderFile=DoitDialog.h
ImplementationFile=DoitDialog.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=DoitDialog

