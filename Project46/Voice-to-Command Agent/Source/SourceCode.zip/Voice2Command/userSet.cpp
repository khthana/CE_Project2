// userSet.cpp : implementation file
//

#include "stdafx.h"
#include "Voice2Command.h"
#include "userSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CuserSet

IMPLEMENT_DYNAMIC(CuserSet, CRecordset)

CuserSet::CuserSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CuserSet)
	m_id = 0;
	m_username = _T("");
	m_password = _T("");
	m_codebook = _T("");
	m_maxwave = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CuserSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=VoiceProject");
}

CString CuserSet::GetDefaultSQL()
{
	return _T("[USERS]");
}

void CuserSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CuserSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Text(pFX, _T("[username]"), m_username);
	RFX_Text(pFX, _T("[password]"), m_password);
	RFX_Text(pFX, _T("[codebook]"), m_codebook);
	RFX_Long(pFX, _T("[maxwave]"), m_maxwave);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CuserSet diagnostics

#ifdef _DEBUG
void CuserSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CuserSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
