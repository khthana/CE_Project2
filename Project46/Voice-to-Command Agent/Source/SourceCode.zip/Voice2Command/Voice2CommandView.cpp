// Voice2CommandView.cpp : implementation of the CVoice2CommandView class
//

#include "stdafx.h"
#include "Voice2Command.h"

#include "Voice2CommandSet.h"
#include "Voice2CommandDoc.h"
#include "Voice2CommandView.h"

#include "Login.h"
#include "Testing.h"

#include "WAVE.h"

#include "RECOGNITION.H"
#include "matrix.h"

#ifndef _NO_NAMESPACE
using namespace math;
#endif
#ifndef _NO_TEMPLATE
typedef matrix<double> Matrix;
#else
typedef matrix Matrix;
#endif



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandView

IMPLEMENT_DYNCREATE(CVoice2CommandView, CRecordView)

BEGIN_MESSAGE_MAP(CVoice2CommandView, CRecordView)
	//{{AFX_MSG_MAP(CVoice2CommandView)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_BN_CLICKED(IDC_TRAINALL, OnTrainall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandView construction/destruction

CVoice2CommandView::CVoice2CommandView()
	: CRecordView(CVoice2CommandView::IDD)
{
	//{{AFX_DATA_INIT(CVoice2CommandView)
	m_pSet = NULL;
	m_puserSet = NULL;
	m_Username = _T("");
	m_Status = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	m_id_user = 0;
	Trained = TRUE;
}

CVoice2CommandView::~CVoice2CommandView()
{
	Rows = 0;
	m_pSet->Close();
	m_puserSet->Close();
}

void CVoice2CommandView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVoice2CommandView)
	DDX_Control(pDX, IDC_PROGRESS, m_Progess);
	DDX_Control(pDX, IDC_MSFLEXGRID1, m_Table);
	DDX_Text(pDX, IDC_USER, m_Username);
	DDX_Text(pDX, IDC_STATUS, m_Status);
	//}}AFX_DATA_MAP
}

BOOL CVoice2CommandView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CVoice2CommandView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_voice2CommandSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	RowColor = 1;
	Rows = 0;
	//show_Command();

	m_puserSet = &m_userSet;
	m_puserSet->Open(AFX_DB_USE_DEFAULT_TYPE,m_userSet.GetDefaultSQL());
	m_puserSet->MoveFirst();

	HWND MyWinHD = GetSafeHwnd();
	::ShowWindow(MyWinHD,SW_HIDE);

	CLogin loginDialog;
	int result = loginDialog.DoModal();	
	if (result == IDOK)
	{
		m_id_user = loginDialog.m_id;
		
		CString tmp_id ;
		tmp_id.Format("[id] = %d",m_id_user);
		m_pSet->m_strFilter = tmp_id;
		m_pSet->m_strSort = "[no] ASC,[id] ASC";
		m_pSet->Requery();

		m_puserSet->m_strFilter = tmp_id;
		m_puserSet->Requery();
		m_Username = m_puserSet->m_username;
		UpdateData(FALSE);

		// if record set < 1 is not work !? how to fixed it ?
		
		if (!loginDialog.m_TrainMode)
		{	
			if (m_pSet->IsEOF())
			{	
				MessageBox("You have no command.\nPlease add your command before testing.",
					"Recommend !?",MB_OK);
			} else {
				OnTest();	// call Testing Mode
			}
		}
		RowColor = 1;
		show_Command();
		::ShowWindow(MyWinHD,SW_SHOW);

	} else {
		::PostQuitMessage(0);
	}
	m_Username = m_puserSet->m_username;
	UpdateData(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandView diagnostics

#ifdef _DEBUG
void CVoice2CommandView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CVoice2CommandView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CVoice2CommandDoc* CVoice2CommandView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVoice2CommandDoc)));
	return (CVoice2CommandDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandView database support
CRecordset* CVoice2CommandView::OnGetRecordset()
{
	return m_pSet;
}

BEGIN_EVENTSINK_MAP(CVoice2CommandView, CRecordView)
    //{{AFX_EVENTSINK_MAP(CVoice2CommandView)
	ON_EVENT(CVoice2CommandView, IDC_MSFLEXGRID1, -600 /* Click */, OnClickMsflexgrid1, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandView message handlers

void CVoice2CommandView::show_Command()
{
	COLORREF myColor = RGB(255,255,80);

	m_Table.SetRows(1);
	m_Table.SetCols(1);

	m_Table.SetRows(11);
	m_Table.SetCols(3);
	m_Table.SetColWidth(0,1000);
	m_Table.SetColWidth(1,2000);
	m_Table.SetColWidth(2,3800);
	m_Table.SetFixedRows(1);
	m_Table.SetFixedCols(0);
	m_Table.SetRow(0);
	m_Table.SetCol(0);	m_Table.SetText("�ӴѺ");				// Id
	m_Table.SetCol(1);	m_Table.SetText("�����");				// Word
	m_Table.SetCol(2);	m_Table.SetText("��͸Ժ���������");	// Description
	
	m_Table.SetRow(0);
	
//	int YCount = m_pSet->GetRecordCount();
//	CString Yy;
//	Yy.Format("%d",YCount);
//	MessageBox(Yy,"GetCount",MB_OK);

	int m_Count = 0;
	if (m_pSet->GetRecordCount() != 0)
	{
		m_pSet->MoveFirst();
		CString tmp;		
		while(! m_pSet->IsEOF())
		{
			m_Table.SetRow(++m_Count);

			tmp.Format("%d",m_Count);
			m_Table.SetCol(0);	m_Table.SetText(tmp);
			m_Table.SetCellAlignment(0);
			if (m_Count == RowColor) {	m_Table.SetCellBackColor(myColor);}

			m_Table.SetCol(1);	m_Table.SetText(m_pSet->m_word);
			m_Table.SetCellAlignment(0);
			if (m_Count == RowColor) {	m_Table.SetCellBackColor(myColor);}

			m_Table.SetCol(2);	m_Table.SetText(m_pSet->m_description);
			m_Table.SetCellAlignment(0);
			if (m_Count == RowColor) {	m_Table.SetCellBackColor(myColor);}

			m_pSet->MoveNext();
		}
	}
	Rows = m_Count;
}


void CVoice2CommandView::Setm_pSet2RowColor()
{
	m_pSet->MoveFirst();
	for (int i=1;i<RowColor;i++)	m_pSet->MoveNext();
}

void CVoice2CommandView::OnAdd() 
{
	int MaxNo = 0;
	if (m_pSet->GetRecordCount() != 0)
	{
		m_pSet->Requery();
		m_pSet->MoveFirst();
		while(!m_pSet->IsEOF())
		{
			if (m_pSet->m_no > MaxNo) {	MaxNo = m_pSet->m_no;	}
			m_pSet->MoveNext();
		}
	}
	MaxNo++;
	
	if (Rows < 10)
	{
		trainDialog.InitialTrain(m_Username,MaxNo,"","");				// MaxNo is next [no]

		int respond = trainDialog.DoModal();
		if (respond == IDOK)
		{
			m_pSet->AddNew();
				m_pSet->m_id			= m_id_user;
				m_pSet->m_no			= trainDialog.m_No;
				m_pSet->m_word			= trainDialog.m_Word;			// "Laugh";
				m_pSet->m_description	= trainDialog.m_Description;	// "555";
				m_pSet->m_filename		= trainDialog.m_Hookfile;		// m_Username+"_"+Next_No+".bin";
				m_pSet->m_wavefile		= trainDialog.m_Wavefile;		// m_Username+"_"+Next_No+".wav";;

			m_pSet->Update();
			m_pSet->m_strSort = "[no] ASC,[id] ASC";
			RowColor = 1;
			m_pSet->Requery();
			show_Command();
		}
		m_Status = "Adding new voice command.";
		UpdateData(FALSE);
	} 
	else
	{
		MessageBox("You have full commands.","ERROR",MB_OK);
	}
	Trained = FALSE;
}

void CVoice2CommandView::OnEdit()
{
	if (Rows > 0)
	{
		Setm_pSet2RowColor();
		trainDialog.InitialTrain(m_Username,m_pSet->m_no,m_pSet->m_word,m_pSet->m_description);
		trainDialog.DoModal();

		// m_id,m_no,m_filename,m_codebook,m_wavefile is the same;

		m_pSet->Edit();
		m_pSet->m_word				= trainDialog.m_Word;
		m_pSet->m_description		= trainDialog.m_Description;
		m_pSet->Update();
		m_pSet->m_strSort = "[no] ASC,[id] ASC";
		m_pSet->Requery();
		m_Status = "Edit your voice command.";
		UpdateData(FALSE);
		show_Command();
		
	} else {
		MessageBox("You haven't any command.","ERROR",MB_OK);
	}
	Trained = FALSE;
}

void CVoice2CommandView::OnRemove() 
{
	if (Rows > 0)
	{
		int respond = MessageBox("�س��ͧ���ź����觹��","Confirm for Delete ?",MB_YESNO);
		if (respond == IDYES)
		{
			m_pSet->MoveFirst();
			for (int i=1;i<RowColor;i++) {	m_pSet->MoveNext();	}

// ************************************************************************			
			// Remove file before
			CString x;
			x.Format("%d",m_pSet->m_no);

			CString m_codebook,m_wave;
			m_codebook	= m_puserSet->m_codebook;
			m_wave		= m_pSet->m_wavefile;		

			//AfxMessageBox(m_codebook);
			//AfxMessageBox(m_wave);

			remove(m_codebook);		//Remove() code book file;
			remove(m_wave);			//Remove() wave file;
			remove(m_pSet->m_filename);
		
// ************************************************************************

			m_pSet->Delete();	//	SQL for delete this row
			RowColor = 1;
			m_pSet->m_strSort = "[no] ASC,[id] ASC";
			m_pSet->Requery();
			m_Status = "Removed your voice command.";
			UpdateData(FALSE);
			show_Command();
			Trained = FALSE;
			//MessageBox("Deleted complete...\nYou should training system again.","Clear Command",MB_OK);
		}
	} 
	else {
		MessageBox("You haven't any command.","ERROR",MB_OK);
	}

}

void CVoice2CommandView::OnClickMsflexgrid1() 
{
	if (m_Table.GetRow() <= Rows)	
			{	RowColor = m_Table.GetRow();	} 
	else 	{	RowColor = 1;	}
	show_Command();
}

void CVoice2CommandView::OnTrainall() 
{
	m_Status = "Training System, please wait a minutes...";
	UpdateData(FALSE);

	m_Progess.SetRange(0,10);
	m_Progess.SetStep(1);
	m_Progess.SetPos(0);
	/*
	CString debug2;
	debug2.Format("%d",Rows);
	MessageBox(debug2,"Rows",MB_OK);
	*/
	if (Rows > 0)
	{
		m_Progess.StepIt();			// Step # 1
		
		// Find Maximum length of all wave;

		long		MaxLengthWave = 0;
		CString		NameofWave = "";
		WaveFile	myWave;

		m_pSet->m_strSort = "[no] ASC,[id] ASC";
		m_pSet->Requery();
		m_pSet->MoveFirst();
		
		bool AreAllWaveCompleted = TRUE;
		for (int p=0;p<Rows;p++)
		{	
			NameofWave = m_pSet->m_wavefile;
			bool Res = myWave.OpenRead(NameofWave);
			AreAllWaveCompleted = AreAllWaveCompleted && Res;

			/*
			CString debug;
			debug.Format("%s :: %d",m_pSet->m_wavefile,myWave.GetNumSamples());
			MessageBox(debug,Wave,MB_OK);

			*/
			if (MaxLengthWave < myWave.GetNumSamples())
			{
				MaxLengthWave = myWave.GetNumSamples();
			}

			myWave.Close();
			m_pSet->MoveNext();
		}

		if (!AreAllWaveCompleted)
		{
			MessageBox("Some voices not completely...\nYour trainning might not right !","Warnning",MB_OK);
		}
		else	//if All wave completely
		{
			m_Progess.StepIt();			// Step # 2
			m_Progess.StepIt();			// Step # 3

			/*
			CString debug3;
			debug3.Format("%d",MaxLengthWave);
			MessageBox(debug3,"Maximum Length is :",MB_OK);
			*/

			//MessageBox("Go Go Go.","Start process...",MB_OK);
			// Initialize Matrix
			Matrix matrix_AllWave(MaxLengthWave,Rows);

			m_pSet->MoveFirst();
			for (int c=0;c<Rows;c++)	// Rows = Commands
			{	
				NameofWave = m_pSet->m_wavefile;
				myWave.OpenRead(NameofWave);
				double m_sample;
				double zero = 0.0001;

				//for (size_t s=0; s<MaxLengthWave; s++)
				for (int s=0; s<MaxLengthWave; s++)
				{
					if (s<myWave.GetNumSamples())
					{
						myWave.ReadSample(m_sample);
						matrix_AllWave(s,c) = m_sample;
					}
					else 
					{
						matrix_AllWave(s,c) = zero;
					}
				}			
				myWave.Close();
				m_pSet->MoveNext();
			}

			m_Progess.StepIt();			// Step # 4
			m_Progess.StepIt();			// Step # 5

			// Complete Here
			// parameters id (matrix_AllWave,MaxLengthWave,Rows)
			
			//MessageBox("Yeah Yeah.","Step process...",MB_OK);

//////////////////////////// Ugly debug so slowly /////////////////////////////////////
/*
			CFile f3;
			CFileException e;
			f3.Open("C:\\DatainAllWave.txt",CFile::modeWrite|CFile::modeCreate,&e);
			
			CString tmpD = "",EndL = "\n";
			for (int ii=0; ii<MaxLengthWave; ii++)
			{
				for (int jj=0; jj<Rows; jj++)
				{
					tmpD.Format("%1.6f\t",matrix_AllWave(ii,jj));	
					f3.Write(tmpD,tmpD.GetLength());
					//f3.Write("1 ",2);
				}
				f3.Write(EndL,EndL.GetLength());
			}
			f3.Close();
			//MessageBox("Commit to disk.","Step process...",MB_OK);
*/
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	//
	//		ReCognition module generate CodeBook
	//
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

			RECOGNITION RecognitionModule;

			Matrix matrix_CodeBook(39,16*Rows);
			matrix_CodeBook = RecognitionModule.TRAINING(matrix_AllWave,MaxLengthWave,Rows);

			m_Progess.StepIt();			// Step # 6
			m_Progess.StepIt();			// Step # 7
			m_Progess.StepIt();			// Step # 8
			
			//MessageBox("Generate CodeBook complete...","Finish process...",MB_OK);

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	//
	//		Save CodeBook matrix to disk.
	//
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	
			CString CodebookFilename = "Codebook\\"+m_Username+".cbk";
			remove(CodebookFilename);
			CStdioFile myfile(CodebookFilename,CFile::modeCreate|CFile::modeWrite);
			CString m_each = "";
			CString m_line = "";
			for (int a=0;a<Rows;a++)
			{
				for(int b=0;b<39;b++)
				{
					m_line = "";
					for(int c=0;c<16;c++)
					{
						m_each.Format("%1.8f\t",matrix_CodeBook(b,c+(16*a)));
						m_line += m_each;
					}
					m_line += "\n";
					myfile.WriteString(m_line);
				}
			}
			myfile.Close();
			m_Progess.StepIt();			// Step # 9

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	//
	//		Save filename of codebook to database.
	//
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			m_puserSet->Edit();
			m_puserSet->m_codebook = CodebookFilename;
			m_puserSet->m_maxwave  = MaxLengthWave;
			m_puserSet->Update();
			m_puserSet->Requery();

			Trained = TRUE;

			m_Progess.StepIt();			// Step # 10
			m_Status = "Training system completed.";
			UpdateData(FALSE);

			MessageBox("Training system completed.","Training system",MB_OK);
		} 
	}
	else
	{
		MessageBox("You haven't a voice command.","ERROR",MB_OK);
		m_Status = "Training system not complete...";
		UpdateData(FALSE);
	}
}

/////////////////// How to Open Testing Mode ////////////////
void CVoice2CommandView::OnTest() 
{
	if (GetCommands() > 0)
	{
		if (Reload_CodeBook())
		{
			if (Trained)
			{
				testDialog.setUser(m_Username,m_id_user,m_puserSet->m_maxwave);
				testDialog.DoModal();
			} 
			else
			{
				MessageBox("You haven't update training system...","ERROR",MB_OK); // Not found file
			}
		} else { MessageBox("You haven't training system...","ERROR",MB_OK); } // Not update
	}
	else {
		MessageBox("You haven't any command.","ERROR !?",MB_OK);
	}
}

BOOL CVoice2CommandView::Reload_CodeBook()
{
	CFile f2;
	CFileException e;
	CString m_Codefile = m_puserSet->m_codebook;

	int CanOpen = f2.Open(m_Codefile,CFile::modeRead,&e);
	if (CanOpen > 0){
		return TRUE;	
	} 
	else {
		return FALSE;
	}
}

int CVoice2CommandView::GetCommands()
{
	//m_id_user = loginDialog.m_id;
		
	CString tmp_id;
	tmp_id.Format("[id] = %d",m_id_user);
//	MessageBox(tmp_id,"I.D.",MB_OK);

	m_pSet->m_strFilter = tmp_id;
	m_pSet->Requery();

	m_puserSet->m_strFilter = tmp_id;
	m_puserSet->Requery();
	m_Username = m_puserSet->m_username;
	
	int m_Count = 0;
	if (m_pSet->GetRecordCount() != 0)
	{
		m_pSet->MoveFirst();		
		while(! m_pSet->IsEOF())
		{
			++m_Count;
			m_pSet->MoveNext();
		}
	}
/*
	CString x;
	x.Format("%d",m_Count);
	MessageBox(x,"Count",MB_OK);
*/
	return m_Count;
}

/*
void CVoice2CommandView::OnFileLogin() 
{
	CLogin loginDialog;
	int result = loginDialog.DoModal();	
	if (result == IDOK)
	{
		m_id_user = loginDialog.m_id;
		
		CString tmp_id ;
		tmp_id.Format("[id] = %d",m_id_user);
		MessageBox(tmp_id,"Name",MB_OK);
		m_pSet->m_strFilter = tmp_id;
		m_pSet->m_strSort = "[no] ASC,[id] ASC";
		m_pSet->Requery();

		m_puserSet->m_strFilter = tmp_id;
		m_puserSet->Requery();
		
		m_Username = m_puserSet->m_username;
		MessageBox(m_Username,"Name",MB_OK);
		UpdateData(FALSE);

		// if record set < 1 is not work !? how to fixed it ?
		
		if (!loginDialog.m_TrainMode)
		{	
			if (m_pSet->IsEOF())
			{	
				MessageBox("You have no command.\nPlease add your command before testing.",
					"Recommend !?",MB_OK);
			} else {
				OnTest();	// call Testing Mode
			}
		}
		RowColor = 1;
		show_Command();
		m_Username = m_puserSet->m_username;
		UpdateData(FALSE);
	}
}
*/