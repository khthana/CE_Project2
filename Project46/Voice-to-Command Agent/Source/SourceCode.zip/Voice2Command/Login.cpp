// Login.cpp : implementation file
//

#include "stdafx.h"
#include "Voice2Command.h"
#include "Login.h"

#include "md5class.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "userSet.h"

/////////////////////////////////////////////////////////////////////////////
// CLogin dialog


CLogin::CLogin(CWnd* pParent /*=NULL*/)	: CDialog(CLogin::IDD, pParent)
{	
	//{{AFX_DATA_INIT(CLogin)
	m_User = _T("");
	m_Pass = _T("");
	m_NewUser = FALSE;
	//}}AFX_DATA_INIT
	m_id = 0;
	m_CheckPermission = FALSE;
}

void CLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogin)
	DDX_Text(pDX, IDC_USERNAME, m_User);
	DDX_Text(pDX, IDC_PASSWD, m_Pass);
	DDX_Check(pDX, IDC_NEWUSER, m_NewUser);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLogin, CDialog)
	//{{AFX_MSG_MAP(CLogin)
	ON_BN_CLICKED(ID_RESET, OnReset)
	ON_BN_CLICKED(IDCHECK, OnCheck)
	ON_WM_CLOSE()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogin message handlers

void CLogin::OnReset() 
{
	m_User = "";
	m_Pass = "";
	m_CheckPermission = FALSE;
	UpdateData(FALSE);
}

void CLogin::OnCheck() 
{
	CuserSet * m_puserSet;
	CuserSet m_userSet;
	m_puserSet = &m_userSet;
	m_puserSet->Open(AFX_DB_USE_DEFAULT_TYPE,m_userSet.GetDefaultSQL());
	m_puserSet->MoveFirst();
	UpdateData(TRUE);

	if (m_NewUser ==TRUE)
	{
		bool SameName = FALSE;
		int  NewID	  = 0;
		while (!m_puserSet->IsEOF())
		{
			if (NewID < m_puserSet->m_id)	{	NewID = m_puserSet->m_id;	}
			if (m_User == m_puserSet->m_username )	{	SameName = TRUE;	}
			m_puserSet->MoveNext();
		}
		NewID++;
		
		if (SameName)
		{
			MessageBox("Exist username.","ERROR",MB_OK);
		}
		else
		{
			if (m_Pass != "")
			{
				m_puserSet->AddNew();
/*
					CString x;
					x.Format("%d",NewID);
					MessageBox(x,"NewID",MB_OK);
*/
				m_id				   = NewID;	
				m_puserSet->m_id	   = NewID;
				m_puserSet->m_username = m_User;

				CMD5 md5;
				md5.setPlainText(m_Pass);
				//MessageBox(md5.getMD5Digest(),NULL,MB_OK);
				//m_User = md5.getMD5Digest();
				//UpdateData(FALSE);
			
				m_puserSet->m_password = md5.getMD5Digest(); //m_Pass;
				m_puserSet->Update();
				m_puserSet->Requery();
				
				m_TrainMode = TRUE; // Force to training mode

				CDialog::OnOK();

			}
			else
			{
				MessageBox("You haven't password.","ERROR",MB_OK);
			}
		}
	}
	else
	{
		CMD5 md5;
		
		while (!m_puserSet->IsEOF())
		{
			md5.setPlainText(m_Pass);

			if ((m_User==m_puserSet->m_username)&&(md5.getMD5Digest()==m_puserSet->m_password))
			{
				m_CheckPermission = TRUE;
				m_id = m_puserSet->m_id;
			}
			m_puserSet->MoveNext();
		}

		if (m_CheckPermission)
		{
			CButton *train;
			train = (CButton*) GetDlgItem(IDC_TRAINMODE);
			
			if ((train->GetCheck())==1)
			{
				m_TrainMode = TRUE;
			} 
			else {
				m_TrainMode = FALSE;
			}
			CDialog::OnOK();
		} else {
			MessageBox("Wrong password","Login result",MB_OK);
			m_Pass = "";
			m_CheckPermission = FALSE;
			UpdateData(FALSE);
		}
	}
}


void CLogin::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	int q = MessageBox("Are you sure to exit program ?","Login question !",MB_YESNO);
	if (q == IDYES)
	{
		CDialog::OnClose();
		//DestroyWindow();
		::PostQuitMessage(0);		
	}
}

void CLogin::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	m_TrainMode = TRUE;
	if (m_TrainMode)
	{
		CButton *train, *test;
		train = (CButton*) GetDlgItem(IDC_TRAINMODE);
		train->SetCheck(TRUE);
		test  = (CButton*) GetDlgItem(IDC_TESTMODE);
		test->SetCheck(FALSE);
	}	
}