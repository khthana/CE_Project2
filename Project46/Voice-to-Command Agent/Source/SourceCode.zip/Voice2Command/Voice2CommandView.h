// Voice2CommandView.h : interface of the CVoice2CommandView class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES

#if !defined(AFX_VOICE2COMMANDVIEW_H__EFF0932D_A74C_4978_8584_D3E16413C3D4__INCLUDED_)
#define AFX_VOICE2COMMANDVIEW_H__EFF0932D_A74C_4978_8584_D3E16413C3D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "userSet.h"
#include "Testing.h"
#include "Training.h"

class CVoice2CommandSet;

class CVoice2CommandView : public CRecordView
{
protected: // create from serialization only
	CVoice2CommandView();
	DECLARE_DYNCREATE(CVoice2CommandView)

public:
	//{{AFX_DATA(CVoice2CommandView)
	enum { IDD = IDD_VOICE2COMMAND_FORM };
	CProgressCtrl	m_Progess;
	CMSFlexGrid	m_Table;
	CVoice2CommandSet *	m_pSet;
	CuserSet		  *	m_puserSet;
	CString				m_Username;
	CString	m_Status;
	//}}AFX_DATA

// Attributes
public:
	CVoice2CommandDoc* GetDocument();
	CuserSet m_userSet;

	int		m_id_user;
	int		RowColor;
	int		Rows;
	BOOL	Trained;

	Testing  testDialog;
	Training trainDialog;

// Operations
public:
	void Setm_pSet2RowColor();
	void show_Command();
	BOOL Reload_CodeBook();
	int  GetCommands();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoice2CommandView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVoice2CommandView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CVoice2CommandView)
	afx_msg void OnAdd();
	afx_msg void OnEdit();
	afx_msg void OnRemove();
	afx_msg void OnClickMsflexgrid1();
	afx_msg void OnTest();
	afx_msg void OnTrainall();
	afx_msg void OnFileLogin();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Voice2CommandView.cpp
inline CVoice2CommandDoc* CVoice2CommandView::GetDocument()
   { return (CVoice2CommandDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOICE2COMMANDVIEW_H__EFF0932D_A74C_4978_8584_D3E16413C3D4__INCLUDED_)
