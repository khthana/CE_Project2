// Voice2CommandDoc.cpp : implementation of the CVoice2CommandDoc class
//

#include "stdafx.h"
#include "Voice2Command.h"

#include "Voice2CommandSet.h"
#include "Voice2CommandDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandDoc

IMPLEMENT_DYNCREATE(CVoice2CommandDoc, CDocument)

BEGIN_MESSAGE_MAP(CVoice2CommandDoc, CDocument)
	//{{AFX_MSG_MAP(CVoice2CommandDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandDoc construction/destruction

CVoice2CommandDoc::CVoice2CommandDoc()
{
	// TODO: add one-time construction code here

}

CVoice2CommandDoc::~CVoice2CommandDoc()
{
}

BOOL CVoice2CommandDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandDoc serialization

void CVoice2CommandDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandDoc diagnostics

#ifdef _DEBUG
void CVoice2CommandDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVoice2CommandDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandDoc commands
