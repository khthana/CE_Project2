#if !defined(AFX_USERSET_H__0A579109_A3B5_4CD5_856A_806B0C763A14__INCLUDED_)
#define AFX_USERSET_H__0A579109_A3B5_4CD5_856A_806B0C763A14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// userSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CuserSet recordset

class CuserSet : public CRecordset
{
public:
	CuserSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CuserSet)

// Field/Param Data
	//{{AFX_FIELD(CuserSet, CRecordset)
	long	m_id;
	CString	m_username;
	CString	m_password;
	CString m_codebook;
	long	m_maxwave;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CuserSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERSET_H__0A579109_A3B5_4CD5_856A_806B0C763A14__INCLUDED_)
