//{{AFX_INCLUDES()
#include "mci.h"
//}}AFX_INCLUDES
#if !defined(AFX_TRAINING_H__3974B7A4_E1E3_4A27_94F1_75557927428E__INCLUDED_)
#define AFX_TRAINING_H__3974B7A4_E1E3_4A27_94F1_75557927428E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Training.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Training dialog

class Training : public CDialog
{
// Construction
public:
	Training(CWnd* pParent = NULL);   // standard constructor
	void InitialTrain(CString user,int no,CString word,CString descript);
	BOOL CheckTmpVoice();
	BOOL CheckOldVoice();
	BOOL CheckTmpHook();
	BOOL CheckOldHook();

// Dialog Data
	//{{AFX_DATA(Training)
	enum { IDD = IDD_TRAINING };
	CEdit	m_HookStatus;
	CEdit	m_WaveStatus;
	CButton	c_PlayHook;
	CButton	c_RecordHook;
	CButton	c_ClearHook;
	CButton	c_ResetWav;
	CButton	c_PlayWav;
	CButton	c_RecordWav;
	int		m_No;
	CString	m_Username;
	CString	m_Word;
	CString	m_Description;
	CString m_Wavefile;
	CString m_Wavetmpfile;
	CString m_WaveOGRfile;
	CString m_Hookfile;
	BOOL WaveRecording;
	BOOL HookRecording;
	//BOOL m_WaveComplete;
	//BOOL m_HookComplete;
	Cmci	m_MCI;
	CString	m_Time;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Training)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void StartTimer();
	bool TimerRunning;
	void ShowTime();

	// Generated message map functions
	//{{AFX_MSG(Training)
	afx_msg void OnComplete();
	afx_msg void OnWPlay();
	afx_msg void OnWRecord();
	afx_msg void OnWReset();
	afx_msg void OnHRecord();
	afx_msg void OnHClear();
	afx_msg void OnHReplay();
	virtual void OnCancel();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnChangeWord();
	afx_msg void OnChangeDescription();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAINING_H__3974B7A4_E1E3_4A27_94F1_75557927428E__INCLUDED_)
