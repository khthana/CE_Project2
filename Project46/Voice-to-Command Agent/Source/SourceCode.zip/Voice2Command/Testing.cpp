// Testing.cpp : implementation file
//

#include "stdafx.h"
#include "Voice2Command.h"
#include "Testing.h"

#include "WAVE.h"

#include "string"
using std::string;

#include "RECOGNITION.H"
#include "matrix.h"

#ifndef _NO_NAMESPACE
using namespace math;
#endif
#ifndef _NO_TEMPLATE
typedef matrix<double> Matrix;
#else
typedef matrix Matrix;
#endif

#include "DoitDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Testing dialog


Testing::Testing(CWnd* pParent /*=NULL*/)
	: CDialog(Testing::IDD, pParent)
{
	//{{AFX_DATA_INIT(Testing)
	m_User = _T("");
	m_pSet = NULL;
	m_TestStatus = _T("");
	m_TempWave		= "Wave\\TempWave.wav";
	m_WaveOGRfile	= "Wave\\Original.wav";
	m_Recording = FALSE;
	m_Filename = _T("");
	//}}AFX_DATA_INIT
}


void Testing::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Testing)
	DDX_Control(pDX, IDC_PROGRESSX, m_Progess);
	DDX_Control(pDX, IDC_RECOGNITION, m_Recog);
	DDX_Text(pDX, IDC_USER, m_User);
	DDX_Control(pDX, IDC_MMC, m_MCI2);
	DDX_Text(pDX, IDC_TESTSTATUS, m_TestStatus);
	DDX_Text(pDX, IDC_LOAD, m_Filename);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Testing, CDialog)
	//{{AFX_MSG_MAP(Testing)
	ON_BN_CLICKED(IDC_RECOGNITION, OnRecognition)
	ON_BN_CLICKED(IDBACK, OnBack)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_LOADED, OnLoaded)
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Testing message handlers

void Testing::setUser(CString user,int ID,long MaxWave)
{
	m_User = user;
	m_pSet = &m_Set;
	m_pSet->Open(AFX_DB_USE_DEFAULT_TYPE,m_Set.GetDefaultSQL());
	m_pSet->MoveFirst();

		m_Id   = ID;
		CString ID_tmp;
		ID_tmp.Format("[id] = %d",m_Id);

	m_pSet->m_strFilter = ID_tmp;
	m_pSet->Requery();				//	Reloaded();

	MaxLengthWave = MaxWave;
	TimerRunning = FALSE;
}

extern HHOOK hhookHooks;

extern string HooksForPlay;

extern "C" {
	LRESULT CALLBACK JournalPlaybackFunc (int nCode,WPARAM wParam,LPARAM lParam);
}

void Testing::OnRecognition() 
{
	m_Progess.SetRange(0,10);
	m_Progess.SetStep(1);
	m_Progess.SetPos(0);

	if (!m_Recording)
	{
		m_MCI2.SetCommand("STOP");
		m_MCI2.SetCommand("CLOSE");
		m_MCI2.SetRecordMode(1);
		m_MCI2.SetRecordEnabled(TRUE);

		m_MCI2.SetFileName(m_WaveOGRfile);
		m_MCI2.SetCommand("OPEN");
		m_MCI2.SetCommand("Prev");
		m_MCI2.SetCommand("Record");

		m_Recog.SetWindowText("&Stop");	// F2 for stop ?
		m_Recording = TRUE;

		m_TestStatus = "Recording...";
		UpdateData(FALSE);

		StartTimer();
	}
	else {
		KillTimer(1);
		m_TestStatus = "Processing...";
		UpdateData(FALSE);
		m_Progess.StepIt();

		m_MCI2.SetCommand("STOP");
		m_MCI2.SetFileName(m_TempWave);
		m_MCI2.SetCommand("Save");

		m_Recog.SetWindowText("&Speak");
		m_Recording = FALSE;

		//////////// Finish recording voice command //////////////
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		//
		//					Initial System
		//
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			int NumberOfCommands = 0;
			
			CString myId;
			myId.Format("[id] = %d",m_Id);
			m_pSet->m_strFilter = myId;
			m_pSet->m_strSort = "[no] ASC,[id] ASC";
			m_pSet->Requery();
			m_pSet->MoveFirst();
			while (! m_pSet->IsEOF())
			{
				//CString HaHa;
				//HaHa.Format("%d %d %s",m_pSet->m_id,m_pSet->m_no,m_pSet->m_word);
				//MessageBox(HaHa,"Please count ?",MB_OK);
				NumberOfCommands++;
				m_pSet->MoveNext();
			}
			
			/*
			CString debugRows;
			debugRows.Format("%d",NumberOfCommands);
			MessageBox(debugRows,"Debug Rows",MB_OK);
			*/
			m_Progess.StepIt();
			
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		//
		//					Reload CodeBook
		//
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			m_TestStatus = "Reload CodeBook...";
			UpdateData(FALSE);

			Matrix matrix_CodeBook(39,16*NumberOfCommands);

			//CString CodebookFilename = "Codebook\\"+m_User+".cbk";
			CString CodebookFilename = "Codebook\\"+m_User+".cbk";			
			
			CStdioFile myfile(CodebookFilename,CFile::modeRead);
			CString myline = "";
			int i = 0 ,j = 0;
			int k = 0;        // Commander
			for (int Commands = 0; Commands < NumberOfCommands; Commands++)
			{
				i = 0;
				for (int lines=0; lines < 39; lines++)
				{
					j = 0;
					myfile.ReadString(myline);
					//MessageBox(myline,"All Line",MB_OK);
					for (int each=0; each < 16; each++)
					{
						/*
						double x = atof(myline);
						CString y;
						y.Format("%1.8f ",x);
						MessageBox(y,"each value",MB_OK);
						*/

						myline.TrimLeft();

						matrix_CodeBook(i,(j+k)) = atof(myline);// Convert fisrt value
						int m_Pos = myline.Find("\t",0);			// find a'st position of " "
						myline = myline.Mid(m_Pos);				// Clear first value in line
						j++;
						//MessageBox(myline,"diffed Line",MB_OK);
					}
					i++;
				}
				k += 16;
			}
			myfile.Close();

			m_Progess.StepIt();

			//save to disk
/*
			CStdioFile myfile2("C:\\TestLoadMatrix.txt",CFile::modeCreate|CFile::modeWrite);
			CString m_each = "";
			CString m_line = "";			
			for (int a=0;a<NumberOfCommands;a++)
			{
				for(int b=0;b<39;b++)
				{
					m_line = "";
					for(int c=0;c<16;c++)
					{
						m_each.Format("%1.8f\t",matrix_CodeBook(b,c+(a*16)));
						m_line += m_each;
					}
					m_line += "\n";
					myfile2.WriteString(m_line);
				}
			}
			myfile2.Close();
*/
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		//
		//					ReadWave to matrix wav test
		//
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

			CString		NameofWave = "";
			WaveFile	myWave;
			myWave.OpenRead(m_TempWave);
			long		GetLengthWave = myWave.GetNumSamples();
			
			/*
			//Debug
			CString tmpMaxWav;
			tmpMaxWav.Format("%d",MaxLengthWave);
			//MessageBox(tmpMaxWav,"DEBUG maxwave",MB_OK);			
			*/

			Matrix matrix_Wavtest(MaxLengthWave,1);
			
				double m_sample;

				//for (size_t s=0; s<MaxLengthWave; s++)  // Keep only 0..MaxLengthWave
				if (GetLengthWave <= MaxLengthWave)
				{
					for (int s=0; s<GetLengthWave; s++)
					{
						myWave.ReadSample(m_sample);
						matrix_Wavtest(s,0) = m_sample;
					}
					for (int ss=GetLengthWave ; ss<MaxLengthWave ; ss++)
					{
						matrix_Wavtest(ss,0) = 0.0001;
					}
				}
				else
				{
					for (int s=0; s<MaxLengthWave; s++)
					{
						myWave.ReadSample(m_sample);
						matrix_Wavtest(s,0) = m_sample;
					}
				}
			myWave.Close();
			m_Progess.StepIt();
			m_Progess.StepIt();

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		//
		//					Recognition Process
		//
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		RECOGNITION RecognitionModule;
		
		int Result = 0;
		Result = RecognitionModule.TESTING(matrix_CodeBook,matrix_Wavtest,NumberOfCommands);
		m_Progess.StepIt();
		m_Progess.StepIt();
		m_Progess.StepIt();	
		
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		//
		//					Playback Windows Hooks 
		//
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		// what command that system choose select ?
		
		CString myId2;
		myId2.Format("[id] = %d",m_Id);
		m_pSet->m_strFilter = myId2;
		m_pSet->m_strSort = "[no] ASC,[id] ASC";
		m_pSet->Requery();		
		m_pSet->MoveFirst();
		int Run = Result;
		while (Run > 0)			// Result is How many step to Windows Hooks.
		{
			m_pSet->MoveNext();
			Run--;
		}
		m_Progess.StepIt();
		m_Progess.StepIt();

		CString Result_no;
		Result_no.Format("(%d) %s",(Result+1),m_pSet->m_word);
		DoitDialog MSN;
		MSN.GetCommand(Result_no);
		int Res = MSN.DoModal();

		if (Res == IDOK)
		{
			m_TestStatus.Format("Playback %s operations.",m_pSet->m_word);
			UpdateData(FALSE);

			HooksForPlay = m_pSet->m_filename;
			UnhookWindowsHookEx(hhookHooks);
			hhookHooks = SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC) JournalPlaybackFunc,AfxGetInstanceHandle(),0);		
			//MessageBox(m_pSet->m_filename,"Process running windows hooks of...",MB_OK);
			//HooksForPlay = "Hook\\Windy_2.bin";
		}


/*
		CString Result_no;
		Result_no.Format("Running word (%d) %s ?",(Result+1),m_pSet->m_word);
		int Res = MessageBox(Result_no,"Recognition Result !",MB_YESNO);
		if (Res == IDYES)
		{
			m_TestStatus.Format("Playback %s operations.",m_pSet->m_word);
			UpdateData(FALSE);

			HooksForPlay = m_pSet->m_filename;
			UnhookWindowsHookEx(hhookHooks);
			hhookHooks = SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC) JournalPlaybackFunc,AfxGetInstanceHandle(),0);		
			//MessageBox(m_pSet->m_filename,"Process running windows hooks of...",MB_OK);
			//HooksForPlay = "Hook\\Windy_2.bin";
		}
*/
	}
}

void Testing::OnBack() 
{
	m_pSet->Close();
	CDialog::OnOK();
}


/*
 // Load Codebook File value to memory ....

void Testing::Reloaded()
{
	float ArrLoad[39][16];		// Array of code book
	// m_CodeBook is object of All Codebook;

	// Save Sound Record to file
	// Read data from wave file to Array

//	m_CodeBook.GetArray

		CString filename = "";
		int     no_tmp;
		CString no_str;


	m_pSet->MoveFirst();
	int Count = 0;

	while (!m_pSet->IsEOF())	// Each Command
	{
		no_tmp = m_pSet->m_no;
		no_str.Format("%d",no_tmp);
		filename = "Codebook\\"+m_User+".cbk";

		// Load file to Array

		CStdioFile myfile(filename,CFile::modeRead);
		CString buffer;

		while (!feof(myfile.m_pStream))
		{
			myfile.ReadString(buffer);
			int LineLength = buffer.GetLength();
			int P = 0;
			
			int i = 0,j = 0;
			CString x = "",value = "";

			while (P<LineLength)
			{
				x = buffer.GetAt(P);
				if (x == " ")
				{
					ArrLoad[i][j] = (float) atof(value);
					if (j<15) { j++; } else { j=0; i++; }	
					value = "";

				} else {
					value += x;
				}
				P++;
			}
		}
		m_CodeBook.SetArrays(ArrLoad,Count++);	// Load this ArrLoad to m_CodeBook
		m_pSet->MoveNext();
	}
}
*/

void Testing::OnTimer(UINT nIDEvent) 
{
	ShowTimer();
	CDialog::OnTimer(nIDEvent);
}

void Testing::ShowTimer()
{
	m_TestStatus.Format("%1.2f s.",m_MCI2.GetPosition()/1000.00);
	UpdateData(FALSE);
}

void Testing::OnDestroy() 
{
	CDialog::OnDestroy();	
	KillTimer(1);	
}

void Testing::StartTimer()
{
	if (TimerRunning)			// if have been set timer
	{
		KillTimer(1);			// Cancel set Timer
		TimerRunning = FALSE;	// It's Free
	}

	if (!TimerRunning)
	{
		SetTimer(1,10,NULL);
		TimerRunning = TRUE;
		m_MCI2.SetTimeFormat(0);
	}
}

void Testing::OnLoaded() 
{
	m_Progess.SetRange(0,10);
	m_Progess.SetStep(1);
	m_Progess.SetPos(0);

	UpdateData(TRUE);
	WaveFile	myWave;
	if (m_Filename != "")
	{
		if (myWave.OpenRead(m_Filename))
		{
			// m_Filename = UserInput;;;

			m_TestStatus = "Processing...";
			UpdateData(FALSE);

			m_Progess.StepIt();
			m_Recog.SetWindowText("&Speak");
			m_Recording = FALSE;

			//////////// Finish recording voice command //////////////
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			//
			//					Initial System
			//
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
				int NumberOfCommands = 0;
				
				CString myId;
				myId.Format("[id] = %d",m_Id);
				m_pSet->m_strFilter = myId;
				m_pSet->m_strSort = "[no] ASC,[id] ASC";
				m_pSet->Requery();
				m_pSet->MoveFirst();
				while (! m_pSet->IsEOF())
				{
					//CString HaHa;
					//HaHa.Format("%d %d %s",m_pSet->m_id,m_pSet->m_no,m_pSet->m_word);
					//MessageBox(HaHa,"Please count ?",MB_OK);
					NumberOfCommands++;
					m_pSet->MoveNext();
				}
				m_Progess.StepIt();
				
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			//
			//					Reload CodeBook
			//
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
				m_TestStatus = "Reload CodeBook...";
				UpdateData(FALSE);

				Matrix matrix_CodeBook(39,16*NumberOfCommands);

				CString CodebookFilename = "Codebook\\"+m_User+".cbk";
				//m_TestStatus = CodebookFilename;
				//UpdateData(FALSE);
				
				CStdioFile myfile(CodebookFilename,CFile::modeRead);
				CString myline = "";
				int i = 0 ,j = 0;
				int k = 0;        // Commander
				for (int Commands = 0; Commands < NumberOfCommands; Commands++)
				{
					i = 0;
					for (int lines=0; lines < 39; lines++)
					{
						j = 0;
						myfile.ReadString(myline);
						for (int each=0; each < 16; each++)
						{
							myline.TrimLeft();
							matrix_CodeBook(i,(j+k)) = atof(myline);// Convert fisrt value
							int m_Pos = myline.Find("\t",0);			// find a'st position of " "
							myline = myline.Mid(m_Pos);				// Clear first value in line
							j++;
						}
						i++;
					}
					k += 16;
				}
				myfile.Close();

				m_Progess.StepIt();
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			//
			//					ReadWave to matrix wav test
			//
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

				CString		NameofWave = "";
				//WaveFile	myWave;
				//myWave.OpenRead(m_TempWave);
				myWave.OpenRead(m_Filename);
				long		GetLengthWave = myWave.GetNumSamples();
				
				Matrix matrix_Wavtest(MaxLengthWave,1);
				
					double m_sample;
					if (GetLengthWave <= MaxLengthWave)
					{
						for (int s=0; s<GetLengthWave; s++)
						{
							myWave.ReadSample(m_sample);
							matrix_Wavtest(s,0) = m_sample;
						}
						for (int ss=GetLengthWave ; ss<MaxLengthWave ; ss++)
						{
							matrix_Wavtest(ss,0) = 0.0001;
						}
					}
					else
					{
						for (int s=0; s<MaxLengthWave; s++)
						{
							myWave.ReadSample(m_sample);
							matrix_Wavtest(s,0) = m_sample;
						}
					}
				myWave.Close();
				m_Progess.StepIt();
				m_Progess.StepIt();

			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			//
			//					Recognition Process
			//
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			RECOGNITION RecognitionModule;
			
			int Result = 0;
			Result = RecognitionModule.TESTING(matrix_CodeBook,matrix_Wavtest,NumberOfCommands);
			m_Progess.StepIt();
			m_Progess.StepIt();
			m_Progess.StepIt();	
			
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			//
			//					Playback Windows Hooks 
			//
			// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
			// what command that system choose select ?
			
			CString myId2;
			myId2.Format("[id] = %d",m_Id);
			m_pSet->m_strFilter = myId2;
			m_pSet->m_strSort = "[no] ASC,[id] ASC";
			m_pSet->Requery();		
			m_pSet->MoveFirst();
			int Run = Result;
			while (Run > 0)			// Result is How many step to Windows Hooks.
			{
				m_pSet->MoveNext();
				Run--;
			}
			m_Progess.StepIt();
			m_Progess.StepIt();

			CString Result_no;
			Result_no.Format("(%d) %s",(Result+1),m_pSet->m_word);
			DoitDialog MSN;
			MSN.GetCommand(Result_no);
			int Res = MSN.DoModal();

			if (Res == IDOK)
			{
				m_TestStatus.Format("Playback %s operations.",m_pSet->m_word);
				UpdateData(FALSE);

				HooksForPlay = m_pSet->m_filename;
				UnhookWindowsHookEx(hhookHooks);
				hhookHooks = SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC) JournalPlaybackFunc,AfxGetInstanceHandle(),0);		
			}
		} else { MessageBox("File cannot access. !? ",NULL,MB_OK);}
	}	
}

void Testing::OnOpen() 
{
	char filter[] = "Wave file (*.wav) | *.*||";
	CFileDialog fd(TRUE,NULL,NULL,NULL,filter);
	if (fd.DoModal()==IDOK)
	{
		m_Filename = fd.GetPathName();
		UpdateData(FALSE);
	}
}
