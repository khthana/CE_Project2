#if !defined(AFX_DOITDIALOG_H__762A0FD6_B5D6_4624_836B_8F03C143F573__INCLUDED_)
#define AFX_DOITDIALOG_H__762A0FD6_B5D6_4624_836B_8F03C143F573__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DoitDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// DoitDialog dialog

class DoitDialog : public CDialog
{
// Construction
public:
	DoitDialog(CWnd* pParent = NULL);   // standard constructor
	void GetCommand(CString Command);

// Dialog Data
	//{{AFX_DATA(DoitDialog)
	enum { IDD = IDD_DOITDIALOG_DIALOG };
	CString	m_Command;
	int		m_Timer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DoitDialog)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(DoitDialog)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(DoitDialog)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOITDIALOG_H__762A0FD6_B5D6_4624_836B_8F03C143F573__INCLUDED_)
