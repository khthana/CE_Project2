// DoitDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Voice2Command.h"
#include "DoitDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DoitDialog dialog


DoitDialog::DoitDialog(CWnd* pParent /*=NULL*/)
	: CDialog(DoitDialog::IDD, pParent)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(DoitDialog)
	m_Command = _T("");
	m_Timer = 4;
	//}}AFX_DATA_INIT
}


void DoitDialog::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void DoitDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DoitDialog)
	DDX_Text(pDX, IDC_COMMAND, m_Command);
	DDX_Text(pDX, IDC_TIMER, m_Timer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DoitDialog, CDialog)
	//{{AFX_MSG_MAP(DoitDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(DoitDialog, CDialog)
	//{{AFX_DISPATCH_MAP(DoitDialog)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IDoitDialog to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {0E8BA877-1F08-4A08-B091-7A57CF310433}
static const IID IID_IDoitDialog =
{ 0xe8ba877, 0x1f08, 0x4a08, { 0xb0, 0x91, 0x7a, 0x57, 0xcf, 0x31, 0x4, 0x33 } };

BEGIN_INTERFACE_MAP(DoitDialog, CDialog)
	INTERFACE_PART(DoitDialog, IID_IDoitDialog, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DoitDialog message handlers

void DoitDialog::GetCommand(CString Command)
{
	m_Command = Command;
}

void DoitDialog::OnOK() 
{
	// TODO: Add extra validation here
	KillTimer(1);
	CDialog::OnOK();
}

void DoitDialog::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillTimer(1);
	CDialog::OnCancel();
}

BOOL DoitDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	KillTimer(1);
	SetTimer(1,1000,NULL);
	m_Timer = 4;
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void DoitDialog::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	UpdateData(TRUE);
	m_Timer--;
	UpdateData(FALSE);
	if (m_Timer == 0)
	{
		KillTimer(1);
		CDialog::OnOK();
	}	
	CDialog::OnTimer(nIDEvent);
}
