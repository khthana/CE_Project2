// Voice2CommandDoc.h : interface of the CVoice2CommandDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOICE2COMMANDDOC_H__9C82141B_B487_4356_8E05_10AB3D247029__INCLUDED_)
#define AFX_VOICE2COMMANDDOC_H__9C82141B_B487_4356_8E05_10AB3D247029__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Voice2CommandSet.h"


class CVoice2CommandDoc : public CDocument
{
protected: // create from serialization only
	CVoice2CommandDoc();
	DECLARE_DYNCREATE(CVoice2CommandDoc)

// Attributes
public:
	CVoice2CommandSet m_voice2CommandSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVoice2CommandDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CVoice2CommandDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CVoice2CommandDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOICE2COMMANDDOC_H__9C82141B_B487_4356_8E05_10AB3D247029__INCLUDED_)
