# Microsoft Developer Studio Project File - Name="Voice2Command" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=Voice2Command - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "Voice2Command.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Voice2Command.mak" CFG="Voice2Command - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Voice2Command - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Voice2Command - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 winmm.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "Voice2Command - Win32 Release"
# Name "Voice2Command - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\DoitDialog.cpp
# End Source File
# Begin Source File

SOURCE=.\FFT.CPP

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\font.cpp
# End Source File
# Begin Source File

SOURCE=.\Login.cpp
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\mci.cpp
# End Source File
# Begin Source File

SOURCE=.\md5c.c

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\md5class.cpp

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\msflexgrid.cpp
# End Source File
# Begin Source File

SOURCE=.\myCodeBook.cpp
# End Source File
# Begin Source File

SOURCE=.\myHooks.cpp

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\picture.cpp
# End Source File
# Begin Source File

SOURCE=.\RECOGNITION.CPP

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\RIFFFile.cpp

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\rowcursor.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\Testing.cpp
# End Source File
# Begin Source File

SOURCE=.\Training.cpp
# End Source File
# Begin Source File

SOURCE=.\userSet.cpp
# End Source File
# Begin Source File

SOURCE=.\Voice2Command.cpp
# End Source File
# Begin Source File

SOURCE=.\Voice2Command.rc
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandSet.cpp
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandView.cpp
# End Source File
# Begin Source File

SOURCE=.\WAVE.cpp

!IF  "$(CFG)" == "Voice2Command - Win32 Release"

!ELSEIF  "$(CFG)" == "Voice2Command - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\DoitDialog.h
# End Source File
# Begin Source File

SOURCE=.\FFT.H
# End Source File
# Begin Source File

SOURCE=.\font.h
# End Source File
# Begin Source File

SOURCE=.\global.h
# End Source File
# Begin Source File

SOURCE=.\Login.h
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\matrix.h
# End Source File
# Begin Source File

SOURCE=.\mci.h
# End Source File
# Begin Source File

SOURCE=.\MD5.h
# End Source File
# Begin Source File

SOURCE=.\md5class.h
# End Source File
# Begin Source File

SOURCE=.\msflexgrid.h
# End Source File
# Begin Source File

SOURCE=.\myCodeBook.h
# End Source File
# Begin Source File

SOURCE=.\picture.h
# End Source File
# Begin Source File

SOURCE=.\RECOGNITION.H
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\rifffile.h
# End Source File
# Begin Source File

SOURCE=.\rowcursor.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\Testing.h
# End Source File
# Begin Source File

SOURCE=.\Training.h
# End Source File
# Begin Source File

SOURCE=.\UserSet.h
# End Source File
# Begin Source File

SOURCE=.\Voice2Command.h
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandDoc.h
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandSet.h
# End Source File
# Begin Source File

SOURCE=.\Voice2CommandView.h
# End Source File
# Begin Source File

SOURCE=.\WAVE.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\res\icon1.ico
# End Source File
# Begin Source File

SOURCE=.\res\loginlogo.bmp
# End Source File
# Begin Source File

SOURCE=.\res\mainlogo.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Speak.bmp
# End Source File
# Begin Source File

SOURCE=.\res\testing.bmp
# End Source File
# Begin Source File

SOURCE=.\res\testlogo.bmp
# End Source File
# Begin Source File

SOURCE=.\res\trainingconsole.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Voice2Command.ico
# End Source File
# Begin Source File

SOURCE=.\res\Voice2Command.rc2
# End Source File
# Begin Source File

SOURCE=.\res\Voice2CommandDoc.ico
# End Source File
# Begin Source File

SOURCE=.\res\WH.bmp
# End Source File
# Begin Source File

SOURCE=.\res\WV.bmp
# End Source File
# End Group
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
# Section Voice2Command : {9F6AA700-D188-11CD-AD48-00AA003C9CB6}
# 	2:5:Class:CRowCursor
# 	2:10:HeaderFile:rowcursor.h
# 	2:8:ImplFile:rowcursor.cpp
# End Section
# Section Voice2Command : {B7ABC220-DF71-11CF-8E74-00A0C90F26F8}
# 	2:5:Class:Cmci
# 	2:10:HeaderFile:mci.h
# 	2:8:ImplFile:mci.cpp
# End Section
# Section Voice2Command : {5F4DF280-531B-11CF-91F6-C2863C385E30}
# 	2:5:Class:CMSFlexGrid
# 	2:10:HeaderFile:msflexgrid.h
# 	2:8:ImplFile:msflexgrid.cpp
# End Section
# Section Voice2Command : {BEF6E003-A874-101A-8BBA-00AA00300CAB}
# 	2:5:Class:COleFont
# 	2:10:HeaderFile:font.h
# 	2:8:ImplFile:font.cpp
# End Section
# Section Voice2Command : {6262D3A0-531B-11CF-91F6-C2863C385E30}
# 	2:21:DefaultSinkHeaderFile:msflexgrid.h
# 	2:16:DefaultSinkClass:CMSFlexGrid
# End Section
# Section Voice2Command : {C1A8AF25-1257-101B-8FB0-0020AF039CA3}
# 	2:21:DefaultSinkHeaderFile:mci.h
# 	2:16:DefaultSinkClass:Cmci
# End Section
# Section Voice2Command : {7BF80981-BF32-101A-8BBB-00AA00300CAB}
# 	2:5:Class:CPicture
# 	2:10:HeaderFile:picture.h
# 	2:8:ImplFile:picture.cpp
# End Section
