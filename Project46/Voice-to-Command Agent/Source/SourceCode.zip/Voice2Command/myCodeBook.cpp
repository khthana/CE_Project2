// myCodeBook.cpp: implementation of the myCodeBook class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Voice2Command.h"
#include "myCodeBook.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

myCodeBook::myCodeBook()
{

}

myCodeBook::~myCodeBook()
{

}

void myCodeBook::SetArray(float x[39][16])
{
	for (int i=0;i<39;i++)
	{
		for (int j=0;j<16;j++)
		{
			Buffer_Book[i][j] = x[i][j];
		}
	}
}

void myCodeBook::SetArrays(float x[39][16],int ID)
{
	for (int i=0;i<39;i++)
	{
		for (int j=0;j<16;j++)
		{
			All_Books[ID][i][j] = x[i][j];
		}
	}
}

void myCodeBook::GetArray(int ID)
{
	for (int i=0;i<39;i++)
	{
		for (int j=0;j<16;j++)
		{
			Buffer_Book[i][j] = All_Books[ID][i][j];
		}
	}
}