// Voice2CommandSet.cpp : implementation of the CVoice2CommandSet class
//

#include "stdafx.h"
#include "Voice2Command.h"
#include "Voice2CommandSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandSet implementation

IMPLEMENT_DYNAMIC(CVoice2CommandSet, CRecordset)

CVoice2CommandSet::CVoice2CommandSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CVoice2CommandSet)
	m_id = 0;
	m_no = 0;
	m_word = _T("");
	m_description = _T("");
	m_filename = _T("");
	m_wavefile = _T("");
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}

CString CVoice2CommandSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=VoiceProject");
}

CString CVoice2CommandSet::GetDefaultSQL()
{
	return _T("[COMMANDS]");
}

void CVoice2CommandSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CVoice2CommandSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Long(pFX, _T("[no]"), m_no);
	RFX_Text(pFX, _T("[word]"), m_word);
	RFX_Text(pFX, _T("[description]"), m_description);
	RFX_Text(pFX, _T("[filename]"), m_filename);
	RFX_Text(pFX, _T("[wavefile]"), m_wavefile);
	
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CVoice2CommandSet diagnostics

#ifdef _DEBUG
void CVoice2CommandSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CVoice2CommandSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
