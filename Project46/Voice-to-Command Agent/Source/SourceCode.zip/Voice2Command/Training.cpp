// Training.cpp : implementation file

#include "stdafx.h"
#include "Voice2Command.h"
#include "Training.h"

#include "mmsystem.h"

#include "string"
using std::string;
/*
#ifndef _NO_NAMESPACE
using namespace std;
#define STD std
#else
#define STD
#endif
*/

//#define  HOOKsFILE "Hook\\TestHooks.bin"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Training dialog


Training::Training(CWnd* pParent /*=NULL*/)
	: CDialog(Training::IDD, pParent)
{
	//{{AFX_DATA_INIT(Training)
	m_No = 0;
	m_Username = _T("");
	m_Word = _T("");
	m_Description = _T("");
	m_Wavefile = "Wave\\";			//.wav
	m_Wavetmpfile = "Wave\\tmp.wav";
	m_WaveOGRfile = "Wave\\Original.wav";
	m_Hookfile = "Hook\\";			//.bin
	//m_WaveComplete = FALSE;
	//m_HookComplete = FALSE;
	m_Time = _T("");
	//}}AFX_DATA_INIT
}


void Training::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Training)
	DDX_Control(pDX, IDC_HOOKSTATUS, m_HookStatus);
	DDX_Control(pDX, IDC_WAVESTATUS, m_WaveStatus);
	DDX_Control(pDX, IDC_H_REPLAY, c_PlayHook);
	DDX_Control(pDX, IDC_H_RECORD, c_RecordHook);
	DDX_Control(pDX, IDC_H_CLEAR, c_ClearHook);
	DDX_Control(pDX, IDC_W_RESET, c_ResetWav);
	DDX_Control(pDX, IDC_W_PLAY, c_PlayWav);
	DDX_Control(pDX, IDC_W_RECORD, c_RecordWav);
	DDX_Text(pDX, IDC_USER, m_Username);
	DDX_Text(pDX, IDC_WORD, m_Word);
	DDX_Text(pDX, IDC_DESCRIPTION, m_Description);
	DDX_Control(pDX, IDC_MMCONTROL, m_MCI);
	DDX_Text(pDX, IDC_TIMER, m_Time);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Training, CDialog)
	//{{AFX_MSG_MAP(Training)
	ON_BN_CLICKED(ID_COMPLETE, OnComplete)
	ON_BN_CLICKED(IDC_W_PLAY, OnWPlay)
	ON_BN_CLICKED(IDC_W_RECORD, OnWRecord)
	ON_BN_CLICKED(IDC_W_RESET, OnWReset)
	ON_BN_CLICKED(IDC_H_RECORD, OnHRecord)
	ON_BN_CLICKED(IDC_H_CLEAR, OnHClear)
	ON_BN_CLICKED(IDC_H_REPLAY, OnHReplay)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_EN_CHANGE(IDC_WORD, OnChangeWord)
	ON_EN_CHANGE(IDC_DESCRIPTION, OnChangeDescription)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Training message handlers

void Training::InitialTrain(CString user,int no,CString word,CString descript)
{
	m_Username		= user;
	m_No			= no;
	m_Word			= word;
	m_Description	= descript;
	
	CString sn;
	sn.Format("%d",m_No);

	m_Wavefile = "Wave\\"+m_Username+"_"+sn+".wav";			//.wav
	m_Hookfile = "Hook\\"+m_Username+"_"+sn+".bin";			//.bin

	//m_WaveComplete = FALSE;
	//m_HookComplete = FALSE;

	WaveRecording = FALSE;		// For Stop/Record Button
	HookRecording = FALSE;		// For Stop/Record Button

	TimerRunning = FALSE;
}

// Wave file Management

void Training::OnWRecord() 
{
	// Initial m_MCI

	m_MCI.SetNotify(FALSE);
	m_MCI.SetWait(TRUE);
	m_MCI.SetShareable(FALSE);
	m_MCI.SetDeviceType("");

	if (!WaveRecording)
	{
		//		AfxMessageBox(m_Wavefile);
		remove(m_Wavetmpfile);

		c_RecordWav.SetWindowText("&Stop");
		c_PlayWav.EnableWindow(FALSE);
		c_ResetWav.EnableWindow(FALSE);
		WaveRecording = TRUE;

		StartTimer();

		// Initialize MCI device
		
		m_MCI.SetCommand("STOP");
		m_MCI.SetCommand("CLOSE");

		m_MCI.SetRecordMode(1);
		m_MCI.SetRecordEnabled(TRUE);

		m_MCI.SetFileName(m_WaveOGRfile);
		m_MCI.SetCommand("OPEN");
		m_MCI.SetCommand("Prev");
		m_MCI.SetCommand("Record");
		m_WaveStatus.SetWindowText("Recording your new voice command.");
	}
	else {
		KillTimer(1);

		c_RecordWav.SetWindowText("&Record");
		c_PlayWav.EnableWindow(TRUE);
		c_ResetWav.EnableWindow(TRUE);
		WaveRecording = FALSE;

		m_MCI.SetCommand("STOP");
		m_MCI.SetFileName(m_Wavetmpfile);
		m_MCI.SetCommand("Save");
		
		m_WaveStatus.SetWindowText("Record new voice command complete.");
		//m_WaveComplete = TRUE;
	}
}

void Training::OnWReset() 
{
	KillTimer(1);
	remove(m_Wavetmpfile);
	//m_WaveComplete = FALSE;
	WaveRecording  = FALSE;
	c_RecordWav.SetWindowText("&Record");
	c_RecordWav.EnableWindow(TRUE);

	m_MCI.SetCommand("STOP");
	m_MCI.SetCommand("CLOSE");
	m_WaveStatus.SetWindowText("Reset to your old voice command.");
}

void Training::OnWPlay() 
{
	//CString filename = "Wave\\Windy_1.wav";
	//sndPlaySound("C:\\Windy.wav",SND_SYNC);
	//sndPlaySound(m_Wavefile,SND_SYNC);

	m_MCI.SetCommand("STOP");
	m_MCI.SetCommand("CLOSE");

	if (CheckTmpVoice())
	{
		m_MCI.SetFileName(m_Wavetmpfile);
		m_MCI.SetCommand("OPEN");
		m_MCI.SetCommand("Prev");
		m_MCI.SetCommand("Play");
		
		StartTimer();
		m_WaveStatus.SetWindowText("Playing your new voice command.");
	} 
	else if (CheckOldVoice())
	{
		m_MCI.SetFileName(m_Wavefile);
		m_MCI.SetCommand("OPEN");
		m_MCI.SetCommand("Prev");
		m_MCI.SetCommand("Play");
		
		StartTimer();
		m_WaveStatus.SetWindowText("Playing your old voice command.");
	}
	else
	{
		MessageBox("You not have a voice.","ERROR",MB_OK);
		m_WaveStatus.SetWindowText("You not have a voice.");
	}
	//KillTimer(1);
}

BOOL Training::CheckTmpVoice()
{
	CFile f1;
	CFileException e;

	int CanOpen = f1.Open(m_Wavetmpfile,CFile::modeRead,&e);

	bool How = TRUE;
	if (CanOpen > 0){	How = TRUE;	} else {	How = FALSE;	}
	return How;

//	f1.Close();
//	if (How) { MessageBox(m_Wavetmpfile+" : TRUE","DEBUG",MB_OK); }
//	else { MessageBox(m_Wavetmpfile+" : FALSE","DEBUG",MB_OK);	}
}

BOOL Training::CheckOldVoice()
{
	CFile f2;
	CFileException e;
	
	int CanOpen = f2.Open(m_Wavefile,CFile::modeRead,&e);
	bool How = TRUE;
	if (CanOpen > 0){	How = TRUE;	} else {	How = FALSE;	}
	return How;

//	f2.Close();
//	if (How) { MessageBox(m_Wavefile+" : TRUE","DEBUG",MB_OK); }
//	else { MessageBox(m_Wavefile+" : FALSE","DEBUG",MB_OK);	}
}
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
////////////// Windows Hook Message Management ////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

extern HHOOK hhookHooks;

extern string HooksForPlay;

extern "C" {
	LRESULT CALLBACK JournalRecordFunc	 (int nCode,WPARAM wParam,LPARAM lParam);
	LRESULT CALLBACK JournalPlaybackFunc (int nCode,WPARAM wParam,LPARAM lParam);
}

///////////////////////////////////////////////////////////////////

BOOL Training::CheckTmpHook()
{
	CFile f3;
	CFileException e;

	int CanOpen = f3.Open("Hook\\TestHooks.bin",CFile::modeRead,&e);
	bool How = TRUE;
	if (CanOpen > 0){	How = TRUE;	} else {	How = FALSE;	}
	return How;

//	f3.Close();	
}

BOOL Training::CheckOldHook()
{
	CFile f4;
	CFileException e;

	int CanOpen = f4.Open(m_Hookfile,CFile::modeRead,&e);
	bool How = TRUE;
	if (CanOpen > 0){	How = TRUE;	} else {	How = FALSE;	}
	return How;

//	f4.Close();
}

void Training::OnHRecord() 
{
	if (!HookRecording)
	{
		HooksForPlay = "Hook\\TestHooks.bin";
		HookRecording = TRUE;
		
		UnhookWindowsHookEx(hhookHooks);
		remove(HooksForPlay.c_str());

		MessageBox("Press F2 for stop recording.","Recommend",MB_OK);

		hhookHooks = SetWindowsHookEx(WH_JOURNALRECORD,(HOOKPROC) JournalRecordFunc,AfxGetInstanceHandle(), 0);

		//m_HookComplete = TRUE;
		HookRecording = FALSE;
//		UnhookWindowsHookEx(hhookHooks);
		m_HookStatus.SetWindowText("Record your new command.");
	}
}

void Training::OnHClear() 
{
	UnhookWindowsHookEx(hhookHooks);

	//m_HookComplete = FALSE;
	HookRecording  = FALSE;
	
//	c_RecordHook.EnableWindow(TRUE);
//	c_ClearHook.EnableWindow(FALSE);
//	c_PlayHook.EnableWindow(FALSE);

	// Remove temporary of Hook file...

	HooksForPlay = "Hook\\TestHooks.bin";
	remove(HooksForPlay.c_str());
	m_HookStatus.SetWindowText("Reset command.");
}

void Training::OnHReplay()
{
	if (CheckTmpHook())	// If Recorded
	{
		HooksForPlay = "Hook\\TestHooks.bin";
		UnhookWindowsHookEx(hhookHooks);
		hhookHooks = SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC) JournalPlaybackFunc,AfxGetInstanceHandle(),0);
		m_HookStatus.SetWindowText("Reply your new command.");
	}
	else if (CheckOldHook())			// if not recorded
	{
		//m_HookComplete = TRUE;

		// Case not new record but have been recorded message hooks ...
		//Problem is : HooksForPlay<string> can't receive value from CString

		HooksForPlay = m_Hookfile;
		UnhookWindowsHookEx(hhookHooks);
		hhookHooks = SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC) JournalPlaybackFunc,AfxGetInstanceHandle(),0);		
		m_HookStatus.SetWindowText("Reply your old command.");
	}
	else // Case haven't been recorded...
	{		
		MessageBox("You haven't record any events.","ERROR",MB_OK);
		m_HookStatus.SetWindowText("No command.");
	}
}

// Check complete 3 steps of record command voice , record WH , write word
void Training::OnComplete() 
{
	UpdateData(TRUE);
	
	m_MCI.SetCommand("STOP");
	m_MCI.SetCommand("CLOSE");

	//if (strcmp(m_Word,"")|| strcmp(m_Description,""))
	//if ((m_Word=="")||(m_Description=="")||(CheckOldVoice())||(!m_HookComplete))
	//if ((m_Word=="")||(m_Description=="")||(!m_WaveComplete)||(!m_HookComplete))
	
	if ((m_Word != "")&&(m_Description != "")&&
		(CheckTmpVoice() || CheckOldVoice()) && 
		( CheckTmpHook() || CheckOldHook() )
	   )		
	{		
		if (CheckTmpVoice())	// Copy Wave temp file -> real wave file...
		{
			m_MCI.SetCommand("STOP");
			m_MCI.SetCommand("CLOSE");

			m_MCI.SetFileName(m_Wavetmpfile);
			m_MCI.SetCommand("OPEN");
			m_MCI.SetCommand("Prev");
			m_MCI.SetFileName(m_Wavefile);
			m_MCI.SetCommand("Save");
			m_MCI.SetCommand("CLOSE");
		}

		if (CheckTmpHook())		// Rename hook tempoary file -> real hooks file...
		{
			remove(m_Hookfile);
			HooksForPlay = "Hook\\TestHooks.bin";
			rename(HooksForPlay.c_str(),m_Hookfile);
		}

		// Copy Hook
 
		remove(m_Wavetmpfile);
		remove("Hook\\TestHooks.bin");
		KillTimer(1);
		CDialog::OnOK();
	}
	else
	{	
		KillTimer(1);
		MessageBox("You haven't completely all step. ","ERROR",MB_OK);
	} 
}

void Training::OnCancel() 
{
	//MessageBox(m_Wavetmpfile,"ERROR",MB_OK);
	
	remove(m_Wavetmpfile);
	remove("Hook\\TestHooks.bin");	

	CDialog::OnCancel();
}

void Training::OnTimer(UINT nIDEvent) 
{
	ShowTime();
	CDialog::OnTimer(nIDEvent);
}

void Training::ShowTime()
{
	UpdateData(TRUE);
	m_Time.Format("%1.2f/%1.2f s.",m_MCI.GetPosition()/1000.00,m_MCI.GetTrackLength()/1000.00);
	UpdateData(FALSE);
}

void Training::StartTimer()
{
	// Initial Timer

	if (TimerRunning)			// if have been set timer
	{
		KillTimer(1);			// Cancel set Timer
		TimerRunning = FALSE;	// It's Free
	}

	if (!TimerRunning)
	{
		SetTimer(1,10,NULL);
		TimerRunning = TRUE;
		m_MCI.SetTimeFormat(0);
	}
}

void Training::OnDestroy() 
{
	CDialog::OnDestroy();
	KillTimer(1);
}

void Training::OnChangeWord() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	//KillTimer(1);
}

void Training::OnChangeDescription() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	//KillTimer(1);
}
