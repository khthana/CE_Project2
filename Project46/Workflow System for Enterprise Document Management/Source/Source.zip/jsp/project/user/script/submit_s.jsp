<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="com.jspsmart.upload.*"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();

	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));

	String keyword = " where WORKID="+WORKID+" ";
	mybean.Work work[];
	work = userpower.readwork.getWork(keyword," ");

	String keyword1 = " where STATEID="+work[0].getSTATEID()+" ";
	mybean.State state[];
	state = userpower.readstate.getState(keyword1," ");

	String keyword2 = " where WORKFLOWID="+state[0].getWORKFLOWID()+" ";
	mybean.WorkFlow workflow[];
	workflow = userpower.readworkflow.getWorkFlow(keyword2," ");
	mybean.State allstate[];
	allstate = userpower.readstate.getState(keyword2," ");
	
	String keyword3 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = userpower.readdocumenttype.getDocumentType(keyword3," ");

	mybean.Attribute attribute[];
	attribute = userpower.readattribute.getAttribute(keyword3," ");
	String ATT_VALUE[] = null;

	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters
	while (e.hasMoreElements()){
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("ATT_VALUE")){
			ATT_VALUE = values;
		}//PRIORITY
	}//while

	userpower.writeworkattribute.deleteallWorkAttribute(new Integer(WORKID));

	for (int i = 0;i<ATT_VALUE.length;i++){
		ATT_VALUE[i] = thaistring.MS874ToUnicode(ATT_VALUE[i]);
		if(!(ATT_VALUE[i].equals(""))){
			userpower.writeworkattribute.addWorkAttribute(new Integer(WORKID),attribute[i].getATTRIBUTEID(),ATT_VALUE[i]);
		}//if
	}//for i

	String upfilename = work[0].getWORKID()+"."+mySmartUpload.getFiles().getFile(0).getFileExt();
	upfilename = upfilename.toUpperCase();
	mySmartUpload.getFiles().getFile(0).saveAs("/project/upload/"+upfilename);

	userpower.writework.editWork(new Integer(WORKID),work[0].getWORKNAME(),new Integer(STATEID),work[0].getPRIORITY(),upfilename,cur_user);

	response.sendRedirect("../worklist.jsp");
%>
