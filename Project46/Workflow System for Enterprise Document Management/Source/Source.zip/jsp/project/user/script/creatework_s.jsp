<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="com.jspsmart.upload.*"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();
//	String upfileext = mySmartUpload.getFiles().getFile(0).getFileExt();

	String WORKNAME = new String();
	String PRIORITY = new String();
	String DOCUMENTTYPEID = new String();

	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters
	while (e.hasMoreElements()){
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("PRIORITY")){
			PRIORITY = thaistring.MS874ToUnicode(values[0]);
		}//PRIORITY
		if(key.equals("DOCUMENTTYPEID")){
			DOCUMENTTYPEID = thaistring.MS874ToUnicode(values[0]);
		}//DOCUMENTTYPEID
		if(key.equals("WORKNAME")){
			WORKNAME = thaistring.MS874ToUnicode(values[0]);
		}//WORKNAME
	}//while
	WORKNAME = WORKNAME.toUpperCase();

	userpower.writework.addWork(WORKNAME,new Integer(DOCUMENTTYPEID),new Integer(PRIORITY),cur_user);
	String keyword = " where CREATED_BY='"+cur_user.getUSERNAME()+"' and PRIORITY="+PRIORITY+" and WORKNAME='"+WORKNAME+"' ";
	mybean.Work work[];
	work = userpower.readwork.getWork(keyword," ");
//	String upfilename = work[work.length-1].getWORKID()+"."+upfileext;
//	upfilename = upfilename.toUpperCase();
//	userpower.writework.setFILENAMEWork(work[0].getWORKID(),upfilename);
//	mySmartUpload.getFiles().getFile(0).saveAs("/project/upload/"+upfilename);
	response.sendRedirect("take_s.jsp?WORKID="+work[0].getWORKID());
%>
