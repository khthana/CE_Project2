<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));

	String keyword = " where WORKID="+WORKID+" ";
	mybean.Work work[];
	work = userpower.readwork.getWork(keyword," ");
	mybean.LogWork logwork[];
	logwork = userpower.readlogwork.getLogWork(keyword," ");

	Integer STATEBEFORE = logwork[logwork.length-1].getSTATEBEFORE();
	userpower.writework.rejectWork(new Integer(WORKID),work[0].getWORKNAME(),STATEBEFORE,work[0].getPRIORITY(),work[0].getFILENAME(),cur_user);

	response.sendRedirect("../worklist.jsp");
%>