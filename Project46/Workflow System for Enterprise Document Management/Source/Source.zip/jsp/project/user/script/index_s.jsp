<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	String USERNAME = thaistring.MS874ToUnicode(request.getParameter("USERNAME"));
	if (USERNAME==null){
		USERNAME = "";
	}
	String PASSWORD = thaistring.MS874ToUnicode(request.getParameter("PASSWORD"));
	if (PASSWORD==null){
		PASSWORD = "";
	}

	String keyword = " where USERNAME='"+USERNAME+"' and PASSWORD='"+PASSWORD+"'";
	mybean.User user[];
	user = userpower.readuser.getUser(keyword," ");

	if (user.length != 0){
		session.setAttribute("CUR_USER",user[0]);
		response.sendRedirect("../frame.jsp");
	}//if
	else{
		out.println("Username or Password wrong");
	}//else
%>
<SCRIPT LANGUAGE="JavaScript">
<!--
	function goBack() {
		window.history.back(2);
	}
	setTimeout('goBack()',3000);
//-->
</SCRIPT>
