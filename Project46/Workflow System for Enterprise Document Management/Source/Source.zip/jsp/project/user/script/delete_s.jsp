<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));
	if (WORKID==null){
		WORKID = "";
	}

	userpower.writework.deleteWork(new Integer(WORKID));

	response.sendRedirect("../worklist.jsp");
%>