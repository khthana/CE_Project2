<%@page contentType="text/html; charset=WINDOWS-874"%> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Login User</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body bgcolor="#FFFFFF" text="#CC0000">
<form name="userlogin" action="script/index_s.jsp" method="post">
<table width="85%">
  <tr bgcolor="#CC0000"> 
    <td height="29" colspan="3"><div align="right">
	
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 WIDTH="550" HEIGHT="40" id="Untitled-2" ALIGN="">
 <PARAM NAME=movie VALUE="header.swf"> <PARAM NAME=quality VALUE=high> <PARAM NAME=wmode VALUE=transparent> <PARAM NAME=bgcolor VALUE=#000000> <EMBED src="header.swf" quality=high wmode=transparent bgcolor=#000000  WIDTH="550" HEIGHT="40" NAME="Untitled-2" ALIGN=""
 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
</OBJECT>

	</div></td>
  </tr>
  <tr> 
    <td width="33%" rowspan="3"><img src="../2.jpg" width="151" height="130"></td>
    <td width="19%" height="62"><div align="right"><font color="#000000">Login 
        : </font></div></td>
    <td width="48%"><font color="#000000">
      <input type="text" name="USERNAME">
      </font></td>
  </tr>
  <tr> 
    <td height="21"><div align="right"><font color="#000000">Password :</font></div></td>
    <td><input type="password" name="PASSWORD"></td>
  </tr>
  <tr> 
    <td height="21">&nbsp;</td>
    <td> <input name="OK" type="submit" id="OK2" value="   OK   "  onClick="window.location='frame.htm'">
      &nbsp;&nbsp;&nbsp; <input name="Clear" type="reset" value="Reset"> 
    </td>
  </tr>
</table>
</form>


</body>
</html>
