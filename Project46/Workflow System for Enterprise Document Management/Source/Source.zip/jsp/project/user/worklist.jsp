<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%@ page language="java" import="java.text.*"%>
<%@ page import="java.util.Locale"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy",Locale.US);
	Integer workflowid[];
	cur_user.createSTATEview();
	workflowid = cur_user.getWORKFLOWbyUSER();
%>

<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../code.js"></SCRIPT>

<body  leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" class="menu">
<font face="Cordia New, CordiaUPC"></font> 
<table width="100%">
  <tr> 
    <td height="47"  colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td  class="head"><strong>Work List </strong></td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td width="97%" ><form name="worklist" method="post" action="">
        <%
	for(int i=0;i<workflowid.length;i++){
		mybean.WorkFlow workflow[];
		mybean.UserState userstate[];
		String keyword = " where WORKFLOWID="+workflowid[i]+" ";
		workflow = userpower.readworkflow.getWorkFlow(keyword," ");
		userstate = cur_user.getSTATEbyUSER(workflowid[i]);
%>
        <table class="box"width="93%">
          <tr> 
            <td colspan="6"><strong>Workflow</strong> : <%=workflow[0].getWORKFLOWNAME()%></td>
          </tr>
          <tr class="submit"> 
            <td width="16%"><div align="center"><strong>State name</strong></div></td>
            <td width="17%" ><div align="center"><strong>Work name</strong></div></td>
            <td width="13%" ><div align="center"><strong>Priority</strong></div></td>
            <td width="18%" ><div align="center"><strong>Coming date</strong></div></td>
            <td width="20%" ><div align="center"><strong>Taken by</strong></div></td>
            <td width="16%" ><div align="center"><strong>Taken date</strong></div></td>
          </tr>
          <%
		for(int j=0;j<userstate.length;j++){
			mybean.State state[];
			mybean.Work work[];
			String keyword1 = " where STATEID="+userstate[j].getSTATEID()+" ";
			state = userpower.readstate.getState(keyword1," ");
			work = userpower.readwork.getWork(keyword1," order by PRIORITY,WORKID ");
%>
          <tr> 
            <td  <%if(state[0].getSTATETYPE().equals("3")){out.print("bgcolor=\"#FFFFCC\"");}else{out.print("class=\"submit\"");}%>><%=state[0].getSTATENAME()%></td>
            <td colspan="5"  bgcolor="#eeeeee" onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); >&nbsp;</td>
          </tr>
          <%
			for(int k=0;k<work.length;k++){
				String keyword2 = " where WORKID="+work[k].getWORKID()+" ";
			  	mybean.LogWork logwork[];
				logwork = userpower.readlogwork.getLogWork(keyword2," ");

%>
          <tr> 
            <td >&nbsp;</td>
            <td width="17%" bgcolor="#eeeeee" onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);>- <a href="work.jsp?WORKID=<%=work[k].getWORKID()%>"><%if(work[k].ISLATE()){out.print("<font color=\"#CC0000\">");}%><%=work[k].getWORKNAME()%><%if(work[k].ISLATE()){out.print("</font>");}%></a> 
            </td>
            <td width="13%" ><%=work[k].getPRIORITY()%></td>
            <td width="18%" ><%if(logwork.length==0){out.print(dateFormat.format(work[k].getCREATED_DATE()));}else{out.print(dateFormat.format(logwork[logwork.length-1].getTIMEAFTER()));}%></td>
            <td width="20%"> 
              <%if(work[k].getUSERNAME()!=null){out.print(work[k].getUSERNAME());}%>
            </td>
            <td width="16%" > 
              <%if(work[k].getTAKEN_DATE()!=null){out.print(dateFormat.format(work[k].getTAKEN_DATE()));}%>
            </td>
          </tr>
          <%
			}//for k
		}//for j
%>
        </table>
        <br>
        <%
	}//for i
%>
      </form></td>
  </tr>
</table>
</body>
</html>
<%
	cur_user.dropSTATEview();
%>