<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%@ page language="java" import="java.text.*"%>
<%@ page import="java.util.Locale"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy",Locale.US);

	String message = "Are you sure you want to edit it? If you edit, all states of works will be null.";

	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));

	String keyword = " where WORKID="+WORKID+" ";
	mybean.Work work[];
	work = userpower.readwork.getWork(keyword," ");
	mybean.LogWork logwork[];
	logwork = userpower.readlogwork.getLogWork(keyword," ");

	String keyword1 = " where STATEID="+work[0].getSTATEID()+" ";
	mybean.State state[];
	state = userpower.readstate.getState(keyword1," ");
	mybean.Condition condition[];
	condition = userpower.readcondition.getCondition(keyword1," ");

	cur_user.createSTATEview();
	mybean.UserState userstate[];
	userstate = cur_user.getSTATEbyUSER(state[0].getWORKFLOWID());
	cur_user.dropSTATEview();

	String keyword2 = " where WORKFLOWID="+state[0].getWORKFLOWID()+" ";
	mybean.WorkFlow workflow[];
	workflow = userpower.readworkflow.getWorkFlow(keyword2," ");
	mybean.State allstate[];
	allstate = userpower.readstate.getState(keyword2," ");
	
	String keyword3 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = userpower.readdocumenttype.getDocumentType(keyword3," ");

	mybean.Attribute attribute[];
	attribute = userpower.readattribute.getAttribute(keyword3," ");

	boolean istekenbycur_user=false;
	if(cur_user.getUSERNAME().equals(work[0].getUSERNAME())){
		istekenbycur_user = true;
	}//if

%>
<HTML><HEAD><TITLE>Work</TITLE>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="34" colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td width="1%">&nbsp;</td>
    <td class= "head" width="33%"><strong>Work</strong></td>
    <td width="66%">&nbsp; </td>
  </tr>
  <tr> 
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"> <form action="script/work_s.jsp" method="post" enctype="multipart/form-data" name="work">
        <table width="100%" border="0">
          <tr> 
            <td>Work name : </td>
            <td><%=work[0].getWORKNAME()%></td>
          </tr>
          <tr> 
            <td>Coming date :</td>
            <td><%if(logwork.length==0){out.print(dateFormat.format(work[0].getCREATED_DATE()));}else{out.print(dateFormat.format(logwork[logwork.length-1].getTIMEAFTER()));}%></td>
          </tr>
          <tr> 
            <td>Priority :</td>
            <td><%=work[0].getPRIORITY()%></td>
          </tr>
          <tr> 
            <td>Created by :</td>
            <td><%=work[0].getCREATED_BY()%></td>
          </tr>
          <tr> 
            <td>Created date :</td>
            <td><%=dateFormat.format(work[0].getCREATED_DATE())%></td>
          </tr>
          <tr> 
            <td width="25%">Workflow name : </td>
            <td width="75%"><%=workflow[0].getWORKFLOWNAME()%></td>
          </tr>
          <tr> 
            <td width="25%">Document type Name : </td>
            <td width="75%"><%=documenttype[0].getDOCUMENTTYPENAME()%></td>
          </tr>
          <tr> 
            <td width="25%">State Name : </td>
            <td width="75%"><%=state[0].getSTATENAME()%></td>
          </tr>
		  <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td   colspan="2"> <table width="66%" class="box">
                <tr class="submit"> 
                  <td width="37%" height="29"><div align="center"><strong>Attribute 
                      Name</strong></div></td>
                  <td width="18%"><div align="center"><strong>Type</strong></div></td>
                  <td width="45%" height="29"><div align="center"><strong>Value</strong></div></td>
                </tr>
<%
	for(int i=0;i<attribute.length;i++){
		String keyword4 = " where WORKID="+WORKID+" and ATTRIBUTEID="+attribute[i].getATTRIBUTEID()+" ";
		mybean.WorkAttribute workattribute[];
		workattribute = userpower.readworkattribute.getWorkAttribute(keyword4," ");
%>
                <tr> 
                  <td width="37%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><strong><%=attribute[i].getATTRIBUTENAME()%></strong></td>
                  <td width="18%" >
<%
		if(attribute[i].getATTRIBUTETYPE().equals("1")){
			  out.println("Number");
		}//if
		else if(attribute[i].getATTRIBUTETYPE().equals("2")){
			  out.println("Date");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("3")){
			  out.println("Bool");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("4")){
			  out.println("String");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("5")){
			  out.println("Char");
		}//else
%>
				   </td>
                  <td width="45%" ><div align="center"><font color="#000000"> 
                      <input name="ATT_VALUE" type="text" size="30" value="<%if(workattribute.length>0){out.print(workattribute[0].getATT_VALUE());}%>" <%if(!(istekenbycur_user)){out.print("disabled");}%> <%if(attribute[i].getATTRIBUTETYPE().equals("5")){out.print("maxlength=\"1\"");}%>>
                      </font></div></td>
                </tr>
<%
	}//for i
%>
<%
	if(work[0].getFILENAME()!=null){
%>
				<tr> 
                  <td colspan="3" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="right"><a href="../upload/<%=work[0].getFILENAME()%>"><img src="folder.jpg" width="16" height="13"><%=work[0].getFILENAME()%></a></div></td>
                </tr>
<%
	}//if
%>
              </table></td>
          </tr>
          <tr> 
            <td height="22" colspan="2">&nbsp;</td>
          </tr>
<%
	if(istekenbycur_user){
%>
		  <tr> 
            <td height="31" colspan="2">
			<table class="submit"width="35%">
                <tr> 
                  <td><strong>Upload :</strong> <input type="file" name="FILENAME"></td>
                </tr>
              </table>
			  </td>
          </tr>
<%
	}//if
%>
          <tr> 
            <td height="22" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="26" colspan="2"><b> </b> <div align="right"> 
                <table width="100%">
                  <tr> 
                    <td width="33%" height="26"><input name="button" type="button" value=" Back " onClick="window.location='worklist.jsp'"></td>
                    <td width="67%"><div align="right"> 
<%
	if(!(istekenbycur_user)&&(work[0].getUSERNAME()==null)){
%>
                        <input name="Button" type="button" value=" Take " onClick="go('take','<%=WORKID%>')">
<%
	}//if
%>
<%
	if(istekenbycur_user){
%>
                        <input name="Button2" type="button" value=" Leave" onClick="go('leave','<%=WORKID%>')">
<%
		if(!(state[0].getSTATETYPE().equals("3"))){
%>
						<input type="button" name="Submit1" value="Submit" onClick="if(checknull()){}else{go('submit','<%=WORKID%>');}">
<%
		}//if
%>
<%
		if((!(state[0].getSTATETYPE().equals("1")))&&(!(state[0].getSTATETYPE().equals("3")))){
%>
						<input type="button" name="Submit2" value="Reject" onClick="go('reject','<%=WORKID%>')">
<%
		}//if
%>
<%
		boolean canreject=false;
		for(int z=0;z<userstate.length;z++){
			if(userstate[z].getSTATEID().equals(state[0].getSTATEID())){
				canreject = userstate[z].getCANREJECT().booleanValue();
				break;
			}//if
		}//for z
		if(canreject){//candelete
%>
                        <input type="button" name="Submit222" value="Terminate" onClick="go('delete','<%=WORKID%>')">
<%
		}//if canreject
%>
<%
	}//if
%>
                      </div></td>
                  </tr>
                </table>
              </div></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
<script language="JavaScript" type="text/JavaScript">
<!--
var doc = document.work;
<%
	for(int p=0;p<attribute.length;p++){
		if((attribute.length==1)&&(p==0)){
			out.println("var "+attribute[p].getATTRIBUTENAME()+" = document.work.ATT_VALUE");
		}//if
		else{
			out.println("var "+attribute[p].getATTRIBUTENAME()+" = document.work.ATT_VALUE["+p+"]");
		}//else
	}//for p
%>
function checknull(){
	if(1==0){
	}//if
<%
	for(int k=0;k<attribute.length;k++){
		if(attribute[k].getATTRIBUTETYPE().equals("1")){
			out.println("else if(("+attribute[k].getATTRIBUTENAME()+".value!='')&&(isNaN("+attribute[k].getATTRIBUTENAME()+".value))){alert('Please insert "+attribute[k].getATTRIBUTENAME()+" into number format');return true;}");
		}//if
		else if(attribute[k].getATTRIBUTETYPE().equals("3")){
			out.println("else if(("+attribute[k].getATTRIBUTENAME()+".value!='')&&(!(("+attribute[k].getATTRIBUTENAME()+".value=='y')||("+attribute[k].getATTRIBUTENAME()+".value=='n')))){alert('Please insert "+attribute[k].getATTRIBUTENAME()+" into y or n');return true;}");
		}//else
	}//for k
%>
	else if  (doc.FILENAME.value == ''||(doc.FILENAME.value!='' && isallspace(doc.FILENAME.value)) ){
		alert('Please insert file name!!!!');
		return true;
	}//else
	else{
		return false;
	}//else
}//function
function isallspace(src){
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++){
		if (src.charAt(i)!=' '){
			return false;
		}//if
	}//for
	return true;
}//function
function specialchar(scr){
	var i=0;
	for (i=0;i<scr.length;i++){
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\='){
			return true;
		}//if
	}//for
	return false;
}//function

function findnextstate(){
	var nextstate=-1;
	if(1==0){
	}//if
<%
	for(int u=0;u<condition.length;u++){
%>
		else if(<%=condition[u].getSTATEMENT()%>){
			nextstate=<%=condition[u].getNEXTSTATEID()%>;
		}//else if
<%
	}//for u
%>
	else{
//		alert("Cannot Submit To Next State");
	}//else
	return nextstate;
}
function go(p,workid){
	var nextstate=0;
	if (p=="reject"){
		doc.action = "script/reject_s.jsp?WORKID="+workid;
	}//if
	else if (p=="delete"){
		doc.action = "script/delete_s.jsp?WORKID="+workid;
	}//else
	else if (p=="take"){
		doc.action = "script/take_s.jsp?WORKID="+workid;
	}//else
	else if (p=="submit"){
		nextstate = findnextstate();
		doc.action = "script/submit_s.jsp?WORKID="+workid+"&STATEID="+nextstate;
	}//else
	else if (p=="leave"){
		doc.action = "script/leave_s.jsp?WORKID="+workid;
	}//else
	if(nextstate!=-1){
		doc.submit();
	}//if
	else{
		alert("Cannot Submit to Next State");
	}//else
}
-->
</script>
