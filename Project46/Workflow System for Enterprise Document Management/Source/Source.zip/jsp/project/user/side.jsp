<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Side</TITLE>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../code.js"></SCRIPT>

<META content="MSHTML 6.00.2800.1276" name=GENERATOR>
</HEAD>

<body bgcolor="eeeeee" >
<table width=133 border=0 cellpadding=0 cellspacing=0 bordercolor="#CC0000"  class=menu>
  <tbody>
  <TR > 
      <TD height="2" bgcolor="#FFFFFF" >&nbsp;</TD>
	  <td  height="2" width=1 bgcolor=#FFFFFF>&nbsp;</td>
    </TR>
    <TR > 
      <TD bgcolor="#CC0000" ><img src="../1.jpg" width="132" height="130" ></TD>
	  <td width=1 bgcolor=#CC0000></td>
    </TR>
    <tr> 
      <td width="130" 
            height=20 align=right bgcolor=#CCCCCC>User Home</td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
    <tr> 
      <td  bgcolor=#eeeeee 
            height=20 width="130">&nbsp;</td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
    <tr> 
      <td onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); align=right 
            height=20 width="130"><a href="worklist.jsp" target="mainFrame">Home</a></td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td  bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
	<td onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); align=right 
            height=20 width="130"><a href="creatework.jsp" target="mainFrame">Create 
      work </a></td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td  bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
    <tr> 
      <td  onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); align=right 
            height=20 width="130"><a href="chpwd.jsp" target="mainFrame">Change Password</a></td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
	<tr> 
      <td  onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); align=right 
            height=20 width="130"><a href="script/logout_s.jsp" target="_parent">Logout</a></td>
      <td width=1 bgcolor=#CC0000></td>
    </tr>
    <tr> 
      <td bgcolor=#CC0000 colspan=2 height=1></td>
    </tr>
</table>
</body>
</html>
