<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../style.css" type=text/css rel=stylesheet>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Please insert information</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="chpwd" method="post" action="script/chpwd_s.jsp">
  <table width="100%" border="0" align="center">
          <tr> 
            <td width="24%"><font color="#000000">New Password :</font></td>
            <td width="76%"> <font color="#000000">
              <input type="password" name="PASSWORD" maxlength="12">
              </font> </td>
    </tr>
          <tr> 
            <td width="24%"><font color="#000000">Retype New Password :</font></td>
            <td width="76%"> <input type="password" name="REPASSWORD" maxlength="12"> 
            </td>
    </tr>
    <tr> 
      <td  colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" width="24%">&nbsp;</td>
      <td width="76%"><input name="OK2" type="button" id="OK" value="   OK   "  onClick="checknull()"> 
              &nbsp; <input name="Cancel 2" type="reset" id="Cancel " value=" Cancel" onClick="window.location='worklist.jsp'"> 
              &nbsp; <input name="Reset2" type="reset" id="Reset2" value="Reset"> 
            </td>
    </tr>
  </table>
 </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.chpwd
	function checknull(){
		if (doc.PASSWORD.value=='')
			{alert('Please enter password !!!!'); } 
		else if (doc.REPASSWORD.value=='')
			{alert('Please retype new password !!!!');} 
		else if (doc.PASSWORD.value != doc.REPASSWORD.value)
			{alert ("The passwords you typed do not match!! Please retype the new password in the both boxes");}
		else 
			{doc.submit();}
	}
</SCRIPT>