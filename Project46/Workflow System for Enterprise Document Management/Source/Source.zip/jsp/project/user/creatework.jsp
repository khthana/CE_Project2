<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="userpower" class="mybean.UserPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if(cur_user==null){
		response.sendRedirect("index.jsp");
	}
%>
<%
	String message = "Are you sure you want to edit it? If you edit, all states of works will be null.";

	Integer workflowid[];
	cur_user.createSTATEview();
	workflowid = cur_user.getWORKFLOWbyUSER();

%>
<HTML><HEAD><TITLE>state edit</TITLE>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="1%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Create Work</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td >&nbsp;</td>
    <td> <form action="script/creatework_s.jsp" method="post" enctype="multipart/form-data" name="creatework">
        <table width="100%" border="0">
          <tr> 
            <td width="31%">Document type Name : </td>
            <td width="69%"><select name="DOCUMENTTYPEID" >
<%
	for(int q=0;q<workflowid.length;q++){
		mybean.State state[];
		String keyword = " where WORKFLOWID="+workflowid[q]+" ";
		state = userpower.readstate.getState(keyword," ");
		for (int i=0;i<state.length;i++){
			if(state[i].getSTATETYPE().equals("1")){
				mybean.WorkFlow workflow[];
				workflow = userpower.readworkflow.getWorkFlow(keyword," ");
				String keyword1 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
				mybean.DocumentType documenttype[];
				documenttype = userpower.readdocumenttype.getDocumentType(keyword1," ");
%>
                <option value="<%=documenttype[0].getDOCUMENTTYPEID()%>"><%=documenttype[0].getDOCUMENTTYPENAME()%></option>
<%
			}//if
		}//for i
	}//for q
%>
              </select></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>
          <tr> 
            <td width="31%">Work name :</td>
            <td width="69%"><b> 
              <input name="WORKNAME" type="text" size="25" maxlength="100">
              </b></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>
		  <tr> 
            <td width="31%">Priority : (1-99)</td>
            <td width="69%"><b> 
              <input name="PRIORITY" type="text" size="5" maxlength="2">
              </b></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>
<!--
		  <tr> 
            <td width="31%">File (Document file): </td>
            <td width="69%"><input type="file" name="FILENAME"></td>
          </tr>
-->
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>
          <tr> 
            <td colspan="2"><b> </b> <div align="right"> 
                <input name="   OK   " type="button"  value="   OK   " onClick="checknull()">
                <input type="button" name="Submit222" value="Cancel" onClick="window.location='worklist.jsp'">
                <input type="reset" name="Submit22" value="Reset">
              </div></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.creatework
	function checknull(){
	if ((doc.DOCUMENTTYPEID.value=='')||(doc.DOCUMENTTYPEID.value==null))
		{alert('Please select Document Type !!!!'); } 
	else if ((doc.PRIORITY.value=='')||(isNaN(doc.PRIORITY.value))||((!(isNaN(doc.PRIORITY.value)))&&((doc.PRIORITY.value<1)||(doc.PRIORITY.value>99))))
		{alert('Please insert into number (1-99)');}
//	else if  (doc.FILENAME.value == ''||(doc.FILENAME.value!='' && isallspace(doc.FILENAME.value)) )
//		{alert('Please insert file name!!!!');}
	else 
		{doc.submit();}
//doc.submit();
	}
	function isallspace(src)
	{
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}
		return true;
	}
-->
</SCRIPT>
<%
	cur_user.dropSTATEview();
%>