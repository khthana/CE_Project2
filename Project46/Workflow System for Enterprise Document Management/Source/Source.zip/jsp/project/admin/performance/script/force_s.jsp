<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));

	String keyword = " where WORKID="+WORKID+" ";
	mybean.Work work[];
	work = adminpower.readwork.getWork(keyword," ");

	String keyword1 = " where STATEID="+work[0].getSTATEID()+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword1," ");

	String keyword2 = " where WORKFLOWID="+state[0].getWORKFLOWID()+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword2," ");
	mybean.State allstate[];
	allstate = adminpower.readstate.getState(keyword2," ");
	
	String keyword3 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword3," ");

	mybean.Attribute attribute[];
	attribute = adminpower.readattribute.getAttribute(keyword3," ");

	adminpower.writeworkattribute.deleteallWorkAttribute(new Integer(WORKID));
	String ATT_VALUE[] = request.getParameterValues("ATT_VALUE");
	for (int i = 0;i<ATT_VALUE.length;i++){
		ATT_VALUE[i] = thaistring.MS874ToUnicode(ATT_VALUE[i]);
		if(!(ATT_VALUE[i].equals(""))){
			adminpower.writeworkattribute.addWorkAttribute(new Integer(WORKID),attribute[i].getATTRIBUTEID(),ATT_VALUE[i]);
		}//if
	}//for i

	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));

	adminpower.writework.editWork(new Integer(WORKID),work[0].getWORKNAME(),new Integer(STATEID),work[0].getPRIORITY(),work[0].getFILENAME(),cur_user);

	response.sendRedirect("../worklist.jsp?WORKFLOWID="+workflow[0].getWORKFLOWID());
%>