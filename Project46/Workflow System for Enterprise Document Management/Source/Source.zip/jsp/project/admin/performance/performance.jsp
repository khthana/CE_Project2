<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(" "," ");
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>
<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<table width="100%">
  <tr> 
    <td  colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class= "head"><strong>Performance & Work Management</strong></td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td class= "head" width="97%">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td> <div align="left"></div>
<form action="" method="post" name="perform">
        <table width="67%">
          <tr> 
            <td width="24%" class ="submit"><div align="center">Workflow</div></td>
            <td width="14%" class ="submit"><div align="center">Performance</div></td>
            <td width="19%" class ="submit"><div align="center">Work management</div></td>
          </tr>
          <%
	for(int i=0;i<workflow.length;i++){
%>
          <tr> 
            <td  bordercolor="#CCCCCC" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><%=workflow[i].getWORKFLOWNAME()%></div></td>
            <td><div align="center"> 
                <input type="button" value="Performance" onClick="go('perform','<%=workflow[i].getWORKFLOWID()%>')">
              </div></td>
            <td><div align="center"> 
                <input type="button" value="Work management" onClick="go('work','<%=workflow[i].getWORKFLOWID()%>')">
              </div></td>
          </tr>
          <%
	}//for
%>
        </table>
</form>	  
	  </td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.perform
	function go(x,name){
		if (x=='perform'){
			doc.action = "perform1.jsp?WORKFLOWID="+name
		}else {
			doc.action = "worklist.jsp?WORKFLOWID="+name
		}
		doc.submit();
	}
-->
</SCRIPT>
