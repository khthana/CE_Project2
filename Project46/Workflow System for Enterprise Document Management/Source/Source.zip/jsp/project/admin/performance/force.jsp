<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%@ page language="java" import="java.text.*"%>
<%@ page import="java.util.Locale"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy",Locale.US);

	String WORKID = thaistring.MS874ToUnicode(request.getParameter("WORKID"));
	if (WORKID==null){
		WORKID = "";
	}
	
	String keyword = " where WORKID="+WORKID+" ";
	mybean.Work work[];
	work = adminpower.readwork.getWork(keyword," ");

	mybean.LogWork logwork[];
	logwork = adminpower.readlogwork.getLogWork(keyword," ");

	String keyword1 = " where STATEID="+work[0].getSTATEID()+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword1," ");
	
	String keyword2 = " where WORKFLOWID="+state[0].getWORKFLOWID()+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword2," ");
	mybean.State allstate[];
	allstate = adminpower.readstate.getState(keyword2," ");
	
	String keyword3 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword3," ");

	mybean.Attribute attribute[];
	attribute = adminpower.readattribute.getAttribute(keyword3," ");

%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
  
<table width="100%">
  <tr> 
    <td  colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td width="97%" >
      <form name="force" method="post" action="script/force_s.jsp">
	  <input type="hidden" name="WORKID" value="<%=WORKID%>">
        <table  class="menu" width="100%" border="0">
          <tr> 
            <td class="head"><strong>Work Management</strong></td>
            <td >&nbsp; </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td><strong>Coming date :</strong></td>
            <td><%if(logwork.length==0){out.print(dateFormat.format(work[0].getCREATED_DATE()));}else{out.print(dateFormat.format(logwork[logwork.length-1].getTIMEAFTER()));}%></td>
          </tr>
          <tr> 
            <td width="33%"><b>Work name : </b></td>
            <td width="67%"><%=work[0].getWORKNAME()%></td>
          </tr>
          <tr> 
            <td><b>Priority : </b></td>
            <td><%=work[0].getPRIORITY()%></td>
          </tr>
          <tr> 
            <td><b>Taken User : </b></td>
            <td><%if(work[0].getUSERNAME()!=null){out.print(work[0].getUSERNAME());}%></td>
          </tr>
          <tr> 
            <td><b>Taken Date : </b></td>
            <td><%if(work[0].getTAKEN_DATE()!=null){out.print(dateFormat.format(work[0].getTAKEN_DATE()));}%></td>
          </tr>
          <tr> 
            <td><b>Created By : </b></td>
            <td><%=work[0].getCREATED_BY()%></td>
          </tr>
          <tr> 
            <td><b>Created Date : </b></td>
            <td><%=dateFormat.format(work[0].getCREATED_DATE())%></td>
          </tr>
          <tr> 
            <td><b>Workflow name : </b></td>
            <td><%=workflow[0].getWORKFLOWNAME()%></td>
          </tr>
          <tr> 
            <td width="33%"><b>Document type Name : </b></td>
            <td width="67%"><%=documenttype[0].getDOCUMENTTYPENAME()%></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="81" colspan="2"> <table width="68%"  class="box">
                <tr class="submit"> 
                  <td width="49%" height="19"><div align="center"><strong>Attribute 
                      Name</strong></div></td>
                  <td ><div align="center"><strong>Type</strong></div></td>
                  <td  ><div align="center"><strong>Value</strong></div></td>
                </tr>
<%
	for(int i=0;i<attribute.length;i++){
		String keyword4 = " where WORKID="+WORKID+" and ATTRIBUTEID="+attribute[i].getATTRIBUTEID()+" ";
		mybean.WorkAttribute workattribute[];
		workattribute = adminpower.readworkattribute.getWorkAttribute(keyword4," ");
%>
				<tr> 
                  <td width="49%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><b><%=attribute[i].getATTRIBUTENAME()%></b></td>
					<td width="51%">
<%
		if(attribute[i].getATTRIBUTETYPE().equals("1")){
			  out.println("Integer");
		}//if
		else if(attribute[i].getATTRIBUTETYPE().equals("2")){
			  out.println("Date");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("3")){
			  out.println("Bool");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("4")){
			  out.println("String");
		}//else
		else if(attribute[i].getATTRIBUTETYPE().equals("5")){
			  out.println("Char");
		}//else
%>
					</td>
                  <td width="51%" > <input type="text" name="ATT_VALUE" value="<%if(workattribute.length>0){out.print(workattribute[0].getATT_VALUE());}%>" <%if(attribute[i].getATTRIBUTETYPE().equals("5")){out.print("maxlength=\"1\"");}%>> 
                  </td>
                </tr>
<%
	}//for i
%>
<%
	if(work[0].getFILENAME()!=null){
%>
				<tr> 
                  <td colspan="3" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="right"><a href="../../upload/<%=work[0].getFILENAME()%>"><img src="folder.jpg" width="16" height="13"><%=work[0].getFILENAME()%></a></div></td>
                </tr>
<%
	}//if
%>
              </table></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>

          <tr> 
            <td colspan="2" height="71" > <table width="80%" class="box">
                <tr class="submit"> 
                  <td width="8%" height="21">&nbsp;</td>
                  <td width="51%" height="21"> <div align="center"><strong>State 
                      name</strong></div></td>
                  <td width="41%" height="21"> <div align="center"><strong>State 
                      type</strong></div></td>
                </tr>
<%
	for(int i=0;i<allstate.length;i++){
%>
				<tr> 
                  <td width="8%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="radio" name="STATEID" value="<%=allstate[i].getSTATEID()%>" <%if(allstate[i].getSTATEID().equals(state[0].getSTATEID())){out.print("checked");}%>>
                    </div></td>
                  <td width="51%" > <div align="center"><%=allstate[i].getSTATENAME()%></div></td>
                  <td width="41%"> <div align="center">
<%
		if(allstate[i].getSTATETYPE().equals("1")){
			  out.println("Start");
		}//if
		else if(allstate[i].getSTATETYPE().equals("2")){
			  out.println("Normal");
		}//else
		else if(allstate[i].getSTATETYPE().equals("3")){
			  out.println("Final");
		}//else
%>
				  </div></td>
                </tr>
<%
	}//for i
%>
              </table></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td colspan="2"><b> </b> <div align="right"> 
<%
	if(!(state[0].getSTATETYPE().equals("3"))){
%>
                <input type="button" name="Submit4" value="  OK  " onClick="if(checknull()){}else{check();}">
<%
	}//if
%>
                <input type="button" name="Submit2222" value="Cancel" onClick="window.location='worklist.jsp?WORKFLOWID=<%=workflow[0].getWORKFLOWID()%>'">
<%
	if(!(state[0].getSTATETYPE().equals("3"))){
%>
                <input type="reset" name="Submit22" value="Reset">
<%
	}//if
%>
              </div></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.force
<%
	for(int p=0;p<attribute.length;p++){
		if((attribute.length==1)&&(p==0)){
			out.println("var "+attribute[p].getATTRIBUTENAME()+" = document.force.ATT_VALUE");
		}//if
		else{
			out.println("var "+attribute[p].getATTRIBUTENAME()+" = document.force.ATT_VALUE["+p+"]");
		}//else
	}//for p
%>
function checknull(){
	if(1==0){
	}//if
<%
	for(int k=0;k<attribute.length;k++){
		if(attribute[k].getATTRIBUTETYPE().equals("1")){
			out.println("else if(("+attribute[k].getATTRIBUTENAME()+".value!='')&&(isNaN("+attribute[k].getATTRIBUTENAME()+".value))){alert('Please insert "+attribute[k].getATTRIBUTENAME()+" into number format');return true;}");
		}//if
		else if(attribute[k].getATTRIBUTETYPE().equals("3")){
			out.println("else if(("+attribute[k].getATTRIBUTENAME()+".value!='')&&(!(("+attribute[k].getATTRIBUTENAME()+".value=='y')||("+attribute[k].getATTRIBUTENAME()+".value=='n')))){alert('Please insert "+attribute[k].getATTRIBUTENAME()+" into y or n');return true;}");
		}//else
	}//for k
%>
	else{
		return false;
	}//else
}//function
function isallspace(src){
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++){
		if (src.charAt(i)!=' '){
			return false;
		}//if
	}//for
	return true;
}//function
function specialchar(scr){
	var i=0;
	for (i=0;i<scr.length;i++){
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\='){
			return true;
		}//if
	}//for
	return false;
}//function
function check (){
	doc.submit()
}
-->
</SCRIPT>
