<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%@ page language="java" import="java.text.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="java.util.Locale"%>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy",Locale.US);
	SimpleDateFormat sqldateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);

	String todate = thaistring.MS874ToUnicode(request.getParameter("todate"));
	if (todate==null){
		todate = "";
	}
	String todate_formatted = sqldateFormat.format(dateFormat.parse(todate));
	Date todate_date = Date.valueOf(todate_formatted);
	
	String fromdate = thaistring.MS874ToUnicode(request.getParameter("fromdate"));
	if (fromdate==null){
		fromdate = "";
	}
	String fromdate_formatted = sqldateFormat.format(dateFormat.parse(fromdate));
	Date fromdate_date = Date.valueOf(fromdate_formatted);

	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	if (STATEID==null){
		STATEID = "";
	}

	String keyword = " where STATEID="+STATEID+" ";

	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

	String keyword1 = " where WORKFLOWID="+state[0].getWORKFLOWID()+" ";

	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword1," ");

	//get log �Ҥӹǳ
//	int workintime,workouttime;
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<form name="perform" method="post" action="force.jsp">
  <table width="100%">
    <tr> 
      <td  colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td class= "head"><strong>Performance Monitoring</strong></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td class= "head">&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td >
<table width="75%">
          <tr> 
            <td width="23%">Workflow name :</td>
            <td width="77%"><strong><%=workflow[0].getWORKFLOWNAME()%></strong></td>
          </tr>
          <tr> 
            <td>State name :</td>
            <td><strong><%=state[0].getSTATENAME()%></strong></td>
          </tr>
          <tr> 
            <td> From :</td>
            <td><%=dateFormat.format(fromdate_date)%></td>
          </tr>
          <tr> 
            <td>To : </td>
            <td><%=dateFormat.format(todate_date)%></td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td width="3%">&nbsp;</td>
      <td class= "head" width="97%">&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td > 
        <table class="box" width="48%">
          <tr  class="submit"> 
            <td  ><div align="center"><strong>Work State</strong></div></td>
            <td><div align="center"><strong>Numbers</strong></div></td>
          </tr>
          <tr> 
            <td width="69%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center">Work in</div></td>
            <td width="31%"><div align="center"><%=state[0].getNumberWorkinState(fromdate_date,todate_date)%></div></td>
          </tr>
          <tr> 
            <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center">Work out (intime)</div></td>
            <td><div align="center"><%=state[0].getNumberWorkoutStateintime(fromdate_date,todate_date)%></div></td>
          </tr>
          <tr> 
            <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center">Work out (late)</div></td>
            <td><div align="center"><%=state[0].getNumberWorkoutStatelate(fromdate_date,todate_date)%></div></td>
          </tr>
          <tr> 
            <td onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center">Still in state</div></td>
            <td><div align="center"><%=(state[0].getNumberWorkinState(fromdate_date,todate_date) - state[0].getNumberWorkoutStateintime(fromdate_date,todate_date) - state[0].getNumberWorkoutStatelate(fromdate_date,todate_date))%></div></td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td></td>
      <td><p align="right"> 
          <input name="Back" type="button" id="Back" value="Back" onClick="window.location='perform1.jsp?WORKFLOWID=<%=state[0].getWORKFLOWID()%>'">
        </p></td>
    </tr>
  </table>
</form>
</body>
</html>
