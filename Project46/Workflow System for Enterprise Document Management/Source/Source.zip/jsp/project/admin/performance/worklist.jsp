<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");

	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
  
<table width="100%">
  <tr> 
    <td  colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td width="97%" >
      <form name="work" method="post" action="force_s.jsp">
        <table  class="menu" width="100%" border="0">
          <tr> 
            <td colspan="2" class="head"><strong>Please select work 
              name</strong></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td width="26%"><strong>Workflow Name : </strong></td>
            <td width="74%"><b><%=workflow[0].getWORKFLOWNAME()%></b></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="90" colspan="2" > <table class="box" width="51%">
                <tr class="submit"> 
                  <td width="42%" ><div align="center"><strong>State name</strong></div></td>
                  <td ><div align="center"><strong>Work name</strong></div></td>
                </tr>
<%
	for(int i=0;i<state.length;i++){
		String keyword1 = " where STATEID="+state[i].getSTATEID()+" ";
		mybean.Work work[];
		work = adminpower.readwork.getWork(keyword1," ");
%>
                <tr> 
                  <td width="42%" class="submit" ><%=state[i].getSTATENAME()%></div></td>
                  <td width="58%" bgcolor=#EEEEEE onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);>&nbsp; </td>
                </tr>
<%
		for(int j=0;j<work.length;j++){
%>
				<tr> 
                  <td>&nbsp;</td>
                  <td bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); ><a href="force.jsp?WORKID=<%=work[j].getWORKID()%>"><%if(work[j].ISLATE()){out.print("<font color=\"#CC0000\">");}%><%=work[j].getWORKNAME()%><%if(work[j].ISLATE()){out.print("</font>");}%></a></td>
                </tr>
<%
		}//for j
	}//for i
%>
			  </table></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp; </td>
          </tr>
          <tr> 
            <td colspan="2"><b> </b> <div align="right"> 
                <input type="button" value=" Back " onClick="window.location='performance.jsp'">
              </div></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>

