<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";

	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");

	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<form name="perform" method="post" action="perform2.jsp">
  <table width="100%">
    <tr> 
      <td  colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td class= "head"><strong>Performance </strong></td>
    </tr>
    <tr> 
      <td height="24">&nbsp;</td>
      <td class= "head">&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td> <table width="57%">
          <tr> 
            <td>From (dd/mm/yy): </td>
            <td><input name="fromdate" type="text" size="15" maxlength="8" width="15"></td>
          </tr>
          <tr> 
            <td>To (dd/mm/yy):</td>
            <td><input name="todate" type="text" size="15" maxlength="8" width="15"></td>
          </tr>
          <tr> 
            <td>Workflow : </td>
            <td><%=workflow[0].getWORKFLOWNAME()%></td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td width="3%" height="27">&nbsp;</td>
      <td  width="97%">&nbsp; </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td> <div align="left"></div>
        <table width="40%">
          <tr> 
            <td width="7%" class ="submit"><div align="center"></div></td>
            <td width="60%" class ="submit"><div align="center">State name</div></td>
          </tr>
<%
	for(int i=0;i<state.length;i++){
		if(!(state[i].getSTATETYPE().equals("3"))){
%>
          <tr> 
            <td  bordercolor="#CCCCCC" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                <input name="STATEID" type="radio" value="<%=state[i].getSTATEID()%>">
              </div></td>
            <td> <div align="center"><%=state[i].getSTATENAME()%></div></td>
          </tr>
<%
		}//if
	}//for i
%>
        </table></td>
    </tr>
    <tr> 
      <td height="27">&nbsp;</td>
      <td><div align="right">
          <input type="button" value="Submit" onClick="if(check_date()){document.perform.submit();}">
          <input type="button" value="Cancel" onClick="window.location='performance.jsp'">
          <input type="reset" value="Reset">
       </div></td>
    </tr>
  </table>
</form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.perform
	function check_date(){
		var arr = doc.fromdate.value.split ("/");
		var flag = false;
		if ((arr.length == 3)&&(arr[0]!="")&&(arr[1]!="")&&(arr[2]!="")&&(!isNaN(arr[0]))&&(!isNaN(arr[1]))&&(!isNaN(arr[2]))){
			var date_from = arr[0];
			var month_from =  arr[1];
			var year_from =  arr[2];
			if ((parseInt(date_from,10) >0)){
				if (parseInt(month_from,10) == 2){
					if (parseInt(date_from,10) > 29){
						alert  ("��س�����ѹ������١��ͧ");return false;
					}
				}else if((parseInt(month_from,10) == 1)||(parseInt(month_from,10) == 3)||(parseInt(month_from,10) == 5)||(parseInt(month_from,10) == 7)||(parseInt(month_from,10) == 8)||(parseInt(month_from,10) == 10)||(parseInt(month_from,10) == 12)){
					if (parseInt(date_from,10) > 31){
						alert  ("��س�����ѹ������١��ͧ 1-31");return false;
					}
				}else{
					if (parseInt(date_from,10) > 30){
						alert  ("��س�����ѹ������١��ͧ 1-30");return false;
					}			
				}
			}else{
				alert("��س�����ѹ������١��ͧ");return false;
			}
			if ((parseInt(month_from,10) >13)||(parseInt(month_from,10) <0)){
				alert("��س������͹���١��ͧ 1-12");return false;
			}
			if ((parseInt(year_from,10) >100)||(parseInt(year_from,10) <0)){
				alert("��س��ʻ����١��ͧ 1-99");return false;
			}
		}else{
			alert  ("��س�����ѹ���١��ͧ��� format dd/mm/yy");return false;
		}
		doc.fromdate.focus();
		doc.fromdate.blur();
		doc.fromdate.select();

		arr = doc.todate.value.split ("/");
		if ((arr.length == 3)&&(arr[0]!="")&&(arr[1]!="")&&(arr[2]!="")&&(!isNaN(arr[0]))&&(!isNaN(arr[1]))&&(!isNaN(arr[2]))){
			var date_to = arr[0];
			var month_to =  arr[1];
			var year_to =  arr[2];
			if ((parseInt(date_to,10) >0)){
				if (parseInt(month_to,10) == 2){
					if (parseInt(date_to,10) > 29){
						alert  ("��س�����ѹ������١��ͧ");return false;
					}
				}else if((parseInt(month_to,10) == 1)||(parseInt(month_to,10) == 3)||(parseInt(month_to,10) == 5)||(parseInt(month_to,10) == 7)||(parseInt(month_to,10) == 8)||(parseInt(month_to,10) == 10)||(parseInt(month_to,10) == 12)){
					if (parseInt(date_to,10) > 31){
						alert  ("��س�����ѹ������١��ͧ 1-31");return false;
					}
				}else{
					if (parseInt(date_to,10) > 30){
						alert  ("��س�����ѹ������١��ͧ 1-30");return false;
					}			
				}
			}else{
				alert("��س�����ѹ������١��ͧ");return false;
			}
			if ((parseInt(month_to,10) >13)||(parseInt(month_to,10) <0)){
				alert("��س������͹���١��ͧ 1-12");return false;
			}
			if ((parseInt(year_to,10) >100)||(parseInt(year_to,10) <0)){
				alert("��س��ʻ����١��ͧ 1-99");return false;
			}
		}else{
			alert  ("��س�����ѹ���١��ͧ��� format dd/mm/yy");return false;
		}
		if (parseInt(year_from,10)<=parseInt(year_to,10)){
		//	flag = true
			if (parseInt(month_from,10)<=parseInt(month_to,10)){
		//		flag = true;
				if (parseInt(date_from,10)<=parseInt(date_to,10)){
					flag = true;
				}else{
					alert  ("��س�����ѹ��������ҡ�����ѹ�ش����");flag=false;return false;
				}
			}else{
	//			if (flag == false){
					alert  ("��س�����ѹ��������ҡ�����ѹ�ش����");flag=false;return false;
	//			}
			}
		}else{
			alert  ("��س�����ѹ��������ҡ�����ѹ�ش����");flag=false;return false;
		}
/*	if (doc.STATEID != undefined){
		if (boxCount == undefined) {
			if (doc.STATEID.checked) {
				return true;
			doc.submit();
			} else {
				alert ("��س����͡ State name");return false;
				return false;
			}
		}*/
	if (flag == true){
		return true;
	}
	}
-->
</SCRIPT>