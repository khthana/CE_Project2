<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("http://161.246.6.90:8080/project/admin/index.jsp");
	}
%>
<SCRIPT language=JavaScript>
<!-- Begin
var day="";
var month="";
var myweekday="";
var year="";
mydate = new Date();
myday = mydate.getDay();
mymonth = mydate.getMonth();
myweekday= mydate.getDate();
weekday= myweekday;
myyear= mydate.getYear();
year = myyear
if(myday == 0)
day = " Sunday, "      
else if(myday == 1)
day = " Monday, "
else if(myday == 2)
day = " Tuesday, "   
else if(myday == 3)
day = " Wednesday, "   
else if(myday == 4)
day = " Thursday, "
else if(myday == 5)
day = " Friday, "
else if(myday == 6)
day = " Saturday, "
if(mymonth == 0) {
month = "January "}
else if(mymonth ==1)
month = "February "
else if(mymonth ==2)
month = "March "
else if(mymonth ==3)
month = "April "
else if(mymonth ==4)
month = "May "
else if(mymonth ==5)
month = "June "
else if(mymonth ==6)
month = "July "
else if(mymonth ==7)
month = "August "
else if(mymonth ==8)
month = "September "
else if(mymonth ==9)
month = "October "
else if(mymonth ==10)
month = "November "
else if(mymonth ==11)
month = "December "
// End -->
</SCRIPT>
<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
-->
</style>
</head>

<body bgcolor="#cc0000" text="#FFFFFF">
<div align="right">
  <SCRIPT>
document.write(""+ day + month);
document.write(myweekday + "");
</SCRIPT>
      </div>
</body>
</html>