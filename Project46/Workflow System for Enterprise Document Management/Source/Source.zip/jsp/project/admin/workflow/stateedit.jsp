<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<% 
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

%>
<form name="stateedit" method="post" action="stateedit2.jsp">
	<input type="hidden" name="WORKFLOWID" value="<%=WORKFLOWID%>">
<% 
	for(int i=0;i<state.length;i++){
		out.println("<input type=\"hidden\" name=\"STATEID_OLD\" value=\""+state[i].getSTATEID()+"\" >");
		out.println("<input type=\"hidden\" name=\"STATENAME_OLD\" value=\""+state[i].getSTATENAME()+"\" >");
		out.println("<input type=\"hidden\" name=\"STATETYPE_OLD\" value=\""+state[i].getSTATETYPE()+"\" >");
		out.println("<input type=\"hidden\" name=\"WORK_TIME_OLD\" value=\""+state[i].getWORK_TIME()+"\" >");

//		out.println("STATEID_OLD="+state[i].getSTATEID()+"<br>");
//		out.println("STATENAME_OLD="+state[i].getSTATENAME()+"<br>");
//		out.println("STATETYPE_OLD="+state[i].getSTATETYPE()+"<br>");
//		out.println("WORK_TIME_OLD="+state[i].getWORK_TIME()+"<br>");
	
	}
%>
</form>

<body>

<script language="JavaScript">
<!--Script 
	document.stateedit.submit();
//-->
</script>

</body>
