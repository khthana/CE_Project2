<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<% 
	String WORKFLOWID=thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	String STATEID_OLD[]=request.getParameterValues("STATEID_OLD");
	String STATENAME[]=request.getParameterValues("STATENAME");
	String STATENAME_OLD[]=request.getParameterValues("STATENAME_OLD");
	String flag=request.getParameter("flag");
	String tmp=request.getParameter("tmp");
	String tmp_old=request.getParameter("tmp_old");
	String STATETYPE[]=request.getParameterValues("STATETYPE"); 
	String STATETYPE_OLD[]=request.getParameterValues("STATETYPE_OLD"); 
	String WORK_TIME_OLD[]=request.getParameterValues("WORK_TIME_OLD");
	String WORK_TIME[]=request.getParameterValues("WORK_TIME");

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");

	String keyword1 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.Attribute attribute[];
	attribute = adminpower.readattribute.getAttribute(keyword1," ");

	String keyword2 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword1," ");

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit State</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="stateedit" method="post" action="script/stateedit2_s.jsp">
<input type="hidden" name="WORKFLOWID" value="<%=WORKFLOWID%>">
        <table width="100%" border="0">
          <tr> 
            <td width="38%"><b>Workflow Name : </b></td>
            <td width="62%"><b><font color="#666666" size="5"><%=workflow[0].getWORKFLOWNAME()%></font></b></td>
          </tr>
          <tr> 
            <td width="38%">&nbsp;</td>
            <td width="62%">&nbsp;</td>
          </tr>
          <tr> 
            <td width="38%"><b>Document type Name : </b></td>
            <td width="62%"><b><font color="#666666"><%=documenttype[0].getDOCUMENTTYPENAME()%></font></b></td>
          </tr>
          <tr> 
            <td width="38%" height="27">&nbsp;</td>
            <td width="62%" height="27">&nbsp;</td>
          </tr>
          <tr> 
            <td colspan="2" height="75"> <table width="54%" class="box">
                <tr class="submit"> 
                  <td width="49%" height="27">Attribute Name</td>
                  <td width="51%" height="27">Type</td>
                </tr>
<%
	for(int i=0;i<attribute.length;i++){
%>
                <tr> 
                  <td width="49%"   bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><b><%=attribute[i].getATTRIBUTENAME()%></b></td>
                  <td width="51%" ><font color="#000000">
				<%
					if(attribute[i].getATTRIBUTETYPE().equals("1")){
						out.print("Integer");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("2")){
						out.print("Date");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("3")){
						out.print("Bool");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("4")){
						out.print("String");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("5")){
						out.print("Char");
					}
				%>
			  </font></td>
                </tr>
<%
	}//for
%>
              </table></td>
          </tr>
          <tr> 
            <td colspan="2"><b> </b> </td>
          </tr>
          <tr> 
            <td colspan="2"> <b>State</b> 
<table width="100%" class="box">
                <tr class="submit"> 
                  <td width="50%" height="25"> <div align="center">State name</div></td>
                  <td width="32%"><div align="center">State</div></td>
                  <td width="18%"><div align="center">Work time (days)</div></td>
                  <td width="18%" height="25">&nbsp;</td>
                </tr>
                <%
	int a = 0;int b = 0;
	if (STATENAME_OLD!=null){
			for(a = 0;a<STATENAME_OLD.length;a++){
				STATENAME_OLD[a] = thaistring.MS874ToUnicode(STATENAME_OLD[a]);
				STATETYPE_OLD[a] = thaistring.MS874ToUnicode(STATETYPE_OLD[a]);
				if(tmp_old==null){tmp_old="";}
				if (!(tmp_old.equals(String.valueOf(a)))){  
%>
                <tr> 
                  <td height="26" bordercolor="#333333" bgcolor="#eeeeee"><div align="center"><b> 
					  <input type="hidden" name="STATEID_OLD" value="<%=STATEID_OLD[a]%>">
                      <input name="STATENAME_OLD" type="text" value="<%=STATENAME_OLD[a]%>" size="50" >
                      </b></div></td>
                  <td width="32%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center">
                      <select name="STATETYPE_OLD"  >
                        <option value="1" <%if(STATETYPE_OLD!=null){if(STATETYPE_OLD[a].equals("1")){out.print("selected");}}%>>Start</option>
                        <option value="2" <%if(STATETYPE_OLD!=null){if(STATETYPE_OLD[a].equals("2")){out.print("selected");}}%>>Normal</option>
                        <option value="3" <%if(STATETYPE_OLD!=null){if(STATETYPE_OLD[a].equals("3")){out.print("selected");}}%>>Final</option>
                      </select>
                    </div></td>
                  <td bordercolor="#333333" bgcolor="eeeeee"><input name="WORK_TIME_OLD" type="text" value="<%=WORK_TIME_OLD[a]%>"></td>
                  <%
		b = a;
		if(!(tmp_old.equals("")) && Integer.parseInt(tmp_old,10)<=a){
			b--;
		}
%>
                  <td height="26" bordercolor="#333333" bgcolor="eeeeee"> <div align="center"> 
                      <input name="delete_old" type="button" id="delete_old" onClick="godelete_old(<%=b%>)" value="Delete">
                    </div></td>
                </tr>
                <%		}//if
		}//for	
	}//if

	int i = 0;int j=0;
	if (STATENAME!=null){
			for(i = 0;i<STATENAME.length;i++){
				STATENAME[i] = thaistring.MS874ToUnicode(STATENAME[i]);
				STATETYPE[i] = thaistring.MS874ToUnicode(STATETYPE[i]);
				if (!(tmp.equals(String.valueOf(i) ) ) ){
%>
                <tr> 
                  <td  bgcolor=#eeeeee > <div align="center"> 
                      <input name="STATENAME" type="text" value="<%=STATENAME[i]%>" size="50">
                    </div></td>
                  <td width="32%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center"> 
                      <select name="STATETYPE" >
                        <option value="1" <%if(STATETYPE[i].equals("1")){out.print("selected");}%>>Start</option>
                        <option value="2" <%if(STATETYPE[i].equals("2")){out.print("selected");}%>>Normal</option>
                        <option value="3" <%if(STATETYPE[i].equals("3")){out.print("selected");}%>>Final</option>
                      </select>
                    </div></td>
                  <td width="18%" bgcolor="eeeeee"><input name="WORK_TIME" type="text" value="<%=WORK_TIME[i]%>"></td>
                  <%
				j = i;
				if(!(tmp.equals("")) && Integer.parseInt(tmp,10)<=i){
					j--;
				}//if
%>
                  <td width="18%" bgcolor="eeeeee"> <div align="center"><b> 
                      <%if (STATENAME!=null){ if(tmp.equals("")&&(STATENAME.length>1)){ ++j;}}%>
                      <input type="button" name="Submit32" value="Delete" onClick="godelete(<%=j%>)">
                      </b></div></td>
                </tr>
                <%
			}//if
		}//for	
	}//if
	if (flag!=null && flag.equals("add")){
%>
                <tr> 
                  <td  bgcolor=#eeeeee > <div align="center"> 
                      <input name="STATENAME" type="text" value="" size="50">
                    </div></td>
                  <td width="32%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><div align="center"> 
                      <select name="STATETYPE"  >
                        <option value="1">Start</option>
                        <option value="2">Normal</option>
                        <option value="3">Final</option>
                      </select>
                    </div></td>
                  <td width="18%" bgcolor="eeeeee"><input name="WORK_TIME" type="text"></td>
                  <td width="18%" bgcolor="eeeeee"> <div align="center"><b> 
                      <input type="button" name="Submit32" value="Delete" onClick="godelete(<%=j%>)">
                      </b></div></td>
                </tr>
                <%
	}//if
%>
                <tr> 
                  <td colspan="4"><b> 
                    <input type="button" name="Submit3" value="Add" onClick="goadd()">
                    </b></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td colspan="2"><b> </b> <div align="right"> 
                <input type="button" name="Submit4" value="  OK  " onClick="checknull()">
                <input type="reset" name="Submit22" value="Reset">
                <input type="button" name="Submit42" value="Cancel" onClick="window.location='wfedit.jsp'">
              </div></td>
          </tr>
        </table>
   </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.stateedit
	function checknull(){
	var flag = false;
	if (doc.STATENAME != null){
			if (doc.STATENAME.length>1){
				for (var i=0;i<doc.STATENAME.length;i++){
					if (doc.STATENAME[i].value == '' || (doc.STATENAME[i].value!='' && isallspace(doc.STATENAME[i].value)) ){
						alert("Please insert State name!!!");flag = true;return true;}//if
					else if (specialchar(doc.STATENAME[i].value))
						{alert('The specific State name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 		
				}//for
			}else{
				if (doc.STATENAME.value == '' || (doc.STATENAME.value!='' && isallspace(doc.STATENAME.value)) ){
						alert("Please insert State name!!!");flag = true;return true;}//if
				else if (specialchar(doc.STATENAME.value))
						{alert('The specific State name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 	
			}
	}if (flag == false){
		doc.submit();
	}
	}
	function isallspace(src)
	{
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}
		return true;
	}
	function goadd(j){
		doc.action = "stateedit2.jsp?WORKFLOWID=<%=WORKFLOWID%>&flag=add&tmp=";
		doc.submit();
	}
	function  godelete(i){
		doc.action = "stateedit2.jsp?WORKFLOWID=<%=WORKFLOWID%>&tmp="+i;
		doc.submit();
	}
	function  godelete_old(i){
		doc.action = "stateedit2.jsp?tmp=&tmp_old="+i;
		doc.submit();
	}
	function specialchar(scr)
	{
		var i=0;
		for (i=0;i<scr.length;i++)
		{
			if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
			{
				return true;
			}
		}
	}
-->
</SCRIPT>