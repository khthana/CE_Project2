<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<% 
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}

	String keyword = " where DOCUMENTTYPEID="+DOCUMENTTYPEID+" ";
	mybean.Attribute attribute[];
	attribute = adminpower.readattribute.getAttribute(keyword," ");

%>
<form name="doctypeattr" method="post" action="doctypeattr2.jsp">
	<input type="hidden" name="DOCUMENTTYPEID" value="<%=DOCUMENTTYPEID%>">
<% 
	for(int i=0;i<attribute.length;i++){
		out.println("<input type=\"hidden\" name=\"ATTRIBUTEID_OLD\" value=\""+attribute[i].getATTRIBUTEID()+"\" >");
		out.println("<input type=\"hidden\" name=\"ATTRIBUTENAME_OLD\" value=\""+attribute[i].getATTRIBUTENAME()+"\" >");
		out.println("<input type=\"hidden\" name=\"ATTRIBUTETYPE_OLD\" value=\""+attribute[i].getATTRIBUTETYPE()+"\" >");
	}
%>
</form>

<body>

<script language="JavaScript">
<!--Script 
	document.doctypeattr.submit();
//-->
</script>

</body>
