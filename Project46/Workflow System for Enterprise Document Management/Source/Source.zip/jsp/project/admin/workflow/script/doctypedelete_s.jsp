<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String DOCUMENTTYPEID[] = request.getParameterValues("DOCUMENTTYPEID");
	for (int i = 0;i<DOCUMENTTYPEID.length;i++){
		DOCUMENTTYPEID[i] = thaistring.MS874ToUnicode(DOCUMENTTYPEID[i]);
		adminpower.writedocumenttype.deleteDocumentType(new Integer(DOCUMENTTYPEID[i]));
	}//for
	response.sendRedirect("../doctypedelete.jsp");
%>