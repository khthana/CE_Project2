<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<% 
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	if (STATEID==null){
		STATEID = "";
	}

	String keyword = " where STATEID="+STATEID+" ";
	mybean.Condition condition[];
	condition = adminpower.readcondition.getCondition(keyword," ");
	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

%>
<form name="condedit" method="post" action="condedit2.jsp">
	<input type="hidden" name="STATEID" value="<%=STATEID%>">
	<input type="hidden" name="WORKFLOWID" value="<%=state[0].getWORKFLOWID()%>">
<% 
	for(int i=0;i<condition.length;i++){
		out.println("<input type=\"hidden\" name=\"CONDITIONID_OLD\" value=\""+condition[i].getCONDITIONID()+"\" >");
		out.println("<input type=\"hidden\" name=\"STATEMENT_OLD\" value=\""+condition[i].getSTATEMENT().replaceAll("\"","&quot;")+"\" >");
		out.println("<input type=\"hidden\" name=\"NEXTSTATEID_OLD\" value=\""+condition[i].getNEXTSTATEID()+"\" >");
	}
%>
</form>

<body>

<script language="JavaScript">
<!--Script 
	document.condedit.submit();
//-->
</script>

</body>
