<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String WORKFLOWNAME = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWNAME"));
	if (WORKFLOWNAME==null){
		WORKFLOWNAME = "";
	}
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}

	adminpower.writeworkflow.addWorkFlow(WORKFLOWNAME,new Integer(DOCUMENTTYPEID));

	String keyword = " where WORKFLOWNAME='"+WORKFLOWNAME+"' and DOCUMENTTYPEID="+DOCUMENTTYPEID;
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");
	response.sendRedirect("../stateedit.jsp?WORKFLOWID="+workflow[0].getWORKFLOWID());

%>
