<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	mybean.DocumentType unassigneddocumenttype[];
	unassigneddocumenttype = adminpower.readdocumenttype.getUnassignedDocumentType();
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Workflow create</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<form name="wfcreate" method="post" action="script/wfcreate_s.jsp">
  <table width="100%" border="0">
    <tr> 
      <td height="46">&nbsp;</td>
      <td colspan="3" class="head">&nbsp;</td>
    </tr>
    <tr> 
      <td width="9">&nbsp;</td>
      <td colspan="3" class="head"><strong>Create Workflow</strong></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr> 
      <td >&nbsp;</td>
      <td colspan="3"><table width="80%" border="0">
          <tr> 
            <td width="31%">Workflow name : * </td>
            <td width="69%"> <input type="text" name="WORKFLOWNAME"> </td>
          </tr>
          <tr> 
            <td width="31%">Document type : * </td>
            <td width="69%"> <select name="DOCUMENTTYPEID">
<%
	for(int i=0;i<unassigneddocumenttype.length;i++){
%>
				<option value="<%=unassigneddocumenttype[i].getDOCUMENTTYPEID()%>"><%=unassigneddocumenttype[i].getDOCUMENTTYPENAME()%></option>
<%
	}//for
%>
              </select> </td>
          </tr>
          <tr> 
            <td width="31%">&nbsp;</td>
            <td width="69%">&nbsp;</td>
          </tr>
          <tr> 
            <td width="31%">&nbsp;</td>
            <td width="69%"> <input type="button" name="Submit" value="  OK  " onClick="checknull()"> 
              <input type="button" name="Submit2" value="Cancel" onClick="window.location='workflow.jsp'"> 
              <input type="reset" name="Submit223" value="Reset" > </td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.wfcreate
	function checknull(){
	if  (doc.WORKFLOWNAME.value == ''||(doc.WORKFLOWNAME.value!='' && isallspace(doc.WORKFLOWNAME.value)) )
		{alert('Please enter Workflow Name !!!!'); return true;} 
	else if (specialchar(doc.WORKFLOWNAME.value))
					{alert('The specific workflow name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
}
-->
</SCRIPT>
