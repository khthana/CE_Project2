<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}

	String keyword = " where DOCUMENTTYPEID="+DOCUMENTTYPEID+" ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit workflow </strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="doctypecreate" method="post" action="script/doctypeedit2_s.jsp">
  <table width="100%" border="0">
    <tr> 
            <td width="35%">Document type Name : * </td>
      <td width="65%"><b> 
		<input type="hidden" name="DOCUMENTTYPEID" value="<%=documenttype[0].getDOCUMENTTYPEID()%>">
        <input type="text" name="DOCUMENTTYPENAME" value="<%=documenttype[0].getDOCUMENTTYPENAME()%>">
        </b></td>
    </tr>
    <tr> 
            <td width="35%">Description : </td>
      <td width="65%"> 
        <textarea name="DOCUMENTTYPEDESC" cols="50" rows="3"><%=documenttype[0].getDOCUMENTTYPEDESC()%></textarea>
      </td>
    </tr>
    <tr> 
      <td width="35%">&nbsp;</td>
      <td width="65%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="35%">&nbsp;</td>
            <td width="65%"> <div align="right">
                <input type="button" name="Submit4" value="  OK  " onClick="checknull()">
                <input type="reset" name="Submit22" value="Reset">
                <input type="button" name="Submit222" value="Cancel" onClick="window.location='doctypeedit.jsp'">
              </div></td>
    </tr>
  </table>
   </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.doctypecreate
	function checknull(){
	if  (doc.DOCUMENTTYPENAME.value == ''||(doc.DOCUMENTTYPENAME.value!='' && isallspace(doc.DOCUMENTTYPENAME.value)) )
		{alert('Please insert Document type name !!!!'); return true;} 
	else if (specialchar(doc.DOCUMENTTYPENAME.value))
		{alert('The specific Document type name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
}
-->
</SCRIPT>