<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");

	mybean.DocumentType unassigneddocumenttype[];
	unassigneddocumenttype = adminpower.readdocumenttype.getUnassignedDocumentType();

	mybean.DocumentType documenttype[];
	documenttype = workflow[0].getDOCUMENTTYPE();
%>
<%
	String message = "Are you sure you want to edit it? If you edit, all states of works will be null.";
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit workflow </strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="wfcreate" method="post" action="script/wfedit2_s.jsp">
        <table width="100%" border="0">
          <tr> 
            <td width="31%">Workflow name : *</td>
			<input type="hidden" name="WORKFLOWID" value="<%=workflow[0].getWORKFLOWID()%>">
            <td width="69%"> <input type="text" name="WORKFLOWNAME" value="<%=workflow[0].getWORKFLOWNAME()%>"> </td>
          </tr>
          <tr> 
            <td width="31%">Document type : </td>
            <td width="69%"> <select name="DOCUMENTTYPEID">
				<option value="<%=workflow[0].getDOCUMENTTYPEID()%>"><%=documenttype[0].getDOCUMENTTYPENAME()%></option>
<%
	for(int i=0;i<unassigneddocumenttype.length;i++){
%>
				<option value="<%=unassigneddocumenttype[i].getDOCUMENTTYPEID()%>"><%=unassigneddocumenttype[i].getDOCUMENTTYPENAME()%></option>
<%
	}//for
%>
              </select> </td>
          </tr>
          <tr> 
            <td width="31%">&nbsp;</td>
            <td width="69%">&nbsp;</td>
          </tr>
          <tr> 
            <td width="31%">&nbsp;</td>
            <td width="69%"> <div align="right">
                <input name="   OK   " type="button" id="   OK   " value="   OK   " onClick="if (confirm('<%= message%>')){checknull();}">
                <input type="reset" name="Submit22" value="Reset" >
                <input type="button" name="Submit2" value="Cancel" onClick="window.location='wfedit.jsp'">
              </div></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.wfcreate
	function checknull(){
	if  (doc.WORKFLOWNAME.value == ''||(doc.WORKFLOWNAME.value!='' && isallspace(doc.WORKFLOWNAME.value)) )
		{alert('Please enter Workflow Name !!!!'); return true;} 
	else if (specialchar(doc.WORKFLOWNAME.value))
					{alert('The specific workflow name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
}
-->
</SCRIPT>
