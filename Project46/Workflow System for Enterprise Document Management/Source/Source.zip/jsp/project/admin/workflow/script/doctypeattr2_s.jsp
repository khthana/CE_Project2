<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}

	String keyword = " where DOCUMENTTYPEID="+DOCUMENTTYPEID+" ";
	mybean.Attribute attribute_old[];
	attribute_old = adminpower.readattribute.getAttribute(keyword," ");

	String ATTRIBUTEID_OLD[]=request.getParameterValues("ATTRIBUTEID_OLD");
	String ATTRIBUTENAME_OLD[]=request.getParameterValues("ATTRIBUTENAME_OLD");
	String ATTRIBUTETYPE_OLD[]=request.getParameterValues("ATTRIBUTETYPE_OLD");
	String ATTRIBUTENAME[]=request.getParameterValues("ATTRIBUTENAME");
	String ATTRIBUTETYPE[]=request.getParameterValues("ATTRIBUTETYPE");

	if(ATTRIBUTEID_OLD!=null){
		for(int k=0;k<attribute_old.length;k++){
			boolean test = true;
			for(int i=0;i<ATTRIBUTENAME_OLD.length;i++){
				ATTRIBUTEID_OLD[i] = thaistring.MS874ToUnicode(ATTRIBUTEID_OLD[i]);
				ATTRIBUTENAME_OLD[i] = thaistring.MS874ToUnicode(ATTRIBUTENAME_OLD[i]);
				ATTRIBUTETYPE_OLD[i] = thaistring.MS874ToUnicode(ATTRIBUTETYPE_OLD[i]);
				if(ATTRIBUTEID_OLD[i].equals(attribute_old[k].getATTRIBUTEID().toString())){
					test = false;
					adminpower.writeattribute.editAttribute(attribute_old[k].getATTRIBUTEID(),new Integer(DOCUMENTTYPEID),ATTRIBUTENAME_OLD[i],ATTRIBUTETYPE_OLD[i]);
				}//if
			}//for i
			if(test){
				adminpower.writeattribute.deleteAttribute(attribute_old[k].getATTRIBUTEID());
			}//if
		}//for k
	}//if
	else{
		adminpower.writeattribute.deleteallAttribute(new Integer(DOCUMENTTYPEID));
	}//if


	if(ATTRIBUTENAME!=null){
		for(int i=0;i<ATTRIBUTENAME.length;i++){
			ATTRIBUTENAME[i] = thaistring.MS874ToUnicode(ATTRIBUTENAME[i]);
			ATTRIBUTETYPE[i] = thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]);
			adminpower.writeattribute.addAttribute(new Integer(DOCUMENTTYPEID),ATTRIBUTENAME[i],ATTRIBUTETYPE[i]);
		}//for i
	}//if

	response.sendRedirect("../doctypeedit.jsp");

%>
