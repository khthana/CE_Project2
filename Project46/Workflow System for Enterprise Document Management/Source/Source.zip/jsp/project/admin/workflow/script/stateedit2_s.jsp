<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.State state_old[];
	state_old = adminpower.readstate.getState(keyword," ");

	String STATEID_OLD[]=request.getParameterValues("STATEID_OLD");
	String STATENAME_OLD[]=request.getParameterValues("STATENAME_OLD");
	String STATETYPE_OLD[]=request.getParameterValues("STATETYPE_OLD");
	String WORK_TIME_OLD[]=request.getParameterValues("WORK_TIME_OLD");

	String STATENAME[]=request.getParameterValues("STATENAME");
	String STATETYPE[]=request.getParameterValues("STATETYPE");
	String WORK_TIME[]=request.getParameterValues("WORK_TIME");

	if(STATEID_OLD!=null){
		for(int k=0;k<state_old.length;k++){
			boolean test = true;
			for(int i=0;i<STATEID_OLD.length;i++){
				STATEID_OLD[i] = thaistring.MS874ToUnicode(STATEID_OLD[i]);
				STATENAME_OLD[i] = thaistring.MS874ToUnicode(STATENAME_OLD[i]);
				STATETYPE_OLD[i] = thaistring.MS874ToUnicode(STATETYPE_OLD[i]);
				WORK_TIME_OLD[i] = thaistring.MS874ToUnicode(WORK_TIME_OLD[i]);
				if(STATEID_OLD[i].equals(state_old[k].getSTATEID().toString())){
					test = false;
					adminpower.writestate.editState(state_old[k].getSTATEID(),STATENAME_OLD[i],STATETYPE_OLD[i],new Integer(WORKFLOWID),new Integer(WORK_TIME_OLD[i]));
				}//if
			}//for i
			if(test){
				adminpower.writestate.deleteState(state_old[k].getSTATEID());
			}//if
		}//for k
	}//if
	else{
		adminpower.writestate.deleteallState(new Integer(WORKFLOWID));
	}//if


	if(STATENAME!=null){
		for(int i=0;i<STATENAME.length;i++){
			STATENAME[i] = thaistring.MS874ToUnicode(STATENAME[i]);
			STATETYPE[i] = thaistring.MS874ToUnicode(STATETYPE[i]);
			WORK_TIME[i] = thaistring.MS874ToUnicode(WORK_TIME[i]);
			adminpower.writestate.addState(STATENAME[i],STATETYPE[i],new Integer(WORKFLOWID),new Integer(WORK_TIME[i]));
		}//for i
	}//if

	response.sendRedirect("../mapcondedit.jsp?WORKFLOWID="+WORKFLOWID);

%>
