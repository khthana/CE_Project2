<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}
	String DOCUMENTTYPENAME = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPENAME"));
	if (DOCUMENTTYPENAME==null){
		DOCUMENTTYPENAME = "";
	}
	String DOCUMENTTYPEDESC = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEDESC"));
	if (DOCUMENTTYPEDESC==null){
		DOCUMENTTYPEDESC = "";
	}
	adminpower.writedocumenttype.editDocumentType(new Integer(DOCUMENTTYPEID),DOCUMENTTYPENAME,DOCUMENTTYPEDESC);
	response.sendRedirect("../doctypeedit.jsp");
%>