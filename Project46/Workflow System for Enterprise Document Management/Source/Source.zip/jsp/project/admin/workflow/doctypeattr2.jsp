<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<% 
	String DOCUMENTTYPEID = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEID"));
	if (DOCUMENTTYPEID==null){
		DOCUMENTTYPEID = "";
	}

	String ATTRIBUTEID_OLD[]=request.getParameterValues("ATTRIBUTEID_OLD");
	String ATTRIBUTENAME_OLD[]=request.getParameterValues("ATTRIBUTENAME_OLD");
	String ATTRIBUTETYPE_OLD[]=request.getParameterValues("ATTRIBUTETYPE_OLD");

	String ATTRIBUTENAME[]=request.getParameterValues("ATTRIBUTENAME");
	String ATTRIBUTETYPE[]=request.getParameterValues("ATTRIBUTETYPE");

	String flag=request.getParameter("flag");
	String tmp=request.getParameter("tmp");
	String tmp_old=request.getParameter("tmp_old");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit document type attribute</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="doctypecreate" method="post" action="script/doctypeattr2_s.jsp">
        <table width="100%" border="0">
          <tr class="submit"> 
            <td width="26%" height="27">Attribute Name</td>
            <td width="26%" height="27">Type</td>
            <td width="27%" height="27">&nbsp;</td>
	<input type="hidden" name="DOCUMENTTYPEID" value="<%=DOCUMENTTYPEID%>">
          </tr>
<%
	int a = 0;int b = 0;
	if (ATTRIBUTENAME_OLD!=null){
			for(a = 0;a<ATTRIBUTENAME_OLD.length;a++){
				ATTRIBUTEID_OLD[a] = thaistring.MS874ToUnicode(ATTRIBUTEID_OLD[a]);
				ATTRIBUTENAME_OLD[a] = thaistring.MS874ToUnicode(ATTRIBUTENAME_OLD[a]);
				ATTRIBUTETYPE_OLD[a] = thaistring.MS874ToUnicode(ATTRIBUTETYPE_OLD[a]);
				if(tmp_old==null){tmp_old="";}
				if (!(tmp_old.equals(String.valueOf(a)))){
%>
          <tr> 
            <td height="26" bordercolor="#333333"><b> 
              <input name="ATTRIBUTENAME_OLD" type="text" value="<%=ATTRIBUTENAME_OLD[a]%>">
              <input name="ATTRIBUTEID_OLD" type="hidden" value="<%=ATTRIBUTEID_OLD[a]%>">
              </b></td>
            <td height="26" bordercolor="#333333"> <b> </b> <select name="ATTRIBUTETYPE_OLD" >
                <option value="1" <%if(ATTRIBUTETYPE_OLD[a].equals("1")){out.print("selected");}%>>Number</option>
                <option value="3"<%if(ATTRIBUTETYPE_OLD[a].equals("3")){out.print("selected");}%>>Bool</option>
                <option value="4"<%if(ATTRIBUTETYPE_OLD[a].equals("4")){out.print("selected");}%>>String</option>
                <option value="5"<%if(ATTRIBUTETYPE_OLD[a].equals("5")){out.print("selected");}%>>Char</option>
              </select> </td>
 <%
		b = a;
		if(!(tmp_old.equals("")) && Integer.parseInt(tmp_old,10)<=a){
			b--;
		}
%>
            <td height="26" bordercolor="#333333"> <input name="delete_old" type="button" id="delete_old" onClick="godelete_old(<%=b%>)" value="Delete"> 
            </td>
          </tr>
<%		}//if
		}//for	
	}//if
	int i = 0;int j = 0;
	if (ATTRIBUTENAME!=null){
			for(i = 0;i<ATTRIBUTENAME.length;i++){
				ATTRIBUTENAME[i] = thaistring.MS874ToUnicode(ATTRIBUTENAME[i]);
				ATTRIBUTETYPE[i] = thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]);
				if (!(tmp.equals(String.valueOf(i)))){
	%>
          <tr> 
            <td width="26%" height="26" bordercolor="#333333"><b> 
              <input type="text" name="ATTRIBUTENAME" value="<%=ATTRIBUTENAME[i]%>">
              </b></td>
            <td width="26%" height="26" bordercolor="#333333"> <b> </b> <select name="ATTRIBUTETYPE">
                <option value="1" <%if(ATTRIBUTETYPE[i].equals("1")){out.print("selected");}%>>Number</option>
                <option value="3"<%if(ATTRIBUTETYPE[i].equals("3")){out.print("selected");}%>>Bool</option>
                <option value="4"<%if(ATTRIBUTETYPE[i].equals("4")){out.print("selected");}%>>String</option>
                <option value="5"<%if(ATTRIBUTETYPE[i].equals("5")){out.print("selected");}%>>Char</option>
              </select> </td>
 <%
		j = i;
		if(!(tmp.equals("")) && Integer.parseInt(tmp,10)<=i){
			j--;
		}
%>
            <td width="27%" height="26" bordercolor="#333333"> <input type="button" name="delete" value="Delete" onClick="godelete(<%=j%>)"> 
            </td>
          </tr>
          <%
			}//if
		}//for	
	}//if
	
	if (flag!=null && flag.equals("add")){
	%>
          <tr> 
            <td width="26%" height="26" bordercolor="#333333"><b> 
              <input type="text" name="ATTRIBUTENAME" >
              </b></td>
            <td width="26%" height="26" bordercolor="#333333"> <b> </b> <select name="ATTRIBUTETYPE">
                <option value="1">Number</option>
                <option value="3">Bool</option>
                <option value="4">String</option>
                <option value="5">Char</option>
              </select> </td>
            <td width="27%" height="26" bordercolor="#333333"> 
              <%if (ATTRIBUTENAME!=null){ if(tmp.equals("")&&(ATTRIBUTENAME.length>1)){ ++j;}}%>
              <input type="button" name="delete" value="Delete" onClick="godelete(<%=j%>)"> 
            </td>
          </tr>
          <%
	}//if
	%>
          <tr> 
            <td width="26%"><b></b></td>
            <td width="26%">&nbsp; </td>
            <td width="27%">&nbsp; </td>
          </tr>
          <tr> 
            <td width="26%"><b> 
              <input type="button" name="add" value="add" onClick="goadd()">
              </b></td>
            <td width="26%">&nbsp; </td>
            <td width="27%">&nbsp; </td>
          </tr>
          <tr> 
            <td width="26%">&nbsp;</td>
            <td width="26%">&nbsp;</td>
            <td width="27%">&nbsp;</td>
          </tr>
          <tr> 
            <td width="26%">&nbsp;</td>
            <td width="26%">&nbsp;</td>
            <td width="27%"> <input type="button" name="Submit4" value="  OK  " onClick="checknull()"> 
              <input type="button" name="Submit222" value="Cancel" onClick="window.location='doctypeedit.jsp'"> 
              <input type="reset" name="Submit22" value="Reset"> </td>
          </tr>
        </table>
</form>
    </td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.doctypecreate
	function checknull(){
		var flag = false;
		if (doc.ATTRIBUTENAME != null){
			if(doc.ATTRIBUTENAME.length>1){
				for (var i=0;i<doc.ATTRIBUTENAME.length;i++){
					if (doc.ATTRIBUTENAME[i].value == ''||(doc.ATTRIBUTENAME[i].value!='' && isallspace(doc.ATTRIBUTENAME[i].value)) ){
						alert("Please insert Attribute name!!!");flag = true;return true;}//if
					else if (specialchar(doc.ATTRIBUTENAME[i].value))
						{alert('The specific Attribute name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
				}//for
			}else{
				if (doc.ATTRIBUTENAME.value == ''||(doc.ATTRIBUTENAME.value!='' && isallspace(doc.ATTRIBUTENAME.value)) ){
						alert("Please insert Attribute name!!!");flag = true;return true;}//if
				else if (specialchar(doc.ATTRIBUTENAME.value))
					{alert('The specific Attribute name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
			}
		}if (flag == false){
			doc.submit();
		}
	}
	function isallspace(src)
	{
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}
		return true;
	}
	function goadd(j){
		doc.action = "doctypeattr2.jsp?flag=add&tmp=&tmp_old=";
		doc.submit();
	}
	function  godelete(i){
		doc.action = "doctypeattr2.jsp?tmp="+i+"&tmp_old=";
		doc.submit();
	}
	function  godelete_old(i){
		doc.action = "doctypeattr2.jsp?tmp=&tmp_old="+i;
		doc.submit();
	}
	function specialchar(scr)
	{
		var i=0;
		for (i=0;i<scr.length;i++)
		{
			if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
			{
				return true;
			}
		}
	}
-->
</SCRIPT>