<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	String CONDITIONID_OLD[] = request.getParameterValues("CONDITIONID_OLD");
	String NEXTSTATEID[]=request.getParameterValues("NEXTSTATEID");
	String NEXTSTATEID_OLD[]=request.getParameterValues("NEXTSTATEID_OLD");
	String STATEMENT_OLD[]=request.getParameterValues("STATEMENT_OLD");
	String STATEMENT[]=request.getParameterValues("STATEMENT");	
	String flag=request.getParameter("flag");
	String tmp=request.getParameter("tmp");
	String tmp_old=request.getParameter("tmp_old");

	String keyword = " where STATEID="+STATEID+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");

	String keyword1 =  "where STATEID<>"+STATEID+" and WORKFLOWID="+state[0].getWORKFLOWID()+" and STATETYPE<>'1'"+" ";
	mybean.State statetogo[];
	statetogo = adminpower.readstate.getState(keyword1," ");

%>
<!DOCNEXTSTATEID HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document NEXTSTATEID edit</TITLE>


<META http-equiv=Content-NEXTSTATEID content="text/html; charset=tis-620"><LINK 
href="../../style.css" NEXTSTATEID=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Create Condition</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="condedit" method="post" action="script/condedit2_s.jsp">
	<input type="hidden" name="STATEID" value="<%=STATEID%>">
	<input type="hidden" name="WORKFLOWID" value="<%=WORKFLOWID%>">
    <table width="100%" border="0" height="235">
    <tr> 
            <td height="39"><b>State name :  <%=state[0].getSTATENAME()%></b></td>
    </tr>
    <tr> 
      <td> 
        <table width="100%">
                <tr class="submit"> 
                  <td width="32%"><div align="center">Statement</div></td>
                  <td width="23%" height="21"> <div align="center">Next State</div></td>
                  <td width="13%" height="21">&nbsp;</td>
                </tr>
                <%
	int i = 0;int j=0;
	if (CONDITIONID_OLD!=null){//
			for(i = 0;i<CONDITIONID_OLD.length;i++){
				if(tmp_old==null){tmp_old="";}
				if (!(tmp_old.equals(String.valueOf(i)))){
					STATEMENT_OLD[i] = thaistring.MS874ToUnicode(STATEMENT_OLD[i]);
					String temp_STATEMENT_OLD = STATEMENT_OLD[i].replaceAll("\"","&quot;");
%>
                <tr> 
                  <td width="32%"><input name="STATEMENT_OLD" value="<%=temp_STATEMENT_OLD%>" size="40" type="text"></td>
				<input type="hidden" name="CONDITIONID_OLD" value="<%=CONDITIONID_OLD[i]%>">
                  <td width="23%"> <div align="center"><font color="#666666"> 
                      <select name="NEXTSTATEID_OLD">
<%
					for(int z=0;z<statetogo.length;z++){
%>
						<option value="<%=statetogo[z].getSTATEID()%>" <%if((new Integer(NEXTSTATEID_OLD[i])).equals(statetogo[z].getSTATEID())){out.print("selected");}%>><%=statetogo[z].getSTATENAME()%></option>
<%
					}//for
%>
                      </select>
                      </font> </div></td>
                  <%
				j = i;
				if(!(tmp_old.equals("")) && Integer.parseInt(tmp_old,10)<=i){
					j--;
				}//if

%>
                  <td width="13%"> <div align="center"> 
                      <input TYPE="button" name="Submit42" value="Delete" onClick="godelete_old(<%=j%>)">
                    </div></td>
                </tr>
                <%
			}//if
		}//for	
	}//if
	if (STATEMENT!=null){
			for(i = 0;i<STATEMENT.length;i++){
				if(tmp==null){tmp="";}
				if (!(tmp.equals(String.valueOf(i)))){
					STATEMENT[i] = thaistring.MS874ToUnicode(STATEMENT[i]);
					String temp_STATEMENT = STATEMENT[i].replaceAll("\"","&quot;");
%>
                <tr> 
                  <td width="32%"><input name="STATEMENT" value="<%=temp_STATEMENT%>" size="40" type="text"></td>
                  <td width="23%"> <div align="center"><font color="#666666"> 
                 <select name="NEXTSTATEID">
<%
					for(int z=0;z<statetogo.length;z++){
%>
						<option value="<%=statetogo[z].getSTATEID()%>" <%if((new Integer(NEXTSTATEID[i])).equals(statetogo[z].getSTATEID())){out.print("selected");}%>><%=statetogo[z].getSTATENAME()%></option>
<%
					}//for
%>
                      </select>
                      </font> </div></td>
                  <%
				j = i;
				if(!(tmp.equals("")) && Integer.parseInt(tmp,10)<=i){
					j--;
				}//if
%>
                  <td width="13%"> <div align="center"> 
				<%if (STATEMENT!=null){ if(tmp.equals("")&&(STATEMENT.length>1)){ ++j;}}%>
				     <input TYPE="button" name="Submit42" value="Delete" onClick="godelete(<%=j%>)">
                    </div></td>
                </tr>
                <%
			}//if
		}//for	
	}//if
	if (flag!=null && flag.equals("add")){
%>
                <tr> 
                  <td width="32%"><input name="STATEMENT" type="text"  size="40"></td>
                  <td width="23%"> <div align="center"> 
                      <select name="NEXTSTATEID">
<%
					for(int z=0;z<statetogo.length;z++){
%>
						<option value="<%=statetogo[z].getSTATEID()%>" ><%=statetogo[z].getSTATENAME()%></option>
<%
					}//for
%>
                      </select>
                    </div></td>
                  <td width="13%"> <div align="center"> 
                      <input TYPE="button" name="Submit42" value="Delete" onClick="godelete(<%=j%>)">
                    </div></td>
                </tr>
                <%
	}//if
%>
                <tr> 
                  <td colspan="3" ><input TYPE="button" name="Submit424" value="Add" onClick="goadd()"></td>
                </tr>
              </table>
      </td>
    </tr>
    <tr> 
            <td> <div align="right"><b> </b> 
                <input TYPE="button" name="Submit4" value="  OK  " onClick="checknull()">
                <input TYPE="reset" name="Submit22" value="Reset">
                <input TYPE="button" name="Submit222" value="Cancel"  onClick="window.location='mapcondedit.jsp?WORKFLOWID=<%=state[0].getWORKFLOWID()%>'">
              </div></td>
    </tr>
  </table>
   </form>
    </td>
  </tr>
</table>

</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.condedit
	function checknull(){
	var flag = false;
	if (doc.CONDITIONID != null){
			if (doc.CONDITIONID.length>1){
				for (var i=1;i<doc.CONDITIONID.length;i++){
					if (doc.CONDITIONID[i].value == '' || (doc.CONDITIONID[i].value!='' && isallspace(doc.CONDITIONID[i].value)) ){
						alert("Please insert State name!!!");flag = true;return true;		
					}//if
				}//for
			}else{
				if (doc.CONDITIONID.value == '' || (doc.CONDITIONID.value!='' && isallspace(doc.CONDITIONID.value)) ){
						alert("Please insert State name!!!");flag = true;return true;		
				}//if
			}
	}
	if (flag == false){
		doc.submit();
	}
	}
	function isallspace(src)
	{
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}
		return true;
	}
	function goadd(j){
		doc.action = "condedit2.jsp?flag=add&tmp=&tmp_old=";
		doc.submit();
	}
	function  godelete(i){
		doc.action = "condedit2.jsp?tmp="+i;
		doc.submit();
	}
		function  godelete_old(i){
		doc.action = "condedit2.jsp?tmp_old="+i;
		doc.submit();
	}
-->
</SCRIPT>