<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	if (STATEID==null){
		STATEID = "";
	}

	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String USERNAME[] = request.getParameterValues("USERNAME");
	String GROUPID[] = request.getParameterValues("GROUPID");
	String ROLEID[] = request.getParameterValues("ROLEID");
	String CANREJECT_USER[] = request.getParameterValues("CANREJECT_USER");
	String CANREJECT_GROUP[] = request.getParameterValues("CANREJECT_GROUP");
	String CANREJECT_ROLE[] = request.getParameterValues("CANREJECT_ROLE");

	String keyword = " where STATEID="+STATEID+" ";
	mybean.UserState userstate[];
	userstate = adminpower.readuserstate.getUserState(keyword," ");
	mybean.GroupState groupstate[];
	groupstate = adminpower.readgroupstate.getGroupState(keyword," ");
	mybean.RoleState rolestate[];
	rolestate = adminpower.readrolestate.getRoleState(keyword," ");

	if(USERNAME!=null){
		for(int i=0;i<userstate.length;i++){
			boolean isinlist=false;
			for(int j=0;j<USERNAME.length;j++){
				if(userstate[i].getUSERNAME().equals(thaistring.MS874ToUnicode(USERNAME[j]))){
					isinlist = true;
					break;
				}//if
			}//for j
			if(isinlist){
				adminpower.writeuserstate.editUserState(userstate[i].getUSERNAME(),new Integer(STATEID),new Boolean("FALSE"));
			}//if
			else{
				adminpower.writeuserstate.deleteUserState(userstate[i].getUSERNAME(),new Integer(STATEID));
			}//else
		}//for i

		userstate = adminpower.readuserstate.getUserState(keyword," ");
		for(int i=0;i<USERNAME.length;i++){
			boolean isinlist=false;
			for(int j=0;j<userstate.length;j++){
				if(USERNAME[i].equals(userstate[j].getUSERNAME())){
					isinlist = true;
					break;
				}//if
			}//for j
			if(!isinlist){
				adminpower.writeuserstate.addUserState(USERNAME[i],new Integer(STATEID),new Boolean("FALSE"));
			}//else
		}//for i

		if(CANREJECT_USER!=null){
			for(int i=0;i<CANREJECT_USER.length;i++){
				CANREJECT_USER[i] = thaistring.MS874ToUnicode(CANREJECT_USER[i]);
				adminpower.writeuserstate.editUserState(CANREJECT_USER[i],new Integer(STATEID),new Boolean("TRUE"));
			}//for i
		}//if
	}//if USERNAME
	else{
		adminpower.writeuserstate.deleteUserallState(new Integer(STATEID));
	}//else


	if(GROUPID!=null){
		for(int i=0;i<groupstate.length;i++){
			boolean isinlist=false;
			for(int j=0;j<GROUPID.length;j++){
				if(groupstate[i].getGROUPID().equals(new Integer(thaistring.MS874ToUnicode(GROUPID[j])))){
					isinlist = true;
					break;
				}//if
			}//for j
			if(isinlist){
				adminpower.writegroupstate.editGroupState(groupstate[i].getGROUPID(),new Integer(STATEID),new Boolean("FALSE"));
			}//if
			else{
				adminpower.writegroupstate.deleteGroupState(groupstate[i].getGROUPID(),new Integer(STATEID));
			}//else
		}//for i

		groupstate = adminpower.readgroupstate.getGroupState(keyword," ");
		for(int i=0;i<GROUPID.length;i++){
			boolean isinlist=false;
			for(int j=0;j<groupstate.length;j++){
				if((new Integer(GROUPID[i])).equals(groupstate[j].getGROUPID())){
					isinlist = true;
					break;
				}//if
			}//for j
			if(!isinlist){
				adminpower.writegroupstate.addGroupState(new Integer(GROUPID[i]),new Integer(STATEID),new Boolean("FALSE"));
			}//else
		}//for i

		if(CANREJECT_GROUP!=null){
			for(int i=0;i<CANREJECT_GROUP.length;i++){
				CANREJECT_GROUP[i] = thaistring.MS874ToUnicode(CANREJECT_GROUP[i]);
				adminpower.writegroupstate.editGroupState(new Integer(CANREJECT_GROUP[i]),new Integer(STATEID),new Boolean("TRUE"));
			}//for i
		}//if
	}//if GROUPID
	else{
		adminpower.writegroupstate.deleteGroupallState(new Integer(STATEID));
	}//else


	if(ROLEID!=null){
		for(int i=0;i<rolestate.length;i++){
			boolean isinlist=false;
			for(int j=0;j<ROLEID.length;j++){
				if(rolestate[i].getROLEID().equals(new Integer(thaistring.MS874ToUnicode(ROLEID[j])))){
					isinlist = true;
					break;
				}//if
			}//for j
			if(isinlist){
				adminpower.writerolestate.editRoleState(rolestate[i].getROLEID(),new Integer(STATEID),new Boolean("FALSE"));
			}//if
			else{
				adminpower.writerolestate.deleteRoleState(rolestate[i].getROLEID(),new Integer(STATEID));
			}//else
		}//for i

		rolestate = adminpower.readrolestate.getRoleState(keyword," ");
		for(int i=0;i<ROLEID.length;i++){
			boolean isinlist=false;
			for(int j=0;j<rolestate.length;j++){
				if((new Integer(ROLEID[i])).equals(rolestate[j].getROLEID())){
					isinlist = true;
					break;
				}//if
			}//for j
			if(!isinlist){
				adminpower.writerolestate.addRoleState(new Integer(ROLEID[i]),new Integer(STATEID),new Boolean("FALSE"));
			}//else
		}//for i

		if(CANREJECT_ROLE!=null){
			for(int i=0;i<CANREJECT_ROLE.length;i++){
				CANREJECT_ROLE[i] = thaistring.MS874ToUnicode(CANREJECT_ROLE[i]);
				adminpower.writerolestate.editRoleState(new Integer(CANREJECT_ROLE[i]),new Integer(STATEID),new Boolean("TRUE"));
			}//for i
		}//if
	}//if ROLEID
	else{
		adminpower.writerolestate.deleteRoleallState(new Integer(STATEID));
	}//else

	response.sendRedirect("../mapcondedit.jsp?WORKFLOWID="+WORKFLOWID);

%>