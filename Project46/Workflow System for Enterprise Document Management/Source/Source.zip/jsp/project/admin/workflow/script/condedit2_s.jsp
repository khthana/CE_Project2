<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));

	String CONDITIONID_OLD[] = request.getParameterValues("CONDITIONID_OLD");
	String NEXTSTATEID[]=request.getParameterValues("NEXTSTATEID");
	String NEXTSTATEID_OLD[]=request.getParameterValues("NEXTSTATEID_OLD");
	String STATEMENT_OLD[]=request.getParameterValues("STATEMENT_OLD");
	String STATEMENT[]=request.getParameterValues("STATEMENT");	
	
	String keyword = " where STATEID="+STATEID+" ";
	mybean.Condition condition[];
	condition = adminpower.readcondition.getCondition(keyword," ");

	if(CONDITIONID_OLD!=null){
		for(int i=0;i<condition.length;i++){
			boolean isinlist=false;
			int positioninlist = -1;
			for(int j=0;j<CONDITIONID_OLD.length;j++){
				if(condition[i].getCONDITIONID().equals(new Integer(CONDITIONID_OLD[j]))){
					isinlist = true;
					positioninlist = j;
					break;
				}//if
			}//for j
			if(isinlist){
				STATEMENT_OLD[positioninlist] = thaistring.MS874ToUnicode(STATEMENT_OLD[positioninlist]);
				adminpower.writecondition.editCondition(condition[i].getCONDITIONID(),STATEMENT_OLD[positioninlist],new Integer(NEXTSTATEID_OLD[positioninlist]),new Integer(STATEID));
			}//if
			else{
				adminpower.writecondition.deleteCondition(condition[i].getCONDITIONID(),new Integer(STATEID));
			}//else
		}//for i

	}//if CONDITIONID_OLD
	else{
		adminpower.writecondition.deleteallCondition(new Integer(STATEID));
	}//else

	if(STATEMENT!=null){
		for(int a=0;a<STATEMENT.length;a++){
			STATEMENT[a] = thaistring.MS874ToUnicode(STATEMENT[a]);
			adminpower.writecondition.addCondition(STATEMENT[a],new Integer(NEXTSTATEID[a]),new Integer(STATEID));
		}//for a
	}//if STATEMENT

	response.sendRedirect("../mapcondedit.jsp?WORKFLOWID="+WORKFLOWID);

%>