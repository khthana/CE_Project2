<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String STATEID = thaistring.MS874ToUnicode(request.getParameter("STATEID"));
	if (STATEID==null){
		STATEID = "";
	}

	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword1 = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword1," ");

	String keyword = " where STATEID="+STATEID+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword," ");
	mybean.UserState userstate[];
	userstate = adminpower.readuserstate.getUserState(keyword," ");
	mybean.GroupState groupstate[];
	groupstate = adminpower.readgroupstate.getGroupState(keyword," ");
	mybean.RoleState rolestate[];
	rolestate = adminpower.readrolestate.getRoleState(keyword," ");

	mybean.User all_user[];
	all_user = adminpower.readuser.getUser(" "," ");
	mybean.Role all_role[];
	all_role = adminpower.readrole.getRole(" "," ");
	mybean.Group all_group[];
	all_group = adminpower.readgroup.getGroup(" "," ");


%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
	<td class= "head" width="98%"><strong> Workflow : </strong> <%=workflow[0].getWORKFLOWNAME()%></td>
  </tr>
    <tr> 
    <td width="2%">&nbsp;</td>
	<td class= "head" width="98%"><strong> State : </strong> <%=state[0].getSTATENAME()%></td>
  </tr>
  
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="mapuseredit" method="post" action="script/mapuseredit_s.jsp">
	<input type="hidden" name="WORKFLOWID" value="<%=WORKFLOWID%>">
	<input type="hidden" name="STATEID" value="<%=STATEID%>">
        <table width="51%" border="0">
          <tr> 
            <td colspan="2" height="39"  class="box"><p><strong>Map User to state</strong></p>
              <table width="100%">
                <tr class="submit"> 
                  <td width="18%" height="22"> <div align="center">Reject</div></td>
                  <td colspan="2" height="22"> <div align="center">User has authorization 
                    </div></td>
                </tr>
<%
	for(int i=0;i<all_user.length;i++){
		boolean temp_flag_read = false;
		boolean temp_flag_reject = false;
		for(int j=0;j<userstate.length;j++){
			if(userstate[j].getUSERNAME().equals(all_user[i].getUSERNAME())){
				temp_flag_read = true;
				temp_flag_reject = userstate[j].getCANREJECT().booleanValue();
				break;
			}//if
		}//for j
%>
				<tr> 
                  <td width="18%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="CANREJECT_USER" value="<%=all_user[i].getUSERNAME()%>" <%if(temp_flag_reject){out.print("checked");}%>>
                    </div></td>
                  <td width="16%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="USERNAME" value="<%=all_user[i].getUSERNAME()%>" <%if(temp_flag_read){out.print("checked");}%>>
                    </div></td>
                  <td width="66%"> <div align="center"><%=all_user[i].getFIRSTNAME()+" "+all_user[i].getLASTNAME()%></div></td>
                </tr>
<%
	}//for all_user
%>
              </table>
              <p>&nbsp;</p></td>
          </tr>
          <tr> 
            <td colspan="2" height="30">&nbsp; </td>
          </tr>
          <tr> 
            <td colspan="2" height="39"  class="box"><p><strong>Map group to state</strong></p>
              <table width="100%">
                <tr class="submit"> 
                  <td width="18%" height="22"> <div align="center">Reject</div></td>
                  <td colspan="2" height="22"> <div align="center">Group has authorization 
                    </div></td>
                </tr>
<%
	for(int i=0;i<all_group.length;i++){
		boolean temp_flag_read = false;
		boolean temp_flag_reject = false;
		for(int j=0;j<groupstate.length;j++){
			if(groupstate[j].getGROUPID().equals(all_group[i].getGROUPID())){
				temp_flag_read = true;
				temp_flag_reject = groupstate[j].getCANREJECT().booleanValue();
				break;
			}//if
		}//for j
%>
				<tr> 
                  <td width="18%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="CANREJECT_GROUP" value="<%=all_group[i].getGROUPID()%>" <%if(temp_flag_reject){out.print("checked");}%>>
                    </div></td>
                  <td width="16%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="GROUPID" value="<%=all_group[i].getGROUPID()%>" <%if(temp_flag_read){out.print("checked");}%>>
                    </div></td>
                  <td width="66%"> <div align="center"><%=all_group[i].getGROUPNAME()%></div></td>
                </tr>
<%
	}//for all_group
%>
			  </table>
              <p>&nbsp;</p></td>
          </tr>
          <tr> 
            <td colspan="2" height="30">&nbsp; </td>
          </tr>
          <tr> 
            <td colspan="2" height="39"  class="box"><p><strong>Map role to state</strong></p>
              <table width="100%">
                <tr class="submit"> 
                  <td width="18%" height="22"> <div align="center">Reject</div></td>
                  <td colspan="2" height="22"> <div align="center">Role has authorization 
                    </div></td>
                </tr>
<%
	for(int i=0;i<all_role.length;i++){
		boolean temp_flag_read = false;
		boolean temp_flag_reject = false;
		for(int j=0;j<rolestate.length;j++){
			if(rolestate[j].getROLEID().equals(all_role[i].getROLEID())){
				temp_flag_read = true;
				temp_flag_reject = rolestate[j].getCANREJECT().booleanValue();
				break;
			}//if
		}//for j
%>
				<tr> 
                  <td width="18%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="CANREJECT_ROLE" value="<%=all_role[i].getROLEID()%>" <%if(temp_flag_reject){out.print("checked");}%>>
                    </div></td>
                  <td width="16%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"> 
                      <input type="checkbox" name="ROLEID" value="<%=all_role[i].getROLEID()%>" <%if(temp_flag_read){out.print("checked");}%>>
                    </div></td>
                  <td width="66%"> <div align="center"><%=all_role[i].getROLENAME()%></div></td>
                </tr>
<%
	}//for all_role
%>
              </table>
              <p>&nbsp;</p></td>
          </tr>
          <tr> 
            <td width="23%"><b> </b></td>
            <td width="77%"> <div align="right">
                <input type="submit" name="Submit4" value="  OK  ">
                <input type="reset" name="Submit22" value="Reset">
                <input type="button" name="Submit222" value="Cancel" onClick="window.location='mapcondedit.jsp?WORKFLOWID=<%=WORKFLOWID%>'">
              </div></td>
          </tr>
        </table>
   </form></td>
  </tr>
</table>
</body>
</html>
