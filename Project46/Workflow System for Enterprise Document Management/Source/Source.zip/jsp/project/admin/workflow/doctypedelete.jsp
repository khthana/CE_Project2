<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
String message = "Are you sure you want to delete it?";
%>
<%
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<form name="doctypedelete" method="post" action="script/doctypedelete_s.jsp">
  <table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Delete document type</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
        <tr class="submit"> 
          <td width="6%" height="19"> <div align="center"> 
              <input type="checkbox" name="alldelete" value="checkbox" onClick="tickAll(this)">
            </div></td>
          <td width="35%"> <div align="center">Document
              Type</div></td>
          <td width="59%"> <div align="center">Detail</div></td>
        </tr>
<%
	for(int i=0;i<documenttype.length;i++){
%>
        <tr> 
          <td width="6%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
              <input type="checkbox" name="DOCUMENTTYPEID" value="<%=documenttype[i].getDOCUMENTTYPEID()%>">
            </div></td>
          <td width="35%"> <div align="center"><%=documenttype[i].getDOCUMENTTYPENAME()%></div></td>
          <td width="59%"> <div align="center"><%=documenttype[i].getDOCUMENTTYPEDESC()%></div></td>
        </tr>
<%
	}//for
%>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
      <td colspan="2"> <div align="right">
          <input name="   OK   " type="button" id="   OK   2" value="   OK   " onClick="if (checkDel()) { if(confirm('<%=message%>')) {document.doctypedelete.submit();}} else {alert('Please select information which you want to delete !!!');}">
          &nbsp; 
		<input type="reset" name="Submit22" value="Reset" >
          &nbsp; 
          <input type="button" name="Submit2" value="Cancel" onClick="window.location = 'workflow.jsp'">
        </div></td>
  </tr>

</table>
  </form>

  <SCRIPT LANGUAGE="JavaScript">
<!--
 function checkDel () {
	var o = document.doctypedelete;
	if (o.DOCUMENTTYPEID != undefined){
		var boxCount = o.DOCUMENTTYPEID.length;
		if (boxCount == undefined) {
			if (o.DOCUMENTTYPEID.checked) {
				return true;
			} else {
				return false;
			}
		} else {
			for (i = 0 ; i < boxCount; i++) {
				if ( o.DOCUMENTTYPEID[i].checked ) {
					return true;
				} 
			}
			return false;
		}
	}
	else {
		return false;
	}
 }

 function tickAll(b) {
	var o = document.doctypedelete;
	if (o.DOCUMENTTYPEID != undefined){
		if (b.checked) {
			var boxCount = o.DOCUMENTTYPEID.length;
			if (boxCount == undefined) {
				o.DOCUMENTTYPEID.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.DOCUMENTTYPEID[i].checked = true;
				}
			}
		} else {
			var boxCount = o.DOCUMENTTYPEID.length;
			if (boxCount == undefined) {
				o.DOCUMENTTYPEID.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.DOCUMENTTYPEID[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>
</p>
