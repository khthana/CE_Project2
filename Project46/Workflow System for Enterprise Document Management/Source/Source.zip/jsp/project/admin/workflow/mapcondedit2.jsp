<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String WORKFLOWID = thaistring.MS874ToUnicode(request.getParameter("WORKFLOWID"));
	if (WORKFLOWID==null){
		WORKFLOWID = "";
	}

	String keyword = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(keyword," ");

	String keyword1 = " where WORKFLOWID="+WORKFLOWID+" ";
	mybean.State state[];
	state = adminpower.readstate.getState(keyword1," ");

	String keyword2 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.Attribute attribute[];
	attribute = adminpower.readattribute.getAttribute(keyword2," ");

	String keyword3 = " where DOCUMENTTYPEID="+workflow[0].getDOCUMENTTYPEID()+" ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword3," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="52" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Assign condition and user to State</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="mapcond" method="post" action="script\mapcond.jsp">
	<input type="hidden" name="WORKFLOWID" value="<%=WORKFLOWID%>">
<table width="100%" border="0">
  <tr> 
            <td width="31%">Workflow name : </td>
    <td width="69%"><strong><%=workflow[0].getWORKFLOWNAME()%></strong></td>
  </tr>
  <tr> 
    <td width="31%">&nbsp;</td>
    <td width="69%">&nbsp;</td>
  </tr>
  <tr> 
            <td width="31%">Document type Name : </td>
            <td width="69%"><strong><%=documenttype[0].getDOCUMENTTYPENAME()%></strong></td>
  </tr>
  <tr> 
    <td width="31%" height="27">&nbsp;</td>
    <td width="69%" height="27">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2" height="98"> 
      <table width="54%">
                <tr class="submit"> 
                  <td width="49%" height="27"><b>Attribute Name</b></td>
                  <td width="51%" height="27"><b>Type</b></td>
                </tr>
<%
	for(int i=0;i<attribute.length;i++){
%>
                <tr> 
					<td width="49%" height="18"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);><b><%=attribute[i].getATTRIBUTENAME()%></b></td>
					<td width="51%" height="18" ><font color="#000000">
				<%
					if(attribute[i].getATTRIBUTETYPE().equals("1")){
						out.print("Integer");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("2")){
						out.print("Date");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("3")){
						out.print("Bool");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("4")){
						out.print("String");
					}
					else if(attribute[i].getATTRIBUTETYPE().equals("5")){
						out.print("Char");
					}
				%>
					</font></td>
                </tr>
<%
	}//for
%>
              </table>
    </td>
  </tr>
  <tr> 
    <td width="31%"><b> </b></td>
    <td width="69%">&nbsp; </td>
  </tr>

  <tr> 
            <td colspan="2" height="38"><strong>State</strong></td>
  </tr>
  <tr> 
    <td colspan="2" height="70"> 
      <table width="100%">
                <tr class="submit"> 
                  <td width="57%" height="21"> <div align="center">State name</div></td>
                  <td width="18%" height="21">&nbsp;</td>
                  <td width="25%" height="21">&nbsp;</td>
                </tr>
<%
	for(int i=0;i<state.length;i++){
%>
                <tr> 
                  <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><b><%=state[i].getSTATENAME()%></b></div>
                  </td>
                  <td> <div align="center"> 
                      <input type="button" name="condition" value="Condition" onClick="go('cond','<%=state[i].getSTATEID()%>')">
                    </div></td>
                  <td> <div align="center"> 
                      <input type="button" name="map" value="Map user/group/role " onClick="go('map','<%=state[i].getSTATEID()%>')">
                    </div></td>
                </tr>
<%
	}//for
%>
              </table>
    </td>
  </tr>
  <tr> 
    <td width="31%">&nbsp;</td>
    <td width="69%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="31%"><b> </b></td>
            <td width="69%"> <div align="right">
                <input type="button" name="Submit4" value="  OK  " onclick="window.location='wfedit.jsp'">
                <input type="reset" name="Submit22" value="Reset">
                <input type="button" name="Submit222" value="Cancel" onClick="window.location='stateedit.jsp?WORKFLOWID=<%=WORKFLOWID%>'">
              </div></td>
  </tr>
</table>
</form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.mapcond
var count1 = 0
var count2 = 0
	function go(x,name){
		if (x=='cond'){
			doc.action = "condedit.jsp?STATEID="+name;
		}else {
			doc.action = "mapuseredit.jsp?STATEID="+name;
		}
		doc.submit();
	}
W-->
</SCRIPT>
