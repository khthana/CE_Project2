<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
String message = "Are you sure you want to delete it?";
%>
<%
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(" "," ");
%>
<HTML><HEAD><TITLE>Workflow delete</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
 <form name="wfdelete" method="post" action="script/wfdelete_s.jsp">
  <table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Delete Workflow</strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0" height="61">
          <tr class="submit"> 
            <td width="3%" height="21"> <input type="checkbox" name="checkbox" value="checkbox" onClick="tickAll(this)"> 
            </td>
            <td width="64%"> <div align="center">Workfow 
               name</div></td>
          </tr>
<%
	for(int i=0;i<workflow.length;i++){
%>
          <tr> 
            <td width="3%" height="2" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <input type="checkbox" name="WORKFLOWID" value="<%=workflow[i].getWORKFLOWID()%>"> 
            </td>
            <td width="64%" height="2"> <div align="center"><%=workflow[i].getWORKFLOWNAME()%></div></td>
          </tr>
<%
	}//for
%>
        </table></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
      <td colspan="2"> <div align="right">
          <input name="   OK   " type="button" id="   OK   2" value="   OK   " onClick="if (checkDel()) { if(confirm('<%=message%>')) {document.wfdelete.submit();}} else {alert('Please select information which you want to delete !!!');}">
          &nbsp; 
		<input type="reset" name="Submit22" value="Reset">
          &nbsp; 
          <input type="reset" name="Submit2" value="Cancel" onClick="window.location = 'workflow.jsp'">
        </div></td>
  </tr>

</table>
  </form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
 function checkDel () {
	var o = document.wfdelete;
	if (o.WORKFLOWID != undefined){
		var boxCount = o.WORKFLOWID.length;
		if (boxCount == undefined) {
			if (o.WORKFLOWID.checked) {
				return true;
			} else {
				return false;
			}
		} else {
			for (i = 0 ; i < boxCount; i++) {
				if ( o.WORKFLOWID[i].checked ) {
					return true;
				} 
			}
			return false;
		}
	}
	else {
		return false;
	}
 }


 function tickAll(b) {
	var o = document.wfdelete;
	if (o.WORKFLOWID != undefined){
		if (b.checked) {
			var boxCount = o.WORKFLOWID.length;
			if (boxCount == undefined) {
				o.WORKFLOWID.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.WORKFLOWID[i].checked = true;
				}
			}
		} else {
			var boxCount = o.WORKFLOWID.length;
			if (boxCount == undefined) {
				o.WORKFLOWID.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.WORKFLOWID[i].checked = false;
				}
			}
		}
	}
 }

 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>