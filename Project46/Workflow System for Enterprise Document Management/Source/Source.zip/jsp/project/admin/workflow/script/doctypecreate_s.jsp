<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String DOCUMENTTYPENAME = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPENAME"));
	if (DOCUMENTTYPENAME==null){
		DOCUMENTTYPENAME = "";
	}
	String DOCUMENTTYPEDESC = thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEDESC"));
	if (DOCUMENTTYPEDESC==null){
		DOCUMENTTYPEDESC = "";
	}
	String ATTRIBUTENAME[]=request.getParameterValues("ATTRIBUTENAME");
	String ATTRIBUTETYPE[]=request.getParameterValues("ATTRIBUTETYPE");

/*	if(ATTRIBUTENAME!=null){
		for(int i=0;i<ATTRIBUTENAME.length;i++){
			out.println(ATTRIBUTENAME[i]+"<BR>");
			out.println(ATTRIBUTETYPE[i]+"<BR>");
		}//for
	}//if
	*/
	adminpower.writedocumenttype.addDocumentType(DOCUMENTTYPENAME,DOCUMENTTYPEDESC);

	String keyword = " where DOCUMENTTYPENAME='"+DOCUMENTTYPENAME+"' and DOCUMENTTYPEDESC='"+DOCUMENTTYPEDESC+"' ";
	mybean.DocumentType documenttype[];
	documenttype = adminpower.readdocumenttype.getDocumentType(keyword," ");

	if(ATTRIBUTENAME!=null){
		for(int i=0;i<ATTRIBUTETYPE.length;i++){
			ATTRIBUTENAME[i] = thaistring.MS874ToUnicode(ATTRIBUTENAME[i]);
			adminpower.writeattribute.addAttribute(documenttype[0].getDOCUMENTTYPEID(),ATTRIBUTENAME[i],ATTRIBUTETYPE[i]);
		}//for
	}//if
	response.sendRedirect("../workflow.jsp");

%>
