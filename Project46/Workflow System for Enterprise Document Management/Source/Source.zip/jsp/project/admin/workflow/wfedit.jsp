<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	mybean.WorkFlow workflow[];
	workflow = adminpower.readworkflow.getWorkFlow(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>document type edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit workflow </strong></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
        <tr class="submit"> 
          <td width="46%"> <div align="center">Workfow name</div></td>
          <td width="29%"> <div align="center">Edit Name and Description</div></td>
          <td width="25%"> <div align="center">Edit State</div></td>
        </tr>
<%
	for(int i=0;i<workflow.length;i++){
%>
		<tr> 
          <td width="46%"> <div align="center"><%=workflow[i].getWORKFLOWNAME()%></div></td>
          <td width="29%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"><a href="wfedit2.jsp?WORKFLOWID=<%=workflow[i].getWORKFLOWID()%>">Edit</a></div></td>
          <td width="25%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"><a href="stateedit.jsp?WORKFLOWID=<%=workflow[i].getWORKFLOWID()%>">State</a></div></td>
        </tr>
<%
	}//for
%>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"><div align="right"><em><strong> 
        <input type="button" name="Button" value="Cancel" onClick="window.location='workflow.jsp'">
        </strong></em></div></td>
  </tr>
</table>
</body>
</html>