<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String WORKFLOWID[] = request.getParameterValues("WORKFLOWID");
	for (int i = 0;i<WORKFLOWID.length;i++){
		WORKFLOWID[i] = thaistring.MS874ToUnicode(WORKFLOWID[i]);
		adminpower.writeworkflow.deleteWorkFlow(new Integer(WORKFLOWID[i]));
	}//for
	response.sendRedirect("../wfdelete.jsp");
%>