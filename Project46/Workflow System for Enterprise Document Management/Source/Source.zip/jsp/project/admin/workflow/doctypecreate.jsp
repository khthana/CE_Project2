<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
  <% 
	String DOCUMENTTYPENAME=thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPENAME"));
	String DOCUMENTTYPEDESC=thaistring.MS874ToUnicode(request.getParameter("DOCUMENTTYPEDESC"));
	String ATTRIBUTENAME[]=request.getParameterValues("ATTRIBUTENAME");
	String ATTRIBUTETYPE[]=request.getParameterValues("ATTRIBUTETYPE");
	String flag=thaistring.MS874ToUnicode(request.getParameter("flag"));
	String tmp=thaistring.MS874ToUnicode(request.getParameter("tmp"));

%>
</p>
<form name="doctypecreate" method="post" action="script/doctypecreate_s.jsp">
  <table width="100%" border="0">
    <tr> 
      <td height="46">&nbsp;</td>
      <td colspan="3" class="head">&nbsp;</td>
    </tr>
    <tr> 
      <td width="9">&nbsp;</td>
      <td colspan="3" class="head"><strong>Create documnent type</strong></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr> 
      <td >&nbsp;</td>
      <td width="268">Document type Name : *</td>
      <td width="353" ><b> 
        <input type="text" name="DOCUMENTTYPENAME" value="<%if (DOCUMENTTYPENAME!=null){out.print(DOCUMENTTYPENAME);}%>" >
        </b></td>
      <td >&nbsp; </td>
    </tr>
    <tr> 
      <td >&nbsp;</td>
      <td >Description : </td>
      <td > <textarea name="DOCUMENTTYPEDESC" cols="50" rows="3"><%if (DOCUMENTTYPEDESC!=null){out.print(DOCUMENTTYPEDESC);}%></textarea> 
      </td>
      <td >&nbsp; </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td >&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp; </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td >&nbsp; </td>
    </tr>
    <tr > 
      <td >&nbsp;</td>
      <td height="27" class="submit"><b>Attribute Name</b></td>
      <td height="27" class="submit"><b>Type</b></td>
      <td width="131" height="27" class="submit">&nbsp;</td>
    </tr>
    <%
	int i = 0;int j = 0;
	if (ATTRIBUTENAME!=null){
			for(i = 0;i<ATTRIBUTENAME.length;i++){
				if (!(tmp.equals(String.valueOf(i)))){
	%>
    <tr> 
      <td bordercolor="#333333">&nbsp;</td>
      <td height="26" bordercolor="#333333"><b> 
        <input type="text" name="ATTRIBUTENAME" value="<%=thaistring.MS874ToUnicode(ATTRIBUTENAME[i])%>">
        </b></td>
      <td  height="26" bordercolor="#333333"> <b> </b> <select name="ATTRIBUTETYPE">
          <option value="1" <%if(thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]).equals("1")){out.print("selected");}%>>Number</option>
          <option value="3"<%if(thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]).equals("3")){out.print("selected");}%>>Bool</option>
          <option value="4"<%if(thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]).equals("4")){out.print("selected");}%>>String</option>
          <option value="5"<%if(thaistring.MS874ToUnicode(ATTRIBUTETYPE[i]).equals("5")){out.print("selected");}%>>Char</option>
        </select> </td>
      <%
		j = i;
		if(!(tmp.equals("")) && Integer.parseInt(tmp,10)<=i){
			j--;
		}
		%>
      <td height="26" bordercolor="#333333"> <input type="button" name="delete" value="Delete" onClick="godelete(<%=j%>)"> 
      </td>
    </tr>
    <%
			}//if
		}//for	
	}//if
	
	if (flag!=null && flag.equals("add")){
	%>
    <tr> 
      <td bordercolor="#333333" >&nbsp;</td>
      <td height="26" bordercolor="#333333"><b> 
        <input type="text" name="ATTRIBUTENAME" >
        </b></td>
      <td  height="26" bordercolor="#333333"> <b> </b> <select name="ATTRIBUTETYPE">
          <option value="1">Number</option>
          <option value="3">Bool</option>
          <option value="4">String</option>
          <option value="5">Char</option>
        </select> </td>
      <td  height="26" bordercolor="#333333"> 
        <%if (ATTRIBUTENAME!=null){ if(tmp.equals("")&&(ATTRIBUTENAME.length>1)){ ++j;}}%>
        <input type="button" name="delete" value="Delete" onClick="godelete(<%=j%>)"> 
      </td>
    </tr>
    <%
	}//if
	%>
    <tr> 
      <td >&nbsp;</td>
      <td ><b></b></td>
      <td >&nbsp; </td>
      <td >&nbsp; </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td ><b> 
        <input type="button" name="add" value="add" onClick="goadd()">
        </b></td>
      <td >&nbsp; </td>
      <td >&nbsp; </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td >&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td colspan="3" > <div align="right"> 
          <input type="button" name="Submit4" value="  OK  " onClick="checknull()">
          <input type="button" name="Submit222" value="Cancel" onClick="window.location='workflow.jsp'">
          <input type="reset" name="Submit22" value="Reset">
        </div></td>
    </tr>
  </table>
</form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.doctypecreate
	function checknull(){
		var flag = false;
		if  (doc.DOCUMENTTYPENAME.value == ''||(doc.DOCUMENTTYPENAME.value!='' && isallspace(doc.DOCUMENTTYPENAME.value)) )
			{alert('Please insert Document type name !!!!'); return true;}
		else if (specialchar(doc.DOCUMENTTYPENAME.value))
					{alert('The specific Document type name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
		if (doc.ATTRIBUTENAME != null){
			if(doc.ATTRIBUTENAME.length>1){
				for (var i=0;i<doc.ATTRIBUTENAME.length;i++){
					if (doc.ATTRIBUTENAME[i].value == ''||(doc.ATTRIBUTENAME[i].value!='' && isallspace(doc.ATTRIBUTENAME[i].value)) ){
						alert("Please insert Attribute name!!!");flag = true;return true;		
					}//if
				}//for
			}else{
				if (doc.ATTRIBUTENAME.value == ''||(doc.ATTRIBUTENAME.value!='' && isallspace(doc.ATTRIBUTENAME.value)) ){
						alert("Please insert Attribute name!!!");flag = true;return true;		
				}//if
			}
		}if (flag == false){
			doc.submit();
		}
	}
	function isallspace(src)
	{
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}
		return true;
	}
	function goadd(j){
		doc.action = "doctypecreate.jsp?flag=add&tmp=";
		doc.submit();
	}
	function  godelete(i){
		doc.action = "doctypecreate.jsp?tmp="+i;
		doc.submit();
	}
	function specialchar(scr)
	{
		var i=0;
		for (i=0;i<scr.length;i++)
		{
			if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
			{
				return true;
			}
		}
	}
-->
</SCRIPT>