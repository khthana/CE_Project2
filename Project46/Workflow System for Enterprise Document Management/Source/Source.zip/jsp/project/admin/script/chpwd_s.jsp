<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("index.jsp");
	}
%>
<%
	String PASSWORD = thaistring.MS874ToUnicode(request.getParameter("PASSWORD"));
	if (PASSWORD==null){
		PASSWORD = "";
	}

	adminpower.writeuser.editUser(cur_user.getUSERNAME(),PASSWORD,cur_user.getFIRSTNAME(),cur_user.getLASTNAME(),cur_user.getISADMIN());

	String keyword = " where USERNAME='"+cur_user.getUSERNAME()+"' and PASSWORD='"+PASSWORD+"'";
	mybean.User user[];
	user = adminpower.readuser.getUser(keyword," ");
	session.setAttribute("CUR_USER",user[0]);

	response.sendRedirect("../home.jsp");
%>