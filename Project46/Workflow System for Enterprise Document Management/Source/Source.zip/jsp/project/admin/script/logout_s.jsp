<%
	session.setAttribute("CUR_USER",null);
	response.sendRedirect("../index.jsp");
%>