<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String message = "Are you sure you want to delete it?";

	mybean.User user[];
	user = adminpower.readuser.getUser(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<form name="userdelete" method="post" action="script/userdelete_s.jsp">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td class= "head" width="97%"><strong>Delete user</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0" height="22">
        <tr class="submit"> 
          <td width="8%" height="2" > <div align="center"> 
              <input type="checkbox" name="sample" onClick="tickAll(this)">
            </div></td>
          <td width="18%" height="2"> <div align="center">User name</div></td>
          <td width="29%" height="2"> <div align="center">First name</div></td>
          <td width="17%" height="2"> <div align="center">Last name</div></td>
          <td width="17%" height="2"> <div align="center">Isadmin</div></td>
        </tr>
<%
	for(int i=0;i<user.length;i++){
		if(user[i].getUSERNAME().equals(cur_user.getUSERNAME())){
		}
		else{
%>
        <tr> 
          <td width="8%"  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
              <input type="checkbox" name="USERNAME" value="<%=user[i].getUSERNAME()%>">
            </div></td>
          <td width="28%" > <div align="center"><%=user[i].getUSERNAME()%></div></td>
          <td width="18%"> <div align="center"><%=user[i].getFIRSTNAME()%></div></td>
          <td width="29%"> <div align="center"><%=user[i].getLASTNAME()%></div></td>
          <td width="17%"> <div align="center"> 
              <input type="checkbox" name="isadmin" value="1" <%if (user[i].getISADMIN().booleanValue()){out.print("checked");}%> disabled>
            </div></td>
        </tr>
        <%
		}//else
	  }//while
%>
      </table></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"><div align="right"><em><strong> 
          <input name="   OK   " type="button" id="   OK   2" value="   OK   " onClick="if (checkDel()) { if(confirm('<%=message%>')) {document.userdelete.submit();}} else {alert('Please select information which you want to delete !!!');}">
          <input type="button" name="Submit2" value="Cancel" onClick="window.location = 'account.jsp'">
          <input type="reset" name="Submit2" value="Reset">
          </strong></em></div></td>
  </tr>
</table>

  <p align="center">&nbsp;</p>
</form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
 function checkDel () {
	var o = document.userdelete;
	if (o.USERNAME != undefined){
		var boxCount = o.USERNAME.length;
		if (boxCount == undefined) {
			if (o.USERNAME.checked) {
				return true;
			} else {
				return false;
			}
		} else {
			for (i = 0 ; i < boxCount; i++) {
				if ( o.USERNAME[i].checked ) {
					return true;
				} 
			}
			return false;
		}
	}
	else {
		return false;
	}
 }

 function tickAll(b) {
	var o = document.userdelete;
	if (o.USERNAME != undefined){
		if (b.checked) {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = true;
				}
			}
		} else {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>
