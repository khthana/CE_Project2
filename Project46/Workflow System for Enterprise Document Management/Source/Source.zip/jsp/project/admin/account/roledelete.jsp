<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String message = "Are you sure you want to delete it?";

	mybean.Role role[];
	role = adminpower.readrole.getRole(" "," ");
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Delete role</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="roledelete" method="post" action="script/roledelete_s.jsp">
  <table width="76%" border="0">
    <tr> 
      <td width="6%" bgcolor="#CCCCCC"> 
        <div align="center"> 
          <input type="checkbox" name="sample" value="checkbox" onClick="tickAll(this)">
        </div>
      </td>
      <td width="21%" bgcolor="#CCCCCC"> 
        <div align="center"><font color="#333333"><b>Group name</b></font></div>
      </td>
      <td width="73%" bgcolor="#CCCCCC"> 
        <div align="center"><font color="#333333"><b>Description</b></font></div>
      </td>
    </tr>
<%
	for(int i=0;i<role.length;i++){
%>
	<tr> 
      <td width="6%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > 
        <div align="center"> 
          <input type="checkbox" name="ROLEID" value="<%=role[i].getROLEID()%>">
        </div>
      </td>
      <td width="21%"> 
        <div align="center"><%=role[i].getROLENAME()%></div>
      </td>
      <td width="73%"> 
        <div align="center"><%=role[i].getROLEDESC()%></div>
      </td>
    </tr>
<%
	}//if
%>
  </table>
    </td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height="30" colspan="2"><div align="right"><em><strong> 
        <input name="   OK   2" type="button" id="   OK   2" value="   OK   " onClick="if (confirm('<%= message%>')){document.roledelete.submit();}">
        <input type="button" name="Button2" value="Cancel" onClick="window.location='account.jsp'">
        <input type="reset" name="Submit2" value="Reset">
		</form>
        </strong></em> 
        <p></p>
        <em><strong> </strong></em></div></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
 function checkDel () {
	var o = document.roledelete;
	if (o.ROLEID != undefined){
		var boxCount = o.ROLEID.length;
		if (boxCount == undefined) {
			if (o.ROLEID.checked) {
				return true;
			} else {
				return false;
			}
		} else {
			for (i = 0 ; i < boxCount; i++) {
				if ( o.ROLEID[i].checked ) {
					return true;
				} 
			}
			return false;
		}
	}
	else {
		return false;
	}
 }

 function tickAll(b) {
	var o = document.roledelete;
	if (o.ROLEID != undefined){
		if (b.checked) {
			var boxCount = o.ROLEID.length;
			if (boxCount == undefined) {
				o.ROLEID.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.ROLEID[i].checked = true;
				}
			}
		} else {
			var boxCount = o.ROLEID.length;
			if (boxCount == undefined) {
				o.ROLEID.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.ROLEID[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>

