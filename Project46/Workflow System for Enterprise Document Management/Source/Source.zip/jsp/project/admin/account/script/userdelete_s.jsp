<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String USERNAME[] = request.getParameterValues("USERNAME");
//	account.createuser(username,password,firstname,lastname,isadmin);
	for (int i = 0;i<USERNAME.length;i++){
		USERNAME[i] = thaistring.MS874ToUnicode(USERNAME[i]);
		adminpower.writeuser.deleteUser(USERNAME[i]);
	}//for
	response.sendRedirect("../userdelete.jsp");
%>