<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String message = "Are you sure you want to delete it?";

	mybean.Group group[];
	group = adminpower.readgroup.getGroup(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<form name="gpdelete" method="post" action="script/gpdelete_s.jsp">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td class= "head" width="97%"><strong>Delete group</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
          <tr class="submit"> 
            <td width="9%"> <div align="center"> 
                <input type="checkbox" name="sample" value="checkbox" onClick="tickAll(this)">
              </div></td>
            <td width="25%"> <div align="center">Group name</div></td>
            <td width="66%"> <div align="center">Description</div></td>
          </tr>
          <%
	for(int i=0;i<group.length;i++){
%>
          <tr> 
            <td width="9%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
                <input type="checkbox" name="GROUPID" value="<%=group[i].getGROUPID()%>">
              </div></td>
            <td width="25%"> <div align="center"><%=group[i].getGROUPNAME()%></div></td>
            <td width="66%"> <div align="center"><%=group[i].getGROUPDESC()%></div></td>
          </tr>
          <%
	}//for
%>
        </table></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"><div align="right"><em><strong> 
          <input name="   OK   " type="button" id="   OK   2" value="   OK   " onClick="if (checkDel()) { if(confirm('<%=message%>')) {document.gpdelete.submit();}} else {alert('Please select information which you want to delete !!!');}">
          <input type="button" name="Submit2" value="Cancel" onClick="window.location = 'account.jsp'">
          <input type="reset" name="Submit2" value="Reset">
          </strong></em></div></td>
  </tr>
</table>
</form>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
 function checkDel () {
	var o = document.gpdelete;
	if (o.GROUPID != undefined){
		var boxCount = o.GROUPID.length;
		if (boxCount == undefined) {
			if (o.GROUPID.checked) {
				return true;
			} else {
				return false;
			}
		} else {
			for (i = 0 ; i < boxCount; i++) {
				if ( o.GROUPID[i].checked ) {
					return true;
				} 
			}
			return false;
		}
	}
	else {
		return false;
	}
 }

 function tickAll(b) {
	var o = document.gpdelete;
	if (o.GROUPID != undefined){
		if (b.checked) {
			var boxCount = o.GROUPID.length;
			if (boxCount == undefined) {
				o.GROUPID.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.GROUPID[i].checked = true;
				}
			}
		} else {
			var boxCount = o.GROUPID.length;
			if (boxCount == undefined) {
				o.GROUPID.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.GROUPID[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>
