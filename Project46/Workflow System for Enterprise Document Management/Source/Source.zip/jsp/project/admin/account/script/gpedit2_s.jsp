<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String GROUPID = thaistring.MS874ToUnicode(request.getParameter("GROUPID"));
	if (GROUPID==null){
		GROUPID = "";
	}
	String GROUPNAME = thaistring.MS874ToUnicode(request.getParameter("GROUPNAME"));
	if (GROUPNAME==null){
		GROUPNAME = "";
	}
	String GROUPDESC = thaistring.MS874ToUnicode(request.getParameter("GROUPDESC"));
	if (GROUPDESC==null){
		GROUPDESC = "";
	}
	adminpower.writegroup.editGroup(new Integer(GROUPID),GROUPNAME,GROUPDESC);
	response.sendRedirect("../gpedit.jsp");
%>