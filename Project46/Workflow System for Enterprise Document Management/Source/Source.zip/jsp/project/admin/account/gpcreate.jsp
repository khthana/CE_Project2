<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Please insert group information</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="gpcreate" method="post" action="script/gpcreate_s.jsp">
  <table width="100%" border="0" align="center">
          <tr> 
            <td width="24%">Group name : *</td>
      <td width="76%"> 
        <input type="text" name="GROUPNAME">
      </td>
    </tr>
          <tr> 
            <td width="24%">Description : *</td>
      <td width="76%"> 
        <textarea name="GROUPDESC" cols="50" rows="4"></textarea>
      </td>
    </tr>
    <tr> 
      <td height="21" colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" width="24%">&nbsp;</td>
      <td width="76%"> 
        <input name="   OK   " type="button" id="   OK   " value="   OK   " onClick="checknull();">
        <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
        <input type="reset" name="Submit3" value="Reset">
      </td>
    </tr>
  </table>
 </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.gpcreate
	function checknull(){
	if  (doc.GROUPNAME.value == ''||(doc.GROUPNAME.value!='' && isallspace(doc.GROUPNAME.value)) )
		{alert('Please insert groupname !!!!'); return true;} 
	else if (specialchar(doc.GROUPNAME.value))
		{alert('The specific group name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
	return false;
}
-->
</SCRIPT>
