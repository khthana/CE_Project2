<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Please insert user information</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="usercreate" method="post" action="script/usercreate_s.jsp">
        <table width="90%" border="0">
          <tr> 
            <td width="39%">First name : *</td>
            <td width="61%"> <input type="text" name="FIRSTNAME"> </td>
          </tr>
          <tr> 
            <td width="39%">Last name : *</td>
            <td width="61%"> <input type="text" name="LASTNAME"> </td>
          </tr>
          <tr> 
            <td width="39%" height="30">User name : *</td>
            <td width="61%" height="30"> <input type="text" name="USERNAME"></td>
             </tr>
          <tr> 
            <td width="39%">Password : *</td>
            <td width="61%"> <input type="password" name="PASSWORD" maxlength="12"> 
            </td>
          </tr>
          <tr> 
            <td width="39%">Confirm Password : *</td>
            <td width="61%"> <input type="password" name="REPASSWORD" maxlength="12"> 
            </td>
          </tr>
          <tr> 
            <td> <div align="right"> 
                <input type="checkbox" name="ISADMIN" value="true" >
              </div></td>
            <td>Administrator</td>
          </tr>
          <tr> 
            <td width="39%">&nbsp;</td>
            <td width="61%"> <input name="   OK   " type="button"  value="   OK   " onClick="checknull()"> 
              <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'"> 
              <input type="reset" name="Submit3" value="Reset"> </td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>

<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.usercreate
	function checknull(){
	if (doc.FIRSTNAME.value=='')
		{alert('Please insert firstname !!!!'); return true;} 
	else if (doc.LASTNAME.value=='')
		{alert('Please insert lastname !!!!'); return true;} 
	else if  (doc.USERNAME.value == ''||(doc.USERNAME.value!='' && isallspace(doc.USERNAME.value)) )
		{alert('Please insert username !!!!'); return true;} 
	else if (specialchar(doc.USERNAME.value))
		{alert('The specific username is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else if (doc.PASSWORD.value=='')
		{alert('Please insert password !!!!'); return true;} 
	else if (doc.REPASSWORD.value=='')
		{alert('Please insert confirm password !!!!'); return true;} 
	else if (doc.PASSWORD.value != doc.REPASSWORD.value)
		{alert ("The passwords you typed do not match!! Please retype the new password in the both boxes");return true}
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
	return false;
}
-->
</SCRIPT>
