<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	mybean.User user[];
	user = adminpower.readuser.getUser(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td class= "head" width="97%">Edit User</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
        <tr> 
          <td width="22%" class="submit"><div align="center"> User name </div></td>
          <td width="23%"  class="submit"> <div align="center">First name</div></td>
          <td width="36%"  class="submit"> <div align="center">Lastname</div></td>
          <td width="19%"  class="submit"> <div align="center">Isadmin</div></td>
        </tr>
<%
	for(int i=0;i<user.length;i++){
%>
        <tr> 
          <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); width="22%"> <div align="center"> <a href="useredit2.jsp?USERNAME=<%=user[i].getUSERNAME()%>"><%=user[i].getUSERNAME()%></a> 
            </div></td>
          <td width="23%"> <div align="center"><%=user[i].getFIRSTNAME()%></div></td>
          <td width="36%"> <div align="center"><%=user[i].getLASTNAME()%></div></td>
          <td width="19%"> <div align="center"> 
              <input type="checkbox" disabled name="ISADMIN" value="1" <%if (user[i].getISADMIN().booleanValue()){out.print("checked");}%>>
            </div></td>
        </tr>
        <%
	}//while
%>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><div align="right"><em><strong> 
        <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
        </strong></em></div></td>
  </tr>
</table>
<p align="left"><em><strong></strong></em></p>
<p align="left">&nbsp;</p>
  
<p align="center">&nbsp; </p>
  </body>
</html>
