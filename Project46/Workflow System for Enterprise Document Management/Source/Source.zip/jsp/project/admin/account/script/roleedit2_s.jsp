<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String ROLEID = thaistring.MS874ToUnicode(request.getParameter("ROLEID"));
	if (ROLEID==null){
		ROLEID = "";
	}
	String ROLENAME = thaistring.MS874ToUnicode(request.getParameter("ROLENAME"));
	if (ROLENAME==null){
		ROLENAME = "";
	}
	String ROLEDESC = thaistring.MS874ToUnicode(request.getParameter("ROLEDESC"));
	if (ROLEDESC==null){
		ROLEDESC = "";
	}
	adminpower.writerole.editRole(new Integer(ROLEID),ROLENAME,ROLEDESC);
	response.sendRedirect("../roleedit.jsp");
%>