<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Please insert role information</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="rolecreate" method="post" action="script/rolecreate_s.jsp">
  <table width="100%" border="0" align="center">
    <tr> 
      <td width="29%"> 
        <div align="right">Role name : *</div>
      </td>
      <td width="71%"> 
        <input type="text" name="ROLENAME">
      </td>
    </tr>
          <tr> 
            <td width="29%">
<div align="right">Description : *</div>
      </td>
      <td width="71%"> 
        <textarea name="ROLEDESC" cols="50" rows="4"></textarea>
      </td>
    </tr>
    <tr> 
      <td height="21" colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" colspan="2"> 
        <div align="center"> 
          <input name="   OK   " type="Button" id="   OK   " value="   OK   " onClick="checknull();">
          <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
          <input type="reset" name="Submit3" value="Reset">
        </div>
      </td>
    </tr>
  </table>
</form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.rolecreate
	function checknull(){
	if  (doc.ROLENAME.value == ''||(doc.ROLENAME.value!='' && isallspace(doc.ROLENAME.value)) )
		{alert('Please insert role name !!!!'); return true;} 
	else if (specialchar(doc.ROLENAME.value))
		{alert('The specific role name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;} 
	else 
		{doc.submit();}
	}
function isallspace(src)
{
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++)
	{
		if (src.charAt(i)!=' ')
		{
			return false;
		}
	}
	return true;
}
function specialchar(scr)
{
	var i=0;
	for (i=0;i<scr.length;i++)
	{
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\=')
		{
			return true;
		}
	}
	return false;
}
-->
</SCRIPT>