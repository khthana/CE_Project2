<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String USERNAME = thaistring.MS874ToUnicode(request.getParameter("USERNAME"));
	if (USERNAME==null){
		USERNAME = "";
	}
	String FIRSTNAME = thaistring.MS874ToUnicode(request.getParameter("FIRSTNAME"));
	if (FIRSTNAME==null){
		FIRSTNAME = "";
	}
	String LASTNAME = thaistring.MS874ToUnicode(request.getParameter("LASTNAME"));
	if (LASTNAME==null){
		LASTNAME = "";
	}
	String PASSWORD = thaistring.MS874ToUnicode(request.getParameter("PASSWORD"));
	if (PASSWORD==null){
		PASSWORD = "";
	}
	String ISADMIN = thaistring.MS874ToUnicode(request.getParameter("ISADMIN"));
	if (ISADMIN==null){
		ISADMIN = "false";
	}

	adminpower.writeuser.addUser(USERNAME,PASSWORD,FIRSTNAME,LASTNAME,new Boolean(ISADMIN));
	response.sendRedirect("../account.jsp");
%>
