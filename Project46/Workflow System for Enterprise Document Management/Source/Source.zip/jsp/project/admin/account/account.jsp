<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<font face="Cordia New, CordiaUPC"></font> 
<table width="100%">
  <tr> 
    <td  colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class= "head"><strong>Account management</strong></td>
  </tr>
  <tr> 
    <td width="3%">&nbsp;</td>
    <td class= "head" width="97%">&nbsp;</td>
  </tr>
  <tr> 
    <td >&nbsp;</td>
    <td> <div align="left"></div>
      <table width="45%">
        <tr> 
          <td width="33%" class ="submit"><div align="center">User</div></td>
          <td width="34%" class ="submit"><div align="center">Group</div></td>
          <td width="33%" class ="submit"><div align="center">Role</div></td>
        </tr>
        <tr> 
          <td  bordercolor="#CCCCCC" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="usercreate.jsp">Create</a></div></td>
          <td  bordercolor="#CCCCCC" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="gpcreate.jsp">Create</a></div></td>
          <td  bordercolor="#CCCCCC" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="rolecreate.jsp">Create</a></div></td>
        </tr>
        <tr> 
          <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="useredit.jsp">Edit</a></div></td>
          <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="gpedit.jsp">Edit</a></div></td>
          <td  bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="roleedit.jsp">Edit</a></div></td>
        </tr>
        <tr> 
          <td height="22" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="userdelete.jsp">Delete</a></div></td>
          <td height="22" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="gpdelete.jsp">Delete</a></div></td>
          <td height="22" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this);> <div align="center"><a href="roledelete.jsp">Delete</a></div></td>
        </tr>
      </table>
        
      </td>
  </tr>
</table>
<div align="center">  


</body>
</html>
