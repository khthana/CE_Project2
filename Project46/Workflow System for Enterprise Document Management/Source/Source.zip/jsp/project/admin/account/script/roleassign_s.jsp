<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../../index.jsp");
	}
%>
<%
	String USERNAME[] = request.getParameterValues("USERNAME");
	String GROUPID[] = request.getParameterValues("GROUPID");
	String ROLEID = thaistring.MS874ToUnicode(request.getParameter("ROLEID"));
	if (ROLEID==null){
		ROLEID = "";
	}

	adminpower.writeroleuser.deleteRoleallUser(new Integer(ROLEID));
	if (USERNAME!=null){
		for (int i = 0;i<USERNAME.length;i++){
			USERNAME[i] = thaistring.MS874ToUnicode(USERNAME[i]);
			adminpower.writeroleuser.addRoleUser(new Integer(ROLEID),USERNAME[i]);
		}//for
	}//if

	adminpower.writerolegroup.deleteRoleallGroup(new Integer(ROLEID));
	if(GROUPID!=null){
		for (int i = 0;i<GROUPID.length;i++){
			GROUPID[i] = thaistring.MS874ToUnicode(GROUPID[i]);
			adminpower.writerolegroup.addRoleGroup(new Integer(GROUPID[i]),new Integer(ROLEID));
		}//for
	}//if

	response.sendRedirect("../roleedit.jsp");
%>