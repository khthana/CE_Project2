<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String USERNAME = thaistring.MS874ToUnicode(request.getParameter("USERNAME"));
	if (USERNAME==null){
		USERNAME = "";
	}

	String keyword = " where USERNAME='"+USERNAME+"' ";
	mybean.User user[];
	user = adminpower.readuser.getUser(keyword," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Edit User</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="useredit" method="post" action="script/useredit2_s.jsp">
        <table width="90%" border="0">
          <tr> 
            <td width="39%">First name : *</td>
            <td width="61%"> <input type="text" name="FIRSTNAME" value='<%=user[0].getFIRSTNAME()%>'> 
            </td>
          </tr>
          <tr> 
            <td width="39%">Last name : *</td>
            <td width="61%"> <input type="text" name="LASTNAME" value='<%=user[0].getLASTNAME()%>'> 
            </td>
          </tr>
          <tr> 
            <td width="39%" height="30">User name : *</td>
            <td width="61%" height="30"> <input type="text" name="USERNAME" disabled value='<%=user[0].getUSERNAME()%>'></td>
          </tr>
          <tr> 
            <td width="39%">Password : *</td>
            <td width="61%"> <input type="password" name="PASSWORD" value='<%=user[0].getPASSWORD()%>'> 
            </td>
          </tr>
          <tr> 
            <td width="39%">Confirm Password : *</td>
            <td width="61%"> <input type="password" name="REPASSWORD" value='<%=user[0].getPASSWORD()%>'> 
            </td>
          </tr>
          <tr> 
            <td> <div align="right"> 
                <input type="checkbox" name="ISADMIN" value="true" <%if (user[0].getISADMIN().booleanValue()){out.print("checked");}%>>
              </div></td>
            <td>Administrator</td>
          </tr>
          <tr> 
            <td width="39%">&nbsp;</td>
            <td width="61%"> <input name="   OK   " type="button"  value="   OK   " onClick="checknull()"> 
              <input type="button" name="Button" value="Cancel" onClick="window.location='useredit.jsp'"> 
              <input type="reset" name="Submit3" value="Reset"> </td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>


</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.useredit
	function checknull(){
	if (doc.FIRSTNAME.value=='')
		{alert('Please insert firstname !!!!'); return true;} 
	else if (doc.LASTNAME.value=='')
		{alert('Please insert lastname !!!!'); return true;} 
	else if (doc.PASSWORD.value=='')
		{alert('Please insert password !!!!'); return true;} 
	else if (doc.REPASSWORD.value=='')
		{alert('Please insert confirm password !!!!'); return true;} 
	else if (doc.PASSWORD.value != doc.REPASSWORD.value)
		{alert ("The passwords you typed do not match!! Please retype the new password in the both boxes");return true}
	else 
		{doc.USERNAME.disabled=false;doc.submit();}
	}
</SCRIPT>

