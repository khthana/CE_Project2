<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String GROUPID = thaistring.MS874ToUnicode(request.getParameter("GROUPID"));
	if (GROUPID==null){
		GROUPID = "";
	}

	String keyword = " where GROUPID="+GROUPID+" ";
	mybean.Group group[];
	group = adminpower.readgroup.getGroup(keyword," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="go" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%">
  <tr> 
    <td height="39">&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class="head" width="98%"><strong>Edit group</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td class="head">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="gpedit2" method="post" action="script/gpedit2_s.jsp">
  <table width="100%" border="0" align="center">
    <tr> 
      <td width="39%"><div align="right">Group name : * </div></td>
      <td width="61%"> 
		<input type="hidden" name="GROUPID" value="<%=group[0].getGROUPID()%>">
        <input type="text" name="GROUPNAME" maxlength="25" size="25" value='<%=group[0].getGROUPNAME()%>'>
      </td>
    </tr>
    <tr> 
      <td width="39%"><div align="right">Description : *</div></td>
      <td width="61%"> 
        <textarea name="GROUPDESC" cols="50" rows="4"><%=group[0].getGROUPDESC()%></textarea>
      </td>
    </tr>
    <tr> 
      <td height="21" colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" width="39%">&nbsp;</td>
      <td width="61%"> 
        <input name="   OK   " type="button" id="   OK   " value="   OK   " onClick="checknull()">
        <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
        <input type="reset" name="Submit3" value="Reset">
      </td>
    </tr>
  </table>
 </form></td>
  </tr>
</table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
var doc = document.gpedit2
function checknull(){
	if(doc.GROUPNAME.value == ''||(doc.GROUPNAME.value!='' && isallspace(doc.GROUPNAME.value)) ){
		alert('Please insert group name !!!!'); return true;
	}//if
	else if (specialchar(doc.GROUPNAME.value)){
		alert('The specific group name is not valid to use \/[]";:|<>+=,*? !!!!'); return true;
	}//else
	else{
		doc.submit();
	}//else
}//function
function isallspace(src){
	var i=0;
	var testtemp=0;
	for (i=0;i<src.length;i++){
		if (src.charAt(i)!=' '){
			return false;
		}//if
	}//for
	return true;
}//function
function specialchar(scr){
	var i=0;
	for (i=0;i<scr.length;i++){
		if (scr.charAt(i)=='/'|| scr.charAt(i)=='\\'|| scr.charAt(i)=='\"'|| scr.charAt(i)==':' || scr.charAt(i)==';'|| scr.charAt(i)==','|| scr.charAt(i)=='\+'|| scr.charAt(i)=='*'|| scr.charAt(i)=='?'|| scr.charAt(i)=='['|| scr.charAt(i)==']'|| scr.charAt(i)=='<'|| scr.charAt(i)=='>'|| scr.charAt(i)=='\''|| scr.charAt(i)=='\='){
			return true;
		}//if
	}//for
	return false;
}//function
-->
</SCRIPT>
