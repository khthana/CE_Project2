<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String ROLEID = thaistring.MS874ToUnicode(request.getParameter("ROLEID"));
	if (ROLEID==null){
		ROLEID = "";
	}

	String keyword = " where ROLEID="+ROLEID+" ";
	mybean.Role role[];
	role = adminpower.readrole.getRole(keyword," ");

	mybean.User all_user[];
	all_user = adminpower.readuser.getUser(" "," ");

	mybean.Group all_group[];
	all_group = adminpower.readgroup.getGroup(" "," ");
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Assing user &amp; group and role</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="roleassign" method="post" action="script/roleassign_s.jsp">
	<input type="hidden" name="ROLEID" value="<%=role[0].getROLEID()%>">
		<table width="100%" border="0" align="center">
          <tr> 
            <td height="20" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="20" width="50%"> <div align="left">Role : </div></td>
            <td height="20" width="54%"><%=role[0].getROLENAME()%></td>
          </tr>
          <tr> 
            <td height="20" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="66" width="50%"> <table width="100%" align="center">
                <tr class="submit"> 
                  <td width="13%"> <div align="center"> 
                      <input type="checkbox" name="alluser" value="checkbox" onClick="tickAll(this)">
                    </div></td>
                  <td width="87%"> <div align="center">User list</div></td>
                </tr>
<%
	for(int i=0;i<all_user.length;i++){
		mybean.RoleUser roleuser[];
		String keyword_user = " where USERNAME='"+all_user[i].getUSERNAME()+"' and ROLEID="+ROLEID;
		roleuser = adminpower.readroleuser.getRoleUser(keyword_user," ");
%>
                <tr> 
                  <td bgcolor="#eeeeee" onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
                      <input type="checkbox" name="USERNAME" value="<%=all_user[i].getUSERNAME()%>" <%if (roleuser.length==1) {out.print("checked");}%>>
                    </div></td>
                  <td> <div align="center"><%=all_user[i].getUSERNAME()%></div></td>
                </tr>
<%
	}//for all_user
%>
              </table></td>
            <td height="66" width="54%"> <div align="center"> 
                <table width="75%" border="0" align="center">
                  <tr class="submit"> 
                    <td width="13%"> <div align="center"> 
                        <input type="checkbox" name="allgp" value="checkbox" onClick="tickAll1(this)">
                      </div></td>
                    <td width="87%"> <div align="center">Group list </div></td>
                  </tr>
<%
	for(int i=0;i<all_group.length;i++){
		mybean.RoleGroup rolegroup[];
		String keyword_group = " where GROUPID="+all_group[i].getGROUPID()+" and ROLEID="+ROLEID;
		rolegroup = adminpower.readrolegroup.getRoleGroup(keyword_group," ");
%>
				  <tr> 
                    <td bgcolor="#eeeeee" onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
                        <input type="checkbox" name="GROUPID" value="<%=all_group[i].getGROUPID()%>" <%if (rolegroup.length==1) {out.print("checked");}%>>
                      </div></td>
                    <td> <div align="center"><%=all_group[i].getGROUPNAME()%></div></td>
                  </tr>
<%
	}//for all_group
%>
				</table>
              </div></td>
          </tr>
          <tr> 
            <td height="21" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="26" colspan="2"> <div align="center"> 
                <input name="   OK   " type="submit" id="   OK   " value="   OK   ">
                <input type="button" name="Button" value="Cancel" onClick="window.location='roleedit.jsp'">
                <input type="reset" name="Submit3" value="Reset">
              </div></td>
          </tr>
        </table>

  </form></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  </table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
  function tickAll(b) {
	 var o = document.roleassign;
	if (o.USERNAME != undefined){
		if (b.checked) {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = true;
				}
			}
		} else {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = false;
				}
			}
		}
	}
 }
   function tickAll1(b) {
	 var o = document.roleassign;
	if (o.GROUPID != undefined){
		if (b.checked) {
			var boxCount = o.GROUPID.length;
			if (boxCount == undefined) {
				o.GROUPID.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.GROUPID[i].checked = true;
				}
			}
		} else {
			var boxCount = o.GROUPID.length;
			if (boxCount == undefined) {
				o.GROUPID.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.GROUPID[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>
