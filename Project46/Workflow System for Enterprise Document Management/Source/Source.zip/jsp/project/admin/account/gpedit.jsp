<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	mybean.Group group[];
	group= adminpower.readgroup.getGroup(" "," ");
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Edit group</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
        <tr class="submit"> 
          <td width="21%"> <div align="center"><b>Group name</b></div></td>
          <td width="37%"> <div align="center"><b>Description</b></div></td>
          <td width="12%"> <div align="center"><b>Edit</b></div></td>
          <td width="30%"> <div align="center"><b>Assign user to group</b></div></td>
        </tr>
        <%
for(int i=0;i<group.length;i++){
 %>
        <tr> 
          <td width="21%"> <div align="center"><%=group[i].getGROUPNAME()%></div></td>
          <td width="37%"> <div align="center"><%=group[i].getGROUPDESC()%></div></td>
          <td width="12%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"><a href="gpedit2.jsp?GROUPID=<%=group[i].getGROUPID()%>">Edit</a></div></td>
          <td width="30%" bgcolor=#eeeeee onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"><a href="gpassign.jsp?GROUPID=<%=group[i].getGROUPID()%>">Assign</a></div></td>
        </tr>
        <%}//while%>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"><div align="right"><em><strong> 
        <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
        </strong></em></div></td>
  </tr>
</table>
<p align="left">&nbsp;</p>
<p align="center">&nbsp; </p>
</body>
</html>
