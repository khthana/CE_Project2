<%@page contentType="text/html; charset=WINDOWS-874"%> 
<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("../index.jsp");
	}
%>
<%
	String GROUPID = thaistring.MS874ToUnicode(request.getParameter("GROUPID"));
	if (GROUPID==null){
		GROUPID = "";
	}

	String keyword = " where GROUPID="+GROUPID+" ";
	mybean.Group group[];
	group = adminpower.readgroup.getGroup(keyword," ");

	mybean.User all_user[];
	all_user = adminpower.readuser.getUser(" "," ");
%>
<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="../../style.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="../../code.js"></SCRIPT>

<body class="menu" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%">
  <tr> 
    <td height="51" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="2%">&nbsp;</td>
    <td class= "head" width="98%"><strong>Assing user to group</strong></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form name="gpassign" method="post" action="script/gpassign_s.jsp">
	<input type="hidden" name="GROUPID" value="<%=group[0].getGROUPID()%>">
        <table width="95%" border="0" align="center">
          <tr> 
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td>Group name : </td>
            <td> <%=group[0].getGROUPNAME()%></td>
          </tr>
          <tr> 
            <td height="21" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="66" colspan="2"> <table width="40%">
                <tr class="submit"> 
                  <td width="13%"> <div align="center"> 
                      <input type="checkbox" name="sample" value="checkbox" onClick="tickAll(this)">
                    </div></td>
                  <td width="87%"> <div align="center">User list</div></td>
                </tr>
<%
	for(int i=0;i<all_user.length;i++){
		mybean.GroupUser groupuser[];
		String keyword_user = " where USERNAME='"+all_user[i].getUSERNAME()+"' and GROUPID="+GROUPID;
		groupuser = adminpower.readgroupuser.getGroupUser(keyword_user," ");
%>
                <tr> 
                  <td bgcolor="#eeeeee" onMouseOver=MouseOver(this); 
          onMouseOut=MouseOut(this); > <div align="center"> 
                      <input name="USERNAME" type="checkbox" value="<%=all_user[i].getUSERNAME()%>" <%if (groupuser.length==1) {out.print("checked");}%>>
                    </div></td>
                  <td> <div align="center"><%=all_user[i].getUSERNAME()%></div></td>
                </tr>
<%
	}//for
%>
              </table></td>
          </tr>
          <tr> 
            <td height="21" colspan="2">&nbsp;</td>
          </tr>
          <tr> 
            <td height="26" width="39%">&nbsp;</td>
            <td width="61%"> <input name="   OK   2" type="submit" id="   OK   2" value="   OK   " > 
              &nbsp; <input type="button" name="Button" value="Cancel" onClick="window.location='gpedit.jsp'"> 
              <input type="reset" name="Submit3" value="Reset"> </td>
          </tr>
        </table>
 </form></td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  </table>
</body>
</html>
<SCRIPT LANGUAGE="JavaScript">
<!--
 function tickAll(b) {
	var o = document.gpassign;
	if (o.USERNAME != undefined){
		if (b.checked) {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = true;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = true;
				}
			}
		} else {
			var boxCount = o.USERNAME.length;
			if (boxCount == undefined) {
				o.USERNAME.checked = false;
			} else {
				for (i = 0 ; i < boxCount; i++) {
					o.USERNAME[i].checked = false;
				}
			}
		}
	}
 }
 function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);}
-->
</SCRIPT>