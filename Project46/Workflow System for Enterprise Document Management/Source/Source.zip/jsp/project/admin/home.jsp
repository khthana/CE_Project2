<%@page contentType="text/html; charset=WINDOWS-874"%> 
<jsp:useBean id="thaistring" class="mybean.ThaiString" scope="application"/>
<jsp:useBean id="adminpower" class="mybean.AdminPower" scope="application"/>
<%
	mybean.User cur_user;
	cur_user=(mybean.User)session.getAttribute("CUR_USER");
	if((cur_user==null)||(!(cur_user.getISADMIN().booleanValue()))){
		response.sendRedirect("index.jsp");
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<jsp:include page="./script/authen_admin.jsp" />
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><font size="+3"><strong><em>Welcome <%=cur_user.getFIRSTNAME()+" "+cur_user.getLASTNAME()%><br>You are Administrator</em></strong></font></p>
</body>
</html>
