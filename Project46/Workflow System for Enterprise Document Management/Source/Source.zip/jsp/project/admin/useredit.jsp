<%@ page language="java" import="java.sql.*"%>
<jsp:useBean id="database" class="mybean.Database" scope="application"/>
<%
	ResultSet rs;
	String sql = "select * from tb_user order by username";
	rs = database.executeQuery(sql);
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>user edit</TITLE>


<META http-equiv=Content-Type content="text/html; charset=tis-620"><LINK 
href="/../../style.css" type=text/css rel=stylesheet>

<body>
<p align="center">&nbsp;</p>
<p align="left"><em><strong><font size="+2" color="#CC0000">Edit User</font></strong></em></p>
<table width="70%" border="0">
  <tr> 
    <td width="22%" class="submit"> User name </td>
    <td width="23%"  class="submit"> <div align="center">First name</div></td>
    <td width="36%"  class="submit"> <div align="center">Lastname</div></td>
    <td width="19%"  class="submit"> <div align="center">Isadmin</div></td>
  </tr>
  <%
	while (rs.next()){
%>
  <tr> 
    <td width="22%"  class="submit"> <div align="center"><a href="useredit2.jsp?username=<%=rs.getString("username")%>"><%=rs.getString("username")%></a></div></td>
    <td width="23%"> <div align="center"><%=rs.getString("firstname")%></div></td>
    <td width="36%"> <div align="center"><%=rs.getString("lastname")%></div></td>
    <td width="19%"> <div align="center"> 
        <input type="checkbox" disabled name="isadmin" value="1" <%if (rs.getBoolean ("isadmin")==true){out.print("checked");}%>>
      </div></td>
  </tr>
  <%
	}//while
%>
</table>
<p align="left">&nbsp;</p>
  
<p align="center">
  <input type="button" name="Button" value="Cancel" onClick="window.location='account.jsp'">
</p>
  </body>
</html>
