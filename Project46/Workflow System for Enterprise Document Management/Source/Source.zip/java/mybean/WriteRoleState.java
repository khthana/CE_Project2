package mybean;
import java.sql.*;

public class WriteRoleState{

	public void addRoleState(Integer ROLEID,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "insert into ROLESTATE values ("+ROLEID+","+STATEID+","+temp_canreject+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addRoleState
	
	public void editRoleState(Integer ROLEID,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "update ROLESTATE set CANREJECT="+temp_canreject+" where ROLEID="+ROLEID+" and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editRoleState

	public void deleteRoleState(Integer ROLEID,Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLESTATE where ROLEID="+ROLEID+" and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleState

	public void deleteRoleallState(Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLESTATE where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleallState

}//class WriteRoleState