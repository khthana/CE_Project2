package mybean;
import java.sql.*;

public class WriteGroup{

	public void addGroup(String GROUPNAME,String GROUPDESC)throws ClassNotFoundException,SQLException{
		GROUPNAME = GROUPNAME.toUpperCase();
		GROUPDESC = GROUPDESC.toUpperCase();

		String sql = "insert into GROUP_TABLE values ('"+GROUPNAME+"','"+GROUPDESC+"')";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addGroup
	
	public void editGroup(Integer GROUPID,String GROUPNAME,String GROUPDESC)throws ClassNotFoundException,SQLException{
		GROUPNAME = GROUPNAME.toUpperCase();
		GROUPDESC = GROUPDESC.toUpperCase();

		String sql = "update GROUP_TABLE set GROUPNAME='"+GROUPNAME+"',GROUPDESC='"+GROUPDESC+"' where GROUPID="+GROUPID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editGroup

	public void deleteGroup(Integer GROUPID)throws ClassNotFoundException,SQLException{

		String sql = "delete from GROUP_TABLE where GROUPID="+GROUPID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteGroup

}//class WriteGroup