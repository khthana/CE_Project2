package mybean;
import java.sql.*;

public class ReadUser{

	public int getNumberUser(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from USER_TABLE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberUser

	public User[] getUser(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberUser(keyword);
		String sql;
		sql = "select * from USER_TABLE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		User user[]= new User[count];
		for(int i=0;i<count;i++){
			rs1.next();
			user[i] = new User(rs1.getString("USERNAME"),rs1.getString("PASSWORD"),rs1.getString("FIRSTNAME"),rs1.getString("LASTNAME"),new Boolean(rs1.getBoolean("ISADMIN")));
		}//for
		return user;
	}//getUser

}//class ReadUser