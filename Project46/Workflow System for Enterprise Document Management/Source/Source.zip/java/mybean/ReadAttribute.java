package mybean;
import java.sql.*;

public class ReadAttribute{

	public int getNumberAttribute(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from ATTRIBUTE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberAttribute

	public Attribute[] getAttribute(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberAttribute(keyword);
		String sql;
		sql = "select * from ATTRIBUTE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		Attribute attribute[]= new Attribute[count];
		for(int i=0;i<count;i++){
			rs1.next();
			attribute[i] = new Attribute(new Integer(rs1.getInt("ATTRIBUTEID")),new Integer(rs1.getInt("DOCUMENTTYPEID")),rs1.getString("ATTRIBUTENAME"),rs1.getString("ATTRIBUTETYPE"));
		}//for
		return attribute;
	}//getAttribute

}//class ReadAttribute