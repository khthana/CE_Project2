package mybean;
import java.sql.*;

public class ReadGroupState{

	public int getNumberGroupState(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from GROUPSTATE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberGroupState

	public GroupState[] getGroupState(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberGroupState(keyword);
		String sql;
		sql = "select * from GROUPSTATE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		GroupState groupstate[]= new GroupState[count];
		for(int i=0;i<count;i++){
			rs1.next();
			groupstate[i] = new GroupState(new Integer(rs1.getInt("GROUPID")),new Integer(rs1.getInt("STATEID")),new Boolean(rs1.getBoolean("CANREJECT")));
		}//for
		return groupstate;
	}//getGroupState

}//class ReadGroupState