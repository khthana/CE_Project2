package mybean;
import java.sql.*;

public class WriteRoleUser{

	public void addRoleUser(Integer ROLEID,String USERNAME)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();

		String sql = "insert into ROLEUSER values ("+ROLEID+",'"+USERNAME+"')";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addRoleUser
	
	public void deleteRoleUser(Integer ROLEID,String USERNAME)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();
		
		String sql = "delete from ROLEUSER where ROLEID="+ROLEID+" and USERNAME='"+USERNAME+"'";
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleUser

	public void deleteRoleallUser(Integer ROLEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLEUSER where ROLEID="+ROLEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleallUser
	
}//class WriteRoleUser