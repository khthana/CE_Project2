package mybean;
import java.sql.*;

public class WriteRole{

	public void addRole(String ROLENAME,String ROLEDESC)throws ClassNotFoundException,SQLException{
		ROLENAME = ROLENAME.toUpperCase();
		ROLEDESC = ROLEDESC.toUpperCase();

		String sql = "insert into ROLE_TABLE values ('"+ROLENAME+"','"+ROLEDESC+"')";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addRole
	
	public void editRole(Integer ROLEID,String ROLENAME,String ROLEDESC)throws ClassNotFoundException,SQLException{
		ROLENAME = ROLENAME.toUpperCase();
		ROLEDESC = ROLEDESC.toUpperCase();

		String sql = "update ROLE_TABLE set ROLENAME='"+ROLENAME+"',ROLEDESC='"+ROLEDESC+"' where ROLEID="+ROLEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editRole

	public void deleteRole(Integer ROLEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLE_TABLE where ROLEID="+ROLEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRole

}//class WriteRole