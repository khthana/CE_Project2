package mybean;
import java.sql.*;

public class WorkFlow{
	private Integer WORKFLOWID;
	private String WORKFLOWNAME;
	private Integer DOCUMENTTYPEID;

	public DocumentType[] getDOCUMENTTYPE()throws ClassNotFoundException,SQLException{
		ReadDocumentType readdocumenttype = new ReadDocumentType();
		String keyword = " where DOCUMENTTYPEID="+this.DOCUMENTTYPEID+" ";
		DocumentType documenttype[];
		documenttype = readdocumenttype.getDocumentType(keyword," ");
		return documenttype;
	}//getDOCUMENTTYPE

	public Integer getWORKFLOWID(){
		return this.WORKFLOWID;
	}//getWORKFLOWID

	public String getWORKFLOWNAME(){
		return this.WORKFLOWNAME;
	}//getWORKFLOWNAME

	public Integer getDOCUMENTTYPEID(){
			return this.DOCUMENTTYPEID;
	}//getDOCUMENTTYPEID

	public WorkFlow(Integer WORKFLOWID,String WORKFLOWNAME,Integer DOCUMENTTYPEID){
		this.WORKFLOWID = WORKFLOWID;
		this.WORKFLOWNAME = WORKFLOWNAME;
		this.DOCUMENTTYPEID = DOCUMENTTYPEID;		
	}//Constructor WorkFlow

}//class WorkFlow