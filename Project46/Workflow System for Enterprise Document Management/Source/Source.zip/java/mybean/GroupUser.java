package mybean;

public class GroupUser{
	private String USERNAME;
	private Integer GROUPID;

	public String USERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public Integer getGROUPID(){
		return this.GROUPID;
	}//getGROUPID

	public GroupUser(String USERNAME,Integer GROUPID){
		this.USERNAME = USERNAME;
		this.GROUPID = GROUPID;
	}//Constructor GroupUser

}//class GroupUser