package mybean;
import java.sql.*;

public class WriteUserState{

	public void addUserState(String USERNAME,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "insert into USERSTATE values ('"+USERNAME+"',"+STATEID+","+temp_canreject+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addUserState
	
	public void editUserState(String USERNAME,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "update USERSTATE set CANREJECT="+temp_canreject+" where USERNAME='"+USERNAME+"' and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editUserState

	public void deleteUserState(String USERNAME,Integer STATEID)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();

		String sql = "delete from USERSTATE where USERNAME='"+USERNAME+"' and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteUserState

	public void deleteUserallState(Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from USERSTATE where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteUserallState

}//class WriteUserState