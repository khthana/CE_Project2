package mybean;

public class GroupState{
	private Integer GROUPID;
	private Integer STATEID;
	private Boolean CANREJECT;

	public Integer getGROUPID(){
		return this.GROUPID;
	}//getGROUPID

	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID

	public Boolean getCANREJECT(){
		return this.CANREJECT;
	}//getCANREJECT

	public GroupState(Integer GROUPID,Integer STATEID,Boolean CANREJECT){
		this.GROUPID = GROUPID;		
		this.STATEID = STATEID;
		this.CANREJECT = CANREJECT;
	}//Constructor GroupState

}//class GroupState