package mybean;
import java.sql.*;

public class WriteWork{

	public void addWork(String WORKNAME,Integer DOCUMENTTYPEID,Integer PRIORITY,User CREATED_BY)throws ClassNotFoundException,SQLException{
		WORKNAME = WORKNAME.toUpperCase();
		
		WorkFlow workflow[];
		String keyword = " where DOCUMENTTYPEID="+DOCUMENTTYPEID+" ";
		ReadWorkFlow readworkflow = new ReadWorkFlow();
		workflow = readworkflow.getWorkFlow(keyword," ");
		
		State state[];
		//STATETYPE = 1 = START STATE
		String keyword1 = " where WORKFLOWID="+workflow[0].getWORKFLOWID()+" and STATETYPE='1' ";
		ReadState readstate = new ReadState();
		state = readstate.getState(keyword1," ");

		String sql = "insert into WORK_TABLE (WORKNAME,STATEID,PRIORITY,CREATED_BY,CREATED_DATE) values ('"+WORKNAME+"',"+state[0].getSTATEID()+","+PRIORITY+",'"+CREATED_BY.getUSERNAME()+"',CONVERT(CHAR(10),GETDATE(),121))";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addWork
	
	public void editWork(Integer WORKID,String WORKNAME,Integer STATEID,Integer PRIORITY,String FILENAME,User user)throws ClassNotFoundException,SQLException{
		WORKNAME = WORKNAME.toUpperCase();
		FILENAME = FILENAME.toUpperCase();
		
		String keyword = "where WORKID="+WORKID+" ";

		Work work[];
		LogWork logwork[];

		ReadWork readwork = new ReadWork();
		ReadLogWork readlogwork = new ReadLogWork();		
		WriteLogWork writelogwork = new WriteLogWork();		

		work = readwork.getWork(keyword," ");
		logwork = readlogwork.getLogWork(keyword," ");

		Integer STATEBEFORE = work[0].getSTATEID();
		Date TIMEBEFORE;
		if(logwork.length==0){
			TIMEBEFORE = work[0].getCREATED_DATE();
		}//if
		else{
			TIMEBEFORE = logwork[logwork.length-1].getTIMEAFTER();
		}//else
		writelogwork.addLogWork(WORKID,STATEBEFORE,STATEID,user.getUSERNAME(),TIMEBEFORE);

		String sql = "update WORK_TABLE set WORKNAME='"+WORKNAME+"',STATEID="+STATEID+",PRIORITY="+PRIORITY+",FILENAME='"+FILENAME+"',USERNAME=null,TAKEN_DATE=null where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editWork

	public void rejectWork(Integer WORKID,String WORKNAME,Integer STATEID,Integer PRIORITY,String FILENAME,User user)throws ClassNotFoundException,SQLException{
		WORKNAME = WORKNAME.toUpperCase();
		FILENAME = FILENAME.toUpperCase();
		
		String keyword = "where WORKID="+WORKID+" ";

		LogWork logwork[];

		ReadLogWork readlogwork = new ReadLogWork();		
		WriteLogWork writelogwork = new WriteLogWork();		

		logwork = readlogwork.getLogWork(keyword," ");
		
		writelogwork.deleteLogWork(logwork[logwork.length-1].getLOGWORKID());

		String sql = "update WORK_TABLE set WORKNAME='"+WORKNAME+"',STATEID="+STATEID+",PRIORITY="+PRIORITY+",FILENAME='"+FILENAME+"',USERNAME=null,TAKEN_DATE=null where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//rejectWork

	public void takeWork(Integer WORKID,User user)throws ClassNotFoundException,SQLException{
		
		String sql = "update WORK_TABLE set USERNAME='"+user.getUSERNAME()+"',TAKEN_DATE=CONVERT(CHAR(10),GETDATE(),121) where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//takeWork

	public void leaveWork(Integer WORKID)throws ClassNotFoundException,SQLException{
		
		String sql = "update WORK_TABLE set USERNAME=null,TAKEN_DATE=null where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//leaveWork


	public void setFILENAMEWork(Integer WORKID,String FILENAME)throws ClassNotFoundException,SQLException{
		FILENAME = FILENAME.toUpperCase();
		
		String sql = "update WORK_TABLE set FILENAME='"+FILENAME+"' where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//setFILENAMEWork

	public void deleteWork(Integer WORKID)throws ClassNotFoundException,SQLException{

		String sql = "delete from WORK_TABLE where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteWork

}//class WriteWork