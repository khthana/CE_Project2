package mybean;
import java.sql.*;
import java.util.*;

public class Database implements java.io.Serializable{
	private Connection connection;
	private Statement statement;

	public Database() throws ClassNotFoundException , SQLException{
		ResourceBundle props = ResourceBundle.getBundle("conf/config");
		String ServerIP= props.getString("ServerIP");
		String ServerPort = props.getString("ServerPort");
		String UserName = props.getString("UserName");
		String PassWord = props.getString("PassWord");

		Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
		connection = DriverManager.getConnection ("jdbc:microsoft:sqlserver://"+ServerIP+":"+ServerPort,UserName,PassWord);
		statement = connection.createStatement();		

//		Class.forName("net.sourceforge.jtds.jdbc.Driver");
//		connection = DriverManager.getConnection ("jdbc:jtds:sqlserver://MOJI:1433;selectmethod=cuasdarsor1","javatech", "javatech" );
//		statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

	}//Constructor Database

	public void executeUpdate(String sql) throws SQLException {
		statement.executeUpdate(sql);
	}//executeUpdate

	public ResultSet executeQuery(String sql) throws SQLException {
		return statement.executeQuery(sql);
	}//executeQuery

	protected void finalize() throws SQLException {
		statement.close();
		connection.close();
	}//finalize

}//Class Database