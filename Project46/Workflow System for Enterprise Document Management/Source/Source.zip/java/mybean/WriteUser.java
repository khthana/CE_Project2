package mybean;
import java.sql.*;

public class WriteUser{

	public void addUser(String USERNAME,String PASSWORD,String FIRSTNAME,String LASTNAME,Boolean ISADMIN)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();
		PASSWORD = PASSWORD.toUpperCase();
		FIRSTNAME = FIRSTNAME.toUpperCase();
		LASTNAME = LASTNAME.toUpperCase();
		int temp_isadmin=0;
		if (ISADMIN.booleanValue()){
			temp_isadmin=1;
		}//if

		String sql = "insert into USER_TABLE values ('"+USERNAME+"','"+PASSWORD+"','"+FIRSTNAME+"','"+LASTNAME+"',"+temp_isadmin+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addUser
	
	public void editUser(String USERNAME,String PASSWORD,String FIRSTNAME,String LASTNAME,Boolean ISADMIN)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();
		PASSWORD = PASSWORD.toUpperCase();
		FIRSTNAME = FIRSTNAME.toUpperCase();
		LASTNAME = LASTNAME.toUpperCase();
		int temp_isadmin=0;
		if ((ISADMIN!=null)&&(ISADMIN.booleanValue())){
			temp_isadmin=1;
		}//if

		String sql = "update USER_TABLE set PASSWORD='"+PASSWORD+"', FIRSTNAME='"+FIRSTNAME+"', LASTNAME='"+LASTNAME+"',ISADMIN="+temp_isadmin+" where USERNAME='"+USERNAME+"'";
		Database database = new Database();
		database.executeUpdate(sql);
	}//editUser

	public void deleteUser(String USERNAME)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();

		String sql = "delete from USER_TABLE where USERNAME='"+USERNAME+"'";
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteUser

}//class WriteUser