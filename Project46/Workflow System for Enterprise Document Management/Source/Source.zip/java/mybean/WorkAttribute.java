package mybean;

public class WorkAttribute{
	private Integer WORKID;
	private Integer ATTRIBUTEID;
	private String ATT_VALUE;


	public Integer getWORKID(){
		return this.WORKID;
	}//getWORKID

	public Integer getATTRIBUTEID(){
		return this.ATTRIBUTEID;
	}//getATTRIBUTEID

	public String getATT_VALUE(){
		return this.ATT_VALUE;
	}//getATT_VALUE

	public WorkAttribute(Integer WORKID,Integer ATTRIBUTEID,String ATT_VALUE){
		this.WORKID = WORKID;
		this.ATTRIBUTEID = ATTRIBUTEID;
		this.ATT_VALUE = ATT_VALUE;
	}//Constructor Work

}//class WorkAttribute