package mybean;
import java.sql.*;

public class ReadState{

	public int getNumberState(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from STATE_TABLE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberState

	public State[] getState(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberState(keyword);
		String sql;
		sql = "select * from STATE_TABLE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		State state[]= new State[count];
		for(int i=0;i<count;i++){
			rs1.next();
			state[i] = new State(new Integer(rs1.getInt("STATEID")),rs1.getString("STATENAME"),rs1.getString("STATETYPE"),new Integer(rs1.getInt("WORKFLOWID")),new Integer(rs1.getInt("WORK_TIME")));
		}//for
		return state;
	}//getState

}//class ReadState