package mybean;

public class RoleState{
	private Integer ROLEID;
	private Integer STATEID;
	private Boolean CANREJECT;

	public Integer getROLEID(){
		return this.ROLEID;
	}//getROLEID

	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID

	public Boolean getCANREJECT(){
		return this.CANREJECT;
	}//getCANREJECT

	public RoleState(Integer ROLEID,Integer STATEID,Boolean CANREJECT){
		this.ROLEID = ROLEID;		
		this.STATEID = STATEID;
		this.CANREJECT = CANREJECT;
	}//Constructor RoleState

}//class RoleState