package mybean;
import java.sql.*;

public class ReadRole{

	public int getNumberRole(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from ROLE_TABLE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberRole

	public Role[] getRole(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberRole(keyword);
		String sql;
		sql = "select * from ROLE_TABLE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		Role role[]= new Role[count];
		for(int i=0;i<count;i++){
			rs1.next();
			role[i] = new Role(new Integer(rs1.getInt("ROLEID")),rs1.getString("ROLENAME"),rs1.getString("ROLEDESC"));
		}//for
		return role;
	}//getRole

}//class ReadRole