package mybean;

public class RoleGroup{
	private Integer GROUPID;
	private Integer ROLEID;

	public Integer getGROUPID(){
		return this.GROUPID;
	}//getGROUPID

	public Integer getROLEID(){
		return this.ROLEID;
	}//getROLEID

	public RoleGroup(Integer GROUPID,Integer ROLEID){
		this.GROUPID = GROUPID;
		this.ROLEID = ROLEID;
	}//Constructor RoleGroup

}//class RoleGroup