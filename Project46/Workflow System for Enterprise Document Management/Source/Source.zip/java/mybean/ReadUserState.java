package mybean;
import java.sql.*;

public class ReadUserState{

	public int getNumberUserState(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from USERSTATE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberUserState

	public UserState[] getUserState(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberUserState(keyword);
		String sql;
		sql = "select * from USERSTATE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		UserState userstate[]= new UserState[count];
		for(int i=0;i<count;i++){
			rs1.next();
			userstate[i] = new UserState(rs1.getString("USERNAME"),new Integer(rs1.getInt("STATEID")),new Boolean(rs1.getBoolean("CANREJECT")));
		}//for
		return userstate;
	}//getUserState

}//class ReadUserState