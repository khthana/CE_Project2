package mybean;
import java.sql.*;

public class ReadCondition{

	public int getNumberCondition(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from CONDITION "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberRole

	public Condition[] getCondition(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberCondition(keyword);
		String sql;
		sql = "select * from CONDITION "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		Condition condition[]= new Condition[count];
		for(int i=0;i<count;i++){
			rs1.next();
			condition[i] = new Condition(new Integer(rs1.getInt("CONDITIONID")),rs1.getString("STATEMENT"),new Integer(rs1.getInt("NEXTSTATEID")),new Integer(rs1.getInt("STATEID")));
		}//for
		return condition;
	}//getCondition

}//class ReadCondition