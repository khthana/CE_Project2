package mybean;
import java.sql.*;

public class WriteCondition{

	public void addCondition(String STATEMENT,Integer NEXTSTATEID,Integer STATEID)throws ClassNotFoundException,SQLException{
//		STATEMENT = STATEMENT.toUpperCase();

		String sql = "insert into CONDITION values ('"+STATEMENT.replaceAll("'","''")+"',"+NEXTSTATEID+","+STATEID+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addCondition
	
	public void editCondition(Integer CONDITIONID,String STATEMENT,Integer NEXTSTATEID,Integer STATEID)throws ClassNotFoundException,SQLException{
//		STATEMENT = STATEMENT.toUpperCase();

		String sql = "update CONDITION set STATEMENT='"+STATEMENT.replaceAll("'","''")+"',NEXTSTATEID="+NEXTSTATEID+",STATEID="+STATEID+" where CONDITIONID="+CONDITIONID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editCondition

	public void deleteCondition(Integer CONDITIONID,Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from CONDITION where CONDITIONID="+CONDITIONID+" and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteCondition

	public void deleteallCondition(Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from CONDITION where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteCondition
}//class WriteCondition