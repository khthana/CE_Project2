package mybean;
import java.sql.*;
import java.util.Calendar;

public class Work{
	private Integer WORKID;
	private String WORKNAME;
	private Integer STATEID;
	private String FILENAME;
	private Integer PRIORITY;
	private String USERNAME;
	private Date TAKEN_DATE;
	private String CREATED_BY;
	private Date CREATED_DATE;

	public boolean ISLATE()throws ClassNotFoundException,SQLException{
		ReadState readstate = new ReadState();
		String keyword1 = " where STATEID="+this.STATEID+" ";
		State state[];
		state = readstate.getState(keyword1," ");
		
		ReadLogWork readlogwork = new ReadLogWork();
		String keyword = " where WORKID="+this.WORKID+" ";
		LogWork logwork[];
		logwork = readlogwork.getLogWork(keyword," ");
		Date in_date_date;
		if (logwork.length==0){
			in_date_date = CREATED_DATE;
		}//if
		else{
			in_date_date = logwork[logwork.length-1].getTIMEAFTER();
		}//else
	
		Calendar today = Calendar.getInstance();
	
		Calendar in_date = Calendar.getInstance();
		in_date.setTime(in_date_date);
		in_date.add(Calendar.DATE,state[0].getWORK_TIME().intValue());

		return today.after(in_date);
	}//ISLATE


	public Integer getWORKID(){
		return this.WORKID;
	}//getWORKID

	public String getWORKNAME(){
		return this.WORKNAME;
	}//getWORKNAME

	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID

	public String getFILENAME(){
		return this.FILENAME;
	}//getFILENAME

	public Integer getPRIORITY(){
		return this.PRIORITY;
	}//getPRIORITY

	public String getUSERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public Date getTAKEN_DATE(){
		return this.TAKEN_DATE;
	}//getTAKEN_DATE

	public String getCREATED_BY(){
		return this.CREATED_BY;
	}//getCREATED_BY

	public Date getCREATED_DATE(){
		return this.CREATED_DATE;
	}//getCREATED_DATE

	public Work(Integer WORKID,String WORKNAME,Integer STATEID,String FILENAME,Integer PRIORITY,String USERNAME,Date TAKEN_DATE,String CREATED_BY,Date CREATED_DATE){
		this.WORKID = WORKID;
		this.WORKNAME = WORKNAME;
		this.STATEID = STATEID;
		this.FILENAME = FILENAME;
		this.PRIORITY = PRIORITY;
		this.USERNAME = USERNAME;
		this.TAKEN_DATE = TAKEN_DATE;
		this.CREATED_BY = CREATED_BY;
		this.CREATED_DATE = CREATED_DATE;
	}//Constructor Work

}//class Work