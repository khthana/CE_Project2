package mybean;
import java.sql.*;

public class ReadWorkAttribute{

	public int getNumberWorkAttribute(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from WORKATTRIBUTE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberWorkAttribute

	public WorkAttribute[] getWorkAttribute(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberWorkAttribute(keyword);
		String sql;
		sql = "select * from WORKATTRIBUTE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		WorkAttribute workattribute[]= new WorkAttribute[count];
		for(int i=0;i<count;i++){
			rs1.next();
			workattribute[i] = new WorkAttribute(new Integer(rs1.getString("WORKID")),new Integer(rs1.getString("ATTRIBUTEID")),rs1.getString("ATT_VALUE"));
		}//for
		return workattribute;
	}//getWorkAttribute

}//class ReadWorkAttribute