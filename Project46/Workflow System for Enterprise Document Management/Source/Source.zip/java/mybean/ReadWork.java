package mybean;
import java.sql.*;

public class ReadWork{

	public int getNumberWork(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from WORK_TABLE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberWork

	public Work[] getWork(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberWork(keyword);
		String sql;
		sql = "select * from WORK_TABLE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		Work work[]= new Work[count];
		for(int i=0;i<count;i++){
			rs1.next();
			work[i] = new Work(new Integer(rs1.getString("WORKID")),rs1.getString("WORKNAME"),new Integer(rs1.getString("STATEID")),rs1.getString("FILENAME"),new Integer(rs1.getString("PRIORITY")),rs1.getString("USERNAME"),rs1.getDate("TAKEN_DATE"),rs1.getString("CREATED_BY"),rs1.getDate("CREATED_DATE"));
		}//for
		return work;
	}//getWork

}//class ReadWork