package mybean;

public class RoleUser{
	private Integer ROLEID;
	private String USERNAME;

	public Integer getROLEID(){
		return this.ROLEID;
	}//getROLEID

	public String getUSERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public RoleUser(Integer ROLEID,String USERNAME){
		this.ROLEID = ROLEID;
		this.USERNAME = USERNAME;
	}//Constructor RoleUser

}//class RoleUser