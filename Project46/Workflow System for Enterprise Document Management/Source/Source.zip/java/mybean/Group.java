package mybean;
//import java.sql.*;

public class Group{
	private Integer GROUPID;
	private String GROUPNAME;
	private String GROUPDESC;

	public Integer getGROUPID(){
		return this.GROUPID;
	}//getGROUPID

	public String getGROUPNAME(){
		return this.GROUPNAME;
	}//getGROUPNAME

	public String getGROUPDESC(){
		return this.GROUPDESC;
	}//getGROUPDESC

	public Group(Integer GROUPID,String GROUPNAME,String GROUPDESC){
		this.GROUPID = GROUPID;
		this.GROUPNAME = GROUPNAME;
		this.GROUPDESC = GROUPDESC;
	}//Constructor Group

}//class Group