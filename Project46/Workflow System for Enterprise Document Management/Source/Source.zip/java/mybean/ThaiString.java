package mybean;
public class ThaiString{
	/**
	* Convert from Incode string into Thai MS Windows charset string.
	*
	* MS-874 Thai char in 161 - 251 ( 0x00A1 - 0x00FB )
	* Unicode char in 0x0E01 - 0x0E5B
	*/
	public static String unicodeToMS874(String s){
		if(s==null) return null;
		StringBuffer sTemp = new StringBuffer(s);
		int code;
		for(int i=0;i<s.length();i++)	{
			code = (int)sTemp.charAt(i);
			if((0xE01 <= code) && (code <= 0xE5B)) sTemp.setCharAt(i,(char)(code-0xD60));
		}//for
		return sTemp.toString();
	}//unicodeToMS874

	/**
	* Convert from Thai MS Windows charset string into Unicode string.
	*
	* MS-874 Thai char in 161 - 251 ( 0x00A1 - 0x00FB )
	* Unicode char in 0x0E01 - 0x0E5B
	*/
	public static String MS874ToUnicode(String s){
		if(s==null) return null;
		StringBuffer sTemp = new StringBuffer(s);
		int code;
		for(int i=0;i<s.length();i++){
			code = (int)sTemp.charAt(i);
			if((0xA1 <= code) && (code <= 0xFB)) sTemp.setCharAt(i,(char)(code+0xD60));
		}//for
		return sTemp.toString();
	}//MS874ToUnicode

} //class