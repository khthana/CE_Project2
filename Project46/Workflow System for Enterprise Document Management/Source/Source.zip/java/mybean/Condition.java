package mybean;

public class Condition{
	private Integer CONDITIONID;
	private String STATEMENT;
	private Integer NEXTSTATEID;
	private Integer STATEID;

	public Integer getCONDITIONID(){
		return this.CONDITIONID;
	}//getCONDITIONID

	public String getSTATEMENT(){
		return this.STATEMENT;
	}//getSTATEMENT

	public Integer getNEXTSTATEID(){
		return this.NEXTSTATEID;
	}//getNEXTSTATEID

	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID
		
	public Condition(Integer CONDITIONID,String STATEMENT,Integer NEXTSTATEID,Integer STATEID){
		this.CONDITIONID = CONDITIONID;		
		this.STATEMENT = STATEMENT;
		this.NEXTSTATEID = NEXTSTATEID;
		this.STATEID = STATEID;		
	}//Constructor Condition

}//class Condition