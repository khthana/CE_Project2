package mybean;
import java.sql.*;

public class WriteGroupUser{

	public void addGroupUser(String USERNAME,Integer GROUPID)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();

		String sql = "insert into GROUPUSER values ('"+USERNAME+"',"+GROUPID+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addGroupUser
	
	public void deleteGroupUser(String USERNAME,Integer GROUPID)throws ClassNotFoundException,SQLException{
		USERNAME = USERNAME.toUpperCase();

		String sql = "delete from GROUPUSER where USERNAME='"+USERNAME+"' and GROUPID="+GROUPID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteGroupUser
	
	public void deleteGroupallUser(Integer GROUPID)throws ClassNotFoundException,SQLException{

		String sql = "delete from GROUPUSER where  GROUPID="+GROUPID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteGroupallUser
	

}//class WriteGroupUser