package mybean;
import java.sql.*;

public class WriteRoleGroup{

	public void addRoleGroup(Integer GROUPID,Integer ROLEID)throws ClassNotFoundException,SQLException{

		String sql = "insert into ROLEGROUP values ("+GROUPID+","+ROLEID+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addRoleGroup
	
	public void deleteRoleGroup(Integer GROUPID,Integer ROLEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLEGROUP where GROUPID="+GROUPID+" and ROLEID="+ROLEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleGroup

	public void deleteRoleallGroup(Integer ROLEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ROLEGROUP where ROLEID="+ROLEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteRoleallGroup

}//class WriteRoleGroup