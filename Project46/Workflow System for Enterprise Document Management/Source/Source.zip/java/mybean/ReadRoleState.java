package mybean;
import java.sql.*;

public class ReadRoleState{

	public int getNumberRoleState(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from ROLESTATE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberRoleState

	public RoleState[] getRoleState(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberRoleState(keyword);
		String sql;
		sql = "select * from ROLESTATE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		RoleState rolestate[]= new RoleState[count];
		for(int i=0;i<count;i++){
			rs1.next();
			rolestate[i] = new RoleState(new Integer(rs1.getInt("ROLEID")),new Integer(rs1.getInt("STATEID")),new Boolean(rs1.getBoolean("CANREJECT")));
		}//for
		return rolestate;
	}//getRoleState

}//class ReadRoleState