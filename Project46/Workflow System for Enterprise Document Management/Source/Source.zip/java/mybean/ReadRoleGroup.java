package mybean;
import java.sql.*;

public class ReadRoleGroup{

	public int getNumberRoleGroup(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from ROLEGROUP "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberRoleGroup

	public RoleGroup[] getRoleGroup(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberRoleGroup(keyword);
		String sql;
		sql = "select * from ROLEGROUP "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		RoleGroup rolegroup[]= new RoleGroup[count];
		for(int i=0;i<count;i++){
			rs1.next();
			rolegroup[i] = new RoleGroup(new Integer(rs1.getInt("GROUPID")),new Integer(rs1.getInt("ROLEID")));
		}//for
		return rolegroup;
	}//getRoleGroup

}//class ReadRoleGroup