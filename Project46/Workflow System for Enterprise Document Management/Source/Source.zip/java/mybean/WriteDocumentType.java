package mybean;
import java.sql.*;

public class WriteDocumentType{

	public void addDocumentType(String DOCUMENTTYPENAME,String DOCUMENTTYPEDESC)throws ClassNotFoundException,SQLException{
		DOCUMENTTYPENAME = DOCUMENTTYPENAME.toUpperCase();
		DOCUMENTTYPEDESC = DOCUMENTTYPEDESC.toUpperCase();

		String sql = "insert into DOCUMENTTYPE values ('"+DOCUMENTTYPENAME+"','"+DOCUMENTTYPEDESC+"')";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addDocumentType
	
	public void editDocumentType(Integer DOCUMENTTYPEID,String DOCUMENTTYPENAME,String DOCUMENTTYPEDESC)throws ClassNotFoundException,SQLException{
		DOCUMENTTYPENAME = DOCUMENTTYPENAME.toUpperCase();
		DOCUMENTTYPEDESC = DOCUMENTTYPEDESC.toUpperCase();

		String sql = "update DOCUMENTTYPE set DOCUMENTTYPENAME='"+DOCUMENTTYPENAME+"',DOCUMENTTYPEDESC='"+DOCUMENTTYPEDESC+"' where DOCUMENTTYPEID="+DOCUMENTTYPEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editDocumentType

	public void deleteDocumentType(Integer DOCUMENTTYPEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from DOCUMENTTYPE where DOCUMENTTYPEID="+DOCUMENTTYPEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteDocumentType

}//class WriteDocumentType