package mybean;
//import java.sql.*;

public class Attribute{
	private Integer ATTRIBUTEID;
	private Integer DOCUMENTTYPEID;
	private String ATTRIBUTENAME;
	private String ATTRIBUTETYPE;

	public Integer getATTRIBUTEID(){
		return this.ATTRIBUTEID;
	}//getATTRIBUTEID

	public Integer getDOCUMENTTYPEID(){
		return this.DOCUMENTTYPEID;
	}//getDOCUMENTTYPEID

	public String getATTRIBUTENAME(){
		return this.ATTRIBUTENAME;
	}//getATTRIBUTENAME

	public String getATTRIBUTETYPE(){
		return this.ATTRIBUTETYPE;
	}//getATTRIBUTETYPE

	public Attribute(Integer ATTRIBUTEID,Integer DOCUMENTTYPEID,String ATTRIBUTENAME,String ATTRIBUTETYPE){
		this.ATTRIBUTEID = ATTRIBUTEID;
		this.DOCUMENTTYPEID = DOCUMENTTYPEID;
		this.ATTRIBUTENAME = ATTRIBUTENAME;
		this.ATTRIBUTETYPE = ATTRIBUTETYPE;
	}//Constructor Attribute

}//class Attribute