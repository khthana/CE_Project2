package mybean;
import java.sql.*;
import java.text.*;
import java.util.Locale;

public class State{
	private Integer STATEID;
	private String STATENAME;
	private String STATETYPE;
	private Integer WORKFLOWID;
	private Integer WORK_TIME;

	public int getNumberWorkinState(Date fromdate,Date todate)throws ClassNotFoundException,SQLException{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		String fromdate_s = "'"+dateFormat.format(fromdate)+"'"; 
		String todate_s = "'"+dateFormat.format(todate)+"'";
		if(this.STATETYPE.equals("1")){
			String keyword = " where STATEID="+this.STATEID+" and CREATED_DATE>="+fromdate_s+" and CREATED_DATE<="+todate_s;
			ReadWork readwork = new ReadWork();
			int nostillinstate = readwork.getNumberWork(keyword);
			int totalwork = nostillinstate + getNumberWorkoutStateintime(fromdate,todate) + getNumberWorkoutStatelate(fromdate,todate);
			return totalwork;
		}//if
		else{
			String keyword = " where STATEAFTER="+this.STATEID+" and TIMEAFTER>="+fromdate_s+" and TIMEAFTER<="+todate_s;
			ReadLogWork readlogwork = new ReadLogWork();
			return readlogwork.getNumberLogWork(keyword);
		}//else
	}//getNumberWorkinState

	public int getNumberWorkoutStateintime(Date fromdate,Date todate)throws ClassNotFoundException,SQLException{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		String fromdate_s = "'"+dateFormat.format(fromdate)+"'"; 
		String todate_s = "'"+dateFormat.format(todate)+"'";
		String keyword = " where STATEBEFORE="+this.STATEID+" and TIMEBEFORE>="+fromdate_s+" and TIMEBEFORE<="+todate_s+" and DATEDIFF(day, TIMEBEFORE, TIMEAFTER)<="+this.WORK_TIME;
		ReadLogWork readlogwork = new ReadLogWork();
		return readlogwork.getNumberLogWork(keyword);
	}//getNumberWorkoutStateintime

	public int getNumberWorkoutStatelate(Date fromdate,Date todate)throws ClassNotFoundException,SQLException{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		String fromdate_s = "'"+dateFormat.format(fromdate)+"'"; 
		String todate_s = "'"+dateFormat.format(todate)+"'";
		String keyword = " where STATEBEFORE="+this.STATEID+" and TIMEBEFORE>="+fromdate_s+" and TIMEBEFORE<="+todate_s+" and DATEDIFF(day, TIMEBEFORE, TIMEAFTER)>"+this.WORK_TIME;
		ReadLogWork readlogwork = new ReadLogWork();
		return readlogwork.getNumberLogWork(keyword);
	}//getNumberWorkoutStatelate


	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID

	public String getSTATENAME(){
		return this.STATENAME;
	}//getSTATENAME

	public String getSTATETYPE(){
		return this.STATETYPE;
	}//getSTATETYPE

	public Integer getWORKFLOWID(){
		return this.WORKFLOWID;
	}//getWORKFLOWID

	public Integer getWORK_TIME(){
		return this.WORK_TIME;
	}//getWORK_TIME

	public State(Integer STATEID,String STATENAME,String STATETYPE,Integer WORKFLOWID,Integer WORK_TIME){
		this.STATEID = STATEID;
		this.STATENAME = STATENAME;
		this.STATETYPE = STATETYPE;
		this.WORKFLOWID = WORKFLOWID;
		this.WORK_TIME = WORK_TIME;
	}//Constructor State

}//class State