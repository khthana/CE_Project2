package mybean;
import java.sql.*;

public class ReadLogWork{

	public int getNumberLogWork(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from LOGWORK "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberLogWork

	public LogWork[] getLogWork(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberLogWork(keyword);
		String sql;
		sql = "select * from LOGWORK "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		LogWork logwork[]= new LogWork[count];
		for(int i=0;i<count;i++){
			rs1.next();
			logwork[i] = new LogWork(new Integer(rs1.getString("LOGWORKID")),new Integer(rs1.getString("WORKID")),new Integer(rs1.getString("STATEBEFORE")),new Integer(rs1.getString("STATEAFTER")),rs1.getString("USERNAME"),rs1.getDate("TIMEBEFORE"),rs1.getDate("TIMEAFTER"));
		}//for
		return logwork;
	}//getLogWork

}//class ReadLogWork