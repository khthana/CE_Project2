package mybean;
import java.sql.*;

public class ReadWorkFlow{

	public int getNumberWorkFlowbyUser(User user)throws ClassNotFoundException,SQLException{
		String sql;
		sql = "select count(*) as rowcounts from WORKFLOW ";
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberWorkFlowbyUser

	public WorkFlow[] getWorkFlowbyUser(User user)throws ClassNotFoundException,SQLException{

		int count = getNumberWorkFlowbyUser(user);
		String sql;
		sql = "select * from WORKFLOW ";
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		WorkFlow workflow[]= new WorkFlow[count];
		for(int i=0;i<count;i++){
			rs1.next();
			workflow[i] = new WorkFlow(new Integer(rs1.getInt("WORKFLOWID")),rs1.getString("WORKFLOWNAME"),new Integer(rs1.getInt("DOCUMENTTYPEID")));
		}//for
		return workflow;
	}//getWorkFlowbyUser

	public int getNumberWorkFlow(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from WORKFLOW "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberWorkFlow

	public WorkFlow[] getWorkFlow(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberWorkFlow(keyword);
		String sql;
		sql = "select * from WORKFLOW "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		WorkFlow workflow[]= new WorkFlow[count];
		for(int i=0;i<count;i++){
			rs1.next();
			workflow[i] = new WorkFlow(new Integer(rs1.getInt("WORKFLOWID")),rs1.getString("WORKFLOWNAME"),new Integer(rs1.getInt("DOCUMENTTYPEID")));
		}//for
		return workflow;
	}//getWorkFlow

}//class ReadWorkFlow