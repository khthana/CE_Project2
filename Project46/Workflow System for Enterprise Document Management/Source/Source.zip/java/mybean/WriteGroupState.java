package mybean;
import java.sql.*;

public class WriteGroupState{

	public void addGroupState(Integer GROUPID,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "insert into GROUPSTATE values ("+GROUPID+","+STATEID+","+temp_canreject+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addGroupState
	
	public void editGroupState(Integer GROUPID,Integer STATEID,Boolean CANREJECT)throws ClassNotFoundException,SQLException{
		int temp_canreject=0;
		if (CANREJECT.booleanValue()){
			temp_canreject=1;
		}//if

		String sql = "update GROUPSTATE set CANREJECT="+temp_canreject+" where GROUPID="+GROUPID+" and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editGroupState

	public void deleteGroupState(Integer GROUPID,Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from GROUPSTATE where GROUPID="+GROUPID+" and STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteGroupState

	public void deleteGroupallState(Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from GROUPSTATE where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteGroupallState

}//class WriteGroupState