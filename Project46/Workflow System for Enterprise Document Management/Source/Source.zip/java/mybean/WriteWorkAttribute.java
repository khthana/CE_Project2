package mybean;
import java.sql.*;

public class WriteWorkAttribute{

	public void addWorkAttribute(Integer WORKID,Integer ATTRIBUTEID,String ATT_VALUE)throws ClassNotFoundException,SQLException{
		String tempsql;
		if(ATT_VALUE==null){
			tempsql="null";
		}//if
		else{
			tempsql = "'"+ATT_VALUE+"'";
		}
		String sql = "insert into WORKATTRIBUTE values ("+WORKID+","+ATTRIBUTEID+","+tempsql+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addWorkAttribute
	
	public void editWorkAttribute(Integer WORKID,Integer ATTRIBUTEID,String ATT_VALUE)throws ClassNotFoundException,SQLException{
		String tempsql;
		if(ATT_VALUE==null){
			tempsql="null";
		}//if
		else{
			tempsql="'"+ATT_VALUE+"'";
		}//else

		String sql = "update WORKATTRIBUTE set ATT_VALUE="+tempsql+" where WORKID="+WORKID+" and ATTRIBUTEID="+ATTRIBUTEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editWorkAttribute

	public void deleteWorkAttribute(Integer WORKID,Integer ATTRIBUTEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from WORKATTRIBUTE where WORKID="+WORKID+" and ATTRIBUTEID="+ATTRIBUTEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteWorkAttribute

	public void deleteallWorkAttribute(Integer WORKID)throws ClassNotFoundException,SQLException{

		String sql = "delete from WORKATTRIBUTE where WORKID="+WORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteallWorkAttribute
	
}//class WriteWorkAttribute