package mybean;

public class Role{
	private Integer ROLEID;
	private String ROLENAME;
	private String ROLEDESC;

	public Integer getROLEID(){
		return this.ROLEID;
	}//getROLEID

	public String getROLENAME(){
		return this.ROLENAME;
	}//getROLENAME

	public String getROLEDESC(){
		return this.ROLEDESC;
	}//getROLEDESC

	public Role(Integer ROLEID,String ROLENAME,String ROLEDESC){
		this.ROLEID = ROLEID;
		this.ROLENAME = ROLENAME;
		this.ROLEDESC = ROLEDESC;
	}//Constructor Role

}//class Role