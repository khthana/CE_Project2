package mybean;
import java.sql.*;

public class WriteWorkFlow{

	public void addWorkFlow(String WORKFLOWNAME,Integer DOCUMENTTYPEID)throws ClassNotFoundException,SQLException{
		WORKFLOWNAME = WORKFLOWNAME.toUpperCase();

		String sql = "insert into WORKFLOW values ('"+WORKFLOWNAME+"',"+DOCUMENTTYPEID+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addWorkFlow
	
	public void editWorkFlow(Integer WORKFLOWID,String WORKFLOWNAME,Integer DOCUMENTTYPEID)throws ClassNotFoundException,SQLException{
		WORKFLOWNAME = WORKFLOWNAME.toUpperCase();

		String sql = "update WORKFLOW set WORKFLOWNAME='"+WORKFLOWNAME+"',DOCUMENTTYPEID="+DOCUMENTTYPEID+" where WORKFLOWID="+WORKFLOWID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editWorkFlow

	public void deleteWorkFlow(Integer WORKFLOWID)throws ClassNotFoundException,SQLException{

		String sql = "delete from WORKFLOW where WORKFLOWID="+WORKFLOWID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteWorkFlow

}//class WriteWorkFlow