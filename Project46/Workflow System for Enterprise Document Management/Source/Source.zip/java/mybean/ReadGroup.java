package mybean;
import java.sql.*;

public class ReadGroup{

	public int getNumberGroup(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from GROUP_TABLE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberGroup

	public Group[] getGroup(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberGroup(keyword);
		String sql;
		sql = "select * from GROUP_TABLE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		Group group[]= new Group[count];
		for(int i=0;i<count;i++){
			rs1.next();
			group[i] = new Group(new Integer(rs1.getInt("GROUPID")),rs1.getString("GROUPNAME"),rs1.getString("GROUPDESC"));
		}//for
		return group;
	}//getGroup

}//class ReadGroup