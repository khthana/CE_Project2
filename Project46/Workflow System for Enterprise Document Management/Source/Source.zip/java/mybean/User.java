package mybean;
import java.sql.*;

public class User{
	private String USERNAME;
	private String PASSWORD;
	private String FIRSTNAME;
	private String LASTNAME;
	private Boolean ISADMIN;

	public void createSTATEview()throws ClassNotFoundException,SQLException{
		Database database = new Database();
		database.executeUpdate("create view STATEviewby"+this.getUSERNAME()+" as (select WORKFLOWID,T1.STATEID,CANREJECT from USERSTATE T1,STATE_TABLE T2 where USERNAME='"+this.getUSERNAME()+"' and T1.STATEID=T2.STATEID union select WORKFLOWID,T1.STATEID,CANREJECT from GROUPSTATE T1,STATE_TABLE T2 where T1.STATEID=T2.STATEID and GROUPID in (select GROUPID from GROUPUSER where USERNAME='"+this.getUSERNAME()+"') union select WORKFLOWID,T1.STATEID,CANREJECT from ROLESTATE T1,STATE_TABLE T2 where T1.STATEID=T2.STATEID and ROLEID in (select ROLEID from ROLEGROUP where GROUPID in (select GROUPID from GROUPUSER where USERNAME='"+this.getUSERNAME()+"')) union select WORKFLOWID,T1.STATEID,CANREJECT from ROLESTATE T1,STATE_TABLE T2 where T1.STATEID=T2.STATEID and ROLEID in (select ROLEID from ROLEUSER where USERNAME='"+this.getUSERNAME()+"'))");
	}//createSTATEview
	
	public Integer[] getWORKFLOWbyUSER()throws ClassNotFoundException,SQLException{
		Database database = new Database();		
		ResultSet rs1;
		rs1 = database.executeQuery("select distinct(WORKFLOWID) from STATEviewby"+this.getUSERNAME()+" ");
		int count=0;
		while(rs1.next()){
			count++;
		}//while
		rs1 = database.executeQuery("select distinct(WORKFLOWID) from STATEviewby"+this.getUSERNAME()+" ");
		Integer workflowid[]= new Integer[count];
		for(int i=0;i<count;i++){
			rs1.next();
			workflowid[i] = new Integer(rs1.getString("WORKFLOWID"));
		}//for i
		return workflowid;		
	}//getWORKFLOWbyUSER	

	public UserState[] getSTATEbyUSER(Integer WORKFLOWID)throws ClassNotFoundException,SQLException{
		Database database = new Database();		
		ResultSet rs1;
		rs1 = database.executeQuery("select * from STATEviewby"+this.getUSERNAME()+" where WORKFLOWID="+WORKFLOWID+" and STATEID in (select STATEID from STATEviewby"+this.getUSERNAME()+" group by STATEID having Count(*)=1) union select * from STATEviewby"+this.getUSERNAME()+" where WORKFLOWID="+WORKFLOWID+" and CANREJECT=1 and STATEID in (select STATEID from STATEviewby"+this.getUSERNAME()+" group by STATEID having Count(*)=2)");
		int count=0;
		while(rs1.next()){
			count++;
		}//while
		rs1 = database.executeQuery("select * from STATEviewby"+this.getUSERNAME()+" where WORKFLOWID="+WORKFLOWID+" and STATEID in (select STATEID from STATEviewby"+this.getUSERNAME()+" group by STATEID having Count(*)=1) union select * from STATEviewby"+this.getUSERNAME()+" where WORKFLOWID="+WORKFLOWID+" and CANREJECT=1 and STATEID in (select STATEID from STATEviewby"+this.getUSERNAME()+" group by STATEID having Count(*)=2)");
		UserState userstate[]= new UserState[count];
		for(int i=0;i<count;i++){
			rs1.next();
			String tempboolean;
			if(rs1.getBoolean("CANREJECT")){
				tempboolean="TRUE";
			}//if
			else{
				tempboolean="FALSE";
			}//else
			userstate[i] = new UserState(this.getUSERNAME(),new Integer(rs1.getString("STATEID")),new Boolean(tempboolean));
		}//for i
		return userstate;		
	}//getSTATEbyUSER	

	public void dropSTATEview()throws ClassNotFoundException,SQLException{
		Database database = new Database();
		database.executeUpdate("drop view STATEviewby"+this.getUSERNAME());
	}//dropSTATEview
	
	public String getUSERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public String getPASSWORD(){
		return this.PASSWORD;
	}//getPASSWORD

	public String getFIRSTNAME(){
		return this.FIRSTNAME;
	}//getFIRSTNAME

	public String getLASTNAME(){
		return this.LASTNAME;
	}//getLASTNAME

	public Boolean getISADMIN(){
		return this.ISADMIN;
	}//getISADMIN

	public User(String USERNAME,String PASSWORD,String FIRSTNAME,String LASTNAME,Boolean ISADMIN){
		this.USERNAME = USERNAME;
		this.PASSWORD = PASSWORD;
		this.FIRSTNAME = FIRSTNAME;
		this.LASTNAME = LASTNAME;
		this.ISADMIN = ISADMIN;
	}//Constructor User

}//class User