package mybean;
import java.sql.*;

public class WriteState{

	public void addState(String STATENAME,String STATETYPE,Integer WORKFLOWID,Integer WORK_TIME)throws ClassNotFoundException,SQLException{
		STATENAME = STATENAME.toUpperCase();
		STATETYPE = STATETYPE.toUpperCase();

		String sql = "insert into STATE_TABLE values ('"+STATENAME+"','"+STATETYPE+"',"+WORKFLOWID+","+WORK_TIME+")";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addState
	
	public void editState(Integer STATEID,String STATENAME,String STATETYPE,Integer WORKFLOWID,Integer WORK_TIME)throws ClassNotFoundException,SQLException{
		STATENAME = STATENAME.toUpperCase();
		STATETYPE = STATETYPE.toUpperCase();

		String sql = "update STATE_TABLE set STATENAME='"+STATENAME+"', STATETYPE='"+STATETYPE+"', WORKFLOWID="+WORKFLOWID+",WORK_TIME="+WORK_TIME+" where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editState

	public void deleteState(Integer STATEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from STATE_TABLE where STATEID="+STATEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteState

	public void deleteallState(Integer WORKFLOWID)throws ClassNotFoundException,SQLException{

		String sql = "delete from STATE_TABLE where WORKFLOWID="+WORKFLOWID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteallState

}//class WriteState