package mybean;

public class UserState{
	private String USERNAME;
	private Integer STATEID;
	private Boolean CANREJECT;

	public String getUSERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public Integer getSTATEID(){
		return this.STATEID;
	}//getSTATEID

	public Boolean getCANREJECT(){
		return this.CANREJECT;
	}//getCANREJECT

	public UserState(String USERNAME,Integer STATEID,Boolean CANREJECT){
		this.USERNAME = USERNAME;		
		this.STATEID = STATEID;
		this.CANREJECT = CANREJECT;
	}//Constructor UserState

}//class UserState