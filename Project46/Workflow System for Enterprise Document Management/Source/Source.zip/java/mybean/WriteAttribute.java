package mybean;
import java.sql.*;

public class WriteAttribute{

	public void addAttribute(Integer DOCUMENTTYPEID,String ATTRIBUTENAME,String ATTRIBUTETYPE)throws ClassNotFoundException,SQLException{
		ATTRIBUTENAME = ATTRIBUTENAME.toUpperCase();
		ATTRIBUTETYPE = ATTRIBUTETYPE.toUpperCase();

		String sql = "insert into ATTRIBUTE values ("+DOCUMENTTYPEID+",'"+ATTRIBUTENAME+"','"+ATTRIBUTETYPE+"')";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addAttribute
	
	public void editAttribute(Integer ATTRIBUTEID,Integer DOCUMENTTYPEID,String ATTRIBUTENAME,String ATTRIBUTETYPE)throws ClassNotFoundException,SQLException{
		ATTRIBUTENAME = ATTRIBUTENAME.toUpperCase();
		ATTRIBUTETYPE = ATTRIBUTETYPE.toUpperCase();

		String sql = "update ATTRIBUTE set DOCUMENTTYPEID="+DOCUMENTTYPEID+", ATTRIBUTENAME='"+ATTRIBUTENAME+"', ATTRIBUTETYPE='"+ATTRIBUTETYPE+"' where ATTRIBUTEID="+ATTRIBUTEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//editAttribute

	public void deleteAttribute(Integer ATTRIBUTEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ATTRIBUTE where ATTRIBUTEID="+ATTRIBUTEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteAttribute

	public void deleteallAttribute(Integer DOCUMENTTYPEID)throws ClassNotFoundException,SQLException{

		String sql = "delete from ATTRIBUTE where DOCUMENTTYPEID="+DOCUMENTTYPEID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteallAttribute

}//class WriteAttribute