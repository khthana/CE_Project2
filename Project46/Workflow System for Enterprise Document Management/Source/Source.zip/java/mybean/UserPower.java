package mybean;

public class UserPower{

/*---------- manage User ----------*/
	public ReadUser readuser = new ReadUser();
	public WriteUser writeuser = new WriteUser();

/*---------- manage Group ----------*/
	public ReadGroup readgroup = new ReadGroup();

/*---------- manage Role ----------*/
	public ReadRole readrole = new ReadRole();

/*---------- manage GroupUser ----------*/
	public ReadGroupUser readgroupuser = new ReadGroupUser();

/*---------- manage RoleGroup ----------*/
	public ReadRoleGroup readrolegroup = new ReadRoleGroup();

/*---------- manage RoleUser ----------*/
	public ReadRoleUser readroleuser = new ReadRoleUser();

/*---------- manage UserState ----------*/
	public ReadUserState readuserstate = new ReadUserState();

/*---------- manage GroupState ----------*/
	public ReadGroupState readgroupstate = new ReadGroupState();

/*---------- manage RoleState ----------*/
	public ReadRoleState readrolestate = new ReadRoleState();

/*---------- manage DocumentType ----------*/
	public ReadDocumentType readdocumenttype = new ReadDocumentType();

/*---------- manage State ----------*/
	public ReadState readstate= new ReadState();

/*---------- manage Condition ----------*/
	public ReadCondition readcondition= new ReadCondition();

/*---------- manage Attribute ----------*/
	public ReadAttribute readattribute= new ReadAttribute();

/*---------- manage WorkFlow ----------*/
	public ReadWorkFlow readworkflow= new ReadWorkFlow();
	
/*---------- manage Work ----------*/
	public ReadWork readwork= new ReadWork();
	public WriteWork writework= new WriteWork();
	
/*---------- manage WorkAttribute ----------*/
	public ReadWorkAttribute readworkattribute= new ReadWorkAttribute();
	public WriteWorkAttribute writeworkattribute= new WriteWorkAttribute();

/*---------- manage LogWork ----------*/
	public ReadLogWork readlogwork= new ReadLogWork();
	public WriteLogWork writelogwork= new WriteLogWork();

}//class UserPower