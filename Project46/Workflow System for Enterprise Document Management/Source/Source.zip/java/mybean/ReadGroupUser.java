package mybean;
import java.sql.*;

public class ReadGroupUser{

	public int getNumberGroupUser(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from GROUPUSER "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberGroupUser

	public GroupUser[] getGroupUser(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberGroupUser(keyword);
		String sql;
		sql = "select * from GROUPUSER "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		GroupUser groupuser[]= new GroupUser[count];
		for(int i=0;i<count;i++){
			rs1.next();
			groupuser[i] = new GroupUser(rs1.getString("USERNAME"),new Integer(rs1.getInt("GROUPID")));
		}//for
		return groupuser;
	}//getGroupUser

}//class ReadGroupUser