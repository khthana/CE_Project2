package mybean;
import java.sql.*;
import java.text.*;
import java.util.Locale;
public class WriteLogWork{

	public void addLogWork(Integer WORKID,Integer STATEBEFORE,Integer STATEAFTER,String USERNAME,Date TIMEBEFORE)throws ClassNotFoundException,SQLException{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US); 
		String temptimebefore = dateFormat.format(TIMEBEFORE);

		String sql = "insert into LOGWORK values ("+WORKID+","+STATEBEFORE+","+STATEAFTER+",'"+USERNAME+"','"+temptimebefore+"',CONVERT(CHAR(10),GETDATE(),121))";
		Database database = new Database();
		database.executeUpdate(sql);
	}//addLogWork

	public void deleteLogWork(Integer LOGWORKID)throws ClassNotFoundException,SQLException{

		String sql = "delete from LOGWORK where LOGWORKID="+LOGWORKID;
		Database database = new Database();
		database.executeUpdate(sql);
	}//deleteLogWork
	
}//class WriteLogWork