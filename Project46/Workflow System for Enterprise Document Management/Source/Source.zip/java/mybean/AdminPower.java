package mybean;

public class AdminPower
{
/*---------- manage User ----------*/
	public ReadUser readuser = new ReadUser();
	public WriteUser writeuser = new WriteUser();

/*---------- manage Group ----------*/
	public ReadGroup readgroup = new ReadGroup();
	public WriteGroup writegroup = new WriteGroup();

/*---------- manage Role ----------*/
	public ReadRole readrole = new ReadRole();
	public WriteRole writerole= new WriteRole();

/*---------- manage GroupUser ----------*/
	public ReadGroupUser readgroupuser = new ReadGroupUser();
	public WriteGroupUser writegroupuser = new WriteGroupUser();

/*---------- manage RoleGroup ----------*/
	public ReadRoleGroup readrolegroup = new ReadRoleGroup();
	public WriteRoleGroup writerolegroup = new WriteRoleGroup();

/*---------- manage RoleUser ----------*/
	public ReadRoleUser readroleuser = new ReadRoleUser();
	public WriteRoleUser writeroleuser = new WriteRoleUser();

/*---------- manage UserState ----------*/
	public ReadUserState readuserstate = new ReadUserState();
	public WriteUserState writeuserstate = new WriteUserState();

/*---------- manage GroupState ----------*/
	public ReadGroupState readgroupstate = new ReadGroupState();
	public WriteGroupState writegroupstate = new WriteGroupState();

/*---------- manage RoleState ----------*/
	public ReadRoleState readrolestate = new ReadRoleState();
	public WriteRoleState writerolestate = new WriteRoleState();

/*---------- manage DocumentType ----------*/
	public ReadDocumentType readdocumenttype = new ReadDocumentType();
	public WriteDocumentType writedocumenttype = new WriteDocumentType();

/*---------- manage State ----------*/
	public ReadState readstate= new ReadState();
	public WriteState writestate= new WriteState();

/*---------- manage Condition ----------*/
	public ReadCondition readcondition= new ReadCondition();
	public WriteCondition writecondition= new WriteCondition();

/*---------- manage Attribute ----------*/
	public ReadAttribute readattribute= new ReadAttribute();
	public WriteAttribute writeattribute= new WriteAttribute();

/*---------- manage WorkFlow ----------*/
	public ReadWorkFlow readworkflow= new ReadWorkFlow();
	public WriteWorkFlow writeworkflow= new WriteWorkFlow();
	
/*---------- manage Work ----------*/
	public ReadWork readwork= new ReadWork();
	public WriteWork writework= new WriteWork();
	
/*---------- manage WorkAttribute ----------*/
	public ReadWorkAttribute readworkattribute= new ReadWorkAttribute();
	public WriteWorkAttribute writeworkattribute= new WriteWorkAttribute();
	
/*---------- manage LogWork ----------*/
	public ReadLogWork readlogwork= new ReadLogWork();
	public WriteLogWork writelogwork= new WriteLogWork();

}//class AdminPower