package mybean;
import java.sql.*;

public class ReadRoleUser{

	public int getNumberRoleUser(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from ROLEUSER "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberRoleUser

	public RoleUser[] getRoleUser(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberRoleUser(keyword);
		String sql;
		sql = "select * from ROLEUSER "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		RoleUser roleuser[]= new RoleUser[count];
		for(int i=0;i<count;i++){
			rs1.next();
			roleuser[i] = new RoleUser(new Integer(rs1.getInt("ROLEID")),rs1.getString("USERNAME"));
		}//for
		return roleuser;
	}//getRoleUser

}//class ReadRoleUser