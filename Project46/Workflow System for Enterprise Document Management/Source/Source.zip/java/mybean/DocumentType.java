package mybean;
//import java.sql.*;

public class DocumentType{
	private Integer DOCUMENTTYPEID;
	private String DOCUMENTTYPENAME;
	private String DOCUMENTTYPEDESC;

	public Integer getDOCUMENTTYPEID(){
		return this.DOCUMENTTYPEID;
	}//getDOCUMENTTYPEID

	public String getDOCUMENTTYPENAME(){
		return this.DOCUMENTTYPENAME;
	}//getDOCUMENTTYPENAME

	public String getDOCUMENTTYPEDESC(){
		return this.DOCUMENTTYPEDESC;
	}//getDOCUMENTTYPEDESC

	public DocumentType(Integer DOCUMENTTYPEID,String DOCUMENTTYPENAME,String DOCUMENTTYPEDESC){
		this.DOCUMENTTYPEID = DOCUMENTTYPEID;
		this.DOCUMENTTYPENAME = DOCUMENTTYPENAME;
		this.DOCUMENTTYPEDESC = DOCUMENTTYPEDESC;
	}//Constructor DocumentType

}//class DocumentType