package mybean;
import java.sql.*;

public class ReadDocumentType{

	public int getNumberDocumentType(String keyword)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		String sql;
		sql = "select count(*) as rowcounts from DOCUMENTTYPE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		rs1.next();
		return rs1.getInt("rowcounts");
	}//getNumberDocumentType

	public DocumentType[] getDocumentType(String keyword,String ordersql)throws ClassNotFoundException,SQLException{
		keyword = keyword.toUpperCase();
		ordersql = ordersql.toUpperCase();
		int count = getNumberDocumentType(keyword);
		String sql;
		sql = "select * from DOCUMENTTYPE "+keyword+ordersql;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		DocumentType documenttype[]= new DocumentType[count];
		for(int i=0;i<count;i++){
			rs1.next();
			documenttype[i] = new DocumentType(new Integer(rs1.getInt("DOCUMENTTYPEID")),rs1.getString("DOCUMENTTYPENAME"),rs1.getString("DOCUMENTTYPEDESC"));
		}//for
		return documenttype;
	}//getDocumentType

	public DocumentType[] getUnassignedDocumentType()throws ClassNotFoundException,SQLException{
		String keyword = "where DOCUMENTTYPEID not in (select DOCUMENTTYPEID from WORKFLOW)";
		keyword = keyword.toUpperCase();
		int count = getNumberDocumentType(keyword);
		String sql;
		sql = "select * from DOCUMENTTYPE "+keyword;
		Database database = new Database();
		ResultSet rs1;
		rs1 = database.executeQuery(sql);
		DocumentType documenttype[]= new DocumentType[count];
		for(int i=0;i<count;i++){
			rs1.next();
			documenttype[i] = new DocumentType(new Integer(rs1.getInt("DOCUMENTTYPEID")),rs1.getString("DOCUMENTTYPENAME"),rs1.getString("DOCUMENTTYPEDESC"));
		}//for
		return documenttype;
	}//getUnassignedDocumentType

}//class ReadDocumentType