package mybean;
import java.sql.*;

public class LogWork{
	private Integer LOGWORKID;
	private Integer WORKID;
	private Integer STATEBEFORE;
	private Integer STATEAFTER;
	private String USERNAME;
	private Date TIMEBEFORE;
	private Date TIMEAFTER;

	public Integer getLOGWORKID(){
		return this.LOGWORKID;
	}//getLOGWORKID

	public Integer getWORKID(){
		return this.WORKID;
	}//getWORKID

	public Integer getSTATEBEFORE(){
		return this.STATEBEFORE;
	}//getSTATEBEFORE

	public Integer getSTATEAFTER(){
		return this.STATEAFTER;
	}//getSTATEAFTER

	public String getUSERNAME(){
		return this.USERNAME;
	}//getUSERNAME

	public Date getTIMEBEFORE(){
		return this.TIMEBEFORE;
	}//getTIMEBEFORE

	public Date getTIMEAFTER(){
		return this.TIMEAFTER;
	}//getTIMEAFTER

	public LogWork(Integer LOGWORKID,Integer WORKID,Integer STATEBEFORE,Integer STATEAFTER,String USERNAME,Date TIMEBEFORE,Date TIMEAFTER){
		this.LOGWORKID = LOGWORKID;
		this.WORKID = WORKID;
		this.STATEBEFORE = STATEBEFORE;
		this.STATEAFTER = STATEAFTER;
		this.USERNAME = USERNAME;
		this.TIMEBEFORE = TIMEBEFORE;
		this.TIMEAFTER = TIMEAFTER;
	}//Constructor LogWork

}//class LogWork