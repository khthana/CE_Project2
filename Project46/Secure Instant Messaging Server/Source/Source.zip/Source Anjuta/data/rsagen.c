#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/bn.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>

#include <openssl/err.h>
#include <openssl/asn1.h>
#include <openssl/objects.h>
#include <openssl/evp.h>
#include <openssl/x509.h>

#define KEY_BIT         1024
#define NUMBER_ITERS    5
#define NUMBER_PRIMES   100
#define fp  "key.pem"
//#define RSA_F4  0x10001




int main(argc,argv) {

  //BIGNUM       pp, qq, tmps;
  //RSA_PUBKEY   public_key;
  //RSA_PRIVATE  private_key;

  char *filename = "testkey.pem";
  FILE *fk;

  BIGNUM *k;
  RSA *rsa_key = NULL;
  EVP_CIPHER *des = NULL;
  int i, j, l, num;
  unsigned long e = 17;
  //unsigned char *pt;
  //unsigned char *ct;
  unsigned char ptext[256];
  unsigned char ctext[256];
  static unsigned char ptext_ex[] = "1234567890";
  unsigned char ctext_ex[256];
  int plen;
  //int clen = 0;        
  //char *passwd = "123456";

  CRYPTO_malloc_debug_init();
  CRYPTO_dbg_set_options(V_CRYPTO_MDEBUG_ALL);
  CRYPTO_mem_ctrl(CRYPTO_MEM_CHECK_ON);

  plen = sizeof(ptext_ex) - 1;

  //des = EVP_des_ede3_cbc();
  rsa_key = RSA_generate_key(KEY_BIT, RSA_F4, NULL, NULL);

  //clen = key3(rsa_key, ctext_ex);
  
  fprintf(stdout,"ptext_ex with in encrypt = %s\n\n", ptext_ex);
  num = RSA_public_encrypt(plen, ptext_ex, ctext, rsa_key,
				 RSA_PKCS1_PADDING);
  //k = rsa_key->n;
  //fprintf(stdout,"ptext_ex after encrypt = %s\n\n", ptext_ex);
  fprintf(stdout,"ctext after encrypt,with ctext get data encryt = %s\n\n", ctext);

  
	num = RSA_private_decrypt(num, ctext, ptext, rsa_key,
				  RSA_PKCS1_PADDING);
	if (num != plen || memcmp(ptext, ptext_ex, num) != 0)
	    {
	    printf("PKCS#1 v1.5 decryption failed!\n\n");
	    }
	else
	    printf("PKCS #1 v1.5 encryption/decryption ok\n\n");

  
  fprintf(stdout,"ptext after decrypt,decryption from ctext = %s\n\n", ptext);
  //fprintf(stdout,"ctext after decrypt = %s\n", ctext);

/*  
  if ((fk=fopen(filename, "wb")) == NULL)
    { perror(filename);
      fprintf(stderr,"something bad happened....");
    }
*/    
  
  //pt = malloc(sizeof(char) * 512 );
  //ct = malloc(sizeof(char) * 512 );
  //strcpy(pt, "adisak wangjanla");
  
  

  
  //for(i=0;i<512;i++)
  //{
  //    pt[i] = '\0';
  //    ct[i] = '\0';
  //}

  

  //PEM_write_RSAPrivateKey(stdout, rsa_key, des, NULL, 0, NULL, passwd);

  //fprintf(stdout,"\n");
  //fprintf(stdout,"\n");
  //PEM_write_RSAPublicKey(stdout, rsa_key);
  /// int PEM_write_RSAPublicKey(FILE *fp, RSA *x);

  
  //i = RSA_size(rsa_key);
  //fprintf(stdout,"rsa_size = %d\n", i);
  //fprintf(stdout,"rsa_key = %d\n", rsa_key->version);

  //RSA_public_encrypt(16, pt, ct, rsa_key, RSA_PKCS1_PADDING);

  //fprintf(stdout,"pt = %s\n", pt);
  //fprintf(stdout,"ct = %s\n", ct);


  //RSA_public_decrypt(16, ct, pt, rsa_key, RSA_PKCS1_PADDING);

  //fprintf(stdout,"pt = %s\n", pt);
  //fprintf(stdout,"ct = %s\n", ct);

  //fclose(fk);

  //free(pt);
  //free(ct);
  RSA_free(rsa_key);
  
  exit(0);

}

