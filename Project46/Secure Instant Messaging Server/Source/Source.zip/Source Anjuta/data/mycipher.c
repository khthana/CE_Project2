#include <stdio.h>
#include <stdlib.h>	//random
#include <string.h>	//strncpy
#include <math.h>    

#define BLOCK_EN			9 //characters or 64 (8*8) bit ,1 byte = temp
#define ROUND_ED			1

unsigned char iv[BLOCK_EN];
unsigned char iv_init[BLOCK_EN];
static unsigned char key[BLOCK_EN];
static unsigned char key_i[16][BLOCK_EN];

char *rotate_lift( unsigned char buff[], int round )
{
	unsigned char temp[BLOCK_EN];
	int cp;
	int i;
	
	while( round > 0)
	{
		round--;
	
		for(i = 7;i >= 0;i--)
		{
			cp = buff[ i ];
			if( cp > 0x7f )
				temp[ i ] = 0x01;
			else temp[ i ] = 0x00;
		
			buff[ i ] <<= 1;
		}	
		buff[7] = buff[7] | temp[0];
		for(i = 6;i >=0;i--)
			buff[ i ] |= temp[ i + 1];		
	}
	return buff;
}

char *rotate_right( unsigned char buff[], int round )
{
	unsigned char temp[BLOCK_EN];
	int i;
	
	while( round > 0)
	{
		round--;
	   
		for(i = 7;i >= 0;i--)
		{
			if( (buff[ i ] % 2)  == 1 )
				temp[ i ] = 0x80;
			else temp[ i ] = 0x00;
			buff[ i ] = buff[ i ] >> 1;
		}
	    
		buff[0] = buff[0] | temp[7];
		buff[1] = buff[1] | temp[0];
		buff[2] = buff[2] | temp[1];
		buff[3] = buff[3] | temp[2];
		buff[4] = buff[4] | temp[3];
		buff[5] = buff[5] | temp[4];
		buff[6] = buff[6] | temp[5];
		buff[7] = buff[7] | temp[6];
	}
	return buff;
}

void set_key()
{
	//int i;
	unsigned char temp[BLOCK_EN];
	
	//fprintf(stderr, "\nKey original En/De :%s \n", key);
	strncpy(temp, key ,8);
	strncpy(key_i[0], rotate_right( temp, 16 ), 8);
	strncpy(temp, key_i[0] ,8);
	strncpy(key_i[1], rotate_right( temp, 1 ), 8); 
	strncpy(temp, key_i[1] ,8);
	strncpy(key_i[2], rotate_right( temp, 1 ), 8);
	strncpy(temp, key_i[2] ,8);
	strncpy(key_i[3], rotate_right( temp, 2 ), 8);
	strncpy(temp, key_i[3] ,8);
	strncpy(key_i[4], rotate_right( temp, 16 ), 8);
	strncpy(temp, key_i[4] ,8);
	strncpy(key_i[5], rotate_right( temp, 3 ), 8);
	strncpy(temp, key_i[5] ,8);
	strncpy(key_i[6], rotate_right( temp, 16),8);
	strncpy(temp, key_i[6] ,8);
	strncpy(key_i[7], rotate_right( temp, 2 ),8);
	strncpy(temp, key_i[7] ,8);
	strncpy(key_i[8], rotate_right( temp, 1 ),8);
	strncpy(temp, key_i[8] ,8);
	strncpy(key_i[9], rotate_right( temp, 1 ),8);
	strncpy(temp, key_i[9] ,8);
	strncpy(key_i[10], rotate_right( temp, 3 ),8);
	strncpy(temp, key_i[10] ,8);
	strncpy(key_i[11], rotate_right( temp, 7 ),8);
	strncpy(temp, key_i[11] ,8);
	strncpy(key_i[12], rotate_right( temp, 1 ),8);
	strncpy(temp, key_i[12] ,8);
	strncpy(key_i[13], rotate_right( temp, 1 ),8);
	strncpy(temp, key_i[13] ,8);
	strncpy(key_i[14], rotate_right( temp, 5 ) ,8);
	strncpy(temp, key_i[14] ,8);
	strncpy(key_i[15], rotate_right( temp, 1 ), 8);
	
	//for(i = 0;i < 16;i++)
	//	fprintf(stderr, "Key %d :%s \n", i, key_i[i]);
}

void pading(int pad ,unsigned char plain[])
{
	int i;
	
		for(i = pad;i < 8;i++)
			plain[i] = ' ';
}

int n =0;
int get_plain(unsigned char plain[])
{
	int i;
	int block = 0;
	unsigned char c = ' ';
	
		for(i = 0;i < 9;i++)
			plain[i] = '\0';			
	
	    while( !feof(stdin) && block < 8) 
		{
			c = getc(stdin);
			plain[block ] = c;
			block++;			
		}
		
		/*Check Paddig*/
		if ( feof(stdin)  && ( block < 8) )	
		{			
			pading(block-1, plain);
			return 0;
		}	
	return 1;
}

void encryption(unsigned char plain[], unsigned char cipher[])
{
	unsigned char buff[BLOCK_EN];
	int i, j;
	
		strncpy(buff, plain, 8);
		for(i = 0;i < 9;i++)
			cipher[i] = '\0';	
		
		for(j = 0;j < ROUND_ED;j++)
		{
			for(i = 0;i < 8;i++)
				cipher[i] = buff[i] ^ key_i[j][i];
			strncpy(buff, cipher, 8);
		}
}

void encryption_three(unsigned char plain[], unsigned char temp[], unsigned char cipher[])
{
	unsigned char buff[BLOCK_EN];
	int i, j;
	
		strncpy(buff, plain, 8);
		for(i = 0;i < 9;i++)
			cipher[i] = '\0';	
		
		for(j = 0;j < ROUND_ED;j++)
		{
			for(i = 0;i < 8;i++)
				cipher[i] = buff[i] ^ temp[i] ^ key_i[j][i];
			strncpy(buff, cipher, 8);
		}
}

unsigned char arm[] = {'0','1' ,'2' ,'3' ,'4' ,'5' ,'6' ,'7', 
	                                 '8','9' ,'a' ,'b' ,'c' ,'d' ,'e' ,'f'};
void armor(unsigned char cipher[])
{	
	int i, hexl, hexh;
	unsigned char temp; 
	
		for(i = 0;i < 8;i++)
		{	
			temp = cipher[i];
			hexl = temp & 0x0f ;
			temp = cipher[i];
			temp >>= 4;
			hexh = temp & 0x0f;
			putc(arm[hexh], stdout);
			putc(arm[hexl], stdout);		
		}
}

/*Higth iv[7] ,  Low iv[0]*/
void add_one_64bit(unsigned char iv[])
{	
	int i;
		
		for(i = 0;i < 8;i++)
		{
				iv[7 - i] += 1;
				if( iv[7 - i] != 0 )
					break;
		}
}

void init_iv()
{
	int num, i;
	
		for(i = 0;i < 9;i++) {
			iv_init[i] = '\0';
			iv[i] = '\0';
		}
	
		for(i = 0;i < 8;i++)
		{
			num = rand() % 255;
			iv_init[i] = num;
		}
}

void rotate_lift_plain(unsigned char plain[])
{
	unsigned char c;
	int ro;
	
		c = plain[5];
		ro = c % 7;
		//fprintf(stderr, "ro :%d\n", ro);
		strncpy(plain, rotate_lift( plain, 7 ), 8);	
}

void iv_to_file()
{
	unsigned char temp_iv[BLOCK_EN];
		
		/*Encrypt IV*/
		encryption(iv_init, temp_iv);
		armor(temp_iv);		
}

void make_en()
{
	int loop = 0;
	unsigned char plain[BLOCK_EN];
	unsigned char cipher[BLOCK_EN];
	unsigned char temp[BLOCK_EN];
	
		set_key();
	
		init_iv();
		strncpy(iv, iv_init, 8);
		iv_to_file();
	
		do
		{
			loop = get_plain(plain);
			
			/*Rotating original Plain*/
			rotate_lift_plain(plain);	
			
			/*Encrypt iv and key = temp*/
			encryption(iv, temp);
			/*iv = iv + 1*/
			add_one_64bit(iv);			
			
			/*Encrypt key and temp and message = cipher*/
			encryption_three(plain, temp ,cipher);	
			
			/*Translate to String 00 - FF*/
			armor(cipher);			
			
		}while( loop );				
		
		fprintf(stderr, "\n\n");
}

unsigned char dearm[] = {0x00,0x01 ,0x02 ,0x03,0x04 ,0x05 ,0x06 ,0x07, 
	                                    0x08,0x09 ,0x0a ,0x0b ,0x0c ,0x0d ,0x0e ,0x0f};
char dearmor(unsigned char ch, unsigned char cl)
{	
	int i, j;
	unsigned char temp[] = {ch, cl};
	
		for(j = 0;j < 2;j++) 
		{
			for(i = 0;i < 16;i++)
			{
				if( temp[j] == arm[i] ) 	{
					temp[j] = dearm[i];
					break;				
				}		
			}	
		}
		temp[0] <<= 4;			
	
	return temp[0] | temp[1];
}

int get_cipher(unsigned char cipher[])
{
	int i, block = 0;
	unsigned char ch, cl, c;
		
		for(i = 0;i < 9;i++)
			cipher[i] = '\0';	
	
		while( !feof(stdin) && block < 8 )
		{
			ch = getc(stdin);
			cl = getc(stdin);			
			c = dearmor(ch, cl);
			cipher[block ] = c;		
			block++;
		}
		return block;
}

void decryption(unsigned char cipher[], unsigned char plain[])
{
	unsigned char buff[BLOCK_EN];
	int i, j;
	
		strncpy(buff, cipher, 8);

		for(j = 0;j < ROUND_ED;j++)
		{
			for(i = 0;i < 8;i++)
				plain[i] = buff[i] ^ key_i[(ROUND_ED - 1) - j][i];
			strncpy(buff, plain, 8);
		}
}

void decryption_three(unsigned char cipher[], unsigned char temp[], unsigned char plain[])
{
	unsigned char buff[BLOCK_EN];
	int i, j;
	
		strncpy(buff, cipher, 8);

		for(j = 0;j < ROUND_ED;j++)
		{
			for(i = 0;i < 8;i++)
				plain[i] = buff[i] ^ temp[i] ^ key_i[(ROUND_ED - 1) - j][i];
			strncpy(buff, plain, 8);
		}
}

void get_iv()
{
	unsigned char temp_iv[BLOCK_EN];
		
		get_cipher(temp_iv);
		decryption(temp_iv, iv_init);
}

void rotate_right_plain(unsigned char plain[])
{
	unsigned char c;
	int ro;
	
		c = plain[5];
		ro = c % 7;
		//fprintf(stderr, "ro :%d\n", ro);
		strncpy(plain, rotate_right( plain, 7 ), 8);	
}

void make_de()
{
	int i;
	unsigned char plain[BLOCK_EN];
	unsigned char cipher[BLOCK_EN];
	unsigned char temp[BLOCK_EN];
	
		set_key();
		
		get_iv();
		strncpy(iv, iv_init, 8);
		
		while( get_cipher(cipher) == 8)
		{	
			/*Encrypt iv and key = temp*/
			encryption(iv, temp);
			/*iv = iv + 1*/
			add_one_64bit(iv);
		
			/*Decrypt key and temp and cipher = plain*/
			decryption_three(cipher, temp ,plain);
			
			/*Rotate to original Plain txt*/
			rotate_right_plain(plain);
			
			for(i = 0;i < 8;i++)
				putc(plain[i], stdout);	
				
		}	
		fprintf(stderr, "\n");
}

int main( int argc ,char *argv[ ] )
{
	unsigned char *option = argv[1];
	
	if( option[0] == '-' &&  option[1] == 'e' )
	{
		strncpy( key, argv[2], 8) ;
		
		if( (strlen(key) != 8) || (strlen(argv[2]) != 8) )
			fprintf(stderr, "\nKey Length != 8 Character, Take Key again\n\n");				
		else {
			make_en();		
			fprintf(stderr, "Encrypt Complete, look in the file cipher.txt\n\n");
		}
		return (1);
	}
	else if( option[0] == '-' &&  option[1] == 'd' )
	{
		strncpy( key, argv[2], 8) ;
		
		if( (strlen(key) != 8) || (strlen(argv[2]) != 8) )
			fprintf(stderr, "\nKey Length != 8 Character, Take Key again\n\n");
		else {
			make_de();
			fprintf(stderr, "Decrypt Complete, look in the file plain.txt\n\n");
		}
		return (1);	
	}
	else 
	{
		fprintf(stderr, "No option\n");
		return (0);
	}
	
}
