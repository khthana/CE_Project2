#include "encryption.h"
#include "thread.h"
#include "rw_ran.h"
#include "db_mysql.h"
#include "comman.h"
#include "services.h"

static char ip_client[16];
static char channel ;

void init_OpenSSL(void);

void do_services(SSL *ssl)
{
    char ip[FIX_IP];
    char subject[MAXSUBJECT];
    char user_id[FIX_USER_ID];
    int  registor_on = 0;
	int check = 0;
    X509 *ctx;
    X509_NAME *ctx_name;
    //char *ftemp = "ftemp.txt";
    //FILE *fs;



    /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
    unsigned char buffer_read[MAX_MESSAGE];
    int i;
   
    for(i = 0;i < MAX_MESSAGE;i++)
    { buffer_read[i] = '\0'; }

    strcpy(ip, ip_client);
    /*Show information connect from client*/
	fprintf(stdout,"Server got connection from :%s\n", ip);
    
    /*Count number client */
    NUMBER_CLIENT++;
    fprintf(stdout,"Number of current Client : %d\n\n", NUMBER_CLIENT);
    if(NUMBER_CLIENT > 250)
    {
      fprintf(stdout, "Number current connect > 250 \n");
      fprintf(stdout, "Connect Again\n");
      write_err_message(ssl, CONNECT_FULL, "Connect Again About Connection Full");
      goto exit_services;
    }
    write_err_message(ssl, NO_ERROR, "Loading Connect Complete ^_^");

    /*Get Subject Information of user*/
        ctx = SSL_get_peer_certificate(ssl);
        ctx_name = X509_get_subject_name(ctx);
        X509_NAME_oneline(ctx_name, subject, sizeof(subject));

    /*Get USER ID*/
        strncpy(user_id, get_user_id(subject), FIX_USER_ID);
    
    //Initial Linked List
    if(NUMBER_CLIENT == 1) {
        if(!start_list(user_id, ip)) {
			fprintf(stdout, "%s   ", user_id);
        	printf("Start Linked List Error\n");
		}
    }
	else
		if( !insert(user_id, ip) ) {
			fprintf(stdout, "%s   ", user_id);
			printf("Insert Linked List Error\n");
		}
		
    while(1)
    {
        /*read message channel*/
        /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
        fprintf(stdout, "%s   ", user_id);
		fprintf(stdout, "Wait service command...........\n");
		ssl_read(ssl, buffer_read, sizeof(buffer_read));
        channel = buffer_read[0];
		
        /*check channel*/
        switch(channel)
        {
            case 0x1: /*check user*/
							fprintf(stdout, "%s   ", user_id);
                     		fprintf(stdout, "Packet channel 1:New user\n");
							
							new_user(ssl, buffer_read, ip, user_id);								
							
							/*free buffer of the channel*/
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';		
                      		break;
            case 0x2: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 2:Login\n");
			
                      		 login(ssl, buffer_read, user_id);
			
							/*free buffer of the channel*/
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
                     		 break;
            case 0x3: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 3:Add Contractlist\n");
			
							add_contactlist(ssl, buffer_read, user_id);
			
							/*free buffer of the channel*/
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';	
                     		break;
            case 0x4: fprintf(stdout, "%s   ", user_id);
				    		fprintf(stdout, "Packet channel 4:Change Nick Name\n");
							change_nick_name(ssl, buffer_read, user_id);
								
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
                      		break;
            case 0x5: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 5:Status\n");
							status(ssl, buffer_read, user_id);
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
                      		break;
            case 0x6: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 6:Error\n");
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
                      		break;
			case 0x7: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 7:Logout\n");
							/*Delect User ID from Liked List*/
            				delete(user_id);
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
							goto exit_services;
			case 0x8: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel 8:Find Contactlist\n");
							/*Find Contract list*/
							find_contactlist(ssl, buffer_read, user_id);
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
							break;
			case 0xa: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel a:Delete Admin\n");
							delete_admin(ssl, buffer_read, user_id);
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
							break;
			case 0xb: fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet channel a:Delete Contactlist\n");
							delete_contactlist(ssl, buffer_read, user_id);
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
							break;
            default : 	fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "Packet no channel\n");
							for(i = 0;i < MAX_MESSAGE;i++)
								buffer_read[i] = '\0';
							delete(user_id);
                      	  	goto exit_services;
        }
    }

exit_services:    
    //return do_server_loop(ssl);
    //return (SSL_get_shutdown(ssl) & SSL_RECEIVED_SHUTDOWN) ? 1 : 0;
}

int do_server_loop(SSL *ssl)
{
    int  err, nread;
    char buf[80];

    do
    {
        for (nread = 0;  nread < sizeof(buf);  nread += err)
        {
            err = SSL_read(ssl, buf + nread, sizeof(buf) - nread);
            if (err <= 0)
                break;
        }
        fprintf(stdout, "%s", buf);
    }
    while (err > 0);
    return (SSL_get_shutdown(ssl) & SSL_RECEIVED_SHUTDOWN) ? 1 : 0;
}

void THREAD_CC server_thread(void *arg)
{
    X509  *cert;
    SSL   *ssl = (SSL *)arg;
    long err;
    //char *CLIENT = "161.246.5.18";

#ifndef WIN32
    pthread_detach(pthread_self(  ));
#endif
    
    //fprintf(stderr, "Take Pthread");
    if (SSL_accept(ssl) <= 0)
    {
        //int_error("Error accepting SSL connection");
        fprintf(stderr, "Error accepting SSL connection");
        //ssl_disconnect(ssl);
        goto end_connect; 
    }

    //SSL_set_timeout(ssl, time_out);
    //time_out = SSL_get_default_timeout(ssl);
    //fprintf(stdout,"time_out :%f\n", time_out);            
    //Check peer_certificate
/*    if (!(cert = SSL_get_peer_certificate(ssl)) || !host)
      {
        fprintf(stdout,"SSL_get_peer_certificate ERROR\n");
        goto err_occured;
      }    
*/         
    fprintf(stderr, "SSL Connection opened\n\n");
    //Managment Services
    do_services(ssl);

end_connect:    
    ssl_disconnect(ssl);
    
    ERR_remove_state(0);
#ifdef WIN32
    _endthread(  );
#endif
}

int main(int argc, char *argv[])
{
    char user_id[10];
	long len, i;
    
    //SSL Connection Argument
    BIO     *client;
    SSL     *ssl;
    SSL_CTX *ctx;

    THREAD_TYPE tid;

    //TCP Connectoin Argument
    int serverfd, clientfd;
    int sin_size;
    struct sockaddr_in server_addr, client_addr;
    unsigned char *client_ip;
    unsigned char *client_hostname;

	system("clear");
	
    fprintf(stdout, "Start\n");
	
	for(i = 0;i < FIX_IP;i++)
    { ip_client[i] = '\0'; }

    init_OpenSSL( );

    seed_prng(  );

    ctx = setup_server_ctx(  );

    //fprintf(stdout, "OK setup_server_ctx\n\n");

    //TCP Connecting
    if((serverfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
      perror("Socket error");
      exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    //server_addr.sin_addr.s_addr = inet_addr("161.246.5.18");
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY); //Get IP Address of server in system

    bzero(&(server_addr.sin_zero), 8);    // zero struct

    if(bind(serverfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1)
    {
      perror("Error binding");
      exit(1);
    }

    if(listen(serverfd, BACKLOG) == -1)
    {
      perror("Error listening");
      exit(1);
    }

    //fprintf(stdout, "\n\n");
    fprintf(stdout, "SSL wait Connection opened from Client\n\n");
    for (;;)
    {
        
        /*Wait and Accept client*/
        sin_size = sizeof(struct sockaddr_in);
        if((clientfd = accept(serverfd, (struct sockaddr*)&client_addr,
                              &sin_size)) == -1)
        {
          perror("Error accepting");
        }

        /*Get ip of connect from client*/
		//len = strlen(inet_ntoa(client_addr.sin_addr));
		//fprintf(stdout, "IP %d\n", len);
		//if(len <= 15 && len >=7)
        	strcpy(ip_client, inet_ntoa(client_addr.sin_addr));
		//else 
		//{
		//	fprintf(stdout, "IP Fail\n");			
		//	goto exit_isagmq;			
		//}
		
        //SSL Connecting
        client = BIO_new_socket(clientfd, BIO_NOCLOSE);

        if (!(ssl = SSL_new(ctx)))
          int_error("Error creating SSL context");

        SSL_set_accept_state(ssl);

        SSL_set_bio(ssl, client, client);
/*
        

        //Random User_ID
        double_random(user_id);
        fprintf(stderr, "\nUser ID: :%s\n",user_id);

        //Linked List
        linked_list();
*/
        //Thread Start
        THREAD_CREATE(tid, (void *)server_thread, ssl);
    }

exit_isagmq:	
	
    SSL_CTX_free(ctx);
    BIO_free(client);
    close(serverfd);
    return 0;
}
