#ifndef HEADER_SUPPORT_SERVICES_H
#define HEADER_SUPPORT_SERVICES_H 

#include "comman.h"
#include "rw_ran.h"

/*Golbal Variable*/
unsigned int length = 0;

/*
  Check Email
*/
int spc_email_isvalid(const char *address) {
  int        count = 0;
  const char *c, *domain;
  static char *rfc822_specials = "()<>@,;:\\\"[]";

  /* first we validate the name portion (name@domain) */
  for (c = address;  *c;  c++) {
    if (*c == '\"' && (c == address || *(c - 1) == '.' || *(c - 1) == '\"')) {
      while (*++c) {
        if (*c == '\"') break;
        if (*c == '\\' && (*++c == ' ')) continue;
        if (*c <= ' ' || *c >= 127) return 0;
      }
      if (!*c++) return 0;
      if (*c == '@') break;
      if (*c != '.') return 0;
      continue;
    }
    if (*c == '@') break;
    if (*c <= ' ' || *c >= 127) return 0;
    if (strchr(rfc822_specials, *c)) return 0;
  }
  if (c == address || *(c - 1) == '.') return 0;

  /* next we validate the domain portion (name@domain) */
  if (!*(domain = ++c)) return 0;
  do {
    if (*c == '.') {
      if (c == domain || *(c - 1) == '.') return 0;
      count++;
    }
    if (*c <= ' ' || *c >= 127) return 0;
    if (strchr(rfc822_specials, *c)) return 0;
  } while (*++c);

  return (count >= 1);
}
void safe_printf(char *data){

    safestr_t fmt;

    fmt = SAFESTR_CREATE(data);

    safestr_printf(fmt);

    safestr_free(fmt);

}

/*
  Get data function
    buf = buffer of data obtian data from netword
    data = final data
    start = point begin get data
*/         
int get_data(char buf[], char data[], int start)
{
    int iptr = 0;
    unsigned char c;
    
    while(1)
    {
        c = buf[start];
        if(c == '$')
        {
            start++;
            data[iptr] = '\0';
            break;
        }
        else if( c < 0x21 || c > 0x7e || c == '\0' )  {
			fprintf(stdout, "             ");
			fprintf(stdout, "ERROR No. Data\n");
            return 0;
		}
          
        data[iptr] = c;
        start++;
        iptr++;
    }
    return start;
}

/*
  Before use not make connect to DB
	Check DB 3 args**************************************************************
*/
int check_db3(char tempq[], char user_id[], char type_service[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	int check_query;
	int check_db = 1;
	int i;
	char query[MAX_MESSAGE];
	
		/*Check Imformation in the Database*/
		
		/*Connect to Database*/
        	isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        	if(isagmq_db == NULL)
        	{
            	fprintf(stdout, "Connect to Database Error");
            	return -1;
        	}
			
			/*Query*/
  			/*Select user_id*/
    			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, tempq);
     			strncat(query, user_id, FIX_USER_ID);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				//fprintf(stdout,"Query = %s\n", query);
       				mysql_query(isagmq_db, query);
       				res_set = mysql_store_result(isagmq_db);

       				row = mysql_fetch_row(res_set);
       				if( row == NULL) {
						fprintf(stdout, "%s   Can %s \n", user_id, type_service);
						return 1;
					}
					else 
						return 0;					
       			
       			mysql_free_result(res_set);
				}	
     			else if(check_query == 0) {
       				fprintf(stdout, "%s   Can't %s \n", user_id,  type_service);
         			return 0;
     			}
     			else {
        			/*Send NACK  DB system error*/
					fprintf(stdout,"%s             DB system error\n", type_service);
					return -1;
     			}

end_check_register:
			
}

/*
	Before use make connect to DB
	Check DB 5 args**************************************************************
*/
int check_db5(char tempq1[], char user_id[], char tempq2[],char user_id_contact[],char type_service[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	int check_query;
	int check_db = 1;
	int i;
	char query[MAX_MESSAGE];
	
			
			/*Query*/
  			/*Select user_id*/
    			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, tempq1);
     			strncat(query, user_id, FIX_USER_ID);
				strcat(query, tempq2);
				strncat(query, user_id_contact, FIX_USER_ID);
				//fprintf(stdout,"Query = %s\n", query);
				
     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				//fprintf(stdout,"Query = %s\n", query);
       				mysql_query(isagmq_db, query);
       				res_set = mysql_store_result(isagmq_db);

       				row = mysql_fetch_row(res_set);
       				if( row == NULL) {
						fprintf(stdout, "%s   Can %s \n", user_id, type_service);
						return 1;
					}
					else 
						return 0;					
       			
       			mysql_free_result(res_set);
				}	
     			else if(check_query == 0) {
       				fprintf(stdout, "%s   Can't %s \n", user_id,  type_service);
         			return 0;
     			}
     			else {
        			/*Send NACK  DB system error*/
					fprintf(stdout,"%s             DB system error\n", type_service);
					return -1;
     			}			
}


/*
	Convert Length & Sequence************************************************
*/
unsigned char convert_high(unsigned char x)
{
	unsigned char tmp;
	switch(x)
	{
		case '0' :tmp = 0x00;
		                break;
		case '1' :tmp = 0x10;
		                break;
		case '2' :tmp = 0x20;
		                break;
		case '3' :tmp = 0x30;
		                break;	
		case '4' :tmp = 0x40;
		                break;
		case '5' :tmp = 0x50;
		                break;
		case '6' :tmp = 0x60;
		                break;
		case '7' :tmp = 0x70;
		                break;
		case '8' :tmp = 0x80;
		                break;
		case '9' :tmp = 0x90;
		                break;
		case 'a' :tmp = 0xa0;
		                break;
		case 'b' :tmp = 0xb0;
		                break;	
		case 'c' :tmp = 0xc0;
		                break;
		case 'd' :tmp = 0xd0;
		                break;
		case 'e' :tmp = 0xe0;
		                break;
		case 'f' :tmp = 0xf0;
		                break;
		default: tmp= 0x45;
	}
	return tmp;
}
unsigned char convert_low(unsigned char y)
{
	unsigned char tmp1;
	switch(y)
	{
		case '0' :tmp1 = 0x00;
		                break;
		case '1' :tmp1 = 0x01;
		                break;
		case '2' :tmp1 = 0x02;
		                break;
		case '3' :tmp1 = 0x03;
		                break;	
		case '4' :tmp1 = 0x04;
		                break;
		case '5' :tmp1 = 0x05;
		                break;
		case '6' :tmp1 = 0x06;
		                break;
		case '7' :tmp1 = 0x07;
		                break;
		case '8' :tmp1 = 0x08;
		                break;
		case '9' :tmp1 = 0x09;
		                break;
		case 'a' :tmp1 = 0x0a;
		                break;
		case 'b' :tmp1 = 0x0b;
		                break;	
		case 'c' :tmp1 = 0x0c;
		                break;
		case 'd' :tmp1 = 0x0d;
		                break;
		case 'e' :tmp1 = 0x0e;
		                break;
		case 'f' :tmp1 = 0x0f;
		                break;
		default: tmp1= 0x45;
	}
	return tmp1;
}
void assign_value(unsigned char* hex,unsigned char* hex_r)
{
	int dec;
	
		dec = strlen(hex);

		if(dec==1){
			hex_r[0]='0';
			hex_r[1]='0';
			hex_r[2]='0';
			hex_r[3]=hex[0];
		}
		else if(dec==2){
			hex_r[0]='0';
			hex_r[1]='0';
			hex_r[2]=hex[0];
			hex_r[3]=hex[1];
		}
		else if(dec==3){
			hex_r[0]='0';
			hex_r[1]=hex[0];
			hex_r[2]=hex[1];
			hex_r[3]=hex[2];
		}
		else {
			hex_r[0]=hex[0];
			hex_r[1]=hex[1];
			hex_r[2]=hex[2];
			hex_r[3]=hex[3];
		}
}
void convert_sequence(int length,unsigned char hex_total[])
{
	int i;
	unsigned char hex[4];
	unsigned char cl[2],ch[2],hex_r[4];
	unsigned char tmp1,tmp2;

		sprintf(hex,"%x",length);
		//printf("%s\n",hex);

	 	assign_value(hex,hex_r);	
	
		for(i=0;i<2;i++)
	 		ch[i]=hex_r[i];
		for(i=0;i<2;i++)
	 		cl[i] = hex_r[2+i];

		tmp1 = convert_high(ch[0]);
		tmp2 = convert_low (ch[1]);
		hex_total[0] = tmp1+tmp2;

		tmp1 = convert_high(cl[0]);
		tmp2 = convert_low (cl[1]);
		hex_total[1] = tmp1+tmp2;
}


/*
	Check Name************************************************
*/
int check_char_name(int a_value)
{
	int status=0;
		if( (a_value>64 && a_value < 91) || (a_value >96 && a_value < 123) )
			status = 1;
		return status;
}
int check_name(char name[])
{
	int dec,i,status;
	
		dec = strlen(name);
   
		for(i=0;i<dec;i++){
	    	status = name[i];
			status = check_char_name(status);
			if(status == 0)break;
		}
  	return status;
}

/*
	Check Sex************************************************
*/
int check_sex(unsigned char sex[])
{
	int status;
    	switch(sex[0])
	 	{
			case 'F' :status = 1;
		                	break;
			case 'f' :status = 1;
		                	break;
			case 'M' :status = 1;
		                	break;
			case 'm' :status = 1;
		                	break;
			default: status= 0;
	 	}
	return status;					
}

/*
	Check age************************************************
*/
int check_char_age(int a_value)
{
	int status=0;
	if( (a_value>47 && a_value < 58) )
		status = 1;
	return status;
}
int check_age(unsigned char age[])
{
	int dec,i,status,max_age;
	
	dec = strlen(age);

	if(dec == 2){
	   
	   for(i=0;i<dec;i++){
			status = age[i];
			status = check_char_age(status);
			if(status == 0)break;
		  }
	}
	else
	{
       max_age = age[0];
	   if(max_age != 49) status = 0;
       else
	   {
		 for(i=1;i<dec;i++){
			status = age[i];
			status = check_char_age(status);
			if(status == 0)break;
		  }
	   }
    }
  return status;
}


/*
	Check Nick Name************************************************
*/
int check_char_nick(int a_value)
{
	int status=0;
	if( a_value>32 && a_value < 127 )
		status = 1;
	return status;
}

int get_pointer(unsigned char buffer[],int point)
{
	int a_value;
	
		while(1){
			a_value = buffer[point];		
			
		}
  return point;
}
int get_nickname(unsigned char buffer[],unsigned char nickname[],int point)
{
	int status,i=0,j,k;
	int a_value;
	int p;
	
	p = point;
	while(1)
	{	
		a_value = buffer[point];
		status = check_char_nick(a_value);
		if(status==0){ 
			k= strlen(nickname);
			for(j=0;j<k;j++) nickname[j]='\0';
			strcpy(nickname,"N/A");
			break;
		}
		else 
		{
			if(a_value == 36)
				{
					point++;
					a_value = buffer[point];
					
					if(a_value != 36) break;
					
					point++;
					a_value = buffer[point];
					
					if(a_value == 36) nickname[i] = '$';
					
					else
					{
						k= strlen(nickname);
						for(j=0;j<k;j++) nickname[j]='\0';
						 strcpy(nickname,"N/A");
						 break;
					}
			}
			else 
			 nickname[i]=buffer[point];
		}
		point++;
		i++;
	}
	
	return get_pointer( buffer , p);
}


/*
	Check User ID************************************************
*/
int check_char_userid(int a_value)
{
	int status=0;
	if( (a_value>47 && a_value < 58) )
		status = 1;
	return status;
}
int check_userid(unsigned char userid[])
{
	int i,status=0,num,a_value;
	num = strlen(userid);
	for(i=0;i<num;i++)
	{
		a_value = userid[i];
		status = check_char_userid(a_value);
		if(status == 0)break;
	}
	return status;
}

#endif
