#ifndef HEADER_RW_RAN_H
#define HEADER_RW_RAN_H

#include "comman.h"

#define PORT            16001
#define BACKLOG         5
#define SERVER          "161.246.5.18"
//#define SERVER          "localhost"
//#define CLIENT          "localhost"


/* Return a random integer between MIN and MAX, inclusive. Obtain
randomness from /dev/random. */
unsigned int random_sequence(int MAX_RAN, int MIN_RAN)
{
  /* Store a file descriptor opened to /dev/random in a static
  variable. That way, we don�t need to open the file every time
  this function is called. */
  static int dev_random_fd = -1;
  char* next_random_byte;
  int bytes_to_read;
  unsigned random_value;
  int x1, x2;
  //char user_id[5];

  /* Make sure MAX is greater than MIN. */
  assert (MAX_RAN > MIN_RAN);

  /* If this is the first time this function is called, open a file
  descriptor to /dev/random. */
  if (dev_random_fd == -1)
  {
    dev_random_fd = open("/dev/random", O_RDONLY);
    assert (dev_random_fd != -1);
  }

  /* Read enough random bytes to fill an integer variable. */
  next_random_byte = (char*) &random_value;
  bytes_to_read = sizeof (random_value);

  /* Loop until we�ve read enough bytes. Because /dev/random is filled
  from user-generated actions, the read may block and may only
  return a single random byte at a time. */
  do
  {
    int bytes_read;
    bytes_read = read (dev_random_fd, next_random_byte, bytes_to_read);
    bytes_to_read -= bytes_read;
    next_random_byte += bytes_read;
  } while (bytes_to_read > 0);

  /* Compute a random number in the correct range. */
 return MIN_RAN + (random_value % (MAX_RAN - MIN_RAN + 1));

}


/*Random*/
#define MAX_RAN 99999
#define MIN_RAN 9999

/***************************************************************************************/
/* Return a random integer between MIN and MAX, inclusive. Obtain
randomness from /dev/random. */
void random_number (char* user_id)
{
  /* Store a file descriptor opened to /dev/random in a static
  variable. That way, we don�t need to open the file every time
  this function is called. */
  static int dev_random_fd = -1;
  char* next_random_byte;
  int bytes_to_read;
  unsigned random_value;
  unsigned id;
  int x1, x2;
  //char user_id[5];

  /* Make sure MAX is greater than MIN. */
  assert (MAX_RAN > MIN_RAN);

  /* If this is the first time this function is called, open a file
  descriptor to /dev/random. */
  if (dev_random_fd == -1)
  {
    dev_random_fd = open("/dev/random", O_RDONLY);
    assert (dev_random_fd != -1);
  }

  /* Read enough random bytes to fill an integer variable. */
  next_random_byte = (char*) &random_value;
  bytes_to_read = sizeof (random_value);

  /* Loop until we�ve read enough bytes. Because /dev/random is filled
  from user-generated actions, the read may block and may only
  return a single random byte at a time. */
  do
  {
    int bytes_read;
    bytes_read = read (dev_random_fd, next_random_byte, bytes_to_read);
    bytes_to_read -= bytes_read;
    next_random_byte += bytes_read;
  } while (bytes_to_read > 0);

  /* Compute a random number in the correct range. */
  id = MIN_RAN + (random_value % (MAX_RAN - MIN_RAN + 1));

  if(id < 9999 && id > 100000)
    exit(0);

 sprintf(user_id,"%d",id);

     /*Check User ID */
}

void double_random(char *user_id){
  char user_id_tmp1[10];
  char user_id_tmp2[5];

  random_number(user_id_tmp1);
  //fprintf(stderr, "\n\nOutput :%s\n",user_id_tmp1);

  random_number(user_id_tmp2);
  //fprintf(stderr, "\nOutput :%s\n",user_id_tmp2);

  strcat(user_id_tmp1,user_id_tmp2);
  //fprintf(stderr, "\nOutput :%s\n",user_id_tmp1);

  strcpy(user_id,user_id_tmp1);

}

void ssl_disconnect(SSL *ssl)
{
    if( (SSL_get_shutdown(ssl) & SSL_RECEIVED_SHUTDOWN) ? 1 : 0 )
        SSL_shutdown(ssl);
    else
        SSL_clear(ssl);

    NUMBER_CLIENT--;
    fprintf(stderr, "\nSSL Connection closed\n");
    SSL_free(ssl);

}

void ssl_read(SSL *ssl, char *buf, int length)
{
    int  err;
    //char *buffer = buf;

    err = SSL_read(ssl, buf, length);
    if (err < 0)
    {
        fprintf(stdout,"Error Read\n");
        ssl_disconnect(ssl);
    }
}

void ssl_write(SSL *ssl, char *buf, int length)
{
    int  err;

    err = SSL_write(ssl, buf, length);
    if (err < 0)
    {
        fprintf(stdout,"Error write\n");
        ssl_disconnect(ssl);
    }
}

void write_err_message(SSL *ssl, unsigned char con, char mess[])
{
    char buffer[MAX_MESSAGE];
    int i;
    
    /*write_err_message*/
        /*channel=0x06, sequence=0x0001, length=x0007, command=0xXX, flag=0xff */
        /*Set header*/
        buffer[0] = 0x06;
        buffer[1] = 0x00;
        buffer[2] = 0x01;
        buffer[3] = 0x00;
        buffer[4] = 0x07;
        buffer[5] = con;
        buffer[6] = 0xff;

        //fprintf(stdout,"mess=%s\n", mess);
        //fprintf(stdout,"strlen(mess)=%d\n", strlen(mess));
        for(i = 0;i < strlen(mess);i++)
            buffer[FIX_HEADER+1+i] = mess[i];         

        buffer[FIX_HEADER+1+strlen(mess)] = '$';
        ssl_write(ssl, buffer, sizeof(buffer));  
}

#endif
