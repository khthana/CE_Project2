#ifndef HEADER_comman_H
#define HEADER_comman_H

#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <errno.h>
#include  <sys/uio.h>   /* for iovec{} and readv/writev */
#include  <unistd.h>

#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>
#include <openssl/ssl.h>

//#include  <signal.h>
#include  <sys/types.h> /* basic system data types */
#include  <sys/socket.h>  /* basic socket definitions */
#include  <sys/time.h>  /* timeval{} for select() */
#include  <time.h>    /* timespec{} for pselect() */
#include  <netinet/in.h>  /* sockaddr_in{} and other Internet defns */
#include  <arpa/inet.h>   /* inet(3) functions */
#include  <fcntl.h>   /* for nonblocking */
#include  <netdb.h>

#include  <sys/stat.h>  /* for S_xxx file mode constants */
//#include  <sys/wait.h>
#include  <sys/un.h>    /* for Unix domain sockets */
#include  <sys/select.h>  /* for convenience */
#include  <assert.h>
#include  <fcntl.h>

#include <safestr.h>
#include <xxl.h>

#include  <mysql/mysql.h>

#define   POINT_USER_ID   "CN="
#define   MAXSUBJECT      256
#define   FIX_USER_ID     9
#define   FIX_IP          16
#define   FIX_HEADER      6     //0 1 2 3 4 5 6 = 7 bytes

#define MAX_MESSAGE     512 //per packet

static int NUMBER_CLIENT = 0;

//Error Messages
#define   NO_ERROR        0x00
#define   CONNECT_FULL    0x01

/*
    Get user id from certificate
*/   
char *get_user_id(char subject[])
{
    char *user_id;
    char temp[3];
    int loop;
    int point = 0;
    
    
    user_id = (char *)malloc(sizeof(char) *10);

    //find user_id
    for(loop = 0;loop < MAXSUBJECT;loop++)
    {
        if(subject[loop] == 'C')
        {
            temp[0] = 'C';
            if(subject[loop+1] == 'N')
                temp[1] = 'N';
            else temp[0] = '\0';

            if(subject[loop+2] == '=')
            {   temp[2] = '=';
                loop +=3;
                for(point =0;point < FIX_USER_ID;point++)
                {   if(subject[loop+point] == '/')
                        break;
                    user_id[point] = subject[loop+point];
                }
                break;
            }
            else
            {   temp[0] = '\0';
                temp[1] = '\0';
            }   
        }    
    }
    return user_id;
}

/*
    Linkde List Get user_id and ip of user online******************************
*/
typedef struct userconn {
  char user_id[FIX_USER_ID +1];
  char ip[FIX_IP];
  struct userconn *next;
} USERCONN;

static USERCONN *start;
static USERCONN *current;

int start_list(char *user_id, char *ip)
{
	int i;


  		if( (start = (USERCONN *)malloc(sizeof(USERCONN))) == NULL) {
    		fprintf( stderr, "Memory Allocation error.\n" );
    		exit(1);
  		}

  		if( (current = (USERCONN *)malloc(sizeof(USERCONN))) == NULL) {
    		fprintf( stderr, "Memory Allocation error.\n" );
    		exit(1);
  		}
  
  		for(i = 0;i < 11;i++) {
			start->user_id[i] = '\0';
			current->user_id[i] = '\0';
		}
		for(i = 0;i < 16;i++) {
 			start->ip[i] = '\0';
			current->ip[i] = '\0';
		}

  		strncpy(start->user_id, user_id, strlen(user_id) );
  		strncpy(start->ip, ip, strlen(ip) );
  		start->next = current;
  		current->next = NULL;

  		
		fprintf(stdout, "%s   ", start->user_id);
		fprintf( stdout, "Start Linked List\n");
  
  	return(1);
}

/*Insertion*/
int insert(char *user_id, char *ip)
{

  		if( (current->next = (USERCONN *)malloc(sizeof(USERCONN))) == NULL) {
    		fprintf( stderr, "Memory Allocation error.\n" );
    	exit(1);
  }

  		strncpy(current->user_id, user_id, strlen(user_id));
  		strncpy(current->ip, ip, strlen(ip));
  		current = current->next;
  		current->next = NULL;

  	return(1);
}

/*Travel*/
int travel()
{
  	USERCONN *tra;
  	int link = 0;

  		tra = start;
  		while(tra->next != NULL)
  		{
    		printf("%d  User ID : %s\n", link, tra->user_id);
    		printf("   IP Address : %s\n\n", tra->ip);
    		tra = tra->next;
    		link++;
  		}
  	return(0);
}

/*Delete*/
int delete(char *user_id)
{
	USERCONN *before_item, *item;
  	int see = 0;

  		//find
  		item = start;
		//printf("Itemp user_id %s\n",item->user_id);
		
  		while(item->next != NULL)
  		{
    		if(strncmp(item->user_id, user_id, FIX_USER_ID) == 0)
			{
				printf("             ");
				printf("loop Item : %d, Delete user_id:%s in Memory\n", see , item->user_id);
      			break;
			}
    		before_item = item;
    		item = item->next;
			see++;
  		}
 		if(item->next == NULL && see != 1)
  		{
			printf("             ");
			printf("User ID %s not math\n", user_id);
    		return(0);
  		}
  		else if(strncmp(item->user_id, start->user_id, FIX_USER_ID) == 0)
  		{
    		start = start->next;
    		free(item);
			printf("             ");
			printf("Delete frist node of Liked List\n");
			if(start->next == NULL) {
				printf("             ");
				printf("NULL Linked list\n");
			}
  		}
  		else if(strncmp(item->user_id, current->user_id, FIX_USER_ID))
  		{
    		current = before_item;
    		current->next = NULL;
    		free(item);
			printf("             ");
			printf("Delete last node of Liked List\n");
  		}
  		else
  		{
    		before_item->next = item->next;
    		free(item);
  		}
  	return(1);
}


/*Find*/
int find(char *user_id, char *ip)
{
	USERCONN *before_item, *item;

  		item = start;
		//printf("Itemp user_id %s\n",item->user_id);
		
  		while(item->next != NULL)
  		{
    		if(strncmp(item->user_id, user_id, FIX_USER_ID) == 0)
			{
				fprintf(stdout, "             Find OK IP = %s\n", item->ip);
				strncpy(ip, item->ip, FIX_IP);
				return 1;
			}
    		before_item = item;
    		item = item->next;
  		}
 		if(item->next == NULL)
  		{
			fprintf(stdout, "             Find not found of user_id %s\n", user_id);
    		return(0);
  		}
}

#endif
