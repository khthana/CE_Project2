#ifndef HEADER_SERVICES_H
#define HEADER_SERVICES_H 

#include "support_services.h"
//#include "comman.h"
//#include "rw_ran.h"


/*
	Register Service********************************************************
*/
void new_user(SSL *ssl, unsigned char *buffer_read, char *ip_client, char user_id[])
{
    unsigned char buffer[MAX_MESSAGE];
    int i;
    int check_infor = 1;
    int check_db = 1;
	int check;

    char query[MAX_MESSAGE];
    int check_query = 0;

    int point = 0;
    char frist_name[64];
    char last_name[64];
    char temp[64];
	unsigned char nick_name[64];
	char temp2[64];
    char sex[1];
    char age[3];
    char email[64];
   
		if(buffer_read[5] == 0x10)
    	{		
						
			check = check_db3("SELECT USER_ID FROM user WHERE USER_ID = ", user_id, "Register");
				if(check != 1) {
					fprintf(stdout, "             Can't register \n");
					write_err_message(ssl, 0x00, "Can't register");
					goto end_new;
				}
				
			/*Send ACK_request_register*/
        	/*channel=0x01, sequence=0x0001, length=x0007, command=0x11, flag=0xff */
        	/*Set header*/
        	buffer[0] = 0x01;
        	buffer[1] = 0x00;
        	buffer[2] = 0x01;
        	buffer[3] = 0x00;
       	 	buffer[4] = 0x07;
       		buffer[5] = 0x11;
        	buffer[6] = 0xff;

        	ssl_write(ssl, buffer, sizeof(buffer));        
    	}
    	else
    	{
			fprintf(stdout, "%s   ", user_id);
        	fprintf(stdout, "Command register incurrect \n");
			write_err_message(ssl, 0x10, "Command register incurrect");
        	goto end_new;
   	 	}
		
    	/*Read information from new user*/
    	ssl_read(ssl, buffer, sizeof(buffer));
    
    	if( (buffer[0] == 0x01) && (buffer[5] == 0x12) )
    	{
        	/*
         Get information from user and check valid of information
       */
        	/*Get frist_name*/
            	point = FIX_HEADER + 1;
            	point = get_data(buffer, frist_name, point);
            	if(!point) {
                	write_err_message(ssl, 0x02, "FRIST NAME INVALID");
					fprintf(stdout, "             FRIST NAME INVALID\n");
					goto end_new;
				}
            	else {
                	if(!check_name(frist_name)) {
                    	write_err_message(ssl, 0x06, "Frist Name INVALID :Insert valid Frist Name and registor again");
                    	fprintf(stdout, "             Frist Name Invalid\n");
						goto end_new;
               		}
            	}
				
			/*Get last_name*/
            	point = get_data(buffer, last_name, point);
            	if(!point) {
                	write_err_message(ssl, 0x03, "LAST NAME INVALID");
            		fprintf(stdout, "             Last NAME INVALID\n");
					goto end_new;
            	}
				else {
                	if(!check_name(last_name)) {
                    	write_err_message(ssl, 0x03, "Last Name INVALID :Insert valid Sex and registor again");
                    	fprintf(stdout, "             Last Name Invalid\n");
						goto end_new;
               		}
            	}
				
			/*Get nick_name*/
				//fprintf(stdout, "Point %d\n", point);
            	point = get_data(buffer, nick_name, point);
            	//fprintf(stdout, "Point %d\n", point);
				if(!point) {
                	write_err_message(ssl, 0x03, "NICK NAME INVALID");
            		fprintf(stdout, "             NICK NAME INVALID\n");
					goto end_new;
            	}
				//fprintf(stdout, "NICK NAME %s\n", nick_name);
				
        	/*Get sex*/
            	point = get_data(buffer, sex, point);
            	if(!point) {
                	write_err_message(ssl, 0x03, "Sex INVALID");
 					fprintf(stdout, "             Sex INVALID\n");
					goto end_new;
            	}           	
				else {
                	if(!check_sex(sex)) {
                    	write_err_message(ssl, 0x03, "Sex INVALID :Insert valid Sex and registor again");
                    	fprintf(stdout, "             Sex Invalid\n");
						goto end_new;
               		}
            	}
           
        	/*Get age*/
            	point = get_data(buffer, age, point);
            	if(!point) {
                	write_err_message(ssl, 0x03, "Age INVALID");
					fprintf(stdout, "             Age INVALID\n");
					goto end_new;
            	}
				else {
                	if(!check_age(age)) {
                    	write_err_message(ssl, 0x03, "Age INVALID :Insert valid Age and registor again");
                    	fprintf(stdout, "             Age Invalid\n");
						goto end_new;
               		}
            	}
         
        	/*Get email*/
            	point = get_data(buffer, email, point);
            	if(!point) {
                	write_err_message(ssl, 0x06, "EMAIL INVALID :Insert valid email and register again");
                	fprintf(stdout, "             EMAIL INVALID\n");
					goto end_new;
            	}
            	else {
               		/*Check email*/
                	if(!spc_email_isvalid(email)) {
                    	write_err_message(ssl, 0x06, "EMAIL INVALID :Insert valid email and registor again");
                    	fprintf(stdout, "             EMAIL INVALID\n");
						goto end_new;
               		}
            	}	       
    		}	
			else {
				fprintf(stdout, "             Command Send Information Incurrect\n");
				write_err_message(ssl, 0x00, "Command Send Information Incurrect");
				goto end_new;
			}
     
    	/*
      Insert information of user to Database
    */
    	/*Connect to Database*/
        	isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        	if(isagmq_db == NULL)
        	{
				fprintf(stdout, "%s   ", user_id);
            	fprintf(stdout, "Register Connect to Database Error\n");
				write_err_message(ssl, 0x00, "DB System Error");
				goto end_new;
        	}
        
        	/*Query user*/
        	/*Set query*/
        	for(i=0;i < MAX_MESSAGE;i++)
            	query[i] = '\0';
        	strcpy(query, "INSERT INTO user VALUES('");
        	strcat(query, user_id);
        	strcat(query, "', '");
        	strcat(query, frist_name);
        	strcat(query, "', '");
        	strcat(query, last_name);
        	strcat(query, "', '");
			strcat(query, nick_name);
        	strcat(query, "', '");
        	strcat(query, sex);
        	strcat(query, "', '");
        	strcat(query, age);
        	strcat(query, "', '");
        	strcat(query, email);
        	strcat(query, "')");
        	//fprintf(stdout, "Query: %s\n", query);

     		/*Process sql command*/
			check_query = process_query(isagmq_db, query);
		
			/*Disconnect MySQL*/
			do_disconnect(isagmq_db);
     
			if( (check_query != 0) || (check_query == -1) )
     		{
        		fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Insert Information of User error \n");
				write_err_message(ssl, 0x00, "DB System Error");
        		goto end_new;
			}
     		else {
				fprintf(stdout, "%s   ", user_id);
        		fprintf(stdout, "Insert Information of User Correct \n");
			}
	
		/*Send send user_id*/
        /*channel=0x01, sequence=0x0001, length=x0007, command=0x13, flag=0xff */
        /*Set header*/
        	buffer[0] = 0x01;
        	buffer[1] = 0x00;
        	buffer[2] = 0x01;
        	buffer[3] = 0x00;
       	 	buffer[4] = 0x07;
       		buffer[5] = 0x13;
        	buffer[6] = 0xff;
			
			for(i = 0;i < FIX_USER_ID;i++)	{
					buffer[i+1 + FIX_HEADER] = user_id[i];
					buffer[i+2 + FIX_HEADER] = '$';
			}

        	ssl_write(ssl, buffer, sizeof(buffer));
			
        	//write_err_message(ssl, 0x00,"Registor OK...........");
        	fprintf(stdout, "%s   ", user_id);
			fprintf(stdout, "Register OK\n");
        	fprintf(stdout, "                User_id: %s\n", user_id);
        	fprintf(stdout, "             Frist Name: %s\n", frist_name);
        	fprintf(stdout, "              Last Name: %s\n", last_name);
			fprintf(stdout, "              Nick Name: %s\n", nick_name);
        	fprintf(stdout, "                    Sex: %s\n", sex);
        	fprintf(stdout, "                    Age: %s\n", age);
        	fprintf(stdout, "                  Email: %s\n", email);
    	
end_new:
		
}

/*
	Add Contactlist with Email and User_id Service****************************
*/
int add_contactlist(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	int point = 0;
  	int contact_online = 0;
  	char email_contact[64];
  	char user_id_contact[FIX_USER_ID];
  	char query[MAX_MESSAGE];
  	char ip_contact[FIX_IP];
	char ch;
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	
			if(buffer_read[5] == 0x32)
        	{
               	/*Show Command*/
               	//fprintf(stdout, "Command channel 3 = 0x32 = request_add_con_email\n");

               	/*Send ACK_request_Add_con_email*/
               	/*channel=0x03, sequence=0x0001, length=x0007, command=0x34, flag=0xff */
               	/*Set header*/
               	buffer[0] = 0x03;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x07;
               	buffer[5] = 0x34;
               	buffer[6] = 0xff;
								
            	ssl_write(ssl, buffer, sizeof(buffer));				
			
						
    			/*Read information from add_contactlist*/
    			ssl_read(ssl, buffer, sizeof(buffer));
    		
    			if( (buffer[0] == 0x03) && (buffer[5] == 0x36) )
    			{
        	
				/*
         	Get information from user and check valid of information
       	*/
  				
				/*Get contact email*/
            		point = FIX_HEADER + 1;			
					point = get_data(buffer, email_contact, point);
            		if(!point) {
						//fprintf(stdout, "get data error\n");
                		write_err_message(ssl, 0x30, "EMAIL Contactlist INVALID :Send valid email and add_contactlist again");
                		fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "EMAIL Contactlist INVALID\n");
						goto end_add;
            		}
            		else {
               			/*Check email*/
                		if(!spc_email_isvalid(email_contact)) {
                    		write_err_message(ssl, 0x30, "EMAIL Contactlist INVALID :Send valid email and add_contactlist again");
                    		fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "EMAIL Contactlist INVALID\n");
							goto end_add;
               			}
            		}	   
  
  				/*get user_id_contact*/
					
    			/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Add Connect to Database Error");
            		check_db = 0;
					goto end_add;
        		}

  				/*Query*/
  				/*Select user_id_contact*/
    			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT USER_ID FROM user WHERE EMAIL = '");
     			strncat(query, email_contact, strlen(email_contact));
				strncat(query, "'", 1);
				//fprintf(stdout, "Query  %s\n", query);
			
     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				//fprintf(stdout,"Query = %s\n", query);
       				mysql_query(isagmq_db, query);
       				res_set = mysql_store_result(isagmq_db);

       				row = mysql_fetch_row(res_set);
       				if( row == NULL) {
						write_err_message(ssl, 0x31, "Can't find email Contactlist :Send email and add_contactlist again\n");
         				fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "No. row = null of Email = %s\n", email_contact);
						goto end_add;
					}
			       
       			/*Only one row, one column(user_id)*/
       			/*get user_id_contact, row[0] = fields 1 of row**/
        			for(i = 0;i < 10;i++)
           				user_id_contact[i] = '\0';
         			strncpy(user_id_contact, row[0], FIX_USER_ID);
         			//fprintf(stdout, "user_id_contact:%s\n", user_id_contact);	
				
       				mysql_free_result(res_set);
				}	
     			else if(check_query == 0)
     			{
       				/*Send NACK  No. this email Contactlist*/
					write_err_message(ssl, 0x31, "Can't find email Contactlist :Send email and add_contactlist again\n");
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"No. Result of Email = %s\n", email_contact);
         			goto end_add;
     			}
     			else
     			{
        			/*Send NACK  DB system error*/
					write_err_message(ssl, 0x32, "DB system error :Can't reply add_contactlist service\n");
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error\n");
					goto end_add;
     			}
			
			/*Check user_id_contact in contactlistBD*/
				if(!check_db5("SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ", user_id, " AND CONTACT_ID = ", user_id_contact, "Add_contactlist"))
				{
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout, "Can not add %s\n", user_id_contact);
					for(i = 0;i < MAX_MESSAGE;i++)
						temp[i] = '\0';
					strcpy(temp, "Can't add this email :");
					strcat(temp, email_contact);
					write_err_message(ssl, 0x00, temp);				
					goto end_add;
				}
            
     		/*Record to contactlist*/
       			for(i=0;i < MAX_MESSAGE;i++)
         			query[i] = '\0';
       			strcpy(query, "INSERT INTO contact_list VALUES('");
       			strcat(query, user_id);
       			strcat(query, "', '");
       			strcat(query, user_id_contact);
       			strcat(query, "')");   
       			//fprintf(stdout, "Query: %s\n", query);
			
       			check_query = process_query(isagmq_db, query);
       			if( (check_query != 0) || (check_query == -1) )
       			{
					write_err_message(ssl, 0x32, "DB system error :Add_contactlist again\n");
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout, "Insert Contactlist of User error\n");
         			goto end_add;
       			}
				else {
					fprintf(stdout, "%s   ", user_id);
       				fprintf(stdout, "Insert Contactlist of User Correct\n");
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 
    		
				/*get ip_contact from linked list*/
					/*Check status contact online or not, travel link list*/         	
					contact_online = find(user_id_contact, ip_contact);				
			
				if(contact_online)
				{
				/*Send ACK_Add_complet to user, and ip new contact*, and contact online/
    			/*channel=0x03, sequence=0x0001, length=x0007, command=0x38, flag=0xff */
    			/*Set header*/
      				buffer[0] = 0x03;
      				buffer[1] = 0x00;
      				buffer[2] = 0x01;
      				buffer[3] = 0x00;
      				buffer[5] = 0x38;
      				buffer[6] = 0xff;
				
					/*Send new user_id-ip$ contact to client*/
						for(i = 0;i < MAX_MESSAGE;i++)
							temp[i] = '\0';
						strncpy(temp, user_id_contact, FIX_USER_ID);
						strcat(temp, ip_contact);					
					
						i = 0;
						while(i < (FIX_USER_ID + FIX_IP) )
						{
							if(temp[i] == '\0')
								break;
							buffer[FIX_HEADER + i + 1] = temp[i];
							buffer[FIX_HEADER + i + 2] = '$';
							i++;
						}
					
						ssl_write(ssl, buffer, sizeof(buffer));
				}
				else //contact off line
				{
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout, "Contact list %s off line\n",user_id_contact);
				
					/*Set header*/
      				buffer[0] = 0x03;
      				buffer[1] = 0x00;
      				buffer[2] = 0x01;
      				buffer[3] = 0x00;
      				buffer[5] = 0x3a;
      				buffer[6] = 0xff;
				
					/*Send new user_id$ contact to client*/
						for(i = 0;i < MAX_MESSAGE;i++)
							temp[i] = '\0';
						strncpy(temp, user_id_contact, FIX_USER_ID);				
					
						i = 0;
						while(i < FIX_USER_ID  )
						{
							if(temp[i] == '\0')
								break;
							buffer[FIX_HEADER + i + 1] = temp[i];
							buffer[FIX_HEADER + i + 2] = '$';
							i++;
						}
					
						ssl_write(ssl, buffer, sizeof(buffer));				
				}
			}
			else {
				fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Header Invalid %\n");			
			}			
		}
		else if(buffer_read[5] == 0x31) {
			/*Show Command*/
               	//fprintf(stdout, "Command channel 3 = 0x32 = request_add_con_email\n");

               	/*Send ACK_request_Add_con_email*/
               	/*channel=0x03, sequence=0x0001, length=x0007, command=0x34, flag=0xff */
               	/*Set header*/
               	buffer[0] = 0x03;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x07;
               	buffer[5] = 0x33;
               	buffer[6] = 0xff;
								
            	ssl_write(ssl, buffer, sizeof(buffer));			
						
    			/*Read information from add_contactlist*/
    			ssl_read(ssl, buffer, sizeof(buffer));
    		
    			if( (buffer[0] == 0x03) && (buffer[5] == 0x35) )
    			{
        	
					/*
         		Get information from user and check valid of information
       		*/
  				
					/*get user_id_contact*/
            		for(i = 0;i < 10;i++)
           				user_id_contact[i] = '\0';
					
					point = FIX_HEADER + 1;			
					point = get_data(buffer, user_id_contact, point);
            		if(!point) {
						//fprintf(stdout, "get data error\n");
                		write_err_message(ssl, 0x30, "User_id Contactlist INVALID :Send valid User_id and add_contactlist again");
                		fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "User_id Contactlist INVALID\n");
						goto end_add;
            		}
            		else {
               			/*Check User_id*/
						if( !check_userid(user_id_contact) ) {
							write_err_message(ssl, 0x30, "User_id Contactlist INVALID :Send valid User_id and add_contactlist again");
                			fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "User_id Contactlist INVALID\n");
							goto end_add;
						}                		
            		}	   
					
    				/*Connect to Database*/
        			isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                		                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        			if(isagmq_db == NULL)
        			{
						fprintf(stdout, "%s   ", user_id);
            			fprintf(stdout, "Add Connect to Database Error");
            			check_db = 0;
						goto end_add;
        			}

  					/*Query*/
  					/*Select user_id_contact in DB*/
    				for(i=0;i < MAX_MESSAGE;i++)
       					query[i] = '\0';
     				strcpy(query, "SELECT EMAIL FROM user WHERE USER_ID = '");
     				strncat(query, user_id_contact, strlen(user_id_contact));
					strncat(query, "'", 1);
					//fprintf(stdout, "Query  %s\n", query);
			
     				check_query = process_query(isagmq_db, query);
     				if( check_query == 1)
     				{
       					//fprintf(stdout,"Query = %s\n", query);
       					mysql_query(isagmq_db, query);
       					res_set = mysql_store_result(isagmq_db);

       					row = mysql_fetch_row(res_set);
       					if( row == NULL) {
							write_err_message(ssl, 0x31, "Can't find User_id Contactlist :Send User_id and add_contactlist again\n");
         					fprintf(stdout, "%s   ", user_id);
							fprintf(stdout, "No. row = null of User_id = %s\n", user_id_contact);
							goto end_add;
						}
			       
       					mysql_free_result(res_set);
					}	
     				else if(check_query == 0)
     				{
       					/*Send NACK  No. this email Contactlist*/
						write_err_message(ssl, 0x31, "Can't find User_id Contactlist :Send User_id and add_contactlist again\n");
         				fprintf(stdout, "%s   ", user_id);
						fprintf(stdout,"No. Result of User_id = %s\n", email_contact);
         				goto end_add;
     				}
     				else
     				{
        				/*Send NACK  DB system error*/
						write_err_message(ssl, 0x32, "DB system error :Can't reply add_contactlist service\n");
         				fprintf(stdout, "%s   ", user_id);
						fprintf(stdout,"DB system error\n");
						goto end_add;
     				}
			
					/*Check user_id_contact in contactlistBD*/
					if(!check_db5("SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ", user_id, " AND CONTACT_ID = ", user_id_contact, "Add_contactlist"))
					{
						fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "Can not add %s\n", user_id_contact);
						for(i = 0;i < MAX_MESSAGE;i++)
							temp[i] = '\0';
						strcpy(temp, "Can't add this email :");
						strcat(temp, email_contact);
						write_err_message(ssl, 0x00, temp);				
						goto end_add;
					}
            
     			/*Record to contactlist*/
       				for(i=0;i < MAX_MESSAGE;i++)
         				query[i] = '\0';
       				strcpy(query, "INSERT INTO contact_list VALUES('");
       				strcat(query, user_id);
       				strcat(query, "', '");
       				strcat(query, user_id_contact);
       				strcat(query, "')");   
       				//fprintf(stdout, "Query: %s\n", query);
			
       				check_query = process_query(isagmq_db, query);
       				if( (check_query != 0) || (check_query == -1) )
       				{
						write_err_message(ssl, 0x32, "DB system error :Add_contactlist again\n");
         				fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "Insert Contactlist of User error\n");
         				goto end_add;
       				}
					else {
						fprintf(stdout, "%s   ", user_id);
       					fprintf(stdout, "Insert Contactlist of User Correct\n");
					}
				
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
    		
					/*get ip_contact from linked list*/
						/*Check status contact online or not, travel link list*/         	
						contact_online = find(user_id_contact, ip_contact);				
			
					if(contact_online)
					{
					/*Send ACK_Add_complet to user, and ip new contact*, and contact online/
    				/*channel=0x03, sequence=0x0001, length=x0007, command=0x38, flag=0xff */
    				/*Set header*/
      					buffer[0] = 0x03;
      					buffer[1] = 0x00;
      					buffer[2] = 0x01;
      					buffer[3] = 0x00;
      					buffer[5] = 0x37;
      					buffer[6] = 0xff;
				
						/*Send new user_id-ip$ contact to client*/
							for(i = 0;i < MAX_MESSAGE;i++)
								temp[i] = '\0';
							strncpy(temp, user_id_contact, FIX_USER_ID);
							strcat(temp, ip_contact);					
					
							i = 0;
							while(i < (FIX_USER_ID + FIX_IP) )
							{
								if(temp[i] == '\0')
									break;
								buffer[FIX_HEADER + i + 1] = temp[i];
								buffer[FIX_HEADER + i + 2] = '$';
								i++;
							}
					
							ssl_write(ssl, buffer, sizeof(buffer));
					}
					else //contact off line
					{
						fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "Contact list %s off line\n",user_id_contact);
				
						/*Set header*/
      					buffer[0] = 0x03;
      					buffer[1] = 0x00;
      					buffer[2] = 0x01;
      					buffer[3] = 0x00;
      					buffer[5] = 0x39;
      					buffer[6] = 0xff;
				
					/*Send new user_id$ contact to client*/
						for(i = 0;i < MAX_MESSAGE;i++)
							temp[i] = '\0';
						strncpy(temp, user_id_contact, FIX_USER_ID);				
					
						i = 0;
						while(i < FIX_USER_ID  )
						{
							if(temp[i] == '\0')
								break;
							buffer[FIX_HEADER + i + 1] = temp[i];
							buffer[FIX_HEADER + i + 2] = '$';
							i++;
						}
					
						ssl_write(ssl, buffer, sizeof(buffer));				
					}
			}
			else {
				fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Header Invalid %\n");			
			}			
		}
    	else {
			fprintf(stdout, "%s   ", user_id);           
        	fprintf(stdout, "Command add incorrect\n");
   	 	}		
  
end_add:
			
     return 1;
}


/*
	Login Service**********************************************************
*/
void add_nick_name(char user_id_contact[], char contact_list[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	
	char query[MAX_MESSAGE];
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	
		/*Find nick_name from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT NICK_NAME FROM user WHERE USER_ID = ");
     			strncat(query, user_id_contact, FIX_USER_ID);
     			
     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{					
					mysql_query(isagmq_db, query);
      				res_set = mysql_store_result(isagmq_db);
       				row = mysql_fetch_row(res_set);
         			if( row[0] != NULL) {
             			/*get Nick$ contact*/
						strncat(contact_list, "#", 1);
						strcat(contact_list, row[0]);					
					}
					else {
						strncat(contact_list, "#N/A", 4);
					}
					mysql_free_result(res_set);
				}
				else if ( check_query == 0)
     			{
       				strncat(contact_list, "#N/A", 4);
         			fprintf(stdout,"            Add Nick not this userID = %s\n", user_id_contact);
     			}
     			else {
					strncat(contact_list, "#N/A$", 5);
					fprintf(stdout,"            Add Nick DB system error\n", user_id_contact);
				}
				
end_add_nick:
}

int add_ip(char user_id_contact[],char contact_list[])
{
	int i;
	int contact_online;
	char ip_contact[FIX_IP];
	
		/*get ip_contact from linked list*/
			/*Check status contact online or not, travel link list*/         	
			for(i = 0;i < FIX_IP;i++)
						ip_contact[i] = '\0';
			contact_online = find(user_id_contact, ip_contact);	
			
			if(contact_online)
			{
				/*get ip$ contact*/
					strncat(contact_list, "#", 1);
					strcat(contact_list, ip_contact);	
					strncat(contact_list, "$", 1);
				return 1;				
			}
			else {
				strncat(contact_list, "#F$", 3);
				//fprintf(stdout, "Contact list %s offline\n",user_id_contact);
				return 0;
			}
}

void login(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	char	contact_list[MAX_MESSAGE];
	char	temp_contact_list[MAX_MESSAGE];
  	char query[MAX_MESSAGE];
	unsigned int i;
  	int check_query;
	int check_db = 1;
	int num_package = 1;
	unsigned int sequence;	
	unsigned char seq[2];
	unsigned char len[2];
	int length = 0;
	int temp_length = 0;
	
    	/*Ack, if commamd = request_login = 0x21 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x21)
             {
             	/*Show Command*/
               	//fprintf(stdout, "Command channel 2 = 0x21 = request_login\n");

               	/*Send ACK_request_login*/
               	/*channel=0x02, sequence=0x0001, length=x0007, command=0x22, flag=0xff */
               	/*Set header*/
               	buffer[0] = 0x02;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x00;
               	buffer[5] = 0x22;
               	buffer[6] = 0xff;
               	
				ssl_write(ssl, buffer, sizeof(buffer));
				
			}
    		else
    		{
				fprintf(stdout, "%s   ", user_id);
        		fprintf(stdout, "Command login incorrect\n");
        		goto end_login;
   	 		}
			
			/*Read request contactlist*/
    		ssl_read(ssl, buffer, sizeof(buffer));
    		
    		if( (buffer[0] == 0x02) && (buffer[5] == 0x23) )
    		{
				
				sequence = random_sequence(65535, 1234);				
				
				/*find contactlist*/
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Login Connect to Database Error");
            		check_db = 0;
					goto end_login;
        		}
				
				//fprintf(stdout, "%s Login \n", user_id);
				
				/*Find contractlist from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ");
     			strncat(query, user_id, FIX_USER_ID);
     			//fprintf(stdout, "Query: %s\n", query);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				for(i = 0;i < MAX_MESSAGE;i++) {
         				contact_list[i] = '\0';
						temp_contact_list[i] = '\0';
					}

       				mysql_query(isagmq_db, query);
      				res_set = mysql_store_result(isagmq_db);
       				while( (row = mysql_fetch_row(res_set)) != NULL )
       				{
         				for (i = 0; i < mysql_num_fields(res_set); i++)
         				{
							/*should you check MAX contact_list buffer*/
           					if( row[i] != NULL) {
													
             					strcpy(temp_contact_list, row[i]);
								//fprintf(stdout, "%s   ", user_id);
								add_nick_name(row[i], temp_contact_list);
								add_ip(row[i], temp_contact_list);
									
								length += strlen(temp_contact_list);
								temp_length = length;
								//fprintf(stdout, "Length = %d\n", length);
								if(length < MAX_MESSAGE - 8) {
									strcat(contact_list, temp_contact_list);		
								}
								else {
									fprintf(stdout, "             More Package\n");
									num_package += 1;
									sequence += 1;
									
									
									convert_sequence(sequence, seq);
									//fprintf(stdout, "Seq[0]=%x  Seq[1]=%x\n", seq[0], seq[1]);
									convert_sequence(temp_length + 7, len);
									//fprintf(stdout, "Len[0]=%x  Len[1]=%x\n", len[0], len[1]);
									/*More package*/
									/*send contactlist*/
									/*Set header*/
      								buffer[0] = 0x02;
      								buffer[1] = seq[0];
      								buffer[2] = seq[1];
      								buffer[3] = len[0];
									buffer[4] = len[1];
      								buffer[5] = 0x24;
      								buffer[6] = 0x01;				/*More of package*/
									
									strncat(contact_list, "$", 1);	
									//fprintf(stdout, "%s   ", user_id);
									//fprintf (stdout, "Contact list = %s\n", contact_list);
									
									i = 0;
									while(i < MAX_MESSAGE  )
									{
										if(contact_list[i] == '\0')
											break;
										buffer[FIX_HEADER + i + 1] = contact_list[i];
										i++;
									}			
									
									ssl_write(ssl, buffer, sizeof(buffer));
									
									
									for(i = 0;i < MAX_MESSAGE;i++) {
										buffer[i] = '\0';
         								contact_list[i] = '\0';
									}
									
								    strcpy(contact_list, temp_contact_list);
									
									for(i = 0;i < MAX_MESSAGE;i++) {
										temp_contact_list[i] = '\0';
									}
									
									temp_length = strlen(contact_list);
									
									length = 0;
								}
																
           					}
           					//printf ("%s", row[i] != NULL ? row[i] : "NULL");
         				}						
       				}	
					strncat(contact_list, "$", 1);					
					
					//fprintf(stdout, "%s   ", user_id);
					//fprintf (stdout, "Contact list = %s\n", contact_list);
       			
       			mysql_free_result(res_set);
    			}
     			else if ( check_query == 0)
     			{
       				//Send NACK  No. this userID
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"No. this userID = %s\n", user_id);
         			/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
					goto end_login;
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error\n", user_id);
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_login;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 
				
				convert_sequence(sequence, seq);
				//fprintf(stdout, "Seq[0]=%x  Seq[1]=%x\n", seq[0], seq[1]);
				convert_sequence(temp_length + 7, len);
				//fprintf(stdout, "Len[0]=%x  Len[1]=%x\n", len[0], len[1]);
				
				/*Frist or End Package*/
				/*Send contact list to client*/
					/*Set header*/
      				buffer[0] = 0x02;
      				buffer[1] = seq[0];
      				buffer[2] = seq[1];
      				buffer[3] = len[0];
					buffer[4] = len[1];
      				buffer[5] = 0x24;
      				buffer[6] = 0x00;				/*End of package*/
				
					i = 0;
					while(i < MAX_MESSAGE  )
					{
						if(contact_list[i] == '\0')
							break;
						buffer[FIX_HEADER + i + 1] = contact_list[i];
						i++;
					}					
					ssl_write(ssl, buffer, sizeof(buffer));					
			}
			else {
				fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Login Command error\n");
			}
            
end_login:
			 
}

/*
	Status Update Service********************************************************
*/
void status(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	char	contact_list[MAX_MESSAGE];
  	char	temp_contact_list[MAX_MESSAGE];
  	char query[MAX_MESSAGE];
  	unsigned char seq[2];
	unsigned char len[2];
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	int num_package = 1;
	unsigned int sequence;	
	int length = 0;
	int temp_length = 0;
	
	
    	/*Ack, if commamd = request_status = 0x51 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x51)
             {
             	/*Show Command*/
               	//fprintf(stdout, "Command channel 5 = 0x51 = request_status\n");

               	
				/*find contactlist*/
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Status Connect to Database Error");
            		check_db = 0;
					goto end_status;
        		}
				
				//fprintf(stdout, "%s status \n", user_id);
				
				/*Find contractlist from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ");
     			strncat(query, user_id, FIX_USER_ID);
     			//fprintf(stdout, "Query: %s\n", query);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				for(i = 0;i < MAX_MESSAGE;i++)
         				contact_list[i] = '\0';
					
					/*Random Sequence of package*/
					sequence = random_sequence(65535, 1234);

       				mysql_query(isagmq_db, query);
      				res_set = mysql_store_result(isagmq_db);
       				while( (row = mysql_fetch_row(res_set)) != NULL )
       				{
         				for (i = 0; i < mysql_num_fields(res_set); i++)
         				{
							/*should you check MAX contact_list buffer*/
           					if( row[i] != NULL) {
													
             					strcpy(temp_contact_list, row[i]);
								//fprintf(stdout, "%s   ", user_id);
								add_nick_name(row[i], temp_contact_list);
								add_ip(row[i], temp_contact_list);
									
								length += strlen(temp_contact_list);
								temp_length = length;
								//fprintf(stdout, "Length = %d\n", length);
								if(length < MAX_MESSAGE - 8) {
									strcat(contact_list, temp_contact_list);		
								}
								else {
									fprintf(stdout, "             More Package\n");
									num_package += 1;
									sequence += 1;
									
									
									convert_sequence(sequence, seq);
									//fprintf(stdout, "Seq[0]=%x  Seq[1]=%x\n", seq[0], seq[1]);
									convert_sequence(temp_length + 7, len);
									//fprintf(stdout, "Len[0]=%x  Len[1]=%x\n", len[0], len[1]);
									/*More package*/
									/*send contactlist*/
									/*Set header*/
      								buffer[0] = 0x05;
      								buffer[1] = seq[0];
      								buffer[2] = seq[1];
      								buffer[3] = len[0];
									buffer[4] = len[1];
      								buffer[5] = 0x52;
      								buffer[6] = 0x01;				/*More of package*/
									
									strncat(contact_list, "$", 1);	
									//fprintf(stdout, "%s   ", user_id);
									//fprintf (stdout, "Contact list = %s\n", contact_list);
									
									i = 0;
									while(i < MAX_MESSAGE  )
									{
										if(contact_list[i] == '\0')
											break;
										buffer[FIX_HEADER + i + 1] = contact_list[i];
										i++;
									}			
									
									ssl_write(ssl, buffer, sizeof(buffer));
									
									
									for(i = 0;i < MAX_MESSAGE;i++) {
										buffer[i] = '\0';
         								contact_list[i] = '\0';
									}
									
								    strcpy(contact_list, temp_contact_list);
									
									for(i = 0;i < MAX_MESSAGE;i++) {
										temp_contact_list[i] = '\0';
									}
									
									temp_length = strlen(contact_list);
									
									length = 0;
								}
																
           					}
           					//printf ("%s", row[i] != NULL ? row[i] : "NULL");
         				}	
       				}
					
       			mysql_free_result(res_set);
    			}
     			else if ( check_query == 0)
     			{
       				//Send NACK  No. this userID
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"No. this userID = %s\n", user_id);
         			/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
					goto end_status;
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error %s\n", user_id);
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_status;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 				 
				
				convert_sequence(sequence, seq);
				//fprintf(stdout, "Seq[0]=%x  Seq[1]=%x\n", seq[0], seq[1]);
				convert_sequence(temp_length + 7, len);
				//fprintf(stdout, "Len[0]=%x  Len[1]=%x\n", len[0], len[1]);				
				
				/*Send response_status*/
               	/*channel=0x05, sequence=0x0001, length=x0007, command=0x52, flag=0xff */
               	/*Set header*/
				 for(i=0;i < MAX_MESSAGE;i++)
       				buffer[i] = '\0';
				 
               	buffer[0] = 0x05;
               	buffer[1] = seq[0];
      			buffer[2] = seq[1];
      			buffer[3] = len[0];
				buffer[4] = len[1];
               	buffer[5] = 0x52;
               	buffer[6] = 0x00;   			
				
				i = 0;
				while(i < MAX_MESSAGE  )
				{
					if(contact_list[i] == '\0')
						break;
					buffer[FIX_HEADER + i + 1] = contact_list[i];
					i++;
				}				
				
				ssl_write(ssl, buffer, sizeof(buffer));				
		}
    	else {
			fprintf(stdout, "%s   ", user_id);
    		fprintf(stdout, "Command status incorrect\n");
		}
            
end_status:
			 
}

/*
	change_nick_name Service****************************************************
*/
void change_nick_name(SSL *ssl, unsigned char *buffer_read, char user_id[])
{  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	unsigned char nick_name[255];	
	unsigned char onick_name[255];
	
  	char query[MAX_MESSAGE];
  	unsigned int i;
  	int check_query;
		
	
		/*Ack, if commamd = request_Nick_name = 0x51 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x41)
             {
             	/*Get new nick_name*/
				 for(i=0;i < 255;i++)
       				nick_name[i] = '\0';
				if(get_data(buffer_read, nick_name, 7) == 0 )
						goto end_change;					
				 
				/*change nick_name*/
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Change Connect to Database Error");
            		goto end_change;
        		}
				
				//fprintf(stdout, "%s status \n", user_id);
				
				/*Find contractlist from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "UPDATE user SET NICK_NAME = ");
     			strncat(query, "'", 1);
				strcat(query, nick_name);
				strncat(query, "'", 1);
				strcat(query, " WHERE USER_ID = ");
				strncat(query, user_id, FIX_USER_ID);
     			//fprintf(stdout, "Query: %s\n", query);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1 || check_query == 0)
     			{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Change Nick Name OK...\n");
					
					for(i=0;i < MAX_MESSAGE;i++) {
       					buffer[i] = '\0';
						temp[i] = '\0';
					}
				 
               		buffer[0] = 0x04;
               		buffer[1] = 0x00;
               		buffer[2] = 0x01;
               		buffer[3] = 0x00;
               		buffer[4] = 0x07;
               		buffer[5] = 0x42;
               		buffer[6] = 0xff;
					
					strcpy(temp, "Change Nick Name OK...$");
					
					for(i=0;i < 255;i++) {
           				buffer[i+7] =  temp[i];
        			}
					
					ssl_write(ssl, buffer, sizeof(buffer));
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error %s\n", user_id);
					write_err_message(ssl, 0x42, "Can't change nick_name, DB error\n");
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_change;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 				 
							
		}
    	else {
			fprintf(stdout, "%s   ", user_id);
    		fprintf(stdout, "Command change nick_name incorrect\n");
			write_err_message(ssl, 0x42, "Command change nick_name incorrect\n");
		}

end_change:	
}

/*
	delete_admin Service****************************************************
*/
void delete_admin(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	unsigned char query[MAX_MESSAGE];
	unsigned char query_2[MAX_MESSAGE];
  	unsigned int i;
  	int check_query;
	int check_query_2;
		
	
		/*Ack, if commamd = request_Nick_name = 0x51 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x0a1)
             {
             	 
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Delete Admin Connect to Database Error");
            		goto delete_admin;
        		}
				
				/*Find contractlist from DB*/
     			for(i = 0;i < MAX_MESSAGE;i++) {
       				query[i] = '\0';
					query_2[i] = '\0';
				}
				/*query 1*/
     			strcpy(query, "DELETE FROM user WHERE USER_ID = ");
     			strncat(query, user_id, FIX_USER_ID);
     			fprintf(stdout, "Query: %s\n", query);
				/*query 2*/
				strcpy(query_2, "DELETE FROM contact_list WHERE USER_ID = ");
     			strncat(query_2, user_id, FIX_USER_ID);
				fprintf(stdout, "Query: %s\n", query_2);

     			check_query = process_query(isagmq_db, query);
     			check_query_2 = process_query(isagmq_db, query_2);
				if( (check_query == 1 || check_query == 0) && (check_query_2 == 1 || check_query_2 == 0) )
     			{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Delete Admin OK...\n");
					
					for(i=0;i < MAX_MESSAGE;i++) {
       					temp[i] = '\0';
						buffer[i] = '\0';
					}
				 
               		buffer[0] = 0x0a;
               		buffer[1] = 0x00;
               		buffer[2] = 0x01;
               		buffer[3] = 0x00;
               		buffer[4] = 0x07;
               		buffer[5] = 0xa2;
               		buffer[6] = 0xff;
					
					strcpy(temp, "Delete admin OK...$");
					
					for(i=0;i < 255;i++) {
           				buffer[i+7] =  temp[i];
        			}
					
					ssl_write(ssl, buffer, sizeof(buffer));
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error %s\n", user_id);
					write_err_message(ssl, 0xa3, "Can't delete admin, DB error\n");
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto delete_admin;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 				 
							
		}
    	else {
			fprintf(stdout, "%s   ", user_id);
    		fprintf(stdout, "Command delete admin incorrect\n");
			write_err_message(ssl, 0xa3, "Command delete admin incorrect\n");
		}

delete_admin:	
}

/*
	delete_contactlist Service**************************************************
*/
void delete_contactlist(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	unsigned char query[MAX_MESSAGE];
	unsigned int i;
	unsigned char contact_id[10];
  	int check_query;	
	
		/*Ack, if commamd = request_Delete contactlist = 0xb1 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x0b1)
             {
             	/*Get contact_id*/	
				for(i=0;i <= 10;i++)
       				contact_id[i] = '\0';
				if(get_data(buffer_read, contact_id, 7) == 0 ) {
					write_err_message(ssl, 0xb3, "User_id that you would like to delete incorrect\n");
					goto end_delete_contactlist;					
				}					
				 
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Delete Contactlist Connect to Database Error");
            		goto end_delete_contactlist;
        		}
				
				/*Find contractlist from DB*/
     			for(i = 0;i < MAX_MESSAGE;i++) {
       				query[i] = '\0';
				}
				/*query check contac_id*/
				/*!check_db5 becuase ,has OK*/
				if(!check_db5("SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ", user_id, " AND CONTACT_ID = ", contact_id, "Delete contact"))
				{
     				strcpy(query, "DELETE FROM contact_list WHERE CONTACT_ID = ");
     			    strncat(query, contact_id, FIX_USER_ID);
					strcat(query," AND USER_ID =");
     				strncat(query, user_id, FIX_USER_ID);
					fprintf(stdout, "Query: %s\n", query);
					
					check_query = process_query(isagmq_db, query);
					if(check_query < 0) {
						fprintf(stdout, "Delete Contactlist Error\n");
						do_disconnect(isagmq_db); 
       					goto end_delete_contactlist;
					}
					
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Delete Contactlist OK...\n");
					
					for(i=0;i < MAX_MESSAGE;i++) {
       					temp[i] = '\0';
						buffer[i] = '\0';
					}
				 
               		buffer[0] = 0x0b;
               		buffer[1] = 0x00;
               		buffer[2] = 0x01;
               		buffer[3] = 0x00;
               		buffer[4] = 0x07;
               		buffer[5] = 0xb2;
               		buffer[6] = 0xff;
					
					strcpy(temp, "Delete contactlist OK...$");
					
					for(i=0;i < 255;i++) {
           				buffer[i+7] =  temp[i];
        			}
					
					ssl_write(ssl, buffer, sizeof(buffer));
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error %s\n", user_id);
					write_err_message(ssl, 0xb3, "Can't delete admin, DB error\n");
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_delete_contactlist;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 				 
							
		}
    	else {
			fprintf(stdout, "%s   ", user_id);
    		fprintf(stdout, "Command delete admin incorrect\n");
			write_err_message(ssl, 0xa3, "Command delete admin incorrect\n");
		}
end_delete_contactlist:
}

/*
	Find Contact_list**********************************************************
	Channel 0x08
*/
void find_contactlist(SSL *ssl, unsigned char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	unsigned char find_infor[MAX_MESSAGE];
	unsigned char temp_ip[FIX_IP];
	
  	unsigned char query[MAX_MESSAGE];
	unsigned int i;
	int check_query;
	int point = 0;
	unsigned char fuser_id[9];
	unsigned char femail[64];
	unsigned char ffrist_name[64];
	unsigned char flast_name[64];
	unsigned char ftype[1];
	unsigned char fage[3];
	unsigned int sequence;	
	unsigned char seq[2];
	unsigned char len[2];
	int length = 0;
	int temp_length = 0;
	int check_infor = 0;
	int cuser = 0;
	int cemail = 0;
	int cfrist = 0;
	int clast = 0;
	int found = 1;
	int num_package = 0;
	
		/*Ack, if commamd = request_find contactlist = 0x81 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x81)
             {
				 sequence = random_sequence(65535, 1234);
				 
				 for(i=0;i < MAX_MESSAGE;i++) {
       					temp[i] = '\0';
						buffer[i] = '\0';
					 	find_infor[i] = '\0';
					}
				 
               		buffer[0] = 0x08;
               		buffer[1] = 0x00;
               		buffer[2] = 0x01;
               		buffer[3] = 0x00;
               		buffer[4] = 0x07;
               		buffer[5] = 0x82;
               		buffer[6] = 0xff;
					
					strcpy(temp, "Wait Find.......");
					
					for(i=0;i < 255;i++) {
           				buffer[i+7] =  temp[i];
        			}
					
					ssl_write(ssl, buffer, sizeof(buffer));
					
					/*Read information from find_contractlist*/
    				ssl_read(ssl, buffer, sizeof(buffer));
					//fprintf(stdout, "Read information from find_contractlist\n");					
					
    				if( (buffer[0] == 0x08) && (buffer[5] == 0x83) )
    				{
						/*
         			Get information from user and check valid of information
       			*/
						
						/*Set query*/
						strcpy(query, "SELECT USER_ID,EMAIL FROM user WHERE ");
						
        				
            			point = FIX_HEADER + 1;
						/*Get type find*/
            			point = get_data(buffer, ftype, point);
            			if(!point) {
							ftype[0] = 'A';
                			fprintf(stdout, "             Type find Invalid,put default = 'A' \n");
						}
						if(ftype[0] == 'a' || ftype[0] == 'A' || ftype[0] == 'o' || ftype[0] == 'O') 
							/*Type OK*/;
						else {
							ftype[0] = 'A';
                			fprintf(stdout, "             Type find Invalid,put default = 'A' \n");
						}
						
						/*Get User_id*/
						point = get_data(buffer, fuser_id, point);
            			if(!point) {
                			fprintf(stdout, "User_id Invalid \n");
							cuser = 1;
						}
						else{
							/*Check User_id*/
							if(check_userid(fuser_id))
							{
								strcat(query, "USER_ID = '");
								strcat(query, fuser_id);
								strcat(query, "'");	
								cuser = 0;								
							}
							else
								cuser = 1;
							check_infor = 1;
						}
						
						/*Get email*/
            			point = get_data(buffer, femail, point);
            			if(!point) {
							fprintf(stdout, "Email Invalid \n");
							cemail = 1;
                		}
						else{
							/*Check email*/
							if( spc_email_isvalid(femail) )
							{
								if(cuser == 0){
									if(ftype[0] == 'a' || ftype[0] == 'A')
										strcat(query, " AND ");
									else
										strcat(query, " OR ");
									strcat(query, "EMAIL = '");
									strcat(query, femail);
									strcat(query, "'");	
									cemail = 0;	
								}
								else {
									strcat(query, "EMAIL = '");
									strcat(query, femail);
									strcat(query, "'");	
									cemail = 0;
								}
							}
							else
								cemail = 1;
							
							check_infor = 1;
						}							
												
						/*Get frist_name*/
            			point = get_data(buffer, ffrist_name, point);
            			if(!point) {
                			fprintf(stdout, "Frist Name Invalid \n");
							cfrist = 1;
						}
						else {
							/*Check frist name*/
							if( check_name(ffrist_name) )
							{
								if(cuser == 0 || cemail == 0 ) {
									if(ftype[0] == 'a' || ftype[0] == 'A')
										strcat(query, " AND ");
									else
										strcat(query, " OR ");
									strcat(query, "FRIST_NAME = '");
									strcat(query, ffrist_name);
									strcat(query, "'");	
									cfrist = 0;	
								}
								else {
									strcat(query, "FRIST_NAME = '");
									strcat(query, ffrist_name);
									strcat(query, "'");	
									cfrist = 0;
								}
							}
							else
								cfrist = 1;
							
							check_infor = 1;
						}	
						
						/*Get last_name*/
            			point = get_data(buffer, flast_name, point);
            			if(!point) {
                			fprintf(stdout, "Last Name Invalid \n");
							clast = 1;
						}
						else {
							/*Check last name*/
							if( check_name(flast_name) )
							{
								if(cuser == 0 || cemail == 0 || cfrist == 0) {
									if(ftype[0] == 'a' || ftype[0] == 'A')
										strcat(query, " AND ");
									else
										strcat(query, " OR ");
									strcat(query, "LAST_NAME = '");
									strcat(query, flast_name);
									strcat(query, "'");	
									clast = 0;	
								}
								else {
									strcat(query, "LAST_NAME = '");
									strcat(query, flast_name);
									strcat(query, "'");	
									clast = 0;
								}
							}
							else
								clast = 1;
							
							check_infor = 1;
						}	
						
						if(check_infor == 0) {
							
							for(i=0;i < MAX_MESSAGE;i++) 
       							buffer[i] = '\0';
					 		
							strcpy(find_infor, "Find Information Invalid");
							
							buffer[0] = 0x08;
      						buffer[1] = 0x00;
      						buffer[2] = 0x01;
      						buffer[3] = 0x00;
							buffer[4] = 0x07;
      						buffer[5] = 0x84;
      						buffer[6] = 0x00;				/*End of package*/
				
							i = 0;
							while(i < MAX_MESSAGE  )
							{
								if(find_infor[i] == '\0')
									break;
								buffer[FIX_HEADER + i + 1] = find_infor[i];
								i++;
							}					
							
							ssl_write(ssl, buffer, sizeof(buffer));							
							
							goto end_find_contactlist;
						}							
						//fprintf(stdout, "%c %s %s %s %s \n", ftype[0], fuser_id, femail, ffrist_name, flast_name);
			 		
						/*Connect to Database*/
        				isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	    		            					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        				if(isagmq_db == NULL)
        				{
							fprintf(stdout, "%s   ", user_id);
            				fprintf(stdout, "Find Contactlist Connect to Database Error");
            				goto end_find_contactlist;
        				}
						
							/*Find user_id from DB*/
     						//fprintf(stdout, "Query: %s\n", query);
							for(i=0;i < MAX_MESSAGE;i++) {
       							temp[i] = '\0';
							}

     						check_query = process_query(isagmq_db, query);
     						mysql_query(isagmq_db, query);
      						res_set = mysql_store_result(isagmq_db);
							while( (row = mysql_fetch_row(res_set)) != NULL )
       						{
       							if( row != NULL) {
									found = 0;
									//fprintf(stdout, "Find user_id OK %s \n", row[0]);
									strcpy(temp, row[0]);
									strncat(temp, "#", 1);
									strcat(temp, row[1]);	
									strncat(temp, "#", 1);
									if(find(fuser_id, temp_ip))
										strncat(temp, "O", 1);
									else
										strncat(temp, "F", 1);
							
									length = strlen(temp);
									temp_length = length;
									if(length < MAX_MESSAGE - 8) {
										strcat(find_infor, temp);		
									}
									else {
										fprintf(stdout, "             More Package\n");
										num_package += 1;
										sequence += 1;									
									
										convert_sequence(sequence, seq);
										convert_sequence(temp_length + 7, len);
									
										/*More package*/
										/*send result*/
										/*Set header*/
      									buffer[0] = 0x08;
      									buffer[1] = seq[0];
      									buffer[2] = seq[1];
      									buffer[3] = len[0];
										buffer[4] = len[1];
      									buffer[5] = 0x84;
      									buffer[6] = 0x01;				/*More of package*/
									
										strncat(find_infor, "$", 1);	
									
										i = 0;
										while(i < MAX_MESSAGE  )
										{
											if(find_infor[i] == '\0')
												break;
											buffer[FIX_HEADER + i + 1] = find_infor[i];
											i++;
										}			
									
										ssl_write(ssl, buffer, sizeof(buffer));
									
									
										for(i = 0;i < MAX_MESSAGE;i++) {
											buffer[i] = '\0';
         									find_infor[i] = '\0';
										}
									
								    	strcpy(find_infor, temp);
									
										for(i = 0;i < MAX_MESSAGE;i++) {
											temp[i] = '\0';
										}
									
										temp_length = strlen(find_infor);
									
										length = 0;
									}									
								}									
								strncat(find_infor, "$", 1);								
							}
							if(row == NULL && found == 1)
								strcpy(find_infor, "Find not found");	
							
							strncat(find_infor, "$", 1);

						/*Free result*/	
						mysql_free_result(res_set);						
							
						/*Disconnect MySQL*/
     					do_disconnect(isagmq_db); 					
				
						convert_sequence(sequence, seq);									
						convert_sequence(temp_length + 7, len);
				
						/*Frist or End Package*/
						/*Reply find information to client*/
						/*Set header*/
								
						for(i = 0;i < MAX_MESSAGE;i++) 
							buffer[i] = '\0';
							
      					buffer[0] = 0x08;
      					buffer[1] = seq[0];
      					buffer[2] = seq[1];
      					buffer[3] = len[0];
						buffer[4] = len[1];
      					buffer[5] = 0x84;
      					buffer[6] = 0x00;				/*End of package*/
				
						i = 0;
						//fprintf(stdout, "find_infor %s \n", find_infor);
						while(i < MAX_MESSAGE  )
						{
							if(find_infor[i] == '\0')
								break;
							buffer[FIX_HEADER + i + 1] = find_infor[i];
							i++;
						}					
						ssl_write(ssl, buffer, sizeof(buffer));
						
					}
					else{
						fprintf(stdout, "%s   ", user_id);
						fprintf(stdout, "Command Send_find_infor error \n");
						goto end_find_contactlist;
					}
				}
				else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout, "Command request find error \n");
					goto end_find_contactlist;
				}
	
end_find_contactlist:
}

#endif
