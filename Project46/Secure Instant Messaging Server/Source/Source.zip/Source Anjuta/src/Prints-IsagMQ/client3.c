#include  <sys/types.h> /* basic system data types */
#include  <sys/socket.h>  /* basic socket definitions */
#include  <sys/time.h>  /* timeval{} for select() */
#include  <time.h>    /* timespec{} for pselect() */
#include  <netinet/in.h>  /* sockaddr_in{} and other Internet defns */
#include  <arpa/inet.h>   /* inet(3) functions */
#include  <errno.h>
#include  <fcntl.h>   /* for nonblocking */
#include  <netdb.h>
//#include  <signal.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <sys/stat.h>  /* for S_xxx file mode constants */
#include  <sys/uio.h>   /* for iovec{} and readv/writev */
#include  <unistd.h>
//#include  <sys/wait.h>
#include  <sys/un.h>    /* for Unix domain sockets */
#include <sys/select.h>  /* for convenience */

#include <string.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>

#include <curses.h>

#ifndef WIN32
#include <pthread.h>
#define THREAD_CC
#define THREAD_TYPE                    pthread_t
#define THREAD_CREATE(tid, entry, arg) pthread_create(&(tid), NULL, \
                                                      (entry), (arg))
#else
#include <windows.h>
#define THREAD_CC                      __cdecl
#define THREAD_TYPE                    DWORD
#define THREAD_CREATE(tid, entry, arg) do { _beginthread((entry), 0, (arg));\
                                            (tid) = GetCurrentThreadId();   \
                                          } while (0)
#endif

#define PORT            			16001
#define SERVER          			"161.246.5.18"
#define MAX_MESSAGE 		512 //per packet
//#define CLIENT          "localhost"
#define FIX_HEADER 			6 //per packet
#define FIX_USER_ID 			9

unsigned char user_id[10] = "N/A";
char lnick_name[255];										  
unsigned char nick_name[255] = "N/A";   
										  
unsigned char contact_list[512];										  
										  
#define int_error(msg)  handle_error(__FILE__, __LINE__, msg)
void handle_error(const char *file, int lineno, const char *msg);

void init_OpenSSL(void);

int verify_callback(int ok, X509_STORE_CTX *store);

void seed_prng(void);

static char *pass;
static int password_cb(char *buf,int num,
  int rwflag,void *userdata);

//**********comman.c*****************************
void handle_error(const char *file, int lineno, const char *msg)
{
    fprintf(stderr, "** %s:%i %s\n", file, lineno, msg);
    ERR_print_errors_fp(stderr);
    exit(-1);
}

void init_OpenSSL(void)
{
    if (!SSL_library_init())
    {
        fprintf(stderr, "** OpenSSL initialization failed!\n");
        exit(-1);
    }

    fprintf(stderr, "** OpenSSL initialization OK!\n");
    SSL_load_error_strings();
}

int verify_callback(int ok, X509_STORE_CTX *store)
{
    char data[256];

    if (!ok)
    {
        X509 *cert = X509_STORE_CTX_get_current_cert(store);
        int  depth = X509_STORE_CTX_get_error_depth(store);
        int  err = X509_STORE_CTX_get_error(store);

        fprintf(stderr, "-Error with certificate at depth: %i\n", depth);
        X509_NAME_oneline(X509_get_issuer_name(cert), data, 256);
        fprintf(stderr, "  issuer   = %s\n", data);
        X509_NAME_oneline(X509_get_subject_name(cert), data, 256);
        fprintf(stderr, "  subject  = %s\n", data);
        fprintf(stderr, "  err %i:%s\n", err, X509_verify_cert_error_string(err));
    }

    return ok;
}

void seed_prng(void)
{
  RAND_load_file("/dev/urandom", 1024);
}

//*******************Client3.c**********************************************
#define CIPHER_LIST "ALL:!ADH:!LOW:!EXP:!MD5:@STRENGTH"
#define CAFILE "ca.pem"
#define CADIR NULL
#define CERTFILE "client.pem"
#define KEYFILE "client.key"
#define PASSWORD "654321"

/*The password code is not thread safe*/
static int password_cb(char *buf,int num,
  int rwflag,void *userdata)
  {
    if(num<strlen(pass)+1)
      return(0);

    strcpy(buf,pass);
    return(strlen(pass));
  }

SSL_CTX *setup_client_ctx(void)
{
    SSL_CTX *ctx;

    ctx = SSL_CTX_new(SSLv23_client_method( ));
    if (SSL_CTX_load_verify_locations(ctx, CAFILE, CADIR) != 1)
        int_error("Error loading CA file and/or directory");
    if (SSL_CTX_set_default_verify_paths(ctx) != 1)
        int_error("Error loading default CA file and/or directory");

    if (SSL_CTX_use_certificate_chain_file(ctx, CERTFILE) != 1)
        int_error("Error loading certificate from file");
    //if (SSL_CTX_use_certificate_file(ctx, CERTFILE, SSL_FILETYPE_PEM) != 1)
    //    int_error("Error loading certificate from file");

    //Set Password
    pass = PASSWORD;
    SSL_CTX_set_default_passwd_cb(ctx,password_cb);    
        
    if (SSL_CTX_use_PrivateKey_file(ctx, KEYFILE, SSL_FILETYPE_PEM) != 1)
        int_error("Error loading private key from file");
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, verify_callback);
    SSL_CTX_set_verify_depth(ctx, 4);
    SSL_CTX_set_options(ctx, SSL_OP_ALL|SSL_OP_NO_SSLv3);
    if (SSL_CTX_set_cipher_list(ctx, CIPHER_LIST) != 1)
        int_error("Error setting cipher list (no valid ciphers)");
    return ctx;
}

int do_client_loop(SSL *ssl)
{
    int  err, nwritten;
    char buf[80];

    for (;;)
    {
        if (!fgets(buf, sizeof(buf), stdin))
            break;
        for (nwritten = 0;  nwritten < sizeof(buf);  nwritten += err)
        {
            err = SSL_write(ssl, buf + nwritten, sizeof(buf) - nwritten);
            if (err <= 0)
                return 0;
        }
    }
    return 1;
}

int
connect_server_TCP()
{
   //TCP Connecting Argument

   int sockfd, i;
   int addr_len;
   struct sockaddr_in address;

   int connect_res;

   sockfd= socket(AF_INET,SOCK_STREAM,0);
   if(sockfd<0) {
   printf("Error creating connection");
   exit(1);
   }

   address.sin_family = AF_INET;
   address.sin_addr.s_addr = inet_addr(SERVER);
   address.sin_port = htons(PORT);
   addr_len = sizeof(address);

   connect_res = connect(sockfd,(struct sockaddr*)&address,addr_len);
   if(connect_res<0)
   {
     perror("Error connecting to remote machine");
     exit(1);
   }

   return sockfd;
}

void disconnect(SSL *ssl, int type)
{
    if (type)
        SSL_shutdown(ssl);
    else
        SSL_clear(ssl);
    fprintf(stderr, "SSL Connection closed\n");
}

void ssl_read(SSL *ssl, char *buf, int length)
{
    int  err;
    //char *buffer = buf;

    err = SSL_read(ssl, buf, length);
    if (err <= 0)
    {   fprintf(stdout,"Error Read\n");
        disconnect(ssl ,0); }
    //else 
    //    disconnect(ssl ,1);    
}

void ssl_write(SSL *ssl, char *buf, int length)
{
    int  err;

    err = SSL_write(ssl, buf, length);
    if (err <= 0)
    {   fprintf(stdout,"Error Write\n");
        disconnect(ssl ,0); }
    //else
    //    disconnect(ssl ,1); 
}

int get_data(char buf[], char data[], int start)
{
    int iptr = 0;
    unsigned char c;

    while(1)
    {
        c = buf[start];
        if(c == '$')
        {
            start++;
            data[iptr] = '\0';
            break;
        }
        else if(c > 0x9b || c == '\0' )
        {   fprintf(stdout, "ERROR No. Data\n");
            break; }

        data[iptr] = c;
        start++;
        iptr++;
    }
    return start;
}

/*
	Status **********************************************************
*/
void status(SSL *ssl)
{
	int i;
  	unsigned char buffer_user[MAX_MESSAGE];
  	unsigned char buffer[MAX_MESSAGE];
	unsigned char more_pack;
	int n = 0;
  	
  		for(i=0;i<=MAX_MESSAGE;i++)
    		buffer_user[i] = '\0';
  		
		/*request_status = 0x51*/
  		/*channel 0x05, sequence 0x0001, length 0x0007, command 0x51, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x05;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0x51;
  		buffer_user[6] = 0xff;
 
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		
		do 
		{			
			/*Receive response status*/
			ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			more_pack = buffer_user[6];	
			
			for(i = 0;i < MAX_MESSAGE;i++)
					buffer[i] = '\0';
		
			if( (buffer_user[0] == 0x05) && (buffer_user[5] == 0x52) )
    		{
				
				i = 0;			
				while(buffer_user[FIX_HEADER +1 +i] != '\0')
				{
					buffer[i] = buffer_user[FIX_HEADER +1 +i];
					++i;
					//fprintf(stdout, "Contact list = %s\n", buffer);
				}	
				
				for(i = 0;i < MAX_MESSAGE;i++)
					buffer_user[i] = '\0';
				
				fprintf(stdout, "Contact_list = %s\n", buffer);
		
				if( n == 0)			
					strcpy(contact_list, buffer);
				else 
					strcat(contact_list, buffer);
				n = 1;
			}
			else {
				fprintf(stdout, "Command Server Error\n");
				goto end_status;
			}
		}while(more_pack == 0x01);	

end_status:
	
}

/*
	Login **********************************************************
*/
void get_user_id_nick_name()
{
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i;
	char c;
	char tmp[MAX_MESSAGE];
	
		for(i = 0;i < MAX_MESSAGE;i++)
			tmp[i] = '\0';			
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "r") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file....");
			goto end_get; 
    	}
		
		i = 0;
		while(i < 3 && c != EOF)
		{
			c = getc(log);
			//fprintf(stderr,"Ch %c", c);
			if( c == ':') {
				i++;
				if(i == 2)
					fgets(nick_name, 255, log);
				else if (i == 3)
					fgets(user_id, 255, log);
			}
		}
		
end_get:
		fclose(log);
}

void login(SSL *ssl)
{
	int nwrite;
  	int i, j, k;
  	char infor[MAX_MESSAGE];
  	unsigned char buffer_user[MAX_MESSAGE];
  	unsigned char buffer[MAX_MESSAGE];
	unsigned char more_pack;
	int n = 0;
  	
  		for(i=0;i<=MAX_MESSAGE;i++)
    		buffer_user[i] = '\0';
  		
		/*request_login = 0x21*/
  		/*channel 0x02, sequence 0x0001, length 0x0007, command 0x21, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x02;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0x21;
  		buffer_user[6] = 0xff;
 
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		/*Receive ACK_response login*/
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
		if( (buffer_user[0] == 0x02) && (buffer_user[5] == 0x22) )
    	{
			
    		/*Send request contactlist*/
			/*channel=0x02, sequence=0x0001, length, command=0x23, flag=0xff */
    		/*Set header*/
    		for(i=0;i<=MAX_MESSAGE;i++)
      			buffer_user[i] = '\0';
   			
			buffer_user[0] = 0x02;
    		buffer_user[1] = 0x00;
    		buffer_user[2] = 0x01;
    		buffer_user[3] = 0x00;
    		buffer_user[4] = 0x18;
    		buffer_user[5] = 0x23;
    		buffer_user[6] = 0xff;
			
			ssl_write(ssl, buffer_user, sizeof(buffer_user));		
		}
		
		do
		{
			/*read contactlist*/
			/*Receive contactlist*/
    		ssl_read(ssl, buffer_user, sizeof(buffer_user));
		
			more_pack = buffer_user[6];
			fprintf(stdout, "more_pack = %x\n", more_pack);
			
			for(i = 0;i < MAX_MESSAGE;i++)
					buffer[i] = '\0';
		
			if( (buffer_user[0] == 0x02) && (buffer_user[5] == 0x24) )
    		{
				i = 0;			
				while(buffer_user[FIX_HEADER +1 +i] != '\0')
				{
					buffer[i] = buffer_user[FIX_HEADER +1 +i];
					++i;
					//fprintf(stdout, "Contact list = %s\n", buffer);
				}	
				
				for(i = 0;i < MAX_MESSAGE;i++)
					buffer_user[i] = '\0';
				
				fprintf(stdout, "Contact list = %s\n", buffer);
			
				if( n == 0)			
					strcpy(contact_list, buffer);
				else 
					strcat(contact_list, buffer);
				n = 1;
			
			}
			else {
				fprintf(stdout, "Command Server Error\n");
				goto end_login;
			}
		}while(more_pack == 0x01 );
		
		/*Show user_id and nick_name at terminal*/
		get_user_id_nick_name();

end_login:
}

int read_connect(SSL *ssl)
{
	char buffer[MAX_MESSAGE];
    char mess[MAX_MESSAGE];
	
	  	ssl_read(ssl, buffer, sizeof(buffer));
    	get_data(buffer, mess, 7);

      	if(buffer[0] == 0x06) {
          	switch(buffer[5]) {
				case 0x00 : fprintf(stdout, "%s\n", mess);
                          			return 1;
		      	default	   :fprintf(stdout, "%s\n", mess);
									return 0;
          	}
      	}
      	else	{
			fprintf(stdout, "Error connect, Connect Again\n");
          	disconnect(ssl ,0);
          	return -1;
      	}
}

/*
	Add Contact_list **********************************************************
*/
void add_contactlist(SSL *ssl, char type)
{
	int i;
  	char mess[MAX_MESSAGE];
  	unsigned char buffer_user[MAX_MESSAGE];
  	
  		for(i=0;i<=MAX_MESSAGE;i++)
    		buffer_user[i] = '\0';
  	
		if(type == 'a')
		{
			/*request_Add_Email = 0x32*/
  			/*channel 0x03, sequence 0x0001, length 0x0007, command 0x32, flag 0xff, data null*/
  			/*Set header*/
  				buffer_user[0] = 0x03;
  				buffer_user[1] = 0x00;
  				buffer_user[2] = 0x01;
  				buffer_user[3] = 0x00;
  				buffer_user[4] = 0x07;
  				buffer_user[5] = 0x32;
  				buffer_user[6] = 0xff;
  	
				ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
				/*Receive ACK_response_add_email*/
    			ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x34) )
    		{
				/*Send send_information*/
        		/*channel=0x03, sequence=0x0001, length, command=0x36, flag=0xff */
        		/*Set header*/
        		for(i=0;i<=MAX_MESSAGE;i++) {
            		buffer_user[i] = '\0';
					mess[i] = '\0';
				}

        		buffer_user[0] = 0x03;
        		buffer_user[1] = 0x00;
        		buffer_user[2] = 0x01;
        		buffer_user[3] = 0x00;
        		buffer_user[4] = 0x01;
        		buffer_user[5] = 0x36;
        		buffer_user[6] = 0xff;
			
				/*Get Contact Email*/
				fprintf(stdout, "Enter Contact Email:");
				scanf("%s", mess);			
        		strcat(mess,"$");
        
				for(i=0;i < 64;i++) {
           			buffer_user[i+7] =  mess[i];
					if(mess[i] == '\0')
						break;
        		}
		
        		ssl_write(ssl, buffer_user, sizeof(buffer_user));
    		}
	
			/*Receive ACK_Infor_add_email*/
				for(i = 0;i < MAX_MESSAGE;i++) {
					buffer_user[i] = '\0';
					mess[i] = '\0';
				}
		
    		ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			get_data(buffer_user, mess, 7);	
		
			/*Reveice new contactlist*/
				if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x38) ) {
					fprintf(stdout, "New email contactlist OK...Online\n");
				}
				else if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x3a) ) {			
					fprintf(stdout, "New email contactlist OK...Offline\n");
				}
				else	
					fprintf(stdout, "%s\n", mess);			
			}
		else if(type == 'u')
		{
			/*request_Add_userID = 0x31*/
  			/*channel 0x03, sequence 0x0001, length 0x0007, command 0x31, flag 0xff, data null*/
  			/*Set header*/
  				buffer_user[0] = 0x03;
  				buffer_user[1] = 0x00;
  				buffer_user[2] = 0x01;
  				buffer_user[3] = 0x00;
  				buffer_user[4] = 0x07;
  				buffer_user[5] = 0x31;
  				buffer_user[6] = 0xff;
  	
				ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
				/*Receive ACK_response_add_User_id*/
    			ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x33) )
    		{
				/*Send send_information*/
        		/*channel=0x03, sequence=0x0001, length, command=0x35, flag=0xff */
        		/*Set header*/
        		for(i=0;i<=MAX_MESSAGE;i++) {
            		buffer_user[i] = '\0';
					mess[i] = '\0';
				}

        		buffer_user[0] = 0x03;
        		buffer_user[1] = 0x00;
        		buffer_user[2] = 0x01;
        		buffer_user[3] = 0x00;
        		buffer_user[4] = 0x01;
        		buffer_user[5] = 0x35;
        		buffer_user[6] = 0xff;
			
				/*Get Contact Email*/
				fprintf(stdout, "Enter Contact User_id:");
				scanf("%s", mess);			
        		strcat(mess,"$");
        
				for(i=0;i < 64;i++) {
           			buffer_user[i+7] =  mess[i];
					if(mess[i] == '\0')
						break;
        		}
		
        		ssl_write(ssl, buffer_user, sizeof(buffer_user));
    		}
	
			/*Receive ACK_Infor_add_user_id*/
				for(i = 0;i < MAX_MESSAGE;i++) {
					buffer_user[i] = '\0';
					mess[i] = '\0';
				}
		
    		ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			get_data(buffer_user, mess, 7);	
		
			/*Reveice new contactlist*/
				if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x37) ) {
					fprintf(stdout, "New user_id contactlist OK...Online\n");
				}
				else if( (buffer_user[0] == 0x03) && (buffer_user[5] == 0x39) ) {			
					fprintf(stdout, "New user_id contactlist OK...Offline\n");
				}
				else	
					fprintf(stdout, "%s\n", mess);	
			
		}
end_add:	
}

void logout(SSL* ssl)
{
    char log[1] = {0x07};

    ssl_write(ssl, log, 1);  
}

/*
	Register **********************************************************
*/
int write_user_id(char user_id[], char nick_name[])
{
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i;
	char tmp[MAX_MESSAGE];
	
		for(i = 0;i < MAX_MESSAGE;i++)
			tmp[i] = '\0';			
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "a") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file....");
			return -1; 
    	}
		strncat(tmp, "\n", 1);		
		strncat(tmp, "\n", 1);		
		strcpy(tmp, "Nick_name:");
		strcat(tmp, nick_name);
		strncat(tmp, "\n", 1);
		//fprintf(stderr,"Tmp %s", tmp);
		if(fputs(tmp, log) == EOF) {
			fprintf(stderr,"Write Nick_name Error");
			return 0;			
		}

		strncat(tmp, "\n", 1);
		strncat(tmp, "\n", 1);
		strcpy(tmp, "User_id:");
		strncat(tmp, user_id, FIX_USER_ID);
		strncat(tmp, "\n", 1);
		//fprintf(stderr,"Tmp %s", tmp);
		if(fputs(tmp, log) == EOF) {
			fprintf(stderr,"Write User_id Error");
			return 0;
		}			
	
		fclose(log);
		return 1;
}

int new_user(SSL *ssl)
{
    int i;
	int point = 7;
    char mess[MAX_MESSAGE];
	char temp[64];
	char email[64];
    unsigned char buffer_user[MAX_MESSAGE];
    
    	for(i=0;i<=MAX_MESSAGE;i++) {
        	buffer_user[i] = '\0';
			mess[i] = '\0';
		}
    	
		/*request register = '1'*/
    	/*channel 1, sequence 1, length 7, command 0x10, flag f, data null*/
    	/*Set header*/
    		buffer_user[0] = 0x01;
    		buffer_user[1] = 0x00;
    		buffer_user[2] = 0x01;
    		buffer_user[3] = 0x00;
    		buffer_user[4] = 0x07;
    		buffer_user[5] = 0x10;
    		buffer_user[6] = 0xff;
  
    		ssl_write(ssl, buffer_user, sizeof(buffer_user));
  
    	/*Receive ACK_request_register*/
		for(i=0;i<=MAX_MESSAGE;i++)
            buffer_user[i] = '\0';
			
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));
   			
   		if( (buffer_user[0] == 0x01) && (buffer_user[5] == 0x11) )
    	{
			/*Send send_information*/
       		/*channel=0x01, sequence=0x0001, length, command=0x12, flag=0xff */
        	/*Set header*/
        	for(i=0;i<=MAX_MESSAGE;i++) {
            	buffer_user[i] = '\0';
				mess[i] = '\0';
				temp[i] = '\0';
			}

        	buffer_user[0] = 0x01;
        	buffer_user[1] = 0x00;
        	buffer_user[2] = 0x01;
        	buffer_user[3] = 0x00;
        	buffer_user[4] = 0x3c;
        	buffer_user[5] = 0x12;
        	buffer_user[6] = 0xff;

        	//strcpy(mess,"Adisak$Wongjanla$M$23$kasdiaon@hotmail.com$");
        	/*Get Information of User*/
			fprintf(stdout, "     Enter Information\n");
			fprintf(stdout, "Frist Name (least than 64 char):");			
        		scanf("%s", temp);
				strcpy(mess, temp);				
				strncat(mess, "$", 1);	
		    fprintf(stdout, " Last Name (least than 64 char):");
				scanf("%s", temp);
				strcat(mess, temp);
				strcat(mess, "$");	
			fprintf(stdout, "Nick Name (least than 255 char):");
				scanf("%s", temp);
				strcat(mess, temp);
				strcat(mess, "$");	
				strncpy(nick_name, temp, 255);
			fprintf(stdout, "SEX (F[female] or M[male] only):");
				scanf("%s", temp);
				strcat(mess, temp);
				strcat(mess, "$");		   				
			fprintf(stdout, "        AGE (least than 3 char):");
				scanf("%s", temp);
				strcat(mess, temp);
				strcat(mess, "$");		    				
			fprintf(stdout, "     Email (least than 64 char):");
				scanf("%s", temp);
				strcat(mess, temp);
				strncat(mess, "$", 1);
				strncpy(email, temp, 64);				
				
			if(strncmp(nick_name, "N/A", 3) == 0 )
				strcpy(nick_name, email);
			
			for(i=0;i < MAX_MESSAGE;i++) {
            	buffer_user[i+7] =  mess[i];
				if(mess[i] == '\0')
					break;
        	}
        	ssl_write(ssl, buffer_user, sizeof(buffer_user));       
		
			/*Receive user_id*/
				for(i = 0;i < MAX_MESSAGE;i++) {
					buffer_user[i] = '\0';
					mess[i] = '\0';
				}
    	
			ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
			if( (buffer_user[0] == 0x01) && (buffer_user[5] == 0x13) ) { 
				/*Get user_id_name*/
            		point = get_data(buffer_user, user_id, 7);
					fprintf(stdout, "User_id => %s\n", user_id);
					write_user_id(user_id, nick_name);
				return 1;
			}
			else {
				get_data(buffer_user, mess, 7);
				fprintf(stdout, "%s\n", mess);
				return 0;
			}
			
		}
		else {
			get_data(buffer_user, mess, 7);
			fprintf(stdout, "%s\n", mess);
			return 0;
		}
	
end_new:
		return 0;		
}

/*
	Change Nick Name**********************************************************
*/
void change_nick_atfile()
{
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i, j;
	char c;
	char tmp[255];
	
		for(i = 0;i < 100;i++)
			tmp[i] = '\0';			
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "r+") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file (change_nick_atfile)");
			goto end_atfile; 
    	}
		
		i = 0;
		while(i < 2 && c != EOF)
		{
			c = getc(log);
			//fprintf(stderr,"Ch %c", c);
			if( c == ':') {
				i++;
				if(i == 2) {
					j = 0;
					while(nick_name[j] != '\0') {
						putc(nick_name[j], log);
						++j;
					}
					putc('\n', log);
					putc('\n', log);
					strcpy(tmp, "User_id:");
					strncat(tmp, user_id, FIX_USER_ID);
					fputs(tmp, log);
					putc('\n', log);
					putc('\n', log);
				}					
			}
		}
end_atfile:
		fclose(log);
		
}

void change_nick_name(SSL *ssl)
{
	int i;
  	unsigned char buffer_user[MAX_MESSAGE];
	unsigned char mess[MAX_MESSAGE];
	unsigned char temp[255];
  	
  		for(i=0;i<=MAX_MESSAGE;i++) {
    		temp[i] = '\0';
			mess[i] = '\0';
			buffer_user[i] = '\0';
		}
		
		/*Get data*/
		fprintf(stdout, "Cerrent Nick name:%s\n", nick_name);
		fprintf(stdout, "Enter Information\n");
		fprintf(stdout, "New Nick_Name (least than 255 char):");			
        scanf("%s", temp);
		strncpy(mess, temp, 255);
		strncpy(nick_name, temp, 255);
		strncat(mess, "$", 1);	
  		
		/*request_change_nick_name = 0x41*/
  		/*channel 0x05, sequence 0x0001, length 0x0007, command 0x51, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x04;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0x41;
  		buffer_user[6] = 0xff;
		
		for(i=0;i < 255;i++) {
            buffer_user[i+7] =  mess[i];
			if(mess[i] == '\0')
					break;
        }
			
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		/*Receive response status*/
			for(i=0;i<=MAX_MESSAGE;i++) {
    		temp[i] = '\0';
			buffer_user[i] = '\0';
		}
			
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));	
	
		if( (buffer_user[0] == 0x04) && (buffer_user[5] == 0x42) )
    	{			
			get_data(buffer_user, temp, 7);
			fprintf(stdout, "%s\n", temp);
			change_nick_atfile();
		}
		else {
			get_user_id_nick_name();
			fprintf(stdout, "Command respone Nick_name Error\n");	
		}			
}

/*
	Find Contact_list**********************************************************
	Channel 0x08
*/
void find_contractlist(SSL *ssl)
{
	int i, j;
  	unsigned char buffer_user[MAX_MESSAGE];
	unsigned char buffer[MAX_MESSAGE];
	unsigned char mess[MAX_MESSAGE];
	int menu_invalid =0;
	char menu[80];
	char temp[64];
	unsigned char fuser_id[9];
	unsigned char femail[64];
	unsigned char ffrist_name[64];
	unsigned char flast_name[64];
	unsigned char ftype[2];
	unsigned char fage[3];
	unsigned char more_pack;
	
		for(i=0;i<=MAX_MESSAGE;i++) {
			mess[i] = '\0';
			buffer_user[i] = '\0';
			buffer[i] = '\0';
		}
		
		/*request_find = 0x81*/
  		/*channel 0x08, sequence 0xXXXX, length 0xXXXX, command 0x81, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x08;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0x81;
  		buffer_user[6] = 0xff;
			
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		/*Receive response find contactlist*/
			for(i=0;i<=MAX_MESSAGE;i++) {
    			buffer_user[i] = '\0';
			}
			
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));	
	
		if( (buffer_user[0] == 0x08) && (buffer_user[5] == 0x82) )
    	{	
			fprintf(stdout, "Enter Information(Null infor put '_'\n");
	    	fprintf(stdout, "Type Find (O = Search OR, A = Search AND):");
				scanf("%s", ftype);
				strncat(mess, ftype, 1);
				strncat(mess, "$", 1);	
			fprintf(stdout, "    User ID (least than 9 char):");			
        		scanf("%s", fuser_id);
				strcat(mess, fuser_id);				
				strncat(mess, "$", 1);	
		    fprintf(stdout, "     Email (least than 64 char):");
				scanf("%s", femail);
				strcat(mess, femail);
				strncat(mess, "$", 1);	
			fprintf(stdout, "Frist Name (least than 64 char):");
				scanf("%s", ffrist_name);
				strcat(mess, ffrist_name);
				strncat(mess, "$", 1);	
			fprintf(stdout, "Last Name  (least than 64 char):");
				scanf("%s", flast_name);
				strcat(mess, flast_name);
				strncat(mess, "$", 1);	
			    				
			//fprintf(stdout, "Find Information Send to server:%s\n", mess);					
			
			/*send_find_infor = 0x83*/
  			/*channel 0x08, sequence 0xXXXX, length 0xXXXX, command 0x83, flag 0xff, data null*/
  			/*Set header*/
  			buffer_user[0] = 0x08;
  			buffer_user[1] = 0x00;
  			buffer_user[2] = 0x01;
  			buffer_user[3] = 0x00;
  			buffer_user[4] = 0x07;
  			buffer_user[5] = 0x83;
  			buffer_user[6] = 0xff;			
			
			for(j = 0;j < MAX_MESSAGE;j++) {
            	buffer_user[j+7] =  mess[j];
				if(mess[j] == '\0')
					break;
        	}
			
        	ssl_write(ssl, buffer_user, sizeof(buffer_user));       
			
			/*Receive find infor*/
				for(i = 0;i < MAX_MESSAGE;i++) {
					buffer_user[i] = '\0';
					mess[i] = '\0';
				}
    	
			do 
			{			
				/*Receive response status*/
				ssl_read(ssl, buffer_user, sizeof(buffer_user));
	
				more_pack = buffer_user[6];	
			
				for(i = 0;i < MAX_MESSAGE;i++)
					buffer[i] = '\0';
		
				if( (buffer_user[0] == 0x08) && (buffer_user[5] == 0x84) )
    			{
				
					i = 0;			
					while(buffer_user[FIX_HEADER +1 +i] != '\0')
					{
						buffer[i] = buffer_user[FIX_HEADER +1 +i];
						++i;
					}	
				
					for(i = 0;i < MAX_MESSAGE;i++)
						buffer_user[i] = '\0';
				
					fprintf(stdout, "Find Result = %s\n", buffer);
				}
				else {
					fprintf(stdout, "Command find Error\n");
					goto end_find_contactlist;
				}
			}while(more_pack == 0x01);
		}
		else {
			fprintf(stdout, "Can't Find contactlist, Command Error\n");	
		}

end_find_contactlist:		
	
}

/*
	Delete Contact_list**********************************************************
	Channel 0x0B
*/
void de_con(SSL *ssl, char temp[])
{
	int i;
  	unsigned char buffer_user[MAX_MESSAGE];
	unsigned char mess[MAX_MESSAGE];
  	
  		for(i=0;i<=MAX_MESSAGE;i++) {
			mess[i] = '\0';
			buffer_user[i] = '\0';
		}
		
		/*request_delete_contactlist = 0xb1*/
  		/*channel 0x0b, sequence 0x0001, length 0x0007, command 0xb1, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x0b;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0xb1;
  		buffer_user[6] = 0xff;
			
		for(i=0;i < 100;i++) {
            buffer_user[i+7] =  temp[i];
        }
		
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		/*Receive response delete contactlist*/
			for(i=0;i<=MAX_MESSAGE;i++) {
    			buffer_user[i] = '\0';
			}
			
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));	
	
		if( (buffer_user[0] == 0x0b) && (buffer_user[5] == 0xb2) )
    	{			
			get_data(buffer_user, mess, 7);
			fprintf(stdout, "%s\n", mess);
			status(ssl);
		}
		else {
			fprintf(stdout, "Can't Delete contactlist\n");	
		}	
}

void delete_contactlist(SSL *ssl)
{
	/*Do you really want to Delete Contact_list:
	    y = Delete
	  	n = Cancel */
 	int i, j;
	int menu_invalid =0;
	char menu[80];
	char temp[64];
	
		fprintf(stdout, "Enter Information\n");
	    fprintf(stdout, "Current Contact_list= %s\n", contact_list);
		fprintf(stdout, "Type the User_id that you would like to delete from Contact_list\n");			
        fprintf(stdout, "   :");
		scanf("%s", temp);
		strncat(temp, "$", 1);
	
		while(1)
		{
			printf("    Do you really want to Delete %s from Contact_list\n", temp);
			printf("************** Verify Delete ************************\n");
    		printf("          y = Delete\n");
			printf("          n = Cancel\n");
			if(menu_invalid)
          			printf("Menu Invalid!!!!!\n\n");
	
			printf("Enter menu  :");
      		scanf("%s", menu);
      		printf("\n");
      		printf("\n");

	  		system("clear");
			switch(menu[0])
      		{
        			case 'y': printf("Delete \n");
                  					de_con(ssl, temp);
                  					menu_invalid = 0;
                  					goto end_delete_contractlist;
					case 'n': printf("Cancel \n");
            						menu_invalid = 0;
                  					goto end_delete_contractlist;
					default	   :menu_invalid = 1;
                  					break;	
			}
		}		

end_delete_contractlist:	
}

/*
	Delete Admin**********************************************************
	Channel 0x0A
*/
void remove_infor_of_log()
{
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i, j;
	char c;
	char tmp[255];
	
		for(i = 0;i < 100;i++)
			tmp[i] = '\0';			
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "w") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file (remove_infor_of_log)");
			goto end_remove_infor_of_log; 
    	}
		
		fputs("New_user :no", log);
		
end_remove_infor_of_log:
		fclose(log);
}

void de_admin(SSL *ssl)
{
	int i;
  	unsigned char buffer_user[MAX_MESSAGE];
	unsigned char mess[MAX_MESSAGE];
	unsigned char temp[255];
  	
  		for(i=0;i<=MAX_MESSAGE;i++) {
			mess[i] = '\0';
			buffer_user[i] = '\0';
		}
		for(i=0;i<=255;i++) {	
			temp[i] = '\0';	
		}	
		
		/*request_delete_admin = 0xa1*/
  		/*channel 0x0a, sequence 0x0001, length 0x0007, command 0xa1, flag 0xff, data null*/
  		/*Set header*/
  		buffer_user[0] = 0x0a;
  		buffer_user[1] = 0x00;
  		buffer_user[2] = 0x01;
  		buffer_user[3] = 0x00;
  		buffer_user[4] = 0x07;
  		buffer_user[5] = 0xa1;
  		buffer_user[6] = 0xff;
				
		ssl_write(ssl, buffer_user, sizeof(buffer_user));
	
		/*Receive response status*/
			for(i=0;i<=MAX_MESSAGE;i++) {
    			buffer_user[i] = '\0';
			}
			for(i=0;i<=255;i++) {	
			temp[i] = '\0';	
			}
			
    	ssl_read(ssl, buffer_user, sizeof(buffer_user));	
	
		if( (buffer_user[0] == 0x0a) && (buffer_user[5] == 0xa2) )
    	{			
			get_data(buffer_user, temp, 7);
			fprintf(stdout, "%s\n", temp);
			remove_infor_of_log();
		}
		else {
			fprintf(stdout, "Can't Delete Admin\n");	
		}	
	
		logout(ssl);
}

void delete_admin(SSL *ssl)
{
	//Do you really want to Delete Admin Information:
	//    y = Delete and Unregister
	//  	n = Cancel
	int i, j;
	int menu_invalid =0;
	char menu[80];
	
		while(1)
		{
			printf("    Do you really want to Delete Admin Information:\n");
			printf("************** Verify Delete ************************\n");
    		printf("          y = Delete and Unregister\n");
			printf("          n = Cancel\n");
			if(menu_invalid)
          			printf("Menu Invalid!!!!!\n\n");
	
			printf("Enter menu  :");
      		scanf("%s", menu);
      		printf("\n");
      		printf("\n");

	  		system("clear");
			switch(menu[0])
      		{
        			case 'y': printf("Delete \n");
                  					de_admin(ssl);
                  					menu_invalid = 0;
                  					goto end_delete_admin;
					case 'n': printf("Cancel \n");
            						menu_invalid = 0;
                  					goto end_delete_admin;
					default	   :menu_invalid = 1;
                  					break;	
			}
		}				
	
end_delete_admin:
}

int  mune_invalid = 0;
void make_services(SSL *ssl)
{
    char menu [80];
    int  exit = 1;
 
		while(1)
		{
				
      		printf("\n");
      		printf("\n");

			printf("************************************************************\n");
      		printf("*   %s", user_id);
			printf("*   %s\n", nick_name);
			printf("*************  Select Services Menu ************************\n");
      		printf("          a = Add Contactlist with Email\n");
			printf("          u = Add Contactlist with User_id\n");
      		printf("          c = Change Nick Name\n");
	  		printf("          f = Find Contactlist\n");
			printf("          z = Delete Contactlist\n");
			printf("          x = Delete Admin\n");
			printf("          s = Status Contactlist Update\n");
      		printf("          o = Logout\n\n");
      		if(mune_invalid)
          		printf("Menu Invalid!!!!!\n\n");

      		printf("Enter menu  :");
      		scanf("%s", menu);
      		printf("\n");
      		printf("\n");

	  		system("clear");
	  
      		switch(menu[0])
      		{
        		case 'a': printf("Add Contactlist with Email \n");
                  				add_contactlist(ssl, 'a');
                  				mune_invalid = 0;
                  				break;
				case 'u': printf("Add Contactlist with User_id \n");
                  				add_contactlist(ssl, 'u');
                  				mune_invalid = 0;
                  				break;
       			case 's': printf("Status Contact_list \n");
				  				status(ssl);	
                  				mune_invalid = 0;
                  				break;
        		case 'c': printf("Change Nick Name\n");
								change_nick_name(ssl);
                  				mune_invalid = 0;
                  				break;
				case 'f': printf("Find Contactlist\n");
								find_contractlist(ssl);
								mune_invalid = 0;
                  				break;
				case 'z': printf("Delete Contactlist\n");
								delete_contactlist(ssl);
								mune_invalid = 0;
                  				break;
				case 'x': printf("Delete Admin\n");
								delete_admin(ssl);
								mune_invalid = 0;
								exit = 0;
                  				break;
        		case 'o': printf("Logout \n");
                  				logout(ssl);
                  				exit = 0;
                  				break;
        		default : mune_invalid = 1;
                  				break;
      		}
			
      		if(!exit)
          		break;
		}
        
exit_services:
}

int check_log()
{
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i;
	unsigned char c = ' ';
    char new[8];
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "r") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file....");
			return -1; 
    	}		
		
		for(i = 0;i < 8;i++)
			new[i] = '\0';			

	    while( feof(log) == 0 ) 
		{
			c = getc(log);
			//fprintf(stderr,"C = %c\n", c);
			if( c == ':') {
				new[0 ] = getc(log);
				new[1] = getc(log);
				new[2] = getc(log);
				break;
			}
		}
		//fprintf(stderr,"new = %s\n", new);		
		fclose(log);
		if( (strncmp(new, "yes", 3) == 0) || (strncmp(new, "YES", 3) == 0 ) )
			return 1;
		else {
			//fputs("New_user :yes", log);
			return 0;
		}
}

void connect_server(int check)
{
	/*SSL Connecting Argument*/
    BIO     *conn;
    SSL     *ssl;
    SSL_CTX *ctx;
    long    err;
	int connect = 0;
	
	/*TCP Connectoin Argument*/
    int clientfd;
	
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
		system("clear");
	     
		init_OpenSSL(  );
    	seed_prng(  );

    	ctx = setup_client_ctx(  );

    	/*TCP Connectinh*/
    	clientfd = connect_server_TCP();
        
    	/*SSL Connecting*/
    	conn = BIO_new_socket(clientfd, BIO_NOCLOSE);
    	ssl = SSL_new(ctx);
    	SSL_set_bio(ssl, conn, conn);
   		if (SSL_connect(ssl) <= 0)
        	int_error("Error connecting SSL object");

    	fprintf(stderr, "Loading Connection.........\n");
	
		if(read_connect(ssl)) {	
			if(check == 0) {
				if(new_user(ssl) == 1)
				{
				/*Open Log file*/
 	 				if ( (log = fopen(filename, "r+") ) == NULL) { 
						perror(filename);
      					fprintf(stderr,"Something bad Open log file....");
						goto end_connect_server; 
    				}
					fputs("New_user :yes", log);
					fclose(log);
					make_services(ssl);
				}
			}
			else if(check == 1) {
				login(ssl);
				make_services(ssl);
			}
		}
		
		SSL_free(ssl);
    	SSL_CTX_free(ctx);
    	close(clientfd);	
		
end_connect_server:

}

int main(int argc, char *argv[])
{
	//int check_new;
	int menu_check = 0;	
	char menu[80];
	
	system("clear");
	
		while(1)
		{
			if(!check_log()) {
				/*new user*/								
				printf("            Menu\n\n");
				printf("         n = New register \n");
				printf("         q = Exit Program \n\n");
				if(menu_check) {
					menu_check = 0;
					printf("Menu Invalid....!\n");
				}
				printf("Enter menu :");
      			scanf("%s", menu);
				if(menu[0] == 'n') {
					/*New user*/
					connect_server(0);
					//goto end_main;
				}
				else if (menu[0] == 'q')
					goto end_main;
				else	{
					menu_check = 1;
				}
				system("clear");																				
			}
			else {
			/*login*/											
				printf("            Menu\n\n");
				printf("         l = Login \n");
				printf("         q = Exit Program \n\n");
				if(menu_check) {
					menu_check = 0;
					printf("Menu Invalid....!\n");
				}
				printf("Enter menu :");
      			scanf("%s", menu);
				if(menu[0] == 'l') {
					/*login*/
					connect_server(1);
					//goto end_main;
				}
				else if (menu[0] == 'q')
					goto end_main;
				else	{
					menu_check = 1;
				}
				system("clear");														
			}
		}
end_main:
		system("clear");

    return 0;
}
