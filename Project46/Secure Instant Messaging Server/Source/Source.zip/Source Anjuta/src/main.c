/* Created by Anjuta version 1.1.97 */
/*	This file will not be overwritten */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comman.h"

void itoa_base10(unsigned long user_id, char buff[])
{
	int i = 0;
	int unit;
	long upper = 1;
	long lower = 1;
	char c;
	char tmp[10];
	unsigned long tmp_id = 0 ;
	
		for(i = 0;i < 10;i++) {
			buff[i] = '\0';
			tmp[i] = '\0';
		}
		
		i = 0;
		while(tmp_id < user_id){
			upper *= 10;
			tmp_id = user_id % upper;
			unit = tmp_id / lower;
			tmp[i] = 48 + unit;	
			lower *=10;
			++i;
		}
		for(i =0;i < 9;i++) 
			buff[i] = tmp[8-i];
}

/* Return a random integer between MIN and MAX, inclusive. Obtain
randomness from /dev/random. */
unsigned int random_number(int MAX_RAN, int MIN_RAN)
{
  /* Store a file descriptor opened to /dev/random in a static
  variable. That way, we dont need to open the file every time
  this function is called. */
  static int dev_random_fd = -1;
  char* next_random_byte;
  int bytes_to_read;
  unsigned random_value;
  int x1, x2;
  //char user_id[5];

  /* Make sure MAX is greater than MIN. */
  assert (MAX_RAN > MIN_RAN);

  /* If this is the first time this function is called, open a file
  descriptor to /dev/random. */
  if (dev_random_fd == -1)
  {
    dev_random_fd = open("/dev/random", O_RDONLY);
    assert (dev_random_fd != -1);
  }

  /* Read enough random bytes to fill an integer variable. */
  next_random_byte = (char*) &random_value;
  bytes_to_read = sizeof (random_value);

  /* Loop until weve read enough bytes. Because /dev/random is filled
  from user-generated actions, the read may block and may only
  return a single random byte at a time. */
  do
  {
    int bytes_read;
    bytes_read = read (dev_random_fd, next_random_byte, bytes_to_read);
    bytes_to_read -= bytes_read;
    next_random_byte += bytes_read;
  } while (bytes_to_read > 0);

  /* Compute a random number in the correct range. */
 return MIN_RAN + (random_value % (MAX_RAN - MIN_RAN + 1));

}

int main()
{
	unsigned long user_id;
	unsigned char userid[10] = "655355555";
	unsigned char tmp[10];
	unsigned char data[5];
	unsigned char msb[3];
	unsigned char lsb[3];
	unsigned char h;
	unsigned char l;
	unsigned int length = 0;
	unsigned int sequence = 0;
	unsigned int dev_random_fd;
	
	
	length = random_number( 65535, 123);
	sequence = random_number(65535, 123);
    
	fprintf(stdout, "Seq = %d\n", sequence);
	fprintf(stdout, "Len = %d\n", length);
	
/*	
    sprintf(data, "%x", 1234);
	
	msb[0] = data[0];
	msb[1] = data[1];
	lsb[0] = data[2];
	lsb[1] = data[3];
	
	fprintf(stdout, "MSB = %s\n", msb);
	fprintf(stdout, "LSB = %s\n", lsb);
	fprintf(stdout, "Data = %s\n", data);
	
	h = atoi(msb);
	l = atoi(lsb);
	
	fprintf(stdout, "MSB = %d\n", h);
	fprintf(stdout, "LSB = %d\n", l);
	
	user_id = atoi(userid);
	
	 //itoa( int value, char* buffer, int radix );
	itoa_base10(user_id, tmp);
	
	fprintf(stdout, "User ID atoi :%d\n", user_id);
	fprintf(stdout, "User ID itoa :%s\n", tmp);
	
*/

/*
if(check_infor == 1)
						{
						
     						for(i=0;i < MAX_MESSAGE;i++)
       							query[i] = '\0';
							strcpy(query, "SELECT EMAIL FROM user WHERE USER_ID = ");
     						strcat(query, fuser_id);
     						//fprintf(stdout, "Query: %s\n", query);

     						check_query = process_query(isagmq_db, query);
     						mysql_query(isagmq_db, query);
      						res_set = mysql_store_result(isagmq_db);
							row = mysql_fetch_row(res_set);
       						if( row != NULL) {
								fprintf(stdout, "Find user_id OK %s \n", fuser_id);
								strcpy(find_infor, fuser_id);
								strncat(find_infor, "#", 1);
								strcat(find_infor, row[0]);	
								strncat(find_infor, "#", 1);
								if(find(fuser_id, temp))
									strncat(find_infor, "O", 1);
								else
									strncat(find_infor, "F", 1);
							
								length = strlen(find_infor);
								temp_length = length;							
							}
						}
						else if(check_infor == 1) {
						
     						for(i=0;i < MAX_MESSAGE;i++)
       							query[i] = '\0';
     						strcpy(query, "SELECT USER_ID FROM user WHERE EMAIL = '");
     						strcat(query, femail);
							strncat(query, "'", 1);
							fprintf(stdout, "Query: %s\n", query);
     					
     						check_query = process_query(isagmq_db, query);
     						mysql_query(isagmq_db, query);
      						res_set = mysql_store_result(isagmq_db);
							row = mysql_fetch_row(res_set);
       						if( row != NULL) {
								fprintf(stdout, "Find email OK %s \n", femail);
								strcpy(find_infor, row[0]);
								strncat(find_infor, "#", 1);
								strcat(find_infor, femail);	
								strncat(find_infor, "#", 1);
								if(find(row[0], temp))
									strncat(find_infor, "O", 1);
								else
									strncat(find_infor, "F", 1);
							
								length = strlen(find_infor);
								temp_length = length;
								
							}
						}
						else {
							strcpy(find_infor, "Find not found");
						}				
						
*/
		return 0;
}
