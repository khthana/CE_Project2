#include  <mysql.h>

#include  <signal.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>

#include  <sys/types.h> /* basic system data types */
#include  <sys/socket.h>  /* basic socket definitions */
#include  <sys/time.h>  /* timeval{} for select() */
#include  <time.h>    /* timespec{} for pselect() */
#include  <netinet/in.h>  /* sockaddr_in{} and other Internet defns */
#include  <arpa/inet.h>   /* inet(3) functions */
#include  <errno.h>
#include  <fcntl.h>   /* for nonblocking */
#include  <netdb.h>

#include  <sys/stat.h>  /* for S_xxx file mode constants */
#include  <sys/uio.h>   /* for iovec{} and readv/writev */
#include  <unistd.h>
#include  <sys/wait.h>
#include  <sys/un.h>    /* for Unix domain sockets */
#include  <sys/select.h>  /* for convenience */
#include  <assert.h>
#include  <fcntl.h>

#include  <pthread.h>

/*Database*/
#define def_host_name "localhost"
#define def_user_name "root"
#define def_password  "25230429"
#define def_db_name   "isagmqdb"
#define def_port_num 0 /* use default port */
#define def_socket_name NULL /* use default socket name */
static MYSQL *isagmq_db;
static MYSQL_RES *res_set;

/***************************************************************************************/
/*Print Error for Mysql*/
void
print_error (MYSQL *conn, char *message)
{
  fprintf (stderr, "%s\n", message);
  if (conn != NULL)
  {
    fprintf(stderr, "Error %u (%s)\n",
            mysql_errno (conn) ,mysql_error (conn));
  }
}

/***************************************************************************************/
MYSQL *do_connect (char *host_name, char *user_name, char *password, char *db_name,
                   unsigned int port_num, char *socket_name, unsigned int flags)
{
  MYSQL *conn; /* pointer to connection handler */
  conn = mysql_init (NULL); /* allocate, initialize connection handler */
  if (conn == NULL)
  {
    print_error(NULL, "mysql_init() failed (probably out of memory)");
    return(NULL);
  }
  if (mysql_real_connect (conn, host_name, user_name, password,
      db_name, port_num, socket_name, flags) == NULL)
  {
    print_error(conn, "mysql_real_connect() failed");
    return(NULL);
  }
  return(conn); /* connection is established */
}

/***************************************************************************************/
void
do_disconnect (MYSQL *conn)
{
  mysql_close (conn);
}

/***************************************************************************************/
/*SHOW Result if SELECT*/
void
process_result_set (MYSQL *conn, MYSQL_RES *res_set)
{
  MYSQL_ROW row;
  unsigned int i;
  while((row = mysql_fetch_row(res_set)) != NULL)
  {
    for (i = 0; i < mysql_num_fields(res_set); i++)
    {
      if (i > 0)
        fputc ('\t', stdout);
      printf ("%s", row[i] != NULL ? row[i] : "NULL");
    }
    fputc ('\n', stdout);
  }
  if(mysql_errno (conn) != 0)
    print_error(conn, "mysql_fetch_row() failed");
  //else
    //printf ("%lu rows returned\n", (unsigned long) mysql_num_rows(res_set));
}

/***************************************************************************************/
/*PROCESS SELECT AND INSERT QUERY*/
#if !defined(MYSQL_VERSION_ID) || MYSQL_VERSION_ID<32224
#define mysql_field_count mysql_num_fields
#endif

int
process_query(MYSQL *conn, char *query)
{
  MYSQL_RES *res_set;
  unsigned int field_count;

  if(mysql_query(conn, query) != 0) /* the query failed */
  {
    print_error(conn, "process_query() failed");
    return -1;
  }

  /* the query succeeded; determine whether or not it returns data */
  res_set = mysql_store_result(conn);
  if(res_set == NULL) /* no result set was returned */
  {
    /*
    * does the lack of a result set mean that an error
    * occurred or that no result set was returned?
    */
    if(mysql_field_count (conn) > 0)
    {
      /*
      * a result set was expected, but mysql_store_result()
      * did not return one; this means an error occurred
      */
      print_error (conn, "Problem processing result set");
      return -1; //Problem processing result set
    }
    else
    {
      /*
      * no result set was returned; query returned no data
      * (it was not a SELECT, SHOW, DESCRIBE, or EXPLAIN),
      * so just report number of rows affected by query
      */
      /*
      printf ("%lu rows affected\n",
             (unsigned long) mysql_affected_rows (conn));
      */
      return 0; //No. result       
    }
  }        
  else /* a result set was returned */
  {
    /* process rows, then free the result set */
    //process_result_set(conn, res_set);
    mysql_free_result(res_set);
    return 1;
  }
}
/***************************************************************************************/

/*Random*/
#define MAX_RAN 99999
#define MIN_RAN 9999

/***************************************************************************************/
/* Return a random integer between MIN and MAX, inclusive. Obtain
randomness from /dev/random. */
void random_number (char* user_id)
{
  /* Store a file descriptor opened to /dev/random in a static
  variable. That way, we don�t need to open the file every time
  this function is called. */
  static int dev_random_fd = -1;
  char* next_random_byte;
  int bytes_to_read;
  unsigned random_value;
  unsigned id;
  int x1, x2;
  //char user_id[5];

  /* Make sure MAX is greater than MIN. */
  assert (MAX_RAN > MIN_RAN);

  /* If this is the first time this function is called, open a file
  descriptor to /dev/random. */
  if (dev_random_fd == -1)
  {
    dev_random_fd = open("/dev/random", O_RDONLY);
    assert (dev_random_fd != -1);
  }

  /* Read enough random bytes to fill an integer variable. */
  next_random_byte = (char*) &random_value;
  bytes_to_read = sizeof (random_value);

  /* Loop until we�ve read enough bytes. Because /dev/random is filled
  from user-generated actions, the read may block and may only
  return a single random byte at a time. */
  do
  {
    int bytes_read;
    bytes_read = read (dev_random_fd, next_random_byte, bytes_to_read);
    bytes_to_read -= bytes_read;
    next_random_byte += bytes_read;
  } while (bytes_to_read > 0);

  /* Compute a random number in the correct range. */
  id = MIN_RAN + (random_value % (MAX_RAN - MIN_RAN + 1));

  if(id < 9999 && id > 100000)
    exit(0);

  //Convert Number to String char
   //10000
   x1 = id;
   x2 = x1/10000;
   user_id[0] = x2 + 48;

   //1000
   x1 = id;
   x2 = x1%10000;
   x2 = x2/1000;
   user_id[1] = x2 + 48;

   //100
   x1 = id;
   x2 = x1%10000;
   x2 = x2%1000;
   x2 = x2/100;
   user_id[2] = x2 + 48;

   //100
   x1 = id;
   x2 = x1%10000;
   x2 = x2%1000;
   x2 = x2%100;
   x2 = x2/10;
   user_id[3] = x2 + 48;

   //unit
   x1 = id;
   x2 = x1%10000;
   x2 = x2%1000;
   x2 = x2%100;
   x2 = x2%10;
   user_id[4] = x2 + 48;

   /*Check User ID */

}

/***************************************************************************************/
/*Network*/
#define MYPORT 2546
#define BACKLOG 5
#define MAX_MESSAGE 512 //per packet
static int NUMBER_CLIENT = 0;

/***No. complet*******************************************************************/
int check_data(char* frist_name, char* last_name, char* sex, char* age, char* email)
{
  return 1;
}

/*********************************************************************************/
int new_register(int client_fd, char* message, int length_data, char* ip_new_user)
{
  int ptr = 0;
  int iptr = 0;
  unsigned int length;
  char c;
  char frist_name[64];
  char last_name[64];
  char sex[2];
  char age[3];
  char email[64];
  char user_id[5];
  char password[64];
  char query[512];
  int check_query;
  int i;

  /*fine point of data*/
  ptr = 7;

  /*Separate information new user*/
  /*FRIST_NAME*/
  while(1)
  {                        
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      frist_name[iptr] = '\0';
      break;
    }
    frist_name[iptr] = c;
    ptr++;
    iptr++;
  }
  //printf("frist name = %s\n",frist_name);

  /*LAST_NAME*/
  iptr = 0;
  while(1)
  {
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      last_name[iptr] = '\0';
      break;
    }
    last_name[iptr] = c;
    ptr++;
    iptr++;
  }
  //printf("frist name = %s\n",last_name);

  /*SEX*/
  iptr = 0;
  while(1)
  {
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      sex[iptr] = '\0';
      break;
    }
    sex[iptr] = c;
    ptr++;
    iptr++;
  }
  //printf("frist name = %s\n",sex);

  /*AGE*/
  iptr = 0;
  while(1)
  {
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      age[iptr] = '\0';
      break;
    }
    age[iptr] = c;
    ptr++;
    iptr++;
  }
  //printf("frist name = %s\n",age);

  /*EMAIL*/
  iptr = 0;
  while(1)
  {
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      email[iptr] = '\0';
      break;
    }
    email[iptr] = c;
    ptr++;
    iptr++;
  }
  //printf("frist name = %s\n",email);
  
  /*Password*/
  iptr = 0;
  while(1)
  {
    c = message[ptr];
    if(c == '$')
    {
      ptr++;
      password[iptr] = '\0';
      break;
    }
    password[iptr] = c;
    ptr++;
    iptr++;
  }

  /*Check data*/
  if(check_data(frist_name, last_name, sex, age, email) == 0)
  {
    /*Send Error to client*/
    return 0;
  }

  //if(ptr <= (length_data + 1 + 8))
  //{
    /*Random User_ID*/
    user_id[5] = '\0' ;
    random_number(user_id);

    /*Record to database*/
    /*Connect to Database*/
    isagmq_db = do_connect (def_host_name, def_user_name, def_password, def_db_name,
                            def_port_num, def_socket_name, 0);

    if(isagmq_db == NULL)
    {
       fprintf(stdout, "Connect to Database Error");
       return 0; 
    }

    /*Query user*/
     /*Set query*/
     for(i=0;i < 512;i++)
       query[i] = '\0';  
     strcpy(query, "INSERT INTO user VALUES('");
     strcat(query, user_id);
     strcat(query, "', '");
     strcat(query, frist_name);
     strcat(query, "', '");
     strcat(query, last_name);
     strcat(query, "', '");
     strcat(query, sex);
     strcat(query, "', '");
     strcat(query, age);
     strcat(query, "', '");
     strcat(query, email);
     strcat(query, "', '");
     strcat(query, ip_new_user);
     strcat(query, "')");
     //fprintf(stdout, "Query: %s\n", query);

     check_query = process_query(isagmq_db, query);
     if( (check_query != 0) || (check_query == -1) )
     {
        fprintf(stdout, "Insert Infor. of User error \n");
        return 0;
     }
     fprintf(stdout, "Insert Infor. of User Correct \n");
             
    /*Query password*/
     /*Set query*/
     for(i=0;i < 512;i++)
       query[i] = '\0';
     strcpy(query, "INSERT INTO password VALUES('");
     strcat(query, user_id);
     strcat(query, "', '");
     strcat(query, password);
     strcat(query, "')");

     check_query = process_query(isagmq_db, query);
     if( (check_query != 0) || (check_query == -1) )
     {
        fprintf(stdout, "Insert Password of User error \n");
        return 0;
     }
     fprintf(stdout, "Insert Password of User Correct \n");
       
    do_disconnect(isagmq_db); //Disconnect MySQL                        

                                                  
    fprintf(stdout, "Information user:%s %s %s %s %s %s %s\n",
            user_id, frist_name, last_name, sex, age, email, ip_new_user);

    /*Send USER_ID to user*/
    /*channel=0x01, sequence=0x0001, length=x000e, command=0x04, flag=0xff */
    /*Set header*/
    message[0] = 0x01;
    message[1] = 0x00;
    message[2] = 0x01;
    message[3] = 0x00;
    message[4] = 0x0e;
    message[5] = 0x04;
    message[6] = 0xff;

    /*insert USER_ID to packet*/
    for(iptr = 0;iptr < 5;iptr++)
      message[iptr + 7] = user_id[iptr];
      
    message[12] = '$';
    
    length = 8 + 6;//(7+1) + (5+)(length id)
    if( write(client_fd, message, length) <= 0)
    {
      fprintf(stdout, "Write USER_ID error");
      return 0 ;
    }
    return 1;        
  //}
  //else
  //{
    /*Send Error to client*/
  //  return 0;
  //}
}

/****************************************************************************************/
int new_add_userID(int client_fd, char* buffer_read, int length_data, char* ip)
{
  MYSQL_RES *res_set;
  MYSQL_ROW row;
  
  int ptr = 0;
  int check_result;
  unsigned int length;
  char c;
  char email[64];
  char contract_user_id[5];
  char user_id_connect[5];
  char query[512];
  char contract_ip[15];
  unsigned int i;
  int check_query;

  /*fine point of data all header = 7 byte*/
    ptr = 7;

  /*get user_id_connect*/
  /*etc. data = "60345$50999$"*/
    user_id_connect[5] = '\0';
    for(i=0;i<5;i++)
      user_id_connect[i] = buffer_read[ptr+i];
    fprintf(stdout,"user_id_connect = %s\n", user_id_connect);
  
  /*get contract_user_id*/
    ptr = 13;
    contract_user_id[5] = '\0';
    for(i=0;i<5;i++)
      contract_user_id[i] = buffer_read[ptr+i];
    fprintf(stdout,"contract_user_id = %s\n", contract_user_id);
    
  /*Record to database*/
  /*Connect to Database*/
    isagmq_db = do_connect (def_host_name, def_user_name, def_password, def_db_name,
                            def_port_num, def_socket_name, 0);

    if(isagmq_db == NULL)
    {
       fprintf(stdout, "Connect to Database Error");
       return 0;
    }
    
  /*Query*/
  /*Select check IP contract*/
    for(i=0;i < 512;i++)
       query[i] = '\0';
     strcpy(query, "SELECT EMAIL, IP FROM user WHERE USER_ID = ");
     strcat(query, contract_user_id);

     check_query = process_query(isagmq_db, query);
     if( check_query == 1)
     {
       //fprintf(stdout,"Query = %s\n", query);

       mysql_query(isagmq_db, query);
       res_set = mysql_store_result(isagmq_db);

       row = mysql_fetch_row(res_set);
       if( row == NULL)
         return 0;
       
       /*Only one row result & two column(email,IP)*/
       /*get contract_email, row[0] = fields 1 of row**/
         for(i=0;i<64;i++)
           email[i] = '\0';
         strcpy(email, row[0]);
         
       /*get contract_IP, row[1] = fields 2 of row*/
         for(i=0;i<15;i++)
           contract_ip[i] = '\0';
         strcpy(contract_ip, row[1]);

       fprintf(stdout, "Add Contractlist of: %s  ",user_id_connect);
       fprintf(stdout, "New = Email: %s IP: %s\n", email, contract_ip);
       mysql_free_result(res_set);
     }
     else if(check_query == 0)
     {
       /*Send NACK  No. this UserID*/
         fprintf(stdout,"No. this UserID = %s\n", contract_user_id);
         return 0;
     }
     else
     {
        /*Send NACK  DB system error*/
         fprintf(stdout,"DB system error\n");
     }
            
     /*Record to contractlist*/
       for(i=0;i < 512;i++)
         query[i] = '\0';
       strcpy(query, "INSERT INTO contractlist VALUES('");
       strcat(query, user_id_connect);
       strcat(query, "', '");
       strcat(query, contract_user_id);
       strcat(query, "', '");
       strcat(query, contract_ip);
       strcat(query, "')");   
       //fprintf(stdout, "Query: %s\n", query);

       check_query = process_query(isagmq_db, query);
       if( (check_query != 0) || (check_query == -1) )
       {
         fprintf(stdout, "Insert Contractlist of User error %\n");
         return 0;
       }
       fprintf(stdout, "Insert Contractlist of User Correct %\n");
          
     do_disconnect(isagmq_db); //Disconnect MySQL

    /*Send ACK_Add_complet to user*/
    /*channel=0x06, sequence=0x0001, length=x0007, command=0x67, flag=0xff */
    /*Set header*/
      buffer_read[0] = 0x06;
      buffer_read[1] = 0x00;
      buffer_read[2] = 0x01;
      buffer_read[3] = 0x00;
      buffer_read[5] = 0x67;
      buffer_read[6] = 0xff;

      length = 8 + strlen(email);//(7+1) + Num_char_email
      buffer_read[4] = length;
      for(i=0;i<strlen(email);i++)
        buffer_read[7+i] = email[i];
      //fprintf(stdout,"length email:%d\n",strlen(email));
      if( write(client_fd, buffer_read, length) <= 0)
      {
        fprintf(stdout, "Write Error ACK_Add_complet");
        return 0 ;
      }
  
     return 1;
}

/****************************************************************************************/
int new_add_email(int client_fd, char* buffer_read, int length_data, char* ip)
{
  int ptr = 0;
  int iptr = 0;
  unsigned int length;
  char c;
  char frist_name[64];
  char email[64];
  char user_id[5];
  char query[512];
  int i;
  int check_query;

  /*fine point of data*/
  ptr = 7;

  /*Separate information new user*/
  
}

/****************************************************************************************/
find_contractlist(int client_fd, unsigned char* buffer_read, int length_data, char* ip)
{
  MYSQL_RES *res_set;
  MYSQL_ROW row;

  int ptr = 0;
  int check_result;
  int check_query;
  unsigned int length;
  char c;
  unsigned char email[64];
  unsigned char buff[64];
  unsigned char password_login[64];
  unsigned char password_db[64];
  unsigned char user_id_login[5];
  unsigned char query[512];
  unsigned char contract_ip[15];
  unsigned char contractlist[4096];
  unsigned int i, j;
  int lsb = 1;
  int num_packet;
  int overflow = 0;
  int current_packet = 0;

  /*fine point of data all header = 7 byte*/
    ptr = 7;

  /*get user_id_login*/
  /*etc. data = "60345$password$"*/
    user_id_login[5] = '\0';
    for(i=0;i<5;i++)
      user_id_login[i] = buffer_read[ptr+i];
    fprintf(stdout,"user_id_login = %s\n", user_id_login);

  /*get password_login*/
    ptr = 13;
    for(i=0;i<64;i++)
      password_login[i] = '\0';
    for(i=0;i<64;i++)
    {
      if(buffer_read[ptr+i] == '$')
        break;
      password_login[i] = buffer_read[ptr+i];
    }
    //fprintf(stdout,"password_login = %s\n", password_login);

  /*Record to database*/
  /*Connect to Database*/
    isagmq_db = do_connect (def_host_name, def_user_name, def_password, def_db_name,
                            def_port_num, def_socket_name, 0);

    if(isagmq_db == NULL)
    {
       fprintf(stdout, "Connect to Database Error");
       return 0;
    }
                            
  /*Query*/
  /*Select check match userID and password*/
    for(i=0;i < 512;i++)
       query[i] = '\0';
     strcpy(query, "SELECT PASSWORD FROM password WHERE USER_ID = ");
     strcat(query, user_id_login);

     check_query = process_query(isagmq_db, query);
     if( check_query == 1)
     {
       //fprintf(stdout,"Query = %s\n", query);

       mysql_query(isagmq_db, query);
       res_set = mysql_store_result(isagmq_db);

       row = mysql_fetch_row(res_set);
       if( row == NULL)
         return 0;

       /*Only one row result & one column(PASSWORD)*/
       /*get password, row[0] = fields 1 of row**/
         for(i=0;i<64;i++)
           password_db[i] = '\0';
         strcpy(password_db, row[0]);

       /*Match password_login and password_db*/
       if(strcmp(password_login,password_db) != 0)
       {
         fprintf(stdout, "Login with password incorrect\n");
         /*Send error to user*/
         return 0;
       }
         
       fprintf(stdout, "Login Correct\n");
       mysql_free_result(res_set);
     }
     else if ( check_query == 0)
     {
       //Send NACK  No. this userID
         fprintf(stdout,"No. this userID = %s\n", user_id_login);
         return 0;
     }
     else
       return 0;
     
  /*Find contractlist from DB*/
     for(i=0;i < 512;i++)
       query[i] = '\0';
     strcpy(query, "SELECT CONTRACT_USER_ID, CONTRACT_IP FROM contractlist WHERE USER_ID = ");
     strcat(query, user_id_login);
     //fprintf(stdout, "Query: %s\n", query);

     check_query = process_query(isagmq_db, query);
     if( check_query == 1)
     {
       for(i=0;i<4096;i++)
         contractlist[i] = '\0';
       //fprintf(stdout,"Query = %s\n", query);

       mysql_query(isagmq_db, query);
       res_set = mysql_store_result(isagmq_db);
       while( (row = mysql_fetch_row(res_set)) != NULL )
       {
         for (i = 0; i < mysql_num_fields(res_set); i++)
         {
           if( row[i] != NULL)
           {
             strcat(contractlist, row[i]);
           }
           /*
           if(i == 0)
             strcat(contractlist, "-");
           */
           //printf ("%s", row[i] != NULL ? row[i] : "NULL");
         }
         strcat(contractlist, "$");
       }
       if(mysql_errno (isagmq_db) != 0)
         print_error(isagmq_db, "mysql_fetch_row() failed");
       //else
        //printf ("%lu rows returned\n", (unsigned long) mysql_num_rows(res_set));

       printf ("Contractlist = %s\n", contractlist);
       
       mysql_query(isagmq_db, query);
       res_set = mysql_store_result(isagmq_db);

       mysql_free_result(res_set);
     }
     else if ( check_query == 0)
     {
       //Send NACK  No. this userID
         fprintf(stdout,"No. this userID = %s\n", user_id_login);
         return 0;
     }
     else
       return 0;

     do_disconnect(isagmq_db); //Disconnect MySQL

    /*Send contractlist to user login*/
    /*channel=0x02, sequence=x, length=x, command=0x24, flag=0x01 */
    /*Make send untile to end of contractlist*/
      ptr = 0; //begin data

      num_packet = strlen(contractlist) / 505; //505 + 7(header) = 512
      //fprintf(stdout,"Number packet = %d\n", num_packet);
      if(num_packet == 0)
      {
        buffer_read[0] = 0x06;
        buffer_read[1] = 0x00;
        buffer_read[2] = 0x01;        
        buffer_read[3] = 0x00;
        buffer_read[5] = 0x24;
        buffer_read[6] = 0x01;

        length = 8 + strlen(contractlist);
        buffer_read[4] = length;

        for(i=0;i<strlen(contractlist);i++)
          buffer_read[7+i] = contractlist[i];
        //fprintf(stdout,"length email:%d\n",strlen(email));

        if( write(client_fd, buffer_read, length) <= 0)
        {
          fprintf(stdout, "Write Contractlist Error");
          return 0 ;
        }
        fprintf(stdout,"Send Contractlist to %s complet\n", user_id_login);
      }
      else
      {
        if( (strlen(contractlist) % 505) != 0 )
          num_packet++;
        while(current_packet < num_packet)    
        {
          for(i=0;i<512;i++)
            buffer_read[i] = '\0';
        
          buffer_read[0] = 0x02;
          buffer_read[5] = 0x24;
          buffer_read[6] = 0x02;  //many packet

          buffer_read[1] = 0x00 + overflow;  //MSB
          buffer_read[2] = 0x00 + lsb;  //LSB
          if(buffer_read[2] == 0xff)  
          {
            overflow++;
            lsb = 0;
          } 
          current_packet++;
          lsb++;

          if( current_packet == num_packet )
            buffer_read[6] = 0x03;  //last packet
          
          /*Set data*/
          for(j=0;j<505;j++)
          {
            c = contractlist[ptr];
            if(c == '\0')
            {
              ptr++;
              buffer_read[ptr] = '\0';
              break;
            }
            buffer_read[ptr] = c;
            ptr++;
          }

          /*No.*/
          length = 8 + 504;//(7+1) + Max data
          
          //fprintf(stdout,"length email:%d\n",strlen(email));
          if( write(client_fd, buffer_read, length) <= 0)
          {
            fprintf(stdout, "Write Contractlist error : sequence = %d", current_packet);
            return 0 ;
          }
        }
      }
      
    return 1;
}                                                                                                                                                                                                                                

/****************************************************************************************/
int compute_length(int m, int l)
{
  //fprintf(stdout,"Length = %d %d\n", m, l);  
  if(m == 0)
    return l;
  else
    return 0;
}

/****************************************************************************************/
void disconnect(char* ip)
{
  fprintf(stdout, "Disconnect fram :%s\n", ip);
  fprintf(stdout,"\n");
  fprintf(stdout,"\n");

  /*Down number client */
  if(NUMBER_CLIENT > 0)
     NUMBER_CLIENT--;

}

/****************************************************************************************/
/*thread routine*/
void *thread_run(void *vargp)
{
  int socket_server = (int)vargp;
  struct sockaddr_in client_addr;
  int client_fd, sin_size;
  
  /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
  unsigned char buffer_read[MAX_MESSAGE];
  unsigned char buffer_write[MAX_MESSAGE];
  unsigned int length, length_data;
  int check_add, check_register, check_findcon;
  int i; 
  
  /*Wait and Accept client*/
  sin_size = sizeof(struct sockaddr_in);
  if((client_fd = accept(socket_server, (struct sockaddr*)&client_addr, &sin_size)) == -1)
  {
    perror("accept");
    return NULL;
  }

  /*Count number client */
  NUMBER_CLIENT++;

  /*Show information connect from client*/
  fprintf(stdout,"Server got connection from :%s\n", inet_ntoa(client_addr.sin_addr));
  printf("\n");
  
  for(i = 0;i < MAX_MESSAGE;i++)
    buffer_read[i] = '\0'; 
  /*read message support Java (new OutputStream())*/
/*  if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout,"Read message support Java (new OutputStream()) Error\n");
    disconnect(inet_ntoa(client_addr.sin_addr));
    return NULL;
  }                                                                        
  fprintf(stdout,"Read message support Java= %s\n", buffer_read);
*/  
  for(i = 0;i < MAX_MESSAGE;i++)
  {
    buffer_read[i] = '\0';
    buffer_write[i]= '\0';
  }
  
  /*read message channel*/
  if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout,"Read message channel Error\n");
    disconnect(inet_ntoa(client_addr.sin_addr));
    return NULL;
  }                
  //fprintf(stdout, "Read request_login =%c\n",buffer_read[0]);
  
  /*Show number connect*/
  fprintf(stdout, "Number current connect: %d\n", NUMBER_CLIENT);
  //fprintf(stdout, "message channel: %s\n", buffer_read);
  if(NUMBER_CLIENT > 250)
  {
    fprintf(stdout, "Number current connect > 250 \n");
    fprintf(stdout, "After connect \n");
    disconnect(inet_ntoa(client_addr.sin_addr));
    return NULL;
  }
               
  /*check channel*/
  switch(buffer_read[0])
  {
    case 0x1:printf("Packet channel 1 = New user --> \n");    
             /*Ack, if commamd = request_register = 0x1 (byte order = 5)
               or not end function*/
             if(buffer_read[5] == 0x1)
             {
               /*Show Command*/
               fprintf(stdout, "Command channel 1 = 0x1 = request_register\n");

               /*Send ACK_request_register*/
               /*channel=0x01, sequence=0x0001, length=x0007, command=0x02, flag=0xff */
               /*Set header*/
               buffer_write[0] = 0x01;
               buffer_write[1] = 0x00;
               buffer_write[2] = 0x01;
               buffer_write[3] = 0x00;
               buffer_write[4] = 0x07;
               buffer_write[5] = 0x02;
               buffer_write[6] = 0xff;
               length = 8;//7+1
               if( write(client_fd, buffer_write, length) <= 0)
               {
                 fprintf(stdout, "Write ACK_request_register error");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 break;
               }      
             }

             /*Read information from new user*/
             if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
             {
               fprintf(stdout,"Read information from new user Error\n");
               disconnect(inet_ntoa(client_addr.sin_addr));
               return NULL;
             }
             if( (buffer_read[0] == 0x01) && (buffer_read[5] == 0x03) )
             {
               /*Register to Database*/
               /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
               length_data = compute_length(buffer_read[3], buffer_read[4]) - 7; //7=header
               //printf("Call new_register\n");
               check_register = new_register(client_fd, buffer_read, length_data, inet_ntoa(client_addr.sin_addr));
             }
        
             break;
    case 0x2:printf("Packet channel 2 = Login\n");
             /*Ack, if commamd = request_login = 0x21 (byte order = 5)
               or not end function*/
             if(buffer_read[5] == 0x21)
             {
               /*Show Command*/
               fprintf(stdout, "Command channel 2 = 0x21 = request_login\n");

               /*Send ACK_request_login*/
               /*channel=0x02, sequence=0x0001, length=x0007, command=0x22, flag=0xff */
               /*Set header*/
               buffer_write[0] = 0x02;
               buffer_write[1] = 0x00;
               buffer_write[2] = 0x01;
               buffer_write[3] = 0x00;
               buffer_write[4] = 0x07;
               buffer_write[5] = 0x22;
               buffer_write[6] = 0xff;
               length = 8;//7+1
               if( write(client_fd, buffer_write, length) <= 0)
               {
                 fprintf(stdout, "Write ACK_request_login error");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 break;
               }
             }

             /*Read userID_password */
             if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
             {
               fprintf(stdout,"Read UserID, Password Error\n");
               disconnect(inet_ntoa(client_addr.sin_addr));
               return NULL;
             }
             if( (buffer_read[0] == 0x02) && (buffer_read[5] == 0x23) )
             {
               /*Find contractlist in the Database*/
               /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
               length_data = compute_length(buffer_read[3], buffer_read[4]) - 7; //7=header
               //fprintf(stdout, "find_contractlist");
               check_findcon = find_contractlist(client_fd, buffer_read, length_data, inet_ntoa(client_addr.sin_addr));
             }

             break;
    case 0x3:printf("Packet channel 3\n");
             break;
    case 0x4:printf("Packet channel 4\n");
             break;
    case 0x5:printf("Packet channel 5\n");
             break;
    case 0x6:printf("Packet channel 6 = Add new Contractlist -->\n");
             if(buffer_read[5] == 0x61)
             {
               /*Show Command*/
               fprintf(stdout, "Command channel 6 = 0x61 = request_Add_userID\n");

               /*Send ACK_request_Add_userID*/
               /*channel=0x06, sequence=0x0001, length=x0007, command=0x62, flag=0xff */
               /*Set header*/
               buffer_write[0] = 0x06;
               buffer_write[1] = 0x00;
               buffer_write[2] = 0x01;
               buffer_write[3] = 0x00;
               buffer_write[4] = 0x07;
               buffer_write[5] = 0x62;
               buffer_write[6] = 0xff;
               length = 8;//7+1
               if( write(client_fd, buffer_write, length) <= 0)
               {
                 fprintf(stdout, "Write ACK_request_add_userID error");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 break;
               }

               /*Read information add new user*/
               if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
               {
                 fprintf(stdout,"Read information add userID Error\n");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 return NULL;
               }
               
               if( (buffer_read[0] == 0x06) && (buffer_read[5] == 0x65) )
               {
                 /*Register to Database*/
                 /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
                 length_data = compute_length(buffer_read[3], buffer_read[4]) - 7; //7=header
                 check_add = new_add_userID(client_fd, buffer_read, length_data, inet_ntoa(client_addr.sin_addr));
               }         
             }        
             else if(buffer_read[5] == 0x63)
             {
               /*Show Command*/
               fprintf(stdout, "Command channel 6 = 0x63 = request_Add_email\n");

               /*Send ACK_request_Add_email*/
               /*channel=0x06, sequence=0x0001, length=x0007, command=0x64, flag=0xff */
               /*Set header*/
               buffer_write[0] = 0x06;
               buffer_write[1] = 0x00;
               buffer_write[2] = 0x01;
               buffer_write[3] = 0x00;
               buffer_write[4] = 0x07;
               buffer_write[5] = 0x64;
               buffer_write[6] = 0xff;
               length = 8;//7+1
               if( write(client_fd, buffer_write, length) <= 0)
               {
                 fprintf(stdout, "Write ACK_request_add_email error");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 break;
               }

               /*Read information add new email*/
               if( read(client_fd, buffer_read, MAX_MESSAGE) <= 0)
               {
                 fprintf(stdout,"Read information add email Error\n");
                 disconnect(inet_ntoa(client_addr.sin_addr));
                 return NULL;
               }

               if( (buffer_read[0] == 0x06) && (buffer_read[5] == 0x65) )
               {
                 /*Register to Database*/
                 /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
                 length_data = compute_length(buffer_read[3], buffer_read[4]) - 7; //7=header
                 check_add = new_add_email(client_fd, buffer_read, length_data, inet_ntoa(client_addr.sin_addr));
               }
             }       
             break;         
    default :printf("Packet no channel\n");
  }

  disconnect(inet_ntoa(client_addr.sin_addr));
  close(client_fd);

  

  return NULL;
}

/***********************************************************************************/
int main()
{
  //Thread server
  pthread_t tid;

  //Sock server
  int sockfd;
  struct sockaddr_in server_addr;

  if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
  {
    perror("Socket error");
    exit(1);
  }

  server_addr.sin_family = AF_INET;
  server_addr.sin_port = htons(MYPORT);
  server_addr.sin_addr.s_addr = inet_addr("161.246.5.18");

  bzero(&(server_addr.sin_zero), 8);    // zero struct

  if(bind(sockfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1)
  {
    perror("bind error");
    exit(1);
  }

  if(listen(sockfd, BACKLOG) == -1)
  {
    perror("listen");
    exit(1);
  }

  fputc ('\n', stdout);
  fputc ('\n', stdout);
  printf("Server: Wait connection at \n");
  printf("Port:2546 \n");
  printf("Address:161.246.5.18 \n");
  fputc ('\n', stdout);

  while(1)
  {
    //Create Thread
    pthread_create(&tid, NULL, *thread_run, (void *)sockfd);

  }
  //pthread_join(tid, NULL);

  close(sockfd);
  exit(0);

}
