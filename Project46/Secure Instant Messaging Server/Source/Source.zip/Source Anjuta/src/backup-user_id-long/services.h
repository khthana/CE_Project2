#ifndef HEADER_SERVICES_H
#define HEADER_SERVICES_H 

#include "comman.h"
#include "rw_ran.h"


/*
  Check Email
*/
int spc_email_isvalid(const char *address) {
  int        count = 0;
  const char *c, *domain;
  static char *rfc822_specials = "()<>@,;:\\\"[]";

  /* first we validate the name portion (name@domain) */
  for (c = address;  *c;  c++) {
    if (*c == '\"' && (c == address || *(c - 1) == '.' || *(c - 1) == '\"')) {
      while (*++c) {
        if (*c == '\"') break;
        if (*c == '\\' && (*++c == ' ')) continue;
        if (*c <= ' ' || *c >= 127) return 0;
      }
      if (!*c++) return 0;
      if (*c == '@') break;
      if (*c != '.') return 0;
      continue;
    }
    if (*c == '@') break;
    if (*c <= ' ' || *c >= 127) return 0;
    if (strchr(rfc822_specials, *c)) return 0;
  }
  if (c == address || *(c - 1) == '.') return 0;

  /* next we validate the domain portion (name@domain) */
  if (!*(domain = ++c)) return 0;
  do {
    if (*c == '.') {
      if (c == domain || *(c - 1) == '.') return 0;
      count++;
    }
    if (*c <= ' ' || *c >= 127) return 0;
    if (strchr(rfc822_specials, *c)) return 0;
  } while (*++c);

  return (count >= 1);
}
void safe_printf(char *data){

    safestr_t fmt;

    fmt = SAFESTR_CREATE(data);

    safestr_printf(fmt);

    safestr_free(fmt);

}

/*
  Get data function
    buf = buffer of data obtian data from netword
    data = final data
    start = point begin get data
*/         
int get_data(char buf[], char data[], int start)
{
    int iptr = 0;
    unsigned char c;
    
    while(1)
    {
        c = buf[start];
        if(c == '$')
        {
            start++;
            data[iptr] = '\0';
            break;
        }
        else if( c < 0x25 || c > 0x9b || c == '\0' )  {
			fprintf(stdout, "             ");
			fprintf(stdout, "ERROR No. Data\n");
            return 0;
		}
          
        data[iptr] = c;
        start++;
        iptr++;
    }
    return start;
}

/*
  Before use make connect to DB
	Check DB 3 args**************************************************************
*/
int check_db3(char tempq[], char user_id[], char type_service[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	int check_query;
	int check_db = 1;
	int i;
	char query[MAX_MESSAGE];
	
		/*Check Imformation in the Database*/
		
		/*Connect to Database*/
        	isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        	if(isagmq_db == NULL)
        	{
            	fprintf(stdout, "Connect to Database Error");
            	return -1;
        	}
			
			/*Query*/
  			/*Select user_id*/
    			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, tempq);
     			strncat(query, user_id, FIX_USER_ID);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				//fprintf(stdout,"Query = %s\n", query);
       				mysql_query(isagmq_db, query);
       				res_set = mysql_store_result(isagmq_db);

       				row = mysql_fetch_row(res_set);
       				if( row == NULL) {
						fprintf(stdout, "%s   Can %s \n", user_id, type_service);
						return 1;
					}
					else 
						return 0;					
       			
       			mysql_free_result(res_set);
				}	
     			else if(check_query == 0) {
       				fprintf(stdout, "%s   Can't %s \n", user_id,  type_service);
         			return 0;
     			}
     			else {
        			/*Send NACK  DB system error*/
					fprintf(stdout,"%s             DB system error\n", type_service);
					return -1;
     			}

end_check_register:
			
}

/*
	Before use not make connect to DB
	Check DB 5 args**************************************************************
*/
int check_db5(char tempq1[], char user_id[], char tempq2[],char user_id_contact[],char type_service[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
	int check_query;
	int check_db = 1;
	int i;
	char query[MAX_MESSAGE];
	
			
			/*Query*/
  			/*Select user_id*/
    			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, tempq1);
     			strncat(query, user_id, FIX_USER_ID);
				strcat(query, tempq2);
				strncat(query, user_id_contact, FIX_USER_ID);
				//fprintf(stdout,"Query = %s\n", query);
				
     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				//fprintf(stdout,"Query = %s\n", query);
       				mysql_query(isagmq_db, query);
       				res_set = mysql_store_result(isagmq_db);

       				row = mysql_fetch_row(res_set);
       				if( row == NULL) {
						fprintf(stdout, "%s   Can %s \n", user_id, type_service);
						return 1;
					}
					else 
						return 0;					
       			
       			mysql_free_result(res_set);
				}	
     			else if(check_query == 0) {
       				fprintf(stdout, "%s   Can't %s \n", user_id,  type_service);
         			return 0;
     			}
     			else {
        			/*Send NACK  DB system error*/
					fprintf(stdout,"%s             DB system error\n", type_service);
					return -1;
     			}			
}

/*
	Register Service********************************************************
*/
void new_user(SSL *ssl, char *buffer_read, char *ip_client, unsigned long user_id)
{
    unsigned char buffer[MAX_MESSAGE];
    int i;
    int check_infor = 1;
    int check_db = 1;
	int check;

    char query[MAX_MESSAGE];
    int check_query = 0;

    int point = 0;
	char cuser_id[FIX_USER_ID + 1];
    char frist_name[64];
    char last_name[64];
    char temp[64];
	char nick_name[64];
    char sex[1];
    char age[3];
    char email[64];
   
		if(buffer_read[5] == 0x10)
    	{		
			itoa_base10(user_id, cuser_id);		
			check = check_db3("SELECT USER_ID FROM user WHERE USER_ID = ", cuser_id, "Register");
				if(check != 1) {
					fprintf(stdout, "             Can't register \n");
					write_err_message(ssl, 0x00, "Can't register");
					goto end_new;
				}
				
			/*Send ACK_request_register*/
        	/*channel=0x01, sequence=0x0001, length=x0007, command=0x11, flag=0xff */
        	/*Set header*/
        	buffer[0] = 0x01;
        	buffer[1] = 0x00;
        	buffer[2] = 0x01;
        	buffer[3] = 0x00;
       	 	buffer[4] = 0x07;
       		buffer[5] = 0x11;
        	buffer[6] = 0xff;

        	ssl_write(ssl, buffer, sizeof(buffer));        
    	}
    	else
    	{
			fprintf(stdout, "%d   ", user_id);
        	fprintf(stdout, "Command register incurrect \n");
			write_err_message(ssl, 0x10, "Command register incurrect");
        	goto end_new;
   	 	}
		
    	/*Read information from new user*/
    	ssl_read(ssl, buffer, sizeof(buffer));
    
    	if( (buffer[0] == 0x01) && (buffer[5] == 0x12) )
    	{
        	/*
         Get information from user and check valid of information
       */
        	/*Get frist_name*/
            	point = FIX_HEADER + 1;
            	point = get_data(buffer, frist_name, point);
            	if(!point)
                	write_err_message(ssl, 0x02, "FRIST NAME INVALID");
            	else {
                	//Check frist name
                	//if(!check_frist_name)
                	//    write_err_message(ssl, 0x02, "FRIST NAME INVALID");
                	//else
                    	//fprintf(stdout, "Frist Name: %s\n", frist_name);
            	}
			/*Get last_name*/
            	point = get_data(buffer, last_name, point);
            	if(!point)
                	write_err_message(ssl, 0x03, "LAST NAME INVALID");
            	else {
                	//Check frist name
                	//if(!check_last_name)
                	//    write_err_message(ssl, 0x02, "LAST NAME INVALID");
                	//else
                    	//fprintf(stdout, " Last Name: %s\n", last_name);
            	} 
			/*Get last_name*/
            	point = get_data(buffer, nick_name, point);
            	if(!point)
                	write_err_message(ssl, 0x03, "NICK NAME INVALID");
            	else {
                	//Check frist name
                	//if(!check_last_name)
                	//    write_err_message(ssl, 0x02, "LAST NAME INVALID");
                	//else
                    	//fprintf(stdout, " Last Name: %s\n", last_name);
            	} 
				
        	/*Get sex*/
            	point = get_data(buffer, sex, point);
            	//fprintf(stdout, "       sex: %s\n", sex);
           
        	/*Get age*/
            	point = get_data(buffer, age, point);
            	//fprintf(stdout, "       age: %s\n", age);
         
        	/*Get email*/
            	point = get_data(buffer, email, point);
            	if(!point) {
                	write_err_message(ssl, 0x06, "EMAIL INVALID :Insert valid email and register again");
                	fprintf(stdout, "%d   ", user_id);
					fprintf(stdout, "EMAIL INVALID\n");
					goto end_new;
            	}
            	else {
               		/*Check email*/
                	if(!spc_email_isvalid(email)) {
                    	write_err_message(ssl, 0x06, "EMAIL INVALID :Insert valid email and registor again");
                    	fprintf(stdout, "User:%d Email Invalid\n", user_id);
                    	fprintf(stdout, "%d   ", user_id);
						fprintf(stdout, "EMAIL INVALID\n");
						goto end_new;
               		}
            	}	       
    		}	
			else {
				fprintf(stdout, "             Command Send Information Incurrect\n");
				write_err_message(ssl, 0x00, "Command Send Information Incurrect");
				goto end_new;
			}
     
    	/*
      Insert information of user to Database
    */
    	/*Connect to Database*/
        	isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        	if(isagmq_db == NULL)
        	{
				fprintf(stdout, "%d   ", user_id);
            	fprintf(stdout, "Register Connect to Database Error\n");
				write_err_message(ssl, 0x00, "DB System Error");
				goto end_new;
        	}
        
        	/*Query user*/
        	/*Set query*/
        	for(i=0;i < MAX_MESSAGE;i++)
            	query[i] = '\0';
        	strcpy(query, "INSERT INTO user VALUES('");
        	strcat(query, cuser_id);
        	strcat(query, "', '");
        	strcat(query, frist_name);
        	strcat(query, "', '");
        	strcat(query, last_name);
        	strcat(query, "', '");
			strcat(query, nick_name);
        	strcat(query, "', '");
        	strcat(query, sex);
        	strcat(query, "', '");
        	strcat(query, age);
        	strcat(query, "', '");
        	strcat(query, email);
        	strcat(query, "')");
        	//fprintf(stdout, "Query: %s\n", query);

     		/*Process sql command*/
			check_query = process_query(isagmq_db, query);
		
			/*Disconnect MySQL*/
			do_disconnect(isagmq_db);
     
			if( (check_query != 0) || (check_query == -1) )
     		{
        		fprintf(stdout, "%d   ", user_id);
				fprintf(stdout, "Insert Information of User error \n");
				write_err_message(ssl, 0x00, "DB System Error");
        		goto end_new;
			}
     		else {
				fprintf(stdout, "%d   ", user_id);
        		fprintf(stdout, "Insert Information of User Correct \n");
			}
	
		/*Send send user_id*/
        /*channel=0x01, sequence=0x0001, length=x0007, command=0x13, flag=0xff */
        /*Set header*/
        	buffer[0] = 0x01;
        	buffer[1] = 0x00;
        	buffer[2] = 0x01;
        	buffer[3] = 0x00;
       	 	buffer[4] = 0x07;
       		buffer[5] = 0x13;
        	buffer[6] = 0xff;
			
			for(i = 0;i < FIX_USER_ID;i++)	{
					buffer[i+1 + FIX_HEADER] = cuser_id[i];
					buffer[i+2 + FIX_HEADER] = '$';
			}

        	ssl_write(ssl, buffer, sizeof(buffer));
			
        	//write_err_message(ssl, 0x00,"Registor OK...........");
        	fprintf(stdout, "%d   ", user_id);
			fprintf(stdout, "Register OK\n");
        	fprintf(stdout, "                User_id: %d\n", user_id);
        	fprintf(stdout, "             Frist Name: %s\n", frist_name);
        	fprintf(stdout, "              Last Name: %s\n", last_name);
        	fprintf(stdout, "                    Sex: %s\n", sex);
        	fprintf(stdout, "                    Age: %s\n", age);
        	fprintf(stdout, "                  Email: %s\n", email);
    	
end_new:
		
}

/*
	Add Contactlist with Email Service*******************************************
*/
int add_contactlist(SSL *ssl, char *buffer_read, unsigned long user_id)
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	int point = 0;
  	int contact_online = 0; 
	char cuser_id[FIX_USER_ID + 1];	
  	char email_contact[64];
	unsigned long  user_id_contact = 0;
  	char cuser_id_contact[FIX_USER_ID + 1];
  	char query[MAX_MESSAGE];
  	char ip_contact[FIX_IP];
	char ch;
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	
			if(buffer_read[5] == 0x32)
        	{
               	/*Show Command*/
               	//fprintf(stdout, "Command channel 3 = 0x32 = request_add_con_email\n");

               	/*Send ACK_request_Add_con_email*/
               	/*channel=0x03, sequence=0x0001, length=x0007, command=0x34, flag=0xff */
               	/*Set header*/
               	buffer[0] = 0x03;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x07;
               	buffer[5] = 0x34;
               	buffer[6] = 0xff;
								
            	ssl_write(ssl, buffer, sizeof(buffer));				
			}
    		else {
				fprintf(stdout, "%d   ", user_id);           
        		fprintf(stdout, "Command add incorrect\n");
        		goto end_add;
   	 		}
						
    		/*Read information from add_contactlist*/
    		ssl_read(ssl, buffer, sizeof(buffer));
    		
    		if( (buffer[0] == 0x03) && (buffer[5] == 0x36) )
    		{
        		/*Convert user_id to string*/
					itoa_base10(user_id, cuser_id);
				
			/*
         Get information from user and check valid of information
       */
  				
			/*Get contact email*/
            	point = FIX_HEADER + 1;			
				point = get_data(buffer, email_contact, point);
            	if(!point) {
					//fprintf(stdout, "get data error\n");
                	write_err_message(ssl, 0x30, "EMAIL Contactlist INVALID :Send valid email and add_contactlist again");
                	fprintf(stdout, "%d   ", user_id);
					fprintf(stdout, "EMAIL Contactlist INVALID\n");
					goto end_add;
            	}
            	else {
               		/*Check email*/
                	if(!spc_email_isvalid(email_contact)) {
                    	write_err_message(ssl, 0x30, "EMAIL Contactlist INVALID :Send valid email and add_contactlist again");
                    	fprintf(stdout, "%d   ", user_id);
						fprintf(stdout, "EMAIL Contactlist INVALID\n");
						goto end_add;
               		}
            	}	   
  
  		/*get user_id_contact*/
    		/*Connect to Database*/
        	isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        	if(isagmq_db == NULL)
        	{
				fprintf(stdout, "%d   ", user_id);
            	fprintf(stdout, "Add Connect to Database Error");
            	check_db = 0;
				goto end_add;
        	}

  			/*Query*/
  			/*Select user_id_contact*/
    		for(i=0;i < MAX_MESSAGE;i++)
       			query[i] = '\0';
     		strcpy(query, "SELECT USER_ID FROM user WHERE EMAIL = '");
     		strncat(query, email_contact, strlen(email_contact));
			strncat(query, "'", 1);
			//fprintf(stdout, "Query  %s\n", query);
			
     		check_query = process_query(isagmq_db, query);
     		if( check_query == 1)
     		{
       			//fprintf(stdout,"Query = %s\n", query);
       			mysql_query(isagmq_db, query);
       			res_set = mysql_store_result(isagmq_db);

       			row = mysql_fetch_row(res_set);
       			if( row == NULL) {
					write_err_message(ssl, 0x31, "Can't find email Contactlist :Send email and add_contactlist again\n");
         			fprintf(stdout, "%d   ", user_id);
					fprintf(stdout, "No. row = null of Email = %s\n", email_contact);
					goto end_add;
				}
			       
       		/*Only one row, one column(user_id)*/
       		/*get user_id_contact, row[0] = fields 1 of row**/
        		for(i = 0;i < 10;i++)
           			cuser_id_contact[i] = '\0';
         		strncpy(cuser_id_contact, row[0], FIX_USER_ID);
				/*Convert user_id to long int*/
				user_id_contact = atoi(cuser_id_contact);
         		//fprintf(stdout, "user_id_contact:%s\n", user_id_contact);	
				
       			mysql_free_result(res_set);
			}	
     		else if(check_query == 0)
     		{
       			/*Send NACK  No. this email Contactlist*/
				write_err_message(ssl, 0x31, "Can't find email Contactlist :Send email and add_contactlist again\n");
         		fprintf(stdout, "%d   ", user_id);
				fprintf(stdout,"No. Result of Email = %s\n", email_contact);
         		goto end_add;
     		}
     		else
     		{
        		/*Send NACK  DB system error*/
				write_err_message(ssl, 0x32, "DB system error :Can't reply add_contactlist service\n");
         		fprintf(stdout, "%d   ", user_id);
				fprintf(stdout,"DB system error\n");
				goto end_add;
     		}
			
		/*Check user_id_contact in contactlistBD*/
			if(!check_db5("SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ", cuser_id, " AND CONTACT_ID = ", cuser_id_contact, "Add_contactlist"))
			{
				fprintf(stdout, "%d   ", user_id);
				fprintf(stdout, "Can not add %d\n", user_id_contact);
				for(i = 0;i < MAX_MESSAGE;i++)
					temp[i] = '\0';
				strcpy(temp, "Can't add this email :");
				strcat(temp, email_contact);
				write_err_message(ssl, 0x00, temp);				
				goto end_add;
			}
            
     	/*Record to contactlist*/
       		for(i=0;i < MAX_MESSAGE;i++)
         		query[i] = '\0';
       		strcpy(query, "INSERT INTO contact_list VALUES('");
       		strcat(query, cuser_id);
       		strcat(query, "', '");
       		strcat(query, user_id_contact);
       		strcat(query, "')");   
       		//fprintf(stdout, "Query: %s\n", query);
			
       		check_query = process_query(isagmq_db, query);
       		if( (check_query != 0) || (check_query == -1) )
       		{
				write_err_message(ssl, 0x32, "DB system error :Add_contactlist again\n");
         		fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Insert Contactlist of User error\n");
         		goto end_add;
       		}
			else {
				fprintf(stdout, "%s   ", user_id);
       			fprintf(stdout, "Insert Contactlist of User Correct\n");
			}
			/*Disconnect MySQL*/
     		do_disconnect(isagmq_db); 
    		
			/*get ip_contact from linked list*/
				/*Check status contact online or not, travel link list*/         	
				contact_online = find(user_id_contact, ip_contact);				
			
			if(contact_online)
			{
			/*Send ACK_Add_complet to user, and ip new contact*, and contact online/
    		/*channel=0x03, sequence=0x0001, length=x0007, command=0x38, flag=0xff */
    		/*Set header*/
      			buffer[0] = 0x03;
      			buffer[1] = 0x00;
      			buffer[2] = 0x01;
      			buffer[3] = 0x00;
      			buffer[5] = 0x38;
      			buffer[6] = 0xff;
				
				/*Send new user_id-ip$ contact to client*/
					for(i = 0;i < MAX_MESSAGE;i++)
						temp[i] = '\0';
					strncpy(temp, user_id_contact, FIX_USER_ID);
					strcat(temp, ip_contact);					
					
					i = 0;
					while(i < (FIX_USER_ID + FIX_IP) )
					{
						if(temp[i] == '\0')
							break;
						buffer[FIX_HEADER + i + 1] = temp[i];
						buffer[FIX_HEADER + i + 2] = '$';
						i++;
					}
					
					ssl_write(ssl, buffer, sizeof(buffer));
			}
			else //contact off line
			{
				fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Contact list %s off line\n",user_id_contact);
				
				/*Set header*/
      			buffer[0] = 0x03;
      			buffer[1] = 0x00;
      			buffer[2] = 0x01;
      			buffer[3] = 0x00;
      			buffer[5] = 0x3a;
      			buffer[6] = 0xff;
				
				/*Send new user_id$ contact to client*/
					for(i = 0;i < MAX_MESSAGE;i++)
						temp[i] = '\0';
					strncpy(temp, user_id_contact, FIX_USER_ID);				
					
					i = 0;
					while(i < FIX_USER_ID  )
					{
						if(temp[i] == '\0')
							break;
						buffer[FIX_HEADER + i + 1] = temp[i];
						buffer[FIX_HEADER + i + 2] = '$';
						i++;
					}
					
					ssl_write(ssl, buffer, sizeof(buffer));				
			}
		}
		else {
			fprintf(stdout, "%s   ", user_id);
			fprintf(stdout, "Header Invalid %\n");			
		}			
  
end_add:
			
     return 1;
}

/*
	Login Service**********************************************************
*/
int add_ip(char user_id_contact[],char contact_list[])
{
	int i;
	int contact_online;
	char ip_contact[FIX_IP];
	
		/*get ip_contact from linked list*/
			/*Check status contact online or not, travel link list*/         	
			for(i = 0;i < FIX_IP;i++)
						ip_contact[i] = '\0';
			contact_online = find(user_id_contact, ip_contact);	
			
			if(contact_online)
			{
				/*get ip$ contact*/
					strncat(contact_list, "-", 1);
					strcat(contact_list, ip_contact);	
					strncat(contact_list, "$", 1);
				return 1;				
			}
			else {
				strncat(contact_list, "-F$", 3);
				//fprintf(stdout, "Contact list %s offline\n",user_id_contact);
				return 0;
			}
}

void login(SSL *ssl, char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	char	contact_list[MAX_MESSAGE];
  	char query[MAX_MESSAGE];
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	
	
    	/*Ack, if commamd = request_login = 0x21 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x21)
             {
             	/*Show Command*/
               	//fprintf(stdout, "Command channel 2 = 0x21 = request_login\n");

               	/*Send ACK_request_login*/
               	/*channel=0x02, sequence=0x0001, length=x0007, command=0x22, flag=0xff */
               	/*Set header*/
               	buffer[0] = 0x02;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x07;
               	buffer[5] = 0x22;
               	buffer[6] = 0xff;
               	
				ssl_write(ssl, buffer, sizeof(buffer));
				
			}
    		else
    		{
				fprintf(stdout, "%s   ", user_id);
        		fprintf(stdout, "Command login incorrect\n");
        		goto end_login;
   	 		}
			
			/*Read request contactlist*/
    		ssl_read(ssl, buffer, sizeof(buffer));
    		
    		if( (buffer[0] == 0x02) && (buffer[5] == 0x23) )
    		{
				/*find contactlist*/
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Login Connect to Database Error");
            		check_db = 0;
					goto end_login;
        		}
				
				//fprintf(stdout, "%s Login \n", user_id);
				
				/*Find contractlist from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ");
     			strncat(query, user_id, FIX_USER_ID);
     			//fprintf(stdout, "Query: %s\n", query);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				for(i = 0;i < MAX_MESSAGE;i++)
         				contact_list[i] = '\0';

       				mysql_query(isagmq_db, query);
      				res_set = mysql_store_result(isagmq_db);
       				while( (row = mysql_fetch_row(res_set)) != NULL )
       				{
         				for (i = 0; i < mysql_num_fields(res_set); i++)
         				{
							/*should you check MAX contact_list buffer*/
           					if( row[i] != NULL) {
             					strcat(contact_list, row[i]);
								fprintf(stdout, "%s   ", user_id);
								add_ip(row[i], contact_list);								
           					}
           					//printf ("%s", row[i] != NULL ? row[i] : "NULL");
         				}
						strncat(contact_list, "$", 1);
       				}		
					
					fprintf(stdout, "%s   ", user_id);
					fprintf (stdout, "Contact list = %s\n", contact_list);
       			
       			mysql_free_result(res_set);
    			}
     			else if ( check_query == 0)
     			{
       				//Send NACK  No. this userID
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"No. this userID = %s\n", user_id);
         			/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
					goto end_login;
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error\n", user_id);
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_login;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 
				
				/*Send contact list to client*/
					/*Set header*/
      				buffer[0] = 0x02;
      				buffer[1] = 0x00;
      				buffer[2] = 0x01;
      				buffer[3] = 0x00;
      				buffer[5] = 0x24;
      				buffer[6] = 0xff;
				
					i = 0;
					while(i < MAX_MESSAGE  )
					{
						if(contact_list[i] == '\0')
							break;
						buffer[FIX_HEADER + i + 1] = contact_list[i];
						i++;
					}					
					ssl_write(ssl, buffer, sizeof(buffer));					
			}
			else {
				fprintf(stdout, "%s   ", user_id);
				fprintf(stdout, "Login Command error\n");
			}
            
end_login:
			 
}

/*
	Status Update Service********************************************************
*/
void status(SSL *ssl, char *buffer_read, char user_id[])
{
	MYSQL_RES *res_set;
 	MYSQL_ROW row;
  
	unsigned char buffer[MAX_MESSAGE];
	unsigned char temp[MAX_MESSAGE];
	
  	char	contact_list[MAX_MESSAGE];
  	char query[MAX_MESSAGE];
  	unsigned int i;
  	int check_query;
	int check_db = 1;
	
	
    	/*Ack, if commamd = request_status = 0x51 (byte order = 5)
           or not end function*/
             if(buffer_read[5] == 0x51)
             {
             	/*Show Command*/
               	//fprintf(stdout, "Command channel 5 = 0x51 = request_status\n");

               	
				/*find contactlist*/
				/*Connect to Database*/
        		isagmq_db = do_connect (DEF_HOST_NAME, DEF_USER_NAME, DEF_PASSWORD, DEF_DB_NAME,
                	                					DEF_PORT_NUM, DEF_SOCKET_NAME, 0);

        		if(isagmq_db == NULL)
        		{
					fprintf(stdout, "%s   ", user_id);
            		fprintf(stdout, "Status Connect to Database Error");
            		check_db = 0;
					goto end_status;
        		}
				
				//fprintf(stdout, "%s status \n", user_id);
				
				/*Find contractlist from DB*/
     			for(i=0;i < MAX_MESSAGE;i++)
       				query[i] = '\0';
     			strcpy(query, "SELECT CONTACT_ID FROM contact_list WHERE USER_ID = ");
     			strncat(query, user_id, FIX_USER_ID);
     			//fprintf(stdout, "Query: %s\n", query);

     			check_query = process_query(isagmq_db, query);
     			if( check_query == 1)
     			{
       				for(i = 0;i < MAX_MESSAGE;i++)
         				contact_list[i] = '\0';

       				mysql_query(isagmq_db, query);
      				res_set = mysql_store_result(isagmq_db);
       				while( (row = mysql_fetch_row(res_set)) != NULL )
       				{
         				for (i = 0; i < mysql_num_fields(res_set); i++)
         				{
							/*should you check MAX contact_list buffer*/
           					if( row[i] != NULL) {
								strcat(contact_list, row[i]);
								fprintf(stdout, "%s   ", user_id);
								add_ip(row[i], contact_list);
           					}
           					//printf ("%s", row[i] != NULL ? row[i] : "NULL");
         				}
						strncat(contact_list, "$", 1);
       				}       				
					//fprintf (stdout, "%s Contact list = %s\n", user_id, contact_list);
       			
       			mysql_free_result(res_set);
    			}
     			else if ( check_query == 0)
     			{
       				//Send NACK  No. this userID
         			fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"No. this userID = %s\n", user_id);
         			/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
					goto end_status;
     			}
     			else {
					fprintf(stdout, "%s   ", user_id);
					fprintf(stdout,"DB system error %s\n", user_id);
					/*Disconnect MySQL*/
     				do_disconnect(isagmq_db); 
       				goto end_status;
				}
				
				/*Disconnect MySQL*/
     			do_disconnect(isagmq_db); 				 
				
				/*Send response_status*/
               	/*channel=0x05, sequence=0x0001, length=x0007, command=0x52, flag=0xff */
               	/*Set header*/
				 for(i=0;i < MAX_MESSAGE;i++)
       				buffer[i] = '\0';
				 
               	buffer[0] = 0x05;
               	buffer[1] = 0x00;
               	buffer[2] = 0x01;
               	buffer[3] = 0x00;
               	buffer[4] = 0x07;
               	buffer[5] = 0x52;
               	buffer[6] = 0xff;
				
				i = 0;
				while(i < MAX_MESSAGE  )
				{
					if(contact_list[i] == '\0')
						break;
					buffer[FIX_HEADER + i + 1] = contact_list[i];
					i++;
				}				
				
				ssl_write(ssl, buffer, sizeof(buffer));				
		}
    	else {
			fprintf(stdout, "%s   ", user_id);
    		fprintf(stdout, "Command status incorrect\n");
		}
            
end_status:
			 
}

#endif
