#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define   FIX_USER_ID     9

int main( )
{
	char user_id[] = "111111111";
	char nick_name[] = "AON--TUE";
 	
	/*File*/
	char *filename = "log.txt";
	FILE *log;
	
	int i;
	char tmp[512];
	
		for(i = 0;i < 512;i++)
			tmp[i] = '\0';			
	
		/*Open Log file*/
 	 	if ( (log = fopen(filename, "a") ) == NULL) { 
			perror(filename);
      		fprintf(stderr,"Something bad Open log file....");
			return -1; 
    	}
		strcpy(tmp, "User_id:");
		strncat(tmp, user_id, FIX_USER_ID);
		strncat(tmp, "\n", 1);
		if(fputs(tmp, log) == EOF) {
			fprintf(stderr,"Write User_id Error");
			return 0;
		}			
		
		strcpy(tmp, "Nick_name:");
		strcat(tmp, nick_name);
		strncat(tmp, "\n", 1);
		if(fputs(tmp, log) == EOF) {
			fprintf(stderr,"Write Nick_name Error");
			return 0;			
		}			
	
		fclose(log);
		return 1;
}
