#include <stdio.h> // printf
#include <assert.h> // assert
#include <stdlib.h> // atol
#include <errno.h>



unsigned char convert_high(unsigned char x)
{
	unsigned char tmp;
	switch(x)
	{
		case '0' :tmp = 0x00;
		                break;
		case '1' :tmp = 0x10;
		                break;
		case '2' :tmp = 0x20;
		                break;
		case '3' :tmp = 0x30;
		                break;	
		case '4' :tmp = 0x40;
		                break;
		case '5' :tmp = 0x50;
		                break;
		case '6' :tmp = 0x60;
		                break;
		case '7' :tmp = 0x70;
		                break;
		case '8' :tmp = 0x80;
		                break;
		case '9' :tmp = 0x90;
		                break;
		case 'a' :tmp = 0xa0;
		                break;
		case 'b' :tmp = 0xb0;
		                break;	
		case 'c' :tmp = 0xc0;
		                break;
		case 'd' :tmp = 0xd0;
		                break;
		case 'e' :tmp = 0xe0;
		                break;
		case 'f' :tmp = 0xf0;
		                break;
		default: tmp= 0x45;
	}
	return tmp;
}
unsigned char convert_low(unsigned char y)
{
	unsigned char tmp1;
	switch(y)
	{
		case '0' :tmp1 = 0x00;
		                break;
		case '1' :tmp1 = 0x01;
		                break;
		case '2' :tmp1 = 0x02;
		                break;
		case '3' :tmp1 = 0x03;
		                break;	
		case '4' :tmp1 = 0x04;
		                break;
		case '5' :tmp1 = 0x05;
		                break;
		case '6' :tmp1 = 0x06;
		                break;
		case '7' :tmp1 = 0x07;
		                break;
		case '8' :tmp1 = 0x08;
		                break;
		case '9' :tmp1 = 0x09;
		                break;
		case 'a' :tmp1 = 0x0a;
		                break;
		case 'b' :tmp1 = 0x0b;
		                break;	
		case 'c' :tmp1 = 0x0c;
		                break;
		case 'd' :tmp1 = 0x0d;
		                break;
		case 'e' :tmp1 = 0x0e;
		                break;
		case 'f' :tmp1 = 0x0f;
		                break;
		default: tmp1= 0x45;
	}
	return tmp1;
}
void assign_value(unsigned char* hex,unsigned char* hex_r)
{
	int dec;
	dec = strlen(hex);

	if(dec==1){
		hex_r[0]='0';
		hex_r[1]='0';
		hex_r[2]='0';
		hex_r[3]=hex[0];
	}
	else if(dec==2){
		hex_r[0]='0';
		hex_r[1]='0';
		hex_r[2]=hex[0];
		hex_r[3]=hex[1];
	}
	else if(dec==3){
		hex_r[0]='0';
		hex_r[1]=hex[0];
		hex_r[2]=hex[1];
		hex_r[3]=hex[2];
	}
	else {
		hex_r[0]=hex[0];
		hex_r[1]=hex[1];
		hex_r[2]=hex[2];
		hex_r[3]=hex[3];
	}
}
void convert_sequence(int length,unsigned char hex_total[])
{
	 int i;
	unsigned char hex[4];
	 unsigned char cl[2],ch[2],hex_r[4];
	unsigned char tmp1,tmp2;

	sprintf(hex,"%x",length);
	printf("%s\n",hex);

	 assign_value(hex,hex_r);	
	
	for(i=0;i<2;i++)
	 ch[i]=hex_r[i];
	for(i=0;i<2;i++)
	 cl[i] = hex_r[2+i];

	tmp1 = convert_high(ch[0]);
	tmp2 = convert_low (ch[1]);
	hex_total[0] = tmp1+tmp2;

	tmp1 = convert_high(cl[0]);
	tmp2 = convert_low (cl[1]);
	hex_total[1] = tmp1+tmp2;
}

int main ()
{
	int dec;
	unsigned char hex_total[2];

	dec = 1;
	convert_sequence(dec,hex_total);
	
	fprintf(stdout,"%x\n",hex_total[0]);
	fprintf(stdout,"%x\n",hex_total[1]);

  return 0;
}
