#include  <sys/types.h> /* basic system data types */
#include  <sys/socket.h>  /* basic socket definitions */
#include  <sys/time.h>  /* timeval{} for select() */
#include  <time.h>    /* timespec{} for pselect() */
#include  <netinet/in.h>  /* sockaddr_in{} and other Internet defns */
#include  <arpa/inet.h>   /* inet(3) functions */
#include  <errno.h>
#include  <fcntl.h>   /* for nonblocking */
#include  <netdb.h>
#include  <signal.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>
#include  <sys/stat.h>  /* for S_xxx file mode constants */
#include  <sys/uio.h>   /* for iovec{} and readv/writev */
#include  <unistd.h>
#include  <sys/wait.h>
#include  <sys/un.h>    /* for Unix domain sockets */
#include <sys/select.h>  /* for convenience */

#define MAX_MESSAGE 512 //per packet

/***********************************************************************************/
/*Read Message*/
int read_message(int client_fd, char* buffer_read)
{
  int nread;
  

  /* First, read message from the socket. If
  read returns zero, the client closed the connection. */
  if ( (nread = read(client_fd, buffer_read, MAX_MESSAGE) ) == 0)
  {
    fprintf(stdout, "The client closed the connection.");
    return 0;
  }
  else if ( nread < 0 )
  {
    fprintf(stdout, "Read error");
    return 0;
  }

  return 1;
}

int write_message(int socket_fd, const char* message, int length)
{
  int nwrite;
  
  /* Write the string. */
  if( (nwrite = write (socket_fd, message, length)) < 0)
  {
    fprintf(stdout, "Write error");
    return 0;
  }
  return 1;
}

void new_user(int sockfd)
{
  int nwrite;
  int i;
  char infor[MAX_MESSAGE];
  unsigned int length;
  unsigned char buffer_user[MAX_MESSAGE];
  unsigned char user_id[5];
  int ptr=0;
  int iptr=0;

  for(i=0;i<=MAX_MESSAGE;i++)
    buffer_user[i] = '\0';
  /*request register = '1'*/
  /*channel 1, sequence 1, length 7, command 1, flag f, data null*/
  /*Set header*/
  buffer_user[0] = 0x01;
  buffer_user[1] = 0x00;
  buffer_user[2] = 0x01;
  buffer_user[3] = 0x00;
  buffer_user[4] = 0x07;
  buffer_user[5] = 0x01;
  buffer_user[6] = 0xff;
  length = 8; //7+1
  if( write(sockfd, buffer_user, length) <= 0)
  {
    fprintf(stdout, "Write request_register error");
    exit(0);
  }

  /*Receive ACK_request_register*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read ACK_request_register error");
    exit(0);
  }
  //fprintf(stdout, "buffer_user %d %d\n",buffer_user[0], buffer_user[5]);

  /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
  if( (buffer_user[0] = 0x01) && (buffer_user[5] = 0x02) )
  {
    /*Send send_information*/
    /*channel=0x01, sequence=0x0001, length, command=0x03, flag=0xff */
    /*Set header*/
    for(i=0;i<=MAX_MESSAGE;i++)
      buffer_user[i] = '\0';
      
    buffer_user[0] = 0x01;
    buffer_user[1] = 0x00;
    buffer_user[2] = 0x01;
    buffer_user[3] = 0x00;
    buffer_user[4] = 0x3c;
    buffer_user[5] = 0x03;
    buffer_user[6] = 0xff;
  
    strcpy(infor,"Adisak$Wangjanla$M$23$kasdiaon@hotmail.com$");
    for(i=0;i < 52;i++)
    {
      buffer_user[i+7] =  infor[i];
    }
          
    length = 8 + 52;
    if( write(sockfd, buffer_user, length) <= 0)
    {
      fprintf(stdout, "Write request_register error");
      exit(0);
    }
  }

  /*Receive USER_ID*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read User_ID error");
    exit(0);
  }
  user_id[5] = '\0';
  for(i=0;i<5;i++)
    user_id[i] = buffer_user[7 + i];
  fprintf(stdout, "User ID: %s\n", user_id);
  fprintf(stdout, "Register complet\n");
   
}

void add_contractlist(int sockfd)
{
  int nwrite;
  int i;
  char infor[MAX_MESSAGE];
  unsigned int length;
  unsigned char buffer_user[MAX_MESSAGE];
  unsigned char contract_user_id[5] = "31359";
  unsigned char email[64];
  int ptr=0;
  int iptr=0;

  for(i=0;i<=MAX_MESSAGE;i++)
    buffer_user[i] = '\0';
  /*request_Add_userID = 0x61*/
  /*channel 0x06, sequence 0x0001, length 0x0007, command 0x61, flag 0xff, data null*/
  /*Set header*/
  buffer_user[0] = 0x06;
  buffer_user[1] = 0x00;
  buffer_user[2] = 0x01;
  buffer_user[3] = 0x00;
  buffer_user[4] = 0x07;
  buffer_user[5] = 0x61;
  buffer_user[6] = 0xff;
  length = 8; //7+1
  if( write(sockfd, buffer_user, length) <= 0)
  {
    fprintf(stdout, "Write request_Add_userID error");
    exit(0);
  }

  /*Receive ACK_request_Add_userID*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read ACK_request_Add_userID error");
    exit(0);
  }
  //fprintf(stdout, "buffer_user %d %d\n",buffer_user[0], buffer_user[5]);

  /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
  if( (buffer_user[0] = 0x06) && (buffer_user[5] = 0x62) )
  {
    /*Send send_information*/
    /*channel=0x06, sequence=0x0001, length, command=0x65, flag=0xff */
    /*Set header*/
    for(i=0;i<=MAX_MESSAGE;i++)
      buffer_user[i] = '\0';
    buffer_user[0] = 0x06;
    buffer_user[1] = 0x00;
    buffer_user[2] = 0x01;
    buffer_user[3] = 0x00;
    buffer_user[4] = 0x0e;
    buffer_user[5] = 0x65;
    buffer_user[6] = 0xff;

    for(i=0;i<512;i++)
      infor[i] = '\0';
    strcpy(infor,"60345$31359$");
    for(i=0;i < 12;i++)
    {
      buffer_user[i+7] =  infor[i];
    }

    length = 8 + 12;
    if( write(sockfd, buffer_user, length) <= 0)
    {
      fprintf(stdout, "Write send_userID_Add error");
      exit(0);
    }
  }

  /*Receive Add_complet*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read Add_complet error\n");
    exit(0);
  }

  if( (buffer_user[0] = 0x06) && (buffer_user[5] = 0x67) )
  {
  
    for(i=0;i< 64;i++)
      email[i] = '\0';
    for(i=0;i<20;i++)
      email[i] = buffer_user[7 + i];
          
    fprintf(stdout, "User New-->Email:%s UserID:%s\n", email, contract_user_id);
    fprintf(stdout, "Register complet\n");
  }
}

void login(int sockfd)
{
  int nwrite;
  int i, j, k;
  char infor[MAX_MESSAGE];
  unsigned int length;
  unsigned char buffer_user[MAX_MESSAGE];
  unsigned char contractlist[512];
  unsigned char buff[20];
  unsigned char userID[5];
  unsigned char ip[15];
  int ptr=0;
  int iptr=0;
  
  for(i=0;i<=MAX_MESSAGE;i++)
    buffer_user[i] = '\0';
  /*request_login = 0x21*/
  /*channel 0x02, sequence 0x0001, length 0x0007, command 0x21, flag 0xff, data null*/
  /*Set header*/
  buffer_user[0] = 0x02;
  buffer_user[1] = 0x00;
  buffer_user[2] = 0x01;
  buffer_user[3] = 0x00;
  buffer_user[4] = 0x07;
  buffer_user[5] = 0x21;
  buffer_user[6] = 0xff;
  length = 8; //7+1

  if( write(sockfd, buffer_user, length) <= 0)
  {
    fprintf(stdout, "Write request_login error\n");
    exit(0);
  }
  //printf("Write request_login = %s\n", buffer_user);
  
  /*Receive ACK_request_login_userID*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read ACK_request_login error");
    exit(0);
  }
  //fprintf(stdout, "buffer_user %d %d\n",buffer_user[0], buffer_user[5]);

  /*channel 0, sequence 1-2, length 3-4, command 5, flag 6*/
  if( (buffer_user[0] = 0x02) && (buffer_user[5] = 0x22) )
  {
    /*Send send_userID_password*/
    /*channel=0x02, sequence=0x0001, length, command=0x23, flag=0xff */
    /*Set header*/
    for(i=0;i<=MAX_MESSAGE;i++)
      buffer_user[i] = '\0';
    buffer_user[0] = 0x02;
    buffer_user[1] = 0x00;
    buffer_user[2] = 0x01;
    buffer_user[3] = 0x00;
    buffer_user[4] = 0x18;
    buffer_user[5] = 0x23;
    buffer_user[6] = 0xff;

    for(i=0;i<512;i++)
      infor[i] = '\0';
    strcpy(infor,"60345$password$");
    for(i=0;i < 15;i++)
    {
      buffer_user[i+7] =  infor[i];
    }

    length = 8 + 15;
    if( write(sockfd, buffer_user, length) <= 0)
    {
      fprintf(stdout, "Write send_userID_password error");
      exit(0);
    }
  }

  /*Receive Contraclist*/
  if( read(sockfd, buffer_user, MAX_MESSAGE) <= 0)
  {
    fprintf(stdout, "Read Contractlist error\n");
    exit(0);
  }

  if( (buffer_user[0] = 0x02) && (buffer_user[5] = 0x24) )
  {

    for(i=0;i< 512;i++)
      contractlist[i] = '\0';
    //fprintf(stdout, "%d", buffer_user[4]);  
    for(i=0;i<buffer_user[4];i++)
      contractlist[i] = buffer_user[7 + i];
    fprintf(stdout, "-----Contractlist----\n");
    fprintf(stdout, "USER_ID         IP\n");

    i=0;
    j=0;
    k=0;
    while(contractlist[i] != '\0')
    {
         
       if(contractlist[i] == '$')
       {
         i++;
         fputc('\n', stdout);
       }
       else
       {
         fprintf(stdout, "%c", contractlist[i]);
         i++;
       }
  
    }
  }
}

int
connect_server()
{
   int sockfd, i;
   int addr_len;
   struct sockaddr_in address;

   int connect_res;

   sockfd= socket(AF_INET,SOCK_STREAM,0);
   if(sockfd<0) {
   printf("Socket error");
   exit(1);
   }

   address.sin_family = AF_INET;
   address.sin_addr.s_addr = inet_addr("161.246.5.18");
   address.sin_port = htons(2546);
   addr_len = sizeof(address);

   connect_res = connect(sockfd,(struct sockaddr*)&address,addr_len);
   if(connect_res<0)
   {
     perror("connection failed!");
     exit(1);
   }

   return sockfd;
}

int write_support(int sockfd)
{
  unsigned char buffer_user[10];
  int length = 10;
  int i;
  
  for(i=0;i<10;i++)
  {
    buffer_user[i]= '$';
  }
  /*Write message support Java (new OutputStream())*/
  if( write(sockfd, buffer_user, length) <= 0)
    {
      fprintf(stdout, "Write message support Java (new OutputStream()) error");
      return 0;
    }
  return 1;
}


int main()
{
   int sockfd, i;
   char menu;
   char userID[5];
   char password[64];
   //char ch='m';
   
   while(1)
   {
   
     printf("\n");
     printf("\n");

     printf("*************  Select Menu ************************\n");
     printf("n = New register : a = Add Contractlist : l = login\n");
     printf("                   q = Exit\n");
     menu = getchar();
     printf("\n");

     switch(menu)
     {
       case 'n':sockfd = connect_server();
                new_user(sockfd);
                close(sockfd);              
                break;
       case 'a':sockfd = connect_server();
                add_contractlist(sockfd);
                close(sockfd);
                break;
       case 'l':sockfd = connect_server();
                //printf("USER_ID  :\n");
                //gets(userID);
                //printf("Password :\n");
                //gets(password);
                //printf("%s %s\n", userID, password);
                //write_support(sockfd);
                printf("call login\n");
                login(sockfd);
                close(sockfd);
                break;
       case 'q':exit(0);
       default :break;                  
     }
     printf("\n");
     printf("\n");
   }
   
 }
 