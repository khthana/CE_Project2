var hash="RCQXSMPRC0NZgKscnlMWKQ==";hash = escape(hash).replace(/\+/g, "%2b");
var turlnameindex="jananet.com";
var page,thflag,udf="undefined",truehitsurl=document.URL;
try {
var truehitsurl_top = top.window.document.URL;
if( (!thflag)  && ( truehitsurl.indexOf(turlnameindex) > 0) &&(truehitsurl_top.indexOf(turlnameindex) > 0) ){
rf=escape("Hidden-Referrer");if((rf==udf)||(rf=="")){rf="bookmark";};
bn=navigator.appName;if(bn.substring(0,9)=="Microsoft"){bn="MSIE";};sv=1.1;ja=(navigator.javaEnabled()==true)?"y":"n";
document.ignore="verify=test; expire="+(new Date()).toGMTString();ck=(document.cookie.length>0)?"y":"n";
document.write("<script language=javascript1.2>sv=1.2;ss=screen.width+'*'+screen.height;sc=(bn=='MSIE')?screen.colorDepth:screen.pixelDepth;if(sc==udf){sc='na';}</script><script language=javascript1.3>sv=1.3;</script>");
arg="&bn="+bn+"&bv=4&ss="+ss+"&sc="+sc+"&sv="+sv+"&ck="+ck+"&ja="+ja+"&rf="+rf+"&web="+hash;
document.write("<a href='http://truehits.net/stat.php?login=jananet' target='_blank'><img src='http://truehits.gits.net.th/biggen.php?hc=b0001001"+arg+"&truehitspage="+page+"&truehitsurl="+truehitsurl+"' width=14 height=17 border=0></a>");
thflag=1;}} catch(e){}