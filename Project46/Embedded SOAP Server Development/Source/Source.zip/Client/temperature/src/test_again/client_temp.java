package test_again;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.event.*;
import org.apache.soap.*;
import org.apache.soap.rpc.*;
import com.borland.jbcl.layout.*;
import org.apache.soap.util.xml.*;
// Java extension packages
import org.w3c.dom.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.transport.http.SOAPHTTPConnection;

public class client_temp extends JFrame
{
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();
  private XYLayout xYLayout1 = new XYLayout();
  public JTextField jTextField1 = new JTextField();
  public JTextField jTextField2 = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();

  Thread a = new MyThread();
  public double temp ;
  double num1;
  double receive;
  double limit=0;
  int overheat=0;
  int temponly=0;
  int count=0;
  URL url;
  private JButton jButton4 = new JButton();
  private JButton jButton5 = new JButton();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JButton jButton6 = new JButton();
  private JLabel jLabel6 = new JLabel();

  public client_temp(String title) {
    super (title);
    try {
      jbInit();
      pack ();
      show ();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception
  {
     this.getContentPane().setLayout(xYLayout1);
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setToolTipText("");
    jButton1.setText("Request Temp");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("Temperature =");
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Celcuis");
    jButton2.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton2.setText("On");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    xYLayout1.setWidth(411);
    xYLayout1.setHeight(242);
    jButton3.setBackground(Color.orange);
    jButton3.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton3.setText("Off");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Limit Temp = ");
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("Celcuis");
    jTextField2.setText("40");
    jButton4.setFont(new java.awt.Font("Dialog", 3, 12));
    jButton4.setText("Connect");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    jButton5.setFont(new java.awt.Font("Dialog", 3, 12));
    jButton5.setText("Disconnect");
    jButton5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton5_actionPerformed(e);
      }
    });
    jLabel5.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel5.setText("Smoke  =");
    jButton6.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton6.setText("Request Smoke");
    jButton6.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton6_actionPerformed(e);
      }
    });
    jLabel6.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel6.setText("Fan ");
    this.getContentPane().add(jLabel3, new XYConstraints(41, 67, 80, 34));
    this.getContentPane().add(jTextField1, new XYConstraints(123, 28, 84, -1));
    this.getContentPane().add(jLabel1, new XYConstraints(35, 23, 100, 30));
    this.getContentPane().add(jTextField2, new XYConstraints(123, 69, 82, 24));
    this.getContentPane().add(jLabel2, new XYConstraints(215, 28, 58, 23));
    this.getContentPane().add(jLabel4, new XYConstraints(214, 70, 49, 24));
    this.getContentPane().add(jLabel5,      new XYConstraints(59, 111, 65, 25));
    this.getContentPane().add(jButton1,  new XYConstraints(272, 44, 122, 28));
    this.getContentPane().add(jButton6,    new XYConstraints(269, 108, 124, -1));
    this.getContentPane().add(jTextField3,  new XYConstraints(122, 111, 86, 25));
    this.getContentPane().add(jButton5, new XYConstraints(180, 197, 111, 28));
    this.getContentPane().add(jLabel6, new XYConstraints(76, 151, 40, 25));
    this.getContentPane().add(jButton4, new XYConstraints(52, 198, 111, -1));
    this.getContentPane().add(jButton2,  new XYConstraints(121, 150, 66, 28));
    this.getContentPane().add(jButton3, new XYConstraints(194, 150, 66, 28));


  }
  public double soap(double num,String method)
  {
            SOAPMappingRegistry smr = new SOAPMappingRegistry();
            StringDeserializer sd = new StringDeserializer();
            smr.mapTypes(Constants.NS_URI_SOAP_ENC,new QName("","Result"),null,null,sd);
            SOAPHTTPConnection st = new SOAPHTTPConnection();
            Call call = new Call();
            call.setSOAPTransport(st);
            call.setSOAPMappingRegistry(smr);
            call.setTargetObjectURI ("urn:xml-soap-demo-temperature");

            call.setMethodName(method);
            call.setEncodingStyleURI("http://schemas.xmlsoap.org/soap/encoding/");

            Vector params = new Vector();
            params.addElement (new Parameter("Num", double.class, new Double (num), null));
            call.setParams (params);
            Response resp = null;
            try
            {
                    resp = call.invoke (/* router URL */ url, /* actionURI */ "" );
            }
            catch(SOAPException ee)
            {
                    System.err.println("Caught SOAPException(" + ee.getFaultCode() + "):" + ee.getMessage());
                   // return;
            }

            if (resp == null)
            {
                    System.out.println("Response was null");
            }

            if(resp != null && !resp.generatedFault())
            {

                    Parameter result = resp.getReturnValue ();
                    temp = ((Double)result.getValue ()).doubleValue ();
            }
            else
            {
                    Fault fault = resp.getFault();
                    System.err.println("Generated fault : ");
                    System.out.println ("  Fault Code   = " + fault.getFaultCode ());
                    System.out.println ("  Fault String = " + fault.getFaultString ());
         }
     return(temp);
  }
  public void delay(int x)
  {
    for(int y=0 ; y<x ; y++);
  }
  void jButton1_actionPerformed(ActionEvent e)//request temp button
  {
        limit = Double.parseDouble(jTextField2.getText());
        receive = soap(limit,"temp");
        jTextField1.setText(String.valueOf(receive));

  }
  void jButton2_actionPerformed(ActionEvent e) //decrease temp button
  { // start fan
        temponly = 1;
        overheat = 1;
        limit = Double.parseDouble(jTextField2.getText());
        receive = soap(limit,"fan_on");
        jButton2.setBackground(Color.orange);
        jButton3.setBackground(Color.lightGray);
    //    JOptionPane.showMessageDialog(null,"MOTOR ON","INFORMATION",JOptionPane.INFORMATION_MESSAGE);
        if (count == 0)
          { a.start();
            a.setPriority(10);
            count++;  }
        else a.resume();
 }
  void jButton3_actionPerformed(ActionEvent e) //stop decrease button
  { //stop fan
        overheat = 0;
        limit = Double.parseDouble(jTextField2.getText());
        receive = soap(limit,"fan_off");
        jButton3.setBackground(Color.orange);
        jButton2.setBackground(Color.lightGray);
       // JOptionPane.showMessageDialog(null,"MOTOR OFF","INFORMATION",JOptionPane.INFORMATION_MESSAGE);
        a.suspend();
 }
  void jButton4_actionPerformed(ActionEvent e) //connect
  {
        overheat = 0;
        if (count == 0)
            { a.start();
              a.setPriority(10);
              count++;  }
        else
          {
              a.resume();
          }
  }

  void jButton5_actionPerformed(ActionEvent e)  //disconnect
  {
         //  jTextField1.setText(String.valueOf(receive));
            a.suspend();
  }

 void jButton6_actionPerformed(ActionEvent e) {
            receive = soap(limit,"smoke");
            if (receive == 1)
            {
                jTextField3.setText("Smoke");
            }
            else  jTextField3.setText("No Smoke");
 }

public class MyThread extends Thread{
    double limit;
    double receive=0;
    double smoke = 0 ;

    public void run()
    {
        while (true)
            {
               limit = Double.parseDouble(jTextField2.getText());
               if (temponly == 1)
               {
                 receive = soap(limit,"temp");
               }
               else
               {
                 smoke = soap(limit,"smoke");
                 receive = soap(limit,"temp");
               }

               if((smoke == 1) && (receive > limit))
               {
                   jTextField1.setText(String.valueOf(receive));
                   jTextField3.setText("Smoke");
                   Runtime rt1 = Runtime.getRuntime();
                   try{
                          rt1.exec("JSms1");
                          JOptionPane.showMessageDialog(null,"SMOKE & TEMPERATURE OVERHEAT","WARNING",JOptionPane.ERROR_MESSAGE);
                          a.suspend();
                   }catch(Exception ex){
                          ex.printStackTrace();
                  }
               }

               if (smoke == 1)
               {
                    jTextField3.setText("Smoke");
                    Runtime rt2 = Runtime.getRuntime();
                    try{
                          rt2.exec("JSms2");
                          JOptionPane.showMessageDialog(null,"SMOKE","WARNING",JOptionPane.ERROR_MESSAGE);
                          a.suspend();
                    }catch(Exception ex){
                          ex.printStackTrace();
                    }
               }
               else  jTextField3.setText("No Smoke");

               if (receive > limit)
               {
              //     jTextField1.setText(String.valueOf(receive));
                   Runtime rt3 = Runtime.getRuntime();

                   if (overheat == 0){
                   try{
                          rt3.exec("JSms3");
                          JOptionPane.showMessageDialog(null,"TEMPERATURE OVERHEAT","WARNING",JOptionPane.ERROR_MESSAGE);
                          a.suspend();

                   }catch(Exception ex){
                          ex.printStackTrace();
                   }}
                }
               else
                 jTextField1.setText(String.valueOf(receive));

               try  {  sleep(5000);  }
               catch (InterruptedException e){}
             }
    }
  }



  public static void main( String args[] )throws Exception
  {
     client_temp application = new client_temp("READ TEMPERATURE");
     application.url = new URL ("http://161.246.6.63/soap/servlet/rpcrouter");
     application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
  }


}


