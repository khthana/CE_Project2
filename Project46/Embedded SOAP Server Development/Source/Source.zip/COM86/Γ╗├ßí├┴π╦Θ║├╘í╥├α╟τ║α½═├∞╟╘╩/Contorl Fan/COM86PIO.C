/******************************************************************************
 * FILE : COM86PIO.C
 *
 * DESC : PIOs
 * NOTE :
 *
 * TARGET : 16 bit Real Mode x86
 *
 * TOOLS : Turbo C 2.0 or higher
 *
 * CVS :
 *	$Revision: $
 *	$Name: $
 *	$Date: $
 *	$Author: $
 *	$Locker: $
 *
 *	$State: $
 *
 *	$Source: $
 *	$RCSfile: $
 *
 *-----------------------------------------------------------------------------
 *
 *	Copyright (c) 2001-2002 NetGadgets Co., Ltd.
 *
 ******************************************************************************
 */

#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include "com86pio.h"

int com86pio_init(int pio, int mode)
{
	unsigned int piomask;
	unsigned int m, d;

	if ((pio < 0) || (pio > 47))
		return COM86PIO_INVALID;
	piomask = 0x0001 << pio;
	if (pio < 16) { /* PIO0 - PIO15 */
		if (piomask & PIO_RESERVED0)
			return COM86PIO_RESERVED;
		m = inport(PIOMODE0);
		d = inport(PIODIR0);
		m = (m & ~piomask) | ((mode >> 1) << pio);
		d = (d & ~piomask) | ((mode & 0x0001) << pio);
		outport(PIOMODE0, m);
		outport(PIODIR0, d);
	}
	else if (pio < 32) { /* PIO16 - PIO31 */
		if (piomask & PIO_RESERVED1)
			return COM86PIO_RESERVED;
		m = inport(PIOMODE1);
		d = inport(PIODIR1);
		m = (m & ~piomask) | ((mode >> 1) << pio);
		d = (d & ~piomask) | ((mode & 0x0001) << pio);
		outport(PIOMODE1, m);
		outport(PIODIR1, d);
	}
	else if (pio < 48) { /* PIO32 - PIO48 */
		if (piomask & PIO_RESERVED2)
			return COM86PIO_RESERVED;
		m = inport(PIOMODE2);
		d = inport(PIODIR2);
		m = (m & ~piomask) | ((mode >> 1) << pio);
		d = (d & ~piomask) | ((mode & 0x0001) << pio);
		outport(PIOMODE2, m);
		outport(PIODIR2, d);
	}
	return COM86PIO_OK;
}

int com86pio_get(int pio, int *val)
{
	unsigned int piomask;
	if ((pio < 0) || (pio > 47))
		return COM86PIO_INVALID;
	piomask = 0x0001 << pio;
	if (pio < 16) {
		if (piomask & PIO_RESERVED0)
			return COM86PIO_RESERVED;
		*val = (inport(PIODATA0) & piomask) >> pio;
	}
	if (pio < 32) {
		if (piomask & PIO_RESERVED1)
			return COM86PIO_RESERVED;
		*val = (inport(PIODATA1) & piomask) >> pio;
	}
	if (pio < 48) {
		if (piomask & PIO_RESERVED2)
			return COM86PIO_RESERVED;
		*val = (inport(PIODATA2) & piomask) >> pio;		
	}
	return COM86PIO_OK;	
}

int com86pio_set(int pio, int val)
{
	unsigned int piomask;
	unsigned int d;

	if ((pio < 0) || (pio > 47))
		return COM86PIO_INVALID;
	piomask = 0x0001 << pio;
	if (pio < 16) {
		if (piomask & PIO_RESERVED0)
			return COM86PIO_RESERVED;
		d = (inport(PIODATA0) & piomask) | ((val & 0x0001) << pio);
		outport(PIODATA0, d);
	}
	if (pio < 32) {
		if (piomask & PIO_RESERVED1)
			return COM86PIO_RESERVED;
		d = (inport(PIODATA1) & piomask) | ((val & 0x0001) << pio);
		outport(PIODATA1, d);
	}
	if (pio < 48) {
		if (piomask & PIO_RESERVED2)
			return COM86PIO_RESERVED;
		d = (inport(PIODATA2) & piomask) | ((val & 0x0001) << pio);
		outport(PIODATA2, d);
	}
	return COM86PIO_OK;
}

/******************************************************************************
 * FOOT NOTES :
 *
 * FN#1 : This is a foot note
 *
 *-----------------------------------------------------------------------------
 * HISTORY:
 *
 * $Log: $
 *
 *-----------------------------------------------------------------------------
 * ENDOF  : COM86PIO.C
 ******************************************************************************
 */