/******************************************************************************
 * FILE : PIO01.C
 *
 * DESC : PIO Demontrate program for Com86 Tutorial 
 *
 * NOTE :
 *
 * TARGET : 16bit Real Mode x86
 *
 * TOOLS : Turbo C 2.0 or higher
 *
 * CVS :
 *	$Revision: $
 *	$Name: $
 *	$Date: $
 *	$Author: $
 *	$Locker: $
 *
 *	$State: $
 *
 *	$Source: $
 *	$RCSfile: $
 *
 *-----------------------------------------------------------------------------
 *
 *	Copyright (c) 2001-2002 NetGadgets Co., Ltd.
 *
 ******************************************************************************
 */


#include "d:\tc\ser01\am186cc.h"

#include<dos.h>
#include<stdio.h>
#include<conio.h>

typedef unsigned char BYTE;
typedef unsigned int WORD;
/**
 * main function for demontrate PIO of Com86 Development Board
 *
 * @param void
 *
 */
void InitSerial() 
{
	
	WORD SysconRegister ;
	WORD PIOMODE1Register, PIODIR1Register ;
	
	/* initital Serial Control Register -> Parity and Stop bit*/
	/* Parity = none , stop bit = 1*/
	
	outport(SPCON0, 0x60) ;
	
	/* initial Serial Baudrate Divisor Register */
	/* Baudrate = 57600 bps */
	
	outport(SPBDV, 0x1a) ;

}
void SendChar(char sout)
{
	WORD SPSTATRegister ;
	/* wait for ready to send*/
	do 
	{
	  SPSTATRegister = inport(SPSTAT) ;
	  /* check THRE bit*/
	  SPSTATRegister = SPSTATRegister & 0x0040 ;
	} while (SPSTATRegister<=0);
	outport(SPTXD, sout) ;
	/* wait for sending completion  */
	do 
	{
	  SPSTATRegister = inport(SPSTAT) ;
	  /* check TEMT bit */
	  SPSTATRegister = SPSTATRegister & 0x0004 ;
	} while (SPSTATRegister<=0) ;
}
void main(void)
{	
	char ch=49;
	InitSerial() ;
	printf("FAN ON");
	SendChar(ch) ;
}

/******************************************************************************
 * FOOT NOTES :
 *
 * FN#1 : This is a foot note
 *
 *-----------------------------------------------------------------------------
 * HISTORY:
 *
 * $Log: $
 *
 *-----------------------------------------------------------------------------
 * ENDOF  : PIO01.C
 ******************************************************************************
 */