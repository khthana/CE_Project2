.AUTODEPEND

.PATH.obj = ..\OBJ

#		*Translator Definitions*
CC = bcc +SERVERD.CFG
TASM = TASM
TLIB = tlib
TLINK = tlink
LIBPATH =D:\BORLANDC\LIB
INCLUDEPATH = D:\BORLANDC\INCLUDE;D:\WATTCP\INCLUDE


#		*Implicit Rules*
.c.obj:
  $(CC) -c {$< }

.cpp.obj:
  $(CC) -c {$< }

#		*List Macros*


EXE_dependencies =  \
 str.obj \
 server.obj \
 const.obj \
 ..\..\..\lib\wattcpsm.lib

#		*Explicit Rules*
..\obj\serverd.exe: serverd.cfg $(EXE_dependencies)
  $(TLINK) /x/P-/A=1024/L$(LIBPATH) @&&|
c0s.obj+
..\obj\str.obj+
..\obj\server.obj+
..\obj\const.obj
..\obj\serverd
		# no map file
..\..\..\lib\wattcpsm.lib+
emu.lib+
maths.lib+
cs.lib
|


#		*Individual File Dependencies*
str.obj: serverd.cfg ..\source\str.cpp 
	$(CC) -c ..\source\str.cpp

server.obj: serverd.cfg ..\source\server.cpp 
	$(CC) -c ..\source\server.cpp

const.obj: serverd.cfg ..\source\const.cpp 
	$(CC) -c ..\source\const.cpp

#		*Compiler Configuration File*
serverd.cfg: serverd.mak
  copy &&|
-1
-v
-vi-
-H=SERVERD.SYM
-wpro
-weas
-wpre
-n..\OBJ
-I$(INCLUDEPATH)
-L$(LIBPATH)
| serverd.cfg


