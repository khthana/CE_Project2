make -f soapserv.mak
del soapserv.cfg
upx ../obj/soapserv.exe

del ..\tmp\soapserv.exe
copy ..\obj\soapserv.exe ..\tmp\soapserv.exe