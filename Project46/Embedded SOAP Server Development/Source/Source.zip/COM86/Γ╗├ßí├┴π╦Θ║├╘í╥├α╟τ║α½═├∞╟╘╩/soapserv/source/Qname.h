// package 
// file name : Qname.h
#ifndef __QNAME_H
#define __QNAME_H
#include "..\source\Str.h"

class QName  
{
	private:
	Str namespaceURI;
	Str localPart;

	public:
	//Constructor
	QName()			{ }
	QName(const char *name, const char *ns) { set(name, ns); }
	QName(const QName& that)
	{
		namespaceURI=that.getNamespaceURI();
		localPart=that.getLocalPart();
	}
	//Destructor
	~QName() { }
	//Overload Operator
	QName& operator=(const QName& that);
	QName& operator=(const char *name);
	void clear()
	{
		namespaceURI.toDelete();
		localPart.toDelete();
	}
	void set(const char *name, const char *ns)
	{
		namespaceURI.set(name);
		localPart.set(ns);
	}
	int operator==(const QName& that) const
	{
		return (namespaceURI.isEqual(that.getNamespaceURI()) 
			&& localPart.isEqual(that.getLocalPart())) ? 1 : 0;
	}
	int operator==(const char *name) const
	{
		return (localPart.isEmpty() && namespaceURI.isEqual(name)) ? 1 : 0; 
	}
	const char* getNamespaceURI() const		{ return namespaceURI.getStr(); }
	//const Str getNamespaceURI() const		{ return namespaceURI; }
	void setNamespaceURI(const Str& that)	{ namespaceURI=that; }
	void setNamespaceURI(const char* string){ namespaceURI=string; }
	const char* getLocalPart() const 		{ return localPart.getStr(); }
	//const Str getLocalPart() const			{ return localPart; }
	void setLocalPart(const Str& that)		{ localPart=that; }
	void setLocalPart(const char* string)	{ localPart=string; }
	int isUndefined()
	{
		return (namespaceURI.isEmpty()) && (localPart.isEmpty()) ? 1 : 0;
	}
	char* toString();	
};

#endif