#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <conio.h>
#include "..\source\SoapDes.h"

const char* SOAPDeserialize::SERVICE="service";
const char* SOAPDeserialize::NAMESPACEID="namespaceid";
const char* SOAPDeserialize::INPUT="input";
const char* SOAPDeserialize::OUTPUT="output";
const char* SOAPDeserialize::PROVIDER="provider";
const char* SOAPDeserialize::MAPPING="mapping";
const char* SOAPDeserialize::MAP="map";
const char* SOAPDeserialize::XMLNS_X="xmlns:x";
const char* SOAPDeserialize::QNAME_A="qname";
const char* SOAPDeserialize::HEADERFILE="headerFile";
const char* SOAPDeserialize::XSI_TYPE="xsi:type";

const char* SOAPDeserialize::INT_S="xsd:int";
const char* SOAPDeserialize::DOUBLE_S="xsd:double";
const char* SOAPDeserialize::LONG_S="xsd:long";
const char* SOAPDeserialize::FLOAT_S="xsd:float";
const char* SOAPDeserialize::STRING_S="xsd:string";
//const char* CHAR__S="char* ";
const char* SOAPDeserialize::CHAR_S="xsd:char";
//const char* UNSIGNED_S="unsigned";
//const char* STATIC_S="static";
//const char* CONST_S="const";


void SOAPDeserialize::readServiceMap(const char* fileName)
{
	int i=0;
	char ch,a[1500];
	FILE *stream;
	stream=fopen(fileName,"r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>1500)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	a[i]='\0';
	fclose(stream);
	Attribute *attr;
	Str name,output,map;
	Parser *pr;
	ParseEvent *pe;
	pr=new Parser();
	pr->setXMLReader(a);
	pe=pr->read();
	name=pe->getName();
	char *temp;
	if (strcmp(name.getStr(),SOAPDeserialize::SERVICE)==0)
	{
		serviceName=pe->getValue(SOAPDeserialize::NAMESPACEID);
		//printf("methodNS  =%s\n",m_ns);
		name=pr->read()->getName();
		while (strcmp(name.getStr(),SOAPDeserialize::SERVICE)!=0)	{
			if (strcmp(name.getStr(),SOAPDeserialize::PROVIDER)==0)	{
				pe=pr->read();
				name=pe->getName();
//owen1 org
/*
				while (strcmp(name.getStr(),SOAPDeserialize::PROVIDER)!=0)	{
					if (strcmp(name.getStr(),serviceMethod.getStr())==0)	{
						while (strcmp(name.getStr(),SOAPDeserialize::OUTPUT)!=0)  {
							name=pr->read()->getName();
						}
						pe=pr->read();
						name=pe->getName();
						while (strcmp(name.getStr(),SOAPDeserialize::OUTPUT)!=0)	 {
							output+=name.getStr();
							temp=pe->getValue(SOAPDeserialize::XSI_TYPE);
							output+=Xml::EQ_S;
							output+=temp;
							output+=Xml::SP_S;
							if (temp!=NULL)
								delete temp;
							pe=pr->read();
							name=pe->getName();
						}
						output+=Xml::ENTER_S;
					}
					while (name!=SOAPDeserialize::PROVIDER){
						name=pr->read()->getName();
					}
				}
*/
//owen1 org

//owen2 new
//owen
				if(strcmp(name.getStr(),SOAPDeserialize::PROVIDER)!=0)	
				{
					while (strcmp(name.getStr(),serviceMethod.getStr())!=0){
						name=pr->read()->getName();
					}

//					while(strcmp(name.getStr(),serviceMethod.getStr())==0)	{
					while (strcmp(name.getStr(),SOAPDeserialize::OUTPUT)!=0)  {
						name=pr->read()->getName();
					}
					pe=pr->read();
					name=pe->getName();
					while (strcmp(name.getStr(),SOAPDeserialize::OUTPUT)!=0)	 {
						output+=name.getStr();
						temp=pe->getValue(SOAPDeserialize::XSI_TYPE);
						output+=Xml::EQ_S;
						output+=temp;
						output+=Xml::SP_S;
						if (temp!=NULL)
							delete temp;
						pe=pr->read();
						name=pe->getName();
					}
					output+=Xml::ENTER_S;

					while (name!=SOAPDeserialize::PROVIDER){
						name=pr->read()->getName();
					}

				}
//owen

//owen2 new

				pe=pr->read();
				name=pe->getName();
			}
			//else
				//ERROR;
			if (strcmp(name.getStr(),SOAPDeserialize::MAPPING)==0)	{
				pe=pr->read();
				name=pe->getName();
				while (strcmp(name.getStr(),SOAPDeserialize::MAPPING)!=0)
				{
					while (strcmp(name.getStr(),SOAPDeserialize::MAP)==0)	{
						temp=pe->getAttribute();
						map+=temp;
						map+=Xml::SM_S;
						delete temp;
						pe=pr->read();
						name=pe->getName();
						while (name!=SOAPDeserialize::MAP)
						{
							map+=name.getStr();
							map+=Xml::EQ_S;
							temp=pe->getValue(SOAPDeserialize::XSI_TYPE);
							map+=temp;
							map+=Xml::SM_S;//SP_S
							if (temp!=NULL)
								delete temp;
							pe=pr->read();
							name=pe->getName();
						}
						pe=pr->read();
						name=pe->getName();
					}
					map+=Xml::ENTER_S;
				}
			}
			//tempporary 
			name=pr->read()->getName();
			//else
			//	break;&ERRROR;
		}//while service
	}//if service
	delete pr;
	if (output==NULL)
	{
		char *e="method unknow";
		setError(e);
	}
	///////cout<<"output="<<output.getStr();
	///////cout<<"map   ="<<map.getStr();
	serviceMap=map;

	Str encodingStyle,xmlns_x,qname,headerFile,obj;
	//////output
	temp=output.cut('=');
	obj=temp;
	if (temp!=NULL)
		delete temp;
	////////////may be should or not think...
	temp=output.cut(' ');
	qname=temp;
	//////modify
	if (isNative(qname.getStr()))
	{
		output=obj;
		output+=Xml::EQ_S;
		output+=qname;
		output+=Xml::SP_S;
	}
	///////
	if (temp!=NULL)
		delete temp;
	//////map
	map.deleteTo(' ');///link to Attrhandler::getAttribute //if (i!=0) cam improve
	////may be improve by for or while loop and case
	temp=map.cut(' ');
	attr=new Attribute(temp);
	encodingStyle=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(' ');
	attr=new Attribute(temp);
	xmlns_x=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(' ');
	attr=new Attribute(temp);
	//if (qname==attr->getValue()) break;  ...mayz.. up I^I
	qname=attr->getValue();
	//qname.deleteTo(':');
	////////////cout<<"qname="<<qname.getStr();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(';');
	attr=new Attribute(temp);
	headerFile=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;
	serviceEncoding=encodingStyle;
	serviceQname=qname;
	serviceQnameNS=xmlns_x;
	serviceOutput=output;
	serviceMap=map;
	//cout<<"encodingStyle="<<encodingStyle.getStr()<<endl;
	//cout<<"xmlns_x      ="<<xmlns_x.getStr()<<endl;
	//cout<<"qname        ="<<qname.getStr()<<endl;
	//cout<<"headerFile   ="<<headerFile.getStr()<<endl;
	//cout<<"obj          ="<<obj.getStr()<<endl;
	//cout<<"map          ="<<map.getStr()<<endl;
	////getch();
}
int SOAPDeserialize::isNative(const char* s)
{
	if ((strcmp(s,SOAPDeserialize::INT_S)==0)||(strcmp(s,SOAPDeserialize::DOUBLE_S)==0)||(strcmp(s,SOAPDeserialize::LONG_S)==0)
		||(strcmp(s,SOAPDeserialize::FLOAT_S)==0)||(strcmp(s,SOAPDeserialize::STRING_S)==0)||(strcmp(s,SOAPDeserialize::CHAR_S)==0))
		return 1;
	else
		return 0;
}
char* SOAPDeserialize::serialOutput()
{
	XMLWriter x1;
	char *temp;int nscount=0;
	Str prefix=Constants::NS;
	temp=new char[30];
	strcpy(temp,NULL);
	itoa(++nscount,temp,10);
	prefix+=temp;
	delete temp;
//	printf("prefix=%s\n",prefix.getStr());
	Str name=serviceMethod;
	name+=Constants::RESPONSE;
	x1.writeStartTag(prefix.getStr(),name.getStr());
	temp=Xml::encode(serviceName.getStr());///m_ns);
	//delete m_ns;
	x1.writeAttribute(Constants::XMLNS,prefix.getStr(),temp);
	delete temp;
	Attribute *attr;char *a,ch;FILE *value;
	char *ptr1;
	value= fopen("out1.txt", "r+");
	fseek(value,0,SEEK_SET);
	int i=0;
	
	a=new char[200];
	ch=fgetc(value);
	i=0;	
	Str classMap;
	while (ch!=EOF)	{
		if (i>200)
			break;
		if (ch!=-0 && ch!='\n')
			a[i++]=ch;
		if (ch=='\n')
			a[i++]=';';
		ch=fgetc(value);
	}
	a[i++]=';';
	a[i]='\0';
	fclose(value);
	Str As=a;
	delete a;
	x1.writeAttribute(Constants::SOAP_ENV,Constants::ENCODING_STYLE,serviceEncoding.getStr());
//owen
//    printf("\n##debug--6--##: serviceEncoding.getStr() = ");
//    printf(serviceEncoding.getStr());
//    printf("\n##debug--6--##\n");
//owen	
	x1.writeStartTag(Constants::RETURN);
//owen
 //   printf("\n##debug--7--##: serviceOutput.getSize() = %d",serviceOutput.getSize());
//    printf(serviceOutput.getSize(),%d);
//    printf("\n##debug--7--##\n");
//owen		
	if (serviceOutput.getSize()>2)
	{
		char *hitt=serviceOutput.cut('=');
		delete hitt;
		hitt=serviceOutput.cut(' ');
		x1.writeAttribute(Constants::XSI,Constants::TYPE,hitt);
		a=As.cut(';');
		x1.writeRaw(a);
		delete a;
		delete hitt;

//owen
//    printf("\n##debug--8--##: Yes... ! serviceOutput.getSize() > 2 ");
//    printf("\n##debug--8--##\n");
//owen	
		/*attr=new Attribute(Constants::XSI,Constants::TYPE,ptr1);
		if (ptr1!=NULL)	{
			delete ptr1;
			ptr1=NULL;	}
		ptr1=attr->toString();

		a=As.cut(';');
		x1.writeTag(temp,ptr1,a);
		delete a;*/
	}
    else {
//owen    
//    printf("\n##debug--9--##: No... ! serviceOutput.getSize() <= 2 ");
//    printf("\n##debug--9--##\n");    
//owen    
	temp=new char[30];
	strcpy(temp,NULL);
	itoa(nscount,temp,10);
	prefix=Constants::NS;
	prefix+=temp;
	delete temp;
	x1.writeAttribute(Constants::XMLNS,prefix.getStr(),serviceQnameNS.getStr());
	serviceQname.replaceBefore(prefix.getStr(),':');
	x1.writeAttribute(XSI_TYPE,serviceQname.getStr());

	cout<<"map="<<serviceMap.getStr()<<endl;
	
	
	while (As.getSize()>1)
	{
		///printf("%s\n",serviceMap.getStr());
		///printf("%s\n",x1.getWriter());
		temp=serviceMap.cut('=');
		ptr1=serviceMap.cut(';');
		if (isNative(ptr1))	{
			attr=new Attribute(Constants::XSI,Constants::TYPE,ptr1);
			if (ptr1!=NULL)	{
				delete ptr1;
				ptr1=NULL;	}
			ptr1=attr->toString();
			a=As.cut(';');
			x1.writeTag(temp,ptr1,a);
			delete a;
			clrscr();
			/////////////////////////////printf("%s",x1.getWriter());
			delete attr;
		}
		///////
		else {
			a=new char[30];
			strcpy(a,NULL);
			itoa(nscount,a,10);
			prefix=Constants::NS;
			prefix+=a;
			delete a;
			classMap=ptr1;
			if (ptr1!=NULL)	{
				delete ptr1;
				ptr1=NULL;	}
			classMap.deleteTo(':');
			prefix+=Xml::CL_S;
			prefix+=classMap.getStr();

			attr=new Attribute(Constants::XSI,Constants::TYPE,prefix.getStr());
			ptr1=attr->toString();
			x1.writeStartTag(temp);
			x1.writeAttribute(ptr1);
			delete attr;
			if (temp!=NULL)	{
				delete temp;
				temp=NULL;	}
			if (ptr1!=NULL)	{
				delete ptr1;
				ptr1=NULL;	}
			temp=serviceMap.cut(' ');
			classMap=temp;
			if (temp!=NULL)	{
				delete temp;
				temp=NULL;	}

			///////cut detial like ns qname encod xmlns_x
			serviceMap.deleteTo(';');

			while (serviceMap.getSize()>1)
			{
				temp=serviceMap.cut('=');
				ptr1=serviceMap.cut(';');
				if (isNative(ptr1))	{
					attr=new Attribute(Constants::XSI,Constants::TYPE,ptr1);
					if (ptr1!=NULL)
						delete ptr1;
					ptr1=attr->toString();
					a=As.cut(';');
					x1.writeTag(temp,ptr1,a);delete a;
					clrscr();
					/////////////////////////////printf("%s",x1.getWriter());
					delete attr;
				}
				if (temp!=NULL)	{
					delete temp;
					temp=NULL;	}
				if (ptr1!=NULL)	{
					delete ptr1;
					ptr1=NULL;	}
			}
			x1.writeEndTag();
			serviceMap=classMap.getStr();
		}
		if (temp!=NULL)
		{
			delete temp;
			temp=NULL;
		}
		if (ptr1!=NULL)
		{
			delete ptr1;
			ptr1=NULL;
		}
	}  }//else
	//delete a;
	x1.closeAll();
	//cout<<x1.getWriter()<<endl;
	/////getch();
	temp=new char[strlen(x1.getWriter())+1];
	strcpy(temp,x1.getWriter());
	strcat(temp,NULL);
	return temp;	
}

int SOAPDeserialize::checkOrder(const char* fileName,const char* params)
{
	/*int i=0;
	char ch,*a;
	a=new char[1500];
	FILE *stream;
	stream=fopen(fileName,"r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>1500)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	a[i]='\0';
	fclose(stream);
	Attribute *attr;
	Str name,name1,type,type1;
	Parser *pr,*pr1;
	ParseEvent *pe,*pe1;
	pr=new Parser();
	pr->setXMLReader(a);
	delete a;
	pr1=new Parser();
	pr1->setXMLReader(params);
	while (pr->isRead())
	{
		pe1=pr1->read();
		pe=pr->read();
		name=pe->getName();
		name1=pe1->getName();
		type=pe->getValue();
		type1=pe->getValue();
		if (strcmp(name.getStr(),name1.getStr())!=0)
			return 0;
		else if (strcmp(type.getStr(),type1.getStr())!=0)
			return 0;
		else if ()
		{
		}
	}*/
	return 0;
	

}
