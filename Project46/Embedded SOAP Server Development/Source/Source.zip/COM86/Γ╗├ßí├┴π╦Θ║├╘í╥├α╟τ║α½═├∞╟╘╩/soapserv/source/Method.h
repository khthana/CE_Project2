//Method.h

#ifndef __METHOD_H
#define __METHOD_H
#include "..\source\Str.h"
#include "..\source\Const.h"
#include "..\source\AttrHand.h"
#include "..\source\Qname.h"
#include "..\source\Parser.h"
#include "..\source\ParseE.h"
#include "..\source\Param.h"

class Method
{
	private:
	Str name;
	Str url;
	Str encoding;
	Str error;
	Parameter parameter;
	//AttributeHandler attr;

	public:
	Method()	{  }
	Method& operator=(const Method& that)	{
		name=that.getMethodName();
		url=that.getMethodURL();
		encoding=that.getMethodEnc();
		error=that.getError();
		parameter=that.getParameter();
		//attr=that.getAttributeHandler();
		return *this;	}
	
	/*void setAttribute(const char* attrQName, int value) {
		attrHandler.setAttribute(attrQName, value); }

	const char* getAttribute(QName attrQName)	{
		return attrHandler.getAttribute(attrQName);	}

	const AttributeHandler getAttributeHandler() const	{
		return attrHandler;	}
	
	char* getAttribute() const 	{
		return attrHandler.getAttribute();	}*/

	int getLength() const {
		return name.getSize()+url.getSize()+encoding.getSize()+parameter.getLength()+60;	}//+attrHandler.getLength();

	void setParameter(const char* p) {
		Parameter pr(p);
		parameter=pr;	}
	
	const Parameter getParameter() {
		return parameter;	}

	void setMethodName(const char* m) {
		Str me=m;
		me.deleteTo(':');
		name=me.getStr();
	writeFile();}
	
	const char* getMethodName() {
		return name.getStr();	}
	
	void setMethodURL(const char* u) {
		url=u;	}
	
	const char* getMethodURL() {
		return url.getStr();	}

	void setMethodEnc(const char* e) {
		encoding=e;	}
	
	const char* getMethodEnc() {
		return encoding.getStr();	}
		
	void setError(const char* e) {
		error=e;	}
	
	const char* getError() const{
		return error.getStr();	}
	
	void writeFile() {
		FILE *stream;
		stream=fopen("input.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%s\n",name.getStr());
		fclose(stream);	}

	char* marshall();
	static Method* unmarshall(Parser* pr,ParseEvent *pe);


};
#endif