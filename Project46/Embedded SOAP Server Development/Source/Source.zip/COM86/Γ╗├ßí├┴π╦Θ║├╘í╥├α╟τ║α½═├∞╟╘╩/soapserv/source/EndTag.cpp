//
//
#include <string.h>
#include "..\source\EndTag.h"

char* EndTag::toString()
{
	char *temp;
	
	/*if (temp!=NULL)
		delete temp;*/
	
	if (strcmp(endTag.getStr(),NULL)!=0)
	{
		temp=new char[strlen(endTag.getStr())+4];
		/*strcpy(temp,NULL);
		s="</";
		strncat(temp,s,2);*/
		strcpy(temp,Xml::LT_S);
		strncat(temp,Xml::SL_S,1);
		strcat(temp,endTag.getStr());
		strncat(temp,Xml::GT_S,1);
		strncat(temp,NULL,1);
	}
	else
		temp=NULL;
	return temp; //  "</"+startTag.name + ">";
}
