// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: Dparser.cpp
#include <string.h>
#include <stdio.h>
#include <iostream.h>
#include "..\source\Parser.h"
const char* Parser::ER_TEXT="Illegal StartTag in readText: ";
/** amp is already consumed, consume incl. comma */
char Parser::parseCharacterEntity ()// throws IOException
{
	char *temp;
	temp=reader.readTo(';');
	char code[10];
	strcpy(code,temp);
	delete temp;
	//char* result;
	reader.read();
	if (code[0]=='#' && code[1]=='x')
	{
		int i=0,j,k;
		int c=0;
		for (j=2;code[j]!='\0' ;j++ )
		{
			i++;
		}
		for (j=2;j<i+2 ;j++ )
		{
			c+=((int)code[j]);
			for (k=i;k>0 ;k-- )
			{
				c*=16;
			}
			i--;
		}
		char ch=(char)c;
		return ch;
	}
	else if (code[0]=='#')
	{
		int i=0,j,k;
		int c=0;
		for (j=2;code[j]!='\0' ;j++ )
		{
			i++;
		}
		for (j=2;j<i+2 ;j++ )
		{
			c+=((int)code[j]);
			for (k=i;k>0 ;k-- )
			{
				c*=10;
			}
			i--;
		}
		char ch=(char)c;
		return ch;
	}
	else if (code[0]=='l' && code[1]=='t')
		return '<';
	else if (code[0]=='g' && code[1]=='t')
		return '>';
	else if (code[0]=='a' && code[1]=='p' && code[2]=='o' && code[3]=='s')
		return '>';
	else if (code[0]=='q' && code[1]=='u' && code[2]=='o' && code[3]=='t')
		return '"';
	else if (code[0]=='a' && code[1]=='m' && code[2]=='p')
		return '&';
	return '$';
	//else throw exception;
}
/* precondition: &lt;!- consumed */
LegacyEvent Parser::parseComment ()// throws IOException
{
	//char buf[300];
	if (reader.read()!='-')
	{
		//throw new ParseException("'-' expected", reader);
	}
	int cnt;
	int lst;
	char temp[100];
	char *s;
	while (1==1)
	{
		char *t;
		t=reader.readTo('-');
		strcpy(temp,t);
		delete t;
		//strcpy(temp,temp);
		if (reader.read()==-1)
		{
			//throw new ParseException ("Unexpected end of file while reading commnent",reader);
		}
		cnt=0;
		do
		{
			lst=reader.read();
			cnt++;
		}
		while (lst=='-');
		if (lst=='>' && cnt>=2)
			break;
		while (cnt-- >0)
		{
			strncat(temp,Xml::CM_S,1);
		}
		char c=(char)lst;
		s=&c;
		strncat(temp,s,1);
	}
	while (cnt-- >2)
	{
		strncat(temp,Xml::CM_S,1);
	}
	LegacyEvent l1(Xml::COMMENT,temp);
	leg=l1;
	return leg;
}
/* precondition: &lt! consumed */
LegacyEvent Parser::parseDoctype ()// throws IOException
{
	char temp[200];
	char c;
	char *s;
	strcpy(temp,NULL);
	int nesting=1;
	while (1==1)
	{
		int i=reader.read();
		switch (i)
		{
			case -1 : break;//throw new ParseException("unexpected eof",reader);
			case '<': nesting++;break;
			case '>': if ((--nesting)==0)
					  {
						  LegacyEvent l1(Xml::DOCTYPE,temp);
						  leg=l1;
						  return leg;
					  }
					  break;				
		}
		c=(char)i;
		s=&c;
		strncat(temp,s,1);
	}
	char *err="error";
	LegacyEvent l1(Xml::DOCTYPE,err);
	leg=l1;
	return leg;
}
TextEvent Parser::parseCData ()// throws IOException
{
	char *s;
	char c;
	char temp[300];
	int cmp;
	char *te;
	te=reader.readTo('[');
	strcpy(temp,te);
	delete te;
	if(strcmp(temp,Xml::CDATA)!=0)
		//trow new ParseException("Invalid CDATA start!", reader);
	reader.read();//skop '['
	int c0=reader.read();
	int c1=reader.read();
	strcpy(temp,NULL);
	while (1==1)
	{
		int c2=reader.read();
		if (c2== -1)
			//throw new ParseException ("unexpected eof", reader);
		if (c0 == ']' && c1 == ']' && c2 == '>')
			break;
		c=c0;
		s=&c;
		strncat(temp,s,1);
		c0=c1;
		c1=c2;
	}
	TextEvent t(temp);
	textEvent=t;
	return textEvent;
}
/* precondition: &lt;/ consumed */
EndTag Parser::parseEndTag ()// throws IOException
{
	char *name;
	name=reader.readTo('>');
	reader.read(); //skip >
	char qName[200];
	strcpy(qName,qNames[--size].getStr());
	if (strcmp(qName,name)==0)
		qName[size]=NULL;
	else
	{
	/*	throw new ParseException
		("StartTag <"+qName+"> does not match end tag </" + name + ">", reader);*/
	}
	EndTag res(name);
	endTag=res;
	delete name;
	//startTag=startTag.previous;
	return endTag;
}
/** precondition: <? consumed */
LegacyEvent Parser::parsePI ()// throws IOException
{
	char buf[300];
	char *s;
	char c;
	char *t;
	t=reader.readTo('?');
	strcpy(buf,t);
	delete t;
	reader.read(); // ?
	while (reader.peek()!='>')
	{
		strncat(buf,Xml::PI_S,1);
		int r=reader.read();
		if (r==-1) 
		{
			//throw new PareException("Unexpected eof while reading PI", reader);
		}
		c=(char)r;
		s=&c;
		strncat(buf,s,1);
		t=reader.readTo('?');
		strcat(buf,t);
		delete t;
		reader.read();
	}
	reader.read(); // consume >
	LegacyEvent l(Xml::PROCESSING_INSTRUCTION, buf);
	leg=l;
	return leg;
}
/*void Parser::fixPrefixMap()
{
	
}*/
StartTag Parser::parseStartTag ()// throws IOException
{
	StartTag s1(reader);
	startTag=s1;
	char *qName;
	qName=new char[strlen(startTag.getName())+1];
	strcpy(qName,startTag.getName());
	strncat(qName,NULL,1);
	/*if (processNamespaces==1)
	{
		fixPrefixMap();
	}*/
	//int co=startTag.getCountAttr();

	// can uncomment to show attribute
	/*for (int i=0;i<startTag.getCountAttr() ;i++ )
	{
		prefixMap.add(startTag.getAttribute(i));
		printf("attributs at %d = %s\n",i,startTag.getAttribute(i));
	}*/
	immediateClose=startTag.getDegenerated();
	if (immediateClose==0)
	{
		qNames[size++]=qName;
	}
	delete qName;
	reader.skipTo(Xml::GT_S);
	reader.read();
	return startTag;
}
TextEvent Parser::parseText ()// throws IOException
{
	char buf[200];
	char *s;
	char c;
	strcpy(buf,NULL);
	int nextChar;
	do
	{
		nextChar=reader.read();
		if (nextChar=='&')
		{
			c=parseCharacterEntity();
			s=&c;
			strncat(buf,s,1);				
		}
		else
		{
			c=(char) nextChar;
			s=&c;
			strncat(buf,s,1);
		}
		nextChar=reader.peek();
	}
	while (nextChar != '<' && nextChar != -1 && nextChar != 10 && nextChar != -9 && nextChar < 128 && nextChar !=0);
	TextEvent t1(buf);
	textEvent=t1;
	return textEvent;
}
/** precondition: &lt; consumed */
void Parser::parseSpecial ()// throws IOException
{
	switch (reader.peek())
	{
	case -1://throw new ParseException ("Unexpected end of file after reading <", reader);
	case '!': 
		reader.read();
		switch (reader.peek())
		{
		case '-':
			reader.read();
			parseComment();
			next=&leg;
			break;
		case '[':
			reader.read();
			parseCData();
			next=&textEvent;
			break;
		default:
			parseDoctype();
			next=&leg;
			break;			
		}
		break;
	case '?':
		reader.read();
		parsePI();
		next=&leg;
		break;
	case '/':
		reader.read();
		parseEndTag();
		next=&endTag;
		break;
	default:
		parseStartTag();
		next=&startTag;
		
	}
}
ParseEvent* Parser::read ()// throws IOException
{
	res=next;
	//char name[30],*attr;
	///while (reader.peek()!='\n')
	///{
	/*******if (immediateClose==1)
	{
		//EndTag e1(startTag);
		//endTag=e1;
		next=&startTag;
		immediateClose=0;
//		startTag=startTag.getPrevious();		
	}
	else {*****/
		//char pt=reader.peek();
		switch (reader.peek())
		{
		case '<':
			reader.read();
			parseSpecial();
			break;
		case -1:
			if (strcmp(startTag.getName(),NULL)!=0)
			{
				//throw new ParseException ("End tag missing for: "+startTag,reader);
			}
			next=&endDoc;
			break;
		default:
			parseText();
			next=&textEvent;
		}
	///////////}
	/*if (!isRead())
	{
		reader.read();
	}
	/*if (next!=NULL)
	{
		
		strcpy(name,next->getName());
		attr=next->getAttribute();
		cout<<"----name="<<name<<endl;
		cout<<"----attr="<<attr<<endl;
		if (attr!=NULL)
			delete attr;
	}*/
	////}
	
	//force to starttag
	/////////////////have problem about endDoc call pure function() ??????
	//res=&textEvent;
	return next;
}