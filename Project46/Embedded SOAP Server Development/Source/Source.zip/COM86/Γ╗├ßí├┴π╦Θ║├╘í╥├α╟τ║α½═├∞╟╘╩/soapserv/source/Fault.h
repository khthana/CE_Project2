// Fault.h

#ifndef __FAULT_H
#define __FAULT_H
#include <string.h>

#include "..\source\Str.h"
#include "..\source\Const.h"
#include "..\source\xml.h"
#include "..\source\AttrHand.h"
#include "..\source\Qname.h"

//#include "Faultin.h"
class Fault
{
	private:
	Str faultCode;
	Str faultString;
	Str faultActorURI;
	Str detailEntries;
	Str faultEntries;
	AttributeHandler attrHandler;

	public:
	Fault() {}
	Fault(const char* fc,const char* fs)
	{
		faultCode=fc;
		faultString=fs;
	}
	Fault& operator=(const Fault& that)
	{
		faultCode=that.faultCode;
		faultString=that.faultString;
		faultActorURI=that.faultActorURI;
		detailEntries=that.detailEntries;
		faultEntries=that.faultEntries;
		attrHandler=that.getAttributeHandler();
		return *this;
	}
	void setAttribute(const char* attrQName, int value) {
		attrHandler.setAttribute(attrQName, value); }

	const char* getAttribute(QName attrQName)	{
		return attrHandler.getAttribute(attrQName);	}

	const AttributeHandler getAttributeHandler() const	{
		return attrHandler;	}

    /*void removeAttribute(QName attrQName)    {
		attrHandler.removeAttribute(attrQName);	}

	/*void declareNamespace(char* nsPrefix, char* namespaceURI)	{
		attrHandler.declareNamespace(nsPrefix, namespaceURI);	}*/

	void setFaultCode(const char* fc)	{
		faultCode=fc;	}

	const char* getFaultCode() 	{
		return faultCode.getStr();	}

	void setFaultString(const char* fs)	{
		faultString=fs;	}

	const char* getFaultString()  {
		return faultString.getStr();  }

	void setFaultActorURI(const char* faURI)	{
		faultActorURI=faURI;  }

	const char* getFaultActorURI()  {
		return faultActorURI.getStr();  }

	void setDetailEntries(const char* dE)  {
		detailEntries=dE;  }

	const char* getDetailEntries()  {
		return detailEntries.getStr();  }

	void setFaultEntries(const char* fe)  {
		faultEntries=fe;  }

	const char* getFaultEntries()  {
		return faultEntries.getStr();  }

	int getLength() const	{
		return faultCode.getSize()+faultString.getSize()+faultActorURI.getSize()
		+detailEntries.getSize()+faultEntries.getSize()+attrHandler.getLength();	}

	char* marshall();
	static Fault* unmarshall(const char* fc,const char* fs)	{
		Fault* f=new Fault(fc,fs);
		//maybe set faultactorURI,DetailEntries,FaultEntries
		return f;
	}
};
#endif