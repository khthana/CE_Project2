// Fault.cpp
//
#include <string.h>
#include "..\source\Fault.h"
char* Fault::marshall()	{
	char *temp=new char[getLength()+200];
	//Determine the prefix
	//fault body
	strcpy(temp,Xml::LT_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::FAULT);
	//Attribute marshall()
	char *t;
	if (attrHandler.getLength() > 0)
	{
		t=attrHandler.marshall();
		strcat(temp,t);
		delete t;
	}
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
		//fault code
	strcat(temp,Xml::LT_S);
	strcat(temp,Constants::FAULT_CODE);
	strcat(temp,Xml::GT_S);
	strcat(temp,faultCode.getStr());
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::FAULT_CODE);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
		//fault string
	strcat(temp,Xml::LT_S);
	strcat(temp,Constants::FAULT_STRING);
	strcat(temp,Xml::GT_S);
	strcat(temp,faultString.getStr());
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::FAULT_STRING);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
		//Generate faultactor element if value is not null
	if (strcmp(faultActorURI.getStr(),NULL)!=0)		{
		strcat(temp,Xml::LT_S);
		strcat(temp,Constants::FAULT_ACTOR);
		strcat(temp,Xml::GT_S);
		strcat(temp,faultActorURI.getStr());
		strcat(temp,Xml::LT_S);
		strcat(temp,Xml::SL_S);
		strcat(temp,Constants::FAULT_ACTOR);
		strcat(temp,Xml::GT_S);
		strcat(temp,Xml::ENTER_S);
	}
		//If there are detail entries, generate the <detail> element,
	// and serialize the detail entries.
/******MUST improve this filed*****************/
	if (strcmp(detailEntries.getStr(),NULL)!=0)	{
		strcat(temp,Xml::LT_S);
		strcat(temp,Constants::DETAIL);
		strcat(temp,Xml::GT_S);
		strcat(temp,detailEntries.getStr());
		strcat(temp,Xml::LT_S);
		strcat(temp,Xml::SL_S);
		strcat(temp,Constants::DETAIL);
		strcat(temp,Xml::GT_S);
		strcat(temp,Xml::ENTER_S);			
	}
	// Serialize any fault entries (in addition to <faultcode>, <faultstring>,
	// <faultactor>, and <detail>).
/******MUST improve this filed*****************/	
	if (strcmp(faultEntries.getStr(),NULL)!=0)
	{}
	
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::FAULT);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	return temp;
}