// package embeddedXML.parser
// import de.kxml.*;
// file name: TextE.cpp

#include <string.h>
#include "..\source\TextE.h"
int TextEvent::endCheck (ParseEvent* start) // 0=false 1=true
{
	int i=text.getSize();
	while (i-- > 0)
	{
		if (text.getStr()[i] > ' ')
		{
			//throw new RuntimeException ("unexpected text: '"+text+"'");
			char *s1="unexpected text: '";
			char *c="'";
			char *s;
			s=new char[text.getSize()+21];
			strcpy(s,NULL);
			strcpy(s,s1);
			strcat(s,text.getStr());
			strncat(s,c,1);
			strncat(s,NULL,1);
			setError(s);
			delete s;
		}
	}
	return 0; //false
}