// package embeddedXML
// file name : Attr.cpp

#include <string.h>
#include <stdio.h>
#include <alloc.h>
#include "..\source\Str.h"
int Str::operator==(const Str& value)		
{ 
	return strcmp(str,value.getStr())==0 ? 1 : 0;
}
int Str::operator==(const char *string)
{
	return strcmp(str,string)==0 ? 1 : 0;
}
int Str::operator!=(const Str& value)		
{ 
	return strcmp(str,value.getStr())!=0 ? 1 : 0;
}
int Str::operator!=(const char *string)
{
	return strcmp(str,string)!=0 ? 1 : 0;
}
void Str::set(const char *string)
{
	toDelete();
	if ((string!=NULL) && (strcmp(string,NULL)!=0) ) //&& (strlen(string)<150))
	{
		str=(char*) malloc(strlen(string)+1);
		strcpy(str,string);
		strncat(str,NULL,1);
		size=strlen(str);
	}
}
void Str::append (const char *string)
{
	char *temp;
	temp=new char[getSize()+1];
	strcpy(temp,getStr());
	strncat(temp,NULL,1);
	if ((string!=NULL) && (strcmp(string,NULL)!=0) )// && (strlen(string)<150))
	{
		str=(char*) realloc(str,strlen(string)+size+1);
		strcpy(str,temp);
		strcat(str,string);
		strncat(str,NULL,1);
		size=strlen(str);
	}
	delete temp;
}
void Str::toDelete()
{
	if (str!=NULL)
	{
		free(str);
		str=NULL;
		size=0;
	}
}
int Str::isEmpty () const
{
	return strcmp(str,NULL)==0 ? 1 : 0;
}
int Str::isEqual (const Str& value) const
{
	return strcmp(str,value.getStr())==0 ? 1 : 0;
}
int Str::isEqual (const char *string) const
{
	return strcmp(str,string)==0 ? 1 : 0;
}
void Str::replaceBefore(const char *s,char c)
{
	char *ptr1=strchr(str,c);
	if (ptr1!=NULL)
	{
		int len=ptr1-str,i=0;
		int lens=strlen(s);
		while (str[i]!=c)
			i++;
		char *ptr2=new char[getSize()-len+1+lens];
		strcpy(ptr2,s);
		int j=lens;
		while (str[i]!='\0')
			ptr2[j++]=str[i++];
		ptr2[j]='\0';
		set(ptr2);
		delete ptr2;
	}
}
void Str::replaceAfter(const char *s,char c)
{
	char *ptr1=strchr(str,c);
	if (ptr1!=NULL)
	{
		int len=ptr1-str,i=0;
		int lens=strlen(s);
		char *ptr2=new char[len+2+lens];
		ptr1=new char[lens+1];
		strcpy(ptr1,s);
		strcat(ptr1,NULL);
		while (str[i]!=c)
			ptr2[i++]=str[i];
		ptr2[i++]=str[i];
		int j=0;
		while (ptr1[j]!='\0')
			ptr2[i++]=ptr1[j++];
		ptr2[i]=ptr1[j];
		set(ptr2);
		delete ptr2;
	}
}
char* Str::cut(char c)
{
	char *ptr1=strchr(str,c);
	if (ptr1==NULL)
	{
		return NULL;
	}else  {
		int len=ptr1-str,i=0;
		ptr1=new char[len+1];
		strcpy(ptr1,NULL);
		while (str[i]!=c)
			ptr1[i++]=str[i];
		ptr1[i++]='\0';
		char *ptr2=new char[getSize()-len+1];
		int j=0;
		while (str[i]!='\0')
			ptr2[j++]=str[i++];
		ptr2[j]='\0';
		set(ptr2);
		delete ptr2;
		return ptr1;
	}
}
void Str::deleteTo(char c)
{
	char *ptr1=strchr(str,c);
	if (ptr1!=NULL)	{
		int len=ptr1-str,i=0;
		while (str[i]!=c)
			i++;
		++i;
		char *ptr2=new char[getSize()-len+1];
		strcpy(ptr2,NULL);
		int j=0;
		while (str[i]!='\0')
			ptr2[j++]=str[i++];
		ptr2[j]='\0';
		set(ptr2);
		delete ptr2;
	}
}