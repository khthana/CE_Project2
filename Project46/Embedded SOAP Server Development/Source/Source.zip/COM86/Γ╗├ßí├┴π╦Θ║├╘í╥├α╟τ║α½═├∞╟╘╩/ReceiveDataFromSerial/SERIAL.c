#include "d:\tc\ser01\am186cc.h"
#include<dos.h>
#include<string.h>
#include<stdio.h>
#include<conio.h>

typedef unsigned char BYTE;
typedef unsigned int WORD;

void InitSerial()
{
	
	WORD SysconRegister ;
	WORD PIOMODE1Register, PIODIR1Register ;
	
	/* initital Serial Control Register -> Parity and Stop bit*/
	/* Parity = none , stop bit = 1*/
	
	outport(SPCON0, 0x60) ;
	
	/* initial Serial Baudrate Divisor Register */
	/* Baudrate = 9600 bps -> 0x9c*/
	/* Baudrate = 57600 bps ->0x1a*/
	outport(SPBDV, 0x1a) ;

}

char ReadChar(void) 
{
	WORD SPSTATRegister ;
	
	/* wait for ready to recieve*/
	do 
	{
	  SPSTATRegister = inport(SPSTAT) ;
	  /* check RDR bit */
	  SPSTATRegister = SPSTATRegister & 0x0080 ;
	}while (SPSTATRegister<=0);
	return inport(SPRXD) ;
}
//void delay1(int count);
void main()
{
FILE *fp;
char ch=0;
char c[4];
int i=0;
int j=0;
	InitSerial() ;
while(j<30){
	ch = ReadChar();
	printf("%c",ch);
	if(ch!=36){
		c[i]=ch;
		i++ ;
		}
	else{
	i=0;
	c[4]='\0';
	fp=fopen("test.txt","a");
	fprintf(fp,"%s",c);
	fprintf(fp,"%c",36);
	fclose(fp);
	i=0;
	     }
j++;
}
}