
#include <stdio.h>
#include <process.h>
#include <math.h>
#include <stdlib.h>
#include<iostream.h>
#include<fstream.h>
#include<time.h>
#include "Str.h"
int main()
{
	const char* TEMP="temp";
	const char* SMOKE="smoke";
	const char* FAN_OFF="fan_off";
	const char* FAN_ON="fan_on";
	FILE *stream;
	stream = fopen("input.txt","r+");
	fseek(stream,0,SEEK_SET);
	FILE *fp;
	fp=fopen("temptime.txt","a");
	char buffer[10];
	time_t ltime;
	time( &ltime );
	char ch,*a;int i=0;
	a=new char[200];
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>200)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		if (ch=='\n')
			a[i++]=';';
		ch=fgetc(stream);
	}
	a[i++]=';';
	a[i]='\0';
	fclose(stream);
	Str in=a;
	delete a;
	a=in.cut(';');
	char *b,*s;
	float p1,p2;
	float tmp;
	s=in.cut(';');
	//b=in.cut(';');
	p1=atof(s);
	//p2=atof(b);
	delete s;
	//delete b;
	if (strcmp(a,TEMP)==0)	
	{
		delete a;
		char ch;
		double temp[3],temperature;
		int i=0;

	    printf("\n##debug--kai--before##:  ");
		printf("\n##debug--kai--##\n ");
		int x = spawnl(P_WAIT,"serial.exe",NULL);
		if (x==-1)
		{
			perror("Error from spawnl");
			exit(1);
		}
 
		ifstream ReadTextFile("test.txt");
		while(ReadTextFile)
		{
			ReadTextFile.get(ch);
			while(ch==' '){ReadTextFile.get(ch);}
				if(ch!='$')
				{	if(i==0)
					 {
						if(ch=='0'){temp[0]=0;i++;} else
						if(ch=='1'){temp[0]=10;i++;} else
						if(ch=='2'){temp[0]=20;i++;} else
						if(ch=='3'){temp[0]=30;i++;} else
						if(ch=='4'){temp[0]=40;i++;} else
						if(ch=='5'){temp[0]=50;i++;} else
						if(ch=='6'){temp[0]=60;i++;} else
						if(ch=='7'){temp[0]=70;i++;} else
						if(ch=='8'){temp[0]=80;i++;} else
						{temp[0]=90;i++;} 
					 }
				    else
					if(i==1)
					 {
						if(ch=='0'){temp[1]=0;i++;} else
						if(ch=='1'){temp[1]=1;i++;} else
						if(ch=='2'){temp[1]=2;i++;} else
						if(ch=='3'){temp[1]=3;i++;} else
						if(ch=='4'){temp[1]=4;i++;} else
						if(ch=='5'){temp[1]=5;i++;} else
						if(ch=='6'){temp[1]=6;i++;} else
						if(ch=='7'){temp[1]=7;i++;} else
						if(ch=='8'){temp[1]=8;i++;} else
						{temp[1]=9;i++;}
					 }
					else
					if(i==2){i++;}else
					if(i==3)
					 {
						if(ch=='0'){temp[2]=0;} else
						if(ch=='5'){temp[2]=0.5;}
					 }
				}
				else
				{
					temperature=temp[0]+temp[1]+temp[2];
					i=0;
					ofstream WriteFile("test.txt");
				}		
		}
	if(temperature>40)
			tmp=0;
	else

			//p1=temperature;
				sprintf(buffer,"%3.3f",temperature);
				fprintf(fp,ctime(&ltime));
				fprintf(fp,buffer);
				fclose(fp);

			tmp =temperature;
		stream = fopen("out1.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%f\n",tmp);
		fclose(stream);
		return 0;
	}
	
	else if (strcmp(a,SMOKE)==0)	{			
		delete a;
		int y;
		ifstream ReadTextFile("smoke.txt");
		ReadTextFile.get(ch);
		if(ch=='1')
		{y =1; cout<<"SMOKE";}
		else {y=0;cout<<"NO SMOKE";}
		ofstream WriteFile("smoke.txt");
		tmp=y;
		stream = fopen("out1.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%f\n",tmp);
		fclose(stream);
		return 0;
	}

	else if (strcmp(a,FAN_ON)==0)	{			
		delete a;
		int x = spawnl(P_WAIT,"kinda.exe",NULL);
		if (x==-1)
		{
			perror("Error from spawnl");
			exit(1);
		}
		tmp =0;
		stream = fopen("out1.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%f\n",tmp);
		fclose(stream);
		return 0;
			}
	else if (strcmp(a,FAN_OFF)==0)	{
		delete a;
		int x = spawnl(P_WAIT,"kinda0.exe",NULL);
		if (x==-1)
		{
			perror("Error from spawnl");
			exit(1);
		}
		tmp = 0;
		stream = fopen("out1.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%f\n",tmp);
		fclose(stream);
		return 0;
			}
}
