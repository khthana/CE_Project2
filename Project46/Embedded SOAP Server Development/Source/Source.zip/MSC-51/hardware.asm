ONEWIRE			BIT		P2.6		; 1-Wire Interface (DS1820 Temp. Sensor)
LCD_EN			BIT		P3.6		; LCD Module Enable (Active High : Level)
LCD_RS			BIT		P3.7		; LCD Module Register Select
MOTOR			BIT		P2.1
FLAG			EQU		02FH		; User FLAG
BUSY			BIT		FLAG.0		; Define BUSY as bit
LCD_ADDR		EQU		030H		; For keep LCD Address
LCD_DATA		EQU		031H		; For keep LCD Data
ONEWIRE_DATA		EQU		032H		; For keep ONEWIRE Data
TEMP			EQU		033H		; For keep Temp. Data (Temp L only)
BUFFER			EQU		040H
RX_OK			BIT		F0	; Define bit to keep received already

;----------------------------------------------------------------------------
; Main Program.
;----------------------------------------------------------------------------

				ORG	0000H			; Reset Vector
				MOV	P0,#00000000B		; Clear Databus
				SETB	ONEWIRE			; Clear Onewire bus
				AJMP	MAIN
		
				ORG	0023H			; TI+RI Vector
				AJMP	SER_INT			; Goto Serial interrupt subroutine

MAIN:				
				MOV     TMOD,#020H              ; T1 8Bit Auto, T0 16Bit
                                MOV     TH1,#0FFH               ; 56400 bps Timer1 Default
                                MOV     PCON,#080H
				MOV	IE,#10010000B		; En. EA, ES
				SETB    TR1                     ; Start Timer1
                                MOV     SCON,#052H              ; Mode1 RX Disable
			
				CLR	RX_OK			; Clear RX_OK flag
				CLR	MOTOR			; Clear Bit motor
				
				ACALL	INIT_LCD		; Call LCD Initial subroutine
				MOV	LCD_ADDR,#000H		; Set Address 00H
				ACALL	SET_ADDR_LCD		;
				MOV	DPTR,#TITLE_1		; Index Pointer ROM to Show LCD
				ACALL	WRLINE_LCD		; 00H-07H,40H-47H(Increase automatic)
				ACALL	DELAY_1s		; Delay
				ACALL	DELAY_1s		;
				MOV	LCD_ADDR,#000H		; Set Address 00H
				ACALL	SET_ADDR_LCD		;
				MOV	DPTR,#SCR_TEMP		; Index Pointer ROM to Show LCD
				ACALL	WRLINE_LCD		; 00H-07H,40H-47H(Increase automatic)

LOOP:				ACALL	DS1820_RST		; DS1820 Reset
				ACALL	DS1820_PRES		; DS1820 Presence
				MOV	ONEWIRE_DATA,#0CCH	; Write Skip ROM
				ACALL	DS1820_WR		;
				MOV	ONEWIRE_DATA,#044H	; Write Convert Command
				ACALL	DS1820_WR		;
				SETB	BUSY			; Set bit BUSY

PRES_CHK_LOOP:
				ACALL	DS1820_RST		; DS1820 Reset
				ACALL	DS1820_PRES		; DS1820 Presence
				JB	BUSY,PRES_CHK_LOOP ; Wait for Busy
				NOP				; Delay
				NOP				;
				NOP				;
				NOP				;

				ACALL	DS1820_RST		; DS1820 Reset
				ACALL	DS1820_PRES		; DS1820 Presence
				MOV	ONEWIRE_DATA,#0CCH	; Write Skip ROM
				ACALL	DS1820_WR
				MOV	ONEWIRE_DATA,#0BEH	; Write Read Scratchpad Command
				ACALL	DS1820_WR
				ACALL	DS1820_RD		; Read DS1820
				MOV	TEMP,ONEWIRE_DATA	; Get First Byte as TEMP (L)
				ACALL	DS1820_RST		; DS1820 Reset
				ACALL	DS1820_PRES		; DS1820 Presence

				MOV	LCD_ADDR,#040H		; Set Address 40H
				ACALL	SET_ADDR_LCD		;

				MOV	A,TEMP			; Get Temp. Data
				CLR	C			; Clear Carry Flag
				RRC	A			; Rotate ACC. to Right with Carry

				MOV	LCD_DATA,A		; Write Temp. in 3 Decimal Digits
				ACALL	HEX2LCD			;

				MOV	LCD_ADDR,#044H		; Set Address 44H
				ACALL	SET_ADDR_LCD		;

				MOV	A,TEMP			; Get Temp. Data
				JNB	ACC.0,WRITE_0C		; Check LSB was set?
				MOV	LCD_DATA,#'5'		; Set => Load '5'
				CLR	TI
				MOV     BUFFER,#2EH
                                SETB	TI 
				CLR	TI
                                MOV	BUFFER,#35H
                                SETB	TI 
				ACALL   DELAY_100ms
				AJMP	WRITE_NEXT

WRITE_0C:			
				MOV	LCD_DATA,#'0'		; Not set => Load '0'
				CLR	TI
				MOV     BUFFER,#2EH
                                SETB	TI 
				ACALL	DELAY_100ms
				CLR	TI
                                MOV	BUFFER,#30H
                                SETB	TI 
				ACALL   DELAY_100ms
WRITE_NEXT:			
				ACALL	WRCHAR_LCD		; Write to LCD
				MOV     BUFFER,#24H
                                SETB	TI 
				AJMP	LOOP			; Jump to loop

;----------------------------------------------------------------------------
; HEX Code to show LCD
; I/P:	LCD_DATA
;----------------------------------------------------------------------------
HEX2LCD:			
				PUSH	ACC			; Push ACC.
				MOV	A,LCD_DATA		; Get Data
				MOV	B,#100			;
				DIV	AB			; Divide by 100
				ADD	A,#030H			; Convert to ASCII
				CJNE	A,#030H,HEX2_LCD_NX	; Check x100 = 0 ?
				MOV	A,#' '			; 0 => Write Space
HEX2_LCD_NX:
				
				MOV	LCD_DATA,A		;
				ACALL	WRCHAR_LCD		; Write x100
				
				MOV	A,B			;
				MOV	B,#10			;
				DIV	AB			; Divide by 10
				ADD	A,#030H			; Convert to ASCII
				MOV	BUFFER,A
                                SETB	TI 
				
				ACALL   DELAY_100ms
				MOV	LCD_DATA,A		;
				ACALL	WRCHAR_LCD		; Write Lower HEX Code
				
				MOV	A,B			; Get Remainder x1
				ADD	A,#030H			; Convert to ASCII
				MOV	BUFFER,A
                                SETB	TI 
				ACALL   DELAY_100ms
				MOV	LCD_DATA,A		;
				ACALL	WRCHAR_LCD		; Write Lower HEX Code
				POP	ACC			; Pop ACC.
				RET				; Return

;----------------------------------------------------------------------------
; DS1820 Data Read
;----------------------------------------------------------------------------
DS1820_RD:		
				MOV	R4,#8			; Set loop 8 times
				CLR	A			; Clear ACC.
DS1820_RD_LOOP:
				CLR	ONEWIRE			; Clear ONEWIRE
				NOP				; Delay
				NOP				;
				SETB	ONEWIRE			; Set ONEWIRE
				NOP				; Delay
				NOP				;
				NOP				;
				NOP				;
				MOV	C,ONEWIRE		; Get ONEWIRE to Carry Flag
				ACALL	ONEWIRE_DELAY		; Delay 75 us
				RRC	A			;
				DJNZ	R4,DS1820_RD_LOOP	; Do until 8 times
				MOV	ONEWIRE_DATA,A		; Move ACC. to ONEWIRE_DATA
				RET				; Return

;----------------------------------------------------------------------------
; DS1820 Data Write
;----------------------------------------------------------------------------
DS1820_WR:			
				MOV	R4,#8			; Set loop 8 times
				MOV	A,ONEWIRE_DATA		; Get ONEWIRE_DATA
DS1820_WR_LOOP: 
				RRC	A			; Rotate ACC. with Carry Flag
				JNC	DS1820_WR_L		; Carry Flag was set ?
				CLR	ONEWIRE			; Set => TX high
				NOP				; Delay
				NOP				;
				NOP				;
				NOP				;
				SETB	ONEWIRE			; Set ONEWIRE
				ACALL	ONEWIRE_DELAY		; Delay 75 us
				AJMP	DS1820_WR_NX		; Jump to next write
DS1820_WR_L:
				CLR	ONEWIRE			; Clear => TX Low
				ACALL	ONEWIRE_DELAY		; Delay 75 us
				SETB	ONEWIRE			; Set ONEWIRE
				NOP				; Delay
				NOP				;
				NOP				;
				NOP				;
DS1820_WR_NX:	
				DJNZ	R4,DS1820_WR_LOOP	; Do until 8 times
				RET				; Return

;----------------------------------------------------------------------------
; DS1820 Reset
;----------------------------------------------------------------------------
DS1820_RST:			CLR	ONEWIRE			; Clear ONEWIRE
				ACALL	DELAY_1ms		; Delay
				SETB	ONEWIRE			; Set ONEWIRE
				MOV	R4,#8			; Delay
				DJNZ	R4,$			;
				RET				; Return

;----------------------------------------------------------------------------
; DS1820 Receive Presence Pulse
;----------------------------------------------------------------------------
DS1820_PRES:	
				MOV	R4,#8			; Set Loop wait 1
DS1820_PRES_1:	
				MOV	R3,#0			; Set Loop wait 2
DS1820_PRES_2:	
				JNB	ONEWIRE,DS1820_PRES_3	; Check ONEWIRE was clear?
				DJNZ	R3,DS1820_PRES_2	; Wait loop check 2
				DJNZ	R4,DS1820_PRES_1	; Wait loop check 1
				RET				; Return
DS1820_PRES_3:	
				JNB	ONEWIRE,$		; Wait until ONEWIRE set
				MOV	R4,#8			; Delay
				DJNZ	R4,$			;
				CLR	BUSY			; Clear BUSY Flag
				RET				; Return

;----------------------------------------------------------------------------
; LCD Initialize
;----------------------------------------------------------------------------
INIT_LCD:	
				ACALL	DELAY_100ms		; Delay
				CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	P0,#00111000B		; 8bit Mode
				ACALL	LCD_CLK			; Pulse LCD Clock
				ACALL	DELAY_10ms		; Delay
				MOV	P0,#00111000B		; 8bit Mode
				ACALL	LCD_CLK			; Pulse LCD Clock
				ACALL	LCD_OFF			; Display Off
				ACALL	LCD_CLR			; Clear Display
				MOV	P0,#00000110B		; Entry Mode
				ACALL	LCD_CLK			; Pulse LCD Clock
				ACALL	LCD_HOME		; Return Home Display

;----------------------------------------------------------------------------
; LCD Clear Display
;----------------------------------------------------------------------------
LCD_CLR:			CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	P0,#00000001B		; Display Clear
				ACALL	LCD_CLK			; Pulse LCD Clock
				RET

;----------------------------------------------------------------------------
; LCD Return Home
;----------------------------------------------------------------------------
LCD_HOME:			CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	P0,#00000010B		; Return Home
				ACALL	LCD_CLK			; Pulse LCD Clock
				RET

;----------------------------------------------------------------------------
; LCD Display Off
;----------------------------------------------------------------------------
LCD_OFF:			CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	P0,#00001000B		; Display Off
				ACALL	LCD_CLK			; Pulse LCD Clock
				RET

;----------------------------------------------------------------------------
; LCD Clk
;----------------------------------------------------------------------------
LCD_CLK:			SETB	LCD_EN			; Pulse Clock to LCD_EN
				ACALL	LCD_DELAY
				CLR	LCD_EN
				ACALL	LCD_DELAY
				RET

;----------------------------------------------------------------------------
; LCD Display On
;----------------------------------------------------------------------------
LCD_ON:				CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	P0,#00001100B		; Display On
				ACALL	LCD_CLK
				RET

;----------------------------------------------------------------------------
; Set LCD Address
; I/P:	LCD_ADDR
;----------------------------------------------------------------------------
SET_ADDR_LCD:			CLR	LCD_RS			; Clear LCD_RS Pin
				MOV	A,LCD_ADDR		; Move LCD_ADDR to ACC.
				SETB	ACC.7			; Set bit ACC.7
				MOV	P0,A			; Move to DATABUS
				ACALL	LCD_CLK			; Pulse LCD Clock
				RET
;----------------------------------------------------------------------------
; Serial interrupt subroutine
;----------------------------------------------------------------------------
SER_INT:			PUSH		ACC			; Push ACC. to stack
	
				JBC		RI,SER_RX		; RX or TX? If RX then received and clear RI
SER_TX:				CLR		TI			; Clear TI
				MOV		SBUF,BUFFER
SER_TX_WAIT:			JBC		TI,SER_EXIT		; Wait until TX already (TI=1) then clear TI
				AJMP		SER_TX_WAIT		; Wait for TX

SER_RX:				CLR		RX_OK			; Clear RI
				MOV		A,SBUF			; Get data to ACC.
				CJNE		A,#031H,CHECK_OFF
				SETB		MOTOR			; On FAN
				AJMP		SER_EXIT
CHECK_OFF:
				CLR		MOTOR			; Off FAN
				;MOV		@R0,A			; Move to Buffer @R0
				;INC		R0			; Increase R0
				;CJNE		A,#00DH,SER_EXIT	; Check 00DH End of Buffer text
				;SETB		RX_OK			; Set RX_OK received message ok.
						; Send 

SER_EXIT:			POP		ACC			; Pop Acc. to Main
				RETI					; Return interrupt

;----------------------------------------------------------------------------
; Write Character to show LCD
; I/P:	LCD_DATA
;----------------------------------------------------------------------------
WRCHAR_LCD:			SETB	LCD_RS			; Set LCD_RS Pin
				MOV	P0,LCD_DATA		; Move LCD_DATA to DATABUS
				ACALL	LCD_CLK			; Pulse LCD Clock
				ACALL	LCD_ON			; Display On
				RET

;----------------------------------------------------------------------------
; Write Line of 16 Character from ROM
; I/P:	DPTR : Locate ROM Address
;----------------------------------------------------------------------------
WRLINE_LCD:		
				MOV	R0,#0			; Clear loop counter
WRLINE_LCD_1:
				SETB	LCD_RS			; Set LCD_RS Pin
				CLR	A			; Clear ACC.
				MOVC	A,@A+DPTR		; Move data from @DPTR to ACC.
				MOV	P0,A			; Move ACC. to DATABUS
				ACALL	LCD_CLK			; Pulse LCD Clock
				INC	DPTR			; Increase Pointer
				INC	R0			; Increase loop counter
				CJNE	R0,#8,WRLINE_LCD_1	; Do until 8 times
				MOV	LCD_ADDR,#040H		; Set Later 8 Char. Address
				ACALL	SET_ADDR_LCD

WRLINE_LCD_2:	
				SETB	LCD_RS			; Set LCD_RS Pin
				CLR	A			; Clear ACC.
				MOVC	A,@A+DPTR		; Move data from @DPTR to ACC.
				MOV	P0,A			; Move ACC. to DATABUS
				ACALL	LCD_CLK			; Pulse LCD Clock
				INC	DPTR			; Increase Pointer
				INC	R0			; Increase loop counter
				CJNE	R0,#16,WRLINE_LCD_2	; Do until 8+8 times
				ACALL	LCD_ON			; Display On
				RET

;----------------------------------------------------------------------------
; Dummy Delay time ONEWIRE_DELAY, LCD_DELAY, 50u, 100u, 1m, 10m, 100m, 1s
;----------------------------------------------------------------------------
ONEWIRE_DELAY:	
				MOV	R6,#012H		; Each loop = 75 us
ONEWIRE_DELAY_1: 
				NOP
				NOP
				DJNZ	R6,ONEWIRE_DELAY_1
				RET

LCD_DELAY:		
				MOV	R7,#002			; Do 2 times
LCD_DELAY_1:	
				MOV	R6,#0E6H		; Each loop = 1 ms
LCD_DELAY_2:	
				NOP
				NOP
				DJNZ	R6,LCD_DELAY_2
				DJNZ	R7,LCD_DELAY_1
				RET

DELAY_50us:		
				MOV	R6,#00CH		; Each loop = 50 us
DELAY_50us_1:	
				NOP
				NOP
				DJNZ	R6,DELAY_50us_1
				RET

DELAY_100us:	
				MOV	R6,#017H		; Each loop = 100 us
DELAY_100us_1:	
				NOP
				NOP
				DJNZ	R6,DELAY_100us_1
				RET

DELAY_1ms:		
				MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_1ms_1:	
				NOP
				NOP
				DJNZ	R6,DELAY_1ms_1
				RET
				
DELAY_10ms:		
				MOV	R7,#010			; Do 10 times
DELAY_10ms_1:	
				MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_10ms_2:	
				NOP
				NOP
				DJNZ	R6,DELAY_10ms_2
				DJNZ	R7,DELAY_10ms_1
				RET

DELAY_100ms:	
				MOV	R7,#100			; Do 100 times
DELAY_100ms_1:	
				MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_100ms_2:
				NOP
				NOP
				DJNZ	R6,DELAY_100ms_2
				DJNZ	R7,DELAY_100ms_1
				RET

DELAY_1s:		
				MOV	R5,#100			; Do 100 times
DELAY_1s_1:		
				ACALL	DELAY_10ms
				DJNZ	R5,DELAY_1s_1
				RET
;----------------------------------------------------------------------------
; TX Serial Text from ROM Pointer
;----------------------------------------------------------------------------
TX_TEXT:           
				CLR     TI                      ; Clear TI
TX_LOOP:               
				CLR     A                       ; Clear ACC.
                                MOVC    A,@A+DPTR               ; Get Data from ROM with Pointer
                                INC     DPTR                    ; Increase Pointer
                                CJNE    A,#0FFH,TX_CHAR         ; Check 0FFH End of Text Char.
                                RET                             ; End => Return

TX_CHAR:               
				MOV     SBUF,A                  ; Send Data to SBUF
                                JNB     TI,$                    ; Wait until TX already (TI=1)
                                CLR     TI                      ; Clear TI
                                AJMP    TX_LOOP                 ; Jump to TX_LOOP
;----------------------------------------------------------------------------
;Define Constant < Store in Flash EEPROM Program Memory >
;----------------------------------------------------------------------------
;					 0123456789ABCDEF
TITLE_1:		DB		' 1-Wire  DS1820 '
SCR_TEMP:		DB		' Temp :    . ',0DFH,'C '
SERIAL_TEXT:		DB              00AH,00DH
                        DB              00AH,00DH
                        DB              'Serial UART Communication < baudrate 57600bps > ',00AH,00DH
                        DB              00AH,00DH,0FFH