<%@ Page language="c#" Codebehind="result.aspx.cs" AutoEventWireup="false" Inherits="project.result" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>result</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="result" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 171px; POSITION: absolute; TOP: 173px" runat="server" Visible="False">��颹С�û�СǴ���</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 356px; POSITION: absolute; TOP: 179px" runat="server" Visible="False">Label</asp:Label>
			<asp:Label id="Label9" style="Z-INDEX: 109; LEFT: 190px; POSITION: absolute; TOP: 250px" runat="server" Visible="False">��û�СǴ����ѧ�����Ѵ�Թ��骹�</asp:Label>
			<asp:LinkButton id="LinkButton1" style="Z-INDEX: 110; LEFT: 253px; POSITION: absolute; TOP: 337px" runat="server">��Ѻ�˹����ѡ</asp:LinkButton>
		</form>
	</body>
</HTML>
