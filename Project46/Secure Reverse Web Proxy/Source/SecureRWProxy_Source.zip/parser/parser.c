#include <stdio.h>

#define MAX_CH 512
#define MAX_RULE 200

int main (int argc,char *argv[]) 
{
  FILE *file_inp,*file_outp;
  char inp[MAX_CH],outp[MAX_CH];\
  char Rule_tmp[MAX_RULE],Msg_tmp[MAX_RULE];
  char *finp = argv[1];				// input file
  char *foutp = argv[2];			// output file
  int i,j,k;
  int pos=0;
  int id=0;
  
  if(argc < 2)
  {
	  printf("******************************\n");
	  printf("Input File name Error\n");
	  printf("parser <input file> <output file> \n");
	  printf("******************************\n");
	  return(0);
  }
  
  file_inp  = fopen ( finp, "rb" );
  file_outp = fopen ( foutp, "rb" );
  
  if (file_inp == NULL) 					// file checking
	  exit (1);
  if (file_outp != NULL)
  {
  	while(fgets(outp,MAX_CH,file_outp)!=NULL)		//count line of rule file
		id++;
  	fclose(file_outp);
  }
  else
  {
  	file_outp = fopen ( foutp, "wb" );			//never has it
	//exit(1);
 	fclose(file_outp); 
	
  }
  
  
  
  file_outp = fopen ( foutp, "a+" );
  printf("%d,",id);
  
  while(fgets(inp,MAX_CH,file_inp)!=NULL)
  {
	
	memset(Rule_tmp,0x0,MAX_RULE);
	memset(Msg_tmp,0x0,MAX_RULE);
	
	for(i=0;i<MAX_CH;i++)
	{
		if(inp[1]=='#')						// comment in rule
			break;
		
		if(inp[i]=='"')						// position
			pos++;
			
		//*****************************************************	// parser to message log file
		if(pos == 1)
		{
			for(j=0;j<MAX_RULE;j++)			
			{
				i++;
				if(inp[i]=='"')
				{
					pos = 2;
					break;
				}
			
				Msg_tmp[j]=inp[i];
			}
		}
	
		//*****************************************************	// parser to rule file.
		else if(pos == 3)
		{
			pos = 0;
			for(k=0;k<MAX_RULE;k++)			
			{
				i++;
				if(inp[i]=='"')
				{
					//pos = 4;
					break;
				}
			
				Rule_tmp[k]=inp[i];
			}
			break;
		}
		
		
	}//line
	
	if((strlen(Rule_tmp) !=0) && (strlen(Msg_tmp) !=0))
	{
		id++;							// ID of Rules+Msg.
		fprintf(file_outp,"%d:\"%s\":\"%s\"\n",id,Rule_tmp,Msg_tmp);
	}
	
  }//fgets 

  fclose (file_inp);
  fclose (file_outp);
  printf(" ** Done **\n");
  return 0;
}
