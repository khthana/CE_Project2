#ifndef _BOYER_MOORE_H_
#define _BOYER_MOORE_H_

#define ALPHASIZE 255        // ASCII Character set

unsigned int BM(unsigned char *txt, unsigned int txt_length,unsigned char *pat, int pat_length);
//unsigned int bmCs[ALPHASIZE];

#endif