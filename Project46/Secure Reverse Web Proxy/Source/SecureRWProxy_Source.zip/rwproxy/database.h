#ifndef _DATABASE_H_
#define _DATABASE_H_

#include <mysql.h>

#define def_host_name NULL /* host to connect NULL is default for localhost */
#define def_user_name "rwproxy" /* user name NULL is default for your login name */
#define def_password "abc123" /* password NULL is default for none */
#define def_port_num 0  /* use default port */
#define def_socket_name NULL /* use default socket name */
#define def_db_name "rwproxy" /* datebase to use NULL is default for none */


void print_error(MYSQL * conn , char * message);

MYSQL * do_connect (char *host_name, char *user_name , char * password , char *db_name , unsigned int port_num , char * socket_name , unsigned int flags);

void do_disconnect(MYSQL *conn);

void process_result_set(MYSQL *conn, MYSQL_RES *res_set);

void logtoMysql(char * logtime , char * logIP , char * logmessage);

#endif