#include <stdio.h>
#include <stdlib.h>
#include "rules.h"
#include "config.h"

int parseRuleContent(unsigned char * ruleContent,unsigned char * parsedRule);
unsigned char * charRuleCpy(unsigned char * rule , int ruleLen);
char *rulefile;

rule * makeRuleList(void){
	FILE * file;
	char buffer[200];
  	rule * rulenode;
	rule * current;
	rule * rootnode;
	
	if((file = fopen(RULES,"r"))==NULL)
	{
		printf("Can not find/open RULES file.\n");
		exit(1);
	}
	
	//define rootnode as dummy node
	rootnode = (rule*) malloc(sizeof(rule));
	rulenode = current = rootnode;
	
	while(fgets(buffer,200,file)){
		char rulebuff[200];
		char ruleCharID[10];
		unsigned char ruleContent[200];
		unsigned char parsedRule[200];
		char ruleMessage[200];

		int ruleID;
		int rulelen;
		int i1=0;
		int index;
		int parsedRuleLen;
		
		//procedure for parsing <id:"content":message> to RWProxy's rules
		
		strcpy(rulebuff,buffer);

		rulelen= strlen(rulebuff);
		while((rulebuff[i1] != ':') && (i1 < rulelen) ) i1++;
		
		for(index=0 ; index<i1 ; index++){ // copy first field of "rulebuff" to "ruleCharID"
			ruleCharID[index] = rulebuff[index];
		}
		ruleCharID[index] = '\0';
		ruleID = atoi(ruleCharID);
		
		while((rulebuff[i1] != '\"') && (i1<rulelen)) i1++;
		i1++;
		
		index = 0;
		while((rulebuff[i1] != '\"') && (i1<rulelen)){// copy second field of "rulebuff" to "ruleContent"
			if(rulebuff[i1] != ' '){
				ruleContent[index] = rulebuff[i1];
				index++;
			}
			i1++;
		}
		ruleContent[index] = '\0';
		//printf("%s:%d\n",ruleContent,strlen(ruleContent));
		rulebuff[rulelen-2] = '\0';
		strcpy(ruleMessage,(rulebuff+i1+3)); // copy Message from rulebuff without double quote (")
		//printf("Message : %s : %d\n",ruleMessage,strlen(ruleMessage));
		
		parsedRuleLen = parseRuleContent(ruleContent,parsedRule);
		//printf("%s:%d\n",parsedRule,parsedRuleLen);
		rulenode -> next = (rule*) malloc(sizeof(rule));
		rulenode = rulenode->next;
		rulenode->length = parsedRuleLen;
		rulenode->ruleID = ruleID;
		//rulenode->content = strcpy((unsigned char*)malloc(sizeof(unsigned char) * (parsedRuleLen+1)),parsedRule);
		rulenode->content = charRuleCpy(parsedRule,parsedRuleLen);
		rulenode->message = strcpy((char *) malloc(sizeof(char) * (strlen(ruleMessage)+1)) , ruleMessage);
	}

/*	
	while((current != NULL) && (current->next != NULL)){
		current = current->next;
		printf("%d:%s:%d\n",current->ruleID,current->content,current->length);
	}
*/	
	fclose(file);
	return (rule*) rootnode;
}

unsigned char * charRuleCpy(unsigned char * rule , int ruleLen){
	unsigned char * mallocRule;
	int i;
	mallocRule = (unsigned char *) malloc(sizeof(unsigned char) * (ruleLen+1));
	for(i=0 ; i<=ruleLen ; i++){
		mallocRule[i] = rule[i];
	}
	return (unsigned char *) mallocRule;
}

int parseRuleContent(unsigned char * ruleContent,unsigned char * parsedRule){
typedef enum {
	STATE1,
	STATE2,
	STATE3,
	STATE4,
  STATE5
}ParseState;
	unsigned char binParse[3]="00";
	int i;
	int rulelen;
	int parseIndex;
	
	ParseState state = STATE1;

	rulelen = strlen(ruleContent);
	parseIndex = 0;
	for(i=0 ; i<rulelen ; i++){
		switch(state){
			case STATE1:
				if(ruleContent[i] == '|'){
					state = STATE2;
        			}else if(ruleContent[i] == '\\'){
          				state = STATE5;
				}else{
					//printf("%c\n",ruleContent[i]);
					parsedRule[parseIndex] = ruleContent[i];
					state = STATE1;
					parseIndex++;
				}
				break;
			case STATE2:
				binParse[0] = ruleContent[i];
				state = STATE3;
				break;
			case STATE3:
				//printf("%s:%d\n",binParse,strtol(binParse,NULL,16));
				binParse[1] = ruleContent[i];
				parsedRule[parseIndex] = (unsigned char)strtol(binParse,NULL,16);
				state = STATE4;
				parseIndex++;
				break;
			case STATE4:
				if(ruleContent[i] == '|'){
					state = STATE1;
				}else{
					binParse[0] = ruleContent[i];
					state = STATE3;
				}
				break;
      			case STATE5:
				parsedRule[parseIndex] = ruleContent[i];
				state = STATE1;
				parseIndex++;
        			break;
			default:
				break;
		}
	}
	parsedRule[parseIndex] = '\0';
	return parseIndex; // Parsed Rule Length
}
