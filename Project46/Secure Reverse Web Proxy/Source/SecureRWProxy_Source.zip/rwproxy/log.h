#ifndef _LOG_H_
#define _LOG_H_

void toLog(char *srcIP,int id,char * message);

#endif
