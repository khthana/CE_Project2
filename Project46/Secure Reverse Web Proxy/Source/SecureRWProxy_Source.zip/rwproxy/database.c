#include <stdio.h>
#include <mysql.h>
#include "database.h"

void print_error(MYSQL * conn , char * message){
	fprintf(stderr, "%s\n" ,message);
	if(conn != NULL){
		fprintf(stderr,"Error %u(%s)\n",mysql_errno(conn),mysql_error(conn));
	}
}

MYSQL * do_connect (char *host_name, char *user_name , char * password , char *db_name , unsigned int port_num , char * socket_name , unsigned int flags)
{
	MYSQL * conn; /* pointer to connection handler*/

	conn = mysql_init(NULL); /* allocate , initialize connection handler*/
	if(conn == NULL){
		print_error(conn,"mysql_init() failed");
	return (NULL);
	}

	if(mysql_real_connect(conn,host_name,user_name,password,db_name, port_num, socket_name, flags) == NULL){
		print_error(conn,"mysql_real_connect() failed");
		return (NULL);
	}
	return (conn);
}

void do_disconnect(MYSQL *conn){
	mysql_close(conn);
}

void process_result_set(MYSQL *conn, MYSQL_RES *res_set){ // display queried data
	MYSQL_ROW row;
	unsigned int i;
	while((row = mysql_fetch_row(res_set)) != NULL){
		for(i = 0; i< mysql_num_fields(res_set); i++){
			if(i>0) printf("\t");
			printf("%s",row[i] != NULL ? row[i] : "NULL");
		}
		printf("\n");
	}
	//if(mysql_error(conn) != 0)
	//	print_error(conn,"mysql_fetch_row() failed");
	//else
		printf("%lu rows returned\n" , (unsigned long)mysql_num_rows(res_set));
}

void logtoMysql(char * logtime , char * logIP , char * logmessage){
	char insertToLog[400];
  MYSQL *conn;
	conn = do_connect(def_host_name , def_user_name, def_password, def_db_name, def_port_num, def_socket_name, 0);
	sprintf(insertToLog,"INSERT INTO rwplog (ltime , lsource , lmessage) VALUES (\'%s\' , \'%s\' , \'%s\' )",logtime,logIP,logmessage);
	//printf("%s\n",insertToLog);
	
	if(mysql_query(conn,insertToLog) != 0){
		printf("Insert Failed\n");
	}else{
		printf("Insert Succeeded\n");
	}
	
	
	do_disconnect(conn);
}
