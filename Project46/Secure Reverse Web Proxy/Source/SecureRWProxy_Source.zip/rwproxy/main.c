#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

#include "boyer-moore.h"
#include "rules.h"
#include "log.h"
#include "config.h"

#define MAX_CH 5120 

unsigned char HTTP404[]=
"HTTP/1.1 404 OK\n"
"Server: Apache/3.5.7 (Unix)\n"
"Accept-Ranges: bytes\n"
"Content-Length: 139\n"
"Keep-Alive: timeout=15, max=100\n"
"Connecti: Keep-Alive\n"
"Content-Type: text/html\n\n"
"<HTML><HEAD><TITLE>404 Not Found</TITLE></HEAD><BODY><H1>Not Found</H1>The requested URL was not found on this server.<P><HR></BODY></HTML>";

int main(void)
{	
	int server_sockfd, client_sockfd;				// initial client.
    	int server_len,client_len;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;
    	//char portchar[10];
	int port,server_port;
	int useDatabase=0;
    	
	rule * traverse;

    	configure();
	port = atoi(PORT);
	server_port = atoi(SERVER_PORT);
	useDatabase = (strcmp(DB,"yes")==0) ? 1 : 0;

	/*printf("PORT %s\n",PORT);
	printf("WEB_SERVER %s\n",WEB_SERVER);
        printf("SERVER_PORT %s\n",SERVER_PORT);
        printf("RULES  %s\n",RULES);
        printf("LOG %s\n",LOG);
        printf("TIME_OUT %s\n",TIME_OUT);
        printf("DB %s\n",DB);*/

	server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    	server_address.sin_family = AF_INET;
    	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    	server_address.sin_port = htons(port);
    	server_len = sizeof(server_address);
    	bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
    	listen(server_sockfd, 11);

	traverse = rootRule = makeRuleList();

    	signal (SIGCHLD,SIG_IGN);

	while(1)
	{
  		int len;
	  	int isBMMatch=0;
		rule * currentRule;
		char inp[MAX_CH],optserver[MAX_CH];

		printf("SERVER WAITING FOR YOU ON PORT : %d\n***********************************\n",port);

		client_len = sizeof(client_address);
		client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address, &client_len);
	
		if(fork() == 0)
		{
		
			read(client_sockfd, inp, MAX_CH);		// reading request from client.

			len = strlen(inp);
	    		//printf("request :%d:\n%s\n",len,inp);
	
			// Check input request
      			// using Boyer Moore Algorithm.
			currentRule = rootRule;
			while((currentRule != NULL)&& (currentRule->next != NULL)){
				currentRule = currentRule->next;
      //for(currentRule = rootRule ; currentRule ; currentRule = currentRule->next){
				//printf("%d\n",currentRule->length);
		    		isBMMatch = BM(inp,len,currentRule->content,currentRule->length);
		    		if(isBMMatch==1){
					toLog(inet_ntoa((struct in_addr)client_address.sin_addr) , currentRule->ruleID , currentRule->message);
					printf("\nRule ID : %d : %s : LOGGING!!!\n",currentRule->ruleID,currentRule->message);
					break;
				}
			}

			if(isBMMatch == 1 ){ // if Matched with rules return HTTP404 response
        			write(client_sockfd, HTTP404,strlen (HTTP404));
			}else{

				int realsock,realresult,reallen;		// initial real web server.
				struct sockaddr_in address;
				//char *req;
				int packet_length;

				realsock = socket(AF_INET, SOCK_STREAM, 0);
				address.sin_family = AF_INET;
				address.sin_addr.s_addr = inet_addr(WEB_SERVER);	//ip of webserver that want to protect.
				address.sin_port = htons(server_port);
				reallen = sizeof(address);
				realresult = connect(realsock, (struct sockaddr *)&address, reallen);	
				if(realresult == -1)
				{
					break;
				}
		
				memset(optserver,0x0,MAX_CH);
				write(realsock,inp, strlen(inp));		// sending request to real web server.
				
				// read data and continueation until packet_length = 0
				do {
					packet_length = read(realsock, optserver, MAX_CH);
					write(client_sockfd,optserver, packet_length);
					memset(optserver,0x0,MAX_CH);
				}while(packet_length > 0);

				close(realsock);
			}
			
			close(client_sockfd);
			exit(0);
		}
		else
		{
			close(client_sockfd);
		}
	}
	
	return 0;
}
