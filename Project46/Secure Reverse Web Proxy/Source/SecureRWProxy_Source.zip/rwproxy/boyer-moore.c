#include <stdio.h>
#include "boyer-moore.h"

unsigned int BM(unsigned char *txt, unsigned int txt_length,unsigned char *pat, int pat_length)
{
   int i;
   int j;
   unsigned int bmCs[ALPHASIZE];
   int found = 0;

   //printf("boyer-moore searching\n");
   //printf("patlen:%d\n",pat_length);
   //------- Preprocessing ------------------
   // boyer moore Character shift Table.
   // initialize table

if(pat_length>txt_length){
  found = 0;
}else{
   for (i=0; i<=ALPHASIZE; i++)
       bmCs[i]=pat_length+1;
   // printf("boyer-moore searching\n");
   // character occurance shift fill
   for (i=0; i<pat_length; i++)
       bmCs[pat[i]]=pat_length-i;
   //------- End of Preprocessing------------

   // Searching
      j=0;
   for (i=0; i<=(txt_length-pat_length); i=i+j){
    // compare char of both text and pattern to find a match
    if (pat[pat_length-1]==txt[i+pat_length-1]){
       for (j= pat_length-1; j>=0; j--)            //compare from right
           if (pat[j] == txt[i+j]){              //if character is same
              if (j==0){  //if full length of pattern matches
                found = 1;
                break;
              }
           }
           else break;                            //break loop if mismatch found
	     if ( found == 1 ) break;
    }
    j = bmCs[txt[i+pat_length]];                  //jump to next occurance or otherwise jump
   }  //end of search
}
   return found; // number of tries.
}
