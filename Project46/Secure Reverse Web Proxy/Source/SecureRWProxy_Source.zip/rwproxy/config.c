#include <stdio.h>
#include "config.h"

void configure(void)
{
	FILE *file_conf;
	char inp[200];
	int i,j;
	
	file_conf = fopen("rwproxy.conf","rb");
	
	memset(inp,0x0,200);
	
	while(fgets(inp,200,file_conf))
	{
		if(inp[0] == '#')				// It's comment in conf file.
		{
			//printf("comment\n");
		}
		else if(inp[0] == 'P')				// It's PORT.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<6;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						PORT[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'W')				// It's WEB SERVER.
		{
			for(i=0;i<40;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<30;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						WEB_SERVER[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'S')				// It's Server Port.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<5;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						SERVER_PORT[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'R')				// It's Rules path.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<50;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						RULES[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'L')				// It's LOG path.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<50;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						LOG[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'T')				// It's Time Out.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<5;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						TIME_OUT[j] = inp[i];
					}
			}
		}
		else if(inp[0] == 'D')				// use data base ,yes or no.
		{
			for(i=0;i<30;i++)
			{
				if(inp[i] == ':')
					for(j=0;j<3;j++)
					{
						i++;
						if(inp[i] == ';')
							break;
						DB[j] = inp[i];
					}
			}
		}
	}
}
