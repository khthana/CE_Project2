#ifndef _RULES_H_
#define _RULES_H_

#include <stdio.h>

struct rulestrct{
	int ruleID;
	unsigned char * content;
	char * message;
	int length;
	struct rulestrct* next;
};
typedef struct rulestrct rule;


rule * rootRule; // Global

rule * makeRuleList(void);

#endif
