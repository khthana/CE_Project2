#ifndef _CONFIGURE_H_
#define _CONFIGURE_H_

char PORT[6];             //Global variable.
char WEB_SERVER[30];
char SERVER_PORT[6];
char RULES[50];
char LOG[50];
char TIME_OUT[6];
char DB[5];

void configure(void);

#endif
