#include <stdio.h>
#include <time.h>
#include "log.h"
#include "rules.h"
#include "config.h"
#include "database.h"

void toLog(char *srcIP,int id,char * message)
{
	FILE *file_log;
	struct tm *tm_ptr;
	time_t the_time;
	char atime[20];

	(void) time(&the_time);
	
//****************** getdate time **************************
	
	tm_ptr = localtime(&the_time);
	strftime(atime,256,"%d/%m/%Y %H:%M:%S",tm_ptr);
	if(strcmp(DB,"yes") != 0){
//***************** write to log file ********************
		file_log=fopen(LOG,"a+");
		fprintf(file_log,"%s\t%s\t%4d : %s\n",atime,srcIP,id,message);
		fclose(file_log);
	}
	else
	{
//**************** store log to Database ******************
		char idmessage[200];
		//printf("DATABASE LOGGING\n");
		sprintf(idmessage,"%4d : %s",id,message);
		logtoMysql(atime,srcIP,idmessage);
	}
}

