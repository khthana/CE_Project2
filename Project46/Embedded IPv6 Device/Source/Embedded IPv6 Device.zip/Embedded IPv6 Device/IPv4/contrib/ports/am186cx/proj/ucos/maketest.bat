REM Embedded IPv6 Device Project
REM by Chitsutha Soomlek
REM Last update: 4/3/2004
REM Must be edit tools path
mkdir .\obj
c:\langs\bc\bin\make -fMakefile
c:\utils\upx\upx test.exe
