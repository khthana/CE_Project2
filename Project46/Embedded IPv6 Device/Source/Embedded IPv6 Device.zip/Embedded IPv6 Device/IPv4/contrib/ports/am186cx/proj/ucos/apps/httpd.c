/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 */

#include "lwip/debug.h"

#include "lwip/stats.h"

#include "httpd.h"

#include "lwip/tcp.h"

#include "fs.h"

struct http_state {
  char *file;
  u32_t left;
  u8_t retries;
};

/*-----------------------------------------------------------------------------------*/
static void
conn_err(void *arg, err_t err)
{
  struct http_state *hs;

  hs = arg;
  mem_free(hs);
}
/*-----------------------------------------------------------------------------------*/
static void
close_conn(struct tcp_pcb *pcb, struct http_state *hs)
{
  tcp_arg(pcb, NULL);
  tcp_sent(pcb, NULL);
  tcp_recv(pcb, NULL);
  mem_free(hs);
  tcp_close(pcb);
}
/*-----------------------------------------------------------------------------------*/
static void
send_data(struct tcp_pcb *pcb, struct http_state *hs)
{
  err_t err;
  u16_t len;

  /* We cannot send more data than space available in the send
     buffer. */     
  if (tcp_sndbuf(pcb) < hs->left) {
    len = tcp_sndbuf(pcb);
  } else {
    len = hs->left;
  }

  do {
    err = tcp_write(pcb, hs->file, len, 0);
    if (err == ERR_MEM) {
      len /= 2;
    }
  } while (err == ERR_MEM && len > 1);  
  
  if (err == ERR_OK) {
    hs->file += len;
    hs->left -= len;
    /*  } else {
	printf("send_data: error %s len %d %d\n", lwip_strerr(err), len, tcp_sndbuf(pcb));*/
  }
}
/*-----------------------------------------------------------------------------------*/
static err_t
http_poll(void *arg, struct tcp_pcb *pcb)
{
  struct http_state *hs;

  hs = arg;
  
  /*  printf("Polll\n");*/
  if (hs == NULL) {
    /*    printf("Null, close\n");*/
    tcp_abort(pcb);
    return ERR_ABRT;
  } else {
    ++hs->retries;
    if (hs->retries == 4) {
      tcp_abort(pcb);
      return ERR_ABRT;
    }
    send_data(pcb, hs);
  }

  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
static err_t
http_sent(void *arg, struct tcp_pcb *pcb, u16_t len)
{
  struct http_state *hs;

  hs = arg;

  hs->retries = 0;
  
  if (hs->left > 0) {    
    send_data(pcb, hs);
  } else {
    close_conn(pcb, hs);
  }

  return ERR_OK;
}

/* This is the data for the actual web page. */
/*static char indexdata[] =
"HTTP/1.0 200 OK\r\n\
Content-type: text/html\r\n\
\r\n\
<html> \
<head><title>A test page</title></head> \
<body> \
This is a small test page. \
</body> \
</html>";
*/
/*-----------------------------------------------------------------------------------*/
static err_t
http_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err)
{
  int i,j,a,k,l,t,w;
  char *data, *iptype;
	  char * *adapteraddr;
	  char ipconfig[100],ip[100],subnet[100],way[100];
	  int ip1;
	    struct fs_file file;
  struct http_state *hs;


  hs = arg;

  if (err == ERR_OK && p != NULL) {

    /* Inform TCP that we have taken the data. */
    tcp_recved(pcb, p->tot_len);
    
    if (hs->file == NULL) {
      data = p->payload;
     
      if (strncmp(data, "GET ", 4) == 0) 
	{
					//clear by note
					for(i = 0; i < 100; i++) 
						{
							 if (((char *)data + 4)[i] == ' '  || ((char *)data + 4)[i] == '\r'  || ((char *)data + 4)[i] == '\n') 
									{
										((char *)data + 4)[i] = 0;
									}
						}

				if (*(char *)(data + 4) == '/' &&
					*(char *)(data + 5) == 0) 
						{
							printf ("FSopenning menu.html\n");
						fs_open("/check1.html", &file);
						} 
	
	else if (!fs_open((char *)data + 4, &file)) {

				 if (*(char *)(data + 4) == '/' &&
					 *(char *)(data + 18) == '4') 
					 {
							printf ("FSopenning /test/testping4\n");
							fs_open("/test/testping4.html", &file);	 
					}
				if (*(char *)(data + 4) == '/' &&
					*(char *)(data + 18) == '6') 
					{
							printf ("FSopenning /test/testping6\n");
							fs_open("/test/testping6.html", &file);	 
					}
				if(*(char *)(data + 4) == '/' &&
					*(char *)(data + 10) == 'r')
					{
							printf ("FSopenning /test/report.html\n");
							fs_open("/test/report.html", &file);
					}
			 if (*(char *)(data + 4) == '/' &&
				*(char *)(data + 17) == '4')
			{
							printf ("FSopenning /config/conip4.html\n");
						  fs_open("/config/conip4.html", &file);
                            
					//printf(data+22);
				    	j=0;	t=0;k=0;l=0;w=0;
						for(i=0;i<200;	i++)
						{

							//if ((*(char *)(data +20+i)== 'i')&&(*(char *)(data +20+i+1)== 'p'))
						
							if(*(char *)(data +20+i)== '=')
								{t++;printf("%d",t);
									for(j=0;j<4;j++)
										{ 
										     // if(*(char *)(data +20+i+j)== '='){t++; printf(t);}
											if(*(char *)(data +20+i+j)== '&')
												{
												break;
													
												 }
												 if (t<=4)
												 {   if(*(char *)(data +20+i+j)!= '='){

													ipconfig[k]=*(char *)(data +20+i+j);
										               printf("ip|");
													k++;}
												 }
											
												  if ((t<=8)&&(t>4))
											   {	 if(*(char *)(data +20+i+j)!= '='){	
													  subnet[l]=*(char *)(data +20+i+j);
										             printf("n|");
											        l++;}
											   }
												  	  if ((t<=11)&&(t>8))
											{ if(*(char *)(data +20+i+j)!= '='){
												  way[w]=*(char *)(data +20+i+j);
											printf("w|");
											        w++;}
											}
												if (t==12)break;
										}	
								   
						
						
								}
                            
						}
						for(k=k; k<50; k++)
				{
								ipconfig[k] ='\0';
				}
						for(l=l; l<50; l++)		
				{		subnet[l] ='\0';
				}
                			for(w=w; w<50; w++)		
				{		way[w] ='\0';
				}

    printf("\n");
	 
				for(k=0;k<30;	k++)
							{//*(char *)(iptype)[i] = ipconfig[i];
						      printf("%c",ipconfig[k]);
						    }
 /* printf("\n");

								for(l=0;l<30;	l++)
							{//*(char *)(iptype)[i] = ipconfig[i];
						      printf("%c",subnet[l]);
						    }
 printf("\n");

								for(w=0; w<30;	w++)
							{//*(char *)(iptype)[i] = ipconfig[i];
						      printf("%c",way[w]);
						    }*/
				for(i=0; i<50; i++){
                      
						  if ((ipconfig[i]=='1')||(ipconfig[i]=='2')||(ipconfig[i]=='3')||(ipconfig[i]=='4')||(ipconfig[i]=='5')||(ipconfig[i]=='6')
							 ||(ipconfig[i]=='7')||(ipconfig[i]=='8')||(ipconfig[i]=='9')||(ipconfig[i]=='0')){
						  
						  
							      printf("\n");
								
									 ip1    = ((int) ipconfig[1]);
								
									  ip1=(ip1-48)*100;
									
									 printf("%d",ip1);
		   
						  }
				}	   
		   }

     
		
			
		  if (*(char *)(data + 4) == '/' &&
			*(char *)(data + 17) == '6')
			  {
						printf ("FSopenning /config/conip6.html\n");
					  fs_open("/config/conipv6.html", &file);	 
				}



	}//login pass

	
	
	/*else if (!fs_open((char *)data + 4, &file)) {
		printf ("FSopenning /test/testping.html\n");
	  fs_open("/test/testping.html", &file);	 
	  printf ( &file);
	}*/
	hs->file = file.data;
	hs->left = file.len;
		//printf("data %p len %ld\n", hs->file, hs->left);
   
	//printf ("pbuf_free\n");
	pbuf_free(p);
//	printf ("send_data(pcb,hs)\n");
	send_data(pcb, hs);

	/* Tell TCP that we wish be to informed of data that has been
	   successfully sent by a call to the http_sent() function. */
//	printf ("tcp_sent\n");
	tcp_sent(pcb, http_sent);
      }//if find "GET" 
	  else
		  {
			pbuf_free(p);
			printf("CLose_conn");
			close_conn(pcb, hs);
			}
    }// if payload
	else 
		{
      pbuf_free(p);
        }
  }// if  err == ERR_OK && p != NULL

  if (err == ERR_OK && p == NULL) {
    close_conn(pcb, hs);
  }
  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
static err_t
http_accept(void *arg, struct tcp_pcb *pcb, err_t err)
{
  struct http_state *hs;

  tcp_setprio(pcb, TCP_PRIO_MIN);
  
  /* Allocate memory for the structure that holds the state of the
     connection. */
  hs = mem_malloc(sizeof(struct http_state));

  if (hs == NULL) {
    printf("http_accept: Out of memory\n");
    return ERR_MEM;
  }
  
  /* Initialize the structure. */
  hs->file = NULL;
  hs->left = 0;
  hs->retries = 0;
  
  /* Tell TCP that this is the structure we wish to be passed for our
     callbacks. */
  tcp_arg(pcb, hs);

  /* Tell TCP that we wish to be informed of incoming data by a call
     to the http_recv() function. */
  tcp_recv(pcb, http_recv);

  tcp_err(pcb, conn_err);
  
  tcp_poll(pcb, http_poll, 4);
  return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
void
httpd_init(void)
{
  struct tcp_pcb *pcb;

/* Create a new TCP PCB. */
  pcb = tcp_new();

  /* Bind the PCB to TCP port 80. */
  tcp_bind(pcb, IP_ADDR_ANY, 80);

/* Change TCP state to LISTEN. */
  pcb = tcp_listen(pcb);

/* Set up http_accept() function to be called when a new connection arrives. */
  tcp_accept(pcb, http_accept);
}
/*-----------------------------------------------------------------------------------*/

