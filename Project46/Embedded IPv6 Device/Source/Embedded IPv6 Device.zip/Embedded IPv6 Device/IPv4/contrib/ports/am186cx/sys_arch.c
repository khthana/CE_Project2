/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 * 
 * Author: Adam Dunkels <adam@sics.se>
 *
 */

/*
*********************************************************************************************************
*                                               UCOS-II Port
*
*     Target           : Any processor
*     Put together by  : Michael Anburaj
*     URL              : http://geocities.com/michaelanburaj/    Email : michaelanburaj@hotmail.com
*
*********************************************************************************************************
*/

/*
 * Port to COM86: Suriyan Laohaprapanon
 * Last update: 2003/12/10
 */

#include <stdlib.h>

#include "lwip/debug.h"

#include "lwip/def.h"
#include "lwip/sys.h"
#include "lwip/mem.h"
#include "lwip/stats.h"

#include "arch/sys_arch.h"

static struct sys_timeouts lwip_timeouts[SYS_MAX_TASKS];
struct sys_timeouts null_timeouts;

static OS_MEM *pQueueMem;
static char pcQueueMemoryPool[SYS_NUM_MBOX * sizeof(TQ_DESCR) ];

/* Static allocation tasks stack for lwIP tasks */
OS_STK sys_stack[SYS_MAX_TASKS][SYS_STACK_SIZE];

static INT8U sys_thread_no;

/*-----------------------------------------------------------------------------------*/
sys_mbox_t
sys_mbox_new(void)
{
    INT8U       ucErr;
    PQ_DESCR    pQDesc;


    pQDesc = OSMemGet( pQueueMem, &ucErr );
    LWIP_ASSERT( "OSMemGet ", ucErr == OS_NO_ERR );
    if( ucErr == OS_NO_ERR ) {   
        pQDesc->pQ = OSQCreate( &(pQDesc->pvQEntries[0]), SYS_MBOX_SIZE );       
        LWIP_ASSERT( "OSQCreate ", pQDesc->pQ != NULL );
        if( pQDesc->pQ != NULL ) {
#ifdef SYS_STATS
            lwip_stats.sys.mbox.used++;
            if (lwip_stats.sys.mbox.used > lwip_stats.sys.mbox.max) {
                lwip_stats.sys.mbox.max = lwip_stats.sys.mbox.used;
            }
#endif /* SYS_STATS */
            return pQDesc;
        }
    } 
    return SYS_MBOX_NULL;
}

/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(sys_mbox_t mbox)
{
    INT8U     ucErr;


    LWIP_ASSERT( "sys_mbox_free ", mbox != SYS_MBOX_NULL );   
#ifdef SYS_STATS
    lwip_stats.sys.mbox.used--;
#endif /* SYS_STATS */
    OSQFlush( mbox->pQ );

    (void)OSQDel( mbox->pQ, OS_DEL_NO_PEND, &ucErr);
    LWIP_ASSERT( "OSQDel ", ucErr == OS_NO_ERR );         

    ucErr = OSMemPut( pQueueMem, mbox );
    LWIP_ASSERT( "OSMemPut ", ucErr == OS_NO_ERR );
}

/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(sys_mbox_t mbox, void *msg)
{
    if( !msg )
        msg = SYS_MBOX_NULL;

    (void)OSQPost( mbox->pQ, msg);
}

/*-----------------------------------------------------------------------------------*/
u32_t
sys_arch_mbox_fetch(sys_mbox_t mbox, void **msg, u32_t timeout)
{
    INT8U ucErr;
    INT32U ucos_timeout;
    INT32U timestart, timespent;
    void *temp;


    /* convert LwIP timeout (in milliseconds) to UCOS-II timeout (in OS_TICKS) */
    if (timeout) {
        ucos_timeout = (timeout * OS_TICKS_PER_SEC)/1000L;
        if (ucos_timeout < 1)
              ucos_timeout = 1;
        else if (ucos_timeout > 65535)
              ucos_timeout = 65535;
    }
    else {
        ucos_timeout = 0;
    }

    timestart = OSTimeGet();
    temp = OSQPend( mbox->pQ, ucos_timeout, &ucErr );

    if (ucErr == OS_NO_ERR) {
        if (msg) {
            *msg = temp;
        }
    }
    else {
        if (msg) {
            *msg = NULL;
        }
    }
    timespent = ((OSTimeGet() - timestart) * 1000L) / OS_TICKS_PER_SEC;

    if( ucErr == OS_TIMEOUT ) {
        return SYS_ARCH_TIMEOUT;
    } else {
#if 0
        LWIP_ASSERT( "OSQPend ", ucErr == OS_NO_ERR );
#endif
        return timespent;
    }
}

/*-----------------------------------------------------------------------------------*/
sys_sem_t
sys_sem_new(u8_t count)
{
    sys_sem_t pSem;


    pSem = OSSemCreate( (INT16U)count );
#ifdef SYS_STATS
    lwip_stats.sys.sem.used++;
    if (lwip_stats.sys.sem.used > lwip_stats.sys.sem.max) {
        lwip_stats.sys.sem.max = lwip_stats.sys.sem.used;
    }
#endif /* SYS_STATS */
    LWIP_ASSERT( "OSSemCreate ", pSem != NULL );
    return pSem;
}
/*-----------------------------------------------------------------------------------*/
u32_t
sys_arch_sem_wait(sys_sem_t sem, u32_t timeout)
{
    INT8U  ucErr;
    INT32U ucos_timeout, timestart, timespent;


    /* convert LwIP timeout (in milliseconds) to UCOS-II timeout (in OS_TICKS) */
    if (timeout) {
        ucos_timeout = (timeout * OS_TICKS_PER_SEC)/1000L;
        if(ucos_timeout < 1L)
              ucos_timeout = 1L;
        else if(ucos_timeout > 65535L)
              ucos_timeout = 65535L;
    }
    else {
        ucos_timeout = 0L;
    }

    timestart = OSTimeGet();
    OSSemPend( sem, ucos_timeout, &ucErr );        
    timespent = ((OSTimeGet() - timestart) * 1000L) / OS_TICKS_PER_SEC;

    if( ucErr == OS_TIMEOUT ) {
        return SYS_ARCH_TIMEOUT;
    } else {
#if 0
        LWIP_ASSERT( "OSSemPend ", ucErr == OS_NO_ERR );
#endif
        return timespent;
    }
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(sys_sem_t sem)
{
    INT8U     ucErr;


    ucErr = OSSemPost( sem );
 
    /* It may happen that a connection is already reset and the semaphore is deleted
       if this function is called. Therefore ASSERTION should not be called */   
    /* LWIP_ASSERT( "OSSemPost ", ucErr == OS_NO_ERR ); */
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(sys_sem_t sem)
{
    INT8U     ucErr;


    (void)OSSemDel( sem, OS_DEL_NO_PEND, &ucErr );
#ifdef SYS_STATS
    lwip_stats.sys.sem.used--;
#endif /* SYS_STATS */    
    LWIP_ASSERT( "OSSemDel ", ucErr == OS_NO_ERR );
}

/*-----------------------------------------------------------------------------------*/
void
sys_init(void)
{
    INT8U   i;
    INT8U   ucErr;


    pQueueMem = OSMemCreate( (void *)pcQueueMemoryPool, SYS_NUM_MBOX, sizeof(TQ_DESCR), &ucErr );
    LWIP_ASSERT( "OSMemCreate ", ucErr == OS_NO_ERR );    

    sys_thread_no = 0;

    //init lwip_timeouts for every lwip task
    for (i = 0; i < SYS_MAX_TASKS; i++) {
        lwip_timeouts[i].next = NULL;
    }

}

/*-----------------------------------------------------------------------------------*/
struct sys_timeouts *
sys_arch_timeouts(void)
{
    OS_TCB task_data;
    INT16U task_id;
    INT8U ucErr, offset;


    null_timeouts.next = NULL;
    /* get current task id */
    ucErr = OSTaskQuery(OS_PRIO_SELF, &task_data);
#if 1
    task_id = task_data.OSTCBId;
#else
    task_id = task_data.OSTCBPrio;
#endif

    offset = task_id - SYS_TASK_START_PRIO;
    /* not called by a lwip task, return timeouts->NULL */
    if (offset < 0 || offset >= SYS_MAX_TASKS) {
        return &null_timeouts;
    }
    return &lwip_timeouts[offset];
}

/*-----------------------------------------------------------------------------------*/
sys_thread_t
sys_thread_new(void (* thread)(void *arg), void *arg, int prio) 
{
    OS_TCB task_data;
    INT8U ucErr;


    if (sys_thread_no > SYS_MAX_TASKS) {
        LWIP_DEBUGF(SYS_DEBUG, ("sys_thread_new: Max Sys. Tasks reached\n"));
        while (1) {
            continue;
        }
    }
#if 1
    /* Priority conlision work around by next lower priority in sequencial manner */ 
    ucErr = OSTaskQuery(SYS_TASK_START_PRIO + prio, &task_data);
    while (ucErr == OS_NO_ERR) {
        prio++;
        ucErr = OSTaskQuery(SYS_TASK_START_PRIO + prio, &task_data);
    }
#endif

    ucErr = OSTaskCreateExt(thread,
                           arg,
                           (OS_STK *)&sys_stack[sys_thread_no][SYS_STACK_SIZE - 1],
#if 1
                           SYS_TASK_START_PRIO + prio,
#else
                           SYS_TASK_START_PRIO + sys_thread_no,
#endif
                           SYS_TASK_START_PRIO + sys_thread_no,
                           (OS_STK *)&sys_stack[sys_thread_no][0],
                           SYS_STACK_SIZE,
                           (void *)0,
                           OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    if (ucErr != OS_NO_ERR) {
        LWIP_DEBUGF(SYS_DEBUG, ("sys_thread_new: Task creation error [%d]\n", ucErr));
        while (1) {
            continue;
        }
    }
    lwip_timeouts[sys_thread_no].next = NULL;
    ++sys_thread_no; /* next task created will be one lower to this one */
}
