#ifndef __PING4_H__
#define __PING4_H__

/*typedef struct icmp_req_hdr
{	u8_t	type;
	u8_t	code;
	u16_t	chksum;
	u16_t	id;
	u16_t	seqno;
	INT32U	timestamp;
};*/

void
ping4_init(int ip_a,int ip_b,int ip_c,int ip_d);

#endif /* __PING4_H__ */