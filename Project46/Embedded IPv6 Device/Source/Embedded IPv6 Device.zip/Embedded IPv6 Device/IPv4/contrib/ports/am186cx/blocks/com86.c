/*
*********************************************************************************************************
*                                        COM86 SUPPORT FUNCTIONS
*
*                               (c) Copyright 2003, NetGadgets Co., Ltd.
*                                           All Rights Reserved
*
* File     : COM86.C
* By       : COM86 Team
* Based on : PC.C by Jean J. Labrosse
*********************************************************************************************************
*/

#include <includes.h>
#include "am186cc.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/
#define  VECT_TICK                    0x08       /* Vector number for COM86 timer 1 tick               */
#define  VECT_DOS_CHAIN               0x81       /* Vector number used to chain DOS                    */

#define  ESC                          "\x1B"
#define  CSI                          ESC"["

/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/
             
static INT16U    COM86_ElapsedOverhead;
static jmp_buf   COM86_JumpBuf;
static BOOLEAN   COM86_ExitFlag;
void             (*COM86_TickISR)(void);

#ifdef COM86_COM2_CONSOLE
char SerialReadChar (void) 
{
    while ((inpw(SPSTAT) & 0x0080) > 0);                    /* wait for ready to recieve               */

    return inpw(SPRXD);
}

BOOLEAN SerialAvailable (void) 
{
    if ((inpw(SPSTAT) & 0x0080) > 0) {                      /* check RDR bit                           */
        return TRUE;
    } 
    else {
        return FALSE;
    }
}

void SerialSendChar (char sout)
{
    WORD SPSTATRegister;


    while ((inpw(SPSTAT) & 0x0040) <= 0);                   /* wait for ready to send                  */
    outpw(SPTXD, sout);
}
#else
char SerialReadChar (void) 
{
    while ((inpw(HSPSTAT) & 0x0080) > 0);                    /* wait for ready to recieve               */

    return inpw(HSPRXD);
}

BOOLEAN SerialAvailable (void) 
{
    if ((inpw(HSPSTAT) & 0x0080) > 0) {                      /* check RDR bit                           */
        return TRUE;
    } 
    else {
        return FALSE;
    }
}

void SerialSendChar (char sout)
{
    WORD SPSTATRegister;


    while ((inpw(HSPSTAT) & 0x0040) <= 0);                   /* wait for ready to send                  */
    outpw(HSPTXD, sout);
}
#endif

void SerialSendString (char *souts) 
{
	INT8U i;


	for(i = 0; i < strlen(souts); i++) {
        SerialSendChar(souts[i]) ;
	}
}

static void DispSetCursorPos (INT8U x, INT8U y)
{
    INT8U stmp[16];


    sprintf(stmp, CSI"%d;%dH", y, x);
    SerialSendString(stmp);
}

static void DispSetAttributes (INT8U fg, INT8U bg)
{
    INT8U   stmp1[16];
    INT8U   stmp2[8];

         
    sprintf(stmp1, CSI);

#if 0
    if (fg & DISP_INVISIBLE) {
        sprintf(stmp2, "%d;", ANSI_INVISIBLE);
        strcat(stmp1, stmp2);
    }
    if (fg & DISP_INVERSE) {
        sprintf(stmp2, "%d;", ANSI_INVERSE);
        strcat(stmp1, stmp2);
    }
#endif
    if (fg & DISP_BLINK) {
        sprintf(stmp2, "%d;", ANSI_BLINK);
        strcat(stmp1, stmp2);
    }
    else {
        sprintf(stmp2, "%d;", ANSI_NOBLINK);
        strcat(stmp1, stmp2);
    }
#if 0
    if (fg & DISP_UNDERLINE) {
        sprintf(stmp2, "%d;", ANSI_UNDERLINE);
        strcat(stmp1, stmp2);
    }
#endif
    if (fg & DISP_BRIGHT) {
        sprintf(stmp2, "%d;", ANSI_BOLD);
        strcat(stmp1, stmp2);
    }
    else {
        sprintf(stmp2, "%d;", ANSI_NOBOLD);
        strcat(stmp1, stmp2);
    }        
    sprintf(stmp2, "%d;%dm", (fg & 0x07) + ANSI_FGND_OFFSET, (bg & 0x07) + ANSI_BGND_OFFSET);
    strcat(stmp1, stmp2);

    SerialSendString(stmp1); 						/* Send attributes                                 */
}

void COM86_DispInit (void)
{
	SerialSendString(CSI"3h");						/* Set video mode to text 80x25 color              */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                              CLEAR SCREEN
*
* Description : This function clears the COM86's terminal screen.
*
* Arguments   : color   specifies the foreground/background color combination to use 
*                       (see COM86.H for available choices)
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DispClrScr (INT8U fg, INT8U bg)
{
    DispSetAttributes(fg, bg);
    SerialSendString(CSI"2J");
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                             CLEAR A LINE
*
* Description : This function clears one of the 25 lines on the COM86's terminal screen.
*
* Arguments   : y            corresponds to the desired line to clear.  Valid line numbers are from 
*                            0 to 24.  Line 0 corresponds to the topmost line.
*
*               color        specifies the foreground/background color combination to use 
*                            (see COM86.H for available choices)
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DispClrLine (INT8U y, INT8U fg, INT8U bg)
{
    DispSetAttributes(fg, bg);
    SerialSendString(CSI"2K");
}
/*$PAGE*/
/*
*********************************************************************************************************
*                           DISPLAY A SINGLE CHARACTER AT 'X' & 'Y' COORDINATE
*
* Description : This function writes a single character anywhere on the COM86's terminal.
*
* Arguments   : x      corresponds to the desired column on the screen.  Valid columns numbers are from
*                      0 to 79.  Column 0 corresponds to the leftmost column.
*               y      corresponds to the desired row on the screen.  Valid row numbers are from 0 to 24.
*                      Line 0 corresponds to the topmost row.
*               c      Is the ASCII character to display.  You can also specify a character with a 
*                      numeric value higher than 128.  In this case, special character based graphics
*                      will be displayed.
*               color  specifies the foreground/background color to use (see COM86.H for available color)
*                      and whether the character will blink or not.
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DispChar (INT8U x, INT8U y, INT8U c, INT8U fg, INT8U bg)
{
    DispSetCursorPos(x, y);
    DispSetAttributes(fg, bg);
    SerialSendChar(c);
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                 DISPLAY A STRING  AT 'X' & 'Y' COORDINATE
*
* Description : This function writes an ASCII string anywhere on the PC's terminal.
*
* Arguments   : x      corresponds to the desired column on the screen.  Valid columns numbers are from
*                      0 to 79.  Column 0 corresponds to the leftmost column.
*               y      corresponds to the desired row on the screen.  Valid row numbers are from 0 to 24.
*                      Line 0 corresponds to the topmost row.
*               s      Is the ASCII string to display.  You can also specify a string containing 
*                      characters with numeric values higher than 128.  In this case, special character 
*                      based graphics will be displayed.
*               color  specifies the foreground/background color to use (see COM86.H for available color)
*                      and whether the characters will blink or not.
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DispStr (INT8U x, INT8U y, INT8U *s, INT8U fg, INT8U bg)
{
    DispSetCursorPos(x, y);
    DispSetAttributes(fg, bg);
    SerialSendString(s);
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                             RETURN TO DOS
*
* Description : This functions returns control back to DOS by doing a 'long jump' back to the saved
*               location stored in 'COM86_JumpBuf'.  The saved location was established by the function
*               'COM86_DOSSaveReturn()'.  After execution of the long jump, execution will resume at the 
*               line following the 'set jump' back in 'COM86_DOSSaveReturn()'.  Setting the flag 
*               'COM86_ExitFlag' to TRUE ensures that the 'if' statement in 'COM86_DOSSaveReturn()' 
*               executes.
*
* Arguments   : None
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DOSReturn (void)
{
    COM86_ExitFlag = TRUE;                                 /* Indicate we are returning to DOS         */
    longjmp(COM86_JumpBuf, 1);                             /* Jump back to saved environment           */
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                        SAVE DOS RETURN LOCATION
*
* Description : This function saves the location of where we are in DOS so that it can be recovered.
*               This allows us to abort multitasking under uC/OS-II and return back to DOS as if we had
*               never left.  When this function is called by 'main()', it sets 'COM86_ExitFlag' to FALSE
*               so that we don't take the 'if' branch.  Instead, the CPU registers are saved in the
*               long jump buffer 'COM86_JumpBuf' and we simply return to the caller.  If a 'long jump' is
*               performed using the jump buffer then, execution would resume at the 'if' statement and
*               this time, if 'COM86_ExitFlag' is set to TRUE then we would execute the 'if' statements
*               and restore the DOS environment.
*
* Arguments   : None
*
* Returns     : None
*********************************************************************************************************
*/
void COM86_DOSSaveReturn (void)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif


    COM86_ExitFlag  = FALSE;                                /* Indicate that we are not exiting yet!   */
    OSTickDOSCtr =     1;                                   /* Initialize the DOS tick counter         */
    COM86_TickISR   = COM86_VectGet(VECT_TICK);             /* Get MS-DOS's tick vector                */
    
    COM86_VectSet(VECT_DOS_CHAIN, COM86_TickISR);           /* Store MS-DOS's tick to chain            */
    
    setjmp(COM86_JumpBuf);                                  /* Capture where we are in DOS             */
    if (COM86_ExitFlag == TRUE) {                           /* See if we are exiting back to DOS       */
        OS_ENTER_CRITICAL();
        COM86_SetTickRate(18);                              /* Restore tick rate to 18.2 Hz            */
        COM86_VectSet(VECT_TICK, COM86_TickISR);            /* Restore DOS's tick vector               */
        OS_EXIT_CRITICAL();
        COM86_DispClrScr(DISP_WHITE, DISP_BLACK);/* Clear the display                       */
        exit(0);                                            /* Return to DOS                           */
    }
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                       ELAPSED TIME INITIALIZATION
*
* Description : This function initialize the elapsed time module by determining how long the START and
*               STOP functions take to execute.  In other words, this function calibrates this module
*               to account for the processing time of the START and STOP functions.
*
* Arguments   : None.
*
* Returns     : None.
*********************************************************************************************************
*/
void COM86_ElapsedInit(void)
{
    COM86_ElapsedOverhead = 0;
    COM86_ElapsedStart();
    COM86_ElapsedOverhead = COM86_ElapsedStop();
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                       INITIALIZE COM86'S TIMER #1
*
* Description : This function initialize the COM86's Timer #1 to be used to measure the time between
*               events. Timer #1 will be running when the function returns.
*
* Arguments   : None.
*
* Returns     : None.
*********************************************************************************************************
*/
void COM86_ElapsedStart(void)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif

    OS_ENTER_CRITICAL();
    outpw(T1CON, TCON_INH);                                 /* Disable timer #1                        */
    outpw(T1CNT, 0x0000);
    outpw(T1CMPA, 0xFFFF);
    outpw(T1CMPB, 0xFFFF);
    outpw(T1CON, TCON_ALT);                                 /* Set timer 1 mode                        */
    outpw(T1CON, (INT16U)inpw(T1CON) | TCON_EN | TCON_INH); /* Start the timer in dual max count mode  */
    OS_EXIT_CRITICAL();
}
/*$PAGE*/
/*
*********************************************************************************************************
*                               STOP THE COM86'S TIMER #1 AND GET ELAPSED TIME
*
* Description : This function stops the COM86's Timer #1, obtains the elapsed counts from when it was
*               started and converts the elapsed counts to micro-seconds.
*
* Arguments   : None.
*
* Returns     : The number of micro-seconds since the timer was last started.
*
* Notes       : - The returned time accounts for the processing time of the START and STOP functions.
*               - 10923 represents S-16 or, 0.166672 which is used to convert timer counts to
*                 micro-seconds.  The clock source for the COM86's timer #1 is 6.0 MHz (or 0.166667 uS)
*********************************************************************************************************
*/
INT16U COM86_ElapsedStop(void)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
    ULONG  cnts;
    INT16U ctrl;


    OS_ENTER_CRITICAL();
    cnts = inpw(T1CNT);
    ctrl = inpw(T1CON);
    outpw(T1CON, TCON_INH);
    if (ctrl & TCON_MC) {
       if (ctrl & TCON_RIU) {
           cnts += 65536L;
       }
       else {
           cnts = (ULONG)(2 * 65536L);
       }
    }
    OS_EXIT_CRITICAL();
    return ((INT16U)((ULONG)cnts * 10923L >> 16) - COM86_ElapsedOverhead);
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                       GET THE CURRENT DATE AND TIME
*
* Description: This function obtains the current date and time from the COM86.
*
* Arguments  : s     is a pointer to where the ASCII string of the current date and time will be stored.
*                    You must allocate at least 19 bytes (includes the NUL) of storage in the return 
*                    string.
*
* Returns    : none
*********************************************************************************************************
*/
void COM86_GetDateTime (char *s)
{
    struct time now;
    struct date today;


    gettime(&now);
    getdate(&today);
    sprintf(s, "%02d-%02d-%02d  %02d:%02d:%02d",
               today.da_mon,
               today.da_day,
               today.da_year,
               now.ti_hour,
               now.ti_min,
               now.ti_sec);
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                        CHECK AND GET KEYBOARD KEY
*
* Description: This function checks to see if a key has been pressed at the keyboard and returns TRUE if
*              so.  Also, if a key is pressed, the key is read and copied where the argument is pointing
*              to.
*
* Arguments  : c     is a pointer to where the read key will be stored.
*
* Returns    : TRUE  if a key was pressed
*              FALSE otherwise
*********************************************************************************************************
*/
BOOLEAN COM86_GetKey (INT16S *c)
{
    if (kbhit()) {                                         /* See if a key has been pressed            */
        *c = getch();                                      /* Get key pressed                          */
        return (TRUE);
    } else {
        *c = 0x00;                                         /* No key pressed                           */
        return (FALSE);
    }
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                    SET THE COM86'S TICK FREQUENCY
*
* Description: This function is called to change the tick rate of a COM86.
*
* Arguments  : freq      is the desired frequency of the ticker (in Hz)
*
* Returns    : none
*
* Notes      : 1) Normally COM86 set timer 2 to 1147 Hz and using to pre-scale timer 0.
*              2) The equation computes the counts needed to load into the T0CMPA.  The strange equation
*                 is actually used to round the number using integer arithmetic.  This is equivalent to
*                 the floating point equation:
*
*                              1147.0 Hz
*                     count = ------------ + 0.5
*                                 freq
*********************************************************************************************************
*/
void COM86_SetTickRate (INT16U freq)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
    INT16U count;


    if (freq == 18) {                            /* See if we need to restore the DOS frequency        */
        count = 63;                              /* Restore original COM86 maximum count value         */
    }
    else if (freq > 0) {                        
                                                 /* Compute COM86 counts for desired frequency and ... */
                                                 /* ... round to nearest count                         */
        count = (INT16U)(((INT32U)(1147L * 2) / freq + 1) >> 1); 
    }
    else {
        count = 0;
    }
    OS_ENTER_CRITICAL();
    outpw(T0CON, TCON_INH);                       /* Disable timer                                     */
    outpw(T0CNT, 0x0000);
    outpw(T0CMPA, count);
    outpw(T0CON, TCON_CONT | TCON_P);             /* Set timer mode                                    */
    outpw(T0CON, (INT16U)inpw(T0CON) | TCON_EN | TCON_INH);/* Enable timer                             */
    outpw(EOI, ITYPE_TMR0);
    outpw(CH0CON, 0x0034);                        /* Enabled Timer 0 Interrupt with 4 priority         */
    outpw(T0CON, (INT16U)inpw(T0CON) & ~(TCON_INH | TCON_MC) | TCON_INT);
    OS_EXIT_CRITICAL();
}
/*$PAGE*/
/*
*********************************************************************************************************
*                                        OBTAIN INTERRUPT VECTOR
*
* Description: This function reads the pointer stored at the specified vector.
*
* Arguments  : vect  is the desired interrupt vector number, a number between 0 and 255.
*
* Returns    : none
*********************************************************************************************************
*/
void *COM86_VectGet (INT8U vect)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif    
    INT16U    *pvect;
    INT16U     off;
    INT16U     seg;
    
    
    pvect = (INT16U *)MK_FP(0x0000, vect * 4);        /* Point into IVT at desired vector location     */
    OS_ENTER_CRITICAL();
    off   = *pvect++;                                 /* Obtain the vector's OFFSET                    */
    seg   = *pvect;                                   /* Obtain the vector's SEGMENT                   */
    OS_EXIT_CRITICAL();
    return (MK_FP(seg, off));
}

/*
*********************************************************************************************************
*                                        INSTALL INTERRUPT VECTOR
*
* Description: This function sets an interrupt vector in the interrupt vector table.
*
* Arguments  : vect  is the desired interrupt vector number, a number between 0 and 255.
*              isr   is a pointer to a function to execute when the interrupt or exception occurs.
*
* Returns    : none
*********************************************************************************************************
*/
void COM86_VectSet (INT8U vect, void (*isr)(void))
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif    
    INT16U    *pvect;
    
    
    pvect    = (INT16U *)MK_FP(0x0000, vect * 4);     /* Point into IVT at desired vector location     */
    OS_ENTER_CRITICAL();
    *pvect++ = (INT16U)FP_OFF(isr);                   /* Store ISR offset                              */
    *pvect   = (INT16U)FP_SEG(isr);                   /* Store ISR segment                             */
    OS_EXIT_CRITICAL();
}
