#include "lwip/sys.h"
#include "lwip/api.h"
#include "lwip/sockets.h"
#include "C:/lwIP/Cat6/lwip/src/include/ipv6/lwip/inet.h"
#include "C:/lwIP/Cat6/lwip/src/include/ipv6/lwip/icmp.h"
#include "C:/lwIP/Cat6/lwip/src/include/ipv6/lwip/ip.h"
#include "C:/lwIP/Cat6/lwip/src/include/ipv6/lwip/ip_addr.h"

typedef struct icmp_req_hdr
{	u8_t	type;
	u8_t	code;
	u16_t	chksum;
	u16_t	id;
	u16_t	seqno;
	INT32U	timestamp;
};	

#define IP6_ADDR(ipaddr, a,b,c,d,e,f,g,h); 

struct ip_addr dest6;

static void 
ping6_thread(void *arg)
{		struct icmp_req_hdr* echo_request;
		struct sockaddr s;
		struct sockaddr_in s_dest;
		struct pbuf *p;
			
		err_t err;

		echo_request -> type = 128;	
		echo_request -> code = 0;	
		echo_request -> chksum = 0; //initial
		echo_request -> id = 0; //initial
		echo_request -> seqno = 0; //initial;
		echo_request -> timestamp = OSTimeGet();
		
		echo_request -> chksum = inet_chksum(echo_request,sizeof(echo_request)+128);

		p->next = NULL;
		p->payload = echo_request;		
		p->len = sizeof(echo_request) + 128;
		p->tot_len = sizeof(echo_request) + 128;
		p->flags = PBUF_FLAG_RAM;
		p->ref = 1;
				
		err = ip_output_if6(p,NULL,&dest6,255,0x01,ip_route(&dest6));	
		pbuf_free(p);		
}

void
ping6_init(unsigned int ip_a,unsigned int ip_b,unsigned int ip_c,unsigned int ip_d,unsigned int ip_e,unsigned int ip_f,unsigned int ip_g,unsigned int ip_h)
{
	IP6_ADDR(&dest6,ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h);
	//printf("%x %x %x %x %x %x %x %x",ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h);
	
	sys_thread_new(ping6_thread, NULL, DEFAULT_THREAD_PRIO);
}