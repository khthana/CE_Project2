#include "lwip/sys.h"
#include "lwip/api.h"
#include "lwip/sockets.h"
#include "lwip/inet.h"
#include "lwip/icmp.h"
#include "lwip/ip.h"

typedef struct icmp_req_hdr
{	u8_t	type;
	u8_t	code;
	u16_t	chksum;
	u16_t	id;
	u16_t	seqno;
	INT32U	timestamp;
};	

struct ip_addr dest;

static void 
ping4_thread(void *arg)
{
		struct icmp_req_hdr* echo_request;
	/*	struct sockaddr s;
		struct sockaddr_in *s_dest; */
		struct pbuf *p;
	//	int sock;

	/*	struct ip_addr naddr;
		u16_t port;
		struct sockaddr_in sin;
		int x;*/
				
		err_t err;

		echo_request -> type = 8;	
		echo_request -> code = 0;	
		echo_request -> chksum = 0; //initial
		echo_request -> id = 0; //initial
		echo_request -> seqno = 0; //initial;
		echo_request -> timestamp = OSTimeGet();
		
		echo_request -> chksum = inet_chksum(echo_request,sizeof(echo_request)+32);

		p->next = NULL;
		p->payload = echo_request;		
		p->len = sizeof(echo_request) + 32;
		p->tot_len = sizeof(echo_request) + 32;
		p->flags = PBUF_FLAG_RAM;
		p->ref = 1;
		
	/*	sock = lwip_socket(AF_INET,SOCK_RAW,IPPROTO_IP); //socket
		s_dest -> sin_family = AF_INET;
		s_dest -> sin_port = htons(0);
		s_dest.sin_addr.s_addr = dest.addr;
	*/	
		
		/* memset(&sin, 0, sizeof(sin));
		 sin.sin_len = sizeof(sin);
		 sin.sin_family = AF_INET;
		 sin.sin_port = htons(port);
		 sin.sin_addr.s_addr = naddr.addr;

		 x = lwip_sendto(s, p,sizeof(echo_request) + 32,0,
       &dest,sizeof(s));*/

		err = ip_output_if(p,NULL,&dest,255,0,0x01,ip_route(&dest));	
		pbuf_free(p);		
}	

void
ping4_init(int ip_a,int ip_b,int ip_c,int ip_d)
{	
	IP4_ADDR(&dest,ip_a,ip_b,ip_c,ip_d);
	sys_thread_new(ping4_thread, NULL, DEFAULT_THREAD_PRIO);	
}