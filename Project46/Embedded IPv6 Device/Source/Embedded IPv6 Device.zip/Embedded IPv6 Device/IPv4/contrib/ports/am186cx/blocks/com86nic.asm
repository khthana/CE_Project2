;********************************************************************************************************
;                                 COM86 NIC ISR Wrapper for MicroC/OS-II
;
;                                       80x86/80x88 Specific code
;                                          LARGE MEMORY MODEL
;
; File : COM86NIC.ASM
; By   : Suriyan Laohaprapanon
;********************************************************************************************************

.MODEL LARGE
.186
            EXTRN  _OSIntEnter:FAR
            EXTRN  _OSIntExit:FAR
            EXTRN  _rtl8019_isr:FAR

            EXTRN  _OSIntNesting:BYTE
            EXTRN  _OSTCBCur:DWORD

.CODE
            PUBLIC _OSNicISR

;*********************************************************************************************************
;                                            HANDLE NIC ISR
;*********************************************************************************************************

_OSNicISR   PROC   FAR

            PUSHA                                     ; Save task's context
            PUSH   ES
            PUSH   DS
;
            MOV    AX, SEG(_OSIntNesting)             ; Reload DS
            MOV    DS, AX
            INC    BYTE PTR DS:_OSIntNesting          ; Notify uC/OS-II of ISR

            LES BX, DWORD PTR DS:_OSTCBCur            ; OSTCBCur->OSTCBStkPtr = SS:SP
            MOV ES:[BX+2], SS
            MOV ES:[BX+0], SP

            CALL   FAR PTR _rtl8019_isr               ; Process network system
            CALL   FAR PTR _OSIntExit                 ; Notify uC/OS of end of ISR
;
            POP    DS                                 ; Restore interrupted task's context
            POP    ES
            POPA
;
            IRET                                      ; Return to interrupted task

_OSNicISR   ENDP

            END
