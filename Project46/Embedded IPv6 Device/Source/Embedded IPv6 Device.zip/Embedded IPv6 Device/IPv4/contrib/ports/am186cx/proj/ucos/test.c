#include <includes.h>

#include "lwip/debug.h"

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/memp.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"

#include "lwip/tcpip.h"
#include "lwip/api.h"

#include "netif/etharp.h"
#include "netif/loopif.h"
#include "netif/rtl8019.h"
#include "arch/sys_arch.h"

#include "tcpecho.h"
#include "shell.h"
#include "httpd.h"
#include "chargen.h"
#include "ping4.h"
#include "ping6.h"

#include "C:/lwIP/Cat6/lwip/src/include/ipv6/lwip/ip_addr.h"

/**** CONSTANTS ****/

#define     TASK_STK_SIZE     512                /* Size of each task's stacks (# of WORDs)       */

#define     TASK_START_ID      4                /* Application tasks IDs                         */
#define		TASK_SETIP4_ID	   5
#define		TASK_PING_ID	   6 
#define		TASK_SETIP6_ID	   7
#define		TASK_6TO4_ID	   8	
#define		TASK_IP4COMPAT_ID  9
#define		TASK_PING6_ID	   10

#define     TASK_START_PRIO    4                /* Application tasks priorities                  */
#define		TASK_SETIP4_PRIO   5 	
#define		TASK_PING_PRIO	   6	
#define		TASK_SETIP6_PRIO   7
#define		TASK_6TO4_PRIO	   8
#define		TASK_IP4COMPAT_PRIO 9
#define		TASK_PING6_PRIO	   10

#define PRINT    COM86_Printf

#define IP6_ADDR(ipaddr, a,b,c,d,e,f,g,h)
#define IPv6

/**** VARIABLES ****/

OS_STK      TaskStartStk[TASK_STK_SIZE];            /* Startup    task stack                         */
OS_STK		TaskSetIP4Stk[TASK_STK_SIZE];
OS_STK		TaskPingStk[TASK_STK_SIZE];
OS_STK		TaskSetIP6Stk[TASK_STK_SIZE];
OS_STK		Task6TO4Stk[TASK_STK_SIZE];
OS_STK		TaskIP4COMPATStk[TASK_STK_SIZE];
OS_STK		TaskPing6Stk[TASK_STK_SIZE];

OS_EVENT	*AckMbox1;	//for set ip4
OS_EVENT	*TxMbox1;	
OS_EVENT	*AckMbox2;	//for ping
OS_EVENT	*TxMbox2;
OS_EVENT	*AckMbox3;	//for set ip6
OS_EVENT	*TxMbox3;	
OS_EVENT	*AckMbox4;	//for ip6-6to4
OS_EVENT	*TxMbox4;	
OS_EVENT	*AckMbox5;	//for ip6-IPv4 compatible
OS_EVENT	*TxMbox5;	
OS_EVENT	*AckMbox6;	//for ping6
OS_EVENT	*TxMbox6;

/**** FUNCTION PROTOTYPES ****/

       void TaskStart(void *data);                  /* Function prototypes of tasks                  */	   
	   void	TaskSetIP4(void *data); 
	   void TaskPing(void *data);
	   void TaskSetIP6(void *data);
	   void Task6to4(void *data);
	   void TaskIP4Compat(void *data);
	   void TaskPing6(void *data);
static void tcpip_init_done(void *arg);
static void menu(void);
int* convert_ip_input(INT16S ip_input[20]);
unsigned int* convert_ip6_input(INT16S ip_input[40]);
void set_link_local(void);
int* convert_6to4(INT16S ip_input[16]);

/**** MAIN ****/
void main (void)
{
    OS_STK *ptos;
    OS_STK *pbos;
    INT32U  size;
    
	OSInit();                                              /* Initialize uC/OS-II                      */

    COM86_DOSSaveReturn();                                 /* Save environment to return to DOS        */
    COM86_VectSet(uCOS, OSCtxSw);                          /* Install uC/OS-II's context switch vector */

    ptos        = &TaskStartStk[TASK_STK_SIZE - 1];        /* TaskStart() will use Floating-Point      */
    pbos        = &TaskStartStk[0];
    size        = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size);            
    OSTaskCreateExt(TaskStart,(void *)0,ptos,TASK_START_PRIO,TASK_START_ID,
		           pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);					


    OSStart();                                             /* Start multitasking                       */
}

/**** STARTUP TASK ****/
#if 0
struct netif netif;
struct netif loopif;
#endif

void  TaskStart (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    INT16S key;				//sign 16 bits integer

	OS_STK *ptos;
    OS_STK *pbos;
    INT32U  size;

	char txmsg;
	INT8U err;

    pdata = pdata;                                         /* Prevent compiler warning                 */	

	txmsg = 'a';

	menu();
	
	OS_ENTER_CRITICAL();                                   /* Install uC/OS-II's clock tick ISR        */
    COM86_VectSet(COM86_TICK_ITYPE, OSTickISR);	 //set interrupt vector in the interrupt vector table->0x08 timer0 interrupt type,maximum number of tasks allowed
    COM86_SetTickRate(OS_TICKS_PER_SEC);                   /* Reprogram tick rate                      */

    COM86_VectSet(COM86_NIC_ITYPE, OSNicISR);              /* Network ISR */ // 0x17 RTL8019AS Interrupt type 	
				
    OS_EXIT_CRITICAL();

    OSStatInit();         /* Initialize uC/OS-II's statistics         */

	AckMbox1 = OSMboxCreate((void *)0);
	TxMbox1 = OSMboxCreate((void *)0);
	AckMbox2 = OSMboxCreate((void *)0);
	TxMbox2 = OSMboxCreate((void *)0);
	AckMbox3 = OSMboxCreate((void *)0);
	TxMbox3 = OSMboxCreate((void *)0);
	AckMbox4 = OSMboxCreate((void *)0);
	TxMbox4 = OSMboxCreate((void *)0);
	AckMbox5 = OSMboxCreate((void *)0);
	TxMbox5 = OSMboxCreate((void *)0);
	AckMbox6 = OSMboxCreate((void *)0);
	TxMbox6 = OSMboxCreate((void *)0);

	ptos = &TaskSetIP4Stk[TASK_STK_SIZE - 1];        
    pbos = &TaskSetIP4Stk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
	OSTaskCreateExt(TaskSetIP4,(void *)0,ptos,TASK_SETIP4_PRIO,TASK_SETIP4_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	ptos = &TaskPingStk[TASK_STK_SIZE - 1];        
    pbos = &TaskPingStk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
    OSTaskCreateExt(TaskPing,(void *)0,ptos,TASK_PING_PRIO,TASK_PING_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	ptos = &TaskSetIP6Stk[TASK_STK_SIZE - 1];        
    pbos = &TaskSetIP6Stk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
	OSTaskCreateExt(TaskSetIP6,(void *)0,ptos,TASK_SETIP6_PRIO,TASK_SETIP6_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	ptos = &Task6TO4Stk[TASK_STK_SIZE - 1];        
    pbos = &Task6TO4Stk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
	OSTaskCreateExt(Task6to4,(void *)0,ptos,TASK_6TO4_PRIO,TASK_6TO4_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	ptos = &TaskIP4COMPATStk[TASK_STK_SIZE - 1];        
    pbos = &TaskIP4COMPATStk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
	OSTaskCreateExt(TaskIP4Compat,(void *)0,ptos,TASK_IP4COMPAT_PRIO,TASK_IP4COMPAT_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	ptos = &TaskPing6Stk[TASK_STK_SIZE - 1];        
    pbos = &TaskPing6Stk[0];
    size = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size); 
    OSTaskCreateExt(TaskPing6,(void *)0,ptos,TASK_PING6_PRIO,TASK_PING6_ID,
					pbos,size,(void *)0,OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR); 

	for (;;) {
        if (COM86_GetKey(&key)) {                          /* See if key has been pressed              */
            switch(key)
			{	case 0x1B: outport(IMASK, inport(IMASK) | IMASK_CH9);	//ESC
                           COM86_DOSReturn();                         
						   break;						
            	case 0x31: OSMboxPost(TxMbox1,(void *)&txmsg);	//1 IPv4
						   OSMboxPend(AckMbox1,0,&err);
						   break;							
				case 0x32: OSMboxPost(TxMbox3,(void *)&txmsg);	//2 IPv6
						   OSMboxPend(AckMbox3,0,&err);
						   break;		
				case 0x33: OSMboxPost(TxMbox2,(void *)&txmsg);	//3 ping4
						   OSMboxPend(AckMbox2,0,&err);
						   break;								
				case 0x34: OSMboxPost(TxMbox6,(void *)&txmsg);	//4 ping6
						   OSMboxPend(AckMbox6,0,&err);
						   break;
				case 0x35: menu(); break;						//5
				default: PRINT("\nERROR!! \nENTER THE SPECIFIED NUMBER \n"); 
				         menu(); break;
			}
        }		
		OSCtxSwCtr = 0;                                    /* Clear context switch counter             */
        OSTimeDly(OS_TICKS_PER_SEC);                       /* Wait one second                          */
    }
}

/*******FUNCTION*******/
static void
tcpip_init_done(void *arg)
{
  sys_sem_t *sem;
  sem = arg;
  sys_sem_signal(*sem);
}

static void
menu(void)
{	PRINT("############# WELCOME TO MENU #############\n");
	PRINT("BY CHITSUTHA SOOMLEK AND THITIWUT SILLAPAPIPAT\n");
	PRINT("############### ESL CE KMITL ##############\n\n");
	PRINT("[ESC] = EXIT   [1] = SET IPv4\n");
	PRINT("[2] = SET IPv6 [3] = PING\n");
	PRINT("[4] = PING6    [5] = VIEW MENU\n\n");
}

int* convert_ip_input(INT16S ip_input[20])
{	int ip_int[20];
	int ip_out[6];
	int i,count = 0;
	int j,k = 0;
				
	for (k = 0;k<=4 ;k++ )
	{	ip_out[k] = 0;
	}

	i = 0;
	j = 0;
	for (i = 0;i <= 20;i++)
	{	if ((ip_input[i] == '.')&& (j<=6) )
		{	if (count >= 3)
			{ ip_out[j] = (ip_int[i-3]*100)+(ip_int[i-2]*10)+(ip_int[i-1]);			  
			}
			else if(count == 2)
			{ ip_out[j] = (ip_int[i-2]*10)+(ip_int[i-1]);			 
			}
			else if(count == 1)
			{ ip_out[j] = ip_int[i-1];			  
			}
			j++;
			count = 0;
		}
		else
		{	count++;
			switch(ip_input[i])
			{	case 0x30: ip_int[i] = 0; break;		//0
				case 0x31: ip_int[i] = 1; break;		//1
				case 0x32: ip_int[i] = 2; break;		//2
				case 0x33: ip_int[i] = 3; break;		//3
				case 0x34: ip_int[i] = 4; break;		//4
				case 0x35: ip_int[i] = 5; break;    	//5
				case 0x36: ip_int[i] = 6; break;		//6
				case 0x37: ip_int[i] = 7; break;		//7
				case 0x38: ip_int[i] = 8; break;		//8
				case 0x39: ip_int[i] = 9; break;		//9			
				default: ip_int[i] = 0; break;		//other = 0
			}
		}		
	}	
	return(ip_out);	
}

unsigned int* convert_ip6_input(INT16S ip_input[40])
{	int ip_int[40];
	unsigned int ip_out[8];
	int i,count = 0;
	int j,k = 0;
				
	for (k = 0;k<=8 ;k++ )
	{	ip_out[k] = 0;
	}

	i = 0;
	j = 0;
	for (i = 0;i <= 40;i++)
	{	if ((ip_input[i] == ':')&& (j<=8) )
		{	
			if(count==4)
			{	ip_out[j] = (ip_int[i-4]*4096)+(ip_int[i-3]*256)+(ip_int[i-2]*16)+(ip_int[i-1]);	
			}
			else if (count == 3)
			{	ip_out[j] = (ip_int[i-3]*256)+(ip_int[i-2]*16)+(ip_int[i-1]);
			}
			else if(count == 2)
			{	ip_out[j] = (ip_int[i-2]*16)+(ip_int[i-1]);
			}
			else if(count == 1)
			{	ip_out[j] = ip_int[i-1];
			}
			
			j++;
			count = 0;
		}
		else
		{	count++;
			switch(ip_input[i])
			{	case 0x30: ip_int[i] = 0; break;		//0
				case 0x31: ip_int[i] = 1; break;		//1
				case 0x32: ip_int[i] = 2; break;		//2
				case 0x33: ip_int[i] = 3; break;		//3
				case 0x34: ip_int[i] = 4; break;		//4
				case 0x35: ip_int[i] = 5; break;    	//5
				case 0x36: ip_int[i] = 6; break;		//6
				case 0x37: ip_int[i] = 7; break;		//7
				case 0x38: ip_int[i] = 8; break;		//8
				case 0x39: ip_int[i] = 9; break;		//9			
				case 0x61: ip_int[i] = 10; break;		//a
				case 0x62: ip_int[i] = 11; break;		//b
				case 0x63: ip_int[i] = 12; break;		//c
				case 0x64: ip_int[i] = 13; break;		//d
				case 0x65: ip_int[i] = 14; break;		//e
				case 0x66: ip_int[i] = 15; break;		//f				
				default: ip_int[i] = 0; break;		//other = 0
			}
		}		
	}	
	return(ip_out);	
}

void set_link_local(void)
{	struct ip_addr ipaddr, netmask, gw;
	sys_sem_t sem;
	unsigned int ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h;
	unsigned int gw_a,gw_b,gw_c,gw_d,gw_e,gw_f,gw_g,gw_h;
	unsigned int net_a,net_b,net_c,net_d,net_e,net_f,net_g,net_h;
	
	INT16S key;
	INT16S ip_input[40];
	
	int x = 0;
	int i = 0;	
	unsigned int* temp;
	
	//get ip addr		
		for (x = 0; x <= 40; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
    
		printf("ENTER IPv6 Link Local ADDRESS (a:b:c:d:e:f:g:h):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');
		ip_input[i-1]=':';
		printf("\n");
		
		temp = convert_ip6_input(ip_input);

		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3);
		ip_e = *(temp+4);
		ip_f = *(temp+5);
		ip_g = *(temp+6);
		ip_h = *(temp+7);

		printf("ENTER GATEWAY ADDRESS (a:b:c:d:e:f:g:h):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');
		ip_input[i-1]=':';
		printf("\n");
		
		temp = convert_ip6_input(ip_input);

		gw_a = *temp;
		gw_b = *(temp+1);
		gw_c = *(temp+2);
		gw_d = *(temp+3);
		gw_e = *(temp+4);
		gw_f = *(temp+5);
		gw_g = *(temp+6);
		gw_h = *(temp+7);

	/*	printf("ENTER PREFIX (a:b:c:d:e:f:g:h):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');
		ip_input[i-1]=':';
		printf("\n");
		
		temp = convert_ip6_input(ip_input);

		net_a = *temp;
		net_b = *(temp+1);
		net_c = *(temp+2);
		net_d = *(temp+3);
		net_e = *(temp+4);
		net_f = *(temp+5);
		net_g = *(temp+6);
		net_h = *(temp+7);
*/
		net_a = 255;
		net_b = 255;
		net_c = 255;
		net_d = 255;
		net_e = 255;
		net_f = 255;
		net_g = 255;
		net_h = 255;
	//init system
		printf("+-+-+-+-+-System is started.+-+-+-+-+-\n");
	#ifdef STATS
		stats_init();
	#endif /* STATS */
		sys_init();		
		mem_init();		
		memp_init();	
		pbuf_init();	
		printf("+-+-+-+-System is initialized.+-+-+-+-\n");

		netif_init();	
		sem = sys_sem_new(0);	
		tcpip_init(tcpip_init_done, &sem);	
		sys_sem_wait(sem);	
		sys_sem_free(sem);	
		printf("+-+-+-+-TCP/IP is initialized.+-+-+-+-\n");
		/*
		* add loop interface
		*/
    
		IP6_ADDR(&gw, 0,0,0,0,0,0,0,1);	
		IP6_ADDR(&ipaddr, 0,0,0,0,0,0,0,1);
		IP6_ADDR(&netmask, 0,0,0,0,255,0,0,0);	
	#if 0
		netif_add(&loopif, &ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);	
	#else
		netif_add(&ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
	#endif
		 /*
		* add rtl8019as interface
		*/

		IP6_ADDR(&gw,gw_a,gw_b,gw_c,gw_d,gw_e,gw_f,gw_g,gw_h);
		IP6_ADDR(&ipaddr,ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h);
		IP6_ADDR(&netmask,net_a,net_b,net_c,net_d,net_e,net_f,net_g,net_h);	

	#if 0
		netif_set_default(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));	
	#else
		netif_set_default(netif_add(&ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
	#endif	

		printf("--IPv6 SETTING IS COMPLETE--\n");
		printf("Current settting: IPv6    %x:%x:%x:%x:%x:%x:%x:%x\n",ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h);
		printf("                  Gateway %x:%x:%x:%x:%x:%x:%x:%x\n",gw_a,gw_b,gw_c,gw_d,gw_e,gw_f,gw_g,gw_h);
		//printf("                  Prefix %x:%x:%x:%x:%x:%x:%x:%x\n",net_a,net_b,net_c,net_d,net_e,net_f,net_g,net_h);

		tcpecho_init();	
		printf("  tcpecho is created!\n");
		shell_init();	
		printf("  shell is created!\n");
		httpd_init();	
		printf("  httpd is created!\n");
		chargen_init();	
		printf("  chargen is created!\n");
}

int* convert_6to4(INT16S ip_input[16])
{	int ip_int[16];
	int ip_out[4];
	int i,count = 0;
	int j,k = 0;
				
	for (k = 0;k<=4 ;k++ )
	{	ip_out[k] = 0;
	}

	i = 5;
	j = 0;
	for (i = 5;i <= 16;i++)
	{	if ((ip_input[i] == ':')&& (j<=4) )
		{	
			if (count == 4)
			{	ip_out[j] = (ip_int[i-4]*16)+ ip_int[i-3]; 
				ip_out[j+1] = (ip_int[i-2]*16)+ ip_int[i-1]; 
			}
			else if (count == 3)
			{	ip_out[j] = ip_int[i-3]; 
				ip_out[j+1] = (ip_int[i-2]*16)+ ip_int[i-1]; 
			}
			else if(count == 2)
			{	ip_out[j] = 0; 
				ip_out[j+1] = (ip_int[i-2]*16)+ ip_int[i-1];  
			}
			else if(count == 1)
			{	ip_out[j] = 0; 
				ip_out[j+1] = ip_int[i-1];  
			}
			j+=2;
			count = 0;
		}
		else
		{	count++;
			switch(ip_input[i])
			{	case 0x30: ip_int[i] = 0; break;		//0
				case 0x31: ip_int[i] = 1; break;		//1
				case 0x32: ip_int[i] = 2; break;		//2
				case 0x33: ip_int[i] = 3; break;		//3
				case 0x34: ip_int[i] = 4; break;		//4
				case 0x35: ip_int[i] = 5; break;    	//5
				case 0x36: ip_int[i] = 6; break;		//6
				case 0x37: ip_int[i] = 7; break;		//7
				case 0x38: ip_int[i] = 8; break;		//8
				case 0x39: ip_int[i] = 9; break;		//9			
				case 0x61: ip_int[i] = 10; break;		//a
				case 0x62: ip_int[i] = 11; break;		//b
				case 0x63: ip_int[i] = 12; break;		//c
				case 0x64: ip_int[i] = 13; break;		//d
				case 0x65: ip_int[i] = 14; break;		//e
				case 0x66: ip_int[i] = 15; break;		//f				
				default: ip_int[i] = 0; break;		//other = 0
			}
		}		
	}	
	return(ip_out);	
}

/********TASKS**********/
void TaskSetIP4(void *data)
{	char *rxmsg;
	INT8U err;
	
	struct ip_addr ipaddr, netmask, gw;
	sys_sem_t sem;
	int ip_a,ip_b,ip_c,ip_d;
	int gw_a,gw_b,gw_c,gw_d;
	int net_a,net_b,net_c,net_d;
	
	INT16S key;
	INT16S ip_input[16];
	
	int x = 0;
	int i = 0;	
			
	int *temp;

	data = data;

	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox1,0,&err);
	//get ip addr
		for (x = 0; x <= 16; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
    
		printf("ENTER IP ADDRESS (a.b.c.d):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);				
			}		
		}while(key != '\r');	
	
		ip_input[i-1]='.';
		printf("\n");	
	
		temp = convert_ip_input(ip_input);	
		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3); 

	//get gateway	
		printf("\nENTER GATEWAY ADDRESS (a.b.c.d):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');	
	
		ip_input[i-1]='.';
		printf("\n");	
	
		temp = convert_ip_input(ip_input);	
		gw_a = *temp;
		gw_b = *(temp+1);
		gw_c = *(temp+2);
		gw_d = *(temp+3); 

	//get netmask
		printf("\nENTER NETMASK (a.b.c.d):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
		    {	ip_input[i] = key;			
				i+=1;
				printf("%c",key);
		    }		
		}while(key != '\r');	
	
		ip_input[i-1]='.';
		printf("\n");	
	
		temp = convert_ip_input(ip_input);	
		net_a = *temp;
		net_b = *(temp+1);
		net_c = *(temp+2);
		net_d = *(temp+3); 

	//init system
		printf("+-+-+-+-+-System is started.+-+-+-+-+-\n");
	#ifdef STATS
		stats_init();
	#endif /* STATS */
		sys_init();		
		mem_init();		
		memp_init();	
		pbuf_init();	
		printf("+-+-+-+-System is initialized.+-+-+-+-\n");

		netif_init();	
		sem = sys_sem_new(0);	
		tcpip_init(tcpip_init_done, &sem);	
		sys_sem_wait(sem);	
		sys_sem_free(sem);	
		printf("+-+-+-+-TCP/IP is initialized.+-+-+-+-\n");


		/*
		* add loop interface
		*/
    
		IP4_ADDR(&gw, 127,0,0,1);	
		IP4_ADDR(&ipaddr, 127,0,0,1);
		IP4_ADDR(&netmask, 255,0,0,0);	
	#if 0
		netif_add(&loopif, &ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);	
	#else
		netif_add(&ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
	#endif
		 /*
		* add rtl8019as interface
		*/

		IP4_ADDR(&gw,gw_a,gw_b,gw_c,gw_d);
		IP4_ADDR(&ipaddr,ip_a,ip_b,ip_c,ip_d);
		IP4_ADDR(&netmask,net_a,net_b,net_c,net_d);	

	#if 0
		netif_set_default(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));	
	#else
		netif_set_default(netif_add(&ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
	#endif	

		printf("--IPv4 SETTING IS COMPLETE--\n");
		printf("Current settting: IP      %d.%d.%d.%d\n",ip_a,ip_b,ip_c,ip_d);
		printf("                  Gateway %d.%d.%d.%d\n",gw_a,gw_b,gw_c,gw_d);
		printf("                  Netmask %d.%d.%d.%d\n",net_a,net_b,net_c,net_d);
		
		tcpecho_init();	
		printf("  tcpecho is created!\n");
		shell_init();	
		printf("  shell is created!\n");
		httpd_init();	
		printf("  httpd is created!\n");
		chargen_init();	
		printf("  chargen is created!\n");

		OSMboxPost(AckMbox1,(void *)1);
	}//for loop
}

void TaskSetIP6(void *data)
{	char txmsg;
	char *rxmsg;
	INT8U err;
	
	INT16S key;
				
	data = data;
	
	txmsg = 'a';

	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox3,0,&err);
	
	//submenu
		printf("Please Choose Address Type\n");
		printf("[1] Link Local Address \n");
		printf("[2] Compatibility Address \n");
		
		while(!COM86_GetKey(&key))
		{	//do nothing
		}
	
		printf("%c\n",key);
		switch(key)
		{	case 0x31: set_link_local(); break;		//1 link local
			case 0x32: printf("Choose type\n");
					   printf("[1] 6to4 (2002:WWXX:YYZZ::/48)\n"); //2
					   printf("[2] IPv4 compatible (::w.x.y.z) \n"); 
					   while(!COM86_GetKey(&key))
					   {	//do nothing
		               }
					   printf("%c\n",key);
					   switch(key)
					   {	case 0x31: OSMboxPost(TxMbox4,(void *)&txmsg);	//1 6to4
									   OSMboxPend(AckMbox4,0,&err);
									   break;		
							case 0x32: OSMboxPost(TxMbox5,(void *)&txmsg);	//2 IPv4 compatible
									   OSMboxPend(AckMbox5,0,&err);	
									   break;		
					   }
					   break;		
		}				
	
		OSMboxPost(AckMbox3,(void *)1);
	}//for loop
}

void Task6to4(void *data)
{	char *rxmsg;
	INT8U err;
	
	INT16S key;
	INT16S ip_input[16];
		
	struct ip_addr ipaddr, netmask, gw;
	sys_sem_t sem;
	int ip_a,ip_b,ip_c,ip_d;
	int gw_a,gw_b,gw_c,gw_d;
	int net_a,net_b,net_c,net_d;
	
	int x = 0;
	int i = 0;

	int *temp;
	
	data = data;
	
	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox4,0,&err);
		
		for (x = 0; x <= 16; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
    
		printf("ENTER IPv6 ADDRESS:(2002:a:b::)\n");	
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
				if (i == 4)
				{	if ((ip_input[0] != 0x32)||(ip_input[1] != 0x30)||(ip_input[2] != 0x30)||(ip_input[3] != 0x32))
					{	printf("\n<ERROR>!!\n");
						printf("Invalid Address!!\n");
						printf("ENTER IPv6 ADDRESS:(2002:a:b::)\n");
						i = 0;
					}					
				}
			}		
		}while(key != '\r');
		
		printf("\n");	

		temp = convert_6to4(ip_input); 
		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3); 

		printf("\nENTER GATEWAY:(2002:a:b::)\n");	
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
				if (i == 4)
				{	if ((ip_input[0] != 0x32)||(ip_input[1] != 0x30)||(ip_input[2] != 0x30)||(ip_input[3] != 0x32))
					{	printf("\n<ERROR>!!\n");
						printf("\nInvalid Address!!\n");
						printf("ENTER IPv6 ADDRESS:(2002:a:b::)\n");
						i = 0;
					}					
				}
			}		
		}while(key != '\r');
		
		printf("\n");	

		temp = convert_6to4(ip_input); 
		gw_a = *temp;
		gw_b = *(temp+1);
		gw_c = *(temp+2);
		gw_d = *(temp+3); 
		
		printf("\nENTER Netmask:(a.b.c.d)\n");	
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');
		
		printf("\n");	

		temp = convert_ip_input(ip_input);

		net_a = *temp;
		net_b = *(temp+1);
		net_c = *(temp+2);
		net_d = *(temp+3);
		
		//init system
		printf("+-+-+-+-+-System is started.+-+-+-+-+-\n");
	#ifdef STATS
		stats_init();
	#endif /* STATS */
		sys_init();		
		mem_init();		
		memp_init();	
		pbuf_init();	
		printf("+-+-+-+-System is initialized.+-+-+-+-\n");

		netif_init();	
		sem = sys_sem_new(0);	
		tcpip_init(tcpip_init_done, &sem);	
		sys_sem_wait(sem);	
		sys_sem_free(sem);	
		printf("+-+-+-+-TCP/IP is initialized.+-+-+-+-\n");

		/*
		* add loop interface
		*/
    
		IP4_ADDR(&gw, 127,0,0,1);	
		IP4_ADDR(&ipaddr, 127,0,0,1);
		IP4_ADDR(&netmask, 255,0,0,0);	
	#if 0
		netif_add(&loopif, &ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);	
	#else
		netif_add(&ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
	#endif
		 /*
		* add rtl8019as interface
		*/

		IP4_ADDR(&gw,gw_a,gw_b,gw_c,gw_d);
		IP4_ADDR(&ipaddr,ip_a,ip_b,ip_c,ip_d);
		IP4_ADDR(&netmask,net_a,net_b,net_c,net_d);	

	#if 0
		netif_set_default(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));	
	#else
		netif_set_default(netif_add(&ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
	#endif	

		printf("--IPv6 (6to4) SETTING IS COMPLETE--\n");
		printf("Current settting: IPv6 (6to4)\n");
		printf("                  IP      %d.%d.%d.%d\n",ip_a,ip_b,ip_c,ip_d);
		printf("                  Gateway %d.%d.%d.%d\n",gw_a,gw_b,gw_c,gw_d);
		printf("                  Netmask %d.%d.%d.%d\n",net_a,net_b,net_c,net_d);

		tcpecho_init();	
		printf("  tcpecho is created!\n");
		shell_init();	
		printf("  shell is created!\n");
		httpd_init();	
		printf("  httpd is created!\n");
		chargen_init();	
		printf("  chargen is created!\n");

		OSMboxPost(AckMbox4,(void *)1);
	}
}

void TaskIP4Compat(void *data)
{	char *rxmsg;
	INT8U err;

	struct ip_addr ipaddr, netmask, gw;
	sys_sem_t sem;
	int ip_a,ip_b,ip_c,ip_d = 0;
	int gw_a,gw_b,gw_c,gw_d = 0;
	int net_a,net_b,net_c,net_d = 0;
	
	INT16S key;
	INT16S ip_input[36];

	int x = 0;
	int i = 0;

	int *temp;

	data = data;
	
	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox5,0,&err);

		for (x = 0; x <= 36; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
		
		printf("ENTER IPv6 ADDRESS (::w.x.y.z):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);				
				if (i == 3)
				{	if ((ip_input[0] != ':')||(ip_input[1] != ':'))
					{	printf("\n<ERROR>!!\n");
						printf("\nInvalid Address!!\n");
						printf("ENTER IPv6 ADDRESS:(::w.x.y.z)\n");
						i = 0;
					}					
				}
			}		
		}while(key != '\r');	
	
	    ip_input[i-1]='.';		
		PRINT("\n");

		temp = convert_ip_input(ip_input);
		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3);

	//get gateway	
		printf("\nENTER GATEWAY ADDRESS (::w.x.y.z):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
				if (i == 3)
				{	if ((ip_input[0] != ':')||(ip_input[1] != ':'))
					{	printf("\n<ERROR>!!\n");
						printf("\nInvalid Address!!\n");
						printf("ENTER IPv6 ADDRESS:(::w.x.y.z)\n");
						i = 0;
					}					
				}
			}		
		}while(key != '\r');	
	
		ip_input[i-1]='.';
		printf("\n");	
	
		temp = convert_ip_input(ip_input);	
		gw_a = *temp;
		gw_b = *(temp+1);
		gw_c = *(temp+2);
		gw_d = *(temp+3); 		

	//get netmask
		printf("\nENTER NETMASK (a.b.c.d):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
		    {	ip_input[i] = key;			
				i+=1;
				printf("%c",key);
		    }		
		}while(key != '\r');	
	
		ip_input[i-1]='.';
		printf("\n");	
	
		temp = convert_ip_input(ip_input);	
		net_a = *temp;
		net_b = *(temp+1);
		net_c = *(temp+2);
		net_d = *(temp+3); 
		
	//init system
		printf("+-+-+-+-+-System is started.+-+-+-+-+-\n");
	#ifdef STATS
		stats_init();
	#endif 
		sys_init();		
		mem_init();		
		memp_init();	
		pbuf_init();	
		printf("+-+-+-+-System is initialized.+-+-+-+-\n");

		netif_init();	
		sem = sys_sem_new(0);	
		tcpip_init(tcpip_init_done, &sem);	
		sys_sem_wait(sem);	
		sys_sem_free(sem);	
		printf("+-+-+-+-TCP/IP is initialized.+-+-+-+-\n");

		//add loop interface		
    
		IP4_ADDR(&gw, 127,0,0,1);	
		IP4_ADDR(&ipaddr, 127,0,0,1);
		IP4_ADDR(&netmask, 255,0,0,0);	
	#if 0
		netif_add(&loopif, &ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);	
	#else
		netif_add(&ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
	#endif
		
		//add rtl8019as interface
		
		IP4_ADDR(&gw,gw_a,gw_b,gw_c,gw_d);
		IP4_ADDR(&ipaddr,ip_a,ip_b,ip_c,ip_d);
		IP4_ADDR(&netmask,net_a,net_b,net_c,net_d);	

	#if 0
		netif_set_default(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));	
	#else
		netif_set_default(netif_add(&ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
	#endif	

		printf("--IPv6 (IPv4 Compatible) SETTING IS COMPLETE--\n");
		printf("Current settting: IPv6 (IPv4 Compatible)\n");
		printf("                  IP      %d.%d.%d.%d\n",ip_a,ip_b,ip_c,ip_d);
		printf("                  Gateway %d.%d.%d.%d\n",gw_a,gw_b,gw_c,gw_d);
		printf("                  Netmask %d.%d.%d.%d\n",net_a,net_b,net_c,net_d);

		tcpecho_init();	
		printf("  tcpecho is created!\n");
		shell_init();	
		printf("  shell is created!\n");
		httpd_init();	
		printf("  httpd is created!\n");
		chargen_init();	
		printf("  chargen is created!\n");
		
		OSMboxPost(AckMbox5,(void *)1);
	}
}

void TaskPing(void *data)
{	char *rxmsg;
	INT8U err;

	INT16S key;
	INT16S ip_input[16];

	int ip_a,ip_b,ip_c,ip_d;	
	int x = 0;
	int i,k = 0;
	int *temp;
				
	data = data;
	
	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox2,0,&err);
		
		for (x = 0; x <= 16; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
    
		printf("ENTER DESTINATION ADDRESS:(a.b.c.d)\n");	
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');

		ip_input[i-1]='.';
		PRINT("\n");	

		temp = convert_ip_input(ip_input);
		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3);
		
		for(k = 0;k<=3;k++)
		{	
			ping4_init(ip_a,ip_b,ip_c,ip_d);
		}
				
		OSMboxPost(AckMbox2,(void *)1);
	}
}

void TaskPing6(void *data)
{	char *rxmsg;
	INT8U err;

	unsigned int ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h;

	INT16S key;
	INT16S ip_input[40];
	
	int x = 0;
	int i = 0;	
	unsigned int* temp;
	
	data = data;
	
	for(;;)
	{	rxmsg = (char *)OSMboxPend(TxMbox6,0,&err);
		
		for (x = 0; x <= 40; x++ )	//initial
		{	ip_input[x] = 0x00;		
		}
    
		printf("ENTER DESTINATION IPv6 ADDRESS (a:b:c:d:e:f:g:h):\n");
		i = 0;
		do 
		{	if (COM86_GetKey(&key))
			{	ip_input[i] = key;			
				i+=1;
				PRINT("%c",key);
			}		
		}while(key != '\r');
		ip_input[i-1]=':';
		printf("\n");
		
		temp = convert_ip6_input(ip_input);

		ip_a = *temp;
		ip_b = *(temp+1);
		ip_c = *(temp+2);
		ip_d = *(temp+3);
		ip_e = *(temp+4);
		ip_f = *(temp+5);
		ip_g = *(temp+6);
		ip_h = *(temp+7);

		ping6_init(ip_a,ip_b,ip_c,ip_d,ip_e,ip_f,ip_g,ip_h);	
						
		OSMboxPost(AckMbox6,(void *)1);
	}
}