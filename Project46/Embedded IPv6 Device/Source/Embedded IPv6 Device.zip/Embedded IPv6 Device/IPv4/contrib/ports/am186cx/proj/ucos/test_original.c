/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                           (c) Copyright 1992-2003, Jean J. Labrosse, Weston, FL
*                                           All Rights Reserved
*
*                                    Lightweight TCP/IP Protocol Stack
*                       Copyright (c) 2001-2003 Swedish Institute of Computer Science.
*                                           All rights reserved.
*
*                                               EXAMPLE #1
*
* By. Suriyan Laohaprapanon
* Last update: 2003/12/10
*
*********************************************************************************************************
*/

#include <includes.h>

#include "lwip/debug.h"

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/mem.h"
#include "lwip/memp.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"

#include "lwip/tcpip.h"
#include "lwip/api.h"

#include "netif/etharp.h"
#include "netif/loopif.h"
#include "netif/rtl8019.h"
#include "arch/sys_arch.h"

#include "tcpecho.h"
#include "shell.h"
#include "httpd.h"
#include "chargen.h"

/*
*********************************************************************************************************
*                                              CONSTANTS
*********************************************************************************************************
*/

#define          TASK_STK_SIZE     512                /* Size of each task's stacks (# of WORDs)       */

#define          TASK_START_ID      4                /* Application tasks IDs                         */

#define          TASK_START_PRIO    4                /* Application tasks priorities                  */

#define PRINT    COM86_Printf
/*
*********************************************************************************************************
*                                              VARIABLES
*********************************************************************************************************
*/

OS_STK        TaskStartStk[TASK_STK_SIZE];            /* Startup    task stack                         */

/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

        void  TaskStart(void *data);                  /* Function prototypes of tasks                  */
static  void  tcpip_init_done(void *arg);

/*
*********************************************************************************************************
*                                                  MAIN
*********************************************************************************************************
*/
void main (void)
{
    OS_STK *ptos;
    OS_STK *pbos;
    INT32U  size;

    OSInit();                                              /* Initialize uC/OS-II                      */

    COM86_DOSSaveReturn();                                 /* Save environment to return to DOS        */
    COM86_VectSet(uCOS, OSCtxSw);                          /* Install uC/OS-II's context switch vector */

    ptos        = &TaskStartStk[TASK_STK_SIZE - 1];        /* TaskStart() will use Floating-Point      */
    pbos        = &TaskStartStk[0];
    size        = TASK_STK_SIZE;
    OSTaskStkInit_FPE_x86(&ptos, &pbos, &size);            
    OSTaskCreateExt(TaskStart,
                   (void *)0,
                   ptos,
                   TASK_START_PRIO,
                   TASK_START_ID,
                   pbos,
                   size,
                   (void *)0,
                   OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSStart();                                             /* Start multitasking                       */
}

/*
*********************************************************************************************************
*                                               STARTUP TASK
*********************************************************************************************************
*/
#if 0
struct netif netif;
struct netif loopif;
#endif

void  TaskStart (void *pdata)
{
#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    struct ip_addr ipaddr, netmask, gw;
    sys_sem_t      sem;
    INT16S         key;


    pdata = pdata;                                         /* Prevent compiler warning                 */

    OS_ENTER_CRITICAL();                                   /* Install uC/OS-II's clock tick ISR        */
    COM86_VectSet(COM86_TICK_ITYPE, OSTickISR);
    COM86_SetTickRate(OS_TICKS_PER_SEC);                   /* Reprogram tick rate                      */

    COM86_VectSet(COM86_NIC_ITYPE, OSNicISR);              /* Network ISR */

    OS_EXIT_CRITICAL();

    OSStatInit();                                          /* Initialize uC/OS-II's statistics         */
    PRINT("System started.\n");
#ifdef STATS
    stats_init();
#endif /* STATS */
    sys_init();
    mem_init();
    memp_init();
    pbuf_init();
    PRINT("System initialized.\n");

    netif_init();
    sem = sys_sem_new(0);
    tcpip_init(tcpip_init_done, &sem);
    sys_sem_wait(sem);
    sys_sem_free(sem);
    PRINT("TCP/IP initialized.\n");


    /*
     * add loop interface
     */
    IP4_ADDR(&gw, 127,0,0,1);
    IP4_ADDR(&ipaddr, 127,0,0,1);
    IP4_ADDR(&netmask, 255,0,0,0);
#if 0
    netif_add(&loopif, &ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
#else
    netif_add(&ipaddr, &netmask, &gw, NULL, loopif_init, tcpip_input);
#endif
    /*
     * add rtl8019as interface
     */
   /* IP4_ADDR(&gw, 192,168,4,1);
    IP4_ADDR(&ipaddr, 192,168,4,101);
    IP4_ADDR(&netmask, 255,255,255,0);
	*/
//cat
	IP4_ADDR(&gw, 161,246,5,254);
    IP4_ADDR(&ipaddr, 161,246,5,140);
    IP4_ADDR(&netmask, 255,255,255,0);
//cat

#if 0
    netif_set_default(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
#else
    netif_set_default(netif_add(&ipaddr, &netmask, &gw, NULL, rtl8019if_init, tcpip_input));
#endif

    PRINT("Applications started.\n");

    tcpecho_init();
    PRINT(" tcpecho created!\n");
    shell_init();
    PRINT(" shell created!\n");
    httpd_init();
    PRINT(" httpd created!\n");
    chargen_init();
    PRINT(" chargen created!\n");


    for (;;) {
        PRINT("#T=%2d, T/S=%4d, CPU=%4d%%\n", OSTaskCtr, OSCtxSwCtr, OSCPUUsage);
        if (COM86_GetKey(&key)) {                          /* See if key has been pressed              */
            if (key == 0x1B) {                             /* Yes, see if it's the ESCAPE key          */
                outport(IMASK, inport(IMASK) | IMASK_CH9); /* Disable NIC Interrupt Channel            */
                COM86_DOSReturn();                         /* Yes, return to DOS                       */
            }
        }
        OSCtxSwCtr = 0;                                    /* Clear context switch counter             */
        OSTimeDly(OS_TICKS_PER_SEC);                       /* Wait one second                          */
    }
}

static void
tcpip_init_done(void *arg)
{
  sys_sem_t *sem;
  sem = arg;
  sys_sem_signal(*sem);
}
