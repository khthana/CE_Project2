#ifndef __PING6_H__
#define __PING6_H__

void
ping6_init(unsigned int ip_a,unsigned int ip_b,unsigned int ip_c,unsigned int ip_d,unsigned int ip_e,unsigned int ip_f,unsigned int ip_g,unsigned int ip_h);

#endif /* __PING4_H__ */