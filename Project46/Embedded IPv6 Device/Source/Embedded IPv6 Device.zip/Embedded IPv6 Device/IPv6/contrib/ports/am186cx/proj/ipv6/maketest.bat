REM MicroC/OS-II with lwIP Example Project Makefile
REM By Suriyan Laohaprapanon
REM Last update: 2003/12/11
REM Must be edit tools path
mkdir .\obj
c:\langs\bc\bin\make -fMakefile
c:\utils\upx\upx test.exe
