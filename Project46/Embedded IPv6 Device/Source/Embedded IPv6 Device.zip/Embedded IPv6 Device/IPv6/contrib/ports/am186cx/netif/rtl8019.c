/*
 * 12/10/2003: rtl8019as driver
 *             Suriyan Laohaprapanon
 * 04/27/2003: delete code: set mac addr manually, 
 *             add code: get mac addr from skyeye ne2k nic, which get from skyeye.conf
 *                              chenyu <chenyu@hpclab.cs.tsinghua.edu.cn>
 * 01/21/2003: ne2k driver for lwip(OS independent) initial version
 *                              yangye <yangye@163.net>
 */

#include "lwip/debug.h"

#include "lwip/opt.h"
#include "lwip/def.h"
#include "lwip/ip.h"
#include "lwip/mem.h"
#include "lwip/pbuf.h"
#include "lwip/sys.h"
#include "lwip/netif.h"
#include "arch/cc.h"

#include "netif/etharp.h"
#include "netif/rtl8019.h"

#include "am186cc.h"

#ifndef __BORLANDC__
#include <conio.h>
#define inportb(a) inp(a)
#define inport(a)   inpw(a)
#define outportb(a, b)  outp(a, b)
#define outport(a, b)   outpw(a, b)
#endif

#define MAX_ADDR_LEN    16
#define EADDR_LEN       6
#define MAX_MULTICAST   8

struct rtl8019_rxhdr {
  u8_t status;
  u8_t next;
  u16_t len;
};

#define NE_BASE             0x300   

#define NE_CR               (NE_BASE+0)       
#define NE_DMA              (NE_BASE+0x10)     
#define NE_RESET            (NE_BASE+0x1F)     

/*
 * Page 0 Registers (Write)
 */
#define P0W_PSTART          (NE_BASE+0x01)    
#define P0W_PSTOP           (NE_BASE+0x02)    
#define P0W_BNRY            (NE_BASE+0x03)    
#define P0W_TPSR            (NE_BASE+0x04)    
#define P0W_TBCR0           (NE_BASE+0x05)    
#define P0W_TBCR1           (NE_BASE+0x06)    
#define P0W_ISR             (NE_BASE+0x07)    
#define P0W_RSAR0           (NE_BASE+0x08)    
#define P0W_RSAR1           (NE_BASE+0x09)    
#define P0W_RBCR0           (NE_BASE+0x0a)    
#define P0W_RBCR1           (NE_BASE+0x0b)    
#define P0W_RCR             (NE_BASE+0x0c)    
#define P0W_TCR             (NE_BASE+0x0d)
#define P0W_DCR             (NE_BASE+0x0e)    
#define P0W_IMR             (NE_BASE+0x0f)    
/*
 * Page 0 Register (Read)
 */
#define P0R_CLDA0           (NE_BASE+0x01)
#define P0R_CLDA1           (NE_BASE+0x02)
#define P0R_BNRY            (NE_BASE+0x03)
#define P0R_TSR             (NE_BASE+0x04)
#define P0R_NCR             (NE_BASE+0x05)
#define P0R_FIFO            (NE_BASE+0x06)
#define P0R_ISR             (NE_BASE+0x07)
#define P0R_CRDA0           (NE_BASE+0x08)
#define P0R_CRDA1           (NE_BASE+0x09)
#define P0R_RESV0           (NE_BASE+0x0A)     /* RTL8019AS magic 'P' (0x50) */
#define P0R_RESV1           (NE_BASE+0x0B)     /* RTL8019AS magic 'p' (0x70) */
#define P0R_RSR             (NE_BASE+0x0C)
#define P0R_CNTR0           (NE_BASE+0x0D)
#define P0R_CNTR1           (NE_BASE+0x0E)
#define P0R_CNTR2           (NE_BASE+0x0F)

/*
 * Page 1 Registers (Read & Write)
 */
#define P1_PAR0            (NE_BASE+0x01)    
#define P1_PAR1            (NE_BASE+0x02)    
#define P1_PAR2            (NE_BASE+0x03)    
#define P1_PAR3            (NE_BASE+0x04)    
#define P1_PAR4            (NE_BASE+0x05)    
#define P1_PAR5            (NE_BASE+0x06)    
#define P1_CURR            (NE_BASE+0x07)    
#define P1_MAR0            (NE_BASE+0x08)    
#define P1_MAR1            (NE_BASE+0x09)    
#define P1_MAR2            (NE_BASE+0x0a)    
#define P1_MAR3            (NE_BASE+0x0b)    
#define P1_MAR4            (NE_BASE+0x0c)    
#define P1_MAR5            (NE_BASE+0x0d)    
#define P1_MAR6            (NE_BASE+0x0e)    
#define P1_MAR7            (NE_BASE+0x0f)    
 
/*
 * Page 2 Registers (read only in rtl8019as)
 */
#define P2R_PSTART          (NE_BASE+0x01)
#define P2R_PSTOP           (NE_BASE+0x02)
#define P2R_TPSR            (NE_BASE+0x04)
#define P2R_RCR             (NE_BASE+0x0c)
#define P2R_TCR             (NE_BASE+0x0d)
#define P2R_DCR             (NE_BASE+0x0e)
#define P2R_IMR             (NE_BASE+0x0f)

/*
 * Page 3 Registers (RTL8019AS Specific) (TODO:)
 */

/*
 * Command Register (NE_CR)
 *
 * | PS1 | PS0 | RD2 | RD1 | RD0 | TXP | STA | STP |
 *
 */
#define CR_STOP   0x01       
#define CR_START  0x02       
#define CR_TXP    0x04       
#define CR_READ   0x08       
#define CR_WRITE  0x10       
#define CR_SEND   0x18       
#define CR_NODMA  0x20       
#define CR_PAGE0  0x00       
#define CR_PAGE1  0x40       
#define CR_PAGE2  0x80       

/*
 * Interrupt Status Register (ISR)
 *
 * | RST | RDC | CNT | OVW | TXE | RXE | PTX | PRX |
 *
 */
#define  ISR_PRX        0x01   
#define  ISR_PTX        0x02       
#define  ISR_RXE        0x04   
#define  ISR_TXE        0x08   
#define  ISR_OVW        0x10   
#define  ISR_CNT        0x20   
#define  ISR_RDC        0x40   
#define  ISR_RST        0x80

#define ISR_ALL         0x3F

/*
 * Interrupt Mask Register (IMR)
 *
 * | -- | RDCE | CNTE | OVWE | TXEE | RXEE | PTXE | PRXE |
 *
 */
#define  IMR_PRXE        0x01
#define  IMR_PTXE        0x02
#define  IMR_RXEE        0x04
#define  IMR_TXEE        0x08
#define  IMR_OVWE        0x10
#define  IMR_CNTE        0x20
#define  IMR_RDCE        0x40

/*
 * Data Configuration Register (DCR)
 *
 * | -- | FT1 | FT0 | ARM | LS | LAS | BOS | WTS |
 *
 */
#define  DCR_WTS          0x01
#define  DCR_BOS          0x02
#define  DCR_LAS          0x04
#define  DCR_LS           0x08
#define  DCR_ARM          0x10
#define  DCR_FIFO2        0x00
#define  DCR_FIFO4        0x20
#define  DCR_FIFO8        0x40
#define  DCR_FIFO12       0x60

/*
 * Transmit Configuration Register (TCR)
 *
 * | -- | -- | -- | OFST | ATD | LB1 | LB0 | CRC |
 *
 */
#define  TCR_CRC        0x01
#define  TCR_LOOP_NONE  0x00
#define  TCR_LOOP_INT   0x02
#define  TCR_LOOP_EXT   0x06
#define  TCR_ATD        0x08
#define  TCR_OFST       0x10

/*
 * Transmit Status Register (TSR)
 *
 * | OWC | CDH | FU | CRS | ABT | COL | -- | PTX |
 *
 */
#define TSR_PTX     0x01
#define TSR_COL     0x04
#define TSR_ABT     0x08
#define TSR_CRS     0x10
#define TSR_FU      0x20
#define TSR_CDH     0x40
#define TSR_OWC     0x80

/*
 * Receive Configuration Register (RCR)
 *
 * | -- | -- | MON | PRO | AM | AB | AR | SEP |
 *
 */
#define  RCR_SEP    0x01
#define  RCR_AR     0x02
#define  RCR_AB     0x04
#define  RCR_AM     0x08
#define  RCR_PRO    0x10
#define  RCR_MON    0x20

/*
 * Receive Status Register (RSR)
 *
 * | DFR | DIS | PHY | MPA | FO | FAE | CRC | PRX |
 *
 */
#define RSR_PRX         0x01
#define RSR_CRC         0x02
#define RSR_FAE         0x04
#define RSR_FO          0x80
#define RSR_MPA         0x10
#define RSR_PHY         0x20
#define RSR_DIS         0x40
#define RSR_DFR         0x80


/*
 * Remote DMA Address for Transmitter
 */
#define  TSTART_PAGE   0x40    
/*
 * Remote DMA Address for Receiver
 */
#define  RSTART_PAGE   0x46
#define  RSTOP_PAGE    0x60    

/*
 * Description of header of each packet in receive area of memory
 */
#define NE_RBUF_STATUS      0  /* Received frame status        */
#define NE_RBUF_NEXT_PG     1  /* Page after this frame        */
#define NE_RBUF_SIZE_LO     2  /* Length of this frame         */
#define NE_RBUF_SIZE_HI     3  /* Length of this frame         */
#define NE_RBUF_HDR_LEN     4  /* Length of above header area  */

#define RBUF_STATUS_OK      0x01

/* 
 * a few useful Ethernet definitions.
 */
#define MIN_PKT_LEN         60    /* smallest legal size packet, no fcs */
#define MAX_PKT_LEN         1514    /* largest legal size packet, no fcs  */


/* Define those to better describe your network interface. */
#define IFNAME0 'e'
#define IFNAME1 't'

const struct eth_addr ethbroadcast = {0xff,0xff,0xff,0xff,0xff,0xff};

struct netif *rtl8019if_netif;   // points to the real netif, used by rtl8019_isr

static void rtl8019_copyin(u16_t count, u8_t *buf);
static void rtl8019_copyout(u16_t count, u8_t *buf);
static void rtl8019_discard(u16_t count);
static void rtl8019_overflowProcess(void);
void far rtl8019_isr(void);
static void low_level_init(struct netif * netif);
static struct pbuf * low_level_input(struct netif *rtl8019if);
static err_t low_level_output(struct netif *rtl8019if, struct pbuf *p);

/*
 * Read the specified number of bytes from the device DMA port into
 * the supplied buffer.
 */
static void rtl8019_copyin(u16_t count, u8_t *buf)
{
  while(count--) {
    *buf++  = inportb(NE_DMA);
  }
}

/*
 * Write the specified number of bytes from the device DMA port into
 * the supplied buffer.
 */
static void rtl8019_copyout(u16_t count, u8_t *buf)
{
  while(count--) {
    outportb(NE_DMA, *buf++);
  }
}

/*
 * Pull the specified number of bytes from the device DMA port,
 * and throw them away.
 */
static void rtl8019_discard(u16_t count)
{
  u8_t tmp;
  while(count--) {
    tmp = inportb(NE_DMA);
  }
}

static void rtl8019_overflowProcess(void)
{
  u8_t cr;
  u8_t resend;
  u8_t curr, bnry;
  u16_t i;

  /*
   * Save the command register, so we can later determine, if NIC
   * transmitter has been interrupted. Then stop the NIC and wait
   * 5 ms for any transmission or reception in progress.
   */
  cr = inportb(NE_CR);
  outportb(NE_CR, CR_PAGE0 | CR_STOP | CR_NODMA);
  for(i = 0; i < 50; i++)              /* delay at least 5ms */
    ;

  /*
   * Clear remote byte count register.
   */
  outportb(P0W_RBCR0, 0);
  outportb(P0W_RBCR1, 0);

  /*
   * Check for any incomplete transmission.
   */
  resend = 0;
  if (cr & CR_TXP) {
      if ((inportb(P0R_ISR) & (ISR_PTX | ISR_TXE)) == 0)
          resend = 1;
  }

  /*
   * Enter loopback mode and restart the NIC.
   */
  outportb(P0W_TCR, TCR_LOOP_INT);
  outportb(NE_CR, CR_PAGE0 | CR_START | CR_NODMA);

  /*
   * Discard all packets from the receiver buffer.
   */
  outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
  curr  =  inportb(P1_CURR);
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
  bnry = inportb(P0R_BNRY);
  /* 
   * get more than one packet until receive buffer is empty
   */
  while(curr != bnry){
    outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
    curr =  inportb(P1_CURR);
    outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
    bnry = inportb(P0R_BNRY);
  }

  /*
   * Switch from loopback to normal mode mode.
   */
  outportb(P0W_TCR, 0);

  /*
   * Re-invoke any interrupted transmission.
   */
  if (resend) {
      outportb(NE_CR, CR_START | CR_TXP | CR_NODMA);
  }

  /* Finally clear the overflow flag. */
  outportb(P0W_ISR, ISR_OVW);
}

/*
 * RTL8019AS Interrupt Service Routine
 */ 
void far rtl8019_isr(void)
{
  u8_t  isr, curr, bnry, tmp;
  struct netif *netif;

  /* Disable Interrupt Channel */
  outport(IMASK, inport(IMASK) | IMASK_CH9);

  /* close nic */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);

  /* in PAGE0 */
  isr = inportb(P0R_ISR);

  /* ram overflow interrupt */
  if (isr & ISR_OVW) {
    outportb(P0W_ISR, ISR_OVW);   /* clear interrupt */
    LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019_isr: Ring buffer overrun\n"));
    rtl8019_overflowProcess();
  }

  /* error transfer interrupt, NIC abort tx due to excessive collisions */
  if (isr & ISR_TXE) {
    outportb(P0W_ISR, ISR_TXE);          /* clear interrupt */
    /* temporarily do nothing */
  }

  /* Rx error, reset BNRY pointer to CURR (use SEND PACKET mode) */
  if (isr & ISR_RXE) {
    outportb(P0W_ISR, ISR_RXE);          /* clear interrupt */
    outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
    curr = inportb(P1_CURR);
    outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
    outportb(P0W_BNRY, curr);
  }

  /* got packet with no errors */
  if (isr & ISR_PRX) {
    outportb(P0W_ISR, ISR_PRX);          /* clear interrupt */
    outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
    curr  =  inportb(P1_CURR);
    outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
    bnry = inportb(P0R_BNRY);
    /* 
     * yangye 2003-1-21
     * get more than one packet until receive buffer is empty
     */
    while(curr != bnry){
      rtl8019if_input(rtl8019if_netif);
      outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
      curr =  inportb(P1_CURR);
      outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
      bnry = inportb(P0R_BNRY);
    }
  }

  /* Transfer complelte, do nothing here */
  if (isr & ISR_PTX){
    outportb(P0W_ISR, ISR_PTX);          /* clear interrupt */
  }

  if (isr & ISR_CNT) {
    LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019_isr: Counter overflow isr\n"));
    tmp = inportb(P0R_CNTR0);
    tmp = inportb(P0R_CNTR1);
    tmp = inportb(P0R_CNTR2);
    outportb(P0W_ISR, ISR_CNT);           /* Clear interrupt */
  }

  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
  outportb(P0W_ISR, ISR_ALL);             /* clear ISR */

  /* open nic for next packet */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_START);

  /* Enable interrupt channel */
  outport(IMASK, inport(IMASK) & ~IMASK_CH9);
  /* Issue End of Interrupt */
  outport(EOI, ITYPE_INT4);
}

/**
 * Initialize the rtk8019as, resetting the interface and getting the ethernet
 * address.
 */
static void
low_level_init(struct netif * netif)
{
  u8_t i;
  u8_t board_data[MAX_ADDR_LEN];


  /*
   * Step 1. Reset and stop the 8390.
   */
  inportb(NE_RESET);
  for(i = 0; i < 100; i++)              /* delay at least 10ms */
    ;
  outportb(NE_RESET, 0);

  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
  /*
   * Wait 1.6ms for the NIC to stop transmitting or receiving a packet. National
   * says monitoring the ISR RST bit is not reliable, so a wait of the maximum
   * packet time (1.2ms) plus some padding is required.
   */
  for(i = 0; i < 100; i++)
    ;

  /*
   * Step 2. Set receiver to monitor mode
   */
  outportb(P0W_RCR, RCR_MON);

  /*
   * Step 3. Place NIC into Loopback Mode 1.
   */
  outportb(P0W_TCR, TCR_LOOP_INT);

  /*
   * Step 4. Clear Remote Byte Count Regs.
   */
  outportb(P0W_RBCR0, 0);
  outportb(P0W_RBCR1, 0);

  /*
   * Step 5. Write 1's to all bits of EN0_ISR to clear pending interrupts.
   */
  outportb(P0W_ISR, 0xff);

  /*
   * Step 6. Init EN0_IMR as desired.
   */
  outportb(P0W_IMR, 0);

  /*
   * Step 7. Do anything special that the card needs.  Read the Ethernet address
   * into rom_address.
   */
  outportb(P0W_DCR, DCR_LS | DCR_FIFO8 | DCR_WTS);    /* Word transfer mode */

  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
  outportb(P0W_RBCR0, 0x20);   /* Low byte count is double of 16 bytes */
  outportb(P0W_RBCR1, 0);      /* High byte count is zero */

  outportb(P0W_RSAR0, 0);      /* From address 0 */
  outportb(P0W_RSAR1, 0);

  outportb(NE_CR, CR_READ | CR_START);  /* Read and start */

  for (i = 0; i < MAX_ADDR_LEN; i++) {
    board_data[i] = inportb(NE_DMA);
  }

  /*
  * Step 1. Reset and stop the 8390.
  */
  inportb(NE_RESET);                
  for(i = 0; i < 100; i++)              /* delay at least 10ms */
    ;
  outportb(NE_RESET, 0);

  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
  /*
  * Wait 1.6ms for the NIC to stop transmitting or receiving a packet. National
  * says monitoring the ISR RST bit is not reliable, so a wait of the maximum
  * packet time (1.2ms) plus some padding is required.
  */
  for(i = 0; i < 100; i++)
    ;

  /*
  * Step 2. Init the Data Config Reg.
   * FIFO threshold = 8 bytes, normal operation, 8-bit byte write DMA, BOS=0
   */
  outportb(P0W_DCR, DCR_LS | DCR_FIFO8);

  /*
  * Step 2a.  Config the Command register to page 0.
  */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);

  /*
  * Step 3. Clear Remote Byte Count Regs.
  */
  outportb(P0W_RBCR0, 0);
  outportb(P0W_RBCR1, 0);

  /*
  * Step 4. Set receiver to monitor mode
  */
  outportb(P0W_RCR, RCR_MON);

  /*
  * Step 5. Place NIC into Loopback Mode 1.
  */
  outportb(P0W_TCR, TCR_LOOP_INT);

  /*
  * Step 6. Init EN0_STARTPG to same value as EN0_BOUNDARY
  */
  outportb(P0W_PSTART, RSTART_PAGE);
  outportb(P0W_BNRY,  RSTART_PAGE);
  outportb(P0W_PSTOP, RSTOP_PAGE);
  outportb(P0W_TPSR, TSTART_PAGE);

  /*
  * Step 7. Write 1's to all bits of EN0_ISR to clear pending interrupts.
  */
  outportb(P0W_ISR, 0xff);

  /*
  * Step 8. Init EN0_IMR as desired.
  */
  outportb(P0W_IMR, IMR_OVWE | IMR_TXEE | IMR_PTXE | IMR_PRXE | IMR_CNTE);


  /*
  * Step 9. Init the Ethernet address and multicast filters.
  */
  outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
  for (i = 0; i < EADDR_LEN; i++) {
    outportb(P1_PAR0 + i, board_data[i]);
    /* set MAC hardware address */
    netif->hwaddr[i] = board_data[i];

  }
  outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);
  for (i = 0; i < MAX_MULTICAST; i++) {
    outportb(P1_MAR0 + i, 0xff); /* Change from 0xff to 0x00 */
  }
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_START);

  /*
  * Step 10. Program EN_CCMD for page 1.
  */
  outportb(NE_CR, CR_PAGE1 | CR_NODMA | CR_STOP);

  /*
  * Step 11. Program the Current Page Register to same value as Boundary Pointer.
  *    THIS IS WRONG WRONG WRONG inspite of some self-contradicting National
  *    documentation. If the Current Page Register is initialized to the same
  *    value as the Boundary Pointer, the first ever packet received will be lost or
  *    trashed because the driver always expects packets to be received at Boundrary
  *    pointer PLUS ONE! 
  */
  outportb(P1_CURR, RSTART_PAGE);
  /*
  * Step 12. Program EN_CCMD back to page 0, and start it.
  */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_START);

  outportb(P0W_TCR, TCR_LOOP_NONE);

  /*
  * Allow broadcast packets, in addition to packets unicast to us.
  * Multicast packets that match MAR filter bits will also be
  * allowed in.
  */
  outportb(P0W_RCR, RCR_AB | RCR_PRO | RCR_AM);

  /*
  * enable_net_irq
  */
  outport(INTPOL, inport(INTPOL) | INTPOL_INT4);
  outport(CH9CON, CHCON_PR7);
  outport(IMASK, inport(IMASK) & ~IMASK_CH9);

  rtl8019if_netif = netif;
}



/*
 * Function to do the actual writing of a packet into the devices
 * transmit buffer.  INT is disable during the function!!!!
 */
/**
 *
 *
 * @return error code
 * - ERR_OK: packet transferred to hardware
 * - ERR_CONN: no link or link failure
 * - ERR_IF: could not transfer to link (hardware buffer full?)
 */

static err_t 
low_level_output(struct netif *rtl8019if, struct pbuf *p)
{
  struct pbuf *q;
  u8_t isr;
  u16_t padLength, packetLength;


  /*
  * Set up to transfer the packet contents to the NIC RAM.
  */
  padLength = 0;
  packetLength = p->tot_len;
  LWIP_DEBUGF(NETIF_DEBUG, ("low_level_output: len=%d\n", packetLength));

  /* packetLength muse >=64 (see 802.3) */
  if ((p->tot_len) < 64)
  {
    padLength = 64 - (p->tot_len);
    packetLength = 64;
  }

#if 1
  /*
   * yangye 2003-1-21
   * don't close nic, just close receive interrupt
   */
  outportb(NE_CR, CR_PAGE2 | CR_NODMA | CR_START);
  isr = inportb(P2R_IMR);
  isr &= ~IMR_PRXE;
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_START);
  outportb(P0W_IMR, isr);

  outportb(P0W_ISR, ISR_RDC);
#else
  /* 
   * yangye 2003-1-21
   * or close nic(CR_STOP) during receive ???
   */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_STOP);
#endif


  /* Amount to send */
  outportb(P0W_RBCR0, packetLength & 0xff);
  outportb(P0W_RBCR1, packetLength >> 8);

  /* Address on NIC to store */
  outportb(P0W_RSAR0, 0x00);
  outportb(P0W_RSAR1, TSTART_PAGE);
  /* Write command to start */
  outportb(NE_CR, CR_PAGE0 | CR_WRITE | CR_START);

  /*
   * Write packet to ring buffers.
   */
  for(q = p; q != NULL; q = q->next) {
    /*
     * Send the data from the pbuf to the interface, one pbuf at a
     * time. The size of the data in each pbuf is kept in the ->len
     * variable.
     */
    rtl8019_copyout(q->len, q->payload);
  }

  while(padLength-- > 0){
    outportb(NE_DMA, 0);        /* Write padding for undersized packets */
  }

  /*  Wait for remote dma to complete - ISR Bit 6 clear if busy */
  while((u8_t)(inportb(P0R_ISR) & ISR_RDC) == 0 );

  outportb(P0W_ISR, ISR_RDC);     /* clear RDC */
  /*
   * Issue the transmit command.(start local dma)
   */
  outportb(P0W_TPSR, TSTART_PAGE);
  outportb(P0W_TBCR0, packetLength & 0xff);
  outportb(P0W_TBCR1, packetLength >> 8);
  /*
   * Start transmission (and shut off remote dma)
   * and reopen nic(CR_START)
   */
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_TXP | CR_START);

  /*
   * yangye 2003-1-21
   * reopen receive interrupt
   */
  outportb(NE_CR, CR_PAGE2 | CR_NODMA | CR_START);
  isr = inportb(P2R_IMR);
  isr |= IMR_PRXE;
  outportb(NE_CR, CR_PAGE0 | CR_NODMA | CR_START);
  outportb(P0W_IMR, isr);

  return ERR_OK;
}


/**
 * Read a packet into a pbuf chain.
 */
/**
 * Move a received packet from the rtl8019as into a new pbuf.
 *
 * Must be called after reading an ISQ event containing the
 * "Receiver Event" register, before reading new ISQ events.
 *
 * This function copies a frame from the rtl8019as.
 * It is designed failsafe:
 * - It does not assume a frame is actually present.
 * - It checks for non-zero length
 * - It does not overflow the frame buffer
 */
static struct pbuf *
  low_level_input(struct netif *rtl8019if)
{
  u16_t  packetLength, len;
  struct rtl8019_rxhdr rxhdr; /* Temp storage for ethernet headers */
  struct pbuf * p;
  struct pbuf * q;
  u8_t * payload;


  outportb(P0W_ISR, ISR_RDC);
  outportb(P0W_RBCR1, 0x0f);     /* See controller manual , use send packet command */
  outportb(NE_CR, CR_PAGE0 | CR_SEND | CR_START);

  /* get the first 4 bytes from nic  */
  rtl8019_copyin(sizeof(struct rtl8019_rxhdr), &rxhdr);

  /*  Store real length, set len to packet length - header */
  packetLength = rxhdr.len;

  LWIP_DEBUGF(NETIF_DEBUG, ("low_level_input: len=%d\n", packetLength));

  /* We allocate a pbuf chain of pbufs from the pool. */
  p = pbuf_alloc(PBUF_RAW, packetLength, PBUF_POOL);
  if (p != NULL) {
    for (q = p; q != NULL; q = q->next){
      /*
       * Read enough bytes to fill this pbuf in the chain. The
       * avaliable data in the pbuf is given by the q->len
       * variable.
       */
      payload = q->payload;
      len = q->len;
       /* read data into(q->payload, q->len); */
      rtl8019_copyin(len, payload);
    } /* for */
  }
  else {
    /* no more PBUF resource, Discard packet in buffer. */
    rtl8019_discard(packetLength);
  }
  return p;
}


/*-----------------------------------------------------------------------------------*/
/*
 * ethernetif_init():
 *
 * Should be called at the beginning of the program to set up the
 * network interface. It calls the function low_level_init() to do the
 * actual setup of the hardware.
 *
 *///  WARNING: must close all interrupts during init!!!!
/*-----------------------------------------------------------------------------------*/
/**
 * Initialize the RTL8019AS Ethernet MAC/PHY and its device driver.
 *
 * @param netif The lwIP network interface data structure belonging to this device.
 * MAY be NULL as we do not support multiple devices yet.
 *
 */
err_t
rtl8019if_init(struct netif *netif)
{
  struct rtl8019if *rtl8019if;

  rtl8019if = mem_malloc(sizeof(struct rtl8019if));
  netif->state = rtl8019if;
  netif->name[0] = IFNAME0;
  netif->name[1] = IFNAME1;
  netif->linkoutput = low_level_output;
  netif->output = rtl8019if_output;
  /* set MAC hardware address length */
  netif->hwaddr_len = EADDR_LEN;
  /* maximum transfer unit */
  netif->mtu = 1500;
  /* broadcast capability */
  netif->flags = NETIF_FLAG_BROADCAST;

  low_level_init(netif);
#ifndef IPV6
  etharp_init();
#endif
  LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019_init: MAC ADDR: %02d:%02d:%02d:%02d:%02d:%02d\n", \
    netif->hwaddr[0],netif->hwaddr[1], \
    netif->hwaddr[2],netif->hwaddr[3], \
    netif->hwaddr[4],netif->hwaddr[5]));
  return ERR_OK;
}


/**
 * Send a packet to the RTL8019AS from a series of pbuf buffers.
 */
/**
 * Writing an IP packet (to be transmitted) to the RTL8019AS.
 *
 * Before writing a frame to the RTL8019AS, the ARP module is asked to resolve the
 * Ethernet MAC address. The ARP module might undertake actions to resolve the
 * address first, and queue this packet for later transmission.
 *
 * @param netif The lwIP network interface data structure belonging to this device.
 * @param p pbuf to be transmitted (or the first pbuf of a chained list of pbufs).
 * @param ipaddr destination IP address.
 *
 * @internal It uses the function rtl8019_input() that should handle the actual
 * reception of bytes from the network interface.
 *
 */
err_t 
rtl8019if_output(struct netif *netif, struct pbuf *p,
  struct ip_addr *ipaddr)
{
  LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019if_output: Transmit packet\n"));
#ifndef IPV6
  p = etharp_output(netif, ipaddr, p);
#else
  pbuf_header(p, 14);
#endif
  if (p != NULL) {
    return low_level_output(netif, p);
  }
  return ERR_OK;
}


/**
 * Read a packet, clearing overflows.
 */
/**
 * Read a received packet from the RTL8019AS.
 *
 * This function should be called when a packet is received by the RTL8019AS
 * and is fully available to read. It moves the received packet to a pbuf
 * which is forwarded to the IP network layer or ARP module. It transmits
 * a resulting ARP reply or queued packet.
 *
 * @param netif The lwIP network interface to read from.
 *
 * @internal Uses rtl8019_input() to move the packet from the RTL8019AS to a
 * newly allocated pbuf.
 *
 */
void
rtl8019if_input(struct netif *netif)
{
  struct rtl8019if *rtl8019if;
  struct eth_hdr *ethhdr;
  struct pbuf *p;
  int time = 0;

  rtl8019if = netif->state;

  p = low_level_input(netif);

  if (p != NULL) {

    ethhdr = p->payload;

    switch (htons(ethhdr->type)) {
    case ETHTYPE_IP:
      LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019if_input: passing packet up to IP\n"));
#ifndef IPV6
      etharp_ip_input(netif, p);
#endif
      pbuf_header(p, -14);
      netif->input(p, netif);
      break;
    case ETHTYPE_ARP:
      LWIP_DEBUGF(NETIF_DEBUG, ("rtl8019if_input: ARP request\n"));
#ifndef IPV6
      p = etharp_arp_input(netif, (struct eth_addr *)&netif->hwaddr, p);
#endif
      if (p != NULL) {
        low_level_output(netif, p);
        pbuf_free(p);
      }
      break;
    case 0x86dd:
        COM86_Printf("IPv6 Packet is recieved\n");
		time = OSTimeGet();
		COM86_Printf("%d\n",time);
        pbuf_header(p, -14);
        netif->input(p, netif);
      break;
    default:
      pbuf_free(p);
      break;
    }
  }
}

