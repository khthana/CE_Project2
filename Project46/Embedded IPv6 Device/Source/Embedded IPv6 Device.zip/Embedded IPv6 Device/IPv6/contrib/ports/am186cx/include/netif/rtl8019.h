#ifndef __NETIF_RTL8019_H__
#define __NETIF_RTL8019_H__

#include "lwip/pbuf.h"
#include "lwip/netif.h"

struct rtl8019if {
    u8_t dummy;
    /* Add whatever per-interface state that is needed here. */
};


err_t rtl8019if_output(struct netif *netif, struct pbuf *p, struct ip_addr *ipaddr);

void rtl8019if_input(struct netif *netif);

err_t rtl8019if_init(struct netif *netif);


#endif /* __NETIF_RTL8019_H__ */
