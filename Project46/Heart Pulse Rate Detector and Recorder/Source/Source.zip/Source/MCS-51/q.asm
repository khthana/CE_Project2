;****************************************************************************
; Program		: Include RAM+LCD+Serial (in & out)
; Description	: HEART PULSE RATE DETECTOR AND RECORDER
; 
; Filename	: q.asm
;****************************************************************************
;----------------------------------------------------------------------------
; Define Port&Pin Name
;----------------------------------------------------------------------------
T0_PIN			BIT		P3.4		; HBR Input from Detector
SND_ALT		BIT		P3.5		; Bit for cleated  sound alert
LCD_EN			BIT		P3.6		; LCD Module Enable (Active High : Level)
LCD_RS			BIT		P3.7		; LCD Module Register Select

NWE			BIT		P1.0
NOE				BIT		P1.1
CS2				BIT		P1.2
NCS1			BIT		P1.3
NCP				BIT		P1.4
MR				BIT		P1.5

RX_OK			BIT		F0		; Define bit to keep received already

;----------------------------------------------------------------------------
; Define User Register
;----------------------------------------------------------------------------

TX_DATA		EQU		02FH		; For keep TX Data
BUFFER			EQU		030H		; For Keep Buffer Data

LCD_ADDR		EQU		031H		; For keep LCD Address
LCD_DATA		EQU		032H		; For keep LCD Data
HBR				EQU		033H		; For Keep HBR Data
OVER_RATE		EQU		034H		; For Keep Over Rate Data

;ID_TAG			EQU		035H		; For Keep ID Tag

;----------------------------------------------------------------------------
; Main Program.
;----------------------------------------------------------------------------

			ORG	0000H			; Reset Vector
			AJMP	INITIAL			; Jump to initial

			ORG	0003H			; IE0 Vector
			RETI					; Retrun interrupt

			ORG	000BH			; TF0 Vector
			RETI					; Retrun interrupt

			ORG	0013H			; IE1 Vector
			RETI					; Retrun interrupt

			ORG	001BH			; TF1 Vector
			RETI					; Return interrupt

			ORG	0023H			; TI+RI Vector
			AJMP	SER_INT			; Goto Serial interrupt subroutine

			ORG	002BH			; TF2+EXF2 Vector
			RETI					; Return interrupt

INITIAL:		MOV	P0,#00000000B		; Clear Databus for LCD
			MOV	P1,#00000000B		; Clear Control bus for RAM
			MOV	P2,#00000000B		; Clear Databus for RAM
			MOV	A,#000H
			CLR		LCD_EN				; Clear LCD Enable
			CLR		LCD_RS				; Clear LCD RS
			CLR		SND_ALT			; Clear SND_ALT

			CLR		MR
			ACALL	MRSET
			ACALL	SETREC				; Set Parameter for write datato RAM

; For Interupt Serial Initial
			MOV	TMOD,#021H			; T1 8Bit Auto, T0 16Bit
			MOV	TH1,#0FDH			; 9600 bps Timer1 Default
			MOV	TL1,#0FDH			;

			MOV	IE,#10010000B		; En. EA, ES
			SETB	TR1					; Start Timer1

			MOV	SCON,#050H			; Mode1 RX Enable
			CLR		RX_OK				; Clear RX_OK flag

; Default Over Rate Data ------- now 150	
			MOV	OVER_RATE,#096H	

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
; Default ID Tag Data ------- now 000
;			MOV	ID_TAG,#000H
; LOOP Until ID Tag must value not equ == default data
;LOOP_GETID:		NOP
;			NOP
;			MOV	A,ID_TAG
;			JZ		LOOP_GETID
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

MAIN:		ACALL	WRITE_TITLE			; Write Title  to LCD

MAIN_LOOP:	MOV	TMOD,#00100110B		; T1 8Bit Auto, C0 8Bit Gate disable
			SETB	EA

FREQ_LOOP:	MOV	R0,#BUFFER				; Clear BUFFER to start pointer
			ACALL	COUNT_HBR				; Count Heart Beat Rate 

; Check Over Range ?
			MOV	A,HBR
			SUBB	A,OVER_RATE
			JZ		WRITE_OVER			; Case HBR == OVER_RATE
			JNC		WRITE_OVER			; Case HBR > OVER_RATE
			
			MOV	A,HBR
			ACALL	WRITE_HBR				; Write Heart Beat Rate  to RAM
			ACALL	WRITE_SCREEN			; Write Screen to LCD
			ACALL	DISPLAY_HBR			; Display Heart Beat Rate  to LCD
			AJMP	FREQ_LOOP				; Jump to Read Frequency again

WRITE_OVER:
			MOV	A,HBR
			ACALL	WRITE_HBR				; Write Heart Beat Rate  to RAM
			ACALL	OVER_SCREEN			; Display Over Rate of HBR to LCD
			ACALL	DISPLAY_HBR			; Display Heart Beat Rate  to LCD
			ACALL	SOUND_ALERT			; Sound Alert when HBR over OVER_RATE
			AJMP	MAIN_LOOP				; Jump to Main loop
			
;#################################################################################################################
;----------------------------------------------------------------------------
; Serial interrupt subroutine
;----------------------------------------------------------------------------
SER_INT:		PUSH	ACC				; Push ACC. to stack

				JBC		RI,SER_RX		; RX or TX? If RX then received and clear RI
SER_TX:			CLR		TI				; Clear TI
				MOV	SBUF,TX_DATA
SER_TX_WAIT:	JBC		TI,SER_EXIT		; Wait until TX already (TI=1) then clear TI
				AJMP	SER_TX_WAIT	; Wait for TX
SER_RX:			CLR		RX_OK			; Clear RI
				MOV	A,SBUF			; Get data to ACC.

				CJNE	A,#49H,SET_OVER	; if not import 'I' then any inturrupt is set over rate
; Serial sent what character for ID_TAG 
;				CJNE	A,#XXH,GET_IDTAG
;Write 99 1 point
				ACALL	WRITE_END_POINT

				ACALL	MRSET
				ACALL	SETPLAY

PLAY:			MOV	P2,#11111111B		; initial to input port
				ACALL	INCADS				; increase address
;=============================== send out serial port
				MOV	A,P2				; mov from P2 to A ==> send out serial
TX_TEXT:		CLR		TI
TX_CHAR:		MOV	 SBUF,A
				JNB		TI,$
				CLR		TI
				JMP		PLAY			; play next address
;=============================== end send out
;=============================== if it's not Import so it was an over rate
SET_OVER:	;===================do set over rate
			CLR		TI					
			MOV	 SBUF,A
			MOV	OVER_RATE,A
			JNB		TI,$
			CLR		TI	
			;===================
;=============================== end set over rate

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;=============================== if it's not Import ,not get over rate then set ID_TAG
;SET_OVER:	;===================do set ID_TAG
;			CLR		TI					
;			MOV	 SBUF,A
;			MOV	ID_TAG,A
;Write ID Tag on Memory
;			ACALL	INCADS
;			MOV	P2,A
;			ACALL	DELAY_250ms
;			ACALL	WERAM
;
;			JNB		TI,$
;			CLR		TI	
			;===================
;=============================== end set ID_TAG
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

SER_EXIT:		POP		ACC				; Pop Acc. to Main
				RETI					; Return interrupt

;----------------------------------------------------------------------------
; Write End Point  HBR Mem on Ram
;----------------------------------------------------------------------------
WRITE_END_POINT:	PUSH	ACC
WRITE_END_LOOP:
					ACALL	INCADS
					MOV	A,#99
					MOV	P2,A
					ACALL	DELAY_250ms
					ACALL	WERAM

					POP		ACC
					RET

;----------------------------------------------------------------------------
; Count Heart Beat Rate Process
;----------------------------------------------------------------------------

COUNT_HBR:		PUSH	ACC
				
				MOV	TH0,#000H		; Clear Loop Counter
				MOV	TL0,#000H		;

				SETB	ET0				; Enable Counter 0 INT.
				SETB	TR0				; Start Counter 0

GATE_EN:		MOV	R7,#50			; Set gate time = 5s
GATE_EN_1:		MOV	R6,#100			; Each loop = 100 ms
GATE_EN_2:		MOV	R5,#0E6H		;
GATE_EN_3:		NOP
			NOP
			DJNZ	R5,GATE_EN_3		;
			DJNZ	R6,GATE_EN_2		;
			DJNZ	R7,GATE_EN_1		;
				
			CLR		TR0					; Stop Counter 0
			CLR		ET0					; Disable Counter 0 INT

			MOV	A,TL0
			MOV	B,#12
			MUL	 	AB					; per min
			MOV	HBR,A
			
			POP		ACC
			RET
;----------------------------------------------------------------------------
; Write Heart Beat Rate Process
;----------------------------------------------------------------------------
WRITE_HBR:	PUSH	ACC

; Write normal Data to Ram
			ACALL	INCADS
			MOV	A,HBR
			MOV	P2,A
			ACALL	DELAY_250ms
			ACALL	WERAM

			POP		ACC
			RET

;----------------------------------------------------------------------------
; Display Heart Beat Rate Process
;----------------------------------------------------------------------------
DISPLAY_HBR:
			PUSH	ACC
			
			MOV	LCD_ADDR,#040H		; Set Address 40H
			ACALL	SET_ADDR_LCD		;
			MOV	A,HBR
			MOV	LCD_DATA,A			; low byte of multiple value 
			
			ACALL	HEX2LCD			; Write to LCD
			ACALL	DELAY_250ms		; Delay Screen

			POP		ACC
			RET

;----------------------------------------------------------------------------
; Display Over Rate of HBR to LCD Process
;----------------------------------------------------------------------------
SOUND_ALERT:	PUSH	ACC
				
				SETB	SND_ALT
				ACALL	DELAY_100ms
				CLR		SND_ALT
				ACALL	DELAY_100ms
				
				SETB	SND_ALT
				ACALL	DELAY_100ms
				CLR		SND_ALT
				ACALL	DELAY_100ms

				SETB	SND_ALT
				ACALL	DELAY_100ms
				CLR		SND_ALT
				ACALL	DELAY_100ms

				SETB	SND_ALT
				ACALL	DELAY_100ms
				CLR		SND_ALT
				ACALL	DELAY_100ms

				SETB	SND_ALT
				ACALL	DELAY_100ms
				CLR		SND_ALT

				POP		ACC
				RET

;----------------------------------------------------------------------------
; Write Title Process
;----------------------------------------------------------------------------
WRITE_TITLE:	PUSH	ACC

				ACALL	INIT_LCD			; Call LCD Initial subroutine

				MOV	LCD_ADDR,#000H		; Set Address 00H
				ACALL	SET_ADDR_LCD		;
				MOV	DPTR,#TITLE_1		; Index Pointer ROM to Show LCD
				ACALL	WRLINE_LCD			; 00H-07H,40H-47H(Increase automatic)

				ACALL	DELAY_1s			; Delay Screen
				ACALL	DELAY_1s			;
			
				POP		ACC
				RET
;----------------------------------------------------------------------------
; Write Screen Process
;----------------------------------------------------------------------------
WRITE_SCREEN:	PUSH	ACC
				
				MOV	LCD_ADDR,#000H		; Set Address 00H
				ACALL	SET_ADDR_LCD		;
				MOV	DPTR,#SCR_RUN		; Index Pointer ROM to Show LCD
				ACALL	WRLINE_LCD			; 00H-07H,40H-47H(Increase automatic)

				POP		ACC
				RET

;----------------------------------------------------------------------------
; Display Over Rate of HBR to LCD Process
;----------------------------------------------------------------------------
OVER_SCREEN:	
			PUSH	ACC

			; Out to LCD
			MOV	LCD_ADDR,#000H			; Set Address 00H
			ACALL	SET_ADDR_LCD			;
			MOV	DPTR,#SCR_OVER		; Index Pointer ROM to Show LCD
			ACALL	WRLINE_LCD				; 00H-07H,40H-47H(Increase automatic)

			POP		ACC
			RET

;----------------------------------------------------------------------------
; HEX Code to show LCD
; I/P:		LCD_DATA
;----------------------------------------------------------------------------
HEX2LCD:	PUSH	ACC						; Push ACC.
			
			MOV	A,LCD_DATA				; Get Data
			MOV	B,#100					;
			DIV		AB						; Divide by 100
			ADD		A,#030H					; Convert to ASCII
			CJNE	A,#030H,HEX2_LCD_NX �	; Check x100 = 0 ?
			MOV	A,#' '					; 0 => Write Space
HEX2_LCD_NX:		MOV	LCD_DATA,A		;
			ACALL	WRCHAR_LCD			; Write x100
			MOV	A,B						;
			MOV	B,#10					;
			DIV		AB						; Divide by 10
			ADD		A,#030H					; Convert to ASCII
			MOV	LCD_DATA,A				;
			ACALL	WRCHAR_LCD			; Write Lower HEX Code
			MOV	A,B						; Get Remainder x1
			ADD		A,#030H					; Convert to ASCII
			MOV	LCD_DATA,A				;
			ACALL	WRCHAR_LCD			; Write Lower HEX Code
			
			POP	 	ACC						; Pop ACC.
			RET								; Return

;----------------------------------------------------------------------------
; LCD Initialize
;----------------------------------------------------------------------------
INIT_LCD:	ACALL	DELAY_100ms		; Delay
			CLR		LCD_RS				; Clear LCD_RS Pin

			MOV	P0,#00111000B		; 8bit Mode
			ACALL	LCD_CLK				; Pulse LCD Clock
			ACALL	DELAY_10ms			; Delay

			MOV	P0,#00111000B		; 8bit Mode
			ACALL	LCD_CLK				; Pulse LCD Clock
			ACALL	LCD_OFF				; Display Off
			ACALL	LCD_CLR			; Clear Display

			MOV	P0,#00000110B		; Entry Mode
			ACALL	LCD_CLK				; Pulse LCD Clock

			ACALL	LCD_HOME			; Return Home Display

;----------------------------------------------------------------------------
; LCD Clear Display
;----------------------------------------------------------------------------
LCD_CLR:	CLR		LCD_RS				; Clear LCD_RS Pin
			MOV	P0,#00000001B		; Display Clear
			ACALL	LCD_CLK				; Pulse LCD Clock
			RET

;----------------------------------------------------------------------------
; LCD Return Home
;----------------------------------------------------------------------------
LCD_HOME:	CLR		LCD_RS				; Clear LCD_RS Pin
			MOV	P0,#00000010B		; Return Home
			ACALL	LCD_CLK				; Pulse LCD Clock
			RET

;----------------------------------------------------------------------------
; LCD Display Off
;----------------------------------------------------------------------------
LCD_OFF:	CLR		LCD_RS				; Clear LCD_RS Pin
			MOV	P0,#00001000B		; Display Off
			ACALL	LCD_CLK				; Pulse LCD Clock
			RET

;----------------------------------------------------------------------------
; LCD Clk
;----------------------------------------------------------------------------
LCD_CLK:	SETB	LCD_EN				; Pulse Clock to LCD_EN
			ACALL	LCD_DELAY
			CLR		LCD_EN
			ACALL	LCD_DELAY
			RET

;----------------------------------------------------------------------------
; LCD Display On
;----------------------------------------------------------------------------
LCD_ON:		CLR		LCD_RS				; Clear LCD_RS Pin
			MOV	P0,#00001100B		; Display On
			ACALL	LCD_CLK
			RET

;----------------------------------------------------------------------------
; Set LCD Address
; I/P:		LCD_ADDR
;----------------------------------------------------------------------------
SET_ADDR_LCD:	CLR		LCD_RS			; Clear LCD_RS Pin
				MOV	A,LCD_ADDR		; Move LCD_ADDR to ACC.
				SETB	ACC.7			; Set bit ACC.7
				MOV	P0,A	 			; Move to DATABUS
				ACALL	LCD_CLK			; Pulse LCD Clock
				RET

;----------------------------------------------------------------------------
; Write Character to show LCD
; I/P:		LCD_DATA
;----------------------------------------------------------------------------
WRCHAR_LCD:		SETB	LCD_RS			; Set LCD_RS Pin
					MOV	P0,LCD_DATA	; Move LCD_DATA to DATABUS
					ACALL	LCD_CLK			; Pulse LCD Clock
					ACALL	LCD_ON			; Display On
					RET

;----------------------------------------------------------------------------
; Write Line of 16 Character from ROM
; I/P:		DPTR : Locate ROM Address
;----------------------------------------------------------------------------
WRLINE_LCD:		MOV	R0,#0			; Clear loop counter
WRLINE_LCD_1:		SETB	LCD_RS			; Set LCD_RS Pin
					CLR		A				; Clear ACC.
					MOVC	A,@A+DPTR		; Move data from @DPTR to ACC.
					MOV	P0,A				; Move ACC. to DATABUS
					ACALL	LCD_CLK			; Pulse LCD Clock
					INC		DPTR			; Increase Pointer
					INC		R0				; Increase loop counter
					CJNE	R0,#8,WRLINE_LCD_1	; Do until 8 times
		
					MOV	LCD_ADDR,#040H		; Set Later 8 Char. Address
					ACALL	SET_ADDR_LCD

WRLINE_LCD_2:		SETB	LCD_RS			; Set LCD_RS Pin
					CLR		A				; Clear ACC.
					MOVC	A,@A+DPTR		; Move data from @DPTR to ACC.
					MOV	P0,A				; Move ACC. to DATABUS
					ACALL	LCD_CLK			; Pulse LCD Clock
					INC		DPTR			; Increase Pointer
					INC		R0				; Increase loop counter
					CJNE	R0,#16,WRLINE_LCD_2	; Do until 8+8 times
					ACALL	LCD_ON			; Display On
					RET

;---------------------------------------------------------------------------
; Set Parametern for record data to RAM
;---------------------------------------------------------------------------
SETREC:		SETB	NWE
			CLR  	NOE
			SETB 	CS2
			CLR 	NCS1
			CLR 	NCP
			RET
;---------------------------------------------------------------------------
; Set Parametern for record data to RAM
;---------------------------------------------------------------------------
INCADS:		ACALL	DELAY_100ms 
			CPL		NCP
			ACALL	DELAY_100ms
			CPL		NCP
			RET

;---------------------------------------------------------------------------
; Set Parametern for record data to RAM
;---------------------------------------------------------------------------
WERAM:		CPL		NWE
			ACALL	DELAY_100ms
			CPL		NWE
			RET

MRSET:		CPL		MR
			ACALL	DELAY_100ms
			CPL		MR
			RET
;---------------------------------------------------------------------------
;initial to display
;---------------------------------------------------------------------------
SETPLAY:	SETB	NWE
			CLR		NOE
			SETB 	CS2
			CLR 	NCS1		
			RET

;----------------------------------------------------------------------------
; Dummy Delay time LCD_DELAY, 10m, 100m, 250m, 1s
;----------------------------------------------------------------------------
LCD_DELAY:			MOV	R7,#002			; Do 2 times
LCD_DELAY_1:		MOV	R6,#0E6H		; Each loop = 1 ms
LCD_DELAY_2:		NOP
					NOP
					DJNZ	R6,LCD_DELAY_2
					DJNZ	R7,LCD_DELAY_1
					RET

DELAY_50us:		MOV		R6,#00CH		; Each loop = 50 us
DELAY_50us_1:	NOP
				NOP
				DJNZ	R6,DELAY_50us_1
				RET

DELAY_10ms:			MOV	R7,#010			; Do 10 times
DELAY_10ms_1:		MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_10ms_2:		NOP
					NOP
					DJNZ	R6,DELAY_10ms_2
					DJNZ	R7,DELAY_10ms_1
					RET

DELAY_100ms:		MOV	R7,#100			; Do 100 times
DELAY_100ms_1:		MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_100ms_2:		NOP
					NOP
					DJNZ	R6,DELAY_100ms_2
					DJNZ	R7,DELAY_100ms_1
					RET

DELAY_250ms:		MOV	R7,#250			; Do 250 times
DELAY_250ms_1:		MOV	R6,#0E6H		; Each loop = 1 ms
DELAY_250ms_2:		NOP
					NOP
					DJNZ	R6,DELAY_250ms_2
					DJNZ	R7,DELAY_250ms_1
					RET

DELAY_1s:			MOV	R5,#100			; Do 100 times
DELAY_1s_1:			ACALL	DELAY_10ms
					DJNZ	R5,DELAY_1s_1
					RET

;----------------------------------------------------------------------------
;Define Constant < Store in Flash EEPROM Program Memory >
;----------------------------------------------------------------------------
;						 0123456789ABCDEF
TITLE_1:			DB		'  HBR Counter  '

SCR_RUN:		DB		' HBR :       bpm'
SCR_OVER:		DB		' OVER:       bpm'

Exit:			END