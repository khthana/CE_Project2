#pragma code symbols debug
#include <reg51.h>
#include <stdio.h>
#define bit2 0x04
#define bit7 0x80
unsigned char data data_key[8];
unsigned char data key_hi=0xff,key_lo=0xff,key_head=0,key_tel=0;
bit key_rev = 0;
unsigned char bdata btest = 0;
sbit b00 = btest^0;
sbit key_data = P3^4;                                                                   
sbit reset = P0^0;
sbit compare = P0^1;
sbit enter = P0^2;
sbit grave = P0^3;
void initial(){
	EA = 0;
	IE = 0x00;	
	P0 = 0xff;
	P1 = 0xff;
	P2 = 0xff;
	P3 = 0xff;
	TMOD = 0x22;
	SCON = 0x50;
	PCON = 0x80;
	TH1 = 255;
	TR1 = 1;
	ES = 0;
	IT0 = 1;
	IE0 = 0;
	EX0 = 1;
	
	EA = 1;
	compare = 0;
}

void delay(int count)
{
	int i,j;
	for(i = 0;i < count;i++)
		for(j = 0;j < 500;j++);
}

void main(void){
	int flag1 = 0;
	int flag2 = 0;
	int flag3 = 0;
	reset = 1;
	initial();
	T1 = 1;
	reset = 0;
	grave = 0;
	while(1)
	{
        	if(key_head != key_tel)
		{
			if(P1 == 0x1a) compare = 0;
			else compare = 1;
			delay(30);
                	key_tel = (key_tel + 1)&0x07;
		        T1 = 1;
			P1 = data_key[key_tel];
			if(P1 == 0x70)	//grave
			{
                        	if(flag3 == 0) {
				flag3 = 1;
				grave = 1;
				}
				else {
				flag3 = 0;
				grave = 0;
				}
			}
			if(P1 == 0x1a)	//caplock
			{
                        	if(flag2 == 0) flag2 = 1;
				else flag2 = 0;
			}			
			if(P1 == 0x1a) //caplock
			{
                        	if(flag1 == 0) flag1 = 1;
				else flag1 = 0;
			}
			/*if(P1 == 0x1a) //caplock
			{
                        	P2 = 0x80;
			}*/
			if(P1 == 0x5a) //enter
			{
                  		P2 = 0x81;      	
			}			
			if(P1 == 0x70) //grave
			{
                        	P2 = 0x82;
			}		
			if(P1 == 0x66) //delete
			{
                        	P2 = 0x83;
			}
 		}

		if(flag3 == 0){
		if(flag2 == 0){		//English (little)
		switch(P1)
		{
                	case 0x38: P2 = 0x61;break;   // "a"
			case 0x4c: P2 = 0x62;break;
                	case 0x84: P2 = 0x63;break;
			case 0xc4: P2 = 0x64;break;
                	case 0x24: P2 = 0x65;break;     
			case 0xd4: P2 = 0x66;break;
                	case 0x2c: P2 = 0x67;break;
			case 0xcc: P2 = 0x68;break;
                	case 0xc2: P2 = 0x69;break;
			case 0xdc: P2 = 0x6a;break;
                	case 0x42: P2 = 0x6b;break;
			case 0xd2: P2 = 0x6c;break;
                	case 0x5c: P2 = 0x6d;break;
			case 0x8c: P2 = 0x6e;break;
                	case 0x22: P2 = 0x6f;break;
			case 0xb2: P2 = 0x70;break;
                	case 0xa8: P2 = 0x71;break;
			case 0xb4: P2 = 0x72;break;
                	case 0xd8: P2 = 0x73;break;
			case 0x34: P2 = 0x74;break;
                	case 0x3c: P2 = 0x75;break;
			case 0x54: P2 = 0x76;break;
                	case 0xb8: P2 = 0x77;break;
			case 0x44: P2 = 0x78;break;
                	case 0xac: P2 = 0x79;break;
			case 0x58: P2 = 0x7a;break;    // "z"
                	case 0x68: P2 = 0x31;break;    // "1"
			case 0x78: P2 = 0x32;break;
                	case 0x64: P2 = 0x33;break;
			case 0xa4: P2 = 0x34;break;
                	case 0x74: P2 = 0x35;break;
			case 0x6c: P2 = 0x36;break;
                	case 0xbc: P2 = 0x37;break;
			case 0x7c: P2 = 0x38;break;
                	case 0x62: P2 = 0x39;break;     // "9"
			case 0xa2: P2 = 0x30;break;     // "0"
                	//case 0x5a: P2 = 0x55;break;	//enter
			case 0x94: P2 = 0x20;break;     //space
			case 0x72: P2 = 0x2d;break;     // "�"   // -
                	case 0xaa: P2 = 0x3d;break;     // "�"   // =
			case 0xba: P2 = 0x5c;break;     // "�"   // \
			case 0x82: P2 = 0x2c;break;     // "�"// ,
                	case 0x92: P2 = 0x2e;break;     // "�"// .
			case 0x52: P2 = 0x2f;break;     // "�"// /
                	case 0x32: P2 = 0x3b;break;     // "�"// ;
			case 0x4a: P2 = 0x27;break;     // "�"// '
                	case 0x2a: P2 = 0x5b;break;     // "�"// [
			case 0xda: P2 = 0x5d;break;     // "�"// ]
			case 0x0e: P2 = 0x30;break;     // "0"//numlock
			case 0x96: P2 = 0x31;break;     // "1"
			case 0x4e: P2 = 0x32;break;
                	case 0x5e: P2 = 0x33;break;
			case 0xd6: P2 = 0x34;break;
                	case 0xce: P2 = 0x35;break;
			case 0x2e: P2 = 0x36;break;
                	case 0x36: P2 = 0x37;break;
			case 0xae: P2 = 0x38;break;
                	case 0xbe: P2 = 0x39;break;     // "9"
		}
		}
			else if(flag2 == 1)                         //English (big)
			{
			switch(P1)
			{
                	case 0x38: P2 = 0x41;break;    // "A"
			case 0x4c: P2 = 0x42;break;
                	case 0x84: P2 = 0x43;break;
			case 0xc4: P2 = 0x44;break;
                	case 0x24: P2 = 0x45;break;
			case 0xd4: P2 = 0x46;break;
                	case 0x2c: P2 = 0x47;break;
			case 0xcc: P2 = 0x48;break;
                	case 0xc2: P2 = 0x49;break;
			case 0xdc: P2 = 0x4a;break;
                	case 0x42: P2 = 0x4b;break;
			case 0xd2: P2 = 0x4c;break;
                	case 0x5c: P2 = 0x4d;break;
			case 0x8c: P2 = 0x4e;break;
                	case 0x22: P2 = 0x4f;break;
			case 0xb2: P2 = 0x50;break;
                	case 0xa8: P2 = 0x51;break;
			case 0xb4: P2 = 0x52;break;
                	case 0xd8: P2 = 0x53;break;
			case 0x34: P2 = 0x54;break;
                	case 0x3c: P2 = 0x55;break;
			case 0x54: P2 = 0x56;break;
                	case 0xb8: P2 = 0x57;break;
			case 0x44: P2 = 0x58;break;
                	case 0xac: P2 = 0x59;break;
			case 0x58: P2 = 0x5a;break;   //"Z"
                	case 0x68: P2 = 0x21;break;    // "1"
			case 0x78: P2 = 0x40;break;
                	case 0x64: P2 = 0x23;break;
			case 0xa4: P2 = 0x24;break;
                	case 0x74: P2 = 0x25;break;
			case 0x6c: P2 = 0x5e;break;
                	case 0xbc: P2 = 0x26;break;
			case 0x7c: P2 = 0x2a;break;
                	case 0x62: P2 = 0x28;break;     // "9"
			case 0xa2: P2 = 0x29;break;     // "0"
                	//case 0x5a: P2 = 0x55;break;	//enter
			case 0x94: P2 = 0x20;break;     //space
			case 0x72: P2 = 0x5f;break;     // "�"   // _
                	case 0xaa: P2 = 0x2b;break;     // "�"   // +
			case 0xba: P2 = 0x7c;break;     // "�"   // |
			case 0x82: P2 = 0x3c;break;     // "�"// <
                	case 0x92: P2 = 0x3e;break;     // "�"// >
			case 0x52: P2 = 0x3f;break;     // "�"// ?
                	case 0x32: P2 = 0x3a;break;     // "�"// :
			case 0x4a: P2 = 0x22;break;     // "�"// "
                	case 0x2a: P2 = 0x7b;break;     // "�"// {
			case 0xda: P2 = 0x7d;break;     // "�"// }
			case 0x0e: P2 = 0x30;break;     // "0" //numlock
			case 0x96: P2 = 0x31;break;     // "1"
			case 0x4e: P2 = 0x32;break;
                	case 0x5e: P2 = 0x33;break;
			case 0xd6: P2 = 0x34;break;
                	case 0xce: P2 = 0x35;break;
			case 0x2e: P2 = 0x36;break;
                	case 0x36: P2 = 0x37;break;
			case 0xae: P2 = 0x38;break;
                	case 0xbe: P2 = 0x39;break;     // "9"
		}
		}
		}                          
                        if(flag3 == 1)
			{
			if(flag1 == 0)		//Thai (�ˡ�) 
			{
			switch(P1)
			{
                	case 0x38: P2 = 0x1f;break;    // "�" //A
			case 0x4c: P2 = 0x34;break;             //B
                	case 0x84: P2 = 0x41;break;           //C
			case 0xc4: P2 = 0x01;break;           //D
                	case 0x24: P2 = 0x33;break;           //E
			case 0xd4: P2 = 0x14;break;           //F
                	case 0x2c: P2 = 0x40;break;           //G 
			case 0xcc: P2 = 0x49;break;           //H
                	case 0xc2: P2 = 0x23;break;           //I
			case 0xdc: P2 = 0x48;break;           //J
                	case 0x42: P2 = 0x32;break;           //K
			case 0xd2: P2 = 0x2a;break;           //L
                	case 0x5c: P2 = 0x17;break;           //M
			case 0x8c: P2 = 0x37;break;           //N  
                	case 0x22: P2 = 0x19;break;           //O
			case 0xb2: P2 = 0x22;break;           //P
                	case 0xa8: P2 = 0x46;break;           //Q
			case 0xb4: P2 = 0x1e;break;           //R 
                	case 0xd8: P2 = 0x2b;break;           //S
			case 0x34: P2 = 0x30;break;           //T
                	case 0x3c: P2 = 0x35;break;           //U
			case 0x54: P2 = 0x2d;break;           //V
                	case 0xb8: P2 = 0x44;break;           //W
			case 0x44: P2 = 0x1b;break;           //X 
                	case 0xac: P2 = 0x31;break;           //Y
			case 0x58: P2 = 0x1C;break;   //"�"   //Z
                	case 0x68: P2 = 0x45;break;    // "�" //1
			//case 0x78: P2 = 0x32;break;           //2
                	//case 0x64: P2 = 0x33;break;           //3
			case 0xa4: P2 = 0x20;break;           //4
                	case 0x74: P2 = 0x16;break;           //5
			case 0x6c: P2 = 0x38;break;           //6
                	case 0xbc: P2 = 0x36;break;           //7
			case 0x7c: P2 = 0x04;break;           //8
                	case 0x62: P2 = 0x15;break;     // "�"//9
			case 0xa2: P2 = 0x08;break;     // "�"//0
			case 0x72: P2 = 0x02;break;     // "�"   // -
                	case 0xaa: P2 = 0x0b;break;     // "�"   // =
			case 0xba: P2 = 0x03;break;     // "�"   // \
			case 0x82: P2 = 0x21;break;     // "�"// ,
                	case 0x92: P2 = 0x43;break;     // "�"// .
			case 0x52: P2 = 0x1d;break;     // "�"// /
                	case 0x32: P2 = 0x27;break;     // "�"// ;
			case 0x4a: P2 = 0x07;break;     // "�"// '
                	case 0x2a: P2 = 0x1a;break;     // "�"// [
			case 0xda: P2 = 0x25;break;     // "�"// ]
                	//case 0x5a: P2 = 0x55;break;	//enter
			case 0x94: P2 = 0x20;break;     //space
			case 0x0e: P2 = 0x30;break;     // "0"
			case 0x96: P2 = 0x31;break;     // "1"
			case 0x4e: P2 = 0x32;break;
                	case 0x5e: P2 = 0x33;break;
			case 0xd6: P2 = 0x34;break;
                	case 0xce: P2 = 0x35;break;
			case 0x2e: P2 = 0x36;break;
                	case 0x36: P2 = 0x37;break;
			case 0xae: P2 = 0x38;break;
                	case 0xbe: P2 = 0x39;break;     // "9"
		}
		}
			else if(flag1 == 1)		        //Thai (Ħ��)
			{
			switch(P1)
			{
                	case 0x38: P2 = 0x24;break;    // "�"//A
			case 0x4c: P2 = 0x3a;break;          //B
                	case 0x84: P2 = 0x09;break;          //C
			case 0xc4: P2 = 0x0f;break;          //D
                	case 0x24: P2 = 0x0e;break;          //E
			case 0xd4: P2 = 0x42;break;          //F
                	case 0x2c: P2 = 0x0c;break;          //G
			case 0xcc: P2 = 0x47;break;          //H
                	case 0xc2: P2 = 0x13;break;          //I
			case 0xdc: P2 = 0x4b;break;          //J
                	case 0x42: P2 = 0x29;break;          //K
			case 0xd2: P2 = 0x28;break;          //L
                	//case 0x5c: P2 = 0x4d;break;          //M
			case 0x8c: P2 = 0x4c;break;          //N
                	case 0x22: P2 = 0x2f;break;          //O
			case 0xb2: P2 = 0x0d;break;          //P
                	case 0xa8: P2 = 0x50;break;          //Q
			case 0xb4: P2 = 0x11;break;          //R
                	case 0xd8: P2 = 0x06;break;          //S
			case 0x34: P2 = 0x18;break;          //T
                	case 0x3c: P2 = 0x4a;break;          //U
			case 0x54: P2 = 0x2e;break;          //V
                	//case 0xb8: P2 = 0x57;break;          //W
			//case 0x44: P2 = 0x;break;          //X
                	case 0xac: P2 = 0x4d;break;          //Y
			//case 0x58: P2 = 0x5a;break;   //"("  //Z
                	//case 0x68: P2 = 0x31;break;    // "+"//1
			case 0x78: P2 = 0x51;break;          //2
                	case 0x64: P2 = 0x52;break;          //3
			case 0xa4: P2 = 0x53;break;          //4 
                	case 0x74: P2 = 0x54;break;          //5
			case 0x6c: P2 = 0x39;break;          //6
                	case 0xbc: P2 = 0x3f;break;          //7
			case 0x7c: P2 = 0x55;break;          //8
                	case 0x62: P2 = 0x56;break;     // "�"//9
			case 0xa2: P2 = 0x57;break;     // "�"//0
			case 0x72: P2 = 0x58;break;     // "�"   // -
                	case 0xaa: P2 = 0x59;break;     // "�"   // =
			case 0xba: P2 = 0x05;break;     // "�"   // \
			case 0x82: P2 = 0x12;break;     // "�"// ,
                	case 0x92: P2 = 0x2c;break;     // "�"// .
			case 0x52: P2 = 0x26;break;     // "�"// /
                	case 0x32: P2 = 0x0b;break;     // "�"// ;
			//case 0x4a: P2 = 0x07;break;     // "�"// '
                	case 0x2a: P2 = 0x10;break;     // "�"// [
			//case 0xda: P2 = 0x25;break;     // "�"// ]
                	//case 0x5a: P2 = 0x55;break;	//enter
			case 0x94: P2 = 0x20;break;     //space
			case 0x0e: P2 = 0x30;break;     // "0"
			case 0x96: P2 = 0x31;break;     // "1"
			case 0x4e: P2 = 0x32;break;
                	case 0x5e: P2 = 0x33;break;
			case 0xd6: P2 = 0x34;break;
                	case 0xce: P2 = 0x35;break;
			case 0x2e: P2 = 0x36;break;
                	case 0x36: P2 = 0x37;break;
			case 0xae: P2 = 0x38;break;
                	case 0xbe: P2 = 0x39;break;     // "9" 
		} 
		}
		}
                        compare = 0;
	}
}

void ext0_service(void) interrupt 0 {

	b00 = key_lo&bit7;
	key_hi = (key_hi<<1) | b00;
	key_lo = (key_lo<<1) | key_data;
	if(!(key_hi&bit2))
	{
        	key_hi = 0xff;
	        key_lo = 0xff;
	}
	if(key_hi == 0xfe)
	{
        	if(key_lo == 15)
	{
		key_rev = 1;
	}
	else
	{
        	if(key_rev)
		{
        		key_head = (key_head+1)&0x07;
			data_key[key_head] = key_lo;
			key_rev = 0;	
		}
	}
    }
}
