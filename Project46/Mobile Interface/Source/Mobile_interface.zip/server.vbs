Public bOK                     As Boolean
Public bError                  As Boolean

Private Sub Wait()
Dim Start
   Start = Timer
   Do While Timer < Start + 5
      DoEvents
      If bOK Then
        Exit Sub
      End If
      If bError Then
        Exit Sub
      End If
   Loop
End Sub

Private Sub MOBILE_Click()
Dim bufferOut  As String
Dim bufferIn   As String
Dim Buf_Len1   As String
Dim Buf_Len2   As String
Dim Buffer_OA  As Variant
Dim Buffer_SMS As Variant
Dim Check_len  As Integer
Dim data_sms1  As String
Dim data_sms2  As String
Dim OA         As String
Dim Len_sms    As Integer
Dim Len_sms2   As Integer
Dim j, k       As Integer

        N = Time$
        sec = Second(Time)
        buf_sec = sec + 5
     Do
        sec = Second(Time)
        Text5.Text = sec
            If buf_sec >= 60 Then
                buf_sec = buf_sec - 60
            End If            
         If sec >= buf_sec Then
            Text1.Text = " "
            Text2.Text = " "
            buf_sec = sec + 5
            MSComm1.Output = "AT+CMGL=0" & Chr$(13)
            
            Do
                bufferIn = ""
                DoEvents
                Do
                    bufferIn = bufferIn & MSComm1.Input
                Loop Until InStr(bufferIn, "OK" & vbCrLf)
            Loop Until bufferIn <> ""
            Check_len = Len(bufferIn)
            If Check_len < 17 Then
                Wait
                Text3.Text = "NO SMS Incoming"
            End If                    
        End If
    Loop Until Check_len > 17
    Text3.Text = "SMS Incoming"   
    '----------------------------- OA Number --------------------------
    OA = "0"
    For i = 51 To 58
        data_sms1 = ""
        data_sms1 = Mid(bufferIn, i + 1, 1)
        data_sms2 = ""
        data_sms2 = Mid(bufferIn, i, 1)
        OA = OA & data_sms1
        OA = OA & data_sms2
        i = i + 1
    Next        
    Text4.Text = OA
    Text2.Text = "[PDU TYPE]" & vbCrLf & bufferIn & vbCrLf  
    '----- SMS PDU Mode
    OA = OA & "F"    
    '-------------------------- PDU OA Number -------------------------
    PDU_OA = ""
    For i = 1 To 10
        data_sms1 = ""
        data_sms1 = Mid(OA, i + 1, 1)
        data_sms2 = ""
        data_sms2 = Mid(OA, i, 1)
        PDU_OA = PDU_OA & data_sms1
        PDU_OA = PDU_OA & data_sms2
        i = i + 1
    Next
    '--------------------------- Decode SMS ---------------------------    
    Buf_Len1 = Mid(bufferIn, 77, 1)
    Buf_Len2 = Mid(bufferIn, 78, 1)
    
    Select Case Buf_Len1
       Case "A"
            j = 16 * 10
       Case "9"
            j = 16 * 9
       Case "8"
            j = 16 * 8
       Case "7"
            j = 16 * 7
       Case "6"
            j = 16 * 6
       Case "5"
            j = 16 * 5
       Case "4"
            j = 16 * 4
       Case "3"
            j = 16 * 3
       Case "2"
            j = 16 * 2
       Case "1"
            j = 16 * 1
       Case "0"
            j = 16 * 0            
    End Select
     
    Select Case Buf_Len2
       Case "F"
            k = 15
       Case "E"
            k = 14
       Case "D"
            k = 13
       Case "C"
            k = 12
       Case "B"
            k = 11
       Case "A"
            k = 10
       Case "9"
            k = 9
       Case "8"
            k = 8
       Case "7"
            k = 7
       Case "6"
            k = 6
       Case "5"
            k = 5
       Case "4"
            k = 4
       Case "3"
            k = 3
       Case "2"
            k = 2
       Case "1"
            k = 1
       Case "0"
            k = 0
    End Select
    
    Len_sms = j + k
    Buffer_SMS = ""
    Buffer_SMS = Mid(bufferIn, 79, (Len_sms * 2) - 2)        
    '-------------------------- Send SMS ------------------------------    
    MSComm1.Output = "AT+CMGF=0" & Chr$(13)    

    Do
        bufferIn = ""
        DoEvents
        Do
            bufferIn = bufferIn & MSComm1.Input
        Loop Until InStr(bufferIn, "OK" & vbCrLf)
    Loop Until bufferIn <> ""
        
    Out_SMS = "0011000981" + PDU_OA
    If Buffer_SMS = "EEF73A1D9ECD6230" Then   
    '---------- nokia3310
        Text8.Text = "Nokia 3310"
        Out_SMS = Out_SMS + "0000A719CEF73A1D06CD663118A8E703D568A0831B34A7BFC76B"
    ElseIf Buffer_SMS = "D374B95D76CF41C3592D0D" Then  
    '---------- Siemens C35i
        Text8.Text = "Siemens C35i"
        Out_SMS = Out_SMS + "0000A716D374B95D76CF413D1F485603A5DDA039FD3D5E03"
    ElseIf Buffer_SMS = "CEF73A1D06CD6C3518" Then      
    '---------- Nokia 3650
        Text8.Text = "Nokia 3650"
        Out_SMS = Out_SMS + "0000A719CEF73A1D06CD6C3518A8E703C570A0831B34A7BFC76B"
    ElseIf Buffer_SMS = "D3707B5E779F41C51B0C06" Then  
    '---------- Samsung E700
        Text8.Text = "Samsung E700"
        Out_SMS = Out_SMS + "0000A71BD3707B5E779F41C51B0C06EAF940321A28ED06CDE9EFF11A"
    End If
    Len_sms2 = (Len(Out_SMS) / 2) + 2
    Text1.Text = "??????? =" & Len_sms2 & " octets" & vbCrLf
    MSComm1.Output = "AT+CMGS=" & Len_sms2 & Chr$(13)
    Do
        bufferIn = ""
        DoEvents
        bufferIn = bufferIn & MSComm1.Input
    Loop Until bufferIn <> ""
    MSComm1.Output = Out_SMS    
    Wait
    MSComm1.Output = vbCrLf    
    Wait    
    MSComm1.Output = Chr$(26)
    Text1.Text = Text1.Text & Out_SMS & vbCrLf    
    Wait
    MOBILE_Click    
End Sub

Private Sub TYPE_MOBILE_Click()
Dim buffer_Cgmm  As Variant
Dim buffer_AT    As Variant
    Wait
    MSComm1.Output = "AT" & Chr$(13)
    Wait
    buffer_AT = ""
    buffer_AT = buffer_AT & MSComm1.Input
    If InStr(buffer_AT, "OK" & vbCrLf) Then
        Text6.Text = "?????????"
    Else
        Text6.Text = "???????????????"
    End If    
    If Len(buffer_AT) > 3 Then
        MSComm1.Output = "AT+CGMM" & Chr$(13)
        buffer_Cgmm = ""
        DoEvents
        Do
            buffer_Cgmm = buffer_Cgmm & MSComm1.Input
        Loop Until InStr(buffer_Cgmm, "OK" & vbCrLf)
        Text7.Text = Mid(buffer_Cgmm, 8, Len(buffer_Cgmm) - 11)
        MOBILE.Enabled = True
    Else
        Text7.Text = "????????????????"
    End If
    buffer_AT = ""
End Sub

Private Sub Form_Load()
    MSComm1.CommPort = 1
    MSComm1.Settings = "19200,N,8,1"
    MSComm1.PortOpen = True
    '------------ Check ComPort -----------------
    If MSComm1.PortOpen = True Then
        MSComm1.PortOpen = False
        OpenPort1.Caption = "Connect"
        TYPE_MOBILE.Enabled = False
        MOBILE.Enabled = False
    Else
        MSComm1.PortOpen = True
        OpenPort1.Caption = "Disconnect"
        TYPE_MOBILE.Enabled = True
    End If        
End Sub

Private Sub OpenPort1_Click()
    If MSComm1.PortOpen = True Then
        MSComm1.PortOpen = False
        OpenPort1.Caption = "Connect"
        TYPE_MOBILE.Enabled = False
        MOBILE.Enabled = False
    Else
        MSComm1.PortOpen = True
        OpenPort1.Caption = "Disconnect"
        TYPE_MOBILE.Enabled = True
    End If    
End Sub
