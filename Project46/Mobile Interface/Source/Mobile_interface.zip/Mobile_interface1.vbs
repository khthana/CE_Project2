$regfile = "89s8252.dat"
$baud = 19200
$crystal = 18432000
$large
$ramstart = 0
$ramsize = &H1000
$lcd = &H P1.3
Config Lcdbus = 4
Config Lcd = 16 * 1
Wait 1
Dim Telno(10) As Xram String * 1
Dim Message(500) As Xram String * 4
Dim Temp As String * 4
Dim Temp1 As String * 2
Dim Temp2 As String * 1
Dim Temp3 As String * 1
Dim Temp4 As String * 2
Dim Count As Byte
Dim Count1 As Byte
Dim Count2 As Byte
Dim K1 As String * 1
Dim C As Byte
Dim D As Byte
Dim E As Byte
Dim F As Byte
Dim G As Byte
Dim I As Byte
Dim J As Byte
Dim Sum As Byte
Dim Dif As Byte
Display On
Cls
I = 0
F = 0
G = 1
While P2 <> &H81
   D = P2
   J = P1.0
   Waitms 100
   If J > 0 Then
      If D = &H82 Then
         Print "hello"
         If E = 1 Then
            E = 0
          Elseif E = 0 Then
            E = 1
         End If
          J = 0
      End If
   End If
   If J > 0 Then
      If D = &H83 Then
         I = I - 1
         G = G - 1
         'Waitms 100
         'Lcd Chr(p2)
         F = F - 1
            Shiftcursor Left
          J = 0
      End If
   End If
   If J > 0 Then
      If E = 1 Then
         C = &H02
      Elseif E = 0 Then
         C = &H03
      End If
      If C = 2 Then
         Temp1 = "0E"
         Elseif C = 3 Then
         Temp1 = "00"
      End If
         C = D / 16
         If C > 9 Then
            Select Case C
               Case 10 : Temp2 = "A"
               Case 11 : Temp2 = "B"
               Case 12 : Temp2 = "C"
               Case 13 : Temp2 = "D"
               Case 14 : Temp2 = "E"
               Case 15 : Temp2 = "F"
            End Select
         Elseif C < 10 Then
            Temp2 = Str(c)
         End If
         C = D Mod 16
         If C > 9 Then
            Select Case C
               Case 10 : Temp3 = "A"
               Case 11 : Temp3 = "B"
               Case 12 : Temp3 = "C"
               Case 13 : Temp3 = "D"
               Case 14 : Temp3 = "E"
               Case 15 : Temp3 = "F"
            End Select
         Elseif C < 10 Then
            Temp3 = Str(c)
         End If
      Temp4 = Temp2 + Temp3
      Message(g) = Temp1 + Temp2 + Temp3
      I = I + 1
      G = G + 1
      Waitms 50
      Lcd Chr(p2)
      F = F + 1
      If F > 8 Then
         Shiftlcd Left
      End If
   End If
Wend
'********************************************
Count = I
Count1 = Count * 2
Count2 = Count1 + 12
'********************************************
Cls
I = 1
G = 0
F = 55
While F <> &H81
   J = P1.0
   If J > 0 Then
      Waitms 100
      F = P2
      E = P2 - 16
      'print "hello"
      If E > 10 Then
         E = E - 32
      End If
      If E < 10 Then
      Telno(i) = Str(e)
      Waitms 50
      Print "hello"
      'Print Telno(i)
      Lcd Telno(i)
      I = I + 1
      G = G + 1
      If G > 8 Then
         Shiftlcd Left
      End If
      End If
   End If
Wend
Cls
'********************************************
Print "AT+CMGF=0"
Wait 2
Print "AT+CMGS=" ; Count2
Wait 2
Print "0011000981";
'********************************************
For I = 1 To 9 Step 2
   J = I + 1
   If J >= 9 Then
      Print "F";
   Else
      K1 = Telno(j)
      Print Chr(k1);
   End If
   K1 = Telno(i)
   Print Chr(k1);
Next
'********************************************
Print "0008A7";
Count = Count * 2
Count = Count - 2
Printhex Count;
Count = Count + 2
Count = Count / 2
For I = 2 To Count
   Print Message(i);
Next
Print Chr(26);
'********************************************
End
