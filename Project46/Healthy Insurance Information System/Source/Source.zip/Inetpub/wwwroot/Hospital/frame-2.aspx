<%@ Page CodeBehind="frame-2.aspx.cs" Language="c#" AutoEventWireup="false" Inherits="Hospital.frame_2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body bgcolor="#000080" TEXT="#FFFFFF " LINK="#FFFFFF" ALINK="#FFFF00 " VLINK="#FFFFFF">
<font color="#000080" > 
<p align="center"><a href="searchinformation.aspx" target="mainFrame">�ͺ���������</a></p>
<p align="center"><a href="register.aspx" target="mainFrame">��Ѥû�Сѹ�آ�Ҿ��ǹ˹��</a></p>
<p align="center"><a href="searchhospital.aspx" target="mainFrame">����¹�ç��Һ��</a></p>
<p align="center"><a href="searchforclearing.aspx" target="mainFrame">Clearing</a></p>
</font>
</body>
</html>
