<? 
	phpinfo();
?>
