<?php
include( "../phpConfig.php" );
include( "../phpFunctionDB.php" );
include( "../phpFunction.php" );
?>
<html>
<head>
<title>��¡�âͧ�������к� ::::. Administrator Menu</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../StyleJobDB.css" type="text/css">
</head>
<script language="JavaScript">
<!-- 
function OpenNewWindow(url,winwidth,winheight) 
{
	NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=auto,resizable=no,copyhistory=no,width='+winwidth+',height='+winheight)
}
-->
</script>
<body background="../images/bgtop.gif" leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>
<br>
<br>
<table border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr> 
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  					<tr>
  						<td align="center" class="subtitle" ><font size="3" >��¡�âͧ�������к�&nbsp;</font>
						</td>
  					</tr>
				</table>
				<table width="100%" border="0" cellspacing="0" cellpadding="3">
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="phpListAdmin.php">��͡���������ź���ѷ��м��������ö�Դ�����</a>
						</td>
					</tr>
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="FrmUpdateCompany/FrmListCompany.htm?OrderBy=C_NAME">Update �����ź���ѷ���������㹰ҹ������</a>
						</td>
					</tr>		
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="FrmInsertByStd/FrmBeforeByStd.php">Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ</a>
						</td>
					</tr>
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="Selectcompany.html?OrderBy=S_DATETIME_SELECT">��ǹ�Ѵ���͡�ѡ�֡��</a>
						</td>
					</tr>
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="FrmManageStudent/FrmListStudent.php">��ǹ��䢡�äѴ���͡�ѡ�֡��</a>
						</td>
					</tr>
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="PrintReport.php">��ǹ�����§ҹ����ª��͹ѡ�֡����ҽ֡�ҹ</a>
						</td>
					</tr>
					<tr bgcolor="eeeeee"> 
						<td class="content2" align="left">&nbsp;<li><a href="phpMyAdmin/index.php">phpMyAdmin</a>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  			<tr>
  				<td align="right" class="subtitle">&nbsp;
				</td>
  			</tr>
		</table>
		</td>
	</tr>
</table>
</body>
</html>