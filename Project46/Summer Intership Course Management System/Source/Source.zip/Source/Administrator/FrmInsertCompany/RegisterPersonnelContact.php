<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$Flag = true;

$P_NAME = htmlspecialchars( trim( $P_NAME ) );
$P_POS = htmlspecialchars( trim( $P_POS ) );
$C_ID;
$C_NAME = htmlspecialchars( trim( $C_NAME ) );

$P_TEL = htmlspecialchars( trim( $P_TEL ) );
$P_FAX = htmlspecialchars( trim( $P_FAX ) );

/* ��Ǩ�ͺ��û�͹���ͼ��Դ��� */
if ( $P_NAME == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹���ͼ��Դ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		$P_ID = CheckPersonnelContactRegister( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS);
		 if($P_ID == "")
			$P_ID = Insert2PersonnelContact( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 Insert2Has( $C_ID,$P_ID );
		
		$msg .= "<li class=\"black16\"><b>$P_NAME</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红��������º��������";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

//echo "<li>$P_PREFACE";
//echo "<li>$P_NAME";
//echo "<li>$P_POS";
//echo "<li>$P_TEL";
//echo "<li>$P_FAX";
//echo "<li>$C_POS_AVA";
//echo "<li>$C_DATE_BEGIN";
//echo "<li>$C_DATE_END";
//echo "<li>$C_DATE_REPORT";
//echo "<li>$C_WHERE_REPORT";
//echo "<li>$C_WORK_LOCATION";
//echo "<li>$C_REST";
//echo "<li>$C_DETAIL";
//echo "<li>$C_ATTACH";
//echo "<li>$C_MIN_GPA";
//echo "<li>$C_WAGE";
//echo "<li>$C_OFFICE_DAY";
//echo "<li>$C_TIME_IN";
//echo "<li>$C_TIME_OUT";
//echo "<li>$C_OTHERA";
//echo "<li>$C_APPLY_MODE";
//echo "<li>$C_OTHERD";

echo $button;

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Register Company</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<li>System Message
<?php echo $msg; ?>

</body>
</html>