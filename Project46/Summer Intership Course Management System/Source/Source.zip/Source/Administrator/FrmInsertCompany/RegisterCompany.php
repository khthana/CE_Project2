<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();
$Flag = true;

$P_NAME = htmlspecialchars( trim( $P_NAME ) );
$P_POS = htmlspecialchars( trim( $P_POS ) );
$C_ID;
$C_TYPE;
$C_NAME = htmlspecialchars( trim( $C_NAME ) );

//Attributes of C_ADDR
$C_ADDR;
$NUMBER = htmlspecialchars( trim( $NUMBER ) );
$TOWER = htmlspecialchars( trim( $TOWER ) );
$MOO = htmlspecialchars( trim( $MOO ) );
$ROAD = htmlspecialchars( trim( $ROAD ) );
$SOY = htmlspecialchars( trim( $SOY ) );
$TUMBON = htmlspecialchars( trim( $TUMBON ) );
$AUMPHER = htmlspecialchars( trim( $AUMPHER ) );
$PROVINCE = htmlspecialchars( trim( $PROVINCE ) );
//End of C_ADDR

$C_COUNTRY;
$C_POSTCODE = htmlspecialchars( trim( $C_POSTCODE ) );
$P_TEL = htmlspecialchars( trim( $P_TEL ) );
$P_FAX = htmlspecialchars( trim( $P_FAX ) );

//�ӹǹ������Ѻ
$C_POS_AVA = htmlspecialchars( trim( $C_POS_AVA ) );

//����Ѻ����ѷ����Ѻ
$C_WHERE_REPORT = htmlspecialchars( trim( $C_WHERE_REPORT ) );
$C_ATTACH = htmlspecialchars( trim( $C_ATTACH ) );
$C_WORK_LOCATION = htmlspecialchars( trim( $C_WORK_LOCATION ) );
$C_MIN_GPA = htmlspecialchars( trim( $C_MIN_GPA ) );
$C_WAGE = htmlspecialchars( trim( $C_WAGE ) );
$C_DETAIL = htmlspecialchars( trim( $C_DETAIL ) );
$C_OTHER = htmlspecialchars( trim( $C_OTHER ) );

//����Ѻ����ѷ�������Ѻ
$C_REASON = htmlspecialchars( trim( $C_REASON ) );

/* ��Ǩ�ͺ��û�͹���ͼ��Դ��� */
if ( $P_NAME == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹���ͼ��Դ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹���ͺ���ѷ */
if ( $C_NAME == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ͺ���ѷ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹ GPA ��鹵�� */
if ( $C_MIN_GPA < 0 )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ GPA ���١��ͧ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹�ѵ�Ҥ�Ҩ�ҧ */
if ( $C_WAGE < 0 )
	{
		$msg .= "<li class=\"black16\">��سһ�͹�ѵ�Ҥ�Ҩ�ҧ���١��ͧ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹��������´�ͧ����ѷ����Ѻ�ѡ�֡�� */
if ( ($C_POS_AVA == "0") or ($C_POS_AVA == "") )
	{
		$msg .= "<li class=\"black16\">��سһ�͹�ӹǹ����Ѻ�ѡ�֡��";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹����������ѷ */
if ( $NUMBER != "" )
	{
		$C_ADDR .= "�Ţ��� ".$NUMBER;
	}
if ( $TOWER != "" )
	{
		$C_ADDR .= " �Ҥ�� ".$TOWER;
	}
if ( $MOO != "" )
	{
		$C_ADDR .= " ���� ".$MOO;
	}
if ( $ROAD != "" )
	{
		$C_ADDR .= " ��� ".$ROAD;
	}
if ( $SOY != "" )
	{
		$C_ADDR .= " ��� ".$SOY;
	}
if ( $PROVINCE == "��ا෾�" )
	{
	if ( $TUMBON != "" )
		{
			$C_ADDR .= " �ǧ ".$TUMBON;
		}
	if ( $AUMPHER != "" )
		{
			$C_ADDR .= " ࢵ ".$AUMPHER;
		}
	}
else
	{
	if ( $TUMBON != "" )
		{
			$C_ADDR .= " �Ӻ� ".$TUMBON;
		}
	if ( $AUMPHER != "" )
		{
			$C_ADDR .= " ����� ".$AUMPHER;
		}
	}
if ( $PROVINCE != "" )
	{
		$C_ADDR .= " �ѧ��Ѵ ".$PROVINCE;
		$C_LOCATION .= $PROVINCE."-".$AUMPHER;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		$C_APPLY_MODE ="���";
		$C_DATE_BEGIN = FormatDATE($YEARB , $MONTHB , $DAYB);
		$C_DATE_END = FormatDATE($YEARE , $MONTHE , $DAYE);
		$C_DATE_SENDLIST = FormatDATE($YEARS , $MONTHS , $DAYS);
		$C_DATETIME_REGISTER = FormatDATE($YEARREG , $MONTHREG , $DAYREG);

		$C_ID = Insert2CompanyName( $C_TYPE, $C_NAME, $C_NAME_EN, $C_ADDR, $C_LOCATION, $C_POSTCODE, $C_TEL, $C_FAX, $C_WEBSITE, $C_COUNTRY );
		 Insert2Company( $C_ID, $C_DETAIL, $C_POS_AVA, $C_DATE_SENDLIST, $C_DATE_RESULT, $C_APPLY_MODE, $C_MIN_GPA, $C_WAGE, $C_WHERE_REPORT,	 $C_DATE_BEGIN, $C_DATE_END, $C_ATTACH, $C_WORK_LOCATION, $C_REST, $C_REASON, $C_OTHER, $C_DATETIME_REGISTER );

		$P_ID = CheckPersonnelContactRegister( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 if($P_ID == "")
			$P_ID = Insert2PersonnelContact( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 Insert2Has( $C_ID,$P_ID );
	
		$msg .= "<li class=\"black16\">����ѷ <b>$C_NAME</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红����ź���ѷ���º��������";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

//echo "<li>$C_NAME";
//echo "<li>$C_ADDR";
//echo "<li>$C_POSTCODE";
//echo "<li>$C_LOCATION";
//echo "<li>$C_POS_AVA";
//echo "<li>$C_DATE_BEGIN";
//echo "<li>$C_DATE_END";
//echo "<li>$C_DATE_REPORT";
//echo "<li>$C_WHERE_REPORT";
//echo "<li>$C_WORK_LOCATION";
//echo "<li>$C_REST";
//echo "<li>$C_DETAIL";
//echo "<li>$C_ATTACH";
//echo "<li>$C_MIN_GPA";
//echo "<li>$C_WAGE";
//echo "<li>$C_OFFICE_DAY";
//echo "<li>$C_TIME_IN";
//echo "<li>$C_TIME_OUT";
//echo "<li>$C_OTHERA";
//echo "<li>$C_APPLY_MODE";
//echo "<li>$C_OTHERD";

echo $button;

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Register Company</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<li>��ͤ����駨ҡ�к�
<?php echo $msg; ?>

</body>
</html>