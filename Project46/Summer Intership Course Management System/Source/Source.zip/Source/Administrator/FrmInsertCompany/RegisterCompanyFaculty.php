<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();
$Flag = true;

$P_PREFACE = htmlspecialchars( trim( $P_PREFACE ) );
$P_NAME = htmlspecialchars( trim( $P_NAME ) );
$P_POS = htmlspecialchars( trim( $P_POS ) );
$C_ID;
$C_TYPE = htmlspecialchars( trim( $C_TYPE ) );
$C_NAME = htmlspecialchars( trim( $C_NAME ) );

//Attributes of C_ADDR
$C_ADDR;
$NUMBER = htmlspecialchars( trim( $NUMBER ) );
$TOWER = htmlspecialchars( trim( $TOWER ) );
$MOO = htmlspecialchars( trim( $MOO ) );
$ROAD = htmlspecialchars( trim( $ROAD ) );
$SOY = htmlspecialchars( trim( $SOY ) );
$TUMBON = htmlspecialchars( trim( $TUMBON ) );
$AUMPHER = htmlspecialchars( trim( $AUMPHER ) );
$PROVINCE = htmlspecialchars( trim( $PROVINCE ) );
//End of C_ADDR

$C_COUNTRY;
$C_POSTCODE = htmlspecialchars( trim( $C_POSTCODE ) );
$P_TEL = htmlspecialchars( trim( $P_TEL ) );
$P_FAX = htmlspecialchars( trim( $P_FAX ) );

/* ��Ǩ�ͺ��û�͹���ͼ��Դ��� */
if ( $P_NAME == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹���ͼ��Դ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹���ͺ���ѷ */
if ( $C_NAME == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ͺ���ѷ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹����������ѷ */
if ( $NUMBER != "" )
	{
		$C_ADDR .= "�Ţ��� ".$NUMBER;
	}
if ( $TOWER != "" )
	{
		$C_ADDR .= " �Ҥ�� ".$TOWER;
	}
if ( $MOO != "" )
	{
		$C_ADDR .= " ���� ".$MOO;
	}
if ( $ROAD != "" )
	{
		$C_ADDR .= " ��� ".$ROAD;
	}
if ( $SOY != "" )
	{
		$C_ADDR .= " ��� ".$SOY;
	}
if ( $PROVINCE == "��ا෾�" )
	{
	if ( $TUMBON != "" )
		{
			$C_ADDR .= " �ǧ ".$TUMBON;
		}
	if ( $AUMPHER != "" )
		{
			$C_ADDR .= " ࢵ ".$AUMPHER;
		}
	}
else
	{
	if ( $TUMBON != "" )
		{
			$C_ADDR .= " �Ӻ� ".$TUMBON;
		}
	if ( $AUMPHER != "" )
		{
			$C_ADDR .= " ����� ".$AUMPHER;
		}
	}
if ( $PROVINCE != "" )
	{
		$C_ADDR .= " �ѧ��Ѵ ".$PROVINCE;
		$C_LOCATION .= $PROVINCE."-".$AUMPHER;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		
		$C_ID = Insert2CompanyName( $C_TYPE, $C_NAME, $C_NAME_EN, $C_ADDR, $C_LOCATION, $C_POSTCODE, $C_TEL, $C_FAX, $C_WEBSITE, $C_COUNTRY );

		$P_ID = CheckPersonnelContactRegister( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 if($P_ID == "")
			$P_ID = Insert2PersonnelContact( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 Insert2Has( $C_ID,$P_ID );
		
		$msg .= "<li class=\"black16\">����ѷ <b>$C_NAME</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红����ź���ѷ���º��������";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

//echo "<li>$P_PREFACE";
//echo "<li>$C_TYPE";
//echo "<li>$C_POSTCODE";
//echo "<li>$C_LOCATION";
//echo "<li>$C_POS_AVA";
//echo "<li>$C_DATE_BEGIN";
//echo "<li>$C_DATE_END";
//echo "<li>$C_DATE_REPORT";
//echo "<li>$C_WHERE_REPORT";
//echo "<li>$C_WORK_LOCATION";
//echo "<li>$C_REST";
//echo "<li>$C_DETAIL";
//echo "<li>$C_ATTACH";
//echo "<li>$C_MIN_GPA";
//echo "<li>$C_WAGE";
//echo "<li>$C_OFFICE_DAY";
//echo "<li>$C_TIME_IN";
//echo "<li>$C_TIME_OUT";
//echo "<li>$C_OTHERA";
//echo "<li>$C_APPLY_MODE";
//echo "<li>$C_OTHERD";

echo $button;

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Register Company</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<li>��ͤ����駨ҡ�к�
<?php echo $msg; ?>

</body>
</html>