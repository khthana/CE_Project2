<?php
include("../../phpFunction.php");
include("../../phpFunctionDB.php");
include("../../phpConfig.php");

Conn2DB();

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL = "SELECT S_PREFACE,S_NAME,S_PARTY,S_ROOM,S_TEL FROM student ";
$strSQL .= "WHERE S_ID='$S_ID' ";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/
$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��" . mysql_error() );

$rs = mysql_fetch_array( $result );

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL = "SELECT C_NAME,C_TYPE FROM company_name ";
$strSQL .= "WHERE C_ID='$C_ID' ";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/
$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��" . mysql_error() );

$rs2 = mysql_fetch_array( $result );

/* �Դ Connection */
CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>
<br>

<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr>
		<td class="subtitle" align="center">Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ
		<table width="100%" border="0" cellspacing="0" cellpadding="0" >
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<form method="post" action="InsertByStd.php" >
				<input name="S_ID" type="hidden" size="25" maxlength="100" value="<?php echo $S_ID; ?>" >
				<input name="C_ID" type="hidden" size="25" maxlength="100" value="<?php echo $C_ID; ?>" >
				<table border="0" class="Atable" cellspacing="0" cellpadding="3" style='table-layout:fixed;' width=760 >
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="20%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp; �������</td>
						<td width="47%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp; ��ǹ����������</td>
						<td width="33%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp; �ٻẺ</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td width="20%" class="black8">&nbsp;��Ҿ���</td>
						<td width="47%" class="black8">&nbsp;<?php getPreface2($rs[S_PREFACE]); ?>
				      		<input name="S_NAME" type="text" size="25" maxlength="100" value="<?php echo $rs[S_NAME]; ?>" disabled ></td>
						<td width="33%" class="black8">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�Ҥ�Ԫ�</td>
						<td class="black8" width="47%">&nbsp;<input name="S_PARTY" type="text" id="S_PARTY" size="25" maxlength="50" value="<?php echo $rs[S_PARTY]; ?>" disabled ></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���ʻ�Шӵ��</td>
						<td class="black8" width="47%">&nbsp;
						<input name="S_ID2" type="text" id="S_ID2" size="25" maxlength="100" value="<?php echo $S_ID; ?>" disabled></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;��鹻�</td>
						<td class="black8" width="47%">&nbsp;<input name="S_ROOM" type="text" id="S_ROOM" size="10" maxlength="20" value="<?php $today=getdate();
						$year=$today[year]+543;
						if($rs[S_ROOM]=="D") 
							$year=substr($year,2)-substr($S_ID,0,2);
						else
							$year=substr($year,2)-substr($S_ID,0,2)-1;
						echo "$year$rs[S_ROOM]"; ?>" disabled>
						</td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;������</td>
						<td class="black8" width="47%">&nbsp;<input name="S_TEL" type="text" id="S_TEL" size="10" maxlength="50" value="<?php echo $rs[S_TEL]; ?>"></td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0625-33 ��� 100</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�դ������ʧ�����ҽ֡�ҹ���˹��§ҹ(����ѷ,�Ѱ����ˡԨ,˹��§ҹ�Ҫ���)</td>
						<td class="black8" width="47%">&nbsp;
						<?php if($C_ID=="") { $disabled=""; getCompanyType($rs2[C_TYPE]); } else { $disabled="disabled"; getCompanyType2($rs2[C_TYPE]); }  ?><input name="C_NAME" type="text" id="C_NAME" size="50" maxlength="50" value="<?php echo $rs2[C_NAME]; ?>" <?php echo $disabled; ?> ></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;����ӡ�õԴ���</td>
						<td class="black8" width="47%">&nbsp;
							<input name="P_PREFACE"  type="radio" value="" checked>NULL
							<input name="P_PREFACE"  type="radio" value="���">���
							<input  type="radio" name="P_PREFACE" value="�ҧ">�ҧ
							<input  type="radio" name="P_PREFACE" value="�ҧ���">�ҧ���
							<input name="P_NAME" type="text" id="P_NAME" size="25" maxlength="100"></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���˹�</td>
						<td class="black8" width="47%">&nbsp;<input name="P_POS" type="text" id="P_POS" size="25" maxlength="100"></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;ʶҹ���Դ���</td>
						<td class="black8" width="47%">&nbsp;<input name="P_PLACE" type="text" id="P_PLACE" size="25" maxlength="100"></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�������Ѿ��</td>
						<td class="black8" width="47%">&nbsp;<input name="P_TEL" type="text" id="P_TEL" size="25" maxlength="50"></td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0625-33 ��� 100</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�����</td>
						<td class="black8" width="47%">&nbsp;<input name="P_FAX" type="text" id="P_FAX" size="25" maxlength="50">
						</td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0053</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;������ҹ�ҹ</td>
						<td class="black8" width="47%">&nbsp;
							<input name="P_PREFACE2"  type="radio" value="" checked>NULL
							<input name="P_PREFACE2"  type="radio" value="���">���
							<input  type="radio" name="P_PREFACE2" value="�ҧ">�ҧ
							<input  type="radio" name="P_PREFACE2" value="�ҧ���">�ҧ���
							&nbsp;<input name="P_NAME2" type="text" id="P_NAME2" size="25" maxlength="100">
						<input name="P_POS2" type="hidden" id="P_POS2" size="25" maxlength="100" value="������ҹ�ҹ" ></td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���Ѿ��</td>
						<td class="black8" width="47%">&nbsp;<input name="P_TEL2" type="text" id="P_TEL2" size="25" maxlength="50"></td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0625-33 ��� 100</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�����</td>
						<td class="black8" width="47%">&nbsp;<input name="P_FAX2" type="text" id="P_FAX2" size="25" maxlength="50">
						</td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0053</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�ѹ���ŧ����¹</td>
						<td class="black8" width="47%">
						&nbsp;�ѹ���&nbsp;<select name="DAYSEL" id="DAYSEL"><?php $today = getdate(); $day=$today[mday]; getDay1to31(); ?></select>
						&nbsp;��͹&nbsp;<select name="MONTHSEL" id="MONTHSEL" ><?php $month=$today[mon]; getThaiMonth(); ?></select>
						&nbsp;�.�.&nbsp;<select name="YEARSEL" id="YEARSEL" ><?php get2ThisYear(); ?></select>
						</td>
						<td class="black8" width="33%">&nbsp;</td>
					</tr>
				</table>
				<br>
				<input name="Submit" type="submit" value="Submit" class="formbutton" style=width:100px>
				<input name="Reset" type="reset" value="Reset" class="formbutton" style=width:100px>
				</form>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>
