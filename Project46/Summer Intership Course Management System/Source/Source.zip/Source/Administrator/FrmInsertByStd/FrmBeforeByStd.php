<?php

include("../../phpFunction.php");
include("../../phpFunctionDB.php");
include("../../phpConfig.php");

Conn2DB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white >
<br>

<table width="760" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr> 
		<td class="subtitle" align="center">Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ
		<table width="100%" border="0" cellspacing="0" cellpadding="0" >
			<tr> 
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<form method="post" action="FrmInsertByStd.php" >
			
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="30%">&nbsp;���ʻ�Шӵ��</td>
						<td class="black8" width="70%">&nbsp;<input name="S_ID" type="text" id="S_ID" size="8" maxlength="8"></td>
					</tr>
				</table>

				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="30%">&nbsp;�դ������ʧ�����ҽ֡�ҹ���˹��§ҹ(����ѷ,�Ѱ����ˡԨ,˹��§ҹ�Ҫ���)</td>
						<td class="black8" width="70%">&nbsp;<select name="C_ID" id="C_ID" ><?php CreateDropDownCompany2(); ?>
						</select></td>
					</tr>
				</table>
				<br>
				<input name="Submit" type="submit" value="Submit" class="formbutton" style=width:100px>
				<input name="Reset" type="reset" value="Reset" class="formbutton" style=width:100px>
				</form>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>
<?php
CloseDB();
?>