<?php
include( "../phpConfig.php" );
include( "../phpFunctionDB.php" );
include( "../phpFunction.php" );
?>

<html>
<head>
<title>˹�Ҩ�����Ѻ���͡������§ҹ�ѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../StyleJobDB.css" type="text/css">
</head>

<script language="JavaScript">
<!-- 
function OpenNewWindow(url,winwidth,winheight) 
{
	NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=auto,resizable=no,copyhistory=no,width='+winwidth+',height='+winheight)
}
-->
</script>

<body background="../images/bgtop.gif" leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br>

<table border="0" cellspacing="0" cellpadding="1" align=center>
	<tr>
		<td class="title2" align="center">&nbsp;��ª��͹ѡ�֡�ҷ���ѧ�������§ҹ<br>�ѹ��� <?php $today=date( "Y-m-d" ); $today=LongThaiDate($today); echo $today ?></td>
	</tr>
</table>
<br>
<form method=post action="SelectReport.php">
<input id="length" name="length" type="hidden" maxlength="10" size="10" >
<table border="0" cellspacing="0" cellpadding="1" align="center" >
	<tr>
		<td class="subtitle">
		<table border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
		
				<table border="0" class="Atable" cellspacing="0" cellpadding="3" style='table-layout:fixed;' >
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td ID=Cell0 width="40%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=P_ID' align="center" >ʶҹ����Сͺ���</td>
						<td ID=Cell1 width="10%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=P_ID' align="center" >���ʻ�Шӵ��</td>
						<td ID=Cell2 width="20%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=P_ID' align="center" >����-ʡ��</td>
						<td ID=Cell3 width="7%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=H_DATETIME_REGISTER' align="center" >�Ը���Ѥ�</td>
						<td ID=Cell4 width="15%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=H_DATETIME_REGISTER' align="center" >�ѹ���ҷ�����͡</td>
						<td ID=Cell4 width="8%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=H_DATETIME_REGISTER' align="center" >���͡</td>
				</tr>
			</table>

<?php

Conn2DB();

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL = "SELECT student.*,company_name.C_NAME FROM company_name LEFT JOIN student ON company_name.C_ID=student.C_ID ";
$strSQL .= "WHERE S_STATUS='������' AND S_DATETIME_RESULT='0000-00-00 00:00:00' ";
$strSQL .= "ORDER BY company_name.C_NAME,S_ID ASC";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/

$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��1" . mysql_error() );

$i=0;
while(  $rs = mysql_fetch_array( $result ) )
	{
		$S_DATETIME_SELECT = ShortThaiDate($rs[S_DATETIME_SELECT]);

		echo "<table class=\"Ltable\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" style=\"table-layout:fixed;\">\n";
		echo "	<tr>\n";
		echo "		<td class=\"black8\" width=\"40%\" ><a href=\"FrmUpdatePersonnel.php?P_ID=$rs[P_ID]\"><u color=\"black\">$rs[C_NAME]</u></a>&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"10%\" align=\"center\" >$rs[S_ID]&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"20%\" align=\"left\" >$rs[S_PREFACE]$rs[S_NAME]&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"7%\" align=\"center\" >$rs[S_METHOD]&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"15%\" align=\"center\" >$S_DATETIME_SELECT ".substr($rs[S_DATETIME_SELECT],10)."</td>\n";
		echo "		<td class=\"black8\" width=\"8%\" align=\"center\" ><input id=\"S_ID[]\" name=\"S_ID[]\" type=\"checkbox\" value=\"$rs[S_ID]\" ></td>\n";
		echo "		</tr>\n";
		echo "	</table>\n";
		$i++;
	}

/* �Դ Connection */
CloseDB();

?>

			</td>
		</tr>
	</table>
	<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  					<tr>
  						<td align="right" class="subtitle">&nbsp;
						</td>
  					</tr>
				</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<tr bgcolor="eeeeee"> 
			<td class="content" align="center" >&nbsp;<input type="submit" name="Submit" id="Submit" value="Submit" class="formbutton" style=width:100px onclick="var y=<?php echo $i; ?>; length.value=y;" >
			<input name="Reset" type="reset" value="Reset" class="formbutton" style=width:100px>
			</td>
		</tr>
	</table>
	</form>
	</td>
  </tr>
</table>

</body>
</html>