<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$strSQL = "DELETE FROM company ";
$strSQL .= "WHERE C_ID='$C_ID' AND C_DATETIME_REGISTER='$C_DATETIME_REGISTER' ";

mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

CloseDB();

header("Location: FrmListCompany.htm?OrderBy=C_NAME");

?>