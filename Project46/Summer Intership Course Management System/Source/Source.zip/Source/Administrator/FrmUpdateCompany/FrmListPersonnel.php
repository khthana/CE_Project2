<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�����Ţͧ���������ö�Դ�����<?php echo $C_NAME; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">

<script language="JavaScript" type="text/javascript" >

function OpenNewWindow(url,winwidth,winheight)
{
	NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=auto,resizable=no,copyhistory=no,width='+winwidth+',height='+winheight)
}

</script>

</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white >
<br>

<table border="0" cellspacing="0" cellpadding="1" align=center>
	<tr>
		<td class="title2" align="center">&nbsp;��¡�â����Ţͧ���������ö�Դ�����<?php echo $C_NAME; ?></td>
	</tr>
</table>
<br>

<table border="0" cellspacing="0" cellpadding="1" align="center" >
	<tr>
		<td class="subtitle">
		<table border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">

				<table border="0" class="Atable" cellspacing="0" cellpadding="3" style='table-layout:fixed;' >
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td ID=Cell0 width="80%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=P_ID' >&nbsp;����-ʡ��</td>
						<td ID=Cell2 width="10%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListPersonnel.php?C_ID=<?php echo $C_ID; ?>&C_NAME=<?php echo $C_NAME; ?>&OrderBy=H_DATETIME_REGISTER' align="center" >Last Update</td>
						<td ID=Cell3 width="10%" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp;</td>
				</tr>
			</table>

<?php
include("../../phpConfig.php");
include("../../phpFunction.php");
include("../../phpFunctionDB.php");

Conn2DB();

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL = "SELECT * FROM has ";
$strSQL .= "WHERE C_ID='$C_ID' ";
$strSQL .= "ORDER BY ".$OrderBy;

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/

$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��1" . mysql_error() );

while(  $rs = mysql_fetch_array( $result ) )
	{
		$strSQL2 = "SELECT P_PREFACE,P_NAME FROM personnel_contact ";
		$strSQL2 .= "WHERE P_ID='$rs[P_ID]' ";
		$result2 = mysql_query( $strSQL2, $conn )
			or die ( "�������ö����������ŧ�����ҧ��2" . mysql_error() );
		$rs2 = mysql_fetch_array( $result2 );

		$H_DATETIME_REGISTER = ShortThaiDate($rs[H_DATETIME_REGISTER]);

		echo "<table class=\"Ltable\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" style=\"table-layout:fixed;\">\n";
		echo "	<tr>\n";
		echo "		<td class=\"black8\" width=\"80%\" ><a href=\"FrmUpdatePersonnel.php?P_ID=$rs[P_ID]\"><u color=\"black\">$rs2[P_PREFACE] $rs2[P_NAME]</u></a>&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"10%\" align=\"center\" >$H_DATETIME_REGISTER&nbsp;</td>\n";
		echo "		<td class=\"black8\" width=\"10%\" align=\"center\" >&nbsp;<a href=\"FrmConfirmDeletePersonnel.php?P_ID=$rs[P_ID]&P_NAME=$rs2[P_NAME]\" ><u>ź</u></a>&nbsp;</td>\n";
		echo "		</tr>\n";
		echo "	</table>\n";
	}

/* �Դ Connection */
CloseDB();

?>

			</td>
		</tr>
	</table>
	<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  					<tr>
  						<td align="right" class="subtitle">&nbsp;
						</td>
  					</tr>
				</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<tr bgcolor="eeeeee"> 
			<td class="content">&nbsp;
			</td>
		</tr>
	</table>
	</td>
  </tr>
</table>

</body>
</html>