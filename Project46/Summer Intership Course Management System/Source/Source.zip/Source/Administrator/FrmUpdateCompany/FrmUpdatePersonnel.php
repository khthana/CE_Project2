<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL = "SELECT * FROM personnel_contact ";
$strSQL .= "WHERE P_ID='$P_ID' ";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/
$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��" . mysql_error() );

$rs = mysql_fetch_array( $result );

/* �Դ Connection */
CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Update Personnel Contact</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr> 
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<form method="post" action="UpdatePersonnel.php">
				<input name="P_ID" type="hidden" id="P_ID" value="<?php echo "$rs[P_ID]"; ?>" size="50" maxlength="100" >
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width=760>
					<tr height="30" bgcolor="#c7c5c5" class="content">	
						<td width="20%" align="center" >&nbsp;����¹�ŧ������ <?php echo $rs[P_PREFACE]; echo $rs[P_NAME]; ?></td>
					</tr>
				</table>
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width=760>
					<tr height="30" bgcolor="#c7c5c5" class="content">	
						<td width="20%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp;Column...</td>
						<td width="47%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp; Update Field...</td>
						<td width="33%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp; Format...</td>
					</tr>				
				</table>

				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���Դ���</td>
						<td class="black8" width="47%">&nbsp;<?php getPreface($rs[P_PREFACE]);  ?><input name="P_NAME" type="text" id="P_NAME" value="<?php echo "$rs[P_NAME]"; ?>" size="50" maxlength="100" ></td>
						<td class="black8" width="33%">&nbsp;�� ��ºح����Է��� ��駪���آ</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���˹�</td>
						<td class="black8" width="47%">&nbsp;<input name="P_POS" type="text" id="P_POS" value="<?php echo "$rs[P_POS]"; ?>" size="25" maxlength="100" ></td>
						<td class="black8" width="33%">&nbsp;�� ������ü��Ѵ���,���Ѵ��ý��ºؤ��</td>
					</tr>
				</table>
			
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;���Ѿ��</td>
						<td class="black8" width="47%">&nbsp;<input name="P_TEL" type="text" id="P_TEL" value="<?php echo "$rs[P_TEL]"; ?>" size="25" maxlength="50" ></td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0625-33 ��� 100</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;����� (FAX)</td>
						<td class="black8" width="47%">&nbsp;<input name="P_FAX" type="text" id="P_FAX" value="<?php echo "$rs[P_FAX]"; ?>" size="25" maxlength="50" ></td>
						<td class="black8" width="33%">&nbsp;�� 0-2298-0053</td>
					</tr>
				</table>
				
				<br>
				<input name="Submit" type="submit" value="Update" class="formbutton" style=width:100px>
				<input name="Reset" type="reset" value="Reset" class="formbutton" style=width:100px>
				</form>

				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>