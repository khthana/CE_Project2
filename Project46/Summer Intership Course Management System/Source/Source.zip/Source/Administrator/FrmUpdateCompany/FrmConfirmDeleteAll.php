<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�׹�ѹ���ź�����ŷ������ͧ<?php echo $C_NAME; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body background="../images/bgtop.gif" leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<form method="post" action="DeleteAll.php" >
		<input name="C_ID" type="hidden" size="25" maxlength="100" value="<?php echo $C_ID; ?>">
		<input name="C_DATETIME_REGISTER" type="hidden" size="25" maxlength="100" value="<?php echo $C_DATETIME_REGISTER; ?>" >
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="40" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;�׹�ѹ���ź�����ŷ������ͧ<?php echo $C_NAME; ?>&nbsp;</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="red" size="2" >��ͧ���ź�����ŷ������ͧ (<?php echo $C_ID; ?>) <?php echo $C_NAME; ?></font><br><br>
						</td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" >
						<input name="Submit" type="submit" value="�׹�ѹ" class="formbutton" style=width:100px>
						<input type="button" value="¡��ԡ" onclick="history.back();" class="formbutton" style="width:100px">
						</form>
						</td>
					</tr>
				</table>

				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>