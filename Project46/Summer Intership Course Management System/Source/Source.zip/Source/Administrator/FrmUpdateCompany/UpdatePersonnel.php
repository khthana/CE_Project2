<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$Flag = true;

$P_ID;
$P_PREFACE = htmlspecialchars( trim( $P_PREFACE ) );
$P_NAME = htmlspecialchars( trim( $P_NAME ) );
$P_POS = htmlspecialchars( trim( $P_POS ) );
$P_TEL = htmlspecialchars( trim( $P_TEL ) );
$P_FAX = htmlspecialchars( trim( $P_FAX ) );

/* ��Ǩ�ͺ��û�͹���ͼ��Դ��� */
if ( $P_NAME == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹���ͼ��Դ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		UpdatePersonnelContact( $P_ID, $P_PREFACE, $P_NAME, $P_POS, $P_TEL, $P_FAX );
		
		$msg .= "<li class=\"black16\"><b>$P_NAME</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红��������º��������";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

echo $button;

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Update Personnel Contact</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<li>System Message
<?php echo $msg; ?>

</body>
</html>