<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$strSQL = "DELETE FROM personnel_contact ";
$strSQL .= "WHERE P_ID='$P_ID' ";

mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

$strSQL = "DELETE FROM has ";
$strSQL .= "WHERE P_ID='$P_ID' ";

mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

CloseDB();

header("Location: FrmListPersonnel.php?OrderBy=H_DATETIME_REGISTER");

?>