<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();
$Flag = true;

$C_ID;
$C_TYPE = htmlspecialchars( trim( $C_TYPE ) );
$C_NAME = htmlspecialchars( trim( $C_NAME ) );
$C_NAME_EN = htmlspecialchars( trim( $C_NAME_EN ) );
$C_ADDR = htmlspecialchars( trim( $C_ADDR ) );
$C_LOCATION = htmlspecialchars( trim( $C_LOCATION ) );
$C_POSTCODE = htmlspecialchars( trim( $C_POSTCODE ) );
$C_COUNTRY = htmlspecialchars( trim( $C_COUNTRY ) );
$C_TEL = htmlspecialchars( trim( $C_TEL ) );
$C_FAX = htmlspecialchars( trim( $C_FAX ) );
$C_WEBSITE = htmlspecialchars( trim( $C_WEBSITE ) );

$C_APPLY_MODE = htmlspecialchars( trim( $C_APPLY_MODE ) );
$C_POS_AVA = htmlspecialchars( trim( $C_POS_AVA ) );
$C_DATE_SENDLIST = htmlspecialchars( trim( $C_DATE_SENDLIST ) );
$C_DATE_RESULT = htmlspecialchars( trim( $C_DATE_RESULT ) );
$C_DATE_BEGIN = htmlspecialchars( trim( $C_DATE_BEGIN ) );
$C_DATE_END = htmlspecialchars( trim( $C_DATE_END ) );
$C_WHERE_REPORT = htmlspecialchars( trim( $C_WHERE_REPORT ) );
$C_ATTACH = htmlspecialchars( trim( $C_ATTACH ) );
$C_WORK_LOCATION = htmlspecialchars( trim( $C_WORK_LOCATION ) );
$C_REST = htmlspecialchars( trim( $C_REST ) );
$C_MIN_GPA = htmlspecialchars( trim( $C_MIN_GPA ) );
$C_WAGE = htmlspecialchars( trim( $C_WAGE ) );
$C_DETAIL = htmlspecialchars( trim( $C_DETAIL ) );
$C_OTHER = htmlspecialchars( trim( $C_OTHER ) );

$C_REASON = htmlspecialchars( trim( $C_REASON ) );

/* ��Ǩ�ͺ��û�͹���ͺ���ѷ */
if ( $C_NAME == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ͺ���ѷ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹ GPA ��鹵�� */
if ( $C_MIN_GPA < 0 )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ GPA ���١��ͧ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹�ѵ�Ҥ�Ҩ�ҧ */
if ( $C_WAGE < 0 )
	{
		$msg .= "<li class=\"black16\">��سһ�͹�ѵ�Ҥ�Ҩ�ҧ���١��ͧ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		echo "<li>$C_ID";
		echo "<li>$C_TYPE";
		echo "<li>$C_NAME";
		echo "<li>$C_NAME_EN";
		echo "<li>$C_ADDR";
		echo "<li>$C_LOCATION";
		echo "<li>$C_POSTCODE";
		echo "<li>$C_COUNTRY";
		echo "<li>$C_TEL";
		echo "<li>$C_FAX";
		echo "<li>$C_WEBSITE";

		echo "<li>$C_APPLY_MODE";
		echo "<li>$C_POS_AVA";
		echo "<li>$C_DATE_SENDLIST";
		echo "<li>$C_DATE_RESULT";
		echo "<li>$C_DATE_BEGIN";
		echo "<li>$C_DATE_END";
		echo "<li>$C_WHERE_REPORT";
		echo "<li>$C_ATTACH";
		echo "<li>$C_WORK_LOCATION";
		echo "<li>$C_REST";
		echo "<li>$C_MIN_GPA";
		echo "<li>$C_WAGE";
		echo "<li>$C_DETAIL";
		echo "<li>$C_OTHER";
		echo "<li>$C_REASON";

		echo "<li>$mode";
		UpdateCompanyName( $C_ID, $C_TYPE, $C_NAME, $C_NAME_EN, $C_ADDR, $C_LOCATION, $C_POSTCODE, $C_TEL, $C_FAX, $C_WEBSITE, $C_COUNTRY );
		$C_DATE_BEGIN = FormatDATE($YEARB , $MONTHB , $DAYB);
		$C_DATE_END = FormatDATE($YEARE , $MONTHE , $DAYE);
		$C_DATE_SENDLIST = FormatDATE($YEARS , $MONTHS , $DAYS);
		$C_DATE_RESULT = FormatDATE($YEARR , $MONTHR , $DAYR);
		$C_DATETIME_REGISTER_NEW = FormatDATE($YEARREG , $MONTHREG , $DAYREG);

		if( $MODE == "UPDATE" )
		{
			UpdateCompany( $C_ID, $C_DETAIL, $C_POS_AVA, $C_DATE_SENDLIST, $C_DATE_RESULT, $C_APPLY_MODE, $C_MIN_GPA, $C_WAGE, $C_WHERE_REPORT,	 $C_DATE_BEGIN, $C_DATE_END, $C_ATTACH, $C_WORK_LOCATION, $C_REST, $C_REASON, $C_OTHER,$C_DATETIME_REGISTER,$C_DATETIME_REGISTER_NEW );

			$msg .= "<li class=\"black16\">����ѷ <b>$C_NAME</b>";
			$msg .= "<li class=\"black16\">�к��ӡ�� Update ���ҧ Company_Name ��� Company ���º��������";
			$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
		}
		else
		{
			 Insert2Company( $C_ID, $C_DETAIL, $C_POS_AVA, $C_DATE_SENDLIST, $C_DATE_RESULT, $C_APPLY_MODE, $C_MIN_GPA, $C_WAGE, $C_WHERE_REPORT,	 $C_DATE_BEGIN, $C_DATE_END, $C_ATTACH, $C_WORK_LOCATION, $C_REST, $C_REASON, $C_OTHER,$C_DATETIME_REGISTER_NEW );

			 $msg .= "<li class=\"black16\">����ѷ <b>$C_NAME</b>";
			$msg .= "<li class=\"black16\">�к��ӡ�� Update ���ҧ Company_Name ��� Insert �����ŵ��ҧ Company ����ѷ���º��������";
			$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
		}
	
		
	}

echo $button;

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Update Company</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<li>��ͤ����駨ҡ�к�
<?php echo $msg; ?>

</body>
</html>