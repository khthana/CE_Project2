<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$strSQL = "DELETE FROM company_name ";
$strSQL .= "WHERE C_ID='$C_ID' ";
mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

$strSQL = "DELETE FROM company ";
$strSQL .= "WHERE C_ID='$C_ID' ";
mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

$strSQL = "SELECT P_ID FROM has ";
$strSQL .= "WHERE C_ID='$C_ID' ";
$result = mysql_query( $strSQL, $conn );
if ( ! $result )
	die ( "SELECT �բ�ͼԴ��Ҵ" . mysql_error() );
while($rs = mysql_fetch_array( $result ))
{
	$strSQL2 = "DELETE FROM personnel_contact ";
	$strSQL2 .= "WHERE P_ID='$rs[P_ID]' ";
	mysql_query( $strSQL2, $conn )
		or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();
}

$strSQL = "DELETE FROM has ";
$strSQL .= "WHERE C_ID='$C_ID' ";
mysql_query( $strSQL, $conn )
	or die ( "DELETE �բ�ͼԴ��Ҵ�Դ���") . mysql_error();

CloseDB();

header("Location: FrmListCompany.htm?OrderBy=C_NAME");

?>