<?php
include( "../phpConfig.php" );
include( "../phpFunctionDB.php" );
include( "../phpFunction.php" );
?>

<html>
<head>
<title>�š������¹�ŧʶҹТͧ�ѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link rel="stylesheet" href="../StyleJobDB.css" type="text/css">
</head>
<script language="JavaScript">
<!-- 
function OpenNewWindow(url,winwidth,winheight) 
{
	NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=auto,resizable=no,copyhistory=no,width='+winwidth+',height='+winheight)
}
-->
</script>

<body background="../images/bgtop.gif" leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<?php 

$Flag = false;

for($i=0;$i<=$length;$i++)
	{
		if ($S_ID[$i] != "")
			$Flag = true;
	}

if ( !$Flag )
{
		$msg .= "<li class=\"black16\" >��سҤѴ���͡�ѡ�֡��";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
{

	Conn2DB();

	for($i=0;$i<=$length;$i++)
	{
		$FlagDB = false;
		for($j=0;$j<=$length;$j++)
		{
			if ($S_ID_ALL[$i] == $S_ID[$j])
			{
				$FlagDB = true;
			}
		}
		if ($FlagDB)
			{
				global $conn;
				$strSQL = "UPDATE student ";
				$strSQL .= "SET S_STATUS='������' ";
				$strSQL .= "WHERE S_ID='$S_ID_ALL[$i]' ";
				mysql_query( $strSQL, $conn )
					or die ( "INSERT �բ�ͼԴ��Ҵ�Դ���" ) . mysql_error();

				$msg .= "<li class=\"black16\">�ѡ�֡�� ����<b>$S_ID[$i]</b>";
				$msg .= "<li class=\"black16\">�к�����¹�ŧʶҹТͧ�ѡ�֡�����º��������";
				$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
				$button2 = "<input type=\"button\" value=\"��Ѻ令Ѵ���͡\" onclick=window.location='SelectCompany.html' class=\"formbutton\" style=\"width:100px\">";
				$button3 = "<input type=\"button\" value=\"˹�� print ��§ҹ\" onclick=window.location='PrintReport.php' class=\"formbutton\" style=\"width:100px\">";
			}
			else
			{
				global $conn;
				$strSQL = "UPDATE student ";
				$strSQL .= "SET S_STATUS='�ѧ�����' ";
				$strSQL .= "WHERE S_ID='$S_ID_ALL[$i]' ";
				mysql_query( $strSQL, $conn )
					or die ( "INSERT �բ�ͼԴ��Ҵ�Դ���" ) . mysql_error();
			}
	}

	CloseDB();

}

?>
<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;��ͤ����駨ҡ�к�&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="blue" size="2" ><?php echo $msg; echo "<br><br>"; echo "$button2&nbsp;"; echo "$button3&nbsp;"; echo $button; ?></font><br><br>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>