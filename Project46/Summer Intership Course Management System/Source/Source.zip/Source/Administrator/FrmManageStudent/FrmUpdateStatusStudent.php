<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

$strSQL_std = "SELECT S_ID,C_ID,S_PREFACE,S_NAME,S_METHOD,S_STATUS FROM student ";
$strSQL_std .= "WHERE S_ID='$S_ID' ";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/

$result_std = mysql_query( $strSQL_std, $conn )
	or die ( "�������ö����������ŧ�����ҧ��" . mysql_error() );

$rs_std = mysql_fetch_array( $result_std );

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�������䢢�����ʶҹйѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitleB" align="center">&nbsp;</td>
	</tr>
</table>
<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr> 
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<form method="post" action="UpdateStatusStudent.php">
				<input name="S_ID" type="hidden" id="S_ID" value="<?php echo "$rs_std[S_ID]"; ?>" size="50" maxlength="100" >
				<input name="S_PREFACE" type="hidden" id="S_PREFACE" value="<?php echo "$rs_std[S_PREFACE]"; ?>" size="50" maxlength="100" >
				<input name="S_NAME" type="hidden" id="S_NAME" value="<?php echo "$rs_std[S_NAME]"; ?>" size="50" maxlength="100" >
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width=760>
					<tr height="30" bgcolor="#c7c5c5" class="content">	
						<td width="20%" align="center" >&nbsp;����¹�ŧ������ <?php echo $rs_std[S_PREFACE]; echo $rs_std[S_NAME]; ?> ���ʻ�Шӵ�� <?php echo $rs_std[S_ID]; ?></td>
					</tr>
				</table>
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width=760>
					<tr height="30" bgcolor="#c7c5c5" class="content">	
						<td width="20%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp;�������</td>
						<td width="80%" onmouseover=this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' >&nbsp;��ǹ��䢢�����</td>
					</tr>				
				</table>

				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;ʶҹ����Сͺ���</td>
						<td class="black8" width="80%">&nbsp;<select name="C_ID" id="C_ID" ><?php CreateDropDownCompanyGetParameter($rs_std[C_ID]); ?></select></td>
					</tr>
				</table>
			
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;�Ըա����Ѥ�</td>
						<td class="black8" width="80%">&nbsp;<select name="S_METHOD" id="S_METHOD" ><?php CreateDropDownMethod($rs_std[S_METHOD]); ?></select></td>
					</tr>
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="20%">&nbsp;ʶҹТͧ�ѡ�֡��</td>
						<td class="black8" width="80%">&nbsp;<select name="S_STATUS" id="S_STATUS" ><?php CreateDropDownStatus($rs_std[S_STATUS]); ?></select></td>
					</tr>
				</table>
				
				<br>
				<input name="Submit" type="submit" value="���" class="formbutton" style=width:100px>
				<input name="Reset" type="reset" value="��Ѻ�׹" class="formbutton" style=width:100px>
				</form>

				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>
<?php

/* �Դ Connection */
CloseDB();

?>