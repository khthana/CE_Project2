<?php
include("../../phpConfig.php");
include("../../phpFunctionDB.php");
include("../../phpFunction.php");

Conn2DB();

$Flag = true;

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		UpdateStatusStudent( $S_ID,$C_ID,$S_METHOD,$S_STATUS );
		
		$msg .= "<li class=\"black16\"><b>$S_PREFACE$S_NAME</b>";
		$msg .= "<li class=\"black16\">�к���䢢����Źѡ�֡�����º��������";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>������ʶҹТͧ�ѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="40" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;������ʶҹТͧ�ѡ�֡��&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="blue" size="2" ><?php echo $msg; echo "<br><br>"; echo $button; ?></font><br><br>
						</td>
					</tr>
				</table>
				
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>