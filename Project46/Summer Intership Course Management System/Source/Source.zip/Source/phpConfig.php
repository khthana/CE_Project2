<?php
$ServerName = "127.0.0.1";
$UserName = "root";
$UserPassword = "lee*tunk";
$DataBaseName = "project";

$BoardTitle = "discuss-board";
$AdminMail = "cossacktunk2@hotmail.com";
$URL = "http://localhost/workshop/discuss/";

/* ��˹�����к���Ժѵԡ�� Unix ���� Win */
$OS = "Win";

$FileBad_Win_Path = "C:\\Apache\\apache\\htdocs\\workshop\\discuss\\inc\\wordbad.txt";
$FileBad_Unix_Path = "/home/httpd/htdocs/discuss/inc/wordbad.txt";

$UpImage_Win_Path = "C:\\Apache\\apache\\htdocs\\workshop\\discuss\\UploadImages\\";
$UpImage_Unix_Path = "/home/httpd/htdocs/discuss/UploadImages/";

$UpFile_Win_Path = "C:\\Apache\\apache\\htdocs\\workshop\\discuss\\UploadFiles\\";
$UpFile_Unix_Path = "/home/httpd/htdocs/discuss/UploadFiles/";

$FileBadWord = ( $OS == "Win" )?$FileBad_Win_Path:$FileBad_Unix_Path;
$PathUploadImages = ( $OS == "Win" )?$UpImage_Win_Path:$UpImage_Unix_Path;
$PathUploadFiles = ( $OS == "Win" )?$UpFile_Win_Path:$UpFile_Unix_Path;

$Per_Page = 35;
$FixedPages = 5;

$bsEnrollTable1 = "#04488C";
$bsEnrollTable2= "#0253AC";
?>
