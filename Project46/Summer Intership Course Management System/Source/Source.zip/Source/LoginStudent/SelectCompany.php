<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

Conn2DB();

$Flag = true;

$C_ID = htmlspecialchars( trim( $C_ID ) );
$S_ID = htmlspecialchars( trim( $S_ID ) );
$S_NAME = htmlspecialchars( trim( $S_NAME ) );
$S_PASSWORD = htmlspecialchars( trim( $S_PASSWORD ) );
$S_PASSWORD2 = htmlspecialchars( trim( $S_PASSWORD2 ) );

/* ��Ǩ�ͺ��û�͹ PASSWORD */
if ( $S_PASSWORD != $S_PASSWORD2 )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ Password ���١��ͧ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹���ʹѡ�֡�� */
if ( $S_ID == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹ Username";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹ PASSWORD */
if ( $S_PASSWORD == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ Password";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ������͡����ѷ*/
if ( ($C_ID == "undefined")or($C_ID == "") )
	{
		$msg .= "<li class=\"black16\" >��س����͡ʶҹ����Сͺ��÷���份֡�ҹ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��õ�Ǩ�ͺ�����Ţ�����
if ($Flag )
	{
		$S_METHOD = "���";
		$S_STATUS = "���ѧ���Թ���";
		UpdateStudentSelectCompany( $C_ID, $S_METHOD, $S_STATUS, $S_ID, $S_PASSWORD2 );

		$strSQL = "SELECT C_NAME ";
		$strSQL .= "FROM company_name ";
		$strSQL .= "WHERE C_ID='$C_ID' ";
		$result = mysql_query( $strSQL, $conn );
		if ( ! $result )
			die ( "SELECT �բ�ͼԴ��Ҵ" . mysql_error() );
		$rs = mysql_fetch_array( $result );

		$msg .= "<li class=\"black16\">�ѡ�֡��&nbsp;<font color=#000EEE>$S_NAME</font>&nbsp;���͡�֡�ҹ�Ѻ&nbsp;<font color=#000EEE>$rs[C_NAME]</font>";
		$msg .= "<li class=\"black16\">�ʹٻ�С�ȼŷ��˹���á�ͧ�к�����";
		$msg .= "<li class=\"black16\">��ѧ�ҡ�����ҹ�������ӡ�ä�ԡ���<a href=\"...\" >�͡�ҡ�к�</a>���ͤ�����ʹ��·ء����";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";
	}

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Index ��ѧ�ҡ Login</title>
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-874">
<link REL="stylesheet" TYPE="text/css" HREF="../StyleJobDB.css">
<!--------------------------Set Style------------------------------->
<style type="text/css">
</style>
<!-------------------Display Time+Date in status line------------------------------->
<SCRIPT>
function display_time_in_status_line()
{
var d = new Date(); 
var y = d.getYear() + 543; 
var h = d.getHours(); 
var m = d.getMinutes(); 
var s = d.getSeconds(); 0
var mo = d.getMonth() + 1; 
var da = d.getDate(); 
var ampm = (h >= 12)?"PM":"AM"; 
if (h > 12) h -= 12; 
if (h == 0) h = 12; 
if (m < 10) m = "0" + m; 
var t = '  ��й�� �ѹ���  ' + da + '/' + mo + '/' + y + '  ���� ' + h + ':' + m + ':' + s + ' ' + ampm; 
defaultStatus = t; 
setTimeout("display_time_in_status_line()", 1000); 
}
onLoad=display_time_in_status_line();
</SCRIPT>
<!---------------------------End Display Time+Date----------------------->
<!---------------------------Function Fade----------------------->
<script>
nereidFadeObjects = new Object();
nereidFadeTimers = new Object();

function nereidFade(object, destOp, rate, delta){
if (!document.all)
return
    if (object != "[object]"){  //do this so I can take a string too
        setTimeout("nereidFade("+object+","+destOp+","+rate+","+delta+")",0);
        return;
    }
        
    clearTimeout(nereidFadeTimers[object.sourceIndex]);
    
    diff = destOp-object.filters.alpha.opacity;
    direction = 1;
    if (object.filters.alpha.opacity > destOp){
        direction = -1;
    }
    delta=Math.min(direction*diff,delta);
    object.filters.alpha.opacity+=direction*delta;

    if (object.filters.alpha.opacity != destOp){
        nereidFadeObjects[object.sourceIndex]=object;
        nereidFadeTimers[object.sourceIndex]=setTimeout("nereidFade(nereidFadeObjects["+object.sourceIndex+"],"+destOp+","+rate+","+delta+")",rate);
    }
}
</script>
<!---------------------------End Function Fade----------------------->
<!---------------------------Top Menu Bar----------------------->
<script language="JavaScript" src="../navcond.js"></script>
<SCRIPT language="JavaScript1.2">
var cssdefinition='<style>\n.menuitems{\nborder:2.5px solid #FFF2BF;\n}\n\n.menuitems a{\ntext-decoration:none;\ncolor:black;\n}\n<\/style>'

//No need to edit beyond here
if (document.all||document.getElementById)
document.write(cssdefinition)

function over_effect(e,state, bgcolor){
if (document.all)
source4=event.srcElement
else if (document.getElementById)
source4=e.target
if (source4.className=="menuitems"){
source4.style.borderStyle=state
source4.style.backgroundColor=bgcolor
}
else{
while(source4.tagName!="DIV"){
source4=document.getElementById? source4.parentNode : source4.parentElement
if (source4.className=="menuitems"){
source4.style.borderStyle=state
source4.style.backgroundColor=bgcolor
}
}
}
}
var myNavBar1 = new NavBar(0);
var dhtmlMenu;

//define menu items (first parameter of NavBarMenu specifies main category width, second specifies sub category width in pixels)
//add more menus simply by adding more "blocks" of same code below

dhtmlMenu = new NavBarMenu(120,150);
dhtmlMenu.addItem(new NavBarMenuItem("˹���á", "Index.html"));
myNavBar1.addMenu(dhtmlMenu);

dhtmlMenu = new NavBarMenu(220,262 );
dhtmlMenu.addItem(new NavBarMenuItem("��鹵͹�����ʶҹ���֡�ҹ", "Way2Regis.html"));
dhtmlMenu.addItem(new NavBarMenuItem("��鹵͹��û�Ժѵ�㹪�ǧ���ҡ�͹��ý֡�ҹ", "BeforeTrain.html"));
dhtmlMenu.addItem(new NavBarMenuItem("��鹵͹��û�Ժѵ�㹪�ǧ�ѹ�Ѻ��ý֡�ҹ", "InTraining.html"));
dhtmlMenu.addItem(new NavBarMenuItem("��鹵͹��û�Ժѵ���ѧ�ҡ�Ѻ��ý֡�ҹ�������", "AfterTrain.html"));
myNavBar1.addMenu(dhtmlMenu);

dhtmlMenu = new NavBarMenu(150,150);
dhtmlMenu.addItem(new NavBarMenuItem("ŧ����¹�ѡ�֡�һ� 3", "../FrmRegisterStudent/FrmCheckID.php"));
myNavBar1.addMenu(dhtmlMenu);

dhtmlMenu = new NavBarMenu(150,261);
dhtmlMenu.addItem(new NavBarMenuItem("�����ź���ѷ", ""));
dhtmlMenu.addItem(new NavBarMenuItem("�����ź���ѷ㹻շ���ҹ��", "FrmListCompany/FrmListCompanyOld.htm?OrderBy=C_DATETIME_REGISTER"));
dhtmlMenu.addItem(new NavBarMenuItem("�����ź���ѷ㹻չ��", "FrmListCompany/FrmListCompanyNew.htm?OrderBy=C_DATETIME_REGISTER"));
dhtmlMenu.addItem(new NavBarMenuItem("�����ź���ѷ����ѧ����ö�Ѻ�ѡ�֡����", ""));
myNavBar1.addMenu(dhtmlMenu);

dhtmlMenu = new NavBarMenu(120,150);
dhtmlMenu.addItem(new NavBarMenuItem("��纺���", "webboard/webboard.php"));
myNavBar1.addMenu(dhtmlMenu);

//set menu colors
myNavBar1.setColors("#000000", "#000000", "#C0C0C0", "#ffffff", "#666666", "#000000", "#cccccc", "#ffffff", "#000080")

//uncomment below line to center the menu (valid values are "left", "center", and "right"
//myNavBar1.setAlign("center")

var fullWidth;

function init() {
  // Get width of window, need to account for scrollbar width in Netscape.

  fullWidth = getWindowWidth() 
    - (isMinNS4 && getWindowHeight() < getPageHeight() ? 16 : 0);

  //myNavBar1.resize(fullWidth);
  myNavBar1.create();
  myNavBar1.setzIndex(2);
  myNavBar1.moveTo(0,130);
}
</SCRIPT>
<!---------------------------End Top Menu Bar----------------------->
</head>

<body onload="init()" BGCOLOR="#FFFFFF" LEFTMARGIN="0" TOPMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0">

<!---------------------------Begin Hidden----------------------->
<input name="S_ID" id="S_ID" type="hidden" size=8 maxlength=20 value="<?php echo $S_ID; ?>" >
<input name="S_PASSWORD" id="S_PASSWORD" type="hidden" size=8 maxlength=20 value="<?php echo $S_PASSWORD; ?>" >
<!---------------------------End Hidden----------------------->

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr> 
    <td colspan="3"> 
      <SCRIPT language=javascript>
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
function submit_login()
{
var username=document.userlogin.username.value
var password=document.userlogin.password.value
var remember=document.userlogin.remember.value
  open_statement="slogin.asp?"+"username="+username+"&password="+password+"&remember="+remember
window.open (open_statement,"spoll", 'scrollbars=no,status=no,width=300,height=200,resizable=yes,top=0')
}
//-->
</SCRIPT>
<!--------------------TOP--------background="../../images/bgtop.gif"------------------------>
<table  WIDTH="100%" BORDER="0" CELLPADDING="2" CELLSPACING="2">
  
  <tr>
    <td height="60">
    <p align="left">
    <img SRC="../images/Web_Logo.gif" border="0" height="120"  width="78%" /></a></p>
    </td>
  </tr>
                <td>&nbsp;&nbsp;</td></tr>
  <tr>
  <!--  Resize-->
		<tr>
<!--  End Resize-->
    </td>

</table>
    </td>
  </tr>
  <!----background="../../images/bgtop.gif"-----------LEFT------------------->
  <tr> 
    <td   width="50" valign="top">    
<table border="8" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="50"  bgcolor="#EEEEEE">	
  <tr> 
    <td  width="10%"> <img border="0" src="../images/menu_user-acc.jpg"  width="180" height="20"></td>
    <TD width=1 bgColor=#919293 rowSpan=20><IMG height=2  width=1></TD>
  </tr>
   <TR> 
    <TD> <IMG height=1  width=1></TD>
  </TR>
<TR>
          <TD>
         <table border="0" width=198 >
  <tr>
    <td width="100%" bgcolor="#E6E6E6" background="../images/bg_sky.gif"><center><font color=#0BAEEE><b>MENU<b></font></center></td>
    <tr>
    <td width="100%"><a href="FrmViewStudent.html?S_ID=<?php echo $S_ID; ?>&S_PASSWORD=<?php echo $S_PASSWORD; ?>&OrderBy=<?php echo $OrderBy; ?>" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� ˹���á��Ҫԡ</a></td>
  </tr>
  <tr>
    <td width="100%"><a href="FrmBeforeByStd.php?S_ID=<?php echo $S_ID; ?>&S_PASSWORD=<?php echo $S_PASSWORD; ?>&OrderBy=<?php echo $OrderBy; ?>" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ�ͧ</a></td>
  </tr>
  <tr>
    <td width="100%"><a href="FrmStatusStudent.html?S_ID=<?php echo $S_ID; ?>&S_PASSWORD=<?php echo $S_PASSWORD; ?>&OrderBy=<?php echo $OrderBy; ?>" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� ��Ǩ�ͺʶҹ�</a></td>
  </tr>
  <tr>
    <td width="100%"><a href="FrmUpdateDetail.html?S_ID=<?php echo $S_ID; ?>&S_PASSWORD=<?php echo $S_PASSWORD; ?>&OrderBy=<?php echo $OrderBy; ?>" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� ��䢢�������ǹ���</a></td>
  </tr>
  <tr>
    <td width="100%"><a href="FrmChangePasswd.html?S_ID=<?php echo $S_ID; ?>&S_PASSWORD=<?php echo $S_PASSWORD; ?>&OrderBy=<?php echo $OrderBy; ?>" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� ����¹ Password</a></td>
  </tr>
  <tr>
    <td width="100%"><a href="Logout.php" onClick="return Conf1(this)" class="menulink2" >&nbsp;&nbsp;&nbsp;&nbsp;� �͡�ҡ�к�</a></td>
  </tr>
  <TR>
          <TD>&nbsp;</TD></TR>
<tr> 
    <td border=0 width="100%"> 
      <table align="center" width="150">
        <tr> 
          <td > <a href="http://webmail.kmitl.ac.th" target="_blank"> <img border="0" src="../images/link_webmail.gif" width="139" height="50" style="filter:alpha(opacity=50)" onMouseOver="nereidFade(this,120,10,30)" onMouseOut="nereidFade(this,60,10,5)"></a></td>
        </tr>
        <tr> 
          <td > <a href="http://161.246.4.7" target="_blank"> <img border="0" src="../images/link_ce.gif" width="139" height="50" style="filter:alpha(opacity=50)" onMouseOver="nereidFade(this,120,10,30)" onMouseOut="nereidFade(this,60,10,5)"></a></td>
        </tr>
		<tr> 
          <td > <a href="http://161.246.10.21" target="_blank"> <img border="0" src="../images/link_kmitl.gif" width="139" height="45" style="filter:alpha(opacity=50)" onMouseOver="nereidFade(this,120,10,30)" onMouseOut="nereidFade(this,60,10,5)"></a></td>
        </tr>
		<TR>
          <TD>&nbsp;</TD></TR>
      </table>

</table></TD></TR>
<!--  End Resize-->


</table>
    </td>
<!-----background="../images/bgtop.gif"-------------- CENTER----------------------648-->	
	<td  width="864"> 
      <table border="0" cellpadding="0" cellspacing="0" align="left" style="border-collapse: collapse" bordercolor="#111111" width="70%">
        <tr> 
          <td> 
            <p class="mtext" align="center">� 
          </td>
        </tr>
        <tr> 
          <td width="100%"> 
            <table width="100%" border=0 cellpadding=0 cellspacing=0>
              <tr>
   			     <!--<td rowspan=2 width=51 height=20> <img src="images/topic_arrow.jpg" width=51 height=20 alt=""></td>-->		
                <td rowspan=2 width=144 height=20> <img src="../images/overview2.jpg"  width=150 height=22 alt=""></td>
                <td colspan=2  height=15></td>
              </tr>
              <tr> 
                <td width="100%" height=1 background="../images/line_bar.jpg" ></td>
                <td  width=13 height=1> <img src="../images/line_bar.jpg" width=13 height=5 alt=""></td>
              </tr>
            </table>
            
            <table width="100%" height="150" border="0" cellspacing="1" cellpadding="2" bgcolor="#999999">
              <tr> 
                <td bgcolor="#FFFFFF"><TABLE border=0 ><TBODY><TR><TD class="thaipanel"><DIV align=justify><font color=#37B444><?php echo $msg; ?><br><?php echo $button; ?></font> </DIV></TD></TR></TBODY></TABLE>
<br>
         
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td> <br><br>        
          </td>
        </tr>
<!---------------------------Begin Footer---------------------------->
				<tr> 
          <td width="100%"> 
              <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">

	<tr>
      <td class=footer height="100%">
      <p align="center"><br><br>
      Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404
�觤ӵ�����<br> mailto:akiyamakung@hotmail.com
<br><br>
        Copyright &copy; 2003; , All rights reserved.
<script language="JavaScript" src="http://m1.nedstatbasic.net/basic.js">
</script>
<script language="JavaScript">
<!--
  nedstatbasic("ACKysAxsJTUzx/pBbeKQm+CTTKwg", 0);
// -->
</script>
<noscript>
<a target="_blank" href="http://v1.nedstatbasic.net/stats?ACKysAxsJTUzx/pBbeKQm+CTTKwg"><img
src="http://m1.nedstatbasic.net/n?id=ACKysAxsJTUzx/pBbeKQm+CTTKwg"
border="0" nosave width="10" height="10"></a></noscript> 
<!--BEGI	N WEB STAT CODE---->
<SCRIPT LANGUAGE="javascript1.1" 
src="http://truehits1.gits.net.th/data/f0009138.js"></SCRIPT><br><br><br><br>
<!-- END WEBSTAT CODE -->
<!---------------------------End Footer---------------------------->
    </td>
    </tr>
  </table>
          </td>
        </tr>
      </table>
    </td>
   	  </tr>
</table>
</body>
</html>