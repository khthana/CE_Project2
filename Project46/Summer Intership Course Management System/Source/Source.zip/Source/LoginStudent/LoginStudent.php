<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

Conn2DB();

$Flag = true;

$S_ID = htmlspecialchars( trim( $S_ID ) );
$S_PASSWORD = htmlspecialchars( trim( $S_PASSWORD ) );

//$mDateBorn = $mYear."-".$mMonth."-".$mDay;

/* ��Ǩ�ͺ������ʹѡ�֡��*/
if ( $S_ID == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹ Username";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��� PASSWORD*/
if ( $S_PASSWORD == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ Password";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��õ�Ǩ�ͺ�����Ţ�����
if ($Flag )
	{
		if(CheckStudentLogin( $S_ID, $S_PASSWORD ))
		{
			if(CheckStudentRegistered( $S_ID ))
			{
				header("Location: FrmViewStudent.html?S_ID=$S_ID&S_PASSWORD=$S_PASSWORD&OrderBy=C_DATETIME_REGISTER");
			}
			else
			{
				header("Location: FrmRegisterStudent.html?S_ID=$S_ID");
			}
		}
		else
		{
			$msg .= "<li class=\"black16\">�Դ�����͡�Թ��ӫ�͹ ���� ��͡ password �Դ";
			$button = "<input type=\"button\" value=\"��Ѻ�˹����ѡ\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		}
	}


CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Login Student</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;��ͤ����駨ҡ�к�&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="red" size="2" ><?php echo $msg; echo "<br><br>"; echo $button; ?></font><br><br>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</body>
</html>