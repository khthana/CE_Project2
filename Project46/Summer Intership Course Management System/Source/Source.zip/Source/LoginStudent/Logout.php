<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

header('Location: ../index.html');

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Redirect to Index.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>
</body>
</html>