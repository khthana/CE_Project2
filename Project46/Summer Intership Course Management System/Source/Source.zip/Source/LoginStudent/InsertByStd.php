<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

Conn2DB();
$Flag = true;

$C_NAME = htmlspecialchars( trim( $C_NAME ) );

$S_TEL = htmlspecialchars( trim( $S_TEL ) );
$P_PREFACE = htmlspecialchars( trim( $P_PREFACE ) );
$P_NAME = htmlspecialchars( trim( $P_NAME ) );
$P_POS = htmlspecialchars( trim( $P_POS ) );
$P_TEL = htmlspecialchars( trim( $P_TEL ) );
$P_FAX = htmlspecialchars( trim( $P_FAX ) );

$P_PREFACE2 = htmlspecialchars( trim( $P_PREFACE2 ) );
$P_NAME2 = htmlspecialchars( trim( $P_NAME2 ) );
$P_POS2 = htmlspecialchars( trim( $P_POS2 ) );
$P_TEL2 = htmlspecialchars( trim( $P_TEL2 ) );
$P_FAX2 = htmlspecialchars( trim( $P_FAX2 ) );

$DATETIME_SELECT = FormatDATE($YEARSEL , $MONTHSEL , $DAYSEL);

/* ��Ǩ�ͺ��û�͹���ͼ��Դ��� */
if ( $P_NAME == "" )
	{
		$msg .= "<li class=\"black16\" >��سһ�͹���ͼ��Դ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹���ͺ���ѷ */
if ( $P_NAME2 == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ͼ�����ҹ�ҹ";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		$S_METHOD = "���ͧ";
		$S_STATUS = "���ѧ�Դ���";
		$C_COUNTRY = "Thailand";
		
		if($C_ID == "")
			$C_ID = Insert2CompanyNameByStd( $C_TYPE, $C_NAME, $C_COUNTRY );

		UpdateStudentByStd( $S_ID, $C_ID, $S_TEL, $S_METHOD, $S_STATUS, $DATETIME_SELECT );

		$P_ID = CheckPersonnelContactRegister( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 if($P_ID == "")
			$P_ID = Insert2PersonnelContact( $P_PREFACE, $P_NAME, $P_TEL, $P_FAX,$P_POS );
		 Insert2Has( $C_ID,$P_ID );

		 $P_ID = CheckPersonnelContactRegister( $P_PREFACE2, $P_NAME2, $P_TEL2, $P_FAX2,$P_POS2 );
		 if($P_ID == "")
			$P_ID = Insert2PersonnelContact( $P_PREFACE2, $P_NAME2, $P_TEL2, $P_FAX2,$P_POS2 );
		 Insert2Has( $C_ID,$P_ID );
	
		$msg .= "<li class=\"black16\">Ẻ������ʴ������ӹ��ʹͪ��ͺ���ѷ����份֡�ҹ";
		$msg .= "<li class=\"black16\">�к��Ѵ�红����ź���ѷ���º��������";
		$button = "<input notab type=\"submit\" value=\"��ѧ˹�Ҩ;����Ẻ�����\" onclick=\"window.location='FrmPrintByStd.php?S_ROOM=$S_ROOM&S_ID=$S_ID&S_TEL=$S_TEL';\" class=\"formbutton\" style=\"width:180px\">";
	}

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>ŧ����¹Ẻ�����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<form method="post" action="FrmPrintByStd.php" >
	<input name="S_PREFACE" type="hidden" size="25" maxlength="100" value="<?php echo $S_PREFACEA; ?>" >
	<input name="S_NAME" type="hidden" size="25" maxlength="100" value="<?php echo $S_NAMEA; ?>" >
	<input name="S_PARTY" type="hidden" size="25" maxlength="100" value="<?php echo $S_PARTYA; ?>" >
	<input name="S_ID" type="hidden" size="25" maxlength="100" value="<?php echo $S_ID; ?>" >
	<input name="S_ROOM" type="hidden" size="25" maxlength="100" value="<?php echo $S_ROOMA; ?>" >
	<input name="S_TEL" type="hidden" size="25" maxlength="100" value="<?php echo $S_TEL; ?>" >
	<input name="C_TYPE" type="hidden" size="25" maxlength="100" value="<?php echo $C_TYPEA; ?>" >
	<input name="C_NAME" type="hidden" size="25" maxlength="100" value="<?php echo $C_NAMEA; ?>" >
	<input name="P_PREFACE" type="hidden" size="25" maxlength="100" value="<?php echo $P_PREFACE3; ?>" >
	<input name="P_NAME" type="hidden" size="25" maxlength="100" value="<?php echo $P_NAME; ?>" >
	<input name="P_POS" type="hidden" size="25" maxlength="100" value="<?php echo $P_POS; ?>" >
	<input name="P_PLACE" type="hidden" size="25" maxlength="100" value="<?php echo $P_PLACE; ?>" >
	<input name="P_TEL" type="hidden" size="25" maxlength="100" value="<?php echo $P_TEL; ?>" >
	<input name="P_FAX" type="hidden" size="25" maxlength="100" value="<?php echo $P_FAX; ?>" >
	<input name="P_PREFACE2" type="hidden" size="25" maxlength="100" value="<?php echo $P_PREFACE2; ?>" >
	<input name="P_NAME2" type="hidden" size="25" maxlength="100" value="<?php echo $P_NAME2; ?>" >
	<input name="P_TEL2" type="hidden" size="25" maxlength="100" value="<?php echo $P_TEL2; ?>" >
	<input name="P_FAX2" type="hidden" size="25" maxlength="100" value="<?php echo $P_FAX2; ?>" >
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;��ͤ����駨ҡ�к�&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="blue" size="2" ><?php echo $msg; echo "<br><br>"; echo $button; ?></font><br><br>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</form>
</body>
</html>