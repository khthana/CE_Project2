<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

Conn2DB();
$Flag = true;
$FlagAddr = false;

$S_PREFACE;
$S_NAME = htmlspecialchars( trim( $S_NAME ));
$S_ID = htmlspecialchars( trim( $S_ID));
$S_ROOM;
$S_BIRTHDAY = FormatDATE($S_YEARB , $S_MONTHB , $S_DAYB);

//Attributes of C_ADDR
$S_ADDR;
$S_NUMBER = htmlspecialchars( trim( $S_NUMBER ) );
$S_MOO = htmlspecialchars( trim( $S_MOO ) );
$S_ROAD = htmlspecialchars( trim( $S_ROAD ) );
$S_SOY = htmlspecialchars( trim( $S_SOY ) );
$S_TUMBON = htmlspecialchars( trim( $S_TUMBON ) );
$S_AUMPHER = htmlspecialchars( trim( $S_AUMPHER ) );
$S_PROVINCE = htmlspecialchars( trim( $S_PROVINCE ) );
//End of C_ADDR

$S_POSTCODE = htmlspecialchars( trim( $S_POSTCODE ) );
$S_GPA = htmlspecialchars( trim( $S_GPA ) );
$S_TEL = htmlspecialchars( trim( $S_TEL ) );
$S_MOBILE = htmlspecialchars( trim( $S_MOBILE ) );
$S_ICQ = htmlspecialchars( trim( $S_ICQ ) );
$S_EMAIL1 = htmlspecialchars( trim( $S_EMAIL1 ) );
$S_EMAIL;
//echo "<li>$S_PREFACE";
//echo "<li>$S_NAME";
//echo "<li>$S_ID";
//echo "<li>$S_ROOM";
//echo "<li>$S_POSTCODE";
//echo "<li>$S_GPA";
//echo "<li>$S_TEL";
//echo "<li>$S_MOBILE";

/* ��Ǩ�ͺ��û�͹���ʹѡ�֡�� */
if ( $S_ID == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ʹѡ�֡��";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}
else
	{
		$today = getdate();
		$year = $today[year]+543;

		//�һչ���
		if($today[mon] > 8)
		{
			$year = $year-2;
			$year = substr( $year, 2, 2 );
			$year = $year."01";
		}
		else
		{
			$year = $year-3;
			$year = substr( $year, 2, 2 );
			$year = $year."01";
		}

		if(substr( $S_ID, 0, 4 ) != $year)
		{
			$msg .= "<li class=\"black16\">��سһ�͹���ʹѡ�֡�����١��ͧ";
			$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
			$Flag = false;
		}
	}

/* ��Ǩ�ͺ��û�͹�������ѡ�֡�� */
if ( $S_NUMBER != "" )
	{
		$S_ADDR .= "�Ţ��� ".$S_NUMBER;
		$FlagAddr = true;
	}
if ( $S_MOO != "" )
	{
		$S_ADDR .= " ���� ".$S_MOO;
		$FlagAddr = true;
	}
if ( $S_ROAD != "" )
	{
		$S_ADDR .= " ��� ".$S_ROAD;
		$FlagAddr = true;
	}
if ( $S_SOY != "" )
	{
		$S_ADDR .= " ��� ".$S_SOY;
		$FlagAddr = true;
	}
if ( $S_PROVINCE == "��ا෾�" )
	{
	if ( $S_TUMBON != "" )
		{
			$S_ADDR .= " �ǧ ".$S_TUMBON;
			$FlagAddr = true;
		}
	if ( $S_AUMPHER != "" )
		{
			$S_ADDR .= " ࢵ ".$S_AUMPHER;
			$FlagAddr = true;
		}
	}
else
	{
	if ( $S_TUMBON != "" )
		{
			$S_ADDR .= " �Ӻ� ".$S_TUMBON;
			$FlagAddr = true;
		}
	if ( $S_AUMPHER != "" )
		{
			$S_ADDR .= " ����� ".$S_AUMPHER;
			$FlagAddr = true;
		}
	}
if ( $S_PROVINCE != "" )
	{
		$S_ADDR .= " �ѧ��Ѵ ".$S_PROVINCE;
		$FlagAddr = true;
	}

if ( !$FlagAddr )
	{
		$msg .= "<li class=\"black16\">��سһ�͹�������ѡ�֡��";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹������ɳ��� */
if ( $S_POSTCODE == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹������ɳ���";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹ GPA */
if ( $S_GPA == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ GPA";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹�����Ţ���Ѿ�� */
if ( $S_TEL == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹�����Ţ���Ѿ��";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

/* ��Ǩ�ͺ��û�͹ E-MAIL */
if ( $S_EMAIL1 == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹ E-mail";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		$S_NAME = $S_NAME." ".$S_SURNAME;
		$S_HOTMAIL = $S_EMAIL1."@".$S_EMAIL;
		$S_STATUS = "�ѧ�����";
		//$S_PASSWORD = GenTxts(6);
		$S_PARTY = "���ǡ�������������";
		Update2StudentRegister( $S_ID, $S_BIRTHDAY, $S_ADDR, $S_POSTCODE, $S_PARTY, $S_GPA, $S_TEL, $S_MOBILE, $S_HOTMAIL, $S_ICQ, $S_STATUS );
		
		$msg .= "<li class=\"black16\">�ѡ�֡�� <b>$S_ID</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红����Źѡ�֡�����º��������";
		$msg .= "<li class=\"black16\">����ö��͡�Թ������ҹ������";
		$button = "<input type=\"button\" value=\"˹���á\" onclick=\"window.location='../index.html'\" class=\"formbutton\" style=\"width:100px\">";

}

//echo "<li>$C_NAME";
//echo "<li>$C_ADDR";
//echo "<li>$C_POSTCODE";
//echo "<li>$C_LOCATION";
//echo "<li>$C_POS_AVA";
//echo "<li>$C_DATE_BEGIN";
//echo "<li>$C_DATE_END";
//echo "<li>$C_DATE_REPORT";
//echo "<li>$C_WHERE_REPORT";
//echo "<li>$C_WORK_LOCATION";
//echo "<li>$C_REST";
//echo "<li>$C_DETAIL";
//echo "<li>$C_ATTACH";
//echo "<li>$C_MIN_GPA";
//echo "<li>$C_WAGE";
//echo "<li>$C_OFFICE_DAY";
//echo "<li>$C_TIME_IN";
//echo "<li>$C_TIME_OUT";
//echo "<li>$C_OTHERA";
//echo "<li>$C_APPLY_MODE";
//echo "<li>$C_OTHERD";

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��䢢����Źѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;��ͤ����駨ҡ�к�&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="red" size="2" ><?php echo $msg; echo "<br><br>"; echo $button; ?></font><br><br>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</body>
</html>