<?php
	include("../phpConfig.php");
	include("../phpFunctionDB.php");
	include("../phpFunction.php");
		
		Conn2DB();
  
//read the posted data
		$username=$HTTP_POST_VARS["username"];
		$password=$HTTP_POST_VARS["password"];
		echo $username;
//querying the db to get user who just logged in
		$strSQL = "SELECT S_ID, S_PASSWORD FROM STUDENT ";
		$strSQL .= "WHERE S_ID='$username' ";
		$strSQL .= "AND S_PASSWORD='$password' ";
		$result = mysql_query( $strSQL, $conn );
		  if ( ! $result )
		  {die ( "��� SELECT �բ�ͼԴ��Ҵ" . mysql_error() );
		echo "��Ҵ1";}

//store the query result in an array
		//$row=mysql_fetch_array($result);
		$row = mysql_num_rows($result) ;
				if( !$row )
				{
					echo "Authentication FAILED  Or  " ;
					echo "your username or password are incorrect";
          //add some errorhandling as you like
					die ;
				}
				else
				{	// Login OK!!
					echo $password;
					$row = mysql_fetch_array($result) ;
					$username_temp = $row[0] ;
					echo "$row[0]";
					session_start() ;
					session_register('user') ;
					echo "$row[0]";
					$user = $username_temp ;
					echo "$user";
					//header("location:user.php") ;
			        print "click <a href=\"user.php\">here</a> to proceed";
				}
			CloseDB();
  ?>