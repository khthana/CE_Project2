<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��ª��͹ѡ�֡�ҷ��ŧ����¹�Ѻ�к�����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">

<script language="JavaScript" type="text/javascript">
function OpenNewWindow(url,winwidth,winheight) 
{
	NewWindow=window.open(url,'descr','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbar=no,scrollbars=auto,resizable=no,copyhistory=no,width='+winwidth+',height='+winheight)
}
</script>

</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitleB" align="center">&nbsp;</td>
	</tr>
</table>
<table width="760" border="0" cellspacing="0" cellpadding="1" align=center>
	<tr> 
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr> 
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  					<tr>
						<td align="left" class="subtitle"><a href="../index.html">˹���á</a>
						</td>
  						<td align="right" class="subtitle">&nbsp;<!-------
						<button class="formbutton"  disabled style=width:100px onClick="OpenNewWindow('FormOrderBy.php','400','300')">Order By...</button>&nbsp;&nbsp;
						<button class="formbutton" disabled style=width:100px onClick="OpenNewWindow('FormSelectColumn.htm','400','300')">Select Column...</button>------>
						</td>
  					</tr>
				</table>
				<table width="100%" border="0" cellspacing="0" cellpadding="3">
					<tr bgcolor="eeeeee"> 
						<td class="title2" align="center" >&nbsp;��ª��͹ѡ�֡�ҷ��ŧ����¹�Ѻ�к�����
						</td>
						<!-----<td align="right" class="content">
						<table cellpadding=0 cellspacing=0><tr><td class=black8 align="center" >&nbsp;<img border=0 src="img/arrow_left.gif" WIDTH=8 HEIGHT=8 hspace=2>&nbsp;&nbsp;
						<input type=text class="formtextfield" OnKeyPress="NumOnly();if(event.keyCode=='13'){if(this.value>0&&this.value<=40&&this.value!=1){ document.JobListingForm.CurrentPageNumber.value=this.
						value;document.JobListingForm.submit()}else{this.value=1}}" size=2 maxlength=3 value="1" disabled>&nbsp;&nbsp;&nbsp;<img border=0 src="img/arrow_right.gif" WIDTH=8 HEIGHT=8 hspace=2 onclick="document.
						JobListingForm.CurrentPageNumber.value=2;document.JobListingForm.submit()" onmouseover="this.style.cursor='hand'">
						</td></tr></table></td>----->
					</tr>
				</table>

				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width=760>
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td ID=Cell0 width="80" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListCompanyNew.htm?OrderBy=C_DATETIME_REGISTER' >&nbsp;���ʹѡ�֡��</td>
						<td ID=Cell1 width="150" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListCompanyNew.htm?OrderBy=C_TYPE' >&nbsp;����-���ʡ��
						</td>
						<td ID=Cell2 width="125" onmouseover=this.style.cursor='hand';this.style.background='#dedede' onmouseout=this.style.background='#c7c5c5' onclick=window.location='FrmListCompanyNew.htm?OrderBy=C_NAME'>&nbsp;�ѹ���ҷ��ŧ����¹</td>
				</tr>				
			</table>

<?php
include("../phpConfig.php");
include("../phpFunction.php");
include("../phpFunctionDB.php");

Conn2DB();

//�һչ���
$today = getdate();
$year = $today[year]+543;

//�һչ���
if($today[mon] > 8)
	{
	$year = $year-2;
	$year = substr( $year, 2, 2 );
	$year = $year."01";
	}
else
	{
	$year = $year-3;
	$year = substr( $year, 2, 2 );
	$year = $year."01";
	}

/* 
��˹��ش��������� SQL 㹡�����¡�٢����Ũҡ���ҧ tbl_guestbook 
�����§����ѹ�������ش��� Post ����� 
*/

/*$strSQL = "SELECT company.C_DATETIME_REGISTER,company_name.C_TYPE,company_name.C_NAME,company_name.C_LOCATION,company.C_APPLY_MODE,company.C_WAGE,company.C_POS_AVA,company_name.C_ID FROM company_name LEFT JOIN company ON company_name.C_ID=company.C_ID ";
$strSQL .= "WHERE company.C_DATETIME_REGISTER>'$yearBefore2' AND company.C_DATETIME_REGISTER<'$yearBefore1' "; 
$strSQL .= "ORDER BY ".$OrderBy." DESC";
$strSQL .= "WHERE company_name.C_NAME LIKE '".$year."%' ";*/

$strSQL = "SELECT S_ID,S_PREFACE,S_NAME,S_DATETIME_REGISTER FROM student ";
$strSQL .= "WHERE S_DATETIME_REGISTER <> '0000-00-00 00:00:00' AND S_ID LIKE '".$year."%' ";
$strSQL .= "ORDER BY S_ID ASC";

/*
�ӡ���������������� SQL ��������Ѻ����� $strSQL �ӧҹ
��Ҽ��Ѿ�����������Ѻ����� $result
*/
$result = mysql_query( $strSQL, $conn )
	or die ( "�������ö����������ŧ�����ҧ��" . mysql_error() );

while(  $rs = mysql_fetch_array( $result ) )
	{
		$S_DATETIME_REGISTER = ShortThaiDate($rs[S_DATETIME_REGISTER]);
		//$rs[S_DATETIME_REGISTER] = substr($rs[S_DATETIME_REGISTER],10);
		
		echo "<table class=\"Ltable\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\" width=\"760\" style=\"table-layout:fixed;\">\n";
		echo "	<tr>\n";
		echo "		<td class=\"black8\" width=\"80\">&nbsp;$rs[S_ID]</td>\n";
		echo "		<td class=\"black8\" width=\"150\">&nbsp;$rs[S_PREFACE]$rs[S_NAME]</td>\n";
		echo "		<td class=\"black8\" width=\"125\">&nbsp;$S_DATETIME_REGISTER ".ThaiTimer($rs[S_DATETIME_REGISTER])."</td>\n";
		echo "	</tr>\n";
		echo "</table>\n";
	}

/* �Դ Connection */
CloseDB();
?>

			</td>
		</tr>
	</table>
	<table align="center" width="100%" border="0" bordercolor="#FFFFFF" cellpadding="3" cellspacing="0">
  					<tr>
  						<td align="right" class="subtitle">&nbsp;<!----
						<button class="formbutton" disabled style=width:100px onClick="OpenSortWindow('EXP%7CDESC')">Order By...</button>&nbsp;&nbsp;
						<button class="formbutton" disabled style=width:100px onClick="OpenSelectWindow('LOCATION%2CEDUCATIONLEVEL%2CEXP%2CSALARY')">Select Column...</button>------>
						</td>
  					</tr>
				</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<tr bgcolor="eeeeee"> 
			<td class="content">&nbsp;
			</td>
		</tr>
	</table>
	</td>
  </tr>
</table>

</body>
</html>