<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<!-- ZoneLabs Privacy Insertion -->
<script language='javascript' src='http://localhost:1027/js.cgi?pea&r=19954'>
</script>

<title>�к���Ǩ�ͺ���ʹѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body  background="../images/bgtop.gif" leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>

<table class="title" border="0" cellspacing="0" cellpadding="3" width="760" style="table-layout:fixed;" align="center">
	<tr>
		<td align="center"  valign="top" width="100%" class="title"><center>&nbsp;��Ǩ�ͺ���ʹѡ�֡��<center></td>
	</tr>
</table>
<br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<form method="post" action="CheckID.php">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;���ʻ�Шӵ�ǹѡ�֡��&nbsp;&nbsp;<input name="S_ID" type="text" id="S_ID" size="8" maxlength="8"></td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="red" size="4" >&nbsp;��سҡ�͡�����ŵ�������繨�ԧ<br>���ͷ���к��зӧҹ�����ҧ�١��ͧ<br></font><br>
						<input name="Submit" type="submit" value="����Ѻ" class="formbutton" style=width:100px>
						<input name="Reset" type="reset" value="Reset" class="formbutton" style=width:100px>
						</form></td>
					</tr>
				</table>
				
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>

</body>
</html>