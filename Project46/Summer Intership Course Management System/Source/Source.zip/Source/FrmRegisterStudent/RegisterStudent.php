<?php
include("../phpConfig.php");
include("../phpFunctionDB.php");
include("../phpFunction.php");

Conn2DB();
$Flag = true;

$S_PREFACE;
$S_NAME = htmlspecialchars( trim( $S_NAME ));
$S_ID = htmlspecialchars( trim( $S_ID));
$S_ROOM;

/* ��Ǩ�ͺ��û�͹���ʹѡ�֡�� */
if ( $S_ID == "" )
	{
		$msg .= "<li class=\"black16\">��سһ�͹���ʹѡ�֡��";
		$button_home = "<input type=\"button\" value=\"˹���á\" onclick=\"window.location='../index.html';\" class=\"formbutton\" style=\"width:100px\">";
		$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
		$Flag = false;
	}
else
	{
		$today = getdate();
		$year = $today[year]+543;

		//�һչ���
		if($today[mon] > 8)
		{
			$year = $year-2;
			$year = substr( $year, 2, 2 );
			$year = $year."01";
		}
		else
		{
			$year = $year-3;
			$year = substr( $year, 2, 2 );
			$year = $year."01";
		}

		if(substr( $S_ID, 0, 4 ) != $year)
		{
			$msg .= "<li class=\"black16\">��سһ�͹���ʹѡ�֡�����١��ͧ";
			$button_home = "<input type=\"button\" value=\"˹���á\" onclick=\"window.location='../index.html';\" class=\"formbutton\" style=\"width:100px\">";
			$button = "<input type=\"button\" value=\"��Ѻ����\" onclick=\"history.back();\" class=\"formbutton\" style=\"width:100px\">";
			$Flag = false;
		}
	}

//�׹�ѹ��èѴ�红�����
if ( $Flag )
	{
		$S_PASSWORD = GenTxts(6);
		Update2StudentRegisterPassword( $S_ID, $S_PASSWORD );
		
		$msg .= "<li class=\"black16\">�ѡ�֡�� <b>$S_NAME</b>";
		$msg .= "<li class=\"black16\">�к��Ѵ�红����Źѡ�֡�����º��������";
		$button_home = "<input type=\"button\" value=\"˹���á\" onclick=\"window.location='../index.html';\" class=\"formbutton\" style=\"width:100px\">";
		$button = "<input notab type=\"reset\" value=\"�Դ˹�ҵ�ҧ\" onclick=\"javascript:parent.close();\" class=\"formbutton\" style=\"width:100px\">";

		$mailto = substr($S_ID,1);
		$mailto = "s".$mailto."@kmitl.ac.th";
		$subject = "Username ��� Password ����Ѻ�Ԫҽ֡�ҹ�ҤĴ���͹";
		$message = "Username : $S_ID\n Password : $S_PASSWORD\n";
		$email = "root@isag35.ce.kmitl.ac.th";
		$f_email = $email;
		if($email) $email = "[".$email."]";
		$msg_mail = "From : $f_email \n Subject : $subject \n\n $message";

		if(mail($mailto , $subject , $msg_mail , "From : ". $f_email)) {
			$result_sendmail .= "<table cellpadding=2><tr><td bgcolor=#ff69b4>";
			$result_sendmail .= "<table cellpadding=20><tr><td bgcolor=#f0ffff>";
			$result_sendmail .= "<center>";
			$result_sendmail .= "<font size=2 face='MS Sans Serif'>";
			$result_sendmail .= "<font size=3 color=red><b>�к���ӡ���� Username ��� Password 价��������ͧʶҺѹ</b></font><br>";
			$result_sendmail .= "���º�������Ǥ�Ѻ<br>";
			$result_sendmail .= "</center>";
			$result_sendmail .= "</td></tr></table>";
			$result_sendmail .= "</td></tr></table>";
			}
		else {
			$result_sendmail .= "<table cellpadding=2><tr><td bgcolor=#ff69b4>";
			$result_sendmail .= "<table cellpadding=20><tr><td bgcolor=#f0ffff>";
			$result_sendmail .= "<center>";
			$result_sendmail .= "<font size=2 face='MS Sans Serif'>";
			$result_sendmail .= "<font size=3 color=red><b>�к��������ö������</b></font><br>";
			$result_sendmail .= "��㹢�й���Ѻ<br>";
			$result_sendmail .= "</center>";
			$result_sendmail .= "</td></tr></table>";
			$result_sendmail .= "</td></tr></table>";
		}
}

CloseDB();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��䢢����Źѡ�֡��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<link href="../StyleJobDB.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin=0 topmargin=0 marginheight=0 marginwidth=0 scroll=auto bgcolor=white>

<br><br>
<br><br>
<table width="400" border="0" cellspacing="0" cellpadding="1" align=center >
	<tr>
		<td class="subtitle">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td align="center" valign="top" bgcolor="#FFFFFF">
				<table border="0" class="Atable" cellspacing="0" cellpadding="3"  style='table-layout:fixed;' width="100%">
					<tr height="30" bgcolor="#c7c5c5" class="content">
						<td width="100%" align="center" >&nbsp;��ͤ����駨ҡ�к�&nbsp;</td>
					</tr>				
				</table>
				<table class="Ltable" border="0" cellspacing="0" cellpadding="3" width="100%" style="table-layout:fixed;">
					<tr>
						<td class="black8" width="100%" align="center" ><br><font color="red" size="2" ><?php echo $msg; echo "<br><br>"; echo $button_home."   "; echo $button; echo "<br><br>"; echo $result_sendmail;?></font><br><br>
						</td>
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</body>
</html>