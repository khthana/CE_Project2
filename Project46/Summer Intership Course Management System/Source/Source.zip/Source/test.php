<?php
	phpinfo();
	#include("/phpCounter/phpCounter.php");
?>