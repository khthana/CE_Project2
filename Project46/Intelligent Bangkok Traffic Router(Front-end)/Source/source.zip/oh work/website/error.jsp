<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-size: 24px;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
}
.style13 {font-size: 18px}
.style18 {font-size: 16}
.style20 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 16px;
	color: #FFFFFF;
}
.style31 {
	font-size: 14px;
	font-weight: bold;
}
.style32 {color: #FFFFFF; font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;}
.style34 {
	color: #000066;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 18px;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style37 {font-size: 18px; font-weight: bold; }
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style40 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	color: #FFFFFF;
	font-size: 18px;
}
.style42 {
	font-size: 36px;
	color: #FF0000;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<div align="center">
	<jsp:include page="header.jsp"/>
<!-- 
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log in</strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
</div>
<table width="800" border="0" align="center">
  <tr>
    <td background="pic/bangkok_map2.gif"><div align="center" class="style42">
      <p>&nbsp;</p>
      <p><strong>������</strong><strong>�Դ�˵آѴ��ͧ</strong></p>
      <p><strong>Internal Server Error </strong></p>
    </div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
