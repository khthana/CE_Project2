<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {font-size: 18px}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="center">
        <form name="form1" method="post" action="">
          <p>&nbsp;</p>
          <table width="90%"  border="0">
            <tr>
              <td bgcolor="#000066"><div align="center" class="style42"><strong>��§ҹ��Ҿ��è�Ҩ�</strong></div></td>
            </tr>
          </table>
          <table width="90%"  border="0">
            <tr>
              <td><div align="center">
                <select name="select" size="1">
                  <option value="district" selected>District</option>
                  <option value="street">Street</option>
                </select>
<%
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();
	String sql1 = "select * from member where usr='"+session.getAttribute("auth")+"' ";
	ResultSet rs1 = stmt.executeQuery(sql1);

	while (rs1.next())
		out.println("<input name='word' type='text' id='word' size='50' maxlength='150' value='"+rs1.getString("district")+"'>");
	
	rs1.close();
	/*stmt.close();
	mycon.close();*/
%>
                <!-- <input name="word" type="text" id="word" size="50" maxlength="150"> -->
                <input name="search" type="submit" id="search" value="Search">
              </div></td>
            </tr>
          </table>
          <table width="80%"  border="0">
          <tr>
            <td>&nbsp;</td>
          </tr>
<%
	String select="";
	String search = request.getParameter("search");
	String ok = request.getParameter("ok");
	String temp="";
	boolean error = false;
	boolean found = false;
	
	/*Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();*/
	
	if (search != null)
	{
		String word = new String(request.getParameter("word").getBytes("ISO8859_1"),"TIS-620");
		select = request.getParameter("select");
		
		word = word.trim();
		
		if (word.equals(""))
		{
			error = true;
			out.println("<tr><td div align='center'><center><font color=red><b>��س�������ǳ����ҹ�зӡ�ä���</b></font></center></td></tr>");
		}
		
		if (error == false)
		{
			String sql = "select * from report";
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				if (select.equals("district"))
					temp = rs.getString("district");
				else
					temp = rs.getString("street");
					
				if (temp.indexOf(word) != -1)
				{
					out.println("<tr>");
					out.println("<td div align='center'><input type='checkbox' name='checkbox' value='"+rs.getString("street")+"' checked><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>"+rs.getString("street")+" - "+rs.getString("district")+"</b></font></td> ");
					out.println("</tr>");
					found = true;
				}
			}
			
			if (found == false)
				out.println("<tr><td div align='center'><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>�������§ҹ��Ҿ��è�Ҩ�㹺���ǳ����ҹ���͡</b></center></font></td></tr>");
			
			rs.close();
		}			
	}
	
	out.println("</table>");
	if (found == true)
	{
		out.println("<table width='90%'  border='0'>");
		out.println("<tr>");
		out.println("<td><div align='center'>");
		out.println("<input name='ok' type='submit' id='ok' value='OK'>");
		out.println("</div></td>");
		out.println("</tr>");
		out.println("</table>");
	}
	
	if (ok != null)
	{
		String [ ] checkbox = request.getParameterValues("checkbox");
		
		if (checkbox.length == 0)
		{
			error = true;
			out.println("<table width='90%'  border='0'><tr><td div align='center'><center><font color=red><b>��س����͡��鹷ҧ����ҹ�зӡ�ä�����§ҹ��Ҿ��è�Ҩ�</b></font></center></td></tr></table>");
		}
		
		if (error == false)
		{
			out.println("<table width='90%'  border='0'>");
			out.println("<tr bgcolor='000066'>");
			out.println("<td div align='center'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>��� - ࢵ</b></center></font></td>");
			out.println("<td div align='center'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>��������´</b></center></font></td>");
			out.println("</tr>");
			
			for (int i=0; i<checkbox.length;i++)
			{
				String sql = "select * from report where street='"+checkbox[i]+"' ";
				ResultSet rs = stmt.executeQuery(sql);
				
				while (rs.next())
				{
					out.println("<tr bgcolor='009966'>");
					out.println("<td div align='center'><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+rs.getString("street")+" - "+rs.getString("district")+"</b></center></font></td>");
					out.println("<td div align='center'><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+rs.getString("comment")+"</b></center></font></td>");
					out.println("</tr>");
				}
				
				rs.close();
				
			}
			out.println("</table>");
		}
	}
	
	stmt.close();
	mycon.close();
%>
        </form>
	  </div></td>
    </tr>
  </table>
</div>
</body>
</html>
