  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066"><a href="home.jsp"><font color="#FFFFFF" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Home&gt;&gt; Intelligent Bangkok Traffic Router</font></a></td>
      <td width="231" bgcolor="#000066"><div align="center"><strong><font size="+1" color="#FFFFFF" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">
		  <%=new java.util.Date()%>
      </font></strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center"><strong><font size="+1" color="#000066" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">PowerBy : KMITL CE</font></strong></div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066"><div align="center"><a href="register.jsp"><strong><font size="+1" color="#FFFFFF" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Register</font></strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066"><div align="center"><a href="logout.jsp"><strong><font size="+1" color="#FFFFFF" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Log out</font></strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066"><div align="center"><a href="member_map.jsp"><strong><font size="+1" color="#FFFFFF" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Map</font></strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066"><div align="center"><a href="member_routing.jsp"><strong><font size="+1" color="#FFFFFF"  face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Routing</font></strong></a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066"><div align="center"><a href="member_report.jsp"><strong><font size="+1" color="#FFFFFF" pointsize="16" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Traffic Report</font></strong></a></div></td>
      <td width="110" bgcolor="#000066"><div align="center"><div align="center"><a href="member_radio.jsp"><strong><font size="+1" color="#FFFFFF" pointsize="16" face="Angsana New, LilyUPC, AngsanaUPC, Tahoma">Live Radio Report</font></strong></a></div>
      </div></td>
    </tr>
  </table>
