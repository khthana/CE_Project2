<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style1 {
	font-size: 18px;
	font-weight: bold;
	color: #000066;
}
.style2 {color: #FFFFFF}
.style3 {
	font-size: 18px;
	color: #000066;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif">
        <div align="center">
          <p>&nbsp;          </p>
          <p>
<form name="form1" method="post" action="edit_cont.jsp">
        <table width="90%"  border="0">
          <tr>
            <td bgcolor="#000066"><div align="center" class="style1 style2">Change Start and Destination </div></td>
          </tr>
        </table>
        <table width="90%"  border="0">
          <tr>
            <td width="50%"><div align="center" class="style44 style1">Start</div></td>
            <td width="50%"><div align="center" class="style44 style3"><strong>Destination</strong></div></td>
          </tr>
          <tr>
            <td><div align="center">
              <input name="start" type="text" id="start" size="30" maxlength="50">
            </div></td>
            <td><div align="center">
              <input name="dest" type="text" id="dest" size="30" maxlength="50">
            </div></td>
          </tr>
        </table>
        <table width="90%"  border="0">
          <tr>
            <td><div align="center">
              <input name="search" type="submit" id="search" value="Search">
			  <br>
			  <br>
<%
	String search = request.getParameter("search");
	String start = "",dest = "";
	String sql = "";
	boolean error = false;
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();

	if (search != null)
	{
		start = request.getParameter("start");
		dest = request.getParameter("dest");
		
		if (start.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Start</font></b></center><br>");
		}
		if (dest.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Destination</font></b></center><br>");
		}
		
		if (error == false)
		{
			out.println("<table width='90%'  border='0'>");
			out.println("<tr>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Start</b></center></font></td>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Destination</b></center></font></td>");
			out.println("</tr>");
		
			out.println("<tr>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+start+"%' ";
			ResultSet rs1 = stmt.executeQuery(sql);
			while (rs1.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_start' value='"+rs1.getString("word")+"' checked>"+rs1.getString("word")+"</label></b></center></font><br>");
			}
			rs1.close();
			out.println("</td>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+dest+"%' ";
			ResultSet rs2 = stmt.executeQuery(sql);
			while (rs2.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_dest' value='"+rs2.getString("word")+"' checked>"+rs2.getString("word")+"</label></b></center></font><br>");
			}
			rs2.close();
			out.println("</td>");
			
			out.println("</tr>");
			
			
			out.println("</table>");
			
			out.println("<select name='select' size='1'>");
			out.println("<option value='1' selected>Change Start1/Destination1</option>");
			out.println("<option value='2'>Change Start2/Destination2</option>");
			out.println("</select>");
			out.println("<center><input name='submit' type='submit' value='Submit'></center>");
		}
	}
	
	String submit = request.getParameter("submit");
	if (submit != null  && error == false)
	{
		start = request.getParameter("radio_start");
		dest = request.getParameter("radio_dest");
		String select = request.getParameter("select");
		
		if (start.equals(dest))
		{
			out.println("<center><b><font color=red>�ش Start ��Шش Destination �繷�����ǡѹ</font></b></center><br>");
		}
		else
		{
			if (select.equals("1"))
				sql = "update member set start1 = '"+start+"',dest1 = '"+dest+"' where usr = '"+session.getAttribute("auth")+"' ";
			else
				sql = "update member set start2 = '"+start+"',dest2 = '"+dest+"' where usr = '"+session.getAttribute("auth")+"' ";
				
			int myresult = stmt.executeUpdate(sql);
			if (myresult != 0)
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>��䢢��������º��������</b></center></font>");
			}
			else
			{
				out.println("<center><b><font color=red>�������ö��䢢�������</font></b></center>");
			}
		}
	}
	
	stmt.close();
	mycon.close();
%>
            </div></td>
          </tr>
        </table>
        </form>
		          </p>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>
