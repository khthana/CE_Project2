<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-size: 24px;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
}
.style13 {font-size: 18px}
.style18 {font-size: 16}
.style20 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 16px;
	color: #FFFFFF;
}
.style31 {
	font-size: 14px;
	font-weight: bold;
}
.style32 {color: #FFFFFF; font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;}
.style34 {
	color: #000066;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 18px;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style37 {font-size: 18px; font-weight: bold; }
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style40 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	color: #FFFFFF;
	font-size: 18px;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
.style43 {	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="left">
        <p>
            <%
%>
        </p>
        <p>&nbsp; </p>
        <table width="80%"  border="0" align="center">
          <tr>
            <th bgcolor="#000066" scope="col"><span class="style43">Live Radio Report </span></th>
          </tr>
          <tr>
            <td><div align="center"> <img src="pic/animJs100.gif" width="337" height="224" border="2"> <br>
                    <Embed	SRC="mms://live.virginradiothailand.com/105.5"
			Width="337"
			Height="70"
			AutoStart="false"
			TYPE="application/x-mplayer2"
			pluginspage="http://www.microsoft.com/Windows/MediaPlayer/"
			Name="objMediaPlayer"
			autoSize="false"
			showdisplay="false"
			displaySize="0"
			center="true"
			ShowControls="true"
			ShowStatusBar="true"
			AnimationAtStart="false" border="2"></embed>
            </div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>
        <p>&nbsp;	      </p>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>
