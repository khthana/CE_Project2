<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {
	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style14 {
	font-size: 18px;
	color: #000066;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<jsp:useBean id="routebean" class="mybean.routing" />
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="center">
	  <form name="form1" method="post" action="member_routing.jsp">
        <table width="90%"  border="0">
          <tr>
            <td bgcolor="#000066"><div align="center" class="style43 style13">Routing</div></td>
          </tr>
        </table>
        <table width="90%"  border="0">
          <tr>
            <td width="50%"><div align="center" class="style44 style14"><strong>Start</strong></div></td>
            <td width="50%"><div align="center" class="style44 style14"><strong>Destination</strong></div></td>
          </tr>
          <tr>
            <td><div align="center">
              <input name="start" type="text" id="start" size="30" maxlength="50">
            </div></td>
            <td><div align="center">
              <input name="dest" type="text" id="dest" size="30" maxlength="50">
            </div></td>
          </tr>
        </table>
        <table width="90%"  border="0">
          <tr>
            <td><div align="center">
              <input name="search" type="submit" id="search" value="Search">
			  <br>
			  <br>
<%
	String search = request.getParameter("search");
	String [ ] parameter = request.getParameterValues("parameter");
	String start = "",dest = "",temp1="",temp2="",temp3="",temp4="",temp5="",temp6="",temp7="",select="1",firstnode="",image="";;
	String sql = "";
	boolean error = false;
	double temp = 0;
	int firstchar = 0;
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();

	if (search != null)
	{
		start = request.getParameter("start");
		dest = request.getParameter("dest");
		
		if (start.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Start</font></b></center><br>");
		}
		if (dest.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Destination</font></b></center><br>");
		}
		
		if (error == false)
		{
			out.println("<table width='90%'  border='0'>");
			out.println("<tr>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Start</b></center></font></td>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Destination</b></center></font></td>");
			out.println("</tr>");
		
			out.println("<tr>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+start+"%' ";
			ResultSet rs1 = stmt.executeQuery(sql);
			while (rs1.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_start' value='"+rs1.getString("word")+"' checked>"+rs1.getString("word")+"</label></b></center></font><br>");
			}
			rs1.close();
			out.println("</td>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+dest+"%' ";
			ResultSet rs2 = stmt.executeQuery(sql);
			while (rs2.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_dest' value='"+rs2.getString("word")+"' checked>"+rs2.getString("word")+"</label></b></center></font><br>");
			}
			rs2.close();
			out.println("</td>");
			
			out.println("</tr>");
			
			out.println("</table>");
			
			//out.println("<center><input name='submit' type='submit' value='Submit'></center>");
		}
	}
	
	sql = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
	ResultSet rs3 = stmt.executeQuery(sql);
	while (rs3.next())
	{
		if (!(rs3.getString("start1").equals("null")))
		{
			out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='group' value='group1'>"+rs3.getString("start1")+" --TO-- "+rs3.getString("dest1")+"</label></b></center></font><br>");
		}
		if (!(rs3.getString("start2").equals("null")))
		{
			out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='group' value='group2'>"+rs3.getString("start2")+" --TO-- "+rs3.getString("dest2")+"</label></b></center></font><br>");
		}
	}
	rs3.close();
	
	out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Please select parameter</b></center></font><br>");
	out.println("<table width='80%'>");
	out.println("<tr>");
	out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='distance' checked>Distance</b></center></font></td>");
	out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='cost' checked>Cost</b></center></font></td>");
	out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='Time' checked>Time</b></center></font></td>");
	out.println("</tr>");
	out.println("</table>");
	out.println("<center><input name='submit' type='submit' value='Submit'></center>");
	String submit = request.getParameter("submit");
	if (submit != null  && error == false)
	{
		start = request.getParameter("radio_start");
		dest = request.getParameter("radio_dest");
		String group = request.getParameter("group");
		
		if (group != null)
		{
			if (group.equals("group1"))
			{
				sql = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
				ResultSet rs4 = stmt.executeQuery(sql);
				while (rs4.next())
				{
					start = rs4.getString("start1");
					dest = rs4.getString("dest1");
				}
				rs4.close();
			}
			if (group.equals("group2"))
			{
				sql = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
				ResultSet rs5 = stmt.executeQuery(sql);
				while (rs5.next())
				{
					start = rs5.getString("start2");
					dest = rs5.getString("dest2");
				}
				rs5.close();
			}
		}
		
		if (start.equals(dest))
		{
			out.println("<center><b><font color=red>�ش Start ��Шش Destination �繷�����ǡѹ</font></b></center><br>");
		}
		else
		{
			out.println("<table width='90%'  border='0'>");
			out.println("<tr>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Start</b></center></font></td>");
			out.println("<td width='50%' bgcolor='000066'><font size='+1'color='FFFFFF' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Destination</b></center></font></td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+start+"</b></center></font><br></td>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+dest+"</b></center></font><br></td>");
			out.println("</tr>");
			out.println("</table>");
			out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Your parameter is ");
			for (int i=0;i<parameter.length;i++)
			{
				out.println(","+parameter[i]);
			}
			out.println("</b></center></font>");
			
			out.println("<table width='80%' border='0'>");
			out.println("<tr>");
			out.println("<td bgcolor='000066'><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Path</b></center></font></td>");
			out.println("</tr>");
			
			ResultSet rs6 = stmt.executeQuery("select * from matching where word = '"+start+"' ");
			while (rs6.next())
			{
				temp1 = rs6.getString("inter1");
				temp2 = rs6.getString("inter2");
			}
			rs6.close();
			
			ResultSet rs7 = stmt.executeQuery("select * from matching where word = '"+dest+"' ");
			while (rs7.next())
			{
				temp3 = rs7.getString("inter1");
				temp4 = rs7.getString("inter2");
			}
			rs7.close();
			
			if (parameter[0].equals("COST"))
			{
				temp5 = "y";
				temp6 = "n";
				temp7 = "n";
			}
			else if (parameter[0].equals("TIME"))
			{
				temp5 = "n";
				temp6 = "y";
				temp7 = "n";
			}
			else if (parameter[0].equals("DISTANCE"))
			{
				temp5 = "n";
				temp6 = "n";
				temp7 = "y";
			}
			else
			{
				temp5 = "n";
				temp6 = "n";
				temp7 = "n";
			}
			
			
			if ((temp2 == null) && (temp4 == null))
			{
				routebean.setParam(temp1,temp3,temp5,temp6,temp7);
			}
			else if (temp2 == null)
			{
				routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				if (temp5.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
				}
				else if (temp6.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
				}
				else if (temp7.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
				}
				
				routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				if ((temp5.equals("y")) && ((Double.valueOf(routebean.getDisplayMoney())).doubleValue() < temp))
				{
					routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				}
				else if ((temp6.equals("y")) && ((Double.valueOf(routebean.getDisplayTime())).doubleValue() < temp))
				{
					routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				}
				else if ((temp7.equals("y")) && ((Double.valueOf(routebean.getDisplayDistance())).doubleValue() < temp))
				{
					routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				}
				else
				{
					routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				}
			}
			else if (temp4 == null)
			{
				routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				if (temp5.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
				}
				else if (temp6.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
				}
				else if (temp7.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
				}
				
				routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				if ((temp5.equals("y")) && ((Double.valueOf(routebean.getDisplayMoney())).doubleValue() < temp))
				{
					routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				}
				else if ((temp6.equals("y")) && ((Double.valueOf(routebean.getDisplayTime())).doubleValue() < temp))
				{
					routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				}
				else if ((temp7.equals("y")) && ((Double.valueOf(routebean.getDisplayDistance())).doubleValue() < temp))
				{
					routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				}
				else
				{
					routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				}
			}
			else
			{
				routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				if (temp5.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
				}
				else if (temp6.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
				}
				else if (temp7.equals("y"))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
				}
				
				routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				if ((temp5.equals("y")) && ((Double.valueOf(routebean.getDisplayMoney())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
					select = "2";
				}
				else if ((temp6.equals("y")) && ((Double.valueOf(routebean.getDisplayTime())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
					select = "2";
				}
				else if ((temp7.equals("y")) && ((Double.valueOf(routebean.getDisplayDistance())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
					select = "2";
				}
				
				routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				if ((temp5.equals("y")) && ((Double.valueOf(routebean.getDisplayMoney())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
					select = "3";
				}
				else if ((temp6.equals("y")) && ((Double.valueOf(routebean.getDisplayTime())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
					select = "3";
				}
				else if ((temp7.equals("y")) && ((Double.valueOf(routebean.getDisplayDistance())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
					select = "3";
				}
				
				
				routebean.setParam(temp2,temp4,temp5,temp6,temp7);
				if ((temp5.equals("y")) && ((Double.valueOf(routebean.getDisplayMoney())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayMoney())).doubleValue();
					select = "4";
				}
				else if ((temp6.equals("y")) && ((Double.valueOf(routebean.getDisplayTime())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayTime())).doubleValue();
					select = "4";
				}
				else if ((temp7.equals("y")) && ((Double.valueOf(routebean.getDisplayDistance())).doubleValue() < temp))
				{
					temp = (Double.valueOf(routebean.getDisplayDistance())).doubleValue();
					select = "4";
				}
				
				if (select.equals("1"))
				{
					routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				}
				else if (select.equals("2"))
				{
					routebean.setParam(temp1,temp4,temp5,temp6,temp7);
				}
				else if (select.equals("3"))
				{
					routebean.setParam(temp2,temp3,temp5,temp6,temp7);
				}
				else if (select.equals("4"))
				{
					routebean.setParam(temp2,temp4,temp5,temp6,temp7);
				}
				else
				{
					routebean.setParam(temp1,temp3,temp5,temp6,temp7);
				}
			}
						
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+routebean.getDisplayRoute()+"</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Usage time about "+routebean.getDisplayTime()+" minutes</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Overall money = "+routebean.getDisplayMoney()+" Baht</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Overall money = "+routebean.getDisplayDistance()+" Baht</b></center></br></td>");
			out.println("</tr>");
			
			out.println("</table>");
			
			firstnode = routebean.getDisplayRoute();
			firstchar = firstnode.indexOf(">");
			firstnode = firstnode.substring(0,firstchar);
			
			ResultSet rs8 = stmt.executeQuery("select image from mapinfo where node = '"+firstnode+"' ");
			while (rs8.next())
			{
				image = rs8.getString("image");
			}
			rs8.close();
			
			out.println("<applet code = 'Map1.class' width='600' height='600'>");
			out.println("<param name=map_image value="+image+">");
			out.println("</applet>");
		}
	}
	
	stmt.close();
	mycon.close();
%>
            </div></td>
          </tr>
        </table>
        </form>
	  </div></td>
    </tr>
  </table>
</div>
</body>
</html>
