<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-size: 24px;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
}
.style13 {font-size: 18px}
.style18 {font-size: 16}
.style20 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 16px;
	color: #FFFFFF;
}
.style31 {
	font-size: 14px;
	font-weight: bold;
}
.style32 {color: #FFFFFF; font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;}
.style34 {
	color: #000066;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 18px;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style37 {font-size: 18px; font-weight: bold; }
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style40 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	color: #FFFFFF;
	font-size: 18px;
}
.style41 {color: #FFFFFF}
.style43 {
	font-size: 18px;
	color: #000066;
	font-weight: bold;
}
.style44 {color: #000066}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<div align="center">
	<jsp:include page="header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log in</strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0">
    <tr>
      <td background="pic/bangkok_map2.gif">
        <p>&nbsp;        </p>
        <form name="form1" method="post" action="login.jsp">
          <table width="80%"  border="0" align="center">
            <tr>
              <td bgcolor="#000066"><div align="center" class="style13 style41"><strong>��س� Log in �����������к� </strong></div></td>
            </tr>
          </table>
          <table width="80%"  border="0" align="center">
            <tr>
              <td width="32%"><div align="center" class="style13 style44"><strong>Log in</strong></div></td>
              <td width="68%"><input name="usr" type="text" id="usr" size="50" maxlength="20"></td>
            </tr>
            <tr>
              <td><div align="center" class="style43">Password</div></td>
              <td><input name="pass" type="password" id="pass" size="50" maxlength="20"></td>
            </tr>
          </table>
          <table width="80%"  border="0" align="center">
            <tr>
              <td><div align="center">
                <p>
                  	<input name="login" type="submit" id="login" value="Login">
                    <input name="reset" type="reset" id="reset" value="Reset">
                  </p>
                </div></td>
            </tr>
          </table>
        </form>        <p>
<%
	String login = request.getParameter("login");
	String usr = "",pass = "";
	boolean error = false;
	
	if (login != null)
	{
		usr = request.getParameter("usr");
		pass = request.getParameter("pass");
		
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
		Statement stmt = mycon.createStatement();
		String sql = "select count(*) as num from member where usr = '"+usr+"' and pass = '"+pass+"' ";
		ResultSet rs = stmt.executeQuery(sql);
		
		while (rs.next())
		{
			if (rs.getInt("num") == 1)
			{
				session.setAttribute("auth",usr);
				response.sendRedirect("member_section.jsp");
			}
			else
			{
				error = true;
				out.println("<center><font color=red><b>Login ���� Password ���١��ͧ</b></font></center>");
			}
		}
		
		rs.close();
		stmt.close();
		mycon.close();
	}
%>	  
      </p>        </td>
    </tr>
  </table>
</div>
</body>
</html>
