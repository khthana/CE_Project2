<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-size: 24px;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
}
.style13 {font-size: 18px}
.style18 {font-size: 16}
.style20 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 16px;
	color: #FFFFFF;
}
.style31 {
	font-size: 14px;
	font-weight: bold;
}
.style32 {color: #FFFFFF; font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;}
.style34 {
	color: #000066;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 18px;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style37 {font-size: 18px; font-weight: bold; }
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style40 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	color: #FFFFFF;
	font-size: 18px;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="101" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="109" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center" class="style13"><a href="member_radio.jsp" class="style41"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="center">
          <br>
		  <br>
<%
	String submit = request.getParameter("submit");
	String pass1 = "",pass2 = "",name = "",email = "";
	String district = "",address = "",mobile = "",provider = "",mo_usr = "",mo_pass = "",start1 = "",dest1 = "",start2 = "",dest2 = "";
	boolean error = false;
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();
	String sql1 = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
	ResultSet rs = stmt.executeQuery(sql1);
	
	while (rs.next() && submit == null)
	{
		out.println("<form method='post' action='edit.jsp'>");
		out.println("<table width='80%'  border='0' align='center'>");
		out.println("<tr>");
		out.println("<td bgcolor='#000066'><div align='center' class='style37 style50 style41'>��䢢�������Ҫԡ</div></td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("<table width='80%'  border='0' align='center'>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Login</b></center></font></td>");
		out.println("<td><font size='+3'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>" + session.getAttribute("auth") + "</b></center></font></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td width='32%'><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Password</b></center></font></td>");
		out.println("<td width='68%'><input name='pass1' type='password' size='40' maxlength='20' value='"+rs.getString("pass")+"'><font color='000066' size='+1' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>* Eng</b></font></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Re-type password</b></center></font></td>");
		out.println("<td><input name='pass2' type='password' size='40' maxlength='20' value='"+rs.getString("pass")+"'><font color='000066' size='+1' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>* Eng</b></font></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Name</b></center></font></td>");
		out.println("<td><input name='name' type='text' size='40' maxlength='50' value='"+rs.getString("name")+"'><font color='000066' size='+1' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>* Eng</b></font></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Email</b></center></font></td>");
		out.println("<td><input name='email' type='text' size='40' maxlength='50' value='"+rs.getString("email")+"'><font color='000066' size='+1' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>*</b></font></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>District</b></center></font></td>");
		out.println("<td><select name='district' size='1' id='district'>");
        out.println("<option selected>"+rs.getString("district")+"</option>");
		out.println("<option value='District'>District</option>");
        out.println("<option value='Bang_Bon'>Bang_Bon</option>");
        out.println("<option value='Bang_Kapi'>Bang_Kapi</option>");
        out.println("<option value='Bang_Khae'>Bang_Khae</option>");
        out.println("<option value='Bang_Khen'>Bang_Khen</option>");
        out.println("<option value='Bang_Kholamm'>Bang_Kholamm</option>");
        out.println("<option value='Bang_Khun_Thian'>Bang_Khun_Thian</option>");
        out.println("<option value='Bang_Na'>Bang_Na</option>");
        out.println("<option value='Bangkok_Noi'>Bangkok_Noi</option>");
        out.println("<option value='Bang_Rak'>Bang_Rak</option>");
        out.println("<option value='Bang_Sue'>Bang_Sue</option>");
        out.println("<option value='Bangkok_Yai�'>Bangkok_Yai</option>");
        out.println("<option value='Bang_Phlat'>Bang_Phlat</option>");
        out.println("<option value='Bueng_Kum'>Bueng_Kum</option>");
        out.println("<option value='Chatuchak'>Chatuchak</option>");
        out.println("<option value='Chom_Thong'>Chom_Thong</option>");
        out.println("<option value='Din_Daeng'>Din_Daeng</option>");
        out.println("<option value='Don_Mueang'>Don_Mueang</option>");
        out.println("<option value='Dusit'>Dusit</option>");
        out.println("<option value='Khan_Na_Yao'>Khan_Na_Yao</option>");
        out.println("<option value='Khlong_Samwa'>Khlong_Samwa</option>");
        out.println("<option value='Khlong_San'>Khlong_San</option>");
        out.println("<option value='Khlong_Toei'>Khlong_Toei</option>");
        out.println("<option value='Khuai_Khwang'>Khuai_ Khwang</option>");
        out.println("<option value='Lak_Si'>Lak_Si</option>");
        out.println("<option value='Lat_Krabang'>Lat_Krabang</option>");
        out.println("<option value='Lat_Phrao'>Lat_Phrao</option>");
        out.println("<option value='Min_Buri'>Min_Buri</option>");
        out.println("<option value='Nong_Chok'>Nong_Chok</option>");
        out.println("<option value='Nong_Khaem'>Nong_Khaem</option>");
        out.println("<option value='Pathumwan'>Pathumwan</option>");
        out.println("<option value='Phasi_Charoen'>Phasi_Charoen</option>");
        out.println("<option value='Phayathai'>Phayathai</option>");
        out.println("<option value='Phra_Khanong'>Phra_Khanong</option>");
        out.println("<option value='Phra_Nakhon'>Phra_Nakhon</option>");
        out.println("<option value='Prawet'>Prawet</option>");
        out.println("<option value='Pom_Prap'>Pom_Prap</option>");
        out.println("<option value='Taling_Chan'>Taling_Chan</option>");
        out.println("<option value='Thawi_Watthana'>Thawi_Watthana</option>");
        out.println("<option value='Thon_Buri'>Thon_Buri</option>");
        out.println("<option value='Thung_Khru'>Thung_Khru</option>");
        out.println("<option value='Rat_Burana'>Rat_Burana</option>");
        out.println("<option value='Ratchathewi'>Ratchathewi</option>");
        out.println("<option value='Sai_Mai'>Sai_Mai</option>");
        out.println("<option value='Samphan_Tha_Wong'>Samphan_Tha_Wong</option>");
        out.println("<option value='Saphan_Sung'>Saphan_Sung</option>");
        out.println("<option value='Sathon'>Sathon</option>");
        out.println("<option value='Suan_Luang'>Suan_Luang</option>");
        out.println("<option value='Wang_Thong Lang'>Wang_Thong_Lang</option>");
        out.println("<option value='Watthina'>Watthina</option>");
        out.println("<option value='Yan_Nawa'>Yan_Nawa</option>");
        out.println("</select></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Address</b></center></font></td>");
		out.println("<td><input name='address' type='text' size='50' maxlength='100' value='"+rs.getString("address")+"'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Mobile Phone#</b></center></font></td>");
		out.println("<td><input name='mobile' type='text' size='50' maxlength='9' value='"+rs.getString("mobile")+"'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Phone's provider</b></center></font></td>");
		out.println("<td>");
		out.println("<label>");
		if (rs.getString("provider").equals("DTAC"))
		{
			out.println("<input type='radio' name='provider' value='DTAC' checked>");
		}
		else
		{
			out.println("<input type='radio' name='provider' value='DTAC'>");
		}
		out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>DTAC</b></font></label>");
		out.println("<label>");
		if (rs.getString("provider").equals("AIS"))
		{
			out.println("<input type='radio' name='provider' value='AIS' checked>");
		}
		else
		{
			out.println("<input type='radio' name='provider' value='AIS'>");
		}
		out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>AIS</b></font></label>");
		out.println("<label>");
		if (rs.getString("provider").equals("Orange"))
		{
			out.println("<input type='radio' name='provider' value='Orange' checked>");
		}
		else
		{
			out.println("<input type='radio' name='provider' value='Orange'>");
		}
		out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>Orange</b></font></label>");
		out.println("<label>");
		if (rs.getString("provider").equals("Hutch"))
		{
			out.println("<input type='radio' name='provider' value='Hutch' checked>");
		}
		else
		{
			out.println("<input type='radio' name='provider' value='Hutch'>");
		}
		out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><b>Hutch</b></font></label>");
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Phone's user</b></center></font></td>");
		out.println("<td><input name='mo_usr' type='text' size='50' maxlength='20' value='"+rs.getString("mo_usr")+"'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Phone's password</b></center></font></td>");
		out.println("<td><input name='mo_pass' type='password' size='50' maxlength='20' value='"+rs.getString("mo_pass")+"'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Start to Destination #1</b></center></font></td>");
		if (rs.getString("start1").equals("null"))
		{
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>...<br>--TO--<br>...</b></center></font></td>");
		}
		else
		{
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+rs.getString("start1")+"<br>--TO--<br>"+rs.getString("dest1")+"</b></center></font></td>");
		}
		out.println("</tr>");
		out.println("<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
		out.println("<tr>");
		out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Start to Destination #2</b></center></font></td>");
		if (rs.getString("start2").equals("null"))
		{
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>...<br>--TO--<br>...</b></center></font></td>");
		}
		else
		{
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+rs.getString("start2")+"<br>--TO--<br>"+rs.getString("dest2")+"</b></center></font></td>");
		}
		out.println("</tr>");
		out.println("</table>");
		out.println("<br>");
		out.println("<table width='80%' border='0' align='center'>");
		//out.println("<tr><td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>������  <a href='edit_cont.jsp'>CHANGE</a> �ҡ��ͧ�����䢨ش Start ��� Destination</b></center></font></td></tr>");
		out.println("<tr>");
		out.println("<td><div align='center'>");
		out.println("<input name='submit' type='submit' value='Submit'>");
		out.println("<input type='reset' name='Reset' value='Reset'>");
		out.println("</div></td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("<p>");
	}
	rs.close();
	
	if (submit != null)
	{
		pass1 = request.getParameter("pass1");
		pass2 = request.getParameter("pass2");
		name = request.getParameter("name");
		email = request.getParameter("email");
		district = request.getParameter("district");
		address = request.getParameter("address");
		mobile = request.getParameter("mobile");
		provider = request.getParameter("provider");
		mo_usr = request.getParameter("mo_usr");
		mo_pass = request.getParameter("mo_pass");
		
		String sql3 = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
		ResultSet rs3 = stmt.executeQuery(sql3);
		while (rs3.next())
		{
			start1 = rs3.getString("start1");
			dest1 = rs3.getString("dest1");
			start2 = rs3.getString("start2");
			dest2 = rs3.getString("dest2");
		}
		rs3.close();
		
		if (pass1.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��س���� PASSWORD</font></b></center>");
		}
		if (name.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��س������ͧ͢��ҹ</font></b></center>");
		}
		if (email.equals("") || email.indexOf('@')==-1 || email.indexOf('.')==-1)
		{
			error = true;
			out.println("<center><b><font color=red>��سҵ�Ǩ�ͺ EMAIL �ͧ��ҹ��١��ͧ</font></b></center>");
		}
		if (!pass1.equals(pass2))
		{
			error = true;
			out.println("<center><b><font color=red>��سҵ�Ǩ�ͺ���ʼ�ҹ�ա�������١��ͧ</font></b></center>");
		}
		
		if (error == false)
		{
			String sql2 = "update member set pass = '"+pass1+"',name = '"+name+"',email = '"+email+"',district = '"+district+"',address = '"+address+"',mobile = '"+mobile+"',provider = '"+provider+"',mo_usr = '"+mo_usr+"',mo_pass = '"+mo_pass+"',start1 = '"+start1+"',dest1 = '"+dest1+"',start2 = '"+start2+"',dest2 = '"+dest2+"' where usr = '"+session.getAttribute("auth")+"' ";
			int myresult = stmt.executeUpdate(sql2);
			if (myresult != 0)
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>��䢢��������º��������</b></center><font>");
				out.println("<form method='post' action='edit_cont.jsp'>");
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>������  <input name='change' type='submit' value='Change'> �ҡ��ͧ�����䢨ش Start ��� Destination</b></center></font>");
				out.println("</form>");
			}
			else
				out.println("<center><b><font color=red>�������ö��䢢�������</font></b></center>");
		}
	}
	
	stmt.close();
	mycon.close();
%>
          </p>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>
