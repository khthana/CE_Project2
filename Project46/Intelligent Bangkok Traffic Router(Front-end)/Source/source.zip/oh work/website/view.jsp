<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*,java.util.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {font-size: 18px}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
.style43 {color: #000066}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="left">
        <p>&nbsp;</p>
        <p>
<%!
	public static String filter_comment(String input)
	{
		StringBuffer temp = new StringBuffer(input.length());
		char c;
		int j=1;
		for (int i=0;i<input.length();i++)
		{
			c = input.charAt(i);
			if (c == '<') temp.append("&lt;");
			else if (c == '>') temp.append("&gt;");
			else if (c == '\'') temp.append("&#039;");
			else if (c == '"') temp.append("&quot;");
			else if (c == '&') temp.append("&amp;");
			else if (c == '\\') temp.append("&#92;");
			else temp.append(c);
			
			if (j == 50)
			{
				temp.append("<br>");
				j = 0;
			}
			if (c == '\n')
				j = 0;
			j++;
		}
		return(temp.toString());
	}
	
	public static String newline(String input)
	{
		StringBuffer temp = new StringBuffer();
		StringTokenizer st = new StringTokenizer(input,"\n");
		while(st.hasMoreTokens())
			temp.append(st.nextToken() + "<br>");
		return(temp.toString());
	}
%>
<%
	if (request.getParameter("id") == null)
		response.sendRedirect("webboard.jsp");
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();
	
	String submit =request.getParameter("submit");
	String name="",email="",comment="",ip="",sql1="";
	boolean error = false;
	int myresult = 0;
	ResultSet result = null;
	
	if (submit != null)
	{
		String sql2 = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
		ResultSet rs = stmt.executeQuery(sql2);
		
		while (rs.next())
		{
			name = rs.getString("usr");
			email = rs.getString("email");
		}
		rs.close();
		comment = filter_comment(request.getParameter("comment"));
		ip = request.getRemoteAddr();
		
		if (comment.equals(""))
		{
			error = true;
			out.println("<center><font color=red><b>��Ǩ�ͺ�����Դ������١��ͧ</b></font></center>");
		}
		
		if (error == false)
		{
			sql1 = "insert into board_ans values('','"+request.getParameter("id")+"','"+name+"','"+email+"','"+comment+"','"+ip+"',NOW())";
			myresult = stmt.executeUpdate(sql1);
			if (myresult != 0)
			{
				sql1 = "update board_quest set ans=ans+1,lastpost=NOW(),lastname='"+name+"' where id='"+request.getParameter("id")+"' ";
				stmt.executeUpdate(sql1);
				response.sendRedirect("view.jsp?id="+request.getParameter("id"));
				return;
			}
			else
				out.println("�������ö����������ŧ㹰ҹ��������");
		}
	}
	
	sql1 = "update board_quest set view=view+1 where id='"+request.getParameter("id")+"' ";
	stmt.executeUpdate(sql1);
	
	sql1 = "select topic,name,email,detail,ip,date_format(datepost,'%e %b %Y, %T') as datepost from board_quest where id='"+request.getParameter("id")+"' ";
	result = stmt.executeQuery(sql1);
	while (result.next())
	{
		out.println("<table width='90%'  border='0' align='center'>");
        out.println("<tr bgcolor='#000066'>");
		out.println("<td width='30%'><div align='center'><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='FFFFFF'><strong>Post by</strong></font></div></td>");
		out.println("<td width='60%'><div align='center'><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='FFFFFF'><strong>Topic : "+result.getString("topic")+"</strong></font></div></td>");
		out.println("</tr>");
		out.println("<tr bgcolor='#009966'>");
		out.println("<td><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='000066'><b>Name : </b>"+result.getString("name")+"<br>");
		out.println("<b>Email : </b>"+result.getString("email")+"<br>");
		out.println("<b>IP : </b>"+result.getString("ip")+"<br>");
		out.println("<b>Time : </b>"+result.getString("datepost"));
		out.println("</font></td>");
		out.println("<td><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='000066'>"+newline(result.getString("detail"))+"</font></td>");
		out.println("</tr>");
		out.println("</table>");
	}
	
	sql1 = "select name,email,detail,ip,date_format(datepost,'%e %b %Y, %T') as datepost from board_ans where id_quest='"+request.getParameter("id")+"' ";
	result = stmt.executeQuery(sql1);
	
	out.println("<table width='90%'  border='0' align='center'>");
	while (result.next())
	{
		out.println("<tr bgcolor='#009966'>");
		out.println("<td width='30%'><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='000066'><b>Name : </b>"+result.getString("name")+"<br>");
		out.println("<b>Email : </b>"+result.getString("email")+"<br>");
		out.println("<b>IP : </b>"+result.getString("ip")+"<br>");
		out.println("<b>Time : </b>"+result.getString("datepost"));
		out.println("</font></td>");
		out.println("<td width='60%'><font face='Angsana New, LilyUPC, AngsanaUPC, Tahoma' size='+1' color='000066'>"+newline(result.getString("detail"))+"</font></td>");
		out.println("</tr>");
	}
	out.println("</table>");
	
	result.close();
	stmt.close();
	mycon.close();
%>
        </p>
        <form name="form1" method="post" action="view.jsp?id=<%=request.getParameter("id")%>">
          <table width="90%"  border="0" align="center">
            <tr>
              <td bgcolor="#000066"><div align="center" class="style42"><strong>�����ʴ������Դ���</strong></div></td>
            </tr>
          </table>
          <table width="90%"  border="0" align="center">
            <tr bgcolor="#009966">
              <td width="20%"><div align="center" class="style13 style43"><strong>��������´</strong></div></td>
              <td width="80%"><textarea name="comment" cols="60" rows="10" id="comment"></textarea></td>
            </tr>
          </table>
          <table width="90%"  border="0" align="center">
            <tr>
              <td bgcolor="#009966"><div align="center">
                <input name="submit" type="submit" id="submit" value="Submit">
                <input name="reset" type="reset" id="reset" value="Reset">
              </div></td>
            </tr>
          </table>
          </form>
        </div></td>
    </tr>
  </table>
</div>
</body>
</html>