<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {font-size: 18px}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
.style43 {color: #000066}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
 	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="left">
        <form name="form1" method="post" action="addnew.jsp">
          <p>&nbsp;</p>
          <table width="80%"  border="0" align="center">
            <tr>
              <td bgcolor="#000066"><div align="center" class="style42"><strong>�����Ǣ������</strong></div></td>
            </tr>
          </table>
          <table width="80%"  border="0" align="center">
            <tr>
              <td width="22%"><div align="center" class="style13 style43"><strong>��Ǫ��</strong></div></td>
              <td width="78%"><input name="topic" type="text" id="topic" size="60" maxlength="150"></td>
            </tr>
            <tr>
              <td><div align="center"><span class="style13 style43"><strong>��������´</strong></span></div></td>
              <td><textarea name="comment" cols="60" rows="10" id="comment"></textarea></td>
            </tr>
          </table>
          <table width="80%"  border="0" align="center">
            <tr>
              <td><div align="center">
                <input name="submit" type="submit" id="submit" value="Submit">
                <input type="reset" name="Reset" value="Reset">
              </div></td>
            </tr>
          </table>
          </form>
        <p>
<%!
	public static String filter_topic(String input)
	{
		StringBuffer temp = new StringBuffer(input.length());
		char c;
		int j=1;
		for (int i=0;i<input.length();i++)
		{
			c = input.charAt(i);
			if (c == '<') temp.append("&lt;");
			else if (c == '>') temp.append("&gt;");
			else if (c == '\'') temp.append("&#039;");
			else if (c == '"') temp.append("&quot;");
			else if (c == '&') temp.append("&amp;");
			else if (c == '\\') temp.append("&#92;");
			else temp.append(c);
			
			if (j == 30)
			{
				temp.append("<br>");
				j = 0;
			}
			j++;
		}
		return(temp.toString());
	}
	
	public static String filter_comment(String input)
	{
		StringBuffer temp = new StringBuffer(input.length());
		char c;
		int j=1;
		for (int i=0;i<input.length();i++)
		{
			c = input.charAt(i);
			if (c == '<') temp.append("&lt;");
			else if (c == '>') temp.append("&gt;");
			else if (c == '\'') temp.append("&#039;");
			else if (c == '"') temp.append("&quot;");
			else if (c == '&') temp.append("&amp;");
			else if (c == '\\') temp.append("&#92;");
			else temp.append(c);
			
			if (j == 50)
			{
				temp.append("<br>");
				j = 0;
			}
			if (c == '\n')
				j = 0;
			j++;
		}
		return(temp.toString());
	}
%>
<%
	String topic="",name="",email="",comment="",ip="";
	String submit = request.getParameter("submit");
	boolean error = false;
	
	if (submit != null)
	{
		topic = filter_topic(request.getParameter("topic"));
		comment = filter_comment(request.getParameter("comment"));
		ip = request.getRemoteAddr();
		
		if (topic.equals(""))
		{
			error = true;
			out.println("<center><font color=red><b>��Ǩ�ͺ��Ǣ�����١��ͧ</b></font></center>");
		}
		if (comment.equals(""))
		{
			error = true;
			out.println("<center><font color=red><b>��Ǩ�ͺ�����Դ������١��ͧ</b></font></center>");
		}
		
		if (error == false)
		{
			Class.forName("org.gjt.mm.mysql.Driver");
			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();
			
			String sql1 = "select * from member where usr = '"+session.getAttribute("auth")+"' ";
			ResultSet rs1 = stmt.executeQuery(sql1);
			while (rs1.next())
			{
				name = rs1.getString("usr");
				email = rs1.getString("email");
			}
				
			String sql2 = "insert into board_quest values('','"+topic+"','"+name+"','"+email+"','"+comment+"','"+ip+"',NOW(),NOW(),'"+name+"',0,0)";
			int myresult = stmt.executeUpdate(sql2);
			if (myresult != 0)
				out.println("<center><font color=red><b>����������ŧ㹰ҹ���������º��������</b></font></center>");
			else
				out.println("<center><font color=red><b>�������ö����������ŧ㹰ҹ��������</b></font></center>");
			
			rs1.close();
			stmt.close();
			mycon.close();
		}			
	}
%>
	          </p>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>