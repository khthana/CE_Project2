<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*, java.util.*, java.lang.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {font-size: 18px}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style41 {color: #FFFFFF}
.style44 {color: #000066}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<div align="center">
	<jsp:include page="header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1  style42">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 "><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 ">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal; color: #FFFFFF;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 " #invalid_attr_id="normal">Log in</a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style43">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style43">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style43">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style37">
          <div align="center"><a href="radio.jsp" class="style44">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0">
    <tr>
      <td background="pic/bangkok_map2.gif"><form action="" method="post">
        <p>&nbsp;</p>
        <table width="80%"  border="0" align="center">
          <tr>
            <td bgcolor="#000066"><div align="center" class="style13 style41"><strong>��Ѥ���Ҫԡ</strong></div></td>
          </tr>
        </table>
        <table width="80%"  border="0" align="center">
          <tr>
            <td width="32%"><div align="center" class="style13 style44"><strong>Login</strong></div></td>
            <td width="68%"><span class="style41">
              <input name="usr" type="text" size="50" maxlength="20"> 
              <span class="style44">* Eng </span></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Password</strong></div></td>
            <td><span class="style41">
              <input name="pass1" type="password" size="50" maxlength="20"> 
              <span class="style44">* Eng</span></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Re-type password </strong></div></td>
            <td><span class="style41">
              <input name="pass2" type="password" size="50" maxlength="20"> 
              <span class="style44">* Eng</span></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Name</strong></div></td>
            <td><span class="style41">
              <input name="name" type="text" size="50" maxlength="50"> 
              <span class="style44">* Eng</span></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Email</strong></div></td>
            <td><span class="style41">
              <input name="email" type="text" size="50" maxlength="50"> 
              <span class="style44">* Eng</span></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>District</strong></div></td>
            <td><span class="style39">
				<select name="district" size="1" id="district">
				<option selected>District</option>
				<%
					Class.forName("org.gjt.mm.mysql.Driver");
					Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
					Statement stmt = mycon.createStatement();
					
					ResultSet rs5 = stmt.executeQuery("select distr_name from district");
					while (rs5.next())
					{
						out.println("<option value='"+rs5.getString("distr_name")+"'>"+rs5.getString("distr_name")+"</option>");
					}
					rs5.close();
				%>
<!--               <select name="district" size="1" id="district">
                  <option selected>District</option>
				  <option value="Bang Bon">Bang Bon</option>
				  <option value="Bang Kapi">Bang Kapi</option>
				  <option value="Bang Khae">Bang Khae</option>
				  <option value="Bang Khen">Bang Khen</option>
				  <option value="Bang Kholamm">Bang Kholamm</option>
				  <option value="Bang Khun Thian">Bang Khun Thian</option>
				  <option value="Bang Na">Bang Na</option>
				  <option value="Bangkok Noi">Bangkok Noi</option>
				  <option value="Bang Rak">Bang Rak</option>
				  <option value="Bang Sue">Bang Sue</option>
				  <option value="Bangkok Yai�">Bangkok Yai</option>
				  <option value="Bang Phlat">Bang Phlat</option>
				  <option value="Bueng Kum">Bueng Kum</option>
				  <option value="Chatuchak">Chatuchak</option>
				  <option value="Chom Thong">Chom Thong</option>
				  <option value="Din Daeng">Din Daeng</option>
				  <option value="Don Mueang">Don Mueang</option>
				  <option value="Dusit">Dusit</option>
				  <option value="Khan Na Yao">Khan Na Yao</option>
				  <option value="Khlong Samwa">Khlong Samwa</option>
				  <option value="Khlong San">Khlong San</option>
				  <option value="Khlong Toei">Khlong Toei</option>
				  <option value="Khuai Khwang">Khuai Khwang</option>
				  <option value="Lak Si">Lak Si</option>
				  <option value="Lat Krabang">Lat Krabang</option>
				  <option value="Lat Phrao">Lat Phrao</option>
				  <option value="Min Buri">Min Buri</option>
				  <option value="Nong Chok">Nong Chok</option>
				  <option value="Nong Khaem">Nong Khaem</option>
				  <option value="Pathumwan">Pathumwan</option>
				  <option value="Phasi Charoen">Phasi Charoen</option>
				  <option value="Phayathai">Phayathai</option>
				  <option value="Phra Khanong">Phra Khanong</option>
				  <option value="Phra Nakhon">Phra Nakhon</option>
				  <option value="Prawet">Prawet</option>
				  <option value="Pom Prap">Pom Prap</option>
				  <option value="Taling Chan">Taling Chan</option>
				  <option value="Thawi Watthana">Thawi Watthana</option>
                  <option value="Thon Buri">Thon Buri</option>
				  <option value="Thung Khru">Thung Khru</option>
                  <option value="Rat Burana">Rat Burana</option>
				  <option value="Ratchathewi">Ratchathewi</option>
				  <option value="Sai Mai">Sai Mai</option>
				  <option value="Samphan Tha Wong�">Samphan Tha Wong</option>
				  <option value="Saphan Sung">Saphan Sung</option>
				  <option value="Sathon">Sathon</option>
				  <option value="Suan Luang">Suan Luang</option>
				  <option value="Wang Thong Lang">Wang Thong Lang</option>
				  <option value="Watthina">Watthina</option>
				  <option value="Yan Nawa">Yan Nawa</option>
              </select>
 -->            </select></span></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Address</strong></div></td>
            <td><input name="address" type="text" id="address" size="50" maxlength="100"></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Mobile Phone#</strong></div></td>
            <td><input name="mobile" type="text" size="50" maxlength="9"></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Phone's provider </strong></div></td>
            <td class="style44 style13"><strong>
                <label><input type="radio" name="provider" value="DTAC">DTAC</label>
                <label><input type="radio" name="provider" value="AIS">AIS</label>
                <label><input type="radio" name="provider" value="Orange">Orange</label>
				<label><input type="radio" name="provider" value="Hutch">Hutch</label>
	        </strong></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Phone's user </strong></div></td>
            <td><input name="mo_usr" type="text" size="50" maxlength="20"></td>
          </tr>
          <tr>
            <td><div align="center" class="style44 style13"><strong>Phone's password </strong></div></td>
            <td><input name="mo_pass" type="password" size="50" maxlength="20"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div align="center"><span class="style44 style13"><strong>Start1</strong></span></div></td>
            <td><input name="start1" type="text" id="start1" size="50" maxlength="50"></td>
          </tr>
          <tr>
            <td><div align="center"><span class="style44 style13"><strong>Destination1</strong></span></div></td>
            <td><input name="dest1" type="text" id="dest1" size="50" maxlength="50"></td>
          </tr>
          <tr>
            <td><div align="center"><span class="style44 style13"><strong>Start2</strong></span></div></td>
            <td><input name="start2" type="text" id="start2" size="50" maxlength="50"></td>
          </tr>
          <tr>
            <td><div align="center"><span class="style44 style13"><strong>Destination2</strong></span></div></td>
            <td><input name="dest2" type="text" id="dest2" size="50" maxlength="50"></td>
          </tr>
        </table>
        <table width="80%"  border="0" align="center">
          <tr>
            <td><div align="center">
              <span class="style13 style44"><strong>������ <input name="search" type="submit" id="search" value="Search"> 
              ����������ӡ�ä��� Start ��� Destination</strong></span>
              <br><br>
<%
	String search = request.getParameter("search");
	String start1 = "",dest1 = "",start2 = "",dest2 = "";
	String sql = "";
	boolean error = false;
	boolean error_start1 = false, error_start2 = false,error_dest1 = false,error_dest2 = false;
	
	//Class.forName("org.gjt.mm.mysql.Driver");
	//Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	//Statement stmt = mycon.createStatement();
	
	if (search != null)
	{
		out.println("<br>");
		out.println("<table width='100%'  border='0'>");
		out.println("<tr>");
		out.println("<td width='25%'><div align='center'><span class='style44 style13'><strong>Start1</strong></span></div></td>");
		out.println("<td width='25%'><div align='center'><span class='style44 style13'><strong>Destination1</strong></span></div></td>");
		out.println("<td width='25%'><div align='center'><span class='style44 style13'><strong>Start2</strong></span></div></td>");
		out.println("<td width='25%'><div align='center'><span class='style44 style13'><strong>Destination2</strong></span></div></td>");
		out.println("</tr>");
		
		start1 = request.getParameter("start1");
		dest1 = request.getParameter("dest1");
		start2 = request.getParameter("start2");
		dest2 = request.getParameter("dest2");
		
		start1 = start1.trim();
		dest1 = dest1.trim();
		start2 = start2.trim();
		dest2 = dest2.trim();
		
		if (start1.equals(""))
		{
			error_start1 = true;
			out.println("<tr>");
			out.println("<td><center><b><font color=red>��ҹ�ѧ������кغ���ǳ</font></b></center></td>");
		}
		else
		{
			out.println("<tr>");
			out.println("<td></td>");
		}
		if (dest1.equals(""))
		{
			error_dest1 = true;
			out.println("<td><center><b><font color=red>��ҹ�ѧ������кغ���ǳ</font></b></center></td>");
		}
		else
		{
			out.println("<td></td>");
		}
		if (start2.equals(""))
		{
			error_start2 = true;
			out.println("<td><center><b><font color=red>��ҹ�ѧ������кغ���ǳ</font></b></center></td>");
		}
		else
		{
			out.println("<td></td>");
		}
		if (dest2.equals(""))
		{
			error_dest2 = true;
			out.println("<td><center><b><font color=red>��ҹ�ѧ������кغ���ǳ</font></b></center></td>");
			out.println("</tr>");
		}
		else
		{
			out.println("<td></td>");
			out.println("</tr>");
		}
		
		if (error == false)
		{
			out.println("<tr>");
			
			out.println("<td>");
			if (error_start1 == false)
			{
				sql = "select * from matching where word like '%"+start1+"%' ";
				ResultSet rs1 = stmt.executeQuery(sql);
				while (rs1.next())
				{
					out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_start1' value='"+rs1.getString("word")+"'>"+rs1.getString("word")+"</label></b></center></font><br>");
				}
				rs1.close();
			}
			out.println("</td>");
			
			out.println("<td>");
			if (error_dest1 == false)
			{
				sql = "select * from matching where word like '%"+dest1+"%' ";
				ResultSet rs2 = stmt.executeQuery(sql);
				while (rs2.next())
				{
					out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_dest1' value='"+rs2.getString("word")+"'>"+rs2.getString("word")+"</label></b></center></font><br>");
				}
				rs2.close();
			}
			out.println("</td>");
			
			out.println("<td>");
			if (error_start2 == false)
			{
				sql = "select * from matching where word like '%"+start2+"%' ";
				ResultSet rs3 = stmt.executeQuery(sql);
				while (rs3.next())
				{
					out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_start2' value='"+rs3.getString("word")+"'>"+rs3.getString("word")+"</label></b></center></font><br>");
				}
				rs3.close();
			}
			out.println("</td>");
			
			out.println("<td>");
			if (error_dest2 == false)
			{
				sql = "select * from matching where word like '%"+dest2+"%' ";
				ResultSet rs4 = stmt.executeQuery(sql);
				while (rs4.next())
				{
					out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_dest2' value='"+rs4.getString("word")+"'>"+rs4.getString("word")+"</label></b></center></font><br>");
				}
				rs4.close();
			}
			out.println("</td>");
			
			out.println("</tr>");
		}
		
		out.println("</table><br>");
	}
%>
            </div></td>
          </tr>
        </table>
        <table width="80%"  border="0" align="center">
          <tr>
            <td><div align="center">
              <input name="submit" type="submit" value="Submit">
              <input type="reset" name="Reset" value="Reset">
            </div></td>
          </tr>
        </table>
      </form>
	  <br>
<% 
	String submit = request.getParameter("submit");
	String usr = "",pass1 = "",pass2 = "",name = "",email = "";
	String district = "",address = "",mobile = "",provider = "",mo_usr = "",mo_pass = "";
	
	if (submit != null)
	{
		usr = request.getParameter("usr");
		pass1 = request.getParameter("pass1");
		pass2 = request.getParameter("pass2");
		name = request.getParameter("name");
		email = request.getParameter("email");
		district = request.getParameter("district");
		address = request.getParameter("address");
		mobile = request.getParameter("mobile");
		provider = request.getParameter("provider");
		mo_usr = request.getParameter("mo_usr");
		mo_pass = request.getParameter("mo_pass");
		start1 = request.getParameter("radio_start1");
		dest1 = request.getParameter("radio_dest1");
		start2 = request.getParameter("radio_start2");
		dest2 = request.getParameter("radio_dest2");

		if (usr.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��س������� LOGIN</font></b></center>");
		}
		if (pass1.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��س���� PASSWORD</font></b></center>");
		}
		if (name.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��س������ͧ͢��ҹ</font></b></center>");
		}
		if (email.equals("") || email.indexOf('@')==-1 || email.indexOf('.')==-1)
		{
			error = true;
			out.println("<center><b><font color=red>��سҵ�Ǩ�ͺ EMAIL �ͧ��ҹ���١��ͧ</font></b></center>");
		}
		if (!pass1.equals(pass2))
		{
			error = true;
			out.println("<center><b><font color=red>��سҵ�Ǩ�ͺ���ʼ�ҹ�ա�������١��ͧ</font></b></center>");
		}
		if (start1 != null && dest1 != null)
		{
			if (start1.equals(dest1))
			{
				error = true;
				out.println("<center><b><font color=red>Start1 �繺���ǳ���ǡѺ Destination1</font></b></center>");
			}
		}
		if (start2 != null && dest2 != null)
		{
			if (start2.equals(dest2))
			{
				error = true;
				out.println("<center><b><font color=red>Start2 �繺���ǳ���ǡѺ Destination2</font></b></center>");
			}
		}
		if (start1 == null && dest1 != null)
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ��������͡ Start1</font></b></center>");
		}
		if (start1 != null && dest1 == null)
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ��������͡ Destination1</font></b></center>");
		}
		if (start2 == null && dest2 != null)
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ��������͡ Start2</font></b></center>");
		}
		if (start2 != null && dest2 == null)
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ��������͡ Destination2</font></b></center>");
		}
	
		if (error == false)
		{
			sql = "select count(*) as num from member where usr = '"+usr+"' ";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				if (rs.getInt("num") == 1)
				{
					error = true;
					out.println("<center><b><font color=red>Login ���������㹰ҹ��������������  ��س����������</font></b></center>");
				}
				else
				{
					sql = "insert into member values('','"+usr+"','"+pass1+"','"+name+"','"+email+"','"+district+"','"+address+"','"+mobile+"','"+provider+"','"+mo_usr+"','"+mo_pass+"','"+start1+"','"+dest1+"','"+start2+"','"+dest2+"')";
					int myresult = stmt.executeUpdate(sql);
					if (myresult != 0)
					{
						out.println("<center><b>��Ѥ���Ҫԡ���º��������</b></center>");
						out.println("<center><b><a href='login.jsp'>���꡷�������� Log in</a></b></center>");
					}
				}
			}
			rs.close();
		}
	}
	stmt.close();
	mycon.close();
%>
	  </td>
    </tr>
  </table>
</div>
</body>
</html>
