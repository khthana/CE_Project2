import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.sql.*;
import java.text.*;

public class Map1 extends Applet implements MouseListener,MouseMotionListener
{
	private Image i;
	private int x,y,clickx,clicky,picx,picy,maxpicx,maxpicy,minpicx,minpicy;
	private int count = 0;
	private int x_coord[] = new int[100];
	private int y_coord[] = new int[100];
	String temp = "",getdistrict = "",getfirstroute = "";

	public int CountXY(String image) throws ClassNotFoundException,SQLException
	{
		int count_xy = 0;

  		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs = stmt.executeQuery("select count(*) as num from mapinfo where image = '"+image+"' ");
			while (rs.next())
			{
				count_xy = rs.getInt("num");
			}

			rs.close();
			stmt.close();
			mycon.close();
  		}
  		catch(Exception ex)
		{
			count_xy = 0;
  		}

		return count_xy;
  	}

	public int[] getX(String image) throws ClassNotFoundException,SQLException
	{
		int x[];
		x = new int[100];
		int i = 0;

  		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs = stmt.executeQuery("select x_coord from mapinfo where image = '"+image+"' ");
			while (rs.next())
			{
				x[i] = rs.getInt("x_coord") - 5;
				i++;
			}

			rs.close();
			stmt.close();
			mycon.close();
  		}
  		catch(Exception ex)
		{
  		}

		return x;
  	}

	public int[] getY(String image) throws ClassNotFoundException,SQLException
	{
		int y[];
		y = new int[100];
		int i = 0;

  		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs = stmt.executeQuery("select y_coord from mapinfo where image = '"+image+"' ");
			while (rs.next())
			{
				y[i] = rs.getInt("y_coord") - 5;
				i++;
			}

			rs.close();
			stmt.close();
			mycon.close();
  		}
  		catch(Exception ex)
		{
  		}

		return y;
  	}

	public String shownode(String image,int x,int y) throws ClassNotFoundException,SQLException
	{
		String node = "";

  		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs1 = stmt.executeQuery("select node from mapinfo where image = '"+image+"'  && x_coord > "+(x-5)+" && x_coord < "+(x+5)+" && y_coord > "+(y-5)+" && y_coord < "+(y+5)+"");
			while (rs1.next())
			{
				node = rs1.getString("node");
			}
			rs1.close();
			
			stmt.close();
			mycon.close();
  		}
  		catch(Exception ex)
		{
  		}

		return node;
  	}

	public String getPic(String district) throws ClassNotFoundException,SQLException
	{
		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs = stmt.executeQuery("select image from mapinfo where default_district = '"+district+"' ");
			while (rs.next())
			{
				temp = rs.getString("image");
			}

			rs.close();
			stmt.close();
			mycon.close();
  		}
		catch (Exception ex)
		{
		}

		if (temp.equals(""))
		{
			temp = "e10047000n1346000s4.jpg";
		}

		return temp;
	}

	public String showdetail(String node)  throws ClassNotFoundException,SQLException
	{
		String detail = "";

		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");
  			Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
			Statement stmt = mycon.createStatement();

			ResultSet rs1 = stmt.executeQuery("select * from nodeadjacent where node = '"+node+"' ");
			while (rs1.next())
			{
				detail = detail + " GOTO " + rs1.getString("adja") + "(" + rs1.getInt("distance") + "," + rs1.getInt("expressway") + "," + rs1.getInt("density") + ")";
			}
			rs1.close();
			
			stmt.close();
			mycon.close();
  		}
  		catch(Exception ex)
		{
  		}

		return detail;
	}

	public void init()
	{
		//picx = 10047000;
		//picy = 1346000;
		String temp = "";
		getdistrict = getParameter("map_district");
		getfirstroute = getParameter("map_image");
		try
		{
			if ((getfirstroute.equals("")) || (getfirstroute == null))
			{
				temp = getPic(getdistrict);
				picx = Integer.parseInt(temp.substring(1,9));
				picy = Integer.parseInt(temp.substring(10,17));
			}
			else
			{
				picx = Integer.parseInt(getfirstroute.substring(1,9));
				picy = Integer.parseInt(getfirstroute.substring(10,17));
			}
		}
		catch(Exception ex)
		{
			picx = 10047000;
			picy = 1346000;
		}
		maxpicx = 10047000;
		maxpicy = 1346000;
		minpicx = 10044600;
		minpicy = 1343600;

		i  =  getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	public void paint (Graphics g)
	{
		try
		{
			count = CountXY("e"+picx+"n"+picy+"s4");
			x_coord = getX("e"+picx+"n"+picy+"s4");
			y_coord = getY("e"+picx+"n"+picy+"s4");
		}
		catch (Exception e)
		{
			count = 0;
		}

		g.drawImage(i,0,0,this);
		//g.drawString("|"+getfirstroute+"|",10,10);
		//g.drawString("e"+picx+"n"+picy+"s4",10,50);
		//g.drawString("|"+getdistrict+"|",10,80);
		//String temp1 = Integer.toString(count);
		//g.drawString(temp1,10,10);
		//String temp2 = Integer.toString(x[0]);
		//g.drawString(temp2,10,70);
		//String temp3 = Integer.toString(y[0]);
		//g.drawString(temp3,10,70);

		for (int i=0;i<count;i++)
		{
			g.fillOval(x_coord[i],y_coord[i],10,10);
		}
	}

	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mouseExited(MouseEvent e)
	{
		showStatus("Pointer outside applet");
	}
	public void mouseEntered(MouseEvent e) {}
	public void mouseClicked(MouseEvent e)
	{
		clickx = e.getX();
		clicky = e.getY();
		showStatus("clicked at "+clickx+","+clicky);
		//move left
		if ((clickx < 20) && (clicky>290) && (clicky<310))
		{
			if (picx == minpicx)
			{
				showStatus("Can't move left");
			}
			else
			{
				showStatus("click move left");
				MoveLeft();
			}
		}
		//move right
		if ((clickx >580) && (clicky>290) && (clicky<310))
		{
			if (picx == maxpicx)
			{
				showStatus("Can't move right");
			}
			else
			{
				showStatus("click move right");
				MoveRight();
			}
		}
		//move up
		if ((x < 310) && (x>290) && (y<20))
		{
			if (picy == maxpicy)
			{
				showStatus("Can't move up");
			}
			else
			{
				showStatus("click move up");
				MoveUp();
			}
		}
		//move down
		if ((x < 310) && (x>290) && (y>580))
		{
			if (picy == minpicy)
			{
				showStatus("Can't move down");
			}
			else
			{
				showStatus("click move down");
				MoveDown();
			}
		}
		//move up left
		if ((x <20) && (y<20))
		{
			if ((picx == minpicx) || (picy == maxpicy))
			{
				showStatus("Can't move up left");
			}
			else
			{
				showStatus("click move up left");
				MoveUpLeft();
			}
		}
		//move down left
		if ((x < 20) && (y>580))
		{
			if ((picx == minpicx) || (picy == minpicy))
			{
				showStatus("Can't move down left");
			}
			else
			{
				showStatus("click move down left");
				MoveDownLeft();
			}
		}
		//move up right
		if ((x > 580) && (y<20))
		{
			if ((picx == maxpicx) || (picy == maxpicy))
			{
				showStatus("Can't move up right");
			}
			else
			{
				showStatus("click move up right");
				MoveUpRight();
			}
		}
		//move down right
		if ((x >580) && (y>580))
		{
			if ((picx == maxpicx) || (picy == minpicy))
			{
				showStatus("Can't move down left");
			}
			else
			{
				showStatus("click move down right");
				MoveDownRight();
			}
		}
	}

	public void mouseDragged(MouseEvent e) {}
	public void mouseMoved(MouseEvent e)
	{
		x = e.getX();
		y = e.getY();
		showStatus(x+","+y);
		try
		{
			showStatus(shownode("e"+picx+"n"+picy+"s4",x,y) + showdetail(shownode("e"+picx+"n"+picy+"s4",x,y)));
		}
		catch(Exception ex)
		{
		}
		if ((x < 20) && (y>290) && (y<310))
		{
			showStatus("Move left");
		}
		if ((x >580) && (y>290) && (y<310))
		{
			showStatus("Move right");
		}
		if ((x < 310) && (x>290) && (y<20))
		{
			showStatus("Move up");
		}
		if ((x < 310) && (x>290) && (y>580))
		{
			showStatus("Move down");
		}
		if ((x <20) && (y<20))
		{
			showStatus("Move up left");
		}
		if ((x < 20) && (y>580))
		{
			showStatus("Move down left");
		}
		if ((x > 580) && (y<20))
		{
			showStatus("Move up right");
		}
		if ((x >580) && (y>580))
		{
			showStatus("Move down right");
		}
	}

	public void MoveLeft()
	{
		picx = picx - 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveRight()
	{
		picx = picx + 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveUp()
	{
		picy = picy + 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveDown()
	{
		picy = picy - 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveUpLeft()
	{
		picx = picx -2400;
		picy = picy + 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveDownLeft()
	{
		picx = picx - 2400;
		picy = picy - 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveUpRight()
	{
		picx = picx + 2400;
		picy = picy + 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
	public void MoveDownRight()
	{
		picx = picx + 2400;
		picy = picy - 2400;
		i = getImage (getCodeBase(),"pic/e"+picx+"n"+picy+"s4.jpg");
		repaint();
	}
}