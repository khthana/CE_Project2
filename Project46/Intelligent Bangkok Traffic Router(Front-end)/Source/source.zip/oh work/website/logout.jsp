<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
<title>Intelligent BangkokTraffic Router</title>
<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
</head>

<body>
<%
	session.invalidate();
	response.sendRedirect("home.jsp");
%>
</body>
</html>
