<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {
	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style42 {
	font-size: 36px;
	color: #FF0000;
}
.style43 {
	font-size: 18px;
	color: #000066;
	font-weight: bold;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<div align="center">
	<jsp:include page="header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log in</strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
</div>
<table width="800" border="0" align="center">
  <tr>
    <td background="pic/bangkok_map2.gif"><div align="center" class="style42">
<%
	if (session.getAttribute("auth") != null)
	{
		response.sendRedirect("member_map.jsp");
		return;
	}
%>
<br>
	<form name="form1" method="post" action="map.jsp">
      <table width="80%"  border="0">
        <tr>
          <td bgcolor="#000066"><div align="center" class="style13">Bangkok Map </div></td>
        </tr>
        <tr>
          <td>
            <div align="center" class="style43">
              Please select DISTRICT 
                <select name="district" id="district">
<%
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();
	
	ResultSet rs1 = stmt.executeQuery("select distr_name from district");
	while (rs1.next())
	{
		out.println("<option value='"+rs1.getString("distr_name")+"'>"+rs1.getString("distr_name")+"</option>");
	}
	rs1.close();
	
	stmt.close();
	mycon.close();
%>
              </select>
                <input type="submit" name="submit" value="OK">
            </div>
		  </td>
        </tr>
      </table>
<%
	String submit = request.getParameter("submit");
	String district = "";
	
	if (submit != null)
	{
		district = request.getParameter("district");
		out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+district+"</b></center></font>");
		out.println("<applet code = 'Map1.class' width='600' height='600'>");
		out.println("<param name=map_image value=''>");
		out.println("<param name=map_district value="+district+">");
		out.println("</applet>");
	}
%>  
	 </form>
	 <font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>NODE GOTO NODEADJACENT(DISTANCE,COST,DENSITY)</b></center></font>
	</div></td>
  </tr>
</table>
</body>
</html>
