<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style9 {
	color: #FFFFFF;
	font-size: 24px;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
}
.style13 {font-size: 18px}
.style18 {font-size: 16}
.style20 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 16px;
	color: #FFFFFF;
}
.style31 {
	font-size: 14px;
	font-weight: bold;
}
.style32 {color: #FFFFFF; font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;}
.style34 {
	color: #000066;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-size: 18px;
}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style36 {
	font-size: 24px;
	font-weight: bold;
	color: #000066;
}
.style37 {font-size: 18px; font-weight: bold; }
.style39 {
	color: #FFFFFF;
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	font-weight: bold;
}
.style40 {
	font-family: "Angsana New", LilyUPC, AngsanaUPC, Tahoma;
	font-style: normal;
	color: #FFFFFF;
	font-size: 18px;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620"><body class="boy1">

<div align="center">
	<jsp:include page="header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
		  
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log in</strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0">
    <tr>
      <td width="590" height="233"><p align="center"><img src="pic/car_main.gif" width="600" height="252"></p>
      <p align="center"><img src="pic/name.gif" width="520" height="50"></p>
      <p align="center" class="style36">�к�������鹷ҧ�Ѩ�����㹡�ا෾�</p></td>
      <td width="200" valign="top"><div align="center">
        <p>&nbsp;</p>
        <p><a href="http://www.communications.police.go.th"><img src="pic/icon_pol_com.gif" width="136" height="48" border="0"></a></p>
        <p><a href="http://www.trafficbkk.com"><img src="pic/logo_swp91.gif" width="136" height="48" border="0"></a></p>
        <p><a href="http://www.mleart91.com"><img src="pic/malert91logo.gif" width="136" height="48" border="0"></a></p>
        <p><a href="http://www.js100.com"><img src="pic/js100.gif" width="100" height="66" border="0"></a></p>
      </div></td>
    </tr>
  </table>
</div>
</body>
</html>
