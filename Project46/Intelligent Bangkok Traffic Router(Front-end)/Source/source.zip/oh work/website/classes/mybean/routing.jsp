<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style42 {
	font-size: 36px;
	color: #FF0000;
}
.style43 {
	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
}
.style44 {
	font-size: 18px;
	font-weight: bold;
	color: #000066;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<jsp:useBean id="routebean" class="mybean.routing" />
<%= getTesting()%>
<%
	if (session.getAttribute("auth") != null)
	{
		response.sendRedirect("member_routing.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="200" bordercolor="#000000" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="login.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log in</strong></a></div></td>
      <td width="85" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bordercolor="#000000" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
</div>
<table width="800" border="0" align="center">
  <tr>
    <td background="pic/bangkok_map2.gif"><p>&nbsp;</p>
    <div align="center" class="style42">
      <form name="form1" method="post" action="routing.jsp">
        <table width="80%"  border="0">
          <tr>
            <td bgcolor="#000066"><div align="center" class="style43">Routing</div></td>
          </tr>
        </table>
        <table width="80%"  border="0">
          <tr>
            <td width="50%"><div align="center" class="style44">Start</div></td>
            <td width="50%"><div align="center" class="style44">Destination</div></td>
          </tr>
          <tr>
            <td><div align="center">
              <input name="start" type="text" id="start" size="30" maxlength="50">
            </div></td>
            <td><div align="center">
              <input name="dest" type="text" id="dest" size="30" maxlength="50">
            </div></td>
          </tr>
        </table>
        <table width="80%"  border="0">
          <tr>
            <td><div align="center">
              <input name="search" type="submit" id="search" value="Search">
			  <br>
			  <br>
<%
	String search = request.getParameter("search");
	String start = "",dest = "";
	String sql = "";
	String [ ] parameter = request.getParameterValues("parameter");
	boolean error = false;
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();

	if (search != null)
	{
		start = request.getParameter("start");
		dest = request.getParameter("dest");
		
		if (start.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Start</font></b></center><br>");
		}
		if (dest.equals(""))
		{
			error = true;
			out.println("<center><b><font color=red>��ҹ�ѧ������кبش Destination</font></b></center><br>");
		}
		
		if (error == false)
		{
			out.println("<table width='80%'  border='0'>");
			out.println("<tr>");
			out.println("<td width='50%' bgcolor='000066'><div align='center'><span class='style43'><strong>Start</strong></span></div></td>");
			out.println("<td width='50%' bgcolor='000066'><div align='center'><span class='style43'><strong>Destination</strong></span></div></td>");
			out.println("</tr>");
		
			out.println("<tr>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+start+"%' ";
			ResultSet rs1 = stmt.executeQuery(sql);
			while (rs1.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_start' value='"+rs1.getString("word")+"' checked>"+rs1.getString("word")+"</label></b></center></font><br>");
			}
			rs1.close();
			out.println("</td>");
			
			out.println("<td>");
			sql = "select * from matching where word like '%"+dest+"%' ";
			ResultSet rs2 = stmt.executeQuery(sql);
			while (rs2.next())
			{
				out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><label><input type='radio' name='radio_dest' value='"+rs2.getString("word")+"' checked>"+rs2.getString("word")+"</label></b></center></font><br>");
			}
			rs2.close();
			out.println("</td>");
			
			out.println("</tr>");
			
			out.println("</table>");
			
			out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Please select parameter</b></center></font><br>");
			out.println("<table width='80%'>");
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='distance' checked>Distance</b></center></font></td>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='cost' checked>Cost</b></center></font></td>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b><input type='checkbox' name='parameter' value='time' checked>Time</b></center></font></td>");
			out.println("</tr>");
			out.println("</table>");
			out.println("<center><input name='submit' type='submit' value='Submit'></center>");
		}
	}
	
	String submit = request.getParameter("submit");
	if (submit != null  && error == false)
	{
		start = request.getParameter("radio_start");
		dest = request.getParameter("radio_dest");
		
		if (parameter.length == 0)
		{
			error = true;
			out.println("<center><font color=red><b>Please select Parameter</b></font></center>");
		}
		
		if (start.equals(dest))
		{
			out.println("<center><b><font color=red>�ش Start ��Шش Destination �繷�����ǡѹ</font></b></center><br>");
		}
		else
		{
			out.println("<table width='80%' border='0'>");
			out.println("<tr>");
			out.println("<td width='50%' bgcolor='000066'><div align='center'><span class='style43'><strong>Start</strong></span></div></td>");
			out.println("<td width='50%' bgcolor='000066'><div align='center'><span class='style43'><strong>Destination</strong></span></div></td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+start+"</b></center></font><br></td>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+dest+"</b></center></font><br></td>");
			out.println("</tr>");
			out.println("</table>");
			out.println("<font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Your parameter is ");
			for (int i=0;i<parameter.length;i++)
			{
				out.println(","+parameter[i]);
			}
			out.println("</b></center></font>");
			
			out.println("<table width='80%' border='0'>");
			out.println("<tr>");
			out.println("<td bgcolor='000066'><div align='center'><span class='style43'><strong>Path</strong></span></div></td>");
			out.println("</tr>");
			
			/*ResultSet rs3 = stmt.executeQuery("select * from matching where word = '"+start+"' ");
			while (rs3.next())
			{
				routebean.setSrcNode(rs3.getString("inter1"));
			}
			rs3.close();
			
			ResultSet rs4= stmt.executeQuery("select * from matching where word = '"+dest+"' ");
			while (rs3.next())
			{
				routebean.setDesNode(rs4.getString("inter1"));
			}
			rs4.close();
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>"+routebean.getDisplayRoute()+"</b></center></br></td>");
			out.println("</tr>");*/
			
			/*out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>LAD KRABANG Uturn1>LAD KRABANG Uturn2>LAD KRABANG Uturn3>LAD KRABANG Uturn4>LAD KRABANG Uturn5>LAD KRABANG Uturn6>LAD KRABANG-CHALONG KRUNG>LAD KRABANG Uturn7>LAD KRABANG-To Bang Na>LAD KRABANG Uturn8</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Usage time about 126.15663 minutes</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Overall money = 40 Baht</b></center></br></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><font size='+1'color='000066' face='Angsana New, LilyUPC, AngsanaUPC, Tahoma'><center><b>Overall money = 40 Baht</b></center></br></td>");
			out.println("</tr>");*/
			
			out.println("</table>");
			
			out.println("<applet code = 'Map1.class' width='600' height='600'>");
		}
	}
	
	stmt.close();
	mycon.close();
%>
            </div></td>
          </tr>
        </table>
        </form>
	</div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
