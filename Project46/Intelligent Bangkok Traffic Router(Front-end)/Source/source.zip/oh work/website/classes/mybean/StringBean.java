package mybean;
public class  StringBean
{
	private String message = "first";

	public String getMessage()
	{
		return(message);
	}

	public void setMessage(String message)
	{
		this.message = message;
	}
}