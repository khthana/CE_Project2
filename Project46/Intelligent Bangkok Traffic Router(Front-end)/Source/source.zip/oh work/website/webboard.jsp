<%@ page contentType="text/html; charset=TIS-620" language="java" import="java.sql.*" errorPage="error.jsp" %>
<html>
<head>
	<title>Intelligent Bangkok Traffic Router</title>
    <link href="style/boy.css" rel="stylesheet" type="text/css">
    <style type="text/css">
<!--
.style13 {font-size: 18px}
body,td,th {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
a {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Angsana New, LilyUPC, AngsanaUPC, Tahoma;
}
.style41 {color: #FFFFFF}
.style42 {font-size: 18px; color: #FFFFFF; }
.style43 {color: #000066}
.style44 {
	font-size: 18px;
	color: #000066;
	font-weight: bold;
	font-family: Tahoma;
}
-->
    </style>

<meta http-equiv="Content-Type" content="text/html; charset=TIS-620">
<body class="boy1">
<%
	if (session.getAttribute("auth") == null)
	{
		response.sendRedirect("login.jsp");
		return;
	}
%>
<div align="center">
	<jsp:include page="member_header.jsp"/>
<!--   <table width="800" border="0">
    <tr bordercolor="#FFFFFF">
      <td width="559" bordercolor="#000000" bgcolor="#000066" class="style18"><a href="home.jsp" class="boy1 style20">Home&gt;&gt; Intelligent Bangkok Traffic Router </a></td>
      <td width="231" bgcolor="#000066"><div align="center" class="boy1 style9 style13"><strong>
          
      </strong></div></td>
    </tr>
  </table>
  <table width="800" height="92" border="0" bgcolor="#FFFFFF">
    <tr>
      <td height="82"><img src="pic/main_pic.gif" width="798" height="80"></td>
    </tr>
  </table>
  <table width="800" border="0">
    <tr>
      <td width="200" bgcolor="#FFFFFF" class="style18"><div align="center" class="style31 style34 style13">PowerBy : KMITL CE</div></td>
      <td width="100" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="register.jsp" class="style32 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Register</strong></a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="logout.jsp" class="style32 style13 " style="font-weight: normal; font-variant: normal; text-transform: none; font-style: normal;" #invalid_attr_id="normal"><strong>Log out </strong></a></div></td>
      <td width="85" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="map.jsp" class="style39">Map</a></div></td>
      <td width="90" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="routing.jsp" class="style39">Routing</a></div></td>
      <td width="95" bgcolor="#000066" class="style18"><div align="center" class="style37"><a href="report.jsp" class="style39">Traffic Report </a></div></td>
      <td width="110" bgcolor="#000066"><div align="center" class="boy1 style9 style31 style13">
          <div align="center"><a href="radio.jsp" class="style40">Live Radio Report </a>      </div>
      </div></td>
    </tr>
  </table> -->
  <table width="800" border="0" bordercolor="#000066">
    <tr>
      <jsp:include page="member_left.jsp"/>
	  <!-- <td width="200" bgcolor="#000066"><p align="center" class="style13"><strong><a href="edit.jsp" class="style41">��䢢�������ǹ���</a></strong></p>
      <p align="center"><strong><a href="member_map.jsp" class="style42">Ἱ���</a></strong></p>
      <p align="center"><strong><a href="member_routing.jsp" class="style13 style41">������鹷ҧ</a></strong></p>
      <p align="center"><strong><a href="member_report.jsp" class="style42">��§ҹ��è�Ҩ�</a></strong></p>
      <p align="center"><a href="member_radio.jsp" class="style42"><strong>��.100</strong></a></p>
      <p align="center"><a href="webboard.jsp" class="style42"><strong>��纺���</strong></a></p>
      <p align="center">&nbsp;</p>
      <p align="center"><a href="logout.jsp" class="style42"><strong>�͡�ҡ�к�</strong></a></p></td> -->
      <td width="590" background="pic/bangkok_map1.gif"><div align="left">
        <p>&nbsp;</p>
        <table width="90%"  border="0" align="center">
          <tr>
            <td><div align="center" class="style44">��纺����ʴ������Դ���</div></td>
          </tr>
        </table>
        <table width="90%"  border="0" align="center">
          <tr>
            <td><a href="addnew.jsp" class="style42 style43"><strong>�����Ǣ������</strong></a></td>
          </tr>
        </table>
        <table width="90%"  border="1" align="center" bordercolor="#000000">
          <tr bgcolor="#000066">
            <td width="47%"><div align="center" class="style42"><strong>��Ǣ��</strong></div></td>
            <td width="13%"><div align="center"><span class="style42"><strong>�����</strong></span></div></td>
            <td width="7%"><div align="center"><span class="style42"><strong>�ͺ</strong></span></div></td>
            <td width="7%"><div align="center"><span class="style42"><strong>��</strong></span></div></td>
            <td width="26%"><div align="center"><span class="style42"><strong>�ʵ�����ش����</strong></span></div></td>
          </tr>
<%
	int row_page = 10;
	int total_row = 0;
	
	Class.forName("org.gjt.mm.mysql.Driver");
	Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myproject?user=root&password=231025231025");
	Statement stmt = mycon.createStatement();
	ResultSet myresult0 = stmt.executeQuery("select count(*) as num from board_quest");
	
	while (myresult0.next())
		total_row = myresult0.getInt("num");

	myresult0.close();
	
	int total_page = (int)Math.ceil((double)total_row/(double)row_page);
	out.println("<font color='000066' size='+1'><b>�ռ���ʴ������Դ��繷����� "+total_row+" �����Դ��� �ʴ��͡������˹���� "+row_page+" �����Դ��� �ҡ������ "+total_page+" ˹��</b></font><br>");
	int screen,start;
	
	if (request.getParameter("screen") == null)
		screen= 1;
	else
		screen = Integer.parseInt(request.getParameter("screen"));
	
	if (screen >= 1 && screen <= total_page)
	{
		start = (screen - 1)*row_page;
		String sql = "select id,topic,name,ans,view,date_format(lastpost,'%e %b %Y, %T') as lastpost,lastname from board_quest order by id desc limit "+start+","+row_page;
		ResultSet myresult = stmt.executeQuery(sql);
	
		while (myresult.next())
		{
			out.println("<tr bgcolor='#009966'>");
			out.println("<td align=left><a href='view.jsp?id="+myresult.getString("id")+"'><font color='000066' size='+1'><b> "+myresult.getString("topic")+"</b></font></a></td>");
			out.println("<td align=center><font color='000066' size='+1'><b>"+myresult.getString("name")+"</b></font></td>");
			out.println("<td align=center><font color='000066'>"+myresult.getString("ans")+"</font></td>");
			out.println("<td align=center><font color='000066'>"+myresult.getString("view")+"</font></td>");
			out.println("<td align=center><font face='MS Sans Serif' size='2' color='000066'>"+myresult.getString("lastpost")+"<br>�� <b>"+myresult.getString("lastname")+"</td></tr>");
		}
		
		if (screen > 1)
			out.println("<a href='webboard.jsp?screen="+(screen-1)+"' ><b>��͹��Ѻ</b></a>");
		for (int i=1; i<=total_page; i++)
		{
			if (i == screen)
				out.println(" <b>["+i+"]</b>");
			else
				out.println(" | <a href='webboard.jsp?screen="+i+"'>"+i+"</a> | ");
		}
		if (screen < total_page)
			out.println("<a href='webboard.jsp?screen="+(screen+1)+"' ><b>�Ѵ�</b></a>");
			
		myresult.close();
	}
	else
		out.println("<center><font color=red><b>��辺������</b></font></center><br>");
	
	stmt.close();
	mycon.close();
%>
        </table>
		<br>
        </div></td>
    </tr>
  </table>
</div>
</body>
</html>