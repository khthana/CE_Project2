import javax.microedition.lcdui.*;
import java.io.*;

public class SearchsourceScreen extends Form implements CommandListener {
	
	public static String[] sourceList = new String[50];
	public static String[] routeArray = new String[7];
	private TrafficReport midlet;
	private UserScreen usr;
	private TextField searchField;
	private ChoiceGroup sourceChoice;
	private String temp = new String("");
	private String serverURL = new String();
	private int  j = 0;
	private	int k = 0;
	private int flag = 0;

	private Command Next,Search,Back;

	SearchsourceScreen(TrafficReport midlet) {
		super("SELECT SOURCE");
		this.midlet = midlet;
		searchField = new TextField("Search Source:","",30,TextField.ANY);
		append(searchField);
		sourceChoice = new ChoiceGroup("Source Choice:",List.EXCLUSIVE);
		if(sourceList[0] != null) {    //make choice
			for(int i=0;i<50;i++) {
				if(sourceList[i] != null) 
					sourceChoice.append(sourceList[i],null);
				else
				i = 50;
			}
		}
		append(sourceChoice);	
		ItemStateListener listener = new ItemStateListener() {
			public void itemStateChanged(Item item) {
				temp = searchField.getString();
				flag = 1;
			}
		};
		Next = new Command("Next",Command.SCREEN,0);
		addCommand(Next);	
		Search = new Command("Search",Command.SCREEN,0);
		addCommand(Search);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();
		int n;		
	
		if(c == Next) {
			try{
				n = sourceChoice.getSelectedIndex();
				encode = midlet.EncodeConnection("search="+sourceChoice.getString(n));
				serverURL = "http://localhost:8080/Server_RouteJunction.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.substring(2,result.length()-1);
				getrouteArray(result);
				midlet.goSearchdest(); 
			}
			catch(IOException e) {
			}
		}
		if(c == Search) {
			try{
				if((flag == 1)||(temp.charAt(0) == (char)32)) {
					encode = midlet.EncodeConnection("search="+temp);
					serverURL = "http://localhost:8080/Server_RouteSearch.jsp?"+encode;
					result = midlet.goConnect(serverURL);
					result = result.substring(4,result.length()-1);
					getsourceList(result);
					midlet.goSearchsource();			
				}
			}
			catch (IOException e) {
			}
		}
		if(c == Back) {
			if(usr.userStatus)
				midlet.goMember();
			else
				midlet.goNonmember();
		}
	}
	public void getsourceList(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					sourceList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					sourceList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
			for(int l=k+1;l<50;l++) 
				sourceList[l] = null;
		}
	}
	public void getrouteArray(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					routeArray[k] = input.substring(j,i);	
					i = 300;
				}
				else {
					routeArray[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
		}
	}
}