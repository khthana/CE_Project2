<%@ page import="java.sql.*" %>
<%
	String reqstr = request.getParameter("str");
	String output = new String();
	
	try{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		ResultSet myresult = stmt.executeQuery("SELECT * FROM report WHERE street='"+reqstr+"'");
		
		while(myresult.next()){
			output = myresult.getString("date")+','+myresult.getString("comment");
		}
		output = output + ",$";
		out.println(output);
		myresult.close();
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e)
	{
		out.println("Can't find database driver");
	}
	catch(SQLException e)
	{
		out.println("Can't find database");
	}
%>