import javax.microedition.lcdui.*;
import java.io.*;

public class ReportrangeScreen extends List implements CommandListener {
	
	public static String[] rangeList = new String[50];
	public static String temp = new String();
	private TrafficReport midlet;
	private String serverURL =  new String();
	private Command Report,Back;

	ReportrangeScreen(TrafficReport midlet) {
		super("SELECT RANGE",List.IMPLICIT);
		this.midlet = midlet;
		if(rangeList[0] != null) {
			for(int i=0;i<50;i++) {
				if(rangeList[i] != null) 
					append(rangeList[i],null);
				else
					i = 50;
			}
		}
		Report = new Command("Report",Command.SCREEN,0);
		addCommand(Report);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();
		int n;		
	
		if(c == Report) {
			try{
				n = getSelectedIndex();
				temp = getString(n);
				encode = midlet.EncodeConnection("str="+temp);
				serverURL = "http://localhost:8080/Server_ReportResponse.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.substring(2,result.length()-1);
				midlet.goResponse(result,2); 
			}
			catch(IOException e) {
			}
		}
		if(c == Back) 
			midlet.goReport();
	}
}