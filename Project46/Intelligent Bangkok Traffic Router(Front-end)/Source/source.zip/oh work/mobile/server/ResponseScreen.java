import javax.microedition.lcdui.*;

public class ResponseScreen extends Form implements CommandListener {
	
	private TrafficReport midlet;
	private UserScreen usr;
	private ReportrangeScreen report;
	private StringItem info; //date
	private String temp = new String();
	private Command Service, Back;
	private int j = 0;
	private int k = 0;
	private int checkresponse; 

	ResponseScreen(TrafficReport midlet, String input, int flag) {
		super("RESPONSE");
		this.midlet = midlet;
		checkresponse = flag;
		info = new StringItem("Infomation: ",input.substring(0,input.length()-3));
		append(info);
		Service = new Command("Service",Command.SCREEN,0);
		addCommand(Service);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		if(c == Service) {
			if(usr.userStatus)
				midlet.goMember();
			else
				midlet.goNonmember();
		}
		if(c == Back)
			if(checkresponse == 1)
				midlet.goCost();
			else if(checkresponse == 2)
				midlet.goRange();
	}
}