<%@ page import="java.sql.*" %>
<%
	String reqsearch = request.getParameter("search");
	String output = new String("#,");
	
	try{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		ResultSet myresult = stmt.executeQuery("SELECT * FROM matching WHERE word like '%"+reqsearch+"%'");
		while(myresult.next()){
			output = output + myresult.getString("word") + ',';
		}
		output = output + '$';
		out.println(output); 
		myresult.close();
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e)
	{
		out.println("Can't find database driver");
	}
	catch(SQLException e)
	{
		out.println("Can't find database");
	}
%>