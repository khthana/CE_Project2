<%@ page import="java.sql.*" %>
<%
	String requser = request.getParameter("username");
	String reqpass = request.getParameter("password");
	String output  = new String();
	
	try
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		ResultSet myresult = stmt.executeQuery("SELECT * FROM member WHERE usr='"+requser+"' and pass='"+reqpass+"'");
		if(myresult != null) {
			while(myresult.next()) {
				output = myresult.getString("usr") +','+
				myresult.getString("pass")+','+
				myresult.getString("name")+','+
				myresult.getString("email")+','+
				myresult.getString("district")+','+
				myresult.getString("address")+','+
				myresult.getString("mobile")+','+
				myresult.getString("provider")+','+
				myresult.getString("mo_usr")+','+
				myresult.getString("mo_pass")+','+
				myresult.getString("start1")+','+
				myresult.getString("dest1")+','+
				myresult.getString("start2")+','+
				myresult.getString("dest2")+",$";	
			}
			out.println(output);
		}
		myresult.close();
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e) {
		out.println("Can't find database driver");
	}
	catch(SQLException e) {
		out.println("Can't find database");
	}
%>