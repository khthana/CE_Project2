import javax.microedition.lcdui.*;
import java.io.*;

public class CostScreen extends List implements CommandListener {
	
	private TrafficReport midlet;
	private SearchsourceScreen source;
	private String serverURL = new String();
	private Command Route,Back;	
	
	CostScreen(TrafficReport midlet) {
		super("SELECT COST",List.MULTIPLE);
		this.midlet = midlet;
		append("Time",null);
		append("Money",null);
		append("Distance",null);
		Route = new Command("Route",Command.SCREEN,0);
		addCommand(Route);
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();

		if(c == Route)	{
			try{
				for(int i=0;i<=size()-1;i++) {
					if(isSelected(i)) 
						source.routeArray[i+4] =  "y";
					else
						source.routeArray[i+4] =  "n";	
				}
				if((source.routeArray[0].equals(source.routeArray[1]))||(source.routeArray[2].equals(source.routeArray[3]))) 
					midlet.goError("cost");
				else {
					encode = midlet.EncodeConnection("source1="+source.routeArray[0]+"&source2="+source.routeArray[1]+"&dest1="+source.routeArray[2]+
										"&dest2="+source.routeArray[3]+"&time="+source.routeArray[4]+"&money="+source.routeArray[5]+"&distance="+source.routeArray[6]);
					serverURL = "http://localhost:8080/Server_RouteResponse.jsp?"+encode;
					System.out.println(serverURL);
					result = midlet.goConnect(serverURL);
					result = result.trim();
					System.out.println(result);
					midlet.goResponse(result,1);
				}
			}
			catch(IOException e) {
			}
		}
		if(c == Back)
			midlet.goSearchdest();
	}
}