<jsp:useBean id="Route1" class="TrafficReport.routing" />
<%
	String reqsource1 = request.getParameter("source1");
	String reqsource2 = request.getParameter("source2");
	String reqdest1 = request.getParameter("dest1");
	String reqdest2 = request.getParameter("dest2");
	String reqtime = request.getParameter("time");
	String reqmoney = request.getParameter("money");
	String reqdistance = request.getParameter("distance");
	String res = new String();
	String res1 = new String();
	String res2 = new String();
	String res3 = new String();
	String res4 = new String();
	//array[0]=time;array[1]=money;array[2]=distance
	double fact1[] = new double[3];
	double fact2[] = new double[3];
	double fact3[] = new double[3];
	double fact4[] = new double[3];
	double comparetime[] = new double[4];
	double comparemoney[] = new double[4];
	double comparedistance[] = new double[4];
	double temptime = 99999.99;
	double tempmoney = 99999.99;
	double tempdistance = 9999999.99;
	int count = 0;
	int path_time = 0;
	int path_money = 0;
	int path_distance = 0;
	//---------------------First Sending---------------------
	Route1.setRoute(reqsource1,reqdest1,reqmoney,reqtime,reqdistance);
	res1 = Route1.getRoute();
	res1 = res1.trim();
	fact1 = Route1.getFactor();
	if(res1.equals("Error")) {
		fact1[0] = 99999.99;		
		fact1[1] = 99999.99;		
		fact1[2] = 9999999.99;		
	}
	count = 1;
	comparetime[0] = fact1[0];
	comparemoney[0] = fact1[1];
	comparedistance[0] = fact1[2];
	System.out.println(res1);
	System.out.println(fact1[0]);
	System.out.println(fact1[1]);
	System.out.println(fact1[2]);
	if((!reqsource2.equals("null"))||(!reqdest2.equals("null"))) {
	//---------------------Second Sending--------------------	
		if(reqsource2.equals("null"))
			Route1.setRoute(reqsource1,reqdest2,reqmoney,reqtime,reqdistance);
		else if(reqdest2.equals("null"))
			Route1.setRoute(reqsource2,reqdest1,reqmoney,reqtime,reqdistance);
		res2 = Route1.getRoute();
		res2 = res2.trim();
		fact2 = Route1.getFactor();
		if(res2.equals("Error")) {
			fact2[0] = 99999.99;		
			fact2[1] = 99999.99;		
			fact2[2] = 9999999.99;
		}
		count = 2;
		comparetime[1] = fact2[0];
		comparemoney[1] = fact2[1];
		comparedistance[1] = fact2[2];
		System.out.println(res2);
		System.out.println(fact2[0]);
		System.out.println(fact2[1]);
		System.out.println(fact2[2]);
	//---------------------Third Sending----------------------
		if((!reqsource2.equals("null"))&&(!reqdest2.equals("null"))) {	
			Route1.setRoute(reqsource2,reqdest1,reqmoney,reqtime,reqdistance);
			res3 = Route1.getRoute();
			res3 = res3.trim();
			fact3 = Route1.getFactor();
			if(fact3.equals("Error")){
				fact3[0] = 99999.99;		
				fact3[1] = 99999.99;		
				fact3[2] = 9999999.99;
			}
			count = 3;
			comparetime[2] = fact3[0];
			comparemoney[2] = fact3[1];
			comparedistance[2] = fact3[2];
			System.out.println(res3);
			System.out.println(fact3[0]);	
			System.out.println(fact3[1]);	
			System.out.println(fact3[2]);		 				
		//---------------------Fourth Sending---------------------
			Route1.setRoute(reqsource2,reqdest2,reqmoney,reqtime,reqdistance);
			res4 = Route1.getRoute();
			res4 = res4.trim();
			fact4 = Route1.getFactor();
			if(fact4.equals("Error")){
				fact4[0] = 99999.99;		
				fact4[1] = 99999.99;		
				fact4[2] = 9999999.99;
			}
			count = 4;
			comparetime[3] = fact4[0];
			comparemoney[3] = fact4[1];
			comparedistance[3] = fact4[2];
			System.out.println(res4);
			System.out.println(fact4[0]);
			System.out.println(fact4[1]);	
			System.out.println(fact4[2]);		
		}
	}
	//---------------------Consideration----------------------
	//consider with factor's priority so we give the priority of money the first,priority of time is second
	//and priority of distance the last 
	for(int i=0;i<count;i++){
		if(comparetime[i] <= temptime){
			temptime = comparetime[i];
			path_time = i;
		}
	}
	System.out.println(temptime);
	for(int j=0;j<count;j++){
		if(comparemoney[j] <= tempmoney){
			tempmoney = comparemoney[j];
			path_money = j;
		}
	}
	System.out.println(tempmoney);
	for(int k=0;k<count;k++) {
		if(comparedistance[k] <= tempdistance) {
			tempdistance = comparedistance[k];
			path_distance = k;
		}
	}
	System.out.println(tempdistance);
	System.out.println(reqtime);
	System.out.println(reqmoney);
	System.out.println(reqdistance);	
	if(((reqtime.equals("y"))&&(reqmoney.equals("n"))&&(reqdistance.equals("n")))||
	((reqtime.equals("y"))&&(reqmoney.equals("n"))&&(reqdistance.equals("y")))){	
		System.out.println(path_time);
		if(path_time == 0)
			out.println(res1+",time="+fact1[0]+",money="+fact1[1]+",distance="+fact1[2]);
		else if(path_time == 1)
			out.println(res2+",time="+fact2[0]+",money="+fact2[1]+",distance="+fact2[2]);
		else if(path_time == 2)
			out.println(res3+",time="+fact3[0]+",money="+fact3[1]+",distance="+fact3[2]);
		else if(path_time == 3)
			out.println(res4+",time="+fact4[0]+",money="+fact4[1]+",distance="+fact4[2]);
	}
	else if(((reqtime.equals("n"))&&(reqmoney.equals("y"))&&(reqdistance.equals("n")))||
	((reqtime.equals("n"))&&(reqmoney.equals("y"))&&(reqdistance.equals("y")))||
	((reqtime.equals("y"))&&(reqmoney.equals("y"))&&(reqdistance.equals("n")))||
	((reqtime.equals("y"))&&(reqmoney.equals("y"))&&(reqdistance.equals("y")))||
	((reqtime.equals("n"))&&(reqmoney.equals("n"))&&(reqdistance.equals("n")))){
		System.out.println(path_money);
		if(path_money == 0)
			out.println(res1+",time="+fact1[0]+",money="+fact1[1]+",distance="+fact1[2]);
		else if(path_money == 1)
			out.println(res2+",time="+fact2[0]+",money="+fact2[1]+",distance="+fact2[2]);
		else if(path_money == 2)
			out.println(res3+",time="+fact3[0]+",money="+fact3[1]+",distance="+fact3[2]);
		else if(path_money == 3)
			out.println(res4+",time="+fact4[0]+",money="+fact4[1]+",distance="+fact4[2]);
	}
	else if((reqtime.equals("n"))&&(reqmoney.equals("n"))&&(reqdistance.equals("y"))){
		System.out.println(path_distance);
		if(path_distance == 0)
			out.println(res1+",time="+fact1[0]+",money="+fact1[1]+",distance="+fact1[2]);
		else if(path_distance == 1)
			out.println(res2+",time="+fact2[0]+",money="+fact2[1]+",distance="+fact2[2]);
		else if(path_distance == 2)
			out.println(res3+",time="+fact3[0]+",money="+fact3[1]+",distance="+fact3[2]);
		else if(path_distance == 3)
			out.println(res4+",time="+fact3[0]+",money="+fact3[1]+",distance="+fact4[2]);
	}
%>	



