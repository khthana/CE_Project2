import javax.microedition.lcdui.*;
import java.io.*;

public class LoginScreen extends Form implements CommandListener {
	
	public static String usr_pss = new String();
	private TrafficReport midlet;
	private UserScreen usr;
	private TextField userField, passField;
	private String serverURL = new String();
	private String temp0 = new String();
	private String temp1 = new String();
	private String output = new String();
	private Command Login, Back;

	LoginScreen(TrafficReport midlet) {
		super("LOGIN");
		this.midlet = midlet;
		userField = new TextField("Username:","",20,TextField.ANY);
		append(userField);
		passField = new TextField("Password:","",20,TextField.PASSWORD);
		append(passField);
		ItemStateListener listener = new ItemStateListener()
		{
			public void itemStateChanged(Item item)
			{
				temp0 = userField.getString();
				temp1 = passField.getString();
			}
		};
		Login = new Command("Login",Command.SCREEN,0);
		addCommand(Login);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();

		if(c == Login) {
			try {
				usr.userStatus = true;
				encode = midlet.EncodeConnection("username="+temp0+"&password="+temp1);
				serverURL =  "http://localhost:8080/Server_Authen.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.trim();
				if(result.equals( "ok")) {
					usr_pss = encode; // usr_pass store username and password again to member get informations
					midlet.goMember();
				}
				else
					midlet.goError("log");
			}
			catch (IOException e) {
			}
		}
		if(c == Back)
			midlet.goUser();
	}
}