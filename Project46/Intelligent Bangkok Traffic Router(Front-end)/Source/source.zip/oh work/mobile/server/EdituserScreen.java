import javax.microedition.lcdui.*;

public class EdituserScreen extends Form implements CommandListener {
	
	private TrafficReport midlet;
	private MemberScreen mem;
	private EditdistrictScreen distr;
	private TextField passField,confField,nameField,emailField,addrField,mobilField,mousrField,mopassField;
	private ChoiceGroup provChoice;
	private StringItem usr;
	private String[] pmet = new String[8];
	private Command Next, Back;

	EdituserScreen(TrafficReport midlet) {
		super("EDIT USER");
		this.midlet = midlet;
		usr = new StringItem("USERNAME: "+mem.infoList[0],"");
		append(usr);
		passField = new TextField("Password:",mem.infoList[1],20,TextField.PASSWORD);
		append(passField);
		confField = new TextField("Confirm:","",20,TextField.PASSWORD);
		append(confField);
		nameField = new TextField("Name:",mem.infoList[2],50,TextField.ANY);
		append(nameField);
		emailField = new TextField("Email:",mem.infoList[3],50,TextField.ANY);
		append(emailField);
		addrField = new TextField("Addressl:",mem.infoList[5],100,TextField.ANY);
		append(addrField);
		mobilField = new TextField("Mobile No:",mem.infoList[6],9,TextField.NUMERIC);
		append(mobilField);
		provChoice = new ChoiceGroup("Provider:",List.EXCLUSIVE);
		provChoice.append("DTAC",null);
		provChoice.append("AIS",null);
		provChoice.append("ORANGE",null);
		provChoice.append("HUTCH",null);
		if(mem.infoList[7].equals("DTAC")) 
			provChoice.setSelectedIndex(0,true);
		else if(mem.infoList[7].equals("AIS")) 
			provChoice.setSelectedIndex(1,true);
		else if(mem.infoList[7].equals("ORANGE")) 
			provChoice.setSelectedIndex(2,true);
		else if(mem.infoList[7].equals("HUTCH")) 
			provChoice.setSelectedIndex(3,true);
		append(provChoice);
		mousrField = new TextField("Mobile User:",mem.infoList[8],20,TextField.ANY);
		append(mousrField);
		mopassField = new TextField("Mobile Password:",mem.infoList[9],20,TextField.PASSWORD);
		append(mopassField);
		ItemStateListener listener = new ItemStateListener() {
			public void itemStateChanged(Item item) {
				pmet[0] = passField.getString();
				pmet[1] = confField.getString();
				pmet[2] = nameField.getString();
				pmet[3] = emailField.getString();
				pmet[4] = addrField.getString();
				pmet[5] = mobilField.getString();
				pmet[6] = mousrField.getString();	
				pmet[7] = mopassField.getString();
			}
		};
		Next = new Command("Next",Command.SCREEN,0);
		addCommand(Next);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		int n;

		if(c == Next) {
			if((pmet[0] == null)&&(pmet[1] == null))
				midlet.goError("edit");
			else if(!(pmet[0].equals(pmet[1])))
				midlet.goError("edit");
			else {
				n = provChoice.getSelectedIndex();
				mem.infoList[1] = pmet[1];
				mem.infoList[2] = pmet[2];
				mem.infoList[3] = pmet[3];
				mem.infoList[5] = pmet[4];
				mem.infoList[6] = pmet[5];
				mem.infoList[7] = provChoice.getString(n);
				mem.infoList[8] = pmet[6];
				mem.infoList[9] = pmet[7];
				distr.distrList[0] = mem.infoList[4]; 
				midlet.goEditdistrict();
			}
		}
		if(c == Back) {
			midlet.goMember();
		}
	}
}