import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

public class TrafficReport extends MIDlet {

	public TrafficReport() {
	}
	//---------------------------MIDlet------------------------------------------------------------------------//
	public void startApp() {
		goUser();
	}
	public void pauseApp() {
	}
	public void destroyApp(boolean unconditional) {
		//-----------------------Clear district list--------------------------------------------------------//
		EditdistrictScreen distr = new EditdistrictScreen(this);
		for(int l=0;l<50;l++) 
			distr.distrList[l] = null;
		//-----------------------Claear area list-------------------------------------------------------------//
		ReportareaScreen report = new ReportareaScreen(this);
		for(int l=0;l<50;l++) 
			report.areaList[l] = null;
	}
	//---------------------------All Functions--------------------------------------------------------------------------------//
	//-------------------------------User Part-----------------------------------------------------------------------------------//
	public void goUser() {
		UserScreen User = new UserScreen(this);
		Display.getDisplay(this).setCurrent(User);
	}
	public void goLogin() {
		LoginScreen Login = new LoginScreen(this); 
		Display.getDisplay(this).setCurrent(Login);
	}
	public void goMember() {
		try{
			LoginScreen log = new LoginScreen(this);
			String result = new String();
			result = goConnect("http://localhost:8080/Server_EditSearch.jsp?"+log.usr_pss);
			result = result.substring(2,result.length()-1);
			MemberScreen Mem = new MemberScreen(this,result); 
			Display.getDisplay(this).setCurrent(Mem);
		}
		catch(IOException e) {
		}
	}
	public void goNonmember() {
		NonmemberScreen Nonmem = new NonmemberScreen(this);
		Display.getDisplay(this).setCurrent(Nonmem);
	}
	//------------------------------------Service Part------------------------------------------------------------------------------//
	//----------------------------------All Search Route Functions-----------------------------------------------------//
	public void goSearchsource() {
		SearchsourceScreen source = new SearchsourceScreen(this);
		Display.getDisplay(this).setCurrent(source);
	}
	public void goSearchdest() {
		SearchdestScreen dest = new SearchdestScreen(this);
		Display.getDisplay(this).setCurrent(dest);
	}
	public void goCost() {
		CostScreen cost = new CostScreen(this);
		Display.getDisplay(this).setCurrent(cost);
	}
	//----------------------------------All Report Area Functions--------------------------------------------------------//
	public void goReport() {
		ReportareaScreen report = new ReportareaScreen(this);
		Display.getDisplay(this).setCurrent(report);
	}
	public void goRange() {
		ReportrangeScreen range = new ReportrangeScreen(this);
		Display.getDisplay(this).setCurrent(range);
	}
	//-------------------------------------Response function getting input from route and report---------------------//
	public void goResponse(String input,int flag) {
		ResponseScreen res = new ResponseScreen(this,input,flag);
		Display.getDisplay(this).setCurrent(res);
	}
	//--------------------------------All Edit Functions------------------------------------------------------------------------//
	public void goEdituser() {
			EdituserScreen user = new EdituserScreen(this);
			Display.getDisplay(this).setCurrent(user);
	}
	public void goEditdistrict() {				
		EditdistrictScreen distr = new EditdistrictScreen(this);
		for(int l=0;l<50;l++) 
			distr.distrList[l] = null;
		Display.getDisplay(this).setCurrent(distr);
	}
	public void goEditok() {
		try{
			Alert Edok =  new Alert("SUCCESS","All of your member information have been updated",null,AlertType.INFO);
			Edok.setTimeout(5000);
			LoginScreen log = new LoginScreen(this);
			String result = new String();
			result = goConnect("http://localhost:8080/Server_EditSearch.jsp?"+log.usr_pss);
			result = result.substring(2,result.length()-1);
			MemberScreen memok = new MemberScreen(this,result);
			Display.getDisplay(this).setCurrent(Edok,memok);
		}
		catch (IOException e){
		}
	}
	//----------------------------------------------Errors-----------------------------------------------------------------------------------//
	public void goError(String flag) {
		Alert Err =  new Alert("ERROR");
		Err.setTimeout(5000);
		if(flag.equals("log")) { 
			Err.setString("Username or Password is not correct!!!");
			LoginScreen errLog = new LoginScreen(this); 
			Display.getDisplay(this).setCurrent(Err,errLog);
		}
		else if(flag.equals("edit")) {
			try{
				Err.setString("Some informations are not correct!!!");
				LoginScreen log = new LoginScreen(this);
				String result = new String(); 
				result = goConnect("http://localhost:8080/Server_EditSearch.jsp?"+log.usr_pss);
				result = result.substring(2,result.length()-1);
				EdituserScreen errEdit = new EdituserScreen(this);
				Display.getDisplay(this).setCurrent(Err,errEdit);
			}
			catch(IOException e) {
			}
		}
		else	if(flag.equals("report")) { 
			Err.setString("Can't Find the Range or Report information!!!");
			ReportareaScreen errReport = new ReportareaScreen(this); 
			Display.getDisplay(this).setCurrent(Err,errReport);
		}
		else	if(flag.equals("cost")) { 
			Err.setString("Source and Destination is same!!!");
			goSearchsource();
		}
	}
	//-------------------------------------------------------Http Connection---------------------------------------------------------------------//
	public String goConnect(String input) throws IOException
	{
		int ch;
		String output = new String();
		HttpConnection hc = (HttpConnection)Connector.open(input);
		InputStream is = hc.openInputStream();		
		while ((ch = is.read()) != -1)
		{
			output = output + (char)ch;
		}
		is.close();
		hc.close();
		return output;
	}
	//--------------------------------------------------MIDlet Encode string connection----------------------------------------------------//
	public String EncodeConnection(String input) {
		String output = new String();
		output = input;
		output = output.replace((char)32,'+');
		return output;
	}
}