import javax.microedition.lcdui.*;
import java.io.*;

public class EditdistrictScreen extends Form implements CommandListener {
	
	public static String[] distrList = new String[50];
	private TrafficReport midlet;
	private MemberScreen mem;
	private LoginScreen log;
	private ChoiceGroup distrChoice;
	private TextField searchField; 
	private String temp = new String();
	private String serverURL = new String();
	private StringItem user;
	private boolean noedit;
	private int j = 0;
	private int k = 0;
	private int flag = 0;
	private Command Edit,Search,Back;
	
	EditdistrictScreen(TrafficReport midlet) {
		super("EDIT DISTRICT");
		this.midlet = midlet;
		user = new StringItem("USERNAME: "+mem.infoList[0],"");
		append(user);
		searchField = new TextField("Search District:","",30,TextField.ANY);
		append(searchField);
		distrChoice = new ChoiceGroup("District Choice:",List.EXCLUSIVE);
		if(distrList[0] != null) {
			for(int i=0;i<50;i++) {
				if(distrList[i] != null) 
					distrChoice.append(distrList[i],null);
				else
					i = 50;
			}
		}
		append(distrChoice);	
		ItemStateListener listener = new ItemStateListener() {
			public void itemStateChanged(Item item)
			{
				temp = searchField.getString();
				flag = 1;
			}
		};
		Edit = new Command("Edit",Command.SCREEN,0);
		addCommand(Edit);	
		Search = new Command("Search",Command.SCREEN,0);
		addCommand(Search);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();
		int n;		
	
		if(c == Edit) {
			try{
				n = distrChoice.getSelectedIndex();
				mem.infoList[4] = distrChoice.getString(n);
				encode = midlet.EncodeConnection("user="+mem.infoList[0]+"&passw="+mem.infoList[1]+"&nam="+mem.infoList[2]+"&ema="+mem.infoList[3]
					+"&dist="+mem.infoList[4]+"&add="+mem.infoList[5]+"&mobile="+mem.infoList[6]+"&pro="+mem.infoList[7]+"&mousr="+mem.infoList[8]+"&mopass="+mem.infoList[9]);
				serverURL = "http://localhost:8080/Server_EditUpdate.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.trim();
				if(result.equals("ok")) {
					log.usr_pss = midlet.EncodeConnection("username="+mem.infoList[0]+"&password="+mem.infoList[1]);
					midlet.goEditok();
				}
				else
					midlet.goError("edit"); 
			}
			catch(IOException e) {
			}
		}
		if(c == Search) {
			try{
				if((flag == 1)||(temp.charAt(0) == (char)32)) {
					encode = midlet.EncodeConnection("area="+temp);
					serverURL = "http://localhost:8080/Server_AreaSearch.jsp?"+encode;
					result = midlet.goConnect(serverURL);
					result = result.substring(4,result.length()-1);
					System.out.println(result);
					getdistrList(result);
					midlet.goEditdistrict();
				}
			}
			catch (IOException e) {
			}
		}
		if(c == Back) 
			midlet.goEdituser();
	}
	public void getdistrList(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					distrList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					distrList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
			for(int l=k+1;l<50;l++) 
				distrList[l] = null;
		}
	}
}