<%@ page import="java.sql.*" %>
<%
	String requser = request.getParameter("username");
	String reqpass = request.getParameter("password");
	
	try
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		ResultSet myresult = stmt.executeQuery("SELECT count(*) as num FROM member WHERE usr='"+requser+"' and pass='"+reqpass+"'");
		while(myresult.next()) {
			if(myresult.getInt("num")==1)
				out.println("ok");
			else
				out.println("no");
		}
		myresult.close();
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e) {
		out.println("Can't find database driver");
	}
	catch(SQLException e) {
		out.println("Can't find database");
	}
%>