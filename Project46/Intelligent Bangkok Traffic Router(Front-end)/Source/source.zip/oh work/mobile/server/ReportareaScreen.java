import javax.microedition.lcdui.*;
import java.io.*;

public class ReportareaScreen extends Form implements CommandListener {
	
	public static String[] areaList = new String[50];
	private TrafficReport midlet;
	private UserScreen usr;
	private	MemberScreen mem;
	private ReportrangeScreen range;
	private TextField searchField;
	private ChoiceGroup areaChoice;
	private String temp = new String();
	private String serverURL = new String();
	private int j = 0;
	private int k = 0;
	private int flag = 0;
	private boolean change;
	private Command Next,Search,Back;

	ReportareaScreen(TrafficReport midlet) {
		super("SELECT AREA");
		this.midlet = midlet;
		searchField = new TextField("Search District","",30,TextField.ANY);
		append(searchField);
		areaChoice = new ChoiceGroup("District Choice",List.EXCLUSIVE);
		if(areaList[0] != null) {
			for(int i=0;i<50;i++) {
				if(areaList[i] != null) 
					areaChoice.append(areaList[i],null);
				else
					i = 50;
			}
		}
		append(areaChoice);	
		ItemStateListener listener = new ItemStateListener() {
			public void itemStateChanged(Item item)
			{
				temp = searchField.getString();
				flag = 1;
			}
		};
		Next = new Command("Next",Command.SCREEN,0);
		addCommand(Next);	
		Search = new Command("Search",Command.SCREEN,0);
		addCommand(Search);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();
		int n;		
	
		if(c == Next) {
			try{
				n = areaChoice.getSelectedIndex();
				encode = midlet.EncodeConnection("area="+areaChoice.getString(n));
				serverURL = "http://localhost:8080/Server_RangeSearch.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.substring(4,result.length()-1);
				if(result.charAt(0) == '$') 
					midlet.goError("report");
				else {
					getRangelist(result);
					midlet.goRange();
				}
			}
			catch(IOException e) {
			}
		}
		if(c == Search) {
			try{
				if((flag == 1)||(temp.charAt(0) == (char)32)) {
					encode = midlet.EncodeConnection("area="+temp);
					serverURL = "http://localhost:8080/Server_AreaSearch.jsp?"+encode;
					result = midlet.goConnect(serverURL);
					result = result.substring(4,result.length()-1);
					getReportlist(result);
					midlet.goReport();
				}
			}
			catch (IOException e) {
			}
		}
		if(c == Back) {
			if(usr.userStatus)
				midlet.goMember();
			else
				midlet.goNonmember();
		}
	}
	public void getReportlist(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					areaList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					areaList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
			for(int l=k+1;l<50;l++) 
				areaList[l] = null;
		}
	}
	public void getRangelist(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					range.rangeList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					range.rangeList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
			for(int l=k+1;l<50;l++) 
				range.rangeList[l] = null;
		}
	}
}