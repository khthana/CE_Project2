import javax.microedition.lcdui.*;

public class MemberScreen extends List implements CommandListener {
	
	public static String[] infoList = new String[14];
	private TrafficReport midlet;
	private SearchsourceScreen source;
	private SearchdestScreen dest;
	private ReportareaScreen report;
	private Command Select;	
	private int j = 0;
	private int k = 0;

	MemberScreen(TrafficReport midlet, String input) {
		super("SERVICE",List.IMPLICIT);
		this.midlet = midlet;
		getinfoList(input);
		append("Search Route",null);
		append("Report Area",null);
		append("Edit Personal",null);
		Select = new Command("Select",Command.SCREEN,0);
		addCommand(Select);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		int n;

		if(c == Select)	{
			n = getSelectedIndex();
			if(n == 0) {
				source.sourceList[0] = infoList[10]; //set source list for member
				source.sourceList[1] = infoList[12];
				dest.destList[0] = infoList[11]; //set destination list for member
				dest.destList[1] = infoList[13];
				midlet.goSearchsource();
			}
			if(n == 1) {
				report.areaList[0] = infoList[4]; //set area list for member
				midlet.goReport();
			}
			if(n == 2) 
				midlet.goEdituser();
		}
	}
	public void getinfoList(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1)=='$') {
					infoList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					infoList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
		} 
	}
}