import javax.microedition.lcdui.*;
import java.io.*;

public class SearchdestScreen extends Form implements CommandListener {
	
	public static String[] destList = new String[50];
	private TrafficReport midlet;
	private SearchsourceScreen source;
	private TextField searchField;
	private ChoiceGroup destChoice;
	private String temp = new String();
	private String serverURL = new String();
	private int j = 0;
	private	int k = 0;
	private int flag = 0;
		
	private Command Next,Search,Back;
	
	SearchdestScreen(TrafficReport midlet) {
		super("SELECT DESTINATION");
		this.midlet = midlet;
		searchField = new TextField("Search Destination:","",30,TextField.ANY);
		append(searchField);
		destChoice = new ChoiceGroup("Destination Choice:",List.EXCLUSIVE);
		if(destList[0] != null) {
			for(int i=0;i<50;i++) {
				if(destList[i] != null) 
					destChoice.append(destList[i],null);
				else
					i = 50;
			}
		}
		append(destChoice);	
		ItemStateListener listener = new ItemStateListener() {
			public void itemStateChanged(Item item)
			{
				temp = searchField.getString();
				flag = 1;
			}
		};
		Next = new Command("Next",Command.SCREEN,0);
		addCommand(Next);	
		Search = new Command("Search",Command.SCREEN,0);
		addCommand(Search);	
		Back = new Command("Back",Command.SCREEN,0);
		addCommand(Back);
		setCommandListener(this);
		setItemStateListener(listener);
	}
	public void commandAction(Command c,Displayable d) {
		String result = new String();
		String encode = new String();
		int n;		
	
		if(c == Next) {
			try{
				n = destChoice.getSelectedIndex();
				encode = midlet.EncodeConnection("search="+destChoice.getString(n));
				serverURL = "http://localhost:8080/Server_RouteJunction.jsp?"+encode;
				result = midlet.goConnect(serverURL);
				result = result.substring(2,result.length()-1);
				getrouteArray(result);
				midlet.goCost(); 
			}
			catch(IOException e) {
			}
		}
		if(c == Search) {
			try{
				if((flag == 1)||(temp.charAt(0) == (char)32)) {
					encode = midlet.EncodeConnection("search="+temp);
					serverURL = "http://localhost:8080/Server_RouteSearch.jsp?"+encode;
					result = midlet.goConnect(serverURL);
					result = result.substring(4,result.length()-1);
					getdestList(result);
					midlet.goSearchdest();			
				}
			}
			catch (IOException e) {
			}
		}
		if(c == Back) 
			midlet.goSearchsource();
	}
	public void getdestList(String input) {
		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					destList[k] = input.substring(j,i);	
					i = input.length();
				}
				else {
					destList[k] = input.substring(j,i);
					k++;
					i++;
					j = i; 
				}
			}
			for(int l=k+1;l<50;l++) 
				destList[l] = null;
		}
	}
	public void getrouteArray(String input) {
		int x = 2;

		for(int i=0;i<input.length();i++) {
			if(input.charAt(i) == ',') {
				if(input.charAt(i+1) == '$') {
					source.routeArray[x] = input.substring(j,i);	
					i = input.length();
				}
				else {
					source.routeArray[x] = input.substring(j,i);
					x++;
					i++;
					j = i; 
				}
			}
		}
	}
}