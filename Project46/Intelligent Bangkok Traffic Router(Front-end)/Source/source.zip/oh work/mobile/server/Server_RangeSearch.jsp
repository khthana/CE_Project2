<%@ page import="java.sql.*" %>
<%
	String reqarea = request.getParameter("area");
	String output = "#,";
	
	try{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		ResultSet myresult = stmt.executeQuery("SELECT * FROM report WHERE district='"+reqarea+"'");
		
		while(myresult.next()){
			output = output + myresult.getString("street") + ',';
		}
		output = output + "$";
		out.println(output);
		myresult.close();
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e)
	{
		out.println("Can't find database driver");
	}
	catch(SQLException e)
	{
		out.println("Can't find database");
	}
%>