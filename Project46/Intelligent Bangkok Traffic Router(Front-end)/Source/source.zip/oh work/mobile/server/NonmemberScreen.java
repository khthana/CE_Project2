import javax.microedition.lcdui.*;

class NonmemberScreen extends List implements CommandListener {
	
	private TrafficReport midlet;
	private Command Select;
	
	NonmemberScreen(TrafficReport midlet) {
		super("SERVICE",List.IMPLICIT);
		this.midlet = midlet;
		append("Search Route",null);
		append("Report Area",null);
		Select = new Command("Select",Command.SCREEN,0);
		addCommand(Select);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		int n;

		if(c == Select)	{
			n = getSelectedIndex();
			if(n == 0)
				midlet.goSearchsource();
			if(n == 1) 
				midlet.goReport();
		}
	}
}