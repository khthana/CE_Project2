import javax.microedition.lcdui.*;

public class UserScreen extends List implements CommandListener {
	
	public static boolean userStatus;
	private TrafficReport midlet;
	private Command Select;

	UserScreen(TrafficReport midlet) {
		super("USER",List.IMPLICIT); // page title
		this.midlet = midlet;
		append("Member",null); // list choice 1
		append("Non Memeber",null); // list choice 2
		Select = new Command("Select",Command.SCREEN,0); // only one command in this page
		addCommand(Select);
		setCommandListener(this);
	}
	public void commandAction(Command c,Displayable d) {
		int n;

		if(c == Select)	{	//detect command select
			n = getSelectedIndex();
			if(n == 0) // ok you are member then go to login first
				midlet.goLogin();
			if(n == 1) { //ok you are non member
				userStatus = false;
				midlet.goNonmember();
			}
		}
	}
}
