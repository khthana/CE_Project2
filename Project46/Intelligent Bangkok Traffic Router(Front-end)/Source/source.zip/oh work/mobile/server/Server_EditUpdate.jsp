<%@ page import="java.sql.*" %>
<%
	String requser = request.getParameter("user");
	String reqpass = request.getParameter("passw");
	String reqname = request.getParameter("nam");
	String reqemail = request.getParameter("ema");
	String reqdistr = request.getParameter("dist");
	String reqaddr = request.getParameter("add");
	String reqmob = request.getParameter("mobile");
	String reqprov = request.getParameter("pro");
	String reqmousr = request.getParameter("mousr");
	String reqmopss = request.getParameter("mopass");

	try
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/memberdb?user=root&password=00000147");
		Statement stmt = mycon.createStatement();
		String sql = "UPDATE member SET usr='"+requser+"',pass='"+reqpass+"',name='"+reqname+"',email='"+reqemail+"',district='"+reqdistr+"',address='"+reqaddr+"',mobile='"+reqmob+"',provider='"+reqprov+"',mo_usr='"+reqmousr+"',mo_pass='"+reqmopss+"' WHERE usr='"+requser+"'"; 
		int result = stmt.executeUpdate(sql);
		if(result == 1)
			out.println("ok");
		else 
			out.println("no");	
		stmt.close();
		mycon.close();
	}
	catch(ClassNotFoundException e)
	{
		out.println("Can't find database driver");
	}
	catch(SQLException e)
	{
		out.println("Can't find database");
	}
%>