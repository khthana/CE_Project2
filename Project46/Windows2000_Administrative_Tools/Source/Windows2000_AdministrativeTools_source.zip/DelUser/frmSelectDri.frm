VERSION 5.00
Begin VB.Form frmSelect 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Select option"
   ClientHeight    =   6945
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   2790
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6945
   ScaleWidth      =   2790
   StartUpPosition =   1  'CenterOwner
   Begin VB.CheckBox chkDelProfile 
      Caption         =   "Delete User's Profile"
      Height          =   315
      Left            =   120
      TabIndex        =   8
      Top             =   1200
      Width           =   2415
   End
   Begin VB.CheckBox chkDelLoginScript 
      Caption         =   "Delete User'sLogon Script"
      Height          =   315
      Left            =   120
      TabIndex        =   7
      Top             =   720
      Width           =   2295
   End
   Begin VB.CheckBox chkDelOwner 
      Caption         =   "Delete Owner Files"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   1680
      Width           =   2295
   End
   Begin VB.CheckBox chkDelHome 
      Caption         =   "Delete Home Directory"
      Height          =   315
      Left            =   120
      TabIndex        =   5
      Top             =   240
      Width           =   2055
   End
   Begin VB.TextBox txtDispPath 
      Alignment       =   2  'Center
      BackColor       =   &H80000000&
      ForeColor       =   &H00800000&
      Height          =   300
      Left            =   480
      Locked          =   -1  'True
      TabIndex        =   4
      Text            =   "Owner files Directory "
      Top             =   5930
      Width           =   2175
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   1440
      TabIndex        =   3
      Top             =   6480
      Width           =   1215
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   6480
      Width           =   1215
   End
   Begin VB.DirListBox dirFolder 
      Enabled         =   0   'False
      Height          =   3465
      Left            =   480
      TabIndex        =   1
      Top             =   2400
      Width           =   2175
   End
   Begin VB.DriveListBox drvDrive 
      Enabled         =   0   'False
      Height          =   315
      Left            =   480
      TabIndex        =   0
      Top             =   2040
      Width           =   2175
   End
   Begin VB.Line Line1 
      X1              =   2880
      X2              =   0
      Y1              =   6360
      Y2              =   6360
   End
End
Attribute VB_Name = "frmSelect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub chkDelOwner_Click()
    If chkDelOwner.Value = 1 Then
        dirFolder.Enabled = True
        drvDrive.Enabled = True
    Else
        dirFolder.Enabled = False
        drvDrive.Enabled = False
    End If
End Sub

Private Sub cmdCancel_Click()
    txtDispPath.Text = ""
    Unload frmSelect
    frmDelUser.Enabled = True
End Sub

Private Sub cmdOK_Click()
    frmSelect.Hide
    frmDelUser.Enabled = True
    frmDelUser.DelFile
    Unload frmSelect
End Sub

Private Sub dirFolder_Change()
    'Set the folder displayed in the txtDispPath
    'control to the user's selection.
    txtDispPath.Alignment = 0
    txtDispPath.Text = dirFolder.Path
End Sub

Private Sub drvDrive_Change()
    'Set the drive displayed in the DirListBox
    'control to the user's selection.
    On Error Resume Next
    dirFolder.Path = drvDrive.Drive
End Sub

