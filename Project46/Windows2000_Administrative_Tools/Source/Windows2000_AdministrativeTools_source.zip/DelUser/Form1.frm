VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmDelUser 
   AutoRedraw      =   -1  'True
   Caption         =   "Delete User"
   ClientHeight    =   6495
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   9600
   DrawStyle       =   6  'Inside Solid
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6495
   ScaleWidth      =   9600
   StartUpPosition =   2  'CenterScreen
   Begin MSComctlLib.ImageList ImageList3 
      Left            =   2160
      Top             =   3960
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   20
      ImageHeight     =   20
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   1
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form1.frx":030A
            Key             =   "bigUser"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ListView ListView1 
      Height          =   3105
      Left            =   2710
      TabIndex        =   2
      Top             =   240
      Width           =   6000
      _ExtentX        =   10583
      _ExtentY        =   5477
      View            =   3
      LabelEdit       =   1
      MultiSelect     =   -1  'True
      LabelWrap       =   0   'False
      HideSelection   =   0   'False
      FullRowSelect   =   -1  'True
      _Version        =   393217
      SmallIcons      =   "ImageList3"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   3
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Key             =   "cn"
         Text            =   "Name"
         Object.Width           =   5292
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Alignment       =   2
         SubItemIndex    =   1
         Key             =   "type"
         Text            =   "Type"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Alignment       =   2
         SubItemIndex    =   2
         Key             =   "description"
         Text            =   "Description"
         Object.Width           =   8819
      EndProperty
   End
   Begin ComctlLib.TreeView TreeView1 
      Height          =   3105
      Left            =   80
      TabIndex        =   1
      Top             =   240
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   5477
      _Version        =   327682
      HideSelection   =   0   'False
      Indentation     =   0
      LabelEdit       =   1
      LineStyle       =   1
      Sorted          =   -1  'True
      Style           =   7
      ImageList       =   "ImageList2"
      Appearance      =   1
   End
   Begin ComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   375
      Left            =   0
      TabIndex        =   0
      Top             =   6120
      Width           =   9600
      _ExtentX        =   16933
      _ExtentY        =   661
      Style           =   1
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   30000
      Y1              =   120
      Y2              =   120
   End
   Begin ComctlLib.ImageList ImageList2 
      Left            =   1320
      Top             =   3960
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   20
      ImageHeight     =   20
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   2
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Form1.frx":0624
            Key             =   "imgDC"
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Form1.frx":17CE
            Key             =   "imgOU"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mufile 
      Caption         =   "&File"
      NegotiatePosition=   2  'Middle
      Begin VB.Menu muExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu muEdit 
      Caption         =   "&Edit"
      NegotiatePosition=   2  'Middle
      Begin VB.Menu muDel 
         Caption         =   "Delete"
      End
   End
   Begin VB.Menu muPopup 
      Caption         =   ""
      Visible         =   0   'False
      Begin VB.Menu muPopDel 
         Caption         =   "Delete"
      End
   End
End
Attribute VB_Name = "frmDelUser"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public DC1, DC2, CN As String

Private Sub Exit_Click()
    Unload frmDelUser
End Sub

Private Sub Form_Load()
    LoadTreeview
End Sub

Private Sub Form_Resize()
    If frmDelUser.Height - 690 - 455 - TreeView1.Top > 0 And frmDelUser.Width - ListView1.Left - 170 > 0 Then
    TreeView1.Height = frmDelUser.Height - 690 - 455 - TreeView1.Top
    ListView1.Height = frmDelUser.Height - 690 - 455 - ListView1.Top
    ListView1.Width = frmDelUser.Width - ListView1.Left - 170
    End If
End Sub

Private Sub LoadTreeview()
    Dim DomainName As String
    Set objRootDSE = GetObject("LDAP://rootDSE")
    Set objSchema = GetObject("LDAP://" & objRootDSE.Get("schemaNamingContext"))
    strSchemaMaster = objSchema.Get("fSMORoleOwner")
    DomainName = FindDomainName(CStr(strSchemaMaster))
    'Config treeview
    With TreeView1
        .Sorted = True
        Set mNode = .Nodes.Add()
        .LabelEdit = False
    End With
    ' Add first node.
    With mNode
        .Text = DomainName
        .Image = "imgDC"
    End With
    Const ADS_SCOPE_SUBTREE = 2
    Set objConnection = CreateObject("ADODB.Connection")
    Set objCommand = CreateObject("ADODB.Command")
    objConnection.Provider = "ADsDSOObject"
    objConnection.Open "Active Directory Provider"
    Set objCommand.ActiveConnection = objConnection
    s = "Select Name from 'LDAP://DC=" + DC1 + ",DC=" + DC2 + "' where objectclass='organizationalUnit'"
    objCommand.CommandText = s
    objCommand.Properties("Page Size") = 1000
    objCommand.Properties("Timeout") = 30
    objCommand.Properties("Searchscope") = ADS_SCOPE_SUBTREE
    objCommand.Properties("Cache Results") = False
    Set objRecordset = objCommand.Execute
    objRecordset.MoveFirst
    Do Until objRecordset.EOF
        s = CStr(objRecordset.fields("Name").Value)
        If s <> "Domain Controllers" Then
        TreeView1.Nodes.Add 1, tvwChild, , s, "imgOU"
        End If
        objRecordset.MoveNext
    Loop
   
End Sub


Private Sub ListView1_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = 46 Then
        resp = MsgBox("Are you sure you want to delete this user", vbYesNo + vbQuestion, "Confirm")
        If resp = 6 Then
            resp = MsgBox("Do you want to delete user's profiles,home directory and owner files", vbYesNo + vbQuestion, "Delete file?")
            If resp = 6 Then
                frmSelect.Show
                frmDelUser.Enabled = False
            Else
                DelUser
                DelListItem
            End If
        End If
    End If
End Sub

Private Sub muDel_Click()
        resp = MsgBox("Are you sure you want to delete this user", vbYesNo + vbQuestion, "Confirm")
        If resp = 6 Then
            resp = MsgBox("Do you want to delete user's profiles,home directory and owner files", vbYesNo + vbQuestion, "Delete file?")
            If resp = 6 Then
                frmSelect.Show
                frmDelUser.Enabled = False
            Else
                DelUser
                DelListItem
            End If
        End If
End Sub

Private Sub TreeView1_AfterLabelEdit(Cancel As Integer, NewString As String)
    'Can not edit Label
End Sub

Private Sub TreeView1_BeforeLabelEdit(Cancel As Integer)
    Cancel = 1
End Sub

Function FindDomainName(Str1) As String
Dim i As Integer
'-----------cut string---------
i = 0
Do While s <> ","
s = Mid(Str1, Len(Str1) - i, 1)
If s = "," Then
DC2 = Right(Str1, i)
DC2 = Right(DC2, Len(DC2) - 3)
MoDC2 = DC2
End If
i = i + 1
Loop
Str1 = Left(Str1, Len(Str1) - i)
i = 0
s = ""
Do While s <> ","
s = Mid(Str1, Len(Str1) - i, 1)
If s = "," Then
DC1 = Right(Str1, i)
DC1 = Right(DC1, Len(DC1) - 3)
MoDC1 = DC1
End If
i = i + 1
Loop
'------------------------------
FindDomainName = DC1 + "." + DC2
End Function

Private Sub TreeView1_NodeClick(ByVal Node As ComctlLib.Node)
    If TreeView1.Nodes(1).Selected <> True Then
        Dim i As Integer
        For i = 2 To TreeView1.Nodes.Count
        If TreeView1.Nodes(i).Selected Then
        s = TreeView1.Nodes(i).Text
        LoadListView (s)
        End If
        Next i
    End If
End Sub

Private Sub LoadListView(NameOU As String)
    Dim s, q As String
    Dim i As Integer
    Const ADS_SCOPE_SUBTREE = 2
    
    i = 1
    s = "LDAP://OU=" + NameOU + ",DC=" + DC1 + ",DC=" + DC2
    q = "Select Name from '" + s + "' where objectCategory='user'"
    ListView1.ListItems.Clear
    Set objConnection = CreateObject("ADODB.Connection")
    Set objCommand = CreateObject("ADODB.Command")
    objConnection.Provider = "ADsDSOObject"
    objConnection.Open "Active Directory Provider"
    Set objCommand.ActiveConnection = objConnection
    objCommand.CommandText = q
    objCommand.Properties("Page Size") = 1000
    objCommand.Properties("Timeout") = 30
    objCommand.Properties("Searchscope") = ADS_SCOPE_SUBTREE
    objCommand.Properties("Cache Results") = False
    Set objRecordset = objCommand.Execute
    If Not objRecordset.EOF Then
    objRecordset.MoveFirst
    Do Until objRecordset.EOF
        q = CStr(objRecordset.fields("Name").Value)
        ListView1.ListItems.Add i, "s" + q, q, , "bigUser"
        s = "LDAP://CN=" + q + ",OU=" + NameOU + ",DC=" + DC1 + ",DC=" + DC2
        
        On Error Resume Next
        Set objUser = GetObject(s)
        objUser.GetInfo
        
        ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("type").SubItemIndex) = "User"
        ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("description").SubItemIndex) = objUser.Get("description")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("physicalDeliveryOfficeName").SubItemIndex) = objUser.Get("physicalDeliveryOfficeName")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("mail").SubItemIndex) = objUser.Get("mail")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("wWWHomePage").SubItemIndex) = objUser.Get("wWWHomePage")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("streetAddress").SubItemIndex) = objUser.Get("streetAddress")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("postOfficeBox").SubItemIndex) = objUser.Get("postOfficeBox")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("l").SubItemIndex) = objUser.Get("l")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("st").SubItemIndex) = objUser.Get("st")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("postalCode").SubItemIndex) = objUser.Get("postalCode")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("c").SubItemIndex) = objUser.Get("c")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("userPrincipalName").SubItemIndex) = objUser.Get("userPrincipalName")
        'CheckPrincipalName (i)
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("sAMAccountName").SubItemIndex) = objUser.Get("sAMAccountName")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("homePhone").SubItemIndex) = objUser.Get("homePhone")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("pager").SubItemIndex) = objUser.Get("pager")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("mobile").SubItemIndex) = objUser.Get("mobile")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("facsimileTelephoneNumber").SubItemIndex) = objUser.Get("facsimileTelephoneNumber")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("ipPhone").SubItemIndex) = objUser.Get("ipPhone")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("info").SubItemIndex) = objUser.Get("info")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("title").SubItemIndex) = q1 = objUser.Get("title")
        'ListView1.ListItems(i).SubItems(ListView1.ColumnHeaders("department").SubItemIndex) = objUser.Get("department")
        
        objRecordset.MoveNext
        i = i + 1
    Loop
    

    Else
    ListView1.ListItems.Clear


    End If
End Sub

Private Sub DelListItem()
    Dim j, k As Integer
    i = ListView1.ListItems.Count
    j = 1
    Do While j <= i
    If ListView1.ListItems(j).Selected Then
        ListView1.ListItems.Remove (j)
        j = j - 1
        i = i - 1
    End If
    j = j + 1
    Loop
End Sub



Private Sub DelOwnerFile(Path As String)
    Dim filename, Owner, Typ As String
    Dim objShell  As Shell
    Dim objFolder As Folder
    Set objFSO = CreateObject("Scripting.FileSystemObject")
    'Dim arrHeaders(13)
    'On Error GoTo Error
    'Set X = frmDelUser.objFolder.Items
    'Set y = strFileName
    Set objShell = New Shell
    Set objFolder = objShell.NameSpace(Path)
    On Error Resume Next
   For Each strFileName In objFolder.Items
        filename = objFolder.GetDetailsOf(strFileName, 0)
        Owner = objFolder.GetDetailsOf(strFileName, 8)
        Typ = objFolder.GetDetailsOf(strFileName, 2)
        '-------Set Owner
        pos = InStr(Owner, "\")
        Owner = Right(Owner, Len(Owner) - pos)
        If Owner = CN Then
            '-------Set shortcut type
            If Typ = "Shortcut" Then
                filename = filename + ".LNK"
            End If
            If Typ = "File Folder" Or Typ = "Briefcase" Then
                objFSO.DeleteFolder (Path + "\" + filename)
                StatusBar1.SimpleText = Path + "\" + filename + " was Deleted"
                StatusBar1.Refresh
            Else
                objFSO.DeleteFile (Path + "\" + filename + ".*")
                StatusBar1.SimpleText = Path + "\" + filename + " was Deleted"
                StatusBar1.Refresh
            End If
        ElseIf Typ = "File Folder" Then
            s = Right(Path, 1)
            If s <> "\" Then
                Path = Path + "\" + filename
            Else
                Path = Path + filename
            End If
            StatusBar1.SimpleText = "Searching at " + Path + filename
            StatusBar1.Refresh
            DelOwnerFile (Path)
            'pos = InStr(Path, filename)
            Path = Left(Path, Len(Path) - Len(filename) - 1)
        End If
            
        'Set objFSO = CreateObject("Scripting.FileSystemObject")
        'objFSO.DeleteFile ("C:\" + filename + ".*")
        'End If
    Next
    
'Error:
'    Exit Sub
End Sub

Public Sub DelFile()
    'Screen.MousePointer = vbHourglass
    For i = 1 To ListView1.ListItems.Count
    If ListView1.ListItems(i).Selected Then
        CN = ListView1.ListItems(i)
        Set objUser = GetObject("LDAP://ou=" + TreeView1.SelectedItem + ",dc=" + DC1 + ",dc=" + DC2)
        Set objFile = GetObject("LDAP://cn=" + ListView1.ListItems(i) + ",ou=" + TreeView1.SelectedItem + ",dc=" + DC1 + ",dc=" + DC2)
        Set objFSO = CreateObject("Scripting.FileSystemObject")
        On Error Resume Next
        objFile.GetInfo
            If frmSelect.chkDelProfile.Value = 1 Then
                StrTemp = objFile.Get("profilePath")
                objFSO.DeleteFile (StrTemp)
                objFSO.DeleteFolder (StrTemp)
            End If
            If frmSelect.chkDelLoginScript.Value = 1 Then
                StrTemp = objFile.Get("scriptPath")
                objFSO.DeleteFile (StrTemp)
                objFSO.DeleteFolder (StrTemp)
            End If
            If frmSelect.chkDelHome.Value = 1 Then
                StrTemp = objFile.Get("homeDirectory")
                objFSO.DeleteFolder (StrTemp)
            End If
            If frmSelect.chkDelOwner.Value = 1 Then
                DelOwnerFile (frmSelect.dirFolder.Path)
            End If
    End If
    Next i
    DelUser
    DelListItem
    StatusBar1.SimpleText = "Delete complete."
    'Screen.MousePointer = vbArrow
 End Sub

Private Sub DelUser()
    For i = 1 To ListView1.ListItems.Count
        If ListView1.ListItems(i).Selected Then
            Set objUser = GetObject("LDAP://ou=" + TreeView1.SelectedItem + ",dc=" + DC1 + ",dc=" + DC2)
            objUser.Delete "User", "cn=" + ListView1.ListItems(i)
        End If
    Next i
End Sub
