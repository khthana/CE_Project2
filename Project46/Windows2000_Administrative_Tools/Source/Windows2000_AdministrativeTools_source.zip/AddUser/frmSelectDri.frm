VERSION 5.00
Begin VB.Form frmSelect 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Select Directory"
   ClientHeight    =   4920
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4080
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4920
   ScaleWidth      =   4080
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox txtDispPath 
      BackColor       =   &H80000000&
      ForeColor       =   &H00800000&
      Height          =   300
      Left            =   120
      Locked          =   -1  'True
      TabIndex        =   3
      Top             =   3960
      Width           =   3855
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   375
      Left            =   2760
      TabIndex        =   2
      Top             =   4440
      Width           =   1215
   End
   Begin VB.DirListBox dirFolder 
      Height          =   3465
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   3855
   End
   Begin VB.DriveListBox drvDrive 
      Height          =   315
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   3855
   End
   Begin VB.Line Line1 
      X1              =   4080
      X2              =   0
      Y1              =   4320
      Y2              =   4320
   End
End
Attribute VB_Name = "frmSelect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdOK_Click()
    frmSelect.Hide
    frmMain.Enabled = True
    'Unload frmSelect
End Sub

Private Sub dirFolder_Change()
    'Set the folder displayed in the txtDispPath
    'control to the user's selection.
    txtDispPath.Alignment = 0
    txtDispPath.Text = dirFolder.Path
End Sub

Private Sub drvDrive_Change()
    'Set the drive displayed in the DirListBox
    'control to the user's selection.
    On Error Resume Next
    dirFolder.Path = drvDrive.Drive
End Sub

Private Sub Form_Load()
    txtDispPath.Text = dirFolder.Path
End Sub
Private Sub Form_Unload(Cancel As Integer)
frmMain.Enabled = True
frmMain.chkCreateHome.Value = 0
End Sub
