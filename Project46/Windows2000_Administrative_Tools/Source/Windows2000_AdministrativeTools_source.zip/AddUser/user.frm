VERSION 5.00
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmMain 
   Caption         =   "Adding user"
   ClientHeight    =   9990
   ClientLeft      =   3060
   ClientTop       =   645
   ClientWidth     =   9930
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   9990
   ScaleWidth      =   9930
   Begin VB.Frame Frame1 
      Caption         =   "Add users"
      Height          =   3255
      Left            =   0
      TabIndex        =   17
      Top             =   6720
      Width           =   9925
      Begin MSComCtl2.DTPicker dtpAccExpire 
         Height          =   300
         Left            =   1680
         TabIndex        =   33
         Top             =   2160
         Width           =   1815
         _ExtentX        =   3201
         _ExtentY        =   529
         _Version        =   393216
         Enabled         =   0   'False
         CalendarTitleBackColor=   -2147483647
         Format          =   22806529
         CurrentDate     =   38036
         MaxDate         =   934292
      End
      Begin VB.CheckBox chkAccExpire 
         Caption         =   "Account expires"
         Enabled         =   0   'False
         Height          =   195
         Left            =   120
         TabIndex        =   32
         Top             =   2160
         Width           =   1575
      End
      Begin VB.CheckBox chkRandompwd 
         Caption         =   "Random password"
         Enabled         =   0   'False
         Height          =   255
         Left            =   6000
         TabIndex        =   31
         Top             =   2100
         Width           =   1935
      End
      Begin VB.CheckBox chkSendMail 
         Caption         =   "Send username and password by e-mail"
         Enabled         =   0   'False
         Height          =   255
         Left            =   6000
         TabIndex        =   24
         Top             =   2440
         Width           =   3375
      End
      Begin VB.CheckBox chkCreateHome 
         Caption         =   "Create Home Directory"
         Enabled         =   0   'False
         Height          =   255
         Left            =   120
         TabIndex        =   23
         Top             =   2520
         Width           =   2055
      End
      Begin VB.ListBox LstDisplayMapping 
         Height          =   1035
         ItemData        =   "user.frx":0000
         Left            =   4080
         List            =   "user.frx":0002
         TabIndex        =   28
         Top             =   240
         Width           =   5745
      End
      Begin VB.CommandButton cmdRemove 
         Caption         =   "<<Remove"
         Enabled         =   0   'False
         Height          =   315
         Left            =   2760
         TabIndex        =   22
         Top             =   740
         Width           =   1200
      End
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Add>>"
         Enabled         =   0   'False
         Height          =   315
         Left            =   2760
         TabIndex        =   21
         Top             =   360
         Width           =   1200
      End
      Begin VB.ComboBox cmbPutIn 
         Enabled         =   0   'False
         Height          =   315
         ItemData        =   "user.frx":0004
         Left            =   960
         List            =   "user.frx":0050
         Sorted          =   -1  'True
         TabIndex        =   27
         Top             =   740
         Width           =   1695
      End
      Begin VB.ComboBox cmbColumn 
         Enabled         =   0   'False
         Height          =   315
         ItemData        =   "user.frx":016D
         Left            =   960
         List            =   "user.frx":016F
         TabIndex        =   20
         Top             =   360
         Width           =   1695
      End
      Begin VB.CommandButton cmdExecute 
         Caption         =   "Execute"
         Enabled         =   0   'False
         Height          =   375
         Left            =   8280
         TabIndex        =   19
         Top             =   2760
         Width           =   1575
      End
      Begin VB.TextBox txtOUName 
         Enabled         =   0   'False
         Height          =   315
         Left            =   1680
         TabIndex        =   18
         Top             =   1200
         Width           =   1935
      End
      Begin VB.Label Label10 
         Caption         =   "Options:"
         Height          =   255
         Left            =   120
         TabIndex        =   30
         Top             =   1800
         Width           =   735
      End
      Begin VB.Line Line1 
         X1              =   120
         X2              =   9610
         Y1              =   1680
         Y2              =   1680
      End
      Begin VB.Label Label8 
         Caption         =   "Put In:"
         Height          =   255
         Left            =   120
         TabIndex        =   29
         Top             =   720
         Width           =   615
      End
      Begin VB.Label Label2 
         Caption         =   "Column:"
         Height          =   255
         Left            =   120
         TabIndex        =   26
         Top             =   360
         Width           =   615
      End
      Begin VB.Label Labe10 
         Caption         =   "Container/OU Name:"
         Height          =   255
         Left            =   120
         TabIndex        =   25
         Top             =   1200
         Width           =   1575
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Database "
      Height          =   6735
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   9925
      Begin MSWinsockLib.Winsock Winsock1 
         Left            =   6120
         Top             =   2280
         _ExtentX        =   741
         _ExtentY        =   741
         _Version        =   393216
      End
      Begin VB.TextBox txtServerMySQL 
         Height          =   285
         Left            =   1560
         TabIndex        =   10
         Top             =   360
         Width           =   2535
      End
      Begin VB.TextBox txtDBNameMySQL 
         Height          =   285
         Left            =   1560
         TabIndex        =   9
         Top             =   720
         Width           =   2535
      End
      Begin VB.TextBox txtUserNameMySQL 
         Height          =   285
         Left            =   1560
         TabIndex        =   8
         Top             =   1080
         Width           =   2535
      End
      Begin VB.TextBox txtPasswordMySQL 
         Height          =   285
         IMEMode         =   3  'DISABLE
         Left            =   1560
         PasswordChar    =   "*"
         TabIndex        =   7
         Top             =   1440
         Width           =   2535
      End
      Begin VB.CommandButton cmdConnectDBmysql 
         Caption         =   "Connect"
         Height          =   375
         Left            =   360
         TabIndex        =   6
         Top             =   2400
         Width           =   1575
      End
      Begin VB.CommandButton cmdDisconnect 
         Caption         =   "Disconnect"
         Enabled         =   0   'False
         Height          =   375
         Left            =   2400
         TabIndex        =   5
         Top             =   2400
         Width           =   1575
      End
      Begin VB.ComboBox cmbMySQLTables 
         Enabled         =   0   'False
         Height          =   315
         ItemData        =   "user.frx":0171
         Left            =   1560
         List            =   "user.frx":0173
         TabIndex        =   4
         Top             =   1800
         Width           =   2535
      End
      Begin VB.CommandButton cmdQueryMySQL 
         Caption         =   "Query"
         Enabled         =   0   'False
         Height          =   375
         Left            =   8280
         TabIndex        =   3
         Top             =   2280
         Width           =   1575
      End
      Begin VB.TextBox txtSQLMysql 
         Enabled         =   0   'False
         Height          =   1375
         Left            =   4320
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   2
         Top             =   720
         Width           =   5500
      End
      Begin MSDataGridLib.DataGrid gridDataMySQL 
         Bindings        =   "user.frx":0175
         Height          =   3735
         Left            =   120
         TabIndex        =   1
         Top             =   2880
         Width           =   9705
         _ExtentX        =   17119
         _ExtentY        =   6588
         _Version        =   393216
         AllowUpdate     =   0   'False
         BackColor       =   -2147483624
         Enabled         =   0   'False
         ForeColor       =   -2147483642
         HeadLines       =   1
         RowHeight       =   15
         BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ColumnCount     =   2
         BeginProperty Column00 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         BeginProperty Column01 
            DataField       =   ""
            Caption         =   ""
            BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
               Type            =   0
               Format          =   ""
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1033
               SubFormatType   =   0
            EndProperty
         EndProperty
         SplitCount      =   1
         BeginProperty Split0 
            BeginProperty Column00 
            EndProperty
            BeginProperty Column01 
            EndProperty
         EndProperty
      End
      Begin MSAdodcLib.Adodc adoDataMySQL 
         Height          =   375
         Left            =   4320
         Top             =   2280
         Visible         =   0   'False
         Width           =   1200
         _ExtentX        =   2117
         _ExtentY        =   661
         ConnectMode     =   0
         CursorLocation  =   3
         IsolationLevel  =   -1
         ConnectionTimeout=   15
         CommandTimeout  =   30
         CursorType      =   3
         LockType        =   3
         CommandType     =   8
         CursorOptions   =   0
         CacheSize       =   50
         MaxRecords      =   0
         BOFAction       =   0
         EOFAction       =   0
         ConnectStringType=   1
         Appearance      =   1
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Orientation     =   0
         Enabled         =   -1
         Connect         =   ""
         OLEDBString     =   ""
         OLEDBFile       =   ""
         DataSourceName  =   ""
         OtherAttributes =   ""
         UserName        =   ""
         Password        =   ""
         RecordSource    =   ""
         Caption         =   "Adodc1"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _Version        =   393216
      End
      Begin MSComDlg.CommonDialog cmmDialog 
         Left            =   5640
         Top             =   2280
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
         DialogTitle     =   "Save to text file"
         FileName        =   "*.txt"
         Filter          =   "Text Document (*.txt)"
         InitDir         =   "c:\Windows\Desktop"
      End
      Begin VB.Label Label1 
         Caption         =   "SQL Statement:"
         Height          =   255
         Left            =   4320
         TabIndex        =   16
         Top             =   360
         Width           =   1335
      End
      Begin VB.Label Label3 
         Caption         =   "Server Name :"
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   360
         Width           =   1335
      End
      Begin VB.Label Label4 
         Caption         =   "Database Name :"
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   720
         Width           =   1335
      End
      Begin VB.Label Label5 
         Caption         =   "User Name :"
         Height          =   255
         Left            =   120
         TabIndex        =   13
         Top             =   1080
         Width           =   1335
      End
      Begin VB.Label Label6 
         Caption         =   "Password :"
         Height          =   255
         Left            =   120
         TabIndex        =   12
         Top             =   1440
         Width           =   1335
      End
      Begin VB.Label Label7 
         Caption         =   "Tables :"
         Enabled         =   0   'False
         Height          =   255
         Left            =   120
         TabIndex        =   11
         Top             =   1800
         Width           =   1335
      End
      Begin VB.Line Line2 
         X1              =   120
         X2              =   4200
         Y1              =   2280
         Y2              =   2280
      End
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileExit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpAbout 
         Caption         =   "&About"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Option Explicit
Public Username As String
Public Password As String
Public EmailAddress As String
Dim Answer As Boolean
Private Sub chkAccExpire_Click()
    If chkAccExpire.Value = 1 Then
        dtpAccExpire.Enabled = True
    Else
        dtpAccExpire.Enabled = False
    End If
End Sub

Private Sub chkCreateHome_Click()
    If chkCreateHome.Value = 1 Then
        frmSelect.Show
        frmMain.Enabled = False
    Else
        frmSelect.Hide
    End If
End Sub

'Private Sub chklogonhour_Click()
'    If chklogonhour.Value = 1 Then
'        frmMain.Enabled = False
'        frmSetLogonHour.Show
'    End If
'End Sub

Private Sub chkRandompwd_Click()
    Dim Resp As Integer
    If chkRandompwd.Value = 1 Then
    'msgbox (,vbYesNo+vbQuestion,"Keep password?")
        Resp = MsgBox("Do you want to keep the passwords?", vbYesNo + vbQuestion, "Keep password?")
        If Resp = 6 Then '6 = yes
            cmmDialog.ShowSave
            If Right(cmmDialog.filename, 4) <> ".txt" Then
                Answer = True
                cmmDialog.filename = cmmDialog.filename + ".txt"
            ElseIf cmmDialog.filename = "*.txt" Or cmmDialog.filename = "" Then
                Answer = False
            Else
                Answer = True
            End If
        Else
        Answer = False
        End If
    End If
End Sub

Private Sub chkSendMail_Click()
    If chkSendMail.Value = 1 Then
        frmMain.Enabled = False
        frmSendMail.Show
    End If
End Sub

Private Sub cmdAdd_Click()
    If cmbColumn.Text = "Select column >>" Or cmbPutIn.Text = "Select user's property >>" Or cmbPutIn.Text = "" Then
        MsgBox "Please choose data from column's combo box and Put In's combo box"
    Else
        LstDisplayMapping.List(LstDisplayMapping.ListCount) = cmbColumn.Text + "->" + cmbPutIn.Text + _
        "(Data from column " + cmbColumn.Text + " will be put in " + cmbPutIn.Text + " field.)"
        If cmbPutIn.Text = "*User logon name*" Then
            MsgBox "Warning!! Data in this column should be unique", vbQuestion, "Warning"
            MakeEnableOption (True)
        ElseIf cmbPutIn.Text = "Password" Then
            chkRandompwd.Enabled = False
        End If
        cmbPutIn.RemoveItem (cmbPutIn.ListIndex)
    End If
End Sub

Private Sub cmdExecute_Click()
    Const ForWriting = 2
    Const TristateFalse = 0
    Dim ColCN, str, ColEmail As String
    Dim i, j, pos As Integer
    'txtStatus.Text = "Now processing...."
    'txtStatus.Refresh
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Now processing...."
    frmTerminal.Text1.Refresh
    FindDN_TOD
    CreateOU (txtOUName.Text)
    'find column email
    For i = 0 To LstDisplayMapping.ListCount - 1
        pos = InStr(LstDisplayMapping.List(i), "->E-mail")
        If pos > 0 Then
            str = Left(LstDisplayMapping.List(i), pos - 1)
            ColEmail = str
        End If
    Next i
    'find columns user account
    For i = 0 To LstDisplayMapping.ListCount - 1
            pos = InStr(LstDisplayMapping.List(i), "*User logon name*")
            If pos > 0 Then
                str = Left(LstDisplayMapping.List(i), pos - 3)
                ColCN = str 'column of CN
                Field = "*User logon name*"
            End If '
    Next i
    'Create User Account
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Creating user account..."
    For j = 0 To gridDataMySQL.ApproxCount - 1
        gridDataMySQL.Row = j
        data = gridDataMySQL.Columns(ColCN)
        PutDataInUserAccount (gridDataMySQL.Columns(ColCN))
    Next j
    'Put user's Attribute
    For i = 0 To LstDisplayMapping.ListCount - 1
            'check columns and user's fields
            pos = InStr(LstDisplayMapping.List(i), "(Data from column ")
            str = Left(LstDisplayMapping.List(i), pos - 1)
            pos = InStr(str, "->")
            Field = Right(str, Len(str) - pos - 1)
            str = Left(str, pos - 1)
            If Field <> "*User logon name*" Then
                For j = 0 To gridDataMySQL.ApproxCount - 1
                    gridDataMySQL.Row = j
                    data = gridDataMySQL.Columns(str)
                    PutDataInUserAccount (gridDataMySQL.Columns(ColCN))
                Next j
            End If
        Next i
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Create user account complete"
    
    'write username and password to textfile
    If Answer = True Then
        Set objFSO = CreateObject("Scripting.FileSystemObject")
        Set objTextFile = objFSO.OpenTextFile(cmmDialog.filename, ForWriting, True, TristateFalse)
        'set password (random)
            For i = 0 To gridDataMySQL.ApproxCount - 1
                gridDataMySQL.Row = i
                data = RndPwd()
                objTextFile.Write ("Username=" + gridDataMySQL.Columns(ColCN) + "       ")
                objTextFile.WriteLine ("Password=" + data)
                SetPwd (gridDataMySQL.Columns(ColCN))
                'send mail
                If chkSendMail.Value = 1 Then
                    Username = gridDataMySQL.Columns(ColCN)
                    Password = data
                    EmailAddress = gridDataMySQL.Columns(ColEmail)
                    Sendmail
                End If
            Next i
        frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Write text file complete"
        objTextFile.Close
    ElseIf chkRandompwd.Value = 1 Then
        For i = 0 To gridDataMySQL.ApproxCount - 1
        gridDataMySQL.Row = i
        data = RndPwd()
        SetPwd (gridDataMySQL.Columns(ColCN))
        'send mail
        If chkSendMail.Value = 1 Then
            Username = gridDataMySQL.Columns(ColCN)
            Password = data
            EmailAddress = gridDataMySQL.Columns(ColEmail)
            Sendmail
        End If
        Next i
    End If
    'set date account expire
    If chkAccExpire.Value = 1 Then
        For i = 0 To gridDataMySQL.ApproxCount - 1
            gridDataMySQL.Row = i
            data = dtpAccExpire.Value
            SetDateExpire (gridDataMySQL.Columns(ColCN))
        Next i
    End If
    'send mail
    If chkSendMail.Value = 1 Then
       For i = 0 To LstDisplayMapping.ListCount - 1
            'check columns and user's fields
            pos = InStr(LstDisplayMapping.List(i), "->Password")
            If pos > 0 Then
                str = Left(LstDisplayMapping.List(i), pos - 1)
                For j = 0 To gridDataMySQL.ApproxCount - 1
                    gridDataMySQL.Row = j
                    Password = gridDataMySQL.Columns(str)
                    Username = gridDataMySQL.Columns(ColCN)
                    EmailAddress = gridDataMySQL.Columns(ColEmail)
                    Sendmail
                Next j
            End If
        Next i
    End If
    'create home folder
    If chkCreateHome.Value = 1 Then
        'On Error GoTo errorHandle
        'Check = InStr(txtHomePath.Text, ":\")
        'If Check = 0 Then
        'GoTo errorHandle
        'End If
        frmSelect.Show
        frmMain.Enabled = False
        Set objFSO = CreateObject("Scripting.FileSystemObject")
        For i = 0 To gridDataMySQL.ApproxCount - 1
            gridDataMySQL.Row = i
            data = frmSelect.txtDispPath.Text + "\" + gridDataMySQL.Columns(ColCN)
            Set objfolder = objFSO.CreateFolder(data)
            PutHomeDirectory (gridDataMySQL.Columns(ColCN))
        Next i
        frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Create Home Directory complete"
    End If
    
    'txtStatus.Text = "Complete"
'    Exit Sub
'errorHandle:
'    MsgBox "Invalid path!!!"
End Sub

Private Sub cmdRemove_Click()
    Dim str As String
    If LstDisplayMapping.ListIndex >= 0 Then
    'Search string to insert cmbPutIn back
    pos = InStr(LstDisplayMapping.Text, "(Data from column ")
    str = Left(LstDisplayMapping.Text, pos - 1)
    pos = InStr(str, "->")
    str = Right(str, Len(str) - pos - 1)
    
    LstDisplayMapping.RemoveItem (LstDisplayMapping.ListIndex)
    cmbPutIn.AddItem (str)
    'Disable cmdExecute
        If str = "*User logon name*" Then
            MakeEnableOption (False)
        ElseIf str = "Password" Then
            chkRandompwd.Enabled = True
        End If
    End If
End Sub

Public Sub cmdConnectDBmysql_Click()
    Dim i As Integer
    frmTerminal.Show
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connecting to Database server...."
    frmTerminal.Text1.Refresh
    'txtStatus.Text = "Connecting to Database server...."
    'txtStatus.Refresh
    If ConnectDBMySQL Then
        Screen.MousePointer = vbArrow
        frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connecting to database succesfully"
        'txtStatus.Text = "Connecting to database succesfully"
        'MsgBox "Connecting to the database succesfully...", , "Connection..."
        MakeEnabledFrameDatabase (True)
        cmbMySQLTables.Text = "Select table >>"
        For i = 1 To UBound(DB2Tables)
            cmbMySQLTables.AddItem DB2Tables(i)
        Next i
    End If
    'For i = lstMySQLTable.ListCount - 1 To 0 Step -1
    '    lstMySQLTable.RemoveItem i
    'Next i
End Sub

Public Sub cmdDisconnect_Click()
    Dim i As Integer
    CloseMySQLConnection
    
    'For i = lstMySQLTable.ListCount - 1 To 0 Step -1
    '    lstMySQLTable.RemoveItem (i)
    'Next
    
    For i = cmbMySQLTables.ListCount - 1 To 0 Step -1
        cmbMySQLTables.RemoveItem (i)
    Next
    'lblRecordCountMySQL.Caption = ""
    'lblColumnMySQL.Caption = ""
    gridDataMySQL.ClearFields
    LstDisplayMapping.Clear
    MakeEnabledFrameDatabase (False)
    MakeEnabledFrameAddUser (False)
    MakeEnableOption (False)
End Sub

Sub MakeEnabledFrameDatabase(a As Boolean)
    txtServerMySQL.Enabled = Not a
    txtPasswordMySQL.Enabled = Not a
    txtUserNameMySQL.Enabled = Not a
    txtDBNameMySQL.Enabled = Not a
    cmdConnectDBmysql.Enabled = Not a
    'Label3.Enabled = Not a
    'Label4.Enabled = Not a
    'Label5.Enabled = Not a
    'Label6.Enabled = Not a
    'Label7.Enabled = a
    cmdDisconnect.Enabled = a
    cmbMySQLTables.Enabled = a
    'lstMySQLTable.Enabled = a
    gridDataMySQL.Enabled = a
    'editModeMySQL.Enabled = a
    txtSQLMysql.Enabled = a
    cmdQueryMySQL.Enabled = a
    'Label18.Enabled = a
    'Label20.Enabled = a
    'Label16.Enabled = a
    'Frame5.Enabled = a
    cmdDisconnect.Default = a
    cmdConnectDBmysql.Default = Not a
End Sub
Sub MakeEnabledFrameAddUser(a As Boolean)
    'txtOUName.Enabled = a
    'chkCreateHome.Enabled = a
    'chkSendMail.Enabled = a
    cmbColumn.Enabled = a
    cmbPutIn.Enabled = a
    cmdAdd.Enabled = a
    cmdRemove.Enabled = a
    LstDisplayMapping.Enabled = a
End Sub
Sub MakeEnableOption(a As Boolean)
    txtOUName.Enabled = a
    chkCreateHome.Enabled = a
    chkSendMail.Enabled = a
    chkAccExpire.Enabled = a
    chkRandompwd.Enabled = a
    'cmdExecute.Enabled = a
End Sub
Private Sub cmdQueryMySQL_Click()
    
  On Error GoTo ErrorTrap
    If Trim(txtSQLMysql.Text) = "" Then Exit Sub
    'txtStatus.Text = "Querying wait a moment...."
    'txtStatus.Refresh
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Querying wait a moment...."
    frmTerminal.Text1.Refresh
    Set gridDataMySQL.DataSource = Nothing
    adoDataMySQL.RecordSource = ""

    If adoDataMySQL.ConnectionString = "" Then
    
    adoDataMySQL.ConnectionString = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" & _
    ServerNameMySQL & "; DATABASE=" & DBNameMySQL & "; UID=" & UserNameMySQL & _
    ";PWD=" & PasswordMySQL
    
    End If

    adoDataMySQL.RecordSource = Trim(txtSQLMysql.Text)
    adoDataMySQL.Refresh
    'Dim i As Integer
        'For i = frmMain.lstMySQLTable.ListCount - 1 To 0 Step -1
            'frmMain.lstMySQLTable.RemoveItem i
        'Next i
    If adoDataMySQL.Recordset.Fields.Count = 0 Then
        gridDataMySQL.ClearFields
    Else
        Set gridDataMySQL.DataSource = adoDataMySQL.Recordset
        gridDataMySQL.ClearFields
        gridDataMySQL.ReBind
    End If
    ReDim Preserve TypeMySQL(0)
    With adoDataMySQL.Recordset
        For Each rsfield In .Fields
                'frmMain.lstMySQLTable.AddItem rsfield.Name
                ReDim Preserve TypeMySQL(UBound(TypeMySQL) + 1)
                TypeMySQL(UBound(TypeMySQL)) = rsfield.Type 'TypeName(rsField.Type)
        Next
    End With
    'lblRecordCountMySQL.Caption = adoDataMySQL.Recordset.RecordCount
    'lblColumnMySQL.Caption = lstMySQLTable.ListCount
    'lblDatabaseNameAccess.Caption = txtFileName.Text
    'lstMySQLTable.ListIndex = 0
    'txtStatus.Text = "Successful"
    LoadcmbColumncmbPutIn
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Successful"
    Exit Sub
ErrorTrap:
    'txtStatus.Text = "Can not query!!!"
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Can not query!!!"
    MsgBox "An Error occured during connecting Database. err.no : " & Err.Number & " err.desc : " & Err.Description

End Sub

Sub Form_Load()
    Dim TableName1
        'TableName1 = GetSetting("prjConvert", "TableNameAcces", "TableNameAcces", "")
        'TableName2 = GetSetting("prjConvert", "TableNameMySQL", "TableNameMySQL", "")
        txtServerMySQL.Text = GetSetting("prjConvert", "TableNameMySQL", "ServerNameMySQL", "")
        txtDBNameMySQL.Text = GetSetting("prjConvert", "TableNameMySQL", "DBNameMySQL", "")
        txtUserNameMySQL.Text = GetSetting("prjConvert", "TableNameMySQL", "UserNameMySQL", "")
        'If Not TableName1 = "" Then
        '    txtFileName.Text = TableName1
        '        For i = cmbAccesTables.ListCount - 1 To 0 Step -1  ' BURASI ��MD�L�K YOK
        '            cmbAccesTable.RemoveItem i
        '        Next i

        '    If GetDBTables(Table1) = True Then
        '        For i = 1 To UBound(DB1Tables)
        '            cmbAccesTables.AddItem DB1Tables(i)
        '        Next i
        '    End If
    
        '    For i = lstAccesTable.ListCount - 1 To 0 Step -1
        '        lstAccesTable.RemoveItem i
        '    Next i
        'End If
        
        'If Not Table2 = "" Then
        '    txtFieldTypeMySQL.Text = Table1
        '    If ConnectDBMySQL Then
        '        For i = 1 To UBound(DB2Tables)
        '            cmbMySQLTables.AddItem DB2Tables(i)
        '        Next i
        '    End If
        '    For i = lstMySQLTable.ListCount - 1 To 0 Step -1
        '        lstMySQLTable.RemoveItem i
        '    Next i
        'End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    'SaveSetting "prjConvert", "TableNameAcces", "TableNameAcces", txtFileName.Text
    SaveSetting "prjConvert", "TableNameMySQL", "ServerNameMySQL", txtServerMySQL.Text
    SaveSetting "prjConvert", "TableNameMySQL", "DBNameMySQL", frmMain.txtDBNameMySQL
    SaveSetting "prjConvert", "TableNameMySQL", "UserNameMySQL", frmMain.txtUserNameMySQL
    EndProgram
    Unload frmTerminal
    Unload frmSendMail
    Unload frmSelect
End Sub

Private Sub lstMySQLTable_Click()
    If lstMySQLTable.ListIndex >= 0 Then
        Label19.Caption = TypeNameMySQL(CInt(TypeMySQL(lstMySQLTable.ListIndex + 1)))
    End If
End Sub

Private Sub LstDisplayMapping_Click()
    If LstDisplayMapping.SelCount > 0 Then
        cmdRemove.Enabled = True
    Else
        cmdRemove.Enabled = False
    End If
End Sub

Private Sub mnuFileExit_Click()
    EndProgram
    Unload Me
End Sub

Public Sub LoadDataMySQL()
    'Screen.MousePointer = vbHourglass
    On Error GoTo ErrorTrap

    Set gridDataMySQL.DataSource = Nothing
    adoDataMySQL.RecordSource = ""
    adoDataMySQL.ConnectionString = ""
    adoDataMySQL.CommandType = adCmdText
    adoDataMySQL.ConnectionString = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" & _
    ServerMySQL & "; DATABASE=" & DBNameMySQL & "; UID=" & UserNameMySQL & _
    ";PWD=" & PasswordMySQL
    
    adoDataMySQL.RecordSource = "SELECT * FROM " & cmbMySQLTables
    adoDataMySQL.Refresh
    'lblRecordCountMySQL.Caption = adoDataMySQL.Recordset.RecordCount
    'lblColumnMySQL.Caption = lstMySQLTable.ListCount
    If adoDataMySQL.Recordset.Fields.Count = 0 Then
        gridDataMySQL.ClearFields
    Else
        Set gridDataMySQL.DataSource = adoDataMySQL.Recordset
        gridDataMySQL.ClearFields
        gridDataMySQL.ReBind
    End If
    gridDataMySQL.Caption = txtServerMySQL.Text & "-> " & _
        txtDBNameMySQL.Text & "-> " & cmbMySQLTables.Text
    MakeEnabledFrameAddUser (True)
    LoadcmbColumncmbPutIn
    Exit Sub
    
ErrorTrap:
    MsgBox "An Error occured during connecting db. err.no : " & Err.Number & " err.desc : " & Err.Description
    MakeEnabledFrameAddUser (False)
End Sub

Private Sub cmbMySQLTables_click()
    If Not cmbMySQLTables.Text = "Select table >>" Then
        frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connecting to table " + cmbMySQLTables.Text + "...."
        frmTerminal.Text1.Refresh
        'txtStatus.Text = "Connecting to table " + cmbMySQLTables.Text + "...."
        'txtStatus.Refresh
        MakeFieldListMySQL (frmMain.cmbMySQLTables)
        LoadDataMySQL
        Screen.MousePointer = vbArrow
        'txtStatus.Text = "Connection complete"
        frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connection complete"
    End If
End Sub

Private Sub txtOUName_Change()
    If txtOUName.Text <> "" And cmbPutIn.List(0) <> "*User logon name*" Then
        cmdExecute.Enabled = True
    Else
        cmdExecute.Enabled = False
    End If
End Sub

Sub LoadcmbColumncmbPutIn()
    cmbColumn.Clear
    cmbPutIn.Clear
    Dim i As Integer
    For i = 0 To gridDataMySQL.Columns.Count - 1
        cmbColumn.List(i) = gridDataMySQL.Columns(i).Caption
    Next i
      'Load cmbputin's list
        cmbPutIn.List(0) = "*User logon name*"
        cmbPutIn.List(1) = "City"
        cmbPutIn.List(2) = "Company"
        cmbPutIn.List(3) = "Department"
        cmbPutIn.List(4) = "Description"
        cmbPutIn.List(5) = "Display name"
        cmbPutIn.List(6) = "E-mail"
        cmbPutIn.List(7) = "Fax number"
        cmbPutIn.List(8) = "First name"
        cmbPutIn.List(9) = "Full name"
        cmbPutIn.List(10) = "Home page"
        cmbPutIn.List(11) = "Initials"
        cmbPutIn.List(12) = "IP phone"
        cmbPutIn.List(13) = "Last name"
        cmbPutIn.List(14) = "Office"
        cmbPutIn.List(15) = "P.O. Box"
        cmbPutIn.List(16) = "Password"
        cmbPutIn.List(17) = "Postal code"
        cmbPutIn.List(18) = "State/Province"
        cmbPutIn.List(19) = "Street"
        cmbPutIn.List(20) = "Telephone home"
        cmbPutIn.List(21) = "Telephone mobile"
        cmbPutIn.List(22) = "Telephone pager"
        cmbPutIn.List(23) = "Title"
    cmbColumn.Text = "Select column >>"
    cmbPutIn.Text = "Select user's property >>"
    LstDisplayMapping.Clear
End Sub

Function RndPwd() As String
    Dim val As Integer
    Dim pwd As String
    Do Until Len(pwd) = 8
    val = Int((122 * Rnd) + 48)
    If val < 57 Or (val > 65 And val < 90) Or (val > 97 And val < 122) Then
    pwd = pwd + Chr(val)
    End If
    Loop
    RndPwd = pwd
End Function

Sub Pause(duration)
'Pause for the specified duration
'Duration is in seconds
Dim Current As Long
Current = Timer
Do Until Timer - Current >= duration
    DoEvents
Loop
End Sub

Public Sub Sendmail()
        Winsock1.Close
        Winsock1.RemoteHost = frmSendMail.txtMailServer.Text
        Winsock1.RemotePort = 25
        Winsock1.Connect
End Sub

Private Sub Winsock1_Close()
    Winsock1.Close
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connection Closed"

End Sub

Private Sub Winsock1_Connect()
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connected.."
Pause 0.9
Pause 0.9
Winsock1.SendData "HELO " & Winsock1.LocalIP

Pause 0.3
Pause 0.9
Pause 3

Pause 0.9

Winsock1.SendData "MAIL FROM:" & frmSendMail.txtFrom.Text & vbCrLf
Winsock1.SendData "MAIL FROM:" & frmSendMail.txtFrom.Text & vbCrLf
Winsock1.SendData "MAIL FROM:" & frmSendMail.txtFrom.Text & vbCrLf
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "MAIL FROM:" & frmSendMail.txtFrom.Text
Pause 0.5
Pause 0.9
Pause 4

Pause 0.9

Winsock1.SendData "RCPT TO:" & EmailAddress & vbCrLf
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "RCPT TO:" & EmailAddress
Pause 0.5
Pause 0.9

frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "DATA"
Pause 0.9
Winsock1.SendData "DATA" & vbCrLf

Pause 0.3
Winsock1.SendData "SUBJECT:" & frmSendMail.txtSubject.Text & vbCrLf
Pause 0.9

Pause 0.9

Pause 0.3
Winsock1.SendData "Username=" + Username + "," + "Password=" + Password & vbCrLf
Pause 0.9
Winsock1.SendData vbCrLf & "." & vbCrLf
Pause 3
Pause 3
Pause 3
Winsock1.Close
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Connection Closed"
End Sub

Private Sub Winsock1_DataArrival(ByVal bytesTotal As Long)
Dim data As String
Winsock1.GetData data, vbString
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + data

End Sub

Private Sub Winsock1_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
Winsock1.Close
frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "ERROR: " & Number & ": " & Description
End Sub
