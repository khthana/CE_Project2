VERSION 5.00
Object = "{0D452EE1-E08F-101A-852E-02608C4D0BB4}#2.0#0"; "FM20.DLL"
Begin VB.Form frmSetLogonHour 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Logon hour"
   ClientHeight    =   3765
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   8970
   DrawMode        =   9  'Not Mask Pen
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3765
   ScaleWidth      =   8970
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   7440
      TabIndex        =   198
      Top             =   1200
      Width           =   1215
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   375
      Left            =   7440
      TabIndex        =   197
      Top             =   720
      Width           =   1215
   End
   Begin VB.Line Line1 
      X1              =   7200
      X2              =   8880
      Y1              =   2520
      Y2              =   2520
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   209
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   208
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   207
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   206
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   205
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   204
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   203
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin VB.Label Label5 
      Caption         =   "Logon Denied"
      Height          =   255
      Left            =   7680
      TabIndex        =   202
      Top             =   2760
      Width           =   1095
   End
   Begin VB.Label Label4 
      Caption         =   "Logon Permitted"
      Height          =   255
      Left            =   7680
      TabIndex        =   201
      Top             =   2160
      Width           =   1215
   End
   Begin MSForms.ToggleButton ToggleButton2 
      Height          =   375
      Index           =   193
      Left            =   7320
      TabIndex        =   200
      Top             =   2640
      Width           =   255
      VariousPropertyBits=   746588191
      BackColor       =   -2147483628
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton ToggleButton2 
      Height          =   375
      Index           =   192
      Left            =   7320
      TabIndex        =   199
      Top             =   2040
      Width           =   255
      VariousPropertyBits=   746588191
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin VB.Label Label2 
      Caption         =   "A.M."
      Height          =   255
      Index           =   1
      Left            =   6960
      TabIndex        =   196
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label3 
      Caption         =   "P.M."
      Height          =   255
      Left            =   4080
      TabIndex        =   195
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label2 
      Caption         =   "A.M."
      Height          =   255
      Index           =   0
      Left            =   1200
      TabIndex        =   194
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label1 
      Caption         =   "0    .    2    .   4    .    6    .    8    .  10    .  12    .   14   .   16   .  18    .  20   .   22   .   0  "
      Height          =   255
      Left            =   1275
      TabIndex        =   193
      Top             =   360
      Width           =   5895
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   192
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   191
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   190
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   189
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   188
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   187
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   186
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   185
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   184
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   183
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   182
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   181
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   180
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   179
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   178
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   177
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   176
      Top             =   3120
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   175
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   174
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   173
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   172
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   171
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   170
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   169
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   168
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   167
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   166
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   165
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   164
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   163
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   162
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   161
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   160
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   159
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   158
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   157
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   156
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   155
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   154
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   153
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   152
      Top             =   2760
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   151
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   150
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   149
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   148
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   147
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   146
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   145
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   144
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   143
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   142
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   141
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   140
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   139
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   138
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   137
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   136
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   135
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   134
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   133
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   132
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   131
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   130
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   129
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   128
      Top             =   2400
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   127
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   126
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   125
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   124
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   123
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   122
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   121
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   120
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   119
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   118
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   117
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   116
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   115
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   114
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   113
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   112
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   111
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   110
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   109
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   108
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   107
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   106
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   105
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   104
      Top             =   2040
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   103
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   102
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   101
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   100
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   99
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   98
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   97
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   96
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   95
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   94
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   93
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   92
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   91
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   90
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   89
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   88
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   87
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   86
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   85
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   84
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   83
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   82
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   81
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   80
      Top             =   1680
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   79
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   78
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   77
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   76
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   75
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   74
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   73
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   72
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   71
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   70
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   69
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   68
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   67
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   66
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   65
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   64
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   63
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   62
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   61
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   60
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   59
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   58
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   57
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   56
      Top             =   1320
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   24
      Left            =   6840
      TabIndex        =   55
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   23
      Left            =   6600
      TabIndex        =   54
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   22
      Left            =   6360
      TabIndex        =   53
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   21
      Left            =   6120
      TabIndex        =   52
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   20
      Left            =   5880
      TabIndex        =   51
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   19
      Left            =   5640
      TabIndex        =   50
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   18
      Left            =   5400
      TabIndex        =   49
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   17
      Left            =   5160
      TabIndex        =   48
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   16
      Left            =   4920
      TabIndex        =   47
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   15
      Left            =   4680
      TabIndex        =   46
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   14
      Left            =   4440
      TabIndex        =   45
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   13
      Left            =   4200
      TabIndex        =   44
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   12
      Left            =   3960
      TabIndex        =   43
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   11
      Left            =   3720
      TabIndex        =   42
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   10
      Left            =   3480
      TabIndex        =   41
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   9
      Left            =   3240
      TabIndex        =   40
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   8
      Left            =   3000
      TabIndex        =   39
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   38
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   6
      Left            =   2520
      TabIndex        =   37
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   5
      Left            =   2280
      TabIndex        =   36
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   4
      Left            =   2040
      TabIndex        =   35
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   3
      Left            =   1800
      TabIndex        =   34
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   2
      Left            =   1560
      TabIndex        =   33
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   1
      Left            =   1320
      TabIndex        =   32
      Top             =   960
      Width           =   255
      BackColor       =   16744576
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH24 
      Height          =   375
      Left            =   6840
      TabIndex        =   31
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH23 
      Height          =   375
      Left            =   6600
      TabIndex        =   30
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH22 
      Height          =   375
      Left            =   6360
      TabIndex        =   29
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH21 
      Height          =   375
      Left            =   6120
      TabIndex        =   28
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH20 
      Height          =   375
      Left            =   5880
      TabIndex        =   27
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH19 
      Height          =   375
      Left            =   5640
      TabIndex        =   26
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH18 
      Height          =   375
      Left            =   5400
      TabIndex        =   25
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH17 
      Height          =   375
      Left            =   5160
      TabIndex        =   24
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH16 
      Height          =   375
      Left            =   4920
      TabIndex        =   23
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH15 
      Height          =   375
      Left            =   4680
      TabIndex        =   22
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH14 
      Height          =   375
      Left            =   4440
      TabIndex        =   21
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH13 
      Height          =   375
      Left            =   4200
      TabIndex        =   20
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH12 
      Height          =   375
      Left            =   3960
      TabIndex        =   19
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH11 
      Height          =   375
      Left            =   3720
      TabIndex        =   18
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH10 
      Height          =   375
      Left            =   3480
      TabIndex        =   17
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH9 
      Height          =   375
      Left            =   3240
      TabIndex        =   16
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH8 
      Height          =   375
      Left            =   3000
      TabIndex        =   15
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH7 
      Height          =   375
      Left            =   2760
      TabIndex        =   14
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH6 
      Height          =   375
      Left            =   2520
      TabIndex        =   13
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH5 
      Height          =   375
      Left            =   2280
      TabIndex        =   12
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH4 
      Height          =   375
      Left            =   2040
      TabIndex        =   11
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH3 
      Height          =   375
      Left            =   1800
      TabIndex        =   10
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH2 
      Height          =   375
      Left            =   1560
      TabIndex        =   9
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggH1 
      Height          =   375
      Left            =   1320
      TabIndex        =   8
      Top             =   600
      Width           =   255
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "450;661"
      Value           =   "0"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSat 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   7
      Top             =   3120
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Saturday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggFri 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   6
      Top             =   2760
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Friday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggThu 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   5
      Top             =   2400
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Thursday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggWed 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   4
      Top             =   2040
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Wednesday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggTue 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   3
      Top             =   1680
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Tuesday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggMon 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   2
      Top             =   1320
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Monday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggSun 
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   1
      Top             =   960
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "Sunday"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton tggAll 
      Height          =   375
      Left            =   240
      TabIndex        =   0
      Top             =   600
      Width           =   1095
      BackColor       =   -2147483633
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "1931;661"
      Value           =   "0"
      Caption         =   "All"
      FontHeight      =   165
      FontCharSet     =   222
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
End
Attribute VB_Name = "frmSetLogonHour"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
    Unload frmSetLogonHour
    frmMain.Enabled = True
End Sub

Private Sub cmdOK_Click()
    frmMain.Enabled = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmMain.Enabled = True
End Sub

Private Sub tggAll_Click()
    If tggAll.Value = True Then
        If tggSun(1).BackColor = &HFF8080 Then
        For i = 1 To 24
            tggSun(i).BackColor = &HFFFFFF
            tggMon(i).BackColor = &HFFFFFF
            tggTue(i).BackColor = &HFFFFFF
            tggWed(i).BackColor = &HFFFFFF
            tggThu(i).BackColor = &HFFFFFF
            tggFri(i).BackColor = &HFFFFFF
            tggSat(i).BackColor = &HFFFFFF
        Next i
        Else
        For i = 1 To 24
            tggSun(i).BackColor = &HFF8080
            tggMon(i).BackColor = &HFF8080
            tggTue(i).BackColor = &HFF8080
            tggWed(i).BackColor = &HFF8080
            tggThu(i).BackColor = &HFF8080
            tggFri(i).BackColor = &HFF8080
            tggSat(i).BackColor = &HFF8080
        Next i
        End If
    End If
        tggAll.Value = False

End Sub

Private Sub tggFri_Click(Index As Integer)
    If tggFri(Index).Value = True And Index <> 0 Then
        If tggFri(Index).BackColor = &HFF8080 Then
            tggFri(Index).BackColor = &HFFFFFF
        Else
            tggFri(Index).BackColor = &HFF8080
        End If
    End If
    If tggFri(0).Value = True Then
        If tggFri(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggFri(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggFri(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggFri(Index).Value = False
End Sub

Private Sub tggH1_Click()
    If tggH1.Value = True Then
        If tggSun(1).BackColor = &HFF8080 Then
            tggSun(1).BackColor = &HFFFFFF
            tggMon(1).BackColor = &HFFFFFF
            tggTue(1).BackColor = &HFFFFFF
            tggWed(1).BackColor = &HFFFFFF
            tggThu(1).BackColor = &HFFFFFF
            tggFri(1).BackColor = &HFFFFFF
            tggSat(1).BackColor = &HFFFFFF
        Else
            tggSun(1).BackColor = &HFF8080
            tggMon(1).BackColor = &HFF8080
            tggTue(1).BackColor = &HFF8080
            tggWed(1).BackColor = &HFF8080
            tggThu(1).BackColor = &HFF8080
            tggFri(1).BackColor = &HFF8080
            tggSat(1).BackColor = &HFF8080
        End If
    End If
    tggH1.Value = False
End Sub

Private Sub tggH10_Click()
    If tggH10.Value = True Then
        If tggSun(10).BackColor = &HFF8080 Then
            tggSun(10).BackColor = &HFFFFFF
            tggMon(10).BackColor = &HFFFFFF
            tggTue(10).BackColor = &HFFFFFF
            tggWed(10).BackColor = &HFFFFFF
            tggThu(10).BackColor = &HFFFFFF
            tggFri(10).BackColor = &HFFFFFF
            tggSat(10).BackColor = &HFFFFFF
        Else
            tggSun(10).BackColor = &HFF8080
            tggMon(10).BackColor = &HFF8080
            tggTue(10).BackColor = &HFF8080
            tggWed(10).BackColor = &HFF8080
            tggThu(10).BackColor = &HFF8080
            tggFri(10).BackColor = &HFF8080
            tggSat(10).BackColor = &HFF8080
        End If
    End If
    tggH10.Value = False
End Sub


Private Sub tggH11_Click()
    If tggH11.Value = True Then
        If tggSun(11).BackColor = &HFF8080 Then
            tggSun(11).BackColor = &HFFFFFF
            tggMon(11).BackColor = &HFFFFFF
            tggTue(11).BackColor = &HFFFFFF
            tggWed(11).BackColor = &HFFFFFF
            tggThu(11).BackColor = &HFFFFFF
            tggFri(11).BackColor = &HFFFFFF
            tggSat(11).BackColor = &HFFFFFF
        Else
            tggSun(11).BackColor = &HFF8080
            tggMon(11).BackColor = &HFF8080
            tggTue(11).BackColor = &HFF8080
            tggWed(11).BackColor = &HFF8080
            tggThu(11).BackColor = &HFF8080
            tggFri(11).BackColor = &HFF8080
            tggSat(11).BackColor = &HFF8080
        End If
    End If
    tggH11.Value = False
End Sub


Private Sub tggH12_Click()
    If tggH12.Value = True Then
        If tggSun(12).BackColor = &HFF8080 Then
            tggSun(12).BackColor = &HFFFFFF
            tggMon(12).BackColor = &HFFFFFF
            tggTue(12).BackColor = &HFFFFFF
            tggWed(12).BackColor = &HFFFFFF
            tggThu(12).BackColor = &HFFFFFF
            tggFri(12).BackColor = &HFFFFFF
            tggSat(12).BackColor = &HFFFFFF
        Else
            tggSun(12).BackColor = &HFF8080
            tggMon(12).BackColor = &HFF8080
            tggTue(12).BackColor = &HFF8080
            tggWed(12).BackColor = &HFF8080
            tggThu(12).BackColor = &HFF8080
            tggFri(12).BackColor = &HFF8080
            tggSat(12).BackColor = &HFF8080
        End If
    End If
    tggH12.Value = False
End Sub


Private Sub tggH13_Click()
    If tggH13.Value = True Then
        If tggSun(13).BackColor = &HFF8080 Then
            tggSun(13).BackColor = &HFFFFFF
            tggMon(13).BackColor = &HFFFFFF
            tggTue(13).BackColor = &HFFFFFF
            tggWed(13).BackColor = &HFFFFFF
            tggThu(13).BackColor = &HFFFFFF
            tggFri(13).BackColor = &HFFFFFF
            tggSat(13).BackColor = &HFFFFFF
        Else
            tggSun(13).BackColor = &HFF8080
            tggMon(13).BackColor = &HFF8080
            tggTue(13).BackColor = &HFF8080
            tggWed(13).BackColor = &HFF8080
            tggThu(13).BackColor = &HFF8080
            tggFri(13).BackColor = &HFF8080
            tggSat(13).BackColor = &HFF8080
        End If
    End If
    tggH13.Value = False
End Sub


Private Sub tggH14_Click()
    If tggH14.Value = True Then
        If tggSun(14).BackColor = &HFF8080 Then
            tggSun(14).BackColor = &HFFFFFF
            tggMon(14).BackColor = &HFFFFFF
            tggTue(14).BackColor = &HFFFFFF
            tggWed(14).BackColor = &HFFFFFF
            tggThu(14).BackColor = &HFFFFFF
            tggFri(14).BackColor = &HFFFFFF
            tggSat(14).BackColor = &HFFFFFF
        Else
            tggSun(14).BackColor = &HFF8080
            tggMon(14).BackColor = &HFF8080
            tggTue(14).BackColor = &HFF8080
            tggWed(14).BackColor = &HFF8080
            tggThu(14).BackColor = &HFF8080
            tggFri(14).BackColor = &HFF8080
            tggSat(14).BackColor = &HFF8080
        End If
    End If
    tggH14.Value = False
End Sub


Private Sub tggH15_Click()
    If tggH15.Value = True Then
        If tggSun(15).BackColor = &HFF8080 Then
            tggSun(15).BackColor = &HFFFFFF
            tggMon(15).BackColor = &HFFFFFF
            tggTue(15).BackColor = &HFFFFFF
            tggWed(15).BackColor = &HFFFFFF
            tggThu(15).BackColor = &HFFFFFF
            tggFri(15).BackColor = &HFFFFFF
            tggSat(15).BackColor = &HFFFFFF
        Else
            tggSun(15).BackColor = &HFF8080
            tggMon(15).BackColor = &HFF8080
            tggTue(15).BackColor = &HFF8080
            tggWed(15).BackColor = &HFF8080
            tggThu(15).BackColor = &HFF8080
            tggFri(15).BackColor = &HFF8080
            tggSat(15).BackColor = &HFF8080
        End If
    End If
    tggH15.Value = False
End Sub


Private Sub tggH16_Click()
    If tggH16.Value = True Then
        If tggSun(16).BackColor = &HFF8080 Then
            tggSun(16).BackColor = &HFFFFFF
            tggMon(16).BackColor = &HFFFFFF
            tggTue(16).BackColor = &HFFFFFF
            tggWed(16).BackColor = &HFFFFFF
            tggThu(16).BackColor = &HFFFFFF
            tggFri(16).BackColor = &HFFFFFF
            tggSat(16).BackColor = &HFFFFFF
        Else
            tggSun(16).BackColor = &HFF8080
            tggMon(16).BackColor = &HFF8080
            tggTue(16).BackColor = &HFF8080
            tggWed(16).BackColor = &HFF8080
            tggThu(16).BackColor = &HFF8080
            tggFri(16).BackColor = &HFF8080
            tggSat(16).BackColor = &HFF8080
        End If
    End If
    tggH16.Value = False
End Sub


Private Sub tggH17_Click()
    If tggH17.Value = True Then
        If tggSun(17).BackColor = &HFF8080 Then
            tggSun(17).BackColor = &HFFFFFF
            tggMon(17).BackColor = &HFFFFFF
            tggTue(17).BackColor = &HFFFFFF
            tggWed(17).BackColor = &HFFFFFF
            tggThu(17).BackColor = &HFFFFFF
            tggFri(17).BackColor = &HFFFFFF
            tggSat(17).BackColor = &HFFFFFF
        Else
            tggSun(17).BackColor = &HFF8080
            tggMon(17).BackColor = &HFF8080
            tggTue(17).BackColor = &HFF8080
            tggWed(17).BackColor = &HFF8080
            tggThu(17).BackColor = &HFF8080
            tggFri(17).BackColor = &HFF8080
            tggSat(17).BackColor = &HFF8080
        End If
    End If
    tggH17.Value = False
End Sub


Private Sub tggH18_Click()
    If tggH18.Value = True Then
        If tggSun(18).BackColor = &HFF8080 Then
            tggSun(18).BackColor = &HFFFFFF
            tggMon(18).BackColor = &HFFFFFF
            tggTue(18).BackColor = &HFFFFFF
            tggWed(18).BackColor = &HFFFFFF
            tggThu(18).BackColor = &HFFFFFF
            tggFri(18).BackColor = &HFFFFFF
            tggSat(18).BackColor = &HFFFFFF
        Else
            tggSun(18).BackColor = &HFF8080
            tggMon(18).BackColor = &HFF8080
            tggTue(18).BackColor = &HFF8080
            tggWed(18).BackColor = &HFF8080
            tggThu(18).BackColor = &HFF8080
            tggFri(18).BackColor = &HFF8080
            tggSat(18).BackColor = &HFF8080
        End If
    End If
    tggH18.Value = False
End Sub


Private Sub tggH19_Click()
    If tggH19.Value = True Then
        If tggSun(19).BackColor = &HFF8080 Then
            tggSun(19).BackColor = &HFFFFFF
            tggMon(19).BackColor = &HFFFFFF
            tggTue(19).BackColor = &HFFFFFF
            tggWed(19).BackColor = &HFFFFFF
            tggThu(19).BackColor = &HFFFFFF
            tggFri(19).BackColor = &HFFFFFF
            tggSat(19).BackColor = &HFFFFFF
        Else
            tggSun(19).BackColor = &HFF8080
            tggMon(19).BackColor = &HFF8080
            tggTue(19).BackColor = &HFF8080
            tggWed(19).BackColor = &HFF8080
            tggThu(19).BackColor = &HFF8080
            tggFri(19).BackColor = &HFF8080
            tggSat(19).BackColor = &HFF8080
        End If
    End If
    tggH19.Value = False
End Sub


Private Sub tggH2_Click()
    If tggH2.Value = True Then
        If tggSun(2).BackColor = &HFF8080 Then
            tggSun(2).BackColor = &HFFFFFF
            tggMon(2).BackColor = &HFFFFFF
            tggTue(2).BackColor = &HFFFFFF
            tggWed(2).BackColor = &HFFFFFF
            tggThu(2).BackColor = &HFFFFFF
            tggFri(2).BackColor = &HFFFFFF
            tggSat(2).BackColor = &HFFFFFF
        Else
            tggSun(2).BackColor = &HFF8080
            tggMon(2).BackColor = &HFF8080
            tggTue(2).BackColor = &HFF8080
            tggWed(2).BackColor = &HFF8080
            tggThu(2).BackColor = &HFF8080
            tggFri(2).BackColor = &HFF8080
            tggSat(2).BackColor = &HFF8080
        End If
    End If
    tggH2.Value = False
End Sub

Private Sub tggH20_Click()
    If tggH20.Value = True Then
        If tggSun(20).BackColor = &HFF8080 Then
            tggSun(20).BackColor = &HFFFFFF
            tggMon(20).BackColor = &HFFFFFF
            tggTue(20).BackColor = &HFFFFFF
            tggWed(20).BackColor = &HFFFFFF
            tggThu(20).BackColor = &HFFFFFF
            tggFri(20).BackColor = &HFFFFFF
            tggSat(20).BackColor = &HFFFFFF
        Else
            tggSun(20).BackColor = &HFF8080
            tggMon(20).BackColor = &HFF8080
            tggTue(20).BackColor = &HFF8080
            tggWed(20).BackColor = &HFF8080
            tggThu(20).BackColor = &HFF8080
            tggFri(20).BackColor = &HFF8080
            tggSat(20).BackColor = &HFF8080
        End If
    End If
    tggH20.Value = False
End Sub



Private Sub tggH21_Click()
    If tggH21.Value = True Then
        If tggSun(21).BackColor = &HFF8080 Then
            tggSun(21).BackColor = &HFFFFFF
            tggMon(21).BackColor = &HFFFFFF
            tggTue(21).BackColor = &HFFFFFF
            tggWed(21).BackColor = &HFFFFFF
            tggThu(21).BackColor = &HFFFFFF
            tggFri(21).BackColor = &HFFFFFF
            tggSat(21).BackColor = &HFFFFFF
        Else
            tggSun(21).BackColor = &HFF8080
            tggMon(21).BackColor = &HFF8080
            tggTue(21).BackColor = &HFF8080
            tggWed(21).BackColor = &HFF8080
            tggThu(21).BackColor = &HFF8080
            tggFri(21).BackColor = &HFF8080
            tggSat(21).BackColor = &HFF8080
        End If
    End If
    tggH21.Value = False
End Sub


Private Sub tggH22_Click()
    If tggH22.Value = True Then
        If tggSun(22).BackColor = &HFF8080 Then
            tggSun(22).BackColor = &HFFFFFF
            tggMon(22).BackColor = &HFFFFFF
            tggTue(22).BackColor = &HFFFFFF
            tggWed(22).BackColor = &HFFFFFF
            tggThu(22).BackColor = &HFFFFFF
            tggFri(22).BackColor = &HFFFFFF
            tggSat(22).BackColor = &HFFFFFF
        Else
            tggSun(22).BackColor = &HFF8080
            tggMon(22).BackColor = &HFF8080
            tggTue(22).BackColor = &HFF8080
            tggWed(22).BackColor = &HFF8080
            tggThu(22).BackColor = &HFF8080
            tggFri(22).BackColor = &HFF8080
            tggSat(22).BackColor = &HFF8080
        End If
    End If
    tggH22.Value = False
End Sub


Private Sub tggH23_Click()
    If tggH23.Value = True Then
        If tggSun(23).BackColor = &HFF8080 Then
            tggSun(23).BackColor = &HFFFFFF
            tggMon(23).BackColor = &HFFFFFF
            tggTue(23).BackColor = &HFFFFFF
            tggWed(23).BackColor = &HFFFFFF
            tggThu(23).BackColor = &HFFFFFF
            tggFri(23).BackColor = &HFFFFFF
            tggSat(23).BackColor = &HFFFFFF
        Else
            tggSun(23).BackColor = &HFF8080
            tggMon(23).BackColor = &HFF8080
            tggTue(23).BackColor = &HFF8080
            tggWed(23).BackColor = &HFF8080
            tggThu(23).BackColor = &HFF8080
            tggFri(23).BackColor = &HFF8080
            tggSat(23).BackColor = &HFF8080
        End If
    End If
    tggH23.Value = False
End Sub


Private Sub tggH24_Click()
    If tggH24.Value = True Then
        If tggSun(24).BackColor = &HFF8080 Then
            tggSun(24).BackColor = &HFFFFFF
            tggMon(24).BackColor = &HFFFFFF
            tggTue(24).BackColor = &HFFFFFF
            tggWed(24).BackColor = &HFFFFFF
            tggThu(24).BackColor = &HFFFFFF
            tggFri(24).BackColor = &HFFFFFF
            tggSat(24).BackColor = &HFFFFFF
        Else
            tggSun(24).BackColor = &HFF8080
            tggMon(24).BackColor = &HFF8080
            tggTue(24).BackColor = &HFF8080
            tggWed(24).BackColor = &HFF8080
            tggThu(24).BackColor = &HFF8080
            tggFri(24).BackColor = &HFF8080
            tggSat(24).BackColor = &HFF8080
        End If
    End If
    tggH24.Value = False
End Sub


Private Sub tggH3_Click()
    If tggH3.Value = True Then
        If tggSun(3).BackColor = &HFF8080 Then
            tggSun(3).BackColor = &HFFFFFF
            tggMon(3).BackColor = &HFFFFFF
            tggTue(3).BackColor = &HFFFFFF
            tggWed(3).BackColor = &HFFFFFF
            tggThu(3).BackColor = &HFFFFFF
            tggFri(3).BackColor = &HFFFFFF
            tggSat(3).BackColor = &HFFFFFF
        Else
            tggSun(3).BackColor = &HFF8080
            tggMon(3).BackColor = &HFF8080
            tggTue(3).BackColor = &HFF8080
            tggWed(3).BackColor = &HFF8080
            tggThu(3).BackColor = &HFF8080
            tggFri(3).BackColor = &HFF8080
            tggSat(3).BackColor = &HFF8080
        End If
    End If
    tggH3.Value = False
End Sub


Private Sub tggH4_Click()
    If tggH4.Value = True Then
        If tggSun(4).BackColor = &HFF8080 Then
            tggSun(4).BackColor = &HFFFFFF
            tggMon(4).BackColor = &HFFFFFF
            tggTue(4).BackColor = &HFFFFFF
            tggWed(4).BackColor = &HFFFFFF
            tggThu(4).BackColor = &HFFFFFF
            tggFri(4).BackColor = &HFFFFFF
            tggSat(4).BackColor = &HFFFFFF
        Else
            tggSun(4).BackColor = &HFF8080
            tggMon(4).BackColor = &HFF8080
            tggTue(4).BackColor = &HFF8080
            tggWed(4).BackColor = &HFF8080
            tggThu(4).BackColor = &HFF8080
            tggFri(4).BackColor = &HFF8080
            tggSat(4).BackColor = &HFF8080
        End If
    End If
    tggH4.Value = False
End Sub


Private Sub tggH5_Click()
    If tggH5.Value = True Then
        If tggSun(5).BackColor = &HFF8080 Then
            tggSun(5).BackColor = &HFFFFFF
            tggMon(5).BackColor = &HFFFFFF
            tggTue(5).BackColor = &HFFFFFF
            tggWed(5).BackColor = &HFFFFFF
            tggThu(5).BackColor = &HFFFFFF
            tggFri(5).BackColor = &HFFFFFF
            tggSat(5).BackColor = &HFFFFFF
        Else
            tggSun(5).BackColor = &HFF8080
            tggMon(5).BackColor = &HFF8080
            tggTue(5).BackColor = &HFF8080
            tggWed(5).BackColor = &HFF8080
            tggThu(5).BackColor = &HFF8080
            tggFri(5).BackColor = &HFF8080
            tggSat(5).BackColor = &HFF8080
        End If
    End If
    tggH5.Value = False
End Sub


Private Sub tggH6_Click()
    If tggH6.Value = True Then
        If tggSun(6).BackColor = &HFF8080 Then
            tggSun(6).BackColor = &HFFFFFF
            tggMon(6).BackColor = &HFFFFFF
            tggTue(6).BackColor = &HFFFFFF
            tggWed(6).BackColor = &HFFFFFF
            tggThu(6).BackColor = &HFFFFFF
            tggFri(6).BackColor = &HFFFFFF
            tggSat(6).BackColor = &HFFFFFF
        Else
            tggSun(6).BackColor = &HFF8080
            tggMon(6).BackColor = &HFF8080
            tggTue(6).BackColor = &HFF8080
            tggWed(6).BackColor = &HFF8080
            tggThu(6).BackColor = &HFF8080
            tggFri(6).BackColor = &HFF8080
            tggSat(6).BackColor = &HFF8080
        End If
    End If
    tggH6.Value = False
End Sub


Private Sub tggH7_Click()
    If tggH7.Value = True Then
        If tggSun(7).BackColor = &HFF8080 Then
            tggSun(7).BackColor = &HFFFFFF
            tggMon(7).BackColor = &HFFFFFF
            tggTue(7).BackColor = &HFFFFFF
            tggWed(7).BackColor = &HFFFFFF
            tggThu(7).BackColor = &HFFFFFF
            tggFri(7).BackColor = &HFFFFFF
            tggSat(7).BackColor = &HFFFFFF
        Else
            tggSun(7).BackColor = &HFF8080
            tggMon(7).BackColor = &HFF8080
            tggTue(7).BackColor = &HFF8080
            tggWed(7).BackColor = &HFF8080
            tggThu(7).BackColor = &HFF8080
            tggFri(7).BackColor = &HFF8080
            tggSat(7).BackColor = &HFF8080
        End If
    End If
    tggH7.Value = False
End Sub


Private Sub tggH8_Click()
    If tggH8.Value = True Then
        If tggSun(8).BackColor = &HFF8080 Then
            tggSun(8).BackColor = &HFFFFFF
            tggMon(8).BackColor = &HFFFFFF
            tggTue(8).BackColor = &HFFFFFF
            tggWed(8).BackColor = &HFFFFFF
            tggThu(8).BackColor = &HFFFFFF
            tggFri(8).BackColor = &HFFFFFF
            tggSat(8).BackColor = &HFFFFFF
        Else
            tggSun(8).BackColor = &HFF8080
            tggMon(8).BackColor = &HFF8080
            tggTue(8).BackColor = &HFF8080
            tggWed(8).BackColor = &HFF8080
            tggThu(8).BackColor = &HFF8080
            tggFri(8).BackColor = &HFF8080
            tggSat(8).BackColor = &HFF8080
        End If
    End If
    tggH8.Value = False
End Sub


Private Sub tggH9_Click()
    If tggH9.Value = True Then
        If tggSun(9).BackColor = &HFF8080 Then
            tggSun(9).BackColor = &HFFFFFF
            tggMon(9).BackColor = &HFFFFFF
            tggTue(9).BackColor = &HFFFFFF
            tggWed(9).BackColor = &HFFFFFF
            tggThu(9).BackColor = &HFFFFFF
            tggFri(9).BackColor = &HFFFFFF
            tggSat(9).BackColor = &HFFFFFF
        Else
            tggSun(9).BackColor = &HFF8080
            tggMon(9).BackColor = &HFF8080
            tggTue(9).BackColor = &HFF8080
            tggWed(9).BackColor = &HFF8080
            tggThu(9).BackColor = &HFF8080
            tggFri(9).BackColor = &HFF8080
            tggSat(9).BackColor = &HFF8080
        End If
    End If
    tggH9.Value = False
End Sub


Private Sub tggMon_Click(Index As Integer)
    If tggMon(Index).Value = True And Index <> 0 Then
        If tggMon(Index).BackColor = &HFF8080 Then
            tggMon(Index).BackColor = &HFFFFFF
        Else
            tggMon(Index).BackColor = &HFF8080
        End If
    End If
    If tggMon(0).Value = True Then
        If tggMon(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggMon(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggMon(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggMon(Index).Value = False
End Sub

Private Sub tggSat_Click(Index As Integer)
    If tggSat(Index).Value = True And Index <> 0 Then
        If tggSat(Index).BackColor = &HFF8080 Then
            tggSat(Index).BackColor = &HFFFFFF
        Else
            tggSat(Index).BackColor = &HFF8080
        End If
    End If
    If tggSat(0).Value = True Then
        If tggSat(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggSat(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggSat(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggSat(Index).Value = False
End Sub

Private Sub tggSun_Click(Index As Integer)
    If tggSun(Index).Value = True And Index <> 0 Then
        If tggSun(Index).BackColor = &HFF8080 Then
            tggSun(Index).BackColor = &HFFFFFF
        Else
            tggSun(Index).BackColor = &HFF8080
        End If
    End If
    If tggSun(0).Value = True Then
        If tggSun(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggSun(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggSun(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggSun(Index).Value = False
End Sub

Private Sub tggThu_Click(Index As Integer)
    If tggThu(Index).Value = True And Index <> 0 Then
        If tggThu(Index).BackColor = &HFF8080 Then
            tggThu(Index).BackColor = &HFFFFFF
        Else
            tggThu(Index).BackColor = &HFF8080
        End If
    End If
    If tggThu(0).Value = True Then
        If tggThu(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggThu(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggThu(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggThu(Index).Value = False
End Sub

Private Sub tggTue_Click(Index As Integer)
    If tggTue(Index).Value = True And Index <> 0 Then
        If tggTue(Index).BackColor = &HFF8080 Then
            tggTue(Index).BackColor = &HFFFFFF
        Else
            tggTue(Index).BackColor = &HFF8080
        End If
    End If
    If tggTue(0).Value = True Then
        If tggTue(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggTue(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggTue(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggTue(Index).Value = False
End Sub

Private Sub tggWed_Click(Index As Integer)
    If tggWed(Index).Value = True And Index <> 0 Then
        If tggWed(Index).BackColor = &HFF8080 Then
            tggWed(Index).BackColor = &HFFFFFF
        Else
            tggWed(Index).BackColor = &HFF8080
        End If
    End If
    If tggWed(0).Value = True Then
        If tggWed(1).BackColor = &HFF8080 Then
            For i = 1 To 24
            tggWed(i).BackColor = &HFFFFFF
            Next i
        Else
            For i = 1 To 24
            tggWed(i).BackColor = &HFF8080
            Next i
        End If
    End If
    tggWed(Index).Value = False
End Sub
