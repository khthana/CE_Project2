Attribute VB_Name = "mdActiveDirectory"
Public DomainName As String
Public TypeOfDomain As String
Public ouName As String
Public data As String
Public Field As String
Public Sub FindDN_TOD()
    Dim i As Integer
    Dim StrTmp, Check As String
    Set objRootDSE = GetObject("LDAP://rootDSE")
    Set objSchema = GetObject("LDAP://" & objRootDSE.Get("schemaNamingContext"))
    strSchemaMaster = objSchema.Get("fSMORoleOwner")
    StrTmp = CStr(strSchemaMaster)
        '---------Cut string from strSchemaMaster
        i = 0
        Do While Check <> ","
        Check = Mid(StrTmp, Len(StrTmp) - i, 1)
            If Check = "," Then
            TypeOfDomain = Right(StrTmp, i)
            TypeOfDomain = Right(TypeOfDomain, Len(TypeOfDomain) - 3)
            End If
        i = i + 1
        Loop
        StrTmp = Left(StrTmp, Len(StrTmp) - i)
        i = 0
        Check = ""
        Do While Check <> ","
        Check = Mid(StrTmp, Len(StrTmp) - i, 1)
            If Check = "," Then
            DomainName = Right(StrTmp, i)
            DomainName = Right(DomainName, Len(DomainName) - 3)
            End If
        i = i + 1
        Loop
End Sub
Public Sub CreateOU(Name As String)
    Dim cont As IADsContainer
    Set cont = GetObject("LDAP://DC=" + DomainName + ",DC=" + TypeOfDomain)
    On Error Resume Next
    Set Org = cont.Create("organizationalUnit", "OU=" + Name)
    ouName = Name
    'Org.Put "description", "Sales Headquarter,SF"
    'Org.Put "wwwHomePage", "http://fabrikam.com/sales"
    Org.SetInfo
End Sub
Public Sub PutDataInUserAccount(CN As String)
    Dim cont As IADsContainer
    Dim usr As IADsUser
    Set cont = GetObject("LDAP://OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
    'Set cont = GetObject("LDAP://OU=Room205,DC=Mars,DC=local")
    On Error Resume Next
    'Set usr = GetObject("LDAP://CN=" + CN + ",OU=Room205,DC=Mars,DC=local")
    Set usr = GetObject("LDAP://CN=" + CN + ",OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
    
    If Field = "*User logon name*" Then
        On Error GoTo errHandle
        Set usr = cont.Create("user", "CN=" + CN)
        usr.Put "samAccountName", data
        usr.Put "userPrincipalName", data
        usr.SetInfo
    ElseIf Field = "City" Then
        usr.Put "c", data
        usr.SetInfo
    ElseIf Field = "Company" Then
        usr.Put "company", data
        usr.SetInfo
    ElseIf Field = "Department" Then
        usr.Department = data
        usr.SetInfo
    ElseIf Field = "Description" Then
        usr.Description = data
        usr.SetInfo
    ElseIf Field = "Display name" Then
        usr.Put "displayName", data
        usr.SetInfo
    ElseIf Field = "E-mail" Then
        usr.EmailAddress = data
        usr.SetInfo
    ElseIf Field = "Fax number" Then
        usr.FaxNumber = data
        usr.SetInfo
    ElseIf Field = "First name" Then
        usr.FirstName = data
        usr.SetInfo
    ElseIf Field = "Full name" Then
        usr.FullName = data
        usr.SetInfo
    ElseIf Field = "Home page" Then
        usr.HomePage = data
        usr.SetInfo
    ElseIf Field = "Initials" Then
        usr.Put "initials", data
        usr.SetInfo
    ElseIf Field = "IP phone" Then
        usr.Put "ipPhone", data
        usr.SetInfo
    ElseIf Field = "Last name" Then
        usr.LastName = data
        usr.SetInfo
    ElseIf Field = "Office" Then
        usr.OfficeLocations = data
        usr.SetInfo
    ElseIf Field = "P.O. Box" Then
        usr.Put "postOfficeBox", data
        usr.SetInfo
    ElseIf Field = "Postal code" Then
        usr.PostalCodes = data
        usr.SetInfo
    ElseIf Field = "State/Province" Then
        usr.Put "st", data
        usr.SetInfo
    ElseIf Field = "Street" Then
        usr.Put "streetAddress", data
        usr.SetInfo
    ElseIf Field = "Telephone home" Then
        usr.TelephoneHome = data
        usr.SetInfo
    ElseIf Field = "Telephone mobile" Then
        usr.TelephoneMobile = data
        usr.SetInfo
    ElseIf Field = "Telephone pager" Then
        usr.TelephonePager = data
        usr.SetInfo
    ElseIf Field = "Title" Then
        usr.Title = data
        usr.SetInfo
    ElseIf Field = "Password" Then
        usr.SetPassword (data)
    End If
    Exit Sub
errHandle:
    frmTerminal.Text1.Text = frmTerminal.Text1.Text + vbNewLine + "Can not Create User account " + CN
End Sub

Public Sub SetPwd(CN As String)
    Dim usr As IADsUser
    Set usr = GetObject("LDAP://CN=" + CN + ",OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
    usr.SetPassword (data)
End Sub
Public Sub SetDateExpire(CN As String)
    Dim usr As IADsUser
    Set usr = GetObject("LDAP://CN=" + CN + ",OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
    usr.AccountExpirationDate = data
    usr.SetInfo
End Sub
Public Sub PutHomeDirectory(CN As String)
    Dim usr As IADsUser
    Set usr = GetObject("LDAP://CN=" + CN + ",OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
    usr.HomeDirectory = data
    usr.SetInfo
End Sub
'Public Sub SetUserMustChgPwdNextLogon(CN As String)
'    Dim usr As IADsUser
'    Set usr = GetObject("LDAP://CN=" + CN + ",OU=" + ouName + ",DC=" + DomainName + ",DC=" + TypeOfDomain)
'    usr.PasswordExpirationDate = CLng(1)  ' User must change password.
'    usr.SetInfo
'End Sub
