// DaoNetworkSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoNetworkSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoNetworkSet

IMPLEMENT_DYNAMIC(CDaoNetworkSet, CDaoRecordset)

CDaoNetworkSet::CDaoNetworkSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoNetworkSet)
	m_NetworkAddress = _T("");
	m_Netmask = _T("");
	m_ConnectTime = (DATE)0;
	m_ConnectDate = (DATE)0;
	m_DisconnectTime = (DATE)0;
	m_DisconnectDate = (DATE)0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoNetworkSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoNetworkSet::GetDefaultSQL()
{
	return _T("[Network]");
}

void CDaoNetworkSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoNetworkSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[NetworkAddress]"), m_NetworkAddress);
	DFX_Text(pFX, _T("[Netmask]"), m_Netmask);
	DFX_DateTime(pFX, _T("[ConnectTime]"), m_ConnectTime);
	DFX_DateTime(pFX, _T("[ConnectDate]"), m_ConnectDate);
	DFX_DateTime(pFX, _T("[DisconnectTime]"), m_DisconnectTime);
	DFX_DateTime(pFX, _T("[DisconnectDate]"), m_DisconnectDate);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoNetworkSet diagnostics

#ifdef _DEBUG
void CDaoNetworkSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoNetworkSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
