#if !defined(AFX_WAITDLG_H__87AF3C6F_E7BA_4267_868E_E546A09E820D__INCLUDED_)
#define AFX_WAITDLG_H__87AF3C6F_E7BA_4267_868E_E546A09E820D__INCLUDED_

#include "WWaitThread.h"	// Added by ClassView

///////////////////////////
// MY INCLUDE START HERE
///////////////////////////
#include "resource.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WaitDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWaitDlg dialog

class CWaitDlg : public CDialog
{
// Construction
public:
	void SetShowMessage( CString strShow );
	bool m_bShowCancelButton;
	CWWaitThread *m_Thread;
	CWaitDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWaitDlg)
	enum { IDD = IDD_DIALOG_WAIT };
	CProgressCtrl	m_ctlProgressWait;
	CString	m_strShow;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWaitDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWaitDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAITDLG_H__87AF3C6F_E7BA_4267_868E_E546A09E820D__INCLUDED_)
