// AddToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "AddToolDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddToolDlg dialog


CAddToolDlg::CAddToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddToolDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddToolDlg)
	m_strToolName = _T("");
	m_strToolPath = _T("");
	m_strParameter = _T("");
	//}}AFX_DATA_INIT
}


void CAddToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddToolDlg)
	DDX_Control(pDX, IDC_BUTTON_REMOVETOOL, m_ctlRemoveTool);
	DDX_Control(pDX, IDC_BUTTON_ADDTOOL, m_ctlAddTool);
	DDX_Control(pDX, IDC_LIST_TOOL, m_ctlListTool);
	DDX_Text(pDX, IDC_EDIT_TOOLNAME, m_strToolName);
	DDX_Text(pDX, IDC_EDIT_TOOLPATH, m_strToolPath);
	DDX_Text(pDX, IDC_EDIT_ARGUMENTS, m_strParameter);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddToolDlg, CDialog)
	//{{AFX_MSG_MAP(CAddToolDlg)
	ON_BN_CLICKED(IDC_BUTTON_ADDTOOL, OnButtonAddtool)
	ON_BN_CLICKED(IDC_BUTTON_REMOVETOOL, OnButtonRemovetool)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddToolDlg message handlers

BOOL CAddToolDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	LV_COLUMN lvColumn;

	// Insert Column to List Control
	//		Tool Name  |  Tool Path   |   Arguments
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt = LVCFMT_LEFT;

	lvColumn.pszText = "Tool Name";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 100;
	m_ctlListTool.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Tool Path";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 150;
	m_ctlListTool.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Arguments";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 150;
	m_ctlListTool.InsertColumn( 2, &lvColumn );

	m_strToolName.Empty( );
	m_strToolPath.Empty( );
	m_strParameter	= "%a";
	UpdateData( FALSE );
	this->ShowList( );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//////////////////////////////////////////////////////////////////////
//	Description : Show tool in list control
//
void CAddToolDlg::ShowList()
{
	//////////////////////////
	// MY START START HERE
	//////////////////////////
	m_ctlListTool.DeleteAllItems( );

	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------
	LV_ITEM lvItem;
	CToolArray *pTools;
	CTool *pTool;
	int i, iSizeTool;
	int iRow = 0; // row position in list control
	CString strToolName;
	CString strToolPath;
	CString strParameter;
	char *cToolName;
	char *cToolPath;
	char *cParameter;


	pTools = m_pDiscover->GetTools( );
	iSizeTool = pTools->GetSize( );

	for ( i=0; i<iSizeTool; i++ ) {
		pTool = pTools->ElementAt( i );

		strToolName = pTool->GetToolName( );
		strToolPath = pTool->GetToolPath( );
		strParameter= pTool->GetParameter( );
		cToolName	= strToolName.GetBuffer( 255 );
		cToolPath	= strToolPath.GetBuffer( 1024 );
		cParameter	= strParameter.GetBuffer( 1024 );

		//-----------------------
		// Add to list control
		//-----------------------
		// row iRow
		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = iRow;
		iRow++;	// update iRow to next row
		lvItem.iSubItem = 0;
		lvItem.pszText = cToolName;
		m_ctlListTool.InsertItem( &lvItem );
		lvItem.iSubItem = 1;
		lvItem.pszText = cToolPath;
		m_ctlListTool.SetItem( &lvItem );
		lvItem.iSubItem = 2;
		lvItem.pszText = cParameter;
		m_ctlListTool.SetItem( &lvItem );
		//-----------------------
		// Add to list control
		//-----------------------
	}
	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------

	if ( iSizeTool < 1  ) 
		m_ctlRemoveTool.EnableWindow( FALSE );
	else 
		m_ctlRemoveTool.EnableWindow( TRUE );

	if ( iSizeTool >= 10 )
		m_ctlAddTool.EnableWindow( FALSE );
	else 
		m_ctlAddTool.EnableWindow( TRUE );
	//////////////////////////
	// MY START END HERE
	//////////////////////////
}

void CAddToolDlg::OnButtonAddtool() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY START START HERE
	//////////////////////////
	int iPosition;

	UpdateData( TRUE );

	// varidation input
	if ( m_strToolName.IsEmpty( )  || 
		 m_strToolPath.IsEmpty( )  || 
		 m_strParameter.IsEmpty( ) ) {
		MessageBox( "Please enter tool data", "Tool Data Error", MB_ICONERROR );
		return;
	}
	if ( m_strParameter.Find( "%a" ) == -1 ) {
		MessageBox( "Error parameter. Please enter again.", 
					"Error Parameter", MB_ICONERROR );
		return;
	}

	// if not found tool then add tool
	iPosition = m_pDiscover->FindTool( m_strToolName );
	if ( iPosition == -1 ) {
		m_pDiscover->AddTool( m_strToolName, m_strToolPath, m_strParameter );
	}
	else {
		MessageBox( "This tool is already exist", "Tool Exist", MB_ICONINFORMATION );
	}

	m_strToolName.Empty( );
	m_strToolPath.Empty( );
	m_strParameter	= "%a";
	UpdateData( FALSE );

	this->ShowList( );
	//////////////////////////
	// MY START END HERE
	//////////////////////////
}

void CAddToolDlg::OnButtonRemovetool() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY START START HERE
	//////////////////////////
	int iPosition, iToolPosition;
	CString strToolName;
	CToolArray *pTools;

	iPosition = m_ctlListTool.GetSelectionMark( );
	// if select mask
	if ( iPosition != -1 ) {
		// find tool name and use in to find position to delete
		strToolName = m_ctlListTool.GetItemText( iPosition, 0 );
		iToolPosition = m_pDiscover->FindTool( strToolName );
		if ( iToolPosition != -1 ) {
			pTools = m_pDiscover->GetTools( );
			pTools->RemoveAt( iToolPosition );
		}
	}

	this->ShowList( );
	//////////////////////////
	// MY START END HERE
	//////////////////////////
}

void CAddToolDlg::OnButtonBrowse() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY START START HERE
	//////////////////////////
	CString strToolName;

	UpdateData( TRUE );
	strToolName = m_strToolName;
	char filter[ ] = "Executable File (*.exe)|*.exe||";
	CFileDialog *fdBrowse = new CFileDialog( TRUE, 
											 "exe",
											 NULL,
											 NULL,
											 filter );
	//fdBrowse->m_ofn.Flags |= OFN_NOCHANGEDIR;
	if ( fdBrowse->DoModal( ) == IDOK ) {
		// update data
		m_strToolName = strToolName;
		m_strToolPath = fdBrowse->GetPathName( );
		UpdateData( FALSE );

		// set default path
		CNetviewApp *pNetviewApp = (CNetviewApp*)::AfxGetApp( );
		::SetCurrentDirectory( pNetviewApp->m_strStartingDirectory );
	}
	//////////////////////////
	// MY START END HERE
	//////////////////////////
}
