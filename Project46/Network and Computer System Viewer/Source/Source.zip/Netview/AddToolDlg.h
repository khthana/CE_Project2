#if !defined(AFX_ADDTOOLDLG_H__90D20BB8_A1A5_4929_A67D_83E8392B5E78__INCLUDED_)
#define AFX_ADDTOOLDLG_H__90D20BB8_A1A5_4929_A67D_83E8392B5E78__INCLUDED_

#include "Discover.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddToolDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddToolDlg dialog

class CAddToolDlg : public CDialog
{
// Construction
public:
	CDiscover *m_pDiscover;
	CAddToolDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddToolDlg)
	enum { IDD = IDD_DIALOG_ADD_TOOL };
	CButton	m_ctlRemoveTool;
	CButton	m_ctlAddTool;
	CListCtrl	m_ctlListTool;
	CString	m_strToolName;
	CString	m_strToolPath;
	CString	m_strParameter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void ShowList( );

	// Generated message map functions
	//{{AFX_MSG(CAddToolDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonAddtool();
	afx_msg void OnButtonRemovetool();
	afx_msg void OnButtonBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDTOOLDLG_H__90D20BB8_A1A5_4929_A67D_83E8392B5E78__INCLUDED_)
