// WizPage03.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "WizPage03.h"

//////////////////////////////////
// MY INCLUDE START HERE
//////////////////////////////////
#include "DaoPortSet.h"
#include "ServiceDlg.h"
//////////////////////////////////
// MY INCLUDE END HERE
//////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizPage03 property page

IMPLEMENT_DYNCREATE(CWizPage03, CPropertyPage)

CWizPage03::CWizPage03() : CPropertyPage(CWizPage03::IDD)
{
	//{{AFX_DATA_INIT(CWizPage03)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWizPage03::~CWizPage03()
{
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	// Clear String Array
	if ( m_saPortNumber.GetSize( ) > 0 )
		m_saPortNumber.RemoveAll( );
	if ( m_saProtocol.GetSize( ) > 0 )
		m_saProtocol.RemoveAll( );
	if ( m_saPortName.GetSize( ) > 0 )
		m_saPortName.RemoveAll( );
	if ( m_saTrojan.GetSize( ) > 0 )
		m_saTrojan.RemoveAll( );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage03::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizPage03)
	DDX_Control(pDX, IDC_LIST_SERVICE, m_ctlListService);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizPage03, CPropertyPage)
	//{{AFX_MSG_MAP(CWizPage03)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_ADDSERVICE, OnButtonAddservice)
	ON_BN_CLICKED(IDC_BUTTON_REMOVESERVICE, OnButtonRemoveservice)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizPage03 message handlers

BOOL CWizPage03::OnSetActive() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CPropertySheet *pSheet = ( CPropertySheet* )this->GetParent( );
	pSheet->SetWizardButtons( PSWIZB_BACK | PSWIZB_NEXT | PSWIZB_FINISH );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnSetActive();
}

BOOL CWizPage03::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	LV_COLUMN lvColumn;
	LV_ITEM lvItem;
	int iRow = 0; // row position in list control

	// Insert Column to List Control
	//	Port Number	| Protocol |	 Port Name    | Trojan	
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt = LVCFMT_CENTER;

	lvColumn.pszText = "Port Number";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 75;
	m_ctlListService.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Protocol";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 60;
	m_ctlListService.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Port Name";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 145;
	m_ctlListService.InsertColumn( 2, &lvColumn );

	lvColumn.pszText = "Trojan";
	lvColumn.iSubItem = 3;
	lvColumn.cx = 50;
	m_ctlListService.InsertColumn( 3, &lvColumn );

	//----------------------------------------------------------------------------
	// Get trojan and want detect data from database and show it to list control
	//----------------------------------------------------------------------------
	CDaoPortSet daoPortSet;	// port table object (DAO)
	CString strSQL;			// SQL Statement

	long	lPortNumber;
	CString	strProtocol;
	CString	strPortName;
	char	cPortNumber[5];
	char	*cProtocol;
	char	*cPortName;
	
	//------------------------------------------------
	// create select want detect port SQL Statement
	//------------------------------------------------
	strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port WHERE Trojan=FALSE AND WantDetect=TRUE";

	// open database
	if ( daoPortSet.IsOpen( ) ) 
		daoPortSet.Close( );
	daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

	if ( !daoPortSet.IsEOF( ) ) {
		daoPortSet.MoveFirst( );
		while ( !daoPortSet.IsEOF( ) ) {
			lPortNumber	= daoPortSet.m_PortNumber;
			strProtocol	= daoPortSet.m_Protocol;
			strPortName	= daoPortSet.m_PortName;
			_ltoa( lPortNumber, cPortNumber, 10 );
			cProtocol	= strProtocol.GetBuffer( 3 );
			cPortName	= strPortName.GetBuffer( 255 );
			
			//-----------------------
			// Add to list control
			//-----------------------
			// row iRow
			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = iRow;
			iRow++;	// update iRow to next row
			lvItem.iSubItem = 0;
			lvItem.pszText = cPortNumber;
			m_ctlListService.InsertItem( &lvItem );
			lvItem.iSubItem = 1;
			lvItem.pszText = cProtocol;
			m_ctlListService.SetItem( &lvItem );
			lvItem.iSubItem = 2;
			lvItem.pszText = cPortName;
			m_ctlListService.SetItem( &lvItem );
			lvItem.iSubItem = 3;
			lvItem.pszText = "NO";
			m_ctlListService.SetItem( &lvItem );
			//-----------------------
			// Add to list control
			//-----------------------

			// Update Position
			daoPortSet.MoveNext( );
		}
	}
	daoPortSet.Close( );
	//------------------------------------------------
	// create select want detect port SQL Statement
	//------------------------------------------------

	//------------------------------------------------
	// create select trojan port SQL Statement
	//------------------------------------------------
	strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port WHERE Trojan=TRUE";

	// open database
	if ( daoPortSet.IsOpen( ) ) 
		daoPortSet.Close( );
	daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

	if ( !daoPortSet.IsEOF( ) ) {
		daoPortSet.MoveFirst( );
		while ( !daoPortSet.IsEOF( ) ) {
			lPortNumber	= daoPortSet.m_PortNumber;
			strProtocol	= daoPortSet.m_Protocol;
			strPortName	= daoPortSet.m_PortName;
			_ltoa( lPortNumber, cPortNumber, 10 );
			cProtocol	= strProtocol.GetBuffer( 3 );
			cPortName	= strPortName.GetBuffer( 255 );
			
			//-----------------------
			// Add to list control
			//-----------------------
			// row iRow
			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = iRow;
			iRow++;	// update iRow to next row
			lvItem.iSubItem = 0;
			lvItem.pszText = cPortNumber;
			m_ctlListService.InsertItem( &lvItem );
			lvItem.iSubItem = 1;
			lvItem.pszText = cProtocol;
			m_ctlListService.SetItem( &lvItem );
			lvItem.iSubItem = 2;
			lvItem.pszText = cPortName;
			m_ctlListService.SetItem( &lvItem );
			lvItem.iSubItem = 3;
			lvItem.pszText = "YES";
			m_ctlListService.SetItem( &lvItem );
			//-----------------------
			// Add to list control
			//-----------------------

			// Update Position
			daoPortSet.MoveNext( );
		}
	}
	daoPortSet.Close( );
	//------------------------------------------------
	// create select trojan port SQL Statement
	//------------------------------------------------
	
	//----------------------------------------------------------------------------
	// Get trojan and want detect data from database and show it to list control
	//----------------------------------------------------------------------------
	/*
	// init default value to column
	//	1-1024	 |	TCP	  |		Well Known Port		| NO
	//	1-1024	 |	UDP	  |		Well Known Port		| NO
	lvItem.mask = LVIF_TEXT;

	// row 0
	lvItem.iItem = 0;
	lvItem.iSubItem = 0;
	lvItem.pszText = "1-1024";
	m_ctlListService.InsertItem( &lvItem );
	lvItem.iSubItem = 1;
	lvItem.pszText = "TCP";
	m_ctlListService.SetItem( &lvItem );
	lvItem.iSubItem = 2;
	lvItem.pszText = "Well Known Port";
	m_ctlListService.SetItem( &lvItem );
	lvItem.iSubItem = 3;
	lvItem.pszText = "NO";
	m_ctlListService.SetItem( &lvItem );

	// row 1
	lvItem.iItem = 1;
	lvItem.iSubItem = 0;
	lvItem.pszText = "1-1024";
	m_ctlListService.InsertItem( &lvItem );
	lvItem.iSubItem = 1;
	lvItem.pszText = "UDP";
	m_ctlListService.SetItem( &lvItem );
	lvItem.iSubItem = 2;
	lvItem.pszText = "Well Known Port";
	m_ctlListService.SetItem( &lvItem );
	lvItem.iSubItem = 3;
	lvItem.pszText = "NO";
	m_ctlListService.SetItem( &lvItem );
	*/
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWizPage03::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CPropertySheet *pSheet = ( CPropertySheet* )this->GetParent( );
	pSheet->SetTitle( "TCP/IP Service Scan - Step 3 of 3" );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
	
	// Do not call CPropertyPage::OnPaint() for painting messages
}

BOOL CWizPage03::OnQueryCancel() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	if ( MessageBox( "Are you sure to quit?", "Quit", 
					 MB_YESNO | MB_ICONINFORMATION ) == IDNO ) {
		return FALSE;
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnQueryCancel();
}

void CWizPage03::OnButtonAddservice() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CServiceDlg dlgService;
	LV_ITEM lvItem;
	int iItem;
	const int MAXBUFFER = 255;
	char *cTemp;
	CString strTemp;

	if ( dlgService.DoModal( ) == IDOK ) {
		lvItem.mask = LVIF_TEXT;
		iItem = m_ctlListService.GetItemCount( );
		lvItem.iItem = iItem;
		
		// column 1
		lvItem.iSubItem = 0;
		if ( dlgService.m_iCatagory == 0 ) {		// Single Catagory
			cTemp = dlgService.m_strStartPort.GetBuffer( MAXBUFFER );
			lvItem.pszText = cTemp;
		}
		else if ( dlgService.m_iCatagory == 1 ) {	// Range Catagory
			strTemp = dlgService.m_strStartPort + "-" + dlgService.m_strEndPort;
			cTemp = strTemp.GetBuffer( MAXBUFFER );
			lvItem.pszText = cTemp;
		}
		m_ctlListService.InsertItem( &lvItem );

		// column 2
		lvItem.iSubItem = 1;
		if ( dlgService.m_iProtocal == 0 )
			lvItem.pszText = "TCP";
		else if ( dlgService.m_iProtocal == 1 ) 
			lvItem.pszText = "UDP";
		m_ctlListService.SetItem( &lvItem );

		// column 3
		lvItem.iSubItem = 2;
		cTemp = dlgService.m_strPortBanner.GetBuffer( MAXBUFFER );
		lvItem.pszText = cTemp;
		m_ctlListService.SetItem( &lvItem );

		// column 4
		lvItem.iSubItem = 3;
		if ( dlgService.m_bTrojanPort ) 
			lvItem.pszText = "YES";
		else
			lvItem.pszText = "NO";
		m_ctlListService.SetItem( &lvItem );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage03::OnButtonRemoveservice() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	int iItem; 
	CButton *ctlRemoveService;

	// remove service item
	iItem = m_ctlListService.GetSelectionMark( );
	m_ctlListService.DeleteItem( iItem );

	// Disible Remove Service 's Button if List Control Empty
	if ( m_ctlListService.GetItemCount( ) == 0 ) {
		ctlRemoveService = (CButton*)GetDlgItem( IDC_BUTTON_REMOVESERVICE );
		ctlRemoveService->EnableWindow( FALSE );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

BOOL CWizPage03::OnWizardFinish() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	
	// copy List Control 's data to String Array
	for ( int i=0; i<m_ctlListService.GetItemCount( ); i++ ) {
		m_saPortNumber.Add( m_ctlListService.GetItemText( i, 0 ) );
		m_saProtocol.Add( m_ctlListService.GetItemText( i, 1 ) );
		m_saPortName.Add( m_ctlListService.GetItemText( i, 2 ) );
		m_saTrojan.Add( m_ctlListService.GetItemText( i, 3 ) );
	}

	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnWizardFinish();
}
