// DaoGroupSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoGroupSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoGroupSet

IMPLEMENT_DYNAMIC(CDaoGroupSet, CDaoRecordset)

CDaoGroupSet::CDaoGroupSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoGroupSet)
	m_IP = _T("");
	m_GroupName = _T("");
	m_GroupComment = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoGroupSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoGroupSet::GetDefaultSQL()
{
	return _T("[Group]");
}

void CDaoGroupSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoGroupSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[GroupName]"), m_GroupName);
	DFX_Text(pFX, _T("[GroupComment]"), m_GroupComment);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoGroupSet diagnostics

#ifdef _DEBUG
void CDaoGroupSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoGroupSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
