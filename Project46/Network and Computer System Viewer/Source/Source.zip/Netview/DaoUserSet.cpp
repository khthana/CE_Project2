// DaoUserSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoUserSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoUserSet

IMPLEMENT_DYNAMIC(CDaoUserSet, CDaoRecordset)

CDaoUserSet::CDaoUserSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoUserSet)
	m_IP = _T("");
	m_UserName = _T("");
	m_UserComment = _T("");
	m_FullName = _T("");
	m_AccountEnable = FALSE;
	m_PWRequired = FALSE;
	m_PWCanChange = FALSE;
	m_PWNotExpire = FALSE;
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoUserSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoUserSet::GetDefaultSQL()
{
	return _T("[User]");
}

void CDaoUserSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoUserSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[UserName]"), m_UserName);
	DFX_Text(pFX, _T("[UserComment]"), m_UserComment);
	DFX_Text(pFX, _T("[FullName]"), m_FullName);
	DFX_Bool(pFX, _T("[AccountEnable]"), m_AccountEnable);
	DFX_Bool(pFX, _T("[PWRequired]"), m_PWRequired);
	DFX_Bool(pFX, _T("[PWCanChange]"), m_PWCanChange);
	DFX_Bool(pFX, _T("[PWNotExpire]"), m_PWNotExpire);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoUserSet diagnostics

#ifdef _DEBUG
void CDaoUserSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoUserSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
