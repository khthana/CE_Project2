#if !defined(AFX_PROPSHAREPAGE_H__37A02723_9C02_463C_B454_C03843C4A6FF__INCLUDED_)
#define AFX_PROPSHAREPAGE_H__37A02723_9C02_463C_B454_C03843C4A6FF__INCLUDED_

#include "TypeShareArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropSharePage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropSharePage dialog

class CPropSharePage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropSharePage)

// Construction
public:
	CShareArray m_saShares;
	CPropSharePage();
	~CPropSharePage();

// Dialog Data
	//{{AFX_DATA(CPropSharePage)
	enum { IDD = IDD_PROPPAGE_SHARE };
	CListCtrl	m_ctlListShare;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropSharePage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropSharePage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPSHAREPAGE_H__37A02723_9C02_463C_B454_C03843C4A6FF__INCLUDED_)
