#if !defined(AFX_SETAUTOREFRESHDLG_H__705F33FA_4BF8_40C9_9A29_04CF1182B9DD__INCLUDED_)
#define AFX_SETAUTOREFRESHDLG_H__705F33FA_4BF8_40C9_9A29_04CF1182B9DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetAutoRefreshDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetAutoRefreshDlg dialog

class CSetAutoRefreshDlg : public CDialog
{
// Construction
public:
	CSetAutoRefreshDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSetAutoRefreshDlg)
	enum { IDD = IDD_DIALOG_SET_AUTO_REFRESH };
	CSpinButtonCtrl	m_ctlSpinSecond;
	CSpinButtonCtrl	m_ctlSpinMinute;
	CSpinButtonCtrl	m_ctlSpinHour;
	CEdit	m_ctlSecond;
	CEdit	m_ctlMinute;
	CEdit	m_ctlHour;
	BOOL	m_bNotAutoRefresh;
	int		m_iRefreshHour;
	int		m_iRefreshMinute;
	int		m_iRefreshSecond;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetAutoRefreshDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetAutoRefreshDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckNotautorefresh();
	afx_msg void OnChangeEditHour();
	afx_msg void OnChangeEditMinute();
	afx_msg void OnChangeEditSecond();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETAUTOREFRESHDLG_H__705F33FA_4BF8_40C9_9A29_04CF1182B9DD__INCLUDED_)
