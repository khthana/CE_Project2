// Netview.h : main header file for the NETVIEW application
//

#if !defined(AFX_NETVIEW_H__99079A5A_F8B0_4450_885F_A75C3BE832D1__INCLUDED_)
#define AFX_NETVIEW_H__99079A5A_F8B0_4450_885F_A75C3BE832D1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CNetviewApp:
// See Netview.cpp for the implementation of this class
//

class CNetviewApp : public CWinApp
{
public:
	CString m_strStartingDirectory;
	BOOL IsWhileExplorer( );
	void SetWhileExplorer( BOOL bWhileExplorer );
	CNetviewApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetviewApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CNetviewApp)
	afx_msg void OnAppAbout();
	afx_msg void OnHelpNetviewHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	BOOL m_bWhileExplorer;	// TRUE=Explorer, FALSE=Not explorer
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETVIEW_H__99079A5A_F8B0_4450_885F_A75C3BE832D1__INCLUDED_)
