// Group.cpp: implementation of the CGroup class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Group.h"

////////////////////////// 
// MY HEADER START HERE
//////////////////////////
#include "DaoGroupSet.h"
#include "DaoMemberSet.h"
////////////////////////// 
// MY HEADER END HERE
//////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGroup::CGroup( CString strGroupName, CString strGroupComment, CStringArray *pGroupMembers )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->m_strGroupName	= strGroupName;
	this->m_strGroupComment	= strGroupComment;
	this->m_saGroupMembers.Copy( *pGroupMembers );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CGroup::~CGroup()
{

}

CString CGroup::GetGroupName()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return this->m_strGroupName;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CGroup::GetGroupComment()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return this->m_strGroupComment;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CStringArray* CGroup::GetGroupMembers()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &this->m_saGroupMembers;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//					Table >> Group, Member
//	Parameter	: strIP(IN)	>>	Host IP Address 's owner
void CGroup::StoreDB(CString strIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	//-------------------------------------------------------
	//  Store in table Group
	//-------------------------------------------------------
	CString strSQL;
	CDaoGroupSet daoGroupSet;

	// data
	long lRowCount;
	CString	strGroupName;
	CString strGroupComment;

	// set data
	strGroupName	= this->m_strGroupName;
	strGroupComment	= this->m_strGroupComment;

	// create SQL statement
	strSQL =  "SELECT IP, GroupName, GroupComment ";
	strSQL += "FROM [Group] WHERE IP='";
	strSQL += strIP;
	strSQL += "' AND GroupName='";
	strSQL += strGroupName;
	strSQL += "'";
	
	// open database
	if ( daoGroupSet.IsOpen( ) )
		daoGroupSet.Close( );
	daoGroupSet.Open( dbOpenDynaset, _T( strSQL ) );
	lRowCount = daoGroupSet.GetRecordCount( );

	// if row is not exist (lRowCount==0) then INSERT it
	if ( lRowCount == 0 ) {
		// Insert
		daoGroupSet.AddNew( );
		daoGroupSet.m_IP			= strIP;
		daoGroupSet.m_GroupName		= strGroupName;
		daoGroupSet.m_GroupComment	= strGroupComment;
		daoGroupSet.Update( );
	}
	// if row is exist (lRowCount>0) then UPDATE it
	else {
		// Update
		daoGroupSet.MoveFirst( );
		daoGroupSet.Edit( );
		daoGroupSet.m_GroupComment	= strGroupComment;
		daoGroupSet.Update( );
	}

	daoGroupSet.Close( );
	//-------------------------------------------------------
	//  Store in table Group
	//-------------------------------------------------------
	
	//--------------------------------
	//  Store in table Member
	//--------------------------------
	this->StoreMemberDB( strIP );
	//--------------------------------
	//  Store in table Member
	//--------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table Member
//	
void CGroup::StoreMemberDB(CString strIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	//--------------------------------
	//  Store in table Member
	//--------------------------------
	int i, iSizeMember;
	CString strSQL;
	CDaoMemberSet daoMemberSet;

	// data
	long lRowCount;
	CString	strGroupName;
	CString	strUserName;
	
	strGroupName = this->m_strGroupName;
	iSizeMember = m_saGroupMembers.GetSize( );
	for ( i=0; i<iSizeMember; i++ ) {
		strUserName = m_saGroupMembers[i];

		// create SQL statement
		strSQL =  "SELECT IP, GroupName, UserName ";
		strSQL += "FROM Member WHERE IP='";
		strSQL += strIP;
		strSQL += "' AND GroupName='";
		strSQL += strGroupName;
		strSQL += "' AND UserName='";
		strSQL += strUserName;
		strSQL += "'";

		// open database
		if ( daoMemberSet.IsOpen( ) )
			daoMemberSet.Close( );
		daoMemberSet.Open( dbOpenDynaset, _T( strSQL ) );
		lRowCount = daoMemberSet.GetRecordCount( );

		// if row is not exist (lRowCount==0) then INSERT it
		if ( lRowCount == 0 ) {
			// Insert
			daoMemberSet.AddNew( );
			daoMemberSet.m_IP		= strIP;
			daoMemberSet.m_GroupName= strGroupName;
			daoMemberSet.m_UserName	= strUserName;
			daoMemberSet.Update( );
		}
		
		daoMemberSet.Close( );
	}
	//--------------------------------
	//  Store in table Member
	//--------------------------------
	
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

