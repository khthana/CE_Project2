// AgentIPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "AgentIPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAgentIPDlg dialog


CAgentIPDlg::CAgentIPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAgentIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAgentIPDlg)
	//}}AFX_DATA_INIT
}


void CAgentIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAgentIPDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAgentIPDlg, CDialog)
	//{{AFX_MSG_MAP(CAgentIPDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAgentIPDlg message handlers

void CAgentIPDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CIPAddressCtrl *ctlIPAddressAgentIP = (CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS_AGENTIP);
	CIPAddressCtrl *ctlIPAddressNetmask = (CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS_NETMASK);
	CIPAddressCtrl *ctlIPAddressNetwork = (CIPAddressCtrl*)GetDlgItem(IDC_IPADDRESS_NETWORK);

	if ( ctlIPAddressAgentIP->IsBlank( ) ||
		 ctlIPAddressNetmask->IsBlank( ) || 
		 ctlIPAddressNetwork->IsBlank( ) ) {
		MessageBox( "Please enter IP Address in Network Address, Net Mask and Agent IP.",
					"Miss IP Address", MB_OK | MB_ICONERROR );
		return;
	}

	// copy to data member
	ctlIPAddressAgentIP->GetWindowText( m_strAgentIP );
	ctlIPAddressNetmask->GetWindowText( m_strNetmask );
	ctlIPAddressNetwork->GetWindowText( m_strNetwork );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	CDialog::OnOK();
}
