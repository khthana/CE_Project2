#if !defined(AFX_NETWORKVIEW_H__69127BF2_3F3C_4027_959F_584D6FA4B6E1__INCLUDED_)
#define AFX_NETWORKVIEW_H__69127BF2_3F3C_4027_959F_584D6FA4B6E1__INCLUDED_

#include "Host.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NetworkView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNetworkView view

class CNetworkView : public CScrollView
{
protected:
	CNetworkView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CNetworkView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetworkView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	CHost *m_pHostShowTraffic;
	CHost *m_pHostShowSnmp;
	void SetBorderRect( CRect &rectBorder, CRect &rect, int iExp );
	virtual ~CNetworkView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CNetworkView)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnNetworkSnmp();
	afx_msg void OnNetworkTraffic();
	afx_msg void OnUpdateNetworkSnmp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNetworkTraffic(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETWORKVIEW_H__69127BF2_3F3C_4027_959F_584D6FA4B6E1__INCLUDED_)
