#if !defined(AFX_WIZPAGE01_H__6F670DDA_78E8_4C1E_BA9A_CC56D6D99182__INCLUDED_)
#define AFX_WIZPAGE01_H__6F670DDA_78E8_4C1E_BA9A_CC56D6D99182__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WizPage01.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWizPage01 dialog

class CWizPage01 : public CPropertyPage
{
	DECLARE_DYNCREATE(CWizPage01)

// Construction
public:
	int m_iDiscoveryType;
	CWizPage01();
	~CWizPage01();

// Dialog Data
	//{{AFX_DATA(CWizPage01)
	enum { IDD = IDD_WIZPAGE01 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizPage01)
	public:
	virtual BOOL OnSetActive();
	virtual BOOL OnQueryCancel();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizPage01)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIZPAGE01_H__6F670DDA_78E8_4C1E_BA9A_CC56D6D99182__INCLUDED_)
