#if !defined(AFX_DAOAGENTSET_H__C69026EA_42AD_4B3E_AE77_31AB6BDCC9D7__INCLUDED_)
#define AFX_DAOAGENTSET_H__C69026EA_42AD_4B3E_AE77_31AB6BDCC9D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoAgentSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoAgentSet DAO recordset

class CDaoAgentSet : public CDaoRecordset
{
public:
	CDaoAgentSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoAgentSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoAgentSet, CDaoRecordset)
	CString	m_NetworkAddress;
	CString	m_AgentIP;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoAgentSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOAGENTSET_H__C69026EA_42AD_4B3E_AE77_31AB6BDCC9D7__INCLUDED_)
