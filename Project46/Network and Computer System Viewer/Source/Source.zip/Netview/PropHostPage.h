#if !defined(AFX_PROPHOSTPAGE_H__5E3B3CE8_78E7_458A_BF4F_F9D8EFFF623C__INCLUDED_)
#define AFX_PROPHOSTPAGE_H__5E3B3CE8_78E7_458A_BF4F_F9D8EFFF623C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropHostPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropHostPage dialog

class CPropHostPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropHostPage)

// Construction
public:
	CStringArray m_saMacAddress;
	CString m_strIP;
	CPropHostPage();
	~CPropHostPage();

// Dialog Data
	//{{AFX_DATA(CPropHostPage)
	enum { IDD = IDD_PROPPAGE_HOST };
	CListCtrl	m_ctlListMac;
	CIPAddressCtrl	m_ctlIPAddressHost;
	CStatic	m_ctlGeneral;
	CStatic	m_ctlSecurity;
	CStatic	m_ctlMac;
	CString	m_strCloseTime;
	CString	m_strHostName;
	CString	m_strLockoutDuration;
	CString	m_strLockoutReset;
	CString	m_strLockoutThreshold;
	CString	m_strOpenTime;
	CString	m_strOS;
	CString	m_strPasswordMaxAge;
	CString	m_strPasswordMinAge;
	CString	m_strPasswordMinLength;
	CString	m_strType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropHostPage)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont m_fontTitle;
	// Generated message map functions
	//{{AFX_MSG(CPropHostPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPHOSTPAGE_H__5E3B3CE8_78E7_458A_BF4F_F9D8EFFF623C__INCLUDED_)
