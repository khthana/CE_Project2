// Group.h: interface for the CGroup class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GROUP_H__46AB70C1_E0FD_403A_A1F6_78CEC9E5186D__INCLUDED_)
#define AFX_GROUP_H__46AB70C1_E0FD_403A_A1F6_78CEC9E5186D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGroup  
{
public:
	void StoreDB( CString strIP );
	CStringArray* GetGroupMembers( );
	CString GetGroupComment( );
	CString GetGroupName();
	CGroup( CString strGroupName, CString strGroupComment, CStringArray *pGroupMembers );
	virtual ~CGroup();

private:
	CStringArray m_saGroupMembers;
	CString m_strGroupComment;
	CString m_strGroupName;
protected:
	void StoreMemberDB( CString strIP );
};

#endif // !defined(AFX_GROUP_H__46AB70C1_E0FD_403A_A1F6_78CEC9E5186D__INCLUDED_)
