// Discover.cpp: implementation of the CDiscover class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Discover.h"

///////////////////////////
// MY INCLUDE START HERE 
///////////////////////////
#include "DaoPortSet.h"
#include "WWaitTarget.h"
#include "FileManip.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDiscover::CDiscover()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_timeStart = COleDateTime::GetCurrentTime( );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CDiscover::~CDiscover()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, iCount;

	// Destroy network object
	iCount = m_naNetworks.GetSize( );
	if ( iCount ) { 
		// Loop through the array, deleteing each object
		for ( i=0; i<iCount; i++ ) 
			delete m_naNetworks[i];
		m_naNetworks.RemoveAll( ); // Reset the array
	}

	// Destroy trojan port object
	iCount = m_paTrojanPorts.GetSize( );
	if ( iCount ) { 
		// Loop through the array, deleteing each object
		for ( i=0; i<iCount; i++ ) 
			delete m_paTrojanPorts[i];
		m_paTrojanPorts.RemoveAll( ); // Reset the array
	}

	// Destroy WantDetect port object
	iCount = m_paWantDetectPorts.GetSize( );
	if ( iCount ) { 
		// Loop through the array, deleteing each object
		for ( i=0; i<iCount; i++ ) 
			delete m_paWantDetectPorts[i];
		m_paWantDetectPorts.RemoveAll( ); // Reset the array
	}

	// Destroy Tool object
	iCount = m_taTools.GetSize( );
	if ( iCount ) {
		// Loop through the array, deleteing each object
		for ( i=0; i<iCount; i++ )
			delete m_taTools[i];
		m_taTools.RemoveAll( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Cut string to find host up in network (result from nmap -sP)
//	Parameter	:	strTemp(IN)	>>	string result from CRedirect (nmap -sP) 
//	Return		:	STVECTOR	>>	List of host in network
//
STVECTOR CDiscover::FindHostInNetwork(CString strTemp)
{ 
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	//Init
	int starttx,stoptx,chkpoint1,chkpoint2;
	CString Dot4,Temp;
	STVECTOR hostip;
	//get ip host
	starttx = strTemp.Find("Host",0);
	stoptx = strTemp.Find(" ",starttx+5);
	while((stoptx > 0)&&(starttx > 0))
	{
		Temp = strTemp.Mid(starttx+5,stoptx-(starttx+5));
		Dot4 = Temp.Right(Temp.GetLength()-(Temp.ReverseFind('.')+1));
		if((Dot4 != "255")&&(Dot4 != "0"))
		{
			chkpoint1 = Temp.Find(".",0);
			chkpoint2 = Temp.Find(".",chkpoint1+1);
			if((chkpoint1 >0)&&(chkpoint2 > 0))
				hostip.push_back(Temp);
		}
		starttx = strTemp.Find("Host",stoptx);
		if(starttx > 0)
			stoptx = strTemp.Find(" ",starttx+5);
	}
	return hostip;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Cut string to find detail in host such as OS, port, 
//				  hostname (result from nmap -sS)
//	Parameter	:	data(OUT)	>>	struct keep host's detail
//					strTemp(IN)	>>	string TCP result from CRedirect (nmap -sS)
//					strTrmp2(IN)>>	string UDP result from CRedirect (nmap -sU)
//					
void CDiscover::FindDetailInHost(struct scanport *data,CString strTemp,CString strTemp1)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	char temp[800];
	for(int i=0;i<strTemp1.GetLength();i++)
		temp[i] = strTemp1.GetAt(i);
	//Init
	int starttx,stoptx,flag,last;;
	flag = 0;
	//get hostname
	starttx = strTemp.Find("ports on",0);
	stoptx = strTemp.Find(" (",starttx);
	data->hostname = strTemp.Mid(starttx+9,(stoptx)-(starttx+9));
	//get ip
	starttx = stoptx;
	stoptx = strTemp.Find("):",starttx);
	data->ip = strTemp.Mid(starttx+2,(stoptx)-(starttx+2));
	//get port
	starttx = stoptx+8;
	stoptx = strTemp.Find(" ports",starttx);
	if(stoptx > 0)
	{
		data->port = strTemp.Mid(starttx+1,stoptx-(starttx+1));
		//get numport,protocol,state,service
		last =strTemp.Find("Device type",stoptx);
		starttx = strTemp.Find("SERVICE",stoptx);
		stoptx = strTemp.Find("/",starttx);
		data->numport.push_back(strTemp.Mid(starttx+9,(stoptx)-(starttx+9)));
		starttx = stoptx;
		stoptx = strTemp.Find(" ",starttx);
		data->protocol.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
		starttx = stoptx;
		while(strTemp.Find(" ",starttx+1) == starttx+1)
			starttx++;
		stoptx = strTemp.Find(" ",starttx+1);
		data->state.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
		starttx = stoptx;
		while(strTemp.Find(" ",starttx+1) == starttx+1)
			starttx++;
		stoptx = strTemp.Find("\n",starttx+1);
		data->service.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
		while((stoptx < last)&&(stoptx > 0))
		{	
			starttx = stoptx;
			stoptx = strTemp.Find("/",starttx);
			if((stoptx < last)&&(stoptx > 0))
			{
				data->numport.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				stoptx = strTemp.Find(" ",starttx);
				data->protocol.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp.Find(" ",starttx+1);
				data->state.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp.Find("\n",starttx+1);
				data->service.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));	
			}
			else
				stoptx = last+1;
		}
		//get type
		starttx = last;
		stoptx = strTemp.Find("\n",starttx);
		data->type = strTemp.Mid(starttx+13,stoptx-(starttx+13));
		//get os
		starttx = strTemp.Find("OS details:",stoptx);
		stoptx = strTemp.Find("\n",starttx);
		data->os = strTemp.Mid(starttx+11,stoptx-(starttx+11));
	}
	starttx = strTemp1.Find("ports on",0);
	starttx = strTemp1.Find(")",starttx);
	starttx = strTemp1.Find("SERVICE",starttx);
	if(starttx > 0)
	{
		stoptx = strTemp1.Find("/",starttx);
		if(strTemp1.Mid(starttx+9,(stoptx)-(starttx+9)) != "0")
		{
			last =strTemp1.Find("\r\n\r\n",stoptx);
			data->numport.push_back(strTemp1.Mid(starttx+9,(stoptx)-(starttx+9)));
			starttx = stoptx;
			stoptx = strTemp1.Find(" ",starttx);
			data->protocol.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
			starttx = stoptx;
			while(strTemp1.Find(" ",starttx+1) == starttx+1)
				starttx++;
			stoptx = strTemp1.Find(" ",starttx+1);
			data->state.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
			starttx = stoptx;
			while(strTemp1.Find(" ",starttx+1) == starttx+1)
				starttx++;
			stoptx = strTemp1.Find("\n",starttx+1);
			data->service.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
			while((stoptx > 0)&&(stoptx < last))
			{	
				starttx = stoptx;
				stoptx = strTemp1.Find("/",starttx);
				if((stoptx > 0)&&(stoptx < last))
				{
					data->numport.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
					starttx = stoptx;
					stoptx = strTemp1.Find(" ",starttx);
					data->protocol.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
					starttx = stoptx;
					while(strTemp1.Find(" ",starttx+1) == starttx+1)
						starttx++;
					stoptx = strTemp1.Find(" ",starttx+1);
					data->state.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
					starttx = stoptx;
					while(strTemp1.Find(" ",starttx+1) == starttx+1)
						starttx++;
					stoptx = strTemp1.Find("\n",starttx+1);
					data->service.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));	
				}
			}
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Network for discovery
//	Parameter	: 
//		strNetworkAddress(IN)	>>	Network Address
//		strSubnet(IN)			>>	Subnet
//	
void CDiscover::AddNetwork(CString strNetworkAddress, CString strNetmask)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CNetwork Object
	CNetwork *pNetwork = new CNetwork( strNetworkAddress, strNetmask );
	
	try {
		// Add new Network to Network Array
		m_naNetworks.Add( pNetwork );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CNetwork Object delete it
		if ( pNetwork ) {
			delete pNetwork;
			pNetwork = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add trojan port for discovery
//	Parameter	: 
//		lPortNumber(IN)	>>
//		strProtocol(IN)	>>
//		strPortName(IN)	>>
//		bTrojan(IN)		>>
//		bWantDetect(IN)	>>
//	
void CDiscover::AddTrojanPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CPort object
	CPort *pPort = new CPort( lPortNumber, strProtocol, strPortName, bTrojan, bWantDetect );
	
	try {
		// Add new Port to Port Array
		m_paTrojanPorts.Add( pPort );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CNetwork Object delete it
		if ( pPort ) {
			delete pPort;
			pPort = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add want detect port for discovery
//	Parameter	: 
//		lPortNumber(IN)	>>
//		strProtocol(IN)	>>
//		strPortName(IN)	>>
//		bTrojan(IN)		>>
//		bWantDetect(IN)	>>
//	
void CDiscover::AddWantDetectPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CPort object
	CPort *pPort = new CPort( lPortNumber, strProtocol, strPortName, bTrojan, bWantDetect );
	
	try {
		// Add new Port to Port Array
		m_paWantDetectPorts.Add( pPort );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CNetwork Object delete it
		if ( pPort ) {
			delete pPort;
			pPort = NULL;
		}
		// Delete the exception object
		pErr->Delete( );   
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Explorer all host in network and find detail on it
//	
void CDiscover::Explorer()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	CWWaitTarget waitTarget;
	waitTarget.SetShowMessage( "Ping sweep and scan port..." );
	waitTarget.Show( );

	CNetviewApp *pApp = (CNetviewApp*)AfxGetApp( );
	pApp->SetWhileExplorer( TRUE );		// set frag while explorer
	 
	// ping sweep and scan port  
	this->PingSweep( );			// ping sweep
	//::AfxMessageBox( "PingSweep OK" ); 
	this->ScanPort( );			// scan port
	//::AfxMessageBox( "ScanPort OK" );
	this->SendArpLocal( );		// find mac address in local network
	//::AfxMessageBox( "SendArpLocal OK" );
	this->SetNetworkStatus( );	// set network status (CONNECT/DISCONNECT)
	//::AfxMessageBox( "SetNetworkStatus OK" );
	this->SetHostStatus( );		// set host status (Snmp, Trojan, Policy)
	//::AfxMessageBox( "SetHostStatus OK" );
	this->ScanNullSession( );	// scan null session
	//::AfxMessageBox( "ScanNullSession OK" );
	this->SetAgentFirstMRTG( );	// set MRTG for get traffic data
	//::AfxMessageBox( "SetAgentFirstMRTG OK" );
 
	pApp->SetWhileExplorer( FALSE );	// set frag while explorer
	
	waitTarget.Close( );

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CNetworkArray* CDiscover::GetNetworks()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_naNetworks;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Thread function for ping sweep for each network
//	
UINT ThreadPingSweepFunc( LPVOID pParam ) {
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CNetwork *pNetwork	= (CNetwork*)pParam;
	CString strCommand	= pNetwork->GetCommand( );
	CString *pResult	= pNetwork->GetResult( );

	// Create CRedirect Object to ping sweep
	CRedirect rdPingSweep( strCommand, pResult );
	rdPingSweep.Run( );
	return 0;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Thread function for scan port for each host
//	
UINT ThreadScanPortFunc( LPVOID pParam ) {
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CHost *pHost		= (CHost*)pParam;
	CString strCommand	= pHost->GetCommand( );
	CString *pResult	= pHost->GetResult( );

	if ( pHost->IsStatus( ) ) {
 		// Create CRedirect Object to scan port
		CRedirect rdScanPort( strCommand, pResult );
		rdScanPort.Run( );
	}
	return 0;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Thread function for send arp for each host
//
UINT ThreadArpFunc(LPVOID pParam) {
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CHost *pHost		= (CHost*)pParam;
	CString strCommand	= pHost->GetCommand( );
	CString *pResult	= pHost->GetResult( );

	// Open host only
	if ( pHost->IsStatus( ) ) {
		// Create CRedirect Object to send arp
		CRedirect rdScanPort( strCommand, pResult );
		rdScanPort.Run( );
	}
	return 0;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Thread function for scan null session for each host
//
UINT ThreadNullSessionFunc(LPVOID pParam) {
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CHost *pHost = (CHost*)pParam;
	
	// Open host only
	if ( pHost->IsStatus( ) ) {
		pHost->ConnectNullSession( );
	}
	return 0; 
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Ping sweep
//	
void CDiscover::PingSweep()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strCommand; 
	CString strResult;
	STVECTOR svHosts;
	CString strNetworkAddress;
	CString strNetmask;
	CString strIPAddress;	// Host IP Address
	int i, j, k;
	int iSize = m_naNetworks.GetSize( );
	int iHostPosition;		// Host Position in CHostArray
	int iSizeHost;
	CHostArray *pHosts;
	CHost *pHost;
	BOOL bFound;	
	CThreadArray m_taPingThreads;

	//---------------------------------------------------
	//  Ping sweep to find host up in network
	//---------------------------------------------------

	// Step 1 :: Create ping sweep command for each network
	for ( i=0; i<iSize; i++ ) {
		strNetworkAddress	= m_naNetworks[i]->GetNetworkAddress( );
		strNetmask			= m_naNetworks[i]->GetNetmask( );

		// create command
		//-------------------------------------------
		// Discovery Type :: "Local Network(This Network)" OR "Range Host"
		//-------------------------------------------
		if ( (m_iDiscoveryType==0) || (m_iDiscoveryType==1) ) {
			strCommand = ".\\Bin\\nmap\\nmap.exe -sP -n ";
			strCommand += strNetworkAddress;
			strCommand += "/";
			strCommand += strNetmask;
		}
		//-------------------------------------------
		// Discovery Type :: "Range Host"
		//-------------------------------------------
		else if ( m_iDiscoveryType == 2 ) {
			strCommand = ".\\Bin\\nmap\\nmap.exe -sP -n ";
			strCommand += m_naNetworks[i]->GetIPRange( );
		}
		
		// set command to network
		m_naNetworks[i]->SetCommand( strCommand );
	}

	// Step 2 :: Create thread ping sweep for each network
	for ( i=0; i<iSize; i++ ) {
		// Start the thread, passing a CNetwork pointer to the thread function
		CWinThread *pThread;
		pThread = AfxBeginThread( ThreadPingSweepFunc, (LPVOID)m_naNetworks[i] );

		// Add thread to array
		m_taPingThreads.Add( pThread );
	}

	// Step 3 :: Kill thread ping sweep for each network
	for ( i=0; i<iSize; i++ ) {
		CWinThread *pThread = NULL;
		pThread = m_taPingThreads.ElementAt( i );
		if ( pThread ) {
			// Get the handle for the thread
			HANDLE hThread = pThread->m_hThread;
			// Wait for the thread to die
			WaitForSingleObject(hThread, INFINITE);
		}
	}
	m_taPingThreads.RemoveAll( ); // clear array

	// Step 4 :: Get result and add host for each network
	for ( i=0; i<iSize; i++ ) {	
		CString *pResult = m_naNetworks[i]->GetResult( );
		svHosts = this->FindHostInNetwork( *m_naNetworks[i]->GetResult( ) );

		// Add new host
		for ( j=0; j<svHosts.size( ); j++ ) {
			iHostPosition = m_naNetworks[i]->FindHost( svHosts.at( j ) );
			// if not found ping result IP Address (svHosts.at( j )) 
			//  then it new host and add it in to array
			//  (m_naNetworks.Add( ))
			if ( iHostPosition == -1 ) {
				CString temp = svHosts.at( j );
				temp = temp;
				m_naNetworks[i]->AddHost( temp );
			}
		}

		// Update Open/Close for each host in network
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) { // For Each Host
			pHost = pHosts->ElementAt( j );
			strIPAddress = pHost->GetIP( );

			bFound = FALSE;
			for ( k=0; k<svHosts.size( ); k++ ) { // For Each svHost
				// if match in result set bFound TRUE
				if ( strIPAddress == svHosts.at( k ) ) {
					bFound = TRUE;
				}
			}

			// set status
			// if found ping result IP Address (svHosts.at( j ))
			//  and Host is down before this
			//  then set status it to Open(TRUE) by position
			if ( ( bFound == TRUE ) && ( !pHost->IsStatus( ) ) ) {
				pHost->SetStatus( TRUE );
			}
			// if not found ping result IP Address (svHosts.at( j )) 
			//  and Host is open before this
			//  then set status it to Close(FALSE) by position
			else if ( ( bFound == FALSE ) && ( pHost->IsStatus( ) ) ) { 
				pHost->SetStatus( FALSE );
			}
		}	
	}
	//---------------------------------------------------
	//  Ping sweep to find host up in network
	//---------------------------------------------------
	
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan Port
//	
void CDiscover::ScanPort()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	//---------------------------------------------------
	//	Scan TCP Port in host
	//---------------------------------------------------
	// Step 1 :: Create sacn TCP port command for each Host in each Network
	// Step 2 :: Create and Kill thread scan TCP port for each host in each network
	this->ScanPortTCP( );
	// Step 3 :: Get TCP result and check port for each host
	this->ScanPortTCPResult( );
	//---------------------------------------------------
	//	Scan TCP Port in host
	//---------------------------------------------------
	
	//---------------------------------------------------
	//	Scan UDP Port in host
	//---------------------------------------------------
	// Step 1 :: Create sacn UDP port command for each Host in each Network
	// Step 2 :: Create and Kill thread scan UDP port for each host in each network
	this->ScanPortUDP( );
	// Step 3 :: Get UDP result and check port for each host
	this->ScanPortUDPResult( );
	//---------------------------------------------------
	//	Scan TCP Port in host
	//---------------------------------------------------
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Agent IP in Network (m_naNetworks[iNetworkPosition])
//	Parameter	: 
//		iNetworkPosition(IN)	>>	Network position in array
//		strAgentIP(IN)			>>	Agent IP
//	
void CDiscover::AddAgentIP(int iNetworkPosition, CString strAgentIP)
{ 
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	if ( iNetworkPosition < m_naNetworks.GetSize( ) ) {
		m_naNetworks[iNetworkPosition]->AddAgentIP( strAgentIP );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Update scan port data from port table in database
//				  which update Trojan and WantDetect 's port 
//	
void CDiscover::UpdatePortData()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CDaoPortSet daoPortSet;	// port table object (DAO)
	CString strSQL;
	long	lPortNumber;
	CString	strProtocol;
	CString	strPortName;
	BOOL	bTrojan;
	BOOL	bWantDetect;

	//-------------------------------------------------
	// Update Trojan Port
	//-------------------------------------------------
	// create SQL Statement
	strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port WHERE Trojan=TRUE";
	
	// open database
	if ( daoPortSet.IsOpen( ) ) 
		daoPortSet.Close( );
	daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

	if ( !daoPortSet.IsEOF( ) ) {
		daoPortSet.MoveFirst( );
		while ( !daoPortSet.IsEOF( ) ) {
			lPortNumber	= daoPortSet.m_PortNumber;
			strProtocol	= daoPortSet.m_Protocol;
			strPortName	= daoPortSet.m_PortName;
			bTrojan		= daoPortSet.m_Trojan;
			bWantDetect	= daoPortSet.m_WantDetect;
			AddTrojanPort( lPortNumber,
						   strProtocol,
						   strPortName,
						   bTrojan,
						   bWantDetect );
		
			// Update Position
			daoPortSet.MoveNext( );
		}
	}
	daoPortSet.Close( );
	//-------------------------------------------------
	// Update Trojan Port
	//-------------------------------------------------
	
	//-------------------------------------------------
	// Update WantDetect Port
	//-------------------------------------------------
	// create SQL Statement
	strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port WHERE Trojan=FALSE AND WantDetect=TRUE";
	
	// open database
	if ( daoPortSet.IsOpen( ) ) 
		daoPortSet.Close( );
	daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

	if ( !daoPortSet.IsEOF( ) ) {
		daoPortSet.MoveFirst( );
		while ( !daoPortSet.IsEOF( ) ) {
			lPortNumber	= daoPortSet.m_PortNumber;
			strProtocol	= daoPortSet.m_Protocol;
			strPortName	= daoPortSet.m_PortName;
			bTrojan		= daoPortSet.m_Trojan;
			bWantDetect	= daoPortSet.m_WantDetect;
			AddWantDetectPort( lPortNumber,
						   strProtocol,
						   strPortName,
						   bTrojan,
						   bWantDetect );
		
			// Update Position
			daoPortSet.MoveNext( );
		}
	}
	daoPortSet.Close( );
	//-------------------------------------------------
	// Update WantDetect Port
	//-------------------------------------------------
	
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set network status for each network
//	
void CDiscover::SetNetworkStatus()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strCommand;		
	CString strResult;
	STVECTOR svHosts;
	BOOL bConnectInternet;
	int i;
	int iSizeNetwork = m_naNetworks.GetSize( );
	CNetwork *pNetwork;

	strCommand  = ".\\Bin\\nmap\\nmap.exe -sP -n ";
	strCommand += m_strInternet;
	
	// Create CRedirect Object to ping to internet
	CRedirect rdPing( strCommand, &strResult );
	rdPing.Run( );
	svHosts = FindHostInNetwork( strResult );
	if ( svHosts.size( )>0 ) {
		if ( svHosts.at( 0 ) == m_strInternet ) {
			bConnectInternet = TRUE;
		}
		else {
			bConnectInternet = FALSE;
		}
	}
	else {
		bConnectInternet = FALSE;
	}

	// if can connect internet from local
	if ( bConnectInternet ) {
		for ( i=0; i<iSizeNetwork; i++ ) {
			//-------------------------------
			// Find status
			//-------------------------------
			int j, iPosition;
			pNetwork = m_naNetworks.ElementAt( i );
			CStringArray *pAgentIPs = pNetwork->GetAgentIP( );
			int iSizeAgentIP = pAgentIPs->GetSize( );
			CHostArray *pHosts = pNetwork->GetHostArray( );
			CHost *pHost;
			CString strAgentIP;

			BOOL bRemoteConnect = FALSE;
			for ( j=0; j<iSizeAgentIP; j++ ) {
				strAgentIP = pAgentIPs->ElementAt( j );
				
				iPosition = pNetwork->FindHost( strAgentIP );
				// if found Agent open in network
				if ( iPosition != -1 ) {
					pHost = pHosts->ElementAt( iPosition );
					// if agent is up
					if ( pHost->IsStatus( ) ) {
						bRemoteConnect = TRUE;
						break;
					}
					// if agent is down
					else {
						bRemoteConnect = FALSE;
					}
				}
				// if not found Agent open in network
				else {
					bRemoteConnect = FALSE;
				}
			}

			// if can connect remote
			if ( bRemoteConnect ) {
				pNetwork->SetNetworkStatus( TRUE );
			}
			// if can not connect remote
			else {
				pNetwork->SetNetworkStatus( FALSE );
			}
			//-------------------------------
			// Find status
			//-------------------------------
		}
	}
	// if can not connect internet from local
	else {
		for ( i=0; i<iSizeNetwork; i++ ) {
			pNetwork = m_naNetworks.ElementAt( i );
			pNetwork->SetNetworkStatus( FALSE );
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Cut string to find TCP detail in host such as OS, port, 
//				  hostname (result from nmap -sS)
//	Parameter	:	data(OUT)	>>	struct keep host's detail
//					strTemp(IN)	>>	string TCP result from CRedirect (nmap -sS)
//
void CDiscover::FindDetailTCPInHost(scanport *data, CString strTemp)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	//char temp[1000];
	//for(int i=0;i<strTemp.GetLength();i++)
	//	temp[i] = strTemp.GetAt(i);
	//Init
	int starttx,stoptx,flag,last,chkpoint1,chkpoint2;
	flag = 0;
	//Check hostname and ip
	chkpoint1 = strTemp.Find("ports on",0);
	last = strTemp.Find("\n",chkpoint1);
	chkpoint2 = strTemp.Find(" (",chkpoint1);
	if((chkpoint2 > last)||(chkpoint2 < 0))
	{
		//get ip
		starttx = strTemp.Find("ports on",0);
		stoptx = strTemp.Find(":",starttx);
		data->ip = strTemp.Mid(starttx+9,(stoptx)-(starttx+9));
	}
	else
	{
		//get hostname
		starttx = strTemp.Find("ports on",0);
		stoptx = strTemp.Find(" (",starttx);
		data->hostname = strTemp.Mid(starttx+9,(stoptx)-(starttx+9));
		//get ip
		starttx = stoptx;
		stoptx = strTemp.Find(")",starttx);
		data->ip = strTemp.Mid(starttx+2,(stoptx)-(starttx+2));
	}
	//Check port
	last = strTemp.Find("\n",last+1);
	chkpoint1 = strTemp.Find("(The",stoptx);
	if((chkpoint1 < last)&&(chkpoint1 > 0))
	{
		//get port
		starttx = strTemp.Find("(The",stoptx);
		stoptx = strTemp.Find(" ports",starttx);
		data->port = strTemp.Mid(starttx+5,stoptx-(starttx+5));
		//Check service
		last = strTemp.Find("\n",stoptx);
		last = strTemp.Find("\n",last+3);
		chkpoint1 = strTemp.Find("SERVICE",stoptx);
		if((chkpoint1 < last)&&(chkpoint1 > 0))
		{
			starttx = strTemp.Find("\n",chkpoint1);
			chkpoint2 = strTemp.Find(" ",starttx);
			last = strTemp.Find("\n",starttx+1);
			stoptx = strTemp.Find("/",starttx);
			while((stoptx < chkpoint2)&&(stoptx > 0))
			{
				//get numport,protocol,state,service
				data->numport.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				stoptx = strTemp.Find(" ",starttx);
				data->protocol.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp.Find(" ",starttx+1);
				data->state.push_back(strTemp.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp.Find("\n",starttx+1);
				data->service.push_back(strTemp.Mid(starttx+1,(stoptx-1)-(starttx+1)));
				starttx = stoptx;
				chkpoint2 = strTemp.Find(" ",starttx);
				last = strTemp.Find("\n",starttx+1);
				stoptx = strTemp.Find("/",starttx);
			}
			starttx = strTemp.Find("Device",starttx);
			if((starttx < chkpoint2)&&(starttx > 0))
			{
				//get type
				stoptx = strTemp.Find("\n",starttx);
				if((starttx > 0)&&(stoptx >0))
				{
					data->type = strTemp.Mid(starttx+13,stoptx-(starttx+13));
					//get os
					starttx = strTemp.Find("OS details:",stoptx);
					stoptx = strTemp.Find("\n",starttx);
					if((starttx > 0)&&(stoptx > 0))
						data->os = strTemp.Mid(starttx+12,stoptx-(starttx+12));
				}
			}
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Cut string to find UDP detail in host such as OS, port, 
//				  hostname (result from nmap -sU)
//	Parameter	:	data(OUT)	>>	struct keep host's detail
//					strTemp(IN)	>>	string UDP result from CRedirect (nmap -sU)
//
void CDiscover::FindDetailUDPInHost(scanport *data, CString strTemp1)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int starttx,stoptx,flag,last;
	flag = 0;
	starttx = strTemp1.Find("ports on",0);
	starttx = strTemp1.Find(")",starttx);
	starttx = strTemp1.Find("SERVICE",starttx);
	if(starttx > 0)
	{
		stoptx = strTemp1.Find("/",starttx);
		last =strTemp1.Find("\r\n\r\n",stoptx);
		data->numport.push_back(strTemp1.Mid(starttx+9,(stoptx)-(starttx+9)));
		starttx = stoptx;
		stoptx = strTemp1.Find(" ",starttx);
		data->protocol.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
		starttx = stoptx;
		while(strTemp1.Find(" ",starttx+1) == starttx+1)
			starttx++;
		stoptx = strTemp1.Find(" ",starttx+1);
		data->state.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
		starttx = stoptx;
		while(strTemp1.Find(" ",starttx+1) == starttx+1)
			starttx++;
		stoptx = strTemp1.Find("\n",starttx+1);
		data->service.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
		while((stoptx > 0)&&(stoptx < last))
		{	
			starttx = stoptx;
			stoptx = strTemp1.Find("/",starttx);
			if((stoptx > 0)&&(stoptx < last))
			{
				data->numport.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				stoptx = strTemp1.Find(" ",starttx);
				data->protocol.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp1.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp1.Find(" ",starttx+1);
				data->state.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));
				starttx = stoptx;
				while(strTemp1.Find(" ",starttx+1) == starttx+1)
					starttx++;
				stoptx = strTemp1.Find("\n",starttx+1);
				data->service.push_back(strTemp1.Mid(starttx+1,(stoptx)-(starttx+1)));	
			}
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Trojan Port in Discover by port number and protocol
//	Parameter	: lPortNumber(IN)	>>	Port number
//				  strProtocol(IN)	>>	Protocol
//	Return		: int		>>	-1=Not Found, 0...n=Found and return position
//
int CDiscover::FindTrojanPort(long lPortNumber, CString strProtocol)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	long lPortNumberCheck;
	CString strProtocolCheck;
	int i, iSize;
	int iFound = -1;

	iSize = m_paTrojanPorts.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		lPortNumberCheck = m_paTrojanPorts[i]->GetPortNumber( );
		strProtocolCheck = m_paTrojanPorts[i]->GetProtocol( );
		// Match Port
		if ( (lPortNumber==lPortNumberCheck) && (strProtocol==strProtocolCheck) ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Want Detect Port in Discover by port number and protocol
//	Parameter	: lPortNumber(IN)	>>	Port number
//				  strProtocol(IN)	>>	Protocol
//	Return		: int		>>	-1=Not Found, 0...n=Found and return position
//
int CDiscover::FindWantDetectPort(long lPortNumber, CString strProtocol)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	long lPortNumberCheck;
	CString strProtocolCheck;
	int i, iSize;
	int iFound = -1;

	iSize = m_paWantDetectPorts.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		lPortNumberCheck = m_paWantDetectPorts[i]->GetPortNumber( );
		strProtocolCheck = m_paWantDetectPorts[i]->GetProtocol( );
		// Match Port
		if ( (lPortNumber==lPortNumberCheck) && (strProtocol==strProtocolCheck) ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Send arp request to find MAC Address in host 
//				  which stand in local network only
//	
void CDiscover::SendArpLocal()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, j;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost;
	int iPosition;
	CString strCommand, strResult;
	CNetwork *pLocalNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CThreadArray m_taArpThreads;
	
	for ( i=0; i<iSizeNetwork; i++ ) {
		pLocalNetwork = m_naNetworks.ElementAt( i );
		if ( pLocalNetwork->IsLocalNetwork( ) ) {
			pHosts = pLocalNetwork->GetHostArray( );
			iSizeHost = pHosts->GetSize( );

			// Create thread for each host
			for ( j=0; j<iSizeHost; j++ ) {
				pHost = pHosts->ElementAt( j );

				// create command
				strCommand = ".\\Bin\\arp\\arp.exe ";
				strCommand += pHost->GetIP( );
				pHost->SetCommand( strCommand );
				
				// Start the thread, passing a CHost pointer to the thread function
				CWinThread *pThread;
				pThread = AfxBeginThread( ThreadArpFunc, (LPVOID)pHost );
				// Add thread to array
				m_taArpThreads.Add( pThread );
			}

			// Kill thread for each host
			for ( j=0; j<iSizeHost; j++ ) {
				pHost = pHosts->ElementAt( j );

				CWinThread *pThread = NULL;
				pThread = m_taArpThreads.ElementAt( j );
				if ( pThread ) {
					// Get the handle for the thread
					HANDLE hThread = pThread->m_hThread;
					// Wait for the thread to die
					WaitForSingleObject(hThread, INFINITE);
				}
			}
			m_taArpThreads.RemoveAll( );

			// Get result
			for ( j=0; j<iSizeHost; j++ ) {
				pHost = pHosts->ElementAt( j );

				// if host not open then "skip"
				if ( !pHost->IsStatus( ) ) continue;

				strResult = *(pHost->GetResult( ));
				strResult.TrimLeft( );
				strResult.TrimRight( );
				if ( strResult != "00-00-00-00-00-00" ) {
					// if not found (result is new) then add new Mac Address
					iPosition = pHost->FindMacAddress( strResult );
					if ( iPosition == -1 )
						pHost->AddMacAddress( strResult );
				}
			}

			break;
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : scan TCP port
//	
void CDiscover::ScanPortTCP()
{
	//////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////
	int i, j, k, iCount;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost, iSizePort;
	CHostArray *pHosts;
	CHost *pHost;
	CString strCommand;
	CString strTempPort;
	CThreadArray m_taTcpThreads;

	//---------------------------------------------------
	//	Scan TCP Port in host
	//---------------------------------------------------

	// Step 1 :: Create sacn TCP port command for each Host in each Network
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		// create command for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );

			// create command
			strCommand = ".\\Bin\\nmap\\nmap.exe -T5 -P0 -sS -O -p ";
			strCommand += "21,22,23,25,79,80,110,111,135,139,443,445,515,1024";
			// add trojan port to scan command
			iSizePort = m_paTrojanPorts.GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				if ( m_paTrojanPorts[k]->GetProtocol( ) == "TCP" ) {
					strCommand += ",";
					strTempPort.Format( "%ld", m_paTrojanPorts[k]->GetPortNumber( ) ); 
					strCommand += strTempPort;
				}
			}
			// add want detect port to scan command
			iSizePort = m_paWantDetectPorts.GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				if ( m_paWantDetectPorts[k]->GetProtocol( ) == "TCP" ) {
					strCommand += ",";
					strTempPort.Format( "%ld", m_paWantDetectPorts[k]->GetPortNumber( ) ); 
					strCommand += strTempPort;
				}
			}
			strCommand += " ";
			strCommand += pHost->GetIP( );

			// set command to host
			pHost->SetCommand( strCommand );
		}
	}

	// Step 2 :: Create and Kill thread scan TCP port for each host in each network
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		j = 0;
		iCount = 0;
		int iLimit = 10; // host limit
		while ( j<iSizeHost ) {
			// Create thread for each host
			for ( iCount=j; (iCount<(j+iLimit))&&(iCount<iSizeHost); iCount++ ) {
				pHost = pHosts->ElementAt( iCount );
	
				// Start the thread, passing a CHost pointer to the thread function
				CWinThread *pThread;
				pThread = AfxBeginThread( ThreadScanPortFunc, (LPVOID)pHost );

				// Add thread to array
				m_taTcpThreads.Add( pThread );
			}

			// Kill thread for each host
			for ( iCount=j; (iCount<(j+iLimit))&&(iCount<iSizeHost); iCount++ ) {
				CWinThread *pThread = NULL;
				pThread = m_taTcpThreads.ElementAt( iCount );
				if ( pThread ) {
					// Get the handle for the thread
					HANDLE hThread = pThread->m_hThread;
					// Wait for the thread to die
					WaitForSingleObject(hThread, INFINITE);
				}
			}
			j = j+iLimit;
		}
		m_taTcpThreads.RemoveAll( );
	}

	//---------------------------------------------------
	//	Scan TCP Port in host
	//---------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Check and cut result TCP scan
//	
void CDiscover::ScanPortTCPResult()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, j, k;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost;
	CHostArray *pHosts;
	CHost *pHost;

	// Port data
	scanport spResult;
	CDaoPortSet *pDaoPortSet;	// port table object (DAO)
	CString strSQL;
	long	lPortNumber;
	CString strTempPortNumber;
	char	*cTempPortNumber;
	CString	strProtocol;
	CString	strPortName;
	BOOL	bTrojan;
	BOOL	bWantDetect;
	CString strStatus;
	int		iSizePort;
	int		iTrojanPortPosition, iWantDetectPortPosition, iPortPosition;
	
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		// find result for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );

			// if host not open then "skip"
			if ( !pHost->IsStatus( ) ) continue;

			CString *pResult = pHost->GetResult( );

			// clear last result scanport
			spResult.ip			= "";
			spResult.hostname	= "";
			spResult.os			= "";
			spResult.type		= "";
			spResult.port		= "";
			spResult.numport.clear( );
			spResult.protocol.clear( );
			spResult.state.clear( );
			spResult.service.clear( );

			// cut string result to struct
			FindDetailTCPInHost( &spResult, *pResult );

			// Set data
			pHost->SetHostData( spResult.hostname, spResult.os, spResult.type );
			
			//-------------------
			// Set Port data
			//-------------------
			iSizePort = spResult.numport.size( );
			for ( k=0; k<iSizePort; k++ ) {
				strTempPortNumber	= spResult.numport.at( k );
				strProtocol			= spResult.protocol.at( k );
				strProtocol.MakeUpper( );
				strStatus			= spResult.state.at( k );

				cTempPortNumber		= strTempPortNumber.GetBuffer( 5 );
				lPortNumber			= atol( cTempPortNumber );
				iPortPosition		= pHost->FindPort( lPortNumber, strProtocol ); 

				// if not found scan TCP result Port (spPorts.at( j )) 
				//  then it new port it in to array
				//  (m_paPorts.Add( ))
				if ( iPortPosition == -1 ) {
					// Get [PortName] from database
					strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect ";
					strSQL += "FROM Port ";
					strSQL += "WHERE PortNumber=";
					strSQL += strTempPortNumber;
					strSQL += " AND Protocol='";
					strSQL += strProtocol;
					strSQL += "'";
					
					// open database and get port name
					pDaoPortSet = new CDaoPortSet( ); 
					if ( pDaoPortSet->IsOpen( ) ) 
						pDaoPortSet->Close( );
					pDaoPortSet->Open( dbOpenDynaset, _T( strSQL ) );
					if ( !pDaoPortSet->IsEOF( ) ) {
						pDaoPortSet->MoveFirst( );
						strPortName = pDaoPortSet->m_PortName;
					}
					pDaoPortSet->Close( );
					delete pDaoPortSet;
					
					// get trojan port
					iTrojanPortPosition = FindTrojanPort( lPortNumber, strProtocol );
					if ( iTrojanPortPosition == -1 ) 
						bTrojan = FALSE;
					else 
						bTrojan = TRUE;

					// get want detect port
					iWantDetectPortPosition = FindWantDetectPort( lPortNumber, strProtocol );
					if ( iWantDetectPortPosition == -1 ) 
						bWantDetect = FALSE;
					else 
						bWantDetect = TRUE;

					// Add new port
					pHost->AddPort( lPortNumber, 
									strProtocol, 
									strPortName, 
									bTrojan, 
									bWantDetect, 
									strStatus );
				}
				// if already TCP Port in host then update it's status
				else {
					pHost->SetPortStatus( iPortPosition, strStatus );
				}
			}
			//-------------------
			// Set Port data
			//-------------------
		}
	}

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : scan UDP port
//	
void CDiscover::ScanPortUDP()
{
	//////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////
	int i, j, k, iCount;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost, iSizePort;
	CHostArray *pHosts;
	CHost *pHost;
	CString strCommand;
	CString strTempPort;
	CThreadArray m_taUdpThreads;

	//---------------------------------------------------
	//	Scan UDP Port in host
	//---------------------------------------------------

	// Step 1 :: Create sacn UDP port command for each Host in each Network
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		// create command for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );

			// create command
			strCommand = ".\\Bin\\nmap\\nmap.exe -T5 -P0 -sU -p ";
			strCommand += "21,22,23,25,79,80,110,111,135,139,161,162,443,445,515,1024";
			// add trojan port to scan command
			iSizePort = m_paTrojanPorts.GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				if ( m_paTrojanPorts[k]->GetProtocol( ) == "UDP" ) {
					strCommand += ",";
					strTempPort.Format( "%ld", m_paTrojanPorts[k]->GetPortNumber( ) ); 
					strCommand += strTempPort;
				}
			}
			// add want detect port to scan command
			iSizePort = m_paWantDetectPorts.GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				if ( m_paWantDetectPorts[k]->GetProtocol( ) == "UDP" ) {
					strCommand += ",";
					strTempPort.Format( "%ld", m_paWantDetectPorts[k]->GetPortNumber( ) ); 
					strCommand += strTempPort;
				}
			}
			strCommand += " ";
			strCommand += pHost->GetIP( );

			// set command to host
			pHost->SetCommand( strCommand );
		}
	}

	// Step 2 :: Create and Kill thread scan UDP port for each host in each network
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		j = 0;
		iCount = 0;
		int iLimit = 10; // host limit
		while ( j<iSizeHost ) {
			// Create thread for each host
			for ( iCount=j; (iCount<(j+iLimit))&&(iCount<iSizeHost); iCount++ ) {
				pHost = pHosts->ElementAt( iCount );
	
				// Start the thread, passing a CHost pointer to the thread function
				CWinThread *pThread;
				pThread = AfxBeginThread( ThreadScanPortFunc, (LPVOID)pHost );

				// Add thread to array
				m_taUdpThreads.Add( pThread );
			}

			// Kill thread for each host
			for ( iCount=j; (iCount<(j+iLimit))&&(iCount<iSizeHost); iCount++ ) {
				CWinThread *pThread = NULL;
				pThread = m_taUdpThreads.ElementAt( iCount );
				if ( pThread ) {
					// Get the handle for the thread
					HANDLE hThread = pThread->m_hThread;
					// Wait for the thread to die
					WaitForSingleObject(hThread, INFINITE);
				}
			}
			j = j+iLimit;
		}
		m_taUdpThreads.RemoveAll( );
	}

	//---------------------------------------------------
	//	Scan UDP Port in host
	//---------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Check and cut result UDP scan
//	
void CDiscover::ScanPortUDPResult()
{
	//////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////
	int i, j, k;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost;
	CHostArray *pHosts;
	CHost *pHost;

	// Port data
	scanport spResult;
	CDaoPortSet *pDaoPortSet;	// port table object (DAO)
	CString strSQL;
	long	lPortNumber;
	CString strTempPortNumber;
	char	*cTempPortNumber;
	CString	strProtocol;
	CString	strPortName;
	BOOL	bTrojan;
	BOOL	bWantDetect;
	CString strStatus;
	int		iSizePort;
	int		iTrojanPortPosition, iWantDetectPortPosition, iPortPosition;
	
	for ( i=0; i<iSizeNetwork; i++ ) {
		pHosts = m_naNetworks[i]->GetHostArray( );
		iSizeHost = pHosts->GetSize( ); 

		// find result for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );

			// if host not open then "skip"
			if ( !pHost->IsStatus( ) ) continue;

			CString *pResult = pHost->GetResult( );

			// clear last result scanport
			spResult.ip			= "";
			spResult.hostname	= "";
			spResult.os			= "";
			spResult.type		= "";
			spResult.port		= "";
			spResult.numport.clear( );
			spResult.protocol.clear( );
			spResult.state.clear( );
			spResult.service.clear( );

			// cut string result to struct
			FindDetailUDPInHost( &spResult, *pResult );

			//-------------------
			// Set Port data
			//-------------------
			iSizePort = spResult.numport.size( );
			for ( k=0; k<iSizePort; k++ ) {
				strTempPortNumber	= spResult.numport.at( k );
				strProtocol			= spResult.protocol.at( k );
				strProtocol.MakeUpper( );
				strStatus			= spResult.state.at( k );

				cTempPortNumber		= strTempPortNumber.GetBuffer( 5 );
				lPortNumber			= atol( cTempPortNumber );
				iPortPosition		= pHost->FindPort( lPortNumber, strProtocol ); 

				// if not found scan UDP result Port (spPorts.at( j )) 
				//  then it new port it in to array
				//  (m_paPorts.Add( ))
				if ( iPortPosition == -1 ) {
					// Get [PortName] from database
					strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect ";
					strSQL += "FROM Port ";
					strSQL += "WHERE PortNumber=";
					strSQL += strTempPortNumber;
					strSQL += " AND Protocol='";
					strSQL += strProtocol;
					strSQL += "'";
					
					// open database and get port name
					pDaoPortSet = new CDaoPortSet( ); 
					if ( pDaoPortSet->IsOpen( ) ) 
						pDaoPortSet->Close( );
					pDaoPortSet->Open( dbOpenDynaset, _T( strSQL ) );
					if ( !pDaoPortSet->IsEOF( ) ) {
						pDaoPortSet->MoveFirst( );
						strPortName = pDaoPortSet->m_PortName;
					}
					pDaoPortSet->Close( );
					delete pDaoPortSet;
					
					// get trojan port
					iTrojanPortPosition = FindTrojanPort( lPortNumber, strProtocol );
					if ( iTrojanPortPosition == -1 ) 
						bTrojan = FALSE;
					else 
						bTrojan = TRUE;

					// get want detect port
					iWantDetectPortPosition = FindWantDetectPort( lPortNumber, strProtocol );
					if ( iWantDetectPortPosition == -1 ) 
						bWantDetect = FALSE;
					else 
						bWantDetect = TRUE;

					// Add new port
					pHost->AddPort( lPortNumber, 
									strProtocol, 
									strPortName, 
									bTrojan, 
									bWantDetect, 
									strStatus );
				}
				// if already TCP Port in host then update it's status
				else {
					pHost->SetPortStatus( iPortPosition, strStatus );
				}
			}
			//-------------------
			// Set Port data
			//-------------------
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set host status for each network
//                status is Snmp, Trojan, Policy
//	
void CDiscover::SetHostStatus()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, j, k;
	int iSizeNetwork, iSizeHost;
	int iSizeTrojanPorts, iSizeWantDetectPorts;
	CNetwork *pNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CPort *pTrojanPort, *pWantDetectPort;
	BOOL bSnmp, bTrojan, bPolicy;

	iSizeNetwork = m_naNetworks.GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = m_naNetworks.ElementAt( i );
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );

		// for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );

			//------------------------------
			//  Check snmp
			//------------------------------
			if ( pHost->FindPort( 161, "UDP" ) != -1 )	// found snmp port
				bSnmp = TRUE;
			else 
				bSnmp = FALSE;
			pHost->SetSnmp( bSnmp );
			//------------------------------
			//  Check snmp
			//------------------------------

			//------------------------------
			//  Check trojan
			//------------------------------
			bTrojan = FALSE;
			iSizeTrojanPorts = m_paTrojanPorts.GetSize( );
			for ( k=0; k<iSizeTrojanPorts; k++ ) {
				pTrojanPort = m_paTrojanPorts.ElementAt( k );
				// found trojan port in this host
				if ( pHost->FindPort( 
						pTrojanPort->GetPortNumber( ), 
						pTrojanPort->GetProtocol( )    ) != -1 ) {
					bTrojan = TRUE;
					break;
				}
			}
			pHost->SetTrojan( bTrojan );
			//------------------------------
			//  Check trojan
			//------------------------------

			//------------------------------
			//  Check policy
			//------------------------------
			bPolicy = TRUE;
			iSizeWantDetectPorts = m_paWantDetectPorts.GetSize( );
			for ( k=0; k<iSizeWantDetectPorts; k++ ) {
				pWantDetectPort = m_paWantDetectPorts.ElementAt( k );
				// found want detect port in this host
				if ( pHost->FindPort( 
						pWantDetectPort->GetPortNumber( ), 
						pWantDetectPort->GetProtocol( ) ) != -1 ) {
					bPolicy = FALSE;
					break;
				}
			}
			pHost->SetPolicy( bPolicy );
			//------------------------------
			//  Check policy
			//------------------------------
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan null session in all host in all network
//
void CDiscover::ScanNullSession()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, j;
	int iSizeNetwork = m_naNetworks.GetSize( );
	int iSizeHost;
	CNetwork *pNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CThreadArray m_taNullSessionThreads;
	
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = m_naNetworks.ElementAt( i );
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );

		// Create thread for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			
			// Start the thread, passing a CHost pointer to the thread function
			CWinThread *pThread;
			pThread = AfxBeginThread( ThreadNullSessionFunc, (LPVOID)pHost );
			// Add thread to array
			m_taNullSessionThreads.Add( pThread );
		}

		// Kill thread for each host
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
	
			CWinThread *pThread = NULL;
			pThread = m_taNullSessionThreads.ElementAt( j );
			if ( pThread ) {
				// Get the handle for the thread
				HANDLE hThread = pThread->m_hThread;
				// Wait for the thread to die
				WaitForSingleObject(hThread, INFINITE);
			}
		}
		m_taNullSessionThreads.RemoveAll( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Test open and test snmp for each agent and then 
//				  it pass set first MRTG to it.
//
void CDiscover::SetAgentFirstMRTG()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CNetwork *pNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CStringArray *pAgentIPs;
	CString strAgentIP;
	int i, j, iNetworkSize, iAgentIPSize;
	int iHostPosition;
	CString strCommand;
	CString strResult;

	// each network
	iNetworkSize = m_naNetworks.GetSize( );
	for ( i=0; i<iNetworkSize; i++ ) {
		pNetwork = m_naNetworks.ElementAt( i );
		pHosts = pNetwork->GetHostArray( );

		// each agent ip
		pAgentIPs = pNetwork->GetAgentIP( );
		iAgentIPSize = pAgentIPs->GetSize( ); 
		for ( j=0; j<iAgentIPSize; j++ ) {
			// get agent ip and use it to get it's host object 
			strAgentIP = pAgentIPs->ElementAt( j );
			iHostPosition = pNetwork->FindHost( strAgentIP );
			if ( iHostPosition != -1 ) {
				pHost = pHosts->ElementAt( iHostPosition );
				// if agent open
				if ( pHost->IsStatus( ) ) {
					// Test snmp is open or not
					// create command for test snmp
					strCommand = ".\\Bin\\snmputil\\checksnmp.exe get ";
					strCommand += strAgentIP;
					strCommand += " public system.sysDescr.0";					
					CRedirect rdCheckSnmp( strCommand, &strResult );
					rdCheckSnmp.Run( );
					// if result not found "error" from result then it support snmp
					if ( strResult.Find( "error" ) == -1 ) {
						pHost->SetSnmp( TRUE ); // set support snmp

						// OK (Open, Support SNMP) then set MRTG
						SetEachAgentFirstMRTG( strAgentIP );
						SetEachAgentTransactionMRTG( strAgentIP );

					}
					else {
						pHost->SetSnmp( FALSE ); // set not support snmp
					}
					
				}
			}
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set MRTG for each host using this method when
//				  first time start program
//
void CDiscover::SetEachAgentFirstMRTG(CString AgentIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	FILE *stream,*streamt;
	int i;
	char Temp[1000];
	CString filename1;
	HBITMAP hBitmap1;
	CString Script;
	//mkdir and copy mrtg program for agent
	CFileManip::MkDir("c:\\MRTG\\"+AgentIP);
	CFileManip::MkDir("c:\\MRTG\\"+AgentIP+"\\mrtg");
	CFileManip::MkDir("c:\\MRTG\\"+AgentIP+"\\picture");
	Script = "xcopy /S /Y c:\\MRTG\\mrtg c:\\MRTG\\"+AgentIP+"\\mrtg\\\n"; // /K /C /R
	Script += "exit\n";
	stream = fopen("c:\\MRTG\\copy.bat","w");
	for(i=0;i<Script.GetLength();i++)
		Temp[i] = Script.GetAt(i);
	fwrite(Temp,sizeof(char),Script.GetLength(),stream);
	fclose(stream);
	WinExec("c:\\MRTG\\copy.bat",SW_HIDE);
	//system( "c:\\MRTG\\copy.bat" );
	filename1 = "c:\\MRTG\\"+AgentIP+"\\mrtg\\z\\z.bmp";
	hBitmap1 = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),filename1,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	while ( !hBitmap1 ) 
	{
		Sleep(1000);
		hBitmap1 = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),filename1,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	}
	for(i=0;i<1000;i++)
		Temp[i] = NULL;
	//Create file mrtg1 which startup mrtg
	Script = "cd c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\\n";
	Script += "c:\n";
	Script += "perl cfgmaker public@"+AgentIP+" -global \"WorkDir: c:\\MRTG\\"+AgentIP+"\\picture\""+" -output mrtg.cfg\n";
	Script += "perl mrtg mrtg.cfg\n";
	Script += "exit\n";
	stream = fopen("c:\\MRTG\\mrtg1.bat","w");
	for(i=0;i<Script.GetLength();i++)
	{
		Temp[i] = Script.GetAt(i);
	}
	fwrite(Temp,sizeof(char),Script.GetLength(),stream);
	fclose(stream);
	WinExec("c:\\MRTG\\mrtg1.bat",SW_HIDE);
	Sleep(5000);
	//Create file mrtg2 which auto startup mrtg
	Script = "cd c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\\n";
	Script += "c:\n";
	Script += "wperl mrtg --logging=eventlog mrtg.cfg\n";
	Script += "exit\n";
	stream = fopen("c:\\MRTG\\"+AgentIP+"\\mrtg2.bat","w");
	for(i=0;i<Script.GetLength();i++)
	{
		Temp[i] = Script.GetAt(i);
	}
	fwrite(Temp,sizeof(char),Script.GetLength(),stream);
	fclose(stream);
	//config mrtg.cfg file
	Script = "RunAsDaemon: yes\n";
	stream = fopen("c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\mrtg.cfg","r");
	streamt = fopen("c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\mrtg1.cfg","w");
	for(i=0;i<Script.GetLength();i++)
		Temp[i] = Script.GetAt(i);
	fwrite(Temp,sizeof(char),Script.GetLength(),streamt);
	while(fgets(Temp,1000,stream) != NULL)
	{
		Script = Temp;
		fwrite(Temp,sizeof(char),Script.GetLength(),streamt);
	}
	fclose(stream);
	fclose(streamt);
	CFileManip::Del("c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\mrtg.cfg",TRUE);
	CFileManip::Ren("c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\mrtg1.cfg","c:\\MRTG\\"+AgentIP+"\\mrtg\\bin\\mrtg.cfg",TRUE);
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set MRTG for each host using this method when
//				  first time start program and when all time to
//				  import discovery file
//
void CDiscover::SetEachAgentTransactionMRTG(CString AgentIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString filename;
	HBITMAP hBitmap;
	filename = "c:\\MRTG\\"+AgentIP+"\\picture\\"+AgentIP+"_1-day.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),filename,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	while ( !hBitmap ) 
	{
		WinExec(".\\Bin\\png2bmp\\png2bmp c:\\MRTG\\"+AgentIP+"\\picture\\"+AgentIP+"_1-day.png",SW_HIDE);
		WinExec(".\\Bin\\png2bmp\\png2bmp c:\\MRTG\\"+AgentIP+"\\picture\\"+AgentIP+"_1-week.png",SW_HIDE);
		WinExec(".\\Bin\\png2bmp\\png2bmp c:\\MRTG\\"+AgentIP+"\\picture\\"+AgentIP+"_1-month.png",SW_HIDE);
		WinExec(".\\Bin\\png2bmp\\png2bmp c:\\MRTG\\"+AgentIP+"\\picture\\"+AgentIP+"_1-year.png",SW_HIDE);
		Sleep(1000);
		hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),filename,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	}
	WinExec("c:\\MRTG\\"+AgentIP+"\\mrtg2.bat",SW_HIDE);
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Clear traffic image when close document or 
//                close dialog
//
void CDiscover::ClearAgentBmp()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CNetwork *pNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CStringArray *pAgentIPs;
	CString strAgentIP;
	int i, j, iNetworkSize, iAgentIPSize;
	int iHostPosition;

	// for each network
	iNetworkSize = m_naNetworks.GetSize( );
	for ( i=0; i<iNetworkSize; i++ ) {
		pNetwork = m_naNetworks.ElementAt( i );
		pHosts = pNetwork->GetHostArray( );

		// for each agent ip
		pAgentIPs = pNetwork->GetAgentIP( );
		iAgentIPSize = pAgentIPs->GetSize( ); 
		for ( j=0; j<iAgentIPSize; j++ ) {
			// get agent ip and use it to get it's host object 
			strAgentIP = pAgentIPs->ElementAt( j );
			iHostPosition = pNetwork->FindHost( strAgentIP );
			if ( iHostPosition != -1 ) {
				pHost = pHosts->ElementAt( iHostPosition );
				// if agent open and support snmp
				if ( pHost->IsStatus( ) && pHost->IsSnmp( ) ) {
					ClearEachAgentBmp( strAgentIP );
				}
			}
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Clear traffic image for each host when close 
//                document or close dialog
//
void CDiscover::ClearEachAgentBmp(CString AgentIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CFileManip::Del("c:\\MRTG\\"+AgentIP+"\\picture\\*.bmp",TRUE);
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Tool for discovery
//	Parameter	: 
//		strToolName(IN)	>>	
//		strToolPath(IN)	>>	
//	
void CDiscover::AddTool(CString strToolName, CString strToolPath, CString strParameter )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CTool Object
	CTool *pTool = new CTool( strToolName, strToolPath, strParameter );
	
	try {
		// Add new Tool to Tool Array
		m_taTools.Add( pTool );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CTool Object delete it
		if ( pTool ) {
			delete pTool;
			pTool = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Tool in Discover by tool name
//	Parameter	: strToolName(IN)	>>	
//	Return		: int				>>	-1=Not Found, 0...n=Found and return position
//
int CDiscover::FindTool(CString strToolName)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strToolNameCheck;

	int i, iSize;
	int iFound = -1;

	iSize = m_taTools.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		strToolNameCheck = m_taTools[i]->GetToolName( );

		// Match Tool Name
		if ( strToolName == strToolNameCheck ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CToolArray* CDiscover::GetTools()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_taTools;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//	
void CDiscover::StoreDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, iSizeNetwork;
	CNetwork *pNetwork;

	// store for each network
	iSizeNetwork = m_naNetworks.GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = m_naNetworks.ElementAt( i );
		pNetwork->StoreDB( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

COleDateTime CDiscover::GetStartTime()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_timeStart;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
