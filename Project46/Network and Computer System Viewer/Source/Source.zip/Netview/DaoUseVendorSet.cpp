// DaoUseVendorSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoUseVendorSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoUseVendorSet

IMPLEMENT_DYNAMIC(CDaoUseVendorSet, CDaoRecordset)

CDaoUseVendorSet::CDaoUseVendorSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoUseVendorSet)
	m_IP = _T("");
	m_VendorMAC = _T("");
	m_VendorName = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoUseVendorSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoUseVendorSet::GetDefaultSQL()
{
	return _T("[UseVendor]");
}

void CDaoUseVendorSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoUseVendorSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[VendorMAC]"), m_VendorMAC);
	DFX_Text(pFX, _T("[VendorName]"), m_VendorName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoUseVendorSet diagnostics

#ifdef _DEBUG
void CDaoUseVendorSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoUseVendorSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
