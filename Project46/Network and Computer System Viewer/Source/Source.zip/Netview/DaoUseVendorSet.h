#if !defined(AFX_DAOUSEVENDORSET_H__257B80B5_9FAF_49F7_925A_76182927425E__INCLUDED_)
#define AFX_DAOUSEVENDORSET_H__257B80B5_9FAF_49F7_925A_76182927425E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoUseVendorSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoUseVendorSet DAO recordset

class CDaoUseVendorSet : public CDaoRecordset
{
public:
	CDaoUseVendorSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoUseVendorSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoUseVendorSet, CDaoRecordset)
	CString	m_IP;
	CString	m_VendorMAC;
	CString	m_VendorName;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoUseVendorSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOUSEVENDORSET_H__257B80B5_9FAF_49F7_925A_76182927425E__INCLUDED_)
