// DaoHostSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoHostSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoHostSet

IMPLEMENT_DYNAMIC(CDaoHostSet, CDaoRecordset)

CDaoHostSet::CDaoHostSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoHostSet)
	m_IP = _T("");
	m_HostName = _T("");
	m_OS = _T("");
	m_Type = _T("");
	m_SNMP = FALSE;
	m_OpenTime = (DATE)0;
	m_OpenDate = (DATE)0;
	m_CloseTime = (DATE)0;
	m_CloseDate = (DATE)0;
	m_MinLength = _T("");
	m_MinAge = _T("");
	m_MaxAge = _T("");
	m_LockoutDuration = _T("");
	m_LockoutReset = _T("");
	m_LockoutThreshold = _T("");
	m_nFields = 15;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoHostSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoHostSet::GetDefaultSQL()
{
	return _T("[Host]");
}

void CDaoHostSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoHostSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[HostName]"), m_HostName);
	DFX_Text(pFX, _T("[OS]"), m_OS);
	DFX_Text(pFX, _T("[Type]"), m_Type);
	DFX_Bool(pFX, _T("[SNMP]"), m_SNMP);
	DFX_DateTime(pFX, _T("[OpenTime]"), m_OpenTime);
	DFX_DateTime(pFX, _T("[OpenDate]"), m_OpenDate);
	DFX_DateTime(pFX, _T("[CloseTime]"), m_CloseTime);
	DFX_DateTime(pFX, _T("[CloseDate]"), m_CloseDate);
	DFX_Text(pFX, _T("[MinLength]"), m_MinLength);
	DFX_Text(pFX, _T("[MinAge]"), m_MinAge);
	DFX_Text(pFX, _T("[MaxAge]"), m_MaxAge);
	DFX_Text(pFX, _T("[LockoutDuration]"), m_LockoutDuration);
	DFX_Text(pFX, _T("[LockoutReset]"), m_LockoutReset);
	DFX_Text(pFX, _T("[LockoutThreshold]"), m_LockoutThreshold);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoHostSet diagnostics

#ifdef _DEBUG
void CDaoHostSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoHostSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
