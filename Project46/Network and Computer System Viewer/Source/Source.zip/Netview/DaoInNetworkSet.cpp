// DaoInNetworkSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoInNetworkSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoInNetworkSet

IMPLEMENT_DYNAMIC(CDaoInNetworkSet, CDaoRecordset)

CDaoInNetworkSet::CDaoInNetworkSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoInNetworkSet)
	m_IP = _T("");
	m_NetworkAddress = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoInNetworkSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoInNetworkSet::GetDefaultSQL()
{
	return _T("[InNetwork]");
}

void CDaoInNetworkSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoInNetworkSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[NetworkAddress]"), m_NetworkAddress);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoInNetworkSet diagnostics

#ifdef _DEBUG
void CDaoInNetworkSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoInNetworkSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
