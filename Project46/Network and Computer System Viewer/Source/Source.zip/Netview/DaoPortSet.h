#if !defined(AFX_DAOPORTSET_H__04BE4E43_63C9_495A_AF9B_E5263D2EAAD0__INCLUDED_)
#define AFX_DAOPORTSET_H__04BE4E43_63C9_495A_AF9B_E5263D2EAAD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoPortSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoPortSet DAO recordset

class CDaoPortSet : public CDaoRecordset
{
public:
	CDaoPortSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoPortSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoPortSet, CDaoRecordset)
	long	m_PortNumber;
	CString	m_Protocol;
	CString	m_PortName;
	BOOL	m_Trojan;
	BOOL	m_WantDetect;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoPortSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOPORTSET_H__04BE4E43_63C9_495A_AF9B_E5263D2EAAD0__INCLUDED_)
