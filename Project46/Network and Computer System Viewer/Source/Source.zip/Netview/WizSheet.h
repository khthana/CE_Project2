#if !defined(AFX_WIZSHEET_H__AC86909B_8438_4995_84CC_4D19248B737D__INCLUDED_)
#define AFX_WIZSHEET_H__AC86909B_8438_4995_84CC_4D19248B737D__INCLUDED_

#include "WizPage01.h"	// Added by ClassView
#include "WizPage02.h"	// Added by ClassView
#include "WizPage03.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WizSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWizSheet

class CWizSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CWizSheet)

// Construction
public:
	CWizSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CWizSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWizSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	CWizPage03 m_wizPage03;
	CWizPage02 m_wizPage02;
	CWizPage01 m_wizPage01;
	virtual ~CWizSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWizSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIZSHEET_H__AC86909B_8438_4995_84CC_4D19248B737D__INCLUDED_)
