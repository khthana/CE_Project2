// Share.cpp: implementation of the CShare class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Share.h"

////////////////////////// 
// MY HEADER START HERE
//////////////////////////
#include "DaoShareSet.h"
////////////////////////// 
// MY HEADER END HERE
//////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShare::CShare( CString strShareName, CString strShareComment, CString strShareType,
				BOOL bAccessRead,	BOOL bAccessWrite,
				BOOL bAccessCreate, BOOL bAccessExec,
				BOOL bAccessDelete,	BOOL bAccessAtrib,
				BOOL bAccessPerm,	BOOL bAccessAll )
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_strShareName		= strShareName;
	m_strShareComment	= strShareComment;
	m_strShareType		= strShareType;
	m_bAccessRead		= bAccessRead;
	m_bAccessWrite		= bAccessWrite;
	m_bAccessCreate		= bAccessCreate;
	m_bAccessExec		= bAccessExec;
	m_bAccessDelete		= bAccessDelete;
	m_bAccessAtrib		= bAccessAtrib;
	m_bAccessPerm		= bAccessPerm;
	m_bAccessAll		= bAccessAll;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

CShare::~CShare()
{

}

CString CShare::GetShareName()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_strShareName;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

CString CShare::GetShareComment()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_strShareComment;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

CString CShare::GetShareType()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_strShareType;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessRead()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessRead;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessWrite()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessWrite;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessCreate()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessCreate;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessExec()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessExec;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessDelete()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessDelete;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessAtrib()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessAtrib;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessPerm()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessPerm;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CShare::IsAccessAll()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	return m_bAccessAll;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//					Table >> Share
//	Parameter	: strIP(IN)	>>	Host IP Address 's owner
void CShare::StoreDB(CString strIP)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	
	//-------------------------------------------------------
	//  Store in table Share
	//-------------------------------------------------------
	CString strSQL;
	CDaoShareSet daoShareSet;

	// data
	long lRowCount;
	CString strShareName;
	CString strShareComment;
	CString strShareType;
	BOOL bAccessRead;
	BOOL bAccessWrite;
	BOOL bAccessCreate;
	BOOL bAccessExec;
	BOOL bAccessDelete;
	BOOL bAccessAtrib;
	BOOL bAccessPerm;
	BOOL bAccessAll;

	// set data
	strShareName	= this->m_strShareName;
	strShareComment = this->m_strShareComment;
	strShareType	= this->m_strShareType;
	bAccessRead		= this->m_bAccessRead;
	bAccessWrite	= this->m_bAccessWrite;
	bAccessCreate	= this->m_bAccessCreate;
	bAccessExec		= this->m_bAccessExec;
	bAccessDelete	= this->m_bAccessDelete;
	bAccessAtrib	= this->m_bAccessAtrib;
	bAccessPerm		= this->m_bAccessPerm;
	bAccessAll		= this->m_bAccessAll;

	// check error share name
	// if found "'" then replace "'" with backspace because it make SQL error
	if ( strShareName.Find( '\'' ) != -1 ) strShareName.Replace( '\'', ' ' );

	// create SQL statement
	strSQL =  "SELECT IP, ShareName, ShareComment, ShareType, ";
	strSQL += "AccessRead, AccessWrite, AccessCreate, AccessExec, ";
	strSQL += "AccessDelete, AccessAtrib, AccessPerm, AccessAll ";
	strSQL += "FROM Share WHERE IP='";
	strSQL += strIP;
	strSQL += "' AND ShareName='";
	strSQL += strShareName;
	strSQL += "'";	
	
	// open database
	if ( daoShareSet.IsOpen( ) )
		daoShareSet.Close( );
	daoShareSet.Open( dbOpenDynaset, _T( strSQL ) );
	lRowCount = daoShareSet.GetRecordCount( );

	// if row is not exist (lRowCount==0) then INSERT it
	if ( lRowCount == 0 ) {
		// Insert
		daoShareSet.AddNew( );

		daoShareSet.m_IP			= strIP;
		daoShareSet.m_ShareName		= strShareName;
		daoShareSet.m_ShareComment	= strShareComment;
		daoShareSet.m_ShareType		= strShareType;
		daoShareSet.m_AccessRead	= bAccessRead;
		daoShareSet.m_AccessWrite	= bAccessWrite;
		daoShareSet.m_AccessCreate	= bAccessCreate;
		daoShareSet.m_AccessExec	= bAccessExec;
		daoShareSet.m_AccessDelete	= bAccessDelete;
		daoShareSet.m_AccessAtrib	= bAccessAtrib;
		daoShareSet.m_AccessPerm	= bAccessPerm;
		daoShareSet.m_AccessAll		= bAccessAll;

		daoShareSet.Update( );
	}
	// if row is exist (lRowCount>0) then UPDATE it
	else {
		// Update
		daoShareSet.MoveFirst( );
		daoShareSet.Edit( );

		daoShareSet.m_ShareComment	= strShareComment;
		daoShareSet.m_ShareType		= strShareType;
		daoShareSet.m_AccessRead	= bAccessRead;
		daoShareSet.m_AccessWrite	= bAccessWrite;
		daoShareSet.m_AccessCreate	= bAccessCreate;
		daoShareSet.m_AccessExec	= bAccessExec;
		daoShareSet.m_AccessDelete	= bAccessDelete;
		daoShareSet.m_AccessAtrib	= bAccessAtrib;
		daoShareSet.m_AccessPerm	= bAccessPerm;
		daoShareSet.m_AccessAll		= bAccessAll;

		daoShareSet.Update( );
	}
	
	daoShareSet.Close( );
	//-------------------------------------------------------
	//  Store in table Share
	//-------------------------------------------------------

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}
