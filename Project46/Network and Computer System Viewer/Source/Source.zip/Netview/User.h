// User.h: interface for the CUser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USER_H__016B26DB_3E32_41CD_B0C7_9A88EF256FB9__INCLUDED_)
#define AFX_USER_H__016B26DB_3E32_41CD_B0C7_9A88EF256FB9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUser  
{
public:
	void StoreDB( CString strIP );
	BOOL IsPasswordNotExpire( );
	BOOL IsPasswordCanChange( );
	BOOL IsPasswordReq( );
	BOOL IsAccountEnable( );
	CString GetFullName( );
	CString GetComment( );
	CString GetUserName( );
	CUser( CString strUserName, CString strComment, CString strFullName, BOOL bAccountEnable, BOOL bPasswordReq, BOOL bPasswordCanChange, BOOL bPasswordNotExpire );
	virtual ~CUser();

private:
	BOOL m_bPasswordNotExpire;
	BOOL m_bPasswordCanChange;
	BOOL m_bPasswordReq;
	BOOL m_bAccountEnable;
	CString m_strFullName;
	CString m_strComment;
	CString m_strUserName;
};

#endif // !defined(AFX_USER_H__016B26DB_3E32_41CD_B0C7_9A88EF256FB9__INCLUDED_)
