// Network.h: interface for the CNetwork class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETWORK_H__AF216EF4_63A4_427C_AEAE_A31D8C981A45__INCLUDED_)
#define AFX_NETWORK_H__AF216EF4_63A4_427C_AEAE_A31D8C981A45__INCLUDED_

#include "TypeHostArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNetwork  
{ 
public:
	COleDateTime GetDisconnectTime( );
	COleDateTime GetConnectTime( );
	void StoreDB( );
	void SetLocalNetwork( BOOL bLocalNetwork );
	BOOL IsLocalNetwork( );
	CHost* IsShowTraffic( );
	CHost* IsShowSnmp( );
	void SetNetworkStatus( BOOL bConnect );
	CBitmap* GetBitmap( );
	BOOL IsConnect( );
	void SetIPRange( CString strIPRange );
	CString GetIPRange( );
	void AddAgentIP( CString strAgentIP );
	int FindHost( CString strIP );
	CHostArray* GetHostArray( );
	CString* GetResult( );
	CString GetCommand( );
	void SetCommand( CString strCommand );
	CRectTracker* GetPosition( );
	void AddHost( CString strIP );
	CStringArray* GetAgentIP( );
	CString GetNetmask( );
	CString GetNetworkAddress( );
	CNetwork(CString strNetworkAddress, CString strSubnet);
	virtual ~CNetwork();

protected:
	void StoreAgentDB( );
	void StoreInNetworkDB( );
	void StoreNetworkDB( );
	BOOL m_bLocalNetwork;
	CBitmap m_bmpDisconnect;
	CBitmap m_bmpConnect;
	CBitmap *m_pBitmap;
	BOOL m_bConnect;	// Connect=TRUE, Disconnect=FALSE
	CString m_strIPRange; 
	// IP range for discovery type "Host Range" only (Option 3 in Wizard Page 2)
	CString m_strResult;
	CString m_strCommand;
	CHostArray m_haHosts;
	CRectTracker m_rtPosition;
private:
	CStringArray m_saAgentIPs;
	COleDateTime m_timeDisconnect;
	COleDateTime m_timeConnect;
	CString m_strNetmask;
	CString m_strNetworkAddress;
};

#endif // !defined(AFX_NETWORK_H__AF216EF4_63A4_427C_AEAE_A31D8C981A45__INCLUDED_)
