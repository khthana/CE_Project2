#if !defined(AFX_DAOHASPORTSET_H__9DF7DFD4_B1F8_4FE2_9372_E716D8E01E3E__INCLUDED_)
#define AFX_DAOHASPORTSET_H__9DF7DFD4_B1F8_4FE2_9372_E716D8E01E3E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoHasPortSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoHasPortSet DAO recordset

class CDaoHasPortSet : public CDaoRecordset
{
public:
	CDaoHasPortSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoHasPortSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoHasPortSet, CDaoRecordset)
	CString	m_IP;
	long	m_PortNumber;
	CString	m_Protocol;
	CString	m_Status;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoHasPortSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOHASPORTSET_H__9DF7DFD4_B1F8_4FE2_9372_E716D8E01E3E__INCLUDED_)
