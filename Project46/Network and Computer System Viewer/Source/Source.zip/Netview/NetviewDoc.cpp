// NetviewDoc.cpp : implementation of the CNetviewDoc class
//

#include "stdafx.h"
#include "Netview.h"

///////////////////////////
// MY INCLUDE START HERE
///////////////////////////
#pragma comment( lib, "Ws2_32.lib" )
#include <Winsock2.h>

#include "WizSheet.h"
#include "DaoPortSet.h"
#include "ToolDlg.h"
#include "AddToolDlg.h"
#include "ReportDlg.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#include "NetviewDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetviewDoc

IMPLEMENT_DYNCREATE(CNetviewDoc, CDocument)

BEGIN_MESSAGE_MAP(CNetviewDoc, CDocument)
	//{{AFX_MSG_MAP(CNetviewDoc)
	ON_COMMAND(ID_TOOLS_CUSTOMIZE_TOOL, OnToolsCustomizeTool)
	ON_COMMAND(ID_TOOLS_TOOL1, OnToolsTool1)
	ON_COMMAND(ID_TOOLS_TOOL2, OnToolsTool2)
	ON_COMMAND(ID_TOOLS_TOOL3, OnToolsTool3)
	ON_COMMAND(ID_TOOLS_TOOL4, OnToolsTool4)
	ON_COMMAND(ID_TOOLS_TOOL5, OnToolsTool5)
	ON_COMMAND(ID_TOOLS_TOOL6, OnToolsTool6)
	ON_COMMAND(ID_TOOLS_TOOL7, OnToolsTool7)
	ON_COMMAND(ID_TOOLS_TOOL8, OnToolsTool8)
	ON_COMMAND(ID_TOOLS_TOOL9, OnToolsTool9)
	ON_COMMAND(ID_TOOLS_TOOL10, OnToolsTool10)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL1, OnUpdateToolsTool1)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL2, OnUpdateToolsTool2)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL3, OnUpdateToolsTool3)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL4, OnUpdateToolsTool4)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL5, OnUpdateToolsTool5)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL6, OnUpdateToolsTool6)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL7, OnUpdateToolsTool7)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL8, OnUpdateToolsTool8)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL9, OnUpdateToolsTool9)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOOL10, OnUpdateToolsTool10)
	ON_COMMAND(ID_REPORT_COMPUTER_REPORT, OnReportComputerReport)
	ON_COMMAND(ID_REPORT_COMPUTER_AVAILIABLE_REPORT, OnReportComputerAvailiableReport)
	ON_COMMAND(ID_REPORT_NETWORK_AVAILIABLE_REPORT, OnReportNetworkAvailiableReport)
	ON_COMMAND(ID_REPORT_COMPUTER_SECURITY_REPORT, OnReportComputerSecurityReport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetviewDoc construction/destruction

CNetviewDoc::CNetviewDoc()
{
	// TODO: add one-time construction code here

}

CNetviewDoc::~CNetviewDoc()
{
}

BOOL CNetviewDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here

	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int i, j;
		
	CWizSheet wizSheet( "Netview Wizard" );
	wizSheet.SetWizardMode( );
	if ( wizSheet.DoModal( ) != ID_WIZFINISH ) { // not FINISH return false
		return FALSE;
	}
		
	//-------------------------------------------------------------
	//  Copy data from Wizard Page to CDiscover
	//-------------------------------------------------------------
	// Copy Wizard Page1
	m_Discover.m_iDiscoveryType = wizSheet.m_wizPage01.m_iDiscoveryType;
	// Copy Wizard Page2
	m_Discover.m_strIPStart		= wizSheet.m_wizPage02.m_strIPStart;
	m_Discover.m_strIPEnd		= wizSheet.m_wizPage02.m_strIPEnd;
	m_Discover.m_strNetmask		= wizSheet.m_wizPage02.m_strNetmask;
	m_Discover.m_strInternet	= wizSheet.m_wizPage02.m_saAgentIP[0];
	m_Discover.m_saAgentIP.Copy( wizSheet.m_wizPage02.m_saAgentIP );
	// Copy Wizard Page3
	m_Discover.m_saPortNumber.Copy( wizSheet.m_wizPage03.m_saPortNumber );
	m_Discover.m_saProtocol.Copy( wizSheet.m_wizPage03.m_saProtocol );
	m_Discover.m_saPortName.Copy( wizSheet.m_wizPage03.m_saPortName );
	m_Discover.m_saTrojan.Copy( wizSheet.m_wizPage03.m_saTrojan );

	//-------------------------------------------------------------
	//  Copy data from Wizard Page to CDiscover
	//-------------------------------------------------------------

	//---------------------------------------------------------------------
	//  Split network from wizard page input
	//---------------------------------------------------------------------
	CString strIPStart;
	CString strIPEnd;
	CString strNetmask;
	CString strNetworkAddress;
	STVECTOR svNetworks;
	STVECTOR svNetworkAgentIPs;	// Network which has agent ip follow by svListAgentIP
	STVECTOR svListAgentIP;		// keep Agent IP in List Control in Wizard Page 2
	CNetworkArray *pNetworks;	// keep Network Array in CDiscover
	CNetwork *pNetwork;			// keep CNetwork object

	//-------------------------------------------
	// Wizard Page 1 select option "Local Network (This Network)"
	//-------------------------------------------
	if ( m_Discover.m_iDiscoveryType == 0 ) {
		// Create new network
		strNetmask	= DotToSlash( m_Discover.m_strNetmask );
		svNetworks.push_back( m_Discover.m_strIPStart ); 
		
		// Add new network
		for ( i=0; i<svNetworks.size( ); i++ ) {
			m_Discover.AddNetwork( svNetworks.at(i), strNetmask );
		}

		// move Agent IP data form m_saAgentIP to svListAgentIP
		for ( i=0; i<m_Discover.m_saAgentIP.GetSize( ); i++ ) {
			svListAgentIP.push_back( m_Discover.m_saAgentIP.GetAt( i ) );
		}
		// match Agent IP for each network
		svNetworkAgentIPs = MatchAgentIP( svListAgentIP, svNetworks, m_Discover.m_strNetmask );
		// Add new agent ip for each network
		pNetworks = m_Discover.GetNetworks( ); 
		for ( i=0; i<pNetworks->GetSize( ); i++ ) {
			// get Network Address 
			pNetwork = pNetworks->ElementAt( i );
			strNetworkAddress = pNetwork->GetNetworkAddress( );
			for ( j=0; j<svNetworkAgentIPs.size( ); j++ ) {
				// if (match agent is this network) then
				//  Add svListAgentIP to this network beacuse 
				//  svNetworkAgentIPs follow svListAgentIP
				if ( strNetworkAddress == svNetworkAgentIPs.at( j ) ) {
					pNetwork->AddAgentIP( svListAgentIP.at( j ) );
				}
			}
		}
	}
	//-------------------------------------------
	// Wizard Page 1 select option "Range Network"
	//-------------------------------------------
	else if ( m_Discover.m_iDiscoveryType == 1 ) {
		strIPStart	= m_Discover.m_strIPStart;
		strIPEnd	= m_Discover.m_strIPEnd;
		strNetmask	= DotToSlash( m_Discover.m_strNetmask );
		svNetworks	= DivideNetworkRange( strIPStart, strIPEnd, m_Discover.m_strNetmask );
		
		// Add new network
		for ( i=0; i<svNetworks.size( ); i++ ) {
			m_Discover.AddNetwork( svNetworks.at(i), strNetmask );
		}

		// move Agent IP data form m_saAgentIP to svListAgentIP
		for ( i=0; i<m_Discover.m_saAgentIP.GetSize( ); i++ ) {
			svListAgentIP.push_back( m_Discover.m_saAgentIP.GetAt( i ) );
		}
		// match Agent IP for each network
		svNetworkAgentIPs = MatchAgentIP( svListAgentIP, svNetworks, m_Discover.m_strNetmask );
		// Add new agent ip for each network
		pNetworks = m_Discover.GetNetworks( ); 
		for ( i=0; i<pNetworks->GetSize( ); i++ ) {
			// get Network Address 
			pNetwork = pNetworks->ElementAt( i );
			strNetworkAddress = pNetwork->GetNetworkAddress( );
			for ( j=0; j<svNetworkAgentIPs.size( ); j++ ) {
				// if (match agent is this network) then
				//  Add svListAgentIP to this network beacuse 
				//  svNetworkAgentIPs follow svListAgentIP
				if ( strNetworkAddress == svNetworkAgentIPs.at( j ) ) {
					pNetwork->AddAgentIP( svListAgentIP.at( j ) );
				}
			}
		}
	}
	//-------------------------------------------
	// Wizard Page 1 select option "Range Host"
	//-------------------------------------------
	else if ( m_Discover.m_iDiscoveryType == 2 ) {
		STVECTOR svIPRanges;

		strIPStart	= m_Discover.m_strIPStart;
		strIPEnd	= m_Discover.m_strIPEnd;
		strNetmask	= DotToSlash( m_Discover.m_strNetmask );
		svNetworks	= DivideHostRange( strIPStart, strIPEnd, m_Discover.m_strNetmask );

		// Add new network
		for ( i=0; i<svNetworks.size( ); i++ ) {
			m_Discover.AddNetwork( svNetworks.at(i), strNetmask );
		}

		// move Agent IP data form m_saAgentIP to svListAgentIP
		for ( i=0; i<m_Discover.m_saAgentIP.GetSize( ); i++ ) {
			svListAgentIP.push_back( m_Discover.m_saAgentIP.GetAt( i ) );
		}
		// match Agent IP for each network
		svNetworkAgentIPs = MatchAgentIP( svListAgentIP, svNetworks, m_Discover.m_strNetmask );
		// Add new agent ip for each network
		pNetworks = m_Discover.GetNetworks( ); 
		for ( i=0; i<pNetworks->GetSize( ); i++ ) {
			// get Network Address 
			pNetwork = pNetworks->ElementAt( i );
			strNetworkAddress = pNetwork->GetNetworkAddress( );
			for ( j=0; j<svNetworkAgentIPs.size( ); j++ ) {
				// if (match agent is this network) then
				//  Add svListAgentIP to this network beacuse 
				//  svNetworkAgentIPs follow svListAgentIP
				if ( strNetworkAddress == svNetworkAgentIPs.at( j ) ) {
					pNetwork->AddAgentIP( svListAgentIP.at( j ) );
				}
			}
		}

		// Find IP Address Range and set in Network
		svIPRanges = MatchIPRange( strIPStart, strIPEnd, m_Discover.m_strNetmask );
		for ( i=0; i<pNetworks->GetSize( ); i++ ) {
			pNetwork = pNetworks->ElementAt( i );
			pNetwork->SetIPRange( svIPRanges.at( i ) );
		}
	}
	//---------------------------------------------------------------------
	//  Split network from wizard page input
	//---------------------------------------------------------------------
	
	//-----------------------------------------------------------------
	//  Test each network is local network
	//-----------------------------------------------------------------
	this->TestLocalNetwork( );
	//-----------------------------------------------------------------
	//  Test each network is local network
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------------------
	//  Clear frag in field "Trojan" and "WantDatect" in Port table database
	//-----------------------------------------------------------------------------
	this->ClearPortData( );
	//-----------------------------------------------------------------------------
	//  Clear frag in field "Trojan" and "WantDatect" in Port table database
	//-----------------------------------------------------------------------------

	//-----------------------------------------------------------------
	//  Update scan port data in Table "Port"
	//-----------------------------------------------------------------
	int iListSize;
	CDaoPortSet daoPortSet;	// port table object (DAO)
	CString strPortNumber;
	CString strProtocol;
	CString strPortName;
	CString strTrojan;
	CString strSQL;			// SQL Statement

	int iStartPort, iEndPort;
	char *cStartPort, *cEndPort;
	CString strStartPort, strEndPort;
	char cPort[5];
	
	iListSize = m_Discover.m_saPortNumber.GetSize( );
	//  For each row in List Control
	for ( i=0; i<iListSize; i++ ) {
		strPortNumber	= m_Discover.m_saPortNumber.GetAt( i );
		strProtocol		= m_Discover.m_saProtocol.GetAt( i );
		strPortName		= m_Discover.m_saPortName.GetAt( i );
		strTrojan		= m_Discover.m_saTrojan.GetAt( i );	
		
		//-----------------------------
		// if single port number
		//-----------------------------
		if ( strPortNumber.Find( "-" ) == -1  ) {
			// create SQL Statement
			strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port";
			strSQL += " WHERE PortNumber=";
			strSQL += strPortNumber;
			strSQL += " AND Protocol='";
			strSQL += strProtocol;
			strSQL += "'";
			
			// open database
			if ( daoPortSet.IsOpen( ) ) 
				daoPortSet.Close( );
			daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

			// Edit port data (PortName, Trojan, WantDetect) in database
			daoPortSet.MoveFirst( );
			daoPortSet.Edit( );
			if ( strPortName != "" ) 
				daoPortSet.m_PortName = strPortName;
			if ( strTrojan == "YES" )
				daoPortSet.m_Trojan = TRUE;
			else 
				daoPortSet.m_Trojan = FALSE;
			daoPortSet.m_WantDetect = TRUE;
			daoPortSet.Update( );
			daoPortSet.Close( );
		}
		//-----------------------------
		// if range port number
		//-----------------------------
		else {
			// get start port and end port
			strStartPort= strPortNumber.Left( strPortNumber.Find( "-" ) );
			strEndPort	= strPortNumber.Right( strPortNumber.GetLength( ) - ( strPortNumber.Find( "-" ) + 1 ) );
			cStartPort	= strStartPort.GetBuffer( 5 );
			cEndPort	= strEndPort.GetBuffer( 5 );
			iStartPort	= atoi( cStartPort );
			iEndPort	= atoi( cEndPort );
			
			// for each ( port in port range ) do edit port data 
			for ( j=iStartPort; j<=iEndPort; j++ ) {
				// create SQL Statement
				_itoa( j, cPort, 10 ); // convert integer to char
				strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port";
				strSQL += " WHERE PortNumber=";
				strSQL += cPort;
				strSQL += " AND Protocol='";
				strSQL += strProtocol;
				strSQL += "'";
			
				// open database
				if ( daoPortSet.IsOpen( ) ) 
					daoPortSet.Close( );
				daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

				// Edit port data (Trojan, WantDetect) in database
				daoPortSet.MoveFirst( );
				daoPortSet.Edit( );
				if ( strTrojan == "YES" )
					daoPortSet.m_Trojan = TRUE;
				else 
					daoPortSet.m_Trojan = FALSE;
				daoPortSet.m_WantDetect = TRUE;
				daoPortSet.Update( );
				daoPortSet.Close( );
			}
		}
	}
	//-----------------------------------------------------------------
	//  Update scan port data in Table "Port"
	//-----------------------------------------------------------------

	//------------------------------------------------------
	//  Update Port and Explorer (Use thread)
	//------------------------------------------------------
	m_Discover.UpdatePortData( );
	m_Discover.Explorer( );
	//------------------------------------------------------
	//  Update Port and Explorer (Use thread)
	//------------------------------------------------------

	//------------------------------------------------------------------------
	// Set first Network which display host in CNetviewView(Host View)
	//------------------------------------------------------------------------
	CHostArray *pHosts;
	CHost *pHost;
	pNetworks = m_Discover.GetNetworks( );
	pNetwork = pNetworks->ElementAt( 0 ); 
	if ( pNetwork != NULL ) {
		SetNetworkDisplay( pNetwork );
		pHosts = pNetwork->GetHostArray( );
		if ( pHosts->GetSize( ) != 0 ) {
			pHost = pHosts->ElementAt( 0 );
			SetHostDisplay( pHost );
		}
		else {
			SetHostDisplay( NULL );
		}
	}
	//------------------------------------------------------------------------
	// Set first Network which display host in CNetviewView(Host View)
	//------------------------------------------------------------------------

	//--------------------------------------------
	// Set ping and trace route tools
	//--------------------------------------------
	CString strToolName;
	CString strToolPath;

	strToolName = "Ping";
	strToolPath = ".\\Bin\\ping\\ping.exe";
	m_Discover.AddTool( strToolName, strToolPath );

	strToolName = "Trace Route";
	strToolPath = ".\\Bin\\tracer\\tracer.exe";
	m_Discover.AddTool( strToolName, strToolPath );
	//--------------------------------------------
	// Set ping and trace route tools
	//--------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////

	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CNetviewDoc serialization

void CNetviewDoc::Serialize(CArchive& ar)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	
	if (ar.IsStoring())
	{
		//------------------------------------------------------
		// TODO: add storing code here
		//------------------------------------------------------
		::AfxMessageBox( "Export" );

		
		//ar << this->m_Discover.m_iDiscoveryType;
		
		//------------------------------------------------------
		// TODO: add storing code here
		//------------------------------------------------------
	}
	else
	{
		//----------------------------------------------
		// TODO: add loading code here
		//----------------------------------------------
		::AfxMessageBox( "Import" );
		
		
		//ar >> this->m_Discover.m_iDiscoveryType;
	
		//----------------------------------------------
		// TODO: add loading code here
		//----------------------------------------------
	}

	//---------------------
	// set default path
	//---------------------
	CNetviewApp *pNetviewApp = (CNetviewApp*)::AfxGetApp( );
	::SetCurrentDirectory( pNetviewApp->m_strStartingDirectory );
	//---------------------
	// set default path
	//---------------------
	
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

/////////////////////////////////////////////////////////////////////////////
// CNetviewDoc diagnostics

#ifdef _DEBUG
void CNetviewDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNetviewDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNetviewDoc commands

//////////////////////////////////////////////////////////////////////
//	Description : Convert dot notation to slash notation
//	Parameter	: strDot(IN)	>>	Dot notation
CString CNetviewDoc::DotToSlash(CString strDot)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString netmask[4],slash;
	char chrTemp[3];
	int intnetmask[4],intslash,i;
	int numhost[9] = {0,128,192,224,240,248,252,254,255};
	int start,stop;
	start = stop = intslash = i =0;
	stop = strDot.Find(".",0);
	while(stop > 0)
	{
		netmask[i] = strDot.Mid(start,stop-(start));
		i++;
		start = stop+1;
		stop = strDot.Find(".",start);
	}
	netmask[i] = strDot.Right(strDot.GetLength()-(strDot.ReverseFind('.')+1));
	for(i=0;i<4;i++)
		intnetmask[i] = atoi(netmask[i]);
	if(intnetmask[0] == 255)	
	{
		intslash = intslash+8;
		if(intnetmask[1] == 255)
		{
			intslash = intslash+8;
			if(intnetmask[2] == 255)
			{
				intslash = intslash+8;
				if(intnetmask[3] == 255)
					intslash = intslash+8;
				else
				{
					for(i=0;i<8;i++)
					{
						if(intnetmask[3] == numhost[i])
							intslash = intslash + i;
					}
				}
			}
			else
			{
				for(i=0;i<8;i++)
				{
					if(intnetmask[2] == numhost[i])
						intslash = intslash + i;
				}
			}
		}
		else
		{
			for(i=0;i<8;i++)
			{
				if(intnetmask[1] == numhost[i])
					intslash = intslash + i;
			}
		}
	}
	else
	{
		for(i=0;i<8;i++)
		{
			if(intnetmask[0] == numhost[i])
				intslash = intslash + i;
		}
	}
	itoa(intslash,chrTemp,10);
	slash = chrTemp;
	return slash;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CDiscover* CNetviewDoc::GetDiscover()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_Discover;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CNetworkArray* CNetviewDoc::GetNetworks()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return this->m_Discover.GetNetworks( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Divide network from network range (Duang::NetworkRange())
//	Parameter	:	IPStart(IN)	>>	Input IP Address Start
//					IPEnd(IN)	>>	Input IP Address End
//					Netmask(IN)	>>	Input Netmask
//	Return		: STVECTOR network
//		
STVECTOR CNetviewDoc::DivideNetworkRange(CString IPStart, CString IPEnd, CString Netmask)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	STVECTOR Network;
	CString ipstart[4],ipstop[4],netmask[4],tmpnetwork;
	int intstart[4],intstop[4],intnetmask[4],tmpstart[4],flag;
	char addr0[3],addr1[3],addr2[3],addr3[3];
	//Devide address of IPStart into ipstart
	flag = 0;
	IPAddrToInt(IPStart,intstart);
	IPAddrToInt(IPEnd,intstop);
	IPAddrToInt(Netmask,intnetmask);
	if(intnetmask[0] == 255)
	{
		if(intnetmask[1] == 255)
		{
			if(intnetmask[2] == 255)//if netmask is 255.255.255.x
			{
				tmpstart[0] = intstart[0];
				tmpstart[1] = intstart[1];
				tmpstart[2] = intstart[2];
				tmpstart[3] = intstart[3];
				if(intstop[3] == 0)
				{
					intstop[3] = 255;
					if(intstop[2] == 0)
					{
						intstop[2] = 255;
						if(intstop[1] == 0)
							intstop[1] = 255;
					}
				}
				while(flag == 0)//Do if no error
				{
					if(((tmpstart[0] > intstop[0])||(tmpstart[1] > intstop[1])||(tmpstart[2] > intstop[2]))||
						((tmpstart[0] == intstop[0])&&(tmpstart[1] == intstop[1])&&(tmpstart[2] == intstop[2])&&(tmpstart[3] > intstop[3])))// Check error
						flag = 1;
					if(flag == 0)//if no error,put value into vector
					{
						itoa(tmpstart[0],addr0,10);
						itoa(tmpstart[1],addr1,10);
						itoa(tmpstart[2],addr2,10);
						itoa(tmpstart[3],addr3,10);
						tmpnetwork = addr0;
						tmpnetwork += ".";
						tmpnetwork += addr1;
						tmpnetwork += ".";
						tmpnetwork += addr2;
						tmpnetwork += ".";
						tmpnetwork += addr3;
						Network.push_back(tmpnetwork);
					}
					tmpstart[3] = tmpstart[3]+(256-intnetmask[3]);
					if(tmpstart[3] == 256)
					{
						tmpstart[3] = 0;
						tmpstart[2]++;
						if(tmpstart[2] == 256)
						{
							tmpstart[2] = 0;
							tmpstart[1]++;
							if(tmpstart[1] == 256)
							{
								tmpstart[1] = 0;
								tmpstart[0]++;
							}
						}
					}
				}
			}
			else//if netmask is 255.255.x.0
			{
				tmpstart[0] = intstart[0];
				tmpstart[1] = intstart[1];
				tmpstart[2] = intstart[2];
				if(intstop[2] == 0)
				{
					intstop[2] = 255;
					if(intstop[1] == 0)
						intstop[1] = 255;
				}
				while(flag == 0)//Do if no error
				{
					if(((tmpstart[0] > intstop[0])||(tmpstart[1] > intstop[1]))||
						((tmpstart[0] == intstop[0])&&(tmpstart[1] == intstop[1])&&(tmpstart[2] > intstop[2])))
						flag = 1;
					if(flag == 0)//if no error,put value into vector
					{
						itoa(tmpstart[0],addr0,10);
						itoa(tmpstart[1],addr1,10);
						itoa(tmpstart[2],addr2,10);
						tmpnetwork = addr0;
						tmpnetwork += ".";
						tmpnetwork += addr1;
						tmpnetwork += ".";
						tmpnetwork += addr2;
						tmpnetwork += ".0";
						Network.push_back(tmpnetwork);
					}
					tmpstart[2] = tmpstart[2]+(256-intnetmask[2]);
					if(tmpstart[2] == 256)
					{
						tmpstart[2] = 0;
						tmpstart[1]++;
						if(tmpstart[1] == 256)
						{
							tmpstart[1] = 0;
							tmpstart[0]++;
						}
					}
				}
			}
		}
		else//if netmask is 255.x.0.0
		{
			tmpstart[0] = intstart[0];
			tmpstart[1] = intstart[1];
			if(intstop[1] == 0)
				intstop[1] = 255;
			while(flag == 0)//Do if no error
			{
				if(((tmpstart[0] > intstop[0]))||((tmpstart[0] == intstop[0])&&(tmpstart[1] > intstop[1])))
					flag = 1;
				if(flag == 0)//if no error,put value into vector
				{
					itoa(tmpstart[0],addr0,10);
					itoa(tmpstart[1],addr1,10);
					tmpnetwork = addr0;
					tmpnetwork += ".";
					tmpnetwork += addr1;
					tmpnetwork += ".0.0";
					Network.push_back(tmpnetwork);
				}
				tmpstart[1] = tmpstart[1]+(256-intnetmask[1]);
				if(tmpstart[1] == 256)
				{
					tmpstart[1] = 0;
					tmpstart[0]++;
				}
			}
		}
	}
	else//if netmask is x.0.0.0
	{
		tmpstart[0] = intstart[0];
		while(flag == 0)//Do if no error
		{
			if(tmpstart[0] > intstop[0])
				flag = 1;
			if(flag == 0)//if no error,put value into vector
			{
				itoa(tmpstart[0],addr0,10);
				tmpnetwork = addr0;
				tmpnetwork += ".0.0.0";
				Network.push_back(tmpnetwork);
			}
			tmpstart[0] = tmpstart[0]+(256-intnetmask[0]);
		}
	}
	return Network;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Divide network from host range (Duang::IPRange())
//	Parameter	:	IPStart(IN)	>>	Input IP Address Start
//					IPEnd(IN)	>>	Input IP Address End
//					Netmask(IN)	>>	Input Netmask
//	Return		: STVECTOR network
//
STVECTOR CNetviewDoc::DivideHostRange(CString IPStart, CString IPEnd, CString Netmask)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	STVECTOR Network;
	CString ipstart[4],ipstop[4],netmask[4],tmpnetwork;
	int i,intstart[4],intstop[4],intnetmask[4],tmpstart[4],flag;
	char addr0[3],addr1[3],addr2[3],addr3[3];
	//Devide address of IPStart into ipstart
	i = flag = 0;
	IPAddrToInt(IPStart,intstart);
	IPAddrToInt(IPEnd,intstop);
	IPAddrToInt(Netmask,intnetmask);
	for(i=0;i<4;i++)
		tmpstart[i] = intstart[i];
	i=0;
	while(flag == 0)//Do when no error
	{
		if(((tmpstart[0] > intstop[0])||(tmpstart[1] > intstop[1]))||
			((tmpstart[0] == intstop[0])&&(tmpstart[1] == intstop[1])&&(tmpstart[2] > intstop[2])))//Check error
			flag = 1;
		if(flag == 0)//if no error,will put value into vector
		{
			itoa(tmpstart[0],addr0,10);
			itoa(tmpstart[1],addr1,10);
			itoa(tmpstart[2],addr2,10);
			itoa(tmpstart[3],addr3,10);
			tmpnetwork = addr0;
			tmpnetwork += ".";
			tmpnetwork += addr1;
			tmpnetwork += ".";
			tmpnetwork += addr2;
			tmpnetwork += ".0";
			Network.push_back(tmpnetwork);
		}
		if(i == 0)//When first iteration
		{
			tmpstart[3] = 0;
			tmpstart[2]++;
		}
		else
			tmpstart[2]++;
		if(tmpstart[2] == 256)
		{
			tmpstart[2] = 0;
			tmpstart[1]++;
			if(tmpstart[1] == 256)
			{
				tmpstart[1] = 0;
				tmpstart[0]++;
			}
		}
		i++;
	}
	return Network;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Convert IP Address to integer
//	Parameter	:	IP(IN)		>>	Input IP Address
//					intip(OUT)	>>	Output integer
//
void CNetviewDoc::IPAddrToInt(CString IP, int *intip)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int start,stop,i;
	start = 0;
	CString ip[4];
	i = 0;
	stop = IP.Find(".",0);
	while(stop > 0)
	{
		ip[i] = IP.Mid(start,stop-(start));
		i++;
		start = stop+1;
		stop = IP.Find(".",start);
	}
	ip[i] = IP.Right(IP.GetLength()-(IP.ReverseFind('.')+1));
	for(i=0;i<4;i++)
		intip[i]= atoi(ip[i]);
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Match agent ip and network (Duang::IPAgent())
//	Parameter	:	Agent(IN)	>>	Agent in List Control in Wizard Page 2
//					Network(IN)	>>	Network after divide (from DivideHostRange OR
//									DivideHostRange 's method)
//					Netmask(IN)	>>	Netmask
//	Return		: STVECTOR Network (match sequence from STVECTOR Agent)
//
STVECTOR CNetviewDoc::MatchAgentIP(STVECTOR Agent, STVECTOR Network, CString Netmask)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	STVECTOR NWAgent;
	int intnetwork[4],intagent[4],intnetmask[4],flag,i,j,numagent,subnet;
	int numhost[9] = {0,128,192,224,240,248,252,254,255};
	IPAddrToInt(Netmask,intnetmask);
	numagent = i = flag = 0;
	for(numagent=0;numagent<Agent.size();numagent++)
	{
		flag = i = 0;
		IPAddrToInt(Agent.at(numagent),intagent);
		while((flag == 0)&&(i < Network.size()))
		{
			if(intnetmask[0] == 255)
			{
				if(intnetmask[1] == 255)
				{
					if(intnetmask[2] == 255)
					{
						IPAddrToInt(Network.at(i),intnetwork);
						for(j=0;j<9;j++)//Check 2 power 0-8 from Classless
						{
							if(intnetmask[3]==numhost[j])
								subnet = 256-numhost[j];
						}
						if((intagent[0] == intnetwork[0])&&(intagent[1] == intnetwork[1])&&(intagent[2] == intnetwork[2])&&(intagent[3] >= intnetwork[3])&&(intagent[3] < (intnetwork[3]+subnet)))
						{
							flag = 1;
							NWAgent.push_back(Network.at(i));
						}
					}
					else
					{
						IPAddrToInt(Network.at(i),intnetwork);
						for(j=0;j<9;j++)//Check 2 power 0-8 from Classless
						{
							if(intnetmask[2]==numhost[j])
								subnet = 256-numhost[j];
						}
						if((intagent[0] == intnetwork[0])&&(intagent[1] == intnetwork[1])&&(intagent[2] >= intnetwork[2])&&(intagent[2] < (intnetwork[2]+subnet)))
						{
							flag = 1;
							NWAgent.push_back(Network.at(i));
						}
					}
	
				}
				else
				{
					IPAddrToInt(Network.at(i),intnetwork);
					for(j=0;j<9;j++)//Check 2 power 0-8 from Classless
					{
						if(intnetmask[1]==numhost[j])
							subnet = 256-numhost[j];
					}
					if((intagent[0] == intnetwork[0])&&(intagent[1] >= intnetwork[1])&&(intagent[1] < (intnetwork[1]+subnet)))
					{
						flag = 1;
						NWAgent.push_back(Network.at(i));
					}
				}
			}
			else
			{
				IPAddrToInt(Network.at(i),intnetwork);
				for(i=0;i<9;i++)//Check 2 power 0-8 from Classless
				{
					if(intnetmask[0]==numhost[i])
						subnet = 256-numhost[i];
				}
				if((intagent[0] >= intnetwork[0])&&(intagent[0] < (intnetwork[0]+subnet)))
				{
					flag = 1;
					NWAgent.push_back(Network.at(i));
				}
			}
			i++;
		}
		if(flag == 0)
			NWAgent.push_back("");
	}
	return NWAgent;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Match ip range with network (Duang::DivideRange())
//	Parameter	:	IPStart(IN)	>>	Input IP Address Start
//					IPEnd(IN)	>>	Input IP Address End
//					Netmask(IN)	>>	Input Netmask
//	Return		: STVECTOR Network (match sequence from STVECTOR svNetworks)
//
STVECTOR CNetviewDoc::MatchIPRange(CString IPStart, CString IPEnd, CString Netmask)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	STVECTOR RangeOfIP;
	CString tmpnetwork,intstop3;
	int i,intstart[4],intstop[4],intnetmask[4],tmpstart[4],flag;
	char addr0[3],addr1[3],addr2[3],addr3[3],stop3[3];
	//Devide address of IPStart into ipstart
	i = flag = 0;
	IPAddrToInt(IPStart,intstart);
	IPAddrToInt(IPEnd,intstop);
	IPAddrToInt(Netmask,intnetmask);
	for(i=0;i<4;i++)
		tmpstart[i] = intstart[i];
	i=0;
	itoa(intstop[3],stop3,10);
	intstop3 = stop3;
	while(flag == 0)//Do when no error
	{
		if(((tmpstart[0] > intstop[0])||(tmpstart[1] > intstop[1]))||
			((tmpstart[0] == intstop[0])&&(tmpstart[1] == intstop[1])&&(tmpstart[2] > intstop[2])))//Check error
				flag = 1;
		if(flag == 0)//if no error,will put value into vector
		{
			itoa(tmpstart[0],addr0,10);
			itoa(tmpstart[1],addr1,10);
			itoa(tmpstart[2],addr2,10);
			itoa(tmpstart[3],addr3,10);
			tmpnetwork = addr0;
			tmpnetwork += ".";
			tmpnetwork += addr1;
			tmpnetwork += ".";
			tmpnetwork += addr2;
			if(i == 0)
			{
				tmpnetwork += ".";
				tmpnetwork += addr3;
			}
			else
				tmpnetwork += ".1";
			if(i == 0)//When first iteration
			{
				tmpstart[3] = 0;
				tmpstart[2]++;
			}
			else
				tmpstart[2]++;
			if(tmpstart[2] == 256)
			{
				tmpstart[2] = 0;
				tmpstart[1]++;
				if(tmpstart[1] == 256)
				{
					tmpstart[1] = 0;
					tmpstart[0]++;
				}
			}
			if(((tmpstart[0] > intstop[0])||(tmpstart[1] > intstop[1]))||
				((tmpstart[0] == intstop[0])&&(tmpstart[1] == intstop[1])&&(tmpstart[2] > intstop[2])))//Check error
			{
				tmpnetwork += "-";
				tmpnetwork += intstop3;
				RangeOfIP.push_back(tmpnetwork);
			}
			else
			{
				tmpnetwork += "-254";
				RangeOfIP.push_back(tmpnetwork);
			}
			i++;
		}
	}
	return RangeOfIP;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::SetNetworkDisplay(CNetwork *pNetworkDisplay)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Network which display host in CNetviewView(Host View)
	m_pNetworkDisplay = pNetworkDisplay;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CNetwork* CNetviewDoc::GetNetworkDisplay()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Network which display host in CNetviewView(Host View)
	return m_pNetworkDisplay;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::SetHostDisplay(CHost *pHostDisplay)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Host which display host property in CNetviewView(Host View)
	m_pHostDisplay = pHostDisplay;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CHost* CNetviewDoc::GetHostDisplay()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Host which display host property in CNetviewView(Host View)
	return m_pHostDisplay;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CNetwork* CNetviewDoc::GetNetworkContext()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_pNetworkContext;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::SetNetworkContext(CNetwork *pNetworkContext)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_pNetworkContext = pNetworkContext;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}


//////////////////////////////////////////////////////////////////////
//	Description : Test each network is local network or not
//	
void CNetviewDoc::TestLocalNetwork()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int i, iSizeNetwork;
	CNetworkArray *pNetworks = m_Discover.GetNetworks( );
	CNetwork *pNetwork;
	STVECTOR svNetworks;
	CString strTestNetworkAddress;
	CString strLocalNetwork;// local Network Address
	CString strLocalHost;	// local Host Address

	char *localIP = NULL;	// local IP Address
	char name[255];			// local Host name
	WORD wVersionRequested;	
	WSADATA wsaData;		// Window socket data
	PHOSTENT hostinfo;		// Host information (local IP)

	// ---------------------------
	//  find local IP address
	// ---------------------------
	wVersionRequested = MAKEWORD( 2, 0 ); 

	if ( WSAStartup( wVersionRequested, &wsaData ) == 0 ) {
		// start Window Socket Function
		if( gethostname( name, sizeof(name) ) == 0 ) { 
			// get local machine name (local host name)
			if( (hostinfo = gethostbyname( name )) != NULL ) {
				// get host information by host name
				localIP = inet_ntoa( *(struct in_addr*)*hostinfo->h_addr_list );
				strLocalHost.Format( "%s", localIP );
				strLocalNetwork = CheckLocal( strLocalHost, m_Discover.m_strNetmask );
				strLocalNetwork.TrimLeft( );
				strLocalNetwork.TrimRight( );
			}
		}
		WSACleanup( );
	}
	// ---------------------------
	//  find local IP address
	// ---------------------------

	if ( !strLocalNetwork.IsEmpty( ) ) {
		iSizeNetwork = pNetworks->GetSize( );
		for ( i=0; i<iSizeNetwork; i++ ) {
			pNetwork = pNetworks->ElementAt( i );
			strTestNetworkAddress = pNetwork->GetNetworkAddress( );
			if ( strTestNetworkAddress == strLocalNetwork ) {
				pNetwork->SetLocalNetwork( TRUE );	
			}
			else {
				pNetwork->SetLocalNetwork( FALSE );	
			}
		}
	}
	else {
		iSizeNetwork = pNetworks->GetSize( );
		for ( i=0; i<iSizeNetwork; i++ ) {
			pNetwork = pNetworks->ElementAt( i );
			pNetwork->SetLocalNetwork( FALSE );	
		}
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

//////////////////////////////////////////////////////////////////////
//	Description : Find local network address
//	Parameter	:	Localhost(IN)	>>	Local IP address
//					Netmask(IN)		>>	Input Netmask
//	Return		: CString Network Address
//
CString CNetviewDoc::CheckLocal(CString Localhost, CString Subnet)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////	
	int i,intSubnet[4],TotalHost,intLocalhost[4];
	int numhost[9] = {0,128,192,224,240,248,252,254,255};
	CString Output;
	char Tmp[3];
	IPAddrToInt(Subnet,intSubnet);
	IPAddrToInt(Localhost,intLocalhost);
	if(intSubnet[0] == 255)
	{
		if(intSubnet[1] == 255)
		{
			if(intSubnet[2] == 255)
			{
				for(i=0;i<9;i++)
				{
					if(intSubnet[3] == numhost[i])
						TotalHost = 256-numhost[i];
				}
				intLocalhost[3] = intLocalhost[3] - (intLocalhost[3]%TotalHost);
				Output = itoa(intLocalhost[0],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[1],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[2],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[3],Tmp,10);
			}
			else
			{
				for(i=0;i<8;i++)
				{
					if(intSubnet[2] == numhost[i])
						TotalHost = 256-numhost[i];
				}
				intLocalhost[2] = intLocalhost[2] - (intLocalhost[2]%TotalHost);
				Output = itoa(intLocalhost[0],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[1],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[2],Tmp,10);Output += ".";
				Output += itoa(intLocalhost[3],Tmp,10);
			}
		}
		else
		{
			for(i=0;i<8;i++)
			{
				if(intSubnet[1] == numhost[i])
					TotalHost = 256-numhost[i];
			}
			intLocalhost[1] = intLocalhost[1] - (intLocalhost[1]%TotalHost);
			Output = itoa(intLocalhost[0],Tmp,10);Output += ".";
			Output += itoa(intLocalhost[1],Tmp,10);Output += ".";
			Output += itoa(intLocalhost[2],Tmp,10);Output += ".";
			Output += itoa(intLocalhost[3],Tmp,10);
		}
	}
	else
	{
		for(i=1;i<8;i++)
		{
			if(intSubnet[0] == numhost[i])
				TotalHost = 256-numhost[i];
		}
		intLocalhost[0] = intLocalhost[0] - (intLocalhost[0]%TotalHost);
		Output = itoa(intLocalhost[0],Tmp,10);Output += ".";
		Output += itoa(intLocalhost[1],Tmp,10);Output += ".";
		Output += itoa(intLocalhost[2],Tmp,10);Output += ".";
		Output += itoa(intLocalhost[3],Tmp,10);
	}
	return Output;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

void CNetviewDoc::DeleteContents() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_Discover.ClearAgentBmp( );
	m_Discover.StoreDB( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////

	CDocument::DeleteContents();
}

//////////////////////////////////////////////////////////////////////
//	Description : Clear frag in field "Trojan" and "WantDatect" in 
//                Port table database
//
void CNetviewDoc::ClearPortData()
{
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////

	//-----------------------------------------------------------------
	//  Update scan port data in Table "Port"
	//-----------------------------------------------------------------
	CDaoPortSet daoPortSet;	// port table object (DAO)

	// create SQL Statement
	CString strSQL = "SELECT PortNumber,Protocol,PortName,Trojan,WantDetect FROM Port WHERE WantDetect=TRUE";
			
	// open database
	if ( daoPortSet.IsOpen( ) ) 
		daoPortSet.Close( );
	daoPortSet.Open( dbOpenDynaset, _T( strSQL ) );

	// Edit port data (PortName, Trojan, WantDetect) in database
	if ( !daoPortSet.IsEOF( ) ) {
		daoPortSet.MoveFirst( );
		while ( !daoPortSet.IsEOF( ) ) {
			daoPortSet.Edit( );
			daoPortSet.m_Trojan = FALSE;
			daoPortSet.m_WantDetect = FALSE;
			daoPortSet.Update( );

			// Update Position
			daoPortSet.MoveNext( );
		}
	}
	daoPortSet.Close( );
	//-----------------------------------------------------------------
	//  Update scan port data in Table "Port"
	//-----------------------------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Refresh explorer
//
void CNetviewDoc::RefreshExplorer()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CHostArray *pHosts;
	CHost *pHost;
	CNetworkArray *pNetworks;
	CNetwork *pNetwork;
	int i;
	int iNetworkSize;

	//------------------------------------------------------
	//  Explorer (Use thread)
	//------------------------------------------------------
	m_Discover.Explorer( );
	//------------------------------------------------------
	//  Explorer (Use thread)
	//------------------------------------------------------

	//----------------------------
	//  Update data to database
	//----------------------------
	m_Discover.StoreDB( );
	//----------------------------
	//  Update data to database
	//----------------------------

	//-----------------------------------------------
	// Sort host order
	//-----------------------------------------------
	pNetworks = m_Discover.GetNetworks( );
	iNetworkSize = pNetworks->GetSize( );
	for ( i=0; i<iNetworkSize; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		pHosts = pNetwork->GetHostArray( );
		
		// Sort 
		SortHost( pHosts );
	}
	//-----------------------------------------------
	// Sort host order
	//-----------------------------------------------

	//------------------------------------------------------------------------
	// Set first Network which display host in CNetviewView(Host View)
	//------------------------------------------------------------------------
	pNetworks = m_Discover.GetNetworks( );
	pNetwork = pNetworks->ElementAt( 0 ); 
	if ( pNetwork != NULL ) {
		SetNetworkDisplay( pNetwork );

		pHosts = pNetwork->GetHostArray( );
		if ( pHosts->GetSize( ) != 0 ) {
			pHost = pHosts->ElementAt( 0 );
			SetHostDisplay( pHost );
		}
	}
	//------------------------------------------------------------------------
	// Set first Network which display host in CNetviewView(Host View)
	//------------------------------------------------------------------------
	
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find local network address (Buble sort)
//	Parameter	:	pHosts(IN/OUT)	>>	Host Array for sort
//				
void CNetviewDoc::SortHost(CHostArray *pHosts)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CHost *pHost1, *pHost2;
	CString strIP1, strIP2;
	
	int i, j; 
	int iSizeHost;
	BOOL bPass = FALSE;

	iSizeHost = pHosts->GetSize( );
	for ( i=iSizeHost-1; ((i>0)&&!(bPass)); i-- ) {
		bPass = TRUE;
		for ( j=0; j<i; j++ ) {
			// get IP Address
			pHost1 = pHosts->ElementAt( j+1 );
			pHost2 = pHosts->ElementAt( j );
			strIP1 = pHost1->GetIP( );
			strIP2 = pHost2->GetIP( );

			// if strIP1 < strIP2
			if ( strIP1.Compare( strIP2 ) < 0 ) {
				// swap host
				pHosts->SetAt( j+1, pHost2 );
				pHosts->SetAt( j  , pHost1 );
				bPass = FALSE;
			}
		}	
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsCustomizeTool() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CAddToolDlg dlgAddTool;
	dlgAddTool.m_pDiscover = this->GetDiscover( );
	dlgAddTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool1() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 1; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool2() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 2; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool3() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 3; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool4() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 4; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool5() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 5; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool6() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 6; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool7() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 7; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool8() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 8; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool9() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 9; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnToolsTool10() 
{
	// TODO: Add your command handler code here

	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 10; // tool number (in all 10 tool)
	CToolDlg dlgTool;
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;

	pTools	= m_Discover.GetTools( );
	pTool	= pTools->ElementAt( iTool-1 );	// set tool number
	strToolName = pTool->GetToolName( );

	dlgTool.m_strToolName	= strToolName;
	dlgTool.m_pDiscover		= this->GetDiscover( );
	dlgTool.m_pHostDisplay	= this->m_pHostDisplay;
	dlgTool.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool1(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 1; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool2(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 2; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool3(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 3; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool4(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 4; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool5(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 5; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool6(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 6; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool7(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 7; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool8(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 8; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool9(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 9; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnUpdateToolsTool10(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	int iTool = 10; // tool number (in all 10 tool)
	int iToolSize;
	CToolArray *pTools;
	CTool *pTool;
	CString strToolName;

	pTools		= m_Discover.GetTools( );
	iToolSize	= pTools->GetSize( );

	// if not have tool then disible menu item else enable
	if ( iToolSize < iTool ) {
		pCmdUI->Enable( FALSE );

		// display tool name to menu item
		strToolName.Format( "Tool %i", iTool ); 
		pCmdUI->SetText( strToolName );
	}
	else { 
		pCmdUI->Enable( TRUE );

		// display tool name to menu item
		pTool = pTools->ElementAt( iTool-1 );
		strToolName = pTool->GetToolName( );
		pCmdUI->SetText( strToolName );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnReportComputerReport() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CReportDlg dlgReport;
	dlgReport.m_pDiscover = this->GetDiscover( );
	dlgReport.m_iReportType = 1;	
	dlgReport.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnReportComputerAvailiableReport() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CReportDlg dlgReport;
	dlgReport.m_pDiscover = this->GetDiscover( );
	dlgReport.m_iReportType = 2;	
	dlgReport.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnReportNetworkAvailiableReport() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CReportDlg dlgReport;
	dlgReport.m_pDiscover = this->GetDiscover( );
	dlgReport.m_iReportType = 3;	
	dlgReport.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CNetviewDoc::OnReportComputerSecurityReport() 
{
	// TODO: Add your command handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CReportDlg dlgReport;
	dlgReport.m_pDiscover = this->GetDiscover( );
	dlgReport.m_iReportType = 4;	
	dlgReport.DoModal( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}
