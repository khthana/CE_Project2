// WizPage01.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "WizPage01.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizPage01 property page

IMPLEMENT_DYNCREATE(CWizPage01, CPropertyPage)

CWizPage01::CWizPage01() : CPropertyPage(CWizPage01::IDD)
{
	//{{AFX_DATA_INIT(CWizPage01)
	//}}AFX_DATA_INIT
}

CWizPage01::~CWizPage01()
{
}

void CWizPage01::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizPage01)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizPage01, CPropertyPage)
	//{{AFX_MSG_MAP(CWizPage01)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizPage01 message handlers

BOOL CWizPage01::OnSetActive() 
{
	// TODO: Add your specialized code here and/or call the base class

	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CPropertySheet *pSheet = ( CPropertySheet* )this->GetParent( );
	pSheet->SetWizardButtons( PSWIZB_NEXT );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnSetActive();
}

BOOL CWizPage01::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CButton *ctlLocalNetwork = (CButton*)this->GetDlgItem( IDC_RADIO_LOCALNETWORK );
	ctlLocalNetwork->SetCheck( 1 );
	UpdateData( FALSE );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWizPage01::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CPropertySheet *pSheet = ( CPropertySheet* )this->GetParent( );
	pSheet->SetTitle( "Device Discovery Type - Step 1 of 3" );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
	
	// Do not call CPropertyPage::OnPaint() for painting messages
}

BOOL CWizPage01::OnQueryCancel() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	if ( MessageBox( "Are you sure to quit?", "Quit", 
					 MB_YESNO | MB_ICONINFORMATION ) == IDNO ) {
		return FALSE;
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnQueryCancel();
}

LRESULT CWizPage01::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////////
	CButton *ctlLocalNetwork = (CButton*)this->GetDlgItem( IDC_RADIO_LOCALNETWORK );
	CButton *ctlRangeNetwork = (CButton*)this->GetDlgItem( IDC_RADIO_RANGENETWORK );
	CButton *ctlRangeHost	 = (CButton*)this->GetDlgItem( IDC_RADIO_RANGEHOST );
	if ( (ctlLocalNetwork->GetCheck( )) == 1 )
		this->m_iDiscoveryType = 0;
	else if ( (ctlRangeNetwork->GetCheck( )) == 1 ) 
		this->m_iDiscoveryType = 1;
	else if ( (ctlRangeHost->GetCheck( )) == 1 )
		this->m_iDiscoveryType = 2;
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnWizardNext();
}
