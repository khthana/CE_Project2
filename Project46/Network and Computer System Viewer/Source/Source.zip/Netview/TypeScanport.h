// TypeScanport.h : Define Type
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_TYPE_SCANPORT_INCLUDED_)
#define _TYPE_SCANPORT_INCLUDED_

///////////////////////////////
// MY INCLUDE START HERE
///////////////////////////////
#include <vector>
using namespace std; 
///////////////////////////////
// MY INCLUDE END HERE
///////////////////////////////

///////////////////////////////
// MY DEFINE TYPE START HERE
///////////////////////////////
typedef vector<CString> STVECTOR;

struct scanport
{
	CString ip;
	CString hostname;
	CString os;
	CString type;
	CString port;		// Total port in host		
	STVECTOR numport;
	STVECTOR protocol;
	STVECTOR state;
	STVECTOR service;	
};
///////////////////////////////
// MY DEFINE TYPE END HERE
///////////////////////////////

#endif