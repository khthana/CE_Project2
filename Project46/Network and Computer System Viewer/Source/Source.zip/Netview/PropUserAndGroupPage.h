#if !defined(AFX_PROPUSERANDGROUPPAGE_H__367982F4_1733_4162_9C79_0389C8BE8AB4__INCLUDED_)
#define AFX_PROPUSERANDGROUPPAGE_H__367982F4_1733_4162_9C79_0389C8BE8AB4__INCLUDED_

#include "TypeUserArray.h"	// Added by ClassView
#include "TypeGroupArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropUserAndGroupPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropUserAndGroupPage dialog

class CPropUserAndGroupPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropUserAndGroupPage)

// Construction
public:
	CGroupArray m_gaGroups;
	CUserArray m_uaUsers;
	CPropUserAndGroupPage();
	~CPropUserAndGroupPage();

// Dialog Data
	//{{AFX_DATA(CPropUserAndGroupPage)
	enum { IDD = IDD_PROPPAGE_USERANDGROUP };
	CListCtrl	m_ctlListUser;
	CListCtrl	m_ctlListGroup;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropUserAndGroupPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropUserAndGroupPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPUSERANDGROUPPAGE_H__367982F4_1733_4162_9C79_0389C8BE8AB4__INCLUDED_)
