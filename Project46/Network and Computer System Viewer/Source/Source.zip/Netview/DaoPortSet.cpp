// DaoPortSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoPortSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoPortSet

IMPLEMENT_DYNAMIC(CDaoPortSet, CDaoRecordset)

CDaoPortSet::CDaoPortSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoPortSet)
	m_PortNumber = 0;
	m_Protocol = _T("");
	m_PortName = _T("");
	m_Trojan = FALSE;
	m_WantDetect = FALSE;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoPortSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoPortSet::GetDefaultSQL()
{
	return _T("[Port]");
}

void CDaoPortSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoPortSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[PortNumber]"), m_PortNumber);
	DFX_Text(pFX, _T("[Protocol]"), m_Protocol);
	DFX_Text(pFX, _T("[PortName]"), m_PortName);
	DFX_Bool(pFX, _T("[Trojan]"), m_Trojan);
	DFX_Bool(pFX, _T("[WantDetect]"), m_WantDetect);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoPortSet diagnostics

#ifdef _DEBUG
void CDaoPortSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoPortSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
