; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CNetviewApp
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Netview.h"
LastPage=0

ClassCount=38
Class1=CNetviewApp
Class2=CNetviewDoc
Class3=CNetviewView
Class4=CMainFrame

ResourceCount=29
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDR_NETVIETYPE
Resource8=IDD_PROPPAGE_LARGE (English (U.S.))
Resource9=IDD_DIALOG_SERVICE
Class5=CChildFrame
Class6=CAboutDlg
Resource10=IDD_DIALOG_SNMP
Resource11=IDD_WIZPAGE01 (English (U.S.))
Resource4=IDD_WIZPAGE02 (English (U.S.))
Resource5=IDD_DIALOG_HELP
Resource6=IDD_DIALOG_MRTG
Resource7=IDD_PROPPAG (English (U.S.))
Class7=CWizPage01
Class8=CWizPage02
Class9=CWizPage03
Class10=CWizSheet
Class11=CServiceDlg
Resource12=IDD_DIALOG_SET_AUTO_REFRESH
Class12=CAgentIPDlg
Class13=CNetworkView
Class14=CAddToolDlg
Class15=CDaoGroupSet
Class16=CDaoNetworkSet
Class17=CSnmpDlg
Class18=CDaoMACSet
Class19=CDaoMACVendorSet
Class20=CDaoMemberSet
Class21=CDaoHasPortSet
Class22=CDaoUseVendorSet
Class23=CDaoShareSet
Class24=CToolDlg
Class25=CDaoUserSet
Class26=CDaoPortSet
Resource13=IDD_PROPPAGE_USERANDGROUP (English (U.S.))
Class27=CWaitDlg
Resource14=IDD_PROPPAGE_HOST (English (U.S.))
Resource15=IDD_PROPPAGE_SNMP (English (U.S.))
Resource16=IDR_CONTEXTMENU
Class28=CPropHostSheet
Resource17=IDD_PROPPAGE_SHARE (English (U.S.))
Resource18=IDD_WIZPAGE03 (English (U.S.))
Resource19=IDD_DIALOG_TOOL
Class29=CDaoHostSet
Resource20=IDR_NETVIETYPE (English (U.S.))
Resource21=IDD_DIALOG_REPORT
Resource22=IDD_PROPPAGE_GROUP (English (U.S.))
Class30=CPropHostPage
Class31=CPropPortPage
Class32=CPropSharePage
Class33=CPropSnmpPage
Class34=CPropUserAndGroupPage
Class35=CMrtgDlg
Resource23=IDD_ABOUTBOX (English (U.S.))
Class36=CSetAutoRefreshDlg
Resource24=IDD_DIALOG_AGENTIP
Resource25=IDD_PROPPAGE_PORT (English (U.S.))
Resource26=IDD_DIALOG_ADD_TOOL
Class37=CReportDlg
Resource27=IDD_DIALOG_WAIT
Resource28=IDR_MENU_REPORT
Class38=CHelpDlg
Resource29=IDR_MAINFRAME (English (U.S.))

[CLS:CNetviewApp]
Type=0
HeaderFile=Netview.h
ImplementationFile=Netview.cpp
Filter=N
LastObject=ID_HELP_NETVIEW_HELP
BaseClass=CWinApp
VirtualFilter=AC

[CLS:CNetviewDoc]
Type=0
HeaderFile=NetviewDoc.h
ImplementationFile=NetviewDoc.cpp
Filter=N
LastObject=CNetviewDoc
BaseClass=CDocument
VirtualFilter=DC

[CLS:CNetviewView]
Type=0
HeaderFile=NetviewView.h
ImplementationFile=NetviewView.cpp
Filter=C
LastObject=ID_REPORT_COMPUTER_REPORT
BaseClass=CScrollView
VirtualFilter=VWC


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
LastObject=CMainFrame
BaseClass=CMDIFrameWnd
VirtualFilter=fWC


[CLS:CChildFrame]
Type=0
HeaderFile=ChildFrm.h
ImplementationFile=ChildFrm.cpp
Filter=M
LastObject=ID_REPORTFILE_PRINT
BaseClass=CMDIChildWnd
VirtualFilter=mfWC


[CLS:CAboutDlg]
Type=0
HeaderFile=Netview.cpp
ImplementationFile=Netview.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_VIEW_TOOLBAR
Command7=ID_VIEW_STATUS_BAR
CommandCount=8
Command8=ID_APP_ABOUT

[TB:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
CommandCount=8
Command8=ID_APP_ABOUT

[MNU:IDR_NETVIETYPE]
Type=1
Class=CNetviewView
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_CLOSE
Command4=ID_FILE_SAVE
Command5=ID_FILE_SAVE_AS
Command6=ID_FILE_PRINT
Command7=ID_FILE_PRINT_PREVIEW
Command8=ID_FILE_PRINT_SETUP
Command9=ID_FILE_MRU_FILE1
Command10=ID_APP_EXIT
Command11=ID_EDIT_UNDO
Command12=ID_EDIT_CUT
Command13=ID_EDIT_COPY
Command14=ID_EDIT_PASTE
CommandCount=21
Command15=ID_VIEW_TOOLBAR
Command16=ID_VIEW_STATUS_BAR
Command17=ID_WINDOW_NEW
Command18=ID_WINDOW_CASCADE
Command19=ID_WINDOW_TILE_HORZ
Command20=ID_WINDOW_ARRANGE
Command21=ID_APP_ABOUT

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
CommandCount=14
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE


[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_VIEW_REFRESH
Command5=ID_CONFIGURE_SET_AUTO_REFRESH
Command6=ID_TOOLS_CUSTOMIZE_TOOL
Command7=ID_APP_ABOUT
CommandCount=7

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_APP_EXIT
Command3=ID_VIEW_TOOLBAR
Command4=ID_VIEW_STATUS_BAR
Command5=ID_HELP_NETVIEW_HELP
Command6=ID_APP_ABOUT
CommandCount=6

[MNU:IDR_NETVIETYPE (English (U.S.))]
Type=1
Class=CNetviewView
Command1=ID_FILE_NEW
Command2=ID_FILE_CLOSE
Command3=ID_APP_EXIT
Command4=ID_VIEW_TOOLBAR
Command5=ID_VIEW_STATUS_BAR
Command6=ID_VIEW_REFRESH
Command7=ID_CONFIGURE_SET_AUTO_REFRESH
Command8=ID_TOOLS_CUSTOMIZE_TOOL
Command9=ID_TOOLS_TOOL1
Command10=ID_TOOLS_TOOL2
Command11=ID_TOOLS_TOOL3
Command12=ID_TOOLS_TOOL4
Command13=ID_TOOLS_TOOL5
Command14=ID_TOOLS_TOOL6
Command15=ID_TOOLS_TOOL7
Command16=ID_TOOLS_TOOL8
Command17=ID_TOOLS_TOOL9
Command18=ID_TOOLS_TOOL10
Command19=ID_REPORT_COMPUTER_REPORT
Command20=ID_REPORT_COMPUTER_AVAILIABLE_REPORT
Command21=ID_REPORT_NETWORK_AVAILIABLE_REPORT
Command22=ID_REPORT_COMPUTER_SECURITY_REPORT
Command23=ID_WINDOW_NEW
Command24=ID_WINDOW_CASCADE
Command25=ID_WINDOW_TILE_HORZ
Command26=ID_WINDOW_ARRANGE
Command27=ID_HELP_NETVIEW_HELP
Command28=ID_APP_ABOUT
CommandCount=28

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_COPY
Command2=ID_TOOLS_CUSTOMIZE_TOOL
Command3=ID_FILE_NEW
Command4=ID_FILE_OPEN
Command5=ID_FILE_PRINT
Command6=ID_VIEW_REFRESH
Command7=ID_FILE_SAVE
Command8=ID_CONFIGURE_SET_AUTO_REFRESH
Command9=ID_EDIT_PASTE
Command10=ID_EDIT_UNDO
Command11=ID_EDIT_CUT
Command12=ID_NEXT_PANE
Command13=ID_PREV_PANE
Command14=ID_EDIT_COPY
Command15=ID_EDIT_PASTE
Command16=ID_EDIT_CUT
Command17=ID_EDIT_UNDO
CommandCount=17

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=5
Control1=IDC_STATIC,static,1342308480
Control2=IDC_STATIC,static,1342308352
Control3=IDOK,button,1342373889
Control4=IDC_STATIC,static,1342177294
Control5=IDC_STATIC,static,1342308352

[DLG:IDD_PROPPAG (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC,static,1342308352

[DLG:IDD_PROPPAGE_LARGE (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC,static,1342308352

[DLG:IDD_WIZPAGE03 (English (U.S.))]
Type=1
Class=CWizPage03
ControlCount=5
Control1=IDC_STATIC,static,1342308352
Control2=IDC_LIST_SERVICE,SysListView32,1350631425
Control3=IDC_BUTTON_ADDSERVICE,button,1342242816
Control4=IDC_BUTTON_REMOVESERVICE,button,1342242816
Control5=IDC_STATIC,static,1342177294

[DLG:IDD_WIZPAGE01 (English (U.S.))]
Type=1
Class=CWizPage01
ControlCount=5
Control1=IDC_STATIC,static,1342308352
Control2=IDC_RADIO_LOCALNETWORK,button,1342177289
Control3=IDC_RADIO_RANGENETWORK,button,1342177289
Control4=IDC_RADIO_RANGEHOST,button,1342177289
Control5=IDC_STATIC,static,1342177294

[DLG:IDD_WIZPAGE02 (English (U.S.))]
Type=1
Class=CWizPage02
ControlCount=16
Control1=IDC_STATIC,static,1342308352
Control2=IDC_STATIC,static,1342308352
Control3=IDC_IPADDRESS_START,SysIPAddress32,1342242816
Control4=IDC_STATIC,static,1342308352
Control5=IDC_IPADDRESS_END,SysIPAddress32,1342242816
Control6=IDC_STATIC,static,1342308352
Control7=IDC_IPADDRESS_NETMASK,SysIPAddress32,1342242816
Control8=IDC_STATIC,static,1342308352
Control9=IDC_IPADDRESS_INTERNETIP,SysIPAddress32,1342242816
Control10=IDC_STATIC,static,1342308352
Control11=IDC_IPADDRESS_ADDAGENTIP,SysIPAddress32,1342242816
Control12=IDC_LIST_AGENTIP,listbox,1352728835
Control13=IDC_BUTTON_ADDAGENTIP,button,1342242816
Control14=IDC_BUTTON_REMOVEAGENTIP,button,1342242816
Control15=IDC_BUTTON_REMOVEALLAGENTIP,button,1342242816
Control16=IDC_STATIC,static,1342177294

[CLS:CWizPage01]
Type=0
HeaderFile=WizPage01.h
ImplementationFile=WizPage01.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CWizPage01
VirtualFilter=idWC

[CLS:CWizPage02]
Type=0
HeaderFile=WizPage02.h
ImplementationFile=WizPage02.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=IDC_BUTTON_ADDAGENTIP
VirtualFilter=idWC

[CLS:CWizPage03]
Type=0
HeaderFile=WizPage03.h
ImplementationFile=WizPage03.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CWizPage03
VirtualFilter=idWC

[CLS:CWizSheet]
Type=0
HeaderFile=WizSheet.h
ImplementationFile=WizSheet.cpp
BaseClass=CPropertySheet
Filter=W
LastObject=CWizSheet

[DLG:IDD_DIALOG_SERVICE]
Type=1
Class=CServiceDlg
ControlCount=15
Control1=IDC_STATIC,button,1342177287
Control2=IDC_RADIO_SINGLEPORT,button,1342308361
Control3=IDC_RADIO_RANGEPORT,button,1342177289
Control4=IDC_STATIC,button,1342177287
Control5=IDC_RADIO_TCPPORT,button,1342308361
Control6=IDC_RADIO_UDPPORT,button,1342177289
Control7=IDC_CHECK_TROJANPORT,button,1342242819
Control8=IDC_STATIC,static,1342308352
Control9=IDC_EDIT_STARTPORT,edit,1350631552
Control10=IDC_STATIC,static,1342308352
Control11=IDC_EDIT_ENDPORT,edit,1484849280
Control12=IDC_STATIC,static,1342308352
Control13=IDC_EDIT_PORTBANNER,edit,1352728644
Control14=IDOK,button,1342242817
Control15=IDCANCEL,button,1342242816

[CLS:CServiceDlg]
Type=0
HeaderFile=ServiceDlg.h
ImplementationFile=ServiceDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CServiceDlg
VirtualFilter=dWC

[DLG:IDD_DIALOG_AGENTIP]
Type=1
Class=CAgentIPDlg
ControlCount=8
Control1=IDC_STATIC,static,1342308352
Control2=IDC_IPADDRESS_NETWORK,SysIPAddress32,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_IPADDRESS_NETMASK,SysIPAddress32,1342242816
Control5=IDC_STATIC,static,1342308352
Control6=IDC_IPADDRESS_AGENTIP,SysIPAddress32,1342242816
Control7=IDOK,button,1342242817
Control8=IDCANCEL,button,1342242816

[CLS:CAgentIPDlg]
Type=0
HeaderFile=AgentIPDlg.h
ImplementationFile=AgentIPDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CAgentIPDlg
VirtualFilter=dWC

[CLS:CNetworkView]
Type=0
HeaderFile=NetworkView.h
ImplementationFile=NetworkView.cpp
BaseClass=CScrollView
Filter=C
LastObject=ID_TOOLS_TOOL1
VirtualFilter=VWC

[DB:CDaoAddToolSet]
DB=1
DBType=DAO
ColumnCount=3
Column1=[IP], 12, 15
Column2=[ToolName], 12, 255
Column3=[Result], -1, 0

[CLS:CDaoGroupSet]
Type=0
HeaderFile=DaoGroupSet.h
ImplementationFile=DaoGroupSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoGroupSet

[DB:CDaoGroupSet]
DB=1
DBType=DAO
ColumnCount=3
Column1=[IP], 12, 15
Column2=[GroupName], 12, 255
Column3=[GroupComment], 12, 255

[DB:CDaoHasPortSet]
DB=1
DBType=DAO
ColumnCount=4
Column1=[IP], 12, 15
Column2=[PortNumber], 4, 4
Column3=[Protocol], 12, 3
Column4=[Status], 12, 50

[DB:CDaoHostSet]
DB=1
DBType=DAO
ColumnCount=15
Column1=[IP], 12, 15
Column2=[HostName], 12, 255
Column3=[OS], 12, 255
Column4=[Type], 12, 255
Column5=[SNMP], -7, 1
Column6=[OpenTime], 11, 8
Column7=[OpenDate], 11, 8
Column8=[CloseTime], 11, 8
Column9=[CloseDate], 11, 8
Column10=[MinLength], 12, 50
Column11=[MinAge], 12, 50
Column12=[MaxAge], 12, 50
Column13=[LockoutDuration], 12, 50
Column14=[LockoutReset], 12, 50
Column15=[LockoutThreshold], 12, 50

[CLS:CDaoMACSet]
Type=0
HeaderFile=DaoMACSet.h
ImplementationFile=DaoMACSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoMACSet

[DB:CDaoMACSet]
DB=1
DBType=DAO
ColumnCount=2
Column1=[IP], 12, 15
Column2=[MACAddress], 12, 17

[CLS:CDaoMACVendorSet]
Type=0
HeaderFile=DaoMACVendorSet.h
ImplementationFile=DaoMACVendorSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:CDaoMACVendorSet]
DB=1
DBType=DAO
ColumnCount=2
Column1=[VendorMAC], 12, 8
Column2=[VendorName], 12, 255

[CLS:CDaoMemberSet]
Type=0
HeaderFile=DaoMemberSet.h
ImplementationFile=DaoMemberSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x

[DB:CDaoMemberSet]
DB=1
DBType=DAO
ColumnCount=3
Column1=[IP], 12, 15
Column2=[GroupName], 12, 255
Column3=[UserName], 12, 255

[DB:CDaoNetworkSet]
DB=1
DBType=DAO
ColumnCount=7
Column1=[NetworkAddress], 12, 15
Column2=[Netmask], 12, 2
Column3=[AgentIP], 12, 15
Column4=[ConnectTime], 11, 8
Column5=[ConnectDate], 11, 8
Column6=[DisconnectTime], 11, 8
Column7=[DisconnectDate], 11, 8

[DB:CDaoPortSet]
DB=1
DBType=DAO
ColumnCount=5
Column1=[PortNumber], 4, 4
Column2=[Protocol], 12, 3
Column3=[PortName], 12, 255
Column4=[Trojan], -7, 1
Column5=[WantDetect], -7, 1

[CLS:CDaoShareSet]
Type=0
HeaderFile=DaoShareSet.h
ImplementationFile=DaoShareSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoShareSet

[DB:CDaoShareSet]
DB=1
DBType=DAO
ColumnCount=12
Column1=[IP], 12, 15
Column2=[ShareName], 12, 255
Column3=[ShareComment], 12, 255
Column4=[ShareType], 12, 50
Column5=[AccessRead], -7, 1
Column6=[AccessWrite], -7, 1
Column7=[AccessCreate], -7, 1
Column8=[AccessExec], -7, 1
Column9=[AccessDelete], -7, 1
Column10=[AccessAtrib], -7, 1
Column11=[AccessPerm], -7, 1
Column12=[AccessAll], -7, 1

[DB:CDaoToolSet]
DB=1
DBType=DAO
ColumnCount=1
Column1=[ToolName], 12, 255

[CLS:CDaoUserSet]
Type=0
HeaderFile=DaoUserSet.h
ImplementationFile=DaoUserSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoUserSet

[DB:CDaoUserSet]
DB=1
DBType=DAO
ColumnCount=8
Column1=[IP], 12, 15
Column2=[UserName], 12, 255
Column3=[UserComment], 12, 255
Column4=[FullName], 12, 255
Column5=[AccountEnable], -7, 1
Column6=[PWRequired], -7, 1
Column7=[PWCanChange], -7, 1
Column8=[PWNotExpire], -7, 1

[CLS:CDaoUseVendorSet]
Type=0
HeaderFile=DaoUseVendorSet.h
ImplementationFile=DaoUseVendorSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoUseVendorSet

[DB:CDaoUseVendorSet]
DB=1
DBType=DAO
ColumnCount=3
Column1=[IP], 12, 15
Column2=[VendorMAC], 12, 8
Column3=[VendorName], 12, 255

[CLS:CDaoHasPortSet]
Type=0
HeaderFile=DaoHasPortSet.h
ImplementationFile=DaoHasPortSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoHasPortSet

[CLS:CDaoNetworkSet]
Type=0
HeaderFile=DaoNetworkSet.h
ImplementationFile=DaoNetworkSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoNetworkSet

[CLS:CDaoPortSet]
Type=0
HeaderFile=DaoPortSet.h
ImplementationFile=DaoPortSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoPortSet

[DLG:IDD_DIALOG_WAIT]
Type=1
Class=CWaitDlg
ControlCount=4
Control1=IDC_PROGRESS_WAIT,msctls_progress32,1350565888
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC_SHOW,static,1342308352
Control4=IDOK,button,1342242816

[CLS:CWaitDlg]
Type=0
HeaderFile=WaitDlg.h
ImplementationFile=WaitDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CWaitDlg
VirtualFilter=dWC

[MNU:IDR_CONTEXTMENU]
Type=1
Class=?
Command1=ID_NETWORK_TRAFFIC
Command2=ID_NETWORK_SNMP
CommandCount=2

[DLG:IDD_DIALOG_MRTG]
Type=1
Class=CMrtgDlg
ControlCount=2
Control1=IDC_BUTTON_PRINT,button,1342242816
Control2=IDC_BUTTON_CLOSE,button,1342242816

[DLG:IDD_DIALOG_SNMP]
Type=1
Class=CSnmpDlg
ControlCount=2
Control1=IDC_TREE_MIB,SysTreeView32,1350631424
Control2=IDC_EDIT_VALUE,edit,1352730692

[CLS:CSnmpDlg]
Type=0
HeaderFile=SnmpDlg.h
ImplementationFile=SnmpDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_EDIT_VALUE
VirtualFilter=dWC

[DLG:IDD_PROPPAGE_PORT (English (U.S.))]
Type=1
Class=CPropPortPage
ControlCount=1
Control1=IDC_LIST_PORT,SysListView32,1350631425

[CLS:CDaoHostSet]
Type=0
HeaderFile=DaoHostSet.h
ImplementationFile=DaoHostSet.cpp
BaseClass=CDaoRecordset
Filter=N
VirtualFilter=x
LastObject=CDaoHostSet

[DLG:IDD_PROPPAGE_HOST (English (U.S.))]
Type=1
Class=CPropHostPage
ControlCount=29
Control1=IDC_STATIC_GENERAL,static,1342308352
Control2=IDC_STATIC,static,1342308352
Control3=IDC_IPADDRESS_HOST,SysIPAddress32,1476460544
Control4=IDC_STATIC,static,1342308352
Control5=IDC_EDIT_HOSTNAME,edit,1350633600
Control6=IDC_STATIC,static,1342308352
Control7=IDC_EDIT_TYPE,edit,1350633600
Control8=IDC_STATIC,static,1342308352
Control9=IDC_EDIT_OS,edit,1352730692
Control10=IDC_STATIC,static,1342308352
Control11=IDC_EDIT_OPENTIME,edit,1350633600
Control12=IDC_STATIC,static,1342308352
Control13=IDC_EDIT_CLOSETIME,edit,1350633600
Control14=IDC_STATIC_SECURITY,static,1342308352
Control15=IDC_STATIC,static,1342308352
Control16=IDC_EDIT_PASSWORDMINLENGTH,edit,1350633600
Control17=IDC_STATIC,static,1342308352
Control18=IDC_EDIT_PASSWORDMINAGE,edit,1350633600
Control19=IDC_STATIC,static,1342308352
Control20=IDC_EDIT_PASSWORDMAXAGE,edit,1350633600
Control21=IDC_STATIC,static,1342308352
Control22=IDC_EDIT_LOCKOUTDURATION,edit,1350633600
Control23=IDC_STATIC,static,1342308352
Control24=IDC_EDIT_LOCKOUTRESET,edit,1350633600
Control25=IDC_STATIC,static,1342308352
Control26=IDC_EDIT_LOCKOUTTHRESHOLD,edit,1350633600
Control27=IDC_STATIC_MAC,static,1342308352
Control28=IDC_LIST_MAC,SysListView32,1350631425
Control29=IDC_STATIC,static,1342177294

[DLG:IDD_PROPPAGE_GROUP (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_LIST1,SysListView32,1350631424

[DLG:IDD_PROPPAGE_SHARE (English (U.S.))]
Type=1
Class=CPropSharePage
ControlCount=1
Control1=IDC_LIST_SHARE,SysListView32,1350631425

[DLG:IDD_PROPPAGE_SNMP (English (U.S.))]
Type=1
Class=CPropSnmpPage
ControlCount=2
Control1=IDC_EDIT_VALUE,edit,1352730692
Control2=IDC_TREE_MIB,SysTreeView32,1350631424

[DLG:IDD_PROPPAGE_USERANDGROUP (English (U.S.))]
Type=1
Class=CPropUserAndGroupPage
ControlCount=4
Control1=IDC_LIST_GROUP,SysListView32,1350631425
Control2=IDC_LIST_USER,SysListView32,1350631425
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352

[CLS:CPropHostPage]
Type=0
HeaderFile=PropHostPage.h
ImplementationFile=PropHostPage.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CPropHostPage
VirtualFilter=idWC

[CLS:CPropPortPage]
Type=0
HeaderFile=PropPortPage.h
ImplementationFile=PropPortPage.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CPropPortPage
VirtualFilter=idWC

[CLS:CPropSharePage]
Type=0
HeaderFile=PropSharePage.h
ImplementationFile=PropSharePage.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CPropSharePage
VirtualFilter=idWC

[CLS:CPropSnmpPage]
Type=0
HeaderFile=PropSnmpPage.h
ImplementationFile=PropSnmpPage.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CPropSnmpPage
VirtualFilter=idWC

[CLS:CPropUserAndGroupPage]
Type=0
HeaderFile=PropUserAndGroupPage.h
ImplementationFile=PropUserAndGroupPage.cpp
BaseClass=CPropertyPage
Filter=D
LastObject=CPropUserAndGroupPage
VirtualFilter=idWC

[CLS:CPropHostSheet]
Type=0
HeaderFile=PropHostSheet.h
ImplementationFile=PropHostSheet.cpp
BaseClass=CPropertySheet
Filter=W
LastObject=CPropHostSheet

[CLS:CMrtgDlg]
Type=0
HeaderFile=MrtgDlg.h
ImplementationFile=MrtgDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_BUTTON_PRINT
VirtualFilter=dWC

[DLG:IDD_DIALOG_SET_AUTO_REFRESH]
Type=1
Class=CSetAutoRefreshDlg
ControlCount=13
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,static,1342308352
Control3=IDC_EDIT_HOUR,edit,1350631552
Control4=IDC_SPIN_HOUR,msctls_updown32,1342177446
Control5=IDC_STATIC,static,1342308352
Control6=IDC_EDIT_MINUTE,edit,1350631552
Control7=IDC_SPIN_MINUTE,msctls_updown32,1342177318
Control8=IDC_STATIC,static,1342308352
Control9=IDC_EDIT_SECOND,edit,1350631552
Control10=IDC_SPIN_SECOND,msctls_updown32,1342177318
Control11=IDC_CHECK_NOTAUTOREFRESH,button,1342242819
Control12=IDOK,button,1342242817
Control13=IDCANCEL,button,1342242816

[CLS:CSetAutoRefreshDlg]
Type=0
HeaderFile=SetAutoRefreshDlg.h
ImplementationFile=SetAutoRefreshDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=ID_APP_EXIT
VirtualFilter=dWC

[DLG:IDD_DIALOG_TOOL]
Type=1
Class=CToolDlg
ControlCount=10
Control1=IDOK,button,1342242817
Control2=IDC_BUTTON_START,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_IPADDRESS_TOOL,SysIPAddress32,1342242816
Control7=IDC_EDIT_PARAMETER,edit,1350631552
Control8=IDC_EDIT_RESULT,edit,1352730692
Control9=IDC_STATIC,static,1342308352
Control10=IDC_COMBO_TOOLNAME,combobox,1344340227

[CLS:CToolDlg]
Type=0
HeaderFile=ToolDlg.h
ImplementationFile=ToolDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CToolDlg
VirtualFilter=dWC

[DLG:IDD_DIALOG_ADD_TOOL]
Type=1
Class=CAddToolDlg
ControlCount=12
Control1=IDC_STATIC,static,1342308352
Control2=IDC_EDIT_TOOLNAME,edit,1350631552
Control3=IDC_STATIC,static,1342308352
Control4=IDC_EDIT_TOOLPATH,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=IDC_EDIT_ARGUMENTS,edit,1350631552
Control7=IDC_LIST_TOOL,SysListView32,1350631425
Control8=IDC_BUTTON_ADDTOOL,button,1342242816
Control9=IDC_BUTTON_REMOVETOOL,button,1342242816
Control10=IDOK,button,1342242817
Control11=IDCANCEL,button,1342242816
Control12=IDC_BUTTON_BROWSE,button,1342242816

[CLS:CAddToolDlg]
Type=0
HeaderFile=AddToolDlg.h
ImplementationFile=AddToolDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CAddToolDlg
VirtualFilter=dWC

[DLG:IDD_DIALOG_REPORT]
Type=1
Class=CReportDlg
ControlCount=1
Control1=IDC_EDIT_REPORT,edit,1353777220

[CLS:CReportDlg]
Type=0
HeaderFile=ReportDlg.h
ImplementationFile=ReportDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CReportDlg
VirtualFilter=dWC

[MNU:IDR_MENU_REPORT]
Type=1
Class=?
Command1=ID_REPORTFILE_SAVE_AS
Command2=ID_REPORTFILE_PRINT
Command3=ID_REPORTFILE_CLOSE
Command4=ID_REPORTEDIT_COPY
Command5=ID_REPORTEDIT_SELECT_ALL
CommandCount=5

[DLG:IDD_DIALOG_HELP]
Type=1
Class=CHelpDlg
ControlCount=17
Control1=IDOK,button,1342242817
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342177294
Control5=IDC_STATIC,static,1342177294
Control6=IDC_STATIC,button,1342177287
Control7=IDC_STATIC,button,1342177287
Control8=IDC_STATIC,static,1342177294
Control9=IDC_STATIC,static,1342177294
Control10=IDC_STATIC,static,1342177294
Control11=IDC_STATIC,static,1342177294
Control12=IDC_STATIC,static,1342177294
Control13=IDC_STATIC,static,1342308352
Control14=IDC_STATIC,static,1342308352
Control15=IDC_STATIC,static,1342308352
Control16=IDC_STATIC,static,1342308352
Control17=IDC_STATIC,static,1342308352

[CLS:CHelpDlg]
Type=0
HeaderFile=HelpDlg.h
ImplementationFile=HelpDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CHelpDlg

