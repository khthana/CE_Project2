// PropSharePage.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropSharePage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropSharePage property page

IMPLEMENT_DYNCREATE(CPropSharePage, CPropertyPage)

CPropSharePage::CPropSharePage() : CPropertyPage(CPropSharePage::IDD)
{
	//{{AFX_DATA_INIT(CPropSharePage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropSharePage::~CPropSharePage()
{
}

void CPropSharePage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropSharePage)
	DDX_Control(pDX, IDC_LIST_SHARE, m_ctlListShare);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropSharePage, CPropertyPage)
	//{{AFX_MSG_MAP(CPropSharePage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropSharePage message handlers

BOOL CPropSharePage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	LV_COLUMN lvColumn;
	LV_ITEM lvItem;
	int i;

	int iShareSize;
	CShare *pShare;

	CString strShareName;
	CString strShareComment;
	CString strShareType;
	char *cShareName;
	char *cShareComment;
	char *cShareType;

	//-----------------------------------------------------
	// Insert Column to List Control
	//	Share Name | Share Type | Share Comment | 
	//	Access Read | Access Write | Access Create | Access Execute |
	//  Access Delete | Access Attributes | Access Permissions | Access All
	//-----------------------------------------------------
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;

	lvColumn.pszText = "Share Name";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 130; 
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListShare.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Share Type";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 170;
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListShare.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Share Comment";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 250;
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListShare.InsertColumn( 2, &lvColumn );

	lvColumn.pszText = "Access Read";
	lvColumn.iSubItem = 3;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 3, &lvColumn );

	lvColumn.pszText = "Access Write";
	lvColumn.iSubItem = 4;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 4, &lvColumn );

	lvColumn.pszText = "Access Create";
	lvColumn.iSubItem = 5;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 5, &lvColumn );

	lvColumn.pszText = "Access Execute";
	lvColumn.iSubItem = 6;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 6, &lvColumn );

	lvColumn.pszText = "Access Delete";
	lvColumn.iSubItem = 7;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 7, &lvColumn );

	lvColumn.pszText = "Access Attributes";
	lvColumn.iSubItem = 8;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 8, &lvColumn );

	lvColumn.pszText = "Access Permissions";
	lvColumn.iSubItem = 9;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 9, &lvColumn );

	lvColumn.pszText = "Access All";
	lvColumn.iSubItem = 10;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListShare.InsertColumn( 10, &lvColumn );
	//-----------------------------------------------------
	// Insert Column to List Control
	//	Share Name | Share Type | Share Comment | 
	//	Access Read | Access Write | Access Create | Access Execute |
	//  Access Delete | Access Attributes | Access Permissions | Access All
	//-----------------------------------------------------

	//------------------------------------------------------------
	// Set value to column
	//  My Movie  |  ..... | ..... | YES | .....
	//	Share Pic |  ..... | ..... |  NO | .....
	//------------------------------------------------------------
	iShareSize = this->m_saShares.GetSize( );
	for ( i=0; i<iShareSize; i++ ) {
		pShare = m_saShares.ElementAt( i );
		
		strShareName	= pShare->GetShareName( );
		strShareType	= pShare->GetShareType( );
		strShareComment	= pShare->GetShareComment( );
		cShareName		= strShareName.GetBuffer( 255 );
		cShareType		= strShareType.GetBuffer( 50 ); 
		cShareComment	= strShareComment.GetBuffer( 255 );
	
		// set in row in list
		lvItem.mask		= LVIF_TEXT;

		lvItem.iItem	= i;
		lvItem.iSubItem = 0;
		lvItem.pszText	= cShareName;
		m_ctlListShare.InsertItem( &lvItem );

		lvItem.iSubItem = 1;
		lvItem.pszText	= cShareType;
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 2;
		lvItem.pszText	= cShareComment;
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 3;
		if ( pShare->IsAccessRead( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 4;
		if ( pShare->IsAccessWrite( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 5;
		if ( pShare->IsAccessCreate( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 6;
		if ( pShare->IsAccessExec( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 7;
		if ( pShare->IsAccessDelete( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 8;
		if ( pShare->IsAccessAtrib( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 9;
		if ( pShare->IsAccessPerm( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );

		lvItem.iSubItem = 10;
		if ( pShare->IsAccessAll( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListShare.SetItem( &lvItem );
	}
	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------

	//-----------------------------------------------------
	//  Set share data
	//-----------------------------------------------------

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
