#if !defined(AFX_PROPPORTPAGE_H__3D39D2DC_C4FA_4961_8B14_18BC9C4A8958__INCLUDED_)
#define AFX_PROPPORTPAGE_H__3D39D2DC_C4FA_4961_8B14_18BC9C4A8958__INCLUDED_

#include "TypePortArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPortPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPortPage dialog

class CPropPortPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPortPage)

// Construction
public:
	CPortArray m_paPorts;
	CPropPortPage();
	~CPropPortPage();

// Dialog Data
	//{{AFX_DATA(CPropPortPage)
	enum { IDD = IDD_PROPPAGE_PORT };
	CListCtrl	m_ctlListPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPortPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPortPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPORTPAGE_H__3D39D2DC_C4FA_4961_8B14_18BC9C4A8958__INCLUDED_)
