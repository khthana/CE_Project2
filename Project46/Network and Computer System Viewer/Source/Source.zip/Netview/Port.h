// Port.h: interface for the CPort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORT_H__68C65399_5F43_4D8B_BAE8_2EB192642A89__INCLUDED_)
#define AFX_PORT_H__68C65399_5F43_4D8B_BAE8_2EB192642A89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPort  
{
public:
	BOOL IsWantDetect( );
	BOOL IsTrojan( );
	CString GetStatus( );
	CString GetPortName( );
	void SetPortStatus( CString strStatus );
	CPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect, CString strStatus);
	CString GetProtocol( );
	long GetPortNumber( );
	void GetPortData(long *pPortNumber, CString *pProtocol, CString *pPortName, BOOL *pTrojan, BOOL *pWantDetect);
	CPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect);
	void SetPortData( long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect );
	virtual ~CPort();
private:
	CString m_strStatus;
	long	m_lPortNumber;
	CString	m_strProtocol;
	CString	m_strPortName;
	BOOL	m_bTrojan;
	BOOL	m_bWantDetect;
};

#endif // !defined(AFX_PORT_H__68C65399_5F43_4D8B_BAE8_2EB192642A89__INCLUDED_)
