// User.cpp: implementation of the CUser class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "User.h"

////////////////////////// 
// MY HEADER START HERE
//////////////////////////
#include "DaoUserSet.h"
////////////////////////// 
// MY HEADER END HERE
//////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUser::CUser( CString strUserName, CString strComment, CString strFullName, BOOL bAccountEnable, BOOL bPasswordReq, BOOL bPasswordCanChange, BOOL bPasswordNotExpire )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->m_strUserName = strUserName;
	this->m_strComment	= strComment;
	this->m_strFullName	= strFullName;
	this->m_bAccountEnable		= bAccountEnable;
	this->m_bPasswordReq		= bPasswordReq;
	this->m_bPasswordCanChange	= bPasswordCanChange;
	this->m_bPasswordNotExpire	= bPasswordNotExpire;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CUser::~CUser()
{

}

CString CUser::GetUserName()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strUserName;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CUser::GetComment()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strComment;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CUser::GetFullName()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strFullName;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CUser::IsAccountEnable()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bAccountEnable;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CUser::IsPasswordReq()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bPasswordReq;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CUser::IsPasswordCanChange()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bPasswordCanChange;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CUser::IsPasswordNotExpire()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bPasswordNotExpire;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//					Table >> User
//	Parameter	: strIP(IN)	>>	Host IP Address 's owner
void CUser::StoreDB(CString strIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	//-------------------------------------------------------
	//  Store in table User
	//-------------------------------------------------------
	CString strSQL;
	CDaoUserSet daoUserSet;

	// data
	long lRowCount;
	CString	strUserName;
	CString	strUserComment;
	CString	strFullName;
	BOOL	bAccountEnable;
	BOOL	bPWRequired;
	BOOL	bPWCanChange;
	BOOL	bPWNotExpire;

	// set data
	strUserName		= this->m_strUserName;
	strUserComment	= this->m_strComment;
	strFullName		= this->m_strFullName;
	bAccountEnable	= this->m_bAccountEnable;
	bPWRequired		= this->m_bPasswordReq;
	bPWCanChange	= this->m_bPasswordCanChange;
	bPWNotExpire	= this->m_bPasswordNotExpire;

	// create SQL statement
	strSQL =  "SELECT IP, UserName, UserComment, FullName, ";
	strSQL += "AccountEnable, PWRequired, PWCanChange, PWNotExpire ";
	strSQL += "FROM User WHERE IP='";
	strSQL += strIP;
	strSQL += "' AND UserName='";
	strSQL += strUserName;
	strSQL += "'";

	// open database
	if ( daoUserSet.IsOpen( ) ) 
		daoUserSet.Close( );
	daoUserSet.Open( dbOpenDynaset, _T( strSQL ) );
	lRowCount = daoUserSet.GetRecordCount( );

	// if row is not exist (lRowCount==0) then INSERT it
	if ( lRowCount == 0 ) {
		// Insert
		daoUserSet.AddNew( );

		daoUserSet.m_IP				= strIP;
		daoUserSet.m_UserName		= strUserName;
		daoUserSet.m_UserComment	= strUserComment;
		daoUserSet.m_FullName		= strFullName;
		daoUserSet.m_AccountEnable	= bAccountEnable;
		daoUserSet.m_PWRequired		= bPWRequired;
		daoUserSet.m_PWCanChange	= bPWCanChange;
		daoUserSet.m_PWNotExpire	= bPWNotExpire;

		daoUserSet.Update( );
	}
	// if row is exist (lRowCount>0) then UPDATE it
	else {
		// Update
		daoUserSet.MoveFirst( );
		daoUserSet.Edit( );

		daoUserSet.m_UserComment	= strUserComment;
		daoUserSet.m_FullName		= strFullName;
		daoUserSet.m_AccountEnable	= bAccountEnable;
		daoUserSet.m_PWRequired		= bPWRequired;
		daoUserSet.m_PWCanChange	= bPWCanChange;
		daoUserSet.m_PWNotExpire	= bPWNotExpire;

		daoUserSet.Update( );
	}

	daoUserSet.Close( );
	//-------------------------------------------------------
	//  Store in table User
	//-------------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
