#if !defined(AFX_DAOSHARESET_H__F9877388_A1C0_40D3_97D6_3D54763A404E__INCLUDED_)
#define AFX_DAOSHARESET_H__F9877388_A1C0_40D3_97D6_3D54763A404E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoShareSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoShareSet DAO recordset

class CDaoShareSet : public CDaoRecordset
{
public:
	CDaoShareSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoShareSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoShareSet, CDaoRecordset)
	CString	m_IP;
	CString	m_ShareName;
	CString	m_ShareComment;
	CString	m_ShareType;
	BOOL	m_AccessRead;
	BOOL	m_AccessWrite;
	BOOL	m_AccessCreate;
	BOOL	m_AccessExec;
	BOOL	m_AccessDelete;
	BOOL	m_AccessAtrib;
	BOOL	m_AccessPerm;
	BOOL	m_AccessAll;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoShareSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOSHARESET_H__F9877388_A1C0_40D3_97D6_3D54763A404E__INCLUDED_)
