// NetviewView.h : interface of the CNetviewView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETVIEWVIEW_H__13738ECE_8B96_402D_9AFF_A505EA575554__INCLUDED_)
#define AFX_NETVIEWVIEW_H__13738ECE_8B96_402D_9AFF_A505EA575554__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNetviewView : public CScrollView
{
protected: // create from serialization only
	CNetviewView();
	DECLARE_DYNCREATE(CNetviewView)

// Attributes
public:
	CNetviewDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetviewView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNetviewView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	void SetViewSize( );
	void SetBorderRect(CRect &rectBorder, CRect &rect, int iExp);
	//{{AFX_MSG(CNetviewView)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in NetviewView.cpp
inline CNetviewDoc* CNetviewView::GetDocument()
   { return (CNetviewDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETVIEWVIEW_H__13738ECE_8B96_402D_9AFF_A505EA575554__INCLUDED_)
