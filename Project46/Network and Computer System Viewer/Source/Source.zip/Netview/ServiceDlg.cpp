// ServiceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "ServiceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServiceDlg dialog


CServiceDlg::CServiceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServiceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServiceDlg)
	m_bTrojanPort = FALSE;
	m_strEndPort = _T("");
	m_strStartPort = _T("");
	m_strPortBanner = _T("");
	m_iCatagory = -1;
	m_iProtocal = -1;
	//}}AFX_DATA_INIT
}


void CServiceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServiceDlg)
	DDX_Check(pDX, IDC_CHECK_TROJANPORT, m_bTrojanPort);
	DDX_Text(pDX, IDC_EDIT_ENDPORT, m_strEndPort);
	DDV_MaxChars(pDX, m_strEndPort, 5);
	DDX_Text(pDX, IDC_EDIT_STARTPORT, m_strStartPort);
	DDV_MaxChars(pDX, m_strStartPort, 5);
	DDX_Text(pDX, IDC_EDIT_PORTBANNER, m_strPortBanner);
	DDV_MaxChars(pDX, m_strPortBanner, 255);
	DDX_Radio(pDX, IDC_RADIO_SINGLEPORT, m_iCatagory);
	DDX_Radio(pDX, IDC_RADIO_TCPPORT, m_iProtocal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CServiceDlg, CDialog)
	//{{AFX_MSG_MAP(CServiceDlg)
	ON_BN_CLICKED(IDC_RADIO_SINGLEPORT, OnRadioSingleport)
	ON_BN_CLICKED(IDC_RADIO_RANGEPORT, OnRadioRangeport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServiceDlg message handlers
BOOL CServiceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_iCatagory = 0;
	m_iProtocal = 0;
	UpdateData( FALSE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CServiceDlg::OnRadioSingleport() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CEdit *ctlEndPort = (CEdit*)GetDlgItem( IDC_EDIT_ENDPORT );
	ctlEndPort->EnableWindow( FALSE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CServiceDlg::OnRadioRangeport() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CEdit *ctlEndPort = (CEdit*)GetDlgItem( IDC_EDIT_ENDPORT );
	ctlEndPort->EnableWindow( TRUE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
void CServiceDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strTemp;
	char *cStartPort, *cEndPort;
	int iStartPort, iEndPort;
	UpdateData( TRUE );

	//------------------
	// single port
	//------------------
	if ( m_iCatagory == 0 ) {		

		// check empty input port
		if ( m_strStartPort.IsEmpty( ) ) {
			MessageBox( "Please enter port number.", "Miss Port", MB_ICONERROR );
			return;
		}

		// check port range (1-65535) and non number error correcting
		cStartPort	= m_strStartPort.GetBuffer( 5 );
		iStartPort	= atoi( cStartPort );
		if (  (iStartPort<1) || (iStartPort>65535) ) {
			MessageBox( "Port error out of range 1-65535.", 
						"Port Range Error", MB_ICONERROR );
			return;
		}
		m_strStartPort.Format( "%i", iStartPort );
		UpdateData( FALSE );
	}
	//------------------
	// range port
	//------------------
	else if ( m_iCatagory == 1 ) {	

		// check empty input port
		if ( m_strStartPort.IsEmpty( ) || m_strEndPort.IsEmpty( ) ) {
			MessageBox( "Please enter start and end port number.", 
						"Miss Port", MB_ICONERROR );
			return;
		}

		// check port range (1-65535) and non number error correcting
		cStartPort	= m_strStartPort.GetBuffer( 5 );
		cEndPort	= m_strEndPort.GetBuffer( 5 );
		iStartPort	= atoi( cStartPort );
		iEndPort	= atoi( cEndPort );
		if ( (iStartPort<1)		||
			 (iStartPort>65535) || 
			 (iEndPort<1)		|| 
			 (iEndPort>65535) ) {
			MessageBox( "Port error out of range 1-65535.", 
						"Port Range Error", MB_ICONERROR );
			return;
		}
		m_strStartPort.Format( "%i", iStartPort );
		m_strEndPort.Format( "%i", iEndPort );
		UpdateData( FALSE );

		// normalize port sequence (swap)
		UpdateData( TRUE );
		if ( m_strStartPort > m_strEndPort ) {
			strTemp			= m_strStartPort;
			m_strStartPort	= m_strEndPort;
			m_strEndPort	= strTemp;
			UpdateData( FALSE );
		}
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	CDialog::OnOK();
}
