// Network.cpp: implementation of the CNetwork class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Network.h"

///////////////////////////
// MY INCLUDE START HERE 
///////////////////////////
#include "DaoNetworkSet.h"
#include "DaoInNetworkSet.h"
#include "DaoAgentSet.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetwork::CNetwork(CString strNetworkAddress, CString strNetmask)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->m_strNetworkAddress	= strNetworkAddress;
	this->m_strNetmask			= strNetmask;
	this->m_timeConnect.SetDateTime( 1900, 1, 1, 0, 0, 0 );
	this->m_timeDisconnect.SetDateTime( 1900, 1, 1, 0, 0, 0 );

	this->m_bConnect = FALSE;
	this->m_pBitmap = &m_bmpDisconnect;
	this->m_bmpConnect.LoadBitmap( IDB_BITMAP_NETWORK_CONNECT );
	this->m_bmpDisconnect.LoadBitmap( IDB_BITMAP_NETWORK_DISCONNECT );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CNetwork::~CNetwork()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, iCount;
	iCount = m_haHosts.GetSize( );
	if ( iCount ) { 
		// Loop through the array, deleteing each object
		for ( i=0; i<iCount; i++ ) 
			delete m_haHosts[i];
		m_haHosts.RemoveAll( ); // Reset the array
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CNetwork::GetNetworkAddress()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return this->m_strNetworkAddress;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CNetwork::GetNetmask()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return this->m_strNetmask;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CStringArray* CNetwork::GetAgentIP()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_saAgentIPs;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Host in Network
//	Parameter	: strIP(IN)	>>	Host's IP Address
//
void CNetwork::AddHost(CString strIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CHost Object (TRUE=Host up)
	CHost *pHost = new CHost( strIP, TRUE );

	try {
		// Add new Host to Host Array
		m_haHosts.Add( pHost );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CHost Object delete it
		if ( pHost ) {
			delete pHost;
			pHost = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CRectTracker* CNetwork::GetPosition()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_rtPosition;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CNetwork::SetCommand(CString strCommand)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_strCommand = strCommand;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CNetwork::GetCommand()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strCommand;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString* CNetwork::GetResult()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_strResult;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CHostArray* CNetwork::GetHostArray()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return &m_haHosts;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Host in Network by IP Address
//	Parameter	: strIP(IN)	>>	Host's IP Address
//	Return		: int		>>	-1=Not Found, 0...n=Found and return position
//
int CNetwork::FindHost(CString strIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	int i, iSize;
	int iFound = -1;

	iSize = m_haHosts.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		// Match IP Address
		if ( strIP == m_haHosts[i]->GetIP( ) ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add agent IP in Network
//	Parameter	: strAgentIP(IN)	>>	Agent IP 
//
void CNetwork::AddAgentIP(CString strAgentIP)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_saAgentIPs.Add( strAgentIP );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CString CNetwork::GetIPRange()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strIPRange;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}	

void CNetwork::SetIPRange(CString strIPRange)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_strIPRange = strIPRange;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CNetwork::IsConnect()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bConnect;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CBitmap* CNetwork::GetBitmap()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_pBitmap;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set network status Connect OR Disconnect
//	
void CNetwork::SetNetworkStatus( BOOL bConnect )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	// Network come back connect up
	if ( (m_bConnect==FALSE) && (bConnect==TRUE) ) {
		m_pBitmap = &m_bmpConnect;
		m_timeConnect = COleDateTime::GetCurrentTime( );
	}
	// Network come back disconnect down
	else if ( (m_bConnect==TRUE) && (bConnect==FALSE) ) {
		m_pBitmap = &m_bmpDisconnect;
		m_timeDisconnect = COleDateTime::GetCurrentTime( );
	}
	m_bConnect = bConnect;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : This network can show SNMP
//	
CHost* CNetwork::IsShowSnmp( )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CHost *pHost = NULL;
	CHost *pHostSnmp = NULL;
	int iSizeAgentIP = m_saAgentIPs.GetSize( );
	int i, iIndex;
	CString strIP;

	// find host open and open snmp on it if it support
	for ( i=0; i<iSizeAgentIP; i++ ) {
		strIP = m_saAgentIPs.ElementAt( i );
		iIndex = FindHost( strIP );
		if ( iIndex != -1 ) {
			pHost	= m_haHosts.ElementAt( iIndex );
			
			// Open and support SNMP
			if ( pHost->IsStatus( ) && pHost->IsSnmp( ) ) {
				pHostSnmp = pHost;
				break;
			}
		}
	}

	return pHostSnmp;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : This network can show Traffic
//
CHost* CNetwork::IsShowTraffic( )
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CHost *pHost = NULL;
	CHost *pHostTraffic = NULL;
	int iSizeAgentIP = m_saAgentIPs.GetSize( );
	int i, iIndex;
	CString strIP;

	// find host open and open snmp on it if it support
	for ( i=0; i<iSizeAgentIP; i++ ) {
		strIP = m_saAgentIPs.ElementAt( i );
		iIndex = FindHost( strIP );
		if ( iIndex != -1 ) {
			pHost	= m_haHosts.ElementAt( iIndex );
			
			// Open and support SNMP
			if ( pHost->IsStatus( ) && pHost->IsSnmp( ) ) {
				pHostTraffic = pHost;
				break;
			}
		}
	}

	return pHostTraffic;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Test Network is local or not.
//	Return		: BOOL >> TRUE=Local Network, FALSE=Remote Network
//
BOOL CNetwork::IsLocalNetwork()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bLocalNetwork;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CNetwork::SetLocalNetwork(BOOL bLocalNetwork)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_bLocalNetwork = bLocalNetwork;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//					Table >> Network, InNetwork, Agent
//	
void CNetwork::StoreDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	//---------------------------------------------------------------------
	//  Store in table Network
	//---------------------------------------------------------------------
	this->StoreNetworkDB( );
	//---------------------------------------------------------------------
	//  Store in table Network
	//---------------------------------------------------------------------	

	//-------------------------------------------------------
	//  Store in table InNetwork
	//-------------------------------------------------------
	this->StoreInNetworkDB( );
	//-------------------------------------------------------
	//  Store in table InNetwork
	//-------------------------------------------------------

	//---------------------------------------------------------------
	//  Store in table Agent
	//---------------------------------------------------------------
	this->StoreAgentDB( );
	//---------------------------------------------------------------
	//  Store in table Agent
	//---------------------------------------------------------------

	//-------------------------------
	//  Store for each host
	//-------------------------------
	CHost *pHost;
	int i, iSizeHost;

	iSizeHost = m_haHosts.GetSize( );
	for ( i=0; i<iSizeHost; i++ ) {
		pHost = m_haHosts.ElementAt( i );
		pHost->StoreDB( );
	}
	//-------------------------------
	//  Store for each host
	//-------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table Network
//	
void CNetwork::StoreNetworkDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	//---------------------------------------------------------------------
	//  Store in table Network
	//---------------------------------------------------------------------
	CString strSQL;
	CDaoNetworkSet daoNetworkSet;

	// data
	long lRowCount;
	CString strNetworkAddress;
	CString strNetmask;
	COleDateTime tConnectTime;
	COleDateTime tConnectDate;
	COleDateTime tDisconnectTime;
	COleDateTime tDisconnectDate;

	// set data
	strNetworkAddress = this->m_strNetworkAddress;
	strNetmask		  = this->m_strNetmask;
	tConnectTime.SetTime( this->m_timeConnect.GetHour( ), 
						  this->m_timeConnect.GetMinute( ),
						  this->m_timeConnect.GetSecond( ) );
	tConnectDate.SetDate( this->m_timeConnect.GetYear( ),
						  this->m_timeConnect.GetMonth( ),
						  this->m_timeConnect.GetDay( ) );
	tDisconnectTime.SetTime( this->m_timeDisconnect.GetHour( ),
							 this->m_timeDisconnect.GetMinute( ),
							 this->m_timeDisconnect.GetSecond( ) );
	tDisconnectDate.SetDate( this->m_timeDisconnect.GetYear( ),
							 this->m_timeDisconnect.GetMonth( ),
							 this->m_timeDisconnect.GetDay( ) );

	// create SQL statement
	strSQL =  "SELECT NetworkAddress, Netmask, ";
	strSQL += "ConnectTime, ConnectDate, DisconnectTime, DisconnectDate ";
	strSQL += "FROM Network WHERE NetworkAddress='";
	strSQL += strNetworkAddress;
	strSQL += "'";

	// open database
	if ( daoNetworkSet.IsOpen( ) )
		daoNetworkSet.Close( );
	daoNetworkSet.Open( dbOpenDynaset, _T( strSQL ) );
	lRowCount = daoNetworkSet.GetRecordCount( );

	// if row is not exist (lRowCount==0) then INSERT it
	if ( lRowCount == 0 ) {
		// Insert
		daoNetworkSet.AddNew( );
		daoNetworkSet.m_NetworkAddress	= strNetworkAddress;
		daoNetworkSet.m_Netmask			= strNetmask;
		daoNetworkSet.m_ConnectTime		= tConnectTime;
		daoNetworkSet.m_ConnectDate		= tConnectDate;
		daoNetworkSet.m_DisconnectTime	= tDisconnectTime;
		daoNetworkSet.m_DisconnectDate	= tDisconnectDate;
		daoNetworkSet.Update( );
	}
	// if row is exist (lRowCount>0) then UPDATE it
	else {
		// Update
		daoNetworkSet.MoveFirst( );
		daoNetworkSet.Edit( );
		daoNetworkSet.m_Netmask			= strNetmask;
		daoNetworkSet.m_ConnectTime		= tConnectTime;
		daoNetworkSet.m_ConnectDate		= tConnectDate;
		daoNetworkSet.m_DisconnectTime	= tDisconnectTime;
		daoNetworkSet.m_DisconnectDate	= tDisconnectDate;
		daoNetworkSet.Update( );
	}

	daoNetworkSet.Close( );
	//---------------------------------------------------------------------
	//  Store in table Network
	//---------------------------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table InNetwork
//
void CNetwork::StoreInNetworkDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	//---------------------------------------------------------------------
	//  Store in table InNetwork
	//---------------------------------------------------------------------
	CHost *pHost;
	int i, iSizeHost;
	CString strSQL;
	CDaoInNetworkSet daoInNetworkSet;

	// data
	long lRowCount;
	CString strIP;
	CString strNetworkAddress;
	
	strNetworkAddress = this->m_strNetworkAddress;
	iSizeHost = m_haHosts.GetSize( );
	for ( i=0; i<iSizeHost; i++ ) {
		pHost = m_haHosts.ElementAt( i );
		strIP = pHost->GetIP( );

		// create SQL statement
		strSQL =  "SELECT IP, NetworkAddress FROM InNetwork WHERE IP='";
		strSQL += strIP;
		strSQL += "' AND NetworkAddress='";
		strSQL += strNetworkAddress;
		strSQL += "'";
		
		// open database
		if ( daoInNetworkSet.IsOpen( ) ) 
			daoInNetworkSet.Close( );
		daoInNetworkSet.Open( dbOpenDynaset, _T( strSQL ) );
		lRowCount = daoInNetworkSet.GetRecordCount( );

		// if row is not exist (lRowCount==0) then INSERT it
		if ( lRowCount == 0 ) {
			// Insert
			daoInNetworkSet.AddNew( );
			daoInNetworkSet.m_IP = strIP;
			daoInNetworkSet.m_NetworkAddress = strNetworkAddress;
			daoInNetworkSet.Update( );
		}

		daoInNetworkSet.Close( );
	}
	//---------------------------------------------------------------------
	//  Store in table InNetwork
	//---------------------------------------------------------------------
	
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table Agent
//
void CNetwork::StoreAgentDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	//---------------------------------------------------------------
	//  Store in table Agent
	//---------------------------------------------------------------
	int i, iSizeAgentIP;
	CString strSQL;
	CDaoAgentSet daoAgentSet;

	// data
	long lRowCount;
	CString strNetworkAddress;
	CString strAgentIP;

	strNetworkAddress = this->m_strNetworkAddress;
	iSizeAgentIP = m_saAgentIPs.GetSize( );
	for ( i=0; i<iSizeAgentIP; i++ ) {
		strAgentIP = m_saAgentIPs[i];
		
		// create SQL statement
		strSQL =  "SELECT NetworkAddress, AgentIP FROM Agent WHERE NetworkAddress='";
		strSQL += strNetworkAddress;
		strSQL += "' AND AgentIP='";
		strSQL += strAgentIP;
		strSQL += "'";

		// open database
		if ( daoAgentSet.IsOpen( ) )
			daoAgentSet.Close( );
		daoAgentSet.Open( dbOpenDynaset, _T( strSQL ) );
		lRowCount = daoAgentSet.GetRecordCount( );

		// if row is not exist (lRowCount==0) then INSERT it
		if ( lRowCount == 0 ) {
			// Insert
			daoAgentSet.AddNew( );
			daoAgentSet.m_NetworkAddress = strNetworkAddress;
			daoAgentSet.m_AgentIP		 = strAgentIP;
			daoAgentSet.Update( );
		}

		daoAgentSet.Close( );
	}
	//---------------------------------------------------------------
	//  Store in table Agent
	//---------------------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}	

COleDateTime CNetwork::GetConnectTime()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_timeConnect;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}	

COleDateTime CNetwork::GetDisconnectTime()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_timeDisconnect;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
