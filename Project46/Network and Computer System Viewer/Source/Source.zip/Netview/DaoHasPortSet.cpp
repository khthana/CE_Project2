// DaoHasPortSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoHasPortSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoHasPortSet

IMPLEMENT_DYNAMIC(CDaoHasPortSet, CDaoRecordset)

CDaoHasPortSet::CDaoHasPortSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoHasPortSet)
	m_IP = _T("");
	m_PortNumber = 0;
	m_Protocol = _T("");
	m_Status = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoHasPortSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoHasPortSet::GetDefaultSQL()
{
	return _T("[HasPort]");
}

void CDaoHasPortSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoHasPortSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Long(pFX, _T("[PortNumber]"), m_PortNumber);
	DFX_Text(pFX, _T("[Protocol]"), m_Protocol);
	DFX_Text(pFX, _T("[Status]"), m_Status);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoHasPortSet diagnostics

#ifdef _DEBUG
void CDaoHasPortSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoHasPortSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
