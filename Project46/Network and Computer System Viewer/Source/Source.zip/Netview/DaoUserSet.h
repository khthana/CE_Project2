#if !defined(AFX_DAOUSERSET_H__AF25E885_1836_4C04_80BB_C3BBE8629FF8__INCLUDED_)
#define AFX_DAOUSERSET_H__AF25E885_1836_4C04_80BB_C3BBE8629FF8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoUserSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoUserSet DAO recordset

class CDaoUserSet : public CDaoRecordset
{
public:
	CDaoUserSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoUserSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoUserSet, CDaoRecordset)
	CString	m_IP;
	CString	m_UserName;
	CString	m_UserComment;
	CString	m_FullName;
	BOOL	m_AccountEnable;
	BOOL	m_PWRequired;
	BOOL	m_PWCanChange;
	BOOL	m_PWNotExpire;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoUserSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOUSERSET_H__AF25E885_1836_4C04_80BB_C3BBE8629FF8__INCLUDED_)
