#if !defined(AFX_DAOHOSTSET_H__2185BD6F_6CD4_4F99_A0AA_46E4561C4F15__INCLUDED_)
#define AFX_DAOHOSTSET_H__2185BD6F_6CD4_4F99_A0AA_46E4561C4F15__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoHostSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoHostSet DAO recordset

class CDaoHostSet : public CDaoRecordset
{
public:
	CDaoHostSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoHostSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoHostSet, CDaoRecordset)
	CString	m_IP;
	CString	m_HostName;
	CString	m_OS;
	CString	m_Type;
	BOOL	m_SNMP;
	COleDateTime	m_OpenTime;
	COleDateTime	m_OpenDate;
	COleDateTime	m_CloseTime;
	COleDateTime	m_CloseDate;
	CString	m_MinLength;
	CString	m_MinAge;
	CString	m_MaxAge;
	CString	m_LockoutDuration;
	CString	m_LockoutReset;
	CString	m_LockoutThreshold;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoHostSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOHOSTSET_H__2185BD6F_6CD4_4F99_A0AA_46E4561C4F15__INCLUDED_)
