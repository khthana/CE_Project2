// PropPortPage.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropPortPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPortPage property page

IMPLEMENT_DYNCREATE(CPropPortPage, CPropertyPage)

CPropPortPage::CPropPortPage() : CPropertyPage(CPropPortPage::IDD)
{
	//{{AFX_DATA_INIT(CPropPortPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropPortPage::~CPropPortPage()
{
}

void CPropPortPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPortPage)
	DDX_Control(pDX, IDC_LIST_PORT, m_ctlListPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPortPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPortPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPortPage message handlers

BOOL CPropPortPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	int i, iPortSize;
	LV_COLUMN lvColumn;
	LV_ITEM lvItem;
	CPort *pPort;

	long lPortNumber;
	CString strProtocol;
	CString strPortName;
	CString strStatus;
	char cPortNumber[5];
	char *cProtocol;
	char *cPortName;
	char *cStatus;

	// create color for show trojan and want detect
	CImageList *imgColor = new CImageList( );
	imgColor->Create( 16, 16, ILC_MASK, 3, 0 );
	imgColor->Add( AfxGetApp( )->LoadIcon( IDI_ICON_LIST_NONE ) );
	imgColor->Add( AfxGetApp( )->LoadIcon( IDI_ICON_LIST_TROJAN ) );
	imgColor->Add( AfxGetApp( )->LoadIcon( IDI_ICON_LIST_WANTDETECT ) );
	m_ctlListPort.SetImageList( imgColor, LVSIL_SMALL );

	//-----------------------------------------------------
	// Insert Column to List Control
	//	Port Number | Protocol | Port Name | Status
	//-----------------------------------------------------
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt = LVCFMT_CENTER;

	lvColumn.pszText = "Port Number";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 80;
	m_ctlListPort.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Protocol";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 70;
	m_ctlListPort.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Port Name";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 290;
	m_ctlListPort.InsertColumn( 2, &lvColumn );

	lvColumn.pszText = "Status";
	lvColumn.iSubItem = 3;
	lvColumn.cx = 80;
	m_ctlListPort.InsertColumn( 3, &lvColumn );
	//-----------------------------------------------------
	// Insert Column to List Control
	//	Port Number | Protocol |   Port Name  | Status
	//-----------------------------------------------------

	//------------------------------------------------------------
	// Set value to column
	//      22      |   tcp    |     ssh      |  open  
	//	   139	    |   tcp	   | netbios-ssn  |  open
	//------------------------------------------------------------
	iPortSize = this->m_paPorts.GetSize( );
	for ( i=0; i<iPortSize; i++ ) {
		pPort = m_paPorts.ElementAt( i );
		
		lPortNumber = pPort->GetPortNumber( );
		strProtocol = pPort->GetProtocol( );
		strPortName = pPort->GetPortName( );
		strStatus	= pPort->GetStatus( );
		_ltoa( lPortNumber, cPortNumber, 10 );
		cProtocol	= strProtocol.GetBuffer( 3 );
		cPortName	= strPortName.GetBuffer( 255 );
		cStatus		= strStatus.GetBuffer( 50 );

		// set in row in list
		lvItem.mask		= LVIF_TEXT | LVIF_IMAGE;
		if ( pPort->IsTrojan( ) ) 
			lvItem.iImage = 1;
		else if ( pPort->IsWantDetect( ) ) 
			lvItem.iImage = 2;
		else 
			lvItem.iImage = 0;
		lvItem.iItem	= i;
		lvItem.iSubItem = 0;
		lvItem.pszText	= cPortNumber;
		m_ctlListPort.InsertItem( &lvItem );
		lvItem.iSubItem = 1;
		lvItem.pszText	= cProtocol;
		m_ctlListPort.SetItem( &lvItem );
		lvItem.iSubItem = 2;
		lvItem.pszText	= cPortName;
		m_ctlListPort.SetItem( &lvItem );
		lvItem.iSubItem = 3;
		lvItem.pszText	= cStatus;
		m_ctlListPort.SetItem( &lvItem );
	}
	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
