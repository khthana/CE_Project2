// Netview.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Netview.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "NetviewDoc.h"
#include "NetviewView.h"

/////////////////////////
// MY INCLUDE START HERE
/////////////////////////
#include "HelpDlg.h"
/////////////////////////
// MY INCLUDE END HERE
/////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetviewApp

BEGIN_MESSAGE_MAP(CNetviewApp, CWinApp)
	//{{AFX_MSG_MAP(CNetviewApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_HELP_NETVIEW_HELP, OnHelpNetviewHelp)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetviewApp construction

CNetviewApp::CNetviewApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CNetviewApp object

CNetviewApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CNetviewApp initialization

BOOL CNetviewApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_NETVIETYPE,
		RUNTIME_CLASS(CNetviewDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CNetviewView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);
	
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////

	// The main window has been initialized, so show and update it.
	m_nCmdShow = SW_SHOWMAXIMIZED; // set show MAXIMIZE
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	// DON'T display a new MDI child window during startup!!!
	//  Because want display a new MDI child window after create 
	//  Main Frame already.
	//cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	m_bWhileExplorer = FALSE; // set not explorer

	//--------------------------------------------
	// Get current Path
	//--------------------------------------------
	TCHAR cStartingDirectory[MAX_PATH];
	::GetCurrentDirectory( MAX_PATH, cStartingDirectory );
	m_strStartingDirectory = cStartingDirectory;
	//--------------------------------------------
	// Get current Path
	//--------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CNetviewApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CNetviewApp message handlers

void CNetviewApp::SetWhileExplorer(BOOL bWhileExplorer)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_bWhileExplorer = bWhileExplorer;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

BOOL CNetviewApp::IsWhileExplorer()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bWhileExplorer;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CNetviewApp::OnHelpNetviewHelp() 
{
	// TODO: Add your command handler code here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CHelpDlg dlgHelp;
	dlgHelp.DoModal( );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
