// Redirect.cpp: implementation of the CRedirect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Redirect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRedirect::CRedirect(LPCTSTR szCommand, CString *pResult, LPCTSTR szCurrentDirectory)
{
	m_szCommand = szCommand;
	m_szCurrentDirectory = szCurrentDirectory;
	m_pResult = pResult;
	m_pResult->Empty( );
}

CRedirect::~CRedirect()
{

}

void CRedirect::Run()
{
	const int BUFF_SIZE = 8192;

	HANDLE				hPipeRead;
	HANDLE				hPipeWrite;
	SECURITY_ATTRIBUTES securityAttr;
	STARTUPINFO			startupInfo;
	PROCESS_INFORMATION processInfo;
	BOOL				bSuccess;

	// Zero the structure (Clear structure)
	ZeroMemory( &securityAttr,	sizeof( securityAttr ) );
	ZeroMemory( &startupInfo,	sizeof( startupInfo ) );
	ZeroMemory( &processInfo,	sizeof( processInfo ) );

	//--------------------------------------------------
	// Create pipe for communication between process
	//--------------------------------------------------
	// set surity attribute
	securityAttr.bInheritHandle			= TRUE;
	securityAttr.lpSecurityDescriptor	= NULL;
	securityAttr.nLength				= sizeof( SECURITY_ATTRIBUTES );

	// create pipe
	bSuccess = CreatePipe( &hPipeRead,		// address of variable for read handle
						   &hPipeWrite,		// address of variable for write handle
						   &securityAttr,	// pointer to security attributes
						   0 );				// number of bytes reserved for pipe (use default size)

	if ( !bSuccess ) { // not success
		m_pResult->Format( "ERROR_CREATE_PIPE" ); 
		return;
	}
	//--------------------------------------------------
	// Create pipe for communication between process
	//--------------------------------------------------

	//-----------------------
	// Create Process
	//-----------------------
	startupInfo.cb			= sizeof( STARTUPINFO );
	// use show window and use stdin, stdout, stderr
	startupInfo.dwFlags		= STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	startupInfo.wShowWindow = SW_HIDE;
	startupInfo.hStdOutput	= hPipeWrite;
	startupInfo.hStdError	= hPipeWrite;

	//create child process
	bSuccess = CreateProcess( 
				NULL,					// pointer to name of executable module
				LPTSTR( m_szCommand ),	// command line
				NULL,					// pointer to process security attributes
				NULL,					// pointer to thread security attributes (use primary thread security attributes)
				TRUE,					// inherit handles
				0,						// creation flags
				NULL,					// pointer to new environment block (use parent's)
				m_szCurrentDirectory,	// pointer to current directory name
				&startupInfo,			// pointer to STARTUPINFO
				&processInfo );			// pointer to PROCESS_INFORMATION

	if ( !bSuccess ) { // not success
		m_pResult->Format( "ERROR_CREATE_PROCESS" );
		return;
	}
	//-----------------------
	// Create Process
	//-----------------------

	//---------------------------------------------------------
	// Read data from pipe 
	//---------------------------------------------------------
	unsigned int i;
	TCHAR bufferPipe[BUFF_SIZE];
	DWORD byteRead;
	DWORD byteTotal = 0;
	DWORD byteRemain = 0;

	// forever loop
	for ( ; ; ) {
		//----------------------------------------
		// Test data have to read (get byteRead)
		//----------------------------------------
		byteRead = 0;

		// copy data from Pipe to Buffer
		bSuccess = PeekNamedPipe( 
					hPipeRead,		// handle to pipe to copy from 
					bufferPipe,		// pointer to data buffer 
					1,				// size, in bytes, of data buffer 
					&byteRead,		// pointer to number of bytes read
					&byteTotal,		// pointer to total number of bytes available
					&byteRemain );	// pointer to unread bytes in this message 

		if ( !bSuccess ) { // not success
			m_pResult->Format( "ERROR_PEEKNAMEDPIPE" );
			break;
		}
		//----------------------------------------
		// Test data have to read (get byteRead)
		//----------------------------------------

		if ( byteRead ) {	
			// have data in pipe to read

			//-------------------------
			// Read data in pipe
			//-------------------------
			bSuccess = ReadFile( 
						hPipeRead,		// handle to pipe to copy from 
						bufferPipe,		// address of buffer that receives data
						BUFF_SIZE - 1,	// number of bytes to read
						&byteRead,		// address of number of bytes read
						NULL );			// address of structure for data for overlapped I/O

			if ( !bSuccess ) { // not success
				m_pResult->Format( "ERROR_READ_PIPE" );
				break;
			}

			bufferPipe[byteRead] = '\0'; // pad last data

			// remove backword (<-)
			for ( i=0; i<byteRead; i++ ) { 
				if ( bufferPipe[i] == _T('\b') ) 
					bufferPipe[i] = ' ';
			}

			this->AppendText( bufferPipe ); // append to return string (m_pResult)
			//-------------------------
			// Read data in pipe
			//-------------------------

			this->PeekAndPump( );
		}
		else {				
			// not have data in pipe to read

			// exit forver loop if wait from child process (exit)
			if ( WaitForSingleObject( processInfo.hProcess, 0 ) == WAIT_OBJECT_0 ) {
				break;
			}

			this->PeekAndPump( );
		}						
	}	
	//---------------------------------------------------------
	// Read data from pipe 
	//---------------------------------------------------------
	
	// close Thread
	bSuccess = CloseHandle( processInfo.hThread );
	if ( !bSuccess ) {
		m_pResult->Format( "ERROR_CLOSE_THREAD" );

	}

	// close Process
	bSuccess = CloseHandle( processInfo.hProcess );
	if ( !bSuccess ) {
		m_pResult->Format( "ERROR_CLOSE_PROCESS" );
	}

	// close PipeRead
	bSuccess = CloseHandle( hPipeRead );
	if ( !bSuccess ) {
		m_pResult->Format( "ERROR_CLOSE_PIPEREAD" );
	}

	// close PipeWrite
	bSuccess = CloseHandle( hPipeWrite );
	if ( !bSuccess ) {
		m_pResult->Format( "ERROR_CLOSE_PIPEWRITE" );
	}
}


void CRedirect::AppendText(LPCTSTR text)
{
	CString strTempResult;
	strTempResult.Format( "%s", text );
	*m_pResult += strTempResult; 
}

void CRedirect::PeekAndPump()
{
	MSG msg;
	while ( ::PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) ) {
		(void)AfxGetApp( )->PumpMessage( );
	}
}
