// Share.h: interface for the CShare class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHARE_H__3CA11925_0611_4663_A49F_A0C2E318EDD1__INCLUDED_)
#define AFX_SHARE_H__3CA11925_0611_4663_A49F_A0C2E318EDD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CShare  
{
public:
	void StoreDB( CString strIP );
	BOOL IsAccessAll( );
	BOOL IsAccessPerm( );
	BOOL IsAccessAtrib( );
	BOOL IsAccessDelete( );
	BOOL IsAccessExec( );
	BOOL IsAccessCreate( );
	BOOL IsAccessWrite( );
	BOOL IsAccessRead( );
	CString GetShareType( );
	CString GetShareComment( );
	CString GetShareName( );
	CShare( CString strShareName, CString strShareComment, CString strShareType,
				BOOL bAccessRead = FALSE,	BOOL bAccessWrite = FALSE,
				BOOL bAccessCreate = FALSE, BOOL bAccessExec = FALSE,
				BOOL bAccessDelete = FALSE,	BOOL bAccessAtrib = FALSE,
				BOOL bAccessPerm = FALSE,	BOOL bAccessAll	= FALSE );
	virtual ~CShare();

private:
	BOOL m_bAccessAll;
	BOOL m_bAccessPerm;
	BOOL m_bAccessAtrib;
	BOOL m_bAccessDelete;
	BOOL m_bAccessExec;
	BOOL m_bAccessCreate;
	BOOL m_bAccessWrite;
	BOOL m_bAccessRead;
	CString m_strShareType;
	CString m_strShareComment;
	CString m_strShareName;
};

#endif // !defined(AFX_SHARE_H__3CA11925_0611_4663_A49F_A0C2E318EDD1__INCLUDED_)
