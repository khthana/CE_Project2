#if !defined(AFX_DAOINNETWORKSET_H__C5B20D2F_D0B3_489B_B733_17113334CC95__INCLUDED_)
#define AFX_DAOINNETWORKSET_H__C5B20D2F_D0B3_489B_B733_17113334CC95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoInNetworkSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoInNetworkSet DAO recordset

class CDaoInNetworkSet : public CDaoRecordset
{
public:
	CDaoInNetworkSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoInNetworkSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoInNetworkSet, CDaoRecordset)
	CString	m_IP;
	CString	m_NetworkAddress;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoInNetworkSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOINNETWORKSET_H__C5B20D2F_D0B3_489B_B733_17113334CC95__INCLUDED_)
