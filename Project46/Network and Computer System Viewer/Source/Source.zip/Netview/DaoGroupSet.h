#if !defined(AFX_DAOGROUPSET_H__7B5A0CF1_093B_46DB_8DB9_5E5EFF07FBAD__INCLUDED_)
#define AFX_DAOGROUPSET_H__7B5A0CF1_093B_46DB_8DB9_5E5EFF07FBAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoGroupSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoGroupSet DAO recordset

class CDaoGroupSet : public CDaoRecordset
{
public:
	CDaoGroupSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoGroupSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoGroupSet, CDaoRecordset)
	CString	m_IP;
	CString	m_GroupName;
	CString	m_GroupComment;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoGroupSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOGROUPSET_H__7B5A0CF1_093B_46DB_8DB9_5E5EFF07FBAD__INCLUDED_)
