#if !defined(AFX_DAOMACSET_H__D6A574D4_D3AC_43DD_A676_DB299CCCC22E__INCLUDED_)
#define AFX_DAOMACSET_H__D6A574D4_D3AC_43DD_A676_DB299CCCC22E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoMACSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoMACSet DAO recordset

class CDaoMACSet : public CDaoRecordset
{
public:
	CDaoMACSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoMACSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoMACSet, CDaoRecordset)
	CString	m_IP;
	CString	m_MACAddress;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoMACSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOMACSET_H__D6A574D4_D3AC_43DD_A676_DB299CCCC22E__INCLUDED_)
