#if !defined(AFX_DAONETWORKSET_H__168815E8_2A3C_4F53_AD8D_8EAEBDA75831__INCLUDED_)
#define AFX_DAONETWORKSET_H__168815E8_2A3C_4F53_AD8D_8EAEBDA75831__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoNetworkSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoNetworkSet DAO recordset

class CDaoNetworkSet : public CDaoRecordset
{
public:
	CDaoNetworkSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoNetworkSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoNetworkSet, CDaoRecordset)
	CString	m_NetworkAddress;
	CString	m_Netmask;
	COleDateTime	m_ConnectTime;
	COleDateTime	m_ConnectDate;
	COleDateTime	m_DisconnectTime;
	COleDateTime	m_DisconnectDate;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoNetworkSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAONETWORKSET_H__168815E8_2A3C_4F53_AD8D_8EAEBDA75831__INCLUDED_)
