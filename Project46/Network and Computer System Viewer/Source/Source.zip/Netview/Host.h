// Host.h: interface for the CHost class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOST_H__B6922268_9707_43FC_8436_E0E1D8E8FF58__INCLUDED_)
#define AFX_HOST_H__B6922268_9707_43FC_8436_E0E1D8E8FF58__INCLUDED_

#include "TypeUserArray.h"	// Added by ClassView
#include "TypeGroupArray.h"	// Added by ClassView
#include "TypePortArray.h"	// Added by ClassView
#include "TypeShareArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHost  
{
public:
	COleDateTime GetCloseTime( );
	COleDateTime GetOpenTime( );
	void StoreDB( );
	CShareArray* GetShares( );
	int FindShare( CString strShareName );
	void AddShare( CString strShareName, CString strShareComment, CString strShareType );
	int FindMacAddress( CString strMacAddress );
	CGroupArray* GetGroups( );
	void AddGroup( CString strGroupName, CString strGroupComment, CStringArray *pGroupMembers );
	int FindGroup( CString strGroupName );
	CUserArray* GetUsers( );
	int FindUser( CString strUserName );
	void AddUser( CString strUserName, CString strComment, CString strFullName, BOOL bAccountEnable, BOOL bPasswordReq, BOOL bPasswordCanChange, BOOL bPasswordNotExpire );
	void ConnectNullSession( );
	void SelectBitmap( );
	void AddMacAddress( CString strMacAddress );
	CStringArray* GetMacAddress( );
	CString GetLockoutThreshold( );
	void SetLockoutThreshold( CString strLockoutThreshold );
	CString GetLockoutReset( );
	void SetLockoutReset( CString strLockoutReset );
	CString GetLockoutDuration( );
	void SetLockoutDuration( CString strLockoutDuration );
	CString GetPasswordMaxAge( );
	void SetPasswordMaxAge( CString strPasswordMaxAge );
	CString GetPasswordMinAge();
	void SetPasswordMinAge( CString strPasswordMinAge );
	CString GetPasswordMinLength( );
	void SetPasswordMinLength( CString strPasswordMinLength );
	CString GetCloseTimeString( );
	CString GetOpenTimeString( );
	CPortArray* GetPorts( );
	CString GetType( );
	CString GetOS( );
	CString GetHostName( );
	void SetPortStatus( int iPortPosition, CString strStatus );
	void AddPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect, CString strStatus);
	int FindPort( long lPortNumber,  CString strProtocol );
	void SetHostData( CString strHostName, CString strOS, CString strType );
	BOOL IsTrojan( );
	BOOL IsStatus( );
	BOOL IsSnmp( );
	BOOL IsPolicy( );
	CString* GetResult( );
	CString GetCommand();
	void SetCommand( CString strCommand );
	CBitmap* GetBitmap( );
	void SetTrojan( BOOL bTrojan );
	void SetSnmp( BOOL bSnmp );
	void SetPolicy( BOOL bPolicy );
	void SetStatus( BOOL bStatus );
	CString GetIP( );
	CRectTracker* GetPosition( );
	CHost( CString strIP, BOOL bStatus );
	virtual ~CHost();

protected:
	void StoreHasPortDB( );
	void StoreUseVendorDB( );
	void StoreMACDB( );
	void StoreHostDB( );
	void ScanShare( char *server );
	void ScanSecurityPolicy( char *server );
	void ScanMacAddress( char *server );
	void ScanGroup( char *server );
	void ScanUserName( char *server );
	CString m_strResult;
	CString m_strCommand;
	CBitmap *m_pBitmap;
	
	CBitmap m_bmpRouterSnmp;
	CBitmap m_bmpRouter;
	CBitmap m_bmpPrinterSnmp;
	CBitmap m_bmpPrinter;
	CBitmap m_bmpTrojanSnmp;
	CBitmap m_bmpTrojan;
	CBitmap m_bmpTrojanAndPolicySnmp;
	CBitmap m_bmpTrojanAndPolicy;
	CBitmap m_bmpPolicySnmp;
	CBitmap m_bmpPolicy;
	CBitmap m_bmpOpenSnmp;
	CBitmap m_bmpOpen;
	CBitmap m_bmpClose;
	
	BOOL m_bPolicy;	// True Policy=TRUE, False Policy=FALSE
	BOOL m_bTrojan;	// Trojan=TRUE, No Trojan=FALSE
	BOOL m_bStatus;	// Open=TRUE, Close=FALSE
	CShareArray m_saShares;
	CPortArray m_paPorts;
	CGroupArray m_gaGroups;
	CUserArray m_uaUsers;
	CRectTracker m_rtPosition;
private:
	CString m_strLockoutThreshold;
	CString m_strLockoutReset;
	CString m_strLockoutDuration;
	CString m_strMaxAge;
	CString m_strMinAge;
	CString m_strMinLength;
	COleDateTime m_timeClose;
	COleDateTime m_timeOpen;
	CStringArray m_saMacAddress;
	BOOL m_bSnmp;
	CString m_strType;
	CString m_strOS;
	CString m_strHostName;
	CString m_strIP;
};

#endif // !defined(AFX_HOST_H__B6922268_9707_43FC_8436_E0E1D8E8FF58__INCLUDED_)
