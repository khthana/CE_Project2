// DaoAgentSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoAgentSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoAgentSet

IMPLEMENT_DYNAMIC(CDaoAgentSet, CDaoRecordset)

CDaoAgentSet::CDaoAgentSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoAgentSet)
	m_NetworkAddress = _T("");
	m_AgentIP = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoAgentSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoAgentSet::GetDefaultSQL()
{
	return _T("[Agent]");
}

void CDaoAgentSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoAgentSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[NetworkAddress]"), m_NetworkAddress);
	DFX_Text(pFX, _T("[AgentIP]"), m_AgentIP);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoAgentSet diagnostics

#ifdef _DEBUG
void CDaoAgentSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoAgentSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
