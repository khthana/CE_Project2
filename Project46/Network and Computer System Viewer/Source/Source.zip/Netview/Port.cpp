// Port.cpp: implementation of the CPort class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Port.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPort::CPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_lPortNumber	= lPortNumber;
	m_strProtocol	= strProtocol;
	m_strPortName	= strPortName;
	m_bTrojan		= bTrojan;
	m_bWantDetect	= bWantDetect;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CPort::CPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect, CString strStatus)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_lPortNumber	= lPortNumber;
	m_strProtocol	= strProtocol;
	m_strPortName	= strPortName;
	m_bTrojan		= bTrojan;
	m_bWantDetect	= bWantDetect;
	m_strStatus		= strStatus;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}


CPort::~CPort()
{

}

void CPort::SetPortData(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_lPortNumber	= lPortNumber;
	m_strProtocol	= strProtocol;
	m_strPortName	= strPortName;
	m_bTrojan		= bTrojan;
	m_bWantDetect	= bWantDetect;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}



void CPort::GetPortData(long *pPortNumber, CString *pProtocol, CString *pPortName, BOOL *pTrojan, BOOL *pWantDetect)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	*pPortNumber	= m_lPortNumber;
	*pProtocol		= m_strProtocol;
	*pPortName		= m_strPortName;
	*pTrojan		= m_bTrojan;
	*pWantDetect	= m_bWantDetect;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

long CPort::GetPortNumber()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_lPortNumber;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

CString CPort::GetProtocol()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strProtocol;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

void CPort::SetPortStatus(CString strStatus)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_strStatus = strStatus;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

CString CPort::GetPortName()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strPortName;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

CString CPort::GetStatus()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_strStatus;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

BOOL CPort::IsTrojan()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bTrojan;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}

BOOL CPort::IsWantDetect()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	return m_bWantDetect;
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
}
