// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "Netview.h"

///////////////////////////////
// MY INCLUDE START HERE 
///////////////////////////////
#include "NetviewDoc.h"
#include "NetworkView.h"
#include "Discover.h"
#include "SetAutoRefreshDlg.h"
///////////////////////////////
// MY INCLUDE END HERE 
///////////////////////////////

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_TIMER()
	ON_COMMAND(ID_CONFIGURE_SET_AUTO_REFRESH, OnConfigureSetAutoRefresh)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

BOOL CChildFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////

	//-------------------------------------
	// Set start timer
	//-------------------------------------
	// reset interval time to 00.00.00
	this->m_iHour	= 0;
	this->m_iMinute	= 0;
	this->m_iSecond	= 0;

	// init auto refresh interval is 1 hours
	this->m_iRefreshHour	= 1;
	this->m_iRefreshMinute	= 0;
	this->m_iRefreshSecond	= 0;

	m_nRefreshTimer = SetTimer( ID_REFRESH_TIMER, 1000, NULL );
	//-------------------------------------
	// Set start timer
	//-------------------------------------
	
	// Create a splitter window which splits an Network View (CNetworkView) and 
	//	an Netview View (CNetviewView = Host View)
	//								  |
	//    NETWORK VIEW (CNetworkView) |  NETVIEW VIEW (CNetviewView)
	//   
	
	// create a splitter with 1 row, 2 columns
	if ( !m_wndSplitter.CreateStatic( this, 1, 2 ) )
		return FALSE;

	// add the first splitter pane - the Network View in column 1
	if ( !m_wndSplitter.CreateView( 0, 0, 
									RUNTIME_CLASS( CNetworkView ),
									CSize( 145, 0 ),
									pContext ) ) 
		return FALSE;

	// add the second splitter pane - an Netview View (Host view) in column 2
	if ( !m_wndSplitter.CreateView( 0, 1,
									pContext->m_pNewViewClass,
									CSize( 0, 0 ),
									pContext ) )
		return FALSE;

	// activate the input view
	SetActiveView( (CView*)m_wndSplitter.GetPane( 0, 0 ) );

	return TRUE;

	// Comment default return
	//return CMDIChildWnd::OnCreateClient(lpcs, pContext);

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CChildFrame::ActivateFrame(int nCmdShow) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	 
	/*
	// Show MAXIMIZED child frame  
	// if another window is open, use default
	if(GetMDIFrame()->MDIGetActive())
		CMDIChildWnd::ActivateFrame(nCmdShow); 
	else
		CMDIChildWnd::ActivateFrame(SW_SHOWMAXIMIZED); // else open maximized.
	*/
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	CMDIChildWnd::ActivateFrame(nCmdShow);
}

void CChildFrame::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	if ( m_nRefreshTimer == nIDEvent ) {

		// (m_iRefreshSecond==0)&&(m_iRefreshMinute==0)&&(m_iRefreshHour==0) == Not auto refresh
		if ( !((m_iRefreshSecond==0)&&(m_iRefreshMinute==0)&&(m_iRefreshHour==0)) ) {
			// Update time
			m_iSecond++;
			if ( m_iSecond == 60 ) {
				m_iSecond = 0;
				m_iMinute++;
				if ( m_iMinute == 60 ) {
					m_iMinute = 0;
					m_iHour++;
				}
			}

			// compare refresh time to activate refresh function
			if ( ( m_iRefreshSecond == m_iSecond ) &&
				 ( m_iRefreshMinute == m_iMinute ) &&
				 ( m_iRefreshHour   == m_iHour   ) ) {
				// reset count time
				m_iSecond = 0;
				m_iMinute = 0;
				m_iHour	  = 0;

				// Activate function
				this->RefreshExplorer( );
			}
		}
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////

	CMDIChildWnd::OnTimer(nIDEvent);
}

void CChildFrame::OnConfigureSetAutoRefresh() 
{
	// TODO: Add your command handler code here
	
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
	CSetAutoRefreshDlg dlgSetAutoRefresh;
	dlgSetAutoRefresh.m_iRefreshHour	= this->m_iRefreshHour;
	dlgSetAutoRefresh.m_iRefreshMinute	= this->m_iRefreshMinute;
	dlgSetAutoRefresh.m_iRefreshSecond	= this->m_iRefreshSecond;
	if ( dlgSetAutoRefresh.DoModal( ) == IDOK ) {
		this->m_iRefreshHour	= dlgSetAutoRefresh.m_iRefreshHour;
		this->m_iRefreshMinute	= dlgSetAutoRefresh.m_iRefreshMinute;
		this->m_iRefreshSecond	= dlgSetAutoRefresh.m_iRefreshSecond;
		// reset count time
		this->m_iHour	= 0;
		this->m_iMinute	= 0;
		this->m_iSecond	= 0;
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Refresh explorer
//
void CChildFrame::RefreshExplorer()
{
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	// on time == refreah
	CNetviewApp *pApp;
	CNetviewDoc *pDoc;
	pApp = (CNetviewApp*)AfxGetApp( );
	pDoc = (CNetviewDoc*)this->GetActiveDocument( );

	// if not while explorer
	if ( !pApp->IsWhileExplorer( ) ) {
		pDoc->RefreshExplorer( );
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CChildFrame::OnViewRefresh() 
{
	// TODO: Add your command handler code here

	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	// reset count time
	m_iSecond = 0;
	m_iMinute = 0;
	m_iHour	  = 0;
	// Activate function
	this->RefreshExplorer( );
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}
