// WizPage02.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "WizPage02.h"

////////////////////////////
// MY INCLUDE START HERE
////////////////////////////
#pragma comment( lib, "Ws2_32.lib" )
#include <Winsock2.h>
#include "WizSheet.h"
#include "AgentIPDlg.h"
////////////////////////////
// MY INCLUDE END HERE
////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizPage02 property page

IMPLEMENT_DYNCREATE(CWizPage02, CPropertyPage)

CWizPage02::CWizPage02() : CPropertyPage(CWizPage02::IDD)
{
	//{{AFX_DATA_INIT(CWizPage02)
	//}}AFX_DATA_INIT
}

CWizPage02::~CWizPage02()
{
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	// Clear String Array
	if ( m_saAgentIP.GetSize( ) > 0 )
		m_saAgentIP.RemoveAll( );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage02::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizPage02)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizPage02, CPropertyPage)
	//{{AFX_MSG_MAP(CWizPage02)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_ADDAGENTIP, OnButtonAddagentip)
	ON_BN_CLICKED(IDC_BUTTON_REMOVEAGENTIP, OnButtonRemoveagentip)
	ON_BN_CLICKED(IDC_BUTTON_REMOVEALLAGENTIP, OnButtonRemoveallagentip)
	ON_NOTIFY(IPN_FIELDCHANGED, IDC_IPADDRESS_START, OnFieldchangedIpaddressStart)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizPage02 message handlers

BOOL CWizPage02::OnSetActive() 
{
	// TODO: Add your specialized code here and/or call the base class

	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CWizSheet *pSheet = ( CWizSheet* )this->GetParent( );	
	CIPAddressCtrl *ctlIPAddressStart	= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_START );
	CIPAddressCtrl *ctlIPAddressEnd		= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_END );
	CIPAddressCtrl *ctlIPAddressNetmask = (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_NETMASK );

	pSheet->SetWizardButtons( PSWIZB_BACK | PSWIZB_NEXT );

	if ( pSheet->m_wizPage01.m_iDiscoveryType == 0 ) {
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Local Network (This Network)"
		// ------------------------------------------------------------------

		CString strLocalNetwork;// local Network Address
		char *localIP = NULL;	// local IP Address
		char name[255];			// local Host name
		WORD wVersionRequested;	
		WSADATA wsaData;		// Window socket data
		PHOSTENT hostinfo;		// Host information (local IP)

		// ---------------------------
		//  find local IP address
		// ---------------------------
		wVersionRequested = MAKEWORD( 2, 0 ); 
	
		if ( WSAStartup( wVersionRequested, &wsaData ) == 0 ) {
			// start Window Socket Function
			if( gethostname( name, sizeof(name) ) == 0 ) { 
				// get local machine name (local host name)
				if( (hostinfo = gethostbyname( name )) != NULL ) {
					// get host information by host name
					localIP = inet_ntoa( *(struct in_addr*)*hostinfo->h_addr_list );
				}
			}
			WSACleanup( );
		}
		// ---------------------------
		//  find local IP address
		// ---------------------------

		if ( localIP == NULL ) {
			// can't find local IP
			MessageBox( "Can not get local network.", "Error", MB_ICONERROR );
		}
		else {
			// can find local IP

			// find Local Network
			strLocalNetwork.Format( "%s", localIP );

			// set network address to wizard page
			strLocalNetwork = strLocalNetwork.Left(strLocalNetwork.ReverseFind('.'));
			strLocalNetwork += ".0";
			ctlIPAddressStart->SetWindowText( strLocalNetwork );
			ctlIPAddressStart->EnableWindow( FALSE );
			
			strLocalNetwork = strLocalNetwork.Left(strLocalNetwork.ReverseFind('.'));
			strLocalNetwork += ".255";
			ctlIPAddressEnd->SetWindowText( strLocalNetwork );
			ctlIPAddressEnd->EnableWindow( FALSE );

			ctlIPAddressNetmask->SetWindowText( "255.255.255.0" );
			ctlIPAddressNetmask->EnableWindow( TRUE );
		}
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Local Network (This Network)"
		// ------------------------------------------------------------------
	}
	else if ( pSheet->m_wizPage01.m_iDiscoveryType == 1 ) {
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Range Network"
		// ------------------------------------------------------------------
		ctlIPAddressStart->SetWindowText( "" );
		ctlIPAddressStart->EnableWindow( TRUE );
		ctlIPAddressEnd->SetWindowText( "" );
		ctlIPAddressEnd->EnableWindow( TRUE );
		ctlIPAddressNetmask->SetWindowText( "255.255.255.0" );
		ctlIPAddressNetmask->EnableWindow( TRUE );
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Range Network"
		// ------------------------------------------------------------------
	}
	else if ( pSheet->m_wizPage01.m_iDiscoveryType == 2 ) {
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Range Host"
		// ------------------------------------------------------------------
		ctlIPAddressStart->SetWindowText( "" );
		ctlIPAddressStart->EnableWindow( TRUE );
		ctlIPAddressEnd->SetWindowText( "" );
		ctlIPAddressEnd->EnableWindow( TRUE );
		ctlIPAddressNetmask->SetWindowText( "255.255.255.0" );
		ctlIPAddressNetmask->EnableWindow( FALSE );
		// ------------------------------------------------------------------
		// Wizard Page 1 select option "Range Host"
		// ------------------------------------------------------------------
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnSetActive();
}

void CWizPage02::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CWizSheet *pSheet = ( CWizSheet* )this->GetParent( );
	pSheet->SetTitle( "IP Address Scan - Step 2 of 3" );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	// Do not call CPropertyPage::OnPaint() for painting messages
}

BOOL CWizPage02::OnQueryCancel() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	if ( MessageBox( "Are you sure to quit?", "Quit", 
					 MB_YESNO | MB_ICONINFORMATION ) == IDNO ) {
		return FALSE;
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnQueryCancel();
}

LRESULT CWizPage02::OnWizardNext() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	int i, iIndex, iCheckClassless;
	int iDiscoveryType;
	CString strIPStart;
	CString strIPEnd;
	CString strNetmask;
	CString strInternet;
	CString strTempAgentIP;

	CWizSheet *pSheet = ( CWizSheet* )this->GetParent( );
	CIPAddressCtrl *ctlIPAddressStart	= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_START );
	CIPAddressCtrl *ctlIPAddressEnd		= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_END );
	CIPAddressCtrl *ctlIPAddressNetmask	= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_NETMASK );
	CIPAddressCtrl *ctlIPAddressInternetIP = (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_INTERNETIP );
	CListBox	   *ctlListAgentIP		= (CListBox*)GetDlgItem( IDC_LIST_AGENTIP );

	iDiscoveryType = pSheet->m_wizPage01.m_iDiscoveryType;
	ctlIPAddressStart->GetWindowText( strIPStart );
	ctlIPAddressEnd->GetWindowText( strIPEnd );
	ctlIPAddressNetmask->GetWindowText( strNetmask );
	ctlIPAddressInternetIP->GetWindowText( strInternet );

	// ----------------------------------------------------------------------------
	// Check user input error
	// ----------------------------------------------------------------------------
	if ( ctlIPAddressStart->IsBlank( ) ||
		 ctlIPAddressEnd->IsBlank( ) ||
		 ctlIPAddressNetmask->IsBlank( ) ) {// if empty IP Address
		MessageBox( "Please enter IP Address in IP start and IP end.",
					"Miss IP Address", MB_OK | MB_ICONERROR );
		return -1;
	}

	// Validation IP Classless
	iCheckClassless = CheckClassless( strIPStart, strIPEnd, strNetmask, iDiscoveryType );
	// if IP Address start and/or IP Address end error
	if ( iCheckClassless == 0 ) {		
		MessageBox( "Input IP Address start and/or IP Address end error.",
					"Miss IP Address", MB_OK | MB_ICONERROR );
		return -1;
	}
	// if Netmask error
	else if ( iCheckClassless == 1 ) {			
		MessageBox( "Input Netmask error.",
					"Miss IP Address", MB_OK | MB_ICONERROR );
		return -1;
	}
	// ----------------------------------------------------------------------------
	// Check user input error
	// ----------------------------------------------------------------------------

	//if not anything error copy ALL data to string 
	// get IP Address
	ctlIPAddressStart->GetWindowText( m_strIPStart );
	ctlIPAddressEnd->GetWindowText( m_strIPEnd );
	ctlIPAddressNetmask->GetWindowText( m_strNetmask );
	m_saAgentIP.Add( strInternet );
	
	// get agent IP in List to String Array (m_saAgentIP)
	iIndex = ctlListAgentIP->GetCount( );
	for ( i=0; i<iIndex; i++ ) {
		ctlListAgentIP->GetText( i, strTempAgentIP );
		m_saAgentIP.Add( strTempAgentIP );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return CPropertyPage::OnWizardNext();
}

BOOL CWizPage02::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////

	// set disible Remove Agent IP 's Button
	CButton *pRemoveAgentIP		= (CButton*)this->GetDlgItem( IDC_BUTTON_REMOVEAGENTIP );
	CButton *pRemoveAllAgentIP	= (CButton*)this->GetDlgItem( IDC_BUTTON_REMOVEALLAGENTIP );
	pRemoveAgentIP->EnableWindow( FALSE );
	pRemoveAllAgentIP->EnableWindow( FALSE );

	// set default internet ip
	CIPAddressCtrl *ctlIPAddressInternetIP = (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_INTERNETIP );
	ctlIPAddressInternetIP->SetWindowText( "203.107.136.6" );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWizPage02::OnButtonAddagentip() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CString strAgentIP;
	CListBox *ctlListAgentIP = (CListBox*)GetDlgItem( IDC_LIST_AGENTIP );
	CButton *pRemoveAgentIP = (CButton*)GetDlgItem( IDC_BUTTON_REMOVEAGENTIP );
	CButton *pRemoveAllAgentIP = (CButton*)GetDlgItem( IDC_BUTTON_REMOVEALLAGENTIP );
	CIPAddressCtrl *ctlIPAddressAgentIP = (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_ADDAGENTIP );
	
	// get and add agent ip
	ctlIPAddressAgentIP->GetWindowText( strAgentIP );
	if ( strAgentIP != "0.0.0.0" ) {
		ctlIPAddressAgentIP->SetWindowText( "" );
		ctlListAgentIP->AddString( strAgentIP );
		pRemoveAgentIP->EnableWindow( TRUE );
		pRemoveAllAgentIP->EnableWindow( TRUE );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage02::OnButtonRemoveagentip() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	int iIndex;
	CListBox *ctlListAgentIP = (CListBox*)GetDlgItem( IDC_LIST_AGENTIP );

	// delete select Agent IP
	iIndex = ctlListAgentIP->GetCurSel( );
	ctlListAgentIP->DeleteString( iIndex );

	// if no more Agent IP disible remove agent ip's button
	if ( ctlListAgentIP->GetCount( ) == 0 ) {
		CButton *pRemoveAgentIP = (CButton*)GetDlgItem( IDC_BUTTON_REMOVEAGENTIP );
		CButton *pRemoveAllAgentIP = (CButton*)this->GetDlgItem( IDC_BUTTON_REMOVEALLAGENTIP );
		pRemoveAgentIP->EnableWindow( FALSE );
		pRemoveAllAgentIP->EnableWindow( FALSE );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage02::OnButtonRemoveallagentip() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	CListBox *ctlListAgentIP = (CListBox*)GetDlgItem( IDC_LIST_AGENTIP );

	// delete all Agent IP
	while ( ctlListAgentIP->GetCount( ) )
		ctlListAgentIP->DeleteString( 0 );

	// if no more Agent IP disible remove agent ip's button
	if ( ctlListAgentIP->GetCount( ) == 0 ) {
		CButton *pRemoveAgentIP = (CButton*)GetDlgItem( IDC_BUTTON_REMOVEAGENTIP );
		CButton *pRemoveAllAgentIP = (CButton*)this->GetDlgItem( IDC_BUTTON_REMOVEALLAGENTIP );
		pRemoveAgentIP->EnableWindow( FALSE );
		pRemoveAllAgentIP->EnableWindow( FALSE );
	}
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Check Classless for input IP start, IP end and Netmask
//	Parameter	: 
//		IPStart(IN)	>>	Input IP Address Start
//		IPEnd(IN)	>>	Input IP Address End
//		Netmask(IN)	>>	Input Netmask
//		type(IN)	>>	Discovery Type from wizard page 1
//	Return		: result check (0=IP Error, 1=Netmask Error, 2=No Error)
//
int CWizPage02::CheckClassless(CString IPStart, CString IPEnd, CString Netmask, int type)
{
	//////////////////////////////////
	// MY CODE START HERE
	//////////////////////////////////
	int start,stop,i,flagip,flagnetmask,flagrelate,flag,subnet;
	int numhost[9] = {0,128,192,224,240,248,252,254,255};
	start = stop = i = flagip = flagnetmask = flagrelate = flag = 0;
	CString ipstart[4],ipstop[4],netmask[4];
	int intstart[4],intstop[4],intnetmask[4];
	//Devide address of IPStart into ipstart
	stop = IPStart.Find(".",0);
	while(stop > 0)
	{
		ipstart[i] = IPStart.Mid(start,stop-(start));
		i++;
		start = stop+1;
		stop = IPStart.Find(".",start);
	}
	ipstart[i] = IPStart.Right(IPStart.GetLength()-(IPStart.ReverseFind('.')+1));
	//Devide address of IPEnd into ipstop
	start = stop = i =0;
	stop = IPEnd.Find(".",0);
	while(stop > 0)
	{
		ipstop[i] = IPEnd.Mid(start,stop-(start));
		i++;
		start = stop+1;
		stop = IPEnd.Find(".",start);
	}
	ipstop[i] = IPEnd.Right(IPEnd.GetLength()-(IPEnd.ReverseFind('.')+1));
	//Devide address of Netmask into netmask
	start = stop = i =0;
	stop = Netmask.Find(".",0);
	while(stop > 0)
	{
		netmask[i] = Netmask.Mid(start,stop-(start));
		i++;
		start = stop+1;
		stop = Netmask.Find(".",start);
	}
	netmask[i] = Netmask.Right(Netmask.GetLength()-(Netmask.ReverseFind('.')+1));
	//Convert CString to int of ipstart,ipend,netmask
	for(i=0;i<4;i++)
	{
		intstart[i] = atoi(ipstart[i]);
		intstop[i] = atoi(ipstop[i]);
		intnetmask[i] = atoi(netmask[i]);
	}
	if(type == 0)//Scan this network
	{
		if((intnetmask[0] == 255)&&(intnetmask[1] == 255)&&(intnetmask[2] == 255))
		{
			for(i=0;i<9;i++)//Check 2 power 0-8 from Classless
			{
				if(intnetmask[3]==numhost[i])
					flag = 1; 
			}
			if(flag == 0)
				flagnetmask = 1;//netmask error
		}
		else
			flagnetmask = 1;
	}
	if(type == 1)//Scan Network Range
	{
		if(intnetmask[0] == 255)
		{
			if(intnetmask[1] == 255)
			{
				if(intnetmask[2] == 255)//Netmask is 255.255.255.x
				{
					for(i=0;i<9;i++)//Check 2 power 0-8 from Classless
					{
						if(intnetmask[3]==numhost[i])
						{
							flag = 1; 
							subnet = 256-numhost[i];
						}
					}
					if(flag == 1)//Not false Classless 
					{
						if((intstart[0]>intstop[0])||(intstart[1]>intstop[1])||(intstart[2]>intstop[2])||
							((intstop[3]%subnet)!=0)||((intstart[3]%subnet)!=0))
							flagip = 1;
					}
					else
						flagnetmask = 1;
				}
				else if((intnetmask[3] == 0)&&(intstart[3] == 0)&&(intstop[3] == 0))//Netmask is 255.255.x.0
				{
					for(i=0;i<8;i++)//Check 2 power 0-8 from Classless
					{
						if(intnetmask[2]==numhost[i])
						{
							flag = 1; 
							subnet = 256-numhost[i];
						}
					}
					if(flag == 1)//Not false Classless 
					{
						if((intstart[0] != 255)&&(intstop[0] != 0)&&(intstop[0] != 255)&&
						   (intstart[1] != 255)&&(intstop[1] != 0)&&(intstop[1] != 255)&&
						   (intstart[2] != 255)&&(intstop[2] != 0)&&(intstop[2] != 255))//Check 0 and 255
						{
							if(intstop[0] > intstart[0])//ipstart is a.b.c.0,ipend is d.e.f.0 ;d > a
							{
								if(((intstop[2]%subnet)!=0)||((intstart[2]%subnet)!=0))//Check c and f is devide by subnet is 0
									flagip = 1;
							}
							else if(intstop[0] == intstart[0]) 
							{
								if(intstop[1] > intstart[1])//if e > b
								{
									if(((intstop[2]%subnet)!=0)||((intstart[2]%subnet)!=0))
										flagip = 1;
								}
								else if(intstop[1] == intstart[1])
								{
									if(intstop[2] >= intstart[2])//if f > c 
									{
										if(((intstop[2]%subnet)!=0)||((intstart[2]%subnet)!=0))
											flagip = 1;
									}
									else
										flagip = 1;
								}
								else
									flagip = 1;
							}
							else
								flagip = 1;
						}
						else 
							flagip = 1;
					}
					else
						flagnetmask = 1;
				}
				else
					flagnetmask = 1;
			}
			else if((intnetmask[2] == 0)&&(intnetmask[3] == 0)&&//Netmask is 255.x.0.0
			(intstart[2] == 0)&&(intstart[3] == 0)&&//ipstart is 255.x.0.0
			(intstop[2] == 0)&&(intstop[3] == 0))//ipend is 255.x.0.0
			{
				for(i=0;i<8;i++)//Check 2 power 1-8 from Classless
				{
					if(intnetmask[1]==numhost[i])
					{
						flag = 1; 
						subnet = 256-numhost[i];
					}
				}
				if(flag == 1)//Not false Classless 
				{
					if((intstart[0] != 255)&&(intstop[0] != 0)&&(intstop[0] != 255)&&
					   (intstart[1] != 255)&&(intstop[1] != 0)&&(intstop[1] != 255))
					{
						if(intstop[0] > intstart[0])//ipstart is a.b.0.0,ipend is d.e.0.0 ;d > a
						{
							if(((intstop[1]%subnet)!=0)||((intstart[1]%subnet)!=0))
								flagip = 1;
						}
						else if(intstop[0] == intstart[0])
						{
							if(intstop[1] >= intstart[1])//if e > b
							{
								if(((intstop[1]%subnet)!=0)||((intstart[1]%subnet)!=0))
									flagip = 1;
							}
							else
								flagip = 1;
						}
						else
							flagip = 1;
					}
					else 
						flagip = 1;
				}
				else
					flagnetmask = 1;
			}
			else
				flagnetmask = 1;
		}
		else if((intnetmask[1] == 0)&&(intnetmask[2] == 0)&&(intnetmask[3] == 0)&&//Netmask is x.0.0.0
			(intstart[1] == 0)&&(intstart[2] == 0)&&(intstart[3] == 0)&&//ipstart is x.0.0.0
			(intstop[1] == 0)&&(intstop[2] == 0)&&(intstop[3] == 0))//ipend is x.0.0.0
		{
			for(i=0;i<8;i++)//Check 2 power 1-8 from Classless
			{
				if(intnetmask[0]==numhost[i])
				{
					flag = 1; 
					subnet = 256-numhost[i];
				}
			}
			if(flag == 1)//Not false Classless 
			{
				if((intstart[0]!=255)&&(intstop[0]!=0)&&(intstop[0]!=255)&&(intstop[0]>=intstart[0]))
				{
					if((intstop[0]-intstart[0]+1)%subnet != 0)
						flagip = 1;
				}
				else
					flagip = 1;
			}
			else
				flagnetmask = 1;
		}
		else
			flagnetmask = 1;
	}
	if(type == 2)//Scan IP Range
	{
		if((intstart[3] != 0)&&(intstart[3] != 255)&&(intstop[3] != 0)&&(intstop[3] != 255)&&(intstart[0] == intstop[0])&&(intstart[1] == intstop[1]))
		{
			if(intstop[2] == intstart[2])
			{
				if(intstop[3] < intstart[3])
					flagip = 1;
			}
			else if(intstop[2] < intstart[2])
				flagip = 1;
		}
		else
			flagip = 1;
	}
	if(flagip == 1)
		return 0;
	else if(flagnetmask == 1)
		return 1;
	else
		return 2;
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////
}

void CWizPage02::OnFieldchangedIpaddressStart(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////////////
	// MY STRAT END HERE
	//////////////////////////////////
	CString strIP;
	CIPAddressCtrl *ctlIPAddressStart = (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_START );
	CIPAddressCtrl *ctlIPAddressEnd	= (CIPAddressCtrl*)GetDlgItem( IDC_IPADDRESS_END );
	ctlIPAddressStart->GetWindowText( strIP );
	ctlIPAddressEnd->SetWindowText( strIP );
	//////////////////////////////////
	// MY CODE END HERE
	//////////////////////////////////

	*pResult = 0;
}
