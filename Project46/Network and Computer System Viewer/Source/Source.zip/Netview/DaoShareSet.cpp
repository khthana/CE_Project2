// DaoShareSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoShareSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoShareSet

IMPLEMENT_DYNAMIC(CDaoShareSet, CDaoRecordset)

CDaoShareSet::CDaoShareSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoShareSet)
	m_IP = _T("");
	m_ShareName = _T("");
	m_ShareComment = _T("");
	m_ShareType = _T("");
	m_AccessRead = FALSE;
	m_AccessWrite = FALSE;
	m_AccessCreate = FALSE;
	m_AccessExec = FALSE;
	m_AccessDelete = FALSE;
	m_AccessAtrib = FALSE;
	m_AccessPerm = FALSE;
	m_AccessAll = FALSE;
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoShareSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoShareSet::GetDefaultSQL()
{
	return _T("[Share]");
}

void CDaoShareSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoShareSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[ShareName]"), m_ShareName);
	DFX_Text(pFX, _T("[ShareComment]"), m_ShareComment);
	DFX_Text(pFX, _T("[ShareType]"), m_ShareType);
	DFX_Bool(pFX, _T("[AccessRead]"), m_AccessRead);
	DFX_Bool(pFX, _T("[AccessWrite]"), m_AccessWrite);
	DFX_Bool(pFX, _T("[AccessCreate]"), m_AccessCreate);
	DFX_Bool(pFX, _T("[AccessExec]"), m_AccessExec);
	DFX_Bool(pFX, _T("[AccessDelete]"), m_AccessDelete);
	DFX_Bool(pFX, _T("[AccessAtrib]"), m_AccessAtrib);
	DFX_Bool(pFX, _T("[AccessPerm]"), m_AccessPerm);
	DFX_Bool(pFX, _T("[AccessAll]"), m_AccessAll);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoShareSet diagnostics

#ifdef _DEBUG
void CDaoShareSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoShareSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
