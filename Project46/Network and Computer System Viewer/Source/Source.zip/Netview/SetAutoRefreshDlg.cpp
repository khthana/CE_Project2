// SetAutoRefreshDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "SetAutoRefreshDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetAutoRefreshDlg dialog


CSetAutoRefreshDlg::CSetAutoRefreshDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetAutoRefreshDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetAutoRefreshDlg)
	m_bNotAutoRefresh = FALSE;
	m_iRefreshHour = 0;
	m_iRefreshMinute = 0;
	m_iRefreshSecond = 0;
	//}}AFX_DATA_INIT
}


void CSetAutoRefreshDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetAutoRefreshDlg)
	DDX_Control(pDX, IDC_SPIN_SECOND, m_ctlSpinSecond);
	DDX_Control(pDX, IDC_SPIN_MINUTE, m_ctlSpinMinute);
	DDX_Control(pDX, IDC_SPIN_HOUR, m_ctlSpinHour);
	DDX_Control(pDX, IDC_EDIT_SECOND, m_ctlSecond);
	DDX_Control(pDX, IDC_EDIT_MINUTE, m_ctlMinute);
	DDX_Control(pDX, IDC_EDIT_HOUR, m_ctlHour);
	DDX_Check(pDX, IDC_CHECK_NOTAUTOREFRESH, m_bNotAutoRefresh);
	DDX_Text(pDX, IDC_EDIT_HOUR, m_iRefreshHour);
	DDV_MinMaxInt(pDX, m_iRefreshHour, 0, 30000);
	DDX_Text(pDX, IDC_EDIT_MINUTE, m_iRefreshMinute);
	DDV_MinMaxInt(pDX, m_iRefreshMinute, 0, 59);
	DDX_Text(pDX, IDC_EDIT_SECOND, m_iRefreshSecond);
	DDV_MinMaxInt(pDX, m_iRefreshSecond, 0, 59);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetAutoRefreshDlg, CDialog)
	//{{AFX_MSG_MAP(CSetAutoRefreshDlg)
	ON_BN_CLICKED(IDC_CHECK_NOTAUTOREFRESH, OnCheckNotautorefresh)
	ON_EN_CHANGE(IDC_EDIT_HOUR, OnChangeEditHour)
	ON_EN_CHANGE(IDC_EDIT_MINUTE, OnChangeEditMinute)
	ON_EN_CHANGE(IDC_EDIT_SECOND, OnChangeEditSecond)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetAutoRefreshDlg message handlers

BOOL CSetAutoRefreshDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	UpdateData( FALSE );

	m_ctlSpinHour.SetRange( 0, 30000 );
	m_ctlSpinHour.SetBuddy( &m_ctlHour );
	
	m_ctlSpinMinute.SetRange( 0, 59 );
	m_ctlSpinMinute.SetBuddy( &m_ctlMinute );

	m_ctlSpinSecond.SetRange( 0, 59 );
	m_ctlSpinSecond.SetBuddy( &m_ctlSecond );

	// set check box value
	if ( (this->m_iRefreshHour == 0) &&
		 (this->m_iRefreshMinute == 0) && 
		 (this->m_iRefreshSecond == 0) ) {
		this->m_bNotAutoRefresh = TRUE;
	}
	else {
		this->m_bNotAutoRefresh = FALSE;
	}
	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetAutoRefreshDlg::OnCheckNotautorefresh() 
{
	// TODO: Add your control notification handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	UpdateData( TRUE );

	if ( this->m_bNotAutoRefresh ) {
		this->m_iRefreshHour	= 0;
		this->m_iRefreshMinute	= 0;
		this->m_iRefreshSecond	= 0;
	}
	else {
		this->m_iRefreshHour	= 1;
		this->m_iRefreshMinute	= 0;
		this->m_iRefreshSecond	= 0;
	}

	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CSetAutoRefreshDlg::OnChangeEditHour() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	UpdateData( TRUE );

	if ( ( this->m_iRefreshHour		== 0 ) &&
		 ( this->m_iRefreshMinute	== 0 ) &&
		 ( this->m_iRefreshSecond	== 0 ) ) {
		this->m_bNotAutoRefresh = TRUE;
	}
	else {
		this->m_bNotAutoRefresh = FALSE;
	}

	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CSetAutoRefreshDlg::OnChangeEditMinute() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	UpdateData( TRUE );

	if ( ( this->m_iRefreshHour		== 0 ) &&
		 ( this->m_iRefreshMinute	== 0 ) &&
		 ( this->m_iRefreshSecond	== 0 ) ) {
		this->m_bNotAutoRefresh = TRUE;
	}
	else {
		this->m_bNotAutoRefresh = FALSE;
	}

	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CSetAutoRefreshDlg::OnChangeEditSecond() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	UpdateData( TRUE );

	if ( ( this->m_iRefreshHour		== 0 ) &&
		 ( this->m_iRefreshMinute	== 0 ) &&
		 ( this->m_iRefreshSecond	== 0 ) ) {
		this->m_bNotAutoRefresh = TRUE;
	}
	else {
		this->m_bNotAutoRefresh = FALSE;
	}

	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}
