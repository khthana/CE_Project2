// PropSnmpPage.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropSnmpPage.h"

///////////////////////////
// MY INCLUDE START HERE
///////////////////////////
#include "Redirect.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropSnmpPage property page

IMPLEMENT_DYNCREATE(CPropSnmpPage, CPropertyPage)

CPropSnmpPage::CPropSnmpPage() : CPropertyPage(CPropSnmpPage::IDD)
{
	//{{AFX_DATA_INIT(CPropSnmpPage)
	m_snmp = _T("");
	//}}AFX_DATA_INIT
}

CPropSnmpPage::~CPropSnmpPage()
{
}

void CPropSnmpPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropSnmpPage)
	DDX_Control(pDX, IDC_TREE_MIB, m_ctree);
	DDX_Text(pDX, IDC_EDIT_VALUE, m_snmp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropSnmpPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPropSnmpPage)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_MIB, OnSelchangedTreeMib)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropSnmpPage message handlers

BOOL CPropSnmpPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	if ( m_pHost->IsStatus( ) && m_pHost->IsSnmp( ) ) {
		TV_INSERTSTRUCT insert;
		HTREEITEM htreeitem;

		CImageList *img;
		CBitmap bmp;
		CString buf;
		CString m_edit2;
	
		CString temp;
		CString variable;
		CString value;
		CString OID[8];
		OID[0] = "system.sysDescr.0";
		OID[1] = "system.sysServices.0";
		OID[2] = "system.sysName.0";
		OID[3] = "system.sysLocation.0";
		OID[4] = "system.sysContact.0";
		OID[5] = "system.sysUpTime.0";
		OID[6] = "server.svShareTable.svShareEntry.svShareName.0";
		OID[7] = "interfaces.ifNumber.0";
	
		CString Time,day,hour,minute,second;
		char TimeTmp[5];
		int inttime,intday,inthour,intminute,intsecond;
		
		buf = ".\\bin\\snmputil\\checksnmp.exe get " + nIP + " public " + OID[0];
		CRedirect Redirect(buf, &m_edit2);
		Redirect.Run();
		temp = m_edit2;
		if (temp.Find("error")==-1)
		{
			m_edit2 = "";
			for(int i=0;i<8;i++)
			{
				int start;
				int stop;
				buf = ".\\bin\\snmputil\\snmputil.exe get " + nIP + " public " + OID[i];
				CRedirect Redirect(buf, &m_edit2);
				Redirect.Run();
	
				temp = m_edit2;
				start = temp.Find("Variable",0);
				stop = temp.Find("Value",start);
				variable = temp.Mid(start+11,stop-(start+11));
			
				start = temp.Find("Value",0);
				start = temp.Find("= ",start);
				start = temp.Find(" ",start+2);
				stop = temp.Find("\n",start);
				snmp[i]="";
				snmp[i] = temp.Mid(start+1,stop-(start+1));
				m_edit2 = "";
				if(i == 5)
				{
					inttime = atoi(snmp[5]);
					intday = inttime/8640000;
					inttime = inttime%8640000;
					inthour = inttime/360000;
					inttime = inttime%360000;
					intminute = inttime/6000;
					inttime = inttime%6000;
					intsecond = inttime/100;
					day = itoa(intday,TimeTmp,10);
					hour = itoa(inthour,TimeTmp,10);
					minute = itoa(intminute,TimeTmp,10);
					second = itoa(intsecond,TimeTmp,10);
					snmp[5] = day+" days "+hour+" hours "+minute+" minutes "+second+" seconds ";
				}
			}
		}
		else
		{
			MessageBox("SNMP can not query","SNMP Error",MB_ICONERROR);
			return TRUE;
		}
		img=new CImageList();
		img->Create(20,20,ILC_MASK,5,0);

		bmp.LoadBitmap(IDB_BITMAP_SNMP1);
		img->Add(&bmp,RGB(255,255,255));
		bmp.DeleteObject();

		bmp.LoadBitmap(IDB_BITMAP_SNMP2);
		img->Add(&bmp,RGB(255,255,255));
		bmp.DeleteObject();
	
		m_ctree.SetImageList(img,TVSIL_NORMAL);
	
		
		insert.hParent=NULL;
		insert.hInsertAfter=TVI_LAST;
		insert.item.mask=TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_TEXT;
		insert.item.iImage=0;
		insert.item.iSelectedImage=0;
		insert.item.pszText="System";
		htreeitem=m_ctree.InsertItem(&insert);
	
		insert.hParent=htreeitem;
		insert.item.iImage=1;
		insert.item.iSelectedImage=1;
		LPTSTR ptr;
		for(int i=0;i<7;i++)
		{
			ptr=OID[i].LockBuffer();
			insert.item.pszText=ptr;
			OID[i].UnlockBuffer();
			if(i==5)
				htreeitem=m_ctree.InsertItem(&insert);
			else
				m_ctree.InsertItem(&insert);
		}
	
		insert.hParent=NULL;
		insert.hInsertAfter=TVI_LAST;
		insert.item.mask=TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_TEXT;
		insert.item.iImage=0;
		insert.item.iSelectedImage=0;
		insert.item.pszText="Interfaces";
		htreeitem=m_ctree.InsertItem(&insert);
	
		insert.hParent=htreeitem;
		insert.item.iImage=1;
		insert.item.iSelectedImage=1;
		insert.item.pszText="interfaces.ifNumber.0";
		htreeitem=m_ctree.InsertItem(&insert);
	
		m_ctree.Expand(htreeitem,TVE_EXPAND);
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropSnmpPage::OnSelchangedTreeMib(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	HTREEITEM htreeitem;
	CString buf;
	htreeitem = m_ctree.GetSelectedItem();
	buf=m_ctree.GetItemText(htreeitem);
	if(buf=="system.sysDescr.0")
		m_snmp=snmp[0];
	else if(buf=="system.sysServices.0")
		m_snmp=snmp[1];
	else if(buf=="system.sysName.0")
		m_snmp=snmp[2];
	else if(buf=="system.sysLocation.0")
		m_snmp=snmp[3];
	else if(buf=="system.sysContact.0")
		m_snmp=snmp[4];
	else if(buf=="system.sysUpTime.0")
		m_snmp=snmp[5];
	else if(buf=="server.svShareTable.svShareEntry.svShareName.0")
		m_snmp=snmp[6];
	else if(buf=="interfaces.ifNumber.0")
		m_snmp=snmp[7];
	else
		m_snmp="";
	UpdateData(FALSE);
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	*pResult = 0;
}
