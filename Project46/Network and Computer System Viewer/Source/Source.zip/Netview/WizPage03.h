#if !defined(AFX_WIZPAGE03_H__B7C1F4E0_F52C_4567_885B_C0EE885A9D4B__INCLUDED_)
#define AFX_WIZPAGE03_H__B7C1F4E0_F52C_4567_885B_C0EE885A9D4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WizPage03.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWizPage03 dialog

class CWizPage03 : public CPropertyPage
{
	DECLARE_DYNCREATE(CWizPage03)

// Construction
public:
	CStringArray m_saTrojan;
	CStringArray m_saPortName;
	CStringArray m_saProtocol;
	CStringArray m_saPortNumber;
	CWizPage03();
	~CWizPage03();

// Dialog Data
	//{{AFX_DATA(CWizPage03)
	enum { IDD = IDD_WIZPAGE03 };
	CListCtrl	m_ctlListService;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizPage03)
	public:
	virtual BOOL OnSetActive();
	virtual BOOL OnQueryCancel();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWizPage03)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnButtonAddservice();
	afx_msg void OnButtonRemoveservice();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIZPAGE03_H__B7C1F4E0_F52C_4567_885B_C0EE885A9D4B__INCLUDED_)
