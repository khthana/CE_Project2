// PropHostPage.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropHostPage.h"

/////////////////////////
// MY INCLUDE START HERE
/////////////////////////
#include "DaoMACVendorSet.h"
/////////////////////////
// MY INCLUDE END HERE
/////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropHostPage property page

IMPLEMENT_DYNCREATE(CPropHostPage, CPropertyPage)

CPropHostPage::CPropHostPage() : CPropertyPage(CPropHostPage::IDD)
{
	//{{AFX_DATA_INIT(CPropHostPage)
	m_strCloseTime = _T("");
	m_strHostName = _T("");
	m_strLockoutDuration = _T("");
	m_strLockoutReset = _T("");
	m_strLockoutThreshold = _T("");
	m_strOpenTime = _T("");
	m_strOS = _T("");
	m_strPasswordMaxAge = _T("");
	m_strPasswordMinAge = _T("");
	m_strPasswordMinLength = _T("");
	m_strType = _T("");
	//}}AFX_DATA_INIT
}

CPropHostPage::~CPropHostPage()
{
}

void CPropHostPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropHostPage)
	DDX_Control(pDX, IDC_LIST_MAC, m_ctlListMac);
	DDX_Control(pDX, IDC_IPADDRESS_HOST, m_ctlIPAddressHost);
	DDX_Control(pDX, IDC_STATIC_GENERAL, m_ctlGeneral);
	DDX_Control(pDX, IDC_STATIC_SECURITY, m_ctlSecurity);
	DDX_Control(pDX, IDC_STATIC_MAC, m_ctlMac);
	DDX_Text(pDX, IDC_EDIT_CLOSETIME, m_strCloseTime);
	DDX_Text(pDX, IDC_EDIT_HOSTNAME, m_strHostName);
	DDX_Text(pDX, IDC_EDIT_LOCKOUTDURATION, m_strLockoutDuration);
	DDX_Text(pDX, IDC_EDIT_LOCKOUTRESET, m_strLockoutReset);
	DDX_Text(pDX, IDC_EDIT_LOCKOUTTHRESHOLD, m_strLockoutThreshold);
	DDX_Text(pDX, IDC_EDIT_OPENTIME, m_strOpenTime);
	DDX_Text(pDX, IDC_EDIT_OS, m_strOS);
	DDX_Text(pDX, IDC_EDIT_PASSWORDMAXAGE, m_strPasswordMaxAge);
	DDX_Text(pDX, IDC_EDIT_PASSWORDMINAGE, m_strPasswordMinAge);
	DDX_Text(pDX, IDC_EDIT_PASSWORDMINLENGTH, m_strPasswordMinLength);
	DDX_Text(pDX, IDC_EDIT_TYPE, m_strType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropHostPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPropHostPage)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropHostPage message handlers

BOOL CPropHostPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_fontTitle.CreateFont( 14, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, 
							DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
							CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
							DEFAULT_PITCH | FF_SWISS, "Arial" );

	// Set IP Address
	this->m_ctlIPAddressHost.SetWindowText( this->m_strIP );

	//-------------------------------------------
	// Set Mac Address
	//-------------------------------------------
	LV_COLUMN lvColumn;
	LV_ITEM lvItem;
	CString strMacAddress;
	CString strMacFindVendor;
	CString strMacVendor;
	CString strSQL;
	char *cMacAddress;
	char *cMacVendor;
	BOOL bFirstLoop = TRUE;
	int i, iMacSize;
	CDaoMACVendorSet *pDaoMACVendorSet;

	//-----------------------------------------------------
	// Insert Column to List Control
	//	MAC Address | Vender Network Interface Card	
	//-----------------------------------------------------
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt = LVCFMT_CENTER;

	lvColumn.pszText = "MAC Address";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 110;
	m_ctlListMac.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Vender Network Interface Card";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 255;
	m_ctlListMac.InsertColumn( 1, &lvColumn );
	//-----------------------------------------------------
	// Insert Column to List Control
	//	MAC Address | Vender Network Interface Card	
	//-----------------------------------------------------

	//------------------------------------------------------------
	// Set value to column
	//	XX:XX:XX:XX:XX:XX	|	Cisco Co't
	//------------------------------------------------------------
	iMacSize = this->m_saMacAddress.GetSize( );
	for ( i=0; i<iMacSize; i++ ) {
		strMacAddress = m_saMacAddress.GetAt( i );
		
		// open database and find MAC Vendor
		if ( !strMacAddress.IsEmpty( ) ) {
			strMacFindVendor = strMacAddress.Left( 8 );
		}
		// create SQL command
		strSQL = "SELECT VendorMAC,VendorName FROM MACVendor ";
		strSQL += "WHERE VendorMAC='";
		strSQL += strMacFindVendor;
		strSQL += "'";
		pDaoMACVendorSet = new CDaoMACVendorSet( );
		if ( pDaoMACVendorSet->IsOpen( ) ) {
			pDaoMACVendorSet->Close( );
		}
		pDaoMACVendorSet->Open( dbOpenDynaset, _T( strSQL ) );
		if ( !pDaoMACVendorSet->IsEOF( ) ) {
			pDaoMACVendorSet->MoveFirst( );
			strMacVendor = ""; // reset for new Mac Vendor
			while ( !pDaoMACVendorSet->IsEOF( ) ) {
				if ( bFirstLoop ) {
					strMacVendor = pDaoMACVendorSet->m_VendorName;
					bFirstLoop = FALSE;
				}
				else {
					strMacVendor += " ,";
					strMacVendor += pDaoMACVendorSet->m_VendorName;
				}
				pDaoMACVendorSet->MoveNext( );
			}
			bFirstLoop = TRUE; // reset for next Mac Address
		}
		else {
			strMacVendor = "Unknown vendor network interface card";
		}
		pDaoMACVendorSet->Close( );
		delete pDaoMACVendorSet;	

		// set in row in list
		cMacAddress	= strMacAddress.GetBuffer( 255 );
		cMacVendor	= strMacVendor.GetBuffer( 255 );
		lvItem.mask		= LVIF_TEXT;
		lvItem.iItem	= i;
		lvItem.iSubItem = 0;
		lvItem.pszText	= cMacAddress;
		m_ctlListMac.InsertItem( &lvItem );
		lvItem.iSubItem = 1;
		lvItem.pszText	= cMacVendor;
		m_ctlListMac.SetItem( &lvItem );
	}
	//------------------------------------------------------------
	// Set value to column
	//	XX:XX:XX:XX:XX:XX	|	Cisco Co't
	//------------------------------------------------------------

	//-------------------------------------------
	// Set Mac Address
	//-------------------------------------------
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropHostPage::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_ctlGeneral.SetFont( &m_fontTitle );
	m_ctlMac.SetFont( &m_fontTitle );
	m_ctlSecurity.SetFont( &m_fontTitle );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
	
	// Do not call CPropertyPage::OnPaint() for painting messages
}
