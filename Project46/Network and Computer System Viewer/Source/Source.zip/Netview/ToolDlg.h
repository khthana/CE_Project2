#if !defined(AFX_TOOLDLG_H__0C616176_D95F_4A3B_B1C7_9DDCEF2DC155__INCLUDED_)
#define AFX_TOOLDLG_H__0C616176_D95F_4A3B_B1C7_9DDCEF2DC155__INCLUDED_

#include "Host.h"	// Added by ClassView
#include "Discover.h"	// Added by ClassView
#include "Tool.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToolDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CToolDlg dialog

class CToolDlg : public CDialog
{
// Construction
public:
	BOOL m_bFirst;
	CTool *m_pTool;
	CHost *m_pHostDisplay;
	CDiscover *m_pDiscover;
	CString m_strToolName;
	CToolDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CToolDlg)
	enum { IDD = IDD_DIALOG_TOOL };
	CButton	m_ctlClose;
	CButton	m_ctlStart;
	CIPAddressCtrl	m_ctlIPAddressTool;
	CComboBox	m_ctlToolName;
	CString	m_strParameter;
	CString	m_strResult;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CToolDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonStart();
	afx_msg void OnPaint();
	afx_msg void OnSelchangeComboToolname();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLDLG_H__0C616176_D95F_4A3B_B1C7_9DDCEF2DC155__INCLUDED_)
