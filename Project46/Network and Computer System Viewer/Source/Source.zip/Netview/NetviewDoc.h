// NetviewDoc.h : interface of the CNetviewDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETVIEWDOC_H__D93A8C5C_D00E_4CB4_B2B5_DE44669D22F1__INCLUDED_)
#define AFX_NETVIEWDOC_H__D93A8C5C_D00E_4CB4_B2B5_DE44669D22F1__INCLUDED_

#include "Discover.h"	// Added by ClassView
#include "TypeScanport.h"	// Added by ClassView
#include "Network.h"	// Added by ClassView
#include "Host.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNetviewDoc : public CDocument
{
protected: // create from serialization only
	CNetviewDoc();
	DECLARE_DYNCREATE(CNetviewDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetviewDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	void RefreshExplorer( );
	void ClearPortData( );
	void SetNetworkContext(CNetwork *pNetworkContext);
	CNetwork* GetNetworkContext();
	CHost* GetHostDisplay( );
	void SetHostDisplay( CHost *pHostDisplay );
	CNetwork* GetNetworkDisplay( );
	void SetNetworkDisplay( CNetwork *pNetworkDisplay );
	CNetworkArray* GetNetworks( );
	CDiscover* GetDiscover( );
	virtual ~CNetviewDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CString DotToSlash( CString strDot );

// Generated message map functions
protected:
	void SortHost( CHostArray *pHosts );
	CString CheckLocal(CString Localhost,CString Subnet);
	void TestLocalNetwork( );
	CNetwork *m_pNetworkContext;
	CHost *m_pHostDisplay; // Host which display host property in CNetviewView(Host View)
	CNetwork *m_pNetworkDisplay; // Network which display host in CNetviewView(Host View)
	STVECTOR MatchIPRange(CString IPStart, CString IPEnd, CString Netmask);
	STVECTOR MatchAgentIP(STVECTOR Agent,STVECTOR Network,CString Netmask);
	void IPAddrToInt(CString IP,int* intip);
	STVECTOR DivideHostRange(CString IPStart, CString IPEnd, CString Netmask);
	STVECTOR DivideNetworkRange(CString IPStart, CString IPEnd, CString Netmask);
	CDiscover m_Discover;
	//{{AFX_MSG(CNetviewDoc)
	afx_msg void OnToolsCustomizeTool();
	afx_msg void OnToolsTool1();
	afx_msg void OnToolsTool2();
	afx_msg void OnToolsTool3();
	afx_msg void OnToolsTool4();
	afx_msg void OnToolsTool5();
	afx_msg void OnToolsTool6();
	afx_msg void OnToolsTool7();
	afx_msg void OnToolsTool8();
	afx_msg void OnToolsTool9();
	afx_msg void OnToolsTool10();
	afx_msg void OnUpdateToolsTool1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool3(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool4(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool5(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool6(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool7(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool8(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool9(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsTool10(CCmdUI* pCmdUI);
	afx_msg void OnReportComputerReport();
	afx_msg void OnReportComputerAvailiableReport();
	afx_msg void OnReportNetworkAvailiableReport();
	afx_msg void OnReportComputerSecurityReport();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETVIEWDOC_H__D93A8C5C_D00E_4CB4_B2B5_DE44669D22F1__INCLUDED_)
