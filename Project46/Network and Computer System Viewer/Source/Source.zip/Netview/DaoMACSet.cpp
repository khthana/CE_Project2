// DaoMACSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoMACSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoMACSet

IMPLEMENT_DYNAMIC(CDaoMACSet, CDaoRecordset)

CDaoMACSet::CDaoMACSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoMACSet)
	m_IP = _T("");
	m_MACAddress = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoMACSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoMACSet::GetDefaultSQL()
{
	return _T("[MAC]");
}

void CDaoMACSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoMACSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[MACAddress]"), m_MACAddress);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoMACSet diagnostics

#ifdef _DEBUG
void CDaoMACSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoMACSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
