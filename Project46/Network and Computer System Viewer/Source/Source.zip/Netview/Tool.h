// Tool.h: interface for the CTool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOOL_H__E784E35D_DA26_4AA8_921C_10879EB578C7__INCLUDED_)
#define AFX_TOOL_H__E784E35D_DA26_4AA8_921C_10879EB578C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTool  
{
public:
	CString GetParameter( );
	CString GetToolPath( );
	CString GetToolName( );
	CTool( CString strToolName, CString strToolPath, CString strParameter );
	virtual ~CTool();

	CString m_strToolPath;
private:
	CString m_strToolName;
protected:
	CString m_strParameter;
	//CString m_strToolPath;
};

#endif // !defined(AFX_TOOL_H__E784E35D_DA26_4AA8_921C_10879EB578C7__INCLUDED_)
