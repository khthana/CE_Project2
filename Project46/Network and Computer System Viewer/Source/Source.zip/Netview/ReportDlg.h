#if !defined(AFX_REPORTDLG_H__EA12CAEA_3E13_4550_AE09_C4A9057D6481__INCLUDED_)
#define AFX_REPORTDLG_H__EA12CAEA_3E13_4550_AE09_C4A9057D6481__INCLUDED_

#include "Discover.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReportDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReportDlg dialog

class CReportDlg : public CDialog
{
// Construction
public:
	CDiscover *m_pDiscover;
	int m_iReportType;
	// Report Type
	//  0 = Default (No show report) 
	//  1 = Computer Report
	//  2 = Computer Availiable Report
	//  3 = Network Avialiable Report
	//  4 = Computer Security Report
	CReportDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CReportDlg)
	enum { IDD = IDD_DIALOG_REPORT };
	CEdit	m_ctlReport;
	CString	m_strReport;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetPrintComputerSecurityReport(CDC *pDC, int &y, HDC hdcPrn);
	void SetPrintNetworkAvailiableReport(CDC *pDC, int &y);
	void SetPrintComputerReport(CDC *pDC, int &y, HDC hdcPrn);
	void SetPrintComputerAvailiableReport(CDC *pDC, int &y);
	void SetPrintReportTitle(CDC *pDC,int &y);
	void SetPrintReportPage( CDC *pDC, HDC hdcPrn );
	void SetPrintAlign(CDC *pDC, HDC hdcPrn);
	CString GetTimeString( COleDateTime time );
	CString GetDateString( COleDateTime time );
	COleDateTime m_timePresent;
	CFont m_fontReport;
	CString DoHeader( );
	CString DoComputerSecurityReport( );
	CString DoNetworkAvialiableReport( );
	CString DoComputerAvailiableReport( );
	CString DoComputerReport( );

	// Generated message map functions
	//{{AFX_MSG(CReportDlg)
	afx_msg void OnReportfileSaveAs();
	afx_msg void OnReportfilePrint();
	afx_msg void OnReportfileClose();
	afx_msg void OnReporteditCopy();
	afx_msg void OnReporteditSelectAll();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTDLG_H__EA12CAEA_3E13_4550_AE09_C4A9057D6481__INCLUDED_)
