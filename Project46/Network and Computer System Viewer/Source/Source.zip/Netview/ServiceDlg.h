#if !defined(AFX_SERVICEDLG_H__4C5B06BA_3BB5_467B_87F7_8457960CE6C9__INCLUDED_)
#define AFX_SERVICEDLG_H__4C5B06BA_3BB5_467B_87F7_8457960CE6C9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ServiceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CServiceDlg dialog

class CServiceDlg : public CDialog
{
// Construction
public:
	CServiceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CServiceDlg)
	enum { IDD = IDD_DIALOG_SERVICE };
	BOOL	m_bTrojanPort;
	CString	m_strEndPort;
	CString	m_strStartPort;
	CString	m_strPortBanner;
	int		m_iCatagory;
	int		m_iProtocal;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServiceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CServiceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadioSingleport();
	afx_msg void OnRadioRangeport();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVICEDLG_H__4C5B06BA_3BB5_467B_87F7_8457960CE6C9__INCLUDED_)
