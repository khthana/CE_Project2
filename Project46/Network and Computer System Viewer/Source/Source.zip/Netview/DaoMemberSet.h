#if !defined(AFX_DAOMEMBERSET_H__2BF0CF4A_8835_47BE_9913_E79212B42F9F__INCLUDED_)
#define AFX_DAOMEMBERSET_H__2BF0CF4A_8835_47BE_9913_E79212B42F9F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoMemberSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoMemberSet DAO recordset

class CDaoMemberSet : public CDaoRecordset
{
public:
	CDaoMemberSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoMemberSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoMemberSet, CDaoRecordset)
	CString	m_IP;
	CString	m_GroupName;
	CString	m_UserName;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoMemberSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOMEMBERSET_H__2BF0CF4A_8835_47BE_9913_E79212B42F9F__INCLUDED_)
