# Microsoft Developer Studio Project File - Name="Netview" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=Netview - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "Netview.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Netview.mak" CFG="Netview - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Netview - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Netview - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Netview - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# SUBTRACT CPP /WX
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "Netview - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "Netview - Win32 Release"
# Name "Netview - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\AddToolDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\AgentIPDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ChildFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoAgentSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoGroupSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoHasPortSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoHostSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoInNetworkSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoMACSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoMACVendorSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoMemberSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoNetworkSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoPortSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoShareSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoUserSet.cpp
# End Source File
# Begin Source File

SOURCE=.\DaoUseVendorSet.cpp
# End Source File
# Begin Source File

SOURCE=.\Discover.cpp
# End Source File
# Begin Source File

SOURCE=.\FileManip.cpp
# End Source File
# Begin Source File

SOURCE=.\Group.cpp
# End Source File
# Begin Source File

SOURCE=.\HelpDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\Host.cpp
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\MrtgDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\Netview.cpp
# End Source File
# Begin Source File

SOURCE=.\Netview.rc
# End Source File
# Begin Source File

SOURCE=.\NetviewDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\NetviewView.cpp
# End Source File
# Begin Source File

SOURCE=.\Network.cpp
# End Source File
# Begin Source File

SOURCE=.\NetworkView.cpp
# End Source File
# Begin Source File

SOURCE=.\Port.cpp
# End Source File
# Begin Source File

SOURCE=.\PropHostPage.cpp
# End Source File
# Begin Source File

SOURCE=.\PropHostSheet.cpp
# End Source File
# Begin Source File

SOURCE=.\PropPortPage.cpp
# End Source File
# Begin Source File

SOURCE=.\PropSharePage.cpp
# End Source File
# Begin Source File

SOURCE=.\PropSnmpPage.cpp
# End Source File
# Begin Source File

SOURCE=.\PropUserAndGroupPage.cpp
# End Source File
# Begin Source File

SOURCE=.\Redirect.cpp
# End Source File
# Begin Source File

SOURCE=.\ReportDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ServiceDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\SetAutoRefreshDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\Share.cpp
# End Source File
# Begin Source File

SOURCE=.\SnmpDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\Tool.cpp
# End Source File
# Begin Source File

SOURCE=.\ToolDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\User.cpp
# End Source File
# Begin Source File

SOURCE=.\WaitDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\WizPage01.cpp
# End Source File
# Begin Source File

SOURCE=.\WizPage02.cpp
# End Source File
# Begin Source File

SOURCE=.\WizPage03.cpp
# End Source File
# Begin Source File

SOURCE=.\WizSheet.cpp
# End Source File
# Begin Source File

SOURCE=.\WWaitTarget.cpp
# End Source File
# Begin Source File

SOURCE=.\WWaitThread.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\AddToolDlg.h
# End Source File
# Begin Source File

SOURCE=.\AgentIPDlg.h
# End Source File
# Begin Source File

SOURCE=.\ChildFrm.h
# End Source File
# Begin Source File

SOURCE=.\DaoAgentSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoGroupSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoHasPortSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoHostSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoInNetworkSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoMACSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoMACVendorSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoMemberSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoNetworkSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoPortSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoShareSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoUserSet.h
# End Source File
# Begin Source File

SOURCE=.\DaoUseVendorSet.h
# End Source File
# Begin Source File

SOURCE=.\Discover.h
# End Source File
# Begin Source File

SOURCE=.\FileManip.h
# End Source File
# Begin Source File

SOURCE=.\Group.h
# End Source File
# Begin Source File

SOURCE=.\HelpDlg.h
# End Source File
# Begin Source File

SOURCE=.\Host.h
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\MrtgDlg.h
# End Source File
# Begin Source File

SOURCE=.\Netview.h
# End Source File
# Begin Source File

SOURCE=.\NetviewDoc.h
# End Source File
# Begin Source File

SOURCE=.\NetviewView.h
# End Source File
# Begin Source File

SOURCE=.\Network.h
# End Source File
# Begin Source File

SOURCE=.\NetworkView.h
# End Source File
# Begin Source File

SOURCE=.\Port.h
# End Source File
# Begin Source File

SOURCE=.\PropHostPage.h
# End Source File
# Begin Source File

SOURCE=.\PropHostSheet.h
# End Source File
# Begin Source File

SOURCE=.\PropPortPage.h
# End Source File
# Begin Source File

SOURCE=.\PropSharePage.h
# End Source File
# Begin Source File

SOURCE=.\PropSnmpPage.h
# End Source File
# Begin Source File

SOURCE=.\PropUserAndGroupPage.h
# End Source File
# Begin Source File

SOURCE=.\Redirect.h
# End Source File
# Begin Source File

SOURCE=.\ReportDlg.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\ServiceDlg.h
# End Source File
# Begin Source File

SOURCE=.\SetAutoRefreshDlg.h
# End Source File
# Begin Source File

SOURCE=.\Share.h
# End Source File
# Begin Source File

SOURCE=.\SnmpDlg.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\Tool.h
# End Source File
# Begin Source File

SOURCE=.\ToolDlg.h
# End Source File
# Begin Source File

SOURCE=.\TypeGroupArray.h
# End Source File
# Begin Source File

SOURCE=.\TypeHostArray.h
# End Source File
# Begin Source File

SOURCE=.\TypeNetworkArray.h
# End Source File
# Begin Source File

SOURCE=.\TypePortArray.h
# End Source File
# Begin Source File

SOURCE=.\TypeScanport.h
# End Source File
# Begin Source File

SOURCE=.\TypeShareArray.h
# End Source File
# Begin Source File

SOURCE=.\TypeToolArray.h
# End Source File
# Begin Source File

SOURCE=.\TypeUserArray.h
# End Source File
# Begin Source File

SOURCE=.\User.h
# End Source File
# Begin Source File

SOURCE=.\WaitDlg.h
# End Source File
# Begin Source File

SOURCE=.\WizPage01.h
# End Source File
# Begin Source File

SOURCE=.\WizPage02.h
# End Source File
# Begin Source File

SOURCE=.\WizPage03.h
# End Source File
# Begin Source File

SOURCE=.\WizSheet.h
# End Source File
# Begin Source File

SOURCE=.\WWaitTarget.h
# End Source File
# Begin Source File

SOURCE=.\WWaitThread.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\Images\about.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\bitmap1.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\general.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\h01.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\h02.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\h03.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\h04.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\h05.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\host.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostClose.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostGame.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostGameSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostTrojan.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostTrojanGame.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostTrojanGameSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\hostTrojanSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\res\ico00001.ico
# End Source File
# Begin Source File

SOURCE=.\res\ico00002.ico
# End Source File
# Begin Source File

SOURCE=.\res\icon1.ico
# End Source File
# Begin Source File

SOURCE=.\Images\NET13.ICO
# End Source File
# Begin Source File

SOURCE=.\res\Netview.ico
# End Source File
# Begin Source File

SOURCE=.\res\Netview.rc2
# End Source File
# Begin Source File

SOURCE=.\res\NetviewDoc.ico
# End Source File
# Begin Source File

SOURCE=.\Images\network.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\networkClose.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\nw01.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\nw02.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\printer.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\printerSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\router.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\routerSNMP.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\Snmp1.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\Snmp2.bmp
# End Source File
# Begin Source File

SOURCE=.\res\Toolbar.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\wizard.bmp
# End Source File
# Begin Source File

SOURCE=.\Images\WRENCH.ICO
# End Source File
# End Group
# Begin Source File

SOURCE=.\Netview.reg
# End Source File
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
