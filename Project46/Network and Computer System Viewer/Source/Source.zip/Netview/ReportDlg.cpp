// ReportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "ReportDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportDlg dialog


CReportDlg::CReportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReportDlg)
	m_strReport = _T("");
	//}}AFX_DATA_INIT

	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	this->m_iReportType = 0;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}


void CReportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReportDlg)
	DDX_Control(pDX, IDC_EDIT_REPORT, m_ctlReport);
	DDX_Text(pDX, IDC_EDIT_REPORT, m_strReport);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReportDlg, CDialog)
	//{{AFX_MSG_MAP(CReportDlg)
	ON_COMMAND(ID_REPORTFILE_SAVE_AS, OnReportfileSaveAs)
	ON_COMMAND(ID_REPORTFILE_PRINT, OnReportfilePrint)
	ON_COMMAND(ID_REPORTFILE_CLOSE, OnReportfileClose)
	ON_COMMAND(ID_REPORTEDIT_COPY, OnReporteditCopy)
	ON_COMMAND(ID_REPORTEDIT_SELECT_ALL, OnReporteditSelectAll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportDlg message handlers

void CReportDlg::OnReportfileSaveAs() 
{
	// TODO: Add your command handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CFileDialog *pSave;
	CStdioFile *pFileHandle;

	char filter[ ] = "Text File (*.txt)|*.txt|Data File (*.dat)|*.dat|All File (*.*)|*.*||"; 
	pSave = new CFileDialog( FALSE, 
							 "txt",
							 NULL,
							 NULL,
							 filter );
	if ( pSave->DoModal( ) == IDOK ) {
		pFileHandle = new CStdioFile( pSave->GetPathName( ), 
									  CFile::modeCreate | CFile::modeWrite );
		// get text from Edit control
		UpdateData( TRUE );
		pFileHandle->WriteString( m_strReport );

		// close file and clear memory
		pFileHandle->Close( );
		delete pFileHandle;

		// set default path
		CNetviewApp *pNetviewApp = (CNetviewApp*)::AfxGetApp( );
		::SetCurrentDirectory( pNetviewApp->m_strStartingDirectory );
	}
	delete pSave;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CReportDlg::OnReportfilePrint() 
{
	// TODO: Add your command handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
    HDC    hdcPrn ;

    // Instantiate a CPrintDialog.
    CPrintDialog *printDlg =
        new CPrintDialog(FALSE, PD_ALLPAGES | PD_RETURNDC, NULL);

    // Initialize some of the fields in PRINTDLG structure.
    printDlg->m_pd.nMinPage = printDlg->m_pd.nMaxPage = 1;
    printDlg->m_pd.nFromPage = printDlg->m_pd.nToPage = 10;

    // Display Windows print dialog box.
    printDlg->DoModal();

    // Obtain a handle to the device context.
    hdcPrn = printDlg->GetPrinterDC();
    if (hdcPrn != NULL) {
		CDC *pDC = new CDC;
        pDC->Attach (hdcPrn);      // attach a printer DC

        pDC->StartDoc("Netview Report");  // begin a new print job
										  // for Win32 use
										  // CDC::StartDoc(LPDOCINFO) override

		//----------------------------------------------
		// Print for each page
		//----------------------------------------------
        pDC->StartPage();					// begin a new page
        SetPrintAlign(pDC, hdcPrn);			// set the printing alignment
		SetPrintReportPage( pDC, hdcPrn );	// set page format to print
        pDC->EndPage();						// end a page
		//----------------------------------------------
		// Print for each page
		//----------------------------------------------

        pDC->EndDoc();             // end a print job

        pDC->Detach();             // detach the printer DC
        delete pDC;
	}

    delete printDlg;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set page alignment
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  hdcPrn(IN)>>	Context Device Handle's pointer
//
void CReportDlg::SetPrintAlign(CDC *pDC, HDC hdcPrn)
{
	/////////////////////////////
	// MY CODE START HERE
	/////////////////////////////
	short cxPage, cyPage;

    cxPage = ::GetDeviceCaps (hdcPrn, HORZRES) ;
    cyPage = ::GetDeviceCaps (hdcPrn, VERTRES) ;
    pDC->SetMapMode (MM_ISOTROPIC) ;
    pDC->SetWindowExt ( 1000, 1000) ;
    pDC->SetViewportExt (cxPage / 2, -cyPage / 2) ;
    pDC->SetViewportOrg (cxPage / 2, cyPage - (cyPage-600)) ;
    pDC->SetTextAlign (TA_BASELINE | TA_CENTER) ;
	/////////////////////////////
	// MY CODE END HERE
	/////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  hdcPrn(IN)>>	Context Device Handle's pointer
//
void CReportDlg::SetPrintReportPage(CDC *pDC, HDC hdcPrn)
{
	/////////////////////////////
	// MY CODE START HERE
	/////////////////////////////
	int y = 10;	// position for each line

	SetPrintReportTitle( pDC, y );	// print title

	//--------------------------------------
	// Report Type (m_iReportType)
	//  0 = Default (No show report) 
	//  1 = Computer Report
	//  2 = Computer Availiable Report
	//  3 = Network Avialiable Report
	//  4 = Computer Security Report
	if ( m_iReportType == 1 ) {
		this->SetPrintComputerReport( pDC, y, hdcPrn);
	}
	else if ( m_iReportType == 2 ) {
		this->SetPrintComputerAvailiableReport( pDC, y );
	}
	else if ( m_iReportType == 3 ) {
		this->SetPrintNetworkAvailiableReport( pDC, y );
	}
	else if ( m_iReportType == 4 ) {
		this->SetPrintComputerSecurityReport( pDC, y, hdcPrn );
	}
	else {
		// do nothing
	}
	/////////////////////////////
	// MY CODE END HERE
	/////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw title report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CReportDlg::SetPrintReportTitle(CDC *pDC, int &y )
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontTitle;
	int iLineH;			// Height for each line
	CString strHeader;
	CString strStartDate, strPresentDate, strPresentTime, strDayOfWeek;
	COleDateTime timeStart;
	int iDayOfWeek;

	//------------------------------------
	// AngsanaUPC font with Bold and Underline style for Title
	fontTitle.CreateFont( 100, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
						  ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						  DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						  "AngsanaUPC" );
	pDC->SelectObject( &fontTitle );

	//------------------------------------
	// get start time
	timeStart = m_pDiscover->GetStartTime( );
	strStartDate = this->GetDateString( timeStart );

	//------------------------------------
	// get present time
	iDayOfWeek = m_timePresent.GetDayOfWeek( );
	switch ( iDayOfWeek ) {
	case 1 : strDayOfWeek = "�ѹ�ҷԵ��";	break;
	case 2 : strDayOfWeek = "�ѹ�ѹ���";	break;
	case 3 : strDayOfWeek = "�ѹ�ѧ���";	break;
	case 4 : strDayOfWeek = "�ѹ�ظ";		break;
	case 5 : strDayOfWeek = "�ѹ����ʺ��";	break;
	case 6 : strDayOfWeek = "�ѹ�ء��";		break;
	case 7 : strDayOfWeek = "�ѹ�����";		break;
	}
	strPresentDate = this->GetDateString( m_timePresent );
	strPresentTime = this->GetTimeString( m_timePresent );

	//------------------------------
	// Line 1
	//------------------------------
	// Prepare Title String 
	strHeader =  "Isagview46  ";
	//--------------------------------------
	// Report Type (m_iReportType)
	//  0 = Default (No show report) 
	//  1 = Computer Report
	//  2 = Computer Availiable Report
	//  3 = Network Avialiable Report
	//  4 = Computer Security Report
	if      ( m_iReportType == 1 ) strHeader += "Computer Report";
	else if ( m_iReportType == 2 ) strHeader += "Computer Availiable Report";
	else if ( m_iReportType == 3 ) strHeader += "Network Avialiable Report";
	else if ( m_iReportType == 4 ) strHeader += "Computer Security Report";
	else						   strHeader += " ";
	//--------------------------------------

	// Title for report line 1
	pDC->TextOut( 10, y, strHeader );	

	// Retrieves the matrics for using the current font
	pDC->GetTextMetrics( &metrics );
	iLineH = metrics.tmHeight + metrics.tmExternalLeading;
	y -= iLineH; // update line position
	//------------------------------
	// Line 1
	//------------------------------

	//------------------------------
	// Line 2
	//------------------------------
	// Prepare Title String 
	strHeader =  "Period: ";
	strHeader += strPresentDate;
	strHeader += " to ";
	strHeader += strStartDate;

	// Title for report line 2
	pDC->TextOut( 10, y, strHeader );	
	y -= iLineH; // update line position
	//------------------------------
	// Line 2
	//------------------------------

	//------------------------------
	// Line 3
	//------------------------------
	// Prepare Title String 
	strHeader =  "Report Date: "; 
	strHeader += strDayOfWeek;
	strHeader += " ";
	strHeader += strPresentDate;
	strHeader += " ";
	strHeader += strPresentTime;

	// Title for report line 2
	pDC->TextOut( 10, y, strHeader );	
	y -= iLineH; // update line position
	//------------------------------
	// Line 3
	//------------------------------	

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw Computer Availiable Report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CReportDlg::SetPrintComputerAvailiableReport(CDC *pDC, int &y)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontHeading;
	CFont fontBody;
	int iLineH;			// Height for each line

	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strTimeOpen, strTimeClose;
	CString strTimeTotal;
	COleDateTime	timeOpen, timeClose, timeStart;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	int i, j;
	int iSizeHost, iSizeNetwork;
	// Date
	int iOpenYear,		iOpenMonth,		iOpenDay;
	int iCloseYear,		iCloseMonth,	iCloseDay;
	int iPresentYear,	iPresentMonth,	iPresentDay;
	int iStartYear,		iStartMonth,	iStartDay;
	int iTotalYear,		iTotalMonth,	iTotalDay;
	// Time
	int iOpenHour,		iOpenMinute,	iOpenSecond;
	int iCloseHour,		iCloseMinute,	iCloseSecond;
	int iPresentHour,	iPresentMinute,	iPresentSecond;
	int iStartHour,		iStartMinute,	iStartSecond;
	int iTotalHour,		iTotalMinute,	iTotalSecond;
	
	// Arial font with Bold and Underline style for Headings
	fontHeading.CreateFont( 60, 0, 0, 0, FW_BOLD, FALSE, TRUE, 0,
							ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
							"Arial" );

	// AngsanaUPC font with Normal and Underline style for Body(Detail)
	fontBody.CreateFont( 80, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
						 ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						 DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						 "AngsanaUPC" );

	pDC->SelectObject( &fontHeading );
	timeStart = m_pDiscover->GetStartTime( );
	//---------------------------------------------------------------------------------
	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		//---------------------------
		// show network addr line 1
		//---------------------------
		strReport =	 "Network :: ";
		strReport += strNetworkAddress;
		pDC->TextOut( 10, y, strReport );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position

		//---------------------------
		// show network addr line 2
		//---------------------------
		strReport = "  IP Address Host Name        Open Time          Close Time                      Total Open Time              ";
		pDC->TextOut( 10, y, strReport );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position

		//---------------------------------------------------------------------------------
		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			timeOpen	= pHost->GetOpenTime( );
			timeClose	= pHost->GetCloseTime( );
			
			// convert time to string
			strTimeOpen		=  this->GetDateString( timeOpen );
			strTimeOpen		+= " ";
			strTimeOpen		+= this->GetTimeString( timeOpen );
			strTimeClose	=  this->GetDateString( timeClose );
			strTimeClose	+= " ";
			strTimeClose	+= this->GetTimeString( timeClose );
			
			//-----------------------
			// find total time 
			//-----------------------
			iCloseYear	= timeClose.GetYear( );
			iCloseMonth	= timeClose.GetMonth( );
			iCloseDay	= timeClose.GetDay( );
			iCloseHour	= timeClose.GetHour( );
			iCloseMinute= timeClose.GetMinute( );
			iCloseSecond= timeClose.GetSecond( );
			// if host close
			if ( !pHost->IsStatus( ) ) {
				// get open time
				iOpenYear	= timeOpen.GetYear( );
				iOpenMonth	= timeOpen.GetMonth( );
				iOpenDay	= timeOpen.GetDay( );
				iOpenHour	= timeOpen.GetHour( );
				iOpenMinute	= timeOpen.GetMinute( );
				iOpenSecond = timeOpen.GetSecond( );

				// Total Time = Close Time - Open Time
				iTotalYear		= iCloseYear   - iOpenYear;
				iTotalMonth		= iCloseMonth  - iOpenMonth;
				iTotalDay		= iCloseDay	   - iOpenDay;
				iTotalHour		= iCloseHour   - iOpenHour;
				iTotalMinute	= iCloseMinute - iOpenMinute;
				iTotalSecond	= iCloseSecond - iOpenSecond;
			}
			// if host open and not have close's time
			else if ( pHost->IsStatus( ) && 
					  (iCloseYear==1900) && 
				      (iCloseMonth==1)   && 
					  (iCloseDay==1)     &&
					  (iCloseHour==0)	 && 
					  (iCloseMinute==0)	 && 
					  (iCloseSecond==0)	) {
				// get present time
				iPresentYear	= m_timePresent.GetYear( );
				iPresentMonth	= m_timePresent.GetMonth( );
				iPresentDay		= m_timePresent.GetDay( );
				iPresentHour	= m_timePresent.GetHour( );
				iPresentMinute	= m_timePresent.GetMinute( );
				iPresentSecond	= m_timePresent.GetSecond( );

				// get start time
				iStartYear	= timeStart.GetYear( );
				iStartMonth	= timeStart.GetMonth( );
				iStartDay	= timeStart.GetDay( );
				iStartHour	= timeStart.GetHour( );
				iStartMinute= timeStart.GetMinute( );
				iStartSecond= timeStart.GetSecond( );
			
				// Total Time = Present Time - Start Time
				iTotalYear		= iPresentYear   - iStartYear;
				iTotalMonth		= iPresentMonth  - iStartMonth;
				iTotalDay		= iPresentDay	 - iStartDay;
				iTotalHour		= iPresentHour   - iStartHour;
				iTotalMinute	= iPresentMinute - iStartMinute;
				iTotalSecond	= iPresentSecond - iStartSecond;
			}
			// if host open and have close's time
			else {
				// get present time
				iPresentYear	= m_timePresent.GetYear( );
				iPresentMonth	= m_timePresent.GetMonth( );
				iPresentDay		= m_timePresent.GetDay( );
				iPresentHour	= m_timePresent.GetHour( );
				iPresentMinute	= m_timePresent.GetMinute( );
				iPresentSecond	= m_timePresent.GetSecond( );

				// get open time
				iOpenYear	= timeOpen.GetYear( );
				iOpenMonth	= timeOpen.GetMonth( );
				iOpenDay	= timeOpen.GetDay( );
				iOpenHour	= timeOpen.GetHour( );
				iOpenMinute	= timeOpen.GetMinute( );
				iOpenSecond = timeOpen.GetSecond( );

				// Total Time = Present Time - Open Time
				iTotalYear		= iPresentYear   - iOpenYear;
				iTotalMonth		= iPresentMonth  - iOpenMonth;
				iTotalDay		= iPresentDay	   - iOpenDay;
				iTotalHour		= iPresentHour   - iOpenHour;
				iTotalMinute	= iPresentMinute - iOpenMinute;
				iTotalSecond	= iPresentSecond - iOpenSecond;
			}
			strTimeTotal.Format( "%i Years, %i Months, %i Days, %i Hours, %i Minutes, %i Second",
								 iTotalYear,
								 iTotalMonth,
								 iTotalDay,
								 iTotalHour,
								 iTotalMinute,
								 iTotalSecond );
			//-----------------------
			// find total time 
			//-----------------------

			// show host
			strReport  = "     ";
			strReport += strIP;
			strReport += "   ";
			strReport += strHostName;
			strReport += "   ";
			strReport += strTimeOpen;
			strReport += "   ";
			strReport += strTimeClose;
			strReport += "   ";
			strReport += strTimeTotal;
			
			pDC->SelectObject( &fontBody );
			pDC->TextOut( 10, y, strReport );
			// Retrieves the matrics for using the current font
			pDC->GetTextMetrics( &metrics );
			iLineH = metrics.tmHeight + metrics.tmExternalLeading;
			y -= iLineH; // update line position
		}
	}
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw Network Avialiable Report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CReportDlg::SetPrintNetworkAvailiableReport(CDC *pDC, int &y)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontHeading;
	CFont fontBody;
	int iLineH;			// Height for each line

	CString strReport;
	CString strNetworkAddress;
	CString strTimeConnect, strTimeDisconnect;
	CString strTimeTotal;
	COleDateTime	timeConnect, timeDisconnect, timeStart;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	int i;
	int iSizeNetwork;
	// Date
	int iConnectYear,	iConnectMonth,	iConnectDay;
	int iDisconnectYear, iDisconnectMonth, iDisconnectDay;
	int iPresentYear,	iPresentMonth,	iPresentDay;
	int iStartYear,		iStartMonth,	iStartDay;
	int iTotalYear,		iTotalMonth,	iTotalDay;
	// Time
	int iConnectHour,	iConnectMinute,	iConnectSecond;
	int iDisconnectHour, iDisconnectMinute,	iDisconnectSecond;
	int iPresentHour,	iPresentMinute,	iPresentSecond;
	int iStartHour,		iStartMinute,	iStartSecond;
	int iTotalHour,		iTotalMinute,	iTotalSecond;

	// Arial font with Bold and Underline style for Headings
	fontHeading.CreateFont( 60, 0, 0, 0, FW_BOLD, FALSE, TRUE, 0,
							ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
							"Arial" );

	// AngsanaUPC font with Normal and Underline style for Body(Detail)
	fontBody.CreateFont( 80, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
						 ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						 DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						 "AngsanaUPC" );

	pDC->SelectObject( &fontHeading );
	timeStart = m_pDiscover->GetStartTime( );
	
	//--------------------------
	// show head table
	//--------------------------
	strReport = "Network Address    Connect Time    Disconnect Time            Total Open Time             ";
	pDC->TextOut( 10, y, strReport );
	// Retrieves the matrics for using the current font
	pDC->GetTextMetrics( &metrics );
	iLineH = metrics.tmHeight + metrics.tmExternalLeading;
	y -= iLineH; // update line position

	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress	= pNetwork->GetNetworkAddress( );
		timeConnect			= pNetwork->GetConnectTime( );
		timeDisconnect		= pNetwork->GetDisconnectTime( );
			
		// convert time to string
		strTimeConnect		=  this->GetDateString( timeConnect );
		strTimeConnect		+= " ";
		strTimeConnect		+= this->GetTimeString( timeConnect );
		strTimeDisconnect	=  this->GetDateString( timeDisconnect );
		strTimeDisconnect	+= " ";
		strTimeDisconnect	+= this->GetTimeString( timeDisconnect );
			
		//-----------------------
		// find total time 
		//-----------------------
		iDisconnectYear		= timeDisconnect.GetYear( );
		iDisconnectMonth	= timeDisconnect.GetMonth( );
		iDisconnectDay		= timeDisconnect.GetDay( );
		iDisconnectHour		= timeDisconnect.GetHour( );
		iDisconnectMinute	= timeDisconnect.GetMinute( );
		iDisconnectSecond	= timeDisconnect.GetSecond( );
		// if network disconnect
		if ( !pNetwork->IsConnect( ) ) {
			// get open time
			iConnectYear	= timeConnect.GetYear( );
			iConnectMonth	= timeConnect.GetMonth( );
			iConnectDay		= timeConnect.GetDay( );
			iConnectHour	= timeConnect.GetHour( );
			iConnectMinute	= timeConnect.GetMinute( );
			iConnectSecond	= timeConnect.GetSecond( );

			// Total Time = Disconnect Time - Connect Time
			iTotalYear		= iDisconnectYear   - iConnectYear;
			iTotalMonth		= iDisconnectMonth  - iConnectMonth;
			iTotalDay		= iDisconnectDay	- iConnectDay;
			iTotalHour		= iDisconnectHour   - iConnectHour;
			iTotalMinute	= iDisconnectMinute - iConnectMinute;
			iTotalSecond	= iDisconnectSecond - iConnectSecond;
		}
		// if host open and not have close's time
		else if ( pNetwork->IsConnect( )	&& 
				  (iDisconnectYear==1900)	&& 
			      (iDisconnectMonth==1)		&& 
				  (iDisconnectDay==1)		&&
				  (iDisconnectHour==0)		&& 
				  (iDisconnectMinute==0)	&& 
				  (iDisconnectSecond==0)	) {
			// get present time
			iPresentYear	= m_timePresent.GetYear( );
			iPresentMonth	= m_timePresent.GetMonth( );
			iPresentDay		= m_timePresent.GetDay( );
			iPresentHour	= m_timePresent.GetHour( );
			iPresentMinute	= m_timePresent.GetMinute( );
			iPresentSecond	= m_timePresent.GetSecond( );
				
			// get start time
			iStartYear	= timeStart.GetYear( );
			iStartMonth	= timeStart.GetMonth( );
			iStartDay	= timeStart.GetDay( );
			iStartHour	= timeStart.GetHour( );
			iStartMinute= timeStart.GetMinute( );
			iStartSecond= timeStart.GetSecond( );
			
			// Total Time = Present Time - Start Time
			iTotalYear		= iPresentYear   - iStartYear;
			iTotalMonth		= iPresentMonth  - iStartMonth;
			iTotalDay		= iPresentDay	 - iStartDay;
			iTotalHour		= iPresentHour   - iStartHour;
			iTotalMinute	= iPresentMinute - iStartMinute;
			iTotalSecond	= iPresentSecond - iStartSecond;
		}
		// if host open and have close's time
		else {
			// get present time
			iPresentYear	= m_timePresent.GetYear( );
			iPresentMonth	= m_timePresent.GetMonth( );
			iPresentDay		= m_timePresent.GetDay( );
			iPresentHour	= m_timePresent.GetHour( );
			iPresentMinute	= m_timePresent.GetMinute( );
			iPresentSecond	= m_timePresent.GetSecond( );
				
			// get connect time
			iConnectYear	= timeConnect.GetYear( );
			iConnectMonth	= timeConnect.GetMonth( );
			iConnectDay		= timeConnect.GetDay( );
			iConnectHour	= timeConnect.GetHour( );
			iConnectMinute	= timeConnect.GetMinute( );
			iConnectSecond	= timeConnect.GetSecond( );

			// Total Time = Present Time - Connect Time
			iTotalYear		= iPresentYear   - iConnectYear;
			iTotalMonth		= iPresentMonth  - iConnectMonth;
			iTotalDay		= iPresentDay	 - iConnectDay;
			iTotalHour		= iPresentHour   - iConnectHour;
			iTotalMinute	= iPresentMinute - iConnectMinute;
			iTotalSecond	= iPresentSecond - iConnectSecond;
		}
		strTimeTotal.Format( "%i Years, %i Months, %i Days, %i Hours, %i Minutes, %i Second",
							 iTotalYear,
							 iTotalMonth,
							 iTotalDay,
							 iTotalHour,
							 iTotalMinute,
							 iTotalSecond );
		//-----------------------
		// find total time 
		//-----------------------

		// show host
		strReport  = "    ";
		strReport += strNetworkAddress;
		strReport += "  ";
		strReport += strTimeConnect;
		strReport += "  ";
		strReport += strTimeDisconnect;
		strReport += "     ";
		strReport += strTimeTotal;

		pDC->SelectObject( &fontBody );
		pDC->TextOut( 10, y, strReport );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position
	}
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw Computer Security Report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CReportDlg::SetPrintComputerSecurityReport(CDC *pDC, int &y, HDC hdcPrn)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontHeading;
	CFont fontBody;
	int iLineH;			// Height for each line

	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strPortNumber;
	long lPortNumber;
	char cPortNumber[5];
	CString strProtocol, strPortName, strTrojan;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	CPortArray		*pPorts;
	CPort			*pPort;
	int i, j, k;
	int iSizeHost, iSizeNetwork, iSizePort;

	// Arial font with Bold and Underline style for Headings
	fontHeading.CreateFont( 40, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
							ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
							"Arial" );

	// AngsanaUPC font with Normal and Underline style for Body(Detail)
	fontBody.CreateFont( 80, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
						 ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						 DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						 "AngsanaUPC" );

	//---------------------------------------------
	// Set Alignment 
	short cxPage, cyPage;
    cxPage = ::GetDeviceCaps (hdcPrn, HORZRES) ;
    cyPage = ::GetDeviceCaps (hdcPrn, VERTRES) ;
	pDC->SetViewportExt (cxPage/2, -cyPage / 2) ;
    pDC->SetViewportOrg (cxPage/4, cyPage - (cyPage-600)) ;
	pDC->SetTextAlign (TA_BASELINE | TA_LEFT) ;

	//-----------------------------------------
	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		//---------------------------------------------------
		// Select header font and get height between line
		pDC->SelectObject( &fontHeading );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position

		// show network addr
		strReport  = "Network :: ";
		strReport += strNetworkAddress;
		pDC->TextOut( 10, y, strReport );
		y -= iLineH; // update line position

		strReport = "==============================================";
		pDC->TextOut( 10, y, strReport );
		y -= iLineH; // update line position

		strReport = "Port Number   Protocol            Port Name            Weak\r\n";
		pDC->TextOut( 10, y, strReport );
		y -= iLineH; // update line position

		strReport = "==============================================";
		pDC->TextOut( 10, y, strReport );
		y -= iLineH; // update line position
		
		//-----------------------------------------
		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			
			//--------------------
			// Select body font
			pDC->SelectObject( &fontBody );

			//------------------------------
			// show host addr and name
			//------------------------------
			strReport  = strIP;
			strReport += " (";
			strReport += strHostName;
			strReport += ")";
			pDC->TextOut( 10, y, strReport );
			// Retrieves the matrics for using the current font
			pDC->GetTextMetrics( &metrics );
			iLineH = metrics.tmHeight + metrics.tmExternalLeading;
			y -= iLineH; // update line position
			
			//-----------------------------------------
			// for each port
			pPorts = pHost->GetPorts( );
			iSizePort = pPorts->GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				pPort = pPorts->ElementAt( k );
				// show port which trojan's port OR want detect's port to report
				if ( pPort->IsTrojan( ) || pPort->IsWantDetect( ) ) {	
					lPortNumber		= pPort->GetPortNumber( );
					_ltoa( lPortNumber, cPortNumber, 10 );
					strPortNumber	= cPortNumber;
					strProtocol		= pPort->GetProtocol( );
					strPortName		= pPort->GetPortName( );
					strTrojan		= (pPort->IsTrojan( )) ? "Trojan" : "Want Detect";
					

					strReport  = "      ";
					strReport += strPortNumber;
					strReport += "     ";
					strReport += strProtocol;
					strReport += "     ";
					strReport += strPortName;
					strReport += "     ";
					strReport += strTrojan;
					strReport += "     ";
					pDC->TextOut( 10, y, strReport );
					// Retrieves the matrics for using the current font
					pDC->GetTextMetrics( &metrics );
					iLineH = metrics.tmHeight + metrics.tmExternalLeading;
					y -= iLineH; // update line position
				}
			}
		}
	}
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw Computer Report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CReportDlg::SetPrintComputerReport(CDC *pDC, int &y, HDC hdcPrn)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontHeading;
	CFont fontBody;
	int iLineH;			// Height for each line

	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strType, strOS;
	CString strGroupName;
	CStringArray *pGroupMembers;
	CString strUser;
	CString strShareName, strShareType;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	CStringArray	*pMacAddress;
	CString			strMacAddress;
	CGroupArray		*pGroups;
	CGroup			*pGroup;
	CShareArray		*pShares;
	CShare			*pShare;
	int i, j, k, l;
	int iSizeHost, iSizeNetwork;
	int iSizeMacAddress, iSizeUser, iSizeGroup, iSizeShare;

	// Arial font with Bold and Underline style for Headings
	fontHeading.CreateFont( 40, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
							ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
							DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
							"Arial" );

	// AngsanaUPC font with Normal and Underline style for Body(Detail)
	fontBody.CreateFont( 80, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
						 ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						 DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						 "AngsanaUPC" );

	//---------------------------------------------
	// Set Alignment 
	short cxPage, cyPage;
    cxPage = ::GetDeviceCaps (hdcPrn, HORZRES) ;
    cyPage = ::GetDeviceCaps (hdcPrn, VERTRES) ;
	pDC->SetViewportExt (cxPage/2, -cyPage / 2) ;
    pDC->SetViewportOrg (100, cyPage - (cyPage-600)) ;
	pDC->SetTextAlign (TA_BASELINE | TA_LEFT) ;

	//-----------------------------------------
	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		//---------------------------------------------------
		// Select header font and get height between line
		pDC->SelectObject( &fontHeading );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position
		y -= iLineH; // update line position

		// show network addr
		strReport  = "Network :: ";
		strReport += strNetworkAddress;
		pDC->TextOut( 10, y, strReport );
		y -= iLineH; // update line position

		// Select body font
		pDC->SelectObject( &fontBody );

		strReport = "==============================================";
		pDC->TextOut( 10, y, strReport );
		// Retrieves the matrics for using the current font
		pDC->GetTextMetrics( &metrics );
		iLineH = metrics.tmHeight + metrics.tmExternalLeading;
		y -= iLineH; // update line position

		//-----------------------------------------
		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			strType		= pHost->GetType( );
			strOS		= pHost->GetOS( );
			
			// Begin Host
			strReport = "=====================================================================";			
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			//-----------------------------------------
			// show host addr and name
			strReport  = "IP Address:: ";
			strReport += strIP;
			strReport += "     Host Name:: ";
			strReport += strHostName;
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			strReport  = "Type:: ";
			strReport += strType;
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			strReport  = "Operating Syatem:: ";
			strReport += strOS;
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			//-----------------------------------------
			// show for each mac address
			strReport = "Mac Address:: ";
			pMacAddress = pHost->GetMacAddress( );
			iSizeMacAddress = pMacAddress->GetSize( );
			for ( k=0; k<iSizeMacAddress; k++ ) {
				strMacAddress = pMacAddress->ElementAt( k );
				strReport += strMacAddress;
				if ( k<(iSizeMacAddress-1) ) {
					strReport += ", ";
				}
			}
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			//-----------------------------------------
			// show for each group
			strReport = "User and Group:: ";
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			pGroups = pHost->GetGroups( );
			iSizeGroup = pGroups->GetSize( );
			for ( k=0; k<iSizeGroup; k++ ) {
				pGroup = pGroups->ElementAt( k );
				strGroupName	= pGroup->GetGroupName( );
			
				strReport  = "     ";
				strReport += strGroupName;
				strReport += " >> ";

				//-----------------------------------------
				// show for each user
				pGroupMembers	= pGroup->GetGroupMembers( );
				iSizeUser = pGroupMembers->GetSize( );
				for ( l=0; l<iSizeUser; l++ ) {	
					strUser = pGroupMembers->ElementAt( l ); 
					strReport += strUser;
					if ( l<(iSizeUser-1) ) {
						strReport += ", ";
					}
				}

				pDC->TextOut( 10, y, strReport );
				y -= iLineH; // update line position
			}
			y -= iLineH; // update line position

			//-----------------------------------------
			// show for each share
			strReport = "Share:: ";
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position

			pShares = pHost->GetShares( );
			iSizeShare = pShares->GetSize( );
			for ( k=0; k<iSizeShare; k++ ) {
				pShare = pShares->ElementAt( k );
				strShareName	= pShare->GetShareName( );
				strShareType	= pShare->GetShareType( );

				strReport  = "     ";
				strReport += strShareName;
				strReport += " (";
				strReport += strShareType; 
				strReport += ")";
				pDC->TextOut( 10, y, strReport );
				y -= iLineH; // update line position
			}

			// End Host
			strReport = "=====================================================================";
			pDC->TextOut( 10, y, strReport );
			y -= iLineH; // update line position
			y -= iLineH; // update line position
		}
	}
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CReportDlg::OnReportfileClose() 
{
	// TODO: Add your command handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	OnOK( );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CReportDlg::OnReporteditCopy() 
{
	// TODO: Add your command handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_ctlReport.Copy( );
	m_ctlReport.SetFocus( );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

void CReportDlg::OnReporteditSelectAll() 
{
	// TODO: Add your command handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_ctlReport.SetSel( 0, -1, TRUE );
	m_ctlReport.SetFocus( );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

BOOL CReportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	m_timePresent = COleDateTime::GetCurrentTime( );
	m_ctlReport.SetReadOnly( TRUE );
	m_fontReport.CreateFont( 14, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, 
							 DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
							 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, 
							 DEFAULT_PITCH | FF_SWISS, "Tahoma" );
	m_ctlReport.SetFont( &m_fontReport );

	//--------------------------------------
	// Report Type (m_iReportType)
	//  0 = Default (No show report) 
	//  1 = Computer Report
	//  2 = Computer Availiable Report
	//  3 = Network Avialiable Report
	//  4 = Computer Security Report
	if ( m_iReportType == 1 ) {
		m_strReport = this->DoComputerReport( );
	}
	else if ( m_iReportType == 2 ) {
		m_strReport = this->DoComputerAvailiableReport( );
	}
	else if ( m_iReportType == 3 ) {
		m_strReport = this->DoNetworkAvialiableReport( );
	}
	else if ( m_iReportType == 4 ) {
		m_strReport = this->DoComputerSecurityReport( );
	}
	else {
		m_strReport = "";
	}
	UpdateData( FALSE );
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//////////////////////////////////////////////////////////////////////
//	Description : Create Computer Report
//	Return		: CString >> Report to show
//
CString CReportDlg::DoComputerReport()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strType, strOS;
	CString strGroupName;
	CStringArray *pGroupMembers;
	CString strUser;
	CString strShareName, strShareType;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	CStringArray	*pMacAddress;
	CString			strMacAddress;
	CGroupArray		*pGroups;
	CGroup			*pGroup;
	CShareArray		*pShares;
	CShare			*pShare;
	int i, j, k, l;
	int iSizeHost, iSizeNetwork;
	int iSizeMacAddress, iSizeUser, iSizeGroup, iSizeShare;

	strReport = this->DoHeader( ); // Header

	//-----------------------------------------
	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		// show network addr
		strReport += "\r\n\r\n";
		strReport += "Network :: ";
		strReport += strNetworkAddress;
		strReport += "\r\n";
		strReport += "==============================================";
		strReport += "\r\n";

		//-----------------------------------------
		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			strType		= pHost->GetType( );
			strOS		= pHost->GetOS( );
			
			// Begin Host
			strReport += "=====================================================================";
			strReport += "\r\n";

			//-----------------------------------------
			// show host addr and name
			strReport += "IP Address:: ";
			strReport += strIP;
			strReport += "     Host Name:: ";
			strReport += strHostName;
			strReport += "\r\n";
			strReport += "Type:: ";
			strReport += strType;
			strReport += "\r\n";
			strReport += "Operating Syatem:: ";
			strReport += strOS;
			strReport += "\r\n";

			//-----------------------------------------
			// show for each mac address
			strReport += "Mac Address:: ";
			pMacAddress = pHost->GetMacAddress( );
			iSizeMacAddress = pMacAddress->GetSize( );
			for ( k=0; k<iSizeMacAddress; k++ ) {
				strMacAddress = pMacAddress->ElementAt( k );
				strReport += strMacAddress;
				if ( k<(iSizeMacAddress-1) ) {
					strReport += ", ";
				}
			}
			strReport += "\r\n";

			//-----------------------------------------
			// show for each group
			strReport += "User and Group:: ";
			strReport += "\r\n";
			pGroups = pHost->GetGroups( );
			iSizeGroup = pGroups->GetSize( );
			for ( k=0; k<iSizeGroup; k++ ) {
				pGroup = pGroups->ElementAt( k );
				strGroupName	= pGroup->GetGroupName( );
			
				strReport += "\t";
				strReport += strGroupName;
				strReport += " >> ";

				//-----------------------------------------
				// show for each user
				pGroupMembers	= pGroup->GetGroupMembers( );
				iSizeUser = pGroupMembers->GetSize( );
				for ( l=0; l<iSizeUser; l++ ) {	
					strUser = pGroupMembers->ElementAt( l ); 
					strReport += strUser;
					if ( l<(iSizeUser-1) ) {
						strReport += ", ";
					}
				}

				strReport += "\r\n";
			}
			strReport += "\r\n";

			//-----------------------------------------
			// show for each share
			strReport += "Share:: ";
			strReport += "\r\n";
			pShares = pHost->GetShares( );
			iSizeShare = pShares->GetSize( );
			for ( k=0; k<iSizeShare; k++ ) {
				pShare = pShares->ElementAt( k );
				strShareName	= pShare->GetShareName( );
				strShareType	= pShare->GetShareType( );

				strReport += "\t";
				strReport += strShareName;
				strReport += " (";
				strReport += strShareType; 
				strReport += ")\r\n";
			}

			// End Host
			strReport += "=====================================================================";
			strReport += "\r\n";
			strReport += "\r\n";
		}
	}

	return strReport;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Create Computer Availiable Report
//	Return		: CString >> Report to show
//
CString CReportDlg::DoComputerAvailiableReport()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strTimeOpen, strTimeClose;
	CString strTimeTotal;
	COleDateTime	timeOpen, timeClose, timeStart;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	int i, j;
	int iSizeHost, iSizeNetwork;
	// Date
	int iOpenYear,		iOpenMonth,		iOpenDay;
	int iCloseYear,		iCloseMonth,	iCloseDay;
	int iPresentYear,	iPresentMonth,	iPresentDay;
	int iStartYear,		iStartMonth,	iStartDay;
	int iTotalYear,		iTotalMonth,	iTotalDay;
	// Time
	int iOpenHour,		iOpenMinute,	iOpenSecond;
	int iCloseHour,		iCloseMinute,	iCloseSecond;
	int iPresentHour,	iPresentMinute,	iPresentSecond;
	int iStartHour,		iStartMinute,	iStartSecond;
	int iTotalHour,		iTotalMinute,	iTotalSecond;

	timeStart = m_pDiscover->GetStartTime( );
	strReport = this->DoHeader( ); // Header

	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		// show network addr
		strReport += "\r\n\r\n";
		strReport += "Network :: ";
		strReport += strNetworkAddress;
		strReport += "\r\n";
		strReport += "=================================================================================================================";
		strReport += "\r\n";
		strReport += "     IP Address\t     Host Name\t\t\tOpen Time\t\tClose Time\t\t\t\tTotal Open Time\r\n";
		strReport += "=================================================================================================================";
		strReport += "\r\n";

		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			timeOpen	= pHost->GetOpenTime( );
			timeClose	= pHost->GetCloseTime( );
			
			// convert time to string
			strTimeOpen		=  this->GetDateString( timeOpen );
			strTimeOpen		+= " ";
			strTimeOpen		+= this->GetTimeString( timeOpen );
			strTimeClose	=  this->GetDateString( timeClose );
			strTimeClose	+= " ";
			strTimeClose	+= this->GetTimeString( timeClose );
			
			//-----------------------
			// find total time 
			//-----------------------
			iCloseYear	= timeClose.GetYear( );
			iCloseMonth	= timeClose.GetMonth( );
			iCloseDay	= timeClose.GetDay( );
			iCloseHour	= timeClose.GetHour( );
			iCloseMinute= timeClose.GetMinute( );
			iCloseSecond= timeClose.GetSecond( );
			// if host close
			if ( !pHost->IsStatus( ) ) {
				// get open time
				iOpenYear	= timeOpen.GetYear( );
				iOpenMonth	= timeOpen.GetMonth( );
				iOpenDay	= timeOpen.GetDay( );
				iOpenHour	= timeOpen.GetHour( );
				iOpenMinute	= timeOpen.GetMinute( );
				iOpenSecond = timeOpen.GetSecond( );

				// Total Time = Close Time - Open Time
				iTotalYear		= iCloseYear   - iOpenYear;
				iTotalMonth		= iCloseMonth  - iOpenMonth;
				iTotalDay		= iCloseDay	   - iOpenDay;
				iTotalHour		= iCloseHour   - iOpenHour;
				iTotalMinute	= iCloseMinute - iOpenMinute;
				iTotalSecond	= iCloseSecond - iOpenSecond;
			}
			// if host open and not have close's time
			else if ( pHost->IsStatus( ) && 
					  (iCloseYear==1900) && 
				      (iCloseMonth==1)   && 
					  (iCloseDay==1)     &&
					  (iCloseHour==0)	 && 
					  (iCloseMinute==0)	 && 
					  (iCloseSecond==0)	) {
				// get present time
				iPresentYear	= m_timePresent.GetYear( );
				iPresentMonth	= m_timePresent.GetMonth( );
				iPresentDay		= m_timePresent.GetDay( );
				iPresentHour	= m_timePresent.GetHour( );
				iPresentMinute	= m_timePresent.GetMinute( );
				iPresentSecond	= m_timePresent.GetSecond( );

				// get start time
				iStartYear	= timeStart.GetYear( );
				iStartMonth	= timeStart.GetMonth( );
				iStartDay	= timeStart.GetDay( );
				iStartHour	= timeStart.GetHour( );
				iStartMinute= timeStart.GetMinute( );
				iStartSecond= timeStart.GetSecond( );
			
				// Total Time = Present Time - Start Time
				iTotalYear		= iPresentYear   - iStartYear;
				iTotalMonth		= iPresentMonth  - iStartMonth;
				iTotalDay		= iPresentDay	 - iStartDay;
				iTotalHour		= iPresentHour   - iStartHour;
				iTotalMinute	= iPresentMinute - iStartMinute;
				iTotalSecond	= iPresentSecond - iStartSecond;
			}
			// if host open and have close's time
			else {
				// get present time
				iPresentYear	= m_timePresent.GetYear( );
				iPresentMonth	= m_timePresent.GetMonth( );
				iPresentDay		= m_timePresent.GetDay( );
				iPresentHour	= m_timePresent.GetHour( );
				iPresentMinute	= m_timePresent.GetMinute( );
				iPresentSecond	= m_timePresent.GetSecond( );

				// get open time
				iOpenYear	= timeOpen.GetYear( );
				iOpenMonth	= timeOpen.GetMonth( );
				iOpenDay	= timeOpen.GetDay( );
				iOpenHour	= timeOpen.GetHour( );
				iOpenMinute	= timeOpen.GetMinute( );
				iOpenSecond = timeOpen.GetSecond( );

				// Total Time = Present Time - Open Time
				iTotalYear		= iPresentYear   - iOpenYear;
				iTotalMonth		= iPresentMonth  - iOpenMonth;
				iTotalDay		= iPresentDay	   - iOpenDay;
				iTotalHour		= iPresentHour   - iOpenHour;
				iTotalMinute	= iPresentMinute - iOpenMinute;
				iTotalSecond	= iPresentSecond - iOpenSecond;
			}
			strTimeTotal.Format( "%i Years, %i Months, %i Days, %i Hours, %i Minutes, %i Second",
								 iTotalYear,
								 iTotalMonth,
								 iTotalDay,
								 iTotalHour,
								 iTotalMinute,
								 iTotalSecond );
			//-----------------------
			// find total time 
			//-----------------------

			// show host
			strReport += "   ";
			strReport += strIP;
			strReport += "\t";
			strReport += strHostName;
			strReport += "\t";
			strReport += strTimeOpen;
			strReport += "\t    ";
			strReport += strTimeClose;
			strReport += "\t";
			strReport += strTimeTotal;
			strReport += "\r\n";
		}
	}

	return strReport;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Create Network Avialiable Report
//	Return		: CString >> Report to show
//
CString CReportDlg::DoNetworkAvialiableReport()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strReport;
	CString strNetworkAddress;
	CString strTimeConnect, strTimeDisconnect;
	CString strTimeTotal;
	COleDateTime	timeConnect, timeDisconnect, timeStart;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	int i;
	int iSizeNetwork;
	// Date
	int iConnectYear,	iConnectMonth,	iConnectDay;
	int iDisconnectYear, iDisconnectMonth, iDisconnectDay;
	int iPresentYear,	iPresentMonth,	iPresentDay;
	int iStartYear,		iStartMonth,	iStartDay;
	int iTotalYear,		iTotalMonth,	iTotalDay;
	// Time
	int iConnectHour,	iConnectMinute,	iConnectSecond;
	int iDisconnectHour, iDisconnectMinute,	iDisconnectSecond;
	int iPresentHour,	iPresentMinute,	iPresentSecond;
	int iStartHour,		iStartMinute,	iStartSecond;
	int iTotalHour,		iTotalMinute,	iTotalSecond;

	timeStart = m_pDiscover->GetStartTime( );
	strReport = this->DoHeader( ); // Header

	// head table
	strReport += "\r\n\r\n";
	strReport += "=======================================================================================================================";
	strReport += "\r\n";
	strReport += "   Network Address\t\t\tConnect Time\t\tDisconnect Time\t\t\t\tTotal Open Time\r\n";
	strReport += "=======================================================================================================================";
	strReport += "\r\n";

	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress	= pNetwork->GetNetworkAddress( );
		timeConnect			= pNetwork->GetConnectTime( );
		timeDisconnect		= pNetwork->GetDisconnectTime( );
			
		// convert time to string
		strTimeConnect		=  this->GetDateString( timeConnect );
		strTimeConnect		+= " ";
		strTimeConnect		+= this->GetTimeString( timeConnect );
		strTimeDisconnect	=  this->GetDateString( timeDisconnect );
		strTimeDisconnect	+= " ";
		strTimeDisconnect	+= this->GetTimeString( timeDisconnect );
			
		//-----------------------
		// find total time 
		//-----------------------
		iDisconnectYear		= timeDisconnect.GetYear( );
		iDisconnectMonth	= timeDisconnect.GetMonth( );
		iDisconnectDay		= timeDisconnect.GetDay( );
		iDisconnectHour		= timeDisconnect.GetHour( );
		iDisconnectMinute	= timeDisconnect.GetMinute( );
		iDisconnectSecond	= timeDisconnect.GetSecond( );
		// if network disconnect
		if ( !pNetwork->IsConnect( ) ) {
			// get open time
			iConnectYear	= timeConnect.GetYear( );
			iConnectMonth	= timeConnect.GetMonth( );
			iConnectDay		= timeConnect.GetDay( );
			iConnectHour	= timeConnect.GetHour( );
			iConnectMinute	= timeConnect.GetMinute( );
			iConnectSecond	= timeConnect.GetSecond( );

			// Total Time = Disconnect Time - Connect Time
			iTotalYear		= iDisconnectYear   - iConnectYear;
			iTotalMonth		= iDisconnectMonth  - iConnectMonth;
			iTotalDay		= iDisconnectDay	- iConnectDay;
			iTotalHour		= iDisconnectHour   - iConnectHour;
			iTotalMinute	= iDisconnectMinute - iConnectMinute;
			iTotalSecond	= iDisconnectSecond - iConnectSecond;
		}
		// if host open and not have close's time
		else if ( pNetwork->IsConnect( )	&& 
				  (iDisconnectYear==1900)	&& 
			      (iDisconnectMonth==1)		&& 
				  (iDisconnectDay==1)		&&
				  (iDisconnectHour==0)		&& 
				  (iDisconnectMinute==0)	&& 
				  (iDisconnectSecond==0)	) {
			// get present time
			iPresentYear	= m_timePresent.GetYear( );
			iPresentMonth	= m_timePresent.GetMonth( );
			iPresentDay		= m_timePresent.GetDay( );
			iPresentHour	= m_timePresent.GetHour( );
			iPresentMinute	= m_timePresent.GetMinute( );
			iPresentSecond	= m_timePresent.GetSecond( );
				
			// get start time
			iStartYear	= timeStart.GetYear( );
			iStartMonth	= timeStart.GetMonth( );
			iStartDay	= timeStart.GetDay( );
			iStartHour	= timeStart.GetHour( );
			iStartMinute= timeStart.GetMinute( );
			iStartSecond= timeStart.GetSecond( );
			
			// Total Time = Present Time - Start Time
			iTotalYear		= iPresentYear   - iStartYear;
			iTotalMonth		= iPresentMonth  - iStartMonth;
			iTotalDay		= iPresentDay	 - iStartDay;
			iTotalHour		= iPresentHour   - iStartHour;
			iTotalMinute	= iPresentMinute - iStartMinute;
			iTotalSecond	= iPresentSecond - iStartSecond;
		}
		// if host open and have close's time
		else {
			// get present time
			iPresentYear	= m_timePresent.GetYear( );
			iPresentMonth	= m_timePresent.GetMonth( );
			iPresentDay		= m_timePresent.GetDay( );
			iPresentHour	= m_timePresent.GetHour( );
			iPresentMinute	= m_timePresent.GetMinute( );
			iPresentSecond	= m_timePresent.GetSecond( );
				
			// get connect time
			iConnectYear	= timeConnect.GetYear( );
			iConnectMonth	= timeConnect.GetMonth( );
			iConnectDay		= timeConnect.GetDay( );
			iConnectHour	= timeConnect.GetHour( );
			iConnectMinute	= timeConnect.GetMinute( );
			iConnectSecond	= timeConnect.GetSecond( );

			// Total Time = Present Time - Connect Time
			iTotalYear		= iPresentYear   - iConnectYear;
			iTotalMonth		= iPresentMonth  - iConnectMonth;
			iTotalDay		= iPresentDay	 - iConnectDay;
			iTotalHour		= iPresentHour   - iConnectHour;
			iTotalMinute	= iPresentMinute - iConnectMinute;
			iTotalSecond	= iPresentSecond - iConnectSecond;
		}
		strTimeTotal.Format( "%i Years, %i Months, %i Days, %i Hours, %i Minutes, %i Second",
							 iTotalYear,
							 iTotalMonth,
							 iTotalDay,
							 iTotalHour,
							 iTotalMinute,
							 iTotalSecond );
		//-----------------------
		// find total time 
		//-----------------------

		// show host
		strReport += "   ";
		strReport += strNetworkAddress;
		strReport += "\t";
		strReport += strTimeConnect;
		strReport += "\t    ";
		strReport += strTimeDisconnect;
		strReport += "\t\t\t";
		strReport += strTimeTotal;
		strReport += "\r\n";
	}
	return strReport;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Create Computer Security Report
//	Return		: CString >> Report to show
//
CString CReportDlg::DoComputerSecurityReport()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strReport;
	CString strNetworkAddress;
	CString strIP, strHostName;
	CString strPortNumber;
	long lPortNumber;
	char cPortNumber[5];
	CString strProtocol, strPortName, strTrojan;
	CNetworkArray	*pNetworks;
	CNetwork		*pNetwork;
	CHostArray		*pHosts;
	CHost			*pHost;
	CPortArray		*pPorts;
	CPort			*pPort;
	int i, j, k;
	int iSizeHost, iSizeNetwork, iSizePort;

	strReport = this->DoHeader( ); // Header

	//-----------------------------------------
	// for each network
	pNetworks = m_pDiscover->GetNetworks( );
	iSizeNetwork = pNetworks->GetSize( );
	for ( i=0; i<iSizeNetwork; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		strNetworkAddress = pNetwork->GetNetworkAddress( );

		// show network addr
		strReport += "\r\n\r\n";
		strReport += "Network :: ";
		strReport += strNetworkAddress;
		strReport += "\r\n";
		strReport += "==============================================";
		strReport += "\r\n";
		strReport += "Port Number   Protocol            Port Name                 Weak\r\n";
		strReport += "==============================================";
		strReport += "\r\n";

		//-----------------------------------------
		// for each host
		pHosts = pNetwork->GetHostArray( );
		iSizeHost = pHosts->GetSize( );
		for ( j=0; j<iSizeHost; j++ ) {
			pHost = pHosts->ElementAt( j );
			strIP		= pHost->GetIP( );
			strHostName = pHost->GetHostName( );
			
			// show host addr and name
			strReport += strIP;
			strReport += " (";
			strReport += strHostName;
			strReport += ")";
			strReport += "\r\n";

			//-----------------------------------------
			// for each port
			pPorts = pHost->GetPorts( );
			iSizePort = pPorts->GetSize( );
			for ( k=0; k<iSizePort; k++ ) {
				pPort = pPorts->ElementAt( k );
				// show port which trojan's port OR want detect's port to report
				if ( pPort->IsTrojan( ) || pPort->IsWantDetect( ) ) {	
					lPortNumber		= pPort->GetPortNumber( );
					_ltoa( lPortNumber, cPortNumber, 10 );
					strPortNumber	= cPortNumber;
					strProtocol		= pPort->GetProtocol( );
					strPortName		= pPort->GetPortName( );
					strTrojan		= (pPort->IsTrojan( )) ? "Trojan" : "Want Detect";
					
					strReport += "      ";
					strReport += strPortNumber;
					strReport += "\t\t";
					strReport += strProtocol;
					strReport += "\t\t";
					strReport += strPortName;
					strReport += "\t\t";
					strReport += strTrojan;
					strReport += "\r\n";
				}
			}
		}
	}

	return strReport;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Create Header Report
//	Return		: CString >> Header report to show
//
CString CReportDlg::DoHeader()
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strHeader;
	CString strStartDate, strPresentDate, strPresentTime, strDayOfWeek;
	COleDateTime timeStart;
	int iDayOfWeek;
	
	//------------------------
	// get start time
	//------------------------
	timeStart = m_pDiscover->GetStartTime( );
	strStartDate = this->GetDateString( timeStart );
	//------------------------
	// get start time
	//------------------------

	//------------------------
	// get present time
	//------------------------
	iDayOfWeek = m_timePresent.GetDayOfWeek( );
	switch ( iDayOfWeek ) {
	case 1 : strDayOfWeek = "�ѹ�ҷԵ��";	break;
	case 2 : strDayOfWeek = "�ѹ�ѹ���";	break;
	case 3 : strDayOfWeek = "�ѹ�ѧ���";	break;
	case 4 : strDayOfWeek = "�ѹ�ظ";		break;
	case 5 : strDayOfWeek = "�ѹ����ʺ��";	break;
	case 6 : strDayOfWeek = "�ѹ�ء��";		break;
	case 7 : strDayOfWeek = "�ѹ�����";		break;
	}
	strPresentDate = this->GetDateString( m_timePresent );
	strPresentTime = this->GetTimeString( m_timePresent );
	//------------------------
	// get present time
	//------------------------ 

	// Header
	strHeader =  "\t\t\t\tIsagview46  ";
	//--------------------------------------
	// Report Type (m_iReportType)
	//  0 = Default (No show report) 
	//  1 = Computer Report
	//  2 = Computer Availiable Report
	//  3 = Network Avialiable Report
	//  4 = Computer Security Report
	if      ( m_iReportType == 1 ) strHeader += "Computer Report";
	else if ( m_iReportType == 2 ) strHeader += "Computer Availiable Report";
	else if ( m_iReportType == 3 ) strHeader += "Network Avialiable Report";
	else if ( m_iReportType == 4 ) strHeader += "Computer Security Report";
	else						   strHeader += " ";
	//--------------------------------------
	strHeader += "\r\n";
	strHeader += "\t\t\t\tPeriod: ";
	strHeader += strPresentDate;
	strHeader += " to ";
	strHeader += strStartDate;
	strHeader += "\r\n";
	strHeader += "\t\t\t\tReport Date: "; 
	strHeader += strDayOfWeek;
	strHeader += " ";
	strHeader += strPresentDate;
	strHeader += " ";
	strHeader += strPresentTime;
	strHeader += "\r\n";

	return strHeader;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Convert date to string
//	Return		: CString >> Date string
//
CString CReportDlg::GetDateString(COleDateTime time)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strDate;
	int iDay, iMonth, iYear;
	char *cMonth;

	iDay	= time.GetDay( );
	iMonth	= time.GetMonth( );
	iYear	= time.GetYear( );
	
	if ( (iYear==1900) && (iMonth==1) && (iDay==1) ) {
		strDate = "                         ";
		return strDate;
	}
	
	// select thai month
	switch ( iMonth ) {
	case 1  : cMonth = "���Ҥ�"; break;
	case 2  : cMonth = "����Ҿѹ��"; break;
	case 3  : cMonth = "�չҤ�"; break;
	case 4  : cMonth = "����¹"; break;
	case 5  : cMonth = "����Ҥ�"; break;
	case 6  : cMonth = "�Զع�¹"; break;
	case 7  : cMonth = "�á�Ҥ�"; break;
	case 8  : cMonth = "�ԧ�Ҥ�"; break;
	case 9  : cMonth = "�ѹ��¹"; break;
	case 10 : cMonth = "���Ҥ�"; break;
	case 11 : cMonth = "��Ȩԡ�¹"; break;
	case 12 : cMonth = "�ѹ�Ҥ�"; break;
	default : cMonth = "";
	}
	iYear = iYear + 543;
	strDate.Format( "%i %s, %i", iDay, cMonth, iYear ); 

	return strDate;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Convert time to string
//	Return		: CString >> Time string
//
CString CReportDlg::GetTimeString(COleDateTime time)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strTime;
	int iHour, iMinute, iSecond;

	iHour	= time.GetHour( );
	iMinute	= time.GetMinute( );
	iSecond	= time.GetSecond( );
	strTime.Format( "%02i:%02i:%02i", iHour, iMinute, iSecond ); 

	return strTime;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}
