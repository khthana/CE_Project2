// Discover.h: interface for the CDiscover class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DISCOVER_H__DC2723D7_201F_42D5_B6A3_E0BE25650D86__INCLUDED_)
#define AFX_DISCOVER_H__DC2723D7_201F_42D5_B6A3_E0BE25650D86__INCLUDED_

#include "TypeToolArray.h"	// Added by ClassView
#include "TypeNetworkArray.h"	// Added by ClassView
#include "TypeScanport.h"	// Added by ClassView
#include "Redirect.h"	// Added by ClassView
#include "TypeThreadArray.h"	// Added by ClassView
#include "TypePortArray.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////
// MY CODE START HERE
/////////////////////////
UINT ThreadPingSweepFunc(LPVOID pParam);
UINT ThreadScanPortFunc(LPVOID pParam);
UINT ThreadArpFunc(LPVOID pParam);
UINT ThreadNullSessionFunc(LPVOID pParam);
/////////////////////////
// MY CODE END HERE
/////////////////////////

class CDiscover  
{
public:
	COleDateTime GetStartTime( );
	void StoreDB( );
	CToolArray* GetTools( );
	int FindTool( CString strToolName );
	void AddTool( CString strToolName, CString strToolPath, CString strParameter = "%a" );
	void ClearAgentBmp( );
	void SetAgentFirstMRTG( );
	void ScanNullSession( );
	void SetHostStatus( );
	void SendArpLocal( );
	int FindWantDetectPort(long lPortNumber, CString strProtocol);
	int FindTrojanPort(long lPortNumber, CString strProtocol);
	CString m_strInternet;
	void SetNetworkStatus();
	void UpdatePortData( );
	void AddAgentIP( int iNetworkPosition, CString strAgentIP );
	void ScanPort( );
	CNetworkArray* GetNetworks( );
	void Explorer( );
	void PingSweep( );
	void AddNetwork( CString strNetworkAddress, CString strSubnet );
	CDiscover();
	virtual ~CDiscover();

	int m_iDiscoveryType;
	CStringArray m_saAgentIP;
	CString m_strNetmask;
	CString m_strIPEnd;
	CString m_strIPStart;
	CStringArray m_saTrojan;
	CStringArray m_saPortName;
	CStringArray m_saProtocol;
	CStringArray m_saPortNumber;
protected:
	COleDateTime m_timeStart;
	CToolArray m_taTools;
	void ClearEachAgentBmp( CString AgentIP );
	void SetEachAgentTransactionMRTG( CString AgentIP );
	void SetEachAgentFirstMRTG( CString AgentIP );
	void ScanPortUDPResult( );
	void ScanPortUDP( );
	void ScanPortTCP( );
	void ScanPortTCPResult( );
	void FindDetailUDPInHost(struct scanport *data,CString strTemp1);
	void FindDetailTCPInHost(struct scanport *data,CString strTemp);
	void AddWantDetectPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect);
	void AddTrojanPort( long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect );
	CPortArray m_paWantDetectPorts;
	CPortArray m_paTrojanPorts;
	void FindDetailInHost(struct scanport *data,CString strTemp,CString strTemp1);
	STVECTOR FindHostInNetwork( CString strTemp );
	CNetworkArray m_naNetworks;
};

#endif // !defined(AFX_DISCOVER_H__DC2723D7_201F_42D5_B6A3_E0BE25650D86__INCLUDED_)
