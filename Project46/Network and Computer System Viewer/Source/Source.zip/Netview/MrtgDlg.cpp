// MrtgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "MrtgDlg.h"

///////////////////////////
// MY INCLUDE START HERE 
///////////////////////////
#include "FileManip.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMrtgDlg dialog


CMrtgDlg::CMrtgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMrtgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMrtgDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMrtgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMrtgDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMrtgDlg, CDialog)
	//{{AFX_MSG_MAP(CMrtgDlg)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_PRINT, OnButtonPrint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMrtgDlg message handlers

CMrtgDlg::~CMrtgDlg()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CFileManip::Del(this->m_Path+"*.bak",TRUE);
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

BOOL CMrtgDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-day.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-week.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-month.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-year.png",SW_HIDE);
	Sleep(1000);
	SetTimer(ID_CLOCK_TIMER,300000,NULL);
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMrtgDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	Output(&dc);
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
	
	// Do not call CDialog::OnPaint() for painting messages
}

void CMrtgDlg::Output(CPaintDC *dc)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString Text;
	HBITMAP hBitmap;
	CMrtgDlg* lpWnd;
	BITMAP bm;
	CDC dcMem;
	CBitmap* pOldBitmap;
	CRect lRect;
	//Get Current Time sir
	CTime CurTime = CTime::GetCurrentTime();
	int year = CurTime.GetYear();
	int month = CurTime.GetMonth();
	int date = CurTime.GetDay();
	int dow = CurTime.GetDayOfWeek();
	int hour = CurTime.GetHour();
	int minute = CurTime.GetMinute();
	CString syear,smonth,sdate,sdow,shour,sminute;
	char temp[4];
	syear = itoa(year,temp,10);
	sdate = itoa(date,temp,10);
	shour = itoa(hour,temp,10);
	sminute = itoa(minute,temp,10);
	if(dow == 1)
		sdow = "Sunday";
	else if(dow == 2)
		sdow = "Monday";
	else if(dow == 3)
		sdow = "Tuesday";
	else if(dow == 4)
		sdow = "Wednesday";
	else if(dow == 5)
		sdow = "Thursday";
	else if(dow == 6)
		sdow = "Friday";
	else if(dow == 7)
		sdow = "Saturday";
	if(month == 1)
		smonth = "January";
	else if(month == 2)
		smonth = "February";
	else if(month == 3)
		smonth = "March";
	else if(month == 4)
		smonth = "April";
	else if(month == 5)
		smonth = "May";
	else if(month == 6)
		smonth = "June";
	else if(month == 7)
		smonth = "July";
	else if(month == 8)
		smonth = "August";
	else if(month == 9)
		smonth = "September";
	else if(month == 10)
		smonth = "October";
	else if(month == 11)
		smonth = "November";
	else if(month == 12)
		smonth = "December";
	//Display Text
	Text = "The statistics were last updated : "+sdow+" "+sdate+" "+smonth+" "+syear+"  "+shour+":"+sminute;
	CFont SetFont;
	SetFont.CreateFont(20,0,0,0,35,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,"arial");
	dc->SelectObject(SetFont);
	dc->SetBkMode( TRANSPARENT );
	dc->TextOut(62,10,Text);
	//Display day Traffic
	m_sBitmap = m_sFilePath+"-day.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		dcMem.CreateCompatibleDC( dc );
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );
		dc->StretchBlt( 50, 40, 500, 125, 
			 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	//Display week Traffic
	m_sBitmap = m_sFilePath+"-week.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );
		dc->StretchBlt( 50, 180, 500, 125, 
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	//Display month Traffic
	m_sBitmap = m_sFilePath+"-month.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );
		dc->StretchBlt( 50, 320, 500, 125, 
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	//Display year Traffic
	m_sBitmap = m_sFilePath+"-year.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );
		dc->StretchBlt( 50, 460, 500, 125, 
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CMrtgDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CFileManip::Del(this->m_Path+"*.bak",TRUE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-day.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-week.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-month.png",SW_HIDE);
	WinExec(".\\Bin\\png2bmp\\png2bmp "+this->m_sFilePath+"-year.png",SW_HIDE);
	CPaintDC dc(this);
	Output(&dc);
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////

	CDialog::OnTimer(nIDEvent);
}

void CMrtgDlg::OnButtonClose() 
{
	// TODO: Add your control notification handler code here
	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	OnOK( );
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CMrtgDlg::OnButtonPrint() 
{
	// TODO: Add your control notification handler code here
	
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
    HDC    hdcPrn ;

    // Instantiate a CPrintDialog.
    CPrintDialog *printDlg =
        new CPrintDialog(FALSE, PD_ALLPAGES | PD_RETURNDC, NULL);

    // Initialize some of the fields in PRINTDLG structure.
    printDlg->m_pd.nMinPage = printDlg->m_pd.nMaxPage = 1;
    printDlg->m_pd.nFromPage = printDlg->m_pd.nToPage = 10;

    // Display Windows print dialog box.
    printDlg->DoModal();

    // Obtain a handle to the device context.
    hdcPrn = printDlg->GetPrinterDC();
    if (hdcPrn != NULL) {
		CDC *pDC = new CDC;
        pDC->Attach (hdcPrn);      // attach a printer DC

        pDC->StartDoc("Netview Report");  // begin a new print job
										  // for Win32 use
										  // CDC::StartDoc(LPDOCINFO) override

		//----------------------------------------------
		// Print for each page
		//----------------------------------------------
        pDC->StartPage();			// begin a new page
        SetPrintAlign(pDC, hdcPrn);	// set the printing alignment
		SetPrintReportPage( pDC );	// set page format to print
        pDC->EndPage();				// end a page
		//----------------------------------------------
		// Print for each page
		//----------------------------------------------

        pDC->EndDoc();             // end a print job

        pDC->Detach();             // detach the printer DC
        delete pDC;
	}

    delete printDlg;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set page alignment
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  hdcPrn(IN)>>	Context Device Handle's pointer
//
void CMrtgDlg::SetPrintAlign(CDC *pDC, HDC hdcPrn)
{
	/////////////////////////////
	// MY CODE START HERE
	/////////////////////////////
	short cxPage, cyPage;

    cxPage = ::GetDeviceCaps (hdcPrn, HORZRES) ;
    cyPage = ::GetDeviceCaps (hdcPrn, VERTRES) ;
    pDC->SetMapMode (MM_ISOTROPIC) ;
    pDC->SetWindowExt ( 1000, 1000) ;
    pDC->SetViewportExt (cxPage / 2, -cyPage / 2) ;
    pDC->SetViewportOrg (cxPage / 2, cyPage - (cyPage-600)) ;
    pDC->SetTextAlign (TA_BASELINE | TA_CENTER) ;


	/*
	short cxPage, cyPage;

    cxPage = ::GetDeviceCaps (hdcPrn, HORZRES) ;
    cyPage = ::GetDeviceCaps (hdcPrn, VERTRES) ;
    pDC->SetMapMode(MM_HIENGLISH   ) ;
    //pDC->SetWindowExt ( 1000, 1000) ;
    //pDC->SetViewportExt (cxPage / 2, -cyPage / 2) ;
    //pDC->SetViewportOrg (cxPage / 2, cyPage - (cyPage-600)) ;
    pDC->SetTextAlign (TA_BASELINE | TA_CENTER) ;
	*/
	/////////////////////////////
	// MY CODE END HERE
	/////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//
void CMrtgDlg::SetPrintReportPage(CDC *pDC)
{
	/////////////////////////////
	// MY CODE START HERE
	/////////////////////////////
	int y = 10;	// position for each line

	SetPrintReportTitle( pDC, y );	// print title

	HBITMAP hBitmap;
	CMrtgDlg* lpWnd;
	BITMAP bm;
	CDC dcMem;
	CBitmap* pOldBitmap;
	CRect lRect;
	
	//Set display text
	CString strDisplay;
	CFont SetFont;
	SetFont.CreateFont(48,0,0,0,35,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,"arial");
	pDC->SelectObject( SetFont );
	pDC->SetBkMode( TRANSPARENT );

	//Display day Traffic
	m_sBitmap = m_sFilePath+"-day.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		dcMem.CreateCompatibleDC( pDC );
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );

		// display text and graph
		strDisplay = "Per Day Traffic";
		pDC->TextOut( -680, -220, strDisplay );
		pDC->StretchBlt( -750, -250, 1500, -375, 
			 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	
	//Display week Traffic
	m_sBitmap = m_sFilePath+"-week.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );

		// display text and graph
		strDisplay = "Per Week Traffic";
		pDC->TextOut( -680, -720, strDisplay );
		pDC->StretchBlt( -750, -750, 1500, -375, 
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}
	
	//Display month Traffic
	m_sBitmap = m_sFilePath+"-month.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );

		// display text and graph
		strDisplay = "Per Month Traffic";
		pDC->TextOut( -680, -1220, strDisplay );
		pDC->StretchBlt( -750, -1250, 1500, -375,
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}

	//Display year Traffic
	m_sBitmap = m_sFilePath+"-year.bmp";
	hBitmap = (HBITMAP)::LoadImage(AfxGetInstanceHandle(),m_sBitmap,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if ( hBitmap ) 
	{
		if ( m_bmpBitmap.DeleteObject( ) ) 
		{
			m_bmpBitmap.Detach( );
		}
		m_bmpBitmap.Attach( hBitmap );
		lpWnd = (CMrtgDlg*)this;
		lpWnd->m_bmpBitmap.GetBitmap(&bm);
		pOldBitmap = (CBitmap*)dcMem.SelectObject( lpWnd->m_bmpBitmap );
		GetClientRect( lRect );

		// display text and graph
		strDisplay = "Per Year Traffic";
		pDC->TextOut( -680, -1720, strDisplay );
		pDC->StretchBlt( -750, -1750, 1500, -375,
				 &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	}

	/////////////////////////////
	// MY CODE END HERE
	/////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Draw title report to context device for printing
//	Parameter	: pDC(IN)	>>	Context Device's pointer
//				  y(IN/OUT)	>>	Position for each line 
//
void CMrtgDlg::SetPrintReportTitle(CDC *pDC, int &y)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	TEXTMETRIC metrics;
	CFont fontTitle;
	int iLineH;			// Height for each line
	CString strHeader;
	CString strPresentDate, strPresentTime, strDayOfWeek;
	COleDateTime timePresent;
	int iDayOfWeek;

	//------------------------------------
	// AngsanaUPC font with Bold and Underline style for Title
	fontTitle.CreateFont( 100, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
						  ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
						  DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,
						  "AngsanaUPC" );
	pDC->SelectObject( &fontTitle );

	//------------------------------------
	// get present time
	timePresent = COleDateTime::GetCurrentTime( );
	iDayOfWeek = timePresent.GetDayOfWeek( );
	switch ( iDayOfWeek ) {
	case 1 : strDayOfWeek = "�ѹ�ҷԵ��";	break;
	case 2 : strDayOfWeek = "�ѹ�ѹ���";	break;
	case 3 : strDayOfWeek = "�ѹ�ѧ���";	break;
	case 4 : strDayOfWeek = "�ѹ�ظ";		break;
	case 5 : strDayOfWeek = "�ѹ����ʺ��";	break;
	case 6 : strDayOfWeek = "�ѹ�ء��";		break;
	case 7 : strDayOfWeek = "�ѹ�����";		break;
	}
	strPresentDate = this->GetDateString( timePresent );
	strPresentTime = this->GetTimeString( timePresent );

	//------------------------------
	// Line 1
	//------------------------------
	strHeader =  "Isagview46 Traffic Network Report";	// Prepare Title String 
	pDC->TextOut( 10, y, strHeader );					// Title for report line 1
	// Retrieves the matrics for using the current font
	pDC->GetTextMetrics( &metrics );
	iLineH = metrics.tmHeight + metrics.tmExternalLeading;
	y -= iLineH; // update line position
	//------------------------------
	// Line 1
	//------------------------------

	//------------------------------
	// Line 2
	//------------------------------
	// Prepare Title String 
	strHeader =  "Report Date: "; 
	strHeader += strDayOfWeek;
	strHeader += " ";
	strHeader += strPresentDate;
	strHeader += " ";
	strHeader += strPresentTime;

	// Title for report line 2
	pDC->TextOut( 10, y, strHeader );	
	y -= iLineH; // update line position
	//------------------------------
	// Line 2
	//------------------------------	

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}


//////////////////////////////////////////////////////////////////////
//	Description : Convert date to string
//	Return		: CString >> Date string
//
CString CMrtgDlg::GetDateString(COleDateTime time)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strDate;
	int iDay, iMonth, iYear;
	char *cMonth;

	iDay	= time.GetDay( );
	iMonth	= time.GetMonth( );
	iYear	= time.GetYear( );
	
	if ( (iYear==1900) && (iMonth==1) && (iDay==1) ) {
		strDate = "                         ";
		return strDate;
	}
	
	// select thai month
	switch ( iMonth ) {
	case 1  : cMonth = "���Ҥ�"; break;
	case 2  : cMonth = "����Ҿѹ��"; break;
	case 3  : cMonth = "�չҤ�"; break;
	case 4  : cMonth = "����¹"; break;
	case 5  : cMonth = "����Ҥ�"; break;
	case 6  : cMonth = "�Զع�¹"; break;
	case 7  : cMonth = "�á�Ҥ�"; break;
	case 8  : cMonth = "�ԧ�Ҥ�"; break;
	case 9  : cMonth = "�ѹ��¹"; break;
	case 10 : cMonth = "���Ҥ�"; break;
	case 11 : cMonth = "��Ȩԡ�¹"; break;
	case 12 : cMonth = "�ѹ�Ҥ�"; break;
	default : cMonth = "";
	}
	iYear = iYear + 543;
	strDate.Format( "%i %s, %i", iDay, cMonth, iYear ); 

	return strDate;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Convert time to string
//	Return		: CString >> Time string
//
CString CMrtgDlg::GetTimeString(COleDateTime time)
{
	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	CString strTime;
	int iHour, iMinute, iSecond;

	iHour	= time.GetHour( );
	iMinute	= time.GetMinute( );
	iSecond	= time.GetSecond( );
	strTime.Format( "%02i:%02i:%02i", iHour, iMinute, iSecond ); 

	return strTime;
	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
}
