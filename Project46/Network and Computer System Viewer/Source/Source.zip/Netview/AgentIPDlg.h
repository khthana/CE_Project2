#if !defined(AFX_AGENTIPDLG_H__EF9AD3FD_EBDD_4AEB_8BFC_8627BAE89003__INCLUDED_)
#define AFX_AGENTIPDLG_H__EF9AD3FD_EBDD_4AEB_8BFC_8627BAE89003__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AgentIPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAgentIPDlg dialog

class CAgentIPDlg : public CDialog
{
// Construction
public:
	CString m_strNetwork;
	CString m_strNetmask;
	CString m_strAgentIP;
	CAgentIPDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAgentIPDlg)
	enum { IDD = IDD_DIALOG_AGENTIP };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAgentIPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAgentIPDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AGENTIPDLG_H__EF9AD3FD_EBDD_4AEB_8BFC_8627BAE89003__INCLUDED_)
