#if !defined(AFX_PROPHOSTSHEET_H__299AF42E_AFF7_4606_9D27_1F3C2870927E__INCLUDED_)
#define AFX_PROPHOSTSHEET_H__299AF42E_AFF7_4606_9D27_1F3C2870927E__INCLUDED_

#include "PropHostPage.h"	// Added by ClassView
#include "PropPortPage.h"	// Added by ClassView
#include "PropUserAndGroupPage.h"	// Added by ClassView
#include "PropSharePage.h"	// Added by ClassView
#include "PropSnmpPage.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropHostSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropHostSheet

class CPropHostSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CPropHostSheet)

// Construction
public:
	CPropHostSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CPropHostSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropHostSheet)
	//}}AFX_VIRTUAL

// Implementation
public:
	CPropSnmpPage m_propSnmpPage;
	CPropSharePage m_propSharePage;
	CPropUserAndGroupPage m_propUserAndGroupPage;
	CPropPortPage m_propPortPage;
	CPropHostPage m_propHostPage;
	virtual ~CPropHostSheet();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropHostSheet)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPHOSTSHEET_H__299AF42E_AFF7_4606_9D27_1F3C2870927E__INCLUDED_)
