// PropUserAndGroupPage.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropUserAndGroupPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropUserAndGroupPage property page

IMPLEMENT_DYNCREATE(CPropUserAndGroupPage, CPropertyPage)

CPropUserAndGroupPage::CPropUserAndGroupPage() : CPropertyPage(CPropUserAndGroupPage::IDD)
{
	//{{AFX_DATA_INIT(CPropUserAndGroupPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPropUserAndGroupPage::~CPropUserAndGroupPage()
{
}

void CPropUserAndGroupPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropUserAndGroupPage)
	DDX_Control(pDX, IDC_LIST_USER, m_ctlListUser);
	DDX_Control(pDX, IDC_LIST_GROUP, m_ctlListGroup);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropUserAndGroupPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPropUserAndGroupPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropUserAndGroupPage message handlers

BOOL CPropUserAndGroupPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here

	/////////////////////////
	// MY CODE START HERE
	/////////////////////////
	LV_COLUMN lvColumn;
	LV_ITEM lvItem;
	int i, j;

	////-----------------------------------------------------
	//
	//  Set user data
	//
	////-----------------------------------------------------
	int iUserSize;
	CUser *pUser;

	CString strUserName;
	CString strComment;
	CString strFullName;
	char *cUserName;
	char *cComment;
	char *cFullName;

	//-----------------------------------------------------
	// Insert Column to List Control
	//	User Name | Comment | Full Name | Account Enable | 
	//  Password Required | Password Can Change | Password Not Expire
	//-----------------------------------------------------
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;

	lvColumn.pszText = "User Name";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListUser.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Comment";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 250;
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListUser.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Full Name";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_LEFT;
	m_ctlListUser.InsertColumn( 2, &lvColumn );

	lvColumn.pszText = "Account Enable";
	lvColumn.iSubItem = 3;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListUser.InsertColumn( 3, &lvColumn );

	lvColumn.pszText = "Password Required";
	lvColumn.iSubItem = 4;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListUser.InsertColumn( 4, &lvColumn );

	lvColumn.pszText = "Password Can Change";
	lvColumn.iSubItem = 5;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListUser.InsertColumn( 5, &lvColumn );

	lvColumn.pszText = "Password Not Expire";
	lvColumn.iSubItem = 6;
	lvColumn.cx = 120;
	lvColumn.fmt = LVCFMT_CENTER;
	m_ctlListUser.InsertColumn( 6, &lvColumn );
	//-----------------------------------------------------
	// Insert Column to List Control
	//	User Name | Comment | Full Name | Account Enable | 
	//  Password Required | Password Can Change | Password Not Expire
	//-----------------------------------------------------

	//------------------------------------------------------------
	// Set value to column
	//  Administrator |  ..... | ..... | YES | .....
	//	    Guest	  |  ..... | ..... |  NO | .....
	//------------------------------------------------------------
	iUserSize = this->m_uaUsers.GetSize( );
	for ( i=0; i<iUserSize; i++ ) {
		pUser = m_uaUsers.ElementAt( i );
		
		strUserName	= pUser->GetUserName( );
		strComment	= pUser->GetComment( );
		strFullName	= pUser->GetFullName( );
		cUserName	= strUserName.GetBuffer( 255 );
		cComment	= strComment.GetBuffer( 255 );
		cFullName	= strFullName.GetBuffer( 255 );

		// set in row in list
		lvItem.mask		= LVIF_TEXT;

		lvItem.iItem	= i;
		lvItem.iSubItem = 0;
		lvItem.pszText	= cUserName;
		m_ctlListUser.InsertItem( &lvItem );

		lvItem.iSubItem = 1;
		lvItem.pszText	= cComment;
		m_ctlListUser.SetItem( &lvItem );

		lvItem.iSubItem = 2;
		lvItem.pszText	= cFullName;
		m_ctlListUser.SetItem( &lvItem );

		lvItem.iSubItem = 3;
		if ( pUser->IsAccountEnable( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListUser.SetItem( &lvItem );

		lvItem.iSubItem = 4;
		if ( pUser->IsPasswordReq( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListUser.SetItem( &lvItem );

		lvItem.iSubItem = 5;
		if ( pUser->IsPasswordCanChange( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListUser.SetItem( &lvItem );

		lvItem.iSubItem = 6;
		if ( pUser->IsPasswordNotExpire( ) )
			lvItem.pszText	= "YES";
		else 
			lvItem.pszText	= "NO";
		m_ctlListUser.SetItem( &lvItem );
	}
	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------
	////-----------------------------------------------------
	//
	//  Set user data
	//
	////-----------------------------------------------------

	////-----------------------------------------------------
	//
	//  Set group data
	//
	////-----------------------------------------------------
	int iGroupSize, iMemberSize;
	CGroup *pGroup;

	CString strGroupName;
	CString strGroupComment;
	CString	strGroupMember = "";
	CStringArray *pGroupMembers;
	char *cGroupName;
	char *cGroupComment;
	char *cGroupMember;
	BOOL bFirst = TRUE;

	//-----------------------------------------------------
	// Insert Column to List Control
	//	 Group Name  |  Group Comment  |  Group Member
	//-----------------------------------------------------
	lvColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvColumn.fmt = LVCFMT_LEFT;

	lvColumn.pszText = "Group Name";
	lvColumn.iSubItem = 0;
	lvColumn.cx = 120;
	m_ctlListGroup.InsertColumn( 0, &lvColumn );

	lvColumn.pszText = "Group Comment";
	lvColumn.iSubItem = 1;
	lvColumn.cx = 250;
	m_ctlListGroup.InsertColumn( 1, &lvColumn );

	lvColumn.pszText = "Group Member";
	lvColumn.iSubItem = 2;
	lvColumn.cx = 250;
	m_ctlListGroup.InsertColumn( 2, &lvColumn );
	//-----------------------------------------------------
	// Insert Column to List Control
	//	 Group Name  |  Group Comment  |  Group Member
	//-----------------------------------------------------

	//------------------------------------------------------------
	// Set value to column
	//  Administrator |  ..... | ..... 
	//	    Guest	  |  ..... | ..... 
	//------------------------------------------------------------
	iGroupSize = this->m_gaGroups.GetSize( );
	for ( i=0; i<iGroupSize; i++ ) {
		pGroup = m_gaGroups.ElementAt( i );
		
		strGroupName	= pGroup->GetGroupName( );
		strGroupComment	= pGroup->GetGroupComment( );
		pGroupMembers	= pGroup->GetGroupMembers( );
		strGroupMember	= "";
		cGroupName		= strGroupName.GetBuffer( 255 );
		cGroupComment	= strGroupComment.GetBuffer( 255 );
		// set show member for each group
		iMemberSize = pGroupMembers->GetSize( ); 
		for ( j=0; j<iMemberSize; j++ ) {
			if ( bFirst ) {
				strGroupMember += pGroupMembers->GetAt( j );
				bFirst = FALSE;
			}
			else {
				strGroupMember += " :: ";
				strGroupMember += pGroupMembers->GetAt( j );
			}
		}
		bFirst = TRUE; // reset for next group
		cGroupMember = strGroupMember.GetBuffer( 1024 );

		// set in row in list
		lvItem.mask		= LVIF_TEXT;

		lvItem.iItem	= i;
		lvItem.iSubItem = 0;
		lvItem.pszText	= cGroupName;
		m_ctlListGroup.InsertItem( &lvItem );

		lvItem.iSubItem = 1;
		lvItem.pszText	= cGroupComment;
		m_ctlListGroup.SetItem( &lvItem );

		lvItem.iSubItem = 2;
		lvItem.pszText	= cGroupMember;
		m_ctlListGroup.SetItem( &lvItem );
	}
	//------------------------------------------------------------
	// Set value to column
	//------------------------------------------------------------
	
	////-----------------------------------------------------
	//
	//  Set group data
	//
	////-----------------------------------------------------

	/////////////////////////
	// MY CODE END HERE
	/////////////////////////
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
