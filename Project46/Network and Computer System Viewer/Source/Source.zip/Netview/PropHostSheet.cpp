// PropHostSheet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "PropHostSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropHostSheet

IMPLEMENT_DYNAMIC(CPropHostSheet, CPropertySheet)

CPropHostSheet::CPropHostSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->AddPage( &m_propHostPage );
	this->AddPage( &m_propPortPage );
	this->AddPage( &m_propUserAndGroupPage );
	this->AddPage( &m_propSharePage );
	this->AddPage( &m_propSnmpPage );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CPropHostSheet::CPropHostSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->AddPage( &m_propHostPage );
	this->AddPage( &m_propPortPage );
	this->AddPage( &m_propUserAndGroupPage );
	this->AddPage( &m_propSharePage );
	this->AddPage( &m_propSnmpPage );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CPropHostSheet::~CPropHostSheet()
{
}


BEGIN_MESSAGE_MAP(CPropHostSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CPropHostSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropHostSheet message handlers
