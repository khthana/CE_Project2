// DaoMemberSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoMemberSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoMemberSet

IMPLEMENT_DYNAMIC(CDaoMemberSet, CDaoRecordset)

CDaoMemberSet::CDaoMemberSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoMemberSet)
	m_IP = _T("");
	m_GroupName = _T("");
	m_UserName = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoMemberSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoMemberSet::GetDefaultSQL()
{
	return _T("[Member]");
}

void CDaoMemberSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoMemberSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[IP]"), m_IP);
	DFX_Text(pFX, _T("[GroupName]"), m_GroupName);
	DFX_Text(pFX, _T("[UserName]"), m_UserName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoMemberSet diagnostics

#ifdef _DEBUG
void CDaoMemberSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoMemberSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
