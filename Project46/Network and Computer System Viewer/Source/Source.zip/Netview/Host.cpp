// Host.cpp: implementation of the CHost class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Netview.h"
#include "Host.h"

//////////////////////////
// MY HEADER START HERE 
//////////////////////////
#pragma comment( lib, "RASsAPI.lib" )
#pragma comment( lib, "Mpr.lib" )
#pragma comment( lib, "NetAPI32.lib" )

#include <lm.h>			// LAN Manager ( MAC Address )
#include <lmcons.h>     // LAN Manager common definitions
#include <lmerr.h>      // LAN Manager network error definitions
#include <lmaccess.h>   // Access, Domain, Group and User classes
#include <lmshare.h>    // Connection, File, Session and Share classes
#include <lmapibuf.h>   // NetApiBuffer class

#include "DaoHostSet.h"
#include "DaoMACSet.h"
#include "DaoUseVendorSet.h"
#include "DaoMACVendorSet.h"
#include "DaoHasPortSet.h"
////////////////////////// 
// MY HEADER END HERE
//////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHost::CHost(CString strIP, BOOL bStatus)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	this->m_strIP	= strIP;

	this->m_timeOpen.SetDateTime( 1900, 1, 1, 0, 0, 0 );
	this->m_timeClose.SetDateTime( 1900, 1, 1, 0, 0, 0 );

	this->SetStatus( TRUE );	// Status = Open
	this->m_bTrojan = FALSE;	// Trojan = No trojan
	this->m_bPolicy = TRUE;		// Policy = Follow policy
	this->m_bSnmp	= FALSE;

	m_bmpRouterSnmp.LoadBitmap( IDB_BITMAP_ROUTER_SNMP );
	m_bmpRouter.LoadBitmap( IDB_BITMAP_ROUTER );
	m_bmpPrinterSnmp.LoadBitmap( IDB_BITMAP_PRINTER_SNMP );
	m_bmpPrinter.LoadBitmap( IDB_BITMAP_PRINTER );
	m_bmpTrojanSnmp.LoadBitmap( IDB_BITMAP_HOST_TROJAN_SNMP );
	m_bmpTrojan.LoadBitmap( IDB_BITMAP_HOST_TROJAN );
	m_bmpPolicySnmp.LoadBitmap( IDB_BITMAP_HOST_POLICY_SNMP );
	m_bmpPolicy.LoadBitmap( IDB_BITMAP_HOST_POLICY );
	m_bmpOpenSnmp.LoadBitmap( IDB_BITMAP_HOST_OPEN_SNMP );
	m_bmpOpen.LoadBitmap( IDB_BITMAP_HOST_OPEN );
	m_bmpClose.LoadBitmap( IDB_BITMAP_HOST_CLOSE );
	m_bmpTrojanAndPolicySnmp.LoadBitmap( IDB_BITMAP_HOST_TROJANANDPOLICY_SNMP );
	m_bmpTrojanAndPolicy.LoadBitmap( IDB_BITMAP_HOST_TROJANANDPOLICY );
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CHost::~CHost()
{

}


CRectTracker* CHost::GetPosition()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_rtPosition;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CString CHost::GetIP()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strIP;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Select bitmap to display
//
void CHost::SelectBitmap()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	
	//
	// Router
	//
	if ( (m_strType.Find( "router" ) != -1) || (m_strType.Find( "WAP" ) != -1) ) {
		// SNMP support
		if ( this->IsSnmp( ) ) {
			m_pBitmap = &m_bmpRouterSnmp;
		}
		// SNMP not support
		else {
			m_pBitmap = &m_bmpRouter;
		}
	}
	//
	// Printer 
	//
	else if ( m_strType.Find( "printer" ) != -1 ) {
		// SNMP support
		if ( this->IsSnmp( ) ) {
			m_pBitmap = &m_bmpPrinterSnmp;
		}
		// SNMP not support
		else {
			m_pBitmap = &m_bmpPrinter;
		}
	}
	//
	// Host
	//
	else {
		// Host open
		if ( this->IsStatus( ) ) {
			// Host has trojan
			if ( (this->IsTrojan( )) && (this->IsPolicy( )) ) {
				// SNMP support
				if ( this->IsSnmp( ) ) {
					m_pBitmap = &m_bmpTrojanSnmp;
				}
				// SNMP not support
				else {
					m_pBitmap = &m_bmpTrojan;
				}
			}
			// Host has trojan and not follow policy
			else if ( (this->IsTrojan( )) && !(this->IsPolicy( )) ) {
				// SNMP support
				if ( this->IsSnmp( ) ) {
					m_pBitmap = &m_bmpTrojanAndPolicySnmp;
				}
				// SNMP not support
				else {
					m_pBitmap = &m_bmpTrojanAndPolicy;
				}
			}
			
			// Host not follow policy
			else if ( !this->IsPolicy( ) ) {
				// SNMP support
				if ( this->IsSnmp( ) ) {
					m_pBitmap = &m_bmpPolicySnmp;
				}
				// SNMP not support
				else {
					m_pBitmap = &m_bmpPolicy;
				}
			}
			// Host normal
			else {
				// SNMP support
				if ( this->IsSnmp( ) ) {
					m_pBitmap = &m_bmpOpenSnmp;
				}
				// SNMP not support
				else {
					m_pBitmap = &m_bmpOpen;
				}
			}
		}
		// Host close
		else {
			m_pBitmap = &m_bmpClose;
		}
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetPolicy(BOOL bPolicy)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_bPolicy = bPolicy;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetSnmp(BOOL bSnmp)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_bSnmp = bSnmp;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetStatus(BOOL bStatus)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_bStatus = bStatus;
	// Open
	if ( bStatus ) 
		this->m_timeOpen = COleDateTime::GetCurrentTime();
	// Close
	else 
		this->m_timeClose = COleDateTime::GetCurrentTime();
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetTrojan(BOOL bTrojan) 
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_bTrojan = bTrojan;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CBitmap* CHost::GetBitmap()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_pBitmap;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetCommand(CString strCommand)
{	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strCommand = strCommand;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CString CHost::GetCommand()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strCommand;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

CString* CHost::GetResult()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_strResult;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}	

BOOL CHost::IsPolicy()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// True Policy=TRUE, False Policy=FALSE
	return m_bPolicy;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

BOOL CHost::IsSnmp()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Support SNMP=TRUE, Not support SNMP=FALSE
	return m_bSnmp;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

BOOL CHost::IsStatus()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Open=TRUE, Close=FALSE
	return m_bStatus;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

BOOL CHost::IsTrojan()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	// Trojan=TRUE, No Trojan=FALSE
	return m_bTrojan;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::SetHostData(CString strHostName, CString strOS, CString strType)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strHostName	= strHostName;
	m_strOS			= strOS;
	m_strType		= strType;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Port in Host by port number and protocol
//	Parameter	: lPortNumber(IN)	>>	Port number
//				  strProtocol(IN)	>>	Protocol
//	Return		: int		>>	-1=Not Found, 0...n=Found and return position
//
int CHost::FindPort(long lPortNumber, CString strProtocol)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	long lPortNumberCheck;
	CString strProtocolCheck;
	int i, iSize;
	int iFound = -1;

	iSize = m_paPorts.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		lPortNumberCheck = m_paPorts[i]->GetPortNumber( );
		strProtocolCheck = m_paPorts[i]->GetProtocol( );
		// Match Port
		if ( (lPortNumber==lPortNumberCheck) && (strProtocol==strProtocolCheck) ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Host in Network
//	Parameter	: lPortNumber(IN)	>>
//				  strProtocol(IN)	>>
//				  strPortName(IN)	>>
//				  bTrojan(IN)		>>
//				  bWantDetect(IN)	>>
//				  strStatus(IN)		>>
//
void CHost::AddPort(long lPortNumber, CString strProtocol, CString strPortName, BOOL bTrojan, BOOL bWantDetect, CString strStatus)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	
	// Create a new CPort Object 
	CPort *pPort = new CPort( lPortNumber, 
							  strProtocol, 
							  strPortName, 
							  bTrojan, 
							  bWantDetect, 
							  strStatus );

	try {
		// Add new Port to Port Array
		m_paPorts.Add( pPort );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CPort Object delete it
		if ( pPort ) {
			delete pPort;
			pPort = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CHost::SetPortStatus(int iPortPosition, CString strStatus)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_paPorts[iPortPosition]->SetPortStatus( strStatus );
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetHostName()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strHostName;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetOS()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strOS;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetType()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strType;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CPortArray* CHost::GetPorts()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_paPorts;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Get open time in string format
//	Return		: String >>	Time in string format
//
CString CHost::GetOpenTimeString()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString strOpenTime;
	char *cMonth; 
	int iDay, iMonth, iYear, iHour, iMinute, iSecond;
	iDay	= m_timeOpen.GetDay( );
	iMonth	= m_timeOpen.GetMonth( );
	iYear	= m_timeOpen.GetYear( );
	iHour	= m_timeOpen.GetHour( );
	iMinute	= m_timeOpen.GetMinute( );
	iSecond	= m_timeOpen.GetSecond( );

	if ( (iYear==1900) && (iMonth==1) && (iDay==1) && 
		 (iHour==0) && (iMinute==0) && (iSecond==0) ) {
		strOpenTime = "";
		return strOpenTime;
	}

	// select thai month
	switch ( iMonth ) {
	case 1 : cMonth = "���Ҥ�"; break;
	case 2 : cMonth = "����Ҿѹ��"; break;
	case 3 : cMonth = "�չҤ�"; break;
	case 4 : cMonth = "����¹"; break;
	case 5 : cMonth = "����Ҥ�"; break;
	case 6 : cMonth = "�Զع�¹"; break;
	case 7 : cMonth = "�á�Ҥ�"; break;
	case 8 : cMonth = "�ԧ�Ҥ�"; break;
	case 9 : cMonth = "�ѹ��¹"; break;
	case 10 : cMonth = "���Ҥ�"; break;
	case 11 : cMonth = "��Ȩԡ�¹"; break;
	case 12 : cMonth = "�ѹ�Ҥ�"; break;
	default : cMonth = "";
	}
	iYear += 543;
	strOpenTime.Format( "%i %s %i   %02i:%02i:%02i", 
						iDay, cMonth, iYear, iHour, iMinute, iSecond ); 
	return strOpenTime;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Get close time in string format
//	Return		: String >>	Time in string format
//
CString CHost::GetCloseTimeString()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString strCloseTime;
	char *cMonth; 
	int iDay, iMonth, iYear, iHour, iMinute, iSecond;
	iDay	= m_timeClose.GetDay( );
	iMonth	= m_timeClose.GetMonth( );
	iYear	= m_timeClose.GetYear( );
	iHour	= m_timeClose.GetHour( );
	iMinute	= m_timeClose.GetMinute( );
	iSecond	= m_timeClose.GetSecond( );

	if ( (iYear==1900) && (iMonth==1) && (iDay==1) && 
		 (iHour==0) && (iMinute==0) && (iSecond==0) ) {
		strCloseTime = "";
		return strCloseTime;
	}

	// select thai month
	switch ( iMonth ) {
	case 1 : cMonth = "���Ҥ�"; break;
	case 2 : cMonth = "����Ҿѹ��"; break;
	case 3 : cMonth = "�չҤ�"; break;
	case 4 : cMonth = "����¹"; break;
	case 5 : cMonth = "����Ҥ�"; break;
	case 6 : cMonth = "�Զع�¹"; break;
	case 7 : cMonth = "�á�Ҥ�"; break;
	case 8 : cMonth = "�ԧ�Ҥ�"; break;
	case 9 : cMonth = "�ѹ��¹"; break;
	case 10 : cMonth = "���Ҥ�"; break;
	case 11 : cMonth = "��Ȩԡ�¹"; break;
	case 12 : cMonth = "�ѹ�Ҥ�"; break;
	default : cMonth = "";
	}
	iYear += 543;
	strCloseTime.Format( "%i %s %i   %02i:%02i:%02i", 
						iDay, cMonth, iYear, iHour, iMinute, iSecond ); 
	return strCloseTime;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetPasswordMinLength(CString strPasswordMinLength)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strMinLength = strPasswordMinLength;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetPasswordMinLength()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strMinLength;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetPasswordMinAge(CString strPasswordMinAge)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strMinAge = strPasswordMinAge;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetPasswordMinAge()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strMinAge;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetPasswordMaxAge(CString strPasswordMaxAge)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strMaxAge = strPasswordMaxAge;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetPasswordMaxAge()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strMaxAge;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetLockoutDuration(CString strLockoutDuration)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strLockoutDuration = strLockoutDuration;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetLockoutDuration()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strLockoutDuration;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetLockoutReset(CString strLockoutReset)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strLockoutReset = strLockoutReset;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetLockoutReset()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strLockoutReset;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::SetLockoutThreshold(CString strLockoutThreshold)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	m_strLockoutThreshold = strLockoutThreshold;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CString CHost::GetLockoutThreshold()
{	
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_strLockoutThreshold;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}	

CStringArray* CHost::GetMacAddress()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_saMacAddress;
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

void CHost::AddMacAddress(CString strMacAddress)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	strMacAddress.TrimLeft( );
	strMacAddress.TrimRight( );
	m_saMacAddress.Add( strMacAddress );
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Connect null session to find host data
//
void CHost::ConnectNullSession()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////

	char username[1024] = ""; // NULL username -> NULL Session
	char password[1024] = ""; // NULL password -> NULL Session
	char server[1024] = "";
	char path[1024] = "";

	NETRESOURCE res;	// structure that specifies details of connection
	DWORD ret;			// return state connection

	// get IP Address
	CString strIP;
	strIP = this->GetIP( );
	strcpy( server, strIP );

	// set path to connect null session
	sprintf(path,"\\\\%s\\ipc$",server);

	// if (connect already) then disconnect
	char cursor[ UNLEN ] = "";
	DWORD size = sizeof( cursor );
	if ( WNetGetUser( path, cursor, &size ) == NO_ERROR ) { 
		WNetCancelConnection2( ( const char* )path, 0, TRUE ); // disconnect
	}

	// ---------------------------------------------------------
	// Connect NULL Session
	// ---------------------------------------------------------
	res.lpLocalName		= NULL;
	res.lpProvider		= NULL;
	res.dwType			= RESOURCETYPE_ANY;
	res.lpRemoteName	= ( char* )&path;

	ret = WNetAddConnection2( &res,							// Network resource 
								( const char* )&password,	// password
								( const char* )&username,	// username
								0 );						// Connect option
	// ---------------------------------------------------------
	// Connect NULL Session
	// ---------------------------------------------------------

	if ( ret != ERROR_SUCCESS ) { 
		// if connect null session fail
		// do nothing 
		return;
	}
	
	//------------------------------------------------------------------------------
	//  if connect null session success
	//------------------------------------------------------------------------------
	
	//----------------------------
	// Enumeration
	//----------------------------
	ScanUserName( server );			// Get Username
	ScanGroup( server );			// Get Group
	ScanMacAddress( server );		// Get Mac Address
	ScanSecurityPolicy( server );	// Get Security Policy
	ScanShare( server );			// Get Share Resource
	//----------------------------
	// Enumeration
	//----------------------------
		
	WNetCancelConnection2( ( const char* )&path, 0, TRUE ); // disconnect
	//------------------------------------------------------------------------------
	//  if connect null session success
	//------------------------------------------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan user name (require NULL Session)
//	Parameter	: server(IN)	>>
//				 
void CHost::ScanUserName( char *server )
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////	
	// Username data
	CString strUserName;
	CString strComment;
	CString strFullName;
	BOOL bAccountEnable;	// Enable=TRUE,				 Disable=FALSE
	BOOL bPasswordReq;		// Password required=TRUE,	 Password not required=FALSE
	BOOL bPasswordCanChange;// Password can change=TRUE, Password can't change=FALSE
	BOOL bPasswordNotExpire;// Password not expire=TRUE, Password can expire=FALSE
	int iPosition;

	// ----------------------------------------------------------------
	// Get Username
	// ----------------------------------------------------------------
	LPVOID buff		= NULL;
	DWORD read		= 0;
	DWORD index		= 0;
	DWORD retUser	= 0;	// return state connection
	
	char cserver[1024];
	wchar_t wserver[1024];
	sprintf( cserver, "\\\\%s", server ); 
	mbstowcs( wserver, cserver, 1024 ); // convert to wide char

	do {
		retUser = NetQueryDisplayInformation( 
							wserver,	// IP Address
							1,			// Get user account
							index,		// 
							1000,		// max user account
							4096,		// max size (bytes)
							&read,		// number of user
							&buff );	// data buffer
	
		if ( retUser != NERR_Success && retUser != ERROR_MORE_DATA ) {
			// if query user account fail
			// AfxMessageBox( "!!Query user account fail!!", MB_ICONERROR );
			// do nothong
		}
		else {
			// if query user account success
			if ( read ) { 
				// if have user account

				PNET_DISPLAY_USER cur = (PNET_DISPLAY_USER)buff; // data buffer
				char userQuery[ UNLEN ];

				for ( unsigned int i=0; i<read; i++, cur++ ) {
					// get user name 
					sprintf( userQuery, "%S", cur->usri1_name );
					strUserName = userQuery;
					strUserName.TrimLeft( );
					strUserName.TrimRight( );

					// get user comment
					sprintf( userQuery, "%S", cur->usri1_comment );
					strComment = userQuery;

					// get full name
					sprintf( userQuery, "%S", cur->usri1_full_name );
					strFullName = userQuery;
	
					// check account disable
					if ( cur->usri1_flags & UF_ACCOUNTDISABLE ) 
						bAccountEnable = FALSE;
					else 
						bAccountEnable = TRUE;
						
					// check password not required
					if ( cur->usri1_flags & UF_PASSWD_NOTREQD ) 
						bPasswordReq = FALSE;
					else 
						bPasswordReq = TRUE;

					// check can not change password
					if ( cur->usri1_flags & UF_PASSWD_CANT_CHANGE ) 
						bPasswordCanChange = FALSE;
					else 
						bPasswordCanChange = TRUE;
						
					// check password never expire
					if ( cur->usri1_flags & UF_DONT_EXPIRE_PASSWD ) 
						bPasswordNotExpire = TRUE;
					else 
						bPasswordNotExpire = FALSE;
					
					//------------------
					// Add user name
					//------------------
					iPosition = FindUser( strUserName );
					// not found then add it
					if ( iPosition == -1 ) {
						AddUser( strUserName, 
								 strComment, 
								 strFullName, 
								 bAccountEnable,
								 bPasswordReq, 
								 bPasswordCanChange, 
								 bPasswordNotExpire );
					}
					//------------------
					// Add user name
					//------------------
				}
				NetApiBufferFree(buff); // clear buffer
			}
		}
	} while ( retUser == ERROR_MORE_DATA );
	
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

//////////////////////////////////////////////////////////////////////
//	Description : Add User in Host
//	Parameter	: 
//		strUserName(IN)
//		strComment(IN)
//		strFullName(IN)
//		bAccountEnable(IN)		// Enable=TRUE,				 Disable=FALSE
//		bPasswordReq(IN)		// Password required=TRUE,	 Password not required=FALSE
//		bPasswordCanChange(IN)	// Password can change=TRUE, Password can't change=FALSE
//		bPasswordNotExpire(IN)	// Password not expire=TRUE, Password can expire=FALSE
//
void CHost::AddUser( CString strUserName, CString strComment, CString strFullName, BOOL bAccountEnable, BOOL bPasswordReq, BOOL bPasswordCanChange, BOOL bPasswordNotExpire )
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////	
	// Create a new CUser Object 
	CUser *pUser = new CUser( strUserName, 
							  strComment, 
							  strFullName,
							  bAccountEnable, 
							  bPasswordReq, 
							  bPasswordCanChange, 
							  bPasswordNotExpire );
	try {
		// Add new User to User Array
		m_uaUsers.Add( pUser );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CUser Object delete it
		if ( pUser ) {
			delete pUser;
			pUser = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

//////////////////////////////////////////////////////////////////////
//	Description : Find User in Host by username
//	Parameter	: strUserName(IN)	>>	
//	Return		: int				>>	-1=Not Found, 0...n=Found and return position
//
int CHost::FindUser(CString strUserName)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strUserNameCheck;

	int i, iSize;
	int iFound = -1;

	iSize = m_uaUsers.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		strUserNameCheck = m_uaUsers[i]->GetUserName( );

		// Match Username
		if ( strUserName == strUserNameCheck ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////	
}

CUserArray* CHost::GetUsers()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_uaUsers;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan group (require NULL Session)
//	Parameter	: server(IN)	>>
//
void CHost::ScanGroup(char *server)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString strGroupName;
	CString	strGroupComment;
	CString strGroupMember;
	CStringArray *pGroupMembers = NULL;
	int iPosition;

	// ----------------------------------------------------------------
	// Get Group
	// ----------------------------------------------------------------
	LPVOID buff = NULL;
	DWORD level;
	DWORD prefmaxlen;
	DWORD read;
	DWORD total;
	DWORD resume = 0;
	DWORD retGroup = 0;	// return state connection

	level = 1;			// get group name and comment
	prefmaxlen = 1024;	// max size buffer

	char cserver[ 1024 ];
	wchar_t wserver[ 1024 ];
	sprintf( cserver, "\\\\%s", server );
	mbstowcs( wserver, cserver, sizeof( cserver ) );

	do {
		// get group name ( not member )
		retGroup = NetLocalGroupEnum( 
							wserver,
							level,
							( unsigned char** )&buff,
							prefmaxlen,
							&read,
							&total,
							&resume );
		if ( retGroup != NERR_Success && retGroup != ERROR_MORE_DATA ) {
			// if get group fail
			// AfxMessageBox( "!!Query group fail!!", MB_ICONERROR );
			// do nothing
		}
		else {
			// if get group success

			PLOCALGROUP_INFO_1 cur = ( PLOCALGROUP_INFO_1 )buff;
			char groupQuery[ UNLEN ];
					
			for ( unsigned int i=0; i<read; i++ ) {
				sprintf( groupQuery, "%S", cur[ i ].lgrpi1_name );
				strGroupName	= groupQuery;
				sprintf( groupQuery, "%S", cur[ i ].lgrpi1_comment );
				strGroupComment = groupQuery;

				// -----------------------------------------------------------------
				// get member data
				// -----------------------------------------------------------------
				LPVOID buffMember = NULL;
				DWORD levelMember;
				DWORD prefmaxlenMember;
				DWORD readMember;
				DWORD totalMember;
				DWORD resumeMember = 0;
				DWORD retMember;	// return state connection

				levelMember = 3;
				prefmaxlenMember = 1024;	// max size buffer

				// get member
				retMember = NetLocalGroupGetMembers( 
								( const unsigned short* )&wserver,
								cur[i].lgrpi1_name,
								levelMember,
								( unsigned char** )&buffMember,
								prefmaxlenMember,
								&readMember,
								&totalMember,
								&resumeMember );

				if ( retMember != NERR_Success && retMember != ERROR_MORE_DATA ) {
					// if query member fail
					// AfxMessageBox( "!!Query member name fail!!", MB_ICONERROR );
					// do nothing
				}
				else {
					// if query member success
					
					PLOCALGROUP_MEMBERS_INFO_3 curMember = ( PLOCALGROUP_MEMBERS_INFO_3 )buffMember;
					char memberQuery[ UNLEN ];

					// create member array
					pGroupMembers = new CStringArray( );

					for ( unsigned int j=0; j<readMember; j++ ) {
						sprintf( memberQuery, "%S", curMember[ j ].lgrmi3_domainandname );
						strGroupMember = memberQuery;
						strGroupMember = strGroupMember.Right( strGroupMember.GetLength( ) - (strGroupMember.ReverseFind( '\\' )+1) );

						// check is new and add if it is new
						strGroupMember.TrimLeft( );
						strGroupMember.TrimRight( );
						pGroupMembers->Add( strGroupMember );
					}

					NetApiBufferFree( buffMember );	// clear buffer
				}
 				// -----------------------------------------------------------------
				// get member data
				// -----------------------------------------------------------------

				//------------------
				// Add group
				//------------------
				iPosition = FindGroup( strGroupName );
				// not found then add it
				if ( iPosition == -1 ) {
					AddGroup( strGroupName,
							  strGroupComment,
							  pGroupMembers );
				}
				// clear member
				if ( pGroupMembers != NULL ) {
					pGroupMembers->RemoveAll( );
					delete pGroupMembers;
				}
				//------------------
				// Add group
				//------------------
			}
			NetApiBufferFree( buff );	// clear buffer
		}

	} while ( retGroup == ERROR_MORE_DATA );
	// ----------------------------------------------------------------
	// Get Group
	// ----------------------------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Group in Host by username
//	Parameter	: strGroupName(IN)	>>	
//	Return		: int				>>	-1=Not Found, 0...n=Found and return position
//
int CHost::FindGroup(CString strGroupName)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strGroupNameCheck;

	int i, iSize;
	int iFound = -1;

	iSize = m_gaGroups.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		strGroupNameCheck = m_gaGroups[i]->GetGroupName( );

		// Match Group Name
		if ( strGroupName == strGroupNameCheck ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Group in Host
//	Parameter	: strGroupName(IN)		>>
//				  strGroupComment(IN)	>>
//				  saGroupMembers(IN)	>>
void CHost::AddGroup(CString strGroupName, CString strGroupComment, CStringArray *pGroupMembers)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////	
	// Create a new CGroup Object 
	CGroup *pGroup = new CGroup( strGroupName, 
								 strGroupComment, 
								 pGroupMembers );
	try {
		// Add new Group to Group Array
		m_gaGroups.Add( pGroup );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CGroup Object delete it
		if ( pGroup ) {
			delete pGroup;
			pGroup = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

CGroupArray* CHost::GetGroups()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_gaGroups;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

void CHost::ScanMacAddress(char *server)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	CString strMacAddress;
	int iPosition;

	// ----------------------------------------------------------------
	// Get MAC Address
	// ----------------------------------------------------------------
	LPVOID buff  = NULL;
	DWORD level;
	DWORD prefmaxlen;
	DWORD read;
	DWORD total;
	DWORD resume = 0;
	DWORD retMAC = 0;	// return state connection

	level = 0;			// Return workstation transport protocol information
	prefmaxlen = 1024;	// max size buffer

	char cserver[ 1024 ];
	wchar_t wserver[ 1024 ];
	sprintf( cserver, "\\\\%s", server );
	mbstowcs( wserver, cserver, 1024 ); // convert to wide char 
	// ( multi byte string to wide char string )
			
	do {
		retMAC = NetWkstaTransportEnum( 
						( char* )wserver,
						level,
						( unsigned char** )&buff,
						prefmaxlen,
						&read,
						&total,
						&resume );

		if ( retMAC != NERR_Success && retMAC != ERROR_MORE_DATA ) {
			// if query MAC Address fail
			// AfxMessageBox( "!!Query MAC Addres fail!!", MB_ICONERROR );
			// do nothing
		}
		else {
			// if query MAC Address success
			if ( total ) {
				// if have MAC Address

				PWKSTA_TRANSPORT_INFO_0 cur = ( PWKSTA_TRANSPORT_INFO_0 )buff;
				CString strTempDisplay;
				char MACQuery[ UNLEN ];
				unsigned char MACData[ 6 ];

				cur++; // MAC Address strat in 1
				for ( unsigned int i=0; i<(read-1); i++, cur++ ) {
					// get MAC Address
					swscanf( ( wchar_t* )cur->wkti0_transport_address, 
							 L"%02X%02X%02X%02X%02X%02X",
							 &MACData[ 0 ], &MACData[ 1 ], &MACData[ 2 ],
							 &MACData[ 3 ], &MACData[ 4 ], &MACData[ 5 ] );
					sprintf( MACQuery, 
							 "%02X-%02X-%02X-%02X-%02X-%02X",
							 MACData[ 0 ], MACData[ 1 ], MACData[ 2 ],
							 MACData[ 3 ], MACData[ 4 ], MACData[ 5 ] ); 
					strMacAddress = MACQuery;

					//------------------
					// Add MAC Address
					//------------------
					iPosition = FindMacAddress( strMacAddress );
					// not found then add it
					if ( iPosition == -1 ) {
						AddMacAddress( strMacAddress );
					}
					//------------------
					// Add MAC Address
					//------------------
				}

				NetApiBufferFree( buff ); // clear buffer
			}
		}
	} while ( retMAC == ERROR_MORE_DATA );
	// ----------------------------------------------------------------
	// Get MAC Address
	// ----------------------------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Find MAC Address in Host
//	Parameter	: strMacAddress(IN)	>>	
//	Return		: int				>>	-1=Not Found, 0...n=Found and return position
//
int CHost::FindMacAddress(CString strMacAddress)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strMacAddressCheck;

	int i, iSize;
	int iFound = -1;

	iSize = m_saMacAddress.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		strMacAddressCheck = m_saMacAddress[i];

		// Match Mac Address Name
		if ( strMacAddress == strMacAddressCheck ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan security policy (require NULL Session)
//	Parameter	: server(IN)	>>
//
void CHost::ScanSecurityPolicy(char *server)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strMinLength		= "";
	CString strMinAge			= "";
	CString strMaxAge			= "";
	CString strLockoutDuration	= "";
	CString strLockoutReset		= "";
	CString strLockoutThreshold	= "";
	
	// ----------------------------------------------------------------
	// Get Security Policy
	// ----------------------------------------------------------------
	LPVOID buff = NULL;
	DWORD level;
	DWORD retPolicy = 0;	// return state connection
	DWORD retLSA = 0;		// return state LSA connection

	char cserver[ 1024 ];
	wchar_t wserver[ 1024 ];
	sprintf( cserver, "\\\\%s", server );
	mbstowcs( wserver, cserver, 1024 );

	char query[ UNLEN ];

	// ----------------------------------
	// Get Password Policy
	// ----------------------------------
	level = 0;				// level to get global password parameters

	// get global password parameters
	retPolicy = NetUserModalsGet( wserver,	
								  level,
								  ( unsigned char** )&buff );

	if ( retPolicy != NERR_Success ) {
		// if get password policy fail
		// AfxMessageBox( "!!Query password policy fail!!", MB_ICONERROR );
		// do nothing
	}
	else  {
		// if get password policy success

		PUSER_MODALS_INFO_0 curPolicy = ( PUSER_MODALS_INFO_0 )buff;

		// display password min length
		if ( curPolicy->usrmod0_min_passwd_len ) 
			sprintf( query, "%d chars", 
					 curPolicy->usrmod0_min_passwd_len );
		else
			sprintf( query, "none" );
		strMinLength = query;

		// display password min age
		if ( curPolicy->usrmod0_min_passwd_age ) 
			sprintf( query, "%d days", 
					 curPolicy->usrmod0_min_passwd_age / ( 60*60*24 ) );
		else
			sprintf( query, "none" );
		strMinAge = query;

		// display password max age
		if ( curPolicy->usrmod0_max_passwd_age ) 
			sprintf( query, "%d days",
					 curPolicy->usrmod0_max_passwd_age / ( 60*60*24 ) );
		else 
			sprintf( query, "none" );
		strMaxAge = query;
	}
	// ----------------------------------
	// Get Password Policy
	// ----------------------------------

	// ----------------------------------
	// Get LSA ( Local Security Authority ) Policy
	// ----------------------------------
	level = 3;				// level to get LSA policy

	retLSA = NetUserModalsGet( wserver,
							   level,
							   ( unsigned char** )&buff );

	if ( retLSA != NERR_Success ) {
		// if get LSA policy fail
		// AfxMessageBox( "!!Query LSA policy fail!!", MB_ICONERROR );
		// do nothing
	}
	else {
		// if get LSA policy success

		PUSER_MODALS_INFO_3 curLSA = ( PUSER_MODALS_INFO_3 )buff;
				
		// get lockout duration
		if ( curLSA->usrmod3_lockout_duration )
			sprintf( query, "%d mins",
					 curLSA->usrmod3_lockout_duration / 60 );
		else  
			sprintf( query, "none" );
		strLockoutDuration = query;

		// get lockout reset ( observation window )
		if ( curLSA->usrmod3_lockout_observation_window ) 
			sprintf( query, "%d mins",
					 curLSA->usrmod3_lockout_observation_window / 60 );
		else 
			sprintf( query, "none" );
		strLockoutReset = query;

		// get lockout threshold
		if ( curLSA->usrmod3_lockout_threshold ) 
			sprintf( query, "%d attempts",
					 curLSA->usrmod3_lockout_threshold );
		else 
			sprintf( query, "none" );
		strLockoutThreshold = query;

	}
	// ----------------------------------
	// Get LSA ( Local Security Authority ) Policy
	// ----------------------------------

	// set polocy to host
	SetPasswordMinLength( strMinLength );
	SetPasswordMinAge( strMinAge );
	SetPasswordMaxAge( strMaxAge );
	SetLockoutDuration( strLockoutDuration );
	SetLockoutReset( strLockoutReset );
	SetLockoutThreshold( strLockoutThreshold );

	// ----------------------------------------------------------------
	// Get Security Policy
	// ----------------------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Scan share resource (require NULL Session)
//	Parameter	: server(IN)	>>
//
void CHost::ScanShare(char *server)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strShareName;
	CString strShareComment;
	CString strShareType;
	BOOL bAccessRead	= FALSE;
	BOOL bAccessWrite	= FALSE;
	BOOL bAccessCreate	= FALSE;
	BOOL bAccessExec	= FALSE;
	BOOL bAccessDelete	= FALSE;
	BOOL bAccessAtrib	= FALSE;
	BOOL bAccessPerm	= FALSE;
	BOOL bAccessAll		= FALSE;
	int iPosition;

	// ----------------------------------------------------------------
	// Get Share Resource
	// ----------------------------------------------------------------
	LPVOID buff = NULL;
	DWORD level;
	DWORD prefmaxlen;
	DWORD read;
	DWORD total;
	DWORD resume = 0;
	DWORD ret = 0;		// return state connection
	DWORD retShare = 0;	// return state connection
			
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	level = 1;			// high detail level query share resource
	//level = 2;
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	prefmaxlen = 1024;	// max size buffer

	char cserver[1024];
	wchar_t wserver[1024];
	sprintf( cserver, "\\\\%s", server ); 
	mbstowcs( wserver, cserver, 1024 ); // convert to wide char

	do {
		ret = NetShareEnum( ( char* )wserver,			// IP Address
							  level,					//
							  ( unsigned char** )&buff, // data buffer
							  prefmaxlen,				// max size buffer
							  &read,					// actual share
							  &total,					// total share
							  &resume );
		
		if ( retShare != NERR_Success && retShare != ERROR_MORE_DATA ) {
			// if query resource fail
			// AfxMessageBox( "!!Query share resource fail!!", MB_ICONERROR );
			// do nothing
		}
		else {
			// if query user account success
			if ( total ) { 
				// if have user account

				// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				PSHARE_INFO_1 cur = (PSHARE_INFO_1)buff; // data buffer
				// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				//PSHARE_INFO_2 cur = (PSHARE_INFO_2)buff; // data buffer

				char shareQuery[ UNLEN ];

				for ( unsigned int i=0; i<read; i++, cur++ ) {

					// get share resource name
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					sprintf( shareQuery, "%S", cur->shi1_netname );
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					//sprintf( shareQuery, "%S\r\n", cur->shi2_netname );					
					strShareName = shareQuery;
					if ( strShareName.IsEmpty( ) ) strShareName = " ";

					// check share type
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					switch ( cur->shi1_type & ~STYPE_SPECIAL ) {
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					//switch ( cur->shi2_type & ~STYPE_SPECIAL ) {
					case STYPE_DISKTREE :
						strShareType = "Disk drive";
						break;
					case STYPE_PRINTQ :
						strShareType = "Print queue";
						break;
					case STYPE_DEVICE :
						strShareType = "Communication device";
						break;
					case STYPE_IPC :
						strShareType = "Interprocess communication (IPC)";
						break;
					default :
						// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
						sprintf( shareQuery, "Unknown (%08lx)",cur->shi1_type );
						// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
						//sprintf( shareQuery, "Unknown (%08lx)",cur->shi2_type );
						strShareType = shareQuery;
					}

					/*
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					if ( cur->shi2_permissions & ACCESS_READ ) 
						strTempDisplay += "ACCESS_READ\r\n";
					else if ( cur->shi2_permissions & ACCESS_WRITE )
						strTempDisplay += "ACCESS_WRITE\r\n";
					else if ( cur->shi2_permissions & ACCESS_CREATE )
						strTempDisplay += "ACCESS_CREATE\r\n";
					else if ( cur->shi2_permissions & ACCESS_EXEC )
						strTempDisplay += "ACCESS_EXEC\r\n";
					else if ( cur->shi2_permissions & ACCESS_DELETE )
						strTempDisplay += "ACCESS_DELETE\r\n";
					else if ( cur->shi2_permissions & ACCESS_ATRIB )
						strTempDisplay += "ACCESS_ATRIB\r\n";
					else if ( cur->shi2_permissions & ACCESS_PERM )
						strTempDisplay += "ACCESS_PERM\r\n";
					else if ( cur->shi2_permissions & ACCESS_ALL )
						strTempDisplay += "ACCESS_ALL\r\n";
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					*/

					// get share resource comment
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					sprintf( shareQuery, "%S", cur->shi1_remark );
					// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					//sprintf( shareQuery, "%S", cur->shi2_remark );
					strShareComment = shareQuery;

					//----------------------
					// Add share resource
					//----------------------
					iPosition = FindShare( strShareName );
					// not found then add it
					if ( iPosition == -1 ) {
						AddShare( strShareName,
								  strShareComment,
								  strShareType );
					}
					//----------------------
					// Add share resource
					//----------------------
				}

				NetApiBufferFree(buff); // clear buffer
			}
		}
	} while ( retShare == ERROR_MORE_DATA );
	// ----------------------------------------------------------------
	// Get Share Resource
	// ----------------------------------------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Add Share in Host
//	Parameter	: strShareName(IN)		>>
//				  strShareComment(IN)	>>
//				  strShareType(IN)		>>
void CHost::AddShare(CString strShareName, CString strShareComment, CString strShareType)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////	
	// Create a new CShare Object 
	CShare *pShare = new CShare( strShareName, 
								 strShareComment, 
								 strShareType );
	try {
		// Add new Share to Share Array
		m_saShares.Add( pShare );
	}
	catch ( CMemoryException *pErr ) {
		AfxMessageBox( "Out of memory, please exit program and start again.", 
					   MB_ICONSTOP | MB_OK );
		// if create CShare Object delete it
		if ( pShare ) {
			delete pShare;
			pShare = NULL;
		}
		// Delete the exception object
		pErr->Delete( );
	}
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////	
}

//////////////////////////////////////////////////////////////////////
//	Description : Find Share in Host by share name
//	Parameter	: strShareName(IN)	>>	
//	Return		: int				>>	-1=Not Found, 0...n=Found and return position
//
int CHost::FindShare(CString strShareName)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strShareNameCheck;

	int i, iSize;
	int iFound = -1;

	iSize = m_saShares.GetSize( );
	for ( i=0; i<iSize; i++ ) {
		strShareNameCheck = m_saShares[i]->GetShareName( );

		// Match Share Name
		if ( strShareName == strShareNameCheck ) {
			iFound = i; // set position
			break;
		}
	}
	return iFound;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

CShareArray* CHost::GetShares()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return &m_saShares;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database
//					Table >> Host, MAC, UseVendor, HasPort
//	
void CHost::StoreDB()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	
	//--------------------------------
	//  Store in table Host
	//--------------------------------
	this->StoreHostDB( );
	//--------------------------------
	//  Store in table Host
	//--------------------------------

	//--------------------------------
	//  Store in table MAC
	//--------------------------------
	this->StoreMACDB( );
	//--------------------------------
	//  Store in table MAC
	//--------------------------------

	//--------------------------------
	//  Store in table UseVendor
	//--------------------------------
	this->StoreUseVendorDB( );
	//--------------------------------
	//  Store in table UseVendor
	//--------------------------------

	//--------------------------------
	//  Store in table HasPort
	//--------------------------------
	this->StoreHasPortDB( );
	//--------------------------------
	//  Store in table HasPort
	//--------------------------------

	int i;
	CString strIP;
	strIP = this->m_strIP;

	//--------------------------------------
	//  Store for each share
	//--------------------------------------
	CShare *pShare;
	int iSizeShare;

	iSizeShare = m_saShares.GetSize( );
	for ( i=0; i<iSizeShare; i++ ) {
		pShare = m_saShares.ElementAt( i );
		pShare->StoreDB( strIP );
	}
	//--------------------------------------
	//  Store for each share
	//--------------------------------------

	//-------------------------
	//  Store for each user
	//-------------------------
	CUser *pUser;
	int iSizeUser;

	iSizeUser = m_uaUsers.GetSize( );
	for ( i=0; i<iSizeUser; i++ ) {
		pUser = m_uaUsers.ElementAt( i );
		pUser->StoreDB( strIP );
	}
	//-------------------------
	//  Store for each user
	//-------------------------

	//-------------------------------------------------
	//  Store for each group
	//-------------------------------------------------
	CGroup *pGroup;
	int iSizeGroup;

	iSizeGroup = m_gaGroups.GetSize( );
	for ( i=0; i<iSizeGroup; i++ ) {
		pGroup = m_gaGroups.ElementAt( i );
		pGroup->StoreDB( strIP );
	}
	//-------------------------------------------------
	//  Store for each group
	//-------------------------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table Host
//	
void CHost::StoreHostDB()
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////

	//--------------------------------
	//  Store in table Host
	//--------------------------------
	CString strSQL;
	CDaoHostSet daoHostSet;

	// data
	long lRowCount;
	CString strIP;
	CString strHostName;
	CString strOS;
	BOOL bSnmp;
	CString strType;
	COleDateTime tOpenTime;
	COleDateTime tOpenDate;
	COleDateTime tCloseTime;
	COleDateTime tCloseDate;
	CString	strMinLength;
	CString	strMinAge;
	CString	strMaxAge;
	CString	strLockoutDuration;
	CString	strLockoutReset;
	CString	strLockoutThreshold;

	// set data
	strIP		= this->m_strIP;
	strHostName	= this->m_strHostName;
	strOS		= this->m_strOS;
	bSnmp		= this->m_bSnmp;
	strType		= this->m_strType;
	tOpenTime.SetTime( this->m_timeOpen.GetHour( ),
					   this->m_timeOpen.GetMinute( ),
					   this->m_timeOpen.GetSecond( ) );
	tOpenDate.SetDate( this->m_timeOpen.GetYear( ),
					   this->m_timeOpen.GetMonth( ),
					   this->m_timeOpen.GetDay( ) );
	tCloseTime.SetTime( this->m_timeClose.GetHour( ),
						this->m_timeClose.GetMinute( ),
						this->m_timeClose.GetSecond( ) );
	tCloseDate.SetDate( this->m_timeClose.GetYear( ),
						this->m_timeClose.GetMonth( ),
						this->m_timeClose.GetDay( ) );
	strMinLength= this->m_strMinLength;
	strMinAge	= this->m_strMinAge;
	strMaxAge	= this->m_strMaxAge;
	strLockoutDuration	= this->m_strLockoutDuration;
	strLockoutReset		= this->m_strLockoutReset;
	strLockoutThreshold	= this->m_strLockoutThreshold;

	// create SQL statement
	strSQL =  "SELECT IP, HostName, OS, Type, SNMP, ";
	strSQL += "OpenTime, OpenDate, CloseTime, CloseDate, ";
	strSQL += "MinLength, MinAge, MaxAge, ";
	strSQL += "LockoutDuration, LockoutReset, LockoutThreshold ";
	strSQL += "FROM Host WHERE IP='";
	strSQL += strIP;
	strSQL += "'";

	// open database
	if ( daoHostSet.IsOpen( ) )
		daoHostSet.Close( );
	daoHostSet.Open( dbOpenDynaset, _T( strSQL ) );
	lRowCount = daoHostSet.GetRecordCount( );

	// if row is not exist (lRowCount==0) then INSERT it
	if ( lRowCount == 0 ) {
		// Insert
		daoHostSet.AddNew( );
		
		daoHostSet.m_IP			= strIP;
		daoHostSet.m_HostName	= strHostName;
		daoHostSet.m_OS			= strOS;
		daoHostSet.m_SNMP		= bSnmp;
		daoHostSet.m_Type		= strType;
		daoHostSet.m_OpenTime	= tOpenTime;
		daoHostSet.m_OpenDate	= tOpenDate;
		daoHostSet.m_CloseTime	= tCloseTime;
		daoHostSet.m_CloseDate	= tCloseDate;
		daoHostSet.m_MinLength	= strMinLength;
		daoHostSet.m_MinAge		= strMinAge;
		daoHostSet.m_MaxAge		= strMaxAge;
		daoHostSet.m_LockoutDuration	= strLockoutDuration;
		daoHostSet.m_LockoutReset		= strLockoutReset;
		daoHostSet.m_LockoutThreshold	= strLockoutThreshold;

		daoHostSet.Update( );
	}
	// if row is exist (lRowCount>0) then UPDATE it
	else {
		// Update
		daoHostSet.MoveFirst( );
		daoHostSet.Edit( );
		
		daoHostSet.m_HostName	= strHostName;
		daoHostSet.m_OS			= strOS;
		daoHostSet.m_SNMP		= bSnmp;
		daoHostSet.m_Type		= strType;
		daoHostSet.m_OpenTime	= tOpenTime;
		daoHostSet.m_OpenDate	= tOpenDate;
		daoHostSet.m_CloseTime	= tCloseTime;
		daoHostSet.m_CloseDate	= tCloseDate;
		daoHostSet.m_MinLength	= strMinLength;
		daoHostSet.m_MinAge		= strMinAge;
		daoHostSet.m_MaxAge		= strMaxAge;
		daoHostSet.m_LockoutDuration	= strLockoutDuration;
		daoHostSet.m_LockoutReset		= strLockoutReset;
		daoHostSet.m_LockoutThreshold	= strLockoutThreshold;

		daoHostSet.Update( );
	}

	daoHostSet.Close( );
	//--------------------------------
	//  Store in table Host
	//--------------------------------

	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table MAC
//	
void CHost::StoreMACDB()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////

	//--------------------------------
	//  Store in table MAC
	//--------------------------------
	int i, iSizeMac;
	CString strSQL;
	CDaoMACSet daoMACSet;

	// data
	long lRowCount;
	CString strIP;
	CString strMacAddress;

	strIP = this->m_strIP;
	iSizeMac = m_saMacAddress.GetSize( );
	for ( i=0; i<iSizeMac; i++ ) {
		strMacAddress = m_saMacAddress[i];

		// create SQL statement
		strSQL =  "SELECT IP, MACAddress FROM MAC WHERE IP='";
		strSQL += strIP;
		strSQL += "' AND MACAddress='";
		strSQL += strMacAddress;
		strSQL += "'";

		// open database
		if ( daoMACSet.IsOpen( ) ) 
			daoMACSet.Close( );
		daoMACSet.Open( dbOpenDynaset, _T( strSQL ) );
		lRowCount = daoMACSet.GetRecordCount( );

		// if row is not exist (lRowCount==0) then INSERT it
		if ( lRowCount == 0 ) {
			// Insert
			daoMACSet.AddNew( );
			daoMACSet.m_IP = strIP;
			daoMACSet.m_MACAddress = strMacAddress;
			daoMACSet.Update( );
		}

		daoMACSet.Close( );
	}
	//--------------------------------
	//  Store in table MAC
	//--------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table UseVendor
//	
void CHost::StoreUseVendorDB()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////

	//--------------------------------
	//  Store in table UseVendor
	//--------------------------------
	int i, j;
	int iSizeMac, iSizeVendorName;
	CString strSQL;
	CDaoUseVendorSet daoUseVendorSet;
	CDaoMACVendorSet daoMACVendorSet;

	// data
	long lRowCount;
	CString strIP;
	CString strVendorMAC;
	CString strVendorName; // not use it direct but use it is temp

	strIP = this->m_strIP;
	iSizeMac = m_saMacAddress.GetSize( );
	for ( i=0; i<iSizeMac; i++ ) {
		// use string array because one Mac Address can more then one Mac Vendor Name
		CStringArray saVendorName; 
		strVendorMAC = (m_saMacAddress[i]).Left( 8 );

		//-------------------------------------------------
		// Find Mac Vendor Name and keep in string array (saVendorName)
		//-------------------------------------------------
		// create SQL statement
		strSQL =  "SELECT VendorMAC,VendorName FROM MACVendor ";
		strSQL += "WHERE VendorMAC='";
		strSQL += strVendorMAC;
		strSQL += "'";

		// open database
		if ( daoMACVendorSet.IsOpen( ) ) 
			daoMACVendorSet.Close( );
		daoMACVendorSet.Open( dbOpenDynaset, _T( strSQL ) );

		if ( !daoMACVendorSet.IsEOF( ) ) {
			// add vendor name to staring array
			daoMACVendorSet.MoveFirst( );
			while ( !daoMACVendorSet.IsEOF( ) ) {
				strVendorName = daoMACVendorSet.m_VendorName;
				saVendorName.Add( strVendorName );
				daoMACVendorSet.MoveNext( );
			}
		}
		else {
			saVendorName.Add( " " );
		}
		daoMACVendorSet.Close( );
		//-------------------------------------------------
		// Find Mac Vendor Name and keep in string array (saVendorName)
		//-------------------------------------------------

		//-----------------------------
		// store in table UseVendor
		//-----------------------------
		iSizeVendorName = saVendorName.GetSize( );
		for ( j=0; j<iSizeVendorName; j++ ) {
			strVendorName = saVendorName[j];
			
			// create SQL statement
			strSQL =  "SELECT IP, VendorMAC, VendorName FROM UseVendor ";
			strSQL += "WHERE IP='";
			strSQL += strIP;
			strSQL += "' AND VendorMAC='";
			strSQL += strVendorMAC;
			strSQL += "' AND VendorName='";
			strSQL += strVendorName;
			strSQL += "'";
			
			// open database 
			if ( daoUseVendorSet.IsOpen( ) ) 
				daoUseVendorSet.Close( );
			daoUseVendorSet.Open( dbOpenDynaset, _T( strSQL ) );
			lRowCount = daoUseVendorSet.GetRecordCount( );

			// if row is not exist (lRowCount==0) then INSERT it
			if ( lRowCount == 0 ) {
				// Insert
				daoUseVendorSet.AddNew( );
				daoUseVendorSet.m_IP		 = strIP;
				daoUseVendorSet.m_VendorMAC  = strVendorMAC;
				daoUseVendorSet.m_VendorName = strVendorName;
				daoUseVendorSet.Update( );
			}

			daoUseVendorSet.Close( );
		}
		//-----------------------------
		// store in table UseVendor
		//-----------------------------

		saVendorName.RemoveAll( ); // clear string array
	}
	//--------------------------------
	//  Store in table UseVendor
	//--------------------------------

	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Store all data to database in table HasPort
//	
void CHost::StoreHasPortDB()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////

	//--------------------------------
	//  Store in table HasPort
	//--------------------------------
	int i, iSizePort;
	CPort *pPort;
	CString strSQL;
	CDaoHasPortSet daoHasPortSet;

	// data
	long lRowCount;
	CString strIP;
	long lPortNumber;
	CString strPortNumber;
	CString strProtocol;
	CString strStatus;

	strIP = this->m_strIP;
	iSizePort = m_paPorts.GetSize( );
	for ( i=0; i<iSizePort; i++ ) {
		pPort = m_paPorts.ElementAt( i );
		lPortNumber = pPort->GetPortNumber( );
		strPortNumber.Format( "%ld", lPortNumber );
		strProtocol = pPort->GetProtocol( );
		strStatus	= pPort->GetStatus( );

		// create SQL statement
		strSQL =  "SELECT IP, PortNumber, Protocol, Status ";
		strSQL += "FROM HasPort WHERE IP='";
		strSQL += strIP;
		strSQL += "' AND PortNumber=";
		strSQL += strPortNumber;
		strSQL += " AND Protocol='";
		strSQL += strProtocol;
		strSQL += "'";

		// open database
		if ( daoHasPortSet.IsOpen( ) )
			daoHasPortSet.Close( );
		daoHasPortSet.Open( dbOpenDynaset, _T( strSQL ) );
		lRowCount = daoHasPortSet.GetRecordCount( );
		
		// if row is not exist (lRowCount==0) then INSERT it
		if ( lRowCount == 0 ) {
			// Insert
			daoHasPortSet.AddNew( );

			daoHasPortSet.m_IP			= strIP;
			daoHasPortSet.m_PortNumber	= lPortNumber;
			daoHasPortSet.m_Protocol	= strProtocol;
			daoHasPortSet.m_Status		= strStatus;

			daoHasPortSet.Update( );
		}
		// if row is exist (lRowCount>0) then UPDATE it
		else {
			// Update
			daoHasPortSet.MoveFirst( );
			daoHasPortSet.Edit( );

			daoHasPortSet.m_Status		= strStatus;

			daoHasPortSet.Update( );
		}

		daoHasPortSet.Close( );
	}
	//--------------------------------
	//  Store in table HasPort
	//--------------------------------
	
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

COleDateTime CHost::GetOpenTime()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_timeOpen;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}

COleDateTime CHost::GetCloseTime()
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	return m_timeClose;
	///////////////////////////
	// MY CODE END HERE
	///////////////////////////
}
