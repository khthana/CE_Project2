#if !defined(AFX_SNMPDLG_H__F96737A1_C65F_444B_BA9C_A258191524DA__INCLUDED_)
#define AFX_SNMPDLG_H__F96737A1_C65F_444B_BA9C_A258191524DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SnmpDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSnmpDlg dialog

class CSnmpDlg : public CDialog
{
// Construction
public:
	CString nIP;
	CString snmp[8];
	CSnmpDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSnmpDlg)
	enum { IDD = IDD_DIALOG_SNMP };
	CTreeCtrl	m_ctree;
	CString	m_snmp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSnmpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSnmpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTreeMib(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SNMPDLG_H__F96737A1_C65F_444B_BA9C_A258191524DA__INCLUDED_)
