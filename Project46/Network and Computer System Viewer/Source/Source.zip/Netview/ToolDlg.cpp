// ToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "ToolDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolDlg dialog


CToolDlg::CToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CToolDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CToolDlg)
	m_strParameter = _T("");
	m_strResult = _T("");
	//}}AFX_DATA_INIT
}


void CToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToolDlg)
	DDX_Control(pDX, IDOK, m_ctlClose);
	DDX_Control(pDX, IDC_BUTTON_START, m_ctlStart);
	DDX_Control(pDX, IDC_IPADDRESS_TOOL, m_ctlIPAddressTool);
	DDX_Control(pDX, IDC_COMBO_TOOLNAME, m_ctlToolName);
	DDX_Text(pDX, IDC_EDIT_PARAMETER, m_strParameter);
	DDX_Text(pDX, IDC_EDIT_RESULT, m_strResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CToolDlg, CDialog)
	//{{AFX_MSG_MAP(CToolDlg)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_COMBO_TOOLNAME, OnSelchangeComboToolname)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolDlg message handlers

BOOL CToolDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString strToolName;
	CToolArray *pTools;
	CTool *pTool;
	int i, iToolSize;
	int iToolPosition;

	m_bFirst = TRUE; // First show dialog
	pTools = m_pDiscover->GetTools( );
	iToolSize = pTools->GetSize( );
	for ( i=0; i<iToolSize; i++ ) {
		pTool = pTools->ElementAt( i );
		strToolName = pTool->GetToolName( );
		m_ctlToolName.InsertString( i, strToolName );
	}
	
	// set select tool to run
	iToolPosition = m_pDiscover->FindTool( m_strToolName );
	if ( iToolPosition != -1 ) {
		m_pTool = pTools->ElementAt( iToolPosition );
		m_ctlToolName.SetCurSel( iToolPosition );
	}
	else {
		m_pTool = NULL;
		m_ctlToolName.SetCurSel( 0 );
	}

	// set host's ip address for tooled
	if ( m_pHostDisplay != NULL ) {
		m_ctlIPAddressTool.SetWindowText( m_pHostDisplay->GetIP( ) );
	}

	// set parameter
	m_strParameter = m_pTool->GetParameter( );

	UpdateData( FALSE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CToolDlg::OnButtonStart() 
{
	// TODO: Add your control notification handler code here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CString	strCommand;
	CString strResult;
	CString strIP, strParameter;

	UpdateData( TRUE );

	m_ctlStart.EnableWindow( FALSE );
	m_ctlClose.EnableWindow( FALSE );
	m_ctlIPAddressTool.GetWindowText( strIP );

	// check any error
	if ( strIP == "0.0.0.0" ) {
		MessageBox( "Error IP Address. Please enter again.", 
					"Error IP Address", MB_ICONERROR );
		return;
	}
	if ( m_strParameter.Find( "%a" ) == -1 ) {
		MessageBox( "Error parameter. Please enter again.", 
					"Error Parameter", MB_ICONERROR );
		return;
	}
	if ( m_pTool == NULL ) {
		MessageBox( "This tool not found", 
					"Error Tool", MB_ICONERROR );
		return;
	}

	// create command
	strParameter = m_strParameter;
	strParameter.Replace( "%a", strIP );
	strCommand = m_pTool->GetToolPath( );
	strCommand += " ";
	strCommand += strParameter;
	
	CRedirect rdTool( strCommand, &strResult );
	rdTool.Run( );
	m_strResult = strResult;

	UpdateData( FALSE );
	m_ctlStart.EnableWindow( TRUE );
	m_ctlClose.EnableWindow( TRUE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}

void CToolDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here

	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	if ( m_bFirst == TRUE ) {
		OnButtonStart();
		m_bFirst = FALSE;
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	// Do not call CDialog::OnPaint() for painting messages
}

void CToolDlg::OnSelchangeComboToolname() 
{
	// TODO: Add your control notification handler code here

	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	CToolArray *pTools;
	CString strToolName;
	int iPosition, iToolPosition;

	iPosition = m_ctlToolName.GetCurSel( );
	m_ctlToolName.GetLBText( iPosition, strToolName );
	iToolPosition = m_pDiscover->FindTool( strToolName );
	pTools	= m_pDiscover->GetTools( );

	// set tool and parameter
	m_pTool = pTools->ElementAt( iToolPosition );
	m_strParameter = m_pTool->GetParameter( );
	UpdateData( FALSE );
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
