// WaitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "WaitDlg.h"

///////////////////////////
// MY INCLUDE START HERE
///////////////////////////
#include <afxmt.h>
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWaitDlg dialog


CWaitDlg::CWaitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWaitDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWaitDlg)
	m_strShow = _T("");
	//}}AFX_DATA_INIT
}


void CWaitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWaitDlg)
	DDX_Control(pDX, IDC_PROGRESS_WAIT, m_ctlProgressWait);
	DDX_Text(pDX, IDC_STATIC_SHOW, m_strShow);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWaitDlg, CDialog)
	//{{AFX_MSG_MAP(CWaitDlg)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWaitDlg message handlers

BOOL CWaitDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_ctlProgressWait.SetRange( 0, 100 );
	m_ctlProgressWait.SetStep( 5 );
	m_ctlProgressWait.SetPos( 0 );

	GetDlgItem(IDOK)->ShowWindow(m_bShowCancelButton ? SW_SHOW : SW_HIDE);
	SetTimer(ID_WAIT_TIMER,200,NULL); 

	this->SetCapture( ); 
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWaitDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	// Update progress bar
	m_ctlProgressWait.StepIt( );
	if ( m_ctlProgressWait.GetPos( ) == 100 ) {
		m_ctlProgressWait.SetPos( 0 );
	}
	UpdateData( FALSE );

	CSingleLock lock(m_Thread->m_Event, FALSE);

	if ( lock.Lock(0) ) {
		CDialog::OnOK();
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
	
	//CDialog::OnTimer(nIDEvent);
}

void CWaitDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	if (m_bShowCancelButton) {
		m_Thread->m_Event->SetEvent();

		ReleaseCapture( );
		CDialog::OnOK();
	}
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////

	CDialog::OnOK();
}

void CWaitDlg::SetShowMessage(CString strShow)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	this->m_strShow = strShow;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
