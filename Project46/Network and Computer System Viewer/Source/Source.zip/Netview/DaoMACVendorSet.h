#if !defined(AFX_DAOMACVENDORSET_H__2E3AD6E0_3336_4955_AF2E_7C86EE33CFAF__INCLUDED_)
#define AFX_DAOMACVENDORSET_H__2E3AD6E0_3336_4955_AF2E_7C86EE33CFAF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DaoMACVendorSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoMACVendorSet DAO recordset

class CDaoMACVendorSet : public CDaoRecordset
{
public:
	CDaoMACVendorSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaoMACVendorSet)

// Field/Param Data
	//{{AFX_FIELD(CDaoMACVendorSet, CDaoRecordset)
	CString	m_VendorMAC;
	CString	m_VendorName;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoMACVendorSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOMACVENDORSET_H__2E3AD6E0_3336_4955_AF2E_7C86EE33CFAF__INCLUDED_)
