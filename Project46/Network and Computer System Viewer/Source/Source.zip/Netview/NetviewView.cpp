// NetviewView.cpp : implementation of the CNetviewView class
//

#include "stdafx.h"
#include "Netview.h"

#include "NetviewDoc.h"
#include "NetviewView.h"

///////////////////////////
// MY INCLUDE START HERE
///////////////////////////
#include "PropHostSheet.h"
#include "SetAutoRefreshDlg.h"
///////////////////////////
// MY INCLUDE END HERE
///////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetviewView

IMPLEMENT_DYNCREATE(CNetviewView, CScrollView)

BEGIN_MESSAGE_MAP(CNetviewView, CScrollView)
	//{{AFX_MSG_MAP(CNetviewView)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetviewView construction/destruction

CNetviewView::CNetviewView()
{
	// TODO: add construction code here

}

CNetviewView::~CNetviewView()
{
}

BOOL CNetviewView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CNetviewView drawing

void CNetviewView::OnDraw(CDC* pDC)
{
	CNetviewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	this->SetViewSize( );

	int i, iHostSize;
	CRectTracker *pPosition;

	// Border
	CRect rectBorder;			// Rect for border
	CBrush brushBorder;			// Brush for paint border
	CBrush	*pOldBrush	= NULL;
	int iExp = 1;				// Expand border size

	CNetviewDoc *pNetviewDoc = (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork = pNetviewDoc->GetNetworkDisplay( );
	CHostArray *pHosts = pNetwork->GetHostArray( );
	CHost *pHost;
	iHostSize = pHosts->GetSize( );
	
	//---------------------------------------------
	// Load Bitmap
	//---------------------------------------------
	CBitmap bmpBitmap;
	BITMAP bm;
	bmpBitmap.LoadBitmap( IDB_BITMAP_HOST_OPEN );
	bmpBitmap.GetBitmap( &bm );
	//---------------------------------------------
	// Load Bitmap
	//---------------------------------------------
	
	//-----------------------------------------------------------
	// Set host position to display(draw)
	//-----------------------------------------------------------
	int iX, iY;
	int iHeightHost, iWidthHost;	// actual host draw size
	int iCountRow;					// count host in one row
	CRect rectClient;
	this->GetClientRect( &rectClient );
	// init start position ( iX, iY )
	iX = 50;
	iY = 20;
	iHeightHost	= bm.bmHeight + 70;
	iWidthHost	= bm.bmWidth + 70;
	iCountRow = 1;
	for ( i=0; i<iHostSize; i++ ) {
		pHost = pHosts->ElementAt( i );
		pPosition = pHost->GetPosition( );
		pPosition->m_rect.left	= iX;
		pPosition->m_rect.top	= iY;
		pPosition->m_rect.right	= iX + bm.bmWidth;
		pPosition->m_rect.bottom= iY + bm.bmHeight;

		// Next host position
		iCountRow++;
		// if full row for display then enter new row
		if ( (iCountRow*iWidthHost) > rectClient.Width( ) ) {
			iY = iY + iHeightHost;	// enter new row
			iX = 50;				// carriage return
			iCountRow = 1;			// reset first host in new row
		}
		// if not full row then plus iX (Width) position
		else {
			iX = iX + iWidthHost;
		}		
	}
	//-----------------------------------------------------------
	// Set host position to display(draw)
	//-----------------------------------------------------------

	//---------------------------------------------------------------
	// Draw host image
	//---------------------------------------------------------------
	int iTextX, iTextY;
	CString strIPAddress;
	CBitmap *pOldBitmap = NULL;
	CBitmap *pBitmap;

	TRY {
		// create device context for load bitmap into
		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );
		
		// get text characteristic for calculate position to show text (Newwork Address)
		TEXTMETRIC tm;
		pDC->GetTextMetrics( &tm );

		//-------------------------------------------------------
		// Draw select border
		//-------------------------------------------------------
		pHost = pNetviewDoc->GetHostDisplay( );
		if ( (pHost != NULL) && (pHosts->GetSize( ) > 0) ) {
			pPosition = pHost->GetPosition( );
		
			SetBorderRect( rectBorder, pPosition->m_rect, iExp );
			brushBorder.CreateSolidBrush( RGB( 0, 0, 255 ) );
	
			// select brush to compatible device
			pOldBrush = pDC->SelectObject( &brushBorder );
			pDC->PatBlt( rectBorder.left, rectBorder.top,
						 rectBorder.Width( ), rectBorder.Height( ),
						 PATCOPY );
			// Set old brush
			if ( pOldBrush != NULL ) {
				pDC->SelectObject( pOldBrush );
				pOldBrush = NULL;
			}
			brushBorder.DeleteObject( );
		}
		//-------------------------------------------------------
		// Draw select border
		//-------------------------------------------------------

		// For each (Host object) do draw in it's position
		for ( i=0; i<iHostSize; i++ ) {
			pHost = pHosts->ElementAt( i );
			pPosition = pHost->GetPosition( );

			//----------------
			// Select image
			//----------------
			pHost->SelectBitmap( );
			//----------------
			// Select image
			//----------------

			//----------------
			// Draw image
			//----------------
			pBitmap = pHost->GetBitmap( );
			// select bitmap to compatible device
			pOldBitmap = dcMem.SelectObject( pBitmap );
			pDC->StretchBlt( pPosition->m_rect.left,
							 pPosition->m_rect.top,
							 pPosition->m_rect.Width( ),
							 pPosition->m_rect.Height( ),
							 &dcMem,
							 0, 0, bm.bmWidth, bm.bmHeight,
							 SRCCOPY );
			// set old bitmap
			if ( pOldBitmap != NULL ) {
				pDC->SelectObject( pOldBitmap );
				pOldBitmap = NULL;
			}

			//----------------
			// Draw text (IP Address) for each host
			//----------------
			strIPAddress = pHost->GetIP( );
			// Calculate position for show text
			iTextX = pPosition->m_rect.left + (pPosition->m_rect.Width( )/2);
			iTextY = pPosition->m_rect.bottom + 3;
			pDC->SetTextAlign( TA_CENTER );
			pDC->TextOut( iTextX, iTextY, strIPAddress );
		}

	}
	CATCH_ALL ( exception ) {
		// set old bitmap
		if ( pOldBitmap != NULL ) {
			pDC->SelectObject( pOldBitmap );
		}
	}
	END_CATCH_ALL
	//---------------------------------------------------------------
	// Draw host image
	//---------------------------------------------------------------

	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetviewView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	// TODO: calculate the total size of this view

	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	int iHeightHost, iWidthHost;	// actual host draw size
	int iCountRow;					// count host in one row
	CRect rectClient;
	this->GetClientRect( &rectClient );

	int i, iSize;
	BITMAP bm;
	CBitmap bmpBitmap;
	CSize sizeTotal;

	CNetviewDoc *pNetviewDoc = (CNetviewDoc*)this->GetDocument( );
	CHostArray *pHosts = pNetviewDoc->GetNetworkDisplay( )->GetHostArray( );
	iSize = pHosts->GetSize( );
	bmpBitmap.LoadBitmap( IDB_BITMAP_NETWORK_CONNECT );
	bmpBitmap.GetBitmap( &bm );
	
	// make scroll view
	sizeTotal.cx = 50;
	sizeTotal.cy = 20;
	iHeightHost	= bm.bmHeight + 70;
	iWidthHost	= bm.bmWidth + 70;
	iCountRow = 1;
	for ( i=0; i<iSize; i++ ) { // increase height by number of network

		// Next host position
		iCountRow++;
		// if full row for display then enter new row
		if ( (iCountRow*iWidthHost) > rectClient.Width( ) ) {
			sizeTotal.cy = sizeTotal.cy + iHeightHost;
			sizeTotal.cx = 50;
			iCountRow = 1;			// reset first host in new row
		}
		// if not full row then plus iX (Width) position
		else {
			sizeTotal.cx = sizeTotal.cx + iWidthHost;
		}
	}

	SetScrollSizes( MM_TEXT, sizeTotal );

	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

/////////////////////////////////////////////////////////////////////////////
// CNetviewView printing

BOOL CNetviewView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNetviewView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNetviewView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CNetviewView diagnostics

#ifdef _DEBUG
void CNetviewView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CNetviewView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CNetviewDoc* CNetviewView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNetviewDoc)));
	return (CNetviewDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNetviewView message handlers

void CNetviewView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	// no hint pass
	if ( lHint == 0 ) { 
		this->Invalidate( );	
	}
	// have hint pass ( CRect )
	else { 
		this->InvalidateRect( ( CRect* )pHint ); // Update draw rect
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set border from original rect
//	Parameter	:	rectBorder(IN/OUT)	>>	border rect
//					rect(IN)			>>	original rect
//					iExp(IN)			>>	expand size
//	
void CNetviewView::SetBorderRect(CRect &rectBorder, CRect &rect, int iExp)
{
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	rectBorder.left		= rect.left - iExp;
	rectBorder.top		= rect.top - iExp;
	rectBorder.right	= rect.right + iExp;
	rectBorder.bottom	= rect.bottom + iExp;
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set scroll view size
//
void CNetviewView::SetViewSize()
{
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	int iHeightHost, iWidthHost;	// actual host draw size
	int iCountRow;					// count host in one row
	CRect rectClient;
	this->GetClientRect( &rectClient );

	int i, iSize;
	BITMAP bm;
	CBitmap bmpBitmap;
	CSize sizeTotal;

	CNetviewDoc *pNetviewDoc = (CNetviewDoc*)this->GetDocument( );
	CHostArray *pHosts = pNetviewDoc->GetNetworkDisplay( )->GetHostArray( );
	iSize = pHosts->GetSize( );
	bmpBitmap.LoadBitmap( IDB_BITMAP_NETWORK_CONNECT );
	bmpBitmap.GetBitmap( &bm );
	
	// make scroll view
	sizeTotal.cx = 50;
	sizeTotal.cy = 20;
	iHeightHost	= bm.bmHeight + 70;
	iWidthHost	= bm.bmWidth + 70;
	iCountRow = 1;
	for ( i=0; i<iSize; i++ ) { // increase height by number of network

		// Next host position
		iCountRow++;
		// if full row for display then enter new row
		if ( (iCountRow*iWidthHost) > rectClient.Width( ) ) {
			sizeTotal.cy = sizeTotal.cy + iHeightHost;
			sizeTotal.cx = 50;
			iCountRow = 1;			// reset first host in new row
		}
		// if not full row then plus iX (Width) position
		else {
			sizeTotal.cx = sizeTotal.cx + iWidthHost;
		}
	}
	sizeTotal.cy = sizeTotal.cy + iHeightHost;

	SetScrollSizes( MM_TEXT, sizeTotal );
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetviewView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////

	// converts device coordinates into logical coordinates
	CClientDC clientDC( this );
	OnPrepareDC( &clientDC );
	clientDC.DPtoLP( &point );

	CNetviewDoc *pDoc	= (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork	= (CNetwork*)pDoc->GetNetworkDisplay( );
	CHostArray *pHosts	= (CHostArray*)pNetwork->GetHostArray( );
	CHost *pHost;
	CRectTracker *pPosition;
	CRect rectTrue, rectBorder;
	int i;

	for ( i=0; i<pHosts->GetSize( ); i++ ) {
		pHost = pHosts->ElementAt( i );
		pPosition = pHost->GetPosition( );
		// check mouse double click with host position
		if ( pPosition->HitTest( point ) >= 0 ) {
			// Set double click Host which display host property in 
			//  this view (CNetviewView, Host View)
			pDoc->SetHostDisplay( pHost );
 
			// update CNetviewView (Host view) view
			pPosition->GetTrueRect( &rectTrue );
			SetBorderRect( rectBorder, rectTrue, 1 );
			pDoc->UpdateAllViews( NULL, ( LPARAM )( LPCRECT )rectBorder );

			//----------------------------------------------------------------
			//  Show property sheet
			//----------------------------------------------------------------
			CPropHostSheet propHostSheet( "Host Properties" );
			CStringArray *pMacAddress = pHost->GetMacAddress( );
			CPortArray *pPorts		= pHost->GetPorts( );
			CUserArray *pUsers		= pHost->GetUsers( );
			CGroupArray *pGroups	= pHost->GetGroups( ); 
			CShareArray	*pShares	= pHost->GetShares( );

			// set host data to host property page
			propHostSheet.m_propHostPage.m_strIP = pHost->GetIP( );
			propHostSheet.m_propHostPage.m_strHostName = pHost->GetHostName( );
			propHostSheet.m_propHostPage.m_strType = pHost->GetType( );
			propHostSheet.m_propHostPage.m_strOS = pHost->GetOS( );
			propHostSheet.m_propHostPage.m_strOpenTime = pHost->GetOpenTimeString( );
			propHostSheet.m_propHostPage.m_strCloseTime	= pHost->GetCloseTimeString( );
			propHostSheet.m_propHostPage.m_strPasswordMinLength = pHost->GetPasswordMinLength( );
			propHostSheet.m_propHostPage.m_strPasswordMinAge	= pHost->GetPasswordMinAge( );
			propHostSheet.m_propHostPage.m_strPasswordMaxAge	= pHost->GetPasswordMaxAge( );
			propHostSheet.m_propHostPage.m_strLockoutDuration	= pHost->GetLockoutDuration( );
			propHostSheet.m_propHostPage.m_strLockoutReset		= pHost->GetLockoutReset( );
			propHostSheet.m_propHostPage.m_strLockoutThreshold	= pHost->GetLockoutThreshold( );
			propHostSheet.m_propHostPage.m_saMacAddress.Copy( *pMacAddress );
			// set port data to port property page
			propHostSheet.m_propPortPage.m_paPorts.Copy( *pPorts );
			// set user and group data to user and group property page
			propHostSheet.m_propUserAndGroupPage.m_uaUsers.Copy( *pUsers );
			propHostSheet.m_propUserAndGroupPage.m_gaGroups.Copy( *pGroups );
			// set share data to share property page
			propHostSheet.m_propSharePage.m_saShares.Copy( *pShares );
			// set snmp data to snmp property page
			propHostSheet.m_propSnmpPage.nIP = pHost->GetIP( );
			propHostSheet.m_propSnmpPage.m_pHost = pHost;

			propHostSheet.DoModal( );
			//----------------------------------------------------------------
			//  Show property sheet
			//----------------------------------------------------------------
		}
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////

	CScrollView::OnLButtonDblClk(nFlags, point);
}

void CNetviewView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////

	// converts device coordinates into logical coordinates
	CClientDC clientDC( this );
	OnPrepareDC( &clientDC );
	clientDC.DPtoLP( &point );

	CNetviewDoc *pDoc	= (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork	= (CNetwork*)pDoc->GetNetworkDisplay( );
	CHostArray *pHosts	= (CHostArray*)pNetwork->GetHostArray( );
	CHost *pHost;
	CRectTracker *pPosition;
	CRect rectTrue, rectBorder;
	int i;

	for ( i=0; i<pHosts->GetSize( ); i++ ) {
		pHost = pHosts->ElementAt( i );
		pPosition = pHost->GetPosition( );
		// check mouse double click with host position
		if ( pPosition->HitTest( point ) >= 0 ) {
			// Set double click Host which display host property in 
			//  this view (CNetviewView, Host View)
			pDoc->SetHostDisplay( pHost );
 
			// update CNetviewView (Host view) view
			pPosition->GetTrueRect( &rectTrue );
			SetBorderRect( rectBorder, rectTrue, 1 );
			pDoc->UpdateAllViews( NULL, ( LPARAM )( LPCRECT )rectBorder );
		}
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////

	CScrollView::OnLButtonDown(nFlags, point);
}

void CNetviewView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	// Convert screen coordinates to device coordinates 
	this->ScreenToClient( &point );
	// converts device coordinates into logical coordinates
	CClientDC clientDC( this );
	OnPrepareDC( &clientDC );
	clientDC.DPtoLP( &point );
	
	CNetviewDoc *pDoc	= (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork	= (CNetwork*)pDoc->GetNetworkDisplay( );
	CHostArray *pHosts	= (CHostArray*)pNetwork->GetHostArray( );
	CHost *pHost;
	CRectTracker *pPosition;
	CRect rectTrue, rectBorder;
	CMenu menu, *pSubMenu;
	int i;

	for ( i=0; i<pHosts->GetSize( ); i++ ) {
		pHost = pHosts->ElementAt( i );
		pPosition = pHost->GetPosition( );
		// check mouse double click with host position
		if ( pPosition->HitTest( point ) >= 0 ) {
			// Set double click Host which display host property in 
			//  this view (CNetviewView, Host View)
			pDoc->SetHostDisplay( pHost );
 
			// update CNetviewView (Host view) view
			pPosition->GetTrueRect( &rectTrue );
			SetBorderRect( rectBorder, rectTrue, 1 );
			pDoc->UpdateAllViews( NULL, ( LPARAM )( LPCRECT )rectBorder );

			// converts logical coordinates into device coordinates
			clientDC.LPtoDP( &point );
			// Convert device coordinates to screen coordinates
			this->ClientToScreen( &point );

			// Load the context menu
			menu.LoadMenu( IDR_NETVIETYPE );
			// Get the first sub menu (network context menu)
			pSubMenu = menu.GetSubMenu( 3 );
			
			// Display the context menu
			pSubMenu->TrackPopupMenu( TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON,
									  point.x, point.y, AfxGetMainWnd( ) );

			break;
		}
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}