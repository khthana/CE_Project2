#if !defined(AFX_MRTGDLG_H__D8F05D6E_A5E7_45F4_96F9_F7F7FE1C161E__INCLUDED_)
#define AFX_MRTGDLG_H__D8F05D6E_A5E7_45F4_96F9_F7F7FE1C161E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MrtgDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMrtgDlg dialog

class CMrtgDlg : public CDialog
{
// Construction
public:
	void Output(CPaintDC*);
	~CMrtgDlg();
	CString m_Path;
	CString m_sFilePath;
	CString m_sBitmap;
	CBitmap m_bmpBitmap;
	CMrtgDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMrtgDlg)
	enum { IDD = IDD_DIALOG_MRTG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMrtgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CString GetTimeString(COleDateTime time);
	CString GetDateString(COleDateTime time);
	void SetPrintReportTitle(CDC *pDC, int &y );
	void SetPrintReportPage(CDC *pDC);
	void SetPrintAlign(CDC *pDC, HDC hdcPrn);

	// Generated message map functions
	//{{AFX_MSG(CMrtgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonClose();
	afx_msg void OnButtonPrint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MRTGDLG_H__D8F05D6E_A5E7_45F4_96F9_F7F7FE1C161E__INCLUDED_)
