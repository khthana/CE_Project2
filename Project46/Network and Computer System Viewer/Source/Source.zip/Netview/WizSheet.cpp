// WizSheet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "WizSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizSheet

IMPLEMENT_DYNAMIC(CWizSheet, CPropertySheet)

CWizSheet::CWizSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	this->AddPage( &m_wizPage01 );
	this->AddPage( &m_wizPage02 );
	this->AddPage( &m_wizPage03 );
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CWizSheet::CWizSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
	this->AddPage( &m_wizPage01 );
	this->AddPage( &m_wizPage02 );
	this->AddPage( &m_wizPage03 );
	///////////////////////////
	// MY CODE START HERE
	///////////////////////////
}

CWizSheet::~CWizSheet()
{
}


BEGIN_MESSAGE_MAP(CWizSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CWizSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizSheet message handlers
