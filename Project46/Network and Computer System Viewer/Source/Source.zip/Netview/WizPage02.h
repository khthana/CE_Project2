#if !defined(AFX_WIZPAGE02_H__AECFB6F1_183B_4DF2_86F3_E77FF184E6C0__INCLUDED_)
#define AFX_WIZPAGE02_H__AECFB6F1_183B_4DF2_86F3_E77FF184E6C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WizPage02.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWizPage02 dialog

class CWizPage02 : public CPropertyPage
{
	DECLARE_DYNCREATE(CWizPage02)

// Construction
public:
	CStringArray m_saAgentIP;
	CString m_strNetmask;
	CString m_strIPEnd;
	CString m_strIPStart;
	CWizPage02();
	~CWizPage02();

// Dialog Data
	//{{AFX_DATA(CWizPage02)
	enum { IDD = IDD_WIZPAGE02 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWizPage02)
	public:
	virtual BOOL OnSetActive();
	virtual BOOL OnQueryCancel();
	virtual LRESULT OnWizardNext();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int CheckClassless(CString IPStart, CString IPEnd, CString Netmask, int type);
	// Generated message map functions
	//{{AFX_MSG(CWizPage02)
	afx_msg void OnPaint();
	afx_msg void OnButtonAddagentip();
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonRemoveagentip();
	afx_msg void OnButtonRemoveallagentip();
	afx_msg void OnFieldchangedIpaddressStart(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WIZPAGE02_H__AECFB6F1_183B_4DF2_86F3_E77FF184E6C0__INCLUDED_)
