#if !defined(AFX_PROPSNMPPAGE_H__91B625AB_B9BE_4554_9715_21E7D32CEB55__INCLUDED_)
#define AFX_PROPSNMPPAGE_H__91B625AB_B9BE_4554_9715_21E7D32CEB55__INCLUDED_

#include "Host.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropSnmpPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropSnmpPage dialog

class CPropSnmpPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropSnmpPage)

// Construction
public:
	CHost *m_pHost;
	CString nIP;
	CString snmp[8];
	CPropSnmpPage();
	~CPropSnmpPage();

// Dialog Data
	//{{AFX_DATA(CPropSnmpPage)
	enum { IDD = IDD_PROPPAGE_SNMP };
	CTreeCtrl	m_ctree;
	CString	m_snmp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropSnmpPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropSnmpPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTreeMib(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPSNMPPAGE_H__91B625AB_B9BE_4554_9715_21E7D32CEB55__INCLUDED_)
