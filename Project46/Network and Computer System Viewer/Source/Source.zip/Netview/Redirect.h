// Redirect.h: interface for the CRedirect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REDIRECT_H__D95C0711_BAE4_4CBE_B724_43BAF60EE529__INCLUDED_)
#define AFX_REDIRECT_H__D95C0711_BAE4_4CBE_B724_43BAF60EE529__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRedirect  
{
public:
	virtual void Run( );
	CRedirect( LPCTSTR szCommand, CString *pResult, LPCTSTR szCurrentDirectory = NULL );
	virtual ~CRedirect();

protected:
	void PeekAndPump( );
	void AppendText( LPCTSTR text );
	LPCTSTR m_szCurrentDirectory;
	CString *m_pResult;
	LPCTSTR m_szCommand;
};

#endif // !defined(AFX_REDIRECT_H__D95C0711_BAE4_4CBE_B724_43BAF60EE529__INCLUDED_)
