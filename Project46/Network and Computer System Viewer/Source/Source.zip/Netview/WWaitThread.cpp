// WWaitThread.cpp : implementation file
//

#include <afxmt.h>
#include "stdafx.h"
#include "WWaitThread.h"
#include "WaitDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWWaitThread

IMPLEMENT_DYNCREATE(CWWaitThread, CWinThread)

CWWaitThread::CWWaitThread()
{
  m_bShowCancelButton = false;
}

CWWaitThread::~CWWaitThread()
{
}

BOOL CWWaitThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
   CWaitDlg dlg;
   dlg.SetShowMessage( m_strShow );
   m_pMainWnd = &dlg;
   m_Event = new CEvent(FALSE, TRUE, m_Eventname);
   dlg.m_bShowCancelButton = m_bShowCancelButton;
   //dlg.m_Text = m_Text;
   dlg.m_Thread = this;
   dlg.DoModal();
   dlg.SetShowMessage( m_strShow );
   delete m_Event;
	return FALSE;
}

int CWWaitThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CWWaitThread, CWinThread)
	//{{AFX_MSG_MAP(CWWaitThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWWaitThread message handlers

void CWWaitThread::SetShowMessage(CString strShow)
{
	//////////////////////////
	// MY CODE START HERE
	//////////////////////////
	m_strShow = strShow;
	//////////////////////////
	// MY CODE END HERE
	//////////////////////////
}
