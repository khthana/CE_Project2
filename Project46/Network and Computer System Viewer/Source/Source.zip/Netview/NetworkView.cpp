// NetworkView.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "NetworkView.h"

////////////////////////////
// MY INCLUDE START HERE
////////////////////////////
#include "NetviewDoc.h"
#include "NetviewView.h"
#include "SnmpDlg.h"
#include "MrtgDlg.h"
////////////////////////////
// MY INCLUDE START HERE
////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetworkView

IMPLEMENT_DYNCREATE(CNetworkView, CScrollView)

CNetworkView::CNetworkView()
{	
}

CNetworkView::~CNetworkView()
{
}


BEGIN_MESSAGE_MAP(CNetworkView, CScrollView)
	//{{AFX_MSG_MAP(CNetworkView)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_NETWORK_SNMP, OnNetworkSnmp)
	ON_COMMAND(ID_NETWORK_TRAFFIC, OnNetworkTraffic)
	ON_UPDATE_COMMAND_UI(ID_NETWORK_SNMP, OnUpdateNetworkSnmp)
	ON_UPDATE_COMMAND_UI(ID_NETWORK_TRAFFIC, OnUpdateNetworkTraffic)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetworkView drawing

void CNetworkView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	// TODO: calculate the total size of this view

	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	int i, iSize;
	BITMAP bm;
	CBitmap bmpBitmap;
	CSize sizeTotal;

	CNetviewDoc *pNetviewDoc = (CNetviewDoc*)this->GetDocument( );
	CNetworkArray *pNetworks = pNetviewDoc->GetNetworks( );
	iSize = pNetworks->GetSize( );
	bmpBitmap.LoadBitmap( IDB_BITMAP_NETWORK_CONNECT );
	bmpBitmap.GetBitmap( &bm );
	
	// make scroll view
	sizeTotal.cx = 125;
	sizeTotal.cy = 15;
	for ( i=0; i<iSize; i++ ) { // increase height by number of network
		sizeTotal.cy = sizeTotal.cy + bm.bmHeight + 35;
	}

	SetScrollSizes( MM_TEXT, sizeTotal );
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	int i, iSize;
	CRectTracker *pPosition;

	// Border
	CRect rectBorder;			// Rect for border
	CBrush brushBorder;			// Brush for paint border
	CBrush	*pOldBrush	= NULL;
	int iExp = 1;				// Expand border size

	CNetviewDoc *pNetviewDoc = (CNetviewDoc*)this->GetDocument( );
	CNetworkArray *pNetworks = pNetviewDoc->GetNetworks( );
	CNetwork *pNetwork;
	
	CBitmap bmpBitmap;
	BITMAP bm;
	bmpBitmap.LoadBitmap( IDB_BITMAP_NETWORK_CONNECT );
	bmpBitmap.GetBitmap( &bm );
	
	iSize = pNetworks->GetSize( );

	//-----------------------------------------------------------
	// Set network position to display(draw)
	//-----------------------------------------------------------
	int iX, iY;
	CRect rect;
	this->GetClientRect( &rect );
	// init start position ( iX, iY )
	iX = ( rect.Width( ) - bm.bmWidth )/2;
	iY = 15;	
	for ( i=0; i<iSize; i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		pPosition = pNetwork->GetPosition( );
		pPosition->m_rect.left	= iX;
		pPosition->m_rect.top	= iY;
		pPosition->m_rect.right	= iX + bm.bmWidth;
		pPosition->m_rect.bottom= iY + bm.bmHeight;

		// Next network position
		iY = iY + bm.bmHeight + 35;
	}
	//-----------------------------------------------------------
	// Set network position to display(draw)
	//-----------------------------------------------------------

	//---------------------------------------------------------------
	// Draw network image
	//---------------------------------------------------------------
	int iTextX, iTextY;
	CString strNetworkAddress;
	CBitmap *pOldBitmap = NULL;
	CBitmap *pBitmap;
		
	TRY {
		// create device context for load bitmap into
		CDC dcMem;
		dcMem.CreateCompatibleDC( pDC );
	
		// get text characteristic for calculate position to show text (Newwork Address)
		TEXTMETRIC tm;
		pDC->GetTextMetrics( &tm );

		//-------------------------------------------------------
		// Draw select border
		//-------------------------------------------------------
		pNetwork = pNetviewDoc->GetNetworkDisplay( );
		pPosition = pNetwork->GetPosition( );
		
		SetBorderRect( rectBorder, pPosition->m_rect, iExp );
		brushBorder.CreateSolidBrush( RGB( 0, 0, 255 ) );

		// select brush to compatible device
		pOldBrush = pDC->SelectObject( &brushBorder );
		pDC->PatBlt( rectBorder.left, rectBorder.top,
					 rectBorder.Width( ), rectBorder.Height( ),
					 PATCOPY );
		// Set old brush
		if ( pOldBrush != NULL ) {
			pDC->SelectObject( pOldBrush );
			pOldBrush = NULL;
		}
		brushBorder.DeleteObject( );
		//-------------------------------------------------------
		// Draw select border
		//-------------------------------------------------------

		// For each (Network object) do draw in it's position
		for ( i=0; i<iSize; i++ ) {
			pNetwork = pNetworks->ElementAt( i );
			pPosition = pNetwork->GetPosition( );
			
			//----------------
			// Load Image
			//----------------
			pBitmap = pNetwork->GetBitmap( );
			
			//----------------
			// Draw image
			//----------------
			// select bitmap to compatible device
			pOldBitmap = dcMem.SelectObject( pBitmap );
			pDC->StretchBlt( pPosition->m_rect.left,
							 pPosition->m_rect.top,
							 pPosition->m_rect.Width( ),
							 pPosition->m_rect.Height( ),
							 &dcMem,
							 0, 0, bm.bmWidth, bm.bmHeight,
							 SRCCOPY );
			// set old bitmap
			if ( pOldBitmap != NULL ) {
				pDC->SelectObject( pOldBitmap );
				pOldBitmap = NULL;
			}
			
			//----------------
			// Draw text (Network Address) 
			//----------------
			strNetworkAddress = pNetwork->GetNetworkAddress( );
			// Calculate position for show text
			iTextX = pPosition->m_rect.left + (pPosition->m_rect.Width( )/2);
			iTextY = pPosition->m_rect.bottom + 3;
			pDC->SetTextAlign( TA_CENTER );
			pDC->TextOut( iTextX, iTextY, strNetworkAddress );
		}
	}
	CATCH_ALL ( exception ) {
		// Set old brush
		if ( pOldBrush != NULL ) {
			pDC->SelectObject( pOldBrush );
		}
		// set old bitmap
		if ( pOldBitmap != NULL ) {
			pDC->SelectObject( pOldBitmap );
		}
	}
	END_CATCH_ALL
	//---------------------------------------------------------------
	// Draw network image
	//---------------------------------------------------------------
	
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

/////////////////////////////////////////////////////////////////////////////
// CNetworkView diagnostics

#ifdef _DEBUG
void CNetworkView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CNetworkView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNetworkView message handlers

void CNetworkView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	this->Invalidate( );
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

//////////////////////////////////////////////////////////////////////
//	Description : Set border from original rect
//	Parameter	:	rectBorder(IN/OUT)	>>	border rect
//					rect(IN)			>>	original rect
//					iExp(IN)			>>	expand size
//					
void CNetworkView::SetBorderRect(CRect &rectBorder, CRect &rect, int iExp)
{
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	rectBorder.left		= rect.left - iExp;
	rectBorder.top		= rect.top - iExp;
	rectBorder.right	= rect.right + iExp;
	rectBorder.bottom	= rect.bottom + iExp;
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////

	// converts device coordinates into logical coordinates
	CClientDC clientDC( this );
	OnPrepareDC( &clientDC );
	clientDC.DPtoLP( &point );

	CNetviewDoc *pDoc		= (CNetviewDoc*)this->GetDocument( );
	CDiscover *pDiscover	= pDoc->GetDiscover( );
	CNetworkArray *pNetworks= pDiscover->GetNetworks( ); 
	CNetwork *pNetwork;
	CHostArray *pHosts;
	CHost *pHost;
	CRectTracker *pPosition;
	CRect rectTrue;
	int i;

	for ( i=0; i<pNetworks->GetSize( ); i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		pPosition = pNetwork->GetPosition( );
		// check mouse double click with network position
		if ( pPosition->HitTest( point ) >= 0 ) {
			// Set double click Network which display host in 
			//  this view (CNetviewView, Host View)
			pDoc->SetNetworkDisplay( pNetwork );
			// Set host which double click Network is display 
			//	host in Host view (CNetviewView, Host View)
			pHosts = pNetwork->GetHostArray( );
			if ( pHosts->GetSize( ) != 0 ) {
				pHost = pHosts->ElementAt( 0 );
				pDoc->SetHostDisplay( pHost );
			}
 
			// update CNetviewView (Host view) view
			pDoc->UpdateAllViews( NULL );
		}
	}

	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////

	CScrollView::OnLButtonDblClk(nFlags, point);
}

void CNetworkView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	
	//////////////////////////////
	// MY CODE STRAT HERE
	//////////////////////////////
	// Convert screen coordinates to device coordinates 
	this->ScreenToClient( &point );
	// converts device coordinates into logical coordinates
	CClientDC clientDC( this );
	OnPrepareDC( &clientDC );
	clientDC.DPtoLP( &point );
	
	CNetviewDoc *pDoc		= (CNetviewDoc*)this->GetDocument( );
	CDiscover *pDiscover	= pDoc->GetDiscover( );
	CNetworkArray *pNetworks= pDiscover->GetNetworks( ); 
	CNetwork *pNetwork;
	CRectTracker *pPosition;
	CMenu menu, *pSubMenu;
	int i;

	for ( i=0; i<pNetworks->GetSize( ); i++ ) {
		pNetwork = pNetworks->ElementAt( i );
		pPosition = pNetwork->GetPosition( );
		// check mouse double click with network position
		if ( pPosition->HitTest( point ) >= 0 ) {
			// Set right click Network 
			pDoc->SetNetworkContext( pNetwork );
			
			// converts logical coordinates into device coordinates
			clientDC.LPtoDP( &point );
			// Convert device coordinates to screen coordinates
			this->ClientToScreen( &point );

			// Load the context menu
			menu.LoadMenu( IDR_CONTEXTMENU );
			// Get the first sub menu (network context menu)
			pSubMenu = menu.GetSubMenu( 0 );
			
			// Display the context menu
			pSubMenu->TrackPopupMenu( TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON,
									  point.x, point.y, AfxGetMainWnd( ) );

			break;
		}
	}
	
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnNetworkSnmp() 
{
	// TODO: Add your command handler code here
	
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	CSnmpDlg ObjSnmp;
	ObjSnmp.nIP = m_pHostShowSnmp->GetIP( );
	ObjSnmp.DoModal();
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnNetworkTraffic() 
{
	// TODO: Add your command handler code here
	
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	CString strIP = m_pHostShowTraffic->GetIP( );
	CMrtgDlg Mrtg;
	Mrtg.m_sFilePath = "c:\\MRTG\\"+strIP+"\\picture\\"+strIP+"_1";
	Mrtg.m_Path = "c:\\MRTG\\"+strIP+"\\picture\\";
	Mrtg.DoModal();
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnUpdateNetworkSnmp(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	CNetviewDoc *pDoc	= (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork	= (CNetwork*)pDoc->GetNetworkContext( );
	CHost *pHostShowSnmp;
 
	// Set show sub menu
	pHostShowSnmp = pNetwork->IsShowSnmp( );
	if ( pHostShowSnmp != NULL ) {
		m_pHostShowSnmp = pHostShowSnmp;
		pCmdUI->Enable( TRUE );
	}
	else {
		pCmdUI->Enable( FALSE );
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}

void CNetworkView::OnUpdateNetworkTraffic(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	//////////////////////////////
	// MY CODE START HERE
	//////////////////////////////
	CNetviewDoc *pDoc	= (CNetviewDoc*)this->GetDocument( );
	CNetwork *pNetwork	= (CNetwork*)pDoc->GetNetworkContext( );
	CHost *pHostShowTraffic;

	// Set show sub menu
	pHostShowTraffic = pNetwork->IsShowTraffic( );
	if ( pHostShowTraffic != NULL ) {
		m_pHostShowTraffic = pHostShowTraffic;
		pCmdUI->Enable( TRUE );
	}
	else {
		pCmdUI->Enable( FALSE );
	}
	//////////////////////////////
	// MY CODE END HERE
	//////////////////////////////
}
