// DaoMACVendorSet.cpp : implementation file
//

#include "stdafx.h"
#include "Netview.h"
#include "DaoMACVendorSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoMACVendorSet

IMPLEMENT_DYNAMIC(CDaoMACVendorSet, CDaoRecordset)

CDaoMACVendorSet::CDaoMACVendorSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaoMACVendorSet)
	m_VendorMAC = _T("");
	m_VendorName = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CDaoMACVendorSet::GetDefaultDBName()
{
	return _T(".\\Database\\Netview.mdb");
}

CString CDaoMACVendorSet::GetDefaultSQL()
{
	return _T("[MACVendor]");
}

void CDaoMACVendorSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaoMACVendorSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[VendorMAC]"), m_VendorMAC);
	DFX_Text(pFX, _T("[VendorName]"), m_VendorName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaoMACVendorSet diagnostics

#ifdef _DEBUG
void CDaoMACVendorSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDaoMACVendorSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
