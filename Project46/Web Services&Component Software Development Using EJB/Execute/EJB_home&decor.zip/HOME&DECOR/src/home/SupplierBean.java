package home;

import javax.ejb.*;

abstract public class SupplierBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer sid) throws CreateException {
    setSid(sid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer sid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setSid(java.lang.Integer sid);
  public abstract void setName(java.lang.String name);
  public abstract void setAddress(java.lang.String address);
  public abstract void setTel(java.lang.Integer tel);
  public abstract void setEmail(java.lang.String email);
  public abstract void setDescription(java.lang.String description);
  public abstract java.lang.Integer getSid();
  public abstract java.lang.String getName();
  public abstract java.lang.String getAddress();
  public abstract java.lang.Integer getTel();
  public abstract java.lang.String getEmail();
  public abstract java.lang.String getDescription();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}