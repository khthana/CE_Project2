package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface UniqueIDHome extends javax.ejb.EJBHome {
  public UniqueID create() throws CreateException, RemoteException;
}