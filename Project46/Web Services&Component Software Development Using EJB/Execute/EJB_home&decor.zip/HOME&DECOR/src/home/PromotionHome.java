package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PromotionHome extends javax.ejb.EJBHome {
  public Promotion create() throws CreateException, RemoteException;
}