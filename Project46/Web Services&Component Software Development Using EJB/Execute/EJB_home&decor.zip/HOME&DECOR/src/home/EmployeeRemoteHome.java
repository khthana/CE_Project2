package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EmployeeRemoteHome extends javax.ejb.EJBHome {
  public EmployeeRemote create(Integer eid) throws CreateException, RemoteException;
  public EmployeeRemote findIDByName(String fname) throws FinderException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public EmployeeRemote findByPrimaryKey(Integer eid) throws FinderException, RemoteException;
}