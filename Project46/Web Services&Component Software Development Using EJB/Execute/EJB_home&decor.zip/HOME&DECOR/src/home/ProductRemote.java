package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface ProductRemote extends javax.ejb.EJBObject {
  public Integer getPid() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setImageurl(String imageurl) throws RemoteException;
  public String getImageurl() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getDescription() throws RemoteException;
  public void setSaleavg(Float saleavg) throws RemoteException;
  public Float getSaleavg() throws RemoteException;
  public void setBarcode(String barcode) throws RemoteException;
  public String getBarcode() throws RemoteException;
  public void setTpid(Integer tpid) throws RemoteException;
  public Integer getTpid() throws RemoteException;
  public void setTuid(Integer tuid) throws RemoteException;
  public Integer getTuid() throws RemoteException;
  public void setTsid(Integer tsid) throws RemoteException;
  public Integer getTsid() throws RemoteException;
  public void setBid(Integer bid) throws RemoteException;
  public Integer getBid() throws RemoteException;
}