package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class AddUnit extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>AddUnit</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    //////////////////////////////////////////
   out.println("<h1><p> Add Type& Other </p></h1>");
   out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
   out.println("<td bgcolor='#66CC99'>Unit ID</td>");
   out.println("<td bgcolor='#66CC99'>Type Name</td>");
   //out.println("<td>Name</td>");
   //out.println("<td>Description</td></tr>");

   try
   {


     Context jndiContext = new InitialContext();
     Object obj = jndiContext.lookup("Type_UnitRemote");
     Object obj2 = jndiContext.lookup("StringTools");

     Type_UnitRemoteHome home = (Type_UnitRemoteHome)
         PortableRemoteObject.narrow(obj, Type_UnitRemoteHome.class);
     StringToolsHome sTools = (StringToolsHome)
         PortableRemoteObject.narrow(obj2, StringToolsHome.class);

     Collection c = home.findSelectall();
     Object[] b = c.toArray();
     StringTools st = sTools.create();

     for (int j = 0; j < c.size(); j++) {
       // Type_UnitRemote sp = home.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
       Type_UnitRemote sp = (Type_UnitRemote)b[j];
       out.println("<tr>");
       out.println("<td>" + sp.getTuid() + "</td>");
       out.println("<td>" + sp.getTypeunitname() + "</td>");
       out.println("</tr>");

     }



   out.println("</table>");

   out.print("<form name='form1' method='get' action='../StockWAR/addunit'>"
                 +"<h1>"
                 +"<p>Add&Edit Product</p>"
                 +"</h1>"
                 +"<table width='550' border='0' cellspacing='0' cellpadding='0'>"

                 +"<tr> "
                 +"<td width='30%'>UnitID</td>"
                 +"<td width='70%'><input type='text' name='textfield'></td>"
                 +"</tr>"
                 +"<tr>"
                 +"<td>Name</td>"
                 +"<td><input type='text' name='textfield2'></td>"
                 +"</tr>"
                 +"<tr>"
                 +"<td><input type='submit' name='Submit' value='Submit'>"
                 +"<input type='reset' name='Submit2' value='Reset'>"
                 +"</td></tr>"
                 +"</table>"
                 +"</form>"
                 //+"<tr>"
                 //+"<td>NameSection</td>"
                 //+"<td><select name='select'>"
                 );


       // out.println("</br>");
       // out.println("</br>");
       // out.println("</br>");
       // out.println("</br>");
       out.println("</br>");
       out.println("<br><a href='../StockWAR/addadmin' >Back</a>");

       String tuid = request.getParameter("textfield");
       Type_UnitRemote turemote;
       boolean haveP = false;
       for (int i = 0; i < c.size(); i++) {
         // if ( st.cutEachColon(b[i].toString()).equals(tuid) ) haveP = true;
         turemote = (Type_UnitRemote)b[i];
         if (turemote.getTuid().equals(new Integer(tuid)))
           haveP = true;
       }
       if (haveP) {
         out.println("Edit Unit Product");
         turemote = home.findByPrimaryKey(new Integer(tuid));
         // name='Submit3' value='del'
         String del = request.getParameter("Submit2");
         if (del.equals("Reset"))
           turemote.remove();
         else {

         }
       }
       else {
         out.println("Add Type");
         turemote = home.create(new Integer(tuid));
         // tpremote.setTpid(new Integer(request.getParameter("textfield")));
         turemote.setTypeunitname(request.getParameter("textfield2"));
         //premote.setBarcode(request.getParameter("textfield3"));

       }

     }

     catch (Throwable t) {
       t.printStackTrace();
     }

     //----------------------------------------
     out.println("</body></html>");
   }

   //Clean up resources
   public void destroy() {
   }
}
