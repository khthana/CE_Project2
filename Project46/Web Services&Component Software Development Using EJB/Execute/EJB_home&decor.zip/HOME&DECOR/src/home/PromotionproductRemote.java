package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface PromotionproductRemote extends javax.ejb.EJBObject {
  public Integer getPsid() throws RemoteException;
  public void setSpecialsale(Integer specialsale) throws RemoteException;
  public Integer getSpecialsale() throws RemoteException;
  public void setStart(Timestamp start) throws RemoteException;
  public Timestamp getStart() throws RemoteException;
  public void setStop(Timestamp stop) throws RemoteException;
  public Timestamp getStop() throws RemoteException;
  public void setTprid(Integer tprid) throws RemoteException;
  public Integer getTprid() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
}