package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerRemote extends javax.ejb.EJBObject {
  public Integer getMid() throws RemoteException;
  public void setLoginname(String loginname) throws RemoteException;
  public String getLoginname() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setSurname(String surname) throws RemoteException;
  public String getSurname() throws RemoteException;
  public void setSalu(String salu) throws RemoteException;
  public String getSalu() throws RemoteException;
  public void setPassword(String password) throws RemoteException;
  public String getPassword() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getAddress() throws RemoteException;
  public void setTel(String tel) throws RemoteException;
  public String getTel() throws RemoteException;
  public void setMobile(String mobile) throws RemoteException;
  public String getMobile() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setJid(Integer jid) throws RemoteException;
  public Integer getJid() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
  public void setStid(Integer stid) throws RemoteException;
  public Integer getStid() throws RemoteException;
  public void setSid(Integer sid) throws RemoteException;
  public Integer getSid() throws RemoteException;
}