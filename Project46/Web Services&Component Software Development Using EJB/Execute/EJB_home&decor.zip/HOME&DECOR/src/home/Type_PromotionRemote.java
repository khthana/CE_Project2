package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_PromotionRemote extends javax.ejb.EJBObject {
  public Integer getTprid() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
}