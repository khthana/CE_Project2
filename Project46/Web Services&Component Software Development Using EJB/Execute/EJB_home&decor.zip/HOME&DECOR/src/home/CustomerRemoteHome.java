package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerRemoteHome extends javax.ejb.EJBHome {
  public CustomerRemote create(Integer mid) throws CreateException, RemoteException;
  public CustomerRemote findIDByLoginName(String loginname) throws FinderException, RemoteException;
  public CustomerRemote findByPrimaryKey(Integer mid) throws FinderException, RemoteException;
}