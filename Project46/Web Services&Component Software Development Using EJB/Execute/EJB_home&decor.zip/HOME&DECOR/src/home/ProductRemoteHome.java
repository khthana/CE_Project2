package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface ProductRemoteHome extends javax.ejb.EJBHome {
  public ProductRemote create(Integer pid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Collection findCollectionTypeSection(Integer Section) throws FinderException, RemoteException;
  public Collection findProductByName(String name) throws FinderException, RemoteException;
  public ProductRemote findByPrimaryKey(Integer pid) throws FinderException, RemoteException;
}