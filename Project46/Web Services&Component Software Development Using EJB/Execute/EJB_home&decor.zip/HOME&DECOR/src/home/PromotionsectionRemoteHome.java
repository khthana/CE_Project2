package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PromotionsectionRemoteHome extends javax.ejb.EJBHome {
  public PromotionsectionRemote create(Integer psid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public PromotionsectionRemote findByPrimaryKey(Integer psid) throws FinderException, RemoteException;
}