package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface SupplyProductRemote extends javax.ejb.EJBObject {
  public Integer getSpid() throws RemoteException;
  public void setPlid(Integer plid) throws RemoteException;
  public Integer getPlid() throws RemoteException;
  public void setSid(Integer sid) throws RemoteException;
  public Integer getSid() throws RemoteException;
  public void setCost(Float cost) throws RemoteException;
  public Float getCost() throws RemoteException;
  public void setNumber(Integer number) throws RemoteException;
  public Integer getNumber() throws RemoteException;
  public void setDate(Timestamp date) throws RemoteException;
  public Timestamp getDate() throws RemoteException;
}