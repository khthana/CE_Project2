package home;

import javax.ejb.*;

abstract public class PromotionproductBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer psid) throws CreateException {
    setPsid(psid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer psid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPsid(java.lang.Integer psid);
  public abstract void setSpecialsale(java.lang.Integer specialsale);
  public abstract void setStart(java.sql.Timestamp start);
  public abstract void setStop(java.sql.Timestamp stop);
  public abstract void setTprid(java.lang.Integer tprid);
  public abstract void setPid(java.lang.Integer pid);
  public abstract java.lang.Integer getPsid();
  public abstract java.lang.Integer getSpecialsale();
  public abstract java.sql.Timestamp getStart();
  public abstract java.sql.Timestamp getStop();
  public abstract java.lang.Integer getTprid();
  public abstract java.lang.Integer getPid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}