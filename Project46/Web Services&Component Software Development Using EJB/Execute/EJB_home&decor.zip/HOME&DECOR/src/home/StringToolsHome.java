package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface StringToolsHome extends javax.ejb.EJBHome {
  public StringTools create() throws CreateException, RemoteException;
}