package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_UnitRemote extends javax.ejb.EJBObject {
  public Integer getTuid() throws RemoteException;
  public void setTypeunitname(String typeunitname) throws RemoteException;
  public String getTypeunitname() throws RemoteException;
}