package home;

import javax.ejb.*;

abstract public class KeepSessionBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer bucid) throws CreateException {
    setBucid(bucid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer bucid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setBucid(java.lang.Integer bucid);
  public abstract void setMid(java.lang.Integer mid);
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setNumber(java.lang.Integer number);
  public abstract void setDate(java.sql.Timestamp date);
  public abstract java.lang.Integer getBucid();
  public abstract java.lang.Integer getMid();
  public abstract java.lang.Integer getPid();
  public abstract java.lang.Integer getNumber();
  public abstract java.sql.Timestamp getDate();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}