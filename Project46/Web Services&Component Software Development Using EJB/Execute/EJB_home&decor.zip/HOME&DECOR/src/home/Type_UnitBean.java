package home;

import javax.ejb.*;

abstract public class Type_UnitBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer tuid) throws CreateException {
    setTuid(tuid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer tuid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTuid(java.lang.Integer tuid);
  public abstract void setTypeunitname(java.lang.String typeunitname);
  public abstract java.lang.Integer getTuid();
  public abstract java.lang.String getTypeunitname();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}