package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class IndexSection extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"<style>"
                +"<!-- Hide style for old browsers __ THIS STYLE SHOULD BE INSIDE HEAD OF DOCUMENT __"
                +"BODY          {font-family:;font-size='10'}"
                +"A:link    {text-decoration: none; color: #0000FF}"
                +"A:visited {text-decoration: none; color: #C0C0C0}"
                +"A:hover   {text-decoration: none; color: #FF0000}"
                +"A:active  {text-decoration: none; color: #FF0000}"
                +"-->"
                +"</style>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'> "
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);

    }
    catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////////////////////////////
    out.println("</strong></font></td>"
                +"<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                +"<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                +"<tr>"
                +"<td>&nbsp;</td>"
                +"</tr>"
                +"<tr>"
                +"<td><div align='center'>&#3588;&#3657;&#3609;&#3627;&#3634; : "
                +"<input type='text' name='textfield'>"
                +"<input type='submit' name='Submit' value='GO!'>"
                +"</div></td>"
                +"</tr>"
                +"</table>"
                +"</form>"
                +"</div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td width='13%' height='404'>");
    // print address /////////////////////////////////
    String section = request.getParameter("section");
    out.println("<a href='../SalesWAR/indexsales'>Home</a>>"
                +"<a href='../SalesWAR/indexsection?section="+section+"'>"+section+"</a><br>");
    // print address /////////////////////////////////

    // login ////////////////////////////////////////////////////
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("SessionCustomer");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionCustomerHome chome = (SessionCustomerHome)
          PortableRemoteObject.narrow(objc, SessionCustomerHome.class);
      ////////////////////////////////////////////////////
      SessionCustomer c = chome.create();
      c.login(request, out);

    }
    catch (Throwable t) { t.printStackTrace(); }
    /////////////////////////////////////////////////////////////
    out.println("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p></td>"
                +"<td width='57%'> <div align='center'> "
                +"<p>&nbsp;</p>");
    // Center ////////////////////////////////////////////////
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("Promotion");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      PromotionHome prhome = (PromotionHome)
          PortableRemoteObject.narrow(objc, PromotionHome.class);
      ////////////////////////////////////////////////////
      Promotion pr = prhome.create();

      Object objts = jndiContext.lookup("Type_SectionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
          PortableRemoteObject.narrow(objts, Type_SectionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ////////////////////////////////////////////////////
      Collection cts = tshome.findSelectall();
      Object[] bts = cts.toArray();
      StringTools st = sTools.create();

      for (int j=0;j<cts.size();j++) {
        // Type_SectionRemote tsremote = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j].toString())));
		Type_SectionRemote tsremote = (Type_SectionRemote)bts[j];
        if (tsremote.getNamesection().equalsIgnoreCase(section)) {
          pr.BoxPromotionSection(out,tsremote.getTsid());
        }
      }

    } catch (Throwable t) { t.printStackTrace(); }
    // Center ////////////////////////////////////////////////
    out.println("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div>"
                +"<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                +"Home&amp;Decor.com Privacy Policy </p>"
                +"<p align='center'>Powered by HomeServices Inc.</p>"
                +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                +"<p>&nbsp;</p>"
                +"</body>"
                +"</html>");
  }

  public void destroy() {
  }

}