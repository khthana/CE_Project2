package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class SearchProduct extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      ///////////////////////////////////////////////////////////////////
    } catch (Throwable t) { t.printStackTrace(); }

    out.print("</strong></font></td>"
              + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "<tr>"
              + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
              + "<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
              + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
              + "<tr>"
              + "<td>&nbsp;</td>"
              + "</tr>"
              + "<tr>"
              + "<td><div align='center'>Search : "
              + "<input type='text' name='textfield'>"
              + "<input type='submit' name='Submit' value='GO!'>"
              + "</div></td>"
              + "</tr>"
              + "</table>"
              + "</form>"
              + "</div></td>"
              + "</tr>"
              + "<tr> "
              + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
              + "<tr> "
              + "<td width='13%' height='404'>");

    // Search Display ///////////////////////////////////////////////////////

    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objp = jndiContext.lookup("ProductRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      ProductRemoteHome phome = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ////////////////////////////////////////////////////
      String nameproduct = request.getParameter("textfield");
      Collection c = phome.findProductByName(nameproduct);
      Object[] b = c.toArray();
      StringTools st = sTools.create();

      if (c.size() != 0) {
        // Display ///////////////////////////////////////////////////////////////
        out.print("<table width='915' border='0' align='center'>");
        for (int j = 0; j < c.size(); j++) {
          // ProductRemote premote = phome.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
          ProductRemote premote = (ProductRemote) b[j];
          //out.println("<br>"+premote.getPid());
          //out.println("<br>"+premote.getName());
          //out.println("<br>"+premote.getSaleavg());
          //out.println("<br>"+premote.getBarcode());
          //out.println("<br>"+premote.getImageurl());
          //out.println("<br>"+premote.getDescription());
          out.print("<tr>"
                    + "<td width='344'><div align='right'>"
                    //+"<img src='http://localhost:8080/jmx-console/"+imageurl+"' width='161' height='125'></div></td>"
                    // error
                    + premote.getImageurl()
                    + "</div></td>"
                    + "<td width='346'><div align='left'>"
                    + "<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><B><p>&#3594;&#3639;&#3656;&#3629;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:</B> "
                    + premote.getName() + "</p></FONT>"
                    //+"<p>Size : 100x100</p>"
                    + "<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><B><p>&#3619;&#3634;&#3588;&#3634;:</B> "
                    + premote.getSaleavg() + "</p></FONT>"
                    + "<a href='../SalesWAR/basket?addproduct="
                    + premote.getPid() + "'>"
                    +
              "<p><img src='../jmx-console/images/th_add.gif' border='0'></p></B></FONT></a>"
                    + "</div></td>"
                    + "</tr>");

          out.print("<br>");

        }
      } else {
        out.println("<center><font color='#006699' size='5'>");
        out.print("Furniture no Found...");
        out.println("<br><a href='../SalesWAR/indexsales'>Back</a>");
        out.println("</font></center>");
      }
    }
    catch (Throwable t) {
      t.printStackTrace();
    }
    out.println("</table><br><br><DIV class=footer>");

    out.println("<p>&nbsp;</p>"
                + "<p>&nbsp;</p>"
                + "<p>&nbsp;</p>"
                + "<p>&nbsp;</p>"
                + "<p>&nbsp;</p></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "</table>"
                + "<p>&nbsp;</p>"
                + "<p>&nbsp;</p>"
                + "<p>&nbsp;</p>"
                + "</div>"
                + "<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                + "<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                + "Home&amp;Decor.com Privacy Policy </p>"
                + "<p align='center'>Powered by HomeServices Inc.</p>"
                + "<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                + "<p>&nbsp;</p>"
                + "</body>"
                + "</html>");


  }
  //Clean up resources
  public void destroy() {
  }
}