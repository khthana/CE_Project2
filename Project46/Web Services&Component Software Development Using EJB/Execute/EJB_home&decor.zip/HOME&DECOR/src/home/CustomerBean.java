package home;

import javax.ejb.*;

abstract public class CustomerBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer mid) throws CreateException {
    setMid(mid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer mid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setMid(java.lang.Integer mid);
  public abstract void setLoginname(java.lang.String loginname);
  public abstract void setName(java.lang.String name);
  public abstract void setSurname(java.lang.String surname);
  public abstract void setSalu(java.lang.String salu);
  public abstract void setPassword(java.lang.String password);
  public abstract void setAddress(java.lang.String address);
  public abstract void setTel(java.lang.String tel);
  public abstract void setMobile(java.lang.String mobile);
  public abstract void setEmail(java.lang.String email);
  public abstract void setJid(java.lang.Integer jid);
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setStid(java.lang.Integer stid);
  public abstract void setSid(java.lang.Integer sid);
  public abstract java.lang.Integer getMid();
  public abstract java.lang.String getLoginname();
  public abstract java.lang.String getName();
  public abstract java.lang.String getSurname();
  public abstract java.lang.String getSalu();
  public abstract java.lang.String getPassword();
  public abstract java.lang.String getAddress();
  public abstract java.lang.String getTel();
  public abstract java.lang.String getMobile();
  public abstract java.lang.String getEmail();
  public abstract java.lang.Integer getJid();
  public abstract java.lang.Integer getPid();
  public abstract java.lang.Integer getStid();
  public abstract java.lang.Integer getSid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}