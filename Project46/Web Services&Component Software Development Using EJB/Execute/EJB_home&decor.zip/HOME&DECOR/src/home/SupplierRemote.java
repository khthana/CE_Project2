package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface SupplierRemote extends javax.ejb.EJBObject {
  public Integer getSid() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getAddress() throws RemoteException;
  public void setTel(Integer tel) throws RemoteException;
  public Integer getTel() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getDescription() throws RemoteException;
}