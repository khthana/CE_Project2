package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_UnitRemoteHome extends javax.ejb.EJBHome {
  public Type_UnitRemote create(Integer tuid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Type_UnitRemote findByPrimaryKey(Integer tuid) throws FinderException, RemoteException;
}