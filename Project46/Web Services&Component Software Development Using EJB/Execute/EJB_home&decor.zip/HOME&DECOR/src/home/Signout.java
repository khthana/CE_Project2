package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Signout extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      ///////////////////////////////////////////////////////////////////

      out.print("</strong></font></td>"
                + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "<tr>"
                + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                + "<tr>"
                + "<td>&nbsp;</td>"
                + "</tr>"
                + "<tr>"
                + "<td><div align='center'>Search : "
                + "<input type='text' name='textfield'>"
                + "<input type='submit' name='Submit' value='GO!'>"
                + "</div></td>"
                + "</tr>"
                + "</table>"
                + "</form>"
                + "</div></td>"
                + "</tr>"
                + "<tr> "
                + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                + "<tr> "
                + "<td width='13%' height='404'>");
      // Thank you  ////////////////////////////////////////////////////////////
      HttpSession session = request.getSession(true);
      session.removeValue("SessionCustomer");

      out.println("<center><font color='#006699' size='5'>");
      out.print("Sign Out Complete");
      out.println("<br><a href='../SalesWAR/indexsales'>Back</a>");
      out.println("</font></center>");

      out.println("<br><br><DIV class=footer>"
                  + "<div align='center'>&copy;2003 Home&amp;Decor - Searching 2 web pages<br></div>"
                  + "</DIV>"
                  + "</p>");

      // Thank you  ////////////////////////////////////////////////////////////
      out.println("<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "</div>"
                  + "<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                  + "<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                  + "Home&amp;Decor.com Privacy Policy </p>"
                  + "<p align='center'>Powered by HomeServices Inc.</p>"
                  + "<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                  + "<p>&nbsp;</p>"
                  + "</body>"
                  + "</html>");
    }
    catch (Throwable t) { t.printStackTrace(); }
  }
  //Clean up resources
  public void destroy() {
  }
}
