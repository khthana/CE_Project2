package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BrandRemoteHome extends javax.ejb.EJBHome {
  public BrandRemote create(Integer bid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public BrandRemote findByPrimaryKey(Integer bid) throws FinderException, RemoteException;
}