package home;

import javax.ejb.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class PromotionBean implements SessionBean {
  SessionContext sessionContext;
  String widths  = "75";
  String heights = "90";
  String width  = "160";
  String height = "180"; //width='71' height='150'
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public void BoxPromotionProduct(PrintWriter out) {
    // Print Box ///////////////////////////////////////////////////////////////
    try {
      // Remote Method /////////////////////////////////////////////////////////
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("ProductRemote");
      Object objpp = jndiContext.lookup("PromotionproductRemote");
      Object objtpm = jndiContext.lookup("Type_PromotionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      // Create RemoteHome ///////////////////////////////
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ProductRemoteHome home = (ProductRemoteHome)
          PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
      PromotionproductRemoteHome pphome = (PromotionproductRemoteHome)
          PortableRemoteObject.narrow(objpp, PromotionproductRemoteHome.class);
      Type_PromotionRemoteHome tpmhome = (Type_PromotionRemoteHome)
          PortableRemoteObject.narrow(objtpm, Type_PromotionRemoteHome.class);
      ////////////////////////////////////////////////////
      StringTools st = sTools.create();
      Collection c = pphome.findSelectall();
      Object[] b = c.toArray();
      int random = Random(c.size());
      // ran = product ID, random = index point to b(promotion)
      // String ran = st.cutEachColon(b[random].toString());
      //PromotionproductRemote pp = pphome.findByPrimaryKey(Integer.valueOf(ran));
      PromotionproductRemote pp = (PromotionproductRemote)b[random];
      ProductRemote p = home.findByPrimaryKey(pp.getPid());
      Type_PromotionRemote tpm = tpmhome.findByPrimaryKey(pp.getTprid());
      // Print /////////////////////////////////////////////////////////////////
      out.print("<br><table width='190' border='0' cellpadding='0' cellspacing='1' bgcolor='#3399CC'>"
                +"<tr> "
                +"<td height='10'>"
                +"<div align='center'>"
                +"<table width='190' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td><div align='center'>"+tpm.getName()+"</div></td>"
                +"</tr>"
                +"</table>"
                +"<table width='190' height='142' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='187' bgcolor='#FFFFFF'><div align='center'>"
                +"<table width='190' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                // Picture //////////////////////
                +"<td><div align='center'>"
                //+"<img src='../jmx-console/"+p.getImageurl()+"' border='0' width='"+widths+"' height='"+heights+"'></a> "
                +p.getImageurl()
                // Picture //////////////////////
                +"</div></td>"
                +"<tr>" // new
                // Name /////////////////////////
                +"<td><a href='../SalesWAR/indexproduct?product="+p.getPid()+"'><FONT face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a size=3><p><B>"+p.getName()+"</B></p></a></FONT>"
                // Name /////////////////////////
                +"<FONT color=red face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><p><B>&#3619;&#3634;&#3588;&#3634;&#3614;&#3636;&#3648;&#3624;&#3625;:</B> "+PriceProduct(p.getPid())+" &#3610;&#3634;&#3607;</p></FONT>"
                // Promotion ////////////////////
                +"<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><B><p>&#3619;&#3634;&#3588;&#3634;&#3611;&#3585;&#3605;&#3636;:</B> "+p.getSaleavg()+" &#3610;&#3634;&#3607;</p></FONT></td>"
                +"</td>" // new
                // Sales ////////////////////////
                +"</tr>"
                +"</table>"
                +"</div></td>"
                +"</tr>"
                +"</table>"
                +"</div></td>"
                +"</tr>"
                +"</table>");
    } catch (Throwable t) { t.printStackTrace(); }
  }
  public void BoxPromotionSection(PrintWriter out, Integer Section) {
    // Input = section , Output = 1 Box ///////
    // Border gray
    //out.print("<table width='400' border='0' cellpadding='0' cellspacing='0' bordercolor='#999999'>"
    //          +"<tr> "
    //          +"<td width='200'><table width='100%' border='0' cellpadding='0' cellspacing='0'>"
    //          +"<tr> ");
    // Right /////////////////////////////////////////////////////////
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("ProductRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      // Create RemoteHome ///////////////////////////////
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ProductRemoteHome home = (ProductRemoteHome)
          PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
      ////////////////////////////////////////////////////
      StringTools st = sTools.create();
      Collection c = home.findCollectionTypeSection(Section);
      Object[] b = c.toArray();
      // First Random ////////////////////////////
      int random = Random(c.size());
      // ran = product ID, random = index point to b(promotion)
      // String ran = st.cutEachColon(b[random].toString());
      // ProductRemote pr = home.findByPrimaryKey(Integer.valueOf(ran));
      ProductRemote pr = (ProductRemote)b[random];
      // Second Random ///////////////////////////
      int temp = random;
      while (random == temp) {
        random = Random(c.size());
      }
      // ran = st.cutEachColon(b[random].toString());
      // ProductRemote pl = home.findByPrimaryKey(Integer.valueOf(ran));
      ProductRemote pl = (ProductRemote)b[random];
      /*
      // Left //////////////////////////////////////////////////////////
      out.print("<td width='20%'>"
                +"<a href='../SalesWAR/indexproduct?product="+pl.getPid()+"'>"
                +"<img src='../jmx-console/"+pl.getImageurl()+"' border='0'></td></a>"
                +"<td width='80%'><p>"
                +"<strong>Name:</strong> <strong>"+pl.getName()+"</strong><br>"
                +"<strong>Sales:</strong>"+pl.getSaleavg()+"<br>"
                +"<strong>sales:</strong><strong>$99.99</strong></p></td>");

      out.print("</tr>"
                +"</table></td>");
      // Right /////////////////////////////////////////////////////////
      out.print("<td width='200'><table width='100%' border='0' cellpadding='0' cellspacing='0'>"
              +"<tr> <td width='20%'>"
              +"<a href='../SalesWAR/indexproduct?product="+pr.getPid()+"'>"
              +"<img src='../jmx-console/"+pr.getImageurl()+"' border='0'></td></a>"
              +"<td width='80%'><p>"
              +"<strong>Name:</strong> <strong>"+pr.getName()+"</strong><br>"
              +"<strong>Sales:</strong>"+pr.getSaleavg()+"<br>"
              +"<strong>sales:</strong><strong>$99.99</strong></p></td>");
       */
      out.print("<table width='400' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr> "
                +"<td width='2'>&nbsp;</td>"
                +"<td width='1' background='../jmx-console/images/1x1grey.gif'></td>"
                +"<td width='75' >"
                //+"<img src='../jmx-console/"+pl.getImageurl()+"' border='0' width='"+width+"' height='"+height+"'>"
                +pl.getImageurl()
                +"</td>"

                +"<td width='6'>&nbsp;</td>"
                +"<td width='1' background='../jmx-console/images/1x1grey.gif'></td>"
                +"<td width='7'>"
                //+"<img src='../jmx-console/"+pr.getImageurl()+"' border='0' width='"+width+"' height='"+height+"'>"
                +pr.getImageurl()
                +"</td></a>"

                +"<tr> "
                +"<td width='2'>&nbsp;</td>"
                +"<td  width='1' background='../jmx-console/images/1x1grey.gif'></td>"
                +"<td width='121'><p>"
                +"<a href='../SalesWAR/indexproduct?product="+pl.getPid()+"'>"
                +"<FONT face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a size=3><strong>&#3594;&#3639;&#3656;&#3629;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:<br></strong>&nbsp;&nbsp;&nbsp;"+pl.getName()+"<br></FONT></a><br>"
                +"<FONT color=red face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><strong>&#3619;&#3634;&#3588;&#3634;&#3614;&#3636;&#3648;&#3624;&#3625;:</strong>"+PriceProduct(pl.getPid())+" &#3610;&#3634;&#3607;<br></FONT><br>"
                +"<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><strong>&#3619;&#3634;&#3588;&#3634;&#3611;&#3585;&#3605;&#3636;:</strong>"+(pl.getSaleavg())+" &#3610;&#3634;&#3607;</FONT></p></td>"

                +"<td width='6'>&nbsp;</td>"
                +"<td width='1' background='../jmx-console/images/1x1grey.gif'></td>"
                +"<td width='121'><p><a href='../SalesWAR/indexproduct?product="+pr.getPid()+"'>"
                +"<FONT face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a size=3><strong>&#3594;&#3639;&#3656;&#3629;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:<br></strong>&nbsp;&nbsp;&nbsp;"+pr.getName()+"<br></FONT></a><br>"
                +"<FONT color=red face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><strong>&#3619;&#3634;&#3588;&#3634;&#3614;&#3636;&#3648;&#3624;&#3625;:</strong>"+PriceProduct(pr.getPid())+" &#3610;&#3634;&#3607;<br></FONT><br>"
                +"<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><strong>&#3619;&#3634;&#3588;&#3634;&#3611;&#3585;&#3605;&#3636;:</strong>"+(pr.getSaleavg())+" &#3610;&#3634;&#3607;</FONT></p></td>"
                +"</tr>"

                +"<tr> "
                +"<td width='2'>&nbsp;</td>"
                +"<td colspan='2'><img src='../jmx-console/images/1x1grey.gif'  width='100%' height='1'></td>"
                +"<td width='6'>&nbsp;</td>"
                +"<td colspan='2'><img src='../jmx-console/images/1x1grey.gif'  width='100%' height='1'></td>"
                +"</tr>"
                +"</table>");
    } catch (Throwable t) { t.printStackTrace(); }
  }
  public void BoxTypePromotionProduct(PrintWriter out) {
    /**@todo Complete this method*/
  }
  public int Random(int range) {
    int result=0;
    result = (int)(Math.random()*range);
    return result;
  }
  public void BoxPromotionIndex(PrintWriter out) {
    //for (int i=0;i<2;i++) {
      BoxPromotionSection(out,new Integer(1));
    //}
  }
  public float PriceProduct(Integer pid) {
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objps = jndiContext.lookup("PromotionsectionRemote");
      Object objpp = jndiContext.lookup("PromotionproductRemote");
      Object objp = jndiContext.lookup("ProductRemote");
      PromotionsectionRemoteHome homeps = (PromotionsectionRemoteHome)
          PortableRemoteObject.narrow(objps, PromotionsectionRemoteHome.class);
      PromotionproductRemoteHome homepp = (PromotionproductRemoteHome)
          PortableRemoteObject.narrow(objpp, PromotionproductRemoteHome.class);
      ProductRemoteHome homep = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);

      ProductRemote product = homep.findByPrimaryKey(pid);
      Collection cpromotionsection = homeps.findSelectall();
      Object[] bpromotionsection = cpromotionsection.toArray();
      Collection cpromotionproduct = homepp.findSelectall();
      Object[] bpromotionproduct = cpromotionproduct.toArray();

      if (bpromotionproduct.length == 0)
      {
        if (bpromotionsection.length == 0)
        {
          for (int i=0;i<bpromotionsection.length;i++)
          {
            PromotionsectionRemote promotionsection = (PromotionsectionRemote)bpromotionsection[i];
            if (promotionsection.getTsid().equals(product.getTsid())) return ((product.getSaleavg().floatValue()*(100-promotionsection.getPercentsale().floatValue()))/100);
          }
        } else return product.getSaleavg().floatValue();
      } else
      {
        for (int i=0;i<bpromotionproduct.length;i++)
        {
          PromotionproductRemote promotionproduct = (PromotionproductRemote)bpromotionproduct[i];
          if (promotionproduct.getPid().equals(pid)) return promotionproduct.getSpecialsale().floatValue();
        }
        //if (bpromotionsection.length == 0) Error
        //{
          for (int i=0;i<bpromotionsection.length;i++)
          {
            PromotionsectionRemote promotionsection = (PromotionsectionRemote)bpromotionsection[i];
            if (promotionsection.getTsid().equals(product.getTsid())) return ((product.getSaleavg().floatValue()*(100-promotionsection.getPercentsale().floatValue()))/100);
          }
        //} else return product.getSaleavg().floatValue();
      }
      return product.getSaleavg().floatValue();
    } catch (Throwable t) { t.printStackTrace(); }
    float free = 0;
    return free;
  }
}