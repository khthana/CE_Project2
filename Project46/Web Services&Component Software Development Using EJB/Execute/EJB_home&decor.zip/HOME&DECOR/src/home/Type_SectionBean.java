package home;

import javax.ejb.*;

abstract public class Type_SectionBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer tsid) throws CreateException {
    setTsid(tsid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer tsid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTsid(java.lang.Integer tsid);
  public abstract void setNamesection(java.lang.String namesection);
  public abstract java.lang.Integer getTsid();
  public abstract java.lang.String getNamesection();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}