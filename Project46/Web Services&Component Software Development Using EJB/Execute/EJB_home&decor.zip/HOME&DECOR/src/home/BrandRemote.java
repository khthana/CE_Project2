package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BrandRemote extends javax.ejb.EJBObject {
  public Integer getBid() throws RemoteException;
  public void setBrandname(String brandname) throws RemoteException;
  public String getBrandname() throws RemoteException;
}