package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface UniqueID extends javax.ejb.EJBObject {
  public int getUnique() throws RemoteException;
}