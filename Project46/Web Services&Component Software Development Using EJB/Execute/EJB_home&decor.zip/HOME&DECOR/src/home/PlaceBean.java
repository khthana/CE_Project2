package home;

import javax.ejb.*;

abstract public class PlaceBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer plid) throws CreateException {
    setPlid(plid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer plid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPlid(java.lang.Integer plid);
  public abstract void setPlacename(java.lang.String placename);
  public abstract void setAddress(java.lang.String address);
  public abstract java.lang.Integer getPlid();
  public abstract java.lang.String getPlacename();
  public abstract java.lang.String getAddress();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}