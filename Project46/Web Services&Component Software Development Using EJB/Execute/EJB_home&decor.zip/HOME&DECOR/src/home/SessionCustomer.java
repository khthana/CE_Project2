package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


public interface SessionCustomer extends javax.ejb.EJBObject {
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setSurname(String surname) throws RemoteException;
  public String getSurname() throws RemoteException;
  public void setID(Integer iD) throws RemoteException;
  public Integer getID() throws RemoteException;
  public void setPassword(String password) throws RemoteException;
  public String getPassword() throws RemoteException;
  public void login(HttpServletRequest request, PrintWriter out) throws RemoteException;
  //public Integer Buy(String iiD, String password, String costdeliver, String amid) throws RemoteException;
  public Integer Buy(String iiD,String password,String costdeliver,String amid) throws RemoteException;
  //public String Buy(String iiD, String password, String[] streamProduct, String[] streamNumProduct, String Amid) throws RemoteException;
  public String[][] ViewKeepSession(String iiD, String password) throws RemoteException;
  public String AddKeepSession(String iiD, String password, String pid) throws RemoteException;
}