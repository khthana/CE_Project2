package home;

import javax.ejb.*;

public class UniqueIDBean implements SessionBean {
  SessionContext sessionContext;
  int uniqueID = (int)System.currentTimeMillis();
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public int getUnique() {
    if (uniqueID < 0) {
      uniqueID *= -1;
    } else uniqueID++;
    return uniqueID;
  }
}
