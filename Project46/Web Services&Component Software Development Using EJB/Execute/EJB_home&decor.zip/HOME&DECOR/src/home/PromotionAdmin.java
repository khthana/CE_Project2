package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class PromotionAdmin extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>PromotionAdmin</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    out.println("<center><h1><p>Menu Promotion</p></h1></center>");
    out.println("<br><a href='../StockWAR/addpromotion' >Add New Promotion of Product </a>");
    out.println("<br><a href='../StockWAR/addsectionpromotion' >Add New Product Section Promotion</a>");
    //out.println("<br><a href='../StockWAR/addtypeproductpro' >Add New Product type Promotion </a>");
    out.println("<br><a href='../StockWAR/addpromotiontype' >Add New type of Product Promotion </a>");
    //out.println("<br><a href='../StockWAR/addpromotion' >Add New type of Product Promotion </a>");

    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
