package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface SessionPageHome extends javax.ejb.EJBHome {
  public SessionPage create() throws CreateException, RemoteException;
}