package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Tip_TrickRemoteHome extends javax.ejb.EJBHome {
  public Tip_TrickRemote create(Integer ttid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Tip_TrickRemote findByPrimaryKey(Integer ttid) throws FinderException, RemoteException;
}