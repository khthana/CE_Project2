package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class IndexTypeProduct extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'> "
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objts = jndiContext.lookup("TypeSectionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
          PortableRemoteObject.narrow(objts, Type_SectionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ////////////////////////////////////////////////////
      Collection cts = tshome.findSelectall();
      Object[] bts = cts.toArray();
      StringTools st = sTools.create();
      out.print("<font color='#FFFFFF'><a href='../SalesWAR/indexsales'>HOME  </a>");
      for (int j=0;j<cts.size();j++) {
        // Type_SectionRemote tsremote = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j].toString())));
		Type_SectionRemote tsremote = (Type_SectionRemote)bts[j];
        out.print("<a href='../SalesWAR/indexsection?section="+tsremote.getNamesection()+"'>"+tsremote.getNamesection()+"  </a>");
        //Link Section?get Value
      }
      out.print("</font>");

    }
    catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////////////////////////////
    out.println("</strong></font></td>"
                +"<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                +"<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                +"<tr>"
                +"<td>&nbsp;</td>"
                +"</tr>"
                +"<tr>"
                +"<td><div align='center'>&#3588;&#3657;&#3609;&#3627;&#3634; : "
                +"<input type='text' name='textfield'>"
                +"<input type='submit' name='Submit' value='GO!'>"
                +"</div></td>"
                +"</tr>"
                +"</table>"
                +"</form>"
                +"</div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td width='13%' height='404'><p>LeftFrame</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p></td>"
                +"<td width='57%'> <div align='center'> "
                +"<p>&nbsp;</p>"
                +"<p>RightFrame</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div>"
                +"<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                +"Home&amp;Decor.com Privacy Policy </p>"
                +"<p align='center'>Powered by HomeServices Inc.</p>"
                +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                +"<p>&nbsp;</p>"
                +"</body>"
                +"</html>");
  }
  //Clean up resources
  public void destroy() {
  }
}