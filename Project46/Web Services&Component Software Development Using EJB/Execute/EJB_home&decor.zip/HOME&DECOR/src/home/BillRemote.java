package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface BillRemote extends javax.ejb.EJBObject {
  public Integer getBid() throws RemoteException;
  public void setCid(Integer cid) throws RemoteException;
  public Integer getCid() throws RemoteException;
  public void setAmid(Integer amid) throws RemoteException;
  public Integer getAmid() throws RemoteException;
  public void setDatebuy(Timestamp datebuy) throws RemoteException;
  public Timestamp getDatebuy() throws RemoteException;
  public void setDatedeliver(Timestamp datedeliver) throws RemoteException;
  public Timestamp getDatedeliver() throws RemoteException;
  public void setCostDeliver(Float costDeliver) throws RemoteException;
  public Float getCostDeliver() throws RemoteException;
  public void setSumsales(Float sumsales) throws RemoteException;
  public Float getSumsales() throws RemoteException;
}