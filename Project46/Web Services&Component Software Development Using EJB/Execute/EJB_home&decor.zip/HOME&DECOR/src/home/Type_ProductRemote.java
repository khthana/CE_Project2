package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_ProductRemote extends javax.ejb.EJBObject {
  public Integer getTpid() throws RemoteException;
  public void setTsid(Integer tsid) throws RemoteException;
  public Integer getTsid() throws RemoteException;
  public void setTypeproductname(String typeproductname) throws RemoteException;
  public String getTypeproductname() throws RemoteException;
}