package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

import java.io.*;

public interface SessionPage extends javax.ejb.EJBObject {
  public void PrintNav(PrintWriter out) throws RemoteException;
}