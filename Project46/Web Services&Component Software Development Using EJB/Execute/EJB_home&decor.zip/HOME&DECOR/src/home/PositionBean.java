package home;

import javax.ejb.*;

abstract public class PositionBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer pid) throws CreateException {
    setPid(pid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer pid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setTypepostion(java.lang.String typepostion);
  public abstract java.lang.Integer getPid();
  public abstract java.lang.String getTypepostion();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}