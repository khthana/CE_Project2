package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BilldetailRemote extends javax.ejb.EJBObject {
  public Integer getBdid() throws RemoteException;
  public void setBid(Integer bid) throws RemoteException;
  public Integer getBid() throws RemoteException;
  public void setLine(Integer line) throws RemoteException;
  public Integer getLine() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
  public void setNumber(Integer number) throws RemoteException;
  public Integer getNumber() throws RemoteException;
  public void setSalesperunit(Float salesperunit) throws RemoteException;
  public Float getSalesperunit() throws RemoteException;
}