package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class AddTypeproductPro extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>Add Type Product Promotion </title></head>");
    out.println("<body bgcolor=\"#ffffff\">");


    ///////////////////////////////////////////
    out.println("<h1><p>Add Type Product Promotion </p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>Type Product Promotion ID</td>");
    out.println("<td bgcolor='#66CC99'>Percent Discount</td>");
    out.println("<td bgcolor='#66CC99'>Start Date</td>");
    out.println("<td bgcolor='#66CC99'>Stop Date</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion ID</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion Name</td>");
    out.println("<td bgcolor='#66CC99'>Type Product ID</td>");
    out.println("<td bgcolor='#66CC99'>Product Name</td>");
    //out.println("<td>NAME</td>");
    out.println("</tr>");

    try
    {
 // obtain MemberRemote
           Context jndiContext = new InitialContext();
           Object tpobj = jndiContext.lookup("PromotiontproductRemote");
           Object obj2 = jndiContext.lookup("StringTools");
           PromotiontproductRemoteHome tphome = (PromotiontproductRemoteHome)
               PortableRemoteObject.narrow(tpobj, PromotiontproductRemoteHome.class);
           StringToolsHome sTools = (StringToolsHome)
               PortableRemoteObject.narrow(obj2, StringToolsHome.class);

           Object ttpobj = jndiContext.lookup("Type_PromotionRemote");
           Type_PromotionRemoteHome ttphome = (Type_PromotionRemoteHome)
                               PortableRemoteObject.narrow(ttpobj, Type_PromotionRemoteHome.class);
           Object tppobj = jndiContext.lookup("Type_ProductRemote");
           Type_ProductRemoteHome tpphome = (Type_ProductRemoteHome)
                               PortableRemoteObject.narrow(tppobj, Type_ProductRemoteHome.class);



           Collection tpc = tphome.findSelectall();
           Object[] ppb = tpc.toArray();
           Collection ttpc = tphome.findSelectall();
           Object[] ttpb = ttpc.toArray();
           Collection tppc = tpphome.findSelectall();
           Object[] tppb = tppc.toArray();
           StringTools st = sTools.create();



           for(int j=0;j<tpc.size();j++){
             // PromotiontproductRemote tps = tphome.findByPrimaryKey(new Integer(st.cutEachColon(ppb[j].toString())));
             PromotiontproductRemote tps = (PromotiontproductRemote)ppb[j];

             out.println("<tr>");
             out.println("<td>"+tps.getPtpid()+"</td>");
             out.println("<td>"+tps.getPercentsale()+"</td>");
             out.println("<td>"+tps.getStart()+"</td>");
             out.println("<td>"+tps.getStop()+"</td>");
             //out.println("<td>"+tps.getTprid()+"</td>");
             //out.println("<td>"+tps.getTpid()+"</td>");
             //out.println("<td>"+tps.getTprid() +"</td>");
             //out.println("<td>"+tps.getName() +"</td>");
             //out.println("<td>"+ps.getPid() +"</td>");
             //out.println("<td>"+ps.getName() +"</td>");



             //for(int i=0;i<ttpc.size();i++)
            //{
              // Type_PromotionRemote ttps = ttphome.findByPrimaryKey(new Integer(st.cutEachColon(ttpb[i].toString())));
              Type_PromotionRemote ttps = ttphome.findByPrimaryKey(tps.getTpid());
              //if(st.cutEachColon(ttpb[i].toString()).equals(tps.getTprid().toString()))
              //{
                out.println("<td>"+ttps.getTprid() +"</td>");
                out.println("<td>"+ttps.getName() +"</td>");
              //}
            //}

            //for(int i=0;i<tppc.size();i++)
            //{
              // Type_ProductRemote tss = tpphome.findByPrimaryKey(new Integer(st.cutEachColon(tppb[i].toString())));
              Type_ProductRemote tss = tpphome.findByPrimaryKey(tps.getTprid());
              //if(st.cutEachColon(tppb[i].toString()).equals(tps.getTpid().toString()))
              //{
                out.println("<td>"+tss.getTpid() +"</td>");
                out.println("<td>"+tss.getTypeproductname() +"</td>");
              //}
            //}

           }
           out.println("</tr>");
           out.println("</table>");



           out.print("<form name='form1' method='get' action='../StockWAR/addtypeproductpro'>"
                     +"<h1>"
                     +"<p>Add Type Product Promotion ID</p>"
                     +"</h1>"
                     +"<table width='650' border='0' cellspacing='0' cellpadding='0'>"

                     +"<tr> "
                     +"<td width='30%'> Type Product Promotion ID</td>"
                     +"<td width='70%'><input type='text' name='textfield'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td>Percent Discount</td>"
                     +"<td><input type='text' name='textfield2'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td>Start Date</td>"
                     +"<td><input type='text' name='textfield3'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td>Stop Date</td>"
                     +"<td><input type='text' name='textfield4'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td>Type Promotion ID</td>"
                     +"<td><input type='text' name='textfield5'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td>Type Product ID</td>"
                     +"<td><input type='text' name='textfield6'></td>"
                     +"</tr>"
                     +"<tr>"
                     +"<td><input type='submit' name='Submit' value='Submit'>"
                     +"<input type='reset' name='Submit2' value='Reset'>"
                     +"</td></tr>"
                     +"</table>"
                     +"</form>"
                     );

           out.println("</br>");
           out.println("<br><a href='../promotionadmin' >Back</a>");


           String tpid = request.getParameter("textfield");
              PromotiontproductRemote tpremote;
              boolean haveP = false;
              for (int i=0;i<tpc.size();i++) {
                if ( st.cutEachColon(ppb[i].toString()).equals(tpid) ) haveP = true;
              }
              if (haveP) {
                out.println("Edit Promotion Product Section ");
                tpremote = tphome.findByPrimaryKey(new Integer(tpid));
                // name='Submit3' value='del'
                String del = request.getParameter("Submit2");
                if (del.equals("Reset")) tpremote.remove();
                else {

                }
              }
              else {
                out.println("Add Type Product Promotion");
                tpremote = tphome.create(new Integer(tpid));
                // tpremote.setTpid(new Integer(request.getParameter("textfield")));
                tpremote.setPercentsale(new Integer(request.getParameter("textfield2")));
                //ppremote.setStart(new Timestamp(new Integer(request.getParameter("textfield3"))));
                //ppremote.setStart(new Integer(request.getParameter("textfield3")));
                //ppremote.setStop(new Integer(request.getParameter("textfield4")));
                tpremote.setTprid(new Integer(request.getParameter("textfield5")));
                tpremote.setTpid(new Integer(request.getParameter("textfield6")));

                //premote.setBarcode(request.getParameter("textfield3"));

               /*
                String ok = request.getParameter("Submit");
                if(ok.equals("Submit")) response.reset();
                */
              }


         }
         catch (Throwable t) { t.printStackTrace(); }


         //---------------------------------------------------------------------
         out.println("</body></html>");
       }
       //Clean up resources
       public void destroy() {
       }
     }
