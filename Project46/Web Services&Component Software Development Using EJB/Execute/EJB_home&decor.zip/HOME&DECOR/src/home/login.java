package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class login extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>login</title></head>");
    out.println("<body bgcolor=\"#ffffff\"><center>");
    out.print("<h1><p>Login </p></h1>");

    try
    {
    // obtain MemberRemote
    Context jndiContext = new InitialContext();
    Object obj = jndiContext.lookup("EmployeeRemote");
    EmployeeRemoteHome home = (EmployeeRemoteHome)
                              PortableRemoteObject.narrow(obj, EmployeeRemoteHome.class);
    String user = request.getParameter("textfield");
    String password = request.getParameter("textfield2");
    EmployeeRemote ss = home.findIDByName(user);

    out.println("<h1>"+ss.getTypePosition()+"</h1>");
    if (ss.getPassword().equals(password)) {
      if (ss.getTypePosition().equals("Stocker"))
        out.print("<a href='../StockWAR/indexstock'>Enter</a>");
      else if (ss.getTypePosition().equals("System"))
        out.print("<a href='../SystemWAR/indexsystem'>Enter</a>");
    } else { out.println("Password Incorrect");
      out.print("<br><a href='../SystemWAR/System'>Back</a>"); }
    }
    catch (Throwable t) {
      out.println("Password Incorrect");
      out.print("<br><a href='../SystemWAR/System'>Back</a>");
      t.printStackTrace();
    }

    out.println("</center></body></html>");

  }
  //Clean up resources
  public void destroy() {
  }
}