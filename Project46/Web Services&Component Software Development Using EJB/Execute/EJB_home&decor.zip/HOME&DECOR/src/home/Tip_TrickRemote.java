package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Tip_TrickRemote extends javax.ejb.EJBObject {
  public Integer getTtid() throws RemoteException;
  public void setImageurl(String imageurl) throws RemoteException;
  public String getImageurl() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setDescription(String description) throws RemoteException;
  public String getDescription() throws RemoteException;
}