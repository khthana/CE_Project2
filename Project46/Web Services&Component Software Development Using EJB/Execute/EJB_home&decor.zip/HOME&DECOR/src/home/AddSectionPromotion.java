package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;
import java.sql.Timestamp;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class AddSectionPromotion extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>AddSectionPromotion</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    ///////////////////////////////////////////
    out.println("<h1><p>Product Section Promotion</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>Promotion Section ID</td>");
    out.println("<td bgcolor='#66CC99'>Percent Discount</td>");
    out.println("<td bgcolor='#66CC99'>Start Date</td>");
    out.println("<td bgcolor='#66CC99'>Stop Date</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion ID</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion Name</td>");
    out.println("<td bgcolor='#66CC99'>Type Product Section  ID</td>");
    out.println("<td bgcolor='#66CC99'>Product Name</td>");
    //out.println("<td>NAME</td>");
    out.println("</tr>");

    try
   {
   // obtain MemberRemote
     Context jndiContext = new InitialContext();
     Object psobj = jndiContext.lookup("PromotionsectionRemote");
     Object obj2 = jndiContext.lookup("StringTools");
     PromotionsectionRemoteHome pshome = (PromotionsectionRemoteHome)
                               PortableRemoteObject.narrow(psobj, PromotionsectionRemoteHome.class);

     StringToolsHome sTools = (StringToolsHome)
                               PortableRemoteObject.narrow(obj2, StringToolsHome.class);
     Object tpobj = jndiContext.lookup("Type_PromotionRemote");
     Type_PromotionRemoteHome tphome = (Type_PromotionRemoteHome)
                               PortableRemoteObject.narrow(tpobj, Type_PromotionRemoteHome.class);
     Object tsobj = jndiContext.lookup("Type_SectionRemote");
     Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
                               PortableRemoteObject.narrow(tsobj, Type_SectionRemoteHome.class);

     Collection psc = pshome.findSelectall();
     Object[] ppb = psc.toArray();
     Collection tsc = tshome.findSelectall();
     Object[] tsb = tsc.toArray();
     Collection tpc = tphome.findSelectall();
     Object[] tpb = tpc.toArray();
     StringTools st = sTools.create();



     for(int j=0;j<psc.size();j++){
           // PromotionsectionRemote pss = pshome.findByPrimaryKey(new Integer(st.cutEachColon(ppb[j].toString())));
		   PromotionsectionRemote pss = (PromotionsectionRemote)ppb[j];
           //ProductRemote ps = phome.findByPrimaryKey(pps.getPsid());
           //Type_PromotionRemote tps = tphome.findByPrimaryKey(pps.getPid());
           //ProductRemote ps = phome.findByPrimaryKey(new Integer(st.cutEachColon(pb[j].toString())));

            out.println("<tr>");
            out.println("<td>"+pss.getPsid()+"</td>");
            out.println("<td>"+pss.getPercentsale()+"</td>");
            out.println("<td>"+pss.getStart()+"</td>");
            out.println("<td>"+pss.getStop()+"</td>");
            //out.println("<td>"+pss.getTprid()+"</td>");
           // out.println("<td>"+pss.getTsid()+"</td>");
            //out.println("<td>"+tps.getTprid() +"</td>");
            //out.println("<td>"+tps.getName() +"</td>");
            //out.println("<td>"+ps.getPid() +"</td>");
            //out.println("<td>"+ps.getName() +"</td>");


             //for(int i=0;i<tpc.size();i++)
             //{
               // Type_PromotionRemote tps = tphome.findByPrimaryKey(new Integer(st.cutEachColon(tpb[i].toString())));
               Type_PromotionRemote tps = tphome.findByPrimaryKey(pss.getTprid());
               //if(st.cutEachColon(tpb[i].toString()).equals(pss.getTprid().toString()))
               //{
                 out.println("<td>"+tps.getTprid() +"</td>");
                 out.println("<td>"+tps.getName() +"</td>");
               //}
             //}


             //for(int i=0;i<tsc.size();i++)
             //{
               // Type_SectionRemote tss = tshome.findByPrimaryKey(new Integer(st.cutEachColon(tsb[i].toString())));
               Type_SectionRemote tss = tshome.findByPrimaryKey(pss.getTsid());
               //if(st.cutEachColon(tsb[i].toString()).equals(pss.getTsid().toString()))
               //{
                 out.println("<td>"+tss.getTsid() +"</td>");
                 out.println("<td>"+tss.getNamesection() +"</td>");
               //}
             //}

        }
        out.println("</tr>");
        out.println("</table>");

        out.print("<form name='form1' method='get' action='../StockWAR/addsectionpromotion'>"
                             +"<h1>"
                             +"<p>Add Promotion Product Section </p>"
                             +"</h1>"
                             +"<table width='600' border='0' cellspacing='0' cellpadding='0'>"

                             +"<tr> "
                             +"<td width='30%'> Promotion Section ID</td>"
                             +"<td width='70%'><input type='text' name='textfield'></td>"
                             +"</tr>"
                             +"<tr>"
                             +"<td>Percent Discount</td>"
                             +"<td><input type='text' name='textfield2'></td>"
                             +"</tr>"

                             + "<tr>"
                             + "<td>Start Date</td>"
                             + "<td>"
                             + "YYYY:<input type='text' name='t1' size='3'>"
                             + "Month:<input type='text' name='t2' size='3'>"
                             + "Day:<input type='text' name='t3' size='3'>"
                             + "HH:<input type='text' name='t4' size='3'>"
                             + "MM:<input type='text' name='t5' size='3'>"
                             //+"SS:<input type='text' name='t6' size='3'>"
                             //+"MS:<input type='text' name='t7' size='3'>"
                             + "</td>"
                             + "</tr>"

                             + "<tr>"
                             + "<td>Stop Date</td>"
                             + "<td>"
                             + "YYYY:<input type='text' name='st1' size='3'>"
                             + "Month:<input type='text' name='st2' size='3'>"
                             + "Day:<input type='text' name='st3' size='3'>"
                             + "HH:<input type='text' name='st4' size='3'>"
                             + "MM:<input type='text' name='st5' size='3'>"
                             //+"SS:<input type='text' name='st6' size='3'>"
                             //+"MS:<input type='text' name='t7' size='3'>"
                             + "</tr>"

                             +"<tr>"
                             +"<td>Type Promotion ID</td>"
                             +"<td><input type='text' name='textfield5'></td>"
                             +"</tr>"
                             +"<tr>"
                             +"<td>Type Product Section ID</td>"
                             +"<td><input type='text' name='textfield6'></td>"
                             +"</tr></br>"
                             +"<tr>"
                             +"<td><input type='submit' name='Submit' value='Submit'>"
                             +"<input type='reset' name='Submit2' value='Reset'>"
                             +"</td></tr>"
                             +"</table>"
                             +"</form>"

                             );

              out.println("</br>");
              out.println("<br><a href='../StockWAR/promotionadmin' >Back</a>");

              String psid = request.getParameter("textfield");
              PromotionsectionRemote psremote;
              boolean haveP = false;
              for (int i=0;i<psc.size();i++) {
                if ( st.cutEachColon(ppb[i].toString()).equals(psid) ) haveP = true;
              }
              if (haveP) {
                out.println("Edit Promotion Product Section ");
                psremote = pshome.findByPrimaryKey(new Integer(psid));
                // name='Submit3' value='del'
                String del = request.getParameter("Submit2");
                if (del.equals("Reset")) psremote.remove();
                else {

                }
              }
              else {
                out.println("Add Promotion Product ");
                psremote = pshome.create(new Integer(psid));
                // tpremote.setTpid(new Integer(request.getParameter("textfield")));
                psremote.setPercentsale(new Integer(request.getParameter("textfield2")));

                //ppremote.setStart(new Timestamp (request.getParameter("textfield3")));
                Integer t1 = new Integer(request.getParameter("t1"));
                Integer t2 = new Integer(request.getParameter("t2"));
                Integer t3 = new Integer(request.getParameter("t3"));
                Integer t4 = new Integer(request.getParameter("t4"));
                Integer t5 = new Integer(request.getParameter("t5"));
                //Integer t6 = new Integer(request.getParameter("t6"));
                //Integer t7 = new Integer(request.getParameter("t7"));

                psremote.setStart(new Timestamp(
                    t1.intValue(),
                    t2.intValue() - 1,
                    t3.intValue(),
                    t4.intValue(),
                    t5.intValue(),
                    0, //t6.intValue(),
                    0 //t7.intValue()
                    ));

                Integer st1 = new Integer(request.getParameter("st1"));
                Integer st2 = new Integer(request.getParameter("st2"));
                Integer st3 = new Integer(request.getParameter("st3"));
                Integer st4 = new Integer(request.getParameter("st4"));
                Integer st5 = new Integer(request.getParameter("st5"));
                //Integer st6 = new Integer(request.getParameter("st6"));
                //Integer st7 = new Integer(request.getParameter("st7"));

                psremote.setStop(new Timestamp(
                    st1.intValue(),
                    st2.intValue() - 1,
                    st3.intValue(),
                    st4.intValue(),
                    st5.intValue(),
                    0, //st6.intValue(),
                    0 //st7.intValue()
                    ));

                psremote.setTprid(new Integer(request.getParameter("textfield5")));
                psremote.setTsid(new Integer(request.getParameter("textfield6")));

                //premote.setBarcode(request.getParameter("textfield3"));

               /*
                String ok = request.getParameter("Submit");
                if(ok.equals("Submit")) response.reset();
                */
              }

    }
     catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////
    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
