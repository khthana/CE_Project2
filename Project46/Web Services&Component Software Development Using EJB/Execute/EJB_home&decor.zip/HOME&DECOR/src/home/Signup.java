package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Signup extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      ///////////////////////////////////////////////////////////////////

      out.print("</strong></font></td>"
                + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "<tr>"
                + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                + "<tr>"
                + "<td>&nbsp;</td>"
                + "</tr>"
                + "<tr>"
                + "<td><div align='center'>Search : "
                + "<input type='text' name='textfield'>"
                + "<input type='submit' name='Submit' value='GO!'>"
                + "</div></td>"
                + "</tr>"
                + "</table>"
                + "</form>"
                + "</div></td>"
                + "</tr>"
                + "<tr> "
                + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                + "<tr> "
                + "<td width='13%' height='404'>");
      //--------------------------------------------------------------------------
      out.println("<form name='form1' method='get' action='../SalesWAR/signupok'>");
      out.print(  "<table width='918' border='0' bordercolor='#CC3366'>"
                +"<tr>"
                +"<td width='178' valign='middle'><div align='left'><STRONG><font color='#3333FF'>User Name</font></STRONG></div>"
                +"&nbsp;</td>"
                +"<td width='730'>"
                +"<input name='textfield1' type='text' size='40' maxlength='45'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td valign='middle'><div align='left'><STRONG><font color='#3333FF'>Password"
                +"</font></STRONG></div>"
                +"&nbsp;</td>"
                +"<td>"
                +"<input name='textfield2' type='password' size='40' maxlength='45'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td valign='middle'><div align='left'><STRONG><font color='#3333FF'> Confirm"
                +"Password </font></STRONG></div>"
                +"&nbsp;</td>"
                +"<td>"
                +"<input name='textfield3' type='password' size='40' maxlength='45'>"
                +"</td>"
                +"</tr>"
                +"</table>"
                +"<table width='925' border='0'>"
                +"<tr>"
                +"<td bgcolor='#CCCCCC'><strong>Profile Information</strong></td>"
                +"</tr>"
                +"</table>"
                +"<table width='915' border='0'>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> Salutation"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td width='730'>"
                +"<select name='select'>"
                +"<option value  = ''>		  --Select--"
                +"<option value = '1'> Mr."
                +"<option value = '2'>Mrs."
                +"<option value = '3'> Ms."
                +"<option value = '4'> Miss"
                +"</select>"
                +"</td>"
                +"</tr>"
                +"</table>"
                +"<table width='915' border='0'>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> First Name"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td width='732'>"
                +"<input name='textfield4' type='text' size='40' maxlength='50'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> Last Name"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td>"
                +"<input name='textfield5' type='text' size='40' maxlength='50'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> Address"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td>"
                +"<textarea name='textarea' cols='20' rows='4'></textarea>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> Telephone"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td>"
                +"<input name='textfield6' type='text' size='40' maxlength='50'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> Mobile"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td>"
                +"<input name='textfield7' type='text' size='40' maxlength='50'>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'> E-Mail  Address"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td> <input name='textfield8' type='text' size='40' maxlength='50'></td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'>"
                +"Occupation</font></STRONG></div>"
                +"&nbsp;</td>"
                +"<td width='730'>"
                +"<select name='select2'>"
                +"<option value=''>--Select--"
                +"<option value='1'>Developer"
                +"<option value='2'>Engineer"
                +"<option value='3'>Architect"
                +"<option value='4'>Student"
                +"<option value='5'>Other"
                +"<option value='6'>Salesperson"
                +"<option value='7'>Marketing"
                +"<option value='8'>Accountant"
                +"<option value='9'>Home Decorate Consultant"
                +"</select>"
                +"</td>"
                +"</tr>"
                +"<tr>"
                +"<td width='176' height='42' valign='middle'>    <div align='left'><STRONG><font color='#3333FF'>Salary"
                +"</font></STRONG></div>&nbsp;</td>"
                +"<td width='730'>"
                +"<select name='select3'>"
                +"<option value  = ''>		  --Select--"
                +"<option value = '1'> 0-10,000 Bath"
                +"<option value = '2'>10,001-20,000 Bath"
                +"<option value = '3'> 20,001-30,000 Bath"
                +"<option value = '4'> 30,001 up"
                +"</select>"
                +"</tr>"
                +"</table>"
                +"<table width='915' border='0'>"
                +"<tr>"
                +"<td width='925' bgcolor='#cccccc'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                +"&nbsp; <input name='Submit' type='submit' value='subscribe'> &nbsp; <input name='Reset' type='reset' value='reset'></td>"
                +"</tr>"
                +"</table>"
                +"</form>");
      //------------------------------------------------------------------------
      out.println("<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "</div>"
                  + "<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                  + "<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                  + "Home&amp;Decor.com Privacy Policy </p>"
                  + "<p align='center'>Powered by HomeServices Inc.</p>"
                  + "<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                  + "<p>&nbsp;</p>"
                  + "</body>"
                  + "</html>");
    }
    catch (Throwable t) { t.printStackTrace(); }
  }
  //Clean up resources
  public void destroy() {
  }
}
