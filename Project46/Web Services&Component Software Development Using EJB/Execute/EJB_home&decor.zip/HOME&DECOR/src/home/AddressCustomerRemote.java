package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AddressCustomerRemote extends javax.ejb.EJBObject {
  public Integer getAmid() throws RemoteException;
  public void setCid(Integer cid) throws RemoteException;
  public Integer getCid() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getAddress() throws RemoteException;
}