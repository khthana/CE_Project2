package home;

import javax.ejb.*;

abstract public class SupplyProductBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer spid) throws CreateException {
    setSpid(spid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer spid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setSpid(java.lang.Integer spid);
  public abstract void setPlid(java.lang.Integer plid);
  public abstract void setSid(java.lang.Integer sid);
  public abstract void setCost(java.lang.Float cost);
  public abstract void setNumber(java.lang.Integer number);
  public abstract void setDate(java.sql.Timestamp date);
  public abstract java.lang.Integer getSpid();
  public abstract java.lang.Integer getPlid();
  public abstract java.lang.Integer getSid();
  public abstract java.lang.Float getCost();
  public abstract java.lang.Integer getNumber();
  public abstract java.sql.Timestamp getDate();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}