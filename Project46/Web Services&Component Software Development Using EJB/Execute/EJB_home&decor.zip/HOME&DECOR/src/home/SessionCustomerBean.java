package home;

import javax.ejb.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class SessionCustomerBean implements SessionBean {
  SessionContext sessionContext;
  java.lang.String name;
  java.lang.String surname;
  Integer iD;
  java.lang.String password;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
    name = "no";
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public void setName(java.lang.String name) {
    this.name = name;
  }
  public void setSurname(java.lang.String surname) {
    this.surname = surname;
  }
  public void setID(Integer iD) {
    this.iD = iD;
  }
  public void setPassword(java.lang.String password) {
    this.password = password;
  }
  public java.lang.String getName() {
    return name;
  }
  public java.lang.String getSurname() {
    return surname;
  }
  public Integer getID() {
    return iD;
  }
  public java.lang.String getPassword() {
    return password;
  }
  public void login(HttpServletRequest request, PrintWriter out) {
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsession = jndiContext.lookup("SessionCustomer");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionCustomerHome chome = (SessionCustomerHome)
          PortableRemoteObject.narrow(objsession, SessionCustomerHome.class);

      // Check login /////////////////////////////////////
      Object obj = jndiContext.lookup("CustomerRemote");
      CustomerRemoteHome home = (CustomerRemoteHome)
          PortableRemoteObject.narrow(obj, CustomerRemoteHome.class);
      String user = request.getParameter("usertextfield");
      String password = request.getParameter("passwordtextfield");
      // Check login /////////////////////////////////////
      HttpSession session = request.getSession(true);
      SessionCustomer customer =
          (SessionCustomer)session.getValue("SessionCustomer");        // Create Session Variable
      if (customer == null) {
        customer = chome.create();
        customer.setID(new Integer(0));
        session.putValue("SessionCustomer", customer);                // put Session
        customer.setID(new Integer(0));

        out.print("<table width='182' height='0%' border='0' cellpadding='0' cellspacing='0' bordercolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='244' height='62%' bgcolor='#FFFFFF'><img src='../jmx-console/images/signin-bar.jpg' width='182' height='36'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td height='50' background='../jmx-console/images/MenubarMiddle.jpg'><div align='center'>"
                  + "<form name='form2' method='get' action='../SalesWAR/logincustomer'>"
                  + "<table width='19%' border='0' cellpadding='1' cellspacing='0' bgcolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='35%' nowrap bgcolor='#f1f3f0'><font size='-1'>"
                  + "Username</font></td>"
                  + "<td width='65%' bgcolor='#f1f3f0'><input name='usertextfield' type='text' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td nowrap bgcolor='#f1f3f0'><font size='-1'> Password</font></td>"
                  + "<td bgcolor='#f1f3f0'> <input name='passwordtextfield' type='password' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td bgcolor='#f1f3f0'><input type='submit' name='Submit2' value='Login'>"
                  + "</td>"
                  + "<td bgcolor='#f1f3f0'><center><a href='../SalesWAR/signup'>Sign-Up</a><center></td>"
                  + "</tr>"
                  + "</table></form>"
                  +"</div></td>"
                  +"</tr>"
                  +"<tr> "
                  +"<td height='7' bgcolor='#FFFFFF'> <div align='center'><img src='../jmx-console/images/MenubarBottom.jpg' width='182' height='7'></div></td>"
                  +"</tr>"
                  +"</table>");

      } else {
        if (!customer.getName().equals("no"))
        {
          out.print("<table width='182' height='0%' border='0' cellpadding='0' cellspacing='0' bordercolor='#FFFFFF'>"
                    + "<tr> "
                    + "<td width='244' height='62%' bgcolor='#FFFFFF'><img src='../jmx-console/images/welcome-bar.jpg' width='182' height='36'></td>"
                    + "</tr>"
                    + "<tr> "
                    + "<td height='50' background='../jmx-console/images/MenubarMiddle.jpg'><div align='center'> "
                    + "<table width='60' height='57' border='0' cellpadding='1' cellspacing='0' bgcolor='#FFFFFF'>"
                    + "<tr>"
                    +
              "<td width='35%' nowrap bgcolor='#f1f3f0'><font size='-1'>Welcome </font></td>"
                    +
              "<td width='35%' nowrap bgcolor='#f1f3f0'><div align='center'><font size='-1'> "
                    + customer.getName() + "</font></div></td>"
                    + "</tr>"
                    + "<tr>"
                    +
              "<td nowrap bgcolor='#f1f3f0'><a href='../SalesWAR/basket'>basket</a></td>"
                    + "<td nowrap bgcolor='#f1f3f0'><div align='left'><font size='-1'><a href='../SalesWAR/signout'>Sign "
                    + "out</a> </font></div></td>"
                    + "</tr>"
                    + "</table>"
                    + "</div></td>"
                    + "</tr>"
                    + "<tr> "
                    + "<td height='7' bgcolor='#FFFFFF'> <div align='center'><img src='../jmx-console/images/MenubarBottom.jpg' width='182' height='7'></div></td>"
                    + "</tr>"
                    + "</table>");
        }
          else {
            // Third ///////////////////////////////////////////////////////////
            out.print("<table width='182' height='0%' border='0' cellpadding='0' cellspacing='0' bordercolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='244' height='62%' bgcolor='#FFFFFF'><img src='../jmx-console/images/signin-bar.jpg' width='182' height='36'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td height='50' background='../jmx-console/images/MenubarMiddle.jpg'><div align='center'>"
                  + "<form name='form2' method='get' action='../SalesWAR/logincustomer'>"
                  + "<table width='19%' border='0' cellpadding='1' cellspacing='0' bgcolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='35%' nowrap bgcolor='#f1f3f0'><font size='-1'>"
                  + "Username</font></td>"
                  + "<td width='65%' bgcolor='#f1f3f0'><input name='usertextfield' type='text' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td nowrap bgcolor='#f1f3f0'><font size='-1'> Password</font></td>"
                  + "<td bgcolor='#f1f3f0'> <input name='passwordtextfield' type='password' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td bgcolor='#f1f3f0'><input type='submit' name='Submit2' value='Login'>"
                  + "</td>"
                  + "<td bgcolor='#f1f3f0'><center><a href='../SalesWAR/signup'>Sign-Up</a><center></td>"
                  + "</tr>"
                  + "</table></form>"
                  +"</div></td>"
                  +"</tr>"
                  +"<tr> "
                  +"<td height='7' bgcolor='#FFFFFF'> <div align='center'><img src='../jmx-console/images/MenubarBottom.jpg' width='182' height='7'></div></td>"
                  +"</tr>"
                  +"</table>");
          }
      }

    }
    catch (Throwable t) { t.printStackTrace(); }
  }
  public Integer Buy(String name, String password, String costdeliver, String amid) {
    Integer output = new Integer(1);
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();

      Object objbu = jndiContext.lookup("KeepSessionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      Object objb = jndiContext.lookup("BillRemote");
      Object objbd = jndiContext.lookup("BilldetailRemote");
      Object objid = jndiContext.lookup("UniqueID");
      Object objp = jndiContext.lookup("ProductRemote");
      Object objpp = jndiContext.lookup("ProductplaceRemote");
      Object obj = jndiContext.lookup("CustomerRemote");
      Object objpromotion = jndiContext.lookup("Promotion");

      KeepSessionRemoteHome buhome = (KeepSessionRemoteHome)
          PortableRemoteObject.narrow(objbu, KeepSessionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      BillRemoteHome bhome = (BillRemoteHome)
          PortableRemoteObject.narrow(objb, BillRemoteHome.class);
      BilldetailRemoteHome bdhome = (BilldetailRemoteHome)
          PortableRemoteObject.narrow(objbd, BilldetailRemoteHome.class);
      UniqueIDHome idhome = (UniqueIDHome)
          PortableRemoteObject.narrow(objid, UniqueIDHome.class);
      ProductRemoteHome phome = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);
      ProductplaceRemoteHome pphome = (ProductplaceRemoteHome)
          PortableRemoteObject.narrow(objpp, ProductplaceRemoteHome.class);
      CustomerRemoteHome chome = (CustomerRemoteHome)
          PortableRemoteObject.narrow(obj, CustomerRemoteHome.class);
      PromotionHome homepromotion = (PromotionHome)
          PortableRemoteObject.narrow(objpromotion, PromotionHome.class);
      Promotion promotion = homepromotion.create();


      UniqueID id = idhome.create();
      StringTools st = sTools.create();

      Collection bc = buhome.findSelectall();
      Object[] bb = bc.toArray();


      // Check Stock ///////////////////////////////////////////////////////////
      boolean exit=false;
      for (int i = 0; i < bc.size(); i++) {
        // KeepSessionRemote keepsession = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bb[i].toString())));
		KeepSessionRemote keepsession = (KeepSessionRemote)bb[i];
        ProductplaceRemote productplace = pphome.findPid(keepsession.getPid());
        if (productplace.getRemain().intValue() < keepsession.getNumber().intValue()) {
          exit = true;
        }
      }
      if (exit) return Integer.valueOf("0");
      // Check Stock ///////////////////////////////////////////////////////////


      BillRemote bill = bhome.create(new Integer(id.getUnique()));
      //bill.setAmid(new Integer(request.getParameter("select")));
      bill.setAmid(new Integer(amid));
      CustomerRemote c = chome.findIDByLoginName(name);
      bill.setCid(c.getMid());
      //bill.setCostDeliver(new Float(request.getParameter("select3")));
      costdeliver = "150";
      bill.setCostDeliver(new Float(costdeliver));
      // Set Time //////////////////////////////////////////////////
      SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
      //bill.setDatebuy(new Timestamp(2003, 11, 17, 9, 30, 00, 0));
      //bill.setDatedeliver(new Timestamp(2003, 11, 17, 9, 30, 00, 0));
      //bill.setDatebuy(new Timestamp(date.YEAR_FIELD, date.MONTH_FIELD, date.DATE_FIELD,
      //                              date.HOUR0_FIELD, date.MINUTE_FIELD, date.MILLISECOND_FIELD, 0));
      //bill.setDatedeliver(new Timestamp(date.YEAR_FIELD, date.MONTH_FIELD, date.DATE_FIELD+7,
      //                              date.HOUR0_FIELD, date.MINUTE_FIELD, date.MILLISECOND_FIELD, 0));
      bill.setDatebuy(new Timestamp(new java.util.Date().getTime()));
      bill.setDatedeliver(new Timestamp(new java.util.Date().getTime()));
      // Set Time //////////////////////////////////////////////////
      bill.setSumsales(new Float(1000));

      // Keep to Database //////////////////////////////////////////////////////
      // OutPut print //////////////////////////////////////////////////////////
      KeepSessionRemote b;
      BilldetailRemote billdetail;
      int countorder = 0;
      for (int i = 0; i < bc.size(); i++) {
        // b = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bb[i].toString())));
		b = (KeepSessionRemote)bb[i];
        ProductRemote product = phome.findByPrimaryKey(b.getPid());
        if (b.getMid().equals(c.getMid())) {
          countorder++;
          billdetail = bdhome.create(new Integer(id.getUnique()));
          billdetail.setBid(bill.getBid());
          billdetail.setNumber(b.getNumber());
          billdetail.setLine(new Integer(countorder));
          billdetail.setPid(b.getPid());
          //billdetail.setSalesperunit(product.getSaleavg());
          billdetail.setSalesperunit(new Float(promotion.PriceProduct(b.getPid())));
          ProductplaceRemote productplace = pphome.findPid(b.getPid());
          productplace.setRemain(new Integer(productplace.getRemain().intValue()-
                                             b.getNumber().intValue()));
          b.remove();
        }
      }
      output = bill.getBid();
    } catch (Throwable t) { t.printStackTrace(); }
    return output;
  }
  /*
  public String Buy(String iiD, String password, String[] streamProduct, String[] streamNumProduct, String Amid) {

    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("CustomerRemote");
      CustomerRemoteHome home = (CustomerRemoteHome)
          PortableRemoteObject.narrow(obj, CustomerRemoteHome.class);

      CustomerRemote member = home.findIDByLoginName(iiD);
      if (member.getPassword().equals(password)) {
        // Create Bill ////////////////////////////////////
        Object objb = jndiContext.lookup("BillRemote");
        Object objbd = jndiContext.lookup("BilldetailRemote");
        Object objid = jndiContext.lookup("UniqueID");
        Object objp = jndiContext.lookup("ProductRemote");

        BillRemoteHome bhome = (BillRemoteHome)
            PortableRemoteObject.narrow(objb, BillRemoteHome.class);
        BilldetailRemoteHome bdhome = (BilldetailRemoteHome)
            PortableRemoteObject.narrow(objbd, BilldetailRemoteHome.class);
        UniqueIDHome idhome = (UniqueIDHome)
            PortableRemoteObject.narrow(objid, UniqueIDHome.class);
        ProductRemoteHome phome = (ProductRemoteHome)
            PortableRemoteObject.narrow(objp, ProductRemoteHome.class);

        UniqueID id = idhome.create();

        BillRemote bill = bhome.create(new Integer(id.getUnique()));
        bill.setAmid(Integer.valueOf(Amid));
        bill.setCid(member.getMid());
        bill.setCostDeliver(new Float("150"));
        // Set Time //////////////////////////////////////////////////
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        //bill.setDatebuy(new Timestamp(2003, 11, 17, 9, 30, 00, 0));
        //bill.setDatedeliver(new Timestamp(2003, 11, 17, 9, 30, 00, 0));
        bill.setDatebuy(new Timestamp(date.YEAR_FIELD, date.MONTH_FIELD, date.DATE_FIELD,
                                      date.HOUR0_FIELD, date.MINUTE_FIELD, date.MILLISECOND_FIELD, 0));
        bill.setDatedeliver(new Timestamp(date.YEAR_FIELD, date.MONTH_FIELD, date.DATE_FIELD+7,
                                          date.HOUR0_FIELD, date.MINUTE_FIELD, date.MILLISECOND_FIELD, 0));
        // Set Time //////////////////////////////////////////////////
        bill.setSumsales(new Float(1000));

        //String [] p = new String[st.NumStreamString(streamProduct)];
        //p = st.cutStreamString(streamProduct);
        //String [] pn = new String[st.NumStreamString(streamNumProduct)];
        //pn = st.cutStreamString(streamNumProduct);
        String [] p = streamProduct;
        String [] pn = streamNumProduct;

        // Keep to Database //////////////////////////////////////////////////////
        // OutPut print //////////////////////////////////////////////////////////
        BilldetailRemote billdetail;
        ProductRemote pd;
        for (int i = 0; i < pn.length; i++) {
          pd = phome.findByPrimaryKey(new Integer(p[i]));
          billdetail = bdhome.create(new Integer(id.getUnique()));
          billdetail.setBid(bill.getBid());
          billdetail.setNumber(new Integer(pn[i]));
          billdetail.setLine(new Integer(i+1));
          billdetail.setPid(pd.getPid());
          billdetail.setSalesperunit(pd.getSaleavg());
        }
      }

    } catch (Throwable t) { t.printStackTrace(); }
    return null;
  }
  */
  public String[][] ViewKeepSession(String name, String password) {
    // List //////////////////////////////////////
    String[][] output = new String[1][1];
    try {
      Context jndiContext = new InitialContext();
      Object objbu = jndiContext.lookup("KeepSessionRemote");
      Object obj = jndiContext.lookup("ProductRemote");
      Object cobj = jndiContext.lookup("CustomerRemote");
      // Create RemoteHome ///////////////////////////////
      KeepSessionRemoteHome buhome = (KeepSessionRemoteHome)
          PortableRemoteObject.narrow(objbu, KeepSessionRemoteHome.class);
      ProductRemoteHome home = (ProductRemoteHome)
          PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
      CustomerRemoteHome chome = (CustomerRemoteHome)
          PortableRemoteObject.narrow(cobj, CustomerRemoteHome.class);
      ////////////////////////////////////////////////////
      KeepSessionRemote b;
      ProductRemote p;
      CustomerRemote customer = chome.findIDByLoginName(name);
      ////////////////////////////////////////////////////

      // Show List Basket ////////////////////////////////
      Collection bc = buhome.findSelectall();
      Object[] bb = bc.toArray();
      // check number ///////////////////////////////////
      int num = 0;
      for (int i = 0; i < bc.size(); i++) {
        b = (KeepSessionRemote) bb[i];
        if (b.getMid().equals(customer.getMid())) {
          num++;
        }
      }
      // check number ///////////////////////////////////
      output = new String[num][4];
      num = 0;
      for (int i = 0; i < bc.size(); i++) {
        b = (KeepSessionRemote) bb[i];
        if (b.getMid().equals(customer.getMid())) {
          p = home.findByPrimaryKey(b.getPid());

          output[num][0] = String.valueOf(b.getPid());
          output[num][1] = p.getName();
          output[num][2] = String.valueOf(b.getNumber());
          output[num++][3] = String.valueOf(p.getSaleavg());
        }
      }
    } catch (Throwable t) { t.printStackTrace(); }
    // List //////////////////////////////////////
    return output;
  }
  public String AddKeepSession(String name, String password, String pid) {
    try {
      Context jndiContext = new InitialContext();
      Object objbu = jndiContext.lookup("KeepSessionRemote");
      Object obj = jndiContext.lookup("ProductRemote");
      Object cobj = jndiContext.lookup("CustomerRemote");
      // Create RemoteHome ///////////////////////////////
      KeepSessionRemoteHome buhome = (KeepSessionRemoteHome)
          PortableRemoteObject.narrow(objbu, KeepSessionRemoteHome.class);
      ProductRemoteHome home = (ProductRemoteHome)
          PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
      CustomerRemoteHome chome = (CustomerRemoteHome)
          PortableRemoteObject.narrow(cobj, CustomerRemoteHome.class);
      ////////////////////////////////////////////////////
      KeepSessionRemote b;
      KeepSessionRemote b2,b3;
      ProductRemote p;
      ////////////////////////////////////////////////////
      // Add to Basket ///////////////////////////////////
      //String add = request.getParameter("addproduct");
      //if (add != null && customer != null) {
      {
        Object objid = jndiContext.lookup("UniqueID");
        UniqueIDHome idhome = (UniqueIDHome)
            PortableRemoteObject.narrow(objid, UniqueIDHome.class);
        UniqueID id = idhome.create();

        CustomerRemote customer = chome.findIDByLoginName(name);
        if (customer != null) {
          b = buhome.create(new Integer(id.getUnique()));
          b.setMid(customer.getMid());
          b.setPid(new Integer(pid));
          b.setNumber(new Integer(1));
          // Delete repeat Product , Member ////////////////////////////////////
          Collection buc = buhome.findbucidByPM(customer.getMid(), b.getPid());
          Object[] bub = buc.toArray();
          if (buc.size() == 1) {
            b2 = (KeepSessionRemote) bub[0];
            b2.setNumber(new Integer(b2.getNumber().intValue() +
                                     b.getNumber().intValue()));
            b.remove();
          }
          //return String.valueOf(buc.size());
        }
      }

    }
    catch (Throwable t) { t.printStackTrace(); }
    return "Ok";

  }
}