package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PositionRemoteHome extends javax.ejb.EJBHome {
  public PositionRemote create(Integer pid) throws CreateException, RemoteException;
  public PositionRemote findByPrimaryKey(Integer pid) throws FinderException, RemoteException;
}