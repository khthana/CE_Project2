package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

public class indexStock extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Stock</title></head>");
    out.println("<frameset rows='*'cols='209,*' framespacing='0' frameborder='NO' border='0'>"
    +"<frame src='../StockWAR/leftframe' name='leftFrame' scrolling='NO' noresize>"
    +"<frame src='../StockWAR/addproduct' name='mainFrame'>"
    +"<noframes></frameset>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("</center></body></noframes></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}