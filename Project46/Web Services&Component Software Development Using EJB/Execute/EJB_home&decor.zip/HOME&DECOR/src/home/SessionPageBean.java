package home;

import javax.ejb.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class SessionPageBean implements SessionBean {
  SessionContext sessionContext;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public void PrintNav(PrintWriter out) {
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objts = jndiContext.lookup("Type_SectionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
          PortableRemoteObject.narrow(objts, Type_SectionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      ////////////////////////////////////////////////////
      Collection cts = tshome.findSelectall();
      Object[] bts = cts.toArray();
      StringTools st = sTools.create();
      out.print("<table><tr>");
      out.print("<td><a href='../SalesWAR/indexsales'><font color='#FFFFFF'><B>&#3627;&#3609;&#3657;&#3634;&#3627;&#3621;&#3633;&#3585;</B></font></td></a>");
      for (int j=0;j<cts.size();j++) {
        if (j != cts.size()) out.print("<td><img src='../jmx-console/images/003.gif'></td>");
        // Type_SectionRemote tsremote = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j].toString())));
		Type_SectionRemote tsremote = (Type_SectionRemote)bts[j];
        out.print("<td><a href='../SalesWAR/indexsection?section="+tsremote.getNamesection()+"'><font color='#FFFFFF'><B>"+tsremote.getNamesection()+"</B></font></td></a>");
        //Link Section?get Value
      }
      out.print("</tr></table>");

    }
    catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////////////////////////////

  }
}