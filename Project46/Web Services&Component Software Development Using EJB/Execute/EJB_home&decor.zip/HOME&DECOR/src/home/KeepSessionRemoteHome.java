package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface KeepSessionRemoteHome extends javax.ejb.EJBHome {
  public KeepSessionRemote create(Integer bucid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Collection findbucidByPM(Integer m, Integer p) throws FinderException, RemoteException;
  public KeepSessionRemote findByPrimaryKey(Integer bucid) throws FinderException, RemoteException;
}