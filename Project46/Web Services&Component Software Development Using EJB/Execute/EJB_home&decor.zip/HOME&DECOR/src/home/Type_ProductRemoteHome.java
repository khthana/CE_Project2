package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_ProductRemoteHome extends javax.ejb.EJBHome {
  public Type_ProductRemote create(Integer tpid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Collection findTypeSection(Integer section) throws FinderException, RemoteException;
  public Type_ProductRemote findByPrimaryKey(Integer tpid) throws FinderException, RemoteException;
}