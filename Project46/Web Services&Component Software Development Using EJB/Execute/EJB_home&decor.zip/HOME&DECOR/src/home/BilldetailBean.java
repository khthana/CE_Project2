package home;import javax.ejb.*;

abstract public class BilldetailBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer bdid) throws CreateException {
    setBdid(bdid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer bdid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setBdid(java.lang.Integer bdid);
  public abstract void setBid(java.lang.Integer bid);
  public abstract void setLine(java.lang.Integer line);
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setNumber(java.lang.Integer number);
  public abstract void setSalesperunit(java.lang.Float salesperunit);
  public abstract java.lang.Integer getBdid();
  public abstract java.lang.Integer getBid();
  public abstract java.lang.Integer getLine();
  public abstract java.lang.Integer getPid();
  public abstract java.lang.Integer getNumber();
  public abstract java.lang.Float getSalesperunit();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}

