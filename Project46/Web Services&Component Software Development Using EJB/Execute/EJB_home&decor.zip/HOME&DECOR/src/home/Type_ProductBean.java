package home;

import javax.ejb.*;

abstract public class Type_ProductBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer tpid) throws CreateException {
    setTpid(tpid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer tpid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTpid(java.lang.Integer tpid);
  public abstract void setTsid(java.lang.Integer tsid);
  public abstract void setTypeproductname(java.lang.String typeproductname);
  public abstract java.lang.Integer getTpid();
  public abstract java.lang.Integer getTsid();
  public abstract java.lang.String getTypeproductname();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}