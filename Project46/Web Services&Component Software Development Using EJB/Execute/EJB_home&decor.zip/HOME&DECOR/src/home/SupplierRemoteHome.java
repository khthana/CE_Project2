package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface SupplierRemoteHome extends javax.ejb.EJBHome {
  public SupplierRemote create(Integer sid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public SupplierRemote findByPrimaryKey(Integer sid) throws FinderException, RemoteException;
}