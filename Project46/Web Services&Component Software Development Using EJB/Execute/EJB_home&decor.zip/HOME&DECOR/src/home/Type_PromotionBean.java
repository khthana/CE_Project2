package home;

import javax.ejb.*;

abstract public class Type_PromotionBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer tprid) throws CreateException {
    setTprid(tprid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer tprid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTprid(java.lang.Integer tprid);
  public abstract void setName(java.lang.String name);
  public abstract java.lang.Integer getTprid();
  public abstract java.lang.String getName();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}