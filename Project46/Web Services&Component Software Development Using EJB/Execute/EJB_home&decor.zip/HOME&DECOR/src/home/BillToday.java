package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class BillToday extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>Tips</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    ///////////////////////////////////////////////////////

    out.println("<h1><p>Bill Today</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>BillNumber</td>");
    out.println("<td bgcolor='#66CC99'>CustomerID</td>");
    out.println("<td bgcolor='#66CC99'>AMID</td>");
    out.println("<td bgcolor='#66CC99'>DateBuy</td>");
    out.println("<td bgcolor='#66CC99'>DateDeliver</td>");
    out.println("<td bgcolor='#66CC99'>costDeliver</td>");
    out.println("<td bgcolor='#66CC99'>SumPrices</td></tr>");

    try
    {
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("BillRemote");
      Object obj2 = jndiContext.lookup("StringTools");

      BillRemoteHome home = (BillRemoteHome)
          PortableRemoteObject.narrow(obj, BillRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);


      // Update //////////////////////////////////////////////
      if (request.getParameter("Delete") != null && request.getParameter("bid") != null)
      {
        BillRemote bill = home.findByPrimaryKey(new Integer(request.getParameter("bid")));
        bill.remove();
      }
      // Update //////////////////////////////////////////////

      Collection c = home.findSelectall();
      Object[] b = c.toArray();
      StringTools st = sTools.create();

      for (int j = 0; j < c.size(); j++) {
        // BillRemote bill = home.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
		BillRemote bill = (BillRemote)b[j];
        out.println("<tr>");
        out.println("<td><a href='../StockWAR/billid?billid=" +
                      bill.getBid() +
                      "'>" + bill.getBid() + "</a></td>");
        out.println("<td>" + bill.getCid() + "</td>");
        out.println("<td>" + bill.getAmid() + "</td>");
        out.println("<td>" + bill.getDatebuy() + "</td>");
        out.println("<td>" + bill.getDatedeliver() + "</td>");
        out.println("<td>" + bill.getCostDeliver() + "</td>");
        out.println("<td>" + bill.getSumsales() + "</td>");
        out.println("</tr>");

      }
    }

    catch (Throwable t) { t.printStackTrace(); }

    out.println("</table>");

    // Form ////////////////////////////////////////////////////////////////////
    out.print(
        "<form name='form1' method='get' action='../StockWAR/billtoday'>"
        + "<h1>"
        + "<p>Delete Bill</p>"
        + "</h1>"
        + "<table width='600' border='0' cellspacing='0' cellpadding='0'>"

        + "<tr> "
        + "<td width='30%'>Bill ID:</td>"
        + "<td width='70%'><input type='text' name='bid'></td>"
        + "</tr>"

        + "<td><input type='submit' name='Delete' value='Delete'>"
        + "<input type='reset' name='Submit2' value='Reset'>"
        + "</td></tr>"
        + "</table>"
        + "</form>");

    out.println("</br>");


    //////////////////////////////////////////////////////
    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}