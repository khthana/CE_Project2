package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.Timestamp;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Thankyou extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      ///////////////////////////////////////////////////////////////////

      out.print("</strong></font></td>"
                + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "</table></td>"
                + "</tr>"
                + "<tr>"
                + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                + "<tr>"
                + "<td>&nbsp;</td>"
                + "</tr>"
                + "<tr>"
                + "<td><div align='center'>Search : "
                + "<input type='text' name='textfield'>"
                + "<input type='submit' name='Submit' value='GO!'>"
                + "</div></td>"
                + "</tr>"
                + "</table>"
                + "</form>"
                + "</div></td>"
                + "</tr>"
                + "<tr> "
                + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                + "<tr> "
                + "<td width='13%' height='404'>");
      // Thank you  ////////////////////////////////////////////////////////////
      HttpSession session = request.getSession(true);
      SessionCustomer customer =
          (SessionCustomer)session.getValue("SessionCustomer");
      Integer bill = customer.Buy(customer.getName(), customer.getPassword(), "150", request.getParameter("select"));

      /*
      Object objbu = jndiContext.lookup("KeepSessionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      Object objb = jndiContext.lookup("BillRemote");
      Object objbd = jndiContext.lookup("BilldetailRemote");
      Object objid = jndiContext.lookup("UniqueID");
      Object objp = jndiContext.lookup("ProductRemote");


      KeepSessionRemoteHome buhome = (KeepSessionRemoteHome)
          PortableRemoteObject.narrow(objbu, KeepSessionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      BillRemoteHome bhome = (BillRemoteHome)
          PortableRemoteObject.narrow(objb, BillRemoteHome.class);
      BilldetailRemoteHome bdhome = (BilldetailRemoteHome)
          PortableRemoteObject.narrow(objbd, BilldetailRemoteHome.class);
      UniqueIDHome idhome = (UniqueIDHome)
          PortableRemoteObject.narrow(objid, UniqueIDHome.class);
      ProductRemoteHome phome = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);

      UniqueID id = idhome.create();
      StringTools st = sTools.create();
      HttpSession session = request.getSession(true);
      SessionCustomer customer =
          (SessionCustomer)session.getValue("SessionCustomer");

      Collection bc = buhome.findSelectall();
      Object[] bb = bc.toArray();

      BillRemote bill = bhome.create(new Integer(id.getUnique()));
      bill.setAmid(new Integer(request.getParameter("select")));
      bill.setCid(customer.getID());
      bill.setCostDeliver(new Float(request.getParameter("select3")));
      bill.setDatebuy(new Timestamp(2003,11,17,9,30,00,0));
      bill.setDatedeliver(new Timestamp(2003,11,17,9,30,00,0));
      bill.setSumsales(new Float(1000));

      // Keep to Database //////////////////////////////////////////////////////
      // OutPut print //////////////////////////////////////////////////////////
      KeepSessionRemote b;
      BilldetailRemote billdetail;
      int countorder=0;
      for (int i =0;i<bc.size();i++) {
        // b = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bb[i].toString())));
		b = (KeepSessionRemote)bb[i];
        ProductRemote product = phome.findByPrimaryKey(b.getPid());
        if (b.getMid().equals(customer.getID())) {
          countorder++;
          billdetail = bdhome.create(new Integer(id.getUnique()));
          billdetail.setBid(bill.getBid());
          billdetail.setNumber(b.getNumber());
          billdetail.setLine(new Integer(countorder));
          billdetail.setPid(b.getPid());
          billdetail.setSalesperunit(product.getSaleavg());
          b.remove();
        }
      }
      */

      if (bill.equals(Integer.valueOf("0")))
          out.println("<center><font color='#006699' size='5'>no Stock</font></center>");
        else {
          out.println("<center><font color='#006699' size='5'>Thank you</font>");
          // OutPut ////////////////////////////////////////////////////////////////
          out.println("<br><a href='../StockWAR/billid?billid=" +
                      bill.toString() +
                      "'><font color='#666666' size='3'>View Bill</font></a></center>");
      }
      out.println("<br><br><DIV class=footer>"
                  + "<div align='center'>&copy;2003 Home&amp;Decor - Searching 2 web pages<br></div>"
                  + "</DIV>"
                  + "</p>");

      // Thank you  ////////////////////////////////////////////////////////////
      out.println("<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "</div>"
                  + "<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                  + "<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                  + "Home&amp;Decor.com Privacy Policy </p>"
                  + "<p align='center'>Powered by HomeServices Inc.</p>"
                  + "<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                  + "<p>&nbsp;</p>"
                  + "</body>"
                  + "</html>");
    }
    catch (Throwable t) { t.printStackTrace(); }
  }
  //Clean up resources
  public void destroy() {
  }
}