package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_PromotionRemoteHome extends javax.ejb.EJBHome {
  public Type_PromotionRemote create(Integer tprid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Type_PromotionRemote findByPrimaryKey(Integer tprid) throws FinderException, RemoteException;
}