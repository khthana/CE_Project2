package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PromotiontproductRemoteHome extends javax.ejb.EJBHome {
  public PromotiontproductRemote create(Integer ptpid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public PromotiontproductRemote findByPrimaryKey(Integer ptpid) throws FinderException, RemoteException;
}