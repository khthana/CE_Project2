package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

public class LeftFrame extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Menu Stock</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("<center><h1><p>Menu Stock</p></h1></center>");
    out.println("<br><a href='../StockWAR/addproduct' target='mainFrame'>Add NewProduct</a>");
    out.println("<br><a href='../StockWAR/addadmin' target='mainFrame'>Add Type&Other</a>");
    out.println("<br><a href='../StockWAR/stockproduct'  target='mainFrame'>Supply</a>");
    out.println("<br><a href='../StockWAR/promotionadmin' target='mainFrame'>Promotion</a>");
    out.println("<br><a href='../StockWAR/tips' target='mainFrame'>Add Tip&Trick</a>");
    out.println("<br><a href='../StockWAR/billtoday' target='mainFrame'>View Order</a>");
    out.println("<br></body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
