package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface PromotiontproductRemote extends javax.ejb.EJBObject {
  public Integer getPtpid() throws RemoteException;
  public void setPercentsale(Integer percentsale) throws RemoteException;
  public Integer getPercentsale() throws RemoteException;
  public void setStart(Timestamp start) throws RemoteException;
  public Timestamp getStart() throws RemoteException;
  public void setStop(Timestamp stop) throws RemoteException;
  public Timestamp getStop() throws RemoteException;
  public void setTprid(Integer tprid) throws RemoteException;
  public Integer getTprid() throws RemoteException;
  public void setTpid(Integer tpid) throws RemoteException;
  public Integer getTpid() throws RemoteException;
}