package home;

import javax.ejb.*;

abstract public class PromotiontproductBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer ptpid) throws CreateException {
    setPtpid(ptpid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer ptpid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPtpid(java.lang.Integer ptpid);
  public abstract void setPercentsale(java.lang.Integer percentsale);
  public abstract void setStart(java.sql.Timestamp start);
  public abstract void setStop(java.sql.Timestamp stop);
  public abstract void setTprid(java.lang.Integer tprid);
  public abstract void setTpid(java.lang.Integer tpid);
  public abstract java.lang.Integer getPtpid();
  public abstract java.lang.Integer getPercentsale();
  public abstract java.sql.Timestamp getStart();
  public abstract java.sql.Timestamp getStop();
  public abstract java.lang.Integer getTprid();
  public abstract java.lang.Integer getTpid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}