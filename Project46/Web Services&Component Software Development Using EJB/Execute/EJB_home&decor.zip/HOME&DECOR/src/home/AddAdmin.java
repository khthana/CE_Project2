package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

public class AddAdmin extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>AddAdmin</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    //////////////////////////////////////////

    out.println("<center><h1><p>Menu Stock</p></h1></center>");
    out.println("<br><a href='../StockWAR/addunit' >Add New Type_Unit of Product </a>");
    out.println("<br><a href='../StockWAR/addtype' >Add Type Product </a>");
    //out.println("<br><a href='../StockWAR/addtypesection' >Add Product Type Section</a>");
    //out.println("<br><a href='../StockWAR/addbrand'  > Add Product Brand </a>");
    //out.println("<br><a href='../StockWAR/addpromotionadmin' >Add Promotion Type </a>");

    //out.println("<br><a href='../StockWAR/tips' target='mainFrame'>Add Tip&Trick</a>");


    out.println("<br></br>");
    out.println("<br></br>");
    out.println("<br></br>");
    out.println("<br></br>");
    out.println("<br></br>");
    //out.println("<br><a href='../StockWAR/addadmin' >Back</a>");

    //////////////////////////////////////////

    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}