package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface PromotionsectionRemote extends javax.ejb.EJBObject {
  public Integer getPsid() throws RemoteException;
  public void setPercentsale(Integer percentsale) throws RemoteException;
  public Integer getPercentsale() throws RemoteException;
  public void setStart(Timestamp start) throws RemoteException;
  public Timestamp getStart() throws RemoteException;
  public void setStop(Timestamp stop) throws RemoteException;
  public Timestamp getStop() throws RemoteException;
  public void setTprid(Integer tprid) throws RemoteException;
  public Integer getTprid() throws RemoteException;
  public void setTsid(Integer tsid) throws RemoteException;
  public Integer getTsid() throws RemoteException;
}