package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class basket extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                + "<html>"
                + "<head>"
                +
        "<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                + "</head>"
                + "<body leftmargin='0'>"
                + "<div align='center'></div>"
                + "<div align='center'></div>"
                + "<div align='center'>"
                +
        "<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                + "<tr>"
                + "<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                + "<tr>"
                +
        "<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                + "</tr>"
                + "<tr>"
                + "<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                + "<tr>"
                +
        "<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
    }
    catch (Throwable t) {
      t.printStackTrace();
    }
    ///////////////////////////////////////////////////////////////////

    out.print("</strong></font></td>"
              + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "<tr>"
              + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
              +
        "<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
              + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
              + "<tr>"
              + "<td>&nbsp;</td>"
              + "</tr>"
              + "<tr>"
              + "<td><div align='center'>Search : "
              + "<input type='text' name='textfield'>"
              + "<input type='submit' name='Submit' value='GO!'>"
              + "</div></td>"
              + "</tr>"
              + "</table>"
              + "</form>"
              + "</div></td>"
              + "</tr>"
              + "<tr> "
              + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
              + "<tr> "
              + "<td width='13%' height='404'>");
    // Table Basket ////////////////////////////////////////////////////////////
    HttpSession session = request.getSession(true);
    SessionCustomer customer =
          (SessionCustomer)session.getValue("SessionCustomer");              // Create Session Variable
    if (!customer.getID().equals(new Integer(0)))
    {
      out.println(
          "<br><center><form name='form1' method='get' action='../SalesWAR/basket'>"
          +
          "<font  size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>"
          + "<p><font color='#006699' size='5'>Shopping Basket</font></p>"
          + "</font> "
          + "<table width='700' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr> "
          + "<div align='center'> "
          + "<td width='49' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>Del</font></td>"
          + "<td width='55' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>Order</font></td>"
          + "<td width='121' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>CodeProduct</font></td>"
          + "<td width='255' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>ProductName</font></td>"
          + "<td width='68' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>number</font></td>"
          + "<td width='100' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>Price/unit</font></td>"
          + "<td width='52' bgcolor='#006699'><font color='#FFFFFF' size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>Price</font></td>"
          + "</div>"
          + "</tr>");
      // List //////////////////////////////////////
      float sumall = 0;
      try {
        Context jndiContext = new InitialContext();
        Object objbu = jndiContext.lookup("KeepSessionRemote");
        Object obj2 = jndiContext.lookup("StringTools");
        Object obj = jndiContext.lookup("ProductRemote");
        Object objpromotion = jndiContext.lookup("Promotion");
        // Create RemoteHome ///////////////////////////////
        KeepSessionRemoteHome buhome = (KeepSessionRemoteHome)
            PortableRemoteObject.narrow(objbu, KeepSessionRemoteHome.class);
        StringToolsHome sTools = (StringToolsHome)
            PortableRemoteObject.narrow(obj2, StringToolsHome.class);
        ProductRemoteHome home = (ProductRemoteHome)
            PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
        PromotionHome homepromotion = (PromotionHome)
          PortableRemoteObject.narrow(objpromotion, PromotionHome.class);
        Promotion promotion = homepromotion.create();
        ////////////////////////////////////////////////////
        StringTools st = sTools.create();

        KeepSessionRemote b;
        KeepSessionRemote b2, b3;
        ProductRemote p;

        ////////////////////////////////////////////////////
        // Add to Basket ///////////////////////////////////
        String add = request.getParameter("addproduct");
        if (add != null && customer != null) {
          Object objid = jndiContext.lookup("UniqueID");
          UniqueIDHome idhome = (UniqueIDHome)
              PortableRemoteObject.narrow(objid, UniqueIDHome.class);
          UniqueID id = idhome.create();
          b = buhome.create(new Integer(id.getUnique()));
          b.setMid(customer.getID());
          b.setPid(new Integer(add));
          b.setNumber(new Integer(1));
          // Delete repeat Product , Member ////////////////////////////////////
          Collection buc = buhome.findbucidByPM(customer.getID(), b.getPid());
          Object[] bub = buc.toArray();
          if (buc.size() > 1) {
            // b2 = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bub[0].toString())));
            b2 = (KeepSessionRemote) bub[0];
            // b3 = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bub[1].toString())));
            b3 = (KeepSessionRemote) bub[1];
            b2.setNumber(new Integer(b2.getNumber().intValue() +
                                     b3.getNumber().intValue()));
            b3.remove();
          }
        }

        // Delete Refresh and Show List Basket ////////////////////////////////
        Collection bc = buhome.findSelectall();
        Object[] bb = bc.toArray();

        // Delete and Refresh //////////////////////////////
        String mode = request.getParameter("Submit");
        if (mode != null)
          if (mode.equals("RefreshDelete")) {
            for (int i = 0; i < bc.size(); i++) {
              b = (KeepSessionRemote) bb[i];
              // Delete ////////////////////////////////////////////
              String cb = request.getParameter("cb" + b.getBucid());
              if (cb != null) {
                if (cb.equals("checkbox"))
                  b.remove();
                else {
                  // Update ////////////////////////////////////////////
                  String nb = request.getParameter("nb" + b.getBucid());
                  if (nb != null)
                    b.setNumber(new Integer(nb));
                }

              }
              else {
                // Update ////////////////////////////////////////////
                String nb = request.getParameter("nb" + b.getBucid());
                if (nb != null)
                  b.setNumber(new Integer(nb));
              }

            }
          }

        // Show List Basket ////////////////////////////////
        int countorder = 0;
        for (int i = 0; i < bc.size(); i++) {
          // b = buhome.findByPrimaryKey(new Integer(st.cutEachColon(bb[i].toString())));
          b = (KeepSessionRemote) bb[i];
          if (b.getMid().equals(customer.getID())) {
            p = home.findByPrimaryKey(b.getPid());
            //float sum = p.getSaleavg().floatValue() * b.getNumber().floatValue();
            float sum = promotion.PriceProduct(p.getPid()) * b.getNumber().floatValue();
            countorder++;
            out.println("<tr> "
                        //+ "<td>" + b.getBucid() + "</td>"
                        + "<td>"
                        + "<input name=cb" + b.getBucid() +
                        " type='checkbox' value='checkbox'>"
                        + "</td>"

                        + "<td>" + countorder + "</td>"
                        + "<td>" + b.getPid() + "</td>"
                        + "<td>" + p.getName() + "</td>"

                        + "<td>"
                        + "<input name=nb" + b.getBucid() +
                        " type='text' value="
                        + b.getNumber() + " size='6'>"
                        + "</td>"

                        //+ "<td><div align='right'>" + p.getSaleavg()
                        + "<td><div align='right'>" + promotion.PriceProduct(p.getPid())
                        + "</div></td>"
                        + "<td><div align='right'>" + sum + "</div></td>"
                        + "</tr>");
            sumall += sum;
          }
        }

      }
      catch (Throwable t) {
        t.printStackTrace();
      }
      // List //////////////////////////////////////
      out.println("</table>"
                  +
          "<table width='700' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr> "
          + "<td width='501' bgcolor='D6E7EF'>Sumary Price (Vat):</td>"
          + "<td width='199' bgcolor='D6E7EF'><div align='right'>"
          + sumall
          + "</div></td></tr>"
          + "</table>"
          + "<p>&nbsp;</p>"
          +
          "<table width='700' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr> "
          + "<td width='288'><input type='submit' name='Submit' value='RefreshDelete'></td></form>"
          + "<form name='form2' method='get' action='../SalesWAR/payment'><td width='239'><div align='right'>"
          + "<input type='submit' name='Submit2' value='Payment'>"
          + "</div></td></form>"
          + "<form name='form3' method='get' action='../SalesWAR/indexsales'><td width='585'><div align='right'>"
          + "<input name='Submit3' type='submit' value='AddProduct'>"
          + "</div></td></form>"
          + "</tr>"
          + "</table>"
          + "<p align='left'>&nbsp; </p>"
          + "<p align='left'>&nbsp; </p>"
          + "<p>&nbsp;</p>"
          + "</center>");
    } else {
      out.println("<center><font color='#006699' size='5'>");
      out.print("Please Login...");
      out.println("<br><a href='../SalesWAR/indexsales'>Back</a>");
      out.println("</font></center>");
    }
    // Table Basket ////////////////////////////////////////////////////////////
    out.println("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div>"
                +"<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                +"Home&amp;Decor.com Privacy Policy </p>"
                +"<p align='center'>Powered by HomeServices Inc.</p>"
                +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                +"<p>&nbsp;</p>"
                +"</body>"
                +"</html>");
  }
  //Clean up resources
  public void destroy() {
  }
}