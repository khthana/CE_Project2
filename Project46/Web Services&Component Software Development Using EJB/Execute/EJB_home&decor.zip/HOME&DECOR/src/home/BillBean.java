package home;

import javax.ejb.*;

abstract public class BillBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer bid) throws CreateException {
    setBid(bid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer bid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setBid(java.lang.Integer bid);
  public abstract void setCid(java.lang.Integer cid);
  public abstract void setAmid(java.lang.Integer amid);
  public abstract void setDatebuy(java.sql.Timestamp datebuy);
  public abstract void setDatedeliver(java.sql.Timestamp datedeliver);
  public abstract void setCostDeliver(java.lang.Float costDeliver);
  public abstract void setSumsales(java.lang.Float sumsales);
  public abstract java.lang.Integer getBid();
  public abstract java.lang.Integer getCid();
  public abstract java.lang.Integer getAmid();
  public abstract java.sql.Timestamp getDatebuy();
  public abstract java.sql.Timestamp getDatedeliver();
  public abstract java.lang.Float getCostDeliver();
  public abstract java.lang.Float getSumsales();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}