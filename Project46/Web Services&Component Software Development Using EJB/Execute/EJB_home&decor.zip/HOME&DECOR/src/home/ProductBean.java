package home;

import javax.ejb.*;

abstract public class ProductBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer pid) throws CreateException {
    setPid(pid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer pid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setName(java.lang.String name);
  public abstract void setImageurl(java.lang.String imageurl);
  public abstract void setDescription(java.lang.String description);
  public abstract void setSaleavg(java.lang.Float saleavg);
  public abstract void setBarcode(java.lang.String barcode);
  public abstract void setTpid(java.lang.Integer tpid);
  public abstract void setTuid(java.lang.Integer tuid);
  public abstract void setTsid(java.lang.Integer tsid);
  public abstract void setBid(java.lang.Integer bid);
  public abstract java.lang.Integer getPid();
  public abstract java.lang.String getName();
  public abstract java.lang.String getImageurl();
  public abstract java.lang.String getDescription();
  public abstract java.lang.Float getSaleavg();
  public abstract java.lang.String getBarcode();
  public abstract java.lang.Integer getTpid();
  public abstract java.lang.Integer getTuid();
  public abstract java.lang.Integer getTsid();
  public abstract java.lang.Integer getBid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}