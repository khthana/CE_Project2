package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class StockProduct extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>Stock Product</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    ///////////////////////////////////////////////////////

    out.println("<h1><p>Stock Product</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>ID</td>");
    out.println("<td bgcolor='#66CC99'>Plid</td>");
    out.println("<td bgcolor='#66CC99'>Pid</td>");
    out.println("<td bgcolor='#66CC99'>Remain</td>");
    out.println("<td bgcolor='#66CC99'>Limit Buy</td></tr>");

    try
    {
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("ProductplaceRemote");
      //Object obj2 = jndiContext.lookup("StringTools");

      ProductplaceRemoteHome home = (ProductplaceRemoteHome)
          PortableRemoteObject.narrow(obj, ProductplaceRemoteHome.class);
      //StringToolsHome sTools = (StringToolsHome)
      //    PortableRemoteObject.narrow(obj2, StringToolsHome.class);

     // StringTools st = sTools.create();

      // 1.Update //////////////////////////////////////////////
      if (request.getParameter("Mode") != null)
      {
        if (request.getParameter("Mode").equals("Insert") && request.getParameter("t1") != null) {
          ProductplaceRemote tt = home.create(new Integer(request.getParameter("t1")));

          if (request.getParameter("t2") != null) tt.setPlid(new Integer(request.getParameter("t2")));
          if (request.getParameter("t3") != null) tt.setPid(new Integer(request.getParameter("t3")));
          if (request.getParameter("t4") != null) tt.setRemain(new Integer(request.getParameter("t4")));
          if (request.getParameter("t5") != null) tt.setLimitbuy(new Integer(request.getParameter("t5")));

        } else if (request.getParameter("Mode").equals("Update") && request.getParameter("t1") != null) {
          ProductplaceRemote tt = home.findByPrimaryKey(new Integer(request.getParameter("t1")));
          if (request.getParameter("t2") != null) tt.setPlid(new Integer(request.getParameter("t2")));
          if (request.getParameter("t3") != null) tt.setPid(new Integer(request.getParameter("t3")));
          if (request.getParameter("t4") != null) tt.setRemain(new Integer(request.getParameter("t4")));
          if (request.getParameter("t5") != null) tt.setLimitbuy(new Integer(request.getParameter("t5")));

        } else if (request.getParameter("Mode").equals("Delete") && request.getParameter("t1") != null) {
          ProductplaceRemote tt = home.findByPrimaryKey(new Integer(request.getParameter("t1")));
          tt.remove();
        }
      }
      // 2.Display //////////////////////////////////////////////

      Collection c = home.findSelectall();
      Object[] b = c.toArray();

      for (int j = 0; j < c.size(); j++) {

        ProductplaceRemote tt = (ProductplaceRemote) b[j];
        out.println("<tr>");
        out.println("<td>" + tt.getPpid() + "</td>");
        out.println("<td>" + tt.getPlid() + "</td>");
        out.println("<td>" + tt.getPid() + "</td>");
        out.println("<td>" + tt.getRemain() + "</td>");
        out.println("<td>" + tt.getLimitbuy() + "</td>");
        out.println("</tr>");

      }
    }

    catch (Throwable t) { t.printStackTrace(); }

    out.println("</table>");

    // 3.Form ////////////////////////////////////////////////////////////////////
    out.print(
        "<form name='form1' method='get' action='../StockWAR/stockproduct'>"
        + "<h1>"
        + "<p>Add&Edit Tip</p>"
        + "</h1>"
        + "<table width='600' border='0' cellspacing='0' cellpadding='0'>"

        // 1
        + "<tr> "
        + "<td width='30%'>Stock ID:</td>"
        + "<td width='70%'><input type='text' name='t1'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Place ID:</td>"
        + "<td width='70%'><input type='text' name='t2'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Product ID:</td>"
        + "<td width='70%'><input type='text' name='t3'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Remain:</td>"
        + "<td width='70%'><input type='text' name='t4'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Limit Buy:</td>"
        + "<td width='70%'><input type='text' name='t5'></td>"
        + "</tr>"


        + "<td>"
        + "<input type='submit' name='Mode' value='Insert'>"
        + "<input type='submit' name='Mode' value='Update'>"
        + "<input type='submit' name='Mode' value='Delete'>"
        + "<input type='reset' name='Submit2' value='Reset'>"
        + "</td></tr>"
        + "</table>"
        + "</form>");

    out.println("</br>");


    //////////////////////////////////////////////////////
    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
