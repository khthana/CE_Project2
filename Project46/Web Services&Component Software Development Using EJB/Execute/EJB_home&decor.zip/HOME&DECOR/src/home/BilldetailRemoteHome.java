package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BilldetailRemoteHome extends javax.ejb.EJBHome {
  public BilldetailRemote create(Integer bdid) throws CreateException, RemoteException;
  public Collection findBilldetailByID(Integer bill) throws FinderException, RemoteException;
  public BilldetailRemote findByPrimaryKey(Integer bdid) throws FinderException, RemoteException;
}