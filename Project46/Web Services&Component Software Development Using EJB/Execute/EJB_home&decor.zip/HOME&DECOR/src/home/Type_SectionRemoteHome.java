package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_SectionRemoteHome extends javax.ejb.EJBHome {
  public Type_SectionRemote create(Integer tsid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public Type_SectionRemote findByPrimaryKey(Integer tsid) throws FinderException, RemoteException;
}