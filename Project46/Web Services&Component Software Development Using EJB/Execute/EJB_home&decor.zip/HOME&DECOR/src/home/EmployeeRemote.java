package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EmployeeRemote extends javax.ejb.EJBObject {
  public Integer getEid() throws RemoteException;
  public void setName(String name) throws RemoteException;
  public String getName() throws RemoteException;
  public void setSurname(String surname) throws RemoteException;
  public String getSurname() throws RemoteException;
  public void setPassword(String password) throws RemoteException;
  public String getPassword() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getAddress() throws RemoteException;
  public void setTel(Integer tel) throws RemoteException;
  public Integer getTel() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
  public String getTypePosition() throws RemoteException;
}