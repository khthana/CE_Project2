package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class IndexProduct extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  SessionCustomer sessioncustomer;
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'> "
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);

    }
    catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////////////////////////////
    out.println("</strong></font></td>"
                +"<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                +"<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                +"<tr>"
                +"<td>&nbsp;</td>"
                +"</tr>"
                +"<tr>"
                +"<td><div align='center'>&#3588;&#3657;&#3609;&#3627;&#3634; : "
                +"<input type='text' name='textfield'>"
                +"<input type='submit' name='Submit' value='GO!'>"
                +"</div></td>"
                +"</tr>"
                +"</table>"
                +"</form>"
                +"</div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td width='13%' height='404'>");
    // login ////////////////////////////////////////////////////
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("SessionCustomer");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionCustomerHome chome = (SessionCustomerHome)
          PortableRemoteObject.narrow(objc, SessionCustomerHome.class);
      ////////////////////////////////////////////////////
      SessionCustomer c = chome.create();
      c.login(request, out);

    }
    catch (Throwable t) { t.printStackTrace(); }
    /////////////////////////////////////////////////////////////
    out.println("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p></td>"
                +"<td width='57%'> <div align='center'> "
                +"<p>&nbsp;</p>");

    // Print Product /////////////////////////////////
    product(request, out);
    // Print Product /////////////////////////////////
    out.println("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div>"
                +"<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                +"Home&amp;Decor.com Privacy Policy </p>"
                +"<p align='center'>Powered by HomeServices Inc.</p>"
                +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                +"<p>&nbsp;</p>"
                +"</body>"
                +"</html>");
  }
  public void login(HttpServletRequest request, PrintWriter out) {
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsession = jndiContext.lookup("SessionCustomer");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionCustomerHome chome = (SessionCustomerHome)
          PortableRemoteObject.narrow(objsession, SessionCustomerHome.class);

      // Check login /////////////////////////////////////
      Object obj = jndiContext.lookup("CustomerRemote");
      CustomerRemoteHome home = (CustomerRemoteHome)
          PortableRemoteObject.narrow(obj, CustomerRemoteHome.class);
      String user = request.getParameter("usertextfield");
      String password = request.getParameter("passwordtextfield");
      // Check login /////////////////////////////////////
      HttpSession session = request.getSession(true);
      sessioncustomer =
          (SessionCustomer)session.getValue("SessionCustomer");              // Create Session Variable
      if (sessioncustomer == null) {
        sessioncustomer = chome.create();
        session.putValue("SessionCustomer", sessioncustomer);                // put Session

        out.print("<table width='182' height='0%' border='0' cellpadding='0' cellspacing='0' bordercolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='244' height='62%' bgcolor='#FFFFFF'><img src='../jmx-console/images/signin-bar.jpg' width='182' height='36'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td height='50' background='../jmx-console/images/MenubarMiddle.jpg'><div align='center'>"
                  + "<form name='form2' method='get' action='../SalesWAR/logincustomer'>"
                  + "<table width='19%' border='0' cellpadding='1' cellspacing='0' bgcolor='#FFFFFF'>"
                  + "<tr>"
                  + "<td width='35%' nowrap bgcolor='#f1f3f0'><font size='-1'>"
                  + "User name</font></td>"
                  + "<td width='65%' bgcolor='#f1f3f0'><input name='usertextfield' type='text' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td nowrap bgcolor='#f1f3f0'><font size='-1'> Passward</font></td>"
                  + "<td bgcolor='#f1f3f0'> <input name='passwordtextfield' type='text' size='10'></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td bgcolor='#f1f3f0'><input type='submit' name='Submit2' value='Submit'>"
                  + "</td>"
                  + "<td bgcolor='#f1f3f0'><input name='Reset2' type='reset' id='Reset22' value='Reset'></td>"
                  + "</tr>"
                  + "</table></form>"
                  +"</div></td>"
                  +"</tr>"
                  +"<tr> "
                  +"<td height='7' bgcolor='#FFFFFF'> <div align='center'><img src='../jmx-console/images/MenubarBottom.jpg' width='182' height='7'></div></td>"
                  +"</tr>"
                  +"</table>");

      } else {
        if (sessioncustomer.getName().equals("no"))
          out.print("<table width='182' height='0%' border='0' cellpadding='0' cellspacing='0' bordercolor='#FFFFFF'>"
                    +"<tr> "
                    +"<td width='244' height='62%' bgcolor='#FFFFFF'><img src='../jmx-console/images/welcome-bar.jpg' width='182' height='36'></td>"
                    +"</tr>"
                    +"<tr> "
                    +"<td height='50' background='../jmx-console/images/MenubarMiddle.jpg'><div align='center'> "
                    +"<table width='60' height='57' border='0' cellpadding='1' cellspacing='0' bgcolor='#FFFFFF'>"
                    +"<tr>"
                    +"<td width='35%' nowrap bgcolor='#f1f3f0'><font size='-1'>Welcome </font></td>"
                    +"<td width='35%' nowrap bgcolor='#f1f3f0'><div align='center'><font size='-1'> "
                    +sessioncustomer.getID()+"</font></div></td>"
                    +"</tr>"
                    +"<tr>"
                    +"<td nowrap bgcolor='#f1f3f0'><a href='viewbasket.html'>basket</a></td>"
                    +"<td nowrap bgcolor='#f1f3f0'><div align='left'><font size='-1'><a href='signout.html'>Sign "
                    +"out</a> </font></div></td>"
                    +"</tr>"
                    +"</table>"
                    +"</div></td>"
                    +"</tr>"
                    +"<tr> "
                    +"<td height='7' bgcolor='#FFFFFF'> <div align='center'><img src='../jmx-console/images/MenubarBottom.jpg' width='182' height='7'></div></td>"
                    +"</tr>"
                    +"</table>");
      }

    }
    catch (Throwable t) { t.printStackTrace(); }

  }
  void product(HttpServletRequest request, PrintWriter out) {
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objp = jndiContext.lookup("ProductRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      Object objpromotion = jndiContext.lookup("Promotion");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      ProductRemoteHome phome = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);
      ProductRemote p = phome.findByPrimaryKey(new Integer(request.getParameter("product")));
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      PromotionHome homepromotion = (PromotionHome)
          PortableRemoteObject.narrow(objpromotion, PromotionHome.class);
      Promotion promotion = homepromotion.create();
      // Print /////////////////////////////////////////////////////////////////
      StringTools st = sTools.create();
      out.print(
          "<table width='350' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr>"
          + "<td><table width='350' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr>"
          + "<td width='148'> <div align='left'>"
          + "<FONT face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a size=3><b>"
          + p.getName()+"</b><br><br>"
          + "</FONT>"
          + "</div></td>"
          + "</tr>"
          + "</table></td>"
          + "</tr>"
          + "<tr>"
          + "<td><table width='350' border='0' cellspacing='0' cellpadding='0'>"
          + "<tr>"
          + "<td width='174'><div align='left'>"
          + p.getImageurl()+"</div></td>"
          + "<td width='176'><div align='left'><br>"
          + "<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>"
          + "<B>CodeProduct: </B>"+p.getPid()+"<br>"
          + "<B>Brand: </B>"+p.getBid()+"<br><br>"
          + "<FONT color=red face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>"
          //+ "<B>Sales: </B>"+p.getSaleavg()+" Bath<br>"
          + "<B>Sales: </B>"+promotion.PriceProduct(p.getPid())+" Bath<br>"
          + "</FONT>"
          + "</FONT>"
          + "<a href='../SalesWAR/basket?addproduct="+p.getPid()+"'>"
          + "<img src='../jmx-console/images/th_add.gif' border='0'>"
          + "</a>"
          + "</div></td>"
          + "</tr>"
          + "</table></td>"
          + "</tr>"
          + "<tr>"
          + "<td>"
          + "<FONT color=#4a0d75 face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>"
          + "<br><B>Description: </B>");
      // PrintDescription //////////////////////////////////////////////////
      out.print(st.addSymbol(p.getDescription())
                + "<br><a href='../SalesWAR/basket?addproduct="+p.getPid()+"'>"
                + "<img src='../jmx-console/images/th_add.gif' border='0'>"
                + "</a>");
      // PrintDescription //////////////////////////////////////////////////
      out.print("</td>"
                + "</FONT>"
                + "</tr>"
                + "</table>");
      // Print /////////////////////////////////////////////////////////////////
    } catch (Throwable t) { t.printStackTrace(); }
  }
  //Clean up resources
  public void destroy() {
  }
}