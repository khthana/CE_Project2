package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface ProductplaceRemoteHome extends javax.ejb.EJBHome {
  public ProductplaceRemote create(Integer ppid) throws CreateException, RemoteException;
  public ProductplaceRemote findPid(Integer pid) throws FinderException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public ProductplaceRemote findByPrimaryKey(Integer ppid) throws FinderException, RemoteException;
}