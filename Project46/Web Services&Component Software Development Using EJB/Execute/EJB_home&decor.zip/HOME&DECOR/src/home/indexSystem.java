package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class indexSystem extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>Admin System</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    ///////////////////////////////////////////////////////

    out.println("<h1><p>Admin System</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>ID</td>");
    out.println("<td bgcolor='#66CC99'>Name</td>");
    out.println("<td bgcolor='#66CC99'>Surname</td>");
    out.println("<td bgcolor='#66CC99'>Password</td>");
    out.println("<td bgcolor='#66CC99'>Address</td>");
    out.println("<td bgcolor='#66CC99'>Tel</td>");
    out.println("<td bgcolor='#66CC99'>Email</td>");
    out.println("<td bgcolor='#66CC99'>Permission</td></tr>");

    try
    {
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("EmployeeRemote");
      //Object obj2 = jndiContext.lookup("StringTools");

      EmployeeRemoteHome home = (EmployeeRemoteHome)
          PortableRemoteObject.narrow(obj, EmployeeRemoteHome.class);
      //StringToolsHome sTools = (StringToolsHome)
      //    PortableRemoteObject.narrow(obj2, StringToolsHome.class);

     // StringTools st = sTools.create();

      // 1.Update //////////////////////////////////////////////
      if (request.getParameter("Mode") != null)
      {
        if (request.getParameter("Mode").equals("Insert") && request.getParameter("t1") != null) {
          EmployeeRemote tt = home.create(new Integer(request.getParameter("t1")));

          if (request.getParameter("t2") != null) tt.setName(request.getParameter("t2"));
          if (request.getParameter("t3") != null) tt.setSurname(request.getParameter("t3"));
          if (request.getParameter("t4") != null) tt.setPassword(request.getParameter("t4"));
          if (request.getParameter("t5") != null) tt.setAddress(request.getParameter("t5"));
          if (request.getParameter("t5") != null) tt.setTel(new Integer(request.getParameter("t6")));
          if (request.getParameter("t5") != null) tt.setEmail(request.getParameter("t7"));
          if (request.getParameter("t5") != null) tt.setPid(new Integer(request.getParameter("t8")));

        } else if (request.getParameter("Mode").equals("Update") && request.getParameter("t1") != null) {
          EmployeeRemote tt = home.findByPrimaryKey(new Integer(request.getParameter("t1")));

          if (request.getParameter("t2") != null) tt.setName(request.getParameter("t2"));
          if (request.getParameter("t3") != null) tt.setSurname(request.getParameter("t3"));
          if (request.getParameter("t4") != null) tt.setPassword(request.getParameter("t4"));
          if (request.getParameter("t5") != null) tt.setAddress(request.getParameter("t5"));
          if (request.getParameter("t5") != null) tt.setTel(new Integer(request.getParameter("t6")));
          if (request.getParameter("t5") != null) tt.setEmail(request.getParameter("t7"));
          if (request.getParameter("t5") != null) tt.setPid(new Integer(request.getParameter("t8")));


        } else if (request.getParameter("Mode").equals("Delete") && request.getParameter("t1") != null) {
          EmployeeRemote tt = home.findByPrimaryKey(new Integer(request.getParameter("t1")));
          tt.remove();
        }
      }
      // 2.Display //////////////////////////////////////////////

      Collection c = home.findSelectall();
      Object[] b = c.toArray();

      for (int j = 0; j < c.size(); j++) {

        EmployeeRemote tt = (EmployeeRemote) b[j];
        out.println("<tr>");
        out.println("<td>" + tt.getEid() + "</td>");
        out.println("<td>" + tt.getName() + "</td>");
        out.println("<td>" + tt.getSurname() + "</td>");
        out.println("<td>" + tt.getPassword() + "</td>");
        out.println("<td>" + tt.getAddress() + "</td>");
        out.println("<td>" + tt.getTel() + "</td>");
        out.println("<td>" + tt.getEmail() + "</td>");
        if (tt.getPid().equals(new Integer(2))) out.println("<td>Admin</td>");
          else out.println("<td>Stocker</td>");
        out.println("</tr>");

      }
    }

    catch (Throwable t) { t.printStackTrace(); }

    out.println("</table>");

    // 3.Form ////////////////////////////////////////////////////////////////////
    out.print(
        "<form name='form1' method='get' action='../SystemWAR/indexsystem'>"
        + "<h1>"
        + "<p>Add&Edit Employee</p>"
        + "</h1>"
        + "<table width='600' border='0' cellspacing='0' cellpadding='0'>"

        // 1
        + "<tr> "
        + "<td width='30%'>ID:</td>"
        + "<td width='70%'><input type='text' name='t1'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Name:</td>"
        + "<td width='70%'><input type='text' name='t2'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Surname:</td>"
        + "<td width='70%'><input type='text' name='t3'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Password:</td>"
        + "<td width='70%'><input type='text' name='t4'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Address:</td>"
        + "<td width='70%'><input type='text' name='t5'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Tel:</td>"
        + "<td width='70%'><input type='text' name='t6'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Email:</td>"
        + "<td width='70%'><input type='text' name='t7'></td>"
        + "</tr>"
        + "<tr> "

        + "<td width='30%'>Use:</td>"
        + "<td width='70%'>"
        + "<select name='t8'>"
        + "<option value='2'>Admin</option>"
        + "<option value='1'>Stocker</option>"
        + "</select>"
        + "</td>"
        + "</tr>"

        + "<td>"
        + "<input type='submit' name='Mode' value='Insert'>"
        + "<input type='submit' name='Mode' value='Update'>"
        + "<input type='submit' name='Mode' value='Delete'>"
        + "<input type='reset' name='Submit2' value='Reset'>"
        + "</td></tr>"
        + "</table>"
        + "</form>");

    out.println("</br>");


    //////////////////////////////////////////////////////
    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
