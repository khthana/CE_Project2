package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class indexSales extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"<style>"
                +"<!-- Hide style for old browsers __ THIS STYLE SHOULD BE INSIDE HEAD OF DOCUMENT __"
                +"BODY          {font-family:;font-size='10'}"
                +"A:link    {text-decoration: none; color: #0000FF}"
                +"A:visited {text-decoration: none; color: #4a0d75}"
                +"A:hover   {text-decoration: none; color: #C0C0C0}"
                +"A:active  {text-decoration: none; color: #C0C0C0}"
                +"-->"
                +"</style>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);

    }
    catch (Throwable t) { t.printStackTrace(); }
    ///////////////////////////////////////////////////////////////////
    out.println("</strong></font></td>"
                +"<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='63' bgcolor='D6E7EF'><div align='center'>"
                +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                +"<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                +"<tr>"
                +"<td>&nbsp;</td>"
                +"</tr>"
                +"<tr>"
                +"<td><div align='center'>&#3588;&#3657;&#3609;&#3627;&#3634; :"
                +"<input type='text' name='textfield'>"
                +"<input type='submit' name='Submit' value='GO!'>"
                +"</div></td>"
                +"</tr>"
                +"</table>"
                +"</form>"
                +"</div></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td width='13%' height='404'>");
    // left Side //////////////////////////////////////////////////////////
    // login ////////////////////////////////////////////////////
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("SessionCustomer");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionCustomerHome chome = (SessionCustomerHome)
          PortableRemoteObject.narrow(objc, SessionCustomerHome.class);
      ////////////////////////////////////////////////////
      SessionCustomer c = chome.create();
      c.login(request, out);
      //c.Buy("piti","a","1#3#4#","1#4#2#","1");
    }
    catch (Throwable t) { t.printStackTrace(); }
    /////////////////////////////////////////////////////////////

    // Promotion Left //////////////////////////////////////////////
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("Promotion");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      PromotionHome prhome = (PromotionHome)
          PortableRemoteObject.narrow(objc, PromotionHome.class);
      ////////////////////////////////////////////////////
      Promotion pr = prhome.create();
      //pr.BoxPromotionProduct(out);

    } catch (Throwable t) { t.printStackTrace(); }
    // Tip&Trick ///////////////////////////////////////////////////
    out.print("<p>&nbsp;</p>"
              + "<p>&nbsp;</p>");
    out.print("<table width='190' border='0' cellpadding='0' cellspacing='1' bgcolor='#669999'>"
              +"<tr> "
              +"<td height='10'> <div align='center'> "
                +"<table width='190' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td bgcolor='#669999'><div align='center'>Tip&Trick</div></td>"
                +"</tr>"
                +"</table>"
                +"<table width='190' height='142' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='187' bgcolor='#FFFFFF'><div align='center'> "
                +"<table width='190' height='120' border='0' cellpadding='0' cellspacing='0'>"
                // Data ///////////////////////////
                +"<tr> ");
                //+"<td height='20'><div align='center'><a href='http://www.central.co.th'>"
                //+"<img src='../jmx-console/images/Link/banner_Central.gif' border='0' width='120' height='30'></a></div></td>"
               // +"</tr>"
                // Tip  ////////////////////////////////////////////////////////////
      try {
        // Create Object ///////////////////////////////////
        Context jndiContext = new InitialContext();
        Object obj = jndiContext.lookup("Tip_TrickRemote");
        Object obj2 = jndiContext.lookup("StringTools");

        Tip_TrickRemoteHome home = (Tip_TrickRemoteHome)
            PortableRemoteObject.narrow(obj, Tip_TrickRemoteHome.class);
        StringToolsHome sTools = (StringToolsHome)
            PortableRemoteObject.narrow(obj2, StringToolsHome.class);

        Collection c = home.findSelectall();
        Object[] b = c.toArray();

        int random = Random(c.size());

        Tip_TrickRemote spa = (Tip_TrickRemote)b[random];
        out.println("<center>");
        out.println("<tr>");
        out.println("<td><img src='../jmx-console/images/tipandtrick/" + spa.getImageurl() + "'></td>");
        out.println("</tr>");
        out.println("<tr><td>");
        out.println("<center>");
        out.println("<a href='../SalesWAR/tipandtrick?tip="+spa.getTtid()+"'>");
        out.println("<FONT face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a size=3><b>"
                    + spa.getName() + "</FONT></td></tr>");
        out.println("</a>");
        out.println("</center>");
        out.println("</center>");

      } catch (Throwable t) { t.printStackTrace(); }
      out.print("</tr>");
      // Data ///////////////////////////
      out.print("<tr> "
                +"</table></div></td></tr></table></div></td></tr></table>");
    // Tip&Trick ///////////////////////////////////////////////////

    // Promotion ///////////////////////////////////////////////////

    out.print("<p>&nbsp;</p>"
              +"<p>&nbsp;</p>"
              +"<p>&nbsp;</p>"
              +"<p>&nbsp;</p>"
              +"</td>");
    // Center Side /////////////////////////////////////////////////
    out.print("<td width='57%'> <div align='center'>");
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objc = jndiContext.lookup("Promotion");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      PromotionHome prhome = (PromotionHome)
          PortableRemoteObject.narrow(objc, PromotionHome.class);
      ////////////////////////////////////////////////////
      Promotion pr = prhome.create();
      pr.BoxPromotionIndex(out);

    } catch (Throwable t) { t.printStackTrace(); }
    out.print("</div></td>");
    // Right Side //////////////////////////////////////////////////////////////
    out.print("<td width='30%'><div align='center'>");
      // Promotion Right /////////////////////////////////////////////
      try
      {
        // Create Object ///////////////////////////////////
        Context jndiContext = new InitialContext();
        Object objc = jndiContext.lookup("Promotion");
        ////////////////////////////////////////////////////
        // Create RemoteHome ///////////////////////////////
        PromotionHome prhome = (PromotionHome)
            PortableRemoteObject.narrow(objc, PromotionHome.class);
        ////////////////////////////////////////////////////
        Promotion pr = prhome.create();
        pr.BoxPromotionProduct(out);

      } catch (Throwable t) { t.printStackTrace(); }
      // Promotion ///////////////////////////////////////////////////
      // Tip&Trick ///////////////////////////////////////////////////
      out.print("<p>&nbsp;</p>"
                +"<p>&nbsp;</p>");
      // Link ////////////////////////////////////////////////////////
      out.print("<table width='190' border='0' cellpadding='0' cellspacing='1' bgcolor='#669999'>"
                +"<tr> "
                +"<td height='10'> <div align='center'> "
                +"<table width='190' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td bgcolor='#669999'><div align='center'>&#3621;&#3636;&#3591;&#3588;&#3660;</div></td>"
                +"</tr>"
                +"</table>"
                +"<table width='190' height='142' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='187' bgcolor='#FFFFFF'><div align='center'> "
                +"<table width='190' height='120' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr> "
                +"<td height='20'><div align='center'><a href='http://www.central.co.th'>"
                +"<img src='../jmx-console/images/Link/banner_Central.gif' border='0' width='120' height='30'></a></div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='20'><div align='center'><a href='http://www.col.co.th'>"
                +"<img src='../jmx-console/images/Link/banner_COL.gif' border='0' width='120' height='30'></a></div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='30'><div align='center'><a href='http://www.officedepot.co.th'>"
                +"<img src='../jmx-console/images/Link/banner_OFD.gif' border='0' width='120' height='30'></a></div></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><div align='center'><a href='http://www.supersports.co.th'>"
                +"<img src='../jmx-console/images/Link/banner_SuperSports.gif' border='0' width='120' height='30'></a></div></td>"
                +"</tr>"
                +"<tr> "
                +"<td height='20'><div align='center'><a href='http://www.robinson.co.th'>"
                +"<img src='../jmx-console/images/Link/banner_RBS.gif' border='0' width='120' height='30'></a></div></td>"
                +"</tr></table></div></td></tr></table></div></td></tr></table>"
      // Link ////////////////////////////////////////////////////////
                +"</div></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>");
      // Table Categories //////////////////////////////////////////////////////
      out.print("<table width='902' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td bgcolor='#3399CC'><table width='902' border='0' cellpadding='0' cellspacing='1'>"
                +"<tr>"
                +"<td bogcolor='#336699'><font color='#FFFFFF'><strong>&#3611;&#3619;&#3632;&#3648;&#3616;&#3607;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;</strong></font></td>"
                +"</tr>"
                +"<tr>"
                +"<td bgcolor='#336699'><table width='902' border='0' cellpadding='0' cellspacing='0'>");
      // 1 ROW ///////////////////////////////////////////////////////
      try {
        // Create Object ///////////////////////////////////
        Context jndiContext = new InitialContext();
        Object objts = jndiContext.lookup("Type_SectionRemote");
        Object obj2 = jndiContext.lookup("StringTools");
        Object objtp = jndiContext.lookup("Type_ProductRemote");
        ////////////////////////////////////////////////////
        // Create RemoteHome ///////////////////////////////
        Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
            PortableRemoteObject.narrow(objts, Type_SectionRemoteHome.class);
        StringToolsHome sTools = (StringToolsHome)
            PortableRemoteObject.narrow(obj2, StringToolsHome.class);
        Type_ProductRemoteHome tphome = (Type_ProductRemoteHome)
            PortableRemoteObject.narrow(objtp, Type_ProductRemoteHome.class);
        ////////////////////////////////////////////////////
        Collection cts = tshome.findSelectall();
        Object[] bts = cts.toArray();
        StringTools st = sTools.create();

        for (int j=0;j<cts.size();j+=2) {
          // Type_SectionRemote tsremotel = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j].toString())));
		  Type_SectionRemote tsremotel = (Type_SectionRemote)bts[j];
          // Type_SectionRemote tsremoter = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j+1].toString())));
          Type_SectionRemote tsremoter = (Type_SectionRemote)bts[j+1];

          Collection ctpl = tphome.findTypeSection(tsremotel.getTsid());
          Object[] btpl = ctpl.toArray();
          Collection ctpr = tphome.findTypeSection(tsremoter.getTsid());
          Object[] btpr = ctpr.toArray();

          out.print("<tr>"
                    // Left ////////////////////////////////////////////////////////
                    + "<td width='454' bgcolor='#FFFFFF'><font color='#0000CC'><a href='../SalesWAR/indexsection?section="+tsremotel.getNamesection()+"'>"+tsremotel.getNamesection()+"</a></font><br>"
                    + "<font color='#0000CC'>");
                    for (int k=0;k<ctpl.size();k++) {
                      // Type_ProductRemote tp = tphome.findByPrimaryKey(new Integer(st.cutEachColon(btpl[k].toString())));
					  Type_ProductRemote tp = (Type_ProductRemote)btpl[k];
                      out.print(tp.getTypeproductname());
                      if (k != ctpl.size()-1) out.print(",");
                    }
          out.print("</font></td><td width='454' bgcolor='#FFFFFF'><font color='#0000CC'><a href='../SalesWAR/indexsection?section="+tsremoter.getNamesection()+"'>"+tsremoter.getNamesection()+"</a></font><br>"
                    // Right ///////////////////////////////////////////////////////
                    + "<font color='#0000CC'>");
                    for (int k=0;k<ctpr.size();k++) {
                      // Type_ProductRemote tp = tphome.findByPrimaryKey(new Integer(st.cutEachColon(btpr[k].toString())));
					  Type_ProductRemote tp = (Type_ProductRemote)btpr[k];
                      out.print(tp.getTypeproductname());
                      if (k != ctpr.size()-1) out.print(",");
                    }

          out.print("</font></td></tr>");
          if (j != ctpl.size()-1) out.print("<tr><td bgcolor='#FFFFFF'>&nbsp;</td><td bgcolor='#FFFFFF'>&nbsp;</td></tr>");
        }
      } catch (Throwable t) { t.printStackTrace(); }
      // 1 ROW ///////////////////////////////////////////////////////
      out.print("<tr>"
                +"<td bgcolor='#FFFFFF'>&nbsp;</td>"
                +"<td bgcolor='#FFFFFF'>&nbsp;</td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table></td>"
                +"</tr>"
                +"</table>"
                // Table Categories //////////////////////////////////////////////////////
                +"<p>&nbsp;</p>"
                +"<p>&nbsp;</p>"
                +"</div>"
                +"<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved."
                +"Home&amp;Decor.com Privacy Policy </p>"
                +"<p align='center'>Powered by HomeServices Inc.</p>"
                +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                +"<p>&nbsp;</p>"
                +"</body>"
                +"</html>");
  }
  public int Random(int range) {
    int result=0;
    result = (int)(Math.random()*range);
    return result;
  }
  //Clean up resources
  public void destroy() {
  }
}