package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface StringTools extends javax.ejb.EJBObject {
  public String cutEachColon(String input) throws RemoteException;
  public String addSymbol(String input) throws RemoteException;
  public String[] cutStreamString(String streamString) throws RemoteException;
  public int NumStreamString(String stearmString) throws RemoteException;
}