package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface ProductplaceRemote extends javax.ejb.EJBObject {
  public Integer getPpid() throws RemoteException;
  public void setPlid(Integer plid) throws RemoteException;
  public Integer getPlid() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
  public void setRemain(Integer remain) throws RemoteException;
  public Integer getRemain() throws RemoteException;
  public void setLimitbuy(Integer limitbuy) throws RemoteException;
  public Integer getLimitbuy() throws RemoteException;
}