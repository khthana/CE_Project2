package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PromotionproductRemoteHome extends javax.ejb.EJBHome {
  public PromotionproductRemote create(Integer psid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public PromotionproductRemote findByPrimaryKey(Integer psid) throws FinderException, RemoteException;
}