package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PositionRemote extends javax.ejb.EJBObject {
  public Integer getPid() throws RemoteException;
  public void setTypepostion(String typepostion) throws RemoteException;
  public String getTypepostion() throws RemoteException;
}