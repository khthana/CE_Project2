package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;


public class Tips extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>Tips</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    ///////////////////////////////////////////////////////

    out.println("<h1><p>Tip&Tricks</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>ID</td>");
    out.println("<td bgcolor='#66CC99'>Image URL</td>");
    out.println("<td bgcolor='#66CC99'>Name</td>");
    out.println("<td bgcolor='#66CC99'>Description</td></tr>");

    try
    {
      Context jndiContext = new InitialContext();
      Object obj = jndiContext.lookup("Tip_TrickRemote");
      //Object obj2 = jndiContext.lookup("StringTools");

      Tip_TrickRemoteHome home = (Tip_TrickRemoteHome)
          PortableRemoteObject.narrow(obj, Tip_TrickRemoteHome.class);
      //StringToolsHome sTools = (StringToolsHome)
      //    PortableRemoteObject.narrow(obj2, StringToolsHome.class);

     // StringTools st = sTools.create();

      // Update //////////////////////////////////////////////
      if (request.getParameter("Mode") != null)
      {
        if (request.getParameter("Mode").equals("Insert") && request.getParameter("tid") != null) {
          Tip_TrickRemote tt = home.create(new Integer(request.getParameter("tid")));
          //imid nid did
          if (request.getParameter("imid") != null) tt.setImageurl(request.getParameter("imid"));
          if (request.getParameter("nid") != null) tt.setName(request.getParameter("nid"));
          if (request.getParameter("did") != null) tt.setDescription(request.getParameter("did"));

        } else if (request.getParameter("Mode").equals("Delete") && request.getParameter("tid") != null) {
          Tip_TrickRemote tt = home.findByPrimaryKey(new Integer(request.getParameter("tid")));
          tt.remove();
        }
      }
      // Update //////////////////////////////////////////////

      Collection c = home.findSelectall();
      Object[] b = c.toArray();
      // StringTools st = sTools.create();

      for (int j = 0; j < c.size(); j++) {
        // Tip_TrickRemote sp = home.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
        Tip_TrickRemote sp = (Tip_TrickRemote) b[j];
        out.println("<tr>");
        out.println("<td>" + sp.getTtid() + "</td>");
        out.println("<td>" + sp.getImageurl() + "</td>");
        out.println("<td>" + sp.getName() + "</td>");
        out.println("<td>" + sp.getDescription() + "</td>");
        out.println("</tr>");

      }
    }

    catch (Throwable t) { t.printStackTrace(); }

    out.println("</table>");

    // Form ////////////////////////////////////////////////////////////////////
    out.print(
        "<form name='form1' method='get' action='../StockWAR/tips'>"
        + "<h1>"
        + "<p>Add&Edit Tip</p>"
        + "</h1>"
        + "<table width='600' border='0' cellspacing='0' cellpadding='0'>"

        // 1
        + "<tr> "
        + "<td width='30%'>Tip ID:</td>"
        + "<td width='70%'><input type='text' name='tid'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Image URL:</td>"
        + "<td width='70%'><input type='text' name='imid'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Name:</td>"
        + "<td width='70%'><input type='text' name='nid'></td>"
        + "</tr>"
        + "<tr> "
        + "<td width='30%'>Description:</td>"
        + "<td width='70%'><input type='text' name='did'></td>"
        + "</tr>"


        + "<td>"
        + "<input type='submit' name='Mode' value='Insert'>"
        + "<input type='submit' name='Mode' value='Delete'>"
        + "<input type='reset' name='Submit2' value='Reset'>"
        + "</td></tr>"
        + "</table>"
        + "</form>");

    out.println("</br>");


    //////////////////////////////////////////////////////
    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}