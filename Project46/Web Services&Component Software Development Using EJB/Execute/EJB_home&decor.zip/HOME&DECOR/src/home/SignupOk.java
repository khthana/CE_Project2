package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class SignupOk extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<div align='center'></div>"
                +"<div align='center'></div>"
                +"<div align='center'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'><strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      ///////////////////////////////////////////////////////////////////
    } catch (Throwable t) { t.printStackTrace(); }
    out.print("</strong></font></td>"
              + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "</table></td>"
              + "</tr>"
              + "<tr>"
              + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
              + "<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
              + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
              + "<tr>"
              + "<td>&nbsp;</td>"
              + "</tr>"
              + "<tr>"
              + "<td><div align='center'>Search : "
              + "<input type='text' name='textfield'>"
              + "<input type='submit' name='Submit' value='GO!'>"
              + "</div></td>"
              + "</tr>"
              + "</table>"
              + "</form>"
              + "</div></td>"
              + "</tr>"
              + "<tr> "
              + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
              + "<tr> "
              + "<td width='13%' height='404'>");
    //--------------------------------------------------------------------------
      try {
        Context jndiContext = new InitialContext();
        Object obj = jndiContext.lookup("CustomerRemote");
        Object objac = jndiContext.lookup("AddressCustomerRemote");
        //Object obj2 = jndiContext.lookup("JobRemote");
        //Object obj3 = jndiContext.lookup("SalaryRemote");
        //Object obj4 = jndiContext.lookup("SalutationRemote");

        CustomerRemoteHome Chome = (CustomerRemoteHome)
            PortableRemoteObject.narrow(obj, CustomerRemoteHome.class);
        AddressCustomerRemoteHome achome = (AddressCustomerRemoteHome)
          PortableRemoteObject.narrow(objac, AddressCustomerRemoteHome.class);

//      JobRemoteHome Jhome = (JobRemoteHome)
//                              PortableRemoteObject.narrow(obj2, JobRemoteHome.class);
//      SalaryRemoteHome Shome = (SalaryRemoteHome)
//                              PortableRemoteObject.narrow(obj3, SalaryRemoteHome.class);
//      SalutationRemoteHome home = (SalutationRemoteHome)
//                              PortableRemoteObject.narrow(obj4, SalutationRemoteHome.class);

        //String cid = request.getParameter("textfield1");

        Object objid = jndiContext.lookup("UniqueID");
        UniqueIDHome idhome = (UniqueIDHome)
            PortableRemoteObject.narrow(objid, UniqueIDHome.class);
        UniqueID id = idhome.create();
        Integer cid = new Integer(id.getUnique());

        CustomerRemote cremote;

        cremote = Chome.create(cid);
        Integer amid = new Integer(id.getUnique());
        AddressCustomerRemote ac = achome.create(amid);
        ac.setCid(cid);
        ac.setAddress(request.getParameter("textarea"));
        //cremote.setLoginname("aa");
        cremote.setLoginname(request.getParameter("textfield1"));
        if (request.getParameter("textfield2").equals(request.getParameter(
            "textfield3"))) {
          cremote.setPassword(request.getParameter("textfield3"));
        }
        cremote.setName(request.getParameter("textfield4"));
        cremote.setSurname(request.getParameter("textfield5"));
        cremote.setAddress(request.getParameter("textarea"));
        //out.println(request.getParameter("textfield6"));
        cremote.setTel(request.getParameter("textfield6"));

        cremote.setMobile(request.getParameter("textfield7"));
        cremote.setEmail(request.getParameter("textfield8"));

        String Salu = new String();
        Salu = request.getParameter("select");
        if (Salu.equals("1"))
          cremote.setSalu("Mr.");
        else if (Salu.equals("2"))
          cremote.setSalu("Mrs.");
        else if (Salu.equals("3"))
          cremote.setSalu("Ms.");
        else if (Salu.equals("4"))
          cremote.setSalu("Miss.");
        else
          cremote.setSalu("\u0E02\u0E35\u0E49\u0E21\u0E31\u0E48\u0E27");

        String job = new String();
        job = request.getParameter("select2");

///// Edit For Project --> Jion Table /////
        if (job.equals("1"))
          cremote.setJid(new Integer(1));
        else if (job.equals("2"))
          cremote.setJid(new Integer(2));
        else if (job.equals("3"))
          cremote.setJid(new Integer(3));
        else if (job.equals("4"))
          cremote.setJid(new Integer(4));
        else if (job.equals("5"))
          cremote.setJid(new Integer(5));
        else if (job.equals("8"))
          cremote.setJid(new Integer(8));
        else if (job.equals("9"))
          cremote.setJid(new Integer(9));
        else if (job.equals("7"))
          cremote.setJid(new Integer(7));
        else if (job.equals("6"))
          cremote.setJid(new Integer(6));

        String salary = new String();
        salary = request.getParameter("select3");

        if (salary.equals("1"))
          cremote.setSid(new Integer(1));
        else if (salary.equals("2"))
          cremote.setSid(new Integer(2));
        else if (salary.equals("3"))
          cremote.setSid(new Integer(3));
        else if (salary.equals("4"))
          cremote.setSid(new Integer(4));

        out.println("<center><font color='#006699' size='5'>");
        out.print("Welcome");
        out.println("</font></center>");

      }
      catch (Throwable t) {
        t.printStackTrace();
      }
      out.println("<center><font color='#006699' size='5'>");
      out.println("<br><a href='../SalesWAR/indexsales'>Back</a>");
      out.println("</font></center>");
      //------------------------------------------------------------------------
      out.println("<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "<p>&nbsp;</p>"
                  + "</div>"
                  + "<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
                  + "<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
                  + "Home&amp;Decor.com Privacy Policy </p>"
                  + "<p align='center'>Powered by HomeServices Inc.</p>"
                  + "<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
                  + "<p>&nbsp;</p>"
                  + "</body>"
                  + "</html>");
  }
  //Clean up resources
  public void destroy() {
  }
}
