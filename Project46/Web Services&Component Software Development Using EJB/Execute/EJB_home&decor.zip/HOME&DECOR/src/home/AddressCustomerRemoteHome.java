package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AddressCustomerRemoteHome extends javax.ejb.EJBHome {
  public AddressCustomerRemote create(Integer amid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public AddressCustomerRemote findByPrimaryKey(Integer amid) throws FinderException, RemoteException;
}