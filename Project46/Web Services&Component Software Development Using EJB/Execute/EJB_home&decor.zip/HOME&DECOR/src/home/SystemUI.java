package home;

// 161.246.6.91 = localhost
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

public class SystemUI
    extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println(
        "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'> "
        + "<html>"
        + "<head>"
        + "<title>System ECommerce</title>"
        +
        "<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
        + "</head>"

        + "<body>"
        + "<div align='center'>"
        + "  <input name='imageField' type='image' src='../jmx-console/images/logo.jpg' width='600' height='86' border='0'>"
        + "  <br>"
        + "</div>"
        + "<div align='center'>"
        + "<FORM action=./login"
        + "      method=get>"
        + "    <TBODY>"
        + "      <TR>"
        + "        <TD align=left><FONT "
        + "            face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
        +
        "            size=1><B>��͡����������ʼ�ҹ�����������к�</B></FONT> </TD>"
        + "      </TR>"
        + "        <TR>"
        + "          <TD colSpan=2><BR>"
        + "        </TD>"
        + "      </TR>"
        + "        <TR>"
        + "          <TD><p>&nbsp;</p>"
        + "          <table width='400' border='1' cellpadding='0' cellspacing='0' bordercolor='#3399FF'>"
        + "            <tr>"
        +
        "              <td bgcolor='#FFCC66' width='29%'> �����������к�</td>"
        + "              <td bgcolor='#FFCC66' width='71%'><input type='text' name='textfield'></td>"
        + "            </tr>"
        + "            <tr>"
        + "              <td bgcolor='#FFCC66' >���ʼ�ҹ</td>"
        +
        "             <td bgcolor='#FFCC66' ><input type='password' name='textfield2'></td>"
        + "            </tr>"
        + "          </table>"
        + "        </TD>"
        + "      </TR>"
        + "        <TR>"

        + "        <TD>&nbsp;</TD>"
        + "      </TR>"
        + "      <TR> "
        + "        <TD><BR> <FONT "
        +
        "            face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1> "
        + "          <INPUT type=submit value=�������к� name=SUBMIT>"
        + "          </FONT></TD>"
        + "      </TR>"
        + "      <TR>"
        + "        <TD align=left colSpan=2>&nbsp;</TD>"
        + "      </TR>"
        + "      <TR> "
        + "        <TD vAlign=midden align=left>&nbsp;</TD>"
        + "      </TR>"
        + "  </FORM>"
        + "</div>"
        + "</body>"
        + "</html>");
  }

  //Clean up resources
  public void destroy() {
  }
}