package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface SessionCustomerHome extends javax.ejb.EJBHome {
  public SessionCustomer create() throws CreateException, RemoteException;
}