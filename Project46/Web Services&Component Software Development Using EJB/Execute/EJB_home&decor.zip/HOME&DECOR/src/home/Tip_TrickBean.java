package home;

import javax.ejb.*;

abstract public class Tip_TrickBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer ttid) throws CreateException {
    setTtid(ttid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer ttid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTtid(java.lang.Integer ttid);
  public abstract void setImageurl(java.lang.String imageurl);
  public abstract void setName(java.lang.String name);
  public abstract void setDescription(java.lang.String description);
  public abstract java.lang.Integer getTtid();
  public abstract java.lang.String getImageurl();
  public abstract java.lang.String getName();
  public abstract java.lang.String getDescription();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}