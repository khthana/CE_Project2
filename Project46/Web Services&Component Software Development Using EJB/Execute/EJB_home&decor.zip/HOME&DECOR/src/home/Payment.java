package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Payment extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<%@ page contentType='text/html; charset=windows-874' language='java' import='java.sql.*' errorPage='' %>"
                +"<html>"
                +"<head>"
                +"<title>Product Delivery</title>"
                +"<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"</head>"
                +"<body leftmargin='0'>"
                +"<table width='900' height='487' border='0' cellpadding='0' cellspacing='0'>"
                +"<tr>"
                +"<td height='20' bgcolor='#FFFFFF'><table width='107%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td><img src='../jmx-console/images/logo.jpg' width='600' height='86'></td>"
                +"</tr>"
                +"<tr>"
                +"<td height='20'><table width='100%' border='0' cellspacing='0' cellpadding='0'>"
                +"<tr>"
                +"<td width='80%' bgcolor='#3399CC'><font color='#FFFFFF'>"
                +"<strong>");
    // Head Navigator /////////////////////////////////////////////////
    //+"HOME LIVINGROOM KITCHEN GARDEN"
    try
    {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object objsp = jndiContext.lookup("SessionPage");
      ////////////////////////////////////////////////////
      // Create RemoteHome ///////////////////////////////
      SessionPageHome sphome = (SessionPageHome)
          PortableRemoteObject.narrow(objsp, SessionPageHome.class);
      ////////////////////////////////////////////////////
      SessionPage sp = sphome.create();
      sp.PrintNav(out);
      // Finish Session Page /////////////////////////////
      // Section Selection ///////////////////////////////
      // address, deliver by /////////////////////////////
      Object objac = jndiContext.lookup("AddressCustomerRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      AddressCustomerRemoteHome achome = (AddressCustomerRemoteHome)
          PortableRemoteObject.narrow(objac, AddressCustomerRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      Collection c = achome.findSelectall();
      Object[] b = c.toArray();
      StringTools st = sTools.create();
      ///////////////////////////////////////////////////////////////////
      out.println("</strong></font></td>"
                  + "<td width='20%'><img src='../jmx-console/images/BRight_Toolbar.jpg' width='56' height='28'></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "</table></td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td height='63' bgcolor='D6E7EF'><div align='center'>"
                  +"<form name='form1' method='get' action='../SalesWAR/searchproduct'>"
                  + "<table width='900' border='0' cellpadding='0' cellspacing='0' bordercolor='#CCFFFF'>"
                  + "<tr>"
                  + "<td>&nbsp;</td>"
                  + "</tr>"
                  + "<tr>"
                  + "<td><div align='center'>Search : "
                  + "<input type='text' name='textfield'>"
                  + "<input type='submit' name='Submit' value='GO!'>"
                  + "</div></td>"
                  + "</tr>"
                  + "</table>"
                  + "</form>"
                  + "</div></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td height='339'><table width='100%' height='404' border='0' cellpadding='0' cellspacing='0'>"
                  + "<tr> "
                  + "<td width='13%' height='404'>");
      // Payment Detail //////////////////////////////////////////////////////////
      out.println("<br>"
                  + "<font  size='3' face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica'>"
                  + "<p><center><font color='#006699' size='5'><form name='form1' method='get' action='../SalesWAR/thankyou'>"
                  + "<table width='700' border='0' cellspacing='0' cellpadding='0'>"
                  + " <tr> "
                  + "<td bgcolor='#FFFFFF'><blockquote> "
                  + "<p><font color='#330066' size='4'><strong>Product Delivery</strong></font></p>"
                  + "</blockquote>"
                  + "<p><font color='#330066'>&#3585;&#3619;&#3640;&#3603;&#3634;&#3648;&#3621;&#3639;&#3629;&#3585;&#3611;&#3619;&#3632;&#3648;&#3616;&#3607; &#3649;&#3621;&#3632; &#3623;&#3636;&#3608;&#3637;&#3585;&#3634;&#3619;&#3586;&#3609;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:</font></p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td bgcolor='#CCCCFF'><p><font color='#330066'><strong>&#3626;&#3606;&#3634;&#3609;&#3607;&#3637;&#3656;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:</strong></font> "
                  + "</p>"
                  + "<p><font color='#330066'> * &#3648;&#3614;&#3639;&#3656;&#3629;&#3588;&#3623;&#3634;&#3617;&#3626;&#3632;&#3604;&#3623;&#3585;&#3586;&#3629;&#3591;&#3607;&#3656;&#3634;&#3609; &#3585;&#3619;&#3640;&#3603;"
                  + "&#3634;&#3648;&#3621;&#3639;&#3629;&#3585;&#3611;&#3621;&#3634;&#3618;&#3607;&#3634;&#3591;&#3585;&#3634;&#3619;&#3586;&#3609;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634; &#3627;"
                  + "&#3619;&#3639;&#3629;&#3648;&#3621;&#3639;&#3629;&#3585;&#3619;&#3633;&#3610;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3607;&#3637;&#3656;&#3592;&#3640;&#3604;&#3610;&#3619;&#3636;&#3585;&#3634;&#3619;"
                  + "&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;&#3621;&#3641;&#3585;&#3588;&#3657;&#3634;&#3592;&#3634;&#3585;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3585;&#3634;&#3619;&#3621;&#3591;&#3607;&#3632;"
                  + "&#3648;&#3610;&#3637;&#3618;&#3609;&#3621;&#3641;&#3585;&#3588;&#3657;&#3634; <br>&#3592;&#3632;&#3651;&#3594;&#3657;&#3648;&#3611;&#3655;&#3609;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3586;&#3629;&#3591;"
                  + "&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;&#3651;&#3610;&#3626;&#3633;&#3656;&#3591;&#3595;&#3639;&#3657;&#3629; &#3627;&#3634;&#3585;&#3607;&#3656;&#3634;&#3609;&#3605;&#3657;&#3629;&#3591;&#3585;"
                  + "&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3652;&#3611;&#3618;&#3633;&#3591;&#3611;&#3621;&#3634;&#3618;&#3607;&#3634;&#3591;&#3629;&#3639;&#3656;&#3609; &#3626;&#3634;"
                  + "&#3617;&#3634;&#3619;&#3606;&#3607;&#3635;&#3652;&#3604;&#3657;&#3650;&#3604;&#3618;&#3648;&#3614;&#3636;&#3656;&#3617;&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;&#3651;&#3627;&#3617;&#3656;"
                  + "</font></p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td bgcolor='#FFFFFF'> <div align='left'> "
                  + "<p>&nbsp;</p>"
                  + "<p><font color='#330066'>&#3648;&#3621;&#3639;&#3629;&#3585;&#3592;&#3634;&#3585;&#3626;&#3617;&#3640;&#3604;&#3610;&#3633;&#3609;&#3607;&#3638;&#3585;&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;:</font> "
                  //+ "<a href='a.html'>&#3648;&#3614;&#3636;&#3656;&#3617;&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;&#3651;&#3609;&#3585;&#3634;&#3619;&#3592;&#3633;&#3604;&#3626;&#3656;&#3591;</a> ");
                  );
      // Address //////////////////////////////////////////////////
      out.print("<select name='select'>");
      HttpSession session = request.getSession(true);
      SessionCustomer customer =
          (SessionCustomer)session.getValue("SessionCustomer");              // Create Session Variable

      for (int j=0;j<c.size();j++){
        // AddressCustomerRemote acremote = achome.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
		AddressCustomerRemote acremote = (AddressCustomerRemote)b[j];
        if (customer.getID().equals(acremote.getCid()))
          out.print("<option value='"+acremote.getAmid()+"'>"+acremote.getAddress()+"</option>");
        //+"<select name='select'><option value='1'>a</option></select>"
      }
      out.print("</select>");
      // Address //////////////////////////////////////////////////
      out.print("</p>"
                  + "</div>"
                  + "<p>&nbsp;</p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td bgcolor='#CCCCFF'><p><font color='#330066'><strong>&#3611;&#3619;&#3632;&#3648;&#3616;&#3607;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;: "
                  + "</strong></font></p>"
                  + "<p><font color='#330066'> * &#3585;&#3619;&#3640;&#3603;&#3634;&#3619;&#3632;&#3610;&#3640;&#3619;&#3634;&#3618;&#3621;&#3632;&#3648;&#3629;&#3637;&#3618;&#3604;&#3611;&#3619;&#3632;&#3648;&#3616;&#3607;&#3585;&#3634;&#3619;&#3586;&#3609;&#3626;&#3656;&#3591;&#3648;&#3614;&#3636;&#3656;&#3617;"
                  + "&#3648;&#3605;&#3636;&#3617; &#3648;&#3594;&#3656;&#3609; &#3610;&#3619;&#3636;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3606;&#3638;&#3591;&#3610;&#3657;&#3634;&#3609;/&#3626;&#3635;&#3609;&#3633;&#3585;&#3591;&#3634;&#3609; &#3610;&#3619;&#3636;&#3585;"
                  + "&#3634;&#3619;&#3626;&#3656;&#3591;&#3614;&#3633;&#3626;&#3604;&#3640;&#3652;&#3611;&#3619;&#3625;&#3603;&#3637;&#3618;&#3660; &#3627;&#3619;&#3639;&#3629; &#3619;&#3633;&#3610;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3607;&#3637;&#3656;&#3592;&#3640;&#3604;&#3610;&#3619;&#3636;&#3585;&#3634;&#3619;"
                  + "<br> &#3595;&#3638;&#3656;&#3591;&#3610;&#3619;&#3636;&#3585;&#3634;&#3619;&#3585;&#3634;&#3619;&#3586;&#3609;&#3626;&#3656;&#3591;&#3586;&#3629;&#3591;&#3648;&#3619;&#3634; &#3626;&#3634;&#3617;&#3634;&#3619;&#3606;&#3592;&#3633;&#3604;&#3626;&#3656;&#3591;&#3652;&#3604;&#3657;&#3627;&#3621;"
                  + "&#3634;&#3585;&#3627;&#3621;&#3634;&#3618;&#3594;&#3656;&#3629;&#3591;&#3607;&#3634;&#3591; &#3607;&#3633;&#3657;&#3591;&#3649;&#3610;&#3610;&#3604;&#3656;&#3623;&#3609;&#3614;&#3636;&#3648;&#3624;&#3625; &#3649;&#3621;&#3632;&#3649;&#3610;&#3610;&#3608;&#3619;&#3619;&#3617;&#3604;&#3634;"
                  + "(&#3604;&#3641;&#3619;&#3634;&#3618;&#3621;&#3632;&#3648;&#3629;&#3637;&#3618;&#3604;&#3648;&#3614;&#3636;&#3656;&#3617;&#3648;&#3605;&#3636;&#3617;) "
                  + "</font></p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td height='59' bgcolor='#FFFFFF'> <div align='center'> "
                  + "<p>&nbsp;</p>"
                  + "<p> "
                  // Deliver By //////////////////////////////////////////////////
                  +"<select name='select3'><option value='150'>Post-Office</option></select>"
                  // Deliver By //////////////////////////////////////////////////
                  + "</p>"
                  + "</div>"
                  + "<p><br>"
                  + "</p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td bgcolor='#CCCCFF'><p><font color='#330066'><strong>&#3623;&#3636;&#3608;&#3637;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;:</strong></font></p>"
                  + "<p><font color='#330066'> * &#3627;&#3621;&#3633;&#3591;&#3592;&#3634;&#3585;&#3607;&#3656;&#3634;&#3609;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;&#3605;&#3634;&#3617;&#3623;&#3636;&#3608;"
                  + "&#3637;&#3607;&#3637;&#3656;&#3607;&#3656;&#3634;&#3609;&#3648;&#3621;&#3639;&#3629;&#3585;&#3649;&#3621;&#3657;&#3623; &#3585;&#3619;&#3640;&#3603;&#3634;&#3626;&#3656;&#3591;&#3648;&#3629;&#3585;"
                  + "&#3626;&#3634;&#3619;&#3585;&#3634;&#3619;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;&#3617;&#3634;&#3618;&#3633;&#3591;&#3610;&#3619;&#3636;&#3625;&#3633;&#3607; &#3648;&#3614;&#3639;"
                  + "&#3656;&#3629;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3585;&#3634;&#3619;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609; (&#3629;&#3656;&#3634;&#3609;&#3619;&#3634;&#3618;&#3621;&#3632;"
                  + "&#3648;&#3629;&#3637;&#3618;&#3604;&#3623;&#3636;&#3608;&#3637;&#3585;&#3634;&#3619;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;)"
                  + "</font></p></td>"
                  + "</tr>"
                  + "<tr> "
                  + "<td height='43' bgcolor='#FFFFFF'><div align='center'><font color='#330066'>&nbsp; "
                  + "</font> "
                  + "<p>&nbsp;</p>"
                  +
          "<table width='700' border='0' cellspacing='0' cellpadding='0'>"
                  + "<tr> "
                  + "<td bgcolor='#FFFFFF'>Card ID: "
                  + "<input type='text' name='textfield'></td>"
                  + "<td bgcolor='#FFFFFF'>Expire date: "
                  + "<input type='text' name='textfield2'></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p>"
                  + "<input type='submit' name='Submit' value='Confirm'>"
                  + "</p>"
                  + "</div></td>"
                  + "</tr>"
                  + "</table>"
                  + "<p align='center'>&nbsp;</p>"
                  + "</form>"
                  + "</font></center></p>"
                  + "</font> ");
      // Paymenr Detail //////////////////////////////////////////////////////////
      out.println("<p align='center'>Company Info | Advertising | Help | Terms of Use </p>"
          +"<p align='center'>Copyright 1997-2003 eComNuke.com Inc., All rights reserved. "
          +"Home&amp;Decor.com Privacy Policy </p>"
          +"<p align='center'>Powered by HomeServices Inc.</p>"
          +"<p align='center'>Web Server by <a href='index2.jsp'>Tomcat</a></p>"
          +"<p>&nbsp;</p>"
          +"</body>"
          +"</html>");
    }
    catch (Throwable t) { t.printStackTrace(); }

  }
  //Clean up resources
  public void destroy() {
  }
}