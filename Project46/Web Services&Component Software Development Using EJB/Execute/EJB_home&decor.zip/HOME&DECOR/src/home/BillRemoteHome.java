package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BillRemoteHome extends javax.ejb.EJBHome {
  public BillRemote create(Integer bid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public BillRemote findByPrimaryKey(Integer bid) throws FinderException, RemoteException;
}