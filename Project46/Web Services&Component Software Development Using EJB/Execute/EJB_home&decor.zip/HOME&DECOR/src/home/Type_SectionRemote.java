package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Type_SectionRemote extends javax.ejb.EJBObject {
  public Integer getTsid() throws RemoteException;
  public void setNamesection(String namesection) throws RemoteException;
  public String getNamesection() throws RemoteException;
}