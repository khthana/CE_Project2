package home;

import javax.ejb.*;

abstract public class BrandBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer bid) throws CreateException {
    setBid(bid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer bid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setBid(java.lang.Integer bid);
  public abstract void setBrandname(java.lang.String brandname);
  public abstract java.lang.Integer getBid();
  public abstract java.lang.String getBrandname();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}