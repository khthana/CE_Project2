package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

import java.io.*;

public interface Promotion extends javax.ejb.EJBObject {
  public void BoxPromotionProduct(PrintWriter out) throws RemoteException;
  public void BoxPromotionSection(PrintWriter out, Integer Section) throws RemoteException;
  public void BoxTypePromotionProduct(PrintWriter out) throws RemoteException;
  public void BoxPromotionIndex(PrintWriter out) throws RemoteException;
  public float PriceProduct(Integer pid) throws RemoteException;
}