package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class BillID extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    String billid = request.getParameter("billid");
    float sum=0;
    try {
      // Create Object ///////////////////////////////////
      Context jndiContext = new InitialContext();
      Object obj2 = jndiContext.lookup("StringTools");
      Object objb = jndiContext.lookup("BillRemote");
      Object objbd = jndiContext.lookup("BilldetailRemote");
      Object objc = jndiContext.lookup("CustomerRemote");
      Object objp = jndiContext.lookup("ProductRemote");
      Object objac = jndiContext.lookup("AddressCustomerRemote");

      StringToolsHome sTools = (StringToolsHome)
          PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      BillRemoteHome bhome = (BillRemoteHome)
          PortableRemoteObject.narrow(objb, BillRemoteHome.class);
      BilldetailRemoteHome bdhome = (BilldetailRemoteHome)
          PortableRemoteObject.narrow(objbd, BilldetailRemoteHome.class);
      CustomerRemoteHome chome = (CustomerRemoteHome)
          PortableRemoteObject.narrow(objc, CustomerRemoteHome.class);
      ProductRemoteHome phome = (ProductRemoteHome)
          PortableRemoteObject.narrow(objp, ProductRemoteHome.class);
      AddressCustomerRemoteHome achome = (AddressCustomerRemoteHome)
          PortableRemoteObject.narrow(objac, AddressCustomerRemoteHome.class);

      StringTools st = sTools.create();
      BillRemote billhead = bhome.findByPrimaryKey(new Integer(billid));
      Collection billdetailcollection = bdhome.findBilldetailByID(billhead.getBid());
      Object[] billdetailb = billdetailcollection.toArray();
      CustomerRemote customer = chome.findByPrimaryKey(billhead.getCid());
      AddressCustomerRemote addressdeliver = achome.findByPrimaryKey(billhead.getAmid());

      out.println(
          "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>"
          + "<!-- saved from url=(0158)https://stores.col.co.th/webapp/commerce/command/OrderDisplay?status=C&order_rn=906931&merchant_rn=631&printorder=yes&language=thai&depart=powerbuy&updatetb=N -->"
          + "<HTML><HEAD><TITLE>Home&Decor</TITLE>"
          + "<META http-equiv=Pragma content=no-cache>"
          + "<META http-equiv=expires content=0>"
          + "<META http-equiv=content-type content='text/html; charset=windows-874'>"
          + "<META content='MSHTML 6.00.2800.1276' name=GENERATOR></HEAD>"
          + "<BODY text=#4a0d75 bgColor=#ffffff leftMargin=0 "
          + "background='../Example/Web_example/%E0%BE%D2%E0%C7%CD%C3%EC%BA%D2%C2%20%E0%C1%D7%CD%A7%CD%D4%E0%C5%E7%A1%B7%C3%CD%B9%D4%A1%CA%ECpager_files/cmdinc.htm' topMargin=0 "
          + "marginwidth='0' marginheight='0' marginleft='0'>"
          + "<DIV align=center>"
          + "<CENTER>"
          + "<TABLE cellSpacing=0 cellPadding=0 width=600 align=center border=0>"
          + "<TBODY>"
          + "<TR> "
          + "<TR> "
          + "<TD colSpan=2><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><B><FONT "
          + "size=2>&#3610;&#3619;&#3636;&#3625;&#3633;&#3607; &#3610;&#3657;&#3634;&#3609;&#3649;&#3621;&#3632;&#3629;&#3640;&#3611;&#3585;&#3619;&#3603;&#3660;&#3605;&#3585;&#3649;&#3605;&#3656;&#3591;&#3610;&#3657;&#3634;&#3609; &#3592;&#3635;&#3585;&#3633;&#3604;</FONT></B><BR>"
          + "&#3629;&#3634;&#3588;&#3634;&#3619; &#3595;&#3629;&#3605;&#3660;&#3649;&#3623;&#3615;&#3611;&#3634;&#3619;&#3660;&#3588;<BR>"
          + "&#3648;&#3621;&#3586;&#3607;&#3637;&#3656; 99/381 &#3627;&#3617;&#3641;&#3656; 8 &#3605;.&#3610;&#3634;&#3591;&#3585;&#3619;&#3632;&#3626;&#3629; &#3629;.&#3648;&#3617;&#3639;&#3656;&#3629;&#3591;  &#3592;.&#3609;&#3609;&#3607;&#3610;&#3640;&#3619;&#3637; "
          + "11000<BR>"
          + "<B>&#3648;&#3621;&#3586;&#3611;&#3619;&#3632;&#3592;&#3635;&#3605;&#3633;&#3623;&#3612;&#3641;&#3657;&#3648;&#3626;&#3637;&#3618;&#3616;&#3634;&#3625;&#3637;&#3629;&#3634;&#3585;&#3619;: 3030172600</B></FONT></TD>"
          + "<TD align=right>&nbsp;</TD>"
          + "</TR>"
          + "<TR> "
          + "<TD width=600 colSpan=2><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>&nbsp;</FONT></TD>"
          + "<TD align=right width=600>&nbsp;</TD>"
          + "</TR>"
          + "<TR>"
          + "<TD align=middle colSpan=3><div align='center'><strong>Form Billing</strong></div></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD align=middle width=600 colSpan=3><hr></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD align=middle width=600 bgColor=#ffffff colSpan=3> <TABLE cellSpacing=0 cellPadding=0 width=600 bgColor=#ffffff border=0>"
          + "<TBODY>"
          + "<TR> "
          + "<TD vAlign=top align=left><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1><IMG "
          + "height=3 "
          + "src='dot(1).gif' "
          + "width=1><BR>"
          + "</FONT></TD>"
          + "</TR>"
          + "</TBODY>"
          + "</TABLE>"
          + "<TABLE cellSpacing=0 cellPadding=0 width=600 align=center bgColor=#ffffff "
          + "border=0>"
          + "<TBODY>"
          + "<TR> "
          + "<TD colSpan=3><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3586;&#3629;&#3586;&#3629;&#3610;&#3588;&#3640;&#3603; "+customer.getName()+" "+customer.getSurname()+" &#3607;&#3637;&#3656;&#3607;&#3656;&#3634;&#3609;&#3652;&#3604;&#3657;&#3626;&#3633;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3592;&#3634;&#3585;&#3619;&#3657;&#3634;&#3609;"
          + ". </FONT><BR> <FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#aa2b4a "
          + "size=1>(&#3585;&#3619;&#3640;&#3603;&#3634;&#3614;&#3636;&#3617;&#3614;&#3660; &#3648;&#3614;&#3639;&#3656;&#3629;&#3651;&#3594;&#3657;&#3648;&#3611;&#3655;&#3609;&#3648;&#3629;&#3585;&#3626;&#3634;&#3619;&#3629;&#3657;&#3634;&#3591;&#3629;&#3636;&#3591;&#3585;&#3634;&#3619;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;&#3612;&#3656;&#3634;&#3609;&#3608;&#3609;&#3634;&#3588;&#3634;&#3619;&#3627;&#3619;&#3639;&#3629;&#3608;&#3609;&#3634;&#3603;&#3633;&#3605;&#3636;)</FONT><BR>"
          + "<BR></TD>"
          + "</TR>"
          + "</TBODY>"
          + "</TABLE></TD>"
          + "</TR>"
          + "<!--   Order detail Message by Yaow-->"
          + "<TR> "
          + "<TD vAlign=top width=600 bgColor=#ffffff><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1><B>&#3648;&#3621;&#3586;&#3607;&#3637;&#3656;&#3651;&#3610;&#3626;&#3633;&#3656;&#3591;&#3595;&#3639;&#3657;&#3629;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;: </B>"+request.getParameter("billid")+"<BR>"
          + "<BR>"
          + "<B>&#3623;&#3633;&#3609;&#3607;&#3637;&#3656;&#3626;&#3633;&#3656;&#3591;&#3595;&#3639;&#3657;&#3629;:</B> 23/12/2003 <BR>"
          + "<BR>"
          + "<B>&#3607;&#3637;&#3656;&#3629;&#3618;&#3641;&#3656;&#3607;&#3637;&#3656;&#3651;&#3594;&#3657;&#3651;&#3609;&#3585;&#3634;&#3619;&#3592;&#3633;&#3604;&#3626;&#3656;&#3591;&#3651;&#3610;&#3585;&#3635;&#3585;&#3633;&#3610;&#3616;&#3634;&#3625;&#3637;/ &#3651;&#3610;&#3648;&#3626;&#3619;&#3655;&#3592;&#3619;&#3633;&#3610;&#3648;&#3591;&#3636;&#3609;</B><BR>"
          + "&#3588;&#3640;&#3603; "+customer.getName()+" "+customer.getSurname()+" <BR>"
          + addressdeliver.getAddress()+"<BR>"
          + "<BR>"
          + "<B>&#3611;&#3619;&#3632;&#3648;&#3616;&#3607;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;: </B> &#3649;&#3610;&#3610;&#3648;&#3605;&#3655;&#3617;&#3592;&#3635;&#3609;&#3623;&#3609;&#3651;&#3610;&#3626;&#3633;&#3656;&#3591;&#3595;&#3639;&#3657;&#3629;<BR>"
          + "<BR>"
          + "<B>&#3623;&#3636;&#3608;&#3637;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:</B> Post Office-Express<BR>"
          + "<BR>"
          + "<B>&#3626;&#3606;&#3634;&#3609;&#3607;&#3637;&#3656;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;:</B><BR>"
          + "&#3588;&#3640;&#3603; "+customer.getName()+" "+customer.getSurname()+" <BR>"
          + addressdeliver.getAddress()+"</FONT></TD>"
          + "<TD vAlign=top width=600 bgColor=#ffffff colSpan=2><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1><B>&#3623;&#3636;&#3608;&#3637;&#3594;&#3635;&#3619;&#3632;&#3648;&#3591;&#3636;&#3609;:</B> &#3610;&#3633;&#3605;&#3619;&#3648;&#3588;&#3619;&#3604;&#3636;&#3605; <BR>"
          + "<BR>"
          + "</FONT></TD>"
          + "</TR>"
          + "<!--   Order detail Message by Yaow  till here -->"
          + "<!--   Product detail Message by Yaow -->"
          + "<TR> "
          + "<TD align=left width=600 bgColor=#ffffff colSpan=3><B><BR>"
          + "<FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>&#3619;&#3634;&#3618;&#3585;&#3634;&#3619;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;: "
          + "</FONT><BR>"
          + "<BR>"
          + "</B> <TABLE borderColor=#a7a7a7 cellSpacing=0 cellPadding=3 width=600 "
          + "border=1>"
          + "<TBODY>"
          + "<TR> "
          + "<TD vAlign=center align=middle width=30 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3621;&#3635;&#3604;&#3633;&#3610;&#3607;&#3637;&#3656; </FONT></B></TD>"
          + "<TD vAlign=center align=middle width=70 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3619;&#3627;&#3633;&#3626;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634; </FONT></B></TD>"
          + "<TD vAlign=center align=middle width=250 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3619;&#3634;&#3618;&#3585;&#3634;&#3619;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634; </FONT></B></TD>"
          + "<TD vAlign=center align=middle width=50 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>&#3592;&#3635;&#3609;&#3623;&#3609; "
          + "</FONT></B></TD>"
          + "<TD vAlign=center align=middle width=100 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3619;&#3634;&#3588;&#3634;&#3605;&#3656;&#3629;&#3627;&#3609;&#3656;&#3623;&#3618; </FONT></B></TD>"
          + "<TD vAlign=center align=middle width=100 bgColor=#d2d8f9><B><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3592;&#3635;&#3609;&#3623;&#3609;&#3648;&#3591;&#3636;&#3609; (&#3610;&#3634;&#3607;)</FONT></B></TD>"
          + "</TR>");
      // 1 ///////////////////////////////////////////////////////////
      for (int i =0;i<billdetailcollection.size();i++) {
        // BilldetailRemote billdetail = bdhome.findByPrimaryKey(new Integer(st.cutEachColon(billdetailb[i].toString())));
		BilldetailRemote billdetail = (BilldetailRemote)billdetailb[i];
        ProductRemote product = phome.findByPrimaryKey(billdetail.getPid());
        float sumLine = billdetail.getSalesperunit().floatValue()*billdetail.getNumber().floatValue();
        out.print("<TR> "
                  + "<TD vAlign=top align=middle bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  //+ "size=1>"+billdetail.getLine()+"</FONT></TD>"
                  + "size=1>"+(i+1)+"</FONT></TD>"
                  + "<TD vAlign=top align=middle bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  + "size=1>"+billdetail.getPid()+"</FONT></TD>"
                  + "<TD vAlign=top align=left bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  + "size=1>"+product.getName()+"</FONT></TD>"
                  + "<TD vAlign=top align=middle bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  + "size=1>"+billdetail.getNumber()+"</FONT></TD>"
                  + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  + "size=1>"+billdetail.getSalesperunit()+"</FONT></TD>"
                  + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
                  + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
                  + "size=1>"+sumLine+"</FONT></TD>"
                  + "</TR>");
        sum += sumLine;
      }
      // Iterative /////////////////////////////////////////////////////////////
      out.print("<TR> "
          + "<TD vAlign=top align=right bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + " <TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1><B>&#3619;&#3623;&#3617;&#3619;&#3634;&#3588;&#3634;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3607;&#3637;&#3656;&#3626;&#3633;&#3656;&#3591; (&#3619;&#3623;&#3617;&#3616;&#3634;&#3625;&#3637;&#3617;&#3641;&#3621;&#3588;&#3656;&#3634;&#3648;&#3614;&#3636;&#3656;&#3617;)</B></FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>"+sum+"</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          //+ "size=1><B>&#3626;&#3656;&#3623;&#3609;&#3621;&#3604; </B></FONT></TD>"
          + "size=1><B></B></FONT></TD>"
          //
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          //+ "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>0.00 "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>"
          + "</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1><B>&#3619;&#3623;&#3617;&#3619;&#3634;&#3588;&#3634;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3607;&#3633;&#3657;&#3591;&#3626;&#3636;&#3657;&#3609; (&#3619;&#3623;&#3617;&#3616;&#3634;&#3625;&#3637;&#3617;&#3641;&#3621;&#3588;&#3656;&#3634;&#3648;&#3614;&#3636;&#3656;&#3617;)</B></FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>"+sum+"</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3588;&#3656;&#3634;&#3651;&#3594;&#3657;&#3592;&#3656;&#3634;&#3618;&#3651;&#3609;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>135.00 "
          + "</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3626;&#3656;&#3623;&#3609;&#3621;&#3604;&#3588;&#3656;&#3634;&#3651;&#3594;&#3657;&#3592;&#3656;&#3634;&#3618;&#3651;&#3609;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>0.00 "
          + "</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#fffbdf colSpan=4><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1><B>&#3619;&#3623;&#3617;&#3588;&#3656;&#3634;&#3651;&#3594;&#3657;&#3592;&#3656;&#3634;&#3618;&#3651;&#3609;&#3585;&#3634;&#3619;&#3626;&#3656;&#3591;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;</B></FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&nbsp;</FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#fffbdf><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' size=1>135.00 "
          + "</FONT></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD vAlign=top align=left bgColor=#4a0d75 colSpan=5><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#ffffff "
          + "size=2><B>&#3619;&#3623;&#3617;&#3588;&#3656;&#3634;&#3651;&#3594;&#3657;&#3592;&#3656;&#3634;&#3618;&#3651;&#3609;&#3585;&#3634;&#3619;&#3626;&#3633;&#3656;&#3591;&#3595;&#3639;&#3657;&#3629;&#3626;&#3636;&#3609;&#3588;&#3657;&#3634;&#3607;&#3633;&#3657;&#3591;&#3626;&#3636;&#3657;&#3609; (&#3619;&#3623;&#3617;&#3616;&#3634;&#3625;&#3637;&#3617;&#3641;&#3621;&#3588;&#3656;&#3634;&#3648;&#3614;&#3636;&#3656;&#3617;)</B></FONT></TD>"
          + "<TD vAlign=top align=right bgColor=#4a0d75><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' color=#ffffff "
          + "size=2><B>"+(sum+135)+"</B><BR>"
          + "</FONT></TD>"
          + "</TR>"
          + "</TBODY>"
          + "</TABLE></TD>"
          + "</TR>"
          + "<!--   Product detail Message by Yaow  till here -->"
          + "<TR> "
          + "<TD align=middle width=600 colSpan=3></TD>"
          + "</TR>"
          + "<TR> "
          + "<TD align=middle width=600 colSpan=3><div align='center'>[<A "
          + "href='javascript:history.back(1);' ?><FONT "
          + "face='Ms Sans Serif,Ms Serif,Verdana,Arial,Helvetica' "
          + "size=1>&#3585;&#3621;&#3633;&#3610;&#3652;&#3611;&#3627;&#3609;&#3657;&#3634;&#3585;&#3656;&#3629;&#3609;&#3609;&#3637;&#3657;]</div></TD>"
          + "</TR>"
          + "</TBODY>"
          + "</TABLE>"
          + "</CENTER></DIV></BODY></HTML>");
    } catch (Throwable t) { t.printStackTrace(); }
  }
  //Clean up resources
  public void destroy() {
  }
}