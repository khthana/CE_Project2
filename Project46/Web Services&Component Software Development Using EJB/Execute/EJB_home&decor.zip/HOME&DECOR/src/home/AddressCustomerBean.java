package home;

import javax.ejb.*;

abstract public class AddressCustomerBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer amid) throws CreateException {
    setAmid(amid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer amid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setAmid(java.lang.Integer amid);
  public abstract void setCid(java.lang.Integer cid);
  public abstract void setAddress(java.lang.String address);
  public abstract java.lang.Integer getAmid();
  public abstract java.lang.Integer getCid();
  public abstract java.lang.String getAddress();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}