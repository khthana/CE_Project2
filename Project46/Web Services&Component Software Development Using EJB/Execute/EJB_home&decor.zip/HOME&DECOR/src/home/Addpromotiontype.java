package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Addpromotiontype extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>");
    out.println("<head><title>addpromotiontype</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    ///////////////////////////////////////////
    out.println("<h1><p>Type Promotion</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td  bgcolor='#66CC99'>ID</td>");
    out.println("<td  bgcolor='#66CC99'>NAME</td>");
    out.println("</tr>");

    try{

      Context jndiContext = new InitialContext();
      Object tpobj = jndiContext.lookup("Type_PromotionRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      Type_PromotionRemoteHome tphome = (Type_PromotionRemoteHome)
                                PortableRemoteObject.narrow(tpobj, Type_PromotionRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
                                PortableRemoteObject.narrow(obj2, StringToolsHome.class);
      Collection tpc = tphome.findSelectall();
      Object[] tpb = tpc.toArray();
      StringTools st = sTools.create();

      for (int j=0;j<tpc.size();j++){
        // Type_PromotionRemote tp = tphome.findByPrimaryKey(new Integer(st.cutEachColon(tpb[j].toString())));
		Type_PromotionRemote tp = (Type_PromotionRemote)tpb[j];
        out.println("<tr>");
        out.println("<td>"+tp.getTprid()+"</td>");
        out.println("<td>"+tp.getName()+"</td>");
        out.println("</tr>");

      }
      out.println("</table><br>");

      out.print("<form name='form1' method='get' action='../StockWAR/addpromotiontype'>"
                       +"<h1>"
                       +"<p>Add Promotion Type </p>"
                       +"</h1>"
                       +"<table width='600' border='0' cellspacing='0' cellpadding='0'>"

                       +"<tr> "
                       +"<td width='30%'>Type Promotion ID</td>"
                       +"<td width='70%'><input type='text' name='textfield'></td>"
                       +"</tr>"
                       +"<tr>"
                       +"<td>Name</td>"
                       +"<td><input type='text' name='textfield2'></td>"
                       +"</tr>"

                       +"<td><input type='submit' name='Submit' value='Submit'>"
                       +"<input type='reset' name='Submit2' value='Reset'>"
                       +"</td></tr>"
                       +"</table>"
                       +"</form>"

                       );

        out.println("</br>");
        out.println("<br><a href='../StockWAR/promotionadmin' >Back</a>");

      String tprid = request.getParameter("textfield");
           Type_PromotionRemote tprremote;
           boolean haveP = false;
              for (int i=0;i<tpc.size();i++) {
                if ( st.cutEachColon(tpb[i].toString()).equals(tprid) ) haveP = true;
                }
              if (haveP) {
                out.println("Edit Type Promotion ");
                tprremote = tphome.findByPrimaryKey(new Integer(tprid));
                // name='Submit3' value='del'
                String del = request.getParameter("Submit2");
                if (del.equals("Reset")) tprremote.remove();
                else {

                }
              } else {
                out.println("Add Type Promotion");
                tprremote = tphome.create(new Integer(tprid));
               // tpremote.setTpid(new Integer(request.getParameter("textfield")));
                tprremote.setName(request.getParameter("textfield2"));
                //premote.setBarcode(request.getParameter("textfield3"));

              }






    }
    catch (Throwable t) { t.printStackTrace(); }


    //////////////////////////////////////////
    out.println("</body></html>");



  }
  //Clean up resources
  public void destroy() {
  }
}
