package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PlaceRemote extends javax.ejb.EJBObject {
  public Integer getPlid() throws RemoteException;
  public void setPlacename(String placename) throws RemoteException;
  public String getPlacename() throws RemoteException;
  public void setAddress(String address) throws RemoteException;
  public String getAddress() throws RemoteException;
}