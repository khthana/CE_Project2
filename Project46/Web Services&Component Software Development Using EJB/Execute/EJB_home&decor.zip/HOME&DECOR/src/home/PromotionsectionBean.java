package home;

import javax.ejb.*;

abstract public class PromotionsectionBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer psid) throws CreateException {
    setPsid(psid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer psid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPsid(java.lang.Integer psid);
  public abstract void setPercentsale(java.lang.Integer percentsale);
  public abstract void setStart(java.sql.Timestamp start);
  public abstract void setStop(java.sql.Timestamp stop);
  public abstract void setTprid(java.lang.Integer tprid);
  public abstract void setTsid(java.lang.Integer tsid);
  public abstract java.lang.Integer getPsid();
  public abstract java.lang.Integer getPercentsale();
  public abstract java.sql.Timestamp getStart();
  public abstract java.sql.Timestamp getStop();
  public abstract java.lang.Integer getTprid();
  public abstract java.lang.Integer getTsid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}