package home;

import javax.ejb.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.lang.String;

abstract public class EmployeeBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer eid) throws CreateException {
    setEid(eid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer eid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setEid(java.lang.Integer eid);
  public abstract void setName(java.lang.String name);
  public abstract void setSurname(java.lang.String surname);
  public abstract void setPassword(java.lang.String password);
  public abstract void setAddress(java.lang.String address);
  public abstract void setTel(java.lang.Integer tel);
  public abstract void setEmail(java.lang.String email);
  public abstract void setPid(java.lang.Integer pid);
  public abstract java.lang.Integer getEid();
  public abstract java.lang.String getName();
  public abstract java.lang.String getSurname();
  public abstract java.lang.String getPassword();
  public abstract java.lang.String getAddress();
  public abstract java.lang.Integer getTel();
  public abstract java.lang.String getEmail();
  public abstract java.lang.Integer getPid();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public String getTypePosition() {
    String tp = new String();
    try
    {
    // obtain MemberRemote
    Context jndiContext = new InitialContext();
    Object obj = jndiContext.lookup("PositionRemote");
    PositionRemoteHome home = (PositionRemoteHome)
                              PortableRemoteObject.narrow(obj, PositionRemoteHome.class);

    PositionRemote ss = home.findByPrimaryKey(getPid());
    //PositionRemote home = getPosition();
    tp = ss.getTypepostion();

    }
    //catch (java.rmi.RemoteException re) { re.printStackTrace(); }
    catch (Throwable t) { t.printStackTrace(); }
    return tp;
  }
}