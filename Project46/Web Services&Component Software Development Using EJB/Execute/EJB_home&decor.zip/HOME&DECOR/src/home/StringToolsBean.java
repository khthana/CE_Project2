package home;

import javax.ejb.*;
import java.lang.String;
import java.util.*;

public class StringToolsBean implements SessionBean {
  SessionContext sessionContext;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public String cutEachColon(String input) {
    int i = input.indexOf(":");
    String output = input.substring(i+1);
    return output;
  }
  public String addSymbol(String input) {
    int position=0;
    while (position >= 0) {
      position = input.indexOf("^");
      if (position >= 0)
        input = input.substring(0 ,position)+"<br><img src='../jmx-console/images/bullet.gif'>"+" "+input.substring(position+1 ,input.length());
    }
    return input;
  }
  public String[] cutStreamString(String streamString) {
    Vector v = new Vector();
    String temp = "";
    int position=0;
    while (position >= 0) {
      position = streamString.indexOf("#");
      if (position >= 0) {
        v.addElement(streamString.substring(0, position));
        streamString = streamString.substring(position + 1, streamString.length());
      }
    }
    String [] output = new String[v.size()];
    for (int i= v.size(); i>0; i--) {
      output[i-1] = (String)v.get(i-1);
    }
    return output;
  }
  public int NumStreamString(String streamString) {
    Vector v = new Vector();
    String temp = "";
    int position=0;
    while (position >= 0) {
      position = streamString.indexOf("#");
      if (position >= 0) {
        v.addElement(streamString.substring(0, position));
        streamString = streamString.substring(position + 1, streamString.length());
      }
    }
    return v.size();
  }
}