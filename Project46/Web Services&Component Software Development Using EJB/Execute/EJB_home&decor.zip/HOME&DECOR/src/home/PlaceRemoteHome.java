package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface PlaceRemoteHome extends javax.ejb.EJBHome {
  public PlaceRemote create(Integer plid) throws CreateException, RemoteException;
  public PlaceRemote findByPrimaryKey(Integer plid) throws FinderException, RemoteException;
}