package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.util.Collection;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class Supply extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Menu Supply</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    out.println("<center><h1><p>Menu Supply</p></h1></center>");
    out.println("<br><a href='../StockWAR/supplyproduct' >Supply to Stock</a>");
    out.println("<br><a href='../StockWAR/supplier' >Supplier</a>");

    out.println("</body></html>");
  }
  //Clean up resources
  public void destroy() {
  }
}