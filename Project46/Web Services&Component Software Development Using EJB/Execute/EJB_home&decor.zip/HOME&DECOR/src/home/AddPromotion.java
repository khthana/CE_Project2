package home;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.util.*;

import java.util.Collection;
import java.lang.String;
import java.lang.*;
import java.sql.Timestamp;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class AddPromotion extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"<head><title>AddPromotion</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");

    // Start ///////////////////////////////////////////////////////////////////
    // Type Promotion //////////////////////////////////////////////////////////
    out.println("<h1><p>Product Promotion</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'>");
    out.println("<tr>");
    out.println("<td bgcolor='#66CC99'>Promotion ID</td>");
    out.println("<td bgcolor='#66CC99'>Special Price</td>");
    out.println("<td bgcolor='#66CC99'>Start Date</td>");
    out.println("<td bgcolor='#66CC99'>Stop Date</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion ID</td>");
    out.println("<td bgcolor='#66CC99'>Type Promotion Name</td>");
    out.println("<td bgcolor='#66CC99'>Product ID</td>");
    out.println("<td bgcolor='#66CC99'>Product Name</td>");
    //out.println("<td>NAME</td>");
    out.println("</tr>");


    try
    {
    // obtain MemberRemote
    Context jndiContext = new InitialContext();
      Object ppobj = jndiContext.lookup("PromotionproductRemote");
      Object obj2 = jndiContext.lookup("StringTools");
      PromotionproductRemoteHome pphome = (PromotionproductRemoteHome)
                                PortableRemoteObject.narrow(ppobj, PromotionproductRemoteHome.class);
      StringToolsHome sTools = (StringToolsHome)
                                PortableRemoteObject.narrow(obj2, StringToolsHome.class);

      Object pobj = jndiContext.lookup("ProductRemote");
      ProductRemoteHome phome = (ProductRemoteHome)
                                PortableRemoteObject.narrow(pobj, ProductRemoteHome.class);
      Object tpobj = jndiContext.lookup("Type_PromotionRemote");
      Type_PromotionRemoteHome tphome = (Type_PromotionRemoteHome)
                                PortableRemoteObject.narrow(tpobj, Type_PromotionRemoteHome.class);

      Collection ppc = pphome.findSelectall();
      Object[] ppb = ppc.toArray();
      Collection pc = phome.findSelectall();
      Object[] pb = pc.toArray();
      Collection tpc = tphome.findSelectall();
      Object[] tpb = tpc.toArray();
      StringTools st = sTools.create();



      for(int j=0;j<ppc.size();j++){
            // PromotionproductRemote pps = pphome.findByPrimaryKey(new Integer(st.cutEachColon(ppb[j].toString())));
            PromotionproductRemote pps = (PromotionproductRemote)ppb[j];


             out.println("<tr>");
             out.println("<td>"+pps.getPsid()+"</td>");
             out.println("<td>"+pps.getSpecialsale()+"</td>");
             out.println("<td>"+pps.getStart()+"</td>");
             out.println("<td>"+pps.getStop()+"</td>");





         //for(int i=0;i<tpc.size();i++)
         //{
           // Type_PromotionRemote tps = tphome.findByPrimaryKey(new Integer(st.cutEachColon(tpb[i].toString())));
           Type_PromotionRemote tps = tphome.findByPrimaryKey(pps.getTprid()); //(Type_PromotionRemote)tpb[i];
           //if(st.cutEachColon(tpb[i].toString()).equals(pps.getTprid().toString()))
           //Type_PromotionRemote ptemp = (Type_PromotionRemote)tpb[i]; // Error
           //if(ptemp.getTprid().equals(pps.getTprid()))
           //{
             out.println("<td>"+tps.getTprid() +"</td>");
             out.println("<td>"+tps.getName() +"</td>");
           //}
         //}


         //for(int i=0;i<pc.size();i++)
         //{
           // ProductRemote ps = phome.findByPrimaryKey(new Integer(st.cutEachColon(pb[i].toString())));
           ProductRemote ps = phome.findByPrimaryKey(pps.getPid());//(ProductRemote)pb[i];
           //if(st.cutEachColon(pb[i].toString()).equals(pps.getPid().toString()))
           //ProductRemote ptemp = (ProductRemote)pb[i]; // Error
           //if(ptemp.getPid().equals(pps.getPid()))
           //{
             out.println("<td>" + ps.getPid() + "</td>");
             out.println("<td>" + ps.getName() + "</td>");
           //}
         //}
    }
         out.println("</tr>");
         out.println("</table>");



    // ADD Promotion Section ///////////////////////////////////////////////////

    out.print("<form name='form1' method='get' action='../StockWAR/addpromotion'>"
                       +"<h1>"
                       +"<p>Add Promotion Product </p>"
                       +"</h1>"
                       +"<table width='600' border='0' cellspacing='0' cellpadding='0'>"
                       //+"</table>"
                       +"<tr> "
                       +"<td width='30%'> Promotion Product ID</td>"
                       +"<td width='70%'><input type='text' name='textfield'></td>"
                       +"</tr>"
                       +"<tr>"
                       +"<td>Special Price</td>"
                       +"<td><input type='text' name='textfield2'></td>"
                       +"</tr>"

                       +"<tr>"
                       +"<td>Start Date</td>"
                       +"<td>"
                       +"YYYY:<input type='text' name='t1' size='3'>"
                       +"Month:<input type='text' name='t2' size='3'>"
                       +"Day:<input type='text' name='t3' size='3'>"
                       +"HH:<input type='text' name='t4' size='3'>"
                       +"MM:<input type='text' name='t5' size='3'>"
                       //+"SS:<input type='text' name='t6' size='3'>"
                       //+"MS:<input type='text' name='t7' size='3'>"
                       +"</td>"
                       +"</tr>"

                       +"<tr>"
                       +"<td>Stop Date</td>"
                       +"<td>"
                       +"YYYY:<input type='text' name='st1' size='3'>"
                       +"Month:<input type='text' name='st2' size='3'>"
                       +"Day:<input type='text' name='st3' size='3'>"
                       +"HH:<input type='text' name='st4' size='3'>"
                       +"MM:<input type='text' name='st5' size='3'>"
                       //+"SS:<input type='text' name='st6' size='3'>"
                       //+"MS:<input type='text' name='t7' size='3'>"
                       +"</tr>"

                       +"<tr>"
                       +"<td>Promotion Type ID</td>"
                       +"<td><input type='text' name='textfield5'></td>"
                       +"</tr>"

                       +"<tr>"
                       +"<td>Product ID</td>"
                       +"<td><input type='text' name='textfield6'></td>"
                       +"</tr>"

                       +"<tr>"
                       +"<td>&nbsp;</td>"
                       +"<td><input type='submit' name='Submit' value='Submit'>"
                       +"<input type='submit' name='Submit' value='Delete'>"
                       +"<input type='reset' name='Submit2' value='Reset'></td>"
                       +"</tr>"
                       +"</table>"
                       +"</form>"
                       );

        out.println("</br>");
        out.println("<br><a href='../StockWAR/promotionadmin' >Back</a>");

       String ppid = request.getParameter("textfield");
       PromotionproductRemote ppremote;
       boolean haveP = false;
       for (int i = 0; i < ppc.size(); i++) {
         // if ( st.cutEachColon(ppb[i].toString()).equals(ppid) ) haveP = true;
         ppremote = (PromotionproductRemote) ppb[i];
         if (ppremote.getPid().equals(new Integer(ppid)))
           haveP = true;
       }
       if (haveP) {
         out.println("Edit Promotion Product ");
         ppremote = pphome.findByPrimaryKey(new Integer(ppid));
         // name='Submit3' value='del'
         String del = request.getParameter("Submit");
         if (del.equals("Delete"))
           ppremote.remove();
         else {

         }
       }
       else {
         out.println("Add Promotion Product ");
         ppremote = pphome.create(new Integer(ppid));
         // tpremote.setTpid(new Integer(request.getParameter("textfield")));
         ppremote.setSpecialsale(new Integer(request.getParameter("textfield2")));

         //ppremote.setStart(new Timestamp (request.getParameter("textfield3")));
         Integer t1 = new Integer(request.getParameter("t1"));
         Integer t2 = new Integer(request.getParameter("t2"));
         Integer t3 = new Integer(request.getParameter("t3"));
         Integer t4 = new Integer(request.getParameter("t4"));
         Integer t5 = new Integer(request.getParameter("t5"));
         //Integer t6 = new Integer(request.getParameter("t6"));
         //Integer t7 = new Integer(request.getParameter("t7"));

         ppremote.setStart(new Timestamp(
             t1.intValue(),
             t2.intValue() - 1,
             t3.intValue(),
             t4.intValue(),
             t5.intValue(),
             0, //t6.intValue(),
             0 //t7.intValue()
             ));

         Integer st1 = new Integer(request.getParameter("st1"));
         Integer st2 = new Integer(request.getParameter("st2"));
         Integer st3 = new Integer(request.getParameter("st3"));
         Integer st4 = new Integer(request.getParameter("st4"));
         Integer st5 = new Integer(request.getParameter("st5"));
         //Integer st6 = new Integer(request.getParameter("st6"));
         //Integer st7 = new Integer(request.getParameter("st7"));

         ppremote.setStop(new Timestamp(
             st1.intValue(),
             st2.intValue() - 1,
             st3.intValue(),
             st4.intValue(),
             st5.intValue(),
             0, //st6.intValue(),
             0 //st7.intValue()
             ));

         //ppremote.setStart(new Integer(request.getParameter("textfield3")));
         //ppremote.setStop(new Integer(request.getParameter("textfield4")));
         ppremote.setTprid(new Integer(request.getParameter("textfield5")));
         ppremote.setPid(new Integer(request.getParameter("textfield6")));

       }

       //  ///////////////////////////////////////////////////

       //////////////////////////////////////////////////////////
     }
     catch (Throwable t) {
       t.printStackTrace();
     }
     out.println("</body></html>");

   }
  //Clean up resources
  public void destroy() {
  }
}
