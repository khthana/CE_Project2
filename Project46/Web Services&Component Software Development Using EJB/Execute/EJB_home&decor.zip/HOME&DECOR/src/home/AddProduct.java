
package home;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.lang.String;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class AddProduct extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  //Initialize global variables
  public void init() throws ServletException {
  }
  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();

    out.println("<html>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>"
                +"<head><title>Product</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("<h1><p>Product</p></h1>");
    out.println("<table width='75%' border='1' cellpadding='0' cellspacing='0' bordercolor='#CCCCCC'><tr>");
    out.println("<td bgcolor='#66CC99'>ID</td>");
    out.println("<td bgcolor='#66CC99'>NAME</td>");
    out.println("<td bgcolor='#66CC99'>Section</td>");
    out.println("<td bgcolor='#66CC99'>Brand</td>");
    out.println("<td bgcolor='#66CC99'>TypeProduct</td>");
    out.println("<td bgcolor='#66CC99'>TypeUnit</td>");
    out.println("<td bgcolor='#66CC99'>Sale</td>");
    out.println("<td bgcolor='#66CC99'>Barcode</td>");
    out.println("<td bgcolor='#66CC99'>Imageurl</td>");
    out.println("<td bgcolor='#66CC99'>Description</td></tr>");

    try
    {
    // Create Object ///////////////////////////////////
    Context jndiContext = new InitialContext();
    Object obj = jndiContext.lookup("ProductRemote");
    Object obj2 = jndiContext.lookup("StringTools");

    Object objts = jndiContext.lookup("Type_SectionRemote");
    Object objb = jndiContext.lookup("BrandRemote");
    Object objtu = jndiContext.lookup("Type_UnitRemote");
    Object objtp = jndiContext.lookup("Type_ProductRemote");
    ////////////////////////////////////////////////////
    // Create RemoteHome ///////////////////////////////
    ProductRemoteHome home = (ProductRemoteHome)
                              PortableRemoteObject.narrow(obj, ProductRemoteHome.class);
    StringToolsHome sTools = (StringToolsHome)
                              PortableRemoteObject.narrow(obj2, StringToolsHome.class);

    Type_SectionRemoteHome tshome = (Type_SectionRemoteHome)
        PortableRemoteObject.narrow(objts, Type_SectionRemoteHome.class);
    BrandRemoteHome bhome = (BrandRemoteHome)
        PortableRemoteObject.narrow(objb, BrandRemoteHome.class);
    Type_UnitRemoteHome tuhome = (Type_UnitRemoteHome)
        PortableRemoteObject.narrow(objtu, Type_UnitRemoteHome.class);
    Type_ProductRemoteHome tphome = (Type_ProductRemoteHome)
        PortableRemoteObject.narrow(objtp, Type_ProductRemoteHome.class);
    ////////////////////////////////////////////////////
    Collection c = home.findSelectall();
    Object[] b = c.toArray();
    // 1.Add & Edit Product ------------------------------------------------------
    String pid = request.getParameter("textfield");
    ProductRemote premote;
    //premote = home.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
    boolean haveP = false;
    for (int i=0;i<c.size();i++) {
      // if ( st.cutEachColon(b[i].toString()).equals(pid) ) haveP = true;
      premote = (ProductRemote)b[i];
      if (pid != null)
        if ( premote.getPid().equals(new Integer(pid)) ) haveP = true;
      }
    if (haveP) {
      // out.println("Edit Product");
      premote = home.findByPrimaryKey(new Integer(pid));
      // name='Submit3' value='del'
      String del = request.getParameter("Submit3");
      if (del.equals("Delete")) premote.remove();
      else {
        // Update ////////////////////////////////////////

        if (request.getParameter("textfield2").length() != 0) premote.setName(request.getParameter("textfield2"));
        if (request.getParameter("select").length() != 0) premote.setTsid(new Integer(request.getParameter("select")));
        if (request.getParameter("select2").length() != 0) premote.setBid(new Integer(request.getParameter("select2")));
        if (request.getParameter("select3").length() != 0) premote.setTpid(new Integer(request.getParameter("select3")));
        if (request.getParameter("select4").length() != 0) premote.setTuid(new Integer(request.getParameter("select4")));
        if (request.getParameter("textfield6").length() != 0) premote.setSaleavg(new Float(request.getParameter("textfield6")));
        if (request.getParameter("textfield3").length() != 0) premote.setBarcode(request.getParameter("textfield3"));
        if (request.getParameter("textfield4").length() != 0) premote.setImageurl(request.getParameter("textfield4"));
        if (request.getParameter("textfield5").length() != 0) premote.setDescription(request.getParameter("textfield5"));

      }
    } else {
      if (/*request.getParameter("Submit").equals("Submit") && */ pid != null) {
        //out.println("Add Product");
        premote = home.create(new Integer(pid));
        premote.setName(request.getParameter("textfield2"));
        premote.setTsid(new Integer(request.getParameter("select")));
        premote.setBid(new Integer(request.getParameter("select2")));
        premote.setTpid(new Integer(request.getParameter("select3")));
        premote.setTuid(new Integer(request.getParameter("select4")));
        premote.setSaleavg(new Float(request.getParameter("textfield6")));
        premote.setBarcode(request.getParameter("textfield3"));
        premote.setImageurl(request.getParameter("textfield4"));
        premote.setDescription(request.getParameter("textfield5"));
      }

    }
    //////////////////////////////////////////////////////////

    c = home.findSelectall();
    b = c.toArray();
    Collection cts = tshome.findSelectall();
    Object[] bts = cts.toArray();
    Collection cb = bhome.findSelectall();
    Object[] bb = cb.toArray();
    Collection ctu = tuhome.findSelectall();
    Object[] btu = ctu.toArray();
    Collection ctp = tphome.findSelectall();
    Object[] btp = ctp.toArray();

    StringTools st = sTools.create();


    // 2.Display Table Product
    for (int j=0;j<c.size();j++){
      // ProductRemote premote = home.findByPrimaryKey(new Integer(st.cutEachColon(b[j].toString())));
	  premote = (ProductRemote)b[j];
      Type_SectionRemote tsremote = tshome.findByPrimaryKey(premote.getTsid());
      BrandRemote bremote = bhome.findByPrimaryKey(premote.getBid());
      Type_UnitRemote turemote = tuhome.findByPrimaryKey(premote.getTuid());
      Type_ProductRemote tpremote = tphome.findByPrimaryKey(premote.getTpid());

      out.println("<tr>");
      out.println("<td>"+premote.getPid()+"</td>");
      out.println("<td>"+premote.getName()+"</td>");
      out.println("<td>"+tsremote.getNamesection()+"</td>");
      out.println("<td>"+bremote.getBrandname()+"</td>");
      out.println("<td>"+tpremote.getTypeproductname()+"</td>");
      out.println("<td>"+turemote.getTypeunitname()+"</td>");
      out.println("<td>"+premote.getSaleavg()+"</td>");
      out.println("<td>"+premote.getBarcode()+"</td>");
      out.println("<td>'"+premote.getImageurl()+"'</td>");
      out.println("<td>"+premote.getDescription()+"</td>");
      out.println("</tr>");

    }
    out.println("</table>");
    out.println("<br></br>");
    // AddProduct and Edit Product /////////////////////////////////////////////
    out.print("<form name='form1' method='get' action='../StockWAR/addproduct'>"
              +"<h1>"
              +"<p>Add&amp;Edit Product</p>"
              +"</h1>"
              +"<br></br>"
              +"<table width='500' border='0' cellspacing='0' cellpadding='0'>"
              +"<tr> "
              +"<td width='25%'>ProductID</td>"
              +"<td width='75%'><input type='text' name='textfield'></td>"
              +"</tr>"
              +"<tr>"
              +"<td>Name</td>"
              +"<td><input type='text' name='textfield2'></td>"
              +"</tr>"
              +"<tr>"
              +"<td>NameSection</td>"
              +"<td><select name='select'>");
    for (int j=0;j<cts.size();j++) {
      // Type_SectionRemote tsremote = tshome.findByPrimaryKey(new Integer(st.cutEachColon(bts[j].toString())));
	  Type_SectionRemote tsremote = (Type_SectionRemote)bts[j];
      out.print("<option value='"+tsremote.getTsid()+"'>"+tsremote.getNamesection()+"</option>");
      //+"<option value='a'>test1</option>"
      //+"<option value='b'>test2</option>"
    }
    out.print(  "</select></td>"
                +"</tr>"
                +"<tr>"
                +"<td>BrandName</td>"
                +"<td><select name='select2'>");
    for (int j=0;j<cb.size();j++) {
      // BrandRemote bremote = bhome.findByPrimaryKey(new Integer(st.cutEachColon(bb[j].toString())));
	  BrandRemote bremote = (BrandRemote)bb[j];
      out.print("<option value='"+bremote.getBid()+"'>"+bremote.getBrandname()+"</option>");
      //+"<option value='a'>test1</option>"
      //+"<option value='b'>test2</option>"
    }
    out.print(  "</select></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Typeproductname</td>"
                +"<td><select name='select3'>");
    for (int j=0;j<ctp.size();j++) {
      // Type_ProductRemote tpremote = tphome.findByPrimaryKey(new Integer(st.cutEachColon(btp[j].toString())));
	  Type_ProductRemote tpremote = (Type_ProductRemote)btp[j];
      out.print("<option value='"+tpremote.getTpid()+"'>"+tpremote.getTypeproductname()+"</option>");
      //+"<option value='a'>test1</option>"
      //+"<option value='b'>test2</option>"
    }

    out.print(  "</select></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Typeunitname</td>"
                +"<td><select name='select4'>");
    for (int j=0;j<ctu.size();j++) {
      // Type_UnitRemote turemote = tuhome.findByPrimaryKey(new Integer(st.cutEachColon(btu[j].toString())));
	  Type_UnitRemote turemote = (Type_UnitRemote)btu[j];
      out.print("<option value='"+turemote.getTuid()+"'>"+turemote.getTypeunitname()+"</option>");
      //+"<option value='a'>test1</option>"
      //+"<option value='b'>test2</option>"
    }
    out.print(  "</select></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Saleavg</td>"
                +"<td><input type='text' name='textfield6'></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Barcode</td>"
                +"<td><input type='text' name='textfield3'></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Imageurl</td>"
                +"<td><input type='text' name='textfield4'></td>"
                +"</tr>"
                +"<tr>"
                +"<td>Description</td>"
                +"<td><input type='text' name='textfield5'></td>"
                +"</tr>"
                +"<tr>"
                +"<td>&nbsp;</td>"
                +"<td><input type='submit' name='Submit' value='Submit'>"
                +"<input type='reset' name='Submit2' value='Reset'>"
                +"<input type='submit' name='Submit3' value='Update'>"
                +"<input type='submit' name='Submit3' value='Delete'></td>"
                +"</tr>"
                +"</table>"
                +"<h1>"
                +"<p>&nbsp;</p>"
                +"</h1>"
                +"</form>");

  }
  catch (Throwable t) { t.printStackTrace(); }

  out.println("</table>");
  /*
  out.println("<br>"+request.getParameter("textfield"));   // pid
  out.println("<br>"+request.getParameter("textfield2"));  // Name
  out.println("<br>"+request.getParameter("select"));      // NameSection
  out.println("<br>"+request.getParameter("select2"));     // BrandName
  out.println("<br>"+request.getParameter("select3"));     // Typeproductname
  out.println("<br>"+request.getParameter("select4"));     // Typeunitname
  out.println("<br>"+request.getParameter("textfield6"));  // Saleavg
  out.println("<br>"+request.getParameter("textfield3"));  // BarCode
  out.println("<br>"+request.getParameter("textfield4"));  // Imageurl
  out.println("<br>"+request.getParameter("textfield5"));  // Description
  */
  out.println("</body></html>");
}
//Clean up resources
public void destroy() {
}
}