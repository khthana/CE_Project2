package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface KeepSessionRemote extends javax.ejb.EJBObject {
  public Integer getBucid() throws RemoteException;
  public void setMid(Integer mid) throws RemoteException;
  public Integer getMid() throws RemoteException;
  public void setPid(Integer pid) throws RemoteException;
  public Integer getPid() throws RemoteException;
  public void setNumber(Integer number) throws RemoteException;
  public Integer getNumber() throws RemoteException;
  public void setDate(Timestamp date) throws RemoteException;
  public Timestamp getDate() throws RemoteException;
}