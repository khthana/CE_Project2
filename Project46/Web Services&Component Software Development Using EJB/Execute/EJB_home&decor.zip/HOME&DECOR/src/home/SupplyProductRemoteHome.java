package home;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface SupplyProductRemoteHome extends javax.ejb.EJBHome {
  public SupplyProductRemote create(Integer spid) throws CreateException, RemoteException;
  public Collection findSelectall() throws FinderException, RemoteException;
  public SupplyProductRemote findByPrimaryKey(Integer spid) throws FinderException, RemoteException;
}