package home;

import javax.ejb.*;

abstract public class ProductplaceBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer ppid) throws CreateException {
    setPpid(ppid);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer ppid) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setPpid(java.lang.Integer ppid);
  public abstract void setPlid(java.lang.Integer plid);
  public abstract void setPid(java.lang.Integer pid);
  public abstract void setRemain(java.lang.Integer remain);
  public abstract void setLimitbuy(java.lang.Integer limitbuy);
  public abstract java.lang.Integer getPpid();
  public abstract java.lang.Integer getPlid();
  public abstract java.lang.Integer getPid();
  public abstract java.lang.Integer getRemain();
  public abstract java.lang.Integer getLimitbuy();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}