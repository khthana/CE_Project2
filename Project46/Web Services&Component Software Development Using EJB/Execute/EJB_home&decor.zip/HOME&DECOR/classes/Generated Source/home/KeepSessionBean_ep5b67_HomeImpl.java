/**
* This code was automatically generated at 17:11:23 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
public final class KeepSessionBean_ep5b67_HomeImpl
extends    weblogic.ejb20.internal.EntityEJBHome
implements home.KeepSessionRemoteHome, weblogic.utils.PlatformConstants
, weblogic.ejb.QueryHome
{
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setNumber_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getBucid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getDate;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getMid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setMid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setDate_java_sql_Timestamp;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getNumber;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbCreate_I;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindByPrimaryKey_I;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindSelectall;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindbucidByPM_II;
  
  
  
  private static java.lang.reflect.Method mth_ejbCreate_I;
  private static java.lang.reflect.Method mth_postejbCreate_I;
  
  
  
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_eo_remove;
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_javax_ejb_Handle;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_O;
  
  static {
    
    try {
      
      
      mth_ejbCreate_I = KeepSessionBean.class.getMethod(
      "ejbCreate", new Class [] {java.lang.Integer.class});
      
      if (true) {
        mth_postejbCreate_I = KeepSessionBean.class.getMethod(
        "ejbPostCreate", new Class [] {java.lang.Integer.class}); 
      }
      
      
      
      
      
    } catch (Exception e) {
      throw new weblogic.utils.AssertionError("Unable to find expected "+
      "methods.  Please check your classpath for stale versions of "+
      "your ejb classes and re-run weblogic.ejbc");
    }
  }
  
  
  public KeepSessionBean_ep5b67_HomeImpl() {
    super(KeepSessionBean_ep5b67_EOImpl.class
    , java.lang.Integer.class);
  }
  
  
  public home.KeepSessionRemote create (java.lang.Integer arg0)
  throws javax.ejb.CreateException, java.rmi.RemoteException
  {
    try {
      return (home.KeepSessionRemote) super.create(md_ejbCreate_I,
      mth_ejbCreate_I, mth_postejbCreate_I, 
      new Object [] {  arg0});
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.CreateException) {
        throw (javax.ejb.CreateException) e;
      }
      else {
        throw new javax.ejb.CreateException ("Error while creating bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  public home.KeepSessionRemote findByPrimaryKey(java.lang.Integer arg0)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (home.KeepSessionRemote)
      super.findByPrimaryKey(md_ejbFindByPrimaryKey_I,  arg0 );
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  public java.util.Collection findSelectall()
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (java.util.Collection)
      super.finder(md_ejbFindSelectall, new Object [] { } , weblogic.ejb20.internal.EntityEJBHome.COLL_FINDER);
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  public java.util.Collection findbucidByPM(java.lang.Integer arg0,java.lang.Integer arg1)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (java.util.Collection)
      super.finder(md_ejbFindbucidByPM_II, new Object [] {  arg0, arg1} , weblogic.ejb20.internal.EntityEJBHome.COLL_FINDER);
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  
  
  public void remove(java.lang.Object pk) 
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_O, pk);
  }
  
  public void remove(javax.ejb.Handle h)
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_javax_ejb_Handle, h);
  }
  
  
}

