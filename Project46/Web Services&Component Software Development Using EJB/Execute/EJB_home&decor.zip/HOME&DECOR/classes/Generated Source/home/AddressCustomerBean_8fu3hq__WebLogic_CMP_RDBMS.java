/**
* This code was automatically generated at 17:11:24 on 21 ��.�. 2547
* by weblogic.ejb20.cmp.rdbms.codegen.RDBMSCodeGenerator -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.IOException;
import java.sql.PreparedStatement;
import javax.ejb.EntityContext;
import javax.ejb.EJBException;
import javax.ejb.EJBObject;
import javax.ejb.ObjectNotFoundException;
import javax.ejb.NoSuchEntityException;
import javax.ejb.Handle;
import javax.ejb.HomeHandle;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NameClassPair;
import javax.rmi.PortableRemoteObject;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import weblogic.ejb.OptimisticConcurrencyException;
import weblogic.ejb20.EJBTextTextFormatter;
import weblogic.ejb20.InternalException;
import weblogic.ejb20.internal.EJBRuntimeUtils;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
import weblogic.ejb20.interfaces.CachingManager;
import weblogic.ejb20.persistence.RSInfoImpl;
import weblogic.ejb20.persistence.spi.CMPBean;
import weblogic.ejb20.persistence.spi.CMPBeanManager;
import weblogic.ejb20.persistence.spi.PersistenceManager;
import weblogic.ejb20.persistence.spi.PersistenceRuntimeException;
import weblogic.ejb20.persistence.spi.RSInfo;

import weblogic.ejb20.cmp.rdbms.RDBMSObjectInputStream;
import weblogic.ejb20.cmp.rdbms.RDBMSPersistenceManager;
import weblogic.ejb20.cmp.rdbms.RDBMSException;
import weblogic.ejb20.cmp.rdbms.RDBMSUtils;
import weblogic.ejb20.cmp.rdbms.RDBMSM2NSet;
import weblogic.ejb20.cmp.rdbms.RDBMSSet;
import weblogic.ejb20.dd.DDConstants;

import javax.transaction.TransactionManager;
import javax.transaction.Transaction;
import weblogic.transaction.TxHelper;

import weblogic.utils.AssertionError;
import weblogic.utils.Debug;

public final class AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS extends home.AddressCustomerBean
implements CMPBean
{
  // =================================================================
  // Class  variable(s)
  private static final boolean __WL_debug =
  (System.getProperty(RDBMSUtils.RDBMS_CODEGEN_DEBUG_PROP) != null);
  private static final boolean __WL_verbose =
  (System.getProperty(RDBMSUtils.RDBMS_CODEGEN_VERBOSE_PROP) != null);
  
  private static String EOL = System.getProperty("line.separator");
  
  
  
  private javax.ejb.EJBContext __WL_EJBContext;
  
  private int __WL_method_state;
  
  private short __WL_bean_state;
  
  private boolean __WL_busy = false;
  
  private boolean __WL_isLocal = true;
  
  private boolean __WL_needsRemove;
  
  private boolean __WL_creatorOfTx;
  
  private Object __WL_loadUser;
  
  private int __WL_offset = 0;
  
  
  public javax.transaction.Transaction __WL_getBeanManagedTransaction() {
    throw new AssertionError("Entity beans can't have"
    + " bean-managed transactions");
  }
  
  public void __WL_setBeanManagedTransaction(javax.transaction.Transaction tx) {
    throw new AssertionError("Entity beans can't have"
    + " bean-managed transactions");
    
  }
  
  
  public boolean __WL_isBusy() { return __WL_busy; }
  public void __WL_setBusy(boolean b) { __WL_busy = b; }
  
  public boolean __WL_getIsLocal() { return __WL_isLocal; }
  public void __WL_setIsLocal(boolean b) { __WL_isLocal = b; }
  
  public int __WL_getMethodState() { return __WL_method_state; }
  public void __WL_setMethodState(int state) { __WL_method_state = state; }
  
  public boolean __WL_needsRemove() { return __WL_needsRemove; }
  public void __WL_setNeedsRemove(boolean b) { __WL_needsRemove = b; }
  
  public void __WL_setCreatorOfTx ( boolean b) { __WL_creatorOfTx = b; }
  public boolean __WL_isCreatorOfTx() { return __WL_creatorOfTx; }
  
  public javax.ejb.EJBContext __WL_getEJBContext() { return __WL_EJBContext; }
  public void __WL_setEJBContext(javax.ejb.EJBContext ctx) {
    __WL_EJBContext = ctx;
  }
  
  public void __WL_setLoadUser(Object o) { __WL_loadUser = o;}
  public Object __WL_getLoadUser() { return __WL_loadUser; } 
  
  
  // =================================================================
  // ejbSelect Methods Defined on CMR Beans
  
  
  
  // =================================================================
  // Instance variable(s)
  private EntityContext __WL_ctx;
  private RDBMSPersistenceManager __WL_pm;
  private ClassLoader __WL_classLoader;
  
  
  public java.lang.Integer amid;
  public java.lang.Integer cid;
  public java.lang.String address;
  
  
  
  
  
  
  
  
  private boolean[] __WL_isModified = new boolean[3];
  private boolean __WL_modifiedBeanIsRegistered= false;
  
  private boolean __WL_invalidatedBeanIsRegistered= false;
  
  private boolean[] __WL_isLoaded = new boolean[3];
  private boolean __WL_beanIsLoaded= false;
  
  
  // for remote relationships
  
  
  
  // =================================================================
  // Constructor(s)
  public AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS()  {
    super();
    
    __WL_initialize();
    
    
  }
  
  // This method is called by ejbLoad, ejbPassivate, and ejbRemove
  // to initialize the persistent state of the bean and its associated
  // variables.
  public void __WL_initialize()
  {
    __WL_initialize_persistent();
    
    __WL_beanIsLoaded = false;
    __WL_modifiedBeanIsRegistered = false;
    
    
    //cached relationship state
    
    
  }
  
  private void __WL_initialize_persistent()
  {
    for (int __WL_i = 0; __WL_i < 3; __WL_i++) {
      __WL_isLoaded[__WL_i] = false;
      __WL_isModified[__WL_i] = false;
    }
    
    
    
    address = null;
    cid = null;
    amid = null;
    
    
  }
  
  // ================================================================
  // Method(s)
  public void setEntityContext(javax.ejb.EntityContext arg0) {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_SET_CONTEXT;
      super.setEntityContext(arg0);
      this.__WL_ctx = arg0;
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  public void unsetEntityContext()
  
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_UNSET_CONTEXT;
      super.unsetEntityContext();
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  public void ejbActivate()
  
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_ACTIVATE;
      super.ejbActivate();
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  
  // ================================================================
  // Getter and Setter methods.
  public java.lang.Integer getAmid()
  {
    try {
      if (!(__WL_isLoaded[0] || __WL_isModified[0])) {
        __WL_loadGroup0();
      }
      
      return amid;
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
  }
  public void setAmid(
  java.lang.Integer amid)
  {
    if (__WL_method_state!=STATE_EJB_CREATE) {
      throw new IllegalStateException("The setXXX method for a primary key field may only be called during ejbCreate.");
    }
    
    this.amid = amid;
    __WL_isModified[0] = true;
    if (! __WL_modifiedBeanIsRegistered) {
      __WL_pm.registerModifiedBean(__WL_ctx.getPrimaryKey());
      __WL_modifiedBeanIsRegistered = true;
    }
    
    
  }
  
  public java.lang.Integer getCid()
  {
    try {
      if (!(__WL_isLoaded[1] || __WL_isModified[1])) {
        __WL_loadGroup0();
      }
      
      return cid;
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
  }
  public void setCid(
  java.lang.Integer cid)
  {
    if ((this.cid == cid || (this.cid!=null && this.cid.equals(cid))) && __WL_isLoaded[1]) return;
    
    this.cid = cid;
    __WL_isModified[1] = true;
    if (! __WL_modifiedBeanIsRegistered) {
      __WL_pm.registerModifiedBean(__WL_ctx.getPrimaryKey());
      __WL_modifiedBeanIsRegistered = true;
    }
    
    
  }
  
  public java.lang.String getAddress()
  {
    try {
      if (!(__WL_isLoaded[2] || __WL_isModified[2])) {
        __WL_loadGroup0();
      }
      
      return address;
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
  }
  public void setAddress(
  java.lang.String address)
  {
    if ((this.address == address || (this.address!=null && this.address.equals(address))) && __WL_isLoaded[2]) return;
    
    this.address = address;
    __WL_isModified[2] = true;
    if (! __WL_modifiedBeanIsRegistered) {
      __WL_pm.registerModifiedBean(__WL_ctx.getPrimaryKey());
      __WL_modifiedBeanIsRegistered = true;
    }
    
    
  }
  
  
  
  
  
  //=================================================================
  //Finder methods.
  public java.util.Collection ejbFindSelectall() throws javax.ejb.FinderException
  {
    if(__WL_verbose) {
      Debug.say("called findSelectall");
    }
    
    java.sql.Connection __WL_con = null;
    java.sql.PreparedStatement __WL_stmt = null;
    java.sql.ResultSet __WL_rs = null;
    
    
    
    int selectForUpdateVal = __WL_pm.getSelectForUpdateValue();
    
    java.lang.String __WL_query = null;
    switch(selectForUpdateVal) {
      case DDConstants.SELECT_FOR_UPDATE_DISABLED:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0 ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0  FOR UPDATE ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE_NO_WAIT:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0  FOR UPDATE NOWAIT ";
      break;
      
      default:
      throw new AssertionError(
      "Unknown selectForUpdate type: '"+selectForUpdateVal+"'");
    }
    if(__WL_verbose) {
      Debug.say("Finder produced statement string " + __WL_query);
    }
    
    
    
    
    try {
      __WL_con = __WL_pm.getConnection();
    } 
    catch (java.lang.Exception e) {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
      throw new javax.ejb.FinderException("Couldn't get connection: " + EOL +
      e.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(e));
    }
    
    
    
    try {
      
      __WL_stmt = __WL_con.prepareStatement(__WL_query);
      
      
      // preparedStatementParamIndex reset.
      
      
      
      __WL_rs = __WL_stmt.executeQuery();
    } 
    catch (java.lang.Exception e) {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
      throw new javax.ejb.FinderException(
      "Exception in findSelectall while preparing or executing " +
      "statement: '" + __WL_stmt + "'" + EOL +
      e.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(e));
    }
    
    try {
      java.util.Collection __WL_collection = new java.util.ArrayList();
      home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS __WL_bean = null;
      Object __WL_eo = null;
      Object __WL_eo_rc = null;
      
      
      Map __WL_pkMap = new HashMap();
      
      while (__WL_rs.next()) {
        
        Integer __WL_offsetIntObj = new Integer(0);
        Object __WL_pk = __WL_getPKFromRS(__WL_rs, __WL_offsetIntObj, __WL_classLoader);
        __WL_eo = null;
        if (__WL_pk != null) { 
          RSInfo __WL_rsInfo = new RSInfoImpl(__WL_rs, 0, 0, __WL_pk);
          __WL_bean = (home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS)__WL_pm.getBeanFromRS(__WL_pk, __WL_rsInfo);
          
          __WL_eo = __WL_pm.finderGetEoFromBeanOrPk(__WL_bean, __WL_pk, __WL_getIsLocal());
          if (__WL_verbose) Debug.say("bean after finder load: " + __WL_bean);
          __WL_collection.add(__WL_eo);
          Object __WL_retVal = __WL_pkMap.put(__WL_pk, __WL_bean);
        }
        
        
      }
      return __WL_collection;
      
    } catch (java.sql.SQLException sqle) {
      throw new javax.ejb.FinderException(
      "Exception in 'findSelectall' while using " +
      "result set: '" + __WL_rs + "'" + EOL +
      sqle.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(sqle));
    } catch (java.lang.Exception e) {
      throw new javax.ejb.FinderException(
      "Exception executing finder 'findSelectall': " + EOL +
      e.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(e));
    } finally {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
    }
    
  }
  
  public java.lang.Object ejbFindByPrimaryKey(java.lang.Integer param0) throws javax.ejb.FinderException
  {
    if(__WL_verbose) {
      Debug.say("called findByPrimaryKey.");
    }
    
    java.sql.Connection __WL_con = null;
    java.sql.PreparedStatement __WL_stmt = null;
    java.sql.ResultSet __WL_rs = null;
    home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS __WL_bean = null;
    Object __WL_eo = null;
    Object __WL_eo_rc = null;
    
    
    
    
    int selectForUpdateVal = __WL_pm.getSelectForUpdateValue();
    
    java.lang.String __WL_query = null;
    
    switch(selectForUpdateVal) {
      case DDConstants.SELECT_FOR_UPDATE_DISABLED:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0  WHERE ( (WL0.amid = ?) ) ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0  WHERE ( (WL0.amid = ?) )  FOR UPDATE ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE_NO_WAIT:
      __WL_query = "SELECT WL0.amid, WL0.address, WL0.cid  FROM address_customer WL0  WHERE ( (WL0.amid = ?) )  FOR UPDATE NOWAIT ";
      break;
      
      default:
      throw new AssertionError(
      "Unknown selectForUpdate type: '"+selectForUpdateVal+"'");
    }
    
    if(__WL_verbose) {
      Debug.say("Finder produced statement string " + __WL_query);
    }
    
    
    
    try {
      __WL_con = __WL_pm.getConnection();
    } 
    catch (java.lang.Exception e) {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
      throw new javax.ejb.FinderException("Couldn't get connection: " + EOL +
      e.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(e));
    }
    
    
    
    try {
      
      __WL_stmt = __WL_con.prepareStatement(__WL_query);
      // preparedStatementParamIndex reset.
      
      if (param0 == null) {
        __WL_stmt.setNull(1,java.sql.Types.INTEGER);
      } else {
        __WL_stmt.setInt(1, param0.intValue());
        if (__WL_verbose) {
          Debug.say("paramIdx :"+1+" binded with value :"+param0);
        }
      }
      
      __WL_rs = __WL_stmt.executeQuery();
      
      
      Map __WL_pkMap = new HashMap();
      
      boolean __WL_isMulti = false;
      while (__WL_rs.next()) {
        
        Integer __WL_offsetIntObj = new Integer(0);
        Object __WL_pk = __WL_getPKFromRS(__WL_rs, __WL_offsetIntObj, __WL_classLoader);
        __WL_eo = null;
        if (__WL_pk != null) { 
          __WL_bean = (home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS)__WL_pm.getBeanFromPool();
          __WL_bean.__WL_initialize();
          __WL_bean = __WL_loadGroup0FromRS(__WL_rs, __WL_offsetIntObj, __WL_pk, __WL_bean);
          
          __WL_eo = __WL_pm.finderCacheInsert(__WL_bean, __WL_getIsLocal());
          if (__WL_verbose) Debug.say("bean after finder load: " + __WL_bean);
          Object __WL_retVal = __WL_pkMap.put(__WL_pk, __WL_bean);
          if (__WL_retVal!=null) __WL_isMulti=true;
        }
        
        
      }
      
      if (__WL_pkMap.size() == 0) {
        if(__WL_verbose) {
          Debug.say("Throwing FinderException because bean wasn't found.");
        }
        throw new javax.ejb.ObjectNotFoundException("Bean with primary key '" + param0.toString() + "' was not found by 'findByPrimaryKey'.");
      }
      if (__WL_isMulti || __WL_pkMap.size() > 1) {
        throw new javax.ejb.FinderException("finder/ejbSelect 'findByPrimaryKey'" +
        "has returned more than one value.  We were expecting only ONE value. "+
        " See EJB Spec 10.5.6.1, 10.5.7.1");
      }
      return __WL_eo;
    } catch (javax.ejb.FinderException fe) {
      throw fe;
    } catch (java.sql.SQLException sqle) {
      throw new javax.ejb.FinderException(
      "Problem in findByPrimaryKey while preparing or executing " +
      "statement: '" +
      __WL_stmt + "': " + EOL +
      sqle.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(sqle));
    } catch (Exception e) {
      throw new javax.ejb.FinderException(
      "Exception raised in findByPrimaryKey " + EOL +
      e.toString() + EOL +
      RDBMSUtils.throwable2StackTrace(e));
    } finally {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
    }
    
  }
  
  
  
  
  // loadGroup method for the 'defaultGroup' group.
  public void __WL_loadGroup0() throws Exception {
    java.sql.Connection __WL_con = null;
    java.sql.PreparedStatement __WL_stmt = null;
    java.sql.ResultSet __WL_rs = null;
    
    int selectForUpdateVal = __WL_pm.getSelectForUpdateValue();
    
    java.lang.String __WL_query;
    
    // http://bugs.beasys.com/CRView?CR=CR070260
    //
    //  optimization.
    
    switch(selectForUpdateVal) {
      case DDConstants.SELECT_FOR_UPDATE_DISABLED:
      __WL_query = "SELECT WL0.address, WL0.amid, WL0.cid  FROM address_customer WL0  WHERE WL0.amid = ? ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE:
      __WL_query = "SELECT WL0.address, WL0.amid, WL0.cid  FROM address_customer WL0  WHERE WL0.amid = ?  FOR UPDATE ";
      break;
      
      case DDConstants.SELECT_FOR_UPDATE_NO_WAIT:
      __WL_query = "SELECT WL0.address, WL0.amid, WL0.cid  FROM address_customer WL0  WHERE WL0.amid = ?  FOR UPDATE NOWAIT ";
      break;
      
      default:
      throw new AssertionError(
      "Unknown selectForUpdate type: '"+selectForUpdateVal+"'");
    }
    
    
    
    try {
      if (__WL_verbose) {
        Debug.say("__WL_loadGroup0 for pk=" + __WL_ctx.getPrimaryKey());
      }
      
      java.lang.Integer __WL_pk = (java.lang.Integer) __WL_ctx.getPrimaryKey();
      
      __WL_con = __WL_pm.getConnection();
      
      
      __WL_stmt = __WL_con.prepareStatement(__WL_query);
      
      // preparedStatementParamIndex reset.
      
      if(!__WL_pm.setParamNull(__WL_stmt, 1, __WL_pk, "amid")) {
        __WL_stmt.setInt(1, __WL_pk.intValue());
        if (__WL_verbose) {
          Debug.say("paramIdx :"+1+" binded with value :"+__WL_pk);
        }
      }
      
      
      if (__WL_verbose) {
        Debug.say("__WL_loadGroup0 for pk=" + __WL_ctx.getPrimaryKey() + 
        ", executeQuery: "+__WL_query);
      }
      
      __WL_rs = __WL_stmt.executeQuery();
      if (__WL_rs.next()) {
        
        if (__WL_verbose) {
          Debug.say("__WL_loadGroup0 for pk=" + __WL_ctx.getPrimaryKey() + 
          " now read columns from Results.");
        }
        
        
        if (!(this.__WL_isLoaded[2] || this.__WL_isModified[2])) {
          this.address = (java.lang.String)__WL_rs.getString(1+__WL_offset);
          if (__WL_rs.wasNull()) { 
            this.address = null;
          }
        }
        else {
          __WL_rs.getString(1+__WL_offset);
        }
        if (!(this.__WL_isLoaded[0] || this.__WL_isModified[0])) {
          this.amid = new Integer(__WL_rs.getInt(2+__WL_offset));
          if (__WL_rs.wasNull()) { 
            this.amid = null;
          }
        }
        else {
          __WL_rs.getInt(2+__WL_offset);
        }
        if (!(this.__WL_isLoaded[1] || this.__WL_isModified[1])) {
          this.cid = new Integer(__WL_rs.getInt(3+__WL_offset));
          if (__WL_rs.wasNull()) { 
            this.cid = null;
          }
        }
        else {
          __WL_rs.getInt(3+__WL_offset);
        }
        this.__WL_isLoaded[2] = true;
        this.__WL_isLoaded[0] = true;
        this.__WL_isLoaded[1] = true;
        this.__WL_beanIsLoaded = true;
        
        
        __WL_beanIsLoaded = true;
      } else {
        if(__WL_verbose) {
          Debug.say("__WL_loadGroup0 could not find primary key " +
          __WL_pk);
        }
        throw new NoSuchEntityException("Bean with " +
        "primary key: '" + __WL_pk + "' not found.");
      }
    } finally {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
    }
    
    
  }
  
  
  // loadGroup from ResultSet to bean method for the 'defaultGroup' group.
  public home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS
  __WL_loadGroup0FromRS
  (java.sql.ResultSet __WL_rs, 
  java.lang.Integer __WL_offsetIntObj, 
  Object __WL_pk,
  home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS __WL_bean)
  throws java.sql.SQLException, java.lang.Exception
  {
    if (__WL_verbose) {
      Debug.say("__WL_loadGroup0FromRS");
    }
    
    int __WL_offset = __WL_offsetIntObj.intValue();
    
    if (__WL_pk == null) {
      if (!(__WL_bean.__WL_isLoaded[0] || __WL_bean.__WL_isModified[0])) {
        __WL_bean.amid = new Integer(__WL_rs.getInt(1+__WL_offset));
        if (__WL_rs.wasNull()) { 
          __WL_bean.amid = null;
        }
      }
      else {
        __WL_rs.getInt(1+__WL_offset);
      }
    } else {
      __WL_bean.__WL_setPrimaryKey((java.lang.Integer) __WL_pk);
    }
    if (!(__WL_bean.__WL_isLoaded[2] || __WL_bean.__WL_isModified[2])) {
      __WL_bean.address = (java.lang.String)__WL_rs.getString(2+__WL_offset);
      if (__WL_rs.wasNull()) { 
        __WL_bean.address = null;
      }
    }
    else {
      __WL_rs.getString(2+__WL_offset);
    }
    if (!(__WL_bean.__WL_isLoaded[1] || __WL_bean.__WL_isModified[1])) {
      __WL_bean.cid = new Integer(__WL_rs.getInt(3+__WL_offset));
      if (__WL_rs.wasNull()) { 
        __WL_bean.cid = null;
      }
    }
    else {
      __WL_rs.getInt(3+__WL_offset);
    }
    __WL_bean.__WL_isLoaded[2] = true;
    __WL_bean.__WL_isLoaded[0] = true;
    __WL_bean.__WL_isLoaded[1] = true;
    __WL_bean.__WL_beanIsLoaded = true;
    
    return __WL_bean;
  }
  
  
  
  public static Object __WL_getPKFromRS(java.sql.ResultSet __WL_rs, java.lang.Integer __WL_offsetIntObj, ClassLoader __WL_classLoader)
  throws java.sql.SQLException, java.lang.Exception
  {
    if (__WL_verbose) {
      Debug.say("__WL_getPKFromRS");
    }
    
    int __WL_offset = __WL_offsetIntObj.intValue();
    
    java.lang.Integer __WL_pk = null;
    
    __WL_pk = new Integer(__WL_rs.getInt(1+__WL_offset));
    if (__WL_rs.wasNull()) { 
      __WL_pk = null;
    }
    
    
    return __WL_pk;
  }
  
  public Object __WL_getPKFromRSInstance(java.sql.ResultSet __WL_rs, java.lang.Integer __WL_offsetIntObj, ClassLoader __WL_classLoader)
  throws java.sql.SQLException, java.lang.Exception
  {
    return __WL_getPKFromRS(__WL_rs, __WL_offsetIntObj, __WL_classLoader);
  }
  
  //End finder methods.
  //=================================================================
  
  //=================================================================
  //Home methods.
  
  
  //End home methods.
  //=================================================================
  
  //=================================================================
  // ejbSelect methods defined in this Bean's abstract class
  
  
  
  
  //=================================================================
  // ejbSelectInternal methods that are to run in this Bean
  
  
  
  
  
  //=================================================================
  
  // ================================================================
  // Implementation of CMPBean
  public void __WL_setup(java.util.Map bmMap, PersistenceManager __WL_pm) {
    if (__WL_verbose) {
      Debug.say("AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS.setup called.");
    }
    if (__WL_debug) {
      Debug.assertion(bmMap!=null);
      Debug.assertion(__WL_pm !=null);
    }
    this.__WL_pm = (RDBMSPersistenceManager)__WL_pm; 
    this.__WL_classLoader = this.__WL_pm.getClassLoader();
    if (__WL_debug) {
      Debug.assertion(this.__WL_classLoader != null);
    }
    
    
  }
  
  public EntityContext __WL_getEntityContext() {
    return __WL_ctx;
  }
  
  public Object __WL_getPrimaryKey() {
    java.lang.Integer __WL_pk = null;
    
    __WL_pk = this.amid;
    return __WL_pk;
    
  }
  
  public void __WL_setPrimaryKey(java.lang.Integer __WL_pk) {
    this.amid = __WL_pk;
    
  }
  
  public void __WL_superEjbLoad()  {
    int oldState = __WL_method_state;
    
    try {
      __WL_method_state = STATE_EJBLOAD;
      super.ejbLoad();
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  public void __WL_copyFrom(CMPBean otherBean) {
    AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS __WL_bean = null;
    try {
      __WL_bean = (AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS)otherBean;
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    if (!(this.__WL_isLoaded[0] || this.__WL_isModified[0])) {
      if (__WL_bean.__WL_isLoaded[0]) {
        if (__WL_verbose) {
          Debug.say("copying field 'amid' to bean '" +
          __WL_bean.__WL_getPrimaryKey() + "'.");
        }
        this.amid = __WL_bean.amid;
        this.__WL_isLoaded[0] = true;
      }
    }
    
    if (!(this.__WL_isLoaded[1] || this.__WL_isModified[1])) {
      if (__WL_bean.__WL_isLoaded[1]) {
        if (__WL_verbose) {
          Debug.say("copying field 'cid' to bean '" +
          __WL_bean.__WL_getPrimaryKey() + "'.");
        }
        this.cid = __WL_bean.cid;
        this.__WL_isLoaded[1] = true;
      }
    }
    
    if (!(this.__WL_isLoaded[2] || this.__WL_isModified[2])) {
      if (__WL_bean.__WL_isLoaded[2]) {
        if (__WL_verbose) {
          Debug.say("copying field 'address' to bean '" +
          __WL_bean.__WL_getPrimaryKey() + "'.");
        }
        this.address = __WL_bean.address;
        this.__WL_isLoaded[2] = true;
      }
    }
    
    
  }
  
  public void __WL_loadGroupByIndex(int index, java.sql.ResultSet rs,
  Integer offset, Object __WL_pk, javax.ejb.EntityBean eb) throws Exception
  {
    switch(index) {
      case 0: __WL_loadGroup0FromRS(rs, offset, __WL_pk, (home.AddressCustomerBean_8fu3hq__WebLogic_CMP_RDBMS)eb); break;
      default: throw new AssertionError("Bad Group index: "+index);
      
    }
  }
  
  public void __WL_loadCMRFieldByCmrField(String cmrField, java.sql.ResultSet rs,
  Integer offset, javax.ejb.EntityBean eb) throws Exception
  {
    
  }
  
  public PersistenceManager __WL_getPersistenceManager() {
    return __WL_pm;
  }
  
  public void __WL_ejbRemoveWithoutDBUpdate()  throws javax.ejb.RemoveException {
    int oldState = __WL_method_state;
    
    try {
      __WL_method_state = STATE_EJB_REMOVE;
      if (__WL_verbose) {
        Debug.say("ejbRemoveWithoutDBUpdate " + __WL_ctx.getPrimaryKey());
      }
      super.ejbRemove();
      
      
      
      // initialize state before this instance goes back into the
      // pool
      __WL_initialize();
      
    } finally {
      __WL_method_state = oldState;
    }
    
  }
  
  public void __WL_makeCascadeDelList(java.util.Map mapCascadeDelBeans,
  java.util.List listCascadeDelBeans,
  java.util.List listCascadeDelBeansWithoutDBUpdate,
  boolean withoutDBUpdate)
  throws java.lang.Exception
  {
    
    int oldState = __WL_method_state;
    __WL_method_state = STATE_EJB_REMOVE;
    
    // create a unique mapKey to map beans to mapCascadeDelBeans
    // re-use weblogic.ejb20.cache.CacheKey class since it take two
    // objects to create the key
    Object pk = __WL_ctx.getPrimaryKey();
    Object beanManager = __WL_pm.getBeanManager();
    weblogic.ejb20.cache.CacheKey mapKey =
    new weblogic.ejb20.cache.CacheKey(pk, (CachingManager)beanManager);
    
    // step 1:
    // keep track of all of the beans been visited is the map to detect the circular case
    if (mapCascadeDelBeans.get(mapKey) == null) {
      mapCascadeDelBeans.put(mapKey, this);
    }
    else {
      if (__WL_verbose) {
        Debug.say("Trying to add " + mapKey + " to list during cascade delete, " +
        "but it already exists in the list, a possible circular detect, ignored.");
      }
      return;
    }
    
    // step 2:
    // This is the place every bean bean added to the list.
    // true  if don't need a database update, db-cascade-delete is specified
    // false if do need a database update, db-cascade-detelet isn't specified
    if (withoutDBUpdate) {
      listCascadeDelBeansWithoutDBUpdate.add(this);
    } else {
      listCascadeDelBeans.add(this);
    }
    
    __WL_method_state = oldState;
    
  }
  
  public java.sql.PreparedStatement[] __WL_getBulkStmtArray(java.sql.Connection __WL_con)
  throws Exception
  {
    if (__WL_verbose) {
      Debug.say("called __WL_getBulkStmtArray.");
    }
    
    
    java.sql.PreparedStatement[] __WL_stmt_array = new java.sql.PreparedStatement[1];
    
    java.sql.PreparedStatement __WL_stmt_address_customer_0 = null;
    __WL_stmt_array[0] = __WL_stmt_address_customer_0;
    
    
    
    String[] __WL_query_array = new String[1];
    
    
    
    __WL_query_array[0] = "INSERT INTO address_customer (amid, cid, address) VALUES (?, ?, ?)";
    
    
    if(__WL_verbose) {
      for (int i = 0 ; i < 1 ; i++) {
        Debug.say("__WL_getBulkStmtArray() produced sqlString " + __WL_query_array[i]);
      }
    }
    
    
    __WL_stmt_array[0] = __WL_con.prepareStatement(__WL_query_array[0]);
    
    
    return __WL_stmt_array;
    
  }
  
  public void __WL_setBeanParamsForCreateArray(java.sql.PreparedStatement[] __WL_stmt_array)
  throws Exception
  {
    
    // preparedStatementParamIndex reset.
    if(!__WL_pm.setParamNull(__WL_stmt_array[0], 1, this.amid, "amid")) {
      __WL_stmt_array[0].setInt(1, this.amid.intValue());
      if (__WL_verbose) {
        Debug.say("paramIdx :"+1+" binded with value :"+this.amid);
      }
    }
    
    if(!__WL_pm.setParamNull(__WL_stmt_array[0], 2, this.cid, "cid")) {
      __WL_stmt_array[0].setInt(2, this.cid.intValue());
      if (__WL_verbose) {
        Debug.say("paramIdx :"+2+" binded with value :"+this.cid);
      }
    }
    
    if(!__WL_pm.setParamNull(__WL_stmt_array[0], 3, this.address, "address")) {
      __WL_stmt_array[0].setString(3, this.address);
      if (__WL_verbose) {
        Debug.say("paramIdx :"+3+" binded with value :"+this.address);
      }
    }
    
    
  }
  
  public void __WL_resetIsModifiedVars() {
    for (int __WL_i = 0; __WL_i < __WL_isModified.length; __WL_i++) {
      __WL_isModified[__WL_i] = false;
    }
    __WL_modifiedBeanIsRegistered = false;
    
  }
  
  public boolean __WL_exists(Object __WL_key) {
    if (__WL_verbose) {
      Debug.say("exists: " + __WL_key);
    }
    
    java.sql.Connection __WL_con = null;
    java.sql.PreparedStatement __WL_stmt = null;
    java.sql.ResultSet __WL_rs = null;
    try {
      java.lang.Integer __WL_pk = (java.lang.Integer) __WL_key;
      __WL_con = __WL_pm.getConnection();
      
      java.lang.String __WL_query =
      "select amid from address_customer where amid = ?";
      
      __WL_stmt = __WL_con.prepareStatement(__WL_query);
      
      // preparedStatementParamIndex reset.
      
      if(!__WL_pm.setParamNull(__WL_stmt, 1, __WL_pk, "amid")) {
        __WL_stmt.setInt(1, __WL_pk.intValue());
        if (__WL_verbose) {
          Debug.say("paramIdx :"+1+" binded with value :"+__WL_pk);
        }
      }
      
      
      __WL_rs = __WL_stmt.executeQuery();
      if (__WL_rs.next()) {
        return true;
      }
      else {
        return false;
      }
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
    finally {
      __WL_pm.releaseResources(__WL_con, __WL_stmt, __WL_rs);
    }
    
  }
  
  public void __WL_checkExistsOnMethod() throws NoSuchEntityException
  {
    
  }
  
  public short __WL_getBeanState() 
  {
    return __WL_bean_state;
  } 
  
  public void __WL_setBeanState(short value)
  {
    __WL_bean_state = value;
  }
  
  
  public String __WL_getM2NSQL(String cmrf,
  int    operation)
  {
    return "";
  }
  
  public void __WL_setBeanParamsForM2NStmt(PreparedStatement __WL_stmt,
  String            cmrf,
  int               operation)
  throws SQLException
  {
    
  }
  
  
  
  // end of CMPBean
  // ================================================================
  
  
  //=================================================================
  // implementation of javax.ejb.EntityBean
  
  public boolean __WL_beanIsLoaded() { 
    return __WL_beanIsLoaded; 
  }
  
  void pkCheck()
  throws javax.ejb.CreateException
  {
    // check that 'amid' was set
    if (!__WL_isModified[0]) {
      throw new javax.ejb.CreateException("In EJB AddressCustomer, primary key field 'amid' was not set during ejbCreate.  All primary key fields must be initialized during ejbCreate.");
    }
  }
  
  
  public java.lang.Integer ejbCreate(java.lang.Integer arg0)
  throws javax.ejb.CreateException
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_CREATE;
      
      for (int __WL_i = 0; __WL_i < 3; __WL_i++) {
        __WL_isLoaded[__WL_i] = true;
        __WL_isModified[__WL_i] = false;
      }
      
      __WL_beanIsLoaded = true;
      
      // set true, this prevents us from registering the bean until after the
      // database insert
      __WL_modifiedBeanIsRegistered = true;
      
      
      // initialize persistent and cached relationship variables, this
      // is done here purely to ensure robustness as the CMP variables
      // are also initialized whenever the bean enters the pooled state
      
      address = null;
      cid = null;
      amid = null;
      
      
      
      
      super.ejbCreate( arg0);
      
      
      pkCheck();
      
      
      
      
      
      java.lang.Integer __WL_pk = (java.lang.Integer) __WL_getPrimaryKey();
      return __WL_pk;
    } catch (javax.ejb.CreateException ce) {
      throw ce;
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
    finally {
      __WL_method_state = oldState;
    }
  }
  
  
  public void ejbPostCreate(java.lang.Integer arg0)
  throws javax.ejb.CreateException
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_POSTCREATE;
      
      
      
      super.ejbPostCreate( arg0);
      
      __WL_create();
      
      
      
      
    } catch (javax.ejb.CreateException ce) {
      throw ce;
      
      
    } catch (RuntimeException re) {
      if (__WL_verbose) {
        Debug.say("rethrowing RuntimeException.");
        re.printStackTrace();
      }
      throw re;
    } catch (Exception ex) {
      if (__WL_verbose) {
        Debug.say("wrapping Exception in PersistenceRuntimeException.");
        ex.printStackTrace();
      }
      throw new PersistenceRuntimeException(ex);
    }
    
    finally {
      __WL_method_state = oldState;
    }
  }
  
  
  
  private Object __WL_create() throws Exception {
    if (__WL_verbose) {
      Debug.say("called __WL_create.");
    }
    
    java.sql.Connection __WL_con = null;
    
    java.sql.PreparedStatement[] __WL_stmt_array = new java.sql.PreparedStatement[1];
    
    java.sql.PreparedStatement __WL_stmt_address_customer_0 = null;
    __WL_stmt_array[0] = __WL_stmt_address_customer_0;
    
    
    
    String[] __WL_query_array = new String[1];
    
    
    
    
    java.lang.Integer __WL_pk = null;
    
    try {
      
      
      __WL_pk = this.amid;
      
      
      __WL_con = __WL_pm.getConnection();
      if(__WL_verbose) {
        Debug.say("__WL_create() got connection.");
      }
      
      
      __WL_query_array[0] = "INSERT INTO address_customer (amid, cid, address) VALUES (?, ?, ?)";
      
      
      if (__WL_verbose) {
        for (int i = 0 ; i < 1 ; i++) {
          Debug.say("__WL_create() produced sqlString " + __WL_query_array[i]);
        }
      }
      
      
      __WL_stmt_array[0] = __WL_con.prepareStatement(__WL_query_array[0]);
      
      
      __WL_setBeanParamsForCreateArray(__WL_stmt_array);
      
      if(__WL_verbose) {
        Debug.say("__WL_create() about to execute sql.");
      }
      for (int i = 0 ; i < 1 ; i++) {
        if (__WL_stmt_array[i].executeUpdate() != 1) {
          throw new java.lang.Exception("Failed to CREATE Bean.  Primary Key Value: '" + __WL_pk + "'");
        }
      }
      
      
      
      for (int __WL_i = 0; __WL_i < __WL_isModified.length; __WL_i++) {
        __WL_isModified[__WL_i] = false;
      }
      __WL_modifiedBeanIsRegistered = false;
      
      return __WL_pk;
    } catch (java.sql.SQLException se) {
      //ejb wants a duplicate key exception if that was what happened
      if(__WL_verbose) {
        Debug.say("__WL_create() "+
        "checking for duplicate key " + __WL_pk);
      }
      boolean exists = false;
      try {
        exists = __WL_exists(__WL_pk);
      }
      catch (Exception e) {
        throw se;
      }
      if (exists) {
        throw new javax.ejb.DuplicateKeyException(
        "Bean with " +
        "primary key: '" + __WL_pk + "' already exists.");
      }
      else {
        throw se;
      }
      
    } finally {
      __WL_pm.releaseArrayResources(__WL_con, __WL_stmt_array, null);
    }
  }
  
  
  public void ejbRemove() throws javax.ejb.RemoveException {
    java.sql.Connection __WL_con = null;
    
    java.sql.PreparedStatement[] __WL_stmt_array = new java.sql.PreparedStatement[1];
    
    java.sql.PreparedStatement __WL_stmt_address_customer_0 = null;
    __WL_stmt_array[0] = __WL_stmt_address_customer_0;
    
    
    
    String[] __WL_query_array = new String[1];
    
    
    java.sql.PreparedStatement __WL_stmt = null;
    
    int oldState = __WL_method_state;
    
    try {
      __WL_method_state = STATE_EJB_REMOVE;
      int __WL_num = 0;
      if (__WL_verbose) {
        Debug.say("ejbRemove " + __WL_ctx.getPrimaryKey());
      }
      super.ejbRemove();
      
      try {
        
        
        java.lang.Integer __WL_pk = (java.lang.Integer) __WL_ctx.getPrimaryKey();
        
        __WL_con = __WL_pm.getConnection();
        
        __WL_query_array[0] = "DELETE FROM address_customer WHERE amid = ?" ;
        
        
        
        __WL_stmt_array[0] = __WL_con.prepareStatement(__WL_query_array[0]);
        
        
        __WL_num = 1;
        __WL_stmt = __WL_stmt_array[0];
        
        if(!__WL_pm.setParamNull(__WL_stmt, __WL_num, __WL_pk, "amid")) {
          __WL_stmt.setInt(__WL_num, __WL_pk.intValue());
          if (__WL_verbose) {
            Debug.say("paramIdx :"+__WL_num+" binded with value :"+__WL_pk);
          }
        }
        __WL_num++;
        
        
        for (int i = 0 ; i < 1 ; i++) {
          int j = __WL_stmt_array[i].executeUpdate();
          if (j == 0) {
            EJBTextTextFormatter fmt = new EJBTextTextFormatter(); 
            throw new NoSuchEntityException(fmt.beanDoesNotExist("AddressCustomer",__WL_pk.toString())); 
          }
        }
        
        // initialize state before this instance goes back into the
        // pool
        __WL_initialize();
        
      } catch (RuntimeException re) {
        if (__WL_verbose) {
          Debug.say("rethrowing RuntimeException.");
          re.printStackTrace();
        }
        throw re;
      } catch (Exception ex) {
        if (__WL_verbose) {
          Debug.say("wrapping Exception in PersistenceRuntimeException.");
          ex.printStackTrace();
        }
        throw new PersistenceRuntimeException(ex);
      }
      
    } finally {
      __WL_method_state = oldState;
      __WL_pm.releaseArrayResources(__WL_con, __WL_stmt_array, null);
    }
  }
  
  
  
  public void ejbLoad()
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJBLOAD;
      
      __WL_initialize();
      
      super.ejbLoad();
      
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  
  public void ejbStore() {
    __WL_store(true);
  }
  
  public void __WL_store(boolean unregister) 
  {
    
    java.sql.Connection __WL_con = null;
    java.sql.PreparedStatement __WL_stmt = null;
    int oldState = __WL_method_state;
    
    
    try {
      __WL_method_state = STATE_EJBSTORE;
      if (__WL_verbose) {
        Debug.say("ejbStore "+ __WL_ctx.getPrimaryKey());
      }
      super.ejbStore();
      
      try {
        int __WL_num          = 0;
        int __WL_count        = 0;
        int __WL_total       = 0;
        java.lang.Integer __WL_pk     = (java.lang.Integer) __WL_ctx.getPrimaryKey();
        String __WL_query     = null;
        StringBuffer sb      = new StringBuffer();
        
        
        
        
        
        __WL_count = 0;
        
        
        sb.setLength(0);
        if (__WL_isModified[1])  {
          if (__WL_count > 0) sb.append(", ");
          sb.append("cid = ? ");
          __WL_count++;
        }
        
        if (__WL_isModified[2])  {
          if (__WL_count > 0) sb.append(", ");
          sb.append("address = ? ");
          __WL_count++;
        }
        
        
        
        __WL_total = __WL_total + __WL_count + 0;
        
        if ( (__WL_count > 0) || (0 > 0) ) {
          
          __WL_con = __WL_pm.getConnection();
          
          if (__WL_count > 0) {
            // we have modified non-Blob/Clob Columns
            
            
            
            
            __WL_query = "UPDATE address_customer SET " +
            sb.toString() +
            " WHERE amid = ?" 
            ;
            if(__WL_verbose) {
              Debug.say("WL_store sql: " + __WL_query);
            }
            
            __WL_stmt = __WL_con.prepareStatement(__WL_query);
            
            __WL_num = 1;
            if (__WL_isModified[1]) {
              if(__WL_verbose) Debug.say("setting("+this+") 'cid' using column " +__WL_num + ". Value is " + this.cid);
              if(!__WL_pm.setParamNull(__WL_stmt, __WL_num, this.cid, "cid")) {
                __WL_stmt.setInt(__WL_num, this.cid.intValue());
                if (__WL_verbose) {
                  Debug.say("paramIdx :"+__WL_num+" binded with value :"+this.cid);
                }
              }
              __WL_num++;
            };
            
            if (__WL_isModified[2]) {
              if(__WL_verbose) Debug.say("setting("+this+") 'address' using column " +__WL_num + ". Value is " + this.address);
              if(!__WL_pm.setParamNull(__WL_stmt, __WL_num, this.address, "address")) {
                __WL_stmt.setString(__WL_num, this.address);
                if (__WL_verbose) {
                  Debug.say("paramIdx :"+__WL_num+" binded with value :"+this.address);
                }
              }
              __WL_num++;
            };
            
            
            
            
            if(!__WL_pm.setParamNull(__WL_stmt, __WL_num, __WL_pk, "amid")) {
              __WL_stmt.setInt(__WL_num, __WL_pk.intValue());
              if (__WL_verbose) {
                Debug.say("paramIdx :"+__WL_num+" binded with value :"+__WL_pk);
              }
            }
            __WL_num++;
            
            
            
            int __WL_i = __WL_stmt.executeUpdate();
            if (__WL_i == 0) {
              EJBTextTextFormatter fmt = new EJBTextTextFormatter(); 
              throw new NoSuchEntityException(fmt.beanDoesNotExist("AddressCustomer",__WL_pk.toString())); 
            }
          }
          
          if (0 > 0) {
            // we have modified Blob/Clob Columns
            
          }
        }
        
        
        if (__WL_total == 0) {
          if (__WL_verbose) {
            Debug.say("ejbStore: avoided a store.  ejbStore: complete");
          }
          return;
        }
        
        for (int __WL_i = 0; __WL_i < __WL_isModified.length; __WL_i++) {
          __WL_isModified[__WL_i] = false;
        }
        if (unregister) {
          __WL_pm.unregisterModifiedBean(__WL_ctx.getPrimaryKey());
          
        }
        __WL_modifiedBeanIsRegistered = false;
        
        
        if (__WL_verbose) {
          Debug.say("ejbStore: complete");
        }
      } catch (RuntimeException re) {
        if (__WL_verbose) {
          Debug.say("rethrowing RuntimeException.");
          re.printStackTrace();
        }
        throw re;
      } catch (Exception ex) {
        if (__WL_verbose) {
          Debug.say("wrapping Exception in PersistenceRuntimeException.");
          ex.printStackTrace();
        }
        throw new PersistenceRuntimeException(ex);
      }
      
    } finally {
      __WL_method_state = oldState;
      __WL_pm.releaseResources(__WL_con, __WL_stmt, null);
    }
  }
  
  
  public void ejbPassivate()
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_PASSIVATE;
      super.ejbPassivate();
      
      __WL_initialize();
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  // Blob/Clob methods
  
  
  // end javax.ejb.EntityBean
  //=================================================================
}

