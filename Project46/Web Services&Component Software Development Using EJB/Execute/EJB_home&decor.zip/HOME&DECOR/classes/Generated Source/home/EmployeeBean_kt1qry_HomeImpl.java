/**
* This code was automatically generated at 17:11:56 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
public final class EmployeeBean_kt1qry_HomeImpl
extends    weblogic.ejb20.internal.EntityEJBHome
implements home.EmployeeRemoteHome, weblogic.utils.PlatformConstants
, weblogic.ejb.QueryHome
{
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPassword;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setTel_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getEmail;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getAddress;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getSurname;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getName;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPassword_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setEmail_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getTel;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setName_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setSurname_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getTypePosition;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setAddress_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getEid;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbCreate_I;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindByPrimaryKey_I;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindIDByName_S;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindSelectall;
  
  
  
  private static java.lang.reflect.Method mth_ejbCreate_I;
  private static java.lang.reflect.Method mth_postejbCreate_I;
  
  
  
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_eo_remove;
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_javax_ejb_Handle;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_O;
  
  static {
    
    try {
      
      
      mth_ejbCreate_I = EmployeeBean.class.getMethod(
      "ejbCreate", new Class [] {java.lang.Integer.class});
      
      if (true) {
        mth_postejbCreate_I = EmployeeBean.class.getMethod(
        "ejbPostCreate", new Class [] {java.lang.Integer.class}); 
      }
      
      
      
      
      
    } catch (Exception e) {
      throw new weblogic.utils.AssertionError("Unable to find expected "+
      "methods.  Please check your classpath for stale versions of "+
      "your ejb classes and re-run weblogic.ejbc");
    }
  }
  
  
  public EmployeeBean_kt1qry_HomeImpl() {
    super(EmployeeBean_kt1qry_EOImpl.class
    , java.lang.Integer.class);
  }
  
  
  public home.EmployeeRemote create (java.lang.Integer arg0)
  throws javax.ejb.CreateException, java.rmi.RemoteException
  {
    try {
      return (home.EmployeeRemote) super.create(md_ejbCreate_I,
      mth_ejbCreate_I, mth_postejbCreate_I, 
      new Object [] {  arg0});
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.CreateException) {
        throw (javax.ejb.CreateException) e;
      }
      else {
        throw new javax.ejb.CreateException ("Error while creating bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  public home.EmployeeRemote findByPrimaryKey(java.lang.Integer arg0)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (home.EmployeeRemote)
      super.findByPrimaryKey(md_ejbFindByPrimaryKey_I,  arg0 );
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  public home.EmployeeRemote findIDByName(java.lang.String arg0)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (home.EmployeeRemote)
      super.finder(md_ejbFindIDByName_S, new Object [] {  arg0} , weblogic.ejb20.internal.EntityEJBHome.SCALAR_FINDER);
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  public java.util.Collection findSelectall()
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (java.util.Collection)
      super.finder(md_ejbFindSelectall, new Object [] { } , weblogic.ejb20.internal.EntityEJBHome.COLL_FINDER);
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  
  
  public void remove(java.lang.Object pk) 
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_O, pk);
  }
  
  public void remove(javax.ejb.Handle h)
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_javax_ejb_Handle, h);
  }
  
  
}

