/**
* This code was automatically generated at 17:11:40 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class StringToolsBean_2fnlm2_EOImpl
extends weblogic.ejb20.internal.StatelessEJBObject
implements home.StringTools, weblogic.utils.PlatformConstants
{
  
  public StringToolsBean_2fnlm2_EOImpl() {}
  
  public int NumStreamString(java.lang.String arg0)
  throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((StringToolsBean_2fnlm2_HomeImpl)getEJBHome()).md_eo_NumStreamString_S;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    int result = 0;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((StringToolsBean) __bean).NumStreamString( arg0);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.StringToolsBean.NumStreamString():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.String addSymbol(java.lang.String arg0)
  throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((StringToolsBean_2fnlm2_HomeImpl)getEJBHome()).md_eo_addSymbol_S;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.String result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((StringToolsBean) __bean).addSymbol( arg0);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.StringToolsBean.addSymbol():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.String[] cutStreamString(java.lang.String arg0)
  throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((StringToolsBean_2fnlm2_HomeImpl)getEJBHome()).md_eo_cutStreamString_S;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.String[] result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((StringToolsBean) __bean).cutStreamString( arg0);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.StringToolsBean.cutStreamString():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.String cutEachColon(java.lang.String arg0)
  throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((StringToolsBean_2fnlm2_HomeImpl)getEJBHome()).md_eo_cutEachColon_S;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.String result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((StringToolsBean) __bean).cutEachColon( arg0);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.StringToolsBean.cutEachColon():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  
  
  public void remove()
  throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((StringToolsBean_2fnlm2_HomeImpl)getEJBHome()).md_eo_remove);
  }
  
}

