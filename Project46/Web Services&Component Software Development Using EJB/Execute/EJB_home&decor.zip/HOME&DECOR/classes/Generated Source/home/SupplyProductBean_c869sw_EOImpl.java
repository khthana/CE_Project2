/**
* This code was automatically generated at 17:11:41 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class SupplyProductBean_c869sw_EOImpl
extends weblogic.ejb20.internal.EntityEJBObject_Activatable
implements home.SupplyProductRemote, weblogic.utils.PlatformConstants
{
  
  public SupplyProductBean_c869sw_EOImpl() {}
  
  public void setNumber(java.lang.Integer arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_setNumber_I;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((SupplyProductBean) __bean).setNumber( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.setNumber():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public void setDate(java.sql.Timestamp arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_setDate_java_sql_Timestamp;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((SupplyProductBean) __bean).setDate( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.setDate():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public java.lang.Float getCost() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getCost;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Float result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getCost();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getCost():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.sql.Timestamp getDate() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getDate;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.sql.Timestamp result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getDate();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getDate():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.Integer getPlid() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getPlid;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getPlid();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getPlid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public void setPlid(java.lang.Integer arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_setPlid_I;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((SupplyProductBean) __bean).setPlid( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.setPlid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public java.lang.Integer getSpid() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getSpid;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getSpid();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getSpid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public void setCost(java.lang.Float arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_setCost_F;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((SupplyProductBean) __bean).setCost( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.setCost():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public java.lang.Integer getSid() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getSid;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getSid();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getSid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public void setSid(java.lang.Integer arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_setSid_I;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((SupplyProductBean) __bean).setSid( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.setSid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public java.lang.Integer getNumber() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_getNumber;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((SupplyProductBean) __bean).getNumber();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.SupplyProductBean.getNumber():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  
  
  public void remove()
  throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((SupplyProductBean_c869sw_HomeImpl)getEJBHome()).md_eo_remove);
  }
  
}

