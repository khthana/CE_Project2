/**
* This code was automatically generated at 17:11:24 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
public final class SessionCustomerBean_l9rpn0_HomeImpl
extends    weblogic.ejb20.internal.StatefulEJBHome
implements home.SessionCustomerHome, weblogic.utils.PlatformConstants

{
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getName;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_AddKeepSession_SSS;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getSurname;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_ViewKeepSession_SS;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPassword_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPassword;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setName_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_Buy_SSSS;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setSurname_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getID;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setID_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_login_javax_servlet_http_HttpServletRequestjava_io_PrintWriter;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbCreate;
  
  
  
  
  
  private static java.lang.reflect.Method mth_ejbCreate;
  private static java.lang.reflect.Method mth_postejbCreate;
  
  
  
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_eo_remove;
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_javax_ejb_Handle;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_O;
  
  static {
    
    try {
      
      
      mth_ejbCreate = SessionCustomerBean.class.getMethod(
      "ejbCreate", null);
      
      if (false) {
        mth_postejbCreate = SessionCustomerBean.class.getMethod(
        "ejbPostCreate", null); 
      }
      
      
      
      
      
    } catch (Exception e) {
      throw new weblogic.utils.AssertionError("Unable to find expected "+
      "methods.  Please check your classpath for stale versions of "+
      "your ejb classes and re-run weblogic.ejbc");
    }
  }
  
  
  public SessionCustomerBean_l9rpn0_HomeImpl() {
    super(SessionCustomerBean_l9rpn0_EOImpl.class
    );
  }
  
  
  public home.SessionCustomer create ()
  throws javax.ejb.CreateException, java.rmi.RemoteException
  {
    try {
      return (home.SessionCustomer) super.create(md_ejbCreate,
      mth_ejbCreate, 
      new Object [] { });
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.CreateException) {
        throw (javax.ejb.CreateException) e;
      }
      else {
        throw new javax.ejb.CreateException ("Error while creating bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  
  
  
  public void remove(java.lang.Object pk) 
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_O, pk);
  }
  
  public void remove(javax.ejb.Handle h)
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_javax_ejb_Handle, h);
  }
  
  
}

