/**
* This code was automatically generated at 17:11:25 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
public final class CustomerBean_b3dzi6_HomeImpl
extends    weblogic.ejb20.internal.EntityEJBHome
implements home.CustomerRemoteHome, weblogic.utils.PlatformConstants
, weblogic.ejb.QueryHome
{
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPassword;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getMobile;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getPid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getEmail;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setJid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setSurname_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getLoginname;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setLoginname_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setSalu_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setMobile_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setSid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getMid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setAddress_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getStid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getAddress;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setPassword_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getSurname;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setStid_I;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getName;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setEmail_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getSalu;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getSid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getJid;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_getTel;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setName_S;
  public weblogic.ejb20.internal.MethodDescriptor md_eo_setTel_S;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbCreate_I;
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindByPrimaryKey_I;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbFindIDByLoginName_S;
  
  
  
  private static java.lang.reflect.Method mth_ejbCreate_I;
  private static java.lang.reflect.Method mth_postejbCreate_I;
  
  
  
  
  
  public weblogic.ejb20.internal.MethodDescriptor md_eo_remove;
  
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_javax_ejb_Handle;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_O;
  
  static {
    
    try {
      
      
      mth_ejbCreate_I = CustomerBean.class.getMethod(
      "ejbCreate", new Class [] {java.lang.Integer.class});
      
      if (true) {
        mth_postejbCreate_I = CustomerBean.class.getMethod(
        "ejbPostCreate", new Class [] {java.lang.Integer.class}); 
      }
      
      
      
      
      
    } catch (Exception e) {
      throw new weblogic.utils.AssertionError("Unable to find expected "+
      "methods.  Please check your classpath for stale versions of "+
      "your ejb classes and re-run weblogic.ejbc");
    }
  }
  
  
  public CustomerBean_b3dzi6_HomeImpl() {
    super(CustomerBean_b3dzi6_EOImpl.class
    , java.lang.Integer.class);
  }
  
  
  public home.CustomerRemote create (java.lang.Integer arg0)
  throws javax.ejb.CreateException, java.rmi.RemoteException
  {
    try {
      return (home.CustomerRemote) super.create(md_ejbCreate_I,
      mth_ejbCreate_I, mth_postejbCreate_I, 
      new Object [] {  arg0});
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.CreateException) {
        throw (javax.ejb.CreateException) e;
      }
      else {
        throw new javax.ejb.CreateException ("Error while creating bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  public home.CustomerRemote findByPrimaryKey(java.lang.Integer arg0)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (home.CustomerRemote)
      super.findByPrimaryKey(md_ejbFindByPrimaryKey_I,  arg0 );
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  public home.CustomerRemote findIDByLoginName(java.lang.String arg0)
  throws javax.ejb.FinderException, java.rmi.RemoteException
  {
    try {
      return (home.CustomerRemote)
      super.finder(md_ejbFindIDByLoginName_S, new Object [] {  arg0} , weblogic.ejb20.internal.EntityEJBHome.SCALAR_FINDER);
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      }
      else if (e instanceof javax.ejb.FinderException) {
        throw (javax.ejb.FinderException) e;
      }
      else {
        throw new javax.ejb.FinderException ("Error while finding bean: " + 
        e.toString());
      }
    }
  }
  
  
  
  
  
  
  public void remove(java.lang.Object pk) 
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_O, pk);
  }
  
  public void remove(javax.ejb.Handle h)
  throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_javax_ejb_Handle, h);
  }
  
  
}

