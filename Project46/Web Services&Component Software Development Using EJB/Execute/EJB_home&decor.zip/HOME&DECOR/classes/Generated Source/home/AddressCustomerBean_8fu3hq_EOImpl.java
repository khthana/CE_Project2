/**
* This code was automatically generated at 17:11:24 on 21 ��.�. 2547
* by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
*
* @version WebLogic Server 7.0 SP4  Tue Aug 12 11:22:26 PDT 2003 284033 
* @author Copyright (c) 2004 by BEA Systems, Inc. All Rights Reserved.
*/

package home;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class AddressCustomerBean_8fu3hq_EOImpl
extends weblogic.ejb20.internal.EntityEJBObject_Activatable
implements home.AddressCustomerRemote, weblogic.utils.PlatformConstants
{
  
  public AddressCustomerBean_8fu3hq_EOImpl() {}
  
  public void setAddress(java.lang.String arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_setAddress_S;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((AddressCustomerBean) __bean).setAddress( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.AddressCustomerBean.setAddress():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  public java.lang.Integer getCid() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_getCid;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((AddressCustomerBean) __bean).getCid();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.AddressCustomerBean.getCid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.String getAddress() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_getAddress;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.String result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((AddressCustomerBean) __bean).getAddress();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.AddressCustomerBean.getAddress():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public java.lang.Integer getAmid() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_getAmid;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] { }));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    java.lang.Integer result = null;
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      result =  ((AddressCustomerBean) __bean).getAmid();
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.AddressCustomerBean.getAmid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }
  
  public void setCid(java.lang.Integer arg0) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;
    
    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
    ((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_setCid_I;
    try {
      __wrap = super.preInvoke(
      __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
      __md, new weblogic.ejb20.internal.EJBContextHandler(
      __md, new Object [] {  arg0}));          
    }
    
    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();
    
    // No return value
    
    int __oldState = __bean.__WL_getMethodState();
    
    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
      
      ((AddressCustomerBean) __bean).setCid( arg0);
      ((weblogic.ejb20.persistence.spi.CMPBean) __bean).__WL_checkExistsOnMethod();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }
    
    try {
      super.postInvoke(__wrap, __ee);
      
    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
        throw new java.rmi.UnexpectedException("Unexpected exception in " +
        "home.AddressCustomerBean.setCid():" + EOL +	
        weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    // No return result
  }
  
  
  
  public void remove()
  throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((AddressCustomerBean_8fu3hq_HomeImpl)getEJBHome()).md_eo_remove);
  }
  
}

