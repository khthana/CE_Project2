Imports System.IO

Public Class makeODL
    Public projectName As String
    Public tmpODL() As tempClass
    Public tout As TextBox = New TextBox()

    Public Sub genFileODL()
        Dim strClass As String : Dim i As Integer
        i = 0
        While i < tmpODL.Length
            strClass = "interface " & tmpODL(i).className & " "
            If tmpODL(i).superName <> "no" Then
                strClass = strClass & "extends " & tmpODL(i).superName & vbCrLf
            End If
            strClass = strClass & "{" & vbCrLf

            ' ���ҧ attribute
            Dim j As Integer : j = 0
            While j < tmpODL(i).attribute.Length
                Dim tmp_attribute As String : tmp_attribute = tmpODL(i).attribute(j)
                Dim check_struct(0) As String
                check_struct = tmp_attribute.Split(":")
                If check_struct(0) = "normal" Then
                    ' attribute ������
                    Dim attribute(3) As String
                    attribute = tmp_attribute.Split(":")
                    If attribute(3) = True Then
                        strClass = strClass & vbTab & "attribute Set<" & attribute(2) & "> " & attribute(1) & ";" & vbCrLf
                    Else
                        strClass = strClass & vbTab & "attribute " & attribute(2) & " " & attribute(1) & ";" & vbCrLf
                    End If
                ElseIf check_struct(0) = "struct" Then
                    ' attribute ����� structure
                    Dim typename, sname As String
                    Dim start, finish As Integer : start = 0 : finish = 0
                    ' ���� type �ͧ structure
                    start = tmp_attribute.IndexOf(":")
                    finish = tmp_attribute.IndexOf(":", start + 1)
                    typename = tmp_attribute.Substring(start + 1, finish - start - 1)
                    ' ���� name �ͧ structure
                    start = finish
                    finish = tmp_attribute.IndexOf(":", start + 1)
                    sname = tmp_attribute.Substring(start + 1, finish - start - 1)
                    ' ��С�ȵ���� structure
                    strClass = strClass & vbTab & "attribute Struct " & typename & vbCrLf
                    strClass = strClass & vbTab & vbTab & "{ "
                    start = finish
                    While finish < tmp_attribute.Length
                        If start <> finish Then strClass = strClass & ", "
                        Dim struct_array(3) As String : Dim si As Integer
                        si = 0
                        For si = 0 To 3
                            Dim str As String
                            finish = tmp_attribute.IndexOf(":", start + 1)
                            str = tmp_attribute.Substring(start + 1, finish - start - 1)
                            start = finish
                            struct_array(si) = str
                        Next
                        ' ��� attribute ��ҧ�ͧ structure
                        If struct_array(0) = "normal" Then
                            If struct_array(3) = True Then
                                strClass = strClass & "Set<" & struct_array(2) & "> " & struct_array(1)
                            Else
                                strClass = strClass & struct_array(2) & " " & struct_array(1)
                            End If
                            ' �����Դ composite attribute ��͹ composite attribute
                        End If
                        finish += 1
                    End While
                    strClass = strClass & " } " & sname & ";" & vbCrLf
                End If
                j += 1
            End While

            ' ���ҧ relationship
            j = 0
            While j < tmpODL(i).relationship.Length
                Dim relationship(3) As String
                relationship = tmpODL(i).relationship(j).Split(":")
                strClass = strClass & vbTab & "relationship "
                If relationship(1) = "many" Then
                    strClass = strClass & "Set<" & relationship(2) & "> " & relationship(0) & vbCrLf
                Else
                    strClass = strClass & relationship(2) & " " & relationship(0) & vbCrLf
                End If
                strClass = strClass & vbTab & vbTab & "inverse " & relationship(2) & "::" & relationship(3) & ";" & vbCrLf
                j += 1
            End While
            strClass = strClass & "}" & vbCrLf

            ' ��¹ŧ���
            tout.Text = tout.Text + strClass
            i += 1
        End While
    End Sub
End Class