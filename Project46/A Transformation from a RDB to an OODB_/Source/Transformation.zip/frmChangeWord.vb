Public Class frmChangeWord
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNewWord As System.Windows.Forms.TextBox
    Friend WithEvents txtOldWord As System.Windows.Forms.TextBox
    Friend WithEvents btnCancle As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtNewWord = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOldWord = New System.Windows.Forms.TextBox()
        Me.btnCancle = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOK.Location = New System.Drawing.Point(104, 80)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(80, 24)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        '
        'txtNewWord
        '
        Me.txtNewWord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewWord.Location = New System.Drawing.Point(80, 48)
        Me.txtNewWord.Name = "txtNewWord"
        Me.txtNewWord.Size = New System.Drawing.Size(296, 20)
        Me.txtNewWord.TabIndex = 1
        Me.txtNewWord.Text = ""
        '
        'btnClear
        '
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Location = New System.Drawing.Point(192, 80)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(80, 24)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Old Word"
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Location = New System.Drawing.Point(16, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "New Word"
        '
        'txtOldWord
        '
        Me.txtOldWord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOldWord.Location = New System.Drawing.Point(72, 16)
        Me.txtOldWord.Name = "txtOldWord"
        Me.txtOldWord.Size = New System.Drawing.Size(296, 20)
        Me.txtOldWord.TabIndex = 6
        Me.txtOldWord.Text = ""
        '
        'btnCancle
        '
        Me.btnCancle.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancle.Location = New System.Drawing.Point(280, 80)
        Me.btnCancle.Name = "btnCancle"
        Me.btnCancle.Size = New System.Drawing.Size(80, 24)
        Me.btnCancle.TabIndex = 2
        Me.btnCancle.Text = "Cancle"
        '
        'frmChangeWord
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btnCancle
        Me.ClientSize = New System.Drawing.Size(392, 118)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtOldWord, Me.Label2, Me.Label1, Me.btnClear, Me.btnCancle, Me.txtNewWord, Me.btnOK})
        Me.Name = "frmChangeWord"
        Me.Text = "Change Word"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public txtOutput As String = ""
    Public fbtn As Boolean = False

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        txtOutput = ""
        If txtNewWord.Text <> "" Then
            txtOutput = txtNewWord.Text
            fbtn = True
            Me.Close()
        End If
    End Sub

    Private Sub btnCancle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancle.Click
        txtOutput = ""
        txtNewWord.Text = ""
        fbtn = False
        Me.Close()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtOutput = ""
        txtOldWord.Text = ""
        txtNewWord.Text = ""
    End Sub
End Class
