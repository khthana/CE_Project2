Public Class ShowRelationalSchema
    Inherits System.Windows.Forms.Form

    Dim Mainform As Form
    Dim DBcon As DatabaseControl
    Dim TableName As DataTable
    Dim SchemaTable As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub

    Public Sub New(ByVal CallForm As Form)
        MyBase.New()
        InitializeComponent()
        Mainform = CallForm
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
        Mainform.Enabled = True
        Mainform.Focus()
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents dgTableName As System.Windows.Forms.DataGrid
    Friend WithEvents dgAttribute As System.Windows.Forms.DataGrid
    Friend WithEvents dgForeignKey As System.Windows.Forms.DataGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dgTableName = New System.Windows.Forms.DataGrid()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.dgAttribute = New System.Windows.Forms.DataGrid()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.dgForeignKey = New System.Windows.Forms.DataGrid()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgTableName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.dgForeignKey, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgTableName})
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Location = New System.Drawing.Point(8, 64)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(192, 280)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Table Name"
        '
        'dgTableName
        '
        Me.dgTableName.DataMember = ""
        Me.dgTableName.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgTableName.Location = New System.Drawing.Point(8, 16)
        Me.dgTableName.Name = "dgTableName"
        Me.dgTableName.ReadOnly = True
        Me.dgTableName.RowHeadersVisible = False
        Me.dgTableName.Size = New System.Drawing.Size(176, 256)
        Me.dgTableName.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgAttribute})
        Me.GroupBox2.Location = New System.Drawing.Point(208, 64)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(392, 136)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Attribute "
        '
        'dgAttribute
        '
        Me.dgAttribute.DataMember = ""
        Me.dgAttribute.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgAttribute.Location = New System.Drawing.Point(8, 16)
        Me.dgAttribute.Name = "dgAttribute"
        Me.dgAttribute.RowHeadersVisible = False
        Me.dgAttribute.Size = New System.Drawing.Size(376, 112)
        Me.dgAttribute.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgForeignKey})
        Me.GroupBox4.Location = New System.Drawing.Point(208, 208)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(392, 136)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Foreign Key"
        '
        'dgForeignKey
        '
        Me.dgForeignKey.DataMember = ""
        Me.dgForeignKey.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgForeignKey.Location = New System.Drawing.Point(8, 16)
        Me.dgForeignKey.Name = "dgForeignKey"
        Me.dgForeignKey.RowHeadersVisible = False
        Me.dgForeignKey.Size = New System.Drawing.Size(376, 112)
        Me.dgForeignKey.TabIndex = 0
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(504, 352)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(96, 24)
        Me.btnNext.TabIndex = 4
        Me.btnNext.Text = "Next"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(328, 40)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Relational Schema"
        '
        'ShowRelationalSchema
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(608, 390)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.btnNext, Me.GroupBox4, Me.GroupBox2, Me.GroupBox1})
        Me.Name = "ShowRelationalSchema"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Show Relational Schema"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgTableName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.dgAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.dgForeignKey, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ShowRelationalTable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        TableName = DBcon.GetTableName()
        dgTableName.DataSource = TableName
        dgTableName.CaptionText = DBcon.GetDatabaseName

        SchemaTable = DBcon.GetSchema(TableName.Rows(0).Item("TableName"))

        dgAttribute.DataSource = SchemaTable.Tables("SchemaList")
        dgAttribute.CaptionText = TableName.Rows(0).Item("TableName")

        dgForeignKey.DataSource = SchemaTable.Tables("ForeignKeyList")
        dgForeignKey.CaptionText = TableName.Rows(0).Item("TableName")

    End Sub

    Private Sub dgtablename_Mouseup(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgTableName.MouseUp
        Dim TableName As String

        TableName = dgTableName.Item(dgTableName.CurrentCell.RowNumber, dgTableName.CurrentCell.ColumnNumber)

        SchemaTable = DBcon.GetSchema(TableName)

        dgAttribute.DataSource = SchemaTable.Tables("SchemaList")
        dgAttribute.CaptionText = TableName

        dgForeignKey.DataSource = SchemaTable.Tables("ForeignKeyList")
        dgForeignKey.CaptionText = TableName
    End Sub

    Public Function SetDatabaseConnection(ByRef con As DatabaseControl)
        Me.DBcon = con
    End Function

    Public Function SetMainForm(ByRef MainForm As Form)
        Me.Mainform = MainForm
    End Function

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Dim SERD As New ShowER()
        SERD.SetMainForm(Mainform)
        SERD.SetDatabaseConnection(DBcon)
        'Now DBcon is connection to Relational Database .May be change to DataTable or DataSchema
        SERD.SetBackForm(Me)

        SERD.Top = (Mainform.Top + Mainform.Height / 2) - (SERD.Height / 2)
        SERD.Left = (Mainform.Left + Mainform.Width / 2) - (SERD.Width / 2)

        If SERD.Top < 0 Then
            SERD.Top = 0
        End If

        If SERD.Left < 0 Then
            SERD.Left = 0
        End If

        Me.Hide()
        SERD.Show()

    End Sub

End Class
