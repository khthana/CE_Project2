Option Explicit On 
Imports System.IO
Imports System.Data
Imports System.Data.OleDb

Public Class frmCreateFileCDL
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBrowse As System.Windows.Forms.TextBox
    Friend WithEvents btnFinishProgram As System.Windows.Forms.Button
    Friend WithEvents txtClassTemp As System.Windows.Forms.TextBox
    Friend WithEvents txtCreateClass As System.Windows.Forms.TextBox
    Friend WithEvents txtPname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnGenCDL As System.Windows.Forms.Button
    Friend WithEvents btnCreateCDL As System.Windows.Forms.Button
    Friend WithEvents btnChangeWord As System.Windows.Forms.Button
    Friend WithEvents btnCheckCharacter As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBrowse = New System.Windows.Forms.TextBox()
        Me.btnFinishProgram = New System.Windows.Forms.Button()
        Me.btnGenCDL = New System.Windows.Forms.Button()
        Me.btnCreateCDL = New System.Windows.Forms.Button()
        Me.txtClassTemp = New System.Windows.Forms.TextBox()
        Me.txtCreateClass = New System.Windows.Forms.TextBox()
        Me.txtPname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCheckCharacter = New System.Windows.Forms.Button()
        Me.btnChangeWord = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Location = New System.Drawing.Point(40, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 16)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Path File"
        '
        'txtBrowse
        '
        Me.txtBrowse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBrowse.Enabled = False
        Me.txtBrowse.Location = New System.Drawing.Point(96, 48)
        Me.txtBrowse.Name = "txtBrowse"
        Me.txtBrowse.Size = New System.Drawing.Size(280, 20)
        Me.txtBrowse.TabIndex = 23
        Me.txtBrowse.Text = ""
        '
        'btnFinishProgram
        '
        Me.btnFinishProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFinishProgram.Location = New System.Drawing.Point(312, 336)
        Me.btnFinishProgram.Name = "btnFinishProgram"
        Me.btnFinishProgram.Size = New System.Drawing.Size(112, 24)
        Me.btnFinishProgram.TabIndex = 22
        Me.btnFinishProgram.Text = "Finish Process"
        '
        'btnGenCDL
        '
        Me.btnGenCDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenCDL.Location = New System.Drawing.Point(312, 88)
        Me.btnGenCDL.Name = "btnGenCDL"
        Me.btnGenCDL.Size = New System.Drawing.Size(112, 32)
        Me.btnGenCDL.TabIndex = 20
        Me.btnGenCDL.Text = "Generate Class CDL"
        '
        'btnCreateCDL
        '
        Me.btnCreateCDL.Enabled = False
        Me.btnCreateCDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCreateCDL.Location = New System.Drawing.Point(312, 192)
        Me.btnCreateCDL.Name = "btnCreateCDL"
        Me.btnCreateCDL.Size = New System.Drawing.Size(112, 24)
        Me.btnCreateCDL.TabIndex = 21
        Me.btnCreateCDL.Text = "Create file .CDL"
        '
        'txtClassTemp
        '
        Me.txtClassTemp.AcceptsTab = True
        Me.txtClassTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtClassTemp.Location = New System.Drawing.Point(16, 80)
        Me.txtClassTemp.Multiline = True
        Me.txtClassTemp.Name = "txtClassTemp"
        Me.txtClassTemp.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtClassTemp.Size = New System.Drawing.Size(288, 280)
        Me.txtClassTemp.TabIndex = 19
        Me.txtClassTemp.Text = ""
        '
        'txtCreateClass
        '
        Me.txtCreateClass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCreateClass.Location = New System.Drawing.Point(336, 16)
        Me.txtCreateClass.Name = "txtCreateClass"
        Me.txtCreateClass.Size = New System.Drawing.Size(8, 20)
        Me.txtCreateClass.TabIndex = 18
        Me.txtCreateClass.Text = ""
        Me.txtCreateClass.Visible = False
        '
        'txtPname
        '
        Me.txtPname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPname.Enabled = False
        Me.txtPname.Location = New System.Drawing.Point(144, 16)
        Me.txtPname.Name = "txtPname"
        Me.txtPname.Size = New System.Drawing.Size(200, 20)
        Me.txtPname.TabIndex = 17
        Me.txtPname.Text = ""
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(72, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 16)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Project Name"
        '
        'btnCheckCharacter
        '
        Me.btnCheckCharacter.Enabled = False
        Me.btnCheckCharacter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheckCharacter.Location = New System.Drawing.Point(312, 160)
        Me.btnCheckCharacter.Name = "btnCheckCharacter"
        Me.btnCheckCharacter.Size = New System.Drawing.Size(112, 24)
        Me.btnCheckCharacter.TabIndex = 25
        Me.btnCheckCharacter.Text = "Check Character"
        '
        'btnChangeWord
        '
        Me.btnChangeWord.Enabled = False
        Me.btnChangeWord.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChangeWord.Location = New System.Drawing.Point(312, 128)
        Me.btnChangeWord.Name = "btnChangeWord"
        Me.btnChangeWord.Size = New System.Drawing.Size(112, 24)
        Me.btnChangeWord.TabIndex = 26
        Me.btnChangeWord.Text = "Change Word"
        '
        'frmCreateFileCDL
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 374)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnChangeWord, Me.btnCheckCharacter, Me.Label2, Me.txtBrowse, Me.btnFinishProgram, Me.btnGenCDL, Me.btnCreateCDL, Me.txtClassTemp, Me.txtCreateClass, Me.txtPname, Me.Label1})
        Me.Name = "frmCreateFileCDL"
        Me.Text = "Create File CDL"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim pathFile As String = "C:\ERmeta.mdb"

    Dim Conn As OleDbConnection = New OleDbConnection()
    Dim tmpClass() As tempClass
    Dim strFileName As String

    Private Sub frmCreateFileCDL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strConn As String = "Provider=Microsoft.JET.OLEDB.4.0;data source=" & pathFile

        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With
    End Sub

    Private Sub btnGenCDL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenCDL.Click
        Dim frm_name As frmInsertNameProject = New frmInsertNameProject()
        frm_name.Activate() : frm_name.ShowDialog()
        txtPname.Text = frm_name.txtPname.Text
        frm_name.Close()

        If txtPname.Text <> "" Then
            Dim classCDL As CreateClassCDL = New CreateClassCDL()
            classCDL.setConnection(Conn)
            classCDL.GenClassCDL()
            tmpClass = classCDL.tmpClass
            txtClassTemp.Enabled = True
            Dim fileCDL As makeCDL = New makeCDL()
            fileCDL.projectName = CStr(txtPname.Text)
            fileCDL.tmpCDL = tmpClass
            fileCDL.genFileCDL()
            txtClassTemp.Text = fileCDL.tout.Text
            btnChangeWord.Enabled = True
            btnCheckCharacter.Enabled = True
        End If
    End Sub

    Private Sub btnCreateCDL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateCDL.Click
        Dim frm_path As frmInsertPathFile = New frmInsertPathFile()
        frm_path.Activate() : frm_path.ShowDialog()
        txtBrowse.Text = frm_path.txtBrowse.Text
        frm_path.Close()

        Dim chkFile As String = ""
        If (txtBrowse.Text <> "") Then
            chkFile = CStr(txtBrowse.Text)
            Try
                chkFile = chkFile.Substring(chkFile.LastIndexOf("."))
            Catch
                chkFile = ""
            End Try
        End If

        If (chkFile = ".cdl") Then
            If txtPname.Text <> "" Then
                ' ���ҧ��� FileStream
                Dim fout As New FileStream(txtBrowse.Text, IO.FileMode.OpenOrCreate, IO.FileAccess.Write, IO.FileShare.None)
                Dim output As New StreamWriter(fout)
                Try
                    output.WriteLine(txtClassTemp.Text)
                    MessageBox.Show("Create Class " & txtPname.Text & " Complete.", "Create Class", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch
                    MessageBox.Show("Couldn't write data to the file.")
                Finally
                    output.Close()
                    fout.Close()
                End Try
            Else
                MessageBox.Show("You could insert a project name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("You don't input a path file CDL.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnChangeWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeWord.Click
        If txtClassTemp.Text <> "" Then
            Dim old_ck As String = ""
            old_ck = txtClassTemp.SelectedText
            Dim frm_changeword As frmChangeWord = New frmChangeWord()
            frm_changeword.txtOldWord.Text = old_ck
            frm_changeword.Activate() : frm_changeword.ShowDialog()
            Dim new_ck As String = ""
            new_ck = frm_changeword.txtOutput
            old_ck = frm_changeword.txtOldWord.Text

            If frm_changeword.fbtn = True Then
                Dim tmp As String
                tmp = "Do you want to change any words from '" & old_ck & "' to '" & new_ck & "'"
                If MessageBox.Show(tmp, "Confirm changing word", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                    txtClassTemp.Text = txtClassTemp.Text.Replace(old_ck, new_ck)
                End If
            End If

            frm_changeword.Close()
        End If
    End Sub

    Private Sub btnCheckCharacter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckCharacter.Click
        If txtClassTemp.Text <> "" Then
            With txtClassTemp.Text
                txtClassTemp.Text = .Trim
                Dim old_ck As String
                Dim start, finish As Integer
                ' �ҵ��˹� start 
                start = .IndexOf(" ")
                While finish < .Length
                    Dim str As String
                    ' �ҵ��˹� finish
                    finish = .IndexOf(" ", start + 1)
                    If finish = -1 Then finish = .Length
                    str = .Substring(start + 1, finish - start - 1)
                    If str.Length > 31 Then
                        old_ck = .Substring(start + 1, finish - start - 1)
                        ' ��ͧ����¹�� word ����
                        If MessageBox.Show("Error word '" & old_ck & "' is over 32 characters. You should repair it.", "Error 32 Characters", MessageBoxButtons.OK, MessageBoxIcon.Error) = DialogResult.OK Then
                            Dim frm_checkcharacter As frmCheckCharacter = New frmCheckCharacter()
                            frm_checkcharacter.txtErrorWord.Text = old_ck
                            frm_checkcharacter.Activate() : frm_checkcharacter.ShowDialog()
                            Dim new_ck As String
                            new_ck = frm_checkcharacter.txtOutput
                            txtClassTemp.Text = txtClassTemp.Text.Replace(old_ck, new_ck)
                        End If
                    End If
                    start = finish
                End While
            End With
            MessageBox.Show("Complete don't have the character's length over 32 characters.", "Compete file CDL", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnCreateCDL.Enabled = True
        End If
    End Sub

    Private Sub btnFinishProgram_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFinishProgram.Click
        Me.Close()
    End Sub
End Class
