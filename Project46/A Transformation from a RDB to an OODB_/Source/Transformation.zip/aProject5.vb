Option Explicit On 

Public Class aProject5
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnProODL As System.Windows.Forms.Button
    Friend WithEvents btnProCDL As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnExitProgram As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnProODL = New System.Windows.Forms.Button()
        Me.btnProCDL = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExitProgram = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnProODL
        '
        Me.btnProODL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProODL.Location = New System.Drawing.Point(32, 56)
        Me.btnProODL.Name = "btnProODL"
        Me.btnProODL.Size = New System.Drawing.Size(264, 24)
        Me.btnProODL.TabIndex = 6
        Me.btnProODL.Text = "Process Create Class ODL"
        '
        'btnProCDL
        '
        Me.btnProCDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProCDL.Location = New System.Drawing.Point(32, 96)
        Me.btnProCDL.Name = "btnProCDL"
        Me.btnProCDL.Size = New System.Drawing.Size(264, 24)
        Me.btnProCDL.TabIndex = 9
        Me.btnProCDL.Text = "Process Create Class CDL"
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(80, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(176, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Transform ER to Object Schema"
        '
        'btnExitProgram
        '
        Me.btnExitProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExitProgram.Location = New System.Drawing.Point(32, 136)
        Me.btnExitProgram.Name = "btnExitProgram"
        Me.btnExitProgram.Size = New System.Drawing.Size(264, 24)
        Me.btnExitProgram.TabIndex = 11
        Me.btnExitProgram.Text = "Exit Program"
        '
        'aProject5
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 182)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnExitProgram, Me.Label1, Me.btnProODL, Me.btnProCDL})
        Me.Name = "aProject5"
        Me.Text = "Transform ER to Object Schema"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub btnProODL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProODL.Click
        Dim test As frmCreateFileODL = New frmCreateFileODL()
        test.ShowDialog()
        test.Activate()
    End Sub

    Private Sub btnProCDL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProCDL.Click
        Dim test As frmCreateFileCDL = New frmCreateFileCDL()
        test.ShowDialog()
        test.Activate()
    End Sub

    Private Sub btnExitProgram_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExitProgram.Click
        If MessageBox.Show("Do you want to exit program?", "Exit Program", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
End Class