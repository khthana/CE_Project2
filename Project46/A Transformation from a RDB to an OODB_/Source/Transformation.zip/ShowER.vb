Public Class ShowER
    Inherits System.Windows.Forms.Form
    Dim MainForm As Form
    Dim BackForm As Form
    Dim DBcon As DatabaseControl
    Dim ER As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)

        
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents tpeEntityType As System.Windows.Forms.TabPage
    Friend WithEvents tpeRelationshipType As System.Windows.Forms.TabPage
    Friend WithEvents tpeAttribute As System.Windows.Forms.TabPage
    Friend WithEvents tpeCardinality As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dgEEntityType As System.Windows.Forms.DataGrid
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents dgRRelationshipType As System.Windows.Forms.DataGrid
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents dgAAttribute As System.Windows.Forms.DataGrid
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents dgCCardinality As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.tpeEntityType = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dgEEntityType = New System.Windows.Forms.DataGrid()
        Me.tpeRelationshipType = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.dgRRelationshipType = New System.Windows.Forms.DataGrid()
        Me.tpeAttribute = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.dgAAttribute = New System.Windows.Forms.DataGrid()
        Me.tpeCardinality = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.dgCCardinality = New System.Windows.Forms.DataGrid()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tpeEntityType.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgEEntityType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpeRelationshipType.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.dgRRelationshipType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpeAttribute.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.dgAAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpeCardinality.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.dgCCardinality, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(320, 32)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "ER "
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(528, 552)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(96, 24)
        Me.btnNext.TabIndex = 5
        Me.btnNext.Text = "Next"
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(424, 552)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(96, 24)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.Visible = False
        '
        'tpeEntityType
        '
        Me.tpeEntityType.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1})
        Me.tpeEntityType.Location = New System.Drawing.Point(4, 22)
        Me.tpeEntityType.Name = "tpeEntityType"
        Me.tpeEntityType.Size = New System.Drawing.Size(608, 454)
        Me.tpeEntityType.TabIndex = 0
        Me.tpeEntityType.Text = "EntityType"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgEEntityType})
        Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(592, 440)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Entity Type"
        '
        'dgEEntityType
        '
        Me.dgEEntityType.DataMember = ""
        Me.dgEEntityType.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgEEntityType.Location = New System.Drawing.Point(8, 16)
        Me.dgEEntityType.Name = "dgEEntityType"
        Me.dgEEntityType.Size = New System.Drawing.Size(576, 424)
        Me.dgEEntityType.TabIndex = 1
        '
        'tpeRelationshipType
        '
        Me.tpeRelationshipType.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox4})
        Me.tpeRelationshipType.Location = New System.Drawing.Point(4, 22)
        Me.tpeRelationshipType.Name = "tpeRelationshipType"
        Me.tpeRelationshipType.Size = New System.Drawing.Size(608, 454)
        Me.tpeRelationshipType.TabIndex = 1
        Me.tpeRelationshipType.Text = "Relationship Type"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgRRelationshipType})
        Me.GroupBox4.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(592, 440)
        Me.GroupBox4.TabIndex = 1
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Relationship Type"
        '
        'dgRRelationshipType
        '
        Me.dgRRelationshipType.DataMember = ""
        Me.dgRRelationshipType.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgRRelationshipType.Location = New System.Drawing.Point(8, 16)
        Me.dgRRelationshipType.Name = "dgRRelationshipType"
        Me.dgRRelationshipType.Size = New System.Drawing.Size(576, 416)
        Me.dgRRelationshipType.TabIndex = 1
        '
        'tpeAttribute
        '
        Me.tpeAttribute.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox7})
        Me.tpeAttribute.Location = New System.Drawing.Point(4, 22)
        Me.tpeAttribute.Name = "tpeAttribute"
        Me.tpeAttribute.Size = New System.Drawing.Size(608, 454)
        Me.tpeAttribute.TabIndex = 2
        Me.tpeAttribute.Text = "Attribute"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgAAttribute})
        Me.GroupBox7.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(592, 440)
        Me.GroupBox7.TabIndex = 1
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Attribute"
        '
        'dgAAttribute
        '
        Me.dgAAttribute.DataMember = ""
        Me.dgAAttribute.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgAAttribute.Location = New System.Drawing.Point(8, 16)
        Me.dgAAttribute.Name = "dgAAttribute"
        Me.dgAAttribute.Size = New System.Drawing.Size(576, 416)
        Me.dgAAttribute.TabIndex = 1
        '
        'tpeCardinality
        '
        Me.tpeCardinality.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox9})
        Me.tpeCardinality.Location = New System.Drawing.Point(4, 22)
        Me.tpeCardinality.Name = "tpeCardinality"
        Me.tpeCardinality.Size = New System.Drawing.Size(608, 454)
        Me.tpeCardinality.TabIndex = 3
        Me.tpeCardinality.Text = "Cardinality"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgCCardinality})
        Me.GroupBox9.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(592, 440)
        Me.GroupBox9.TabIndex = 2
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Cardinality"
        '
        'dgCCardinality
        '
        Me.dgCCardinality.DataMember = ""
        Me.dgCCardinality.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgCCardinality.Location = New System.Drawing.Point(8, 16)
        Me.dgCCardinality.Name = "dgCCardinality"
        Me.dgCCardinality.Size = New System.Drawing.Size(576, 416)
        Me.dgCCardinality.TabIndex = 2
        '
        'TabControl1
        '
        Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.tpeEntityType, Me.tpeAttribute, Me.tpeRelationshipType, Me.tpeCardinality})
        Me.TabControl1.ItemSize = New System.Drawing.Size(62, 18)
        Me.TabControl1.Location = New System.Drawing.Point(24, 64)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(616, 480)
        Me.TabControl1.TabIndex = 3
        '
        'ShowER
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(664, 614)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnBack, Me.btnNext, Me.TabControl1, Me.Label1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ShowER"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Show ER"
        Me.tpeEntityType.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgEEntityType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpeRelationshipType.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.dgRRelationshipType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpeAttribute.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.dgAAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpeCardinality.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.dgCCardinality, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ShowERDiagram_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ERCon As New ERConverter(DBcon)
        ERCon.ConvertToER()
        ER = ERCon.GetER()

        dgEEntityType.DataSource = ER.Tables("Entity_Type")
        dgRRelationshipType.DataSource = ER.Tables("Relationship_Type")
        dgAAttribute.DataSource = ER.Tables("Attribute")
        dgCCardinality.DataSource = ER.Tables("Entity_Cardinality")

    End Sub

    Public Function SetDatabaseConnection(ByRef con As DatabaseControl)
        Me.DBcon = con
    End Function

    Public Function SetMainForm(ByRef MainForm As Form)
        Me.MainForm = MainForm
    End Function

    Public Function SetBackForm(ByRef BackForm As Form)
        Me.BackForm = BackForm
    End Function


    'dgEEntityType.Update()
    '    dgRRelationshipType.Update()
    '    dgAAttribute.Update()
    '    dgCCardinality.Update()
    

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click

    End Sub



    Private Sub dgEEntityType_Mouseup(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgEEntityType.MouseUp
        Dim EntityID As Integer, RelationshipID As Integer
        Dim i As Integer, j As Integer
        Dim RelationIDList As New ArrayList()
        Dim ERelationshipTypeTable As DataTable
        EntityID = -1
        EntityID = dgEEntityType.Item(dgEEntityType.CurrentCell.RowNumber, 0) ' dgEEntityType.CurrentCell.ColumnNumber)
        If EntityID <> -1 Then
            'MsgBox(EntityID)

            For i = 0 To ER.Tables("Entity_Cardinality").Rows.Count - 1
                If ER.Tables("Entity_Cardinality").Rows(i).Item("Entity_ID") = EntityID Then
                    RelationIDList.Add(ER.Tables("Entity_Cardinality").Rows(i).Item("Relationship_ID"))
                End If
            Next

            'For i = 0 To ER.Tables("Attribute").Rows.Count - 1
            'If ER.Tables("Attribute").Rows(i).Item("Entity_ID") = EntityID _
            'And ER.Tables("Attribute").Rows(i).Item("Entity_ID") = "Entity" Then

            'End If
            'Next

            For i = 0 To RelationIDList.Count - 1
                For j = 0 To ER.Tables("Relationship_Type").Rows.Count - 1
                    If ER.Tables("Relationship_Type").Rows(j).Item("Relationship_ID") = RelationIDList.Item(i) Then
                        'MsgBox(ER.Tables("Relationship_Type").Rows(j).Item("Relationship_ID"))
                    End If
                Next
            Next

            'dgERelate.DataSource = ERelationshipTypeTable
            'SchemaTable = DBcon.GetSchema(TableName)

            'dgAttribute.DataSource = SchemaTable.Tables("SchemaList")
            'dgAttribute.CaptionText = TableName

            'dgForeignKey.DataSource = SchemaTable.Tables("ForeignKeyList")
            'dgForeignKey.CaptionText = TableName
        End If
    End Sub





    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Dim SERD As New aProject5()
        Dim con As New SetDatabase()
        'SERD.SetMainForm(MainForm)
        'SERD.SetDatabaseConnection(DBcon)
        'SERD.SetER(ER)
        
        'Now DBcon is connection to Relational Database .May be change to DataTable or DataSchema
        'SERD.SetBackForm(Me)

        SERD.Top = (MainForm.Top + MainForm.Height / 2) - (SERD.Height / 2)
        SERD.Left = (MainForm.Left + MainForm.Width / 2) - (SERD.Width / 2)

        If SERD.Top < 0 Then
            SERD.Top = 0
        End If
        If SERD.Left < 0 Then
            SERD.Left = 0
        End If

        con.SetRelationalMetaER(ER)
        con.SetDataToObjectMetaER()

        Me.Hide()
        SERD.Show()

    End Sub
End Class
