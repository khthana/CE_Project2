Public Class main
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(488, 312)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(96, 24)
        Me.btnNext.TabIndex = 0
        Me.btnNext.Text = "Next"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label1.Location = New System.Drawing.Point(48, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(528, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "A transformation from a relational database to an object-oriented database"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label2.Location = New System.Drawing.Point(96, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(464, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "��ö����͹�ҹ�����Ũҡ�ҹ�������ԧ����ѹ����ѧ�ҹ�������ԧ�ѵ��"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label3.Location = New System.Drawing.Point(288, 160)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(288, 23)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "�Ҩ�������֡�� ��.��. ����Ե� �Ե����ȸ� "
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label4.Location = New System.Drawing.Point(288, 232)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(288, 24)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "����زԸ�        �ز����ù��   43010413"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Label5.Location = New System.Drawing.Point(288, 272)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(288, 24)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "�������       �Ը�侨Ե��    43010449"
        '
        'main
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(624, 366)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.Label4, Me.Label3, Me.Label2, Me.Label1, Me.btnNext})
        Me.Name = "main"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim SelDB As New SelectDatabase(Me)
        ''SelDB.MdiParent = Me
        'Me.Enabled = False


        'SelDB.Top = (Me.Top + Me.Height / 2) - (SelDB.Height / 2)
        'SelDB.Left = (Me.Top + Me.Width / 2) - (SelDB.Width / 2)

        'SelDB.Show()

    End Sub



    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        End
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim SelDB As New SelectDatabase(Me)
        'SelDB.MdiParent = Me
        Me.Enabled = False


        SelDB.Top = (Me.Top + Me.Height / 2) - (SelDB.Height / 2)
        SelDB.Left = (Me.Top + Me.Width / 2) - (SelDB.Width / 2)

        If SelDB.Top < 0 Then
            SelDB.Top = 0
        End If

        If SelDB.Left < 0 Then
            SelDB.Left = 0
        End If
        SelDB.Show()
    End Sub



    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Dim SelDB As New SelectDatabase(Me)
        'SelDB.MdiParent = Me
        Me.Enabled = False
        Me.Hide()

        SelDB.Top = (Me.Top + Me.Height / 2) - (SelDB.Height / 2)
        SelDB.Left = (Me.Top + Me.Width / 2) - (SelDB.Width / 2)

        SelDB.Show()
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class
