Public Class MetaER

    Dim EntityTable As New DataTable("Entity_Type")
    Dim RelationshipTable As New DataTable("Relationship_Type")
    Dim AttributeTable As New DataTable("Attribute")
    Dim EntityCardinalityTable As New DataTable("Entity_Cardinality")
    Dim RelationshipCardinalityTable As New DataTable("Relationship_Cardinality")
    Dim MetaER As New DataSet("MetaER")

    Sub New()
        Dim ParentColumn As New DataColumn()
        Dim ChildColumn As New DataColumn()
        Dim FKConstraint As ForeignKeyConstraint

        Dim TempColumn1 As New DataColumn()
        TempColumn1.Caption = "Entity_ID"
        TempColumn1.ColumnName = "Entity_ID"
        TempColumn1.AllowDBNull = False
        TempColumn1.DataType = System.Type.GetType("System.Int16")
        TempColumn1.Unique = True
        TempColumn1.AutoIncrement = True
        EntityTable.Columns.Add(TempColumn1)

        Dim TempColumn2 As New DataColumn()
        TempColumn2.Caption = "Entity_Name"
        TempColumn2.ColumnName = "Entity_Name"
        TempColumn2.AllowDBNull = False
        TempColumn2.DataType = System.Type.GetType("System.String")
        TempColumn2.Unique = False
        TempColumn2.AutoIncrement = False
        EntityTable.Columns.Add(TempColumn2)

        Dim TempColumn3 As New DataColumn()
        TempColumn3.Caption = "Entity_Type"
        TempColumn3.ColumnName = "Entity_Type"
        TempColumn3.AllowDBNull = False
        TempColumn3.DataType = System.Type.GetType("System.String")
        TempColumn3.Unique = False
        TempColumn3.AutoIncrement = False
        EntityTable.Columns.Add(TempColumn3)

        Dim TempColumn18 As New DataColumn()
        TempColumn18.Caption = "Entity_NumberOfPrimaryKey"
        TempColumn18.ColumnName = "Entity_NumberOfPrimaryKey"
        TempColumn18.AllowDBNull = False
        TempColumn18.DataType = System.Type.GetType("System.String")
        TempColumn18.Unique = False
        TempColumn18.AutoIncrement = False
        EntityTable.Columns.Add(TempColumn18)

        Dim TempColumn22 As New DataColumn()
        TempColumn22.Caption = "Entity_SuperClass"
        TempColumn22.ColumnName = "Entity_SuperClass"
        TempColumn22.AllowDBNull = False
        TempColumn22.DataType = System.Type.GetType("System.String")
        TempColumn22.Unique = False
        TempColumn22.AutoIncrement = False
        EntityTable.Columns.Add(TempColumn22)

        Dim TempColumn4 As New DataColumn()
        TempColumn4.Caption = "Relationship_ID"
        TempColumn4.ColumnName = "Relationship_ID"
        TempColumn4.AllowDBNull = False
        TempColumn4.DataType = System.Type.GetType("System.Int16")
        TempColumn4.Unique = True
        TempColumn4.AutoIncrement = True
        RelationshipTable.Columns.Add(TempColumn4)

        Dim TempColumn5 As New DataColumn()
        TempColumn5.Caption = "Relationship_Name"
        TempColumn5.ColumnName = "Relationship_Name"
        TempColumn5.AllowDBNull = False
        TempColumn5.DataType = System.Type.GetType("System.String")
        TempColumn5.Unique = False
        TempColumn5.AutoIncrement = False
        RelationshipTable.Columns.Add(TempColumn5)

        Dim TempColumn23 As New DataColumn()
        TempColumn23.Caption = "Relationship_ShowName"
        TempColumn23.ColumnName = "Relationship_ShowName"
        TempColumn23.AllowDBNull = False
        TempColumn23.DataType = System.Type.GetType("System.String")
        TempColumn23.Unique = False
        TempColumn23.AutoIncrement = False
        RelationshipTable.Columns.Add(TempColumn23)

        Dim TempColumn24 As New DataColumn()
        TempColumn24.Caption = "Relationship_Type"
        TempColumn24.ColumnName = "Relationship_Type"
        TempColumn24.AllowDBNull = False
        TempColumn24.DataType = System.Type.GetType("System.String")
        TempColumn24.Unique = False
        TempColumn24.AutoIncrement = False
        RelationshipTable.Columns.Add(TempColumn24)

        Dim TempColumn6 As New DataColumn()
        TempColumn6.Caption = "Attribute_ID"
        TempColumn6.ColumnName = "Attribute_ID"
        TempColumn6.AllowDBNull = False
        TempColumn6.DataType = System.Type.GetType("System.Int16")
        TempColumn6.Unique = True
        TempColumn6.AutoIncrement = True
        AttributeTable.Columns.Add(TempColumn6)

        Dim TempColumn7 As New DataColumn()
        TempColumn7.Caption = "Attribute_Name"
        TempColumn7.ColumnName = "Attribute_Name"
        TempColumn7.AllowDBNull = False
        TempColumn7.DataType = System.Type.GetType("System.String")
        TempColumn7.Unique = False
        TempColumn7.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn7)

        Dim TempColumn8 As New DataColumn()
        TempColumn8.Caption = "Attribute_Type"
        TempColumn8.ColumnName = "Attribute_Type"
        TempColumn8.AllowDBNull = False
        TempColumn8.DataType = System.Type.GetType("System.String")
        TempColumn8.Unique = False
        TempColumn8.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn8)

        Dim TempColumn9 As New DataColumn()
        TempColumn9.Caption = "Attribute_DataType"
        TempColumn9.ColumnName = "Attribute_DataType"
        TempColumn9.AllowDBNull = False
        TempColumn9.DataType = System.Type.GetType("System.String")
        TempColumn9.Unique = False
        TempColumn9.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn9)

        Dim TempColumn10 As New DataColumn()
        TempColumn10.Caption = "Attribute_Belong"
        TempColumn10.ColumnName = "Attribute_Belong"
        TempColumn10.AllowDBNull = False
        TempColumn10.DataType = System.Type.GetType("System.String")
        TempColumn10.Unique = False
        TempColumn10.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn10)

        Dim TempColumn11 As New DataColumn()
        TempColumn11.Caption = "Attribute_BelongType"
        TempColumn11.ColumnName = "Attribute_BelongType"
        TempColumn11.AllowDBNull = False
        TempColumn11.DataType = System.Type.GetType("System.String")
        TempColumn11.Unique = False
        TempColumn11.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn11)

        Dim TempColumn12 As New DataColumn()
        TempColumn12.Caption = "Attribute_PrimaryKey"
        TempColumn12.ColumnName = "Attribute_PrimaryKey"
        TempColumn12.AllowDBNull = False
        TempColumn12.DataType = System.Type.GetType("System.Boolean")
        TempColumn12.Unique = False
        TempColumn12.AutoIncrement = False
        AttributeTable.Columns.Add(TempColumn12)

        Dim TempColumn13 As New DataColumn()
        TempColumn13.Caption = "Entity_ID"
        TempColumn13.ColumnName = "Entity_ID"
        TempColumn13.AllowDBNull = False
        TempColumn13.DataType = System.Type.GetType("System.Int16")
        TempColumn13.Unique = False
        TempColumn13.AutoIncrement = False
        EntityCardinalityTable.Columns.Add(TempColumn13)

        Dim TempColumn14 As New DataColumn()
        TempColumn14.Caption = "Relationship_ID"
        TempColumn14.ColumnName = "Relationship_ID"
        TempColumn14.AllowDBNull = False
        TempColumn14.DataType = System.Type.GetType("System.Int16")
        TempColumn14.Unique = False
        TempColumn14.AutoIncrement = False
        EntityCardinalityTable.Columns.Add(TempColumn14)

        'Dim TempColumn15 As New DataColumn()
        'TempColumn15.Caption = "Relation_Name"
        'TempColumn15.ColumnName = "Relation_Name"
        'TempColumn15.AllowDBNull = False
        'TempColumn15.DataType = System.Type.GetType("System.String")
        'TempColumn15.Unique = True
        'TempColumn15.AutoIncrement = False
        'RelationTable.Columns.Add(TempColumn15)

        'Dim TempColumn16 As New DataColumn()
        'TempColumn16.Caption = "CardinalityOfEntity"
        'TempColumn16.ColumnName = "CardinalityOfEntity"
        'TempColumn16.AllowDBNull = False
        'TempColumn16.DataType = System.Type.GetType("System.String")
        'TempColumn16.Unique = False
        'TempColumn16.AutoIncrement = False
        'CardinalityTable.Columns.Add(TempColumn16)

        Dim TempColumn17 As New DataColumn()
        TempColumn17.Caption = "NumberOfCardinality"
        TempColumn17.ColumnName = "NumberOfCardinality"
        TempColumn17.AllowDBNull = False
        TempColumn17.DataType = System.Type.GetType("System.String")
        TempColumn17.Unique = False
        TempColumn17.AutoIncrement = False
        EntityCardinalityTable.Columns.Add(TempColumn17)


        Dim TempColumn19 As New DataColumn()
        TempColumn19.Caption = "ERelationship_ID"
        TempColumn19.ColumnName = "ERelationship_ID"
        TempColumn19.AllowDBNull = False
        TempColumn19.DataType = System.Type.GetType("System.Int16")
        TempColumn19.Unique = False
        TempColumn19.AutoIncrement = False
        RelationshipCardinalityTable.Columns.Add(TempColumn19)

        Dim TempColumn20 As New DataColumn()
        TempColumn20.Caption = "Relationship_ID"
        TempColumn20.ColumnName = "Relationship_ID"
        TempColumn20.AllowDBNull = False
        TempColumn20.DataType = System.Type.GetType("System.Int16")
        TempColumn20.Unique = False
        TempColumn20.AutoIncrement = False
        RelationshipCardinalityTable.Columns.Add(TempColumn20)

        Dim TempColumn21 As New DataColumn()
        TempColumn21.Caption = "NumberOfCardinality"
        TempColumn21.ColumnName = "NumberOfCardinality"
        TempColumn21.AllowDBNull = False
        TempColumn21.DataType = System.Type.GetType("System.String")
        TempColumn21.Unique = False
        TempColumn21.AutoIncrement = False
        RelationshipCardinalityTable.Columns.Add(TempColumn21)

        MetaER.Tables.Add(EntityTable)
        MetaER.Tables.Add(RelationshipTable)
        MetaER.Tables.Add(AttributeTable)
        MetaER.Tables.Add(EntityCardinalityTable)
        MetaER.Tables.Add(RelationshipCardinalityTable)


        ParentColumn = MetaER.Tables("Entity_Type").Columns("Entity_ID")
        ChildColumn = MetaER.Tables("Entity_Cardinality").Columns("Entity_ID")
        FKConstraint = New ForeignKeyConstraint("EntityTypeFKConstraint", ParentColumn, ChildColumn)
        FKConstraint.DeleteRule = Rule.Cascade
        FKConstraint.UpdateRule = Rule.Cascade
        FKConstraint.AcceptRejectRule = AcceptRejectRule.Cascade
        MetaER.Tables("Entity_Cardinality").Constraints.Add(FKConstraint)

        ParentColumn = MetaER.Tables("Relationship_Type").Columns("Relationship_ID")
        ChildColumn = MetaER.Tables("Entity_Cardinality").Columns("Relationship_ID")
        FKConstraint = New ForeignKeyConstraint("RelationshipTypeFKConstraint", ParentColumn, ChildColumn)
        FKConstraint.DeleteRule = Rule.Cascade
        FKConstraint.UpdateRule = Rule.Cascade
        FKConstraint.AcceptRejectRule = AcceptRejectRule.Cascade
        MetaER.Tables("Entity_Cardinality").Constraints.Add(FKConstraint)

        ParentColumn = MetaER.Tables("Relationship_Type").Columns("Relationship_ID")
        ChildColumn = MetaER.Tables("Relationship_Cardinality").Columns("ERelationship_ID")
        FKConstraint = New ForeignKeyConstraint("EntityTypeFKConstraint", ParentColumn, ChildColumn)
        FKConstraint.DeleteRule = Rule.Cascade
        FKConstraint.UpdateRule = Rule.Cascade
        FKConstraint.AcceptRejectRule = AcceptRejectRule.Cascade
        MetaER.Tables("Relationship_Cardinality").Constraints.Add(FKConstraint)

        ParentColumn = MetaER.Tables("Relationship_Type").Columns("Relationship_ID")
        ChildColumn = MetaER.Tables("Relationship_Cardinality").Columns("Relationship_ID")
        FKConstraint = New ForeignKeyConstraint("RelationshipTypeFKConstraint", ParentColumn, ChildColumn)
        FKConstraint.DeleteRule = Rule.Cascade
        FKConstraint.UpdateRule = Rule.Cascade
        FKConstraint.AcceptRejectRule = AcceptRejectRule.Cascade
        MetaER.Tables("Relationship_Cardinality").Constraints.Add(FKConstraint)

        MetaER.EnforceConstraints = True

    End Sub

    Function InsertEntityTable(ByRef Entity_Name As String, ByRef Entity_Type As String, ByRef Entity_NumberOfPrimaryKey As Integer)
        Dim nRow As DataRow
        nRow = MetaER.Tables("Entity_Type").NewRow()
        nRow("Entity_Name") = Entity_Name
        nRow("Entity_Type") = Entity_Type
        nRow("Entity_NumberOfPrimaryKey") = Entity_NumberOfPrimaryKey
        nRow("Entity_SuperClass") = ""
        MetaER.Tables("Entity_Type").Rows.Add(nRow)
    End Function

    Function InsertEntityTable(ByRef Entity_Name As String, ByRef Entity_Type As String, ByRef Entity_NumberOfPrimaryKey As Integer, _
        ByVal Entity_SuperClass As String)
        Dim nRow As DataRow
        nRow = MetaER.Tables("Entity_Type").NewRow()
        nRow("Entity_Name") = Entity_Name
        nRow("Entity_Type") = Entity_Type
        nRow("Entity_NumberOfPrimaryKey") = Entity_NumberOfPrimaryKey
        nRow("Entity_SuperClass") = Entity_NumberOfPrimaryKey
        MetaER.Tables("Entity_Type").Rows.Add(nRow)
    End Function

    Function InsertRelationshipTable(ByRef Relationship_Name As String, ByRef Relationship_Type As String)
        Dim nRow As DataRow
        nRow = MetaER.Tables("Relationship_Type").NewRow()
        nRow("Relationship_Name") = Relationship_Name
        nRow("Relationship_ShowName") = ""
        nRow("Relationship_Type") = Relationship_Type
        MetaER.Tables("Relationship_Type").Rows.Add(nRow)
    End Function

    Function InsertRelationshipTable(ByRef Relationship_Name As String, ByRef Relationship_Type As String, _
     ByRef Relationship_ShowName As String)
        Dim nRow As DataRow
        nRow = MetaER.Tables("Relationship_Type").NewRow()
        nRow("Relationship_Name") = Relationship_Name
        nRow("Relationship_ShowName") = Relationship_ShowName
        nRow("Relationship_Type") = Relationship_Type
        MetaER.Tables("Relationship_Type").Rows.Add(nRow)
    End Function

    Function InsertAttributeTable(ByRef Attribute_Name As String, ByRef Attribute_Type As String, _
                ByRef Attribute_DataType As String, ByRef Attribute_Belong As Integer, _
                ByRef Attribute_BelongType As String, ByRef Attribute_PrimaryKey As Boolean)
        Dim nRow As DataRow
        nRow = MetaER.Tables("Attribute").NewRow()
        nRow("Attribute_Name") = Attribute_Name
        nRow("Attribute_Type") = Attribute_Type
        nRow("Attribute_DataType") = Attribute_DataType
        nRow("Attribute_Belong") = Attribute_Belong
        nRow("Attribute_BelongType") = Attribute_BelongType
        nRow("Attribute_PrimaryKey") = Attribute_PrimaryKey
        MetaER.Tables("Attribute").Rows.Add(nRow)
    End Function

    Function InsertEntityCardinalityTable(ByRef Entity_ID As Integer, ByRef Relationship_ID As Integer, _
                ByRef NumberOfCardinality As String)

        Dim nRow As DataRow
        nRow = MetaER.Tables("Entity_Cardinality").NewRow()
        nRow("Entity_ID") = Entity_ID
        nRow("Relationship_ID") = Relationship_ID
        'nRow("Relation_Name") = Relation_Name
        nRow("NumberOfCardinality") = NumberOfCardinality
        'nRow("CardinalityofRelationship") = CardinalityofRelationship
        MetaER.Tables("Entity_Cardinality").Rows.Add(nRow)

    End Function

    Function InsertRelationshipCardinalityTable(ByRef ERelationship_ID As Integer, ByRef Relationship_ID As Integer, _
                ByRef NumberOfCardinality As String)

        Dim nRow As DataRow
        nRow = MetaER.Tables("Relationship_Cardinality").NewRow()
        nRow("ERelationship_ID") = ERelationship_ID
        nRow("Relationship_ID") = Relationship_ID
        'nRow("Relation_Name") = Relation_Name
        nRow("NumberOfCardinality") = NumberOfCardinality
        'nRow("CardinalityofRelationship") = CardinalityofRelationship
        MetaER.Tables("Relationship_Cardinality").Rows.Add(nRow)

    End Function

    Function FindEntity(ByRef Entity_Name As String) As Integer
        Dim I As Integer
        For I = 0 To MetaER.Tables("Entity_Type").Rows.Count() - 1
            If MetaER.Tables("Entity_Type").Rows(I).Item("Entity_Name") = Entity_Name Then
                Return MetaER.Tables("Entity_Type").Rows(I).Item("Entity_ID")
            End If
        Next
        Return -1
    End Function

    Function FindRelationship(ByRef Relationship_Name As String) As Integer
        Dim I As Integer
        For I = 0 To MetaER.Tables("Relationship_Type").Rows.Count() - 1
            If MetaER.Tables("Relationship_Type").Rows(I).Item("Relationship_Name") = Relationship_Name Then
                Return MetaER.Tables("Relationship_Type").Rows(I).Item("Relationship_ID")
            End If
        Next
        Return -1
    End Function

    Function FindAttribute(ByRef Attribute_Name As String) As Integer
        Dim I As Integer
        For I = 0 To MetaER.Tables("Attribute").Rows.Count() - 1
            If MetaER.Tables("Attribute").Rows(I).Item("Attribute_Name") = Attribute_Name Then
                Return MetaER.Tables("Attribute").Rows(I).Item("Attribute_ID")
            End If
        Next
        Return -1
    End Function

    Function InsertSuperClass(ByVal SuperClassTableName As String, ByVal SubClassTableName As String)
        Dim SubClassEntityID As Integer, i As Integer
        SubClassEntityID = FindEntity(SubClassTableName)
        For i = 0 To MetaER.Tables("Entity_Type").Rows.Count - 1
            If MetaER.Tables("Entity_Type").Rows(i).Item("Entity_ID") = SubClassEntityID Then
                MetaER.Tables("Entity_Type").Rows(i).Item("Entity_SuperClass") = SuperClassTableName
            End If
        Next

    End Function

    Function GetMetaER() As DataSet
        Dim ER As DataSet
        ER = MetaER
        Return ER
    End Function
End Class
