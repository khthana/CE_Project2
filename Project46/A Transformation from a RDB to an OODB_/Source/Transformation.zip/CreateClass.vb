Imports System.Data
Imports System.Data.OleDb

Public Class CreateClass
    Protected projectName As String
    Protected total As Integer
    Protected nary() As Integer
    Protected manyAttribute() As Integer
    Protected relationHasAttribute() As String
    Protected da As OleDbDataAdapter
    Public Conn As OleDbConnection
    Public ds As DataSet

    Public Sub setConnection(ByVal conn As OleDbConnection)
        Me.Conn = conn
    End Sub

    '####################################################
    '       fn ����¹��ҵ����ʵ�ԧ����á����繵���ѡ�õ���˭�
    '           input: string
    '           output: string (������ѡ�õ���á�繵���˭�)
    '####################################################
    Function change_first_char_to_upper(ByVal str As String) As String
        Dim temp As String = ""
        temp = str : str = str.ToLower
        ' ����¹�ǡ data type ��鹰ҹ��ҧ�
        If str = "boolean" Then
            temp = "Boolean"
        ElseIf str = "integer" Then
            temp = "Integer"
        ElseIf str = "float" Then
            temp = "Float"
        ElseIf str = "string" Then
            temp = "String"
        ElseIf str = "stream" Then
            temp = "Stream"
        ElseIf str = "date" Then
            temp = "Date"
        ElseIf str = "time" Then
            temp = "Time"
        ElseIf str = "binary" Then
            temp = "Binary"
        End If
        Return temp
    End Function

    '####################################################
    '       fn ��Ǩ�ͺ��� rid 㹵���� array integer
    '           input: array_integer(), rid
    '           output: boolean (���� = T, ������� = F)
    '####################################################
    Function find_rid_in_array_integer(ByVal a() As Integer, ByVal b As Integer) As Boolean
        Dim i As Integer = 0
        While i < a.Length
            If a(i) <> -1 Then
                If b = a(i) Then Return True
            Else
                Return False
            End If
            i += 1
        End While
        Return False
    End Function

    '####################################################
    '       fn ����� index ����ժ��ͤ�����ҡѺ����� b 㹵���� array tempClass
    '           input: tempClass(), string (���ͤ��ʷ���ͧ�����)
    '           output: integer (��� index �ͧ���ͤ���)
    '####################################################
    Function get_index_in_create_class(ByVal a() As tempClass, ByVal b As String) As Integer
        Dim i As Integer = 0
        While i < a.Length
            If a(i).className = b Then Return i
            i += 1
        End While
        Return -1
    End Function

    '####################################################
    '       fn �Ҩӹǹ attribute �������ͧ eid 㹵���� array reAttribute
    '           input: reAttribute(), integer (eid)
    '           output: integer (�ӹǹ attribute �������ͧ eid ����Դ�ҡ relationship ����� attribute)
    '####################################################
    Function get_num_total_in_relation_attribute(ByVal a() As String, ByVal b As Integer) As Integer
        Dim i, total As Integer : i = 0 : total = 0
        While i < a.Length
            Dim tmp(3) As String
            tmp = a(i).Split(":")
            If (tmp(1).Equals(CStr(b)) = True) Then
                total += CInt(tmp(2))
            End If
            i += 1
        End While
        Return total
    End Function

    '####################################################
    '       fn �� index �������ͧ eid 㹵���� array reAttribute
    '           input: reAttribute(), integer (eid)
    '           output: integer() (array index �������ͧ eid)
    '####################################################
    Function get_indexs_eid_in_relation_attribute(ByVal a() As String, ByVal b As Integer) As Integer()
        Dim i, rows As Integer : i = 0 : rows = 0
        While i < a.Length
            Dim tmp(3) As String
            tmp = a(i).Split(":")
            If (tmp(1).Equals(CStr(b)) = True) Then rows += 1
            i += 1
        End While
        Dim j, idxs(rows - 1) As Integer : i = 0 : j = 0
        While (i < a.Length) And (j < idxs.Length)
            Dim tmp(3) As String
            tmp = a(i).Split(":")
            If (tmp(1).Equals(CStr(b)) = True) Then
                idxs(j) = i : j += 1
            End If
            i += 1
        End While
        Return idxs
    End Function

    '####################################################
    '       �ʴ����ʷ�����ҧ����ҷ�������к� ��ҹ�ҧ MessageBox
    '           input: tempClass()
    '####################################################
    Sub showClass(ByVal tmpClass() As tempClass)
        Dim ss As String : Dim i As Integer
        i = 0 : ss = ""
        MessageBox.Show("Class Total = " & tmpClass.Length)
        While i < tmpClass.Length
            ss = "Class name : "
            ss = ss & tmpClass(i).className & vbCrLf & vbCrLf & "Attribute:" & vbCrLf

            Dim j As Integer = 0
            While j < tmpClass(i).attribute.Length
                ss = ss & tmpClass(i).attribute(j) & vbCrLf
                j += 1
            End While
            ss = ss & vbCrLf & "Relationship:" & vbCrLf
            j = 0
            While j < tmpClass(i).relationship.Length
                ss = ss & tmpClass(i).relationship(j) & vbCrLf
                j += 1
            End While

            MessageBox.Show(ss)
            i += 1
        End While
    End Sub

End Class
