Public Class tempClass
    Public className As String
    Public superName As String
    Public attribute() As String
    Public relationship() As String

    Public Sub setArrayToAttribute(ByVal count As Integer)
        ReDim Me.attribute(count)
    End Sub

    Public Sub setArrayToRelationship(ByVal count As Integer)
        ReDim Me.relationship(count)
    End Sub

    Public Function getLastIndex() As Integer
        Dim i As Integer = 0
        While i < relationship.Length
            If relationship(i) = "" Then Return i
            i += 1
        End While
        Return 0
    End Function
End Class
