Imports System.Data.OleDb
Imports System.Data

Public Class DatabaseControl
    Dim DatabaseName As String
    Dim OleDBCon As New OleDbConnection()
    Dim StringTestConnection As String

    Sub New()
        StringTestConnection = ""
    End Sub

    Sub New(ByRef ConnectionType As Integer, ByVal FileName As String, _
        ByVal UserName As String, ByVal Password As String)
        DatabaseName = FileName
        StringTestConnection = ""
        StringTestConnection = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=" & UserName & _
                                       ";Password=" & Password & ";"
        StringTestConnection = StringTestConnection & "Data Source=" & FileName
        OleDBCon.ConnectionString = StringTestConnection

    End Sub

    Sub ChangeConnection(ByRef ConnectionType As Integer, ByVal Filename As String, _
    ByVal UserName As String, ByVal Password As String)
        DatabaseName = Filename
        StringTestConnection = ""
        StringTestConnection = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=" & UserName & _
                                       ";Password=" & Password & ";"
        StringTestConnection = StringTestConnection & "Data Source=" & Filename
        OleDBCon.ConnectionString = StringTestConnection
    End Sub

    'Public Function AccessConnect()
    '    MsgBox("����ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
    'End Function

    Public Function GetDatabaseName() As String
        Return DatabaseName
    End Function

    Public Function GetPrimaryKey() As DataTable
        Dim ListPrimaryKey As New DataTable()
        Dim PrimaryKeyTable As New DataTable()
        Dim i As Integer

        PrimaryKeyTable.Columns.Add("TableName", Type.GetType("System.String"))
        PrimaryKeyTable.Columns.Add("PrimaryKey", Type.GetType("System.String"))

        If Me.TestOpen() Then
            OleDBCon.Open()
            ListPrimaryKey = OleDBCon.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, Nothing)
            OleDBCon.Close()
            For i = 0 To ListPrimaryKey.Rows.Count - 1
                Dim rowAttribute As DataRow
                rowAttribute = PrimaryKeyTable.NewRow
                rowAttribute("TableName") = ListPrimaryKey.Rows(i).Item("TABLE_NAME")
                rowAttribute("PrimaryKey") = ListPrimaryKey.Rows(i).Item("COLUMN_NAME")
                PrimaryKeyTable.Rows.Add(rowAttribute)
            Next
            Return PrimaryKeyTable
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Private Function GetPrimaryKey(ByRef TableName As String) As DataTable
        Dim ListPrimaryKey As New DataTable()
        Dim PrimaryKeyTable As New DataTable()
        Dim i As Integer

        PrimaryKeyTable.Columns.Add("PrimaryKey", Type.GetType("System.String"))

        If Me.TestOpen() Then
            OleDBCon.Open()
            ListPrimaryKey = OleDBCon.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, New Object() _
            {Nothing, Nothing, TableName})
            OleDBCon.Close()
            For i = 0 To ListPrimaryKey.Rows.Count - 1
                Dim rowAttribute As DataRow
                rowAttribute = PrimaryKeyTable.NewRow
                rowAttribute("PrimaryKey") = ListPrimaryKey.Rows(i).Item("COLUMN_NAME")
                PrimaryKeyTable.Rows.Add(rowAttribute)
            Next
            Return PrimaryKeyTable
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Public Function GetForeignKey() As DataTable
        Dim ListForeignKey As New DataTable()
        Dim ForeignKeyTable As New DataTable()
        Dim i As Integer

        ForeignKeyTable.Columns.Add("PrimaryKeyTable", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("PrimaryKey", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("ForeignKeyTable", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("ForeignKey", Type.GetType("System.String"))

        If Me.TestOpen() Then
            OleDBCon.Open()
            ListForeignKey = OleDBCon.GetOleDbSchemaTable(OleDbSchemaGuid.Foreign_Keys, Nothing)
            OleDBCon.Close()
            For i = 0 To ListForeignKey.Rows.Count - 1
                Dim rowAttribute As DataRow
                rowAttribute = ForeignKeyTable.NewRow
                rowAttribute("PrimaryKeyTable") = ListForeignKey.Rows(i).Item("PK_TABLE_NAME")
                rowAttribute("PrimaryKey") = ListForeignKey.Rows(i).Item("PK_COLUMN_NAME")
                rowAttribute("ForeignKeyTable") = ListForeignKey.Rows(i).Item("FK_TABLE_NAME")
                rowAttribute("ForeignKey") = ListForeignKey.Rows(i).Item("FK_COLUMN_NAME")
                ForeignKeyTable.Rows.Add(rowAttribute)
            Next
            Return ForeignKeyTable
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Private Function GetForeignKey(ByRef TableName As String) As DataTable
        Dim ListForeignKey As New DataTable()
        Dim ForeignKeyTable As New DataTable()
        Dim i As Integer

        ForeignKeyTable.Columns.Add("PrimaryKeyTable", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("PrimaryKey", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("ForeignKeyTable", Type.GetType("System.String"))
        ForeignKeyTable.Columns.Add("ForeignKey", Type.GetType("System.String"))

        If Me.TestOpen() Then
            OleDBCon.Open()
            ListForeignKey = OleDBCon.GetOleDbSchemaTable(OleDbSchemaGuid.Foreign_Keys, New Object() _
            {Nothing, Nothing, TableName})
            OleDBCon.Close()
            For i = 0 To ListForeignKey.Rows.Count - 1
                Dim rowAttribute As DataRow
                rowAttribute = ForeignKeyTable.NewRow
                rowAttribute("PrimaryKeyTable") = ListForeignKey.Rows(i).Item("PK_TABLE_NAME")
                rowAttribute("PrimaryKey") = ListForeignKey.Rows(i).Item("PK_COLUMN_NAME")
                rowAttribute("ForeignKeyTable") = ListForeignKey.Rows(i).Item("FK_TABLE_NAME")
                rowAttribute("ForeignKey") = ListForeignKey.Rows(i).Item("FK_COLUMN_NAME")
                ForeignKeyTable.Rows.Add(rowAttribute)
            Next
            Return ForeignKeyTable
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Public Function GetTableName() As DataTable
        Dim ListTableName As New DataTable()
        Dim TableName As New DataTable()
        Dim i As Integer
        TableName.Columns.Add("TableName", Type.GetType("System.String"))

        If Me.TestOpen() Then
            OleDBCon.Open()
            ListTableName = OleDBCon.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, New Object() _
            {Nothing, Nothing, Nothing, "Table"})
            OleDBCon.Close()
            For i = 0 To ListTableName.Rows.Count - 1
                Dim rowAttribute As DataRow
                rowAttribute = TableName.NewRow
                rowAttribute("TableName") = ListTableName.Rows(i).Item("TABLE_NAME")
                TableName.Rows.Add(rowAttribute)
            Next i

            Return TableName
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Public Function GetSchema(ByRef TableName As String) As DataSet
        Dim dbAdapter As OleDbDataAdapter = New OleDbDataAdapter()
        Dim sFieldInfo, sDataType As String
        Dim sTableName As String
        Dim i As Integer, j As Integer
        Dim dbDataSet As DataSet = New DataSet()

        sTableName = TableName

        Dim selectCMD As OleDbCommand = New OleDbCommand("SELECT * FROM " & "[" & _
            sTableName & "]", OleDBCon)
        dbAdapter.SelectCommand = selectCMD
        dbDataSet.Clear()
        dbAdapter.Fill(dbDataSet, sTableName)

        'Create DataTable for contain List of Primary key
        Dim PrimaryKeyListTable = New DataTable("PrimaryKeyList")
        PrimaryKeyListTable = Me.GetPrimaryKey(TableName)
        PrimaryKeyListTable.TableName = "PrimaryKeyList"

        'Create DataTable for contain List of Foreign key
        Dim ForeignKeyListTable = New DataTable("ForeignKeyList")
        ForeignKeyListTable = Me.GetForeignKey(TableName)
        ForeignKeyListTable.TableName = "ForeignKeyList"

        'Create DataSet For save Relational Schema
        Dim SchemaDataSet = New DataSet()
        Dim SchemaListTable = New DataTable("SchemaList")

        SchemaListTable.Columns.add("AttributeName", Type.GetType("System.String"))
        SchemaListTable.Columns.add("DataType", Type.GetType("System.String"))
        SchemaListTable.Columns.add("PrimaryKey", Type.GetType("System.Boolean"))

        SchemaDataSet.tables.add(SchemaListTable)

        For i = 0 To dbDataSet.Tables(0).Columns.Count - 1
            Dim rowAttribute As DataRow
            With dbDataSet.Tables(0).Columns(i)
                rowAttribute = SchemaListTable.newrow
                rowAttribute("AttributeName") = .ColumnName
                rowAttribute("DataType") = .DataType.ToString.Substring(InStrRev(.DataType.ToString, "."))

                For j = 0 To PrimaryKeyListTable.rows.count() - 1
                    If .ColumnName = PrimaryKeyListTable.rows(j).Item("PrimaryKey") Then
                        rowAttribute("PrimaryKey") = True
                        Exit For
                    Else
                        rowAttribute("PrimaryKey") = False
                    End If
                Next
            End With
            SchemaListTable.rows.add(rowAttribute)
        Next

        SchemaDataSet.tables.add(PrimaryKeyListTable)
        SchemaDataSet.tables.add(ForeignKeyListTable)
        Return SchemaDataSet
    End Function

    Public Function GetSchema() As DataSet
        Dim dbAdapter As OleDbDataAdapter = New OleDbDataAdapter()
        Dim sFieldInfo, sDataType As String
        Dim sTableName As String
        Dim i As Integer, j As Integer, k As Integer
        Dim dbDataSet As DataSet = New DataSet()

        'Create DataTable for contain List of Primary key
        Dim PrimaryKeyListTable = New DataTable("PrimaryKeyList")
        PrimaryKeyListTable = Me.GetPrimaryKey()
        PrimaryKeyListTable.TableName = "PrimaryKeyList"

        'Create DataTable for contain List of Foreign key
        Dim ForeignKeyListTable = New DataTable("ForeignKeyList")
        ForeignKeyListTable = Me.GetForeignKey()
        ForeignKeyListTable.TableName = "ForeignKeyList"

        'Get TableName from GetTableName()
        Dim TableName = New DataTable("TableNameList")
        TableName = Me.GetTableName

        'Create DataSet For save Relational Schema
        Dim SchemaDataSet = New DataSet()
        Dim SchemaListTable = New DataTable("SchemaList")

        SchemaListTable.Columns.add("TableName", Type.GetType("System.String"))
        SchemaListTable.Columns.add("AttributeName", Type.GetType("System.String"))
        SchemaListTable.Columns.add("DataType", Type.GetType("System.String"))
        SchemaListTable.Columns.add("PrimaryKey", Type.GetType("System.Boolean"))
        SchemaDataSet.tables.add(SchemaListTable)



        For k = 0 To TableName.rows.count() - 1

            sTableName = TableName.rows(k).item("TableName")

            Dim selectCMD As OleDbCommand = New OleDbCommand("SELECT * FROM " & "[" & _
                sTableName & "]", OleDBCon)
            dbAdapter.SelectCommand = selectCMD
            dbDataSet.Clear()
            dbAdapter.Fill(dbDataSet, sTableName)


            For i = 0 To dbDataSet.Tables(sTableName).Columns.Count - 1
                Dim rowAttribute As DataRow
                With dbDataSet.Tables(sTableName).Columns(i)
                    rowAttribute = SchemaListTable.newrow
                    rowAttribute("TableName") = TableName.rows(k).item("TableName")
                    rowAttribute("AttributeName") = .ColumnName
                    rowAttribute("DataType") = .DataType.ToString.Substring(InStrRev(.DataType.ToString, "."))

                    For j = 0 To PrimaryKeyListTable.rows.count() - 1
                        If sTableName = PrimaryKeyListTable.rows(j).Item("TableName") Then
                            If .ColumnName = PrimaryKeyListTable.rows(j).Item("PrimaryKey") Then
                                rowAttribute("PrimaryKey") = True
                                Exit For
                            Else
                                rowAttribute("PrimaryKey") = False
                            End If
                        End If
                    Next
                End With
                SchemaListTable.rows.add(rowAttribute)
            Next

        Next
        SchemaDataSet.tables.add(PrimaryKeyListTable)
        SchemaDataSet.tables.add(ForeignKeyListTable)
        Return SchemaDataSet
    End Function

    Public Function TestOpen() As Boolean
        Try
            OleDBCon.Open()
            Return True
        Catch
            Return False
        Finally
            If OleDBCon.State = ConnectionState.Open Then
                OleDBCon.Close()
            End If
        End Try
    End Function

    Public Function TestConnection()
        If TestOpen() Then
            MsgBox("����ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "�š����������")
        End If
    End Function

    Public Function GetRow(ByVal TableName As String) As Integer
        Dim SQLstr As String
        Dim oleDBCom As OleDbCommand
        Dim RowCount As Integer
        SQLstr = "Select count(*) from " & TableName

        oleDBCom = New OleDbCommand(SQLstr, OleDBCon)
        oleDBCom.Connection.Open()
        RowCount = oleDBCom.ExecuteScalar()
        oleDBCom.Connection.Close()
        Return RowCount
    End Function

    Public Function GetRowDistinct(ByVal TableName As String, _
    ByVal ColumnName As String) As Integer
        Dim SQLstr As String
        Dim oleDBCom As OleDbCommand
        Dim RowCount As Integer
        SQLstr = "Select count(" & ColumnName & _
        ") from  (Select DISTINCT " & ColumnName & " from " & TableName & ")"

        oleDBCom = New OleDbCommand(SQLstr, OleDBCon)
        oleDBCom.Connection.Open()
        RowCount = oleDBCom.ExecuteScalar()
        oleDBCom.Connection.Close()
        Return RowCount
    End Function

    Function GetDetailTable() As DataTable
        Dim NameTable As DataTable
        Dim SequenceTable As DataTable = New DataTable("DetailTable")
        Dim SequenceTable2 As DataTable = New DataTable("DetailTable")
        Dim nonSequenceRow As DataRow
        Dim TableSchemaSet As DataSet
        Dim I As Integer

        Dim SequenceCol As DataColumn = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.String")
        SequenceCol.Caption = "TableName"
        SequenceCol.ColumnName = "TableName"
        SequenceTable.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfPrimarykey"
        SequenceCol.ColumnName = "NumberOfPrimarykey"
        SequenceTable.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfForeignkey"
        SequenceCol.ColumnName = "NumberOfForeignkey"
        SequenceTable.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfAttribute"
        SequenceCol.ColumnName = "NumberOfAttribute"
        SequenceTable.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.String")
        SequenceCol.Caption = "TableName"
        SequenceCol.ColumnName = "TableName"
        SequenceTable2.Columns.Add(SequenceCol)


        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfPrimarykey"
        SequenceCol.ColumnName = "NumberOfPrimarykey"
        SequenceTable2.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfForeignkey"
        SequenceCol.ColumnName = "NumberOfForeignkey"
        SequenceTable2.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Int16")
        SequenceCol.Caption = "NumberOfAttribute"
        SequenceCol.ColumnName = "NumberOfAttribute"
        SequenceTable2.Columns.Add(SequenceCol)

        SequenceCol = New DataColumn()
        SequenceCol.DataType = System.Type.GetType("System.Boolean")
        SequenceCol.Caption = "ConvertToER"
        SequenceCol.ColumnName = "ConvertToER"
        SequenceTable2.Columns.Add(SequenceCol)

        NameTable = GetTableName()

        For I = 0 To NameTable.Rows.Count - 1
            nonSequenceRow = SequenceTable.NewRow
            nonSequenceRow("TableName") = NameTable.Rows(I).Item("TableName")
            TableSchemaSet = GetSchema(NameTable.Rows(I).Item("TableName"))
            nonSequenceRow("NumberOfAttribute") = TableSchemaSet.Tables("SchemaList").Rows.Count
            nonSequenceRow("NumberOfPrimarykey") = TableSchemaSet.Tables("PrimaryKeyList").Rows.Count
            nonSequenceRow("NumberOfForeignkey") = TableSchemaSet.Tables("ForeignKeyList").Rows.Count
            SequenceTable.Rows.Add(nonSequenceRow)
        Next

        Dim foundRows As DataRow() = SequenceTable.Select(Nothing, "NumberOfPrimarykey")
        For I = 0 To foundRows.Length - 1
            nonSequenceRow = SequenceTable2.NewRow
            nonSequenceRow("TableName") = foundRows(I).Item("TableName")
            nonSequenceRow("NumberOfAttribute") = foundRows(I).Item("NumberOfAttribute")
            nonSequenceRow("NumberOfPrimarykey") = foundRows(I).Item("NumberOfPrimarykey")
            nonSequenceRow("NumberOfForeignkey") = foundRows(I).Item("NumberOfForeignkey")
            nonSequenceRow("ConvertToER") = False
            SequenceTable2.Rows.Add(nonSequenceRow)
        Next
        Return SequenceTable2
    End Function

    Protected Overrides Sub Finalize()
        OleDBCon = Nothing
        MyBase.Finalize()
    End Sub
End Class