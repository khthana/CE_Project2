Public Class frmCheckCharacter
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents txtNewWord As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtErrorWord As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtErrorWord = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtNewWord = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtErrorWord
        '
        Me.txtErrorWord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtErrorWord.Enabled = False
        Me.txtErrorWord.Location = New System.Drawing.Point(88, 16)
        Me.txtErrorWord.Name = "txtErrorWord"
        Me.txtErrorWord.Size = New System.Drawing.Size(296, 20)
        Me.txtErrorWord.TabIndex = 13
        Me.txtErrorWord.Text = ""
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Location = New System.Drawing.Point(24, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 23)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "New Word"
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 23)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Error Word"
        '
        'btnClear
        '
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Location = New System.Drawing.Point(240, 80)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(80, 24)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        '
        'txtNewWord
        '
        Me.txtNewWord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewWord.Location = New System.Drawing.Point(88, 48)
        Me.txtNewWord.Name = "txtNewWord"
        Me.txtNewWord.Size = New System.Drawing.Size(296, 20)
        Me.txtNewWord.TabIndex = 8
        Me.txtNewWord.Text = ""
        '
        'btnOK
        '
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOK.Location = New System.Drawing.Point(152, 80)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(80, 24)
        Me.btnOK.TabIndex = 7
        Me.btnOK.Text = "OK"
        '
        'frmCheckCharacter
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(408, 118)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtErrorWord, Me.Label2, Me.Label1, Me.btnClear, Me.txtNewWord, Me.btnOK})
        Me.Name = "frmCheckCharacter"
        Me.Text = "Check Character"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public txtOutput As String = ""

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        txtOutput = ""
        If txtNewWord.Text <> "" Then
            txtOutput = txtNewWord.Text
            Me.Close()
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtNewWord.Text = ""
    End Sub
End Class
