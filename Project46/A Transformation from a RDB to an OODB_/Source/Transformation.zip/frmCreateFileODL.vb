Option Explicit On 
Imports System.IO
Imports System.Data
Imports System.Data.OleDb

Public Class frmCreateFileODL
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtCreateClass As System.Windows.Forms.TextBox
    Friend WithEvents txtPname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtClassTemp As System.Windows.Forms.TextBox
    Friend WithEvents btnGenODL As System.Windows.Forms.Button
    Friend WithEvents btnCreateODL As System.Windows.Forms.Button
    Friend WithEvents btnFinishProgram As System.Windows.Forms.Button
    Friend WithEvents txtBrowse As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnChangeWord As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtCreateClass = New System.Windows.Forms.TextBox()
        Me.txtPname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtClassTemp = New System.Windows.Forms.TextBox()
        Me.btnGenODL = New System.Windows.Forms.Button()
        Me.btnCreateODL = New System.Windows.Forms.Button()
        Me.btnFinishProgram = New System.Windows.Forms.Button()
        Me.txtBrowse = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnChangeWord = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtCreateClass
        '
        Me.txtCreateClass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCreateClass.Location = New System.Drawing.Point(344, 16)
        Me.txtCreateClass.Name = "txtCreateClass"
        Me.txtCreateClass.Size = New System.Drawing.Size(8, 20)
        Me.txtCreateClass.TabIndex = 8
        Me.txtCreateClass.Text = ""
        Me.txtCreateClass.Visible = False
        '
        'txtPname
        '
        Me.txtPname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPname.Enabled = False
        Me.txtPname.Location = New System.Drawing.Point(152, 16)
        Me.txtPname.Name = "txtPname"
        Me.txtPname.Size = New System.Drawing.Size(200, 20)
        Me.txtPname.TabIndex = 7
        Me.txtPname.Text = ""
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Location = New System.Drawing.Point(80, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Project Name"
        '
        'txtClassTemp
        '
        Me.txtClassTemp.AcceptsTab = True
        Me.txtClassTemp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtClassTemp.Location = New System.Drawing.Point(16, 80)
        Me.txtClassTemp.Multiline = True
        Me.txtClassTemp.Name = "txtClassTemp"
        Me.txtClassTemp.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtClassTemp.Size = New System.Drawing.Size(288, 280)
        Me.txtClassTemp.TabIndex = 9
        Me.txtClassTemp.Text = ""
        '
        'btnGenODL
        '
        Me.btnGenODL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGenODL.Location = New System.Drawing.Point(320, 88)
        Me.btnGenODL.Name = "btnGenODL"
        Me.btnGenODL.Size = New System.Drawing.Size(112, 32)
        Me.btnGenODL.TabIndex = 10
        Me.btnGenODL.Text = "Generate Class ODL"
        '
        'btnCreateODL
        '
        Me.btnCreateODL.Enabled = False
        Me.btnCreateODL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCreateODL.Location = New System.Drawing.Point(320, 160)
        Me.btnCreateODL.Name = "btnCreateODL"
        Me.btnCreateODL.Size = New System.Drawing.Size(112, 24)
        Me.btnCreateODL.TabIndex = 11
        Me.btnCreateODL.Text = "Create file .ODL"
        '
        'btnFinishProgram
        '
        Me.btnFinishProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFinishProgram.Location = New System.Drawing.Point(320, 336)
        Me.btnFinishProgram.Name = "btnFinishProgram"
        Me.btnFinishProgram.Size = New System.Drawing.Size(112, 24)
        Me.btnFinishProgram.TabIndex = 13
        Me.btnFinishProgram.Text = "Finish Process"
        '
        'txtBrowse
        '
        Me.txtBrowse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBrowse.Enabled = False
        Me.txtBrowse.Location = New System.Drawing.Point(104, 48)
        Me.txtBrowse.Name = "txtBrowse"
        Me.txtBrowse.Size = New System.Drawing.Size(280, 20)
        Me.txtBrowse.TabIndex = 14
        Me.txtBrowse.Text = ""
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Location = New System.Drawing.Point(48, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 16)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Path File"
        '
        'btnChangeWord
        '
        Me.btnChangeWord.Enabled = False
        Me.btnChangeWord.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChangeWord.Location = New System.Drawing.Point(320, 128)
        Me.btnChangeWord.Name = "btnChangeWord"
        Me.btnChangeWord.Size = New System.Drawing.Size(112, 24)
        Me.btnChangeWord.TabIndex = 27
        Me.btnChangeWord.Text = "Change Word"
        '
        'frmCreateFileODL
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(448, 374)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnChangeWord, Me.Label2, Me.txtBrowse, Me.btnFinishProgram, Me.btnGenODL, Me.btnCreateODL, Me.txtClassTemp, Me.txtCreateClass, Me.txtPname, Me.Label1})
        Me.Name = "frmCreateFileODL"
        Me.Text = "Create File ODL"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim pathFile As String = "C:\ERmeta.mdb"

    Dim Conn As OleDbConnection = New OleDbConnection()
    Dim tmpClass() As tempClass
    Dim strFileName As String

    Private Sub frmCreateFileODL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strConn As String = "Provider=Microsoft.JET.OLEDB.4.0;data source=" & pathFile

        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With
    End Sub

    Private Sub btnGenODL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenODL.Click
        Dim frm_name As frmInsertNameProject = New frmInsertNameProject()
        frm_name.Activate() : frm_name.ShowDialog()
        txtPname.Text = frm_name.txtPname.Text
        frm_name.Close()

        If txtPname.Text <> "" Then
            Dim classODL As CreateClassODL = New CreateClassODL()
            classODL.setConnection(Conn)
            classODL.GenClassODL()
            tmpClass = classODL.tmpClass
            txtClassTemp.Enabled = True
            Dim fileODL As makeODL = New makeODL()
            fileODL.projectName = CStr(txtPname.Text)
            fileODL.tmpODL = tmpClass
            fileODL.genFileODL()
            txtClassTemp.Text = fileODL.tout.Text
            btnCreateODL.Enabled = True
            btnChangeWord.Enabled = True
        End If
    End Sub

    Private Sub btnCreateODL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateODL.Click
        Dim frm_path As frmInsertPathFile = New frmInsertPathFile()
        frm_path.Activate() : frm_path.ShowDialog()
        txtBrowse.Text = frm_path.txtBrowse.Text
        frm_path.Close()

        Dim chkFile As String = ""
        If (txtBrowse.Text <> "") Then
            chkFile = CStr(txtBrowse.Text)
            Try
                chkFile = chkFile.Substring(chkFile.LastIndexOf("."))
            Catch
                chkFile = ""
            End Try
        End If

        If (chkFile = ".odl") Then
            If txtPname.Text <> "" Then
                ' ���ҧ��� FileStream
                Dim fout As New FileStream(txtBrowse.Text, IO.FileMode.OpenOrCreate, IO.FileAccess.Write, IO.FileShare.None)
                Dim output As New StreamWriter(fout)
                Try
                    output.WriteLine(txtClassTemp.Text)
                    MessageBox.Show("Create Class " & txtPname.Text & " Complete.", "Create Class", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Catch
                    MessageBox.Show("Couldn't write data to the file.")
                Finally
                    output.Close()
                    fout.Close()
                End Try
            Else
                MessageBox.Show("You could insert a project name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("You don't input a path file ODL.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnChangeWord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeWord.Click
        If txtClassTemp.Text <> "" Then
            Dim old_ck As String = ""
            old_ck = txtClassTemp.SelectedText
            Dim frm_changeword As frmChangeWord = New frmChangeWord()
            frm_changeword.txtOldWord.Text = old_ck
            frm_changeword.Activate() : frm_changeword.ShowDialog()
            Dim new_ck As String = ""
            new_ck = frm_changeword.txtOutput
            old_ck = frm_changeword.txtOldWord.Text

            If frm_changeword.fbtn = True Then
                Dim tmp As String
                tmp = "Do you want to change any words from '" & old_ck & "' to '" & new_ck & "'"
                If MessageBox.Show(tmp, "Confirm changing word", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                    txtClassTemp.Text = txtClassTemp.Text.Replace(old_ck, new_ck)
                End If
            End If

            frm_changeword.Close()
        End If
    End Sub

    Private Sub btnFinishProgram_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFinishProgram.Click
        Me.Close()
    End Sub
End Class
