Imports System.IO

Public Class makeCDL
    Public projectName As String
    Public tmpCDL() As tempClass
    Public tout As TextBox = New TextBox()

    Public Sub genFileCDL()
        Dim strClass As String : Dim i As Integer
        i = 0
        While i < tmpCDL.Length
            strClass = "class " & projectName & "." & tmpCDL(i).className & " " & vbCrLf & _
                            "{ " & vbCrLf & _
                            vbTab & "classtype = persistent; " & vbCrLf
            If tmpCDL(i).superName = "no" Then
                ' type of class (default)
                strClass = strClass & vbTab & "super = %Persistent; " & vbCrLf
                strClass = strClass & vbTab & "persistent; " & vbCrLf
            Else
                strClass = strClass & vbTab & "super = " & projectName & "." & tmpCDL(i).superName & "; " & vbCrLf
            End If

            ' ���ҧ attribute
            Dim j As Integer : j = 0
            While j < tmpCDL(i).attribute.Length
                Dim attribute(3) As String
                attribute = tmpCDL(i).attribute(j).Split(":")
                If attribute(0) <> "struct" Then
                    If attribute(3) = True Then
                        strClass = strClass & vbTab & "array attribute " & attribute(1) & " { type = %" & attribute(2) & "; } " & vbCrLf
                    Else
                        strClass = strClass & vbTab & "attribute " & attribute(1) & " { type = %" & attribute(2) & "; } " & vbCrLf
                    End If
                ElseIf attribute(0) = "struct" Then
                    If attribute(3) = True Then
                        strClass = strClass & vbTab & "array attribute " & attribute(1) & " { type = " & attribute(2) & "; } " & vbCrLf
                    Else
                        strClass = strClass & vbTab & "attribute " & attribute(1) & " { type = " & attribute(2) & "; } " & vbCrLf
                    End If
                End If
                j += 1
            End While

            ' ���ҧ relationship
            j = 0
            While j < tmpCDL(i).relationship.Length
                Dim relationship(4) As String
                relationship = tmpCDL(i).relationship(j).Split(":")
                strClass = strClass & vbTab & "relationship " & relationship(0) & " { type = " & projectName & "." & relationship(2) & "; " & _
                                    "cardinality = " & relationship(1) & "; inverse = " & relationship(3) & "; } " & vbCrLf
                ' ���ҧ index ����Ѻ one to one relationship
                If relationship(4) = "one to one" Then
                    strClass = strClass & vbTab & "index " & relationship(2) & "Index { attribute = " & relationship(0) & "; unique; } " & vbCrLf
                End If
                j += 1
            End While
            strClass = strClass & "} " & vbCrLf

            ' ��¹ŧ���
            tout.Text = tout.Text + strClass
            i += 1
        End While
    End Sub
End Class
