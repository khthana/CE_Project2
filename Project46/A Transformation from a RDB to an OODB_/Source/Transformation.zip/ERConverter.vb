Public Class ERConverter

    Dim OpenDatabase As Boolean
    Dim MetaERDataSet As New MetaER()
    Dim UndefinedTable As New DataTable()
    Dim DatabaseConnection As New DatabaseControl()

    Sub New(ByVal DC As DatabaseControl)
        If DC.TestOpen Then
            Dim col As New DataColumn()
            col.DataType = System.Type.GetType("System.String")
            col.AllowDBNull = False
            col.Caption = "TableName"
            col.ColumnName = "TableName"
            col.Unique = True
            UndefinedTable.Columns.Add(col)
            DatabaseConnection = DC
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "��ͼԴ��Ҵ")
        End If
    End Sub

    Sub New(ByVal GetConnectionType As String, ByVal GetFileName As String, _
        ByVal GetUserName As String, ByVal GetPassword As String)

        Dim DatabaseConnection As New DatabaseControl(GetConnectionType, GetFileName, GetUserName, GetPassword)
        If DatabaseConnection.TestOpen() Then
            Dim col As New DataColumn()
            col.DataType = System.Type.GetType("System.String")
            col.AllowDBNull = False
            col.Caption = "TableName"
            col.ColumnName = "TableName"
            col.Unique = True
            UndefinedTable.Columns.Add(col)

            DatabaseConnection.ChangeConnection(GetConnectionType, GetFileName, GetUserName, GetPassword)

            Me.DatabaseConnection = DatabaseConnection
        Else
            MsgBox("�������ö�������Ͱҹ��������", MsgBoxStyle.OKOnly, "��ͼԴ��Ҵ")
        End If

    End Sub

    Function ConvertToER() As DataTable 'Don't forget to change function to sub

        Dim NameTable As New DataTable()
        Dim TempTableName, TempRelationshipName As String, CountRelationshipname As String
        Dim i As Integer, j As Integer, k As Integer, Count As Integer
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TempTable As New DataTable()
        Dim AllForeignKey As New DataTable()
        Dim TableSchemaSet As New DataSet()
        Dim ForeignTableSchemaSet As New DataSet()
        Dim EntityID As Integer, RelationshipID As Integer
        Dim DetailTable As DataTable
        Dim Primarykey As String, CompositAttribute As Boolean
        Dim OneToM As String
        Dim AttributeStatus As Boolean, CombinekeyStatus
        Dim RelationshipNameType As Integer


        NameTable = DatabaseConnection.GetTableName()
        AllForeignKey = DatabaseConnection.GetForeignKey
        DetailTable = DatabaseConnection.GetDetailTable

        GetAllEntityType(DetailTable, AllForeignKey) 'complete 'Using for Detection Entity Type except WeakEntity
        GetAllWeakEntityType(DetailTable, AllForeignKey) 'complete 

        'GetCompositeAttribute(DetailTable, AllForeignKey)
        GetSimpleRelationship(DetailTable, AllForeignKey) 'Get 1:m, M:n Relationship
        GetComplexRelationship(DetailTable, AllForeignKey)
        GetMultivalueAttribute(DetailTable, AllForeignKey) 'complete

        Return DetailTable ' remove if This class is completed.
    End Function
    '/////////////// End Get N-ary or Nesting Relationship type, Weak Entity \\\\\\\\\\\\\\\
    '/////////////// and Multivalue Attribute from more 2 NumberofPrimarykey \\\\\\\\\\\\\\\

    Function GetER() As DataSet
        Dim ER As DataSet
        ER = MetaERDataSet.GetMetaER
        Return ER
    End Function

    Function CheckNaryRelationship(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
    ByVal AllForeignKeyTable As DataTable, ByVal NumberOfNary As Integer)
        Dim i As Integer, j As Integer
        Dim RelationshipName As String
        Dim Count As Integer
        Count = 0
        RelationshipName = ""

        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
            For j = 0 To AllForeignKeyTable.Rows.Count - 1
                With AllForeignKeyTable.Rows(j)

                    If (.Item("ForeignKeyTable") = TableName) _
                    And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey")) Then
                        If RelationshipName = "" Then
                            RelationshipName = .Item("PrimaryKeyTable")
                            Count = Count + 1
                        Else
                            RelationshipName = RelationshipName + " - " + .Item("PrimaryKeyTable")
                            Count = Count + 1
                        End If
                    End If
                End With
            Next
            If Count = NumberOfNary Then
                Return RelationshipName
            End If
        Next
        RelationshipName = ""
        Return RelationshipName
    End Function

    Private Function CheckMultivalueCompositeAttribute(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
        ByVal AllForeignKeyTable As DataTable, ByVal NumAttribute As Integer) As Integer
        Dim i As Integer, Count As Integer
        'if count = 1 then MultivalueCompositeAttribute 
        'if count = 2 then RelationshipMultivalueAttribute
        'if count = 3,4 then N-aryMultivalueAttribute

        For i = 0 To AllForeignKeyTable.Rows.Count - 1
            If AllForeignKeyTable.Rows(i).Item("ForeignKeyTable") = TableName Then
                Count = Count + 1
            End If
        Next

        Return Count
    End Function

    Private Function CheckCompositeAttribute(ByVal TempTableName As String, _
    ByVal TableSchemaset As DataSet, ByVal AllForeignKey As DataTable) As Boolean
        Dim Primarykey As String, j As Integer
        For j = 0 To AllForeignKey.Rows.Count - 1
            If AllForeignKey.Rows(j).Item("ForeignKeyTable") = TempTableName Then
                Primarykey = AllForeignKey.Rows(j).Item("ForeignKey")
                If TableSchemaset.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey") = Primarykey Then
                    Return True
                End If
                Exit For
            End If
        Next
        Return False
    End Function


    Private Function CheckWeakEntityAndMultivalueAttribute(ByRef ForeignTableSchemaSet As DataSet) As Boolean
        Dim RowsCount As Integer
        RowsCount = ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count()
        If RowsCount > 1 Then
            Return True
        End If
    End Function

    Private Function CheckWeakEntity(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
    ByVal AllForeignKeyTable As DataTable, ByVal NumAttribute As Integer) As Boolean
        Dim i As Integer, j As Integer
        Dim Check As Boolean
        Check = False

        If Not CheckMultivalueAttribute(TableSchemaSet, NumAttribute) Then
            For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                For j = 0 To AllForeignKeyTable.Rows.Count - 1
                    With AllForeignKeyTable.Rows(j)

                        If (.Item("ForeignKeyTable") = TableName) _
                        And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey")) Then
                            If Check = False Then
                                Check = True
                            Else
                                Return False
                            End If
                        End If
                    End With
                Next
            Next

            Return Check
        End If
    End Function

    Private Function CheckMultivalueAttribute(ByVal TableSchemaSet As DataSet, _
        ByVal NumAttribute As Integer) As Boolean
        Dim AttributeRowsCount As Integer
        Dim PrimaryKeyRowsCount As Integer
        AttributeRowsCount = TableSchemaSet.Tables("SchemaList").Rows.Count()
        PrimaryKeyRowsCount = TableSchemaSet.Tables("PrimaryKeyList").Rows.Count()
        If AttributeRowsCount = NumAttribute AndAlso PrimaryKeyRowsCount = NumAttribute Then
            Return True
        End If
        Return False
    End Function

    Private Function CheckRelaionShipMN(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
    ByVal AllForeignKeyTable As DataTable) As String
        Dim i As Integer, j As Integer
        Dim RelationshipName As String
        Dim Check As Boolean
        Check = False
        RelationshipName = ""

        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
            For j = 0 To AllForeignKeyTable.Rows.Count - 1
                With AllForeignKeyTable.Rows(j)

                    If (.Item("ForeignKeyTable") = TableName) _
                    And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey")) Then
                        If RelationshipName = "" Then
                            RelationshipName = .Item("PrimaryKeyTable")
                            Check = True
                        Else
                            RelationshipName = RelationshipName + " - " + .Item("PrimaryKeyTable")
                            Check = True
                        End If
                        Exit For

                    End If
                End With
            Next
            If Not Check Then
                RelationshipName = ""
                Return RelationshipName
            End If
        Next
        Return RelationshipName
    End Function

    Private Function CheckRelaionShipMNBoolean(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
       ByVal AllForeignKeyTable As DataTable) As Boolean
        Dim i As Integer, j As Integer
        Dim RelationshipName As String
        Dim Count As Integer = 0
        RelationshipName = ""

        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
            For j = 0 To AllForeignKeyTable.Rows.Count - 1
                With AllForeignKeyTable.Rows(j)
                    If (.Item("ForeignKeyTable") = TableName) _
                    And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey")) Then
                        Count = Count + 1
                    End If
                End With
            Next
        Next
        If Count = 2 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function InsertUndefineTable(ByVal TableName As String)
        Dim row As DataRow
        row = UndefinedTable.NewRow
        row.Item("TableName") = TableName
        UndefinedTable.Rows.Add(row)
    End Function

    Private Function GetUndefined() As DataTable
        Return UndefinedTable
    End Function

    Function gettest() As DataTable
        Return DatabaseConnection.GetDetailTable
    End Function

    Private Function OneOrMCardinality(ByVal PrimaryTable As String, ByVal ForeignTable As String, _
    ByVal Primarykey As String, ByVal Foreignkey As String) As String
        Dim PrimaryCount As Integer, ForeignCount As Integer
        Dim ForeignDistinctCount As Integer
        PrimaryCount = DatabaseConnection.GetRow(PrimaryTable)
        ForeignCount = DatabaseConnection.GetRow(ForeignTable)
        ForeignDistinctCount = DatabaseConnection.GetRowDistinct(ForeignTable, Foreignkey)
        If ForeignCount > ForeignDistinctCount Then
            Return "m"
        ElseIf ForeignCount > PrimaryCount Then
            Return "m"
        ElseIf ForeignCount = PrimaryCount AndAlso PrimaryCount = ForeignDistinctCount _
        AndAlso PrimaryCount <> 0 Then
            Return "1"
        End If
        Return "?"
    End Function

    Private Function CheckCombinePrimarykey(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
    ByVal AllForeignKeyTable As DataTable) As Boolean
        Dim Check As Boolean, i As Integer, j As Integer

        Check = True
        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count() - 1
            For j = 0 To AllForeignKeyTable.Rows.Count - 1
                If TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey") = _
                  AllForeignKeyTable.Rows(j).Item("ForeignKey") AndAlso TableName = _
                 AllForeignKeyTable.Rows(j).Item("ForeignKeyTable") Then
                    'If TableName = AllForeignKeyTable.Rows(j).Item("ForeignKeyTable") Then
                    Check = False
                End If
            Next
        Next
        Return Check
    End Function

    Private Function SetRowOfDetailTable(ByRef DetailTable As DataTable, ByVal TableName As String) As Boolean
        Dim i As Integer
        For i = 0 To DetailTable.Rows.Count - 1
            If TableName = DetailTable.Rows(i).Item("TableName") Then
                DetailTable.Rows(i).Item("ConvertToER") = True
                Return True
            End If
        Next
        Return False
    End Function

    '########### Using for Function CheckCombinekey ###########

    Private Function CheckCombineKey(ByVal Tablename As String, ByRef DetailTable As DataTable) As Boolean
        Dim i As Integer
        For i = 0 To DetailTable.Rows.Count - 1
            If Tablename = DetailTable.Rows(i).Item("TableName") AndAlso _
            DetailTable.Rows(i).Item("NumberOfPrimarykey") > 1 Then
                Return True
            End If
        Next
    End Function

    Private Function CheckRelatedTableCombinekey(ByVal TableName As String, ByRef DetailTable As DataTable, _
    ByRef AllForeignkeyTable As DataTable) As Boolean
        Dim i As Integer, j As Integer
        For i = 0 To AllForeignkeyTable.Rows.Count - 1
            If TableName = AllForeignkeyTable.Rows(i).Item("ForeignKeyTable") Then
                For j = 0 To DetailTable.Rows.Count - 1
                    If DetailTable.Rows(j).Item("TableName") = AllForeignkeyTable.Rows(i).Item("PrimaryKeyTable") _
                    And DetailTable.Rows(j).Item("NumberOfPrimarykey") > 1 Then
                        Return True
                    ElseIf DetailTable.Rows(j).Item("TableName") = AllForeignkeyTable.Rows(i).Item("PrimaryKeyTable") _
                    And DetailTable.Rows(j).Item("NumberOfPrimarykey") = 1 Then
                        Exit For
                    End If
                Next
            End If
        Next
        Return False
    End Function

    Private Function CheckCombineNesting(ByRef TableList As ArrayList, ByRef MetaER As MetaER)
        Dim i As Integer
        For i = 0 To TableList.Count - 1
            If MetaER.FindEntity(TableList.Item(i)) < 0 Then
                Return True
            End If
        Next
        Return False
    End Function

    Private Function CheckCombineWeakEntity(ByVal TableName As String, ByRef TableSchemaSet As DataSet, _
    ByRef AllForeignkeyTable As DataTable, ByRef NumAttribute As Integer) As Boolean
        Dim i As Integer, j As Integer, check As Boolean
        Dim Count As Integer
        check = False
        If Not CheckMultivalueAttribute(TableSchemaSet, NumAttribute) Then
            For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                For j = 0 To AllForeignkeyTable.Rows.Count - 1
                    If AllForeignkeyTable.Rows(j).Item("ForeignKeyTable") = TableName AndAlso _
                    AllForeignkeyTable.Rows(j).Item("ForeignKey") = _
                    TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey") Then
                        Count = Count + 1
                        Exit For
                    End If
                Next
            Next
        End If
        If Count = 0 Then
            Return False
        ElseIf TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - Count <> 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    'Found some bug
    Private Function CheckCombineWeakEntityAndMultivalueAttribute(ByVal TableName As String, ByRef TableSchemaSet As DataSet, _
    ByVal ForeignTableName As String, ByRef ForeignTableSchemaSet As DataSet, ByRef AllForeignkeyTable As DataTable) As Boolean
        Dim i As Integer, j As Integer
        Dim Check As Boolean = True

        If TableSchemaSet.Tables("PrimaryKeyList").Rows.Count = TableSchemaSet.Tables("SchemaList").Rows.Count Then
            Return True
        End If

        If CheckCombineWeakEntity(ForeignTableName, ForeignTableSchemaSet, AllForeignkeyTable, _
             ForeignTableSchemaSet.Tables("SchemaList").Rows.Count) Then
            Return True
        End If

        Return False
    End Function

    Private Function TableRelatedTable(ByVal TableName As String, ByRef AllForeignkeyTable As DataTable) _
    As ArrayList
        Dim TableList As New ArrayList()
        Dim ForeignTableName As String
        Dim i As Integer, j As Integer, check As Boolean

        For i = 0 To AllForeignkeyTable.Rows.Count - 1
            If AllForeignkeyTable.Rows(i).Item("ForeignKeyTable") = TableName Then
                check = True
                For j = 0 To TableList.Count - 1
                    If AllForeignkeyTable.Rows(i).Item("PrimaryKeyTable") = TableList.Item(j) Then
                        check = False
                    End If
                Next
                If check Then
                    TableList.Add(AllForeignkeyTable.Rows(i).Item("PrimaryKeyTable"))
                End If
            End If

        Next

        Return TableList
    End Function

    Private Function CheckCombineMultivalueCompositeAttribute(ByVal TableName As String, ByVal TableSchemaSet As DataSet, _
        ByVal AllForeignKeyTable As DataTable, ByVal NumAttribute As Integer) As Integer
        Dim i As Integer, Count As Integer
        'if count = 1 then MultivalueCompositeAttribute 
        'if count = 2 then RelationshipMultivalueAttribute
        'if count = 3,4 then N-aryMultivalueAttribute

        For i = 0 To AllForeignKeyTable.Rows.Count - 1
            If AllForeignKeyTable.Rows(i).Item("ForeignKeyTable") = TableName Then
                Count = Count + 1
            End If
        Next

        Count = TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - Count
        Return Count
    End Function

    Private Function ForeignTable(ByVal TableName As String, ByRef AllForeignkeyTable As DataTable) _
    As ArrayList
        Dim TableList As New ArrayList()
        Dim ForeignTableName As String
        Dim i As Integer, j As Integer, check As Boolean

        For i = 0 To AllForeignkeyTable.Rows.Count - 1
            If AllForeignkeyTable.Rows(i).Item("PrimaryKeyTable") = TableName Then
                check = True
                For j = 0 To TableList.Count - 1
                    If AllForeignkeyTable.Rows(i).Item("ForeignKeyTable") = TableList.Item(j) Then
                        check = False
                    End If
                Next
                If check Then
                    TableList.Add(AllForeignkeyTable.Rows(i).Item("ForeignKeyTable"))
                End If
            End If

        Next

        Return TableList


    End Function

    Private Function CheckSameCombinekey(ByRef TableSchemaSet As DataSet, ByRef ForeignTableSchemaSet As DataSet) As Boolean
        Dim i As Integer, j As Integer
        Dim Check As Boolean = False
        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
            For j = 0 To ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                If TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey") = _
                ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey") Then
                    Check = True
                    Exit For
                End If
            Next
            If Check = True Then
                Check = False
            Else
                Return False
            End If
        Next
        Return True
    End Function

    Private Function CheckONET0M(ByRef TableSchemaSet As DataSet, ByRef ForeignTableSchemaSet As DataSet) As Boolean
        Dim i As Integer, j As Integer
        For i = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
            For j = 0 To ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                If TableSchemaSet.Tables("PrimaryKeyList").Rows(i).Item("PrimaryKey") = _
                ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(j).Item("PrimaryKey") Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function
    '##########################################################

    Sub GetAllEntityType(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)

        '/////////////// Start Get All Entity Type \\\\\\\\\\\\\\\
        'Edit Algorithm for efficiency from For Loop to insert Buffer Tables
        'First Loop for insert all Entity Type to MetaER 
        'Change algorithm 1.find maximum NumberOfPrimarykey 
        ' 2.for loop find Entity Type 
        ' 3.CheckCombinePrimarykey Function may be change
        Dim TempRelationshipname As String, TempTableName As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet
        Dim EntityID As Integer, i As Integer, j As Integer

        For i = 0 To DetailTable.Rows.Count - 1
            TempRelationshipname = ""
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")


            TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)

            If NumberOfPrimaryKey = 1 Then

                If Not CheckCompositeAttribute(TempTableName, TableSchemaSet, AllForeignKey) Then
                    'One Primarykey's Table isn't Entity Type.It is Composit attribute.
                    'Check by Primarykey's table is primarykey another table

                    'Add Entity Type
                    MetaERDataSet.InsertEntityTable(TempTableName, "Regular", 1)
                    SetRowOfDetailTable(DetailTable, TempTableName)
                    'Add Attribute 
                    EntityID = MetaERDataSet.FindEntity(TempTableName)
                    For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                        With TableSchemaSet.Tables("SchemaList").Rows(j)
                            MetaERDataSet.InsertAttributeTable _
                            (.Item("AttributeName"), "Simple", .Item("DataType"), _
                            EntityID, "Entity", .Item("PrimaryKey"))
                        End With
                    Next
                Else
                End If

            ElseIf CheckCombinePrimarykey(TempTableName, TableSchemaSet, AllForeignKey) Then

                MetaERDataSet.InsertEntityTable(TempTableName, "Regular", NumberOfPrimaryKey)
                SetRowOfDetailTable(DetailTable, TempTableName)
                EntityID = MetaERDataSet.FindEntity(TempTableName)

                For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                    With TableSchemaSet.Tables("SchemaList").Rows(j)
                        MetaERDataSet.InsertAttributeTable _
                        (.Item("AttributeName"), "Simple", .Item("DataType"), _
                        EntityID, "Entity", .Item("PrimaryKey"))
                    End With
                Next

            End If
        Next
        '/////////////// End Get All Entity Type \\\\\\\\\\\\\\\
    End Sub 'Complete

    Sub GetAllWeakEntityType(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)
        '/////////////// Get All Weak Entity   \\\\\\\\\\\\\\\
        Dim TempRelationshipname As String, TempTableName As String, CountRelationshipname As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet
        Dim EntityID As Integer, RelationshipID As Integer
        Dim AttributeStatus As Boolean, CombinekeyStatus As Boolean
        Dim Count As Integer, i As Integer, j As Integer, k As Integer

        For i = 0 To DetailTable.Rows.Count - 1
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")
            AttributeStatus = DetailTable.Rows(i).Item("ConvertToER")

            If Not AttributeStatus Then
                CombinekeyStatus = CheckRelatedTableCombinekey(TempTableName, DetailTable, AllForeignKey)
                TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)


                If CheckWeakEntity(TempTableName, TableSchemaSet, AllForeignKey, 2) AndAlso Not CombinekeyStatus Then
                    'Insert Entity,Insert Relationship,Insert Attribute and Insert Cardinality
                    Dim StrongTable As String
                    Dim StrongAttribute As String
                    For k = 0 To AllForeignKey.Rows.Count - 1
                        If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") And _
                            AllForeignKey.Rows(k).Item("ForeignKey") = AllForeignKey.Rows(k).Item("PrimaryKey") Then
                            StrongTable = AllForeignKey.Rows(k).Item("PrimaryKeyTable")
                            StrongAttribute = AllForeignKey.Rows(k).Item("ForeignKey")
                            Exit For
                        End If
                    Next

                    If StrongTable = "" Then
                        InsertUndefineTable(TempTableName)
                    Else
                        'Insert WeakEntiy and WeakRelationship
                        MetaERDataSet.InsertEntityTable(TempTableName, "Weak", 2)
                        SetRowOfDetailTable(DetailTable, TempTableName)
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        For k = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                            With TableSchemaSet.Tables("SchemaList").Rows(k)
                                If StrongAttribute <> .Item("AttributeName") Then
                                    MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), "Simple", .Item("DataType"), EntityID, _
                                            "Entity", .Item("PrimaryKey"))
                                End If
                            End With
                        Next

                        TempRelationshipname = String.Concat(StrongTable, " - ", TempTableName)
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        ' if RelationshipID = -1 then no Relationship_Name
                        Count = 2
                        While RelationshipID <> -1
                            CountRelationshipname = String.Concat(TempRelationshipname, Count)
                            RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                            Count = Count + 1
                        End While
                        MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Weak")
                        'Insert Cardinality 1 : m by Weak Entity
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        EntityID = MetaERDataSet.FindEntity(StrongTable)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                    End If

                ElseIf CheckWeakEntity(TempTableName, TableSchemaSet, AllForeignKey, NumberOfPrimaryKey) _
                                    AndAlso Not CombinekeyStatus Then
                    'CheckWeakEntity from 3 or more combine primarykey attribute
                    'Insert Entity,Insert Relationship,Insert Attribute and Insert Cardinality

                    Dim StrongTable As String
                    Dim StrongAttribute As String
                    For k = 0 To AllForeignKey.Rows.Count - 1
                        If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") Then
                            StrongTable = AllForeignKey.Rows(k).Item("PrimaryKeyTable")
                            StrongAttribute = AllForeignKey.Rows(k).Item("ForeignKey")
                            Exit For
                        End If
                    Next

                    If StrongTable = "" Then
                        InsertUndefineTable(TempTableName)
                    Else
                        'Insert WeakEntiy and WeakRelationship
                        MetaERDataSet.InsertEntityTable(TempTableName, "Weak", NumberOfPrimaryKey)
                        SetRowOfDetailTable(DetailTable, TempTableName)
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        For k = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                            With TableSchemaSet.Tables("SchemaList").Rows(k)
                                If StrongAttribute <> .Item("AttributeName") Then
                                    MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), "Simple", .Item("DataType"), EntityID, _
                                            "Entity", .Item("PrimaryKey"))
                                End If
                            End With
                        Next

                        TempRelationshipname = String.Concat(StrongTable, " - ", TempTableName)
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        ' if RelationshipID = -1 then not Relationship_Name
                        Count = 2
                        While RelationshipID <> -1
                            CountRelationshipname = String.Concat(TempRelationshipname, Count)
                            RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                            Count = Count + 1
                        End While
                        MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Weak")
                        'Insert Cardinality 1 : m by Weak Entity
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        EntityID = MetaERDataSet.FindEntity(StrongTable)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                    End If

                ElseIf CombinekeyStatus Then

                    Dim TableList As ArrayList
                    'TableList.Sort()
                    TableList = TableRelatedTable(TempTableName, AllForeignKey)
                    '//////Uncheck SuperClass or Composit Attribute
                    'If TableList.Count = 1 Then
                    'Check Weak Entity, Multivalue Attribute and Superclass
                    If CheckCombineWeakEntity(TempTableName, TableSchemaSet, _
                    AllForeignKey, NumberOfPrimaryKey) Then

                        Dim StrongTable As String
                        Dim StrongAttributeList As New ArrayList()
                        Dim l As Integer
                        For k = 0 To AllForeignKey.Rows.Count - 1
                            If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") Then
                                StrongTable = AllForeignKey.Rows(k).Item("PrimaryKeyTable")
                                StrongAttributeList.Add(AllForeignKey.Rows(k).Item("ForeignKey"))
                            End If
                        Next

                        'Insert WeakEntiy and WeakRelationship
                        MetaERDataSet.InsertEntityTable(TempTableName, "Weak", NumberOfPrimaryKey)
                        SetRowOfDetailTable(DetailTable, TempTableName)
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        For k = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                            With TableSchemaSet.Tables("SchemaList").Rows(k)
                                If StrongAttributeList.BinarySearch(.Item("AttributeName")) < 0 Then
                                    MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), "Simple", .Item("DataType"), EntityID, _
                                            "Entity", .Item("PrimaryKey"))
                                End If
                            End With
                        Next

                        TempRelationshipname = String.Concat(StrongTable, " - ", TempTableName)
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        ' if RelationshipID = -1 then no Relationship_Name
                        Count = 2
                        While RelationshipID <> -1
                            CountRelationshipname = String.Concat(TempRelationshipname, Count)
                            RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                            Count = Count + 1
                        End While
                        MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Weak")
                        'Insert Cardinality 1 : m by Weak Entity
                        RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                        EntityID = MetaERDataSet.FindEntity(StrongTable)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                        EntityID = MetaERDataSet.FindEntity(TempTableName)
                        MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                    End If
                End If
            End If
        Next
        '/////////////// End Get Weak Entity  \\\\\\\\\\\\\\\
    End Sub 'Complete

    Sub GetMultivalueAttribute(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)
        Dim TempRelationshipname As String, TempTableName As String, CountRelationshipname As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet
        Dim EntityID As Integer, RelationshipID As Integer
        Dim AttributeStatus As Boolean, CombinekeyStatus As Boolean
        Dim Count As Integer, i As Integer, j As Integer, k As Integer

        For i = 0 To DetailTable.Rows.Count - 1
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")
            AttributeStatus = DetailTable.Rows(i).Item("ConvertToER")

            If Not AttributeStatus Then
                CombinekeyStatus = CheckRelatedTableCombinekey(TempTableName, DetailTable, AllForeignKey)
                TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)



                If CheckMultivalueAttribute(TableSchemaSet, 2) AndAlso Not CombinekeyStatus Then
                    'Don't insert Cadinality for MultivalueAttribute
                    Dim check As Boolean = True

                    For k = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                        For j = 0 To AllForeignKey.Rows.Count - 1
                            With AllForeignKey.Rows(j)
                                If (.Item("ForeignKeyTable") = TempTableName) _
                                And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(k).Item("PrimaryKey")) Then
                                    EntityID = MetaERDataSet.FindEntity(.Item("PrimaryKeyTable"))
                                    Dim MultiAttributeName As String
                                    Dim MultiAttributeDataType As String
                                    Dim l As Integer
                                    'Find Multivalue DataType 2 Attribute only
                                    'Name of Multivalue from Attribute
                                    If k = 0 Then
                                        MultiAttributeName = TableSchemaSet.Tables("PrimaryKeyList").Rows(1).Item("PrimaryKey")
                                    Else
                                        MultiAttributeName = TableSchemaSet.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey")
                                    End If
                                    For l = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                        If TableSchemaSet.Tables("SchemaList").Rows(l).Item("AttributeName") = MultiAttributeName Then
                                            MultiAttributeDataType = TableSchemaSet.Tables("SchemaList").Rows(l).Item("DataType")
                                            MetaERDataSet.InsertAttributeTable(MultiAttributeName, _
                                            "Multivalue", MultiAttributeDataType, EntityID, "Entity", False)
                                            SetRowOfDetailTable(DetailTable, TempTableName)
                                            check = False
                                            Exit For
                                        End If
                                    Next
                                End If
                            End With
                        Next
                    Next

                    If check Then
                        InsertUndefineTable(TempTableName)
                    End If

                ElseIf CombinekeyStatus Then

                    Dim TableList As ArrayList
                    'TableList.Sort()
                    TableList = TableRelatedTable(TempTableName, AllForeignKey)

                    If CheckMultivalueAttribute(TableSchemaSet, NumberOfPrimaryKey) And TableList.Count = 1 Then

                        Dim check As Boolean = True

                        For k = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                            For j = 0 To AllForeignKey.Rows.Count - 1
                                With AllForeignKey.Rows(j)
                                    If (.Item("ForeignKeyTable") = TempTableName) _
                                    And (.Item("ForeignKey") = TableSchemaSet.Tables("PrimaryKeyList").Rows(k).Item("PrimaryKey")) _
                                    And check Then
                                        EntityID = MetaERDataSet.FindEntity(.Item("PrimaryKeyTable"))
                                        Dim MultiAttributeName As String
                                        Dim MultiAttributeDataType As String
                                        Dim l As Integer
                                        'Find Multivalue DataType 2 Attribute only
                                        'Name of Multivalue from Attribute
                                        If k = 0 Then
                                            MultiAttributeName = TableSchemaSet.Tables("PrimaryKeyList").Rows(1).Item("PrimaryKey")
                                        Else
                                            MultiAttributeName = TableSchemaSet.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey")
                                        End If
                                        For l = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                            If TableSchemaSet.Tables("SchemaList").Rows(l).Item("AttributeName") = MultiAttributeName Then
                                                MultiAttributeDataType = TableSchemaSet.Tables("SchemaList").Rows(l).Item("DataType")
                                                MetaERDataSet.InsertAttributeTable(MultiAttributeName, _
                                                "Multivalue", MultiAttributeDataType, EntityID, "Entity", False)
                                                SetRowOfDetailTable(DetailTable, TempTableName)
                                                check = False
                                                Exit For
                                            End If
                                        Next
                                    End If
                                End With
                            Next
                        Next

                    End If
                End If
            End If

        Next
    End Sub

    Sub GetCompositeAttribute(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)
        '/////////////// Get Relationship type or composite \\\\\\\\\\\\\\\
        '/////////////// Attribute from 1 NumberofPrimarykey \\\\\\\\\\\\\\\
        Dim TempRelationshipname As String, TempTableName As String, CountRelationshipname As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet, ForeignTableSchemaSet As DataSet
        Dim EntityID As Integer, RelationshipID As Integer
        Dim AttributeStatus As Boolean, CombinekeyStatus As Boolean
        Dim Count As Integer, i As Integer, j As Integer, k As Integer

        For i = 0 To DetailTable.Rows.Count - 1
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")
            AttributeStatus = DetailTable.Rows(i).Item("ConvertToER")


            If NumberOfPrimaryKey = 1 And NumberOfForeignKey > 0 Then
                'Before Add Relation must be Multivalue Attribute and Composite Attribute
                'Add Relationship Type 1:m
                TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)
                For j = 0 To NumberOfForeignKey - 1
                    With TableSchemaSet.Tables("ForeignKeyList").Rows(j)

                        ForeignTableSchemaSet = DatabaseConnection.GetSchema(.Item("ForeignKeyTable"))

                        If Not CheckWeakEntityAndMultivalueAttribute(ForeignTableSchemaSet) AndAlso _
                           ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey") <> .Item("ForeignKey") Then
                            'TempRelationshipName = String.Concat(TempTableName, " - ", .Item("ForeignKeyTable"))
                            'RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipName)
                            '   ' if RelationshipID = -1 then not Relationship_Name
                            '  Count = 2
                            ' While RelationshipID <> -1
                            '    CountRelationshipname = String.Concat(TempRelationshipName, Count)
                            '   RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                            '  Count = Count + 1
                            'End While

                            ''Recursive Relationship Undetect Binary or Recursive
                            'If .Item("PrimaryKeyTable") = .Item("ForeignKeyTable") Then
                            '   MetaERDataSet.InsertRelationshipTable(TempRelationshipName, "Recursive")
                            'Else
                            '   MetaERDataSet.InsertRelationshipTable(TempRelationshipName, "Binary")
                            'End If

                            'SetRowOfDetailTable(DetailTable, TempTableName)
                            ''Add Relation
                            ''Insertion isn't complete because Cardinality may be 1:m,1:1
                            'OneToM = OneOrMCardinality(.Item("PrimaryKeyTable"), .Item("ForeignKeyTable"), _
                            '.Item("PrimaryKey"), .Item("ForeignKey"))
                            'EntityID = MetaERDataSet.FindEntity(TempTableName)
                            'RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipName)
                            'MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                            'EntityID = MetaERDataSet.FindEntity(.Item("ForeignKeyTable"))
                            'MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, OneToM)


                        ElseIf Not CheckWeakEntityAndMultivalueAttribute(ForeignTableSchemaSet) AndAlso _
                           ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey") = .Item("ForeignKey") Then
                            Dim AttributeID As Integer
                            Dim CompositeName As String
                            'Insert Composite attribute 
                            'Name of Composite attribute from Table Name of composite Table
                            'May be Ask User Composite Attribute or Super Class 

                            EntityID = MetaERDataSet.FindEntity(TempTableName)
                            CompositeName = String.Concat _
                            (TempTableName, TableSchemaSet.Tables("ForeignKeyList").Rows(j).Item("ForeignKeyTable"))

                            MetaERDataSet.InsertAttributeTable _
                                (CompositeName, "Composite", "", _
                                            EntityID, "Entity", False)
                            SetRowOfDetailTable(DetailTable, TempTableName)
                            AttributeID = MetaERDataSet.FindAttribute(CompositeName)

                            For k = 0 To ForeignTableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With ForeignTableSchemaSet.Tables("SchemaList").Rows(k)
                                    MetaERDataSet.InsertAttributeTable _
                                    (.Item("AttributeName"), "Simple", .Item("DataType"), _
                                    AttributeID, "Attribute", .Item("PrimaryKey"))
                                End With
                            Next

                        End If
                    End With
                Next
                'ElseIf CombinekeyStatus Then
                ' TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)

            End If

        Next
        '/////////////// End Get Relationship type or composite \\\\\\\\\\\\\\\
        '//////////////// Attribute from 1 NumberofPrimarykey \\\\\\\\\\\\\\\\\
    End Sub

    Sub GetSimpleRelationship(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)
        Dim TempRelationshipname As String, TempTableName As String, CountRelationshipname As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet, ForeignTableSchemaSet As DataSet
        Dim EntityID As Integer, RelationshipID As Integer
        Dim AttributeStatus As Boolean, Combinekey As Boolean
        Dim Count As Integer, i As Integer, j As Integer, k As Integer
        Dim OneToM As String
        Dim Tablelist As ArrayList

        For i = 0 To DetailTable.Rows.Count - 1
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")
            AttributeStatus = DetailTable.Rows(i).Item("ConvertToER")
            Combinekey = CheckCombineKey(TempTableName, DetailTable)
            TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)

            If (NumberOfPrimaryKey = 1 And NumberOfForeignKey > 0) Then
                'Before Add Relation must be Multivalue Attribute and Composite Attribute
                'Add Relationship Type 1:m

                For j = 0 To NumberOfForeignKey - 1
                    With TableSchemaSet.Tables("ForeignKeyList").Rows(j)

                        ForeignTableSchemaSet = DatabaseConnection.GetSchema(.Item("ForeignKeyTable"))

                        If Not CheckWeakEntityAndMultivalueAttribute(ForeignTableSchemaSet) AndAlso _
                           ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(0).Item("PrimaryKey") <> .Item("ForeignKey") Then
                            TempRelationshipname = String.Concat(TempTableName, " - ", .Item("ForeignKeyTable"))
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                            ' if RelationshipID = -1 then not Relationship_Name
                            Count = 2
                            While RelationshipID <> -1
                                CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                Count = Count + 1
                                TempRelationshipname = CountRelationshipname
                            End While



                            'Recursive Relationship Undetect Binary or Recursive
                            If .Item("PrimaryKeyTable") = .Item("ForeignKeyTable") Then
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Recursive")
                            Else
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary")
                            End If

                            SetRowOfDetailTable(DetailTable, TempTableName)
                            'Add Relation
                            'Insertion isn't complete because Cardinality may be 1:m,1:1
                            OneToM = OneOrMCardinality(.Item("PrimaryKeyTable"), .Item("ForeignKeyTable"), _
                            .Item("PrimaryKey"), .Item("ForeignKey"))
                            EntityID = MetaERDataSet.FindEntity(TempTableName)
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                            MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                            EntityID = MetaERDataSet.FindEntity(.Item("ForeignKeyTable"))
                            MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, OneToM)

                        ElseIf Not CheckMultivalueAttribute(ForeignTableSchemaSet, _
                           ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count) Then
                            'Relationship to Weak Entity 

                            Dim Check As Boolean = True, l As Integer

                            For k = 0 To TableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                                For l = 0 To ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count - 1
                                    If ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows(l).Item("PrimaryKey") = _
                                        TableSchemaSet.Tables("PrimaryKeyList").Rows(k).Item("PrimaryKey") Then
                                        check = False
                                        Exit For
                                    End If
                                Next
                            Next

                            If Not check Then
                                check = True
                                For k = 0 To AllForeignKey.Rows.Count - 1
                                    If TempTableName = AllForeignKey.Rows(k).Item("PrimaryKeyTable") And _
                                        .Item("ForeignKeyTable") = AllForeignKey.Rows(k).Item("ForeignKeyTable") And _
                                        AllForeignKey.Rows(k).Item("PrimaryKey") = AllForeignKey.Rows(k).Item("ForeignKey") Then
                                        check = False
                                        Exit For
                                    End If
                                Next
                            End If

                            If Check AndAlso CheckWeakEntity(.Item("ForeignKeyTable"), ForeignTableSchemaSet, AllForeignKey, _
                            ForeignTableSchemaSet.Tables("SchemaList").Rows.Count) Then
                                TempRelationshipname = String.Concat(TempTableName, " - ", .Item("ForeignKeyTable"))
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                    TempRelationshipname = CountRelationshipname
                                End While



                                'Recursive Relationship Undetect Binary or Recursive
                                If .Item("PrimaryKeyTable") = .Item("ForeignKeyTable") Then
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Recursive")
                                Else
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary")
                                End If

                                SetRowOfDetailTable(DetailTable, TempTableName)
                                'Add Relation
                                OneToM = OneOrMCardinality(.Item("PrimaryKeyTable"), .Item("ForeignKeyTable"), _
                                .Item("PrimaryKey"), .Item("ForeignKey"))
                                EntityID = MetaERDataSet.FindEntity(TempTableName)
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                                EntityID = MetaERDataSet.FindEntity(.Item("ForeignKeyTable"))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, OneToM)
                            End If
                        End If
                    End With
                Next
                'ElseIf CombinekeyStatus Then
                ' TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)
            ElseIf CheckRelaionShipMNBoolean(TempTableName, TableSchemaSet, AllForeignKey) Then


                TempRelationshipname = CheckRelaionShipMN(TempTableName, TableSchemaSet, AllForeignKey)
                If TempRelationshipname <> "" Then
                    'Insert Attribute

                    RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                    ' if RelationshipID = -1 then not Relationship_Name
                    Count = 2
                    While RelationshipID <> -1
                        CountRelationshipname = String.Concat(TempRelationshipname, Count)
                        RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                        Count = Count + 1
                        TempRelationshipname = CountRelationshipname
                    End While



                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary", TempTableName)
                    SetRowOfDetailTable(DetailTable, TempTableName)
                    RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                    For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                        With TableSchemaSet.Tables("SchemaList").Rows(j)
                            If .Item("PrimaryKey") <> True Then
                                MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                "Simple", .Item("DataType"), RelationshipID, "Relationship", False)
                            End If
                        End With
                    Next

                    Count = 0
                    For j = 0 To AllForeignKey.Rows.Count - 1
                        With AllForeignKey.Rows(j)
                            If .Item("ForeignKeyTable") = TempTableName And Count = 0 Then
                                EntityID = MetaERDataSet.FindEntity(.Item("PrimaryKeyTable"))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                                Count = Count + 1
                            ElseIf .Item("ForeignKeyTable") = TempTableName And Count = 1 Then
                                EntityID = MetaERDataSet.FindEntity(.Item("PrimaryKeyTable"))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                                Exit For
                            End If
                        End With
                    Next

                    If MetaERDataSet.FindRelationship(TempRelationshipname) = -1 Then
                        InsertUndefineTable(TempRelationshipname)
                    End If
                End If

            ElseIf Combinekey AndAlso NumberOfForeignKey > 0 Then

                Tablelist = ForeignTable(TempTableName, AllForeignKey)
                ' If Tablelist.Count = 1 Then
                'It dosen't same 1:m Relationship
                For j = 0 To Tablelist.Count - 1
                    TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)

                    With TableSchemaSet.Tables("ForeignKeyList").Rows(j)

                        ForeignTableSchemaSet = DatabaseConnection.GetSchema(Tablelist.Item(j))
                        If Not CheckONET0M(TableSchemaSet, ForeignTableSchemaSet) Then
                            If Not CheckCombineWeakEntityAndMultivalueAttribute(TempTableName, TableSchemaSet, _
                             Tablelist.Item(j), ForeignTableSchemaSet, AllForeignKey) Then
                                TempRelationshipname = String.Concat(TempTableName, " - ", Tablelist.Item(j))
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                    TempRelationshipname = CountRelationshipname
                                End While



                                'Recursive Relationship Undetect Binary or Recursive
                                If TempTableName = Tablelist.Item(j) Then
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Recursive")
                                Else
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary")
                                End If

                                ''SetRowOfDetailTable(DetailTable, TempTableName)
                                'Add Relation
                                'Insertion(isn) 't complete because Cardinality may be 1:m,1:1
                                OneToM = OneOrMCardinality(.Item("PrimaryKeyTable"), Tablelist.Item(j), _
                                    .Item("PrimaryKey"), .Item("ForeignKey"))
                                EntityID = MetaERDataSet.FindEntity(TempTableName)
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                                EntityID = MetaERDataSet.FindEntity(Tablelist.Item(j))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, OneToM)
                            End If
                        ElseIf Not CheckMultivalueAttribute(ForeignTableSchemaSet, _
                           ForeignTableSchemaSet.Tables("PrimaryKeyList").Rows.Count) Then
                            'Relationship to Weak Entity 

                            Dim Check As Boolean = True, l As Integer

                            For k = 0 To AllForeignKey.Rows.Count - 1
                                If TempTableName = AllForeignKey.Rows(k).Item("PrimaryKeyTable") And _
                                    .Item("ForeignKeyTable") = AllForeignKey.Rows(k).Item("ForeignKeyTable") And _
                                    AllForeignKey.Rows(k).Item("PrimaryKey") = AllForeignKey.Rows(k).Item("ForeignKey") Then
                                    check = False
                                    Exit For
                                End If
                            Next

                            If Check Then
                                TempRelationshipname = String.Concat(TempTableName, " - ", Tablelist.Item(j))
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                    TempRelationshipname = CountRelationshipname
                                End While



                                'Recursive Relationship Undetect Binary or Recursive
                                If TempTableName = Tablelist.Item(j) Then
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Recursive")
                                Else
                                    MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary")
                                End If

                                ''SetRowOfDetailTable(DetailTable, TempTableName)
                                ''Add Relation
                                OneToM = OneOrMCardinality(.Item("PrimaryKeyTable"), Tablelist.Item(j), _
                                .Item("PrimaryKey"), .Item("ForeignKey"))
                                EntityID = MetaERDataSet.FindEntity(TempTableName)
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "1")
                                EntityID = MetaERDataSet.FindEntity(Tablelist.Item(j))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, OneToM)
                            End If
                        End If
                    End With
                Next
                '                End If
            End If



        Next
    End Sub

    Sub GetComplexRelationship(ByRef DetailTable As DataTable, ByRef AllForeignKey As DataTable)
        '/////////////// Get N-ary or Nesting Relationship type, Weak Entity \\\\\\\\\\\\\\\
        '/////////////// and Multivalue Attribute from more 2 NumberofPrimarykey \\\\\\\\\\\\\\\
        Dim TempRelationshipname As String, TempTableName As String, CountRelationshipname As String
        Dim NumberOfPrimaryKey As Integer, NumberOfForeignKey As Integer
        Dim TableSchemaSet As DataSet, ForeignTableSchemaSet As DataSet
        Dim EntityID As Integer, RelationshipID As Integer
        Dim AttributeStatus As Boolean, CombinekeyStatus As Boolean
        Dim Count As Integer, i As Integer, j As Integer, k As Integer
        Dim OneToM As String
        Dim Tablelist As ArrayList

        For i = 0 To DetailTable.Rows.Count - 1
            TempTableName = DetailTable.Rows(i).Item("TableName")
            NumberOfPrimaryKey = DetailTable.Rows(i).Item("NumberOfPrimarykey")
            NumberOfForeignKey = DetailTable.Rows(i).Item("NumberOfForeignkey")
            AttributeStatus = DetailTable.Rows(i).Item("ConvertToER")

            'using for check RelatedTable
            If Not AttributeStatus Then
                CombinekeyStatus = CheckRelatedTableCombinekey(TempTableName, DetailTable, AllForeignKey)

                TableSchemaSet = DatabaseConnection.GetSchema(TempTableName)
                'First insert N-ary relationship to MetaERTable
                'unknow Relationship  -- other relationship
                'Weak Entity From Table has Primary key more than two --work
                'Nesting Relationship 
                'If primarykey form 3 combine attribute may be relationship...


                TempRelationshipname = CheckNaryRelationship(TempTableName, TableSchemaSet, AllForeignKey, NumberOfPrimaryKey)

                If TempRelationshipname <> "" AndAlso Not CombinekeyStatus Then
                    'CheckRelationship Trinary or N-ary
                    If NumberOfPrimaryKey = 3 Then
                        MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Trenary", TempTableName)
                    Else
                        MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "N-ary", TempTableName)
                    End If

                    SetRowOfDetailTable(DetailTable, TempTableName)
                    RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                    For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                        With TableSchemaSet.Tables("SchemaList").Rows(j)
                            If .Item("PrimaryKey") <> True Then
                                MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                "Simple", .Item("DataType"), RelationshipID, "Relationship", False)
                            End If
                        End With
                    Next
                    For j = 0 To AllForeignKey.Rows.Count - 1
                        If AllForeignKey.Rows(j).Item("ForeignKeyTable") = TempTableName Then
                            EntityID = MetaERDataSet.FindEntity(AllForeignKey.Rows(j).Item("PrimaryKeyTable"))
                            MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                        End If
                    Next

                ElseIf CheckMultivalueAttribute(TableSchemaSet, NumberOfPrimaryKey) _
                        AndAlso Not CombinekeyStatus AndAlso False Then
                    Dim Type As Integer
                    Type = CheckMultivalueCompositeAttribute(TempTableName, TableSchemaSet, AllForeignKey, NumberOfPrimaryKey)
                    SetRowOfDetailTable(DetailTable, TempTableName)
                    Select Case Type
                        Case 1

                            Dim AttributeID As Integer
                            Dim CompositeName As String
                            Dim EntityTable As String

                            For j = 0 To AllForeignKey.Rows.Count - 1
                                If AllForeignKey.Rows(j).Item("ForeignKeyTable") = TempTableName Then
                                    EntityTable = AllForeignKey.Rows(j).Item("PrimaryKeyTable")
                                    Exit For
                                End If
                            Next

                            EntityID = MetaERDataSet.FindEntity(EntityTable)
                            CompositeName = String.Concat(EntityTable, TempTableName)

                            MetaERDataSet.InsertAttributeTable _
                                (CompositeName, "Complex", "", _
                                            EntityID, "Entity", False)

                            AttributeID = MetaERDataSet.FindAttribute(CompositeName)

                            For k = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With TableSchemaSet.Tables("SchemaList").Rows(k)
                                    MetaERDataSet.InsertAttributeTable _
                                    (.Item("AttributeName"), "Simple", .Item("DataType"), _
                                    AttributeID, "Attribute", .Item("PrimaryKey"))
                                End With
                            Next

                        Case 2
                            Dim Check As Boolean

                            If NumberOfPrimaryKey = 3 Then
                                TempRelationshipname = TempTableName
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                End While
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary", TempTableName)
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                                For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                    check = True
                                    For k = 0 To AllForeignKey.Rows.Count - 1
                                        If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") _
                                        AndAlso TableSchemaSet.Tables("SchemaList").Rows(j).Item("AttributeName") = _
                                        AllForeignKey.Rows(k).Item("ForeignKey") Then
                                            check = False
                                            Exit For
                                        End If
                                    Next
                                    If check Then
                                        With TableSchemaSet.Tables("SchemaList").Rows(j)
                                            MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                            "Multivalue", .Item("DataType"), RelationshipID, "Relationship", False)
                                        End With
                                    End If
                                Next
                            End If

                        Case Else
                            Dim check As Boolean

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                check = True
                                For k = 0 To AllForeignKey.Rows.Count - 1
                                    If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") _
                                    AndAlso TableSchemaSet.Tables("SchemaList").Rows(j).Item("AttributeName") = _
                                    AllForeignKey.Rows(k).Item("ForeignKey") Then
                                        If TempRelationshipname = "" Then
                                            TempRelationshipname = AllForeignKey.Rows(k).Item("PrimaryKeyTable")
                                        Else
                                            TempRelationshipname = String.Concat(TempRelationshipname, " - ", _
                                            AllForeignKey.Rows(k).Item("PrimaryKeyTable"))
                                        End If
                                        Exit For
                                    End If
                                Next
                            Next
                            'Detection Trinary or N-ary 
                            If NumberOfPrimaryKey = 3 Then
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Ternary", TempTableName)
                            Else
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Ternary", TempTableName)
                            End If
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With TableSchemaSet.Tables("SchemaList").Rows(j)
                                    If .Item("PrimaryKey") <> True Then
                                        MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                        "Simple", .Item("DataType"), RelationshipID, "Relationship", False)
                                    End If
                                End With
                            Next

                            For j = 0 To AllForeignKey.Rows.Count - 1
                                If AllForeignKey.Rows(j).Item("ForeignKeyTable") = TempTableName Then
                                    EntityID = MetaERDataSet.FindEntity(AllForeignKey.Rows(j).Item("PrimaryKeyTable"))
                                    MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                                End If
                            Next

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                check = True
                                For k = 0 To AllForeignKey.Rows.Count - 1
                                    If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") _
                                    AndAlso TableSchemaSet.Tables("SchemaList").Rows(j).Item("AttributeName") = _
                                    AllForeignKey.Rows(k).Item("ForeignKey") Then
                                        check = False
                                        Exit For
                                    End If
                                Next
                                If check Then
                                    With TableSchemaSet.Tables("SchemaList").Rows(j)
                                        MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                        "Multivalue", .Item("DataType"), RelationshipID, "Relationship", False)
                                    End With
                                End If
                            Next
                    End Select

                    '####### Check CombineKey Table #######
                ElseIf CombinekeyStatus Then

                    Tablelist = TableRelatedTable(TempTableName, AllForeignKey)
                    '//////Uncheck SuperClass or Composit Attribute
                    If Tablelist.Count = 1 Then

                    ElseIf Tablelist.Count = 2 Then
                        'Check Nesting or M:N Relationship 
                        Dim ERelationship As String
                        Dim RRelationship As String
                        If CheckCombineNesting(Tablelist, MetaERDataSet) Then
                            'Nesting
                            If MetaERDataSet.FindEntity(Tablelist.Item(0)) > 0 Then
                                ERelationship = Tablelist.Item(0)
                                RRelationship = Tablelist.Item(1)
                            Else
                                ERelationship = Tablelist.Item(1)
                                RRelationship = Tablelist.Item(0)
                            End If


                            TempRelationshipname = String.Concat(ERelationship, " - ", RRelationship)
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                            ' if RelationshipID = -1 then not Relationship_Name
                            Count = 2
                            While RelationshipID <> -1
                                CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                Count = Count + 1
                            End While
                            MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Nesting", TempTableName)
                            SetRowOfDetailTable(DetailTable, TempTableName)

                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                            EntityID = MetaERDataSet.FindEntity(ERelationship)
                            MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "M")
                            'New select type of RelationshipName
                            'Warning Algorithm is error if 2 Relationship same name

                            Tablelist = TableRelatedTable(RRelationship, AllForeignKey)
                            TempRelationshipname = String.Concat(Tablelist.Item(0), " - ", Tablelist.Item(1))
                            If MetaERDataSet.FindRelationship(TempRelationshipname) < 0 Then
                                TempRelationshipname = String.Concat(Tablelist.Item(1), " - ", Tablelist.Item(0))
                                EntityID = MetaERDataSet.FindRelationship(TempRelationshipname) '<--- EntityID = RelationshipID
                            Else
                                EntityID = MetaERDataSet.FindRelationship(TempRelationshipname) '<--- EntityID = RelationshipID
                            End If
                            MetaERDataSet.InsertRelationshipCardinalityTable(EntityID, RelationshipID, "N")


                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With TableSchemaSet.Tables("SchemaList").Rows(j)
                                    If Not .Item("PrimaryKey") Then
                                        MetaERDataSet.InsertAttributeTable _
                                        (.Item("AttributeName"), "Simple", .Item("DataType"), _
                                        RelationshipID, "Relationship", .Item("PrimaryKey"))
                                    End If
                                End With
                            Next

                        Else
                            'M:N Relationship
                            If Not CheckMultivalueAttribute(TableSchemaSet, NumberOfPrimaryKey) Then

                                TempRelationshipname = String.Concat(Tablelist.Item(0), " - ", Tablelist.Item(1))
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                End While
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary", TempTableName)
                                SetRowOfDetailTable(DetailTable, TempTableName)

                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                EntityID = MetaERDataSet.FindEntity(Tablelist.Item(0))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "M")
                                EntityID = MetaERDataSet.FindEntity(Tablelist.Item(1))
                                MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "M")
                            Else
                                'What section is doing?
                                Dim Check As Boolean
                                TempRelationshipname = String.Concat(Tablelist.Item(0), " - ", Tablelist.Item(1))
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)
                                ' if RelationshipID = -1 then not Relationship_Name
                                Count = 2
                                While RelationshipID <> -1
                                    CountRelationshipname = String.Concat(TempRelationshipname, Count)
                                    RelationshipID = MetaERDataSet.FindRelationship(CountRelationshipname)
                                    Count = Count + 1
                                End While
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Binary", TempTableName)
                                SetRowOfDetailTable(DetailTable, TempTableName)
                                RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                                For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                    check = True
                                    For k = 0 To AllForeignKey.Rows.Count - 1
                                        If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") _
                                        AndAlso TableSchemaSet.Tables("SchemaList").Rows(j).Item("AttributeName") = _
                                        AllForeignKey.Rows(k).Item("ForeignKey") Then
                                            check = False
                                            Exit For
                                        End If
                                    Next
                                    If check Then
                                        With TableSchemaSet.Tables("SchemaList").Rows(j)
                                            MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                            "Multivalue", .Item("DataType"), RelationshipID, "Relationship", False)
                                        End With
                                    End If
                                Next
                            End If
                        End If

                        For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                            With TableSchemaSet.Tables("SchemaList").Rows(j)
                                If Not .Item("PrimaryKey") Then
                                    MetaERDataSet.InsertAttributeTable _
                                    (.Item("AttributeName"), "Simple", .Item("DataType"), _
                                    RelationshipID, "Relationship", .Item("PrimaryKey"))
                                End If
                            End With
                        Next

                    ElseIf Tablelist.Count > 2 Then
                        'Check N-ary Relationship
                        If Not CheckMultivalueAttribute(TableSchemaSet, NumberOfPrimaryKey) Then
                            Tablelist.Sort()
                            TempRelationshipname = ""
                            For j = 0 To Tablelist.Count - 1
                                If TempRelationshipname = "" Then
                                    TempRelationshipname = Tablelist.Item(j)
                                Else
                                    TempRelationshipname = String.Concat(TempRelationshipname, " - ", Tablelist.Item(j))
                                End If

                            Next
                            'Detect Trinary or N-ary
                            If Tablelist.Count = 3 Then
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Trenary", TempTableName)
                            Else
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "N-ary", TempTableName)
                            End If
                            SetRowOfDetailTable(DetailTable, TempTableName)
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With TableSchemaSet.Tables("SchemaList").Rows(j)
                                    If Not .Item("PrimaryKey") Then
                                        MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                        "Simple", .Item("DataType"), RelationshipID, "Relationship", False)
                                    End If
                                End With
                            Next

                            For j = 0 To Tablelist.Count - 1
                                EntityID = MetaERDataSet.FindEntity(Tablelist.Item(j))
                                If EntityID >= 0 Then
                                    MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                                Else
                                    Dim sublist As New ArrayList()
                                    sublist = TableRelatedTable(Tablelist.Item(j), AllForeignKey)
                                    TempRelationshipname = String.Concat(sublist.Item(0), " - ", sublist.Item(1))

                                    If MetaERDataSet.FindRelationship(TempRelationshipname) < 0 Then
                                        TempRelationshipname = String.Concat(sublist.Item(1), " - ", sublist.Item(0))
                                        EntityID = MetaERDataSet.FindRelationship(TempRelationshipname) '<--- EntityID = RelationshipID
                                    Else
                                        EntityID = MetaERDataSet.FindRelationship(TempRelationshipname) '<--- EntityID = RelationshipID
                                    End If
                                    MetaERDataSet.InsertRelationshipCardinalityTable(EntityID, RelationshipID, "N")

                                End If
                            Next
                        Else
                            'What section is doing?
                            Dim check As Boolean
                            check = True

                            For k = 0 To Tablelist.Count - 1
                                If TempRelationshipname = "" Then
                                    TempRelationshipname = Tablelist.Item(k)
                                Else
                                    TempRelationshipname = String.Concat(TempRelationshipname, " - ", Tablelist.Item(k))
                                End If
                            Next


                            If Tablelist.Count = 3 Then
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "Trenary", TempTableName)
                            Else
                                MetaERDataSet.InsertRelationshipTable(TempRelationshipname, "N-ary", TempTableName)
                            End If

                            SetRowOfDetailTable(DetailTable, TempTableName)
                            RelationshipID = MetaERDataSet.FindRelationship(TempRelationshipname)

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                With TableSchemaSet.Tables("SchemaList").Rows(j)
                                    If .Item("PrimaryKey") <> True Then
                                        MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                        "Simple", .Item("DataType"), RelationshipID, "Relationship", False)
                                    End If
                                End With
                            Next

                            For j = 0 To AllForeignKey.Rows.Count - 1
                                If AllForeignKey.Rows(j).Item("ForeignKeyTable") = TempTableName Then
                                    EntityID = MetaERDataSet.FindEntity(AllForeignKey.Rows(j).Item("PrimaryKeyTable"))
                                    MetaERDataSet.InsertEntityCardinalityTable(EntityID, RelationshipID, "m")
                                End If
                            Next

                            For j = 0 To TableSchemaSet.Tables("SchemaList").Rows.Count - 1
                                check = True
                                For k = 0 To AllForeignKey.Rows.Count - 1
                                    If TempTableName = AllForeignKey.Rows(k).Item("ForeignKeyTable") _
                                    AndAlso TableSchemaSet.Tables("SchemaList").Rows(j).Item("AttributeName") = _
                                    AllForeignKey.Rows(k).Item("ForeignKey") Then
                                        check = False
                                        Exit For
                                    End If
                                Next
                                If check Then
                                    With TableSchemaSet.Tables("SchemaList").Rows(j)
                                        MetaERDataSet.InsertAttributeTable(.Item("AttributeName"), _
                                        "Multivalue", .Item("DataType"), RelationshipID, "Relationship", False)
                                    End With
                                End If
                            Next
                        End If
                    End If
                    '####### End Check CombineKey Table #######
                Else
                    InsertUndefineTable(TempTableName)
                End If

            Else
                InsertUndefineTable(TempTableName)
            End If
        Next
    End Sub
End Class


