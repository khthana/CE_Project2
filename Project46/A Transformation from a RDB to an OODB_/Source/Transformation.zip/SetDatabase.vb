Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class SetDatabase
    Dim RelationalMetaER As DataSet

    Sub New()
        'SourceDatabase = CurDir("") + "ERmeta.mdb"
    End Sub

    Sub New(ByRef MetaERDataset As DataSet)
        RelationalMetaER = MetaERDataset
        'SourceDatabase = CurDir() + "ERmeta.mdb"
    End Sub

    Sub SetDataToObjectMetaER()

        Dim strConn As String

        Dim i As Integer

        Dim TestConnection As OleDbConnection

        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\ERmeta.mdb;"

        TestConnection = New OleDbConnection(strConn)

        'TestConnection.Open()

        InsertEntityTable(strConn)          'SuperClass 
        InsertRelationshipTable(strConn)    'Comp
        InsertEntityAttributeTable(strConn)
        InsertRelationshipAttributeTable(strConn)
        InsertStructureAttributeTable(strConn)
        InsertCardinalityTable(strConn)

    End Sub

    Private Sub InsertEntityTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()

        TempDataAdapter = New OleDbDataAdapter("Select * from EntityType", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "EntityType")
        TempDataTable = TempDataSet.Tables("EntityType")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Entity_Type").Rows.Count - 1
            TempDatarow = TempDataTable.NewRow()
            TempDatarow("Ename") = ChangeEntityName(RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_Name"))
            TempDatarow("Etype") = ConvertEntityType(RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_Type"))
            If RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_SuperClass") <> "" Then
                TempDatarow("ESuperClass") = ChangeEntityName(RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_SuperClass"))
            Else
                TempDatarow("ESuperClass") = "no"
            End If
            TempDataTable.Rows.Add(TempDatarow)

        Next

        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "EntityType")
        End If
    End Sub

    Private Sub InsertRelationshipTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()

        TempDataAdapter = New OleDbDataAdapter("Select * from Relationship", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "Relationship")
        TempDataTable = TempDataSet.Tables("Relationship")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Relationship_Type").Rows.Count - 1
            TempDatarow = TempDataTable.NewRow()
            If RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_ShowName") <> "" Then
                TempDatarow("Rname") = ChangeRelationshipName(RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_ShowName"))
            Else
                TempDatarow("Rname") = ChangeRelationshipName(RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_Name"))
            End If
            TempDataTable.Rows.Add(TempDatarow)

        Next
        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "Relationship")
        End If
    End Sub

    Private Sub InsertEntityAttributeTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()
        Dim TempDataType As String
        TempDataAdapter = New OleDbDataAdapter("Select * from EntityAttribute", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "EntityAttribute")
        TempDataTable = TempDataSet.Tables("EntityAttribute")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Attribute").Rows.Count - 1

            If LCase(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_BelongType")) = LCase("Entity") Then
                TempDatarow = TempDataTable.NewRow()
                TempDatarow("EID") = FindEntityID(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Belong"), TempStrConn)
                TempDatarow("Aname") = ChangeAttributeName(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Name"))
                TempDatarow("DataType") = ConvertDataType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_DataType"))
                TempDatarow("AttrType") = ConvertAttributeType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDatarow("Array") = CheckArray(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDatarow("Primarykey") = RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_PrimaryKey")
                TempDataTable.Rows.Add(TempDatarow)

            End If
        Next
        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "EntityAttribute")
        End If
    End Sub

    Private Sub InsertRelationshipAttributeTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()

        TempDataAdapter = New OleDbDataAdapter("Select * from RelationshipAttribute", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "RelationshipAttribute")
        TempDataTable = TempDataSet.Tables("RelationshipAttribute")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Attribute").Rows.Count - 1
            If LCase(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_BelongType")) = LCase("Relationship") Then
                TempDatarow = TempDataTable.NewRow()
                TempDatarow("RID") = FindRelationshipID(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Belong"), TempStrConn)
                TempDatarow("Aname") = ChangeAttributeName(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Name"))
                TempDatarow("DataType") = ConvertDataType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_DataType"))
                TempDatarow("AttrType") = ConvertAttributeType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDatarow("Array") = CheckArray(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDataTable.Rows.Add(TempDatarow)
            End If
        Next
        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "RelationshipAttribute")
        End If
    End Sub

    Private Sub InsertStructureAttributeTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()

        TempDataAdapter = New OleDbDataAdapter("Select * from StructureAttribute", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "StructureAttribute")
        TempDataTable = TempDataSet.Tables("StructureAttribute")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Attribute").Rows.Count - 1
            If LCase(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_BelongType")) = LCase("Attribute") Then
                TempDatarow = TempDataTable.NewRow()
                TempDatarow("Struct_name") = FindStructName(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Belong"), TempStrConn)
                TempDatarow("Aname") = ChangeAttributeName(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Name"))
                TempDatarow("DataType") = ConvertDataType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_DataType"))
                TempDatarow("AttrType") = ConvertAttributeType(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDatarow("Array") = CheckArray(RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Type"))
                TempDataTable.Rows.Add(TempDatarow)
            End If
        Next
        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "StructureAttribute")
        End If
    End Sub

    Private Sub InsertCardinalityTable(ByVal TempStrConn As String)
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet(), tempdatachange As New DataSet()

        TempDataAdapter = New OleDbDataAdapter("Select * from Cardinality", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "Cardinality")
        TempDataTable = TempDataSet.Tables("Cardinality")

        Dim tempDataCB As New OleDbCommandBuilder(TempDataAdapter)
        For i = 0 To RelationalMetaER.Tables("Entity_Cardinality").Rows.Count - 1
            TempDatarow = TempDataTable.NewRow()
            TempDatarow("EID") = FindEntityID(RelationalMetaER.Tables("Entity_Cardinality").Rows(i).Item("Entity_ID"), TempStrConn)
            TempDatarow("RID") = FindRelationshipID(RelationalMetaER.Tables("Entity_Cardinality").Rows(i).Item("Relationship_ID"), TempStrConn)
            TempDatarow("Cardinality") = ConvertCardinality(RelationalMetaER.Tables("Entity_Cardinality").Rows(i).Item("NumberOfCardinality"))
            TempDataTable.Rows.Add(TempDatarow)

        Next
        TempDataSet = TempDataSet.GetChanges(DataRowState.Added)
        If Not TempDataSet Is Nothing Then
            TempDataAdapter.Update(TempDataSet, "Cardinality")
        End If
    End Sub

    Private Function ConvertEntityType(ByVal EntityType As String) As String
        If LCase(EntityType) = LCase("Regular") Then
            EntityType = "Simple"
        ElseIf LCase(EntityType) = LCase("Weak") Then
            EntityType = "Weak"
        End If
        Return EntityType
    End Function

    Private Function FindEntityID(ByVal ID As Integer, ByVal TempStrConn As String) As Integer
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()
        Dim TempDataType As String, TempEntityTypeName As String
        TempDataAdapter = New OleDbDataAdapter("Select * from EntityType", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "EntityAttribute")
        TempDataTable = TempDataSet.Tables("EntityAttribute")

        For i = 0 To RelationalMetaER.Tables("Entity_Type").Rows.Count - 1
            If RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_ID") = ID Then
                TempEntityTypeName = RelationalMetaER.Tables("Entity_Type").Rows(i).Item("Entity_Name")
                Exit For
            End If
        Next

        For i = 0 To TempDataTable.Rows.Count - 1
            If TempDataTable.Rows(i).Item("Ename") = ChangeEntityName(TempEntityTypeName) Then
                ID = TempDataTable.Rows(i).Item("EID")
                Exit For
            End If
        Next

        Return ID
    End Function

    Private Function FindRelationshipID(ByVal ID As Integer, ByVal TempStrConn As String) As Integer
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()
        Dim TempDataType As String, TempRelationshipTypeName As String
        TempDataAdapter = New OleDbDataAdapter("Select * from Relationship", TempStrConn)
        TempDataAdapter.Fill(TempDataSet, "Relationship")
        TempDataTable = TempDataSet.Tables("Relationship")

        For i = 0 To RelationalMetaER.Tables("Relationship_Type").Rows.Count - 1
            If RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_ID") = ID Then
                If RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_ShowName") <> "" Then
                    TempRelationshipTypeName = RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_ShowName")
                    Exit For
                Else
                    TempRelationshipTypeName = RelationalMetaER.Tables("Relationship_Type").Rows(i).Item("Relationship_Name")
                    Exit For
                End If
            End If
        Next

        For i = 0 To TempDataTable.Rows.Count - 1
            If TempDataTable.Rows(i).Item("Rname") = ChangeRelationshipName(TempRelationshipTypeName) Then
                ID = TempDataTable.Rows(i).Item("RID")
                Exit For
            End If
        Next

        Return ID
    End Function

    Private Function FindStructName(ByVal ID As Integer, ByVal TempStrConn As String) As String
        Dim i As Integer
        Dim TempDatarow As DataRow
        Dim TempDataAdapter As New OleDbDataAdapter()
        Dim TempDataTable As New DataTable()
        Dim TempDataSet As New DataSet()
        Dim TempDataType As String, TempAttributeName As String, TempAttributeType As String
        Dim TempStructName As String

        For i = 0 To RelationalMetaER.Tables("Attribute").Rows.Count - 1
            If RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_ID") = ID Then
                TempAttributeName = RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_Name")
                TempAttributeType = RelationalMetaER.Tables("Attribute").Rows(i).Item("Attribute_BelongType")
                Exit For
            End If
        Next

        If LCase(TempAttributeType) = LCase("Entity") Then
            TempDataAdapter = New OleDbDataAdapter("Select * from EntityAttribute", TempStrConn)
            TempDataAdapter.Fill(TempDataSet, "EntityAttribute")
            TempDataTable = TempDataSet.Tables("EntityAttribute")

            For i = 0 To TempDataTable.Rows.Count - 1
                If TempDataTable.Rows(i).Item("Aname") = TempAttributeName Then
                    TempStructName = TempDataTable.Rows(i).Item("Aname")
                    Exit For
                End If
            Next

        ElseIf LCase(TempAttributeType) = LCase("Relationship") Then
            TempDataAdapter = New OleDbDataAdapter("Select * from RelationshipAttribute", TempStrConn)
            TempDataAdapter.Fill(TempDataSet, "RelationshipAttribute")
            TempDataTable = TempDataSet.Tables("RelationshipAttribute")

            For i = 0 To TempDataTable.Rows.Count - 1
                If TempDataTable.Rows(i).Item("Aname") = ChangeAttributeName(TempAttributeName) Then
                    TempStructName = TempDataTable.Rows(i).Item("Aname")
                    Exit For
                End If
            Next

        End If

        Return TempStructName
    End Function

    Private Function ConvertDataType(ByVal DataType As String)
        DataType = LCase(DataType)
        Select Case DataType
            Case LCase("string")
                DataType = "string"
            Case LCase("single"), LCase("double")
                DataType = "float"
            Case LCase("int16"), LCase("Int32")
                DataType = "integer"
            Case LCase("DateTime")
                DataType = "date"
            Case LCase("Decimal")
                DataType = "integer"
            Case LCase("Boolean")
                DataType = "boolean"
            Case LCase("stream"), LCase("Byte[]")
                DataType = "stream"
            Case LCase("Time")
                DataType = "time"
            Case LCase("binary")
                DataType = "binary"
        End Select

        Return LCase(DataType)
    End Function

    Private Function ConvertAttributeType(ByVal AttributeType As String) As String
        If LCase(AttributeType) = LCase("Simple") Then
            AttributeType = "normal"
        ElseIf LCase(AttributeType) = LCase("Composite") Then
            AttributeType = "struct"
        ElseIf LCase(AttributeType) = LCase("Multivalue") Then
            AttributeType = "normal"
        ElseIf LCase(AttributeType) = LCase("Complex") Then
            AttributeType = "struct"
        End If
        Return AttributeType
    End Function

    Private Function CheckArray(ByVal AttributeType As String) As String

        If LCase(AttributeType) = LCase("Simple") Then
            AttributeType = False
        ElseIf LCase(AttributeType) = LCase("Composite") Then
            AttributeType = False
        ElseIf LCase(AttributeType) = LCase("Multivalue") Then
            AttributeType = True
        ElseIf LCase(AttributeType) = LCase("Complex") Then
            AttributeType = True
        End If
        Return AttributeType
    End Function

    Private Function ConvertCardinality(ByVal AttributeType As String) As String
        If LCase(AttributeType) = LCase("1") Then
            AttributeType = "one"
        ElseIf LCase(AttributeType) = LCase("m") Then
            AttributeType = "many"
        Else
            AttributeType = "many"
        End If
        Return AttributeType
    End Function

    Private Function ChangeRelationshipName(ByVal RelationshipName As String) As String
        RelationshipName = Replace(RelationshipName, "table", "")
        RelationshipName = Replace(RelationshipName, "TABLE", "")
        RelationshipName = Replace(RelationshipName, "-", "")
        RelationshipName = Replace(RelationshipName, " ", "")
        RelationshipName = Replace(RelationshipName, "_", "")
        Return RelationshipName
    End Function

    Private Function ChangeEntityName(ByVal EntityName As String) As String
        EntityName = Replace(EntityName, "table", "")
        EntityName = Replace(EntityName, "TABLE", "")
        EntityName = Replace(EntityName, "-", "")
        EntityName = Replace(EntityName, " ", "")
        EntityName = Replace(EntityName, "_", "")
        Return EntityName
    End Function

    Private Function ChangeAttributeName(ByVal AttributeName As String) As String
        AttributeName = Replace(AttributeName, "table", "")
        AttributeName = Replace(AttributeName, "TABLE", "")
        AttributeName = Replace(AttributeName, "-", "")
        AttributeName = Replace(AttributeName, " ", "")
        AttributeName = Replace(AttributeName, "_", "")
        Return AttributeName
    End Function

    Public Function SetRelationalMetaER(ByVal ER As DataSet)
        RelationalMetaER = ER
    End Function
End Class
