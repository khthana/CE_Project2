Public Class SelectDatabase
    Inherits System.Windows.Forms.Form

    Private MainForm As Form
    Private Filename As String
    Private TypeConnection As Integer
    Public Status As Boolean
    Dim DBCon As New DatabaseControl()

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal CallForm As Form)

        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        MainForm = CallForm
        TypeConnection = 1
        Status = False


    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)

        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)

        If Status = True Then
            Dim srt As New ShowRelationalSchema()
            srt.SetMainForm(MainForm)
            srt.SetDatabaseConnection(DBCon)

            srt.Top = (MainForm.Top + MainForm.Height / 2) - (srt.Height / 2)
            srt.Left = (MainForm.Left + MainForm.Width / 2) - (srt.Width / 2)

            MainForm.Focus()
            srt.Show()
            srt.Focus()
        Else
            MainForm.Enabled = True
            MainForm.Focus()
        End If

        
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtDatabaseName As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowser As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnTestConnection As System.Windows.Forms.Button
    Friend WithEvents BtnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents ofdAccessFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnBrowser = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtDatabaseName = New System.Windows.Forms.TextBox()
        Me.btnTestConnection = New System.Windows.Forms.Button()
        Me.BtnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.ofdAccessFile = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label4, Me.Label3, Me.txtPassword, Me.txtUsername, Me.Label2, Me.btnBrowser, Me.Label1, Me.txtDatabaseName, Me.btnTestConnection})
        Me.GroupBox1.Location = New System.Drawing.Point(48, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(328, 224)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Ms Access"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(24, 144)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Password :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label4.Visible = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(24, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "User name :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label3.Visible = False
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(96, 144)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(200, 20)
        Me.txtPassword.TabIndex = 4
        Me.txtPassword.Text = ""
        Me.txtPassword.Visible = False
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(96, 120)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(200, 20)
        Me.txtUsername.TabIndex = 3
        Me.txtUsername.Text = ""
        Me.txtUsername.Visible = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(216, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Enter information to log on the database :"
        Me.Label2.Visible = False
        '
        'btnBrowser
        '
        Me.btnBrowser.Location = New System.Drawing.Point(272, 48)
        Me.btnBrowser.Name = "btnBrowser"
        Me.btnBrowser.Size = New System.Drawing.Size(24, 20)
        Me.btnBrowser.TabIndex = 2
        Me.btnBrowser.Text = "..."
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(184, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Select or enter  database name :"
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(40, 48)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.Size = New System.Drawing.Size(232, 20)
        Me.txtDatabaseName.TabIndex = 1
        Me.txtDatabaseName.Text = ""
        '
        'btnTestConnection
        '
        Me.btnTestConnection.Enabled = False
        Me.btnTestConnection.Location = New System.Drawing.Point(192, 184)
        Me.btnTestConnection.Name = "btnTestConnection"
        Me.btnTestConnection.Size = New System.Drawing.Size(104, 24)
        Me.btnTestConnection.TabIndex = 5
        Me.btnTestConnection.Text = "&Test Connection"
        '
        'BtnOK
        '
        Me.BtnOK.Enabled = False
        Me.BtnOK.Location = New System.Drawing.Point(224, 272)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.Size = New System.Drawing.Size(72, 24)
        Me.BtnOK.TabIndex = 6
        Me.BtnOK.Text = "&OK"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(304, 272)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(72, 24)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "&Cancel"
        '
        'ofdAccessFile
        '
        Me.ofdAccessFile.Filter = "*.mdb|*.mdb"
        '
        'SelectDatabase
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCancel, Me.BtnOK, Me.GroupBox1})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SelectDatabase"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Select Database "
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub btnBrowser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowser.Click

        ofdAccessFile.ShowDialog()
        Filename = ofdAccessFile.FileName()
        txtDatabaseName.Text = Filename
        If txtDatabaseName.Text <> "" Then
            btnTestConnection.Enabled = True
            BtnOK.Enabled = True
        End If

    End Sub

    Private Sub btnTestConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestConnection.Click
        DBCon.ChangeConnection(1, txtDatabaseName.Text, txtUsername.Text, txtPassword.Text)
        DBCon.TestConnection()
    End Sub

    Private Sub BtnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOK.Click
        DBCon.ChangeConnection(1, txtDatabaseName.Text, txtUsername.Text, txtPassword.Text)
        If DBCon.TestOpen() Then
            Status = True
            Me.Close()
        Else
            DBCon.TestConnection()
            Status = False
        End If

    End Sub

    Private Sub txtDatabaseName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDatabaseName.TextChanged
        If txtDatabaseName.Text <> "" Then
            btnTestConnection.Enabled = True
            BtnOK.Enabled = True
        Else
            btnTestConnection.Enabled = False
            BtnOK.Enabled = False
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Status = False
        Me.Close()
    End Sub

    Private Sub SelectDatabase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
