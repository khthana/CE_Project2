Imports System.Data
Imports System.Data.OleDb

Public Class CreateClassCDL
    Inherits CreateClass

    Public tmpClass() As tempClass
    Private structAttribute() As Integer

    Public Sub GenClassCDL()
        ' clear ���������� DataSet()
        ds = New DataSet()

        ' ��˹����������� ������ҧ�����
        Dim i As Integer : i = 0 : total = 0
        da = New OleDbDataAdapter("", Conn)
        total = totalClass(Conn, nary, manyAttribute, structAttribute)       ' �Ҩӹǹ���ʷ�������к�
        listRIDrelationship(Conn, relationHasAttribute)     ' �� RID (relationship ����� attribute) ¡��� many to many relationship

        ' �͹������ӹǹ���ʷ������ͧ�к�, ���ҧ array tempClass()
        ReDim tmpClass(total - 1)
        Dim idx As Integer = 0

        ' ���ҧ���� (���� attribute ��� relationship) 
        makeClassStructure(tmpClass, idx, structAttribute, da)
        makeClassEntityType(tmpClass, idx, relationHasAttribute, da)
        makeClassNary(tmpClass, idx, da, nary)
        makeClassManyRelationship(tmpClass, idx, da, manyAttribute)
        makeRelationshipForClassCDL(tmpClass, da, nary, manyAttribute)

        ' test
        'showClass(tmpClass)
    End Sub

    '####################################################
    '       fn �Ҩӹǹ���ʷ������ͧ�к�
    '           input: Conn, nary()
    '           output: integer (�ӹǹ���ʷ�������к�)
    '####################################################
    Function totalClass(ByVal Conn As OleDbConnection, ByRef na() As Integer, ByRef mre() As Integer, ByRef str() As Integer) As Integer
        Dim cnt, total As Integer : cnt = 0 : total = 0
        ' 1.�óբͧ Entity Type
        Dim sql As String = "select * from EntityType"
        Dim da As OleDbDataAdapter = New OleDbDataAdapter(sql, Conn)
        da.SelectCommand.CommandText = sql
        da.Fill(ds, "Entities")
        cnt = ds.Tables("Entities").Rows.Count : total = cnt
        ' 2.�óբͧ N-ary Relationship Type
        sql = "select r.RID as RID, r.Rname as Rname, Count(*) from Relationship as r, Cardinality as c where r.RID = c.RID group by r.RID, r.Rname having count(*)>2"
        da.SelectCommand.CommandText = sql
        da.Fill(ds, "Nary")
        cnt = ds.Tables("Nary").Rows.Count : total += cnt
        ReDim na(cnt - 1)
        Dim i = 0
        While i < na.Length
            Dim rid = CInt(ds.Tables("Nary").Rows(i).Item("RID"))
            na(i) = rid
            i += 1
        End While
        ' 3.�óբͧ many to many relationship Ẻ�� attribute
        sql = "select c.RID as RID, max(r.Rname) as Rname from Cardinality as c, Relationship as r where c.RID = r.RID and c.Cardinality = 'many' group by c.RID having count(*)=2"
        da.SelectCommand.CommandText = sql
        da.Fill(ds, "ManyRelationship")
        cnt = ds.Tables("ManyRelationship").Rows.Count : total += cnt
        ReDim mre(cnt - 1) : i = 0
        While i < mre.Length
            Dim rid = CInt(ds.Tables("ManyRelationship").Rows(i).Item("RID"))
            mre(i) = rid
            i += 1
        End While
        ' 4.�óբͧ Structure � attribute
        sql = "select sa.Struct_name as typename from EntityAttribute as en, StructureAttribute as sa where en.DataType=sa.Struct_name group by sa.Struct_name"
        da.SelectCommand.CommandText = sql
        da.Fill(ds, "TypeStruct")
        cnt = ds.Tables("TypeStruct").Rows.Count : total += cnt
        ReDim str(cnt - 1) : i = 0
        Return total
    End Function

    '####################################################
    '       fn ��˹���� rid ����� attribute ŧ� reAttribute()  ¡��� many to many relationship
    '           input: Conn, reAttribute()
    '####################################################
    Sub listRIDrelationship(ByVal Conn As OleDbConnection, ByRef re() As String)
        Dim cnt, i As Integer : cnt = 0 : i = 0
        Dim sql As String = "select RID, count(*) as total from RelationshipAttribute " & _
            "where RID in (select RID from Cardinality where Cardinality = 'one' group by RID having count(*)<3) " & _
            "group by RID"
        Dim da As OleDbDataAdapter = New OleDbDataAdapter(sql, Conn)
        da.Fill(ds, "ReAttr")
        cnt = ds.Tables("ReAttr").Rows.Count
        ReDim re(cnt - 1)
        While i < re.Length
            Dim rid = CInt(ds.Tables("ReAttr").Rows(i).Item("RID"))
            Dim tot = CInt(ds.Tables("ReAttr").Rows(i).Item("total"))
            sql = "select EID,Cardinality as degree from Cardinality where RID=" & rid
            Dim da_temp As OleDbDataAdapter = New OleDbDataAdapter(sql, Conn)
            Dim ds_temp As DataSet = New DataSet() : da_temp.Fill(ds_temp)
            Dim eid1 As Integer = ds_temp.Tables(0).Rows(0).Item("EID")
            Dim deg1 As String = ds_temp.Tables(0).Rows(0).Item("degree")
            Dim eid2 As Integer = ds_temp.Tables(0).Rows(1).Item("EID")
            Dim deg2 As String = ds_temp.Tables(0).Rows(1).Item("degree")
            Dim eid As Integer : Dim size As String
            If (deg1 = "many") And (deg2 = "one") Then
                eid = eid1 : size = "normal"
            ElseIf (deg1 = "one") And (deg2 = "many") Then
                eid = eid2 : size = "normal"
            ElseIf (deg1 = "one") And (deg2 = "one") Then
                eid = eid1 : size = "normal"
            End If
            re(i) = rid & ":" & eid & ":" & tot & ":" & size
            i += 1
        End While
    End Sub

    '####################################################
    '       ���ҧ���� Structure (Composite Attribute)
    '           input: tempClass(), index, structAttribute()
    '####################################################
    Sub makeClassStructure(ByRef tmpClass() As tempClass, ByRef idx As Integer, ByVal struct() As Integer, ByVal da As OleDbDataAdapter)
        Dim cnt, i As Integer : Dim sql As String
        i = 0 : cnt = ds.Tables("TypeStruct").Rows.Count
        While i < cnt
            Dim struct_name As String
            struct_name = CStr(ds.Tables("TypeStruct").Rows(i).Item("typename"))

            tmpClass(idx) = New tempClass()
            tmpClass(idx).className = struct_name
            tmpClass(idx).superName = "no"
            Dim ds1 As DataSet = New DataSet()
            sql = "select * from StructureAttribute where struct_name='" & struct_name & "'"
            da.SelectCommand.CommandText = sql
            da.Fill(ds1, "StructAttributes")
            ' ��˹���Ҵ attribute �ͧ���� Structure Attribute
            Dim num_attribute As Integer
            num_attribute = ds1.Tables("StructAttributes").Rows.Count
            tmpClass(idx).setArrayToAttribute(num_attribute - 1)
            ' ��˹���Ҵ relationship �ͧ���� Structure Attribute ��ҡѺ -1
            tmpClass(idx).setArrayToRelationship(-1)
            Dim j As Integer : j = 0
            While j < num_attribute
                ' ��������� attribute �ͧ���� Entity
                Dim aname, datatype, attrtype As String
                Dim array As Boolean
                aname = CStr(ds1.Tables("StructAttributes").Rows(j).Item("Aname"))
                datatype = CStr(ds1.Tables("StructAttributes").Rows(j).Item("DataType"))
                attrtype = CStr(ds1.Tables("StructAttributes").Rows(j).Item("AttrType"))
                array = CBool(ds1.Tables("StructAttributes").Rows(j).Item("Array"))
                datatype = change_first_char_to_upper(datatype)
                Dim str_attribute As String
                str_attribute = attrtype & ":" & aname & ":" & datatype & ":" & array
                tmpClass(idx).attribute(j) = str_attribute
                j += 1
            End While
            idx += 1
            i += 1
        End While
    End Sub

    '####################################################
    '       ���ҧ���� EntityType
    '           input: tempClass(), index, reAttribute()
    '####################################################
    Sub makeClassEntityType(ByRef tmpClass() As tempClass, ByRef idx As Integer, ByVal re() As String, ByVal da As OleDbDataAdapter)
        Dim cnt, i As Integer : Dim sql As String
        i = 0 : cnt = ds.Tables("Entities").Rows.Count
        While i < cnt
            Dim eid As Integer
            Dim ename, etype, esuper As String
            eid = CInt(ds.Tables("Entities").Rows(i).Item("EID"))
            ename = CStr(ds.Tables("Entities").Rows(i).Item("Ename"))
            etype = CStr(ds.Tables("Entities").Rows(i).Item("Etype"))
            esuper = CStr(ds.Tables("Entities").Rows(i).Item("ESuperClass"))
            tmpClass(idx) = New tempClass()
            tmpClass(idx).className = ename
            If esuper = "no" Then
                tmpClass(idx).superName = "no"
            Else
                tmpClass(idx).superName = esuper
            End If
            ' ��˹���Ҵ attribute �ͧ���� Entity Type
            Dim ds1 As DataSet = New DataSet()
            sql = "select * from EntityAttribute where EID = " & eid
            da.SelectCommand.CommandText = sql
            da.Fill(ds1, "EnAttributes")
            Dim num_attribute As Integer
            num_attribute = ds1.Tables("EnAttributes").Rows.Count
            num_attribute += get_num_total_in_relation_attribute(re, eid)
            tmpClass(idx).setArrayToAttribute(num_attribute - 1)
            ' ��˹���Ҵ relationship �ͧ���� Entity Type
            sql = "select count(*) as totRelation from Cardinality where EID = " & eid & " group by EID"
            da.SelectCommand.CommandText = sql
            da.Fill(ds1, "sizeRelationship")
            Dim num_relationship As Integer
            If ds1.Tables("sizeRelationship").Rows.Count = 0 Then
                num_relationship = 0
            Else
                num_relationship = ds1.Tables("sizeRelationship").Rows(0).Item("totRelation")
            End If
            'num_relationship = ds1.Tables("sizeRelationship").Rows(0).Item("totRelation")
            tmpClass(idx).setArrayToRelationship(num_relationship - 1)
            ' ��������� attribute �ͧ���� Entity
            Dim j, num_attribute_in_entity As Integer : j = 0
            num_attribute_in_entity = ds1.Tables("EnAttributes").Rows.Count
            While j < num_attribute_in_entity
                ' ��˹���Ңͧ���� attribute �ͧ����
                Dim aid As Integer
                Dim aname, datatype, attrtype As String
                Dim array, akey As Boolean
                aid = CInt(ds1.Tables("EnAttributes").Rows(j).Item("AID"))
                aname = CStr(ds1.Tables("EnAttributes").Rows(j).Item("Aname"))
                datatype = CStr(ds1.Tables("EnAttributes").Rows(j).Item("DataType"))
                attrtype = CStr(ds1.Tables("EnAttributes").Rows(j).Item("AttrType"))
                array = CBool(ds1.Tables("EnAttributes").Rows(j).Item("Array"))
                akey = CBool(ds1.Tables("EnAttributes").Rows(j).Item("Primarykey"))
                ' ��Ǩ�ͺ structure
                Dim str_attribute As String = ""
                If attrtype <> "struct" Then
                    datatype = change_first_char_to_upper(datatype)
                End If
                str_attribute = attrtype & ":" & aname & ":" & datatype & ":" & array
                tmpClass(idx).attribute(j) = str_attribute
                j += 1
            End While

            ' ��������� attribute �ͧ relationship (����� attribute) ŧ㹤��� Entity
            Dim k, idx_reAttribute() As Integer : k = 0
            idx_reAttribute = get_indexs_eid_in_relation_attribute(re, eid)
            While (j < num_attribute) And (k < idx_reAttribute.Length)
                Dim tmp(3) As String
                tmp = re(idx_reAttribute(k)).Split(":")
                Dim ds2 As DataSet = New DataSet()
                sql = "select * from RelationshipAttribute where RID=" & tmp(0)
                da.SelectCommand.CommandText = sql
                da.Fill(ds2, "attribute_in_relationship")
                Dim i1, tmp_cnt As Integer : i1 = 0
                tmp_cnt = ds2.Tables("attribute_in_relationship").Rows.Count
                While i1 < tmp_cnt
                    ' ��˹���Ңͧ���� attribute �ͧ����
                    Dim aid As Integer
                    Dim aname, datatype, attrtype As String
                    Dim array As Boolean
                    aid = CInt(ds2.Tables("attribute_in_relationship").Rows(i1).Item("AID"))
                    aname = CStr(ds2.Tables("attribute_in_relationship").Rows(i1).Item("Aname"))
                    datatype = CStr(ds2.Tables("attribute_in_relationship").Rows(i1).Item("DataType"))
                    attrtype = tmp(3)
                    array = CBool(ds2.Tables("attribute_in_relationship").Rows(i1).Item("Array"))
                    datatype = change_first_char_to_upper(datatype)
                    ' �ѧ�����Դ �����
                    tmpClass(idx).attribute(j) = "normal:" & aname & ":" & datatype & ":" & array
                    j += 1 : i1 += 1
                End While
                k += 1
            End While
            idx += 1
            i += 1
        End While
    End Sub

    '####################################################
    '       ���ҧ���� N-ary relationship type
    '           input: tempClass(), index, nary()
    '####################################################
    Sub makeClassNary(ByRef tmpClass() As tempClass, ByRef idx As Integer, ByVal da As OleDbDataAdapter, ByVal na() As Integer)
        Dim cnt, i As Integer : Dim sql As String
        i = 0
        While i < na.Length
            Dim rid As Integer
            rid = na(i)
            If rid <> 0 Then
                Dim rname As String
                rname = ds.Tables("Nary").Rows(i).Item("Rname")
                tmpClass(idx) = New tempClass()
                tmpClass(idx).className = rname & "ing"
                tmpClass(idx).superName = "No"      ' not edit na na...
                ' ��˹���Ҵ attribute �ͧ���� N-ary relationship type
                Dim ds3 As DataSet = New DataSet()
                sql = "select * from RelationshipAttribute where RID = " & rid
                da.SelectCommand.CommandText = sql
                da.Fill(ds3, "ReAttributes")
                Dim num_attribute As Integer
                num_attribute = ds3.Tables("ReAttributes").Rows.Count
                tmpClass(idx).setArrayToAttribute(num_attribute - 1)
                ' ��˹���Ҵ relationship �ͧ���� N-ary relationship type
                sql = "select count(*) as totRelation from Cardinality where RID = " & rid & " group by RID"
                da.SelectCommand.CommandText = sql
                da.Fill(ds3, "sizeRelationship")
                Dim num_relationship As Integer
                num_relationship = ds3.Tables("sizeRelationship").Rows(0).Item("totRelation")
                tmpClass(idx).setArrayToRelationship(num_relationship - 1)
                Dim j As Integer = 0
                While j < tmpClass(idx).attribute.Length
                    ' ��˹�������� attribute �ͧ����
                    Dim aname, datatype, attrtype As String
                    Dim array As Boolean
                    aname = CStr(ds3.Tables("ReAttributes").Rows(j).Item("Aname"))
                    datatype = CStr(ds3.Tables("ReAttributes").Rows(j).Item("DataType"))
                    attrtype = CStr(ds3.Tables("ReAttributes").Rows(j).Item("AttrType"))
                    array = CBool(ds3.Tables("ReAttributes").Rows(j).Item("Array"))
                    datatype = change_first_char_to_upper(datatype)
                    tmpClass(idx).attribute(j) = attrtype & ":" & aname & ":" & datatype & ":" & array
                    j += 1
                End While
                idx += 1
            End If
            i += 1
        End While
    End Sub

    '####################################################
    '       ���ҧ���� many to many relationship type (����� attributes)
    '           input: tempClass(), index, relationshipHasAttribute()
    '####################################################
    Sub makeClassManyRelationship(ByRef tmpClass() As tempClass, ByRef idx As Integer, ByVal da As OleDbDataAdapter, ByVal re() As Integer)
        Dim cnt, i As Integer : Dim sql As String
        i = 0
        While i < re.Length
            Dim rid As Integer
            rid = re(i)
            If rid <> 0 Then
                Dim rname As String
                rname = ds.Tables("ManyRelationship").Rows(i).Item("Rname")
                tmpClass(idx) = New tempClass()
                tmpClass(idx).className = rname & "ing"
                tmpClass(idx).superName = "no"      ' not edit na na...
                ' ��˹���Ҵ attribute �ͧ���� many to many relationship type
                Dim ds4 As DataSet = New DataSet()
                sql = "Select * From RelationshipAttribute Where RID = " & rid
                da.SelectCommand.CommandText = sql
                da.Fill(ds4, "ReAttributes")
                Dim num_attribute As Integer
                num_attribute = ds4.Tables("ReAttributes").Rows.Count
                tmpClass(idx).setArrayToAttribute(num_attribute - 1)
                ' ��˹���Ҵ relationship �ͧ���� many to many relationship type
                tmpClass(idx).setArrayToRelationship(1)    ' size �� 2 ���
                Dim j As Integer = 0
                While j < tmpClass(idx).attribute.Length
                    ' ��˹�������� attribute �ͧ����
                    Dim aname, datatype, attrtype As String
                    Dim array As Boolean
                    aname = CStr(ds4.Tables("ReAttributes").Rows(j).Item("Aname"))
                    datatype = CStr(ds4.Tables("ReAttributes").Rows(j).Item("DataType"))
                    attrtype = CStr(ds4.Tables("ReAttributes").Rows(j).Item("AttrType"))
                    array = CBool(ds4.Tables("ReAttributes").Rows(j).Item("Array"))
                    datatype = change_first_char_to_upper(datatype)
                    tmpClass(idx).attribute(j) = attrtype & ":" & aname & ":" & datatype & ":" & array
                    j += 1
                End While
                idx += 1
            End If
            i += 1
        End While
    End Sub

    '####################################################
    '       ����Ѻ���ҧ��� .CDL
    '       ���ҧ relationship ���Ѻ���Ф��� (Entity, N-ary ��� many to many relationship(����� attribute))
    '           input: tempClass(), DataAdapter, nary(), many()
    '####################################################
    Sub makeRelationshipForClassCDL(ByRef tmpClass() As tempClass, ByVal da As OleDbDataAdapter, ByVal na() As Integer, ByVal many() As Integer)
        Dim cnt, i As Integer : Dim sql As String
        sql = "Select RID, Rname From Relationship Order By RID"
        da.SelectCommand.CommandText = sql
        da.Fill(ds, "relation1")
        i = 0 : cnt = ds.Tables("relation1").Rows.Count
        While i < cnt
            Dim rid As Integer = CInt(ds.Tables("relation1").Rows(i).Item("RID"))
            Dim rname As String = CStr(ds.Tables("relation1").Rows(i).Item("Rname"))
            ' �ó� N-ary relationship type
            If find_rid_in_array_integer(na, rid) = True Then
                ' ��� relationship ���Ѻ���� N-ary : �դ�� rid ��� rname
                Dim ds1 As DataSet = New DataSet()
                sql = "Select * From Cardinality As c, EntityType As e, Relationship As r Where e.EID = c.EID And r.RID = c.RID And c.RID = " & rid & " Order By c.EID, c.RID"
                da.SelectCommand.CommandText = sql
                da.Fill(ds1, "relation2")
                Dim naryName As String = rname & "ing"
                Dim at As Integer = get_index_in_create_class(tmpClass, naryName)
                Dim x As Integer = 0
                While x < tmpClass(at).relationship.Length
                    ' entity
                    Dim enid1 As Integer = CInt(ds1.Tables("relation2").Rows(x).Item("e.EID"))
                    Dim en1 As String = CStr(ds1.Tables("relation2").Rows(x).Item("Ename"))
                    Dim car1 As String = CStr(ds1.Tables("relation2").Rows(x).Item("Cardinality"))
                    Dim at1 As Integer = get_index_in_create_class(tmpClass, en1)
                    ' add for n-ary
                    tmpClass(at).relationship(x) = naryName & rname & enid1 & en1 & ":" & car1 & ":" & tmpClass(at1).className & ":" & en1 & rname & enid1 & naryName & ":" & " "
                    ' add for entity
                    tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & enid1 & naryName & ":one:" & naryName & ":" & naryName & rname & enid1 & en1 & ":" & " "
                    x += 1
                End While

                ' �ó� many to many relationship type (����� attributes)
            ElseIf find_rid_in_array_integer(many, rid) = True Then
                ' ��� relationship ���Ѻ���� many to many relationship type : �դ�� rid ��� rname
                Dim ds1 As DataSet = New DataSet()
                sql = "Select * From Cardinality As c, EntityType As e, Relationship As r Where e.EID = c.EID And r.RID = c.RID And c.RID = " & rid & " Order By c.EID, c.RID"
                da.SelectCommand.CommandText = sql
                da.Fill(ds1, "relation2")
                Dim maryName As String = rname & "ing"
                Dim at As Integer = get_index_in_create_class(tmpClass, maryName)
                Dim x As Integer = 0
                While x < tmpClass(at).relationship.Length
                    ' entity
                    Dim enid1 As Integer = CInt(ds1.Tables("relation2").Rows(x).Item("e.EID"))
                    Dim en1 As String = CStr(ds1.Tables("relation2").Rows(x).Item("Ename"))
                    Dim car1 As String = CStr(ds1.Tables("relation2").Rows(x).Item("Cardinality"))
                    Dim at1 As Integer = get_index_in_create_class(tmpClass, en1)
                    ' add for many to many relationship type
                    tmpClass(at).relationship(x) = maryName & rname & enid1 & en1 & ":" & car1 & ":" & tmpClass(at1).className & ":" & en1 & rname & enid1 & maryName & ":" & " "
                    ' add for entity
                    tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & enid1 & maryName & ":one:" & maryName & ":" & maryName & rname & enid1 & en1 & ":" & " "
                    x += 1
                End While

                ' �ó� Entity type
            Else
                ' ��� relationship ���Ѻ���� Entity type : �դ�� rid ��� rname
                Dim ds1 As DataSet = New DataSet()
                sql = "Select * From Cardinality As c, EntityType As e Where e.EID = c.EID and c.RID = " & rid & " Order By c.EID"
                da.SelectCommand.CommandText = sql
                da.Fill(ds1, "relation2")
                ' entity 1
                Dim en1 As String = CStr(ds1.Tables("relation2").Rows(0).Item("Ename"))
                Dim car1 As String = CStr(ds1.Tables("relation2").Rows(0).Item("Cardinality"))
                Dim at1 As Integer = get_index_in_create_class(tmpClass, en1)
                ' entity 2
                Dim en2 As String = CStr(ds1.Tables("relation2").Rows(1).Item("Ename"))
                Dim car2 As String = CStr(ds1.Tables("relation2").Rows(1).Item("Cardinality"))
                Dim at2 As Integer = get_index_in_create_class(tmpClass, en2)
                ' ��Ǩ�ͺ����� Recursive relationship �������
                If en1.Equals(en2) Then
                    ' ��Ǩ�ͺ relationship ����� 1:1 relationship �������
                    If (car1 = "one") And (car2 = "one") Then
                        tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & ":" & car1 & ":" & tmpClass(at2).className & ":" & rname & en2 & ":" & "one to one"
                        tmpClass(at2).relationship(tmpClass(at2).getLastIndex) = rname & en2 & ":many:" & tmpClass(at1).className & ":" & en1 & rname & ":" & " "
                    Else
                        tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & ":" & car1 & ":" & tmpClass(at2).className & ":" & rname & en2 & ":" & " "
                        tmpClass(at2).relationship(tmpClass(at2).getLastIndex) = rname & en2 & ":" & car2 & ":" & tmpClass(at1).className & ":" & en1 & rname & ":" & " "
                    End If
                Else
                    ' ��Ǩ�ͺ relationship ����� 1:1 relationship �������
                    If (car1 = "one") And (car2 = "one") Then
                        tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & en2 & ":" & car1 & ":" & tmpClass(at2).className & ":" & en2 & rname & en1 & ":" & "one to one"
                        tmpClass(at2).relationship(tmpClass(at2).getLastIndex) = en2 & rname & en1 & ":many:" & tmpClass(at1).className & ":" & en1 & rname & en2 & ":" & " "
                    Else
                        tmpClass(at1).relationship(tmpClass(at1).getLastIndex) = en1 & rname & en2 & ":" & car1 & ":" & tmpClass(at2).className & ":" & en2 & rname & en1 & ":" & " "
                        tmpClass(at2).relationship(tmpClass(at2).getLastIndex) = en2 & rname & en1 & ":" & car2 & ":" & tmpClass(at1).className & ":" & en1 & rname & en2 & ":" & " "
                    End If
                End If
            End If
            i += 1
        End While
    End Sub

End Class