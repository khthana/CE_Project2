package netmaker;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SwitchDialog extends JDialog {
  private Switch sw = new Switch();
  private XYLayout xYLayout1 = new XYLayout();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  private JPanel jPanel1 = new JPanel();
  private JPanel jPanel2 = new JPanel();
  private XYLayout xYLayout2 = new XYLayout();
  private XYLayout xYLayout3 = new XYLayout();
  private JTextField password = new JTextField();
  private XYLayout xYLayout4 = new XYLayout();
  private JTextField hostName = new JTextField();
  private JLabel pSWRouter = new JLabel();
  private JLabel hostnameRouter = new JLabel();
  private JPanel jPanel3 = new JPanel();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JButton proprety = new JButton();
  private JPanel jPanel5 = new JPanel();
  private XYLayout xYLayout6 = new XYLayout();
  private JLabel defaultGateway = new JLabel();
  private JTextField gateway = new JTextField();
  private JList jList1 = new JList();
  private Vector list =  new Vector();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private Vector swPort,forCancel = new Vector() ;
  public SwitchDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SwitchDialog() {
    this(null, "", true);
  }
  //--------------------------------------------------------------------//


  public void chkSW(Switch sw1){
      list = sw1.getVectorOfPort();
      Vector portChannels = sw1.getPortChannels();
      swPort = sw1.getEthernetInterfaces();
      PortChannelINF portChannel;
      String idPortChannel;
      for(int i=0;i<swPort.size();i++){
        SwitchEthINF eth = (SwitchEthINF)swPort.elementAt(i);
        SwitchEthINF temp = new SwitchEthINF();
        boolean chk =eth.isConnected();
        String str = new String();
        temp.setConnected(chk);
        str = eth.getInterfaceName();
        temp.setInterfaceName(str);
        str = eth.getIpAddress();
        temp.setIpAddress(str);
        str = eth.getMode();
        temp.setMode(str);
        str = eth.getPortChannelID();
        temp.setPortChannelID(str);
        chk = eth.isShutdown();
        temp.setShutdown(chk);
        str =eth.getSubnet();
        temp.setSubnet(str);Vector temps = new Vector();
        for(int j = 0 ;j< eth.getVlanSTPs().size();j++)
          temps.addElement(eth.getVlanSTPs().elementAt(j));
        temp.setVlanSTPs(temps);
        forCancel.addElement(temp);
      }
      for(int j=0;j<portChannels.size();j++){
        portChannel = (PortChannelINF)portChannels.elementAt(j);
        list.addElement("Group"+portChannel.getId());
      }
      sw = sw1;
      this.hostName.setText(sw.getHostName());
      this.gateway.setText(sw.getDefaultGateWay());
      this.password.setText(sw.getPassword());
      this.iosVersion.setText(sw.getIosVersion());
      this.setTitle(sw.getHostName());
    jList1.setListData(list);
  }
  //--------------------------------------------------------------------//
  private void jbInit() throws Exception {
   this.getContentPane().setLayout(xYLayout1);
//   jList1.setListData(list);
   this.setTitle(sw.getHostName());
    jPanel1.setLayout(xYLayout2);
    jPanel2.setLayout(xYLayout3);
    jTabbedPane1.setSize(400,456);
    jTabbedPane1.setVisible(true);
    xYLayout1.setWidth(400);
    xYLayout1.setHeight(456);
    xYLayout2.setWidth(400);
    xYLayout3.setHeight(456);
    xYLayout3.setWidth(400);
    xYLayout2.setHeight(456);
    xYLayout4.setWidth(400);
    xYLayout4.setHeight(456);
    pSWRouter.setText("Password");
    hostnameRouter.setText("host name");
    jPanel3.setLayout(xYLayout4);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setPreferredSize(new Dimension(404, 460));
    jPanel3.setBackground(SystemColor.inactiveCaptionText);
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    jPanel1.setBackground(SystemColor.inactiveCaptionText);
    jPanel1.setPreferredSize(new Dimension(400, 456));
    jTabbedPane1.setBackground(SystemColor.inactiveCaptionText);
    this.getContentPane().setBackground(UIManager.getColor("inactiveCaptionText"));
    jPanel2.setBackground(UIManager.getColor("inactiveCaptionText"));
    proprety.setBackground(SystemColor.inactiveCaptionText);
    proprety.setText("Properties");
    proprety.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        proprety_actionPerformed(e);
      }
    });
    jPanel5.setBackground(SystemColor.inactiveCaptionText);
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setLayout(xYLayout6);
    defaultGateway.setText("Default Gateway");
    jList1.setBackground(SystemColor.window);
    jLabel1.setText("IOS Version");
    this.getContentPane().add(jTabbedPane1,           new XYConstraints(5, 5, 400, 400));
    jTabbedPane1.add(jPanel1,   "General");
    jPanel3.add(hostnameRouter,   new XYConstraints(25, 100, -1, -1));
    jPanel3.add(pSWRouter,   new XYConstraints(25, 200, -1, -1));
    jPanel3.add(hostName,   new XYConstraints(125, 100, 150, -1));
    jPanel3.add(password,   new XYConstraints(125, 200, 150, -1));
    jPanel3.add(gateway,      new XYConstraints(125, 150, 150, -1));
    jPanel3.add(defaultGateway,     new XYConstraints(25, 150, -1, -1));
    jPanel3.add(jLabel1,   new XYConstraints(25, 50, -1, -1));
    jPanel3.add(iosVersion,    new XYConstraints(125, 50, 150, -1));
    jPanel1.add(jPanel3,  new XYConstraints(42, 33, 308, 285));
    jTabbedPane1.add(jPanel2,   "Interface");
    jPanel5.add(jScrollPane1,       new XYConstraints(74, 33, 217, 197));
    jPanel2.add(proprety,    new XYConstraints(300, 300, -1, -1));
    this.getContentPane().add(ok,  new XYConstraints(250, 420, -1, -1));
    this.getContentPane().add(cancel,  new XYConstraints(320, 420, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);

    jPanel2.add(jPanel5,         new XYConstraints(5, 5, 380, 275));
    hostName.setText(sw.getHostName());
    gateway.setText(sw.getDefaultGateWay());
    password.setText(sw.getPassword());

  }

  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(415,500);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
  }

void proprety_actionPerformed(ActionEvent e) {

    String name = "";
    SwitchEthINF in ;
    PortChannelINF portChannel ;
    if(!jList1.isSelectionEmpty())
    name = (String)jList1.getSelectedValue();
    Vector swPortChannel = sw.getPortChannels();

    for(int i=0;i<swPort.size();i++)
    {
      in = (SwitchEthINF)swPort.elementAt(i);
      if(name.equals(in.getInterfaceName()))
      {
      ConfigPort config = new ConfigPort();
      config.config(in,sw);
      config.showDialog();
      }
    }
    for(int i=0;i<swPortChannel.size();i++)
    {
      portChannel = (PortChannelINF)swPortChannel.elementAt(i);
      if(name.equals("Group"+portChannel.getId()))
      {
      ConfigPortChannel config = new ConfigPortChannel();
      config.config(portChannel,sw);
      config.showDialog();
      }
    }

  }

  void ok_actionPerformed(ActionEvent e) {
    boolean isError = false;
    String name;
    String psw;
    name = hostName.getText();
    psw =password.getText();
    if (!isError){
      if(!name.equals(sw.getHostName())){

        for(int i = 0 ;i < Frame1.vSwitch.size();i++){
          Switch sw1 = (Switch)Frame1.vSwitch.elementAt(i);
          String temp = sw1.getHostName();
          if(name.equals(temp)){
            isError = true;
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Hostname is already! Please try again");
            dialog.showDialog();
          }
        }
      }
    }
    if (!isError)
    if(chkIP(gateway.getText()) || gateway.getText().equals("")){
      isError = false;
    }else{
    isError = true;
    gateway.setText("");
    ErrorDialog dialog = new ErrorDialog();
    dialog.setText("Illegal Default Gateway! Please try again");
    dialog.showDialog();
    }
    if(!isError){
      if(!gateway.getText().equals(""))
      sw.setDefaultGateWay(correctIP(gateway.getText()));
      else sw.setDefaultGateWay("");
      sw.setHostName(name);
      sw.setPassword(psw);
      sw.setIosVersion(iosVersion.getText());
    this.dispose();
    }
    sw.showDetail();
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
    sw.setEthernetInterfaces(forCancel);
    sw.showDetail();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel_actionPerformed(null);
    }
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
        int num = Integer.parseInt(temp);
        ip = ip+String.valueOf(num)+".";
        if((num>=0)&&(num<=255)){
          temp = "";
        }else {
          return false;
        }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
    return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
        int num = Integer.parseInt(temp);
        ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
    int num = Integer.parseInt(temp);
    ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
  private JLabel jLabel1 = new JLabel();
  private JTextField iosVersion = new JTextField();
}