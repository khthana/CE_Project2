package netmaker;

import java.util.Vector;
public class ExtACL {

  private Vector aces = new Vector();//Vector of ExtACE class
  private String id = ""; // ALC id
  public ExtACL() {
  }
  public ExtACL(String id){
    this.setId(id);
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public Vector getAces() {
    return aces;
  }
  public void setAces(Vector aces) {
    this.aces = aces;
  }

  /////////////////////////////function////////////////////////////

  public void addExtAce(ExtACE ace){
    this.aces.addElement(ace);
  }
  public void removeExtAce(String stringACE){
    for (int i=0;i<this.aces.size();i++){
      if (stringACE.equalsIgnoreCase(((ExtACE)this.aces.elementAt(i)).getStringACE())){  //compare string
        this.aces.removeElementAt(i);
      }
    }
  }
}