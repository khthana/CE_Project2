package netmaker;

import java.util.Vector;

public class SerialINF {
  private String ipAddress = "";
  private String subnet = "";
  private String interfaceName = "";
  private String clockRate = "";
  private boolean shutdown;
  private java.util.Vector accessGroups = new Vector();;
  private boolean connected;
  public SerialINF() {
  }
  public SerialINF(String interfaceName){//overide from constructor
    this.setInterfaceName(interfaceName);
  }
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public String getInterfaceName() {
    return interfaceName;
  }
  public void setInterfaceName(String interfaceName) {
    this.interfaceName = interfaceName;
  }
  public String getClockRate() {
    return clockRate;
  }
  public void setClockRate(String clockRate) {
    this.clockRate = clockRate;
  }
  public boolean isShutdown() {
    return shutdown;
  }
  public void setShutdown(boolean shutdown) {
    this.shutdown = shutdown;
  }

  /////////////////////////////////////function////////////////////////////////
  public void addAccessGroup(String id, boolean incoming) {
    if (!this.isAccessGroupAdded(id)){
      this.accessGroups.addElement(new AccessGroup(id, incoming));
    }

  }
  private boolean isAccessGroupAdded(String id)  {
    int lastIndex = this.accessGroups.size();
    int i=0;
    while (i<lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(i)).getId().equalsIgnoreCase(id))
        return true;
      i++;
    }
    return false;
  }
  public void removeAccessGroup(String id) {
    if (this.indexOfAccessGroup(id) != -1)
      this.accessGroups.removeElementAt(this.indexOfAccessGroup(id));
  }
  private int indexOfAccessGroup(String id)  {
    int lastIndex = this.accessGroups.size();
    int index = 0;
    while (index < lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(index)).getId().equalsIgnoreCase(id))
        return index;
      index++;
    }
    return -1;
  }
  public java.util.Vector getAccessGroups() {
    return accessGroups;
  }
  public void setAccessGroups(java.util.Vector accessGroups) {
    this.accessGroups = accessGroups;
  }
  public void setConnected(boolean connected) {
    this.connected = connected;
  }
  public boolean isConnected() {
    return connected;
  }
}