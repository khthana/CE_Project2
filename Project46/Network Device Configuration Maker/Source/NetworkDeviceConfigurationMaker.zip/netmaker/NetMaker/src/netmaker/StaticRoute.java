package netmaker;

public class StaticRoute extends DefaultRoute {
  private String network = "";
  private String subnet = "";
  public StaticRoute() {
  }
  public String getNetwork() {
    return network;
  }
  public void setNetwork(String network) {
    this.network = network;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public String getSubnet() {
    return subnet;
  }

}