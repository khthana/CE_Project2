package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

public class StdAceDialog extends JDialog {
  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  ButtonGroup actionGroup = new ButtonGroup();
  JRadioButton permitRadio = new JRadioButton();
  JRadioButton denyRadio = new JRadioButton();
  JCheckBox anyCheckBox = new JCheckBox();
  JLabel jLabel1 = new JLabel();
  JTextField sourceAddress = new JTextField();
  JButton jButton1 = new JButton();
  JButton cancel = new JButton();
  StdACE stdACE;
  StdACL stdACL;
  boolean newElement;

  public StdAceDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public StdAceDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    jButton1.setBackground(SystemColor.inactiveCaptionText);
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("CANCEL");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    panel1.setBackground(SystemColor.inactiveCaptionText);
    denyRadio.setBackground(SystemColor.inactiveCaptionText);
    permitRadio.setBackground(SystemColor.inactiveCaptionText);
    anyCheckBox.setBackground(SystemColor.inactiveCaptionText);
    permitRadio.setText("Permit");
    denyRadio.setText("Deny");
    anyCheckBox.setText("all IP address");
    anyCheckBox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        anyCheckBox_actionPerformed(e);
      }
    });
    jLabel1.setText("source address");
    sourceAddress.setText("");
    actionGroup.add(denyRadio);
    actionGroup.add(permitRadio);
    panel1.add(anyCheckBox,       new XYConstraints(30, 70, 97, 22));
    panel1.add(jLabel1,     new XYConstraints(30, 100, 92, 31));
    panel1.add(sourceAddress,       new XYConstraints(140, 105, 146, -1));
    panel1.add(jButton1,      new XYConstraints(131, 150, -1, -1));
    panel1.add(permitRadio,  new XYConstraints(150, 20, -1, -1));
    panel1.add(cancel,    new XYConstraints(203, 150, -1, -1));
    panel1.add(denyRadio,  new XYConstraints(150, 44, 85, -1));
    this.getContentPane().add(panel1);
    this.setTitle("Standard ACL");
  }
  public void setStdAce(StdACE stdACE1,StdACL stdACL1,boolean newElement1){
    newElement = newElement1;
    stdACL = stdACL1;
    stdACE = stdACE1;
    if(stdACE.isPermit()){
      this.permitRadio.setSelected(true);
      this.denyRadio.setSelected(false);
    }else{
      this.permitRadio.setSelected(false);
      this.denyRadio.setSelected(true);
    }
    if(stdACE.isAnySource()){
      this.anyCheckBox.setSelected(true);
      this.sourceAddress.setEnabled(false);
      this.jLabel1.setEnabled(false);
    }else{
     this.sourceAddress.setText(stdACE.getSrcAddress());
    }
  }

  void cancel_actionPerformed(ActionEvent e) {
    if(newElement)
    stdACL.getAces().removeElement(stdACE);
    this.dispose();
  }

  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel_actionPerformed(null);
    }
  }
  void jButton1_actionPerformed(ActionEvent e) {
    boolean isError = false;
    stdACE.setId(stdACL.getId());
    if(this.permitRadio.isSelected())
      stdACE.setPermit(true);
    else
      stdACE.setPermit(false);
    if(this.anyCheckBox.isSelected())
      stdACE.setAnySource(true);
    else{
      if(this.chkIP(this.sourceAddress.getText()))
      stdACE.setSrcAddress(this.correctIP(this.sourceAddress.getText()));
      else{
          isError = true;
          sourceAddress.setText("");
          ErrorDialog dialog = new ErrorDialog();
          dialog.setText("Illegal source Address! Please try again");
          dialog.showDialog();
          }
   }
    if(!isError)
    this.dispose();
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(330,260);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void anyCheckBox_actionPerformed(ActionEvent e) {
    if(this.anyCheckBox.isSelected()){
      this.sourceAddress.setEnabled(false);
      this.jLabel1.setEnabled(false);
    }
    if(!this.anyCheckBox.isSelected()){
      this.sourceAddress.setEnabled(true);
      this.jLabel1.setEnabled(true);
    }

  }

  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkWildcard(String st){
    String temp = "";
    String ip = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 0)){
          temp = "";
          chk = false;
            }else if ((num == 127)||(num == 63)||(num == 31)||(num == 15)||(num == 7)||(num == 3)||(num == 1)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 255)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }



}