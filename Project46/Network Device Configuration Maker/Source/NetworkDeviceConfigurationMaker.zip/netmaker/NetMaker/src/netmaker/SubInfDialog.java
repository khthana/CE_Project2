package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SubInfDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton remove = new JButton();
  private JButton newButton = new JButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private Vector subInfName = new Vector();
  private Vector forCancel = new Vector();
  private Vector subInf = new Vector();
  private RouterEthINF inf;

  public SubInfDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SubInfDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    newButton.setBackground(SystemColor.inactiveCaptionText);
    newButton.setText("New");
    newButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        newButton_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jScrollPane1,    new XYConstraints(30, 30, 200, 120));
    panel1.add(ok,  new XYConstraints(80, 200, -1, -1));
    panel1.add(cancel,   new XYConstraints(150, 200, -1, -1));
    panel1.add(remove,    new XYConstraints(150, 160, -1, -1));
    panel1.add(newButton,   new XYConstraints(80, 160, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
  }

  public void chkInterface(RouterEthINF inf){
    this.inf = inf;
    subInf = inf.getSubInterfaces();
    this.setTitle(inf.getInterfaceName());
    for(int i=0;i<subInf.size();i++){
      forCancel.addElement(subInf.elementAt(i));
    }
    setList();
  }
  void setList(){
    subInfName.removeAllElements();
    for(int i=0;i< subInf.size();i++){
      subInfName.addElement(((SubInterface)subInf.elementAt(i)).getInterfaceName());
    }
    jList1.setListData(subInfName);
  }
  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(400,456);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
  }
  void newButton_actionPerformed(ActionEvent e) {
    String temp = inf.getInterfaceName()+".1";
    for(int i=0;i<subInf.size();i++){
      if(((SubInterface)subInf.elementAt(i)).getInterfaceName().equals(temp))
        temp = inf.getInterfaceName()+"."+String.valueOf(i+2);
    }
/*    name = "Router"+num;

    for(int i=0;i < vRouter.size(); i++){
      Router rt = (Router)vRouter.elementAt(i);
      if(rt.getHostName().equals(name))
        name = "Router"+String.valueOf(i+2);
    }
*/

    subInf.addElement(new SubInterface(temp));
    bubble(subInf);
    setList();
  }

  void remove_actionPerformed(ActionEvent e) {
    subInf.removeElementAt(jList1.getSelectedIndex());
    setList();
  }

  void cancel_actionPerformed(ActionEvent e) {
    inf.setSubInterfaces(forCancel);
    this.dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel_actionPerformed(null);
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }
  void bubble(Vector vector){
    String name1;
    String name2;
    int num1,num2;
    SubInterface temp;
    for(int i=0; i < vector.size();i++){
      for(int j=i; j < vector.size();j++){
        name1 = ((SubInterface)vector.elementAt(i)).getInterfaceName().substring
      (inf.getInterfaceName().length()+1,((SubInterface)vector.elementAt(i)).getInterfaceName().length());
        name2 = ((SubInterface)vector.elementAt(j)).getInterfaceName().substring
      (inf.getInterfaceName().length()+1,((SubInterface)vector.elementAt(j)).getInterfaceName().length());
        num1 = Integer.parseInt(name1);
        num2 = Integer.parseInt(name2);
        if(num1 > num2){
          temp = ((SubInterface)vector.elementAt(i));
          vector.insertElementAt(vector.elementAt(j),i);
          vector.removeElementAt(j+1);
          vector.removeElementAt(i+1);
          vector.addElement(temp);
        }
      }
    }
  }
}