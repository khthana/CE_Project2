package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.Vector;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DisconnectionDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton disConnect = new JButton();
  private JButton cancel = new JButton();
  private Vector list1 = new Vector();
  private Vector list2 = new Vector();
  private Vector list3 = new Vector();
  private Vector list4 = new Vector();

  public DisconnectionDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DisconnectionDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    disConnect.setBackground(SystemColor.inactiveCaptionText);
    disConnect.setText("Disconnect");
    disConnect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        disConnect_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jScrollPane1,       new XYConstraints(30, 30, 500, 150));
    jScrollPane1.getViewport().add(jList1, null);
    panel1.add(cancel,   new XYConstraints(250, 200, -1, -1));
    panel1.add(disConnect,  new XYConstraints(120, 200, -1, -1));
    setList();
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(560,300);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  void setList(){
    java.util.Vector list = new java.util.Vector();
    list1.removeAllElements();
    list2.removeAllElements();
    list3.removeAllElements();
    list4.removeAllElements();
    for(int i=0;i< Frame1.vConnection.size(); i++){
      Connection connect = (Connection)Frame1.vConnection.elementAt(i);
      for(int j=0;j<connect.getCon1InfName().size();j++){
        list.addElement(connect.getCon1DeviceID()+" at port "+connect.getCon1InfName().elementAt(j)+" connect with "
        + connect.getCon2DeviceID()+" at port "+connect.getCon2InfName().elementAt(j));
        list1.addElement(connect.getCon1DeviceID());
        list2.addElement(connect.getCon1InfName().elementAt(j));
        list3.addElement(connect.getCon2DeviceID());
        list4.addElement(connect.getCon2InfName().elementAt(j));
      }
    }
    jList1.removeAll();
    jList1.setListData(list);
    this.setTitle("Disconnection");
  }

  void disConnect_actionPerformed(ActionEvent e) {
    int k = jList1.getSelectedIndex();
      if(k >= 0)
        for(int i=0;i< Frame1.vConnection.size(); i++){
      Connection connect = (Connection)Frame1.vConnection.elementAt(i);
      {
        if(connect.getCon1DeviceID().equals(list1.elementAt(k)) && connect.getCon2DeviceID().equals(list3.elementAt(k)))
          for(int j=0;j<connect.getCon1InfName().size();j++){
        if(connect.getCon1InfName().elementAt(j).equals(list2.elementAt(k))
           && connect.getCon2InfName().elementAt(j).equals(list4.elementAt(k))){
            connect.getCon1InfName().removeElementAt(j);
            connect.getCon2InfName().removeElementAt(j);
        }
        }
      }
      if((connect.getCon1InfName().size() == 0)){
       Frame1.vConnection.removeElementAt(i);
      }
    }
    setList();
    if(k >= 0)
    this.dispose();
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }
}
