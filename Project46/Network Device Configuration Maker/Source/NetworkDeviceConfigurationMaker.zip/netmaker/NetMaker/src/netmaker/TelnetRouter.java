package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class TelnetRouter extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JTextField password = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JLabel login = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private Router rt;
  private JButton buttonACL = new JButton();

  public TelnetRouter(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public TelnetRouter() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("Password");
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    jRadioButton1.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton1.setText("Enable");
    jRadioButton2.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton2.setSelected(true);
    jRadioButton2.setText("Disable");
    login.setBackground(SystemColor.inactiveCaptionText);
    login.setOpaque(true);
    login.setText("Login");
    jLabel2.setBorder(BorderFactory.createEtchedBorder());
    buttonACL.setBackground(SystemColor.inactiveCaptionText);
    buttonACL.setText("ACL");
    buttonACL.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonACL_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jRadioButton1,  new XYConstraints(45, 45, -1, -1));
    panel1.add(jRadioButton2,     new XYConstraints(120, 45, 70, 24));
    panel1.add(password,    new XYConstraints(110, 110, 100, -1));
    panel1.add(cancel,   new XYConstraints(140, 190, -1, -1));
    panel1.add(ok,    new XYConstraints(65, 190, -1, -1));
    panel1.add(jLabel1,  new XYConstraints(24, 110, -1, -1));
    panel1.add(login, new XYConstraints(31, 23, -1, -1));
    panel1.add(jLabel2, new XYConstraints(19, 32, 191, 53));
    panel1.add(buttonACL, new XYConstraints(157, 153, -1, -1));
    buttonGroup1.add(jRadioButton2);
    buttonGroup1.add(jRadioButton1);
    this.setTitle("Telnet");
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(240,275);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  public void setRouter(Router rt1){
    rt = rt1;
    LineINF lineInf = rt.getVty();
    if(lineInf.isLogin()){
      this.jRadioButton1.setSelected(true);
      this.jRadioButton2.setSelected(false);
    }else{
      this.jRadioButton1.setSelected(false);
      this.jRadioButton2.setSelected(true);
    }
    password.setText(lineInf.getPassword());

  }

  void ok_actionPerformed(ActionEvent e) {
    LineINF lineInf = rt.getVty();
    if(this.jRadioButton1.isSelected()){
      lineInf.setLogin(true);
    }
    if(this.jRadioButton2.isSelected()){
      lineInf.setLogin(false);
    }
    lineInf.setPassword(this.password.getText());
    this.dispose();
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void buttonACL_actionPerformed(ActionEvent e) {
    AclAddRemoveDialog dialog = new AclAddRemoveDialog();
    dialog.setRouter(rt,3);
    dialog.showDialog();

  }

}