package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ConfigInfRouter extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JTextField ipAddress = new JTextField();
  private JTextField subnet = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JComboBox jComboBox1 = new JComboBox();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private RouterEthINF routerInf;
  private AccessGroup accessGroup;
  private Vector forCancel = new Vector();
  private Vector accessGroups = new Vector();
  private Vector stdACLs,listACL,extACLs,acls,list;
  private Router rt = new Router();
  private JButton jButton3 = new JButton();
  private JButton jButton4 = new JButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JRadioButton inRadio = new JRadioButton();
  private JRadioButton outRadio = new JRadioButton();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();

  public ConfigInfRouter(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ConfigInfRouter() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("IP Address");
    jLabel2.setText("Subnet");
    jButton1.setBackground(SystemColor.inactiveCaptionText);
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBackground(SystemColor.inactiveCaptionText);
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBackground(SystemColor.inactiveCaptionText);
    jButton3.setText("ADD");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jButton4.setBackground(SystemColor.inactiveCaptionText);
    jButton4.setText("Remove");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    inRadio.setBackground(SystemColor.inactiveCaptionText);
    inRadio.setSelected(true);
    inRadio.setText("in");
    outRadio.setBackground(SystemColor.inactiveCaptionText);
    outRadio.setText("out");
    jLabel3.setBorder(BorderFactory.createEtchedBorder());
    jLabel4.setBackground(SystemColor.inactiveCaptionText);
    jLabel4.setText("ACL");
    panel1.add(jLabel1,     new XYConstraints(40, 30, -1, -1));
    panel1.add(ipAddress,     new XYConstraints(150, 30, 100, -1));
    panel1.add(subnet,     new XYConstraints(150, 60, 100, -1));
    panel1.add(jScrollPane1,        new XYConstraints(40, 210, 220, 175));
    panel1.add(jLabel2, new XYConstraints(40, 60, -1, -1));
    panel1.add(jComboBox1, new XYConstraints(50, 120, 146, -1));
    panel1.add(jButton1,  new XYConstraints(120, 410, -1, -1));
    panel1.add(jButton2,  new XYConstraints(185, 410, -1, -1));
    panel1.add(jButton3, new XYConstraints(50, 160, -1, -1));
    panel1.add(jButton4, new XYConstraints(120, 160, -1, -1));
    panel1.add(inRadio, new XYConstraints(210, 120, -1, -1));
    panel1.add(outRadio, new XYConstraints(210, 150, -1, -1));
    panel1.add(jLabel3,  new XYConstraints(20, 100, 260, 297));
    panel1.add(jLabel4, new XYConstraints(40, 83, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    buttonGroup1.add(inRadio);
    buttonGroup1.add(outRadio);
    this.getContentPane().add(panel1, BorderLayout.CENTER);
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(300,490);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  public void setRouter(Router rt1,RouterEthINF rtInf){
    routerInf = rtInf;
    acls = rtInf.getAccessGroups();
    for(int i=0;i<acls.size();i++){
      forCancel.addElement(acls.elementAt(i));
    }
    rt = rt1;
    stdACLs = rt.getStdACLs();
    extACLs = rt.getExtACLs();
    this.setTitle(rtInf.getInterfaceName());
    this.ipAddress.setText(rtInf.getIpAddress());
    this.subnet.setText(rtInf.getSubnet());
    this.setList();
  }
  public void setList(){
    list = new Vector();
    listACL=new Vector();
    StdACL stdACL;
    ExtACL extACL;
    AccessGroup accessGroup ;
    for(int i=0;i<acls.size();i++){
      forCancel.addElement(acls.elementAt(i));
    }
    for(int i=0;i<acls.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      list.addElement(accessGroup.getId());
    }
    for(int i=0;i<stdACLs.size();i++){
      stdACL = (StdACL)stdACLs.elementAt(i);
      if(!this.isInThisVector(list,stdACL.getId())){
        listACL.addElement(stdACL.getId());
      }
    }
    for(int i=0;i<extACLs.size();i++){
      extACL = (ExtACL)extACLs.elementAt(i);
      if(!this.isInThisVector(list,extACL.getId())){
        listACL.addElement(extACL.getId());
      }
    }
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    for(int i=0;i<listACL.size();i++){
      list1.addElement("access-list "+listACL.elementAt(i));
    }
    for(int i=0;i<list.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      if(accessGroup.isIncoming())
      list2.addElement("access-list "+list.elementAt(i)+" in");
      else list2.addElement("access-list "+list.elementAt(i)+" out");
    }
    for(int i=0;i<list1.size();i++){
      this.jComboBox1.addItem(list1.elementAt(i));
    }
    jList1.setListData(list2);
  }
  boolean isInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return true;
    }
    return false;
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean chk = true;
    if(this.jComboBox1.getItemCount() != 0){
    list.addElement(listACL.elementAt(this.jComboBox1.getSelectedIndex()));
    if(inRadio.isSelected()) chk = true;
    if(outRadio.isSelected()) chk = false;
    acls.addElement(new AccessGroup((String)listACL.elementAt(jComboBox1.getSelectedIndex()),chk));
    listACL.removeElementAt(jComboBox1.getSelectedIndex());
    jComboBox1.removeAllItems();
    jList1.removeAll();
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    AccessGroup accessGroup ;
    for(int i=0;i<listACL.size();i++){
      list1.addElement("access-list "+listACL.elementAt(i));
    }
    for(int i=0;i<list.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      if(accessGroup.isIncoming())
      list2.addElement("access-list "+list.elementAt(i)+" in");
      else list2.addElement("access-list "+list.elementAt(i)+" out");
    }

    for(int i=0;i<list1.size();i++){
      this.jComboBox1.addItem(list1.elementAt(i));
    }
    jList1.setListData(list2);
    inRadio.setSelected(true);
    }
  }

  void jButton4_actionPerformed(ActionEvent e) {
    if(!this.jList1.isSelectionEmpty()){
    acls.removeElementAt(jList1.getSelectedIndex());
    listACL.addElement(list.elementAt(jList1.getSelectedIndex()));
    list.removeElementAt(jList1.getSelectedIndex());
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    AccessGroup accessGroup ;
    for(int i=0;i<listACL.size();i++){
      list1.addElement("access-list "+listACL.elementAt(i));
    }
    for(int i=0;i<list.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      if(accessGroup.isIncoming())
      list2.addElement("access-list "+list.elementAt(i)+" in");
      else list2.addElement("access-list "+list.elementAt(i)+" out");
    }
    jComboBox1.removeAllItems();
    for(int i=0;i<list1.size();i++){
      this.jComboBox1.addItem(list1.elementAt(i));
    }
    jList1.setListData(list2);
    inRadio.setSelected(true);
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    boolean isError = false;
    if(chkIP(ipAddress.getText())){
      isError = false;
    }else{
      isError = true;
      ipAddress.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }
    if(!isError)
      if(this.chkSubnet(subnet.getText())){
    isError = false;
      }
      else{
        isError = true;
        subnet.setText("");
        ErrorDialog dialog = new ErrorDialog();
        dialog.setText("Illegal Subnet! Please try again");
        dialog.showDialog();
      }
      if(!isError){
        if(!ipAddress.getText().equals(""))
          routerInf.setIpAddress(this.ipAddress.getText());
        if(!subnet.getText().equals(""))
        routerInf.setSubnet(this.subnet.getText());
    this.dispose();
      }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    routerInf.setAccessGroups(forCancel);
    this.dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e) ;
     if (e.getID() == WindowEvent.WINDOW_CLOSING) {
       routerInf.setAccessGroups(forCancel);
       dispose();
     }
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkSubnet(String st){
    String temp = "";
    String ip = "";
    String sub = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 255)){
          temp = "";
          chk = false;
            }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 0)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    {
      count++;
      try{
        int num = Integer.parseInt(temp);
        if (!chk)
          if((num == 255)){
        temp = "";
        chk = false;
          }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
            chk = true;
            temp = "";
          }else
            return false;
          if (chk){
            if(num != 0)
              return false;
          }
      }catch(Exception e){
        return false;
      }

      }    if((count == 4)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
  boolean chkInteger(String st){
    try{
      Integer.parseInt(st);
      return true;
    }catch (Exception e){
      return false;
    }
  }
}