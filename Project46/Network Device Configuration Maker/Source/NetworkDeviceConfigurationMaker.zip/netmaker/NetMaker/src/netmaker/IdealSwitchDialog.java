package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.Vector;
import java.awt.event.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class IdealSwitchDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton add = new JButton();
  private JButton remove = new JButton();
  private JButton select = new JButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private String series = "";
  private Vector forCancel = new Vector();

  public IdealSwitchDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public IdealSwitchDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    add.setBackground(SystemColor.inactiveCaptionText);
    add.setText("Add new Switch");
    add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        add_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    select.setBackground(SystemColor.inactiveCaptionText);
    select.setText("Select");
    select.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        select_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jScrollPane1,  new XYConstraints(45, 40, 223, 181));
    panel1.add(remove,  new XYConstraints(163, 280, -1, -1));
    panel1.add(select,   new XYConstraints(65, 280, -1, -1));
    panel1.add(add,    new XYConstraints(95, 235, -1, -1));
    panel1.add(ok,   new XYConstraints(65, 325, -1, -1));
    panel1.add(cancel,  new XYConstraints(172, 325, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    Vector list1 = new Vector();
    for(int i=0;i<Frame1.idealSwitchs.size();i++){
      list1.addElement(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getSeries());
      IdealSwitch ideal = new IdealSwitch();
      ideal.setSeries(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getSeries());
      ideal.setNFastEth(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getNFastEth());
      ideal.setNGigaEth(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getNGigaEth());
      forCancel.addElement(ideal);
    }
    this.jList1.setListData(list1);
    this.setTitle("Ideal Switch");
  }
  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(320,420);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
  }

  void add_actionPerformed(ActionEvent e) {
    NewSwitchDialog dialog = new NewSwitchDialog();
    dialog.showDialog1();
    Vector list1 = new Vector();
    for(int i=0;i<Frame1.idealSwitchs.size();i++){
      list1.addElement(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getSeries());
    }
    this.jList1.setListData(list1);
  }

  void select_actionPerformed(ActionEvent e) {
    series = (String)jList1.getSelectedValue();
    Frame1.newSwitch(series);
    this.dispose();
  }
  public String getSeries() {
    return series;
  }

  void ok_actionPerformed(ActionEvent e) {
    dispose();
  }

  void cancel_actionPerformed(ActionEvent e) {
    Frame1.idealSwitchs = forCancel;
    dispose();
  }

  void remove_actionPerformed(ActionEvent e) {
    Vector list1 = new Vector();
    for(int i=0;i<Frame1.idealSwitchs.size();i++){
      if(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getSeries().equals(jList1.getSelectedValue()))
      Frame1.idealSwitchs.remove(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))));
    }
    for(int i=0;i<Frame1.idealSwitchs.size();i++){
      list1.addElement(((IdealSwitch)(Frame1.idealSwitchs.elementAt(i))).getSeries());
    }
    this.jList1.setListData(list1);
  }
}