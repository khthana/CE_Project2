package netmaker;

import java.util.Vector;
import java.io.*;
import java.awt.*;

public class Router {
  private int id ;//primary key of device
  private String series = "";
  private int nFastEthPort=0;
  private int nGigabitEthPort=0;
  private int nSerialPort=0;
  private Vector fastEthernets = new Vector();//Vector of RouterEthINF class
  private Vector gigabitEthernets = new Vector();//Vector of RouterEthINF class
  private Vector serials = new Vector();//Vector of SerialINF class
  private String hostName = "";
  private String iosVersion = "12.1";
  private LineINF console = new LineINF();;
  private LineINF vty = new LineINF();
  private Vector stdACLs = new Vector();//Vector of StdACL class
  private Vector extACLs = new Vector();//Vector of ExtACL class
  private String defaultGateWay = "";
  private Vector connectingSwitch = new Vector();//Vector of Connection class
  private Vector connectingRouter = new Vector();//Vector of Connection class
  private Routing routing = new Routing();
  private String asNo = "";
  private String password = "";
  public Router() {
  }
  public Router(int id){
    this.setId(id);
  }
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public String getSeries() {
    return series;
  }
  public void setSeries(String series) {
    this.series = series;
    this.addPort(series);
  }
  public int getNFastEthPort() {
    return nFastEthPort;
  }
  public void setNFastEthPort(int nFastEthPort) {
    this.nFastEthPort = nFastEthPort;
  }
  public int getNGigabitEthPort() {
    return nGigabitEthPort;
  }
  public void setNGigabitEthPort(int nGigabitEthPort) {
    this.nGigabitEthPort = nGigabitEthPort;
  }
  public java.util.Vector getFastEthernets() {
    return fastEthernets;
  }
  public void setFastEthernets(java.util.Vector fastEthernets) {
    this.fastEthernets = fastEthernets;
  }
  public java.util.Vector getGigabitEthernets() {
    return gigabitEthernets;
  }
  public void setGigabitEthernets(java.util.Vector gigabitEthernets) {
    this.gigabitEthernets = gigabitEthernets;
  }
  public java.util.Vector getSerials() {
    return serials;
  }
  public void setSerials(java.util.Vector serials) {
    this.serials = serials;
  }
  public String getIosVersion() {
    return iosVersion;
  }
  public void setIosVersion(String iosVersion) {
    this.iosVersion = iosVersion;
  }
  public String getHostName() {
    return hostName;
  }
  public void setHostName(String hostName) {
    this.hostName = hostName;
  }
  public LineINF getConsole() {
    return console;
  }
  public void setConsole(LineINF console) {
    this.console = console;
  }
  public LineINF getVty() {
    return vty;
  }
  public void setVty(LineINF vty) {
    this.vty = vty;
  }
  public java.util.Vector getStdACLs() {
    return stdACLs;
  }
  public void setStdACLs(java.util.Vector stdACLs) {
    this.stdACLs = stdACLs;
  }
  public java.util.Vector getExtACLs() {
    return extACLs;
  }
  public void setExtACLs(java.util.Vector extACLs) {
    this.extACLs = extACLs;
  }
  public String getDefaultGateWay() {
    return defaultGateWay;
  }
  public void setDefaultGateWay(String defaultGateWay) {
    this.defaultGateWay = defaultGateWay;
  }
  public Vector getConnectingSwitch() {
    return connectingSwitch;
  }
  public void setConnectingSwitch(java.util.Vector connectingSwitch) {
    this.connectingSwitch = connectingSwitch;
  }
  public void addConnectingSwitch(SwitchImg simg){
    this.connectingSwitch.addElement(simg);
  }
  public void addConnectingRouter(RouterImg rimg){
    this.connectingRouter.addElement(rimg);
  }
  public void connect(String interfaceName)
  {
    RouterEthINF inf;
    for(int i=0;i<this.fastEthernets.size();i++){
      inf = (RouterEthINF)this.fastEthernets.elementAt(i);
      if(inf.getInterfaceName().equalsIgnoreCase(interfaceName)){
        inf.setConnected(true);
      }
    }
    SerialINF serialInf;
    for(int i=0;i<this.serials.size();i++){
      serialInf = (SerialINF)this.serials.elementAt(i);
      if(serialInf.getInterfaceName().equalsIgnoreCase(interfaceName)){
        serialInf.setConnected(true);
      }
    }

  }

  public Vector getConnectingRouter() {
    return connectingRouter;
  }
  public void setConnectingRouter(java.util.Vector connectingRouter) {
    this.connectingRouter = connectingRouter;
  }
  public void setRouting(Routing routing){
    this.routing = routing;
  }
  public Routing getRouting(){
    return routing;
  }
  public String getAsNo() {
    return asNo;
  }
  public void setAsNo(String asNo) {
    this.asNo = asNo;
  }
  //**********************************************************************
  public void removeConnectSwitch(int i){
    this.connectingSwitch.remove(this.connectingSwitch.elementAt(i));
  }
  public void removeConnectRouter(int i){
    this.connectingRouter.remove(this.connectingRouter.elementAt(i));
  }
  public void addPort(String series){
    if(series.equals("1760")){
      this.nFastEthPort=2;
      this.nSerialPort=1;
    }
    if(series.equals("2620")){
      this.nFastEthPort=1;
      this.nSerialPort=2;
    }
    if(series.equals("2621")){
      this.nFastEthPort=1;
      this.nSerialPort=2;
    }
    for(int i=0 ; i<Frame1.idealRouters.size();i++){
      IdealRouter idealRouter = (IdealRouter)Frame1.idealRouters.elementAt(i);
      if(series.equals(idealRouter.getSeries())){
        this.nFastEthPort = idealRouter.getNFastEth();
        this.nSerialPort = idealRouter.getNSerial();
      }
    }
    this.addElementToEthernetInterface();
  }
  void  addElementToEthernetInterface(){
    for(int i=0;i<this.nFastEthPort;i++)
      this.fastEthernets.addElement(new RouterEthINF("FastEthernet0/"+(i)));

    for(int i=0;i<this.nSerialPort;i++)
      this.serials.addElement(new SerialINF("Serial0/"+(i)));
  }
  public Vector getVectorOfPort(){
    Vector vPort = new Vector();
    RouterEthINF routerEthINF = new RouterEthINF();
    for(int i=0;i<this.fastEthernets.size();i++){
      routerEthINF = (RouterEthINF)this.fastEthernets.elementAt(i);
      vPort.addElement(routerEthINF.getInterfaceName());
    }
    SerialINF serialINF = new SerialINF();
    for(int i=0;i<this.serials.size();i++){
      serialINF = (SerialINF)this.serials.elementAt(i);
      vPort.addElement(serialINF.getInterfaceName());
    }
    return vPort;
  }

  void addElementEthInf(){
    for(int i=0;i<this.nFastEthPort;i++)
      this.fastEthernets.addElement(new RouterEthINF("FastEthernet0/"+(i+1)));
    for(int i=0;i<this.nSerialPort;i++)
      this.serials.addElement(new SerialINF("Serial0/"+(i+1)));

  }
  public void genConfigFile(){
    FileDialog fileDialog = new FileDialog(new Frame(), "Save As",
                                           FileDialog.SAVE);
    fileDialog.setDirectory(".");
    fileDialog.setVisible(true);
    File file = new File(fileDialog.getDirectory(),
                         fileDialog.getFile() + ".text");
    try {
      FileWriter fileWriter = new FileWriter(file);
      BufferedWriter bwriter = new BufferedWriter(fileWriter);
      PrintWriter pwriter = new PrintWriter(bwriter);
      pwriter.print("");
      pwriter.print(this.genVersion());
      pwriter.print(this.genService());
      pwriter.print(this.genHostname());
      pwriter.print(this.genIpSubnet());
      pwriter.print(this.genEthernetInterfaces());
      pwriter.print(this.genSerialInterfaces());
      pwriter.print(this.genBRIInterfaces());
      pwriter.print(this.genRoutings());
      pwriter.print(this.genDetailStdACLs());
      pwriter.print(this.genDetailExtACLs());
      pwriter.print(this.genIpHttpServer());
      pwriter.print(this.genIpDefaultGateWay());
      pwriter.print(this.genLineCon());
      pwriter.print(this.genLineAux());
      pwriter.print(this.genLineVty());
      pwriter.print(this.genTailer());
      pwriter.close();

    }
    catch (IOException io) {
      System.out.println("IOException at generateSwitchConfig");
    }
   }
   ///////////////////////////////////////////////////////////////////////////////////
   //********************sub function for generate config-file************************

   public String genVersion(){
     String strVersion ="";
     strVersion += "version " + this.iosVersion + "\n";
     return strVersion;
   }

   //***Default Generate
   public String genService(){
     String strService = "";
     strService += "service timestamps debug datetime msec\n";
     strService += "service timestamps log datetime msec\n";
     strService += "no service password-encryption\n!\n";
     return strService;
   }
  //***End Default Generate
   public String genHostname(){
     String strHostname = "";
     if (!strHostname.equals(""))
       strHostname += "hostname " + this.hostName + "\n!\n";
     return strHostname;
   }

   public String genIpSubnet(){
     String strIpSubnet = "ip subnet-zero\n!\n";
     return strIpSubnet;
   }

   //////////////////////////////////////////////
   //***start Generate FastEthernet Interfaces***
   public String genEthernetInterfaces(){
    String strEthInfs = "";
    for (int i=0;i<this.fastEthernets.size();i++){
      //gen information in each FastEthernet Interface
      strEthInfs += this.genEthernetInterface((RouterEthINF)this.fastEthernets.elementAt(i));
    }
    return strEthInfs;
   }

   //***Generate FastEthernet Interface Detail
   public String genEthernetInterface(RouterEthINF eth){
     String strEthInf = "";
     strEthInf += "interface " + eth.getInterfaceName() + "\n";
     //***gen ip address
     if (eth.getIpAddress().equals(""))
       strEthInf += " no ip address\n";
     else
       strEthInf += " ip address " + eth.getIpAddress() + " " + eth.getSubnet() + "\n";
     //***gen ip access-group
     strEthInf += this.genIpAccessGroup(eth.getAccessGroups());
     if (eth.isShutdown())
       strEthInf += " shutdown\n";
     strEthInf += " speed auto\n!\n";
     //***gen SubInterface
     strEthInf += this.genSubInterfaces(eth.getSubInterfaces());
     return strEthInf;
   }
   //***end Generate FastEthernet Interfaces***
   ////////////////////////////////////////////



   ///////////////////////////////
   //***start gen subIntrefaces***
   private String genSubInterfaces(Vector subInterfaces){
     String strSubInfs = "";
     SubInterface subInf;
     for (int i = 0; i < subInterfaces.size(); i++) {
       subInf = (SubInterface) subInterfaces.elementAt(i);
       strSubInfs += this.genSubInterface(subInf);
     }
     return strSubInfs;
   }
   private String genSubInterface(SubInterface subInf){
     String strSubInf = "";
     strSubInf += "interface " + subInf.getInterfaceName() + "\n";
     //***gen protocol encapsulation
     if (!subInf.getProtocolEncap().equals("")) {
       if (subInf.isDot1Q())
         strSubInf += "encapsulation dot1Q " + subInf.getVlan() + "\n";
         // else if ISL not finish
     }
     //***gen ip address
     if (subInf.getIpAddress().equals(""))
       strSubInf += " no ip address\n";
     else
       strSubInf += " ip address " + subInf.getIpAddress() + " " + subInf.getSubnet() + "\n";
     //***gen ip access group
     strSubInf += this.genIpAccessGroup(subInf.getAccessGroups());
     //***gen status
     if (subInf.isShutdown())
       strSubInf += " shutdown\n";
     strSubInf += "!\n";
     return strSubInf;
   }
   //***end gen SubInterfaces***
   ////////////////////////////


   //***Generate AccessGroup in each Interface
   private String genIpAccessGroup(Vector accessGroups){
     String strAccessGroup = "";
     AccessGroup group;
     for (int i = 0; i < accessGroups.size(); i++) {
       group = (AccessGroup) accessGroups.elementAt(i);
       if (group.isIncoming()) {
         strAccessGroup += " ip access-group " + group.getId() + " " + "in\n";
       }
       else
         strAccessGroup += " ip access-group " + group.getId() + " " + "out\n";
     }
     return strAccessGroup;
   }


   ////////////////////////////////////////
   //***start Generate Serial Interfaces***
   public String genSerialInterfaces(){
     String strSerialInfs = "";
     for (int i=0;i<this.serials.size();i++){
       strSerialInfs += this.genSerialInterface((SerialINF)this.serials.elementAt(i));
     }
     return strSerialInfs;
   }
   //***Generate Serial Interface Detail
   public String genSerialInterface(SerialINF sInf){
     String strSerialInf = "";
     strSerialInf += "interface " + sInf.getInterfaceName() + "\n";
     //***gen ip address
     if (sInf.getIpAddress().equals(""))
       strSerialInf += " no ip address\n";
     else
       strSerialInf += " ip address " + sInf.getIpAddress() + " " + sInf.getSubnet() + "\n";
     //***gen status
     if (sInf.isShutdown())
       strSerialInf += " shutdown\n";
     //***gen clockrate
     if (!sInf.getClockRate().equals(""))
       strSerialInf += " clockrate " + sInf.getClockRate() + "\n!\n";
     //***gen ip access-group
     strSerialInf += this.genIpAccessGroup(sInf.getAccessGroups());
     return strSerialInf + "!\n";
   }
  //***end Generate Serial Interfaces***
   ////////////////////////////////////////


   public String genBRIInterfaces(){
     String strBRIInfs = "interface BRI1/0\n no ip address\n shutdown\n!\n";
     return strBRIInfs;
   }

   ///////////////////////////////////////
   //***start Generate Routing Protocol***
   public String genRoutings() {
      String strRoutings = "";
      strRoutings += this.genDynamicRouting();
      strRoutings += this.genDefaultRouting();
      strRoutings += this.genStaticRouting();
      return strRoutings;
   }
   public String genStaticRouting(){
     String strStatic = "";
     StaticRoute staticRoute;
     int nNetwork = this.routing.getStaticRoutes().size();
     for (int i=0;i<nNetwork;i++){
       staticRoute = (StaticRoute)this.routing.getStaticRoutes().elementAt(i);
       //ip route 161.246.5.0 255.255.255.0 161.246.4.3
       strStatic += "ip route " + (String)staticRoute.getNetwork() + " ";
       strStatic += (String)staticRoute.getSubnet() + " ";
       strStatic += (String)staticRoute.getRoute() + "\n";
     }
     strStatic += "!\n";
     return strStatic;
   }
   public String genDynamicRouting(){
     String strDynamic = "";
     DynamicRoute dynmcRoute = this.routing.getDynamicRoutes();
     strDynamic += this.genRipRouting(dynmcRoute.getRip());
     strDynamic += this.genIgrpRouting(dynmcRoute.getIgrp());
     return strDynamic;
   }
   public String genRipRouting(Vector rips){
     String strRip = "";
     if(rips.size() != 0){
       strRip += "router rip\n";
       for (int i = 0; i < rips.size(); i++) {
         strRip += " network " + rips.elementAt(i) + "\n";
       }
     }
     return strRip;
   }
   public String genIgrpRouting(Vector igrps){
     String strIgrp = "";
     if (igrps.size() !=0){
       strIgrp += "router igrp " + this.asNo +"\n";
       for (int i = 0; i < igrps.size(); i++) {
         strIgrp += " network " + igrps.elementAt(i) + "\n";
       }
       strIgrp += "!\n";
     }
     return strIgrp ;
   }
   public String genDefaultRouting(){
     String strDefault = "";
     strDefault += this.genIPClassless();
     for (int i=0;i<this.routing.getDefaultRoutes().size();i++){
       strDefault += "ip route 0.0.0.0 0.0.0.0 " + ((DefaultRoute)this.routing.getDefaultRoutes().elementAt(i)).getRoute() + "\n";
     }
     return strDefault;
   }
   //***End Generate Routing Protocol***
   //////////////////////////////////////


   //***Show ACLs
   public String genDetailStdACLs() {
     String strStdACLs = "";
     StdACL acl;
     int nACL = this.stdACLs.size();
     if (nACL !=0){
       for (int i=0;i<nACL;i++){
         acl = (StdACL)this.stdACLs.elementAt(i);
         strStdACLs += this.genDetailStdACEs(acl);
       }
     }
     return strStdACLs;
   }
   private String genDetailStdACEs(StdACL acl) {
     String strACEs = "";
     StdACE ace;
     int nACE = acl.getAces().size();
     if (nACE!=0){
       for (int i=0;i<nACE;i++){
         ace = (StdACE)acl.getAces().elementAt(i);
         strACEs += ace.getStringACE() + "\n";
       }
     }
     return strACEs;
   }
   public String genDetailExtACLs() {
     String strExtACLs = "";
     ExtACL acl;
     int nList = this.extACLs.size();
     if (nList !=0){
       for (int i=0;i<nList;i++){
         acl = (ExtACL)this.extACLs.elementAt(i);
         strExtACLs += this.genDetailExtACEs(acl);
       }
     }
     return strExtACLs;
   }
   private String genDetailExtACEs(ExtACL acl) {
     String strACEs = "";
     ExtACE ace;
     int nACE = acl.getAces().size();
     if (nACE!=0){
       for (int i=0;i<nACE;i++){
         ace = (ExtACE)acl.getAces().elementAt(i);
         strACEs += ace.getStringACE() + "\n";
       }
     }
     return strACEs;
   }
   //***End Show ACLs

   //***Default Generate in program
   public String genIPClassless() {
     String strIpClassless = "!\nip classless\n";
     return strIpClassless;
   }
   public String genIpHttpServer() {
     String strIpHttp = "no ip http server\n";
     return strIpHttp;
   }
   //***End Default Generate in program

   public String genIpDefaultGateWay() {
     String strGateWay = "";
     if(!this.defaultGateWay.equals(""))
       strGateWay += "ip default-gateway " + this.defaultGateWay + "\n";
     strGateWay += "!\n";
     return strGateWay;
   }
   //***Generate Detail in eace LineINF
   public String genLineCon() {
     String strLineCon = "line con 0\n";
     strLineCon += this.genAccessClass(this.console.getAccessGroups());
     if (this.console.isLogin()){
       if (!(this.console.getPassword().equals(""))){
         strLineCon += " password " + this.console.getPassword() + "\n";
         strLineCon += " login\n";
       }
     }
     return strLineCon;
   }
   public String genLineAux() {
     String strLineAux = "line aux 0\n";
     return strLineAux;
   }
   public String genLineVty() {
     String strLineVty = "line vty 0 4\n";
     strLineVty += this.genAccessClass(this.vty.getAccessGroups());
     if (this.vty.isLogin()){
       if (! (this.vty.getPassword().equals(""))) {
         strLineVty += " password " + this.vty.getPassword() + "\n";
         strLineVty += " login\n";
       }
     }
     return strLineVty;
   }
   private String genAccessClass(Vector accessGroups){
     String strAccessGroup = "";
     AccessGroup accessGroup;
     if (accessGroups.size() != 0){
       for (int i=0;i<accessGroups.size();i++){
         accessGroup = (AccessGroup)accessGroups.elementAt(i);
         if (accessGroup.isIncoming()){
           strAccessGroup += "access-class " + accessGroup.getId() + " in\n";
         }
         else{
           strAccessGroup += "access-class " + accessGroup.getId() + " out\n";
         }
       }
     }
     return strAccessGroup;
   }
   //***End Generate Detail in eace LineINF

   //***Default Generate in program
   public String genTailer() {
     String strTailer = "!\nno scheduler allocate\n";
     strTailer += "end\n";
     return strTailer;
   }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
   //***End Default Generate in program
}