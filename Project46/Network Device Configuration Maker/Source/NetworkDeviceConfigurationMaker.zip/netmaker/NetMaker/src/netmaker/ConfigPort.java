package netmaker;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ConfigPort extends JDialog {
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JRadioButton access = new JRadioButton();
  private JRadioButton trunk = new JRadioButton();
  private JComboBox accessComboBox = new JComboBox();
  private JLabel jLabel2 = new JLabel();
  private JButton add = new JButton();
  private JButton remove = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JList jList1 = new JList();
  private JList jList2 = new JList();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private JTextField ipAddress = new JTextField();
  private JTextField subnet = new JTextField();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private ButtonGroup a = new ButtonGroup();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private JComboBox channelGroup = new JComboBox();
  private JLabel jLabel10 = new JLabel();
  private JLabel jLabel11 = new JLabel();
  private JTextField prio = new JTextField();
  private JLabel jLabel12 = new JLabel();
  private JLabel jLabel13 = new JLabel();
  private JTextField cost = new JTextField();
  private JButton prop = new JButton();
  private Vector list1 = new Vector();//list of vlan in jList1
  private Vector list2 = new Vector();//list of vlan in jList2
  private Vector list1VlanSTP = new Vector();//list fo VlanSTP of trunk(not selected)
  private Vector list2VlanSTP = new Vector();//list fo VlanSTP of trunk(selected)

  private Switch sw = new Switch();
  private SwitchEthINF in = new SwitchEthINF();
  private TitledBorder titledBorder1;

  public ConfigPort(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ConfigPort() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    jLabel1.setBackground(Color.white);
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    this.getContentPane().setBackground(UIManager.getColor("InternalFrame.inactiveTitleForeground"));
    this.getContentPane().setLayout(xYLayout1);
    access.setBackground(SystemColor.inactiveCaptionText);
    access.setText("Access");
    access.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        access_actionPerformed(e);
      }
    });
    trunk.setBackground(SystemColor.inactiveCaptionText);
    trunk.setBorder(null);
    trunk.setText("Trunk");
    trunk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        trunk_actionPerformed(e);
      }
    });
    jLabel2.setBorder(BorderFactory.createEtchedBorder());
    add.setBackground(SystemColor.inactiveCaptionText);
    add.setMargin(new Insets(0, 0, 0, 0));
    add.setText("ADD>>");
    add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        add_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setMargin(new Insets(0, 0, 0, 0));
    remove.setText("Remove<<");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    jScrollPane1.getViewport().setBackground(Color.white);
    jScrollPane2.getViewport().setBackground(Color.white);
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Interface Address");
    jLabel4.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setText("IP Address");
    jLabel6.setText("Subnet");
    xYLayout1.setWidth(400);
    xYLayout1.setHeight(486);
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    jLabel7.setBorder(BorderFactory.createEtchedBorder());
    jLabel8.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel8.setText("EtherChannel");
    jLabel9.setText("Channel Group");
    jLabel10.setBorder(BorderFactory.createEtchedBorder());
    jLabel11.setText("VLAN");
    jLabel12.setBackground(SystemColor.inactiveCaptionText);
    jLabel12.setText("Priority");
    jLabel13.setText("Cost");
    prop.setBackground(SystemColor.inactiveCaptionText);
    prop.setAlignmentY((float) 0.0);
    prop.setMargin(new Insets(2, 2, 2, 2));
    prop.setText("Proprety");
    prop.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        prop_actionPerformed(e);
      }
    });
    this.getContentPane().add(trunk,       new XYConstraints(80, 111, -1, 22));
    this.getContentPane().add(access,        new XYConstraints(80, 19, -1, 17));
    this.getContentPane().add(add,          new XYConstraints(163, 140, 72, -1));
    this.getContentPane().add(jLabel2,             new XYConstraints(55, 122, 290, 129));
    this.getContentPane().add(remove,           new XYConstraints(163, 175, 74, -1));
    this.getContentPane().add(jLabel1,     new XYConstraints(50, 15, 300, 241));
    this.getContentPane().add(jScrollPane1,           new XYConstraints(60, 135, 100, 104));
    jScrollPane1.getViewport().add(jList1, null);
    this.getContentPane().add(jScrollPane2,                   new XYConstraints(240, 135, 100, 104));
    this.getContentPane().add(jLabel3,          new XYConstraints(60, 250, -1, 34));
    this.getContentPane().add(jLabel5,     new XYConstraints(60, 290, 100, -1));
    this.getContentPane().add(jLabel4,      new XYConstraints(49, 280, 306, 82));
    this.getContentPane().add(jLabel6,     new XYConstraints(60, 330, 45, -1));
    this.getContentPane().add(ipAddress,   new XYConstraints(157, 290, 161, 25));
    this.getContentPane().add(subnet,       new XYConstraints(157, 325, 161, 27));
    this.getContentPane().add(ok,     new XYConstraints(300, 450, -1, -1));
    this.getContentPane().add(cancel,     new XYConstraints(200, 450, -1, -1));
    this.getContentPane().add(jLabel7, new XYConstraints(48, 394, 308, 48));
    this.getContentPane().add(jLabel8,  new XYConstraints(60, 375, -1, -1));
    this.getContentPane().add(jLabel9,      new XYConstraints(58, 409, 92, 23));
    this.getContentPane().add(channelGroup,         new XYConstraints(167, 408, 169, 23));
    this.getContentPane().add(jLabel10,     new XYConstraints(54, 26, 290, 86));
    this.getContentPane().add(accessComboBox,     new XYConstraints(150, 40, 161, 23));
    this.getContentPane().add(jLabel11, new XYConstraints(75, 43, -1, -1));
    this.getContentPane().add(prio,    new XYConstraints(120, 80, 50, -1));
    this.getContentPane().add(jLabel12,     new XYConstraints(75, 80, -1, -1));
    this.getContentPane().add(jLabel13,       new XYConstraints(210, 80, -1, -1));
    this.getContentPane().add(cost,     new XYConstraints(255, 80, 50, -1));
    this.getContentPane().add(prop,                       new XYConstraints(162, 210, 75, 25));
    this.channelGroup.addItem("no group channel");
    jScrollPane2.getViewport().add(jList2, null);
    a.add(access);
    a.add(trunk);
  }
  //////////////////////////////////////////////////////
  public void config(SwitchEthINF in1,Switch sw1)
  {
    sw=sw1;
    in=in1;
    String inChannel = in.getPortChannelID();
    Vector portChannels = sw.getPortChannels();
    String inIP = in.getIpAddress();
    String inMode = in.getMode();
    String inName = in.getInterfaceName();
    boolean inConnected = in.isConnected();
    Vector inVlan = in.getVlanSTPs();
    Vector swVlan = sw.getVectorVlanID();
    Vector vlans = new Vector();
    Vector groupPorts = new Vector();
    VlanSTP vlanSTP ;
    for(int i=0;i<inVlan.size();i++){
      vlanSTP = (VlanSTP)inVlan.elementAt(i);
      vlans.addElement(vlanSTP.getVlanID());
    }

    this.setTitle(inName);

    for(int i=0; i<swVlan.size(); i++){
      this.accessComboBox.addItem(swVlan.elementAt(i));
    }

    if(inMode.equals("access")){
      access.setSelected(true);
      add.setEnabled(false);
      remove.setEnabled(false);
      prop.setEnabled(false);
      jList1.setEnabled(false);
      jList2.setEnabled(false);
      vlanSTP = (VlanSTP)inVlan.elementAt(0);
      cost.setText(vlanSTP.getCost());
      prio.setText(vlanSTP.getPriority());
      this.accessComboBox.setSelectedItem(vlanSTP.getVlanID());
    }
    if(inMode.equals("trunk")){
      trunk.setSelected(true);
      cost.setEnabled(false);
      prio.setEnabled(false);
      accessComboBox.setEnabled(false);
      for(int i=0;i<swVlan.size();i++){
        if(!this.isInThisVector(vlans,swVlan.elementAt(i))){
          if(!this.isInThisVector(list1,swVlan.elementAt(i)))
            list1.addElement(swVlan.elementAt(i));
        }
      }
      jList1.setListData(list1);

      for(int i=0;i<swVlan.size();i++){
        if(this.isInThisVector(vlans,swVlan.elementAt(i))){
          if(!this.isInThisVector(list2,swVlan.elementAt(i)))
            list2.addElement(swVlan.elementAt(i));
        }
      }
      jList2.setListData(list2);

      for(int i=0;i<list2.size();i++){
        vlanSTP = (VlanSTP)inVlan.elementAt(i);
        VlanSTP vlanTemp = new VlanSTP(vlanSTP.getVlanID(),
                                       vlanSTP.getCost(),
                                       vlanSTP.getPriority());
        this.list2VlanSTP.addElement(vlanTemp);
      }
      for(int i=0;i<list1.size();i++){
        this.list1VlanSTP.addElement(new VlanSTP((String)list1.elementAt(i)));
      }

    }
    for(int i=0;i<portChannels.size();i++){
      PortChannelINF port = (PortChannelINF)portChannels.elementAt(i);
      channelGroup.addItem("Group"+port.getId());
    }
    if(!(inChannel.equals("")))
      this.channelGroup.setSelectedItem("Group"+inChannel);
    this.ipAddress.setText(in.getIpAddress());
    this.subnet.setText(in.getSubnet());
  }
  ///////////////////////////////////////////////////////////////////
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(400,550);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void trunk_actionPerformed(ActionEvent e) {
    Vector inVlan = in.getVlanSTPs();
    Vector swVlan = sw.getVectorVlanID();
    Vector swVlans = sw.getVlans();
    Vector vlans = new Vector();
    VlanSTP vlanSTP ;
    for(int i=0;i<inVlan.size();i++){
      vlanSTP = (VlanSTP)inVlan.elementAt(i);
      vlans.addElement(vlanSTP.getVlanID());
    }

    add.setEnabled(true);
    remove.setEnabled(true);
    this.jList1.setEnabled(true);
    this.jList2.setEnabled(true);
    this.accessComboBox.setEnabled(false);
    prio.setEnabled(false);
    cost.setEnabled(false);
    this.jLabel11.setEnabled(false);
    this.jLabel12.setEnabled(false);
    this.jLabel13.setEnabled(false);
    prop.setEnabled(true);

    for(int i=0;i<swVlan.size();i++){
      if(!this.isInThisVector(vlans,swVlan.elementAt(i))){
        if(!this.isInThisVector(list1,swVlan.elementAt(i)))
          list1.addElement(swVlan.elementAt(i));
      }
    }
    jList1.setListData(list1);

    for(int i=0;i<swVlan.size();i++){
      if(this.isInThisVector(vlans,swVlan.elementAt(i))){
        if(!this.isInThisVector(list2,swVlan.elementAt(i)))
          list2.addElement(swVlan.elementAt(i));
      }
    }
    jList2.setListData(list2);

    for(int i=0;i<list2.size();i++){
      vlanSTP = (VlanSTP)inVlan.elementAt(i);
      VlanSTP vlanTemp = new VlanSTP(vlanSTP.getVlanID(),
                                     vlanSTP.getCost(),
                                     vlanSTP.getPriority());
      this.list2VlanSTP.addElement(vlanTemp);
    }
    for(int i=0;i<list1.size();i++){
      this.list1VlanSTP.addElement(new VlanSTP((String)list1.elementAt(i)));
    }
  }

  void add_actionPerformed(ActionEvent e) {
    Vector inVlan = new Vector();
    Vector swVlan = sw.getVectorVlanID();
    VlanSTP vlanSTP;
    String temp = (String)jList1.getSelectedValue();
    if(!(temp == null)){
      list2.addElement(temp);
      list1.removeElement(temp);
      jList1.setListData(list1);
      jList2.setListData(list2);
    }
    for(int i=0;i<list1VlanSTP.size();i++){
      vlanSTP = (VlanSTP)list1VlanSTP.elementAt(i);
      if(vlanSTP.getVlanID().equals(temp)){
        list2VlanSTP.addElement(vlanSTP);
        list1VlanSTP.remove(i);
      }
    }
  }

  void remove_actionPerformed(ActionEvent e) {
    Vector inVlan = in.getVlanSTPs();
    Vector swVlan = sw.getVectorVlanID();
    VlanSTP vlanSTP;
    String temp = (String)jList2.getSelectedValue();
    int k=list2.size();
    if(k>1)
    {
      list1.addElement(temp);
      list2.removeElement(temp);
      jList1.setListData(list1);
      jList2.setListData(list2);
    }
    for(int i=0;i<list2VlanSTP.size();i++){
      vlanSTP = (VlanSTP)list2VlanSTP.elementAt(i);
      if(vlanSTP.getVlanID().equals(temp)){
        list1VlanSTP.addElement(vlanSTP);
        list2VlanSTP.remove(i);
      }
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    boolean isError = false;
    String inChannel = in.getPortChannelID();
    String inIP = in.getIpAddress();
    String inMode = in.getMode();
    String inName = in.getInterfaceName();
    boolean inConnected = in.isConnected();
    Vector inVlan = in.getVlanSTPs();
    Vector swVlan = sw.getVectorVlanID();
    if(chkIP(ipAddress.getText()) || ipAddress.getText().equals("")){
      isError = false;
    }else{
      isError = true;
      ipAddress.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }
    if(!isError)
      if(this.chkSubnet(subnet.getText()) || subnet.getText().equals("")){
    isError = false;
      }
      else{
        isError = true;
        subnet.setText("");
        ErrorDialog dialog = new ErrorDialog();
        dialog.setText("Illegal Subnet! Please try again");
        dialog.showDialog();
      }
      if(!isError){
        String temp = this.cost.getText();
        if(this.chkInteger(temp)){
          int cost = Integer.parseInt(temp);
          if(!(cost < 1 || cost > 65535)){
            isError = false;
          }
          else{
            isError = true;
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("cost must between 1 and 65535! Please try again");
            dialog.showDialog();
          }
        }    else if(!temp.equals("")){
          isError = true;
          ErrorDialog dialog = new ErrorDialog();
          dialog.setText("cost must between 1 and 65535! Please try again");
          dialog.showDialog();
        }

      }
      if(!isError){
        String temp = this.prio.getText();
        if(this.chkInteger(temp)){
          int prio = Integer.parseInt(temp);
          if(!(prio < 0 || prio > 255)){
            isError = false;
          }
          else{
            isError = true;
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("priority must between 0 and 255! Please try again");
            dialog.showDialog();
          }
        }    else if(!temp.equals("")){
          isError = true;
          ErrorDialog dialog = new ErrorDialog();
          dialog.setText("priority must between 0 and 255! Please try again");
          dialog.showDialog();
        }

      }
      if(!isError){
        if(!this.ipAddress.getText().equals(""))
        in.setIpAddress(correctIP(ipAddress.getText()));
        if(!this.subnet.getText().equals(""))
        in.setSubnet(this.correctIP(this.subnet.getText()));
        in.setPortChannelID((String)this.channelGroup.getSelectedItem());
        if(trunk.isSelected()){
          in.removeAllVlan();
          for(int i=0;i<this.list2VlanSTP.size();i++){
            in.addVlan((VlanSTP)this.list2VlanSTP.elementAt(i));
            in.setMode("trunk");
          }
        }
        if(access.isSelected()){
          in.removeAllVlan();
          VlanSTP vlanSTP = new VlanSTP((String)this.accessComboBox.getSelectedItem(),cost.getText(),prio.getText());
          in.addVlan(vlanSTP);
          in.setMode("access");
        }
        String groupID="";
        if(this.channelGroup.getSelectedItem().equals("Group1")){
          groupID = "1";
        }
        if(this.channelGroup.getSelectedItem().equals("Group2")){
          groupID = "2";
        }
        if(this.channelGroup.getSelectedItem().equals("Group3")){
          groupID = "3";
        }
        if(this.channelGroup.getSelectedItem().equals("Group4")){
          groupID = "4";
        }
        if(this.channelGroup.getSelectedItem().equals("Group5")){
          groupID = "5";
        }
        if(this.channelGroup.getSelectedItem().equals("Group6")){
          groupID = "6";
        }
        if(this.channelGroup.getSelectedItem().equals("Group7")){
          groupID = "7";
        }
        if(this.channelGroup.getSelectedItem().equals("Group8")){
          groupID = "8";
        }
        in.setPortChannelID(groupID);
        this.dispose();
      }
  }
  public SwitchEthINF getInterface()
  {
    return in;
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void access_actionPerformed(ActionEvent e) {
    add.setEnabled(false);
    remove.setEnabled(false);
    this.jList1.setEnabled(false);
    this.jList2.setEnabled(false);
    this.accessComboBox.setEnabled(true);
    prio.setEnabled(true);
    cost.setEnabled(true);
    this.jLabel11.setEnabled(true);
    this.jLabel12.setEnabled(true);
    this.jLabel13.setEnabled(true);
    this.prop.setEnabled(false);

  }

  void prop_actionPerformed(ActionEvent e){
    String temp = (String)this.jList2.getSelectedValue();
    VlanSTP vlanSTP;
    if(temp != null)
      for(int i=0;i<list2VlanSTP.size();i++){
    vlanSTP = (VlanSTP)list2VlanSTP.elementAt(i);
    if(vlanSTP.getVlanID().equals(temp)){
      PropVlan propVlan = new PropVlan();
      propVlan.setVlan(vlanSTP);
      propVlan.showDialog();
    }
      }
  }
  int rankInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return i;
    }
    return -1;
  }
  boolean isInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return true;
    }
    return false;
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkSubnet(String st){
    String temp = "";
    String ip = "";
    String sub = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 255)){
          temp = "";
          chk = false;
            }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 0)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    {
      count++;
      try{
        int num = Integer.parseInt(temp);
        if (!chk)
          if((num == 255)){
        temp = "";
        chk = false;
          }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
            chk = true;
            temp = "";
          }else
            return false;
          if (chk){
            if(num != 0)
              return false;
          }
      }catch(Exception e){
        return false;
      }

      }    if((count == 4)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
  boolean chkInteger(String st){
    try{
      Integer.parseInt(st);
      return true;
    }catch (Exception e){
      return false;
    }
  }

  void jList1_mouseClicked(MouseEvent e) {
    jList2.setSelectedIndex(-1);
  }

  void jList2_mouseClicked(MouseEvent e) {
    jList1.setSelectedIndex(-1);
  }

  void jList1_mousePressed(MouseEvent e) {
    jList2.setSelectedIndex(-1);

  }

  void jList2_mousePressed(MouseEvent e) {
    jList1.setSelectedIndex(-1);

  }

}

































