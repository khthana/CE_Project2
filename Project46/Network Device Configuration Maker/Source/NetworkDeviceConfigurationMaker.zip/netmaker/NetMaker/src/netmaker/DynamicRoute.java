package netmaker;

import java.util.Vector;

public class DynamicRoute {
  private Vector rip = new Vector();//Vector of String networks RIP Route
  private Vector igrp = new Vector();//Vector of String networks IGRP Route
  public DynamicRoute() {
  }
  public Vector getRip() {
    return rip;
  }
  public void setRip(Vector rip) {
    this.rip = rip;
  }
  public Vector getIgrp() {
    return igrp;
  }
  public void setIgrp(Vector igrp) {
    this.igrp = igrp;
  }
  //*************************************************
  public boolean addRIP(String network){
    for (int i=0;i<this.rip.size();i++){
      if (this.rip.elementAt(i).equals(network)){
        return false;
      }
    }
    this.rip.addElement(network);
    return true;
  }
  public boolean removeRIP(String network){
    for (int i=0;i<this.rip.size();i++){
      if (this.rip.elementAt(i).equals(network)){
        this.rip.removeElementAt(i);
        return true;
      }
    }
    return false;
  }
  public boolean addIGRP(String network){
    for (int i=0;i<this.igrp.size();i++){
      if (this.igrp.elementAt(i).equals(network)){
        return false;
      }
    }
    this.igrp.addElement(network);
    return true;
  }
  public boolean removeIGRP(String network){
    for (int i=0;i<this.igrp.size();i++){
      if (this.igrp.elementAt(i).equals(network)){
        this.igrp.removeElementAt(i);
        return true;
      }
    }
    return false;
  }
}