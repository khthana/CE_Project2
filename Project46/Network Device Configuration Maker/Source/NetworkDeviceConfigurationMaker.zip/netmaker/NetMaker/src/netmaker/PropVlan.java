package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class PropVlan extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private SwitchEthINF in = new SwitchEthINF();
  private String no = "";
//  private VlanOfPort vlanPort = new VlanOfPort();
  private VlanSTP vlanSTP = new VlanSTP();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();

  public PropVlan(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropVlan() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    this.getContentPane().setBackground(UIManager.getColor("InternalFrame.inactiveTitleForeground"));
    jLabel1.setText("Priority");
    jLabel2.setText("Cost");
    this.getContentPane().add(panel1, BorderLayout.CENTER);
    panel1.add(jTextField1,  new XYConstraints(120, 30, 50, -1));
    panel1.add(jTextField2,  new XYConstraints(120, 60, 50, -1));
    panel1.add(ok,   new XYConstraints(36, 113, -1, -1));
    panel1.add(cancel,    new XYConstraints(105, 112, -1, -1));
    panel1.add(jLabel2,    new XYConstraints(33, 64, -1, -1));
    panel1.add(jLabel1, new XYConstraints(32, 31, -1, -1));
  }
  public void setVlan(VlanSTP vlanSTP1){
    vlanSTP = vlanSTP1;
    no = vlanSTP1.getVlanID();
    this.jTextField1.setText(vlanSTP1.getPriority());
    this.jTextField2.setText(vlanSTP1.getCost());
    this.setTitle("VLAN "+no);
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(200,200);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  public VlanSTP getVlanSTP(){ return vlanSTP;}
  void jButton2_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void ok_actionPerformed(ActionEvent e) {
    vlanSTP.setVlanID(no);
    vlanSTP.setPriority(jTextField1.getText());
    vlanSTP.setCost(jTextField2.getText());
   this.dispose();

  }
}