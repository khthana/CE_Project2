package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class RoutingProtocolDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JComboBox jComboBox1 = new JComboBox();
  private JButton add = new JButton();
  private JButton remove = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JList jList1 = new JList();
  private JButton edit = new JButton();
  private Router rt;
  private Vector list1;
  private Vector defaultRoutes,staticRoutes,rips,igrps;
  private Routing tempForCancel = new Routing();

  public RoutingProtocolDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public RoutingProtocolDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    add.setBackground(SystemColor.inactiveCaptionText);
    add.setToolTipText("");
    add.setText("ADD");
    add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        add_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setMargin(new Insets(2, 7, 2, 7));
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setMargin(new Insets(2, 5, 2, 5));
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    edit.setBackground(SystemColor.inactiveCaptionText);
    edit.setMargin(new Insets(2, 7, 2, 7));
    edit.setText("Edit");
    edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        edit_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jComboBox1,          new XYConstraints(65, 20, 180, -1));
    panel1.add(add,   new XYConstraints(75, 65, -1, -1));
    panel1.add(remove,  new XYConstraints(155, 65, -1, -1));
    panel1.add(jScrollPane1,    new XYConstraints(30, 115, 250, 160));
    panel1.add(ok,       new XYConstraints(170, 285, -1, -1));
    panel1.add(cancel,      new XYConstraints(220, 285, -1, -1));
    panel1.add(edit,     new XYConstraints(110, 285, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    jComboBox1.addItem("Static Routing");
    jComboBox1.addItem("RIP");
    jComboBox1.addItem("IGRP");
    jComboBox1.addItem("Default Routing");
    this.setTitle("Routing Protocol");
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(320,375);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  public void setRouter(Router rt1){
    rt = rt1;
    Routing routing = rt.getRouting();
    staticRoutes = routing.getStaticRoutes();
    defaultRoutes = routing.getDefaultRoutes();
    rips = routing.getDynamicRoutes().getRip();
    igrps = routing.getDynamicRoutes().getIgrp();
    DefaultRoute defaultRoute;
    StaticRoute staticRoute;
    list1 = new Vector();
    for(int i = 0 ; i < defaultRoutes.size();i++){
      tempForCancel.getDefaultRoutes().addElement(defaultRoutes.elementAt(i));
    }
    for(int i = 0 ; i < staticRoutes.size() ; i++){
      tempForCancel.getStaticRoutes().addElement(staticRoutes.elementAt(i));
    }
    for(int i = 0 ; i <rips.size() ; i++){
      tempForCancel.getDynamicRoutes().getRip().addElement(rips.elementAt(i));
    }
    for(int i = 0 ; i < igrps.size();i++){
      tempForCancel.getDynamicRoutes().getIgrp().addElement(igrps.elementAt(i));
    }
    this.setList1(rt);
  }
  public void setList1(Router rt1){
    rt = rt1;
    Routing routing = rt.getRouting();
    staticRoutes = routing.getStaticRoutes();
    defaultRoutes = routing.getDefaultRoutes();
    rips = routing.getDynamicRoutes().getRip();
    igrps = routing.getDynamicRoutes().getIgrp();
    DefaultRoute defaultRoute;
    StaticRoute staticRoute;
    String rip;
    String igrp;
    list1 = new Vector();
    for(int i = 0 ; i < defaultRoutes.size();i++){
      defaultRoute = (DefaultRoute)defaultRoutes.elementAt(i);
      list1.addElement("ip route 0.0.0.0 0.0.0.0 "+defaultRoute.getRoute());
    }
    for(int i = 0 ; i < staticRoutes.size() ; i++){
      staticRoute = (StaticRoute)staticRoutes.elementAt(i);
      list1.addElement("ip route "+staticRoute.getNetwork()+" "+staticRoute.getSubnet()+" "+staticRoute.getRoute());
    }
    if(rips.size()!=0){ list1.addElement("router rip");}
    for(int i = 0 ; i <rips.size() ; i++){
      rip = (String)rips.elementAt(i);
      list1.addElement("network "+rip);
    }
    if(igrps.size()!=0)
    list1.addElement("router igrp "+rt.getAsNo());
    for(int i = 0 ; i < igrps.size();i++){
      igrp = (String)igrps.elementAt(i);
      list1.addElement("network "+igrp);
    }
    jList1.setListData(list1);
  }

  void add_actionPerformed(ActionEvent e) {
    String temp = (String)this.jComboBox1.getSelectedItem();
    if(temp.equals("Static Routing")){
      StaticRoute staticRoute = new StaticRoute();
      StaticRoutingDialog dialog = new StaticRoutingDialog();
      rt.getRouting().getStaticRoutes().addElement(staticRoute);
      dialog.setStaticRoute(rt,staticRoute,true);
      dialog.showDialog();
    }else if(temp.equals("RIP")||temp.equals(("IGRP"))){
      DynamicRouteDialog dialog = new DynamicRouteDialog();
      dialog.setProtocol(rt,temp,true);
      dialog.showDialog();
    }else if(temp.equals("Default Routing")){
      DefaultRoute defaultRoute = new DefaultRoute();
      DefaultRoutingDialog dialog = new DefaultRoutingDialog();
      rt.getRouting().getDefaultRoutes().addElement(defaultRoute);
      dialog.setDefaultRoute(rt,defaultRoute,true);
      dialog.showDialog();
    }
    this.setList1(rt);

  }

  void remove_actionPerformed(ActionEvent e) {
  if (!jList1.isSelectionEmpty()){
    int temp = jList1.getSelectedIndex();
    if((temp < defaultRoutes.size())){
      defaultRoutes.removeElementAt(temp);
    }else if((temp < defaultRoutes.size()+staticRoutes.size() )){
      staticRoutes.removeElementAt(temp-defaultRoutes.size());
    }else if(rips.size()!=0){
      if((temp < defaultRoutes.size()+staticRoutes.size()+rips.size()+1 )){//have RIP
        rips.removeElementAt(temp-defaultRoutes.size()-staticRoutes.size()-1);
      }else if((temp < defaultRoutes.size()+staticRoutes.size()+rips.size()+igrps.size()+2 )){
        //have RIP & IGRP
        igrps.removeElementAt(temp-defaultRoutes.size()-staticRoutes.size()-rips.size()-2);
      }
    }else if((temp < defaultRoutes.size()+staticRoutes.size()+igrps.size()+1 )){//no RIP have IGMP
      igrps.removeElementAt(temp-defaultRoutes.size()-staticRoutes.size()-1);
    }
    this.setList1(rt);
  }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void cancel_actionPerformed(ActionEvent e) {
    rt.setRouting(tempForCancel);
    this.dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel_actionPerformed(null);
    }
  }

  void edit_actionPerformed(ActionEvent e) {
    if (!jList1.isSelectionEmpty()){
    int temp = jList1.getSelectedIndex();
    int a;
    if((temp < defaultRoutes.size())){
      DefaultRoute defaultRoute = (DefaultRoute)defaultRoutes.elementAt(temp);
      DefaultRoutingDialog dialog = new DefaultRoutingDialog();
      dialog.setDefaultRoute(rt,defaultRoute,false);
      dialog.showDialog();
    }else if((temp < defaultRoutes.size()+staticRoutes.size() )){
      StaticRoute staticRoute = (StaticRoute)staticRoutes.elementAt(temp-defaultRoutes.size());
      StaticRoutingDialog dialog = new StaticRoutingDialog();
      dialog.setStaticRoute(rt,staticRoute,false);
      dialog.showDialog();
    }else if(rips.size()!=0){
      if((temp < defaultRoutes.size()+staticRoutes.size()+rips.size()+1 )){//have RIP
        String rip = (String)rips.elementAt(temp-defaultRoutes.size()-staticRoutes.size()-1);
        a = temp-defaultRoutes.size()-staticRoutes.size()-1;
        DynamicRouteDialog dialog = new DynamicRouteDialog();
        dialog.setProtocol(rt,"RIP",a,false);
        dialog.showDialog();
      }else if((temp < defaultRoutes.size()+staticRoutes.size()+rips.size()+igrps.size()+2 )){
        //have RIP & IGRP
        String igrp = (String)igrps.elementAt(temp-defaultRoutes.size()-staticRoutes.size()-rips.size()-2);
        a = temp-defaultRoutes.size()-staticRoutes.size()-rips.size()-2;
        DynamicRouteDialog dialog = new DynamicRouteDialog();
        dialog.setProtocol(rt,"IGRP",a,false);
        dialog.showDialog();
      }
    }else if((temp < defaultRoutes.size()+staticRoutes.size()+igrps.size()+1 )){//no RIP have IGMP
      String igrp = (String)igrps.elementAt(temp-defaultRoutes.size()-staticRoutes.size()-1);
      DynamicRouteDialog dialog = new DynamicRouteDialog();
      a = temp-defaultRoutes.size()-staticRoutes.size()-1;
      dialog.setProtocol(rt,"IGRP",a,false);
      dialog.showDialog();
    }
    this.setList1(rt);
    }
  }

}















