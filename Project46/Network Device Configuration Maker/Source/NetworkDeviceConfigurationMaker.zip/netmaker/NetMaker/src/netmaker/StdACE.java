package netmaker;

public class StdACE {

  private String srcAddress = "";
  private String stringACE = "";
  private String id = "";
  private boolean permit = false;
  private boolean anySource = false;
  public StdACE() {
  }
  public String getSrcAddress() {
    return srcAddress;
  }
  public void setSrcAddress(String srcAddress) {
    this.srcAddress = srcAddress;
  }

  public String getStringACE() {// create config standard ACE
    if (permit)
      this.stringACE = "access-list " + this.id + " permit ";
    else this.stringACE = "access-list " + this.id + " deny ";

    if (anySource)
      this.stringACE += "any";
    else this.stringACE += this.srcAddress;

    return stringACE;
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public void setPermit(boolean permit) {
    this.permit = permit;
  }
  public boolean isPermit() {
    return permit;
  }
  public void setAnySource(boolean anySource) {
    this.anySource = anySource;
  }
  public boolean isAnySource() {
    return anySource;
  }

}
