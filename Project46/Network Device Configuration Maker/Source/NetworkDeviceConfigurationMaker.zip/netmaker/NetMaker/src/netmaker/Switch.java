package netmaker;

import java.util.Vector;
import java.io.*;
import java.awt.*;

public class Switch {
  private int id;//primary key of device
  private String series="";
  private int nFastEthPort=0;
  private int nGigabitEthPort=0;
  private Vector ethernetInterfaces = new Vector();//Vector of SwitchEthINF class
  private String iosVersion="12.1";
  private String hostName="";
  private Vector vlans = new Vector();//Vector of VlanINF class
  private Vector portChannels = new Vector();//Vector of PortChannelINF class
  private LineINF console = new LineINF();
  private LineINF vty = new LineINF();
  private Vector stdACLs = new Vector();//Vector of StdACL class
  private Vector extACLs = new Vector();//Vector of ExtACL class
  private String defaultGateWay="";
  private Vector connectingSwitch = new Vector();//SwitchImg class
  private Vector connectingRouter = new Vector();//RouterImg class
  private String password = "";//RouterImg class

  public Switch() {
    vlans.addElement(new VlanINF("1"));
  }
  public Switch(int id, int nFastEth, int nGigabitEth, String series, String iosVersion) {
    this.id = id;
    for (int i=0;i<nFastEth;i++){
      this.ethernetInterfaces.addElement(new SwitchEthINF("f0/" + (i+1)));
    }
  }
  //////////////////////////////////////////////////////////////////////////////////
  public String getDefaultGateWay() {
    return defaultGateWay;
  }
  public void setDefaultGateWay(String defaultGateWay) {
    this.defaultGateWay = defaultGateWay;
  }
  public String getHostName() {
    return hostName;
  }
  public void setHostName(String hostName) {
    this.hostName = hostName;
  }
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public String getIosVersion() {
    return iosVersion;
  }
  public void setIosVersion(String iosVersion) {
    this.iosVersion = iosVersion;
  }
  public String getSeries() {
    return series;
  }
  public void setSeries(String series) {
    this.series = series;
    assignPort(series);
  }
  public Vector getConnectingRouter() {
    return connectingRouter;
  }
  public void setConnectingRouter(Vector connectingRouter) {
    this.connectingRouter = connectingRouter;
  }
  public Vector getConnectingSwitch() {
    return connectingSwitch;
  }
  public void setConnectingSwitch(Vector connectingSwitch) {
    this.connectingSwitch = connectingSwitch;
  }
  public LineINF getConsole() {
    return console;
  }
  public void setConsole(LineINF console) {
    this.console = console;
  }
  public Vector getExtACLs() {
    return extACLs;
  }
  public void setExtACLs(Vector extACLs) {
    this.extACLs = extACLs;
  }
  public Vector getPortChannels() {
    return portChannels;
  }
  public void setPortChannels(Vector portChannels) {
    this.portChannels = portChannels;
  }
  public Vector getStdACLs() {
    return stdACLs;
  }
  public void setStdACLs(Vector stdACLs) {
    this.stdACLs = stdACLs;
  }
  public Vector getVlans() {
    return vlans;
  }
  public void setVlans(Vector vlans) {
    this.vlans = vlans;
  }
  public void setVty(LineINF vty) {
    this.vty = vty;
  }
  public LineINF getVty() {
    return vty;
  }
  public Vector getEthernetInterfaces() {
    return ethernetInterfaces;
  }
  public void setEthernetInterfaces(Vector ethernetInterfaces) {
    this.ethernetInterfaces = ethernetInterfaces;
  }
///////////////////////////////////////////////////////
  public void removeConnectSwitch(int i){
    this.connectingSwitch.remove(this.connectingSwitch.elementAt(i));
  }
  public void removeConnectRouter(int i){
    this.connectingRouter.remove(this.connectingRouter.elementAt(i));
  }
  public Vector getVectorOfPort(){
    Vector vPort = new Vector();
    SwitchEthINF switchEthINF = new SwitchEthINF();
    for(int i=0;i<this.ethernetInterfaces.size();i++){
      switchEthINF = (SwitchEthINF)this.ethernetInterfaces.elementAt(i);
      vPort.addElement(switchEthINF.getInterfaceName());
    }
    return vPort;
  }
  public void addConnectingSwitch(SwitchImg simg){
    this.connectingSwitch.addElement(simg);
  }
  public void addConnectingRouter(RouterImg rimg){
    this.connectingRouter.addElement(rimg);
  }
  public void connect(String interfaceName){
    SwitchEthINF inf;
    for(int i=0;i<this.ethernetInterfaces.size();i++){
      inf = (SwitchEthINF)this.ethernetInterfaces.elementAt(i);
      if(inf.getInterfaceName().equalsIgnoreCase(interfaceName)){
        inf.setConnected(true);
      }
    }
  }
  void assignPort(String series){
    if(series.equals("2950_12")){
      this.nFastEthPort = 12;
      this.nGigabitEthPort = 0;
    }
    if(series.equals("2950_24")){
      this.nFastEthPort = 24;
      this.nGigabitEthPort = 0;
    }
    if(series.equals("2950G_12")){
      this.nFastEthPort = 12;
      this.nGigabitEthPort = 2;
    }
    if(series.equals("2950T_24")){
      this.nFastEthPort = 24;
      this.nGigabitEthPort = 2;
    }
    if(series.equals("2955T_12")){
      this.nFastEthPort = 12;
      this.nGigabitEthPort = 2;
    }
    for(int i=0 ; i<Frame1.idealSwitchs.size();i++){
      IdealSwitch idealSwitch = (IdealSwitch)Frame1.idealSwitchs.elementAt(i);
      if(series.equals(idealSwitch.getSeries())){
        this.nFastEthPort = idealSwitch.getNFastEth();
        this.nGigabitEthPort = idealSwitch.getNGigaEth();
      }
    }
    addElementToEthernetInterface();
  }
  void  addElementToEthernetInterface(){
    for(int i=0;i<this.nFastEthPort;i++)
      this.ethernetInterfaces.addElement(new SwitchEthINF("FastEthernet0/"+(i+1)));

    for(int i=0;i<this.nGigabitEthPort;i++)
      this.ethernetInterfaces.addElement(new SwitchEthINF("GigabitEthernet0/"+(i+1)));
  }
  public Vector getVectorVlanID(){//return vector of vlan id
    Vector vector = new Vector();
    for(int i=0;i<vlans.size();i++){
      VlanINF vlanInf = (VlanINF)vlans.elementAt(i);
      vector.addElement(vlanInf.getId());
    }
    return vector;
  }
  public void addVlanNo(String no){
      this.vlans.addElement(new VlanINF(no));
  }
  public void removeVlan(String id){
    for(int i=0;i< vlans.size();i++)
    {
      VlanINF vlanInf = (VlanINF)vlans.elementAt(i);
      if(id.equals(vlanInf.getId()))
        vlans.remove(i);
    }
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public String getPassword() {
    return password;
  }
  public void addNewPortChannel(String name){
    this.portChannels.addElement(new PortChannelINF(name));
  }
  public void removePortChannel(String name){
    for(int i=0;i<this.portChannels.size();i++){
      PortChannelINF portChannel =(PortChannelINF)portChannels.elementAt(i);
      if(portChannel.getId().endsWith(name))
        portChannels.remove(i);
    }
  }
  public void showDetail(){
    System.out.println("id :"+id );
    System.out.println("Series :"+series);
    System.out.println("Name :"+hostName);
    for(int i=0;i<this.vlans.size();i++){
      VlanINF vlan = (VlanINF)vlans.elementAt(i);
      System.out.print("vlan : vlan"+vlan.getId()+" ip : "+vlan.getIpAddress()+" subnet : "+vlan.getSubnet());
      if(vlan.isShutdown()){
        System.out.print("  shutdown");
        }else
          System.out.print("  no shutdown");
        System.out.println();
    }
    for(int i=0;i<this.ethernetInterfaces.size();i++){
      SwitchEthINF in = (SwitchEthINF)ethernetInterfaces.elementAt(i);
      System.out.print("Name : "+in.getInterfaceName()+" ip : "+in.getIpAddress()+
                       " subnet : "+in.getSubnet()+" portChannel : "+in.getPortChannelID()+
                       " mode : "+in.getMode());
      System.out.println();
      for(int j=0 ; j<in.getVlanSTPs().size();j++){
        VlanSTP vlan = (VlanSTP)in.getVlanSTPs().elementAt(j);
        System.out.print("vlan : vlan"+vlan.getVlanID()+" Cost : "+vlan.getCost()+" Priority : "+vlan.getPriority());
        System.out.println();
      }
    }
  }
  public void genConfigFile(){
    FileDialog fileDialog = new FileDialog(new Frame(), "Save As",FileDialog.SAVE);
    fileDialog.setDirectory(".");
    fileDialog.setVisible(true);

    File file = new File(fileDialog.getDirectory(),fileDialog.getFile()+".text");
    try{
      FileWriter fileWriter = new FileWriter(file);
      BufferedWriter bwriter = new BufferedWriter(fileWriter);
      PrintWriter pwriter = new PrintWriter(bwriter);
      pwriter.print("");
      pwriter.print(this.genVersion());
      pwriter.print(this.genService());
      pwriter.print(this.genHostName());
      pwriter.print(this.genPassword());
      pwriter.print(this.genIpSubnet());
      pwriter.print(this.genSTPID());
      pwriter.print(this.genInterfacePortChannels());
      pwriter.print(this.genSwitchEthernetInterfaces());
      pwriter.print(this.genVlanInterfaces());
      pwriter.print(this.genDetailStdACLs());
      pwriter.print(this.genDetailExtACLs());
      pwriter.print(this.genIpDefaultGateway());
      pwriter.print(this.genIpHttpServer());
      pwriter.print(this.genLineCon());
      pwriter.print(this.genLineVty());
      pwriter.close();
    }
    catch(IOException io){
      System.out.println("IOException at generateSwitchConfig");
    }
  }
  /////////////////function////////////////////
  private String genVersion(){
    String s = "";
    s = "version " + this.getIosVersion() + "\n";
    return s;
  }
  private String genService(){
    String s = "";
    s =  "no service single-slot-reload-enable\n";
    s += "no service pad\n";
    s += "service timestamps debug uptime\n";
    s += "service timestamps log uptime\n";
    s += "no service password-encryption\n";
    s += "!\n";
    return s;
  }
  private String genHostName(){
    String s = "";
    s =  "hostname " + this.getHostName() + "\n";
    return s;
  }
  private String genPassword(){
    String strPassword = "";
    if (!this.password.equals(""))
      strPassword += "enable password " + this.password + "\n!\n";
    else strPassword += "!\n";
    return strPassword;
  }
  private String genIpSubnet(){
    String s = "";
    s = "ip subnet-zero\n";
    return s;
  }
  private String genSTPID(){
    String s = "";
    s = "spanning-tree extend system-id\n";
    s += "!\n!\n";
    return s;
  }
  private String genInterfacePortChannels(){
    PortChannelINF portChannel;
    String strPortChannel = "";
    for (int i = 0; i < this.getPortChannels().size(); i++) {
      portChannel = (PortChannelINF) this.getPortChannels().elementAt(i);
      strPortChannel += this.genInterfacePortChannel(portChannel);
    }
    return strPortChannel;
  }
  private String genInterfacePortChannel(PortChannelINF inf){
    String strModeAndVlan = "";
    String strSTPVlan = "";
    strModeAndVlan = "interface Port-channel" + inf.getId() + "\n";
    if ((inf.getMode().equals("access")) & (inf.getVlanSTPs().size()==1)){//if mode access and allowed only one vlan
      if (!((VlanSTP)inf.getVlanSTPs().elementAt(0)).getVlanID().equals("1")){//if mode is access and not vlan 1
        strModeAndVlan += "switchport acces vlan " + ((VlanSTP)inf.getVlanSTPs().elementAt(0)).getVlanID() + "\n";
        strModeAndVlan += "switchport mode access\n";
        VlanSTP vlanSTP;
        vlanSTP = (VlanSTP)inf.getVlanSTPs().elementAt(0);
        if (!vlanSTP.getCost().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-cost " + vlanSTP.getCost() + "\n";
        }
        else if (!vlanSTP.getPriority().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-priority " + vlanSTP.getPriority() + "\n";
        }
      }
    }
    else {//trunk mode
      strModeAndVlan += "switchport trunk allowed vlan ";
      int size = inf.getVlanSTPs().size();
      VlanSTP vlanSTP;
      for (int i=0;i<size;i++){
        vlanSTP = (VlanSTP)inf.getVlanSTPs().elementAt(i);
        strModeAndVlan += vlanSTP.getVlanID();
        //*****Spanning tree vlan***********//
        if (!vlanSTP.getCost().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-cost " + vlanSTP.getCost() + "\n";
        }
        else if (!vlanSTP.getPriority().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-priority " + vlanSTP.getPriority() + "\n";
        }
        //*********end stp vlan*************//
        if (i==(size-1))  //if last vlan
          strModeAndVlan += "\n";
        else strModeAndVlan += ",";    //if has another vlan
      }
      strModeAndVlan += "switchport mode trunk\n";
    }
    strModeAndVlan += "no ip address\n";
    strModeAndVlan += "flowcontrol send off\n";
    strModeAndVlan += strSTPVlan;//concat string
    strModeAndVlan += "!\n";
    return strModeAndVlan;
  }
  private String genSwitchEthernetInterfaces(){
    String strSwitchEthernetINF = "";
    SwitchEthINF swInf;
    for (int i = 0; i < this.getEthernetInterfaces().size(); i++) {
      swInf = (SwitchEthINF) this.getEthernetInterfaces().elementAt(i);
      strSwitchEthernetINF += this.genSwitchEthernetInterface(swInf);
    }
    return strSwitchEthernetINF;
  }
  private String genSwitchEthernetInterface(SwitchEthINF inf){
    String strModeAndVlan = "interface ";
    String strSTPVlan = "";
    strModeAndVlan += inf.getInterfaceName() + "\n";
    if ((inf.getMode().equals("access")) & (inf.getVlanSTPs().size()==1)){//if mode access and allowed only one vlan
      if (!((VlanSTP)inf.getVlanSTPs().elementAt(0)).getVlanID().equals("1")){//if mode is access and not vlan 1
        strModeAndVlan += "switchport acces vlan " + ((VlanSTP)inf.getVlanSTPs().elementAt(0)).getVlanID() + "\n";
        strModeAndVlan += "switchport mode access\n";
        VlanSTP vlanSTP;
        vlanSTP = (VlanSTP)inf.getVlanSTPs().elementAt(0);
        if (!vlanSTP.getCost().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-cost " + vlanSTP.getCost() + "\n";
        }
        else if (!vlanSTP.getPriority().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-priority " + vlanSTP.getPriority() + "\n";
        }
      }
    }
    else {//trunk mode
      strModeAndVlan += "switchport trunk allowed vlan ";
      int size = inf.getVlanSTPs().size();
      VlanSTP vlanSTP;
      for (int i=0;i<size;i++){
        vlanSTP = (VlanSTP)inf.getVlanSTPs().elementAt(i);
        strModeAndVlan += vlanSTP.getVlanID();
        //*****Spanning tree vlan***********//
        if (!vlanSTP.getCost().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-cost " + vlanSTP.getCost() + "\n";
        }
        else if (!vlanSTP.getPriority().equals("")){
          strSTPVlan += "spanning-tree vlan " + vlanSTP.getVlanID() +
              " port-priority " + vlanSTP.getPriority() + "\n";
        }
        //*********end stp vlan*************//
        if (i==(size-1))  //if last vlan
          strModeAndVlan += "\n";
        else strModeAndVlan += ",";    //if has another vlan
      }
      strModeAndVlan += "switchport mode trunk\n";
    }
    strModeAndVlan += "no ip address\n";
    if (!inf.getPortChannelID().equals("")){  //gen portchannel
      strModeAndVlan += "channel-group " + inf.getPortChannelID() + " mode on\n";
    }
    strModeAndVlan += strSTPVlan;
    strModeAndVlan += "!\n";
    return strModeAndVlan;
  }
  private String genVlanInterfaces(){
    String strVlan = "";
    VlanINF vlanInf;
    for (int i = 0; i < this.getVlans().size(); i++) {
      vlanInf = (VlanINF) this.getVlans().elementAt(i);
      strVlan += this.genVlanInterface(vlanInf);
    }
    return strVlan;
  }
  private String genVlanInterface(VlanINF vlanINF){
    AccessGroup group;
    String strVlanINF = "interface Vlan" + vlanINF.getId() + "\n";
    //*******************show ip of vlan *********************
    if (vlanINF.getIpAddress().equals(""))
      strVlanINF += "no ip address\n";
    else strVlanINF += "ip address " + vlanINF.getIpAddress() + " " + vlanINF.getSubnet() + "\n";
    //*******************show access group********************
    if (vlanINF.getAccessGroups().size()!=0){
      for (int i=0;i<vlanINF.getAccessGroups().size();i++){
        group = (AccessGroup)vlanINF.getAccessGroups().elementAt(i);
        if (group.isIncoming())
          strVlanINF += "ip access-group " + group.getId() + " " + "in\n";
        else
          strVlanINF += "ip access-group " + group.getId() + " " + "out\n";
      }
    }
    //*******************************************************
     if (vlanINF.isShutdown())
       strVlanINF += "shutdown\n";
    strVlanINF += "no ip route-cache\n";
    strVlanINF += "!\n";

    return strVlanINF;
  }
  private String genDetailStdACLs(){
    String strStdACLs = "";
    StdACL acl;
    int nACL = this.stdACLs.size();
    if (nACL !=0){
      for (int i=0;i<nACL;i++){
        acl = (StdACL)this.stdACLs.elementAt(i);
        strStdACLs += this.genDetailStdACEs(acl);
      }
    }
    return strStdACLs;
  }
  private String genDetailStdACEs(StdACL acl){
    String strACEs = "";
    StdACE ace;
    int nACE = acl.getAces().size();
    if (nACE!=0){
      for (int i=0;i<nACE;i++){
        ace = (StdACE)acl.getAces().elementAt(i);
        strACEs += ace.getStringACE() + "\n";
      }
    }
    return strACEs;
  }
  private String genDetailExtACLs(){
    ExtACL acl;
    String strExtACLs = "";
    int nList = this.extACLs.size();
    if (nList !=0){
      for (int i=0;i<nList;i++){
        acl = (ExtACL)this.extACLs.elementAt(i);
        strExtACLs += this.genDetailExtACEs(acl);
      }
    }
    return strExtACLs;
  }
  private String genDetailExtACEs(ExtACL acl){
    String strACEs = "";
    ExtACE ace;
    int nACE = acl.getAces().size();
    if (nACE!=0){
      for (int i=0;i<nACE;i++){
        ace = (ExtACE)acl.getAces().elementAt(i);
        strACEs += ace.getStringACE() + "\n";
      }
    }
    return strACEs;
  }
  private String genIpDefaultGateway(){
    String strDefaultGateway = "";
    if (!this.getDefaultGateWay().equals("")){
      strDefaultGateway += "ip default-gateway " + this.getDefaultGateWay() +"\n";
    }
    return strDefaultGateway;
  }
  private String genIpHttpServer(){
    String s = "ip http server\n!\n";
    return s;
  }
  private String genLineCon(){
    String s = "line con 0\n";
    if (this.console.isLogin())
      if (!this.console.getPassword().equals("")){
        s += "password " + this.console.getPassword() + "\n";
        s += "login\n";
      }
    return s;
  }
  private String genLineVty(){
    String s = "line vty 0 15\n";
    if (this.vty.isLogin())
      if (!this.vty.getPassword().equals("")){
        s += "password " + this.vty.getPassword() + "\n";
        s += "login\n";
      }
    s += "!\n";
    s += "end\n";
    return s;
  }

}