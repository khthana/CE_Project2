package netmaker;

import java.util.Vector;
public class Routing {
  private Vector staticRoutes = new Vector();//Vector of StaticRoute Class
  private DynamicRoute dynamicRoutes = new DynamicRoute();
  private Vector defaultRoutes = new Vector();//Vector of DefaultRoute Class
  public Routing() {
  }
  public Vector getStaticRoutes() {
    return staticRoutes;
  }
  public void setStaticRoutes(java.util.Vector staticRoutes) {
    this.staticRoutes = staticRoutes;
  }
  public DynamicRoute getDynamicRoutes() {
    return dynamicRoutes;
  }
  public void setDynamicRoutes(DynamicRoute dynamicRoutes) {
    this.dynamicRoutes = dynamicRoutes;
  }
  public Vector getDefaultRoutes() {
    return defaultRoutes;
  }
  public void setDefaultRoutes(Vector defaultRoutes) {
    this.defaultRoutes = defaultRoutes;
  }

  /////////////////////////////function/////////////////////////////

  //*******StaticRoute
  public void addStaticRoute(StaticRoute sRoute){
    if (!this.isStaticRouteAdded(sRoute)) {
      this.staticRoutes.addElement(sRoute);
    }
  }
  private boolean isStaticRouteAdded(StaticRoute sRoute) {
    for (int i=0;i<this.staticRoutes.size();i++){
      if (sRoute.equals((StaticRoute)this.staticRoutes.elementAt(i))) {
        return true;
      }
    }
    return false;
  }
  public void removeStaticRoute(StaticRoute sRoute){//by check network attribute
    for (int i=0;i<this.staticRoutes.size();i++){
      if (sRoute.equals((StaticRoute)this.staticRoutes.elementAt(i))) {
        this.staticRoutes.removeElementAt(i);
      }
    }
  }


  //*******DynamicRoute
  public boolean addRIP(String network) {
    return this.dynamicRoutes.addRIP(network);
    //return true if no have network in RIP Vector and add RIP successful.
    //return false if had network in RIP Vector.
  }
  public boolean removeRIP(String network) {
    return this.dynamicRoutes.removeRIP(network);
    //return true if found network that you want to remove in RIP Vector and remove RIP successful
    //return false if not found network that you want to remove in RIP Vector.
  }

  public boolean addIGRP(String network) {
    return this.dynamicRoutes.addIGRP(network);
  }
  public boolean removeIGRP(String network){
    return this.dynamicRoutes.removeIGRP(network);
  }

  //*******DefaultRoute
   public void addDefaultRoute(DefaultRoute defaultRoute) {
     if (!this.isDefaultRouteAdded(defaultRoute)){
       this.defaultRoutes.addElement(defaultRoute);
     }
   }
   public boolean isDefaultRouteAdded(DefaultRoute defaultRoute){
     int size = this.defaultRoutes.size();
     for (int i=0;i<size;i++){
       if (this.defaultRoutes.elementAt(i).equals(defaultRoute)) {
         return true;
       }
     }
     return false;
   }
   public boolean removeDefaultRoute(DefaultRoute defaultRoute) {
     for (int i=0;i<this.defaultRoutes.size();i++){
       if (this.defaultRoutes.elementAt(i).equals(defaultRoute)){
         this.defaultRoutes.removeElementAt(i);
         return true;
       }
     }
     return false;
   }

}