package netmaker;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame1 extends JFrame {
  static Vector vRouter = new Vector();
  static Vector vSwitch = new Vector();
  static Vector vConnection = new Vector();
  private JPanel contentPane;
  private XYLayout xYLayout1 = new XYLayout();
  private JToolBar jToolBar2 = new JToolBar();
  static DesignAreaPanel designAreaPanel = new DesignAreaPanel();
  private JButton switchButton1 = new JButton();
  private JButton switchButton2 = new JButton();
  private JButton switchButton3 = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton switchButton4 = new JButton();
  private JButton switchButton5 = new JButton();
  private JLabel jLabel2 = new JLabel();
  private JButton routerButton1 = new JButton();
  private JButton routerButton2 = new JButton();
  private JButton routerButton3 = new JButton();
  private JButton connectButton = new JButton();
  private TitledBorder titledBorder1;
  private XYLayout xYLayout2 = new XYLayout();
  static Vector idealSwitchs = new Vector();
  static Vector idealRouters = new Vector();
  private JButton idealSwitchButton = new JButton();
  private JButton idealRouterButton = new JButton();
  private JLabel jLabel3 = new JLabel();
  JButton disconnectButton = new JButton();
  JButton jButton1 = new JButton();
  //Construct the frame
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    ImageIcon imageFeature;
    ImageIcon imageConnect;
    ImageIcon imageHandBook;
    ImageIcon imageSwitch1;
    ImageIcon imageSwitch2;
    ImageIcon imageSwitch3;
    ImageIcon imageSwitch4;
    ImageIcon imageSwitch5;
    ImageIcon imageRouter1;
    ImageIcon imageRouter2;
    ImageIcon imageRouter3;
    ImageIcon imageIdealRouter;
    ImageIcon imageIdealSwitch;
    ImageIcon imageDisconnect;
    ImageIcon imageEBook;

    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    imageConnect = new ImageIcon(netmaker.Frame1.class.getResource("connection1.jpg"));
    imageSwitch1 = new ImageIcon(netmaker.Frame1.class.getResource("2950-12-n.jpg"));
    imageSwitch2 = new ImageIcon(netmaker.Frame1.class.getResource("2950-24-n.jpg"));
    imageSwitch3 = new ImageIcon(netmaker.Frame1.class.getResource("2950G-12-n.jpg"));
    imageSwitch4 = new ImageIcon(netmaker.Frame1.class.getResource("2950T-24-n.jpg"));
    imageSwitch5 = new ImageIcon(netmaker.Frame1.class.getResource("2955T-12-n.jpg"));
    imageRouter1 = new ImageIcon(netmaker.Frame1.class.getResource("1760.jpg"));
    imageRouter2 = new ImageIcon(netmaker.Frame1.class.getResource("2620.jpg"));
    imageRouter3 = new ImageIcon(netmaker.Frame1.class.getResource("2621.jpg"));
    imageIdealRouter = new ImageIcon(netmaker.Frame1.class.getResource("IdealRouter.jpg"));
    imageIdealSwitch = new ImageIcon(netmaker.Frame1.class.getResource("IdealSwitch.jpg"));
    imageDisconnect = new ImageIcon(netmaker.Frame1.class.getResource("disconnect.jpg"));
    imageEBook = new ImageIcon(netmaker.Frame1.class.getResource("e-Book.jpg"));


    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    contentPane.setLayout(xYLayout2);
    this.getContentPane().setBackground(SystemColor.inactiveCaptionText);
    this.setSize(new Dimension(1011, 721));
    this.setTitle("Network Devices Configuration Maker");
    jToolBar2.setOrientation(JToolBar.VERTICAL);
    jToolBar2.setBackground(UIManager.getColor("InternalFrame.inactiveTitleForeground"));
    jToolBar2.setEnabled(false);
    jToolBar2.setBorder(null);
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 25));
    jLabel1.setRequestFocusEnabled(false);
    jLabel1.setText(" Switch Series");
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 25));
    jLabel2.setRequestFocusEnabled(false);
    jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel2.setText(" Router Series");
    connectButton.setBackground(SystemColor.inactiveCaptionText);
    connectButton.setBorder(BorderFactory.createRaisedBevelBorder());
    connectButton.setMargin(new Insets(0, 0, 0, 0));
    connectButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connectButton_actionPerformed(e);
      }
    });
    switchButton1.setBorder(null);
    switchButton1.setMargin(new Insets(0, 0, 0, 0));
    switchButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switchButton1_actionPerformed(e);
      }
    });
    switchButton2.setBorder(null);
    switchButton2.setMargin(new Insets(0, 0, 0, 0));
    switchButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switchButton2_actionPerformed(e);
      }
    });
    switchButton4.setBorder(null);
    switchButton4.setMargin(new Insets(0, 0, 0, 0));
    switchButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switchButton4_actionPerformed(e);
      }
    });
    switchButton3.setBorder(null);
    switchButton3.setMargin(new Insets(0, 0, 0, 0));
    switchButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switchButton3_actionPerformed(e);
      }
    });
    switchButton5.setBorder(null);
    switchButton5.setMargin(new Insets(0, 0, 0, 0));
    switchButton5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switchButton5_actionPerformed(e);
      }
    });
    routerButton1.setBorder(null);
    routerButton1.setMargin(new Insets(0, 0, 0, 0));
    routerButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        routerButton1_actionPerformed(e);
      }
    });
    routerButton2.setBorder(null);
    routerButton2.setMargin(new Insets(0, 0, 0, 0));
    routerButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        routerButton2_actionPerformed(e);
      }
    });
    routerButton3.setBorder(null);
    routerButton3.setMargin(new Insets(0, 0, 0, 0));
    routerButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        routerButton3_actionPerformed(e);
      }
    });
    contentPane.setBackground(UIManager.getColor("InternalFrame.inactiveTitleForeground"));
    designAreaPanel.setBackground(new Color(255, 245, 245));
    designAreaPanel.setBorder(BorderFactory.createEtchedBorder());
    idealSwitchButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        idealSwitchButton_actionPerformed(e);
      }
    });
    idealRouterButton.setBorder(null);
    idealRouterButton.setMargin(new Insets(0, 0, 0, 0));
    idealRouterButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        idealRouterButton_actionPerformed(e);
      }
    });
    idealSwitchButton.setBorder(null);
    idealSwitchButton.setMargin(new Insets(0, 0, 0, 0));
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 25));
    jLabel3.setText("    Functions");
    disconnectButton.setBackground(UIManager.getColor("inactiveCaptionText"));
    disconnectButton.setToolTipText("");
    disconnectButton.setIcon(imageDisconnect);
    disconnectButton.setMargin(new Insets(0, 0, 0, 0));
    disconnectButton.setText("");
    disconnectButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        disconnectButton_actionPerformed(e);
      }
    });
    jButton1.setBackground(UIManager.getColor("inactiveCaptionText"));
    jButton1.setIcon(imageEBook);
    jButton1.setMargin(new Insets(0, 0, 0, 0));
    jButton1.setText("");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jToolBar2.add(jLabel1, null);
    jToolBar2.add(switchButton1, null);
    jToolBar2.add(switchButton2, null);
    jToolBar2.add(switchButton3, null);
    jToolBar2.add(switchButton4, null);
    jToolBar2.add(switchButton5, null);
    jToolBar2.add(idealSwitchButton, null);
    jToolBar2.add(jLabel2, null);
    jToolBar2.add(routerButton1, null);
    jToolBar2.add(routerButton2, null);
    jToolBar2.add(routerButton3, null);
    jToolBar2.add(idealRouterButton, null);
    jToolBar2.add(jLabel3, null);
    jToolBar2.add(connectButton, null);
    jToolBar2.add(disconnectButton, null);
    jToolBar2.add(jButton1, null);
    contentPane.add(jToolBar2,                 new XYConstraints(3, 20, -1, 1400));
    contentPane.add(designAreaPanel,         new XYConstraints(180, 2, 823, 690));

    connectButton.setIcon(imageConnect);
    disconnectButton.setIcon(imageDisconnect);
    switchButton1.setIcon(imageSwitch1);
    switchButton2.setIcon(imageSwitch2);
    switchButton3.setIcon(imageSwitch3);
    switchButton4.setIcon(imageSwitch4);
    switchButton5.setIcon(imageSwitch5);
    routerButton1.setIcon(imageRouter1);
    routerButton2.setIcon(imageRouter2);
    routerButton3.setIcon(imageRouter3);
    this.idealRouterButton.setIcon(imageIdealRouter);
    this.idealSwitchButton.setIcon(imageIdealSwitch);
    File file = new File("../","temp.text");
    FileReader fin = new FileReader(file);
    BufferedReader bin = new BufferedReader(fin);
    String temp = "";
    IdealSwitch idealSwitch = new IdealSwitch();
    IdealRouter idealRouter = new IdealRouter();
    boolean isSwitch = false,isRouter = false;
    while(( (temp = bin.readLine())!= null)){
      if (isSwitch){
        if(temp.length()>=6){
          if(temp.substring(0,6).equals("series")){
          String t = temp.substring(7,temp.length());
          idealSwitch = new IdealSwitch();
          idealSwitch.setSeries(t);
          System.out.println(t);
        }
        }
        if(temp.length()>=17){
          if(temp.substring(0,17).equals("nFastEthernetPort")){
          String t = temp.substring(18,temp.length());
          idealSwitch.setNFastEth(Integer.parseInt(t));
          System.out.println(t);
        }
        }
        if(temp.length()>=20){
          if(temp.substring(0,20).equals("nGigabitEthernetPort")){
          String t = temp.substring(21,temp.length());
          idealSwitch.setNGigaEth(Integer.parseInt(t));
          System.out.println(t);
          this.idealSwitchs.addElement(idealSwitch);
        }
        }
      }
      if (isRouter){
        if(temp.length()>=6){
          if(temp.substring(0,6).equals("series")){
          String t = temp.substring(7,temp.length());
          idealRouter = new IdealRouter();
          idealRouter.setSeries(t);
          System.out.println(t);
        }
        }
        if(temp.length()>=17){
          if(temp.substring(0,17).equals("nFastEthernetPort")){
          String t = temp.substring(18,temp.length());
          idealRouter.setNFastEth(Integer.parseInt(t));
          System.out.println(t);
        }
        }
        if(temp.length()>=11){
          if(temp.substring(0,11).equals("nSerialPort")){
          String t = temp.substring(12,temp.length());
          idealRouter.setNSerial(Integer.parseInt(t));
          System.out.println(t);
          this.idealRouters.addElement(idealRouter);
        }
        }
      }
    if(temp.length()>=6){
      if(temp.substring(0,6).equals("switch")){
        isSwitch = true;
        isRouter = false;
    }
    }
    if(temp.length()>=6){
      if(temp.substring(0,6).equals("router")){
        isSwitch = false;
        isRouter = true;
    }
    }
    }
    for(int i=0;i<idealSwitchs.size();i++){
      IdealSwitch ideal = (IdealSwitch)this.idealSwitchs.elementAt(i);
      System.out.println(" series: "+ideal.getSeries()+
                         " nFast: "+ideal.getNFastEth()+" nGiga: "+ideal.getNGigaEth());
    }
    for(int i=0;i<idealRouters.size();i++){
      IdealRouter ideal = (IdealRouter)this.idealRouters.elementAt(i);
      System.out.println(" series: "+ideal.getSeries()+
                         " nFast: "+ideal.getNFastEth()+" nSerial: "+ideal.getNSerial());
    }
    bin.close();
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      saveFile();
      System.exit(0);
    }
  }

  void saveFile(){
    try{

      File file = new File("../","temp.text");
      FileWriter fin = new FileWriter(file);
      BufferedWriter bin = new BufferedWriter(fin);
      PrintWriter print = new PrintWriter(bin);
      print.println("switch");
      for(int i=0 ; i< this.idealSwitchs.size();i++){
        IdealSwitch ideal = (IdealSwitch)idealSwitchs.elementAt(i);
        print.println("series "+ideal.getSeries());
        print.println("nFastEthernetPort "+ideal.getNFastEth());
        print.println("nGigabitEthernetPort "+ideal.getNGigaEth());
      }print.println("router");
      for(int i=0 ; i< this.idealRouters.size();i++){
        IdealRouter ideal = (IdealRouter)idealRouters.elementAt(i);
        print.println("series "+ideal.getSeries());
        print.println("nFastEthernetPort "+ideal.getNFastEth());
        print.println("nSerialPort "+ideal.getNSerial());
      }
      print.close();
    }
    catch(Exception e){}
  }

  static void newSwitch(String series){

    Switch s1 = new Switch();
    SwitchImg simg = new SwitchImg();
    String name = "";
    String num = "1";
    name = "Switch"+num;

    for(int i=0;i < vSwitch.size(); i++){
      Switch sw = (Switch)vSwitch.elementAt(i);
      if(sw.getHostName().equals(name))
        name = "Switch"+String.valueOf(i+2);
    }

    s1.setHostName(name);
    s1.setSeries(series);
    Frame1.vSwitch.addElement(s1);
    simg = new SwitchImg(s1.getSeries());
    designAreaPanel.vImgSwitch.addElement(simg);
    designAreaPanel.repaintView();
  }

  static void newRouter(String series){

    Router r1 = new Router();
    RouterImg rimg = new RouterImg();
    String name = "";
    String num = "1";
    name = "Router"+num;

    for(int i=0;i < vRouter.size(); i++){
      Router rt = (Router)vRouter.elementAt(i);
      if(rt.getHostName().equals(name))
        name = "Router"+String.valueOf(i+2);
    }

    r1.setHostName(name);
    r1.setSeries(series);
    Frame1.vRouter.addElement(r1);
    rimg = new RouterImg(r1.getSeries());
    designAreaPanel.vImgRouter.addElement(rimg);
    designAreaPanel.repaintView();

  }

  void switchButton1_actionPerformed(ActionEvent e) {
    newSwitch("2950_12");
  }

  void switchButton2_actionPerformed(ActionEvent e) {
    newSwitch("2950_24");
  }

  void switchButton3_actionPerformed(ActionEvent e) {
    newSwitch("2950G_12");
  }

  void switchButton4_actionPerformed(ActionEvent e) {
    newSwitch("2950T_24");
  }

  void switchButton5_actionPerformed(ActionEvent e) {
    newSwitch("2955T_12");
  }

  void routerButton1_actionPerformed(ActionEvent e) {
    newRouter("1760");
  }

  void routerButton2_actionPerformed(ActionEvent e) {
    newRouter("2620");
  }

  void routerButton3_actionPerformed(ActionEvent e) {
    newRouter("2621");
  }

  void connectButton_actionPerformed(ActionEvent e) {
    ConnectDialog d4 = new ConnectDialog();
    d4.showDialog();
  }

  void idealSwitchButton_actionPerformed(ActionEvent e) {
    IdealSwitchDialog dialog = new IdealSwitchDialog();
    dialog.showDialog1();

  }

  void idealRouterButton_actionPerformed(ActionEvent e) {
    IdealRouterDialog dialog = new IdealRouterDialog();
    dialog.showDialog1();

  }

  void disconnectButton_actionPerformed(ActionEvent e) {
    DisconnectionDialog dialog = new DisconnectionDialog();
    dialog.showDialog();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    Runtime ed = Runtime.getRuntime();
    try{
      ed.exec("explorer .\\eBook\\index.html");
    }
    catch(Exception e1){
      System.out.println("Error : "+e1);
    }
  }


}