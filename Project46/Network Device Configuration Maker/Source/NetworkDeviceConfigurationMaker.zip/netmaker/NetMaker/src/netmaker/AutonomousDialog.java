package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AutonomousDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JTextField jTextField1 = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private Router rt;

  public AutonomousDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AutonomousDialog() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    jLabel1.setText("Autonomous Number");
    panel1.add(cancel,  new XYConstraints(190, 60, -1, -1));
    panel1.add(ok,   new XYConstraints(120, 60, -1, -1));
    panel1.add(jTextField1,     new XYConstraints(170, 30, 100, -1));
    panel1.add(jLabel1,  new XYConstraints(30, 30, -1, -1));
    this.getContentPane().add(panel1, BorderLayout.CENTER);
    this.setTitle("Autonomous Number");
  }
  public void setRouter(Router rt1){
    rt=rt1;
    jTextField1.setText(rt.getAsNo());
  }

  public void showDialog() {
   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
   Dimension frameSize = this.getSize();
   if (frameSize.height > screenSize.height) {
     frameSize.height = screenSize.height;
   }
   if (frameSize.width > screenSize.width) {
     frameSize.width = screenSize.width;
   }

   this.setSize(320,150);
   this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
   this.setVisible(true);
 }

  void ok_actionPerformed(ActionEvent e) {
    if(chkInteger(this.jTextField1.getText())){
      int temp = Integer.parseInt(jTextField1.getText());
      if( temp >= 1 && temp <= 65535){
    rt.setAsNo(jTextField1.getText());
    this.dispose();}
    else{
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Autonomous number must between 1 and 65535! please try again");
      dialog.showDialog();
    }}
    else{
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illigal Autonomous number! please try again");
      dialog.showDialog();
    }
  }

  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }
  boolean chkInteger(String st){
    try{
      Integer.parseInt(st);
      return true;
    }catch (Exception e){
      return false;
    }
  }
}