package netmaker;

public class IGRP {
  private String network;
  private String subnet;
  public IGRP() {
  }
  public String getNetwork() {
    return network;
  }
  public void setNetwork(String network) {
    this.network = network;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }

}