package netmaker;

public class ExtACE {

  private String id = "";
  private String protocol = "";
  private boolean permit = false;
  private String destAddress = "";
  private String srcAddress = "";
  private String wildCardDestAddress = "";
  private String wildCardSrcAddress = "";
  private boolean anySource = false;
  private boolean anyDestination = false;
  private boolean eqSrcPort = false;//only tcp or udp
  private boolean neqSrcPort = false;//only tcp or udp
  private boolean rangeSrcPort = false;
  private boolean eqDestPort = false;
  private boolean neqDestPort = false;
  private boolean rangeDestPort = false;
  private String destPort;
  private String srcPort;
  private boolean anySrcPort = true;
  private boolean anyDestPort = true;
  private String rangeSrcPort1 = "";//upper bound range of source port
  private String rangeSrcPort2 = "";//lower bound range of source port
  private String rangeDestPort1 = "";//upper bound range of destination port
  private String rangeDestPort2 = "";//upper bound range of source port
  public ExtACE() {
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public boolean isPermit() {
    return permit;
  }
  public void setPermit(boolean permit) {
    this.permit = permit;
  }
  public String getProtocol() {
    return protocol;
  }
  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }
  public String getSrcAddress() {
    return srcAddress;
  }
  public void setSrcAddress(String srcAddress) {
    this.setAnySource(false);
    this.srcAddress = srcAddress;
  }
  public String getWildCardSrcAddress() {
    return wildCardSrcAddress;
  }
  public void setWildCardSrcAddress(String wildCardSrcAddress) {
    this.wildCardSrcAddress = wildCardSrcAddress;
  }
  public String getDestAddress() {
    return destAddress;
  }
  public void setDestAddress(String destAddress) {
    this.setAnyDestination(false);
    this.destAddress = destAddress;
  }
  public String getWildCardDestAddress() {
    return wildCardDestAddress;
  }
  public void setWildCardDestAddress(String wildCardDestAddress) {
    this.wildCardDestAddress = wildCardDestAddress;
  }
  public String getSrcPort() {
    return srcPort;
  }
  public void setSrcPort(String srcPort) {
    this.srcPort = srcPort;
  }
  public String getDestPort() {
    return destPort;
  }
  public void setDestPort(String destPort) {
    this.destPort = destPort;
  }
  public boolean isAnySource() {
    return anySource;
  }
  public void setAnySource(boolean anySource) {
    this.anySource = anySource;
  }
  public boolean isAnyDestination() {
    return anyDestination;
  }
  public void setAnyDestination(boolean anyDestination) {
    this.anyDestination = anyDestination;
  }
  public boolean isAnySrcPort() {
    return anySrcPort;
  }
  public void setAnySrcPort() {
    this.anySrcPort = true;
    this.eqSrcPort = false;
    this.neqSrcPort = false;
    this.rangeSrcPort = false;
  }
  public boolean isEqSrcPort() {
    return eqSrcPort;
  }
  public void setEqSrcPort() {
    this.eqSrcPort = true;
    this.anySrcPort = false;
    this.neqSrcPort = false;
    this.rangeSrcPort = false;
  }
  public boolean isNeqSrcPort() {
    return neqSrcPort;
  }
  public void setNeqSrcPort() {
    this.neqSrcPort = true;
    this.anySrcPort = false;
    this.eqSrcPort = false;
    this.rangeSrcPort = false;
  }
  public boolean isRangeSrcPort() {
    return rangeSrcPort;
  }
  public void setRangeSrcPort() {
    this.rangeSrcPort = true;
    this.anySrcPort = false;
    this.eqSrcPort = false;
    this.neqSrcPort = false;
  }
  public boolean isAnyDestPort() {
    return anyDestPort;
  }
  public void setAnyDestPort() {
    this.anyDestPort = true;
    this.eqDestPort = false;
    this.neqDestPort = false;
    this.rangeDestPort = false;
  }
  public boolean isEqDestPort() {
    return eqDestPort;
  }
  public void setEqDestPort() {
    this.eqDestPort = true;
    this.anyDestPort = false;
    this.neqDestPort = false;
    this.rangeDestPort = false;
  }
  public boolean isNeqDestPort() {
    return neqDestPort;
  }
  public void setNeqDestPort() {
    this.neqDestPort = true;
    this.anyDestPort = false;
    this.eqDestPort = false;
    this.rangeDestPort = false;
  }
  public boolean isRangeDestPort() {
    return rangeDestPort;
  }
  public void setRangeDestPort() {
    this.rangeDestPort = true;
    this.anyDestPort = false;
    this.eqDestPort = false;
    this.neqDestPort = false;
  }
  public String getRangeSrcPort1() {
    return rangeSrcPort1;
  }
  public void setRangeSrcPort1(String rangeSrcPort1) {
    this.rangeSrcPort1 = rangeSrcPort1;
  }
  public String getRangeSrcPort2() {
    return rangeSrcPort2;
  }
  public void setRangeSrcPort2(String rangeSrcPort2) {
    this.rangeSrcPort2 = rangeSrcPort2;
  }
  public String getRangeDestPort1() {
    return rangeDestPort1;
  }
  public void setRangeDestPort1(String rangeDestPort1) {
    this.rangeDestPort1 = rangeDestPort1;
  }
  public String getRangeDestPort2() {
    return rangeDestPort2;
  }
  public void setRangeDestPort2(String rangeDestPort2) {
    this.rangeDestPort2 = rangeDestPort2;
  }
///////////////////////////////////function///////////////////////////////////////


  public String getStringACE() {  // create config extend ACE
    String stringACE="";
    if (!this.protocol.equals("")) {
//------------------------------------------------
//1. define acess-list number, action and protocol
      if (this.permit)
        stringACE += "access-list " + this.id + " permit " + this.protocol + " ";
      else
        stringACE += "access-list " + this.id + " deny " + this.protocol + " ";
//end 1.
//------------------------------------------------
//2. define source information
      //2.1 ip address section
      if (this.anySource)
        stringACE += "any ";
      else if ((!this.srcAddress.equals(""))&(this.wildCardSrcAddress.equals("")))
        stringACE += "host ";
      else if ((!this.srcAddress.equals(""))&(!this.wildCardSrcAddress.equals("")))
        stringACE += this.srcAddress + " " + this.wildCardSrcAddress + " ";
      else {
        System.out.println("something wrong with source ip address");
        ErrorDialog error = new ErrorDialog();
        error.setText("something wrong with source ip address");
        error.showDialog();
        return "";
      }
      //end 2.1
      //2.2 port section
      if (this.protocol.equalsIgnoreCase("TCP") | this.protocol.equalsIgnoreCase("UDP")) {
        if (!this.isAnySrcPort()){
          if (this.eqSrcPort)
            stringACE += "eq " + this.srcPort + " ";
          else if (this.neqSrcPort)
            stringACE += "neq " + this.srcPort + " ";
          else if (this.rangeSrcPort)
            stringACE += "range " + this.rangeSrcPort1 + " " + this.rangeSrcPort2;
        }
      }
      //end 2.2
//end 2.
//------------------------------------------------
//3. define destination information
      //3.1 ip address information

      if (this.anyDestination)
        stringACE += "any ";
      else if ((!this.destAddress.equals(""))&(this.wildCardDestAddress.equals("")))
        stringACE += "host ";
      else if ((!this.destAddress.equals(""))&(!this.wildCardDestAddress.equals("")))
        stringACE += this.destAddress + " " + this.wildCardDestAddress + " ";
      else {
        System.out.println("something wrong with destination ip address");
        return "";
      }
      //end 3.1
      //3.2 port section
      if (this.protocol.equalsIgnoreCase("TCP") | this.protocol.equalsIgnoreCase("UDP")) {
        if (!this.isAnyDestPort()){
          if (this.eqDestPort)
            stringACE += "eq " + this.destPort + " ";
          else if (this.neqDestPort)
            stringACE += "neq " + this.destPort + " ";
          else if (this.rangeDestPort)
            stringACE += "range " + this.rangeDestPort1 + " " + this.rangeDestPort2;
        }
      }
      //end 3.2
//end 3.
    }
    return stringACE;
  }
}
