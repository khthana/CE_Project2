package netmaker;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CreateVlan extends JDialog {
  private Switch sw = new Switch();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JTextField vLanNo = new JTextField();
  private JButton create = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private Vector list = new Vector();
  private JButton remove = new JButton();
  private JButton edit = new JButton();
  private JButton ok = new JButton();

  public CreateVlan(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public CreateVlan() {
    this(null, "", true);
  }
  //--------------------------------------------------------------------//

public void chkSW(String name){
  Switch sw1;
  String name2;
  for(int i = 0;i < Frame1.vSwitch.size();i++ ){
    sw1 = (Switch)Frame1.vSwitch.elementAt(i);
    name2 = sw1.getHostName();
    if(name.equalsIgnoreCase(name2)){
      sw = sw1;
    list = sw.getVectorVlanID();
    }
  }
  jList1.setListData(list);
}
//--------------------------------------------------------------------//

  private void jbInit() throws Exception {

    this.setTitle("Create/Remove VLAN");
    list = sw.getVectorVlanID();
    jList1.setListData(list);
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 18));
    jLabel1.setText("New VLAN No.");
    this.getContentPane().setLayout(xYLayout1);
    create.setBackground(UIManager.getColor("InternalFrame.inactiveTitleForeground"));
    create.setText("Create");
    create.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        create_actionPerformed(e);
      }
    });
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane1.getViewport().setBackground(Color.white);
    this.getContentPane().setBackground(SystemColor.inactiveCaptionText);
    xYLayout1.setWidth(400);
    xYLayout1.setHeight(457);
    vLanNo.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        vLanNo_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    edit.setBackground(SystemColor.inactiveCaptionText);
    edit.setText("Edit");
    edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        edit_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setFont(new java.awt.Font("Dialog", 0, 15));
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    this.getContentPane().add(jLabel1,  new XYConstraints(25, 30, 140, 40));
    this.getContentPane().add(vLanNo,  new XYConstraints(200, 35, 125, 25));
    this.getContentPane().add(jScrollPane1,            new XYConstraints(40, 100, 315, 220));
    jScrollPane1.getViewport().add(jList1, null);
    this.getContentPane().add(create,         new XYConstraints(50, 350, 85, 30));
    this.getContentPane().add(remove,       new XYConstraints(175, 350, -1, 30));
    this.getContentPane().add(edit,       new XYConstraints(290, 350, -1, 30));
    this.getContentPane().add(ok,       new XYConstraints(160, 400, -1, 35));
    this.setTitle("Vlan");
  }
  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(400,480);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
}

  void vLanNo_actionPerformed(ActionEvent e) {

  }

  void create_actionPerformed(ActionEvent e) {
    String no = "";
    Vector vNo = new Vector();
    boolean temp= true,chk = true;
    vNo = sw.getVectorVlanID();
    no = vLanNo.getText();
    try{
    int num = Integer.parseInt(no);
    }catch(Exception ee){
      temp = false;
      chk = false;
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal Vlan number! Please try again");
      dialog.showDialog();

    }
    if(no.equals("")){
      temp=false;
    }
      for(int j=0;j < vNo.size(); j++){
        if(((no.equalsIgnoreCase((String)vNo.elementAt(j)))))
        temp=false;
      }
      if(temp){
      sw.addVlanNo(no);
      }else if(chk){
        ErrorDialog dialog = new ErrorDialog();
        dialog.setText("Vlan number "+no+" is already ");
        dialog.showDialog();
      }
    list = sw.getVectorVlanID();
    jList1.setListData(list);
    vLanNo.setText("");
    for(int i=0;i<vNo.size();i++){ System.out.println("No :  "+vNo.elementAt(i));}
  }

  void remove_actionPerformed(ActionEvent e) {
    int i = list.size();
    if (i>1){
      String temp = (String)jList1.getSelectedValue();
      if(!temp.equals("1")){
        for(int j=0;j<sw.getEthernetInterfaces().size();j++){
          SwitchEthINF switchPort= (SwitchEthINF)sw.getEthernetInterfaces().elementAt(i);
          if(switchPort.getMode().equals("access")){
            VlanSTP vlanstp = (VlanSTP)switchPort.getVlanSTPs().elementAt(0);
            if(vlanstp.getVlanID().equals(temp)){
              switchPort.removeVlan(temp);
              switchPort.addVlan(new VlanSTP("1"));
            }
          }
          if(switchPort.getMode().equals("trunk")){
            for(int k=0;k<switchPort.getVlanSTPs().size();k++){
              VlanSTP vlanstp = (VlanSTP)switchPort.getVlanSTPs().elementAt(k);
              if(vlanstp.getVlanID().equals(temp)){
                switchPort.removeVlan(temp);
              }
            }
          }
        }

        sw.removeVlan(temp);
        list = sw.getVectorVlanID();
        jList1.setListData(list);
      }

    }
  }

  void edit_actionPerformed(ActionEvent e) {
    String temp = (String)jList1.getSelectedValue();
    VlanINF vlanInf;
    for(int i = 0 ; i<sw.getVlans().size();i++){
      vlanInf = (VlanINF)sw.getVlans().elementAt(i);
      if(vlanInf.getId().equals(temp)){
        EditVlan editVlan = new EditVlan();
        editVlan.setVlan(vlanInf,sw);
        editVlan.showDialog();
      }
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }
}











