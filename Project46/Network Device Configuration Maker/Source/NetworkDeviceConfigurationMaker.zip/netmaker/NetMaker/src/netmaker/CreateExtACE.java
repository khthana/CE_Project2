package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CreateExtACE extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton create = new JButton();
  private JButton edit = new JButton();
  private JButton remove = new JButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private ExtACL extACL;
  private Vector list1 = new Vector();
  private Vector forCancel = new Vector();


  public CreateExtACE(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public CreateExtACE() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    create.setBackground(SystemColor.inactiveCaptionText);
    create.setText("Create");
    create.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        create_actionPerformed(e);
      }
    });
    edit.setBackground(SystemColor.inactiveCaptionText);
    edit.setText("Edit");
    edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        edit_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jScrollPane1,      new XYConstraints(19, 15, 414, 145));
    panel1.add(remove,   new XYConstraints(350, 180, -1, -1));
    panel1.add(create,    new XYConstraints(200, 180, -1, -1));
    panel1.add(cancel,    new XYConstraints(355, 225, -1, -1));
    panel1.add(ok,   new XYConstraints(285, 225, -1, -1));
    panel1.add(edit,   new XYConstraints(285, 180, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    this.setTitle("Extended ACL");

  }

  public void setACL(ExtACL extACL1){
    extACL = extACL1;
    String temp;
    this.setTitle("ACL "+extACL.getId());
    list1.removeAllElements();
    for(int i=0;i<extACL.getAces().size();i++){
      ExtACE extACE = (ExtACE)extACL.getAces().elementAt(i);
      temp = extACE.getStringACE();
      list1.addElement(temp);
    }
    jList1.setListData(list1);
  }
  public void showDialog() {
    for(int i=0;i<extACL.getAces().size();i++){
      forCancel.addElement(extACL.getAces().elementAt(i));
    }
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(455,300);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void create_actionPerformed(ActionEvent e) {
    ExtACE extACE = new ExtACE();
    extACL.getAces().addElement(extACE);
    ExtAceDialog dialog = new ExtAceDialog();
    dialog.setACE(extACE,extACL,true);
    dialog.showDialog();
    setACL(extACL);
  }

  void remove_actionPerformed(ActionEvent e) {
    int temp = this.jList1.getSelectedIndex();
    if(temp >= 0){
    extACL.getAces().removeElementAt(temp);
    setACL(extACL);
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void edit_actionPerformed(ActionEvent e) {
    int temp = this.jList1.getSelectedIndex();
    if (temp >= 0 ){
    ExtACE extACE = (ExtACE)extACL.getAces().elementAt(temp);
    ExtAceDialog dialog = new ExtAceDialog();
    dialog.setACE(extACE,extACL,false);
    dialog.showDialog();
    setACL(extACL);
  }
  }

  void cancel_actionPerformed(ActionEvent e) {
    extACL.setAces(forCancel);
    dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e) ;
     if (e.getID() == WindowEvent.WINDOW_CLOSING) {
       extACL.setAces(forCancel);
       dispose();
     }
  }
}