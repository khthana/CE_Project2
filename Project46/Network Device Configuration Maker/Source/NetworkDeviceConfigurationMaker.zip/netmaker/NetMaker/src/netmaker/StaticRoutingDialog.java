package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class StaticRoutingDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JTextField network = new JTextField();
  private JTextField subnet = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JTextField gateway = new JTextField();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private StaticRoute staticRoute;
  private Router rt;
  private boolean isNew ;

  public StaticRoutingDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public StaticRoutingDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("Remote Network");
    jLabel2.setText("Subnet");
    jLabel3.setText("Default Gateway");
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    panel1.add(jLabel1,   new XYConstraints(25, 30, -1, -1));
    panel1.add(jLabel2,   new XYConstraints(25, 60, -1, -1));
    panel1.add(network,      new XYConstraints(140, 30, 80, -1));
    panel1.add(subnet,      new XYConstraints(140, 60, 80, -1));
    panel1.add(jLabel3,     new XYConstraints(25, 90, -1, -1));
    panel1.add(gateway,  new XYConstraints(140, 90, 80, -1));
    panel1.add(ok,  new XYConstraints(80, 130, -1, -1));
    panel1.add(cancel,    new XYConstraints(145, 130, -1, -1));
    this.getContentPane().add(panel1, BorderLayout.CENTER);
    this.setTitle("Static Route");
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(250,200);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  public void setStaticRoute(Router rt1,StaticRoute staticRoute1,boolean chk){
    rt = rt1;
    staticRoute = staticRoute1;
    isNew = chk;
    network.setText(staticRoute.getNetwork());
    subnet.setText(staticRoute.getSubnet());
    gateway.setText(staticRoute.getRoute());
  }
  void ok_actionPerformed(ActionEvent e) {
    boolean isError = false;
    if(chkIP(network.getText())){
      isError = false;
    }else{
      isError = true;
      network.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }
    if(!isError)
    if(chkSubnet(subnet.getText())){
      isError = false;
    }else{
      isError = true;
      subnet.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }
    if(!isError)
      if(chkIP(gateway.getText())){
      isError = false;
    }else{
      isError = true;
      gateway.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }

    if(!isError){
    staticRoute.setNetwork(network.getText());
    staticRoute.setSubnet(subnet.getText());
    staticRoute.setRoute(gateway.getText());
    this.dispose();
  }
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel_actionPerformed(null);
    }
  }

  void cancel_actionPerformed(ActionEvent e) {
    if(isNew)
      rt.getRouting().getStaticRoutes().removeElementAt(rt.getRouting().getStaticRoutes().size()-1);
    this.dispose();
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkSubnet(String st){
    String temp = "";
    String ip = "";
    String sub = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 255)){
          temp = "";
          chk = false;
            }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 0)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    {
      count++;
      try{
        int num = Integer.parseInt(temp);
        if (!chk)
          if((num == 255)){
        temp = "";
        chk = false;
          }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
            chk = true;
            temp = "";
          }else
            return false;
          if (chk){
            if(num != 0)
              return false;
          }
      }catch(Exception e){
        return false;
      }

      }    if((count == 4)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
}