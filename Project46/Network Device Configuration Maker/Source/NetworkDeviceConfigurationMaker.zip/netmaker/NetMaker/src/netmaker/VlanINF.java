package netmaker;

import java.util.Vector;

public class VlanINF {

  private boolean shutdown = false;
  private String ipAddress = "";
  private String subnet = "";
  private Vector accessGroups = new Vector();//Vector of AccessGroup(ACL)
  private String id = "";
  public VlanINF(){
  }
  public VlanINF(String id) {
    setId(id);
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }
  public boolean isShutdown() {
    return shutdown;
  }
  public void setShutdown(boolean shutdown) {
    this.shutdown = shutdown;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public Vector getAccessGroups() {
    return accessGroups;
  }
  public void setAccessGroups(Vector AccessGroups) {
    this.accessGroups = AccessGroups;
  }
  /////////////////////////////////////function////////////////////////////////
  public void addAccessGroup(String id, boolean incoming) {
    if (!this.isAccessGroupAdded(id)){
      this.accessGroups.addElement(new AccessGroup(id, incoming));
    }

  }
  private boolean isAccessGroupAdded(String id)  {
    int lastIndex = this.accessGroups.size();
    int i=0;
    while (i<lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(i)).getId().equalsIgnoreCase(id))
        return true;
      i++;
    }
    return false;
  }
  public void removeAccessGroup(String id) {
    if (this.indexOfAccessGroup(id) != -1)
      this.accessGroups.removeElementAt(this.indexOfAccessGroup(id));
  }
  private int indexOfAccessGroup(String id)  {
    int lastIndex = this.accessGroups.size();
    int index = 0;
    while (index < lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(index)).getId().equalsIgnoreCase(id))
        return index;
      index++;
    }
    return -1;
  }
}

