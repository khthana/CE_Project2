package netmaker;

import java.util.Vector;

public class SwitchEthINF {
  private boolean shutdown = true;
  private String ipAddress = "";
  private String subnet = "";
  private String portChannelID = "";
  private String interfaceName = "";
  private boolean connected = false;
  private String mode = "access";
  private Vector vlanSTPs = new Vector();

  public SwitchEthINF() {
  }

  public SwitchEthINF(String interfaceName) {
    this.setInterfaceName(interfaceName);
    this.vlanSTPs.addElement(new VlanSTP("1"));
  }

  public String getPortChannelID() {
    return portChannelID;
  }

  public void setPortChannelID(String portChannelID) {
    this.portChannelID = portChannelID;
  }



  public java.util.Vector getVlanSTPs() {
    return vlanSTPs;
  }

  public void setVlanSTPs(java.util.Vector vlanSTPs) {
    this.vlanSTPs = vlanSTPs;
  }

  public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public boolean isShutdown() {
    return shutdown;
  }

  public void setShutdown(boolean shutdown) {
    this.shutdown = shutdown;
  }

  public String getInterfaceName() {
    return interfaceName;
  }

  public void setInterfaceName(String interfaceName) {
    this.interfaceName = interfaceName;
  }
  public boolean isConnected() {
    return connected;
  }
  public void setConnected(boolean connected) {
    this.connected = connected;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public String getMode() {
    return mode;
  }
  public void setMode(String mode) {
    this.mode = mode;
  }
//////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////function////////////////////////////////////////////////

  public void addVlan(VlanSTP vlanSTP){// add vlan of membership of switchport
    VlanSTP vlanSTPTemp;
    boolean chk = true;
    for(int i=0;i<vlanSTPs.size();i++){
      vlanSTPTemp = (VlanSTP)vlanSTPs.elementAt(i);
      if(vlanSTPTemp.getVlanID().equals(vlanSTP.getVlanID())){
        vlanSTPs.remove(i);
        vlanSTPs.add(i,vlanSTP);
        chk = false;
      }
    }
    if(chk){
      vlanSTPs.addElement(vlanSTP);
    }
  }
  public void removeVlan(String id) {// remove vlan from membership of switchport
    if (this.indexOfVlan(id) != (-1)){
      this.vlanSTPs.remove(this.indexOfVlan(id));
    }
  }
  public void removeAllVlan(){
    this.vlanSTPs.removeAllElements();
  }
  public int indexOfVlan(String id){// search index of vlan
    int lastIndex = this.vlanSTPs.size();
    int index = 0;
    while (index < lastIndex){
      if (((VlanSTP)this.vlanSTPs.elementAt(index)).getVlanID().equalsIgnoreCase(id))
        return index;
      index++;
    }
    return -1;
  }

}
