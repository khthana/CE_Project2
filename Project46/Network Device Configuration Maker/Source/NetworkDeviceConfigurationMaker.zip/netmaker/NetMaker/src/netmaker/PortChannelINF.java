package netmaker;
import java.util.*;

public class PortChannelINF {

//  private SwitchPort switchPort;
  private Boolean shutdown;
  private String ipAddress = "";
  private String id = "";
  private String mode = "access";
  private Vector vlanSTPs = new Vector();
  private String subnet = "";
  public PortChannelINF() {
  }
  public PortChannelINF(String id){ //overide from constructor
    this.setId(id);
    this.vlanSTPs.addElement(new VlanSTP("1"));
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }
  public Boolean getShutdown() {
    return shutdown;
  }
  public void setShutdown(Boolean shutdown) {
    this.shutdown = shutdown;
  }
  public void setMode(String mode) {
    this.mode = mode;
  }
  public String getMode() {
    return mode;
  }
  public void setVlanSTPs(java.util.Vector vlanSTPs) {
    this.vlanSTPs = vlanSTPs;
  }
  public java.util.Vector getVlanSTPs() {
    return vlanSTPs;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public String getSubnet() {
    return subnet;
  }
//////////////////////////////////////////////////////////////
  public void addVlan(VlanSTP vlanSTP){// add vlan of membership of switchport
  VlanSTP vlanSTPTemp;
  boolean chk = true;
  for(int i=0;i<vlanSTPs.size();i++){
    vlanSTPTemp = (VlanSTP)vlanSTPs.elementAt(i);
    if(vlanSTPTemp.getVlanID().equals(vlanSTP.getVlanID())){
      vlanSTPs.remove(i);
      vlanSTPs.add(i,vlanSTP);
      chk = false;
    }
  }
  if(chk){
    vlanSTPs.addElement(vlanSTP);
  }
  }
  public void removeVlan(String id) {// remove vlan from membership of switchport
    if (this.indexOfVlan(id) != (-1)){
      this.vlanSTPs.remove(this.indexOfVlan(id));
    }
  }
  public void removeAllVlan(){
    this.vlanSTPs.removeAllElements();
  }
  public int indexOfVlan(String id){// search index of vlan
    int lastIndex = this.vlanSTPs.size();
    int index = 0;
    while (index < lastIndex){
      if (((VlanSTP)this.vlanSTPs.elementAt(index)).getVlanID().equalsIgnoreCase(id))
        return index;
      index++;
    }
    return -1;
  }

}