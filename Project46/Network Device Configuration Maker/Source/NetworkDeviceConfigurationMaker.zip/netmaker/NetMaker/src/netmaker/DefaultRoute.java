package netmaker;

import java.util.Vector;

public class DefaultRoute {
  private String route = "";
  public DefaultRoute() {
  }
  public String getRoute() {
    return route;
  }
  public void setRoute(String route) {
    this.route = route;
  }

}