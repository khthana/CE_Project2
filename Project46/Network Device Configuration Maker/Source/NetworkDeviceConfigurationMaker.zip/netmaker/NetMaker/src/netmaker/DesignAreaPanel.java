package netmaker;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.JPanel;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DesignAreaPanel extends JPanel {
  private XYLayout xYLayout1 = new XYLayout();
  public static Vector vImgSwitch = new Vector();//add element in Frame1
  public static Vector vImgRouter = new Vector();
  int popup=0;
  int dx,dy,ddx,ddy;
  String chkColor,chkName;
  boolean pressin = false;
  SwitchImg simg;
  Switch sw;
  RouterImg rimg;
  Router rt;

  JPopupMenu jPopupMenu1 = new JPopupMenu();
  JPopupMenu jPopupMenu2 = new JPopupMenu();
  JPopupMenu jPopupMenu3 = new JPopupMenu();
  JMenuItem configSW;
  JMenuItem deleteSW;
  JMenuItem configRT;
  JMenuItem deleteRT;
  JMenuItem createVLAN;
  JMenuItem etherchannel;
  JMenuItem createConfigSwitch;
  JMenuItem createConfigRouter;
  JMenuItem telnetSW;
  JMenuItem consoleSW;
  JMenuItem telnetRouter;
  JMenuItem consoleRouter;
  JMenuItem createACLSwitch;
  JMenuItem createACLRouter;
  JMenuItem routingProtocol;
  JMenuItem autonomousNumber;
  public DesignAreaPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    configSW = new JMenuItem("Config");
    createVLAN = new JMenuItem("Create/Remove VLAN");
    deleteSW = new JMenuItem("Delete");
    configRT = new JMenuItem("Config");
    deleteRT = new JMenuItem("Delete");
    etherchannel = new JMenuItem("EtherChannel");
    createConfigSwitch = new JMenuItem("Create Configuration file");
    createConfigRouter = new JMenuItem("Create Configuration file");
    telnetSW = new JMenuItem("Telnet");
    consoleSW = new JMenuItem("Console");
    telnetRouter = new JMenuItem("Telnet");
    consoleRouter = new JMenuItem("Console");
    createACLSwitch = new JMenuItem("Create ACL");
    createACLRouter = new JMenuItem("Create ACL");
    routingProtocol = new JMenuItem("Routing Protocol");
    autonomousNumber = new JMenuItem("Autonomous Number");

    this.setBackground(SystemColor.inactiveCaptionText);
    routingProtocol.setBackground(new Color(223,223,223));
    configSW.setBackground(new Color(223,223,223));
    createVLAN.setBackground(new Color(223,223,223));
    etherchannel.setBackground(new Color(223,223,223));
    deleteSW.setBackground(new Color(223,223,223));
    configRT.setBackground(new Color(223,223,223));
    deleteRT.setBackground(new Color(223,223,223));
    createConfigSwitch.setBackground(new Color(223,223,223));
    createConfigRouter.setBackground(new Color(223,223,223));
    telnetSW.setBackground(new Color(223,223,223));
    consoleSW.setBackground(new Color(223,223,223));
    telnetRouter.setBackground(new Color(223,223,223));
    consoleRouter.setBackground(new Color(223,223,223));
    createACLSwitch.setBackground(new Color(223,223,223));
    createACLRouter.setBackground(new Color(223,223,223));
    autonomousNumber.setBackground(new Color(223,223,223));
    jPopupMenu1.setBackground(new Color(223,223,223));
    jPopupMenu2.setBackground(new Color(223, 223, 223));

    this.setLayout(xYLayout1);
    this.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        this_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        this_mouseReleased(e);
      }
    });
    this.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        this_mouseDragged(e);
      }
    });
//**************///*********************///******************//
    configSW.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        configSW_actionPerformed(e);
      }
    });

    deleteSW.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteSW_actionPerformed(e);
      }
    });
    deleteRT.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteRT_actionPerformed(e);
      }
    });

    createVLAN.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        vLanSW_actionPerformed(e);
      }
    });
    etherchannel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        etherchannel_actionPerformed(e);
      }
    });
    this.configRT.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        configRT_actionPerformed(e);
      }
    });
    this.telnetSW.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        telnetSW_actionPerformed(e);
      }
    });
    this.consoleSW.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        consoleSW_actionPerformed(e);
      }
    });
    this.telnetRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        telnetRouter_actionPerformed(e);
      }
    });
    this.consoleRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        consoleRouter_actionPerformed(e);
      }
    });
    this.createConfigSwitch.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        createConfigSwitch_actionPerformed(e);
      }
    });
    this.createConfigRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        createConfigRouter_actionPerformed(e);
      }
    });
    this.createACLSwitch.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        createACLSwitch_actionPerformed(e);
      }
    });
    this.createACLRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        createACLRouter_actionPerformed(e);
      }
    });
    this.routingProtocol.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        routingProtocol_actionPerformed(e);
      }
    });
    this.autonomousNumber.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        autonomousNumber_actionPerformed(e);
      }
    });

    jPopupMenu1.add(configSW);
    jPopupMenu1.add(createVLAN);
    jPopupMenu1.add(etherchannel);
    jPopupMenu1.add(telnetSW);
    jPopupMenu1.add(consoleSW);
    jPopupMenu1.add(createACLSwitch);
    jPopupMenu1.add(deleteSW);
    jPopupMenu1.addSeparator();
    jPopupMenu1.add(createConfigSwitch);
    jPopupMenu2.add(configRT);
    jPopupMenu2.add(routingProtocol);
    jPopupMenu2.add(telnetRouter);
    jPopupMenu2.add(consoleRouter);
    jPopupMenu2.add(this.autonomousNumber);
    jPopupMenu2.add(createACLRouter);
    jPopupMenu2.add(deleteRT);
    jPopupMenu2.addSeparator();
     jPopupMenu2.add(createConfigRouter);


//***********************//*************************//************************//
  }

  public void paintComponent(Graphics g){
    super.paintComponent(g);
    g.setColor(Color.black);
    for (int i=0; i < Frame1.vRouter.size(); i++){
      Router rt1 = (Router)Frame1.vRouter.elementAt(i);
      RouterImg r1 = (RouterImg)vImgRouter.elementAt(i);
      try{
        g.drawImage(r1.getImge(),r1.getXPos(),r1.getYPos(),this);
        g.drawString(rt1.getHostName(),r1.getXPos(),r1.getYPos()+r1.getHigh());
 /*       Vector vConnectRouter = rt1.getConnectingRouter();
        for(int j = 0 ; j < vConnectRouter.size(); j ++){
          if(vConnectRouter.elementAt(j)!= null){
            RouterImg r2 = (RouterImg)vConnectRouter.elementAt(j);
            g.drawLine(r1.getXPos()+25,r1.getYPos()+15,r2.getXPos()+25,r2.getYPos()+15);
            g.drawLine(r1.getXPos()+26,r1.getYPos()+16,r2.getXPos()+26,r2.getYPos()+16);
          }
        }
        Vector vConnectSwitch = rt1.getConnectingSwitch();
        for(int j = 0 ;j <= vConnectSwitch.size();j++){
          if(vConnectSwitch.elementAt(j) != null){
            SwitchImg s2 = (SwitchImg)vConnectSwitch.elementAt(j);
            g.drawLine(r1.getXPos()+25,r1.getYPos()+15,s2.getXPos()+25,s2.getYPos()+15);
            g.drawLine(r1.getXPos()+26,r1.getYPos()+16,s2.getXPos()+26,s2.getYPos()+16);
            //g.drawString(str,s1.getXPos(),s1.getYPos());
          }
        }
*/
      }
      catch(Exception e){
      }
    }
    for (int i=0; i < Frame1.vSwitch.size(); i++){
      Switch sw1 = (Switch)Frame1.vSwitch.elementAt(i);
      SwitchImg s1 = (SwitchImg)vImgSwitch.elementAt(i);
      try{
        g.drawImage(s1.getImge(),s1.getXPos(),s1.getYPos(),this);
        g.drawString(sw1.getHostName(),s1.getXPos(),s1.getYPos()+s1.getHigh());
/*        Vector vConnectSwitch = sw1.getConnectingSwitch();
        for(int j = 0 ;j <= vConnectSwitch.size();j++){
          if(vConnectSwitch.elementAt(j) != null){
            SwitchImg s2 = (SwitchImg)vConnectSwitch.elementAt(j);
            g.drawLine(s1.getXPos()+25,s1.getYPos()+15,s2.getXPos()+25,s2.getYPos()+15);
            g.drawLine(s1.getXPos()+26,s1.getYPos()+16,s2.getXPos()+26,s2.getYPos()+16);
            //g.drawString(str,s1.getXPos(),s1.getYPos());
          }
        }
        Vector vConnectRouter = sw1.getConnectingRouter();
        for(int j = 0 ; j < vConnectRouter.size(); j ++){
          if(vConnectRouter.elementAt(j)!= null){
            RouterImg r2 = (RouterImg)vConnectRouter.elementAt(j);
            g.drawLine(s1.getXPos()+25,s1.getYPos()+15,r2.getXPos()+25,r2.getYPos()+15);
            g.drawLine(s1.getXPos()+26,s1.getYPos()+16,r2.getXPos()+26,r2.getYPos()+16);
          }
        }
*/
      }
      catch(Exception e){
      }
    }//end for switch 1
    for(int i=0;i<Frame1.vConnection.size();i++){
      Connection connect = (Connection)Frame1.vConnection.elementAt(i);
      for(int j=0;j<Frame1.vSwitch.size();j++){
        for(int k=0;k<Frame1.vSwitch.size();k++){
          Switch swTemp1 = (Switch)Frame1.vSwitch.elementAt(j);
          Switch swTemp2 = (Switch)Frame1.vSwitch.elementAt(k);
          if(connect.getCon1DeviceID().equals(swTemp1.getHostName())
             && connect.getCon2DeviceID().equals(swTemp2.getHostName())){
            SwitchImg s1 = (SwitchImg)this.vImgSwitch.elementAt(j);
            SwitchImg s2 = (SwitchImg)this.vImgSwitch.elementAt(k);
//            g.drawLine(s1.getXPos()+25,s1.getYPos()+15,s2.getXPos()+25,s2.getYPos()+15);
//            g.drawLine(s1.getXPos()+26,s1.getYPos()+16,s2.getXPos()+26,s2.getYPos()+16);

            int x1 = s1.getXPos()+25;
            int y1 = s1.getYPos()+15;
            int x2 = s2.getXPos()+25;
            int y2 = s2.getYPos()+15;
            this.drawLine(x1,x2,y1,y2,g,connect);

          }
        }
      }
      for(int j=0;j<Frame1.vSwitch.size();j++){
        for(int k=0;k<Frame1.vRouter.size();k++){
          Switch swTemp1 = (Switch)Frame1.vSwitch.elementAt(j);
          Router rtTemp2 = (Router)Frame1.vRouter.elementAt(k);
          if(connect.getCon1DeviceID().equals(swTemp1.getHostName())
             && connect.getCon2DeviceID().equals(rtTemp2.getHostName())){
            SwitchImg s1 = (SwitchImg)this.vImgSwitch.elementAt(j);
            RouterImg r2 = (RouterImg)this.vImgRouter.elementAt(k);
//            g.drawLine(s1.getXPos()+25,s1.getYPos()+15,r2.getXPos()+25,r2.getYPos()+15);
//            g.drawLine(s1.getXPos()+26,s1.getYPos()+16,r2.getXPos()+26,r2.getYPos()+16);
            int x1 = s1.getXPos()+25;
            int y1 = s1.getYPos()+15;
            int x2 = r2.getXPos()+25;
            int y2 = r2.getYPos()+15;
            this.drawLine(x1,x2,y1,y2,g,connect);
          }
        }
      }
      for(int j=0;j<Frame1.vRouter.size();j++){
        for(int k=0;k<Frame1.vSwitch.size();k++){
          Router rtTemp1 = (Router)Frame1.vRouter.elementAt(j);
          Switch swTemp2 = (Switch)Frame1.vSwitch.elementAt(k);
          if(connect.getCon1DeviceID().equals(rtTemp1.getHostName())
             && connect.getCon2DeviceID().equals(swTemp2.getHostName())){
            RouterImg r1 = (RouterImg)this.vImgRouter.elementAt(j);
            SwitchImg s2 = (SwitchImg)this.vImgSwitch.elementAt(k);
//            g.drawLine(r1.getXPos()+25,r1.getYPos()+15,s2.getXPos()+25,s2.getYPos()+15);
//            g.drawLine(r1.getXPos()+26,r1.getYPos()+16,s2.getXPos()+26,s2.getYPos()+16);
            int x1 = r1.getXPos()+25;
            int y1 = r1.getYPos()+15;
            int x2 = s2.getXPos()+25;
            int y2 = s2.getYPos()+15;
            this.drawLine(x1,x2,y1,y2,g,connect);
          }
        }
      }
      for(int j=0;j<Frame1.vRouter.size();j++){
        for(int k=0;k<Frame1.vRouter.size();k++){
          Router rtTemp1 = (Router)Frame1.vRouter.elementAt(j);
          Router rtTemp2 = (Router)Frame1.vRouter.elementAt(k);
          if(connect.getCon1DeviceID().equals(rtTemp1.getHostName())
             && connect.getCon2DeviceID().equals(rtTemp2.getHostName())){
            RouterImg r1 = (RouterImg)this.vImgRouter.elementAt(j);
            RouterImg r2 = (RouterImg)this.vImgRouter.elementAt(k);
//            g.drawLine(r1.getXPos()+25,r1.getYPos()+15,r2.getXPos()+25,r2.getYPos()+15);
//            g.drawLine(r1.getXPos()+26,r1.getYPos()+16,r2.getXPos()+26,r2.getYPos()+16);
            int x1 = r1.getXPos()+25;
            int y1 = r1.getYPos()+15;
            int x2 = r2.getXPos()+25;
            int y2 = r2.getYPos()+15;
            this.drawLine(x1,x2,y1,y2,g,connect);
          }
        }
      }
    }

  }
  void this_mouseDragged(MouseEvent e) {
    if (pressin) {
      // in  Frame
      dx = e.getX();
      dy = e.getY();
      //        int ddx = simg.getXPos()-e.getX();
      //        int ddy = simg.getYPos()-e.getY();
      if ((rimg!=null) && (dx+ddx < this.getWidth()-52) && (dx+ddx >= 14)&& (dy+ddy < this.getHeight()-44) && (dy+ddy >= 2)){
        //setposition
        rimg.setXPos(e.getX()+ddx);
        rimg.setYPos(e.getY()+ddy);
      /*         for (int i=0; i<this.vImgInt.size(); i++) {
      InterfaceImg iimg = (InterfaceImg)this.vImgInt.elementAt(i);
      if (iimg.getType()==2) {
      iimg.setXPos2(cimg.getXPos()+(int)(cimg.getWide()/2));
      iimg.setYPos2(cimg.getYPos()+(int)(cimg.getHigh()/2));
      }
      }
        */         repaint();
      }
      else if ((simg!=null) && (dx+ddx < this.getWidth()-60) && (dx+ddx >= 2) && (dy+ddy < this.getHeight()-40) && (dy+ddy >= 2)){
        //setposition
        simg.setXPos(e.getX()+ddx);
        simg.setYPos(e.getY()+ddy);
        /**         for (int i=0; i<this.vImgInt.size(); i++) {
       InterfaceImg iimg = (InterfaceImg)this.vImgInt.elementAt(i);
       if (iimg.getType()==1) {
       for (int j=0; j<Frame1.vSwitch.size(); j++) {
       SwitchImg si = (SwitchImg)this.vImgSwitch.elementAt(j);
       if (si.equals(simg)) {
       Switch sw = (Switch)Frame1.vSwitch.elementAt(j);
       for (int k=0; k<sw.getVIntSwitch().size(); k++) {
       Interface inf = (Interface)sw.getVIntSwitch().elementAt(k);
       if (inf.equals(iimg.getInt1())) {
       iimg.setXPos1(simg.getXPos()+(int)(simg.getWide()/2));
       iimg.setYPos1(simg.getYPos()+(int)(simg.getHigh()/2));
       }
                 else if (inf.equals(iimg.getInt2())) {
                 iimg.setXPos2(simg.getXPos()+(int)(simg.getWide()/2));
                 iimg.setYPos2(simg.getYPos()+(int)(simg.getHigh()/2));
                 }
                 }
                 }
                 }
                 }
                 else {
                 for (int j=0; j<Frame1.vSwitch.size(); j++) {
                 SwitchImg si = (SwitchImg)this.vImgSwitch.elementAt(j);
                 if (si.equals(simg)) {
                 Switch sw = (Switch)Frame1.vSwitch.elementAt(j);
                 for (int k=0; k<sw.getVIntCom().size(); k++) {
                 Interface inf = (Interface)sw.getVIntCom().elementAt(k);
                 if (inf.equals(iimg.getInt1())) {
                 iimg.setXPos1(simg.getXPos()+(int)(simg.getWide()/2));
                 iimg.setYPos1(simg.getYPos()+(int)(simg.getHigh()/2));
                 }
                 }
                 }
                 }
                 }
                 }
                 **/
        repaint();
      }
    }
  }

  void this_mousePressed(MouseEvent e) {
    //Left Click
    if(e.getModifiers()==16){
      int i=0,j=0;
      pressin = false;
      rimg = null;
      simg = null;
      while((i < vImgRouter.size()) && (!pressin)){
        rimg = (RouterImg)vImgRouter.elementAt(i);
        //position at mouse press
        dx = e.getX();
        dy = e.getY();
        if ((dx < rimg.getXPos()+rimg.getWide()) && (dx > rimg.getXPos()) && (dy > rimg.getYPos()) && (dy < rimg.getYPos() + rimg.getHigh())){
          pressin = true;
          ddx = rimg.getXPos()-e.getX();
          ddy = rimg.getYPos()-e.getY();
        }
        else rimg = null;
        i++;
      }
      while((j < vImgSwitch.size()) && (!pressin)){
        simg = (SwitchImg)vImgSwitch.elementAt(j);
        //position at mouse press
        dx = e.getX();
        dy = e.getY();
        if ((dx < simg.getXPos()+simg.getWide()) && (dx > simg.getXPos()) && (dy > simg.getYPos()) && (dy < simg.getYPos() + simg.getHigh())){
          pressin = true;
          ddx = simg.getXPos()-e.getX();
          ddy = simg.getYPos()-e.getY();
        }
        else simg = null;
        j++;
      }
      /**if (Frame1.drawInt) {
     pressin = true;
     if (simg!=null) {
     intimg = new InterfaceImg();
     intimg.setXPos1((int)simg.getXPos()+(simg.getWide()/2));
     intimg.setYPos1((int)simg.getYPos()+(simg.getHigh()/2));
     }
     }**/
    }
    // Right Click
    else {
      //      System.out.println("show menu");
      System.out.println(e.getX()+" - "+e.getY());
      int i=0;
      int j=0;
      int k=0;
      rimg = null;
      simg = null;
      popup=0;
      // Check Click on Workstation
      while((i < vImgRouter.size()) && (popup==0)){
        rimg = (RouterImg)vImgRouter.elementAt(i);
        rt = (Router)Frame1.vRouter.elementAt(i);
        //position at mouse press
        dx = e.getX();
        dy = e.getY();
        if ((dx < rimg.getXPos()+rimg.getWide()) && (dx > rimg.getXPos()) && (dy > rimg.getYPos()) && (dy < rimg.getYPos() + rimg.getHigh())){
          popup = 2;
          ddx = rimg.getXPos()-e.getX();
          ddy = rimg.getYPos()-e.getY();
        }
        else rimg = null;
        i++;
      }
      // Check Click on Switch
      while((j < vImgSwitch.size()) && (popup==0)){
        Switch sw2;
        sw2 = (Switch)Frame1.vSwitch.elementAt(j);
        simg = (SwitchImg)vImgSwitch.elementAt(j);

        //position at mouse press
        dx = e.getX();
        dy = e.getY();
        sw=sw2;
        chkName = (String)sw2.getHostName();
        if ((dx < simg.getXPos()+simg.getWide()) && (dx > simg.getXPos()) && (dy > simg.getYPos()) && (dy < simg.getYPos() + simg.getHigh())){
          popup = 1;
          ddx = simg.getXPos()-e.getX();
          ddy = simg.getYPos()-e.getY();
        }
        else simg = null;
        j++;
      }
      // Check Click on Interface
      /**while((k < vImgInt.size()) && (popup==0)){
     intimg = (InterfaceImg)vImgInt.elementAt(k);
     //position at mouse press
     dx = e.getX();
     dy = e.getY();
     if (intimg.isSelected(dx,dy)){
     popup = 3;
     System.out.println("Selected");
     //            ddx = cimg.getXPos()-e.getX();
     //            ddy = cimg.getYPos()-e.getY();
     }
     else intimg = null;
     k++;
     }**/
    }
  }

  void this_mouseReleased(MouseEvent e) {
    boolean drawn = false;
    int intx2,inty2;
    Switch sw1=null,sw2=null;
    Router rt1;
    SwitchImg si = null;
    RouterImg ri = null;
    //    System.out.println("Releasing");
    // Check Right Click
    if (e.isPopupTrigger()) {
      if (popup==1) {
        jPopupMenu1.show(e.getComponent(), e.getX(), e.getY());
      }
      else if (popup==2) {

        jPopupMenu2.show(e.getComponent(), e.getX(), e.getY());
      }
      popup=0;
    }
    // Check "Draw Interface"
    pressin = false;
    repaint();
  }

  public void repaintView() {
    repaint();
  }
  void vLanSW_actionPerformed(ActionEvent e) {
    CreateVlan dialog = new CreateVlan();
    dialog.chkSW(chkName);
    dialog.showDialog1();

  }
  void etherchannel_actionPerformed(ActionEvent e)
  {
    EtherChannel ether = new EtherChannel(chkName);
    ether.showDialog();
  }

  void configSW_actionPerformed(ActionEvent e) {
    SwitchDialog swDialog = new SwitchDialog();
    swDialog.chkSW(sw);
    swDialog.showDialog1();
    repaint();
  }
  void deleteSW_actionPerformed(ActionEvent e) {
    int numdel = 0;
    for (int i=0; i<Frame1.vSwitch.size(); i++) {
      Switch sw_temp = (Switch)Frame1.vSwitch.elementAt(i);
      for(int j=0 ; j < sw_temp.getConnectingSwitch().size() ; j++){

      }

    }
    for (int i=0; i<Frame1.vSwitch.size(); i++) {
      Switch sw = (Switch)Frame1.vSwitch.elementAt(i);
      try {
        SwitchImg swimg = (SwitchImg)this.vImgSwitch.elementAt(i);
        if (swimg.equals(simg)) {
          numdel = i;
          System.out.println("Delete Switch: "+sw.getHostName());
          i=Frame1.vSwitch.size();
        }
      }
      catch (Exception exp) {}
    }

    for(int i=0;i<Frame1.vSwitch.size();i++){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(i);
      SwitchImg simg = (SwitchImg)this.vImgSwitch.elementAt(numdel);
      Vector vConnectSwitch = sw.getConnectingSwitch();
      for(int k = 0;k< vConnectSwitch.size();k++){
        SwitchImg simg2 = (SwitchImg)vConnectSwitch.elementAt(k);
        if(simg==simg2){
          sw.removeConnectSwitch(k);
          i--;
        }
      }
    }
    Switch delSwitch = (Switch)Frame1.vSwitch.elementAt(numdel);
    for(int num=0;num < Frame1.vConnection.size();num++)
    {
      Connection connect = (Connection)Frame1.vConnection.elementAt(num);
      if(connect.getCon1DeviceID().equals(delSwitch.getHostName())
         || connect.getCon2DeviceID().equals(delSwitch.getHostName()))
      {
        Frame1.vConnection.removeElement(connect);
        num--;
      }

    }

    Frame1.vSwitch.removeElementAt(numdel);
    this.vImgSwitch.removeElementAt(numdel);
    repaint();

  }
  void deleteRT_actionPerformed(ActionEvent e) {
    int numdel = 0;

    for (int i=0; i<Frame1.vRouter.size(); i++) {
      Router rt = (Router)Frame1.vRouter.elementAt(i);
      try {
        RouterImg rtimg = (RouterImg)this.vImgRouter.elementAt(i);
        if (rtimg.equals(rimg)) {
          numdel = i;
//          System.out.println("Delete Router: "+rt.getName());
          for (int j=0; j<Frame1.vRouter.size(); j++) {
            Router rt_tmp = (Router)Frame1.vRouter.elementAt(j);
          }
          i=Frame1.vRouter.size();
        }
      }
      catch (Exception exp) {}
    }

    for(int i=0;i<Frame1.vRouter.size();i++){
      Router rt = (Router)Frame1.vRouter.elementAt(i);
      RouterImg rimg = (RouterImg)this.vImgRouter.elementAt(numdel);
      Vector vConnectRouter = rt.getConnectingRouter();
      for(int k = 0;k< vConnectRouter.size();k++){
        RouterImg rimg2 = (RouterImg)vConnectRouter.elementAt(k);
        if(rimg==rimg2){
          rt.removeConnectRouter(k);
          i--;
        }
      }
    }
    Router delRouter = (Router)Frame1.vRouter.elementAt(numdel);
    for(int num=0;num < Frame1.vConnection.size();num++)
    {
      Connection connect = (Connection)Frame1.vConnection.elementAt(num);
      if(connect.getCon1DeviceID().equals(delRouter.getHostName())
         || connect.getCon2DeviceID().equals(delRouter.getHostName()))
      {
        Frame1.vConnection.removeElement(connect);
        num--;
      }
    }

    Frame1.vRouter.removeElementAt(numdel);
    this.vImgRouter.removeElementAt(numdel);
    repaint();
  }

  void configRT_actionPerformed(ActionEvent e)
  {
    RouterDialog rtDialog = new RouterDialog(chkName);
    rtDialog.chkRT(rt);
    rtDialog.showDialog1();

  }
  void telnetSW_actionPerformed(ActionEvent e)
  {
    TelnetSwitch telnet = new TelnetSwitch();
    telnet.setSwitch(sw);
    telnet.showDialog();
  }
  void consoleSW_actionPerformed(ActionEvent e)
  {
    ConsoleSwitch console = new ConsoleSwitch();
    console.setSwitch(sw);
    console.showDialog();
  }
  void telnetRouter_actionPerformed(ActionEvent e)
  {
    TelnetRouter telnet = new TelnetRouter();
    telnet.setRouter(rt);
    telnet.showDialog();
  }
  void consoleRouter_actionPerformed(ActionEvent e)
  {
    ConsoleRouter console = new ConsoleRouter();
    console.setRouter(rt);
    console.showDialog();
  }
  void createConfigSwitch_actionPerformed(ActionEvent e)
  {
    sw.showDetail();
    sw.genConfigFile();
  }
  void createConfigRouter_actionPerformed(ActionEvent e)
  {
    rt.genConfigFile();
  }
  void createACLSwitch_actionPerformed(ActionEvent e)
  {
    AclDialog aclDialog = new AclDialog();
    aclDialog.setSwitch(sw);
    aclDialog.showDialog();
  }
  void routingProtocol_actionPerformed(ActionEvent e)
  {
    RoutingProtocolDialog dialog = new RoutingProtocolDialog();
    dialog.setRouter(rt);
    dialog.showDialog();
  }
  void createACLRouter_actionPerformed(ActionEvent e)
  {
    AclDialog aclDialog = new AclDialog();
    aclDialog.setRouter(rt);
    aclDialog.showDialog();
  }
  void autonomousNumber_actionPerformed(ActionEvent e)
  {
    AutonomousDialog dialog = new AutonomousDialog();
    dialog.setRouter(rt);
    dialog.showDialog();
  }
  void drawLine(int x1,int x2,int y1,int y2,Graphics g,Connection connect){
    {                g.drawLine(x1-1,y1,x2-1,y2);
                g.drawLine(x1,y1-1,x2,y2-1);
                g.drawLine(x1,y1,x2,y2);
                g.drawLine(x1+1,y1,x2+1,y2);
                g.drawLine(x1,y1+1,x2,y2+1);

                String infName1 = "",infName2 = "";
                for(int l = 0 ;l <connect.getCon1InfName().size();l++){
                  String connection1 = (String)connect.getCon1InfName().elementAt(l);
                  String connection2 = (String)connect.getCon2InfName().elementAt(l);
                  if(l==0){
                  if(connection1.startsWith("F")){
                    infName1 = infName1+"F"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection1.startsWith("G")){
                    infName1 = infName1+"G"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection1.startsWith("S")){
                    infName1 = infName1+"S"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection2.startsWith("F")){
                    infName2 = infName2+"F"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  if(connection2.startsWith("G")){
                    infName2 = infName2+"G"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  if(connection2.startsWith("S")){
                    infName2 = infName2+"S"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  }else{
                  if(connection1.startsWith("F")){
                    infName1 = infName1+",F"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection1.startsWith("G")){
                    infName1 = infName1+",G"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection1.startsWith("S")){
                    infName1 = infName1+",S"+connection1.substring(connection1.indexOf("0"),connection1.length());
                  }
                  if(connection2.startsWith("F")){
                    infName2 = infName2+",F"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  if(connection2.startsWith("G")){
                    infName2 = infName2+",G"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  if(connection2.startsWith("S")){
                    infName2 = infName2+",S"+connection2.substring(connection2.indexOf("0"),connection2.length());
                  }
                  }
                }
                double temp1 = 0;
                if( (y1-y2) != 0){
                  temp1 =  Math.atan2(x1-x2,y1-y2);
                  System.out.println(" x1 = "+x1+" x2 = "+x2+" y1 = "+y1+" y2 = "+y2+" (x1-x2)/(y1-y2) = "+temp1);

                  g.setColor(Color.blue);
                  if( temp1 > 0.167*0 && temp1 <= 0.167*1){
                    g.drawString(infName1,x1+5,y1-20);
                    g.drawString(infName2,x2-25,y2+50);
                  }
                  else if( temp1 > 0.167*1 && temp1 <= 0.167*2){
                    g.drawString(infName1,x1+5,y1-20);
                    g.drawString(infName2,x2-20,y2+50);
                  }
                  else if( temp1 > 0.167*2 && temp1 <= 0.167*3){
                    g.drawString(infName1,x1,y1-20);
                    g.drawString(infName2,x2-15,y2+50);
                  }
                  else if( temp1 > 0.167*3 && temp1 <= 0.167*4){
                    g.drawString(infName1,x1-5,y1-20);
                    g.drawString(infName2,x2-10,y2+50);
                  }
                  else if( temp1 > 0.167*4 && temp1 <= 0.167*5){
                    g.drawString(infName1,x1-10,y1-20);
                    g.drawString(infName2,x2-5,y2+45);
                  }
                  else if( temp1 > 0.167*5 && temp1 <= 0.167*6){
                    g.drawString(infName1,x1-15,y1-20);
                    g.drawString(infName2,x2,y2+45);
                  }
                  else if( temp1 > 0.167*6 && temp1 <= 0.167*7){
                    g.drawString(infName1,x1-20,y1-20);
                    g.drawString(infName2,x2+5,y2+45);
                  }
                  else if( temp1 > 0.167*7 && temp1 <= 0.167*8){
                    g.drawString(infName1,x1-25,y1-20);
                    g.drawString(infName2,x2+10,y2+40);
                  }
                  else if( temp1 > 0.167*8 && temp1 <= 0.167*9){
                    g.drawString(infName1,x1-30,y1-15);
                    g.drawString(infName2,x2+20,y2+35);
                  }
                  else if( temp1 > 0.167*9 && temp1 <= 0.167*10){
                    g.drawString(infName1,x1-35,y1-10);
                    g.drawString(infName2,x2+30,y2+25);
                  }
                  else if( temp1 > 0.167*10 && temp1 <= 0.167*11){
                    g.drawString(infName1,x1-50,y1+20);
                    g.drawString(infName2,x2+25,y2-20);
                  }
                  else if( temp1 > 0.167*11 && temp1 <= 0.167*12){
                    g.drawString(infName1,x1-50,y1+30);
                    g.drawString(infName2,x2+15,y2-20);
                  }
                  else if( temp1 > 0.167*12 && temp1 <= 0.167*13){
                    g.drawString(infName1,x1-40,y1+35);
                    g.drawString(infName2,x2+5,y2-20);
                  }
                  else if( temp1 > 0.167*13 && temp1 <= 0.167*14){
                    g.drawString(infName1,x1-35,y1+40);
                    g.drawString(infName2,x2,y2-20);
                  }
                  else if( temp1 > 0.167*14 && temp1 <= 0.167*15){
                    g.drawString(infName1,x1-25,y1+45);
                    g.drawString(infName2,x2-5,y2-25);
                  }
                  else if( temp1 > 0.167*15 && temp1 <= 0.167*16){
                    g.drawString(infName1,x1-15,y1+50);
                    g.drawString(infName2,x2-10,y2-30);
                  }
                  else if( temp1 > 0.167*16 && temp1 <= 0.167*17){
                    g.drawString(infName1,x1-10,y1+50);
                    g.drawString(infName2,x2-15,y2-35);
                  }
                  else if( temp1 > 0.167*17 && temp1 <= 0.167*18){
                    g.drawString(infName1,x1-5,y1+50);
                    g.drawString(infName2,x2-20,y2-35);
                  }
                  else if( temp1 > 0.167*18 && temp1 <= 0.167*19){
                    g.drawString(infName1,x1,y1+50);
                    g.drawString(infName2,x2-25,y2-35);
                  }
                  else if( temp1 > 0.167*19 && temp1 <= 3.15){
                    g.drawString(infName1,x1-5,y1+50);
                    g.drawString(infName2,x2-25,y2-40);
                  }
                  ////////////////////////////////////////////////
                  else if( temp1 > 0.167*-1 && temp1 <= 0.167*0){
                    g.drawString(infName1,x1-25,y1-40);
                    g.drawString(infName2,x2-5,y2+50);
                  }
                  else if( temp1 > 0.167*-2 && temp1 <= 0.167*-1){
                    g.drawString(infName1,x1-25,y1-35);
                    g.drawString(infName2,x2,y2+50);
                  }
                  else if( temp1 > 0.167*-3 && temp1 <= 0.167*-2){
                    g.drawString(infName1,x1-20,y1-35);
                    g.drawString(infName2,x2-5,y2+50);
                  }
                  else if( temp1 > 0.167*-4 && temp1 <= 0.167*-3){
                    g.drawString(infName1,x1-15,y1-35);
                    g.drawString(infName2,x2-10,y2+50);
                  }
                  else if( temp1 > 0.167*-5 && temp1 <= 0.167*-4){
                    g.drawString(infName1,x1-10,y1-30);
                    g.drawString(infName2,x2-15,y2+50);
                  }
                  else if( temp1 > 0.167*-6 && temp1 <= 0.167*-5){
                    g.drawString(infName1,x1-5,y1-25);
                    g.drawString(infName2,x2-25,y2+45);
                  }
                  else if( temp1 > 0.167*-7 && temp1 <= 0.167*-6){
                    g.drawString(infName1,x1,y1-20);
                    g.drawString(infName2,x2-35,y2+40);
                  }
                  else if( temp1 > 0.167*-8 && temp1 <= 0.167*-7){
                    g.drawString(infName1,x1+5,y1-20);
                    g.drawString(infName2,x2-40,y2+35);
                  }
                  else if( temp1 > 0.167*-9 && temp1 <= 0.167*-8){
                    g.drawString(infName1,x1+15,y1-20);
                    g.drawString(infName2,x2-50,y2+30);
                  }
                  else if( temp1 > 0.167*-10 && temp1 <= 0.167*-9){
                    g.drawString(infName1,x1+25,y1-20);
                    g.drawString(infName2,x2-50,y2+20);
                  }
                  else if( temp1 > 0.167*-11 && temp1 <= 0.167*-10){
                    g.drawString(infName1,x1+30,y1+25);
                    g.drawString(infName2,x2-35,y2-10);
                  }
                  else if( temp1 > 0.167*-12 && temp1 <= 0.167*-11){
                    g.drawString(infName1,x1+20,y1+35);
                    g.drawString(infName2,x2-30,y2-15);
                  }
                  else if( temp1 > 0.167*-13 && temp1 <= 0.167*-12){
                    g.drawString(infName1,x1+10,y1+40);
                    g.drawString(infName2,x2-25,y2-20);
                  }
                  else if( temp1 > 0.167*-14 && temp1 <= 0.167*-13){
                    g.drawString(infName1,x1+5,y1+45);
                    g.drawString(infName2,x2-20,y2-20);
                  }
                  else if( temp1 > 0.167*-15 && temp1 <= 0.167*-14){
                    g.drawString(infName1,x1,y1+45);
                    g.drawString(infName2,x2-15,y2-20);
                  }
                  else if( temp1 > 0.167*-16 && temp1 <= 0.167*-15){
                    g.drawString(infName1,x1-5,y1+45);
                    g.drawString(infName2,x2-10,y2-20);
                  }
                  else if( temp1 > 0.167*-17 && temp1 <= 0.167*-16){
                    g.drawString(infName1,x1-10,y1+50);
                    g.drawString(infName2,x2-5,y2-20);
                  }
                  else if( temp1 > 0.167*-18 && temp1 <= 0.167*-17){
                    g.drawString(infName1,x1-15,y1+50);
                    g.drawString(infName2,x2,y2-20);
                  }
                  else if( temp1 > 0.167*-19 && temp1 <= 0.167*-18){
                    g.drawString(infName1,x1-20,y1+50);
                    g.drawString(infName2,x2+5,y2-20);
                  }
                  else if( temp1 > -3.15 && temp1 <= 0.167*-19){
                    g.drawString(infName1,x1-25,y1+50);
                    g.drawString(infName2,x2+5,y2-20);
                  }

                  g.setColor(Color.black);

                }
}
  }
}
