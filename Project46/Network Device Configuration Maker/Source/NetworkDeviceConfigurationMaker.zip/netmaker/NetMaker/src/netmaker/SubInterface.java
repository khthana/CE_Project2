package netmaker;

public class SubInterface extends RouterEthINF {
  private String protocolEncap = "";
  private boolean dot1Q = true;
  private String vlanNo = "";
  public SubInterface() {
  }
  public SubInterface(String str) {
    this.setInterfaceName(str);
  }
  public String getProtocolEncap() {
    return protocolEncap;
  }
  public void setProtocolEncap(String protocolEncap) {
    this.protocolEncap = protocolEncap;
  }
  public boolean isDot1Q(){
    return this.dot1Q;
  }
  public void setProtocolEncap(boolean isDot1Q){
    if (isDot1Q){
      this.protocolEncap = "Dot1Q";
      this.dot1Q = isDot1Q;
    }
    else {
      this.protocolEncap = "ISL";
      this.dot1Q = isDot1Q;
    }
  }
  public void setVlanNo(String vlan) {
    this.vlanNo = vlan;
  }
  public String getVlan() {
    return vlanNo;
  }
}