package netmaker;

import java.util.Vector;

public class StdACL {

  private Vector aces = new Vector();//Vector of StdACE class
  private String id = "";

  public StdACL() {
  }
  public StdACL(String id) {
    this.setId(id);
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public Vector getAces() {
    return aces;
  }
  public void setAces(Vector aces) {
    this.aces = aces;
  }
  /////////////////////////////function////////////////////////////

  public void addStdAce(StdACE ace){
    this.aces.addElement(ace);
  }
  public void removeStdAce(String stringACE){
    for (int i=0;i<this.aces.size();i++){
      if (stringACE.equalsIgnoreCase(((StdACE)this.aces.elementAt(i)).getStringACE())){  //compare string
        this.aces.removeElementAt(i);
      }
    }
  }
}