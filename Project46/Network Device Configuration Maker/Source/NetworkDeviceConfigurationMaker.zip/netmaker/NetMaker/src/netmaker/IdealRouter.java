package netmaker;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class IdealRouter {

  private String series;
  private int nSerial;
  private int nFastEth;
  public IdealRouter() {
  }
  public void setSeries(String series) {
    this.series = series;
  }
  public String getSeries() {
    return series;
  }
  public int getNFastEth() {
    return nFastEth;
  }
  public int getNSerial() {
    return nSerial;
  }
  public void setNFastEth(int nFastEth) {
    this.nFastEth = nFastEth;
  }
  public void setNSerial(int nSerial) {
    this.nSerial = nSerial;
  }
}