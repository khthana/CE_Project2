package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EtherChannel extends JDialog {
  private Switch sw = new Switch();
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JRadioButton jRadioButton3 = new JRadioButton();
  private JRadioButton jRadioButton4 = new JRadioButton();
  private JRadioButton jRadioButton5 = new JRadioButton();
  private JRadioButton jRadioButton6 = new JRadioButton();
  private JRadioButton jRadioButton7 = new JRadioButton();
  private JRadioButton jRadioButton8 = new JRadioButton();
  private JRadioButton jRadioButton9 = new JRadioButton();
  private JRadioButton jRadioButton10 = new JRadioButton();
  private JRadioButton jRadioButton11 = new JRadioButton();
  private JRadioButton jRadioButton12 = new JRadioButton();
  private JRadioButton jRadioButton13 = new JRadioButton();
  private JRadioButton jRadioButton14 = new JRadioButton();
  private JRadioButton jRadioButton15 = new JRadioButton();
  private JRadioButton jRadioButton16 = new JRadioButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private ButtonGroup buttonGroup2 = new ButtonGroup();
  private ButtonGroup buttonGroup3 = new ButtonGroup();
  private ButtonGroup buttonGroup4 = new ButtonGroup();
  private ButtonGroup buttonGroup5 = new ButtonGroup();
  private ButtonGroup buttonGroup6 = new ButtonGroup();
  private ButtonGroup buttonGroup7 = new ButtonGroup();
  private ButtonGroup buttonGroup8 = new ButtonGroup();
  private Vector portChannels = new Vector();

  public EtherChannel(Frame frame, String title, boolean modal,String name) {
    super(frame, title, modal);
    try {
      ChkSwitch(name);
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public EtherChannel(String name) {
    this(null, "", false,name);
  }
  public void ChkSwitch(String name)
  {
    Switch sw1;
    String name2;
    for(int i = 0;i < Frame1.vSwitch.size();i++ ){
      sw1 = (Switch)Frame1.vSwitch.elementAt(i);
      name2 = sw1.getHostName();
      if(name.equalsIgnoreCase(name2))
        sw = sw1;
    }
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    this.getContentPane().setBackground(SystemColor.inactiveCaptionText);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("Group1");
    jLabel2.setText("Group2");
    jLabel3.setText("Group3");
    jLabel4.setText("Group4");
    jLabel5.setText("Group5");
    jLabel6.setText("Group6");
    jLabel7.setText("Group7");
    jLabel8.setText("Group8");
    jRadioButton1.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton1.setText("Enable");
    jRadioButton2.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton2.setSelected(true);
    jRadioButton2.setText("Disable");
    jRadioButton3.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton3.setText("Enable");
    jRadioButton4.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton4.setSelected(true);
    jRadioButton4.setText("Disable");
    jRadioButton5.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton5.setText("Enable");
    jRadioButton6.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton6.setSelected(true);
    jRadioButton6.setText("Disable");
    jRadioButton7.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton7.setText("Enable");
    jRadioButton8.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton8.setSelected(true);
    jRadioButton8.setText("Disable");
    jRadioButton9.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton9.setText("Enable");
    jRadioButton10.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton10.setSelected(true);
    jRadioButton10.setText("Disable");
    jRadioButton11.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton11.setText("Enable");
    jRadioButton12.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton12.setSelected(true);
    jRadioButton12.setText("Disable");
    jRadioButton12.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jRadioButton12_actionPerformed(e);
      }
    });
    jRadioButton13.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton13.setText("Enable");
    jRadioButton14.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton14.setSelected(true);
    jRadioButton14.setText("Disable");
    jRadioButton15.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton15.setText("Enable");
    jRadioButton16.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton16.setSelected(true);
    jRadioButton16.setText("Disable");
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    panel1.add(jLabel1,  new XYConstraints(20, 30, -1, -1));
    panel1.add(jLabel2,  new XYConstraints(20, 70, -1, -1));
    panel1.add(jLabel3,  new XYConstraints(20, 110, -1, -1));
    panel1.add(jLabel4,  new XYConstraints(20, 150, -1, -1));
    panel1.add(jLabel5,  new XYConstraints(20, 190, -1, -1));
    panel1.add(jLabel6,  new XYConstraints(20, 230, -1, -1));
    panel1.add(jLabel7,  new XYConstraints(20, 270, -1, -1));
    panel1.add(jLabel8,  new XYConstraints(20, 310, -1, -1));
    panel1.add(jRadioButton1,     new XYConstraints(100, 27, -1, -1));
    panel1.add(jRadioButton2,   new XYConstraints(200, 27, -1, -1));
    panel1.add(jRadioButton3,   new XYConstraints(100, 67, -1, -1));
    panel1.add(jRadioButton4,   new XYConstraints(200, 67, -1, -1));
    panel1.add(jRadioButton5,   new XYConstraints(100, 107, -1, -1));
    panel1.add(jRadioButton6,   new XYConstraints(200, 107, -1, -1));
    panel1.add(jRadioButton7,   new XYConstraints(100, 147, -1, -1));
    panel1.add(jRadioButton8,   new XYConstraints(200, 147, -1, -1));
    panel1.add(jRadioButton9,   new XYConstraints(100, 187, -1, -1));
    panel1.add(jRadioButton10,   new XYConstraints(200, 187, -1, -1));
    panel1.add(jRadioButton11,   new XYConstraints(100, 227, -1, -1));
    panel1.add(jRadioButton12,   new XYConstraints(200, 227, -1, -1));
    panel1.add(jRadioButton13,   new XYConstraints(100, 267, -1, -1));
    panel1.add(jRadioButton14,   new XYConstraints(200, 267, -1, -1));
    panel1.add(jRadioButton15,   new XYConstraints(100, 307, -1, -1));
    panel1.add(jRadioButton16,   new XYConstraints(200, 307, -1, -1));
    panel1.add(ok,   new XYConstraints(70, 360, -1, -1));
    panel1.add(cancel,  new XYConstraints(160, 360, -1, -1));
    this.getContentPane().add(panel1, BorderLayout.CENTER);
    buttonGroup1.add(jRadioButton1);
    buttonGroup1.add(jRadioButton2);
    buttonGroup2.add(jRadioButton3);
    buttonGroup2.add(jRadioButton4);
    buttonGroup3.add(jRadioButton5);
    buttonGroup3.add(jRadioButton6);
    buttonGroup4.add(jRadioButton7);
    buttonGroup4.add(jRadioButton8);
    buttonGroup5.add(jRadioButton9);
    buttonGroup5.add(jRadioButton10);
    buttonGroup7.add(jRadioButton13);
    buttonGroup7.add(jRadioButton14);
    buttonGroup6.add(jRadioButton11);
    buttonGroup6.add(jRadioButton12);
    buttonGroup8.add(jRadioButton15);
    buttonGroup8.add(jRadioButton16);
    this.setTitle("Etherchannel");
////////////////////////////////////////////////////////////////////////
    Vector portChannelsTemp = sw.getPortChannels();
    for(int i=0; i< portChannelsTemp.size();i++){
      PortChannelINF portChannel = (PortChannelINF)portChannelsTemp.elementAt(i);
      portChannels.addElement(portChannel.getId());
    }

    for(int i=0;i<portChannels.size();i++){
      String portName = (String)portChannels.elementAt(i);
      if(portName.equals("1")){
        this.jRadioButton1.setSelected(true);
        this.jRadioButton2.setSelected(false);
      }
      if(portName.equals("2")){
        this.jRadioButton3.setSelected(true);
        this.jRadioButton4.setSelected(false);
      }
      if(portName.equals("3")){
        this.jRadioButton5.setSelected(true);
        this.jRadioButton6.setSelected(false);
      }
      if(portName.equals("4")){
        this.jRadioButton7.setSelected(true);
        this.jRadioButton8.setSelected(false);
      }
      if(portName.equals("5")){
        this.jRadioButton9.setSelected(true);
        this.jRadioButton10.setSelected(false);
      }
      if(portName.equals("6")){
        this.jRadioButton11.setSelected(true);
        this.jRadioButton12.setSelected(false);
      }
      if(portName.equals("7")){
        this.jRadioButton13.setSelected(true);
        this.jRadioButton14.setSelected(false);
      }
      if(portName.equals("8")){
        this.jRadioButton15.setSelected(true);
        this.jRadioButton16.setSelected(false);
      }
    }
////////////////////////////////////////////////////////////////////////
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(300, 450);
    this.setLocation( (screenSize.width - frameSize.width) / 4,
                      (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void ok_actionPerformed(ActionEvent e) {

    if(this.jRadioButton1.isSelected()){
      if(!this.isInThisVector(this.portChannels,"1")){
        sw.addNewPortChannel("1");
      }
    }
    if(this.jRadioButton3.isSelected()){
      if(!this.isInThisVector(this.portChannels,"2")){
        sw.addNewPortChannel("2");
      }
    }
    if(this.jRadioButton5.isSelected()){
      if(!this.isInThisVector(this.portChannels,"3")){
        sw.addNewPortChannel("3");
      }
    }
    if(this.jRadioButton7.isSelected()){
      if(!this.isInThisVector(this.portChannels,"4")){
        sw.addNewPortChannel("4");
      }
    }
    if(this.jRadioButton9.isSelected()){
      if(!this.isInThisVector(this.portChannels,"5")){
        sw.addNewPortChannel("5");
      }
    }
    if(this.jRadioButton11.isSelected()){
      if(!this.isInThisVector(this.portChannels,"6")){
        sw.addNewPortChannel("6");
      }
    }
    if(this.jRadioButton13.isSelected()){
      if(!this.isInThisVector(this.portChannels,"7")){
        sw.addNewPortChannel("7");
      }
    }
    if(this.jRadioButton15.isSelected()){
      if(!this.isInThisVector(this.portChannels,"8")){
        sw.addNewPortChannel("8");
      }
    }
    if(this.jRadioButton2.isSelected()){
      if(this.isInThisVector(this.portChannels,"1")){
        sw.removePortChannel("1");
      }
    }
    if(this.jRadioButton4.isSelected()){
      if(this.isInThisVector(this.portChannels,"2")){
        sw.removePortChannel("2");
      }
    }
    if(this.jRadioButton6.isSelected()){
      if(this.isInThisVector(this.portChannels,"3")){
        sw.removePortChannel("3");
      }
    }
    if(this.jRadioButton8.isSelected()){
      if(this.isInThisVector(this.portChannels,"4")){
        sw.removePortChannel("4");
      }
    }
    if(this.jRadioButton10.isSelected()){
      if(this.isInThisVector(this.portChannels,"5")){
        sw.removePortChannel("5");
      }
    }
    if(this.jRadioButton12.isSelected()){
      if(this.isInThisVector(this.portChannels,"6")){
        sw.removePortChannel("6");
      }
    }
    if(this.jRadioButton14.isSelected()){
      if(this.isInThisVector(this.portChannels,"7")){
        sw.removePortChannel("7");
      }
    }
    if(this.jRadioButton16.isSelected()){
      if(this.isInThisVector(this.portChannels,"8")){
        sw.removePortChannel("8");
      }
    }
    this.dispose();
  }

  void cancel_actionPerformed(ActionEvent e) {
    dispose();
  }
  int rankInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return i;
    }
    return 0;
  }
  boolean isInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return true;
    }
    return false;
  }

  void jRadioButton12_actionPerformed(ActionEvent e) {

  }

}