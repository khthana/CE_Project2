package netmaker;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;

public class SwitchImg {
  private int xpos,ypos;
  private int width,height;
  private Image img;
  private String color;

  public SwitchImg() {
    width = 47;
    height = 38;
    xpos = 60*(DesignAreaPanel.vImgSwitch.size()+1);
    ypos = 30*(DesignAreaPanel.vImgSwitch.size()+1)+50;
    color="noe";

  }
  public SwitchImg(String series) {
    int model = 0;
    if(series.equals("2950_12"))
      model = 1;
    else if(series.equals("2950_24"))
      model = 2;
    else if(series.equals("2950G_12"))
      model = 3;
    else if(series.equals("2950T_24"))
      model = 4;
    else if(series.equals("2955T_12"))
      model = 5;
    else model = 6;
    switch (model){
      case 1 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("blueSwitch.gif"));color="blue";break;
      case 2 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("graySwitch.gif"));color="gray";break;
      case 3 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("greenSwitch.gif"));color="green";break;
      case 4 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("pinkSwitch.gif"));color="pink";break;
      case 5 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("purpleSwitch.gif"));color="pupil";break;
      case 6 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("purpleSwitch.gif"));color="pupil";break;
      default : color="none";break;
    }
    System.out.println("SwitchImg->"+color);
    width = 47;
    height = 38;
    xpos = 60*(DesignAreaPanel.vImgSwitch.size()+1);
    ypos = 30*(DesignAreaPanel.vImgSwitch.size()+1)+50;

  }
  public String getColors(){
    return color;
  }
  public int getXPos(){
    return xpos;
  }
  public int getYPos(){
    return ypos;
  }
  public int getWide(){
    return width;
  }
  public int getHigh(){
    return height;
  }
  public Image getImge(){
    return img;
  }
  public void setXPos(int n){
    xpos = n;
  }
  public void setYPos(int n){
    ypos = n;
  }
  public void setWide(int n){
    width = n;
  }
  public void setHigh(int n){
    height = n;
  }
}