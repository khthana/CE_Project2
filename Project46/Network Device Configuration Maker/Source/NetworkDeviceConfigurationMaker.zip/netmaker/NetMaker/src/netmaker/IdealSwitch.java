package netmaker;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class IdealSwitch {

  private String series;
  private int nFastEth;
  private int nGigaEth;
  public IdealSwitch() {
  }
  public void setSeries(String series) {
    this.series = series;
  }
  public String getSeries() {
    return series;
  }
  public int getNFastEth() {
    return nFastEth;
  }
  public int getNGigaEth() {
    return nGigaEth;
  }
  public void setNGigaEth(int nGigaEth) {
    this.nGigaEth = nGigaEth;
  }
  public void setNFastEth(int nFastEth) {
    this.nFastEth = nFastEth;
  }
}