package netmaker;

public class Connection {

  private boolean connected = false;
  private int id;//id of connection// source port connection
  private String con1DeviceID;// source switch or router id// destination port connection
  private String con2DeviceID;
  private java.util.Vector con1InfName = new java.util.Vector();
  private java.util.Vector con2InfName = new java.util.Vector();// destination switch or router id

  public Connection() {
  }
  public Connection(int id) {
    this.setId(id);
  }
  public boolean isConnected() {
    return connected;
  }
  public void setConnected(boolean connected) {
    this.connected = connected;
  }
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  public java.util.Vector getCon1InfName() {
    return con1InfName;
  }
  public void setCon1InfName(java.util.Vector con1InfName) {
    this.con1InfName = con1InfName;
  }
  public void addCon1InfName(String str){
    con1InfName.addElement(str);
  }
  public String getCon1DeviceID() {
    return con1DeviceID;
  }
  public void setCon1DeviceID(String con1DeviceID) {
    this.con1DeviceID = con1DeviceID;
  }
  public java.util.Vector getCon2InfName() {
    return con2InfName;
  }
  public void setCon2InfName(java.util.Vector con2InfName) {
    this.con2InfName = con2InfName;
  }
  public void addCon2InfName(String str){
    con2InfName.addElement(str);
  }
  public String getCon2DeviceID() {
    return con2DeviceID;
  }
  public void setCon2DeviceID(String con2DeviceID) {
    this.con2DeviceID = con2DeviceID;
  }

}