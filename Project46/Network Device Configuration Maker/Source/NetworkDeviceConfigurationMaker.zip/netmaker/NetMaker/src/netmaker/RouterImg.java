package netmaker;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;

public class RouterImg {
  private int xpos,ypos;
  private int width,height;
  private Image img;
  private String color;

  public RouterImg() {
    width = 47;
    height = 38;
    xpos = 60*(DesignAreaPanel.vImgRouter.size()+1);
    ypos = 30*(DesignAreaPanel.vImgRouter.size()+1)+100;
    color="noe";

  }
  public RouterImg(String series) {
    int model = 0;
    if(series.equals("1760"))
      model = 1;else
    if(series.equals("2620"))
      model = 2;else
    if(series.equals("2621"))
      model = 3;else
      model = 4;
        switch (model){
      case 1 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("bluerouter.gif"));color="blue";break;
      case 2 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("pinkrouter.gif"));color="pink";break;
      case 3 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("greenrouter.gif"));color="green";break;
      case 4 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("greenrouter.gif"));color="green";break;
      default : color="none";break;
    }
    System.out.println("RouterImg->"+color);
    width = 47;
    height = 38;
    xpos = 60*(DesignAreaPanel.vImgRouter.size()+1);
    ypos = 30*(DesignAreaPanel.vImgRouter.size()+1)+100;

  }
  public String getColors(){
    return color;
  }
  public int getXPos(){
    return xpos;
  }
  public int getYPos(){
    return ypos;
  }
  public int getWide(){
    return width;
  }
  public int getHigh(){
    return height;
  }
  public Image getImge(){
    return img;
  }
  public void setXPos(int n){
    xpos = n;
  }
  public void setYPos(int n){
    ypos = n;
  }
  public void setWide(int n){
    width = n;
  }
  public void setHigh(int n){
    height = n;
  }
}