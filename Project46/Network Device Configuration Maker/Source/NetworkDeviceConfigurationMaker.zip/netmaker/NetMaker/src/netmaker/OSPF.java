package netmaker;

public class OSPF {
  private String network;
  private String subnet;
  public OSPF() {
  }
  public String getNetwork() {
    return network;
  }
  public void setNetwork(String network) {
    this.network = network;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }

}