package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class NewRouterDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  private JTextField series = new JTextField();
  private JTextField fastEth = new JTextField();
  private JTextField gigaEth = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();

  public NewRouterDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public NewRouterDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("Series");
    jLabel2.setText("FastEthernet");
    jLabel3.setText("Serial");
    jLabel4.setText("ports");
    jLabel5.setText("ports");
    jButton1.setBackground(SystemColor.inactiveCaptionText);
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBackground(SystemColor.inactiveCaptionText);
    jButton2.setText("Cancel");
    getContentPane().add(panel1);
    panel1.add(jLabel1,    new XYConstraints(30, 30, -1, -1));
    panel1.add(series,     new XYConstraints(130, 30, 100, -1));
    panel1.add(fastEth,      new XYConstraints(130, 70, 25, 20));
    panel1.add(gigaEth,     new XYConstraints(130, 110, 25, -1));
    panel1.add(jLabel2,  new XYConstraints(30, 70, -1, -1));
    panel1.add(jLabel3,    new XYConstraints(30, 110, -1, -1));
    panel1.add(jLabel5,    new XYConstraints(175, 110, -1, -1));
    panel1.add(jLabel4,  new XYConstraints(175, 70, -1, -1));
    panel1.add(jButton1,     new XYConstraints(50, 150, -1, -1));
    panel1.add(jButton2,    new XYConstraints(130, 150, -1, -1));
    this.setTitle("New Router");
  }
  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(250,250);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    IdealRouter ideal = new IdealRouter();
    ideal.setSeries(this.series.getText());
    ideal.setNFastEth(Integer.parseInt(this.fastEth.getText()));
    ideal.setNSerial(Integer.parseInt(this.gigaEth.getText()));
    Frame1.idealRouters.addElement(ideal);
    this.dispose();
  }
}