package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.Vector;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ConnectDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JComboBox jComboBox1 = new JComboBox();
  private JComboBox jComboBox2 = new JComboBox();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JList jList2 = new JList();
  private JList jList1 = new JList();
  private JButton connectButton = new JButton();
  private JButton cancelButton = new JButton();

  public ConnectDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ConnectDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    connectButton.setBackground(SystemColor.inactiveCaptionText);
    connectButton.setText("Connect");
    connectButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connectButton_actionPerformed(e);
      }
    });
    cancelButton.setBackground(SystemColor.inactiveCaptionText);
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancelButton_actionPerformed(e);
      }
    });
    jComboBox2.setBackground(SystemColor.inactiveCaptionText);
    jComboBox2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jComboBox2_actionPerformed(e);
      }
    });
    jComboBox1.setBackground(SystemColor.inactiveCaptionText);
    jComboBox1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jComboBox1_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jComboBox1,     new XYConstraints(50, 20, 130, 25));
    panel1.add(jComboBox2,   new XYConstraints(200, 20, 130, 25));
    panel1.add(jScrollPane1,   new XYConstraints(50, 75, 130, 150));
    jScrollPane1.getViewport().add(jList1, null);
    panel1.add(jScrollPane2,   new XYConstraints(200, 75, 130, 150));
    panel1.add(cancelButton,   new XYConstraints(230, 245, -1, -1));
    panel1.add(connectButton,   new XYConstraints(75, 245, -1, -1));
    jScrollPane2.getViewport().add(jList2, null);
    Vector list1 = new Vector();
    for(int i=0 ;i<Frame1.vSwitch.size();i++){
      list1.addElement(((Switch)Frame1.vSwitch.elementAt(i)).getHostName());
    }
    for(int i=0 ;i<Frame1.vRouter.size();i++){
      list1.addElement(((Router)Frame1.vRouter.elementAt(i)).getHostName());
    }
    String temp1 = "";
    String temp2 = "";
    if(list1.size()>=1)
    temp1 = (String)list1.elementAt(0);
    if(list1.size()>=2)
    temp2 = (String)list1.elementAt(1);
    setList(temp1,temp2);
    this.setTitle("Connection");
  }

  private void setList(String temp1,String temp2){
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    this.jComboBox1.removeAllItems();
    this.jComboBox2.removeAllItems();
    for(int i=0 ;i<Frame1.vSwitch.size();i++){
      list1.addElement(((Switch)Frame1.vSwitch.elementAt(i)).getHostName());
      list2.addElement(((Switch)Frame1.vSwitch.elementAt(i)).getHostName());
    }
    for (int i=0;i<Frame1.vRouter.size();i++){
      list1.addElement(((Router)Frame1.vRouter.elementAt(i)).getHostName());
      list2.addElement(((Router)Frame1.vRouter.elementAt(i)).getHostName());
    }
    list1.remove(temp2);
    list2.remove(temp1);
    for(int i=0;i<list1.size();i++)
    jComboBox1.addItem(list1.elementAt(i));
    for(int i=0;i<list2.size();i++)
    jComboBox2.addItem(list2.elementAt(i));
    jComboBox1.setSelectedItem(temp1);
    jComboBox2.setSelectedItem(temp2);
  }
  boolean isInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return true;
    }
    return false;
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(380,330);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  private void showList(JComboBox comboBox,JList jList){
    String temp = (String)comboBox.getSelectedItem();
    for(int i=0;i<Frame1.vSwitch.size();i++){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(i);
      if(sw.getHostName().equals(temp)){
        Vector list1 = new Vector();
        list1 = sw.getVectorOfPort();
        for(int j=0;j<Frame1.vConnection.size();j++){
          Connection connect = (Connection)Frame1.vConnection.elementAt(j);
          if(connect.getCon1DeviceID().equals(temp)){
            for(int k=0;k<connect.getCon1InfName().size();k++){
              list1.removeElement(connect.getCon1InfName().elementAt(k));
            }
          }
          if(connect.getCon2DeviceID().equals(temp)){
            for(int k=0;k<connect.getCon2InfName().size();k++){
              list1.removeElement(connect.getCon2InfName().elementAt(k));
            }
          }
        }
        jList.setListData(list1);
      }
    }
    for(int i=0;i<Frame1.vRouter.size();i++){
      Router rt = (Router)Frame1.vRouter.elementAt(i);
      if(rt.getHostName().equals(temp)){
        Vector list1 = new Vector();
        list1 = rt.getVectorOfPort();
        for(int j=0;j<Frame1.vConnection.size();j++){
          Connection connect = (Connection)Frame1.vConnection.elementAt(j);
          if(connect.getCon1DeviceID().equals(temp)){
            for(int k=0;k<connect.getCon1InfName().size();k++){
              list1.removeElement(connect.getCon1InfName().elementAt(k));
            }
          }
          if(connect.getCon2DeviceID().equals(temp)){
            for(int k=0;k<connect.getCon2InfName().size();k++){
              list1.removeElement(connect.getCon2InfName().elementAt(k));
            }
          }
        }
        jList.setListData(list1);
      }
    }
  }
  void jComboBox1_actionPerformed(ActionEvent e) {
    showList(jComboBox1,jList1);
    setList((String)jComboBox1.getSelectedItem(),(String)jComboBox2.getSelectedItem());
  }

  void jComboBox2_actionPerformed(ActionEvent e) {
    showList(jComboBox2,jList2);
    setList((String)jComboBox1.getSelectedItem(),(String)jComboBox2.getSelectedItem());
  }

  void connectButton_actionPerformed(ActionEvent e) {
      String temp1,temp2,temp3,temp4;
      temp1 = (String)jComboBox1.getSelectedItem();
      temp2 = (String)jComboBox2.getSelectedItem();
      temp3 = (String)jList1.getSelectedValue();
      temp4 = (String)jList2.getSelectedValue();
      boolean chk = true;
      if(temp3 == null || temp4 == null)
        chk = false;
      if(chk){
      for(int i=0;i<Frame1.vSwitch.size();i++){
        for(int j=0;j<Frame1.vSwitch.size();j++){
          Switch sw1 = (Switch)Frame1.vSwitch.elementAt(i);
          Switch sw2 = (Switch)Frame1.vSwitch.elementAt(j);
          if(sw1.getHostName().equals(temp1)&&sw2.getHostName().equals(temp2))
          {
            SwitchImg s1 = (SwitchImg)DesignAreaPanel.vImgSwitch.elementAt(i);
            SwitchImg s2 = (SwitchImg)DesignAreaPanel.vImgSwitch.elementAt(j);
  /*          sw1.addConnectingSwitch(s2);
            sw2.addConnectingSwitch(s1);
            sw1.connect(temp3);
            sw2.connect(temp4);
  */
            boolean isSameConnect = false;
            for(int k=0;k< Frame1.vConnection.size();k++){
              Connection connect = (Connection)Frame1.vConnection.elementAt(k);
              if(connect.getCon1DeviceID().equals(sw1.getHostName())
                 && connect.getCon2DeviceID().equals(sw2.getHostName())){
                isSameConnect = true;
                connect.addCon1InfName(temp3);
                connect.addCon2InfName(temp4);
              }

            }
            if(!isSameConnect){
            Connection connect = new Connection();
            connect.setCon1DeviceID(sw1.getHostName());
            connect.addCon1InfName(temp3);
            connect.setCon2DeviceID(sw2.getHostName());
            connect.addCon2InfName(temp4);
            Frame1.vConnection.addElement(connect);
            }
          }
        }
      }
      for(int i=0;i<Frame1.vRouter.size();i++){
        for(int j=0;j<Frame1.vRouter.size();j++){
          Router rt1 = (Router)Frame1.vRouter.elementAt(i);
          Router rt2 = (Router)Frame1.vRouter.elementAt(j);
          if(rt1.getHostName().equals(temp1)&&rt2.getHostName().equals(temp2))
          {if((temp3.substring(0,1).equals("S")&&temp4.substring(0,1).equals("S"))
              ||(temp3.substring(0,1).equals("F")&&temp3.substring(0,1).equals("F"))){
            RouterImg r1 = (RouterImg)DesignAreaPanel.vImgRouter.elementAt(i);
            RouterImg r2 = (RouterImg)DesignAreaPanel.vImgRouter.elementAt(j);
  /*          rt1.addConnectingRouter(r2);
            rt2.addConnectingRouter(r1);
            rt1.connect(temp3);
            rt2.connect(temp4);
  */
            boolean isSameConnect = false;
            for(int k=0;k< Frame1.vConnection.size();k++){
              Connection connect = (Connection)Frame1.vConnection.elementAt(k);
              if(connect.getCon1DeviceID().equals(rt1.getHostName())
                 && connect.getCon2DeviceID().equals(rt2.getHostName())){
                isSameConnect = true;
                connect.addCon1InfName(temp3);
                connect.addCon2InfName(temp4);
              }

            }
            if(!isSameConnect){
              Connection connect = new Connection();
            connect.setCon1DeviceID(rt1.getHostName());
            connect.addCon1InfName(temp3);
            connect.setCon2DeviceID(rt2.getHostName());
            connect.addCon2InfName(temp4);
            Frame1.vConnection.addElement(connect);
            }
          }else {
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Cannot Connect! please try again");
            dialog.showDialog();
          }
          }
        }
      }
      for(int i=0;i<Frame1.vSwitch.size();i++){
        for(int j=0;j<Frame1.vRouter.size();j++){
          Switch sw1 = (Switch)Frame1.vSwitch.elementAt(i);
          Router rt2 = (Router)Frame1.vRouter.elementAt(j);
          if(sw1.getHostName().equals(temp1)&&rt2.getHostName().equals(temp2))
          {if (temp4.substring(0,1).equals("F")){
  /*          SwitchImg s1 = (SwitchImg)DesignAreaPanel.vImgSwitch.elementAt(i);
            RouterImg r2 = (RouterImg)DesignAreaPanel.vImgRouter.elementAt(j);
            sw1.addConnectingRouter(r2);
            rt2.addConnectingSwitch(s1);
            sw1.connect(temp3);
            rt2.connect(temp4);
  */
          boolean isSameConnect = false;
          for(int k=0;k< Frame1.vConnection.size();k++){
            Connection connect = (Connection)Frame1.vConnection.elementAt(k);
            if(connect.getCon1DeviceID().equals(sw1.getHostName())
               && connect.getCon2DeviceID().equals(rt2.getHostName())){
              isSameConnect = true;
              connect.addCon1InfName(temp3);
              connect.addCon2InfName(temp4);
            }

          }
          if(!isSameConnect){
            Connection connect = new Connection();
            connect.setCon1DeviceID(sw1.getHostName());
            connect.addCon1InfName(temp3);
            connect.setCon2DeviceID(rt2.getHostName());
            connect.addCon2InfName(temp4);
            Frame1.vConnection.addElement(connect);
          }
          }else {
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Cannot Connect! please try again");
            dialog.showDialog();
          }
          }
        }
      }
      for(int i=0;i<Frame1.vRouter.size();i++){
        for(int j=0;j<Frame1.vSwitch.size();j++){
          Router rt1 = (Router)Frame1.vRouter.elementAt(i);
          Switch sw2 = (Switch)Frame1.vSwitch.elementAt(j);
          if(rt1.getHostName().equals(temp1)&&sw2.getHostName().equals(temp2))
          { if (temp3.substring(0,1).equals("F")){
  /*          RouterImg r1 = (RouterImg)DesignAreaPanel.vImgRouter.elementAt(i);
            SwitchImg s2 = (SwitchImg)DesignAreaPanel.vImgSwitch.elementAt(j);
            rt1.addConnectingSwitch(s2);
            sw2.addConnectingRouter(r1);
            rt1.connect(temp3);
            sw2.connect(temp4);
  */
          boolean isSameConnect = false;
          for(int k=0;k< Frame1.vConnection.size();k++){
            Connection connect = (Connection)Frame1.vConnection.elementAt(k);
            if(connect.getCon1DeviceID().equals(rt1.getHostName())
               && connect.getCon2DeviceID().equals(sw2.getHostName())){
              isSameConnect = true;
              connect.addCon1InfName(temp3);
              connect.addCon2InfName(temp4);
            }

          }
          if(!isSameConnect){
            Connection connect = new Connection();
            connect.setCon1DeviceID(rt1.getHostName());
            connect.addCon1InfName(temp3);
            connect.setCon2DeviceID(sw2.getHostName());
            connect.addCon2InfName(temp4);
            Frame1.vConnection.addElement(connect);
          }
          }else {
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Cannot Connect! please try again");
            dialog.showDialog();
          }
          }
        }
      }

      for (int j=0; j<Frame1.vSwitch.size(); j++) {
        Switch sw2 = (Switch)Frame1.vSwitch.elementAt(j);
        System.out.println();
      }
      this.dispose();}else {
        ErrorDialog dialog = new ErrorDialog();
        dialog.setText("You did not choose port !!! please try again");
        dialog.showDialog();

      }

  }

  void cancelButton_actionPerformed(ActionEvent e) {
    this.dispose();
  }

}