package netmaker;

import java.util.Vector;

public class LineINF {
//set permit access or not
  private String password = "";
  private boolean login = false;
  private Vector accessGroups = new Vector();//Vector of AccessGroup
  public LineINF() {
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public void setLogin(boolean login) {
    this.login = login;
  }
  public boolean isLogin() {
    return login;
  }
  public Vector getAccessGroups() {
    return accessGroups;
  }
  public void setAccessGroups(Vector accessGroups) {
    this.accessGroups = accessGroups;
  }
  /////////////////////////////////function////////////////////////////////////
  public void addAccessGroup(AccessGroup accessGroup){
    if (!isAccessGroupAdded(accessGroup)){
      this.accessGroups.addElement(accessGroup);
    }
  }
  private boolean isAccessGroupAdded(AccessGroup accessGroup){
    for (int i=0;i<this.accessGroups.size();i++){
      if (((AccessGroup)this.accessGroups.elementAt(i)).equals(accessGroup)){
        return false;
      }
    }
    return true;
  }
  public void removeAccessGroup(AccessGroup accessGroup){
    int index = this.indexOfAccesGroup(accessGroup);
    if (index != -1){
      this.accessGroups.removeElementAt(index);
    }
  }
  private int indexOfAccesGroup(AccessGroup accessGroup){
    for (int i=0;i<this.accessGroups.size();i++){
      if (((AccessGroup)this.accessGroups.elementAt(i)).equals(accessGroup)){
        return i;
      }
    }
    return -1;
  }
}