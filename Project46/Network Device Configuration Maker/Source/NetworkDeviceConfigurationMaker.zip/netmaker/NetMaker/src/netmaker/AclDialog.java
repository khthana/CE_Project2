package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;
public class AclDialog extends JDialog {
  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JLabel jLabel1 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JButton create = new JButton();
  JButton remove = new JButton();
  JButton edit = new JButton();
  JButton ok = new JButton();
  JButton cancel = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private Vector list1 = new Vector();//showed data in jList1
  private Switch sw;
  private Router rt;
  private boolean isSwitch = false;
  private boolean isRouter = false;
  private Vector stdACLs;
  private Vector extACLs;
  private Vector forCancel1 = new Vector(),forCancel2 = new Vector();

  public AclDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AclDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    jLabel1.setText("ACL Number");
    create.setBackground(SystemColor.inactiveCaptionText);
    create.setText("Create");
    create.addActionListener(new AclDialog_create_actionAdapter(this));
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new AclDialog_remove_actionAdapter(this));
    edit.setBackground(SystemColor.inactiveCaptionText);
    edit.setText("Edit..");
    edit.addActionListener(new AclDialog_edit_actionAdapter(this));
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new AclDialog_ok_actionAdapter(this));
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new AclDialog_cancel_actionAdapter(this));
    jTextField1.setText("");
    panel1.setBackground(SystemColor.inactiveCaptionText);
    getContentPane().add(panel1);
    panel1.add(jLabel1,   new XYConstraints(25, 35, -1, -1));
    panel1.add(jTextField1,  new XYConstraints(104, 34, 75, -1));
    panel1.add(create,     new XYConstraints(190, 30, -1, -1));
    panel1.add(jScrollPane1,      new XYConstraints(24, 82, 238, 122));
    panel1.add(remove,  new XYConstraints(180, 220, -1, -1));
    panel1.add(edit,   new XYConstraints(100, 220, -1, -1));
    panel1.add(ok,  new XYConstraints(100, 260, -1, -1));
    panel1.add(cancel, new XYConstraints(186, 260, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    this.setTitle("Access Control List");
  }

  public void setSwitch(Switch sw1){
    isSwitch = true;
    sw = sw1;
    stdACLs = sw.getStdACLs();
    extACLs = sw.getExtACLs();
    for(int i=0;i<stdACLs.size();i++){
      forCancel1.addElement(stdACLs.elementAt(i));
    }
    for(int i=0;i<extACLs.size();i++){
      forCancel2.addElement(extACLs.elementAt(i));
    }
    for(int i=0;i<stdACLs.size();i++){
      StdACL stdACL = (StdACL)stdACLs.elementAt(i);
      list1.addElement("access-list "+stdACL.getId());
    }
    for(int i=0;i<extACLs.size();i++){
      ExtACL extACL = (ExtACL)extACLs.elementAt(i);
      list1.addElement("access-list "+extACL.getId());
    }
    jList1.setListData(list1);
  }
  public void setRouter(Router rt1){
    isRouter = true;
    rt = rt1;
    stdACLs = rt.getStdACLs();
    extACLs = rt.getExtACLs();
    for(int i=0;i<stdACLs.size();i++){
      forCancel1.addElement(stdACLs.elementAt(i));
    }
    for(int i=0;i<extACLs.size();i++){
      forCancel2.addElement(extACLs.elementAt(i));
    }
    for(int i=0;i<stdACLs.size();i++){
      StdACL stdACL = (StdACL)stdACLs.elementAt(i);
      list1.addElement("access-list "+stdACL.getId());
    }
    for(int i=0;i<extACLs.size();i++){
      ExtACL extACL = (ExtACL)extACLs.elementAt(i);
      list1.addElement("access-list "+extACL.getId());
    }
    jList1.setListData(list1);
  }

  void cancel_actionPerformed(ActionEvent e) {
    if(isSwitch){
    sw.setStdACLs(forCancel1);
    sw.setExtACLs(forCancel2);
    }
    if(isRouter){
    rt.setStdACLs(forCancel1);
    rt.setExtACLs(forCancel2);
    }
    dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e) ;
     if (e.getID() == WindowEvent.WINDOW_CLOSING) {
       if(isSwitch){
       sw.setStdACLs(forCancel1);
       sw.setExtACLs(forCancel2);
       }
       if(isRouter){
       rt.setStdACLs(forCancel1);
       rt.setExtACLs(forCancel2);
       }
       dispose();
     }
  }  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(300,350);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  boolean chkInteger(String st){
    try{
      Integer.parseInt(st);
      return true;
    }catch (Exception e){
      return false;
    }
  }
  void create_actionPerformed(ActionEvent e) {
    boolean chk = true;
    for(int i=0;i<list1.size();i++){
      if(("access-list "+this.jTextField1.getText()).equals(list1.elementAt(i))){
        chk = false;
      }    }
    if(chkInteger(this.jTextField1.getText())){
      if(!chk){
          ErrorDialog dialog = new ErrorDialog();
          dialog.setText("ACL number "+jTextField1.getText()+" is already");
          dialog.showDialog();
        }

    if(chk && !this.jTextField1.getText().equals("")){
    int a;
    a = Integer.parseInt(this.jTextField1.getText());
    if(0<=a && a<100)
      stdACLs.addElement(new StdACL(this.jTextField1.getText()));
    else if(100<=a && a<200)
      extACLs.addElement(new ExtACL(this.jTextField1.getText()));
    else {
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("ACL number must be between 0 and 200");
      dialog.showDialog();
    }}
    }else{
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illigal ACL number! please try again");
      dialog.showDialog();
    }
    list1.removeAllElements();
    for(int i=0;i<stdACLs.size();i++){
      StdACL stdACL = (StdACL)stdACLs.elementAt(i);
      list1.addElement("access-list "+stdACL.getId());
    }
    for(int i=0;i<extACLs.size();i++){
      ExtACL extACL = (ExtACL)extACLs.elementAt(i);
      list1.addElement("access-list "+extACL.getId());
    }
    jList1.removeAll();
    jList1.setListData(list1);
    this.jTextField1.setText("");

  }

  void edit_actionPerformed(ActionEvent e) {
    if(!jList1.isSelectionEmpty()){
    int temp = this.jList1.getSelectedIndex();
    if(temp < stdACLs.size()){
      CreateStdACE createStdACE = new CreateStdACE();
      createStdACE.setACL((StdACL)stdACLs.elementAt(temp));
      createStdACE.showDialog();
    }else{
      CreateExtACE createExtACE = new CreateExtACE();
      createExtACE.setACL((ExtACL)extACLs.elementAt(temp-stdACLs.size()));
      createExtACE.showDialog();
    }
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void remove_actionPerformed(ActionEvent e) {
    if (!jList1.isSelectionEmpty()){
    int temp = this.jList1.getSelectedIndex();
    if(temp < stdACLs.size())
      stdACLs.remove(temp);
    else
      extACLs.remove(temp-stdACLs.size());
    list1.removeAllElements();
    for(int i=0;i<stdACLs.size();i++){
      StdACL stdACL = (StdACL)stdACLs.elementAt(i);
      list1.addElement("access-list "+stdACL.getId());
    }
    for(int i=0;i<extACLs.size();i++){
      ExtACL extACL = (ExtACL)extACLs.elementAt(i);
      list1.addElement("access-list "+extACL.getId());
    }
    jList1.removeAll();
    jList1.setListData(list1);
    }
  }

}

class AclDialog_cancel_actionAdapter implements java.awt.event.ActionListener {
  AclDialog adaptee;

  AclDialog_cancel_actionAdapter(AclDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cancel_actionPerformed(e);
  }
}

class AclDialog_create_actionAdapter implements java.awt.event.ActionListener {
  private AclDialog adaptee;

  AclDialog_create_actionAdapter(AclDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.create_actionPerformed(e);
  }
}

class AclDialog_edit_actionAdapter implements java.awt.event.ActionListener {
  private AclDialog adaptee;

  AclDialog_edit_actionAdapter(AclDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.edit_actionPerformed(e);
  }
}

class AclDialog_ok_actionAdapter implements java.awt.event.ActionListener {
  private AclDialog adaptee;

  AclDialog_ok_actionAdapter(AclDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.ok_actionPerformed(e);
  }
}

class AclDialog_remove_actionAdapter implements java.awt.event.ActionListener {
  private AclDialog adaptee;

  AclDialog_remove_actionAdapter(AclDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.remove_actionPerformed(e);
  }
}