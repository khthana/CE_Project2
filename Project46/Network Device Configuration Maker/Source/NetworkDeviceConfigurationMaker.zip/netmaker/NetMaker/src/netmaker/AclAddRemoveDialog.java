package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AclAddRemoveDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JRadioButton outRadio = new JRadioButton();
  private JRadioButton inRadio = new JRadioButton();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private Switch sw;
  private Vector stdACLs,listACL,extACLs,acls,list;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JList jList2 = new JList();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JButton add = new JButton();
  private JButton remove = new JButton();
  private Vector forCancel = new Vector();
  private JComboBox jComboBox1 = new JComboBox();
  private VlanINF vlanInf;
  private Router rt;
  private int tempChk;//0=vlan 1=vtySW 2=consoleSW 3=vtyRT 4=consoleRT

  public AclAddRemoveDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AclAddRemoveDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    remove.setMargin(new Insets(2, 7, 2, 7));
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        add_actionPerformed(e);
      }
    });
    inRadio.setSelected(true);
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    outRadio.setBackground(SystemColor.inactiveCaptionText);
    outRadio.setText("Out");
    inRadio.setBackground(SystemColor.inactiveCaptionText);
    inRadio.setText("In");
    jButton1.setBackground(SystemColor.inactiveCaptionText);
    jButton1.setText("Cancel");
    jButton2.setBackground(SystemColor.inactiveCaptionText);
    jButton2.setText("OK");
    add.setBackground(SystemColor.inactiveCaptionText);
    add.setText("ADD");
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    buttonGroup1.add(inRadio);
    buttonGroup1.add(outRadio);
    panel1.add(jScrollPane2,   new XYConstraints(30, 120, 250, 150));
    panel1.add(jButton1,   new XYConstraints(200, 280, -1, -1));
    panel1.add(jButton2,   new XYConstraints(135, 280, -1, -1));
    panel1.add(add,   new XYConstraints(60, 80, -1, -1));
    panel1.add(remove,  new XYConstraints(175, 80, -1, -1));
    panel1.add(outRadio,  new XYConstraints(200, 45, -1, -1));
    panel1.add(inRadio,  new XYConstraints(200, 25, -1, -1));
    panel1.add(jComboBox1,     new XYConstraints(30, 30, 150, 25));
    jScrollPane2.getViewport().add(jList2, null);
    this.getContentPane().add(panel1, BorderLayout.CENTER);
    this.setTitle("Add or Remove ACL");
  }
  public void setSwitch(Switch sw1,VlanINF vlanInf1){
    tempChk=0;
    vlanInf = vlanInf1;
    acls = vlanInf.getAccessGroups();
    sw = sw1;
    stdACLs = sw.getStdACLs();
    extACLs = sw.getExtACLs();
    for(int i=0;i<acls.size();i++){
      forCancel.addElement(acls.elementAt(i));
    }
    this.setList();
  }
  public void setSwitch(Switch sw1,int i){
    tempChk=i;
    if (i==2)
      acls = sw1.getConsole().getAccessGroups();
    if (i==1)
      acls = sw1.getVty().getAccessGroups();
    sw = sw1;
    stdACLs = sw.getStdACLs();
    extACLs = sw.getExtACLs();
    for(int j=0;j<acls.size();j++){
      forCancel.addElement(acls.elementAt(j));
    }
    this.setList();
  }
  public void setRouter(Router rt1,int i){
    tempChk=i;
    if (i==4)
      acls = rt1.getConsole().getAccessGroups();
    if (i==3)
      acls = rt1.getVty().getAccessGroups();
    rt = rt1;
    stdACLs = rt.getStdACLs();
    extACLs = rt.getExtACLs();
    for(int j=0;j<acls.size();j++){
      forCancel.addElement(acls.elementAt(j));
    }
    this.setList();
  }
  public void setList(){
    list = new Vector();
    listACL=new Vector();
    StdACL stdACL;
    ExtACL extACL;
    AccessGroup accessGroup ;
    for(int i=0;i<acls.size();i++){
      forCancel.addElement(acls.elementAt(i));
    }
    for(int i=0;i<acls.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      list.addElement(accessGroup.getId());
    }
    for(int i=0;i<stdACLs.size();i++){
      stdACL = (StdACL)stdACLs.elementAt(i);
      if(!this.isInThisVector(list,stdACL.getId())){
        listACL.addElement(stdACL.getId());
      }
    }
    for(int i=0;i<extACLs.size();i++){
      extACL = (ExtACL)extACLs.elementAt(i);
      if(!this.isInThisVector(list,extACL.getId())){
        listACL.addElement(extACL.getId());
      }
    }
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    for(int i=0;i<listACL.size();i++){
      list1.addElement("access-list "+listACL.elementAt(i));
    }
    for(int i=0;i<list.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      if(accessGroup.isIncoming())
        list2.addElement("access-list "+list.elementAt(i)+" in");
      else list2.addElement("access-list "+list.elementAt(i)+" out");
    }
    for(int i=0;i<list1.size();i++){
      this.jComboBox1.addItem(list1.elementAt(i));
    }
    jList2.setListData(list2);
  }
  boolean isInThisVector(Vector vector,Object obj){
    for(int i=0;i<vector.size();i++){
      if(obj.equals(vector.elementAt(i)))
        return true;
    }
    return false;
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(310,350);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void add_actionPerformed(ActionEvent e) {
    if (this.jComboBox1.getItemCount() != 0){
    boolean chk = true;
    list.addElement(listACL.elementAt(this.jComboBox1.getSelectedIndex()));
    if(inRadio.isSelected()) chk = true;
    if(outRadio.isSelected()) chk = false;
    acls.addElement(new AccessGroup((String)listACL.elementAt(jComboBox1.getSelectedIndex()),chk));
//    listACL.removeElementAt(jComboBox1.getSelectedIndex());
    jComboBox1.removeAllItems();
    jList2.removeAll();
    Vector list1 = new Vector();
    Vector list2 = new Vector();
    AccessGroup accessGroup ;
    for(int i=0;i<listACL.size();i++){
      list1.addElement("access-list "+listACL.elementAt(i));
    }
    for(int i=0;i<list.size();i++){
      accessGroup = (AccessGroup)acls.elementAt(i);
      if(accessGroup.isIncoming())
        list2.addElement("access-list "+list.elementAt(i)+" in");
      else list2.addElement("access-list "+list.elementAt(i)+" out");
    }

    for(int i=0;i<list1.size();i++){
      this.jComboBox1.addItem(list1.elementAt(i));
    }
    jList2.setListData(list2);
    inRadio.setSelected(true);
    }
  }

  void remove_actionPerformed(ActionEvent e) {
    if (!jList2.isSelectionEmpty())
    {
      acls.removeElementAt(jList2.getSelectedIndex());
//      listACL.addElement(list.elementAt(jList2.getSelectedIndex()));
      list.removeElementAt(jList2.getSelectedIndex());
      Vector list1 = new Vector();
      Vector list2 = new Vector();
      AccessGroup accessGroup ;
      for(int i=0;i<listACL.size();i++){
        list1.addElement("access-list "+listACL.elementAt(i));
      }
      for(int i=0;i<list.size();i++){
        accessGroup = (AccessGroup)acls.elementAt(i);
        if(accessGroup.isIncoming())
          list2.addElement("access-list "+list.elementAt(i)+" in");
        else list2.addElement("access-list "+list.elementAt(i)+" out");
      }
      jComboBox1.removeAllItems();
      for(int i=0;i<list1.size();i++){
        this.jComboBox1.addItem(list1.elementAt(i));
      }
      jList2.setListData(list2);
      inRadio.setSelected(true);
    }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    if(tempChk == 0)
      vlanInf.setAccessGroups(forCancel);
    if(tempChk == 2)
      sw.getConsole().setAccessGroups(forCancel);
    if(tempChk == 1)
      sw.getVty().setAccessGroups(forCancel);
    if(tempChk == 4)
      rt.getConsole().setAccessGroups(forCancel);
    if(tempChk == 3)
      rt.getVty().setAccessGroups(forCancel);
    this.dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      if(tempChk == 0)
        vlanInf.setAccessGroups(forCancel);
      if(tempChk == 2)
        sw.getConsole().setAccessGroups(forCancel);
      if(tempChk == 1)
        sw.getVty().setAccessGroups(forCancel);
      if(tempChk == 4)
        rt.getConsole().setAccessGroups(forCancel);
      if(tempChk == 3)
        rt.getVty().setAccessGroups(forCancel);
      this.dispose();
    }
  }

}












