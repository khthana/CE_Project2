package netmaker;

import java.util.Vector;

public class VlanSTP {

  private String vlanID = "";
  private String cost = "";
  private String priority = "";
  public VlanSTP() {
  }
  public VlanSTP(String vlanID) {
    this.vlanID = vlanID;
  }
  public VlanSTP(String vlanID,String cost,String priority) {
    this.vlanID = vlanID;
    this.cost = cost;
    this.priority = priority;
  }
  public String getCost() {
    return cost;
  }
  public String getPriority() {
    return priority;
  }
  public String getVlanID() {
    return vlanID;
  }
  public void setCost(String cost) {
    this.cost = cost;
  }
  public void setPriority(String priority) {
    this.priority = priority;
  }
  public void setVlanID(String vlanID) {
    this.vlanID = vlanID;
  }
}