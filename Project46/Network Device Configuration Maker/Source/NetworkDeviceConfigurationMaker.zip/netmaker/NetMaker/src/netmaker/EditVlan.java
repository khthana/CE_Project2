package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditVlan extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JTextField ip = new JTextField();
  private JTextField subnet = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JButton aclButton = new JButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private VlanINF vlanInf;
  private Switch sw;

  public EditVlan(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public EditVlan() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    jLabel1.setText("IP Address");
    jLabel2.setText("Subnet mask");
    jRadioButton1.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton1.setText("Shutdown");
    jRadioButton2.setBackground(SystemColor.inactiveCaptionText);
    jRadioButton2.setText("No shutdown");
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    aclButton.setBackground(SystemColor.inactiveCaptionText);
    aclButton.setText("ACL");
    aclButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        aclButton_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(subnet,      new XYConstraints(120, 105, 100, -1));
    panel1.add(ip,       new XYConstraints(120, 70, 100, -1));
    panel1.add(jLabel2,      new XYConstraints(30, 105, -1, -1));
    panel1.add(jLabel1,      new XYConstraints(30, 70, -1, -1));
    panel1.add(jRadioButton1,    new XYConstraints(31, 20, -1, -1));
    panel1.add(jRadioButton2,  new XYConstraints(117, 20, -1, -1));
    panel1.add(ok,   new XYConstraints(75, 180, -1, -1));
    panel1.add(aclButton,  new XYConstraints(161, 140, -1, -1));
    panel1.add(cancel,  new XYConstraints(145, 180, -1, -1));
    buttonGroup1.add(jRadioButton2);
    buttonGroup1.add(jRadioButton1);
    this.setTitle("Edit Vlan");
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(255,260);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  public void setVlan(VlanINF vlanInf1,Switch sw1){
    sw = sw1;
    vlanInf = vlanInf1;
    if(vlanInf.isShutdown()){
      this.jRadioButton1.setSelected(true);
      this.jRadioButton2.setSelected(false);
    }else{
      this.jRadioButton1.setSelected(false);
      this.jRadioButton2.setSelected(true);
    }
    ip.setText(vlanInf.getIpAddress());
    subnet.setText(vlanInf.getSubnet());
  }

  void ok_actionPerformed(ActionEvent e) {
    boolean isError = false;
    if(chkIP(ip.getText())){
      isError = false;
    }else{
      isError = true;
      ip.setText("");
      ErrorDialog dialog = new ErrorDialog();
      dialog.setText("Illegal IP Address! Please try again");
      dialog.showDialog();
    }
    if(!isError)
      if(this.chkSubnet(subnet.getText())){
    isError = false;
      }
      else{
        isError = true;
        subnet.setText("");
        ErrorDialog dialog = new ErrorDialog();
        dialog.setText("Illegal Subnet! Please try again");
        dialog.showDialog();
      }
    if(!isError){
    if(this.jRadioButton1.isSelected()){
      vlanInf.setShutdown(true);
    }
    if(this.jRadioButton2.isSelected()){
      vlanInf.setShutdown(false);
    }
    if(!ip.getText().equals(""))
    vlanInf.setIpAddress(ip.getText());
    if(!subnet.getText().equals(""))
    vlanInf.setSubnet(subnet.getText());
    this.dispose();
    }
  }
  void cancel_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void aclButton_actionPerformed(ActionEvent e) {
    AclAddRemoveDialog dialog = new AclAddRemoveDialog();
    dialog.setSwitch(sw,vlanInf);
    dialog.showDialog();

  }
  boolean chkIP(String st){
    if(st.equals(""))
      return true;
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkSubnet(String st){
    if(st.equals(""))
      return true;
    String temp = "";
    String ip = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 255)){
          temp = "";
          chk = false;
            }else if ((num == 252)||(num == 248)||(num == 240)||(num == 224)||(num == 192)||(num == 128)||(num == 254)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 0)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
  boolean chkInteger(String st){
    try{
      Integer.parseInt(st);
      return true;
    }catch (Exception e){
      return false;
    }
  }
}