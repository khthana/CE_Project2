package netmaker;

import java.util.Vector;
public class RouterEthINF {
  private String interfaceName = "";
  private String ipAddress = "";
  private String subnet = "";
  private Connection connection ;
  private Vector subInterfaces = new Vector();//Vector of SubInterface class
  private boolean shutdown;
  private Vector accessGroups = new Vector();
  private boolean connected = false;
  public RouterEthINF() {
  }
  public RouterEthINF(String interfaceName){
    this.interfaceName = interfaceName ;
  }
  public String getInterfaceName() {
    return interfaceName;
  }
  public void setInterfaceName(String interfaceName) {
    this.interfaceName = interfaceName;
  }
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }
  public String getSubnet() {
    return subnet;
  }
  public void setSubnet(String subnet) {
    this.subnet = subnet;
  }
  public Connection getConnection() {
    return connection;
  }
  public void setConnection(Connection connection) {
    this.connection = connection;
  }
  public Vector getSubInterfaces() {
    return subInterfaces;
  }
  public void setSubInterfaces(Vector subInterfaces) {
    this.subInterfaces = subInterfaces;
  }
  public boolean isShutdown() {
    return shutdown;
  }
  public void setShutdown(boolean shutdown) {
    this.shutdown = shutdown;
  }
  public Vector getAccessGroups() {
    return accessGroups;
  }
  public void setAccessGroups(Vector accessGroups) {
    this.accessGroups = accessGroups;
  }
  ////////////////////////function//////////////////////////////
  public void addAccessGroup(String id, boolean incoming) {
    if (!this.isAccessGroupAdded(id)){
      this.accessGroups.addElement(new AccessGroup(id, incoming));
    }
  }
  private boolean isAccessGroupAdded(String id)  {
    int lastIndex = this.accessGroups.size();
    int i=0;
    while (i<lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(i)).getId().equalsIgnoreCase(id))
        return true;
      i++;
    }
    return false;
  }
  public void removeAccessGroup(String id) {
    if (this.indexOfAccessGroup(id) != -1)
      this.accessGroups.removeElementAt(this.indexOfAccessGroup(id));
  }
  private int indexOfAccessGroup(String id)  {
    int lastIndex = this.accessGroups.size();
    int index = 0;
    while (index < lastIndex){
      if (((AccessGroup)this.accessGroups.elementAt(index)).getId().equalsIgnoreCase(id))
        return index;
      index++;
    }
    return -1;
  }
  public void setConnected(boolean connected) {
    this.connected = connected;
  }
  public boolean isConnected() {
    return connected;
  }
}