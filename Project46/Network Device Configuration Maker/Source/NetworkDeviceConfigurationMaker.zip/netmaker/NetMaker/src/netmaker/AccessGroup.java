package netmaker;

public class AccessGroup {
  private String id;//id of ACL
  private boolean incoming;//incoming or outgoing
  public AccessGroup() {
  }
  public AccessGroup(String id, boolean incoming)  {
    this.id = id;
    this.incoming = incoming;
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public boolean isIncoming() {
    return incoming;
  }
  public void setIncoming(boolean incoming) {
    this.incoming = incoming;
  }

}