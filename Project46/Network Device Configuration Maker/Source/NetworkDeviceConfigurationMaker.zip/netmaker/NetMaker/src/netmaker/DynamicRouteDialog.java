package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DynamicRouteDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JTextField network = new JTextField();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private JLabel jLabel1 = new JLabel();
  private Router rt;
  private boolean isNew;
  private String temp;
  private int a;

  public DynamicRouteDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public DynamicRouteDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    jLabel1.setText("Remote Network");
    this.setTitle("Dynamic Routing");
    panel1.add(network,     new XYConstraints(140, 30, 120, -1));
    panel1.add(jLabel1,  new XYConstraints(30, 30, -1, -1));
    panel1.add(cancel,       new XYConstraints(180, 70, -1, -1));
    panel1.add(ok,      new XYConstraints(110, 70, -1, -1));
    this.getContentPane().add(panel1, BorderLayout.CENTER);
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(300,150);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }
  public void setProtocol(Router rt1,String temp1,boolean chk){
    rt = rt1;
    temp = temp1;
    isNew = chk;
  }
  public void setProtocol(Router rt1,String temp1,int a,boolean chk){
    rt = rt1;
    temp = temp1;
    isNew = chk;
    this.a=a;
    if(temp.equals("RIP")){
      String rip = (String)rt.getRouting().getDynamicRoutes().getRip().elementAt(a);
      network.setText(rip);
    }
    if(temp.equals("IGRP")){
      String igrp = (String)rt.getRouting().getDynamicRoutes().getIgrp().elementAt(a);
      network.setText(igrp);
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    boolean isError = false;
if(chkIP(network.getText())){
  isError = false;
}else{
  isError = true;
  network.setText("");
  ErrorDialog dialog = new ErrorDialog();
  dialog.setText("Illegal IP Address! Please try again");
  dialog.showDialog();
}
if(!isError){
    if(isNew){
    if(temp.equals("RIP"))
    rt.getRouting().getDynamicRoutes().getRip().addElement(network.getText());
    if(temp.equals("IGRP"))
    rt.getRouting().getDynamicRoutes().getIgrp().addElement(network.getText());
    }else{
      if(temp.equals("RIP")){
        rt.getRouting().getDynamicRoutes().getRip().removeElementAt(a);
        rt.getRouting().getDynamicRoutes().getRip().insertElementAt(network.getText(),a);
      }if(temp.equals("IGRP")){
        rt.getRouting().getDynamicRoutes().getIgrp().removeElementAt(a);
        rt.getRouting().getDynamicRoutes().getIgrp().insertElementAt(network.getText(),a);
      }
    }
    dispose();
  }
  }
  void cancel_actionPerformed(ActionEvent e) {
    dispose();
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
}