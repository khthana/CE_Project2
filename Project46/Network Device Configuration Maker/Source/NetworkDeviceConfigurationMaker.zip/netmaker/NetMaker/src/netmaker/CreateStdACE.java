package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CreateStdACE extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList jList1 = new JList();
  private JButton create = new JButton();
  private JButton edit = new JButton();
  private JButton remove = new JButton();
  private JButton ok = new JButton();
  private JButton cancel = new JButton();
  private StdACL stdACL;
  private Vector list1 = new Vector(),forCancel = new Vector();


  public CreateStdACE(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public CreateStdACE() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    create.setBackground(SystemColor.inactiveCaptionText);
    create.setText("Create");
    create.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        create_actionPerformed(e);
      }
    });
    edit.setBackground(SystemColor.inactiveCaptionText);
    edit.setText("Edit");
    edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        edit_actionPerformed(e);
      }
    });
    remove.setBackground(SystemColor.inactiveCaptionText);
    remove.setText("Remove");
    remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        remove_actionPerformed(e);
      }
    });
    ok.setBackground(SystemColor.inactiveCaptionText);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setBackground(SystemColor.inactiveCaptionText);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jScrollPane1,      new XYConstraints(19, 15, 414, 145));
    panel1.add(remove,   new XYConstraints(350, 180, -1, -1));
    panel1.add(create,    new XYConstraints(200, 180, -1, -1));
    panel1.add(cancel,    new XYConstraints(355, 225, -1, -1));
    panel1.add(ok,   new XYConstraints(285, 225, -1, -1));
    panel1.add(edit,   new XYConstraints(285, 180, -1, -1));
    jScrollPane1.getViewport().add(jList1, null);
    this.setTitle("Standard ACL");
  }

  public void setACL(StdACL stdACL1){
    stdACL = stdACL1;
    list1.removeAllElements();
    this.setTitle("ACL"+stdACL.getId());
    String temp;
    for(int i=0;i<stdACL.getAces().size();i++){
      StdACE stdACE = (StdACE)stdACL.getAces().elementAt(i);
      temp = stdACE.getStringACE();
      list1.addElement(temp);
    }
    jList1.setListData(list1);
  }
  public void showDialog() {
    for(int i=0;i<stdACL.getAces().size();i++){
      forCancel.addElement(stdACL.getAces().elementAt(i));
    }
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(455,300);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void create_actionPerformed(ActionEvent e) {
    StdACE stdACE = new StdACE();
    stdACL.getAces().addElement(stdACE);
    StdAceDialog stdAceDialog = new StdAceDialog();
    stdAceDialog.setStdAce(stdACE,stdACL,true);
    stdAceDialog.showDialog();
    setACL(stdACL);

  }

  void remove_actionPerformed(ActionEvent e) {
    int temp = this.jList1.getSelectedIndex();
    if(temp >= 0){
    stdACL.getAces().removeElementAt(temp);
    setACL(stdACL);
    }
  }

  void ok_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void edit_actionPerformed(ActionEvent e) {
    int temp = this.jList1.getSelectedIndex();
    if(temp >= 0){
    StdACE stdACE = (StdACE)stdACL.getAces().elementAt(temp);
    StdAceDialog stdAceDialog = new StdAceDialog();
    stdAceDialog.setStdAce(stdACE,stdACL,false);
    stdAceDialog.showDialog();
    setACL(stdACL);
    }
  }

  void cancel_actionPerformed(ActionEvent e) {
    stdACL.setAces(forCancel);
    dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
     super.processWindowEvent(e) ;
     if (e.getID() == WindowEvent.WINDOW_CLOSING) {
       stdACL.setAces(forCancel);
       dispose();
     }
   }


}