package netmaker;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class RouterDialog extends JDialog {
  private Router router = new Router();
  private XYLayout xYLayout1 = new XYLayout();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  private JPanel generalRTPanel = new JPanel();
  private JPanel interfacePanel = new JPanel();
  private XYLayout xYLayout2 = new XYLayout();
  private XYLayout xYLayout3 = new XYLayout();
  private JTextField password = new JTextField();
  private XYLayout xYLayout4 = new XYLayout();
  private JTextField hostName = new JTextField();
  private JLabel pSWRouter = new JLabel();
  private JLabel hostnameRouter = new JLabel();
  private JPanel jPanel3 = new JPanel();
  private JButton okButton = new JButton();
  private JButton cancelButton = new JButton();
  private JButton propertyButton = new JButton();
  private JPanel jPanel5 = new JPanel();
  private XYLayout xYLayout6 = new XYLayout();
  private JLabel defaultGateway = new JLabel();
  private JTextField gateway = new JTextField();
  private Vector list =  new Vector();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JButton subInfButton = new JButton();
  XYLayout xYLayout5 = new XYLayout();
  private Router rt;
  private JList jList1 = new JList();
  private Vector forChk = new Vector(),fastEth = new Vector(),serialEth = new Vector();
  public RouterDialog(Frame frame, String title, boolean modal,String name) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public RouterDialog(String name) {  //
    this(null, "", true,name);
  }
  //--------------------------------------------------------------------//


  //--------------------------------------------------------------------//
  private void jbInit() throws Exception {
   this.getContentPane().setLayout(xYLayout5);
//   jList1.setListData(list);
   this.setTitle(router.getHostName());
    generalRTPanel.setLayout(xYLayout2);
    interfacePanel.setLayout(xYLayout3);
    jTabbedPane1.setSize(400,456);
    jTabbedPane1.setVisible(true);
    xYLayout1.setWidth(400);
    xYLayout1.setHeight(456);
    xYLayout2.setWidth(400);
    xYLayout3.setHeight(456);
    xYLayout3.setWidth(400);
    xYLayout2.setHeight(456);
    xYLayout4.setWidth(400);
    xYLayout4.setHeight(456);
    pSWRouter.setText("Password");
    hostnameRouter.setText("host name");
    jPanel3.setLayout(xYLayout4);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setPreferredSize(new Dimension(404, 460));
    jPanel3.setBackground(SystemColor.inactiveCaptionText);
    okButton.setBackground(SystemColor.inactiveCaptionText);
    okButton.setText("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    cancelButton.setBackground(SystemColor.inactiveCaptionText);
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancelButton_actionPerformed(e);
      }
    });
    generalRTPanel.setBackground(SystemColor.inactiveCaptionText);
    generalRTPanel.setPreferredSize(new Dimension(400, 456));
    jTabbedPane1.setBackground(SystemColor.inactiveCaptionText);
    this.getContentPane().setBackground(UIManager.getColor("inactiveCaptionText"));
    interfacePanel.setBackground(UIManager.getColor("inactiveCaptionText"));
    propertyButton.setBackground(SystemColor.inactiveCaptionText);
    propertyButton.setText("Properties");
    propertyButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        propertyButton_actionPerformed(e);
      }
    });
    jPanel5.setBackground(SystemColor.inactiveCaptionText);
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setLayout(xYLayout6);
    defaultGateway.setText("Default Gateway");
    subInfButton.setBackground(SystemColor.inactiveCaptionText);
    subInfButton.setText("Sub-Interface");
    subInfButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        subInfButton_actionPerformed(e);
      }
    });
    xYLayout5.setWidth(402);
    xYLayout5.setHeight(457);
    jLabel1.setText("IOS Version");
    this.getContentPane().add(jTabbedPane1,        new XYConstraints(5, 4, 390, 409));
    jPanel3.add(hostnameRouter,    new XYConstraints(25, 100, -1, -1));
    jPanel3.add(pSWRouter,    new XYConstraints(25, 200, -1, -1));
    jPanel3.add(hostName,    new XYConstraints(125, 100, 150, -1));
    jPanel3.add(password,    new XYConstraints(125, 200, 150, -1));
    jPanel3.add(gateway,      new XYConstraints(125, 150, 150, -1));
    jPanel3.add(defaultGateway,     new XYConstraints(25, 150, -1, -1));
    jPanel3.add(jLabel1,     new XYConstraints(25, 50, -1, -1));
    jPanel3.add(iosVersion,     new XYConstraints(125, 50, 150, -1));
    generalRTPanel.add(jPanel3,     new XYConstraints(42, 33, 308, 276));
    jTabbedPane1.add(generalRTPanel,   "General");
    jTabbedPane1.add(interfacePanel,   "Interface");
    interfacePanel.add(jPanel5, new XYConstraints(1, 0, 392, 300));
    jPanel5.add(jScrollPane1,       new XYConstraints(74, 33, 217, 197));
    jScrollPane1.getViewport().add(jList1, null);
    jPanel5.add(propertyButton,  new XYConstraints(210, 250, -1, -1));
    jPanel5.add(subInfButton,   new XYConstraints(75, 250, -1, -1));
    this.getContentPane().add(okButton, new XYConstraints(230, 420, -1, -1));
    this.getContentPane().add(cancelButton, new XYConstraints(301, 419, -1, -1));

    hostName.setText(router.getHostName());
    jTabbedPane1.setSelectedComponent(generalRTPanel);

  }

  public void chkRT(Router rt1){
    rt = rt1;
    this.setTitle(rt.getHostName());
    this.hostName.setText(rt.getHostName());
    this.gateway.setText(rt.getDefaultGateWay());
    this.password.setText(rt.getPassword());
    this.iosVersion.setText(rt.getIosVersion());
    for(int i=0;i<rt.getNFastEthPort();i++){
      RouterEthINF rtInf = (RouterEthINF)rt.getFastEthernets().elementAt(i),inf = new RouterEthINF();
      String temp = new String();
      boolean temp2;
      Vector temp3 = new Vector();
      temp = rtInf.getInterfaceName();
      inf.setInterfaceName(temp);
      temp = rtInf.getIpAddress();
      inf.setIpAddress(temp);
      temp = rtInf.getSubnet();
      inf.setSubnet(temp);
      temp2 = rtInf.isConnected();
      inf.setConnected(temp2);
      temp2 = rtInf.isShutdown();
      inf.setShutdown(temp2);
      Vector accesses = new Vector();
      temp3 = rtInf.getAccessGroups();
      for(int j=0 ; j<temp3.size();j++){
        AccessGroup access = new AccessGroup(),temp4 = (AccessGroup)temp3.elementAt(j);
        temp = temp4.getId();
        temp2 = temp4.isIncoming();
        access.setId(temp);
        access.setIncoming(temp2);
        accesses.addElement(access);
      }
      inf.setAccessGroups(accesses);
      temp3 = rtInf.getSubInterfaces();
      Vector vSub = new Vector();
      for(int k=0;k<temp3.size();k++){
        SubInterface subInf = (SubInterface)temp3.elementAt(i),sub = new SubInterface();
        temp = subInf.getInterfaceName();
        sub.setInterfaceName(temp);
        temp = subInf.getProtocolEncap();
        sub.setProtocolEncap(temp);
        temp = subInf.getVlan();
        sub.setVlanNo(temp);
        temp = subInf.getIpAddress();
        sub.setIpAddress(temp);
        temp = subInf.getSubnet();
        sub.setSubnet(temp);
        temp2 = subInf.isConnected();
        sub.setConnected(temp2);
        temp2 = subInf.isShutdown();
        sub.setShutdown(temp2);
        temp3 = subInf.getAccessGroups();
        for(int j=0 ; j<temp3.size();j++){
          AccessGroup access = new AccessGroup(),temp4 = (AccessGroup)temp3.elementAt(j);
          temp = temp4.getId();
          temp2 = temp4.isIncoming();
          access.setId(temp);
          access.setIncoming(temp2);
          accesses.addElement(access);
        }
        sub.setAccessGroups(accesses);
        vSub.addElement(sub);
      }
      inf.setSubInterfaces(vSub);
      fastEth.addElement(inf);
    }
    Vector serials = rt.getSerials();
    for(int i=0;i<serials.size();i++){
      SerialINF serialInf = (SerialINF)rt.getSerials().elementAt(i),inf = new SerialINF();
      String temp = new String();
      boolean temp2;
      Vector temp3 = new Vector();
      temp = serialInf.getClockRate();
      inf.setClockRate(temp);
      temp = serialInf.getInterfaceName();
      inf.setInterfaceName(temp);
      temp = serialInf.getIpAddress();
      inf.setIpAddress(temp);
      temp = serialInf.getSubnet();
      inf.setSubnet(temp);
      temp2 = serialInf.isConnected();
      inf.setConnected(temp2);
      temp2 = serialInf.isShutdown();
      inf.setShutdown(temp2);
      Vector accesses = new Vector();
      temp3 = serialInf.getAccessGroups();
      for(int j=0 ; j<temp3.size();j++){
        AccessGroup access = new AccessGroup(),temp4 = (AccessGroup)temp3.elementAt(j);
        temp = temp4.getId();
        temp2 = temp4.isIncoming();
        access.setId(temp);
        access.setIncoming(temp2);
        accesses.addElement(access);
      }
      inf.setAccessGroups(accesses);
      serialEth.addElement(inf);
    }
    setList();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancelButton_actionPerformed(null);
    }
  }
  public void showDialog1() {
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  Dimension frameSize = this.getSize();
  if (frameSize.height > screenSize.height) {
    frameSize.height = screenSize.height;
  }
  if (frameSize.width > screenSize.width) {
    frameSize.width = screenSize.width;
  }

  this.setSize(400,490);
  this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
  this.setVisible(true);
  }

  void propertyButton_actionPerformed(ActionEvent e) {
    int num = jList1.getSelectedIndex();
    if(num >= 0){
    ForChkType chk = (ForChkType)forChk.elementAt(num);
    if(chk.getType() == 0){
      RouterEthINF rtInf = (RouterEthINF)rt.getFastEthernets().elementAt(chk.getNum());
      ConfigInfRouter dialog = new ConfigInfRouter();
      dialog.setRouter(rt,rtInf);
      dialog.showDialog();
    }else if(chk.getType() == 1){
      SerialINF serial = (SerialINF)rt.getSerials().elementAt(chk.getNum());
      ConfigSerialRouter dialog = new ConfigSerialRouter();
      dialog.setRouter(rt,serial);
      dialog.showDialog();
    }else if(chk.getType() == 2){
      SubInterface subInf = (SubInterface)((RouterEthINF)rt.getFastEthernets()
           .elementAt(chk.getRemark())).getSubInterfaces().elementAt(chk.getNum());
      ConfigSubInf dialog = new ConfigSubInf();
      dialog.setRouter(rt,subInf);
      dialog.showDialog();
    }
    }
  }
 void setList(){
   forChk.removeAllElements();
   list.removeAllElements();
   for(int i=0;i<rt.getFastEthernets().size();i++){
     RouterEthINF inf = (RouterEthINF)rt.getFastEthernets().elementAt(i);
     list.addElement(inf.getInterfaceName());
     forChk.addElement(new ForChkType(i,0,0));
     for(int j=0;j<inf.getSubInterfaces().size();j++){
       SubInterface subInf = (SubInterface)inf.getSubInterfaces().elementAt(j);
       list.addElement(subInf.getInterfaceName());
       forChk.addElement(new ForChkType(j,2,i));
     }
   }
   for(int i=0;i<rt.getSerials().size();i++){
     SerialINF serial = (SerialINF)rt.getSerials().elementAt(i);
     list.addElement(serial.getInterfaceName());
     forChk.addElement(new ForChkType(i,1,0));
   }

   jList1.setListData(list);

 }
  void okButton_actionPerformed(ActionEvent e) {
    boolean isError = false;
    String name;
    String psw;
    name = hostName.getText();
    psw =password.getText();
    if (!isError){
      if(!name.equals(rt.getHostName())){

        for(int i = 0 ;i < Frame1.vRouter.size();i++){
          Router rt1 = (Router)Frame1.vRouter.elementAt(i);
          String temp = rt1.getHostName();
          if(name.equals(temp)){
            isError = true;
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Hostname is already! Please try again");
            dialog.showDialog();
          }
        }
      }
    }
    if (!isError)
    if(chkIP(gateway.getText()) || gateway.getText().equals("")){
      isError = false;
    }else{
    isError = true;
    gateway.setText("");
    ErrorDialog dialog = new ErrorDialog();
    dialog.setText("Illegal Default Gateway! Please try again");
    dialog.showDialog();
    }
    if(!isError){
      if(!gateway.getText().equals(""))
      rt.setDefaultGateWay(correctIP(gateway.getText()));
      else rt.setDefaultGateWay("");
    rt.setHostName(name);
      rt.setPassword(psw);
      rt.setIosVersion(this.iosVersion.getText());
    this.dispose();
    }

  }

  void cancelButton_actionPerformed(ActionEvent e) {
    rt.setFastEthernets(fastEth);
    this.dispose();
  }

  void subInfButton_actionPerformed(ActionEvent e) {
    RouterEthINF inf = new RouterEthINF();
    String temp;
    temp = (String)jList1.getSelectedValue();
    for(int i=0;i<rt.getFastEthernets().size();i++){
      RouterEthINF inf1 = (RouterEthINF)rt.getFastEthernets().elementAt(i);
      if(inf1.getInterfaceName().equals(temp)){
        inf = inf1;
      }
    }
    int num = jList1.getSelectedIndex();
    if(num >= 0){
    ForChkType chk = (ForChkType)forChk.elementAt(num);
    if(chk.getType() == 0){
    SubInfDialog dialog = new SubInfDialog();
    dialog.chkInterface(inf);
    dialog.showDialog1();
    }}
    setList();
  }
  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }
  private JLabel jLabel1 = new JLabel();
  private JTextField iosVersion = new JTextField();
}
class ForChkType {

  private int num;
  private int type;//0=inf 1= serial 2= subinf
  private int remark;//
  public ForChkType() {
  }
  public ForChkType(int i,int j ,int k) {
    num = i;
    type = j;
    remark = k;
  }
  public int getNum() {
    return num;
  }
  public void setNum(int num) {
    this.num = num;
  }
  public void setType(int type) {
    this.type = type;
  }
  public int getType() {
    return type;
  }
  public void setRemark(int remark) {
    this.remark = remark;
  }
  public int getRemark() {
    return remark;
  }
}