package netmaker;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ExtAceDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JRadioButton permit = new JRadioButton();
  private JRadioButton deny = new JRadioButton();
  private JComboBox protocol = new JComboBox();
  private JPanel jPanel1 = new JPanel();
  private JCheckBox chkBoxSource = new JCheckBox();
  private XYLayout xYLayout2 = new XYLayout();
  private JTextField ipSource = new JTextField();
  private JTextField wildCardSource = new JTextField();
  private JTextField lowerPortSource = new JTextField();
  private JTextField upperPortSource = new JTextField();
  private JTextField portSourceEq = new JTextField();
  private JTextField portSourceNeq = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JRadioButton anyPortSource = new JRadioButton();
  private JRadioButton betweenPortSource = new JRadioButton();
  private JRadioButton portNumSource = new JRadioButton();
  private JRadioButton exceptPortSource = new JRadioButton();
  private JLabel jLabel3 = new JLabel();
  private JTextField portDestNeq = new JTextField();
  private JPanel jPanel2 = new JPanel();
  private JTextField portDestEq = new JTextField();
  private JTextField upperPortDest = new JTextField();
  private JTextField lowerPortDest = new JTextField();
  private JTextField wildCardDest = new JTextField();
  private XYLayout xYLayout3 = new XYLayout();
  private JTextField ipDest = new JTextField();
  private JRadioButton exceptPortDest = new JRadioButton();
  private JRadioButton portNumDest = new JRadioButton();
  private JRadioButton betweenPortDest = new JRadioButton();
  private JRadioButton anyPortDest = new JRadioButton();
  private JCheckBox chkBoxDest = new JCheckBox();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private ExtACE extACE;
  private ExtACL extACL;
  private boolean newElement;
  private ButtonGroup sourceGroup = new ButtonGroup();
  private ButtonGroup DestGroup = new ButtonGroup();
  private ButtonGroup permitOrDeny = new ButtonGroup();

  public ExtAceDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ExtAceDialog() {
    this(null, "", true);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(xYLayout1);
    panel1.setBackground(SystemColor.inactiveCaptionText);
    permit.setBackground(SystemColor.inactiveCaptionText);
    permit.setText("permit");
    deny.setBackground(SystemColor.inactiveCaptionText);
    deny.setText("deny");
    jPanel1.setBackground(SystemColor.inactiveCaptionText);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(xYLayout2);
    chkBoxSource.setBackground(SystemColor.inactiveCaptionText);
    chkBoxSource.setText("all IP Address");
    chkBoxSource.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        chkBoxSource_actionPerformed(e);
      }
    });
    jLabel1.setText("IP Address");
    jLabel2.setText("WildCard");
    anyPortSource.setBackground(SystemColor.inactiveCaptionText);
    anyPortSource.setText("any Port");
    anyPortSource.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        anyPortSource_actionPerformed(e);
      }
    });
    betweenPortSource.setBackground(SystemColor.inactiveCaptionText);
    betweenPortSource.setText("between port number");
    betweenPortSource.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        betweenPortSource_actionPerformed(e);
      }
    });
    portNumSource.setBackground(SystemColor.inactiveCaptionText);
    portNumSource.setText("port number");
    portNumSource.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        portNumSource_actionPerformed(e);
      }
    });
    exceptPortSource.setBackground(SystemColor.inactiveCaptionText);
    exceptPortSource.setText("except port number");
    exceptPortSource.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        exceptPortSource_actionPerformed(e);
      }
    });
    jLabel3.setText("and");
    jPanel2.setLayout(xYLayout3);
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBackground(SystemColor.inactiveCaptionText);
    exceptPortDest.setBackground(SystemColor.inactiveCaptionText);
    exceptPortDest.setText("except port number");
    exceptPortDest.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        exceptPortDest_actionPerformed(e);
      }
    });
    portNumDest.setBackground(SystemColor.inactiveCaptionText);
    portNumDest.setText("port number");
    portNumDest.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        portNumDest_actionPerformed(e);
      }
    });
    betweenPortDest.setBackground(SystemColor.inactiveCaptionText);
    betweenPortDest.setText("between port number");
    betweenPortDest.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        betweenPortDest_actionPerformed(e);
      }
    });
    anyPortDest.setBackground(SystemColor.inactiveCaptionText);
    anyPortDest.setText("any Port");
    anyPortDest.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        anyPortDest_actionPerformed(e);
      }
    });
    chkBoxDest.setBackground(SystemColor.inactiveCaptionText);
    chkBoxDest.setText("all IP Address");
    chkBoxDest.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        chkBoxDest_actionPerformed(e);
      }
    });
    jLabel4.setText("and");
    jLabel5.setText("WildCard");
    jLabel6.setText("IP Address");
    jLabel7.setText("protocol");
    jLabel8.setText("Source");
    jLabel9.setText("Destination");
    jButton1.setBackground(SystemColor.inactiveCaptionText);
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBackground(SystemColor.inactiveCaptionText);
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(permit,  new XYConstraints(70, 20, -1, -1));
    panel1.add(deny,   new XYConstraints(70, 45, -1, -1));
    panel1.add(jPanel1,         new XYConstraints(30, 100, 375, 200));
    jPanel1.add(chkBoxSource,  new XYConstraints(10, 10, -1, -1));
    jPanel1.add(jLabel1,  new XYConstraints(10, 45, -1, -1));
    jPanel1.add(ipSource,  new XYConstraints(80, 40, 100, -1));
    jPanel1.add(jLabel2,    new XYConstraints(200, 45, -1, -1));
    jPanel1.add(wildCardSource,  new XYConstraints(260, 40, 100, -1));
    jPanel1.add(anyPortSource,  new XYConstraints(10, 75, -1, -1));
    jPanel1.add(betweenPortSource,  new XYConstraints(170, 75, -1, -1));
    jPanel1.add(portNumSource,    new XYConstraints(10, 135, -1, -1));
    jPanel1.add(exceptPortSource,  new XYConstraints(170, 135, -1, -1));
    jPanel1.add(portSourceNeq,    new XYConstraints(190, 160, 30, -1));
    jPanel1.add(portSourceEq,    new XYConstraints(20, 160, 30, -1));
    jPanel1.add(upperPortSource,     new XYConstraints(260, 100, 30, -1));
    jPanel1.add(jLabel3,    new XYConstraints(230, 105, -1, -1));
    jPanel1.add(lowerPortSource,      new XYConstraints(190, 100, 30, -1));
    panel1.add(jPanel2,   new XYConstraints(30, 330, 375, 200));
    jPanel2.add(chkBoxDest, new XYConstraints(10, 10, -1, -1));
    jPanel2.add(jLabel6, new XYConstraints(10, 45, -1, -1));
    jPanel2.add(ipDest, new XYConstraints(80, 40, 100, -1));
    jPanel2.add(jLabel5, new XYConstraints(200, 45, -1, -1));
    jPanel2.add(wildCardDest, new XYConstraints(260, 40, 100, -1));
    jPanel2.add(anyPortDest, new XYConstraints(10, 75, -1, -1));
    jPanel2.add(betweenPortDest, new XYConstraints(170, 75, -1, -1));
    jPanel2.add(portNumDest, new XYConstraints(10, 135, -1, -1));
    jPanel2.add(exceptPortDest, new XYConstraints(170, 135, -1, -1));
    jPanel2.add(portDestNeq, new XYConstraints(190, 160, 30, -1));
    jPanel2.add(portDestEq, new XYConstraints(20, 160, 30, -1));
    jPanel2.add(upperPortDest, new XYConstraints(260, 100, 30, -1));
    jPanel2.add(jLabel4, new XYConstraints(230, 105, -1, -1));
    jPanel2.add(lowerPortDest, new XYConstraints(190, 100, 30, -1));
    panel1.add(jLabel7,              new XYConstraints(175, 20, 57, 24));
    panel1.add(protocol,   new XYConstraints(240, 20, -1, -1));
    panel1.add(jLabel8,   new XYConstraints(29, 82, -1, -1));
    panel1.add(jLabel9,   new XYConstraints(28, 312, -1, -1));
    panel1.add(jButton1,    new XYConstraints(250, 540, -1, -1));
    panel1.add(jButton2,      new XYConstraints(330, 540, -1, -1));
    permitOrDeny.add(permit);
    permitOrDeny.add(deny);
    sourceGroup.add(anyPortSource);
    sourceGroup.add(betweenPortSource);
    sourceGroup.add(exceptPortSource);
    sourceGroup.add(portNumSource);
    DestGroup.add(anyPortDest);
    DestGroup.add(betweenPortDest);
    DestGroup.add(portNumDest);
    DestGroup.add(exceptPortDest);
    protocol.addItem("TCP");
    protocol.addItem("UDP");
    protocol.addItem("IP");
    protocol.addItem("any");
    this.lowerPortDest.setEnabled(false);
    this.upperPortDest.setEnabled(false);
    this.jLabel4.setEnabled(false);
    this.portDestEq.setEnabled(false);
    this.portDestNeq.setEnabled(false);
    this.lowerPortSource.setEnabled(false);
    this.upperPortSource.setEnabled(false);
    this.portSourceEq.setEnabled(false);
    this.portSourceNeq.setEnabled(false);
    this.jLabel3.setEnabled(false);
  }
  public void setACE(ExtACE extACE1,ExtACL extACL1,boolean chk){
    extACL = extACL1;
    newElement = chk;
    extACE = extACE1;
    if(extACE.isPermit()){
      this.permit.setSelected(true);
    }else{
      this.deny.setSelected(true);
    }
    if(extACE.isAnySource()){
      this.chkBoxSource.setSelected(true);
      this.ipSource.setEnabled(false);
      this.wildCardSource.setEnabled(false);
      this.jLabel1.setEnabled(false);
      this.jLabel2.setEnabled(false);
    }else{
      this.ipSource.setText(extACE.getSrcAddress());
      this.wildCardSource.setText(extACE.getWildCardSrcAddress());
    }
    if(extACE.isAnyDestination()){
      this.chkBoxDest.setSelected(true);
      this.ipDest.setEditable(false);
      this.wildCardDest.setEnabled(false);
      this.jLabel5.setEnabled(false);
      this.jLabel6.setEnabled(false);
    }else{
      this.ipDest.setText(extACE.getDestAddress());
      this.wildCardDest.setText(extACE.getWildCardDestAddress());
    }

    if(extACE.isAnySrcPort()){
      this.anyPortSource.setSelected(true);
    }else if(extACE.isRangeSrcPort()){
      this.betweenPortSource.setSelected(true);
      this.lowerPortSource.setText(extACE.getRangeSrcPort1());
      this.upperPortSource.setText(extACE.getRangeSrcPort2());
    }else if(extACE.isEqSrcPort()){
      this.portNumSource.setSelected(true);
      this.portSourceEq.setText(extACE.getSrcPort());
    }else if(extACE.isNeqSrcPort()){
      this.exceptPortSource.setSelected(true);
      this.portSourceNeq.setText(extACE.getSrcPort());
    }
    if(extACE.isAnyDestPort()){
      this.anyPortDest.setSelected(true);
    }else if(extACE.isRangeDestPort()){
      this.betweenPortDest.setSelected(true);
      this.lowerPortDest.setText(extACE.getRangeDestPort1());
      this.upperPortDest.setText(extACE.getRangeDestPort2());
    }else if(extACE.isEqDestPort()){
      this.portNumDest.setSelected(true);
      this.portDestEq.setText(extACE.getDestPort());
    }else if(extACE.isNeqDestPort()){
      this.exceptPortDest.setSelected(true);
      this.portDestNeq.setText(extACE.getDestPort());
    }
    this.setTitle("ACL "+this.extACL.getId());
  }
  public void showDialog() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }

    this.setSize(445,620);
    this.setLocation((screenSize.width - frameSize.width) / 4, (screenSize.height - frameSize.height) / 4);
    this.setVisible(true);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    if(newElement)
      extACL.getAces().removeElement(extACE);
    this.dispose();
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e) ;
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      extACL.getAces().removeElement(extACE);
    this.dispose();
    }
  }
  void jButton1_actionPerformed(ActionEvent e) {
    boolean isError = false;
      extACE.setId(extACL.getId());
      extACE.setProtocol((String)protocol.getSelectedItem());
      if(this.chkBoxSource.isSelected()){
      }else{
        if(this.chkIP(this.ipSource.getText()))
        extACE.setSrcAddress(this.correctIP(this.ipSource.getText()));
        else{
            isError = true;
            ipSource.setText("");
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Illegal source Address! Please try again");
            dialog.showDialog();
            }
            if(!isError)
            if(this.chkWildcard(this.wildCardSource.getText()))
            extACE.setWildCardSrcAddress(this.correctIP(this.wildCardSource.getText()));
            else{
                isError = true;
                wildCardSource.setText("");
                ErrorDialog dialog = new ErrorDialog();
                dialog.setText("Illegal source wildcard! Please try again");
                dialog.showDialog();
    }      }
      if(this.chkBoxDest.isSelected()){
      }else{
        extACE.setDestAddress(this.ipDest.getText());
        extACE.setWildCardDestAddress(this.wildCardDest.getText());
        if(this.chkIP(this.ipDest.getText()))
        extACE.setDestAddress(this.correctIP(this.ipDest.getText()));
        else if(!isError){
            isError = true;
            ipDest.setText("");
            ErrorDialog dialog = new ErrorDialog();
            dialog.setText("Illegal destination Address! Please try again");
            dialog.showDialog();
            }
            if(!isError)
            if(this.chkWildcard(this.wildCardDest.getText()))
            extACE.setWildCardDestAddress(this.correctIP(this.wildCardDest.getText()));
            else{
                isError = true;
                wildCardDest.setText("");
                ErrorDialog dialog = new ErrorDialog();
                dialog.setText("Illegal destination wildcard! Please try again");
                dialog.showDialog();
    }      }
    if(!isError){
      if(this.anyPortSource.isSelected()){
        extACE.setAnySrcPort();
      }else if(this.betweenPortSource.isSelected()){
        extACE.setRangeSrcPort();
        extACE.setRangeSrcPort1(this.lowerPortSource.getText());
        extACE.setRangeSrcPort2(this.upperPortSource.getText());
      }else if(this.portNumSource.isSelected()){
        extACE.setEqSrcPort();
        extACE.setSrcPort(this.portSourceEq.getText());
      }else if(this.exceptPortSource.isSelected()){
        extACE.setNeqSrcPort();
        extACE.setSrcPort(this.portSourceNeq.getText());
      }
      if(this.anyPortDest.isSelected()){
        extACE.setAnyDestPort();
      }else if(this.betweenPortDest.isSelected()){
        extACE.setRangeDestPort();
        extACE.setRangeDestPort1(this.lowerPortDest.getText());
        extACE.setRangeDestPort2(this.upperPortDest.getText());
      }else if(this.portNumDest.isSelected()){
        extACE.setEqDestPort();
        extACE.setDestPort(this.portDestEq.getText());
      }else if(this.exceptPortDest.isSelected()){
        extACE.setNeqDestPort();
        extACE.setDestPort(this.portDestNeq.getText());
      }
      if(this.permit.isSelected()){
        extACE.setPermit(true);
      }else{
        extACE.setPermit(false);
      }
      if(this.chkBoxSource.isSelected()){
        extACE.setAnySource(true);
      }
      if(this.chkBoxDest.isSelected()){
      extACE.setAnyDestination(true);
      }
      this.dispose();
    }

  }

  void chkBoxSource_actionPerformed(ActionEvent e) {
    if(this.chkBoxSource.isSelected()){
      this.ipSource.setEnabled(false);
      this.wildCardSource.setEnabled(false);
      this.jLabel1.setEnabled(false);
      this.jLabel2.setEnabled(false);
    }else{
      this.ipSource.setEnabled(true);
      this.wildCardSource.setEnabled(true);
      this.jLabel1.setEnabled(true);
      this.jLabel2.setEnabled(true);
   }
  }

  void anyPortSource_actionPerformed(ActionEvent e) {
    this.lowerPortSource.setEnabled(false);
    this.upperPortSource.setEnabled(false);
    this.portSourceEq.setEnabled(false);
    this.portSourceNeq.setEnabled(false);
    this.jLabel3.setEnabled(false);
  }

  void betweenPortSource_actionPerformed(ActionEvent e) {
    this.lowerPortSource.setEnabled(true);
    this.upperPortSource.setEnabled(true);
    this.portSourceEq.setEnabled(false);
    this.portSourceNeq.setEnabled(false);
    this.jLabel3.setEnabled(true);
  }

  void portNumSource_actionPerformed(ActionEvent e) {
    this.lowerPortSource.setEnabled(false);
    this.upperPortSource.setEnabled(false);
    this.portSourceEq.setEnabled(true);
    this.portSourceNeq.setEnabled(false);
    this.jLabel3.setEnabled(false);
  }

  void exceptPortSource_actionPerformed(ActionEvent e) {
    this.lowerPortSource.setEnabled(false);
    this.upperPortSource.setEnabled(false);
    this.portSourceEq.setEnabled(false);
    this.portSourceNeq.setEnabled(true);
    this.jLabel3.setEnabled(false);
  }

  void anyPortDest_actionPerformed(ActionEvent e) {
    this.lowerPortDest.setEnabled(false);
    this.upperPortDest.setEnabled(false);
    this.jLabel4.setEnabled(false);
    this.portDestEq.setEnabled(false);
    this.portDestNeq.setEnabled(false);
  }

  void betweenPortDest_actionPerformed(ActionEvent e) {
    this.lowerPortDest.setEnabled(true);
    this.upperPortDest.setEnabled(true);
    this.jLabel4.setEnabled(true);
    this.portDestEq.setEnabled(false);
    this.portDestNeq.setEnabled(false);
  }

  void portNumDest_actionPerformed(ActionEvent e) {
    this.lowerPortDest.setEnabled(false);
    this.upperPortDest.setEnabled(false);
    this.jLabel4.setEnabled(false);
    this.portDestEq.setEnabled(true);
    this.portDestNeq.setEnabled(false);
  }

  void exceptPortDest_actionPerformed(ActionEvent e) {
    this.lowerPortDest.setEnabled(false);
    this.upperPortDest.setEnabled(false);
    this.jLabel4.setEnabled(false);
    this.portDestEq.setEnabled(false);
    this.portDestNeq.setEnabled(true);
  }

  void chkBoxDest_actionPerformed(ActionEvent e) {
    if(this.chkBoxDest.isSelected()){
      this.ipDest.setEnabled(false);
      this.wildCardDest.setEnabled(false);
      this.jLabel6.setEnabled(false);
      this.jLabel5.setEnabled(false);
    }else{
      this.ipDest.setEnabled(true);
      this.wildCardDest.setEnabled(true);
      this.jLabel6.setEnabled(true);
      this.jLabel5.setEnabled(true);
   }

  }

  boolean chkIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          if((num>=0)&&(num<=255)){
            temp = "";
          }else {
            return false;
          }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  boolean chkWildcard(String st){
    String temp = "";
    String ip = "";
    boolean chk = false;
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          if (!chk)
            if((num == 0)){
          temp = "";
          chk = false;
            }else if ((num == 127)||(num == 63)||(num == 31)||(num == 15)||(num == 7)||(num == 3)||(num == 1)||(num == 0)){
              chk = true;
              temp = "";
            }else
              return false;
            if (chk){
              if(num != 255)
                return false;
            }
        }catch(Exception e){
          return false;
        }

      }else{
        temp = temp + sub;
      }
    }
    if((count == 3)&&(!st.substring(st.length()-1,st.length()).equals(".")))
      return true;
    else{
      return false;
    }
  }
  String correctIP(String st){
    String temp = "";
    String ip = "";
    int count = 0;
    for(int i=0 ; i<st.length() ; i++){
      String sub = st.substring(i,i+1);
      if(sub.equals(".")){
        count++;
        try{
          int num = Integer.parseInt(temp);
          ip = ip+String.valueOf(num)+".";
          temp = "";
        }catch(Exception e){
        }

      }else{
        temp = temp + sub;
      }
    }
    try{
      int num = Integer.parseInt(temp);
      ip = ip+String.valueOf(num)+".";
      temp = "";
    }catch(Exception e){
    }

    ip = ip.substring(0,ip.length()-1);
    return ip;
  }


}