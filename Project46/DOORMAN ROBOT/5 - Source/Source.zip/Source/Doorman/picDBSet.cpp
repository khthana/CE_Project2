// picDBSet.h : Implementation of the CpicDBSet class



// CpicDBSet implementation

// code generated on 2 ���Ҥ� 2547, 2:32

#include "stdafx.h"
#include "picDBSet.h"
IMPLEMENT_DYNAMIC(CpicDBSet, CRecordset)

CpicDBSet::CpicDBSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	m_PIC_ID = 0;
	m_X_EYE = 0;
	m_Y_EYE = 0;
	m_AVG_EYE = 0;
	m_STD_EYE = 0;
	m_X_NOSE = 0;
	m_Y_NOSE = 0;
	m_AVG_NOSE = 0;
	m_STD_NOSE = 0;
	m_X_MOUTH = 0;
	m_Y_MOUTH = 0;
	m_AVG_MOUTH = 0;
	m_STD_MOUTH = 0;
	m_nFields = 13;
	m_nDefaultType = snapshot;
}
//#error Security Issue: The connection string may contain a password
// The connection string below may contain plain text passwords and/or
// other sensitive information. Please remove the #error after reviewing
// the connection string for any security related issues. You may want to
// store the password in some other form or use a different user authentication.
CString CpicDBSet::GetDefaultConnect()
{
	return _T("DSN=doorman;DBQ=C:\\DoormanRobot\\DB\\doorman.mdb;DriverId=25;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;");
}

CString CpicDBSet::GetDefaultSQL()
{
	return _T("[picDB]");
}

void CpicDBSet::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
// Macros such as RFX_Text() and RFX_Int() are dependent on the
// type of the member variable, not the type of the field in the database.
// ODBC will try to automatically convert the column value to the requested type
	RFX_Long(pFX, _T("[PIC_ID]"), m_PIC_ID);
	RFX_Long(pFX, _T("[X_EYE]"), m_X_EYE);
	RFX_Long(pFX, _T("[Y_EYE]"), m_Y_EYE);
	RFX_Long(pFX, _T("[AVG_EYE]"), m_AVG_EYE);
	RFX_Long(pFX, _T("[STD_EYE]"), m_STD_EYE);
	RFX_Long(pFX, _T("[X_NOSE]"), m_X_NOSE);
	RFX_Long(pFX, _T("[Y_NOSE]"), m_Y_NOSE);
	RFX_Long(pFX, _T("[AVG_NOSE]"), m_AVG_NOSE);
	RFX_Long(pFX, _T("[STD_NOSE]"), m_STD_NOSE);
	RFX_Long(pFX, _T("[X_MOUTH]"), m_X_MOUTH);
	RFX_Long(pFX, _T("[Y_MOUTH]"), m_Y_MOUTH);
	RFX_Long(pFX, _T("[AVG_MOUTH]"), m_AVG_MOUTH);
	RFX_Long(pFX, _T("[STD_MOUTH]"), m_STD_MOUTH);

}
/////////////////////////////////////////////////////////////////////////////
// CpicDBSet diagnostics

#ifdef _DEBUG
void CpicDBSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CpicDBSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


