//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StillCap.rc
//
#define IDOK2                           3
#define IDC_NOISE                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STILLCAP_DIALOG             102
#define IDC_CANCELALL                   102
#define IDC_STILLCAP                    102
#define IDR_MAINFRAME                   128
#define SNAPSHOT                        133
#define ADMINISTRATOR                   134
#define IDB_BITMAP1                     145
#define IDB_BITMAP2                     146
#define IDC_CAPDIR                      1000
#define IDC_CAPOBJ                      1001
#define IDC_SNAP                        1002
#define IDC_PREVIEW                     1003
#define IDC_STILL                       1004
#define IDC_STILL1                      1004
#define IDC_SNAPNAME                    1005
#define IDC_ADMIN                       1005
#define IDC_STILL2                      1005
#define IDC_CAPSTILLS                   1006
#define IDC_STILL3                      1006
#define IDC_PREVIEW2                    1006
#define IDC_CAPVID                      1007
#define IDC_STILL4                      1007
#define IDC_SNAP2                       1007
#define IDC_AUTOBUMP                    1008
#define IDC_BUTTON_RESET                1009
#define IDC_CANCEL                      1009
#define IDC_SKINTONE                    1009
#define IDC_PLAYSOUND                   1010
#define IDC_STATUS                      1011
#define IDC_BUTTON_VIEWSTILL            1012
#define IDC_SHOW                        1014
#define IDC_PREVIEW1                    1014
#define IDC_SHOW2                       1015
#define IDC_EDIT1                       1017
#define IDC_EDIT2                       1018
#define IDC_PROGRESS2                   1020
#define IDC_EDIT3                       1022
#define IDC_EDIT5                       1024
#define IDC_OK                          1025
#define IDC_GRAY                        1027
#define IDC_MOUTH                       1030
#define IDC_BOUNDARY                    1031
#define IDC_EDGE                        1032
#define IDC_BUTTON1                     1033
#define IDC_BUTTON2                     1034
#define IDC_LIST1                       1035
#define IDC_BUTTON3                     1036
#define IDC_LIST2                       1037
#define IDC_BUTTON4                     1038
#define IDC_LIST3                       1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
