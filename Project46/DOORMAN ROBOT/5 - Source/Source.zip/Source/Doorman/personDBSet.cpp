// personDBSet.h : Implementation of the CpersonDBSet class



// CpersonDBSet implementation

// code generated on 2 ���Ҥ� 2547, 1:54

#include "stdafx.h"
#include "personDBSet.h"
IMPLEMENT_DYNAMIC(CpersonDBSet, CRecordset)

CpersonDBSet::CpersonDBSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	m_ID = 0;
	m_NAME = L"";
	m_SURNAME = L"";
	m_SEX = FALSE;
	m_BIRTHDAY;
	m_ADDRESS = L"";
	m_PIC_ID = 0;
	m_PWD = L"";
	m_nFields = 8;
	m_nDefaultType = snapshot;
}
//#error Security Issue: The connection string may contain a password
// The connection string below may contain plain text passwords and/or
// other sensitive information. Please remove the #error after reviewing
// the connection string for any security related issues. You may want to
// store the password in some other form or use a different user authentication.
CString CpersonDBSet::GetDefaultConnect()
{
	return _T("DSN=doorman;DBQ=C:\\DoormanRobot\\DB\\doorman.mdb;DriverId=25;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;");
}

CString CpersonDBSet::GetDefaultSQL()
{
	//return _T("[personDB]");
	return _T("SELECT * FROM personDB ORDER BY PIC_ID");
}

void CpersonDBSet::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
// Macros such as RFX_Text() and RFX_Int() are dependent on the
// type of the member variable, not the type of the field in the database.
// ODBC will try to automatically convert the column value to the requested type
	RFX_Long(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[SURNAME]"), m_SURNAME);
	RFX_Bool(pFX, _T("[SEX]"), m_SEX);
	RFX_Date(pFX, _T("[BIRTHDAY]"), m_BIRTHDAY);
	RFX_Text(pFX, _T("[ADDRESS]"), m_ADDRESS);
	RFX_Long(pFX, _T("[PIC_ID]"), m_PIC_ID);
	RFX_Text(pFX, _T("[PWD]"), m_PWD);
}
/////////////////////////////////////////////////////////////////////////////
// CpersonDBSet diagnostics

#ifdef _DEBUG
void CpersonDBSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CpersonDBSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


