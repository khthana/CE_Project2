//------------------------------------------------------------------------------
// File: StillCapDlg.h
// Desc: DoorMan Robot - definition of callback and dialog
//       classes for StillCap application.
// Project: DoorMan Robot:2003 Version: 1
// Copyright (c) 2003 KMITL. All rights reserved.
//------------------------------------------------------------------------------
#include "personDBSet.h"
#include "picDBSet.h"
#include "afxwin.h"
#include "afxcmn.h"

#if !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
#define AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

class CSampleGrabberCB;

class CStillCapDlg : public CDialog
{
    friend class CSampleGrabberCB;

//protected:
public:
    // either the capture live graph, or the capture still graph
    CComPtr< IGraphBuilder > m_pGraph;

    // the playback graph when capturing video
    CComPtr< IGraphBuilder > m_pPlayGraph;

    // the sample grabber for grabbing stills
    CComPtr< ISampleGrabber > m_pGrabber;

    // if you're in still mode or capturing video mode
    bool m_bCapStills;

    // when in video mode, whether capturing or playing back
    int m_nCapState;

    // how many times you've captured
    int m_nCapTimes;

    void GetDefaultCapDevice( IBaseFilter ** ppCap );
    HRESULT InitStillGraph( );
    HRESULT InitCaptureGraph( TCHAR * pFilename );
    HRESULT InitPlaybackGraph( TCHAR * pFilename ); 
    void ClearGraphs( );
    void UpdateStatus(TCHAR *szStatus);
    void Error( TCHAR * pText );


// Construction
public:
	CStillCapDlg(CWnd* pParent = NULL);	// standard constructor
	
// Dialog Data
	//{{AFX_DATA(CStillCapDlg)
	enum { IDD = IDD_STILLCAP_DIALOG };
	CStatic	m_StrStatus;
	CStatic	m_StillScreen;
	CStatic	m_PreviewScreen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStillCapDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CStillCapDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSnap();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void OnBnClickedResult();
public:
	static void SnapPicture();
	static void CallCompute();
	void OnBnClickedButton1();
//Database Access
public:
	CpersonDBSet* m_pPerson;
	CpersonDBSet getPerson;
	CpicDBSet* m_pPic;
	CpicDBSet getPic;
	afx_msg void OnBnClickedButton2();
	void OnLbnDblclkList1();
	afx_msg void Computation();

//Image Processing Method
public:
	CDC mem_binary;			//get image for converting and filtering
	CDC mem_display;
	CDC mem_test;
	CDC mem_eye;

	HBITMAP LoadImageDB();
	void ConvertToYCrCb();
	void Filter(int*,CDC&,int,int,int);
	void Label();
	void findBoundary(int,int,int*,int*,int);

	bool Histrogram();
	bool CheckBelowEye(int*,int*,int,int,int);
	void DrawPosition(int[2][2]);

	void ConvertToGray(CDC&,int,int,int,int);
	double Correlation(int,int,double,double);

	CListBox m_list1;
	CProgressCtrl m_progress;
	CListBox m_list2;
	CEdit m_input;
	CButton m_confirm;
	afx_msg void OnBnClickedButton4();

	void Clear();
	void CancelAll();


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
