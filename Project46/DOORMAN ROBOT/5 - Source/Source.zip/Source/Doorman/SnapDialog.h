//------------------------------------------------------------------------------
// File: StillCap.h
// Desc: DoorMan Robot - header file for CSample Dialog.
// Project: DoorMan Robot:2003 Version: 1
// Copyright (c) 2003 KMITL. All rights reserved.
//------------------------------------------------------------------------------

class CSampleDialog:public CDialog
{
public:
	CString strFileName;
	HBITMAP H_bg;
	HBITMAP H_save;
	CDC mem_bg;
	CDC mem_gray;
	CDC mem_binary;
	CDC mem_eye;
	CDC mem_YCrCb;
	CDC mem_afterFilter;
	CDC mem_boundaryDisplay;
	CDC mem_test;

	BOOL CSampleDialog::OnInitDialog();
	CSampleDialog(UINT DialogName,CWnd *Owner):CDialog(DialogName,Owner){}
	CSampleDialog(){}

	CpersonDBSet* m_pPPerson;
	CpersonDBSet getPPerson;
	CpicDBSet* m_pPPic;
	CpicDBSet getPPic;


	HBITMAP LoadImageDB(CString);

	void OnOK();
	void OnCancel();

	void ShowPic();
	void ShowGrayPic();
	void ConvertToYCrCb();

	DECLARE_MESSAGE_MAP()
protected:
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnSkinTone();
	afx_msg void OnGray();
	afx_msg void BoundaryDisplay();
	
public:
	void OntestFilter();
	void OntestEyeLocate();
public:
	void Filter(int*,CDC&,int,int,int);
	void Label();
	void findBoundary(int,int,int*,int*,int);
	bool CheckBelowEye(int*,int*,int,int,int);
	void Histrogram();
	void Correlation(int,int);
	double EyeCorrelation(int,int,int,int);
	void DrawPosition(int[2][2]);
	void ApproxNoseMouth(int,int,int);

	void CheckDataRetrieved();

};
