//------------------------------------------------------------------------------
// File: StillCapDlg.h
// Desc: DoorMan Robot - definition of callback and dialog
//       classes for StillCap application.
// Project: DoorMan Robot:2003 Version: 1
// Copyright (c) 2003 KMITL. All rights reserved.
//------------------------------------------------------------------------------


#if !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
#define AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "adminDB.h"
#include "personDB.h"
#include "picDB.h"

#include "atltime.h"
#include "afxwin.h"
//#include "afxwin.h"
/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

class CSampleGrabberCB;

class CStillCapDlg : public CDialog
{
    friend class CSampleGrabberCB;

//protected:
public:
    // either the capture live graph, or the capture still graph
    CComPtr< IGraphBuilder > m_pGraph;

    // the playback graph when capturing video
    CComPtr< IGraphBuilder > m_pPlayGraph;

    // the sample grabber for grabbing stills
    CComPtr< ISampleGrabber > m_pGrabber;

    // if you're in still mode or capturing video mode
    bool m_bCapStills;

    // when in video mode, whether capturing or playing back
    int m_nCapState;

    // how many times you've captured
    int m_nCapTimes;

    void GetDefaultCapDevice( IBaseFilter ** ppCap );
    HRESULT InitStillGraph( );
    HRESULT InitCaptureGraph( TCHAR * pFilename );
    HRESULT InitPlaybackGraph( TCHAR * pFilename ); 
    void ClearGraphs( );
    void UpdateStatus(TCHAR *szStatus);
    void Error( TCHAR * pText );

// Construction
public:
	CStillCapDlg(CWnd* pParent = NULL);	// standard constructor
//DB
	CpersonDB* m_pPerson;
	CpersonDB getPerson;

	CpicDB* m_pPic;
	CpicDB getPic;

	CadminDB* m_pAdminDB;
	CadminDB getAdminDB;

// Dialog Data
	//{{AFX_DATA(CStillCapDlg)
	enum { IDD = IDD_STILLCAP_DIALOG };
	CStatic	m_StrStatus;
	CStatic	m_StillScreen;
	CStatic	m_PreviewScreen;
	CStatic m_Still1Screen;
	CStatic m_Preview1Screen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStillCapDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CStillCapDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSnap();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedAdmin();
public:
	static void SnapPicture();
	
	long m_ID;
	CString m_NAME;
	CString m_SURNAME;
	long m_PICID;
	CString m_ADDRESS;
	CTime m_BIRTHDAY;
	BOOL m_SEX;
	virtual void ClearRecord(void);
	virtual void GetData(void);
	virtual void GetDataPic();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();

	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedAddpicdb();
	afx_msg void OnBnClickedDelete();
	int m_Listbox;
	CListBox m_List;
	afx_msg void OnBnClickedUpdate();
private:
	BOOL m_bFlag;
	

public:
	//Image Processing Method
	CDC mem_binary;			//get image for converting and filtering
	CDC mem_display;
	CDC mem_eye;
	HBITMAP LoadImageDB();
	void ConvertToYCrCb();
	void Filter(int*,CDC&,int,int,int);
	void Label();
	void findBoundary(int,int,int*,int*,int);

	void Histrogram();
	bool CheckBelowEye(int*,int*,int,int,int);
	void DrawPosition(int[2][2]);

	void ConvertToGray(CDC&,int,int,int,int);
	double Correlation(int,int,double,double);

	CString m_PWD;
	afx_msg void OnEnChangeId();
	afx_msg void OnBnClickedAdminAcc();
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
