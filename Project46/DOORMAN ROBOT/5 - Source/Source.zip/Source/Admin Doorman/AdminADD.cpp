// AdminADD.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "AdminADD.h"
//#include "StillCapDlg.h"

// CAdminADD dialog

IMPLEMENT_DYNAMIC(CAdminADD, CDialog)
CAdminADD::CAdminADD(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminADD::IDD, pParent)
	, m_AdminName(_T(""))
	, m_AdminPWD(_T(""))
	, m_ConfirmPWD(_T(""))
{
}

CAdminADD::~CAdminADD()
{
}

void CAdminADD::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_AdminName);
	DDX_Text(pDX, IDC_EDIT2, m_AdminPWD);
	DDX_Text(pDX, IDC_EDIT3, m_ConfirmPWD);
}


BEGIN_MESSAGE_MAP(CAdminADD, CDialog)
	ON_BN_CLICKED(IDC_ADMINADD, OnBnClickedAdminadd)
END_MESSAGE_MAP()


// CAdminADD message handlers

void CAdminADD::OnBnClickedAdminadd()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString stm;
	char filter[40]="";
	char endQ[2]="'";

	CadminDB rpAdmin( NULL );
    strncpy(filter,"name= '",10);
	strncat(filter,m_AdminName,strlen(m_AdminName));
	strncat(filter,endQ,strlen(endQ));
	rpAdmin.m_strFilter = filter;
	rpAdmin.Open(CadminDB::snapshot,"Admin");

	if (m_AdminName != (CString) rpAdmin.m_name) //��������㹰ҹ������
	{
		if (m_AdminPWD == m_ConfirmPWD)
		{
			if(rpAdmin.IsEOF())
				rpAdmin.AddNew();
			else
			{
				rpAdmin.MoveLast();
				rpAdmin.AddNew();
			}
			//Ẻ����� Text
			this->GetDlgItemText(IDC_EDIT1,stm);
			rpAdmin.m_name = stm;
			this->GetDlgItemText(IDC_EDIT2,stm);
			rpAdmin.m_pwd = stm;
			rpAdmin.Update();
			if(rpAdmin.CanUpdate())
				AfxMessageBox("�ѹ�֡ŧ�ҹ���������º����",MB_OK |MB_ICONEXCLAMATION);
			rpAdmin.Requery();
			rpAdmin.Close();
			Sleep(1000); //Delay Time
			return;
		}
		else
		{
			AfxMessageBox("���ʼ�ҹ���ç�ѹ ��سҡ�͡�����ա����",MB_OK |MB_ICONEXCLAMATION);
			return;
		}

	}
	else
	{
		AfxMessageBox("�ժ�������ҹ����������",MB_OK |MB_ICONEXCLAMATION);
		return;
	}
}


