
#pragma once


// CLogin dialog
#include "adminDB.h"
#include "StillCapDlg.h"

class CLogin : public CDialog
{
	DECLARE_DYNAMIC(CLogin)

public:
	CLogin(CWnd* pParent = NULL);   // standard constructor
	virtual ~CLogin();
//DB

// Dialog Data
	enum { IDD = ADMINISTRATOR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CString m_username;
	CString m_password;
	afx_msg void OnBnClickedCancel();
};
