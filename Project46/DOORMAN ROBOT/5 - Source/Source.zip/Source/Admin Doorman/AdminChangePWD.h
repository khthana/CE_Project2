#pragma once

#include "adminDB.h"
#include "StillCapDlg.h"
#include "afxwin.h"
// CAdminChangePWD dialog

class CAdminChangePWD : public CDialog
{
	DECLARE_DYNAMIC(CAdminChangePWD)

public:
	CAdminChangePWD(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAdminChangePWD();

// Dialog Data
	enum { IDD = IDD_ADMIN_CHANGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_AdminName;
	CString m_OldPWD;
	CString m_NewPWD;
	CString m_ConfirmPWD;
	afx_msg void OnBnClickedButton1();

};
