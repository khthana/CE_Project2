// AdminDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "AdminDlg.h"
#include "AdminChangePWD.h"
#include "AdminADD.h"
#include "AdminDEL.h"


// CAdminDlg dialog

IMPLEMENT_DYNAMIC(CAdminDlg, CDialog)
CAdminDlg::CAdminDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminDlg::IDD, pParent)
{
}

CAdminDlg::~CAdminDlg()
{
}

void CAdminDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAdminDlg, CDialog)
	ON_BN_CLICKED(IDC_ADMIN_CHANGE, OnBnClickedAdminChange)
	ON_BN_CLICKED(IDC_ADMIN_ADDNEW, OnBnClickedAdminAddnew)
	ON_BN_CLICKED(IDC_ADMIN_DEL, OnBnClickedAdminDel)
END_MESSAGE_MAP()


// CAdminDlg message handlers

void CAdminDlg::OnBnClickedAdminChange()
{
	// TODO: Add your control notification handler code here
	CAdminChangePWD dlg;
	dlg.DoModal();		
}

void CAdminDlg::OnBnClickedAdminAddnew()
{
	// TODO: Add your control notification handler code here
	CAdminADD dlg;
	dlg.DoModal();		
}

void CAdminDlg::OnBnClickedAdminDel()
{
	// TODO: Add your control notification handler code here
	CAdminDEL dlg;
	dlg.DoModal();		
}

