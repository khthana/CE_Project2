#pragma once


// CStillCapView view

class CStillCapView : public CRecordView
{
	DECLARE_DYNCREATE(CStillCapView)

protected:
	CStillCapView();           // protected constructor used by dynamic creation
	virtual ~CStillCapView();

public:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	DECLARE_MESSAGE_MAP()
};


