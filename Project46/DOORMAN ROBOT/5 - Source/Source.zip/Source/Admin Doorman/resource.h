//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StillCap.rc
//
#define IDOK2                           3
#define IDC_NOISE                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STILLCAP_DIALOG             102
#define IDD_PROPPAGE_LARGE              107
#define SNAPSHOT                        133
#define ADMINISTRATOR                   134
#define IDB_BITMAP1                     146
#define IDB_BITMAP2                     147
#define IDI_ICON1                       150
#define IDB_BITMAP3                     153
#define IDD_ADMIN                       154
#define IDB_BITMAP4                     156
#define IDB_BITMAP5                     157
#define IDD_ADMIN_CHANGE                158
#define IDD_DIALOG2                     159
#define IDD_DIALOG3                     160
#define IDC_CAPDIR                      1000
#define IDC_CAPOBJ                      1001
#define IDC_SNAP                        1002
#define IDC_PREVIEW                     1003
#define IDC_STILL                       1004
#define IDC_STILL1                      1004
#define IDC_SNAPNAME                    1005
#define IDC_ADMIN                       1005
#define IDC_STILL2                      1005
#define IDC_CAPSTILLS                   1006
#define IDC_STILL3                      1006
#define IDC_CAPVID                      1007
#define IDC_STILL4                      1007
#define IDC_AUTOBUMP                    1008
#define IDC_BUTTON_RESET                1009
#define IDC_CANCEL                      1009
#define IDC_SKINTONE                    1009
#define IDC_PLAYSOUND                   1010
#define IDC_STATUS                      1011
#define IDC_BUTTON_VIEWSTILL            1012
#define IDC_SHOW                        1014
#define IDC_PREVIEW1                    1014
#define IDC_SHOW2                       1015
#define IDC_EDIT1                       1017
#define IDC_EDIT2                       1018
#define IDC_PROGRESS2                   1020
#define IDC_EDIT3                       1022
#define IDC_EDIT5                       1024
#define IDC_OK                          1025
#define IDC_GRAY                        1027
#define IDC_MOUTH                       1030
#define IDC_BOUNDARY                    1031
#define IDC_EDGE                        1032
#define IDC_BUTTON1                     1033
#define IDC_EDIT4                       1034
#define IDC_EDIT6                       1035
#define IDC_ADDRESS                     1035
#define IDC_SAVE                        1037
#define IDC_PICID                       1038
#define IDC_ID                          1039
#define IDC_NAME                        1040
#define IDC_SURNAME                     1041
#define IDC_Male                        1042
#define IDC_Female                      1043
#define IDC_DATETIMEPICKER1             1044
#define IDC_BUTTON2                     1045
#define IDC_BUTTON3                     1046
#define IDC_SEX                         1047
#define IDC_CLEAR                       1048
#define IDC_ADDPICDB                    1049
#define IDC_DELETE                      1050
#define IDC_LIST2                       1052
#define IDC_UPDATE                      1053
#define IDC_ADMIN_CHANGE                1055
#define IDC_ADMIN_ADDNEW                1056
#define IDC_ADMIN_DEL                   1057
#define IDC_ADMIN_ACC                   1059
#define IDC_ADMINADD                    1061
#define ID_ADMIN_DEL                    1062
#define ID_ADMIN_CANCEL                 1063
#define IDC_CHECK1                      1064

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        161
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
