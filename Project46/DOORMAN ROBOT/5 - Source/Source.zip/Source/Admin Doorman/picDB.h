// picDB.h : Declaration of the CpicDB

#pragma once

// code generated on 26 �ѹ�Ҥ� 2546, 23:00

class CpicDB : public CRecordset
{
public:
	CpicDB(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CpicDB)

// Field/Param Data

// The string types below (if present) reflect the actual data type of the
// database field - CStringA for ANSI datatypes and CStringW for Unicode
// datatypes. This is to prevent the ODBC driver from performing potentially
// unnecessary conversions.  If you wish, you may change these members to
// CString types and the ODBC driver will perform all necessary conversions.
// (Note: You must use an ODBC driver version that is version 3.5 or greater
// to support both Unicode and these conversions).

	long	m_PIC_ID;
	long	m_X_EYE;
	long	m_Y_EYE;
	long	m_AVG_EYE;
	long	m_X_NOSE;

	long	m_Y_NOSE;
	long	m_AVG_NOSE;
	long	m_X_MOUTH;
	long	m_Y_MOUTH;
	long	m_AVG_MOUTH;
	
	long	m_STD_EYE;
	long	m_STD_NOSE;
	long	m_STD_MOUTH;	
	

// Overrides
	// Wizard generated virtual function overrides
	public:
	virtual CString GetDefaultConnect();	// Default connection string

	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};


