// AdminDEL.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "AdminDEL.h"
#include "StillCapDlg.h"

// CAdminDEL dialog
BOOL DelFlag;
IMPLEMENT_DYNAMIC(CAdminDEL, CDialog)
CAdminDEL::CAdminDEL(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminDEL::IDD, pParent)
	, m_AdminName(_T(""))
	, m_AdminPWD(_T(""))
{
}

CAdminDEL::~CAdminDEL()
{
}

void CAdminDEL::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_AdminName);
	DDX_Text(pDX, IDC_EDIT2, m_AdminPWD);
}


BEGIN_MESSAGE_MAP(CAdminDEL, CDialog)
	ON_BN_CLICKED(IDC_CHECK1, OnBnClickedCheck1)
	ON_BN_CLICKED(ID_ADMIN_DEL, OnBnClickedAdminDel)
END_MESSAGE_MAP()


// CAdminDEL message handlers

void CAdminDEL::OnBnClickedCheck1()
{
	// TODO: Add your control notification handler code here
	if (IsDlgButtonChecked(IDC_CHECK1))
	{
		DelFlag = TRUE;
	}
	else
	{
		DelFlag = FALSE;
	}
}

void CAdminDEL::OnBnClickedAdminDel()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString stm;
	char filter[40]="";
	char endQ[2]="'";

	CadminDB rpAdmin( NULL );
    strncpy(filter,"name= '",10);
	strncat(filter,m_AdminName,strlen(m_AdminName));
	strncat(filter,endQ,strlen(endQ));
	rpAdmin.m_strFilter = filter;
	rpAdmin.Open(CadminDB::snapshot,"Admin");
	if (m_AdminName != "root")
	{
	if (DelFlag)
	{
	if ((m_AdminName == (CString) rpAdmin.m_name)&& (m_AdminPWD == (CString) rpAdmin.m_pwd))
	{
		rpAdmin.Delete();
		if(rpAdmin.CanUpdate())
			AfxMessageBox("ź���������º����",MB_OK |MB_ICONEXCLAMATION);
		rpAdmin.MoveNext();
		if (rpAdmin.IsEOF())
			rpAdmin.MoveLast();
		if (rpAdmin.IsBOF())
			rpAdmin.SetFieldNull(NULL);

		Sleep(1000); //Delay Time
		return;
	}
	else
	{
		AfxMessageBox("Username ���� Password ������١��ͧ",MB_OK |MB_ICONEXCLAMATION);
		return;
	}
	}
	else
	{
		AfxMessageBox("��س��׹�ѹ���ź",MB_OK |MB_ICONEXCLAMATION);
		return;
	}
	}
	else
	{
		AfxMessageBox("�������öź��",MB_OK |MB_ICONEXCLAMATION);
		return;
	}
}
