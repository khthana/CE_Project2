#pragma once

#include "adminDB.h"
#include "StillCapDlg.h"
// CAdminDEL dialog

class CAdminDEL : public CDialog
{
	DECLARE_DYNAMIC(CAdminDEL)

public:
	CAdminDEL(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAdminDEL();

// Dialog Data
	enum { IDD = IDD_DIALOG3 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCheck1();
	CString m_AdminName;
	CString m_AdminPWD;
	afx_msg void OnBnClickedAdminDel();
};
