//------------------------------------------------------------------------------
// File: StillCapDlg.cpp
// Desc: Face Recognition - Application for detect and recognize faces.
// Project: DoorMan Robot:2003 Version: 1
// Copyright (c) 2003 KMITL. All rights reserved.
//------------------------------------------------------------------------------

#include "stdafx.h"
#include "StillCap.h"
#include "StillCapDlg.h"
#include "..\..\common\dshowutil.cpp"
#include "string.h"
#include <stdlib.h> 
//#include "Login.h"
//include more library
#include "SnapDialog.h"
#include "AdminDlg.h"
#include "Math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// An application can advertise the existence of its filter graph
// by registering the graph with a global Running Object Table (ROT).
// The GraphEdit application can detect and remotely view the running
// filter graph, allowing you to 'spy' on the graph with GraphEdit.
//
// To enable registration in this sample, define REGISTER_FILTERGRAPH.
//
#ifdef DEBUG
#define REGISTER_FILTERGRAPH
#endif

// Constants
#define WM_CAPTURE_BITMAP   WM_APP + 1

// Global data
BOOL g_bOneShot = FALSE;
DWORD g_dwGraphRegister=0;  // For running object table
HWND g_hwnd;


//More Global data
CWnd *hwnd;
CWnd* pSnap;
CWnd* pAdmin;
CWnd* pSave;
CWnd* pEdit;
CWnd* pDel;
CWnd* pPrv;
CWnd* pNext;
//for play sound & display text
//use to suspend & resume in Thread's Global Function
CWinThread* m_soundPlay;
CWinThread* m_displayDialog;

CDC *pdc;
CString fileName;
long ldisplayWidth;
long ldisplayHeight;

//for label function 
//Use in Filter function
long width;
long height;
int afterFilter[320][240];

//Label
int line,line1,line2,line3,line4;

BOOL m_mainWindow = true;
int controlPreviewName = IDC_PREVIEW;
int controlStillName = IDC_STILL;

int x_eye,y_eye,x_nose,y_nose,x_mouth,y_mouth;	
double avg_mouth,avg_eye,avg_nose,std_mouth,std_nose,std_eye;


//New Global Variable

//keep the bitmap that is used to compare
HBITMAP H_image;
char filename[40] = "";
int numfilename = 0;

//keep gray level image
int grayImage[320][240];

//binary image
int temp_binary[320][240];

//distance between eye
int xdistance;
int ydistance;
int adistance;

//retrieve file from database
char str[5];
char filter[20];
int tempPicid;


//Correlation Coefficient
int plate[21][61];
int image[42][122];
int tempgray[240][320];
int x,y,avgf,stdf;
double score[100];


// Structures
typedef struct _callbackinfo 
{
    double dblSampleTime;
    long lBufferSize;
    BYTE *pBuffer;
    BITMAPINFOHEADER bih;

} CALLBACKINFO;

CALLBACKINFO cb={0};

//���ͺ�������  ������¡���§
//Global Function for thread
//pParam is a Handle window


//WaitKey Thread Function 
UINT WaitKey(LPVOID pParam)
{
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�� Enter �ҡ��ͧ��þ��ؤ�������ͧ ���� 5 �Թҷ� .");
	::Sleep(1000);
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�� Enter �ҡ��ͧ��þ��ؤ�������ͧ ���� 4 �Թҷ� ..");
	::Sleep(1000);
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�� Enter �ҡ��ͧ��þ��ؤ�������ͧ ���� 3 �Թҷ� ...");
	::Sleep(1000);
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�� Enter �ҡ��ͧ��þ��ؤ�������ͧ ���� 2 �Թҷ� ....");
	::Sleep(1000);
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�� Enter �ҡ��ͧ��þ��ؤ�������ͧ ���� 1 �Թҷ� .....");
	::Sleep(1000);
	return 0;
}

//Play sound Thread Function 
UINT SoundPlay(LPVOID pParam)
{
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog1.wav", NULL, SND_FILENAME);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog2.wav", NULL, SND_FILENAME);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog2_1.wav", NULL, SND_FILENAME);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog2_2.wav", NULL, SND_FILENAME);
	//Wait Enter Key!!!!
	AfxBeginThread(WaitKey,(HWND)pParam,THREAD_PRIORITY_NORMAL);
	::Sleep(5000);
	m_displayDialog->ResumeThread();

	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog3.wav", NULL, SND_FILENAME);
	::Sleep(2000);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog4.wav", NULL, SND_FILENAME);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog5.wav", NULL, SND_FILENAME);
	m_displayDialog->ResumeThread();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog6.wav", NULL, SND_FILENAME);	
	m_displayDialog->ResumeThread();
	//Snap Picture
	CStillCapDlg::SnapPicture();
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/dialog7.wav", NULL, SND_FILENAME);	
	m_displayDialog->ResumeThread();
	return 0;
}

//Display text Thread Function 
UINT DisplayDialog(LPVOID pParam)
{
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"���ʴդ��");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�͵�͹�Ѻ�������к� Doorman Robot");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�ҡ��ͧ��þ��ؤ��������ͧ ��سҡ� Enter");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�����׹��� � �����������鹵͹����");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"��س��׹���ç���˹觷���˹������¤��");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�ͺ�س���");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"��س��ͧ���ش��ᴧ �����׹��� � ���");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"��� �ͧ ˹��");
	m_displayDialog->SuspendThread();
	SetDlgItemText((HWND)pParam,IDC_EDIT1,"�к���ӡ�úѹ�֡�Ҿ���º�������Ǥ��");
	m_displayDialog->SuspendThread();
	return 0;
}


// Note: this object is a SEMI-COM object, and can only be created statically.
// We use this little semi-com object to handle the sample-grab-callback,
// since the callback must provide a COM interface. We could have had an interface
// where you provided a function-call callback, but that's really messy, so we
// did it this way. You can put anything you want into this C++ object, even
// a pointer to a CDialog. Be aware of multi-thread issues though.
//
class CSampleGrabberCB : public ISampleGrabberCB 
{
public:
    // these will get set by the main thread below. We need to
    // know this in order to write out the bmp
    long lWidth;
    long lHeight;
    CStillCapDlg * pOwner;
    TCHAR m_szCapDir[MAX_PATH]; // the directory we want to capture to
    TCHAR m_szSnappedName[MAX_PATH];
    BOOL bFileWritten;

    CSampleGrabberCB( )
    {
        pOwner = NULL;
        m_szCapDir[0] = 0;
        bFileWritten = FALSE;
    }   

    // fake out any COM ref counting
    //
    STDMETHODIMP_(ULONG) AddRef() { return 2; }
    STDMETHODIMP_(ULONG) Release() { return 1; }

    // fake out any COM QI'ing
    //
    STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
    {
        if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
        {
            *ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
            return NOERROR;
        }    
        return E_NOINTERFACE;
    }

    // we don't implement this interface for this example
    //
    STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
    {
        return 0;
    }

    // The sample grabber is calling us back on its deliver thread.
    // This is NOT the main app thread!
    //
    //           !!!!! WARNING WARNING WARNING !!!!!
    //
    // On Windows 9x systems, you are not allowed to call most of the 
    // Windows API functions in this callback.  Why not?  Because the
    // video renderer might hold the global Win16 lock so that the video
    // surface can be locked while you copy its data.  This is not an
    // issue on Windows 2000, but is a limitation on Win95,98,98SE, and ME.
    // Calling a 16-bit legacy function could lock the system, because 
    // it would wait forever for the Win16 lock, which would be forever
    // held by the video renderer.
    //
    // As a workaround, copy the bitmap data during the callback,
    // post a message to our app, and write the data later.
    //
    STDMETHODIMP BufferCB( double dblSampleTime, BYTE * pBuffer, long lBufferSize )
    {
        // this flag will get set to true in order to take a picture
        //
        if( !g_bOneShot )
            return 0;

        // Since we can't access Windows API functions in this callback, just
        // copy the bitmap data to a global structure for later reference.
        cb.dblSampleTime = dblSampleTime;
        cb.lBufferSize   = lBufferSize;

        // If we haven't yet allocated the data buffer, do it now.
        // Just allocate what we need to store the new bitmap.
        if (!cb.pBuffer)
            cb.pBuffer = new BYTE[lBufferSize];

        // Copy the bitmap data into our global buffer
        if (cb.pBuffer)
            memcpy(cb.pBuffer, pBuffer, lBufferSize);

        // Post a message to our application, telling it to come back
        // and write the saved data to a bitmap file on the user's disk.
        PostMessage(g_hwnd, WM_CAPTURE_BITMAP, 0, 0L);
        return 0;
    }

    // This function will be called whenever a captured still needs to be
    // displayed in the preview window.  It is called initially within
    // CopyBitmap() to display the captured still, but it is also called
    // whenever the main dialog needs to repaint and when we transition
    // from video capture mode back into still capture mode.
    //
    BOOL DisplayCapturedBits(BYTE *pBuffer, BITMAPINFOHEADER *pbih)
    {
        // If we haven't yet snapped a still, return
        if (!bFileWritten || !pOwner || !pBuffer)
            return FALSE;

        // put bits into the preview window with StretchDIBits
        //
        HWND hwndStill = NULL;
        pOwner->GetDlgItem( controlStillName, &hwndStill );

        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
        long lStillWidth = rc.right - rc.left;
        long lStillHeight = rc.bottom - rc.top;
        
        HDC hdcStill = GetDC( hwndStill );
        PAINTSTRUCT ps;
        BeginPaint(hwndStill, &ps);

        SetStretchBltMode(hdcStill, COLORONCOLOR);
        StretchDIBits( 
            hdcStill, 0, 0, 
            lStillWidth, lStillHeight, 
            0, 0, lWidth, lHeight, 
            pBuffer, 
            (BITMAPINFO*) pbih, 
            DIB_RGB_COLORS, 
            SRCCOPY );

        EndPaint(hwndStill, &ps);
        ReleaseDC( hwndStill, hdcStill );    

        return TRUE;
    }

    // This is the implementation function that writes the captured video
    // data onto a bitmap on the user's disk.
    //
    BOOL CopyBitmap( double dblSampleTime, BYTE * pBuffer, long lBufferSize )
    {
        if( !g_bOneShot )
            return 0;

        // we only take one at a time
        //
        g_bOneShot = FALSE;

        // figure out where to capture to
        //
		//keep the value that is retrieve form database,personDB table
		wsprintf( m_szSnappedName, TEXT("%s%ld.bmp"), 
        m_szCapDir,numfilename );

		//Update new fileName of image is recently snapped.
		fileName = m_szSnappedName;
		strcpy(filename,m_szSnappedName);

		//Update new fileName of image is recently snapped.
		fileName = m_szSnappedName;
		//increment filename
		pOwner->m_nCapTimes++;

        // write out a BMP file
        //
        HANDLE hf = CreateFile(
            m_szSnappedName, GENERIC_WRITE, 0, NULL,
            CREATE_ALWAYS, NULL, NULL );

        if( hf == INVALID_HANDLE_VALUE )
            return 0;

        // write out the file header
        //
        BITMAPFILEHEADER bfh;
        memset( &bfh, 0, sizeof( bfh ) );
        bfh.bfType = 'MB';
        bfh.bfSize = sizeof( bfh ) + lBufferSize + sizeof( BITMAPINFOHEADER );
        bfh.bfOffBits = sizeof( BITMAPINFOHEADER ) + sizeof( BITMAPFILEHEADER );

        DWORD dwWritten = 0;
        WriteFile( hf, &bfh, sizeof( bfh ), &dwWritten, NULL );

        // and the bitmap format
        //
        BITMAPINFOHEADER bih;
        memset( &bih, 0, sizeof( bih ) );
        bih.biSize = sizeof( bih );
        bih.biWidth = lWidth;
        bih.biHeight = lHeight;
        bih.biPlanes = 1;
        bih.biBitCount = 24;

        dwWritten = 0;
        WriteFile( hf, &bih, sizeof( bih ), &dwWritten, NULL );

        // and the bits themselves
        //
        dwWritten = 0;
        WriteFile( hf, pBuffer, lBufferSize, &dwWritten, NULL );
        CloseHandle( hf );
        bFileWritten = TRUE;

        // Display the bitmap bits on the dialog's preview window
        DisplayCapturedBits(pBuffer, &bih);

        // Save bitmap header for later use when repainting the window
        memcpy(&(cb.bih), &bih, sizeof(bih));        
	
        return 0;
    }

};

// this semi-COM object will receive sample callbacks for us
//
CSampleGrabberCB mCB;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

CStillCapDlg::CStillCapDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStillCapDlg::IDD, pParent)
	, m_ID(NULL)
	, m_NAME(_T(""))
	, m_SURNAME(_T(""))
	, m_ADDRESS(_T(""))
	, m_BIRTHDAY(0)
	, m_SEX(FALSE)
	, m_Listbox(0)
	, m_PWD(_T(""))
{
	//{{AFX_DATA_INIT(CStillCapDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
 	//m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
}

void CStillCapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStillCapDlg)
	if(m_mainWindow){
		DDX_Control(pDX, controlStillName, m_StillScreen);
		DDX_Control(pDX, controlPreviewName, m_PreviewScreen);
		//DDX_Control(pDX, IDC_PREVIEW, m_PreviewScreen);
	}else{
		// Implement Administrator Dialog Control	
		DDX_Control(pDX, controlStillName, m_Still1Screen);
		DDX_Control(pDX, controlPreviewName, m_Preview1Screen);
	}
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_ID,m_ID);
	DDX_Text(pDX, IDC_NAME, m_NAME);
	DDX_Text(pDX, IDC_SURNAME, m_SURNAME);
	DDX_Text(pDX, IDC_PICID, m_PICID);
	DDX_Text(pDX, IDC_ADDRESS, m_ADDRESS);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER1, m_BIRTHDAY);
	DDX_Radio(pDX, IDC_Male, m_SEX);
	DDX_Control(pDX, IDC_LIST2, m_List);
	DDX_Text(pDX, IDC_EDIT1, m_PWD);
}

BEGIN_MESSAGE_MAP(CStillCapDlg, CDialog)
	//{{AFX_MSG_MAP(CStillCapDlg)
	ON_WM_PAINT()
	ON_WM_SYSCOMMAND()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SNAP, OnSnap)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_ADMIN, OnBnClickedAdmin)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_SAVE, OnBnClickedSave)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
	ON_BN_CLICKED(IDC_CLEAR, OnBnClickedClear)
	ON_BN_CLICKED(IDC_ADDPICDB, OnBnClickedAddpicdb)
	ON_BN_CLICKED(IDC_DELETE, OnBnClickedDelete)
	ON_BN_CLICKED(IDC_UPDATE, OnBnClickedUpdate)

	ON_EN_CHANGE(IDC_ID, OnEnChangeId)
	ON_BN_CLICKED(IDC_ADMIN_ACC, OnBnClickedAdminAcc)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg message handlers

void CStillCapDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CStillCapDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
        // Update the bitmap preview window, if we have
        // already captured bitmap data
        mCB.DisplayCapturedBits(cb.pBuffer, &(cb.bih));
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStillCapDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CStillCapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
    // StillCap-specific initialization
    CoInitialize( NULL );

    // default to capturing stills
    //
  //  CheckDlgButton( IDC_CAPSTILLS, 1 );
    m_bCapStills = true;
    m_nCapTimes = 0;
    g_hwnd = GetSafeHwnd();

    // start up the still image capture graph
    //
    HRESULT hr = InitStillGraph( );
    if (FAILED(hr))
        Error( TEXT("Failed to initialize StillGraph!"));

    // Modify the window style of the capture and still windows
    // to prevent excessive repainting
    m_PreviewScreen.ModifyStyle(0, WS_CLIPCHILDREN);
    m_StillScreen.ModifyStyle(0, WS_CLIPCHILDREN);

	pSnap = GetDlgItem(IDC_SNAP);
	pAdmin = GetDlgItem(IDC_ADMIN);
	pSave = GetDlgItem(IDC_SAVE);
	pEdit = GetDlgItem(IDC_UPDATE);
	pDel = GetDlgItem(IDC_DELETE);
	pPrv = GetDlgItem(IDC_BUTTON3);
	pNext = GetDlgItem(IDC_BUTTON2);
//DB
	m_pPerson = &getPerson;
	m_pPerson->Open(AFX_DB_USE_DEFAULT_TYPE,getPerson.GetDefaultSQL());

	m_pPic = &getPic;
	m_pPic->Open(AFX_DB_USE_DEFAULT_TYPE,getPic.GetDefaultSQL());

	m_pAdminDB = &getAdminDB;
	m_pAdminDB->Open(AFX_DB_USE_DEFAULT_TYPE,getAdminDB.GetDefaultSQL());

	m_bFlag=TRUE;
	//ClearRecord();
	GetData();
	GetDataPic();
    UpdateData(FALSE);

	pdc = GetDC();
	mem_binary.CreateCompatibleDC(pdc);
	mem_eye.CreateCompatibleDC(pdc);
	mem_display.CreateCompatibleDC(pdc);
	ReleaseDC(pdc);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStillCapDlg::ClearGraphs( )
{
    // Destroy capture graph
    if( m_pGraph )
    {
        // have to wait for the graphs to stop first
        //
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
        if( pControl ) 
            pControl->Stop( );

        // make the window go away before we release graph
        // or we'll leak memory/resources
        // 
        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }

#ifdef REGISTER_FILTERGRAPH
        // Remove filter graph from the running object table   
        if (g_dwGraphRegister)
            RemoveGraphFromRot(g_dwGraphRegister);
#endif

        m_pGraph.Release( );
        m_pGrabber.Release( );
    }

    // Destroy playback graph, if it exists
    if( m_pPlayGraph )
    {
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pPlayGraph;
        if( pControl ) 
            pControl->Stop( );

        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }

        m_pPlayGraph.Release( );
    }
}

HRESULT CStillCapDlg::InitStillGraph( )
{
    HRESULT hr;

    // create a filter graph
    //
    hr = m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error( TEXT("Could not create filter graph") );
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return E_FAIL;
    }

    // create a sample grabber
    //
    hr = m_pGrabber.CoCreateInstance( CLSID_SampleGrabber );
    if( !m_pGrabber )
    {
        Error( TEXT("Could not create SampleGrabber (is qedit.dll registered?)"));
        return hr;
    }
    CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabBase( m_pGrabber );

    // force it to connect to video, 24 bit
    //
    CMediaType VideoType;
    VideoType.SetType( &MEDIATYPE_Video );
    VideoType.SetSubtype( &MEDIASUBTYPE_RGB24 );
    hr = m_pGrabber->SetMediaType( &VideoType ); // shouldn't fail
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set media type"));
        return hr;
    }

    // add the grabber to the graph
    //
    hr = m_pGraph->AddFilter( pGrabBase, L"Grabber" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put sample grabber in graph"));
        return hr;
    }

    // find the two pins and connect them
    //
    IPin * pCapOut = GetOutPin( pCap, 0 );
    IPin * pGrabIn = GetInPin( pGrabBase, 0 );
    hr = m_pGraph->Connect( pCapOut, pGrabIn );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin #0 to grabber.\r\n")
               TEXT("Is the capture device being used by another application?"));
        return hr;
    }

    // render the sample grabber output pin, so we get a preview window
    //
    IPin * pGrabOut = GetOutPin( pGrabBase, 0 );
    hr = m_pGraph->Render( pGrabOut );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render sample grabber output pin"));
        return hr;
    }

    // ask for the connection media type so we know how big
    // it is, so we can write out bitmaps
    //
    AM_MEDIA_TYPE mt;
    hr = m_pGrabber->GetConnectedMediaType( &mt );
    if ( FAILED( hr) )
    {
        Error( TEXT("Could not read the connected media type"));
        return hr;
    }
    
    VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mt.pbFormat;
    mCB.pOwner = this;
    mCB.lWidth  = vih->bmiHeader.biWidth;
    mCB.lHeight = vih->bmiHeader.biHeight;
    FreeMediaType( mt );

    // don't buffer the samples as they pass through
    //
    m_pGrabber->SetBufferSamples( FALSE );

    // only grab one at a time, stop stream after
    // grabbing one sample
    //
    m_pGrabber->SetOneShot( FALSE );

    // set the callback, so we can grab the one sample
    //
    m_pGrabber->SetCallback( &mCB, 1 );

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( controlPreviewName, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );

    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // Add our graph to the running object table, which will allow
    // the GraphEdit application to "spy" on our graph
#ifdef REGISTER_FILTERGRAPH
    hr = AddGraphToRot(m_pGraph, &g_dwGraphRegister);
    if (FAILED(hr))
    {
        Error(TEXT("Failed to register filter graph with ROT!"));
        g_dwGraphRegister = 0;
    }
#endif

    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

    UpdateStatus(_T("Previewing Live Video"));
    return 0;
}

HRESULT CStillCapDlg::InitCaptureGraph( TCHAR * pFilename )
{
    HRESULT hr;

    // make a filter graph
    //    m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error(TEXT("Could not create filter graph"));
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return hr;
    }

    // make a capture builder graph (for connecting help)
    //
    CComPtr< ICaptureGraphBuilder2 > pBuilder;
    hr = pBuilder.CoCreateInstance( CLSID_CaptureGraphBuilder2 );
    if( !pBuilder )
    {
        Error( TEXT("Could not create capture graph builder2"));
        return hr;
    }

    hr = pBuilder->SetFiltergraph( m_pGraph );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set filtergraph on graphbuilder2"));
        return hr;
    }

    CComPtr< IBaseFilter > pMux;
    CComPtr< IFileSinkFilter > pSink;
    USES_CONVERSION;

    hr = pBuilder->SetOutputFileName( &MEDIASUBTYPE_Avi,
        T2W( pFilename ),
        &pMux,
        &pSink );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not create/hookup mux and writer"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_CAPTURE,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        pMux );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_PREVIEW,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        NULL );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render capture pin"));
        return hr;
    }
    if( hr == VFW_S_NOPREVIEWPIN )
    {
        // preview was faked up using the capture pin, so we can't
        // turn capture on and off at will.
        hr = 0;
    }

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return hr;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( controlPreviewName, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

    UpdateStatus(_T("Capturing Video To Disk"));
    return 0;
}

HRESULT CStillCapDlg::InitPlaybackGraph( TCHAR * pFilename )
{
    m_pPlayGraph.CoCreateInstance( CLSID_FilterGraph );
    USES_CONVERSION;

    HRESULT hr = m_pPlayGraph->RenderFile( T2W( pFilename ), NULL );
    if (FAILED(hr))
        return hr;

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( controlStillName, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );

    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl;
    pControl = m_pPlayGraph;

    // Play back the recorded video
    pControl->Run( );
    UpdateStatus(_T("Playing Back Recorded Video"));
    return 0;
}

void CStillCapDlg::GetDefaultCapDevice( IBaseFilter ** ppCap )
{
    HRESULT hr;

    *ppCap = NULL;

    // create an enumerator
    //
    CComPtr< ICreateDevEnum > pCreateDevEnum;
    pCreateDevEnum.CoCreateInstance( CLSID_SystemDeviceEnum );
    if( !pCreateDevEnum )
        return;

    // enumerate video capture devices
    //
    CComPtr< IEnumMoniker > pEm;
    pCreateDevEnum->CreateClassEnumerator( CLSID_VideoInputDeviceCategory, &pEm, 0 );
    if( !pEm )
        return;

    pEm->Reset( );
 
    // go through and find first video capture device
    //
    while( 1 )
    {
        ULONG ulFetched = 0;
        CComPtr< IMoniker > pM;
        hr = pEm->Next( 1, &pM, &ulFetched );
        if( hr != S_OK )
            break;

        // get the property bag interface from the moniker
        //
        CComPtr< IPropertyBag > pBag;
        hr = pM->BindToStorage( 0, 0, IID_IPropertyBag, (void**) &pBag );
        if( hr != S_OK )
            continue;

        // ask for the english-readable name
        //
        CComVariant var;
        var.vt = VT_BSTR;
        hr = pBag->Read( L"FriendlyName", &var, NULL );
        if( hr != S_OK )
            continue;

        // set it in our UI
        //
        USES_CONVERSION;
      //  SetDlgItemText( IDC_CAPOBJ, W2T( var.bstrVal ) );

        // ask for the actual filter
        //
        hr = pM->BindToObject( 0, 0, IID_IBaseFilter, (void**) ppCap );
        if( *ppCap )
            break;
    }

    return;
}

//First Step,people is detected.
void CStillCapDlg::OnSnap() 
{
	//Enables or disables mouse and keyboard input.
	//::EnableWindow(GetSafeHwnd(),FALSE);
	//Enables or disables button
	pSnap->EnableWindow(FALSE);
	pAdmin->EnableWindow(FALSE);
	//create Thread for diplay text and sound
	m_displayDialog = AfxBeginThread(DisplayDialog,GetSafeHwnd(),THREAD_PRIORITY_NORMAL);
	m_soundPlay = AfxBeginThread(SoundPlay,GetSafeHwnd(),THREAD_PRIORITY_NORMAL);
}


//Snap picture into file
void CStillCapDlg::SnapPicture()
{
	//Set Directory path to keep picture here!!!!
	CString CapDir="c:/DoormanRobot/DB/Picture/";
	//Keep picture in file format
    _tcscpy( mCB.m_szCapDir,CapDir );
    g_bOneShot = TRUE;
	//PlaySound snap picture
	PlaySound((LPCTSTR)"C:/DoormanRobot/Sound_Project/Dialog/snap.wav", NULL, SND_FILENAME);	
	//return accessible for all windowcontrol
	pAdmin->EnableWindow(TRUE);
	pSnap->EnableWindow(TRUE);

	//::EnableWindow(GetSafeHwnd(),TRUE);
}


BOOL CStillCapDlg::DestroyWindow() 
{
    ClearGraphs( );

    return CDialog::DestroyWindow();
}

void CStillCapDlg::Error( TCHAR * pText )
{
    GetDlgItem( IDC_SNAP )->EnableWindow( FALSE );
    ::MessageBox( NULL, pText, TEXT("Error!"), MB_OK | MB_TASKMODAL | MB_SETFOREGROUND );
}

void CStillCapDlg::UpdateStatus(TCHAR *szStatus)
{
  //  m_StrStatus.SetWindowText(szStatus);
}

LRESULT CStillCapDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
    // Field the message posted by our SampleGrabber callback function.
    if (message == WM_CAPTURE_BITMAP)
        mCB.CopyBitmap(cb.dblSampleTime, cb.pBuffer, cb.lBufferSize);        
	
	return CDialog::WindowProc(message, wParam, lParam);
}

void CStillCapDlg::OnClose() 
{
    // Free the memory allocated for our bitmap data buffer
    if (cb.pBuffer != 0)
    {
        delete cb.pBuffer;
        cb.pBuffer = 0;
    }
    	
	CDialog::OnClose();
}


//Implement CSampleDialog Class
//Handle Dialog is used to Display image after snap
//The SNAPSHOTDialog's message map
BEGIN_MESSAGE_MAP(CSampleDialog, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_COMMAND(IDOK,OnOK)
	ON_COMMAND(IDCANCEL,OnCancel)
	ON_COMMAND(IDC_SKINTONE,OnSkinTone)
	ON_COMMAND(IDC_GRAY,OnGray)
	ON_COMMAND(IDC_BOUNDARY,BoundaryDisplay)
	ON_COMMAND(IDC_MOUTH,FeatureExtract)
	ON_COMMAND(IDC_EDGE,EdgeDetection)
	ON_COMMAND(IDC_NOISE,Filter)
END_MESSAGE_MAP()

BOOL CSampleDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// TODO: Add extra initialization here	
	//Initial Data for Display Picture after the picture is snapped.
	//The CreateCompatibleDC function creates a memory device context (DC) compatible with the specified device. 
	pdc = GetDC();
	mem_bg.CreateCompatibleDC(pdc);
	mem_gray.CreateCompatibleDC(pdc);
	mem_binary.CreateCompatibleDC(pdc);
	mem_mouthbinary.CreateCompatibleDC(pdc);
	mem_edge.CreateCompatibleDC(pdc);
	mem_YCrCb.CreateCompatibleDC(pdc);
	mem_afterFilter.CreateCompatibleDC(pdc);
	mem_boundaryDisplay.CreateCompatibleDC(pdc);
	ReleaseDC(pdc);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSampleDialog::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CSampleDialog::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		// Draw the icon
	}
	else
	{
		CDialog::OnPaint();
	}
}
//Button Control from Testing Mode
//show Picture
void CSampleDialog::OnOK()
{
	ShowPic();
}
//End Dialog
void CSampleDialog::OnCancel()
{
	EndDialog(0);
}
//ConvertToYCrCb then Create Binary Image
void CSampleDialog::OnSkinTone()
{
	ConvertToYCrCb();
}
//Test Gray Level Picture
void CSampleDialog::OnGray()
{
	ShowGrayPic();
}

// ShowPic function is used to display image
void CSampleDialog::ShowPic()
{
	//Get current path of image.
	strFileName = fileName;

	HWND hwndStill = NULL;
	GetDlgItem(IDC_STILL1,&hwndStill);
	RECT rc;
	::GetWindowRect(hwndStill, &rc);
	ldisplayWidth = rc.right - rc.left;
	ldisplayHeight = rc.bottom - rc.top;
	H_bg = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	H_save = H_bg;
	hwnd = GetDlgItem(IDC_STILL1);
	mem_bg.SelectObject(H_bg);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_bg,0,0,SRCCOPY);
}

void CSampleDialog::ShowGrayPic()
{
	strFileName = fileName;
	int i,j;
	COLORREF color;
	BYTE red,green,blue;
	double temp;

	HWND hwndStill2 = NULL;
	GetDlgItem(IDC_STILL2,&hwndStill2);
	RECT rc;
	::GetWindowRect(hwndStill2, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	HBITMAP H_bg = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);

	mem_gray.SelectObject(H_bg);

	CWnd *hwnd2 = GetDlgItem(IDC_STILL2);
	CClientDC dc1(hwnd2);

	for(i=0;i<=ldisplayWidth;i++){
		for(j=0;j<=ldisplayHeight;j++){
			
			color = mem_gray.GetPixel(i,j);	
			//Get RGB Value at each position 
			red   = GetRValue(color);
			green = GetGValue(color);
			blue  = GetBValue(color);
			//conversion to GrayScale
			temp = (0.299*red) + (0.587*green) + (0.114*blue);

			mem_gray.SetPixel(i,j,RGB(temp,temp,temp));
		}	
	}
	//mem_gray keep the value of binary image
	dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_gray,0,0,SRCCOPY);
}

void CSampleDialog::ConvertToYCrCb()
{
	strFileName = fileName;
	//strFileName = "c:/Project_Snap/StillCap0001.bmp";
	int i,j;
	COLORREF color;
	BYTE red,green,blue;
	double Y,Cr,Cb;

	HWND hwndStill2 = NULL;
	GetDlgItem(IDC_STILL3,&hwndStill2);
	RECT rc;
	::GetWindowRect(hwndStill2, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;

	HBITMAP H_bg = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	mem_binary.SelectObject(H_bg);
	
	//Load & SelectObject for mem_mouthbinary
	HBITMAP H_bgx = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	mem_mouthbinary.SelectObject(H_bgx);

	//Get handle of Control
	CWnd *hwnd2 = GetDlgItem(IDC_STILL3);
	CClientDC dc1(hwnd2);

	for(i=0;i<=ldisplayWidth;i++){
		for(j=0;j<=ldisplayHeight;j++){
			
			color = mem_binary.GetPixel(i,j);	

			//Get RGB Value at each position 
			red   = GetRValue(color);
			green = GetGValue(color);
			blue  = GetBValue(color);

			//conversion to GrayScale
			Y	 = (0.299*red)  + (0.587*green)  + (0.114*blue);
			Cr	=  red - Y;
			Cb   = blue - Y;

			//Skin color Segmentation
			//For luminance values Y <= 195:
			//	Cr component lies in the range 14 to 28
			//	Cb component has value greater than -21
			//For luminance values Y > 195:
			//	Cr component lies in the range 6 to 28
			//	Cb component has value greater than -21
			if((Y <= 195) && (Cr > 14 && Cr < 35) && (Cb > -35)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else if((Y > 195) && (Cr > 6 && Cr < 35) && (Cb > -35)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else{
				mem_binary.SetPixel(i,j,RGB(0,0,0));
			}
		
/*
//Low intensity
			if((Y <= 195) && (Cr > 35 && Cr < 70) && (Cb > -70)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else if((Y > 195) && (Cr > 30 && Cr < 70) && (Cb > -70)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else{
				mem_binary.SetPixel(i,j,RGB(0,0,0));
			}
*/

			//Detect Mouth using  Cr threshold,values between 40 - 59
			if(Cr > 35 && Cr < 59)
				mem_mouthbinary.SetPixel(i,j,RGB(255,255,255));
			else
				mem_mouthbinary.SetPixel(i,j,RGB(0,0,0));

		}	
	}
		//mem_binary keep the value of binary image
		dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_binary,0,0,SRCCOPY);
}

//Filter by  3 x 3 neigborhood
void CSampleDialog::Filter()
{	
	strFileName = fileName;
	int i,j;
	//variable for value of neighborhood's position
	int a1,a2,a3,a4,a5,a6,a7,a8,a9 = 0;
	//----------------
	//| a1 | a2 | a3 |
	//----------------
	//| a4 | a5 | a6 |
	//----------------
	//| a7 | a8 | a9 |
	//----------------
	
	HWND hwndStill3 = NULL;
	GetDlgItem(IDC_PREVIEW1,&hwndStill3);
	RECT rc;
	::GetWindowRect(hwndStill3, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	//Keep width & height for label funtion
	width = ldisplayWidth;
	height = ldisplayHeight;
	HBITMAP H_bg = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);

	mem_afterFilter.SelectObject(H_bg);
	
	CWnd *hwnd2 = GetDlgItem(IDC_PREVIEW1);
	CClientDC dc1(hwnd2);

	for(i=1;i<=ldisplayWidth;i++){
		for(j=1;j<=ldisplayHeight;j++){
			//condition operator (?:)
			a1 = (GetRValue(mem_binary.GetPixel(i-1,j-1))==255 ? 1 : 0);
			a2 = (GetRValue(mem_binary.GetPixel(i-1,j))==255 ? 1 : 0);
			a3 = (GetRValue(mem_binary.GetPixel(i-1,j+1))==255 ? 1 : 0);
			a4 = (GetRValue(mem_binary.GetPixel(i,j-1))==255 ? 1 : 0);
			a5 = (GetRValue(mem_binary.GetPixel(i,j))==255 ? 1 : 0);
			a6 = (GetRValue(mem_binary.GetPixel(i,j+1))==255 ? 1 : 0);
			a7 = (GetRValue(mem_binary.GetPixel(i+1,j-1))==255 ? 1 : 0);
			a8 = (GetRValue(mem_binary.GetPixel(i+1,j))==255 ? 1 : 0);
			a9 = (GetRValue(mem_binary.GetPixel(i+1,j+1))==255 ? 1 : 0);

			if((a1+a2+a3+a4+a5+a6+a7+a8+a9) >= 5){
				mem_afterFilter.SetPixel(i,j,RGB(255,255,255));
				afterFilter[i][j] = 1;
			}else{
				mem_afterFilter.SetPixel(i,j,RGB(0,0,0));
				afterFilter[i][j] = 0;
			}
		}	
	}

	//border of frame
	for(i=0;i<=width;i++){
			afterFilter[0][i] = 0;
			afterFilter[width][i] = 0;
	}
	for(i=0;i<=height;i++){
			afterFilter[i][0] = 0;
			afterFilter[i][height] =0;
	} 
	//mem_binary keep the value of binary image
		dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_afterFilter,0,0,SRCCOPY);
		
}

//Label 
void CSampleDialog::Label()
{
	int i,j,m,n;
	int temp=0;
	int count=0;
	int set=0;
	bool find = false;
	int check[500]={0};
	int pattern[320][240]={0};
	int a[4] = {0};

	//variable for value of neighborhood's position

	//----------------
	//| xx | a0 | a2 |
	//----------------
	//| a1 | ij | a3 |
	//----------------
	//| xx | xx | xx |
	//----------------

	for(i=1;i<height;i++){
		for(j=1;j<width;j++){

			//if(GetRValue(mem_afterFilter.GetPixel(i,j))==255)
			if(afterFilter[i][j]==1)
			{			
			a[0] = (pattern[i-1][j]);
			a[1] = (pattern[i][j-1]);
			a[2] = afterFilter[i-1][j+1];
			a[3] = afterFilter[i][j+1];

			//find minimum number of Label 
			if (a[2]==1 && a[3]==1){
				set = pattern[i-1][j+1];
			//chage relative pixes that should be the same label value
				int checkNumber = pattern[i][j-2];
				if(checkNumber != 0){
					for(m=1;m<height;m++){
						for(n=1;n<width;n++){
							if(pattern[m][n]==checkNumber)
						//if(pattern[m][n]==count)
							   pattern[m][n]=set;
						}			
					}
				}
			}else if(a[0]==0)
				set = a[1];
			else if (a[1]==0)
				set = a[0];			
			else
				set = (a[0]<=a[1]? a[0] : a[1]);
			//set = (set==0 ? 1 : set);
			//set adjacent to be the same Label
			//set Label for pattern[i][j] position


			if(a[0]+a[1]==0)
				pattern[i][j] = ++count;
			else{
				pattern[i][j] = set;
				pattern[i-1][j] = (a[0]!=0 ? set : 0);
				pattern[i][j-1] = (a[1]!=0 ? set : 0);	
			}

			}
		}//end for	
	}//end for

	//Adding Code for change some adjacent pixel
	//but didn't have the same number Label

	//how many label per one label
	for(i=1;i<height;i++){
		for(j=1;j<width;j++){
			temp = pattern[i][j];
			check[temp]= ++check[temp];
		}
	}
	temp = 0;
	int checkValue = 0;
	//check the most pixel keep the position
	for(i=1;i<499;i++){
		if(check[i]>checkValue){
			temp=i;
			checkValue = check[i];
		}
	}
	

//line1 top of the picture
	for(i=1;i<height;i++){
		for(j=1;j<width;j++){
			if(pattern[i][j]==temp){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	line1=i;
//line2 bottom of the picture
	find = false;
	for(i=height-1;i>=1;i--){
		for(j=width-1;j>=1;j--){
			if(pattern[i][j]==temp){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	line2=i;
//line3 left of the picture
	find = false;
	for(i=1;i<height;i++){
		for(j=1;j<width;j++){
			if(pattern[j][i]==temp){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	line3=i;
//line4 right of the picture
	find = false;
	for(i=height-1;i>=1;i--){
		for(j=width-1;j>=1;j--){
			if(pattern[j][i]==temp){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	line4=i;
}

void CSampleDialog::BoundaryDisplay()
{
	Label();

	strFileName = fileName;
	int i,j;

	HWND hwndStill2 = NULL;
	GetDlgItem(IDC_PREVIEW1,&hwndStill2);
	RECT rc;
	::GetWindowRect(hwndStill2, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	HBITMAP H_bg = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);

	mem_boundaryDisplay.SelectObject(H_bg);
	
	CWnd *hwnd2 = GetDlgItem(IDC_PREVIEW1);
	CClientDC dc1(hwnd2);

	//Set show Boundary
	for(i=line3;i<=line4;i++){
		mem_boundaryDisplay.SetPixel(line1,i,RGB(255,0,0));
		mem_boundaryDisplay.SetPixel(line2,i,RGB(255,0,0));		
	}
	for(j=line1;j<=line2;j++){
		mem_boundaryDisplay.SetPixel(j,line3,RGB(255,0,0));
		mem_boundaryDisplay.SetPixel(j,line4,RGB(255,0,0));			
	}

	//mem_gray keep the value of binary image
	dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_boundaryDisplay,0,0,SRCCOPY);
}


void CSampleDialog::FeatureExtract(){
	
	HWND hwndStill2 = NULL;
	GetDlgItem(IDC_STILL4,&hwndStill2);
	RECT rc;
	::GetWindowRect(hwndStill2, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	
	CWnd *hwnd2 = GetDlgItem(IDC_STILL4);
	CClientDC dc1(hwnd2);
	dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_mouthbinary,0,0,SRCCOPY);
}

void CSampleDialog::EdgeDetection(){
	strFileName = fileName;
	int i,j;
	//variable for value of neighborhood's position
	int z1,z2,z3,z4,z6,z7,z8,z9 = 0;
	int Gx,Gy = 0;
	//int edgeThreshold = 180;
	//----------------
	//| z1 | z2 | z3 |
	//----------------
	//| z4 | z5 | z6 |
	//----------------
	//| z7 | z8 | z9 |
	//----------------
	int edgeThreshold = (int)GetDlgItemInt(IDC_EDIT1,NULL,TRUE);

	HWND hwndStill3 = NULL;
	GetDlgItem(IDC_STILL2,&hwndStill3);
	RECT rc;
	::GetWindowRect(hwndStill3, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;

	HBITMAP H_bgx = (HBITMAP)LoadImage(NULL,strFileName,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);

	mem_edge.SelectObject(H_bgx);

	CWnd *hwnd2 = GetDlgItem(IDC_STILL2);
	CClientDC dc1(hwnd2);

	//clear all pixel to RGB(0,0,0)
	for(i=1;i<=ldisplayWidth;i++){
		for(j=1;j<=ldisplayHeight;j++){
			mem_edge.SetPixel(i,j,RGB(0,0,0));	
		}
	}

	for(i=line1;i<=line2;i++){
		for(j=line3;j<=line4;j++){
			z1 = GetRValue(mem_gray.GetPixel(i-1,j-1));
			z2 = GetRValue(mem_gray.GetPixel(i-1,j));
			z3 = GetRValue(mem_gray.GetPixel(i-1,j+1));
			z4 = GetRValue(mem_gray.GetPixel(i,j-1));

			z6 = GetRValue(mem_gray.GetPixel(i,j+1));
			z7 = GetRValue(mem_gray.GetPixel(i+1,j-1));
			z8 = GetRValue(mem_gray.GetPixel(i+1,j));
			z9 = GetRValue(mem_gray.GetPixel(i+1,j+1));

			//Calculate Gx & Gy
			Gx = abs((z7 + 2*z8 + z9) - (z1 + 2*z2 + z3));
			Gy = abs((z3 + 2*z6 + z9) - (z1 + 2*z4 + z7));

			if((Gx + Gy) >= edgeThreshold){
				mem_edge.SetPixel(i,j,RGB(255,255,255));
			}else{
				mem_edge.SetPixel(i,j,RGB(0,0,0));	
			}		

		}//end for	
	}//end for
	dc1.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_edge,0,0,SRCCOPY);
}//end EdgeDetection



//����������ͷ��ͺ��͹ �������ǡѺ��ǹ��ѡ
void CStillCapDlg::OnBnClickedButton1()
{	
	SnapPicture();
}

void CStillCapDlg::OnBnClickedSave()
{
	m_bFlag = FALSE;
	UpdateData(TRUE);
	CString stm;
	BOOL sex_temp;
	double day;
	int month_im,month_exp;
	int im,exp,qty=0;

	BOOL im_test;
	
	if(m_pPerson->IsEOF())
		m_pPerson->AddNew();
	else{
		m_pPerson->MoveLast();
		m_pPerson->AddNew();
	}

//********** Date Time *****************
	//UpdateData(TRUE);
	m_pPerson->m_BIRTHDAY= m_BIRTHDAY;
	
//********** Date Time *****************

	int tmp_int;  // Ẻ ����� Int
	tmp_int = this->GetDlgItemInt(IDC_ID,NULL,TRUE);
	m_pPerson->m_ID = tmp_int;

	 //Ẻ����� Text
	this->GetDlgItemText(IDC_NAME,stm);
	m_pPerson->m_NAME = stm;
	
	this->GetDlgItemText(IDC_SURNAME,stm);
	m_pPerson->m_SURNAME = stm;

	this->GetDlgItemText(IDC_ADDRESS,stm);
	m_pPerson->m_ADDRESS = stm;
	
	this->GetDlgItemText(IDC_EDIT1,stm);
	m_pPerson->m_PWD = stm;

//********* Radio BT **************
	CButton* pCheck= (CButton*)GetDlgItem(IDC_Male);
	sex_temp = pCheck->GetCheck();
		if (sex_temp != 1) 	{
			m_pPerson->m_SEX = FALSE ;
		}else
			m_pPerson->m_SEX = TRUE ;
//********* Radio BT END **************

	m_pPerson->Update();
	m_pPerson->Requery();
	Sleep(1000); //Delay Time

//************************************
	CpersonDB AddpSet(NULL);
	AddpSet.m_strSort = "PIC_ID DESC";
	AddpSet.Open( );
	tmp_int = AddpSet.m_PIC_ID;
//set filename 
	numfilename = tmp_int;
// copybitmap
	g_bOneShot = TRUE;
	mCB.CopyBitmap(cb.dblSampleTime, cb.pBuffer, cb.lBufferSize); 
	numfilename = 0;
//call for finding any position
	OnBnClickedAdmin();
//******** Table Picture *********
	if(m_pPic->IsEOF())
		m_pPic->AddNew();
	else{
		m_pPic->MoveLast();
		m_pPic->AddNew();
	}
	m_pPic->m_PIC_ID = tmp_int ;
	m_pPic->m_X_EYE= x_eye;
	m_pPic->m_Y_EYE= y_eye;
	m_pPic->m_AVG_EYE=avg_eye;
	m_pPic->m_X_MOUTH= x_mouth;
	m_pPic->m_Y_MOUTH= y_mouth;
	m_pPic->m_AVG_MOUTH= avg_mouth;
	m_pPic->m_X_NOSE= x_nose;
	m_pPic->m_Y_NOSE= y_nose;
	m_pPic->m_AVG_NOSE= avg_nose;
	m_pPic->m_STD_EYE = std_eye;
	m_pPic->m_STD_NOSE = std_nose;
	m_pPic->m_STD_MOUTH = std_mouth;	

	m_pPic->Update();
	if(m_pPic->CanUpdate())
		AfxMessageBox("�ѹ�֡ŧ�ҹ���������º����",MB_OK |MB_ICONEXCLAMATION);
	m_pPic->Requery();
	Sleep(1000); //Delay Time
//****************************
	m_pPerson->MoveFirst();
	GetData();
	GetDataPic();
    UpdateData(FALSE);
	m_bFlag=TRUE;
	pSave->EnableWindow(FALSE);
}

void CStillCapDlg::OnBnClickedButton2()  // �Ѵ�
{
	if (m_pPerson->IsEOF())
	{	
		pNext->EnableWindow(FALSE);
		AfxMessageBox( "�ä����ش��������",MB_OK|MB_ICONINFORMATION);
		m_pPerson->MoveLast();
		GetData();
        UpdateData(FALSE);


		return;
	}
	else
	{	
		m_pPerson->MoveNext();
		GetData();
        GetDataPic();
		UpdateData(FALSE);

		pEdit->EnableWindow(TRUE);
		pDel->EnableWindow(TRUE);
		pPrv->EnableWindow(TRUE);
		return;
	}
}

void CStillCapDlg::OnBnClickedButton3() //��͹˹��
{
	// TODO: Add your control notification handler code here
	//m_bFlag=FALSE;

	if (m_pPerson->IsBOF())
	{
		pPrv->EnableWindow(FALSE);
		AfxMessageBox( "�ä����á�ش����",MB_OK|MB_ICONINFORMATION);	
		m_pPerson->MoveFirst();
		GetData();
        UpdateData(FALSE);
		return;
	}
	else
	{
		m_pPerson->MovePrev();
		GetData();
		GetDataPic();
		UpdateData(FALSE);
		pEdit->EnableWindow(TRUE);
		pDel->EnableWindow(TRUE);
		pNext->EnableWindow(TRUE);
		return;
	}
}

void CStillCapDlg::OnBnClickedClear()
{
	m_bFlag=TRUE;
	m_List.ResetContent();
	ClearRecord();
	UpdateData(FALSE);
}

void CStillCapDlg::OnBnClickedAddpicdb()
{
	m_List.ResetContent();
	UpdateData(TRUE);
	char filter[20]="";
	char str[5]="";
	int temp = m_PICID;
	itoa(temp,str,10);

	CpicDB reSet(NULL);
	strncpy(filter,"[PIC_ID]=",10);
	strncat(filter,str,strlen(str));
	reSet.m_strFilter = filter;
	reSet.Open(CpicDB::snapshot,"PicDB");
	
	int x = reSet.m_X_EYE;
	itoa(x,str,10);
	strncpy(filter,"X-Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_EYE;
	itoa(x,str,10);
	strncpy(filter,"Y-Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_EYE;
	itoa(x,str,10);
	strncpy(filter,"Avg Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_X_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"X-Mouth = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"Y-Mouth = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"Avg Mouth = ",15);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_X_NOSE;
	itoa(x,str,10);
	strncpy(filter,"X-Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_NOSE;
	itoa(x,str,10);
	strncpy(filter,"Y-Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_NOSE;
	itoa(x,str,10);
	strncpy(filter,"Avg Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

}

void CStillCapDlg::OnBnClickedDelete()
{
	UpdateData(TRUE);
	char filter[20]="";
	char str[5]="";
	int temp = m_PICID;
	itoa(temp,str,10);

	int del = AfxMessageBox( "�س��ͧ���ź ���������",MB_YESNO|MB_ICONSTOP);
	if (del == IDYES)
	{
		CpicDB reSet(NULL);
		CpersonDB rpSet(NULL);

		strncpy(filter,"[PIC_ID]=",10);
		strncat(filter,str,strlen(str));
		reSet.m_strFilter = filter;
		//reSet.m_strFilter = "PIC_ID = " + temp;
		reSet.Open();
		rpSet.m_strFilter = filter;
		rpSet.Open();

		reSet.Delete();
		if(reSet.CanUpdate())
			AfxMessageBox("�ѹ�֡ŧ�ҹ���������º����",MB_OK |MB_ICONEXCLAMATION);

		reSet.MoveNext();
		if (reSet.IsEOF())
			reSet.MoveLast();
		if (reSet.IsBOF())
			reSet.SetFieldNull(NULL);

		Sleep(1000); //Delay Time

		rpSet.Delete();
		rpSet.MoveNext();
		if (rpSet.IsEOF())
			rpSet.MoveLast();		
		if (rpSet.IsBOF())
			rpSet.SetFieldNull(NULL);

	//	AfxMessageBox( "�к��ӡ��ź����������",MB_OK|MB_ICONINFORMATION);
		reSet.Requery();
		rpSet.Requery();
		reSet.Close();
		rpSet.Close();
	}
	m_pPerson->Requery();
	m_pPic->Requery();
	m_pPerson->MoveFirst();
	GetData();
    UpdateData(FALSE);
}

void CStillCapDlg::OnBnClickedUpdate()
{
	int del = AfxMessageBox( "�س��ͧ������ ���������",MB_YESNO|MB_ICONSTOP);
	if (del == IDYES)
	{
		UpdateData(TRUE);
	
		//Add New
		CString stm;
		BOOL sex_temp;
		double day;
		int month_im,month_exp;
		int im,exp,qty=0;

		BOOL im_test;
		m_pPerson->Edit();

		//********** Date Time *****************
		m_pPerson->m_BIRTHDAY= m_BIRTHDAY;
		
		int tmp_int;  // Ẻ ����� Int
		tmp_int = this->GetDlgItemInt(IDC_ID,NULL,TRUE);
		//m_pPerson->m_ID = tmp_int;
		//Ẻ����� Text
		this->GetDlgItemText(IDC_NAME,stm);
		m_pPerson->m_NAME = stm;	
		this->GetDlgItemText(IDC_SURNAME,stm);
		m_pPerson->m_SURNAME = stm;
		this->GetDlgItemText(IDC_ADDRESS,stm);
		m_pPerson->m_ADDRESS = stm;
		this->GetDlgItemText(IDC_EDIT1,stm);
		m_pPerson->m_PWD = stm;
		//********* Radio BT **************
		CButton* pCheck= (CButton*)GetDlgItem(IDC_Male);
		sex_temp = pCheck->GetCheck();
		if (sex_temp != 1) 	{
			m_pPerson->m_SEX = FALSE ;
		}else
			m_pPerson->m_SEX = TRUE ;
		//********* Radio BT END **************
		m_pPerson->Update();
		if(m_pPerson->CanUpdate())
			AfxMessageBox("��䢢��������º����",MB_OK |MB_ICONEXCLAMATION);
		//m_pPerson->Requery();
		Sleep(1000); //Delay Time
	
//************************************
	//m_pPerson->Close();
	}
	m_pPerson->Requery();
	m_pPerson->MoveFirst();
	GetData();
    UpdateData(FALSE);
}

void CStillCapDlg::ClearRecord(void)
{
	m_ID = NULL;
	m_NAME = L"";
	m_SURNAME = L"";
	m_SEX = FALSE;
	m_BIRTHDAY = COleDateTime(2004,01,01,00,00,00);
	m_ADDRESS = L"";
	m_PICID = 0;
	m_PWD = L"";
}
void CStillCapDlg::GetData(void)
{
	m_ID = m_pPerson->m_ID;
	m_NAME = m_pPerson->m_NAME;
	m_SURNAME = m_pPerson->m_SURNAME;
	m_ADDRESS = m_pPerson->m_ADDRESS;
	m_BIRTHDAY = m_pPerson->m_BIRTHDAY;
	m_SEX = m_pPerson->m_SEX;
	m_PICID = m_pPerson->m_PIC_ID;
	m_PWD = m_pPerson->m_PWD;
}
void CStillCapDlg::GetDataPic()
{
	m_List.ResetContent();
	//UpdateData(TRUE);
	char filter[50]="";
	char str[5]="";
	char bmp[5]=".bmp";
	int temp = m_PICID;
	itoa(temp,str,10);

	CpicDB reSet(NULL);
	strncpy(filter,"[PIC_ID]=",10);
	strncat(filter,str,strlen(str));
	reSet.m_strFilter = filter;
	reSet.Open(CpicDB::snapshot,"PicDB");

	int x = reSet.m_X_EYE;
	itoa(x,str,10);
	strncpy(filter,"X-Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_EYE;
	itoa(x,str,10);
	strncpy(filter,"Y-Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_EYE;
	itoa(x,str,10);
	strncpy(filter,"Avg Eye = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_X_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"X-Mouth = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"Y-Mouth = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_MOUTH;
	itoa(x,str,10);
	strncpy(filter,"Avg Mouth = ",15);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_X_NOSE;
	itoa(x,str,10);
	strncpy(filter,"X-Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_Y_NOSE;
	itoa(x,str,10);
	strncpy(filter,"Y-Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);

	x = reSet.m_AVG_NOSE;
	itoa(x,str,10);
	strncpy(filter,"Avg Nose = ",10);
	strncat(filter,str,strlen(str));
	m_List.AddString((LPCTSTR)filter);	
////Load image display	
	x = reSet.m_PIC_ID;
	itoa(x,str,10);
	strncpy(filter,"c:/DoormanRobot/DB/Picture/",27);
	strncat(filter,str,strlen(str));
	strncat(filter,bmp,strlen(bmp));
	memset(&filename,'\0',50);
	strncpy(filename,filter,35);
	
	H_image = LoadImageDB();
	mem_display.SelectObject(H_image);
	CWnd *hwnd = GetDlgItem(IDC_STILL);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_display,0,0,SRCCOPY);	
}


//New Method for CStillCapDlg
void CStillCapDlg::OnBnClickedAdmin()
{
//------------- call Convert Color Model function-------------
	ConvertToYCrCb();

//------------- call Filter function--------------------------
	//convert 2 dimensional arrays to 1 dimentional array
	//for passing by reference
	int* temp = new int[width*height];
	for(int i=0;i<width;i++)
		for(int j=0;j<height;j++)
			temp[(i*height)+j] = temp_binary[i][j];

	//call Filter fn' (width alternate with height na)
	Filter(temp,mem_binary,height,width,5);
	delete[] temp;

//------------- call Label function--------------------------
	Label();
//We must load new image into mem_display first	

//Set show Boundary (Temporary)
	for(int i=line3;i<=line4;i++){
		mem_display.SetPixel(line1,i,RGB(255,0,0));
		mem_display.SetPixel(line2,i,RGB(255,0,0));		
	}
	for(int j=line1;j<=line2;j++){
		mem_display.SetPixel(j,line3,RGB(255,0,0));
		mem_display.SetPixel(j,line4,RGB(255,0,0));			
	}

//------------- call Histrogram function--------------------------

	Histrogram();

	CWnd *hwnd = GetDlgItem(IDC_STILL);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,width,height,&mem_eye,0,0,SRCCOPY);	

//-------------- call Correlation function------------------------
//Loop checking image from database 

	int xieye = 30;
	int yieye = 10;
	int xinose = 16;
	int yinose = 10;
	int ximouth = 30;
	int yimouth = 10;

//finding average and standard deviation of eye
	for(int i = xdistance-xieye; i<= xdistance+xieye; i++){
		for(int j = ydistance-yieye; j <= ydistance+yieye; j++){
			image[(j-(ydistance-yieye))+(yieye+1)][(i-(xdistance-xieye))+(xieye+1)] = grayImage[i][j];
			//find average value of image	
			avg_eye = avg_eye + grayImage[i][j];
		}
	}
			avg_eye = avg_eye /(61*21);

	//finding standard deviation
	for(int i=yieye+1;i<=(2*yieye);i++)
		for(int j=xieye;j<=(2*xieye);j++)
			std_eye = std_eye + (pow((image[i][j] - avg_eye),2));

//finding average and standard deviation of nose

ydistance = y_nose;

	for(int i = xdistance-xinose; i<= xdistance+xinose; i++){
		for(int j = ydistance-yinose; j <= ydistance+yinose; j++){
			image[(j-(ydistance-yinose))+(yinose+1)][(i-(xdistance-xinose))+(xinose+1)] = grayImage[i][j];
			//find average value of image	
			avg_nose = avg_nose + grayImage[i][j];
		}
	}
			avg_nose = avg_nose /(33*21);

	//finding standard deviation
	for(int i=yinose+1;i<=(2*yinose);i++)
		for(int j=xinose;j<=(2*xinose);j++)
			std_nose = std_nose + (pow((image[i][j] - avg_nose),2));



//finding average and standard deviation of mouth

ydistance = y_mouth;

	for(int i = xdistance-ximouth; i<= xdistance+ximouth; i++){
		for(int j = ydistance-yimouth; j <= ydistance+yimouth; j++){
			image[(j-(ydistance-yimouth))+(yimouth+1)][(i-(xdistance-ximouth))+(ximouth+1)] = grayImage[i][j];
			//find average value of image	
			avg_mouth = avg_mouth + grayImage[i][j];
		}
	}
			avg_mouth = avg_mouth /(61*21);

	//finding standard deviation
	for(int i=yimouth+1;i<=(2*yimouth);i++)
		for(int j=ximouth;j<=(2*ximouth);j++)
			std_mouth = std_mouth + (pow((image[i][j] - avg_mouth),2));

	ClearRecord();
	UpdateData(FALSE);
	pSave->EnableWindow(TRUE);
}




void CStillCapDlg::ConvertToGray(CDC& mem_gray,int x,int xi,int y,int yi){
	COLORREF color;
	BYTE red,green,blue;
	double temp;

	for(int i = x-xi; i<= x+xi; i++){
		for(int j = y-yi; j <= y+yi; j++){
			color = mem_gray.GetPixel(i,j);	
			//Get RGB Value at each position 
			red   = GetRValue(color);
			green = GetGValue(color);
			blue  = GetBValue(color);
			//conversion to GrayScale
			temp = (0.299*red) + (0.587*green) + (0.114*blue);
			plate[j-(y-yi)][i-(x-xi)] = (int)temp;			
		//	mem_gray.SetPixel(i,j,RGB(temp,temp,temp));	
		}
	}
}

HBITMAP CStillCapDlg::LoadImageDB(){
	
	HWND hwndStill = NULL;
	GetDlgItem(IDC_STILL,&hwndStill);
	RECT rc;
	::GetWindowRect(hwndStill, &rc);
	width = ldisplayWidth = rc.right - rc.left;
	height = ldisplayHeight = rc.bottom - rc.top;
	
	H_image = (HBITMAP)LoadImage(NULL,(CString)filename,
		    IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	
	return H_image;
}

void CStillCapDlg::ConvertToYCrCb(){
	int i,j;
	COLORREF color;
	BYTE red,green,blue;
	double Y,Cr,Cb;

	H_image = LoadImageDB();
	mem_binary.SelectObject(H_image);

	for(i=0;i<=width;i++){
		for(j=0;j<=height;j++){
			
			color = mem_binary.GetPixel(i,j);	

			//Get RGB Value at each position 
			red   = GetRValue(color);
			green = GetGValue(color);
			blue  = GetBValue(color);

			//conversion to GrayScale
			Y	 = (0.299*red)  + (0.587*green)  + (0.114*blue);
			Cr	=  red - Y;
			Cb   = blue - Y;
			grayImage[i][j] = int(Y);

			//Skin color Segmentation
			//For luminance values Y <= 195:
			//	Cr component lies in the range 14 to 28
			//	Cb component has value greater than -21
			//For luminance values Y > 195:
			//	Cr component lies in the range 6 to 28
			//	Cb component has value greater than -21
			if((Y <= 195) && (Cr > 14 && Cr < 35) && (Cb > -35)){
				temp_binary[i][j]=1;
			}
			else if((Y > 195) && (Cr > 6 && Cr < 35) && (Cb > -35)){
				temp_binary[i][j]=1;
			}
			else{
				temp_binary[i][j]=0;
			}
		
/*
//Low intensity
			if((Y <= 195) && (Cr > 35 && Cr < 70) && (Cb > -70)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else if((Y > 195) && (Cr > 30 && Cr < 70) && (Cb > -70)){
				mem_binary.SetPixel(i,j,RGB(255,255,255));
			}
			else{
				mem_binary.SetPixel(i,j,RGB(0,0,0));
			}
*/
		}	
	}
}

void CStillCapDlg::Filter(int* temp_binary,CDC& mem_afterFilter,int width,int height,int neighbor){
	//variable for value of neighborhood's position
	int a1,a2,a3,a4,a5,a6,a7,a8,a9 = 0;
	//----------------
	//| a1 | a2 | a3 |
	//----------------
	//| a4 | a5 | a6 |
	//----------------
	//| a7 | a8 | a9 |
	//----------------

	memset(&afterFilter,0,sizeof(afterFilter));

	for(int i=1;i<height;i++){
		for(int j=1;j<width;j++){
			a1 = temp_binary[((i-1)*width)+(j-1)];
			a2 = temp_binary[((i-1)*width)+j];
			a3 = temp_binary[((i-1)*width)+(j+1)];
			a4 = temp_binary[(i*width)+(j-1)];
			a5 = temp_binary[(i*width)+j];
			a6 = temp_binary[(i*width)+(j+1)];
			a7 = temp_binary[((i+1)*width)+(j-1)];
			a8 = temp_binary[((i+1)*width)+j];
			a9 = temp_binary[((i+1)*width)+(j+1)];

			if((a1+a2+a3+a4+a5+a6+a7+a8+a9) >= neighbor){
				mem_afterFilter.SetPixel(i,j,RGB(255,255,255));
				afterFilter[i][j] = 1;
			}else{
				mem_afterFilter.SetPixel(i,j,RGB(0,0,0));
				afterFilter[i][j] = 0;
			}
		}	
	}
	//border of frame
	for(i=0;i<=width;i++){
			afterFilter[0][i] = 0;
			afterFilter[height][i] = 0;
	}
	for(i=0;i<=height;i++){
			afterFilter[i][0] = 0;
			afterFilter[i][width] =0;
	}
}

void CStillCapDlg::Label(){
	int temp=0;
	int count=0;
	int set=0;
	bool find = false;
	int check[500]={0};
	int pattern[320][300]={0};
	int a[4] = {0};
	int b[4] = {0};

	//variable for value of neighborhood's position

	//----------------
	//| xx | a0 | a2 |
	//----------------
	//| a1 | ij | a3 |
	//----------------
	//| xx | xx | xx |
	//----------------

	for(int i=1;i<width;i++){
		for(int j=1;j<height;j++){
			if(afterFilter[i][j]==1)
			{			
				b[0] = pattern[i-1][j-1];
				b[1] = pattern[i-1][j];
				b[2] = pattern[i-1][j+1];
				b[3] = pattern[i][j-1];
				
				a[0] = afterFilter[i-1][j-1];
				a[1] = afterFilter[i-1][j];
				a[2] = afterFilter[i-1][j+1];
				a[3] = afterFilter[i][j-1];

				if(a[0]+a[1]+a[2]+a[3] == 0)
					pattern[i][j] = ++count;
				else if(a[0] == 1 && a[1] == 0 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 0 && a[1] == 1 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[1];
				else if(a[0] == 0 && a[1] == 0 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[2];
				else if(a[0] == 0 && a[1] == 0 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[3];
				else if(a[0] == 1 && a[1] == 0 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[1];
				else if((a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 0)||
					    (a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 1)){
					if(b[0] == b[2])
						pattern[i][j] = b[0];
					else{
						pattern[i][j] = b[0];
						for(int m=1;m<width;m++){
							for(int n=1;n<height;n++){
								if(pattern[m][n]==b[2])
								   pattern[m][n]=b[0];
							}			
						}
					}
				}else if((a[0] == 0 && a[1] == 0 && a[2] == 1 && a[3] == 1)||
					     (a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 1)){
					if(b[2] == b[3])
						pattern[i][j] = b[2];
					else{
						pattern[i][j] = b[2];
						for(int m=1;m<width;m++){
							for(int n=1;n<height;n++){
								if(pattern[m][n]==b[3])
								   pattern[m][n]=b[2];
							}			
						}
					}
				}else if(a[0] == 0 && a[1] == 1 && a[2] == 0 && a[3] == 1){
					if(b[1] == b[3])
						pattern[i][j] = b[1];
					else{
						pattern[i][j] = b[1];
						for(int m=1;m<width;m++){
							for(int n=1;n<height;n++){
								if(pattern[m][n]==b[3])
								   pattern[m][n]=b[1];
							}			
						}
					}
				}else if(a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[1];
				else if(a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[0];
			}//end if
		}//end for	
	}//end for

	//Adding Code for change some adjacent pixel
	//but didn't have the same number Label

	//how many label per one label
	for(int i=1;i<height;i++){
		for(int j=1;j<width;j++){
			temp = pattern[i][j];
			check[temp]= ++check[temp];
		}
	}
	temp = 0;
	int checkValue = 0;
	//check the most pixel keep the position
	for(int i=1;i<=count;i++){
		if(check[i]>checkValue){
				temp=i;
				checkValue = check[i];
		}
	}
	//convert 2 Dimensional Array to 1 Dimensional Array
	int* temparray = new int[width*height];
	int* answer = new int[4];
	for(int i=1;i<height;i++)
		for(int j=1;j<width;j++)
			temparray[(i*width)+j] = pattern[i][j];

	findBoundary(height,width,temparray,answer,temp);
	//keep line position of boundary of Skin color segmented image
	line1 = answer[0];
	line2 = answer[1];
	line3 = answer[2];
	line4 = answer[3];
	delete[] temparray;
	delete[] answer;	
}

void CStillCapDlg::findBoundary(int height,int width,int* pattern,int* answer,int value)
{
	bool find = false;
	for(int i=1;i<height;i++){
		for(int j=1;j<width;j++){
			if(pattern[(i * width)+j]==value){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	answer[0]=i; 

//line2 bottom of the picture
	find = false;
	for(int i=height-1;i>=1;i--){
		for(int j = 1;j<width;j++){
			if(pattern[(i * width)+j]==value){
				find = true;
				break;
			}
		}
			if(find)
				break;
	}
	answer[1]=i; 
//line3 left of the picture
	find = false;
	for(int j=1;j<width;j++){
		for(int i=1;i<height;i++){
			if(pattern[(i * width)+j]==value){
				find = true;
				answer[2]=j;
				break;
			}
		}
			if(find)
				break;
	}

//line4 right of the picture
	find = false;
	for(int j=width-1;j>=1;j--){
		for(int i=height-1;i>=1;i--){
			if(pattern[(i * width)+j]==value){
				find = true;
				answer[3]=j;
				break;
			}
		}
			if(find)
				break;
	}
}

void CStillCapDlg::Histrogram(){
	int histro[255] = {0};
	int histromax[26]= {0};
	int histromin[26] = {0};
	int min =0,max = 0;
	int temp=1;		//initial value for seeking the first peak of histrogram
	int appthresh=0;
	int hwidth = line2 - line1;
	int hheight = int(ceil(((line4 - line3)*1)/2));
	int* temparray = new int[hwidth*hheight];	

	//Kept gray level image
	//line1 = top,line2 = bottom,line3 = left,line4 = right
	for(int i=line3;i<=line4;i++)
		for(int j = line1;j<=line2;j++)
			histro[grayImage[i][j]]=histro[grayImage[i][j]]+1;
	
	//smoothed histrogram
	for(int x=0;x<=24;x++){
		min = 255;
		max = 0;
		//find maximum and minimum in local range
		for(int y =(x*10+1);y<=((x+1)*10);y++){
			if (max < histro[y])
				max = histro[y];
			if (min > histro[y])
				min = histro[y];
		}
		histromax[x+1] = max;
		histromin[x+1] = min;		
	}
	while(histromax[temp+1]-histromax[temp] >= 0)
		temp = temp+1;
	
	//find x position of histrogram
	for(int i=0;i<255;i++){
		if(histro[i]==histromax[temp]){
			temp = i;		//Now,temp will keep first peak position of histrogram		
			break;
		}
	}

	//We've got the appropriate threshold
	appthresh = temp;

	//clear all pixel to RGB(0,0,0)
	for(int i=0;i<=width;i++){
		for(int j=0;j<=height;j++){
			mem_binary.SetPixel(i,j,RGB(0,0,0));	
		}
	}

//Analyze eye position
int realeye[2][2] = {0};
bool eye = false;

//find center of expected eyepos
//convert 2 Dimensional Array to 1 Dimensional Array
int* temparray2 = new int[hwidth*hheight];
int* answer = new int[4];
int* centerx = new int[10];
int* centery = new int[10];
int foundeye = 0;

//seeking for group of pixel that have the interesting size
int eyepos[10] = {0};
int pos = 0;

//label for find group of eye
int pattern[200][200]={0};
int a[4] = {0},b[4] ={0};
int set = 0,count = 0;
int check[100]={0};

//maximum round of loop
int maxround = 0;

do{

	memset(&afterFilter,0,sizeof(afterFilter));
	for(int i=1;i<hwidth-1;i++){
		for(int j=1;j<hheight-1;j++){
		if(grayImage[i+line1][j+line3] >= (appthresh + (6*maxround))){
				temparray[(i*hheight)+j] = 0;
			}else{
				temparray[(i*hheight)+j] = 1;
			}			
		}
	}
	//call Filter fn' (width alternate with height na)
	Filter(temparray,mem_binary,hheight,hwidth,3);

//label for find group of eye
memset(&pattern,0,(200*200));
memset(&a,0,4);
memset(&b,0,4);
memset(&check,0,100);
set = count = 0;

for(int i=1;i<hwidth;i++){
		for(int j=1;j<hheight;j++){
			if(afterFilter[i][j]==1)
			{			
				b[0] = pattern[i-1][j-1];
				b[1] = pattern[i-1][j];
				b[2] = pattern[i-1][j+1];
				b[3] = pattern[i][j-1];
				
				a[0] = afterFilter[i-1][j-1];
				a[1] = afterFilter[i-1][j];
				a[2] = afterFilter[i-1][j+1];
				a[3] = afterFilter[i][j-1];

				if(a[0]+a[1]+a[2]+a[3] == 0)
					pattern[i][j] = ++count;
				else if(a[0] == 1 && a[1] == 0 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 0 && a[1] == 1 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[1];
				else if(a[0] == 0 && a[1] == 0 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[2];
				else if(a[0] == 0 && a[1] == 0 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[3];
				else if(a[0] == 1 && a[1] == 0 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 0 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[1];
				else if((a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 0)||
					    (a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 1)){
					if(b[0] == b[2])
						pattern[i][j] = b[0];
					else{
						pattern[i][j] = b[0];
						for(int m=1;m<hwidth;m++){
							for(int n=1;n<hheight;n++){
								if(pattern[m][n]==b[2])
								   pattern[m][n]=b[0];
							}			
						}
					}
				}else if((a[0] == 0 && a[1] == 0 && a[2] == 1 && a[3] == 1)||
					     (a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 1)){
					if(b[2] == b[3])
						pattern[i][j] = b[2];
					else{
						pattern[i][j] = b[2];
						for(int m=1;m<hwidth;m++){
							for(int n=1;n<hheight;n++){
								if(pattern[m][n]==b[3])
								   pattern[m][n]=b[2];
							}			
						}
					}
				}else if(a[0] == 0 && a[1] == 1 && a[2] == 0 && a[3] == 1){
					if(b[1] == b[3])
						pattern[i][j] = b[1];
					else{
						pattern[i][j] = b[1];
						for(int m=1;m<hwidth;m++){
							for(int n=1;n<hheight;n++){
								if(pattern[m][n]==b[3])
								   pattern[m][n]=b[1];
							}			
						}
					}
				}else if(a[0] == 0 && a[1] == 1 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[1];
				else if(a[0] == 1 && a[1] == 0 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 0 && a[3] == 1)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 1 && a[3] == 0)
					pattern[i][j] = b[0];
				else if(a[0] == 1 && a[1] == 1 && a[2] == 1 && a[3] == 1)
					pattern[i][j] = b[0];
			}//end if
		}//end for	
	}//end for

	//how many label per one label
	for(int i=1;i<hwidth;i++){
		for(int j=1;j<hheight;j++){
			temp = pattern[i][j];
			check[temp]= ++check[temp];
		}
	}

//seeking for group of pixel that have the interesting size
memset(&eyepos,0,10);
pos = 0;

for(int i=1;i<100;i++)
		if(check[i]>=10 && check[i]<=50)
			eyepos[pos++]=i;

//load for draw expected position
	H_image = LoadImageDB();
	mem_eye.SelectObject(H_image);

//find center of expected eyepos
//convert 2 Dimensional Array to 1 Dimensional Array

	foundeye = 0;

	for(int round=0;round<10;round++){
		if(eyepos[round] == 0)
			break;
		else{
			for(int i=1;i<hheight;i++)
				for(int j=1;j<hwidth;j++)
					temparray2[(i*hwidth)+j] = pattern[i][j];

			findBoundary(hheight,hwidth,temparray2,answer,eyepos[round]);
			if(((answer[1]-answer[0]) <= 20 )&& ((answer[3]-answer[2]) <= 20)){ //check ratio of x and y
				centery[foundeye] = line3 + answer[2] + (answer[3] - answer[2]);
				centerx[foundeye] = line1 + answer[0] + (answer[1] - answer[0]);
				foundeye++;	//increment to indicate eye is found in round presently.	
				for(int i=centerx[round]-2;i<=centerx[round]+2;i++){
					mem_eye.SetPixel(i,centery[round],RGB(255,0,0));
				}
				for(int j=centery[round]-2;j<=centery[round]+2;j++){
					mem_eye.SetPixel(centerx[round],j,RGB(255,0,0));
				}
			}//end if
		}//end else

	}//end for
			
//Analyze eye position

//memset(&realeye,0,4);

	for(int i = 0;i<(foundeye-1) ; i++)
		for(int j = (i+1);j<foundeye;j++){		
		//	if(EyeCorrelation(centerx[i],centery[i],centerx[j],centery[j])>0.5){
			if((centery[i]- 9 <= centery[j] && centery[i] + 9 >= centery[j])&& 
				//the level of eye not difference over + 9 & - 9
			   (abs(centerx[i] - centerx[j]) >= 30)&& // x distance checking
			   (abs(centerx[i] - centerx[j]) <= 50)&&
			   !CheckBelowEye(centerx,centery,i,j,foundeye)) 
			{
				realeye[0][0] = centerx[i];
				realeye[0][1] = centery[i];
				realeye[1][0] = centerx[j];
				realeye[1][1] = centery[j];
				
				adistance = abs(centerx[i] - centerx[j]);
				xdistance = min(centerx[i],centerx[j]) + (abs(centerx[i] - centerx[j])/2);
				ydistance = min(centery[i],centery[j]) + (abs(centery[i] - centery[j])/2);
				eye = true;
				break;
			}
			if(eye)
				break;
		}

		maxround++;
}while(!eye && maxround < 30);
//draw real position
		if(eye){
			//draw eye	
			DrawPosition(realeye);
//keep value of x_eye,y_eye
			x_eye = xdistance;
			y_eye = ydistance;
            
			//draw nose & mouth
			//reuse realeye array for keeping nose & mouth position respectively
			//And keep value of nose and mouth
			x_nose = realeye[0][0] = xdistance;
			y_nose = realeye[0][1] = ydistance + ((adistance * 7) / 12);
			x_mouth = realeye[1][0] = xdistance;
			y_mouth = realeye[1][1] = ydistance + ((adistance * 13) / 12);
			DrawPosition(realeye);		
		}//end if

	delete[] temparray;
	delete[] temparray2; 
	delete[] answer;
	delete[] centerx;
	delete[] centery;
}

void CStillCapDlg::DrawPosition(int realeye[2][2]){
			for(int i=realeye[0][0]-2;i<=realeye[0][0]+2;i++){
				mem_eye.SetPixel(i,realeye[0][1],RGB(0,255,0));
			}
			for(int j=realeye[0][1]-2;j<=realeye[0][1]+2;j++){
				mem_eye.SetPixel(realeye[0][0],j,RGB(0,255,0));
			}
			for(int i=realeye[1][0]-2;i<=realeye[1][0]+2;i++){
				mem_eye.SetPixel(i,realeye[1][1],RGB(0,255,0));
			}
			for(int j=realeye[1][1]-2;j<=realeye[1][1]+2;j++){
				mem_eye.SetPixel(realeye[1][0],j,RGB(0,255,0));
			}
}

bool CStillCapDlg::CheckBelowEye(int* centerx,int* centery,int a,int b,int foundeye){
	bool temp = false;
	for(int i = 0;i<foundeye; i++){
		if(centery[i] > centery[a]) 
			if(centerx[a]-9 <= centerx[i] && centerx[a]+9 >= centerx[i])
				temp = true;
	}

	for(int j = 0; j<foundeye; j++){
		if(centery[j] > centery[b])
			if(centerx[b]-9 <= centerx[j] && centerx[b]+9 >= centerx[j])
				temp = true;
	}
	return temp;
}

//Correlation Coefficient function do on Y plane,gray level image.
//m = height,n = width
double CStillCapDlg::Correlation(int m,int n,double avgf,double stdf){
//using plate and image array,global variable,to take correlate
	double avgw = 0;
	double stdw = 0;
	double correlate = 0;
	double maxcor = 0;


//matching
	for(int x = 0;x<m;x++){
		for(int y = 0;y<n;y++){
//find average value of image array in the region coincident with the current location.
		for(int r = x ; r<= m + x; r++)
			for(int s = y; s <= n + y; s++)
				avgw = avgw + image[r][s];
		avgw = avgw /(m*n);

		//finding standard deviation
		for(int r = x ; r<= m + x; r++)
			for(int s = y; s <= n + y; s++)
				stdw = stdw + (pow((image[r][s] - avgw),2));	
			
//loop for finding correlation			
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){ 
				 correlate = correlate+(((plate[i][j]-avgf)*(image[i+x][j+y]-avgw)));
				}
			}
			 correlate = correlate / (sqrt(stdf*stdw));
			 if(maxcor < correlate)
				 maxcor = correlate;
			 //clear value for next round
			 correlate = 0;
			 avgw = 0;
			 stdw = 0;
		}
	}
	char buffer[30] = "";	
	sprintf(buffer,"%f",maxcor);
	MessageBox(buffer,NULL,MB_OK);
	return maxcor;
}


void CStillCapDlg::OnEnChangeId()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);
	char str[10] = "";
	itoa(m_ID,str,10); //�ŧ�� ʵ�ԧ�����Ҩӹǹ��ѡ
	int countID = strlen(str); // �Ҩӹǹ�ͧʵ�ԧ
	//int countID = atoi(str);  //�ҡʵ�ԧ�ŧ�繵���Ţ
	
	if (countID==8)
	{
		UpdateData(TRUE);
		int id = m_ID;
		char filter[20]="";
		char str[10]="";

		itoa(id,str,10);

		CpersonDB rpSet(NULL);
        strncpy(filter,"[ID]=",10);
		strncat(filter,str,strlen(str));
		rpSet.m_strFilter = filter;

		rpSet.Open( CpersonDB::snapshot,"personDB");
		if (m_ID == rpSet.m_ID)
		{
			m_ID = rpSet.m_ID;
			m_NAME = rpSet.m_NAME;
			m_SURNAME = rpSet.m_SURNAME;
			m_ADDRESS = rpSet.m_ADDRESS;
			m_BIRTHDAY = rpSet.m_BIRTHDAY;
			m_SEX = rpSet.m_SEX;
			m_PICID = rpSet.m_PIC_ID;
			m_PWD = rpSet.m_PWD;
//			GetData();
			GetDataPic();
			UpdateData(FALSE);	
			rpSet.Close();
		}
		/*else
		{
			MessageBox("�ú 8 ����",NULL,MB_OK);
			UpdateData(FALSE);	
		}*/
		
		pEdit->EnableWindow(TRUE);
		pDel->EnableWindow(TRUE);

		//MessageBox("�ú 8 ����",NULL,MB_OK);
		return;
	}
	else if (countID > 8)
	{
		m_ID = 0;
		UpdateData(FALSE);
		pEdit->EnableWindow(FALSE);
		pDel->EnableWindow(FALSE);
	}
		pEdit->EnableWindow(FALSE);
		pDel->EnableWindow(FALSE);
}

void CStillCapDlg::OnBnClickedAdminAcc()
{
	// TODO: Add your control notification handler code here
	//ShowWindow(SW_MINIMIZE);
	CAdminDlg dlg;
	dlg.DoModal();		
}
