// adminDB.h : Implementation of the CadminDB class



// CadminDB implementation

// code generated on 11 �չҤ� 2547, 14:56

#include "stdafx.h"
#include "adminDB.h"
IMPLEMENT_DYNAMIC(CadminDB, CRecordset)

CadminDB::CadminDB(CDatabase* pdb)
	: CRecordset(pdb)
{
	m_name = L"";
	m_pwd = L"";
	m_nFields = 2;
	m_nDefaultType = snapshot;
}
//#error Security Issue: The connection string may contain a password
// The connection string below may contain plain text passwords and/or
// other sensitive information. Please remove the #error after reviewing
// the connection string for any security related issues. You may want to
// store the password in some other form or use a different user authentication.
CString CadminDB::GetDefaultConnect()
{
	return _T("DSN=doorman;DBQ=C:\\DoormanRobot\\DB\\doorman.mdb;DriverId=25;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;");
}

CString CadminDB::GetDefaultSQL()
{
	return _T("[admin]");
}

void CadminDB::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
// Macros such as RFX_Text() and RFX_Int() are dependent on the
// type of the member variable, not the type of the field in the database.
// ODBC will try to automatically convert the column value to the requested type
	RFX_Text(pFX, _T("[name]"), m_name);
	RFX_Text(pFX, _T("[pwd]"), m_pwd);

}
/////////////////////////////////////////////////////////////////////////////
// CadminDB diagnostics

#ifdef _DEBUG
void CadminDB::AssertValid() const
{
	CRecordset::AssertValid();
}

void CadminDB::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


