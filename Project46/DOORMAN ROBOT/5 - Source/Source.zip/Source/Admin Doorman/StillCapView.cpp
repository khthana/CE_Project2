// StillCapView.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "StillCapView.h"


// CStillCapView

IMPLEMENT_DYNCREATE(CStillCapView, CView)

CStillCapView::CStillCapView()
{
}

CStillCapView::~CStillCapView()
{
}

BEGIN_MESSAGE_MAP(CStillCapView, CView)
END_MESSAGE_MAP()


// CStillCapView drawing

void CStillCapView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}


// CStillCapView diagnostics

#ifdef _DEBUG
void CStillCapView::AssertValid() const
{
	CView::AssertValid();
}

void CStillCapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG


// CStillCapView message handlers
