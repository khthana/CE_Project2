// Login.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "Login.h"
#include "StillCapDlg.h"

// CLogin dialog

IMPLEMENT_DYNAMIC(CLogin, CDialog)
CLogin::CLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CLogin::IDD, pParent)
	, m_username(_T(""))
	, m_password(_T(""))
{
}

CLogin::~CLogin()
{
}

void CLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_username);
	DDX_Text(pDX, IDC_EDIT2, m_password);
}


BEGIN_MESSAGE_MAP(CLogin, CDialog)
	ON_BN_CLICKED(IDC_OK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_CANCEL, OnBnClickedCancel)
END_MESSAGE_MAP()


// CLogin message handlers

void CLogin::OnBnClickedOk()
{
	UpdateData(TRUE);
	char filter[40]="";
	char endQ[2]="'";
	CadminDB rpAdmin( NULL );
    strncpy(filter," name = '",10);
	strncat(filter,m_username,strlen(m_username));
	strncat(filter,endQ,strlen(endQ));
	rpAdmin.m_strFilter = filter;
	rpAdmin.Open(CadminDB::snapshot,"Admin");

	if ((m_username == (CString)rpAdmin.m_name)&&(m_password == (CString)rpAdmin.m_pwd)&&(m_password != ""))
	{			
			//ShowWindow(SW_HIDE);
			EndDialog(1); 
			CStillCapDlg dlg2;
			dlg2.DoModal();				
	}
	else
	{
		AfxMessageBox( "Username ���� Password �Դ ��سҡ�͡�����ա����",MB_OK|MB_ICONINFORMATION);
	}

	// TODO: Add your control notification handler code here
}

void CLogin::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	DestroyWindow();
}
