// picDB.h : Implementation of the CpicDB class



// CpicDB implementation

// code generated on 26 �ѹ�Ҥ� 2546, 23:00

#include "stdafx.h"
#include "picDB.h"
IMPLEMENT_DYNAMIC(CpicDB, CRecordset)

CpicDB::CpicDB(CDatabase* pdb)
	: CRecordset(pdb)
{
	m_PIC_ID = 0;
	m_X_EYE = 0;
	m_Y_EYE = 0;
	m_AVG_EYE = 0;
	m_X_NOSE = 0;
	m_Y_NOSE = 0;
	m_AVG_NOSE = 0;
	m_X_MOUTH = 0;
	m_Y_MOUTH = 0;
	m_AVG_MOUTH = 0;

	m_STD_EYE = 0;
	m_STD_NOSE = 0;
	m_STD_MOUTH= 0;	


	m_nFields = 13;
	m_nDefaultType = snapshot;
}
//#error Security Issue: The connection string may contain a password
// The connection string below may contain plain text passwords and/or
// other sensitive information. Please remove the #error after reviewing
// the connection string for any security related issues. You may want to
// store the password in some other form or use a different user authentication.
CString CpicDB::GetDefaultConnect()
{
	return _T("DSN=Doorman;DBQ=C:\\DoormanRobot\\DB\\doorman.mdb;DriverId=25;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;");
}

CString CpicDB::GetDefaultSQL()
{
	return _T("[picDB]");
	//return _T("SELECT * FROM picDB ORDER BY PIC_ID DESC");
}

void CpicDB::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
// Macros such as RFX_Text() and RFX_Int() are dependent on the
// type of the member variable, not the type of the field in the database.
// ODBC will try to automatically convert the column value to the requested type
	RFX_Long(pFX, _T("[PIC_ID]"), m_PIC_ID);
	RFX_Long(pFX, _T("[X_EYE]"), m_X_EYE);
	RFX_Long(pFX, _T("[Y_EYE]"), m_Y_EYE);
	RFX_Long(pFX, _T("[AVG_EYE]"), m_AVG_EYE);
	RFX_Long(pFX, _T("[X_NOSE]"), m_X_NOSE);
	RFX_Long(pFX, _T("[Y_NOSE]"), m_Y_NOSE);
	RFX_Long(pFX, _T("[AVG_NOSE]"), m_AVG_NOSE);
	RFX_Long(pFX, _T("[X_MOUTH]"), m_X_MOUTH);
	RFX_Long(pFX, _T("[Y_MOUTH]"), m_Y_MOUTH);
	RFX_Long(pFX, _T("[AVG_MOUTH]"), m_AVG_MOUTH);
	RFX_Long(pFX, _T("[STD_EYE]"), m_STD_EYE);
	RFX_Long(pFX, _T("[STD_MOUTH]"), m_STD_MOUTH);
	RFX_Long(pFX, _T("[STD_NOSE]"), m_STD_NOSE);

}
/////////////////////////////////////////////////////////////////////////////
// CpicDB diagnostics

#ifdef _DEBUG
void CpicDB::AssertValid() const
{
	CRecordset::AssertValid();
}

void CpicDB::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


