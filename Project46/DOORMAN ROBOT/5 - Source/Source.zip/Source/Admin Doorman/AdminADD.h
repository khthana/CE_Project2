#pragma once

#include "adminDB.h"
//#include "StillCapDlg.h"
// CAdminADD dialog

class CAdminADD : public CDialog
{
	DECLARE_DYNAMIC(CAdminADD)

public:
	CAdminADD(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAdminADD();
//CadminDB* m_pAdminDB;
//	CadminDB getAdminDB;
// Dialog Data
	enum { IDD = IDD_DIALOG2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_AdminName;
	CString m_AdminPWD;
	CString m_ConfirmPWD;
	afx_msg void OnBnClickedAdminadd();

};
