#pragma once


// CAdminDlg dialog

class CAdminDlg : public CDialog
{
	DECLARE_DYNAMIC(CAdminDlg)

public:
	CAdminDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAdminDlg();

// Dialog Data
	enum { IDD = IDD_ADMIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedAdminChange();
	afx_msg void OnBnClickedAdminAddnew();
	afx_msg void OnBnClickedAdminDel();
};
