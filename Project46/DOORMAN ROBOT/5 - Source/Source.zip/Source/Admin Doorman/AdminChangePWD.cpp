// AdminChangePWD.cpp : implementation file
//

#include "stdafx.h"
#include "StillCap.h"
#include "AdminChangePWD.h"


// CAdminChangePWD dialog

IMPLEMENT_DYNAMIC(CAdminChangePWD, CDialog)
CAdminChangePWD::CAdminChangePWD(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminChangePWD::IDD, pParent)
	, m_AdminName(_T(""))
	, m_OldPWD(_T(""))
	, m_NewPWD(_T(""))
{
}

CAdminChangePWD::~CAdminChangePWD()
{
}

void CAdminChangePWD::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_AdminName);
	DDX_Text(pDX, IDC_EDIT2, m_OldPWD);
	DDX_Text(pDX, IDC_EDIT3, m_NewPWD);
	DDX_Text(pDX, IDC_EDIT4, m_ConfirmPWD);
}


BEGIN_MESSAGE_MAP(CAdminChangePWD, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// CAdminChangePWD message handlers

void CAdminChangePWD::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString stm;
	char filter[40]="";
	char endQ[2]="'";

	CadminDB rpAdmin( NULL );
    strncpy(filter,"name= '",10);
	strncat(filter,m_AdminName,strlen(m_AdminName));
	strncat(filter,endQ,strlen(endQ));
	rpAdmin.m_strFilter = filter;
	rpAdmin.Open(CadminDB::snapshot,"Admin");
	//��������㹰ҹ������
	if ((m_AdminName == (CString) rpAdmin.m_name)&& (m_OldPWD == (CString) rpAdmin.m_pwd))
	{
		if (m_NewPWD == m_ConfirmPWD)
		{
			rpAdmin.Edit();
			//Ẻ����� Text
			this->GetDlgItemText(IDC_EDIT3,stm);
			rpAdmin.m_pwd = stm;

			rpAdmin.Update();
			if(rpAdmin.CanUpdate())
				AfxMessageBox("����¹���ʼ�ҹ���º����",MB_OK |MB_ICONEXCLAMATION);
			rpAdmin.Requery();
			rpAdmin.Close();
			Sleep(1000); //Delay Time
			return;
		}
		else
		{
			AfxMessageBox("���ʼ�ҹ���ç�ѹ ��سҡ�͡�����ա����",MB_OK |MB_ICONEXCLAMATION);
			return;
		}

	}
	else
	{
		AfxMessageBox("Username ���� Password ������١��ͧ",MB_OK |MB_ICONEXCLAMATION);
		return;
	}

}

