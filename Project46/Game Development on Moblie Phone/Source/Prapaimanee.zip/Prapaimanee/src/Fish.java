import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;



public class Fish
{

public Image[] Fi = new Image[12];

public Fish ()
	{


		try
			{
			
		Fi[0]=Image.createImage("/f1.png");
		Fi[1]=Image.createImage("/f2.png");
		Fi[2]=Image.createImage("/f3.png");
		Fi[3]=Image.createImage("/f4.png");
		Fi[4]=Image.createImage("/f5.png");
		Fi[5]=Image.createImage("/f6.png");
		Fi[6]=Image.createImage("/f7.png");
		Fi[7]=Image.createImage("/f8.png");
		Fi[8]=Image.createImage("/f9.png");
		Fi[9]=Image.createImage("/f10.png");
		Fi[10]=Image.createImage("/f11.png");
		Fi[11]=Image.createImage("/f12.png");
		
			}
		catch (java.io.IOException e){}
	}

public void draw(Graphics g,int hun,int cb,int cf,int cl,int cr)
	{
		
		switch(hun)
		{

		case 0 : { 
			
			if(cb==0){
			g.drawImage(Fi[0],79,67,0);
			}
			else
			{
			g.drawImage(Fi[2],79,67,0);
			}
			break;
			}
		case 1 : { 	
			if(cf==0){
			g.drawImage(Fi[6],79,67,0);
			}else
			{
			g.drawImage(Fi[8],79,67,0);
			}
			break;}
		case 2 : { 
			if(cl==0){
			g.drawImage(Fi[9],79,67,0);
			}
			else
			{
			g.drawImage(Fi[11],79,67,0);
			}
			break;}

		case 3 :  { 
			if(cr==0){
			g.drawImage(Fi[3],79,67,0);
			}
			else
			{
			g.drawImage(Fi[5],79,67,0);
			}
			break;}
	
	}



	}


};