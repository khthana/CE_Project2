//-----------------------------------------------------class monsters--------------------------------
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;

public class Randommon
	{
		
		
		public int[] xm2,ym2,xm3,ym3,xm4,ym4,xm5,ym5,xm6,ym6;
		private int temp_random;
		int[] max_mon;
		
		public Randommon()
		{
			max_mon = new int[7];
			max_mon[2] = 100;
			max_mon[3] = 100;
			max_mon[4] = 100;
			max_mon[5] = 100;
			max_mon[6] = 20;
			
			xm2 = new int[max_mon[2]];
			ym2 = new int[max_mon[2]];
			xm3  = new int[max_mon[3]];
			ym3 = new int[max_mon[3]];
			xm4  = new int[max_mon[4]];
			ym4 = new int[max_mon[4]];
			xm5  = new int[max_mon[5]];
			ym5 = new int[max_mon[5]];
			xm6  = new int[max_mon[6]];
			ym6 = new int[max_mon[6]];
			
		}
		
		
	}
//------------------------------------------------------end monsters-----------------------------------