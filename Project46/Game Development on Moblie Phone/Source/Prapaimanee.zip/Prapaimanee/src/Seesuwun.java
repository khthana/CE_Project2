import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;



public class Seesuwun
{

public Image[] Fai = new Image[12];

public Seesuwun ()
	{


		try
			{
			
		Fai[0]=Image.createImage("/s1.png");
		Fai[1]=Image.createImage("/s2.png");
		Fai[2]=Image.createImage("/s3.png");
		Fai[3]=Image.createImage("/s4.png");
		Fai[4]=Image.createImage("/s5.png");
		Fai[5]=Image.createImage("/s6.png");
		Fai[6]=Image.createImage("/s7.png");
		Fai[7]=Image.createImage("/s8.png");
		Fai[8]=Image.createImage("/s9.png");
		Fai[9]=Image.createImage("/s10.png");
		Fai[10]=Image.createImage("/s11.png");
		Fai[11]=Image.createImage("/s12.png");
		
			}
		catch (java.io.IOException e){}
	}

public void draw(Graphics g,int hun,int cb,int cf,int cl,int cr)
	{
		
		switch(hun)
		{

		case 0 : { 
			
			if(cb==0){
			g.drawImage(Fai[0],79,67,0);
			}
			else
			{
			g.drawImage(Fai[2],79,67,0);
			}
			break;
			}
		case 1 : { 	
			if(cf==0){
			g.drawImage(Fai[6],79,67,0);
			}else
			{
			g.drawImage(Fai[8],79,67,0);
			}
			break;}
		case 2 : { 
			if(cl==0){
			g.drawImage(Fai[9],79,67,0);
			}
			else
			{
			g.drawImage(Fai[11],79,67,0);
			}
			break;}

		case 3 :  { 
			if(cr==0){
			g.drawImage(Fai[3],79,67,0);
			}
			else
			{
			g.drawImage(Fai[5],79,67,0);
			}
			break;}
	
	}



	}


};