import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.lang.*;
import java.util.*;
import java.io.*;


public class Prapaimanee extends MIDlet implements CommandListener,ItemStateListener
	{
		private Form onescreen,threescreen,tenscreen,fourscreen,fivescreen,sixscreen,twoscreen,ninescreen,inscreen;
		private Display display;
		private Command exitCommand = new Command("exit",Command.EXIT,3);
		private Command startCommand = new Command("Start",Command.OK,1);
		private Command backCommand = new Command("Back",Command.BACK,1);
		private Command saveCommand = new Command("Save",Command.BACK,1);
		private Command newCommand = new Command("New Game",Command.OK,2);
		private Command okCommand = new Command("Ok",Command.OK,1);
		private TextField createid,createpass,recreatepass,namefield,conid,conpass  = null;
		private ChoiceGroup start_choice,charecter_choice = null;
		private String[] start_str = {"new game","continue","Instruction"};
		private static String addidurl="http://161.246.6.95/project/newid.asp?id=";
		public static String addnametypeurl="http://161.246.6.95/project/newnametype.asp?id=";
		public static String chkconurl="http://161.246.6.95/project/chkcon.asp?id=";

		public String realid,temp_string;
		MyCanvas canvas;
		public int human_special,inti,str,dex,agi,temp_human_hp,max_human_hp,temp_red,temp_white,human_attack,money,job,level,exp;
		public String name;
		public Battle battle;
		int Char=0;//-----------------index apaimanee=0,seesuwun=1,kaewkaesa=2,fish=3
	
	
		public  Prapaimanee()
		{
				
			createone();
			createtwo();	
			display = Display.getDisplay(this);
	//**********************************		
			inti = 2;
			str = 2;
			dex = 2;
			agi =3;	
		/*
			human_special = 700;
			job = 2;
			money =5000;
			inti = 2;
			str = 2;
			dex = 2;
			agi =40;
			exp = 90000;
			temp_human_hp = 9999;
			max_human_hp = 9999;
			human_attack = 300;
			temp_red = 99;
			temp_white = 99;
			name = "hutup";
			level=98;
			*/
	//**********************************
	battle = new Battle(this);
	canvas=new MyCanvas(this,battle);	
	canvas.addCommand(saveCommand);
	canvas.addCommand(newCommand);
	canvas.setCommandListener(this);
		}
		public void startApp() throws MIDletStateChangeException
		{
			display.setCurrent(onescreen);
			System.out.println("start na");
		}
		public void pauseApp()
		{}
		public void destroyApp(boolean unconditional) 
		{
			onescreen = null;
			exitCommand = null;
			okCommand= null;
			backCommand=null ;
			display = null;
		}
		public void commandAction(Command c,Displayable a)
		{
			
			if(a==canvas)
			{
				if(c==saveCommand)
				{
					if(canvas.m !=7 && canvas.m !=8 && canvas.m !=9 && battle.monhere == false)
					{
						addnametypeurl = "http://161.246.6.95/project/newnametype.asp?id="+realid+"&char="+Char+"&name="+ name+"&level="+level+"&human_hp="+temp_human_hp+"&exp="+exp+"&red="+temp_red+"&white="+temp_white+"&m="+canvas.m+"&l="+canvas.l+"&k="+canvas.k+"&money="+money+"&job="+job;
						
						addnametype();
						
					}
				}
				else if(c == newCommand)
				{
					System.out.print("yeah");
					//canvas.gameover = false;
					
					//battle.monhere = false;
					if(canvas.m !=7 && canvas.m !=8 && canvas.m !=9 && battle.monhere == false)
					{
						display.setCurrent(onescreen);
						battle.rdy = false;
						battle.xbox = 0;
						battle.warn_time = 0;
						battle.mon_attack_time = 0;
						battle.temp_mondelay = 0;
						battle.temp_monhp = -10000;
						canvas.gameover = false;
						canvas.startpic1 = 0;
						addnametypeurl = "http://161.246.6.95/project/newnametype.asp?id="+realid+"&char="+Char+"&name="+ name+"&level="+level+"&human_hp="+temp_human_hp+"&exp="+exp+"&red="+temp_red+"&white="+temp_white+"&m="+canvas.m+"&l="+canvas.l+"&k="+canvas.k+"&money="+money+"&job="+job;
						addnametype();
						//system.out.println("save");
					}
				}	
			}
			if(c== exitCommand)
			{
				destroyApp(true);
				notifyDestroyed();
			}
			if( c == backCommand )
			{
				if (a == twoscreen)
				{
					display.setCurrent(onescreen);
				}
				else if (a == threescreen)
				{
					display.setCurrent(twoscreen);
				}
				else if (a == tenscreen)
				{
					display.setCurrent(threescreen);
				}
				else if (a == sixscreen)
				{
					display.setCurrent(twoscreen);
				}
				else if (a == ninescreen)
				{
					display.setCurrent(twoscreen);
				}else if (a == inscreen)
				{
					display.setCurrent(twoscreen);
				}
			}
			if (c == startCommand)
			{
				createtwo();
				display.setCurrent(twoscreen);
			}
			if ((c == okCommand))
			{
				if (a == twoscreen)
				{
					if (start_choice.getSelectedIndex()==0)
					{
						createthree();
						display.setCurrent(threescreen);
					}
					else if (start_choice.getSelectedIndex() == 1)
					{
						createsix();
						display.setCurrent(sixscreen);
					}
					else if (start_choice.getSelectedIndex() == 2)
					{
						createin();
						display.setCurrent(inscreen);
					}
				}
				else if (a == threescreen)
				{
					if (createpass.getString().equals("") || recreatepass.getString().equals("") || createid.getString().equals(""))
					{
						createten();
						display.setCurrent(tenscreen);
					}
					else if (createpass.getString().equals(recreatepass.getString()))
					{
						if (!(chkid (createid.getString(),createpass.getString()).equals("")))
						{
							createfour();
							display.setCurrent(fourscreen);
						}
						else
						{
							createten();
							display.setCurrent(tenscreen);
						}
					}
					else
					{
						createten();
						display.setCurrent(tenscreen);
					}
				}
				else if (a == fourscreen)
				{
					Char = charecter_choice.getSelectedIndex();
					addnametypeurl = addnametypeurl + realid + "&char=" + charecter_choice.getSelectedIndex() + "&name=";
					createfive();
					display.setCurrent(fivescreen);
				}
				else if (a == sixscreen)
				{
					if (conpass.getString().equals("") || conid.getString().equals(""))
					{
					}
					else
					{
						if (!(chkcon (conid.getString(),conpass.getString()).equals("")))
						{
							if (canvas.startpic1==0)
							{
								battle.createpic1();
								canvas.startpic1=1;
							}
							if (canvas.startpic2==0)
							{	
									battle.createpic2();
									canvas.startpic2=1;
							}
							createnine();
							display.setCurrent(ninescreen);
						}
						else
						{
							//createten();
							//display.setCurrent(tenscreen);
						}
					}
					
				}
				else if (a == fivescreen)
				{
					if (namefield.getString() == "")
					{
						
					}
					else
					{
						name = namefield.getString();
						addnametypeurl = addnametypeurl + namefield.getString()+"&level=1&human_hp=199&exp=0&red=1&white=1&m=0&l=3&k=3&money=0&job=1";
						addnametype();
						job = 1;
						money =0;
						exp = 0;
						temp_human_hp = 199;
						max_human_hp = 199;
						canvas.m = 0;
						canvas.k = 3;
						canvas.l = 3;
						agi = 3;
						if (Char == 1)
						{
							human_attack = 55;
						}
						else
						{
							human_attack = 45;
						}
						
						temp_red = 1;
						temp_white = 1;
						level=1;
						createnine();
						display.setCurrent(ninescreen);
						
					}
				}
				else if(a == ninescreen)
				{
					display.setCurrent(canvas);
				}
			}

			
			
		}
		public void itemStateChanged(Item item)
		{
			
		}
		public void addokback(Form a)
		{
			a.addCommand(okCommand);
			a.addCommand(backCommand);
			a.setCommandListener(this);
		}
		public void addstartexit(Form a)
		{
			a.addCommand(startCommand);
			a.addCommand(exitCommand);
			a.setCommandListener(this);
		}
		public void createone()
		{
			onescreen = new Form("Let's go");
		//	onescreen.append(new StringItem("","     Prapaimanee Online"));
			//crate image
			Image img = null;
			try
				{
						img = Image.createImage("/title.png");
				}
			catch (Exception e){}
			onescreen.append(new ImageItem("",img,ImageItem.LAYOUT_CENTER+ImageItem.LAYOUT_NEWLINE_BEFORE+ImageItem.LAYOUT_NEWLINE_AFTER,null));
			addstartexit(onescreen);
		}
		public void createin()
		{
			inscreen = new Form("Instruction");
			inscreen.append(new StringItem("","     Detail Use Key\n"));
			inscreen.append(new StringItem("","     press 1:attack \n"));
			inscreen.append(new StringItem("","     press 2:Use Potion \n"));
			inscreen.append(new StringItem("","     press 3:Use Skill Point(job 2) \n"));
			inscreen.append(new StringItem("","     press 4:Escape \n"));
			inscreen.append(new StringItem("","     press 5:Talk npc \n"));

			inscreen.addCommand(backCommand);
			inscreen.setCommandListener(this);
			
		}
		public void createtwo()
		{
			twoscreen = new Form("Select");
			String[] start_str = {"New game","Continue","Instruction"};
			start_choice = new ChoiceGroup("",Choice.EXCLUSIVE,start_str,null);
			twoscreen.append(start_choice);
			addokback(twoscreen);
		}
		public void createthree()
		{
			threescreen = new Form("Create ID");
			createid = new TextField("ID","IDna",20,TextField.ANY);
			createpass = new TextField("Password","",20,TextField.PASSWORD);
			recreatepass = new TextField("Repassword ","",20,TextField.PASSWORD);
			threescreen.append(createid);
			threescreen.append(createpass);
			threescreen.append(recreatepass);
			addokback(threescreen);
			threescreen.setCommandListener(this);
		}
		public void createten()
		{
			tenscreen = new Form("Password Invalid");
			tenscreen.addCommand(backCommand);
			tenscreen.setCommandListener(this);
		}
		public void createfour()
		{
			fourscreen = new Form("Choose yourself");
			String[] charecter = {"Apaimanee","Seesuwan","Kaewkaesa","Mermaid"};
			charecter_choice = new ChoiceGroup("",Choice.EXCLUSIVE,charecter,null);
			fourscreen.append(charecter_choice);
			fourscreen.addCommand(okCommand);
			fourscreen.setCommandListener(this);
		}
		public void createfive()
		{
			fivescreen = new Form("Type Your Name");
			namefield = new TextField("NAME","",5,TextField.ANY);
			fivescreen.append(namefield);
			fivescreen.addCommand(okCommand);
			fivescreen.setCommandListener(this);
		}
		public void createsix()
		{
			sixscreen = new Form("Insert Password");
			conid = new TextField("ID","IDna",20,TextField.ANY);
			conpass = new TextField("Password","",20,TextField.PASSWORD);
			sixscreen.append(conid);
			sixscreen.append(conpass);
			addokback(sixscreen);
		}
		public void createnine()
		{
			if(Char == 0)
			{
				temp_string = "Apaimanee";
			}
			else if(Char == 1)
			{
				temp_string = "Seesuwun";
			}
			else if(Char == 2)
			{
				temp_string = "Kaewkaesa";
			}
			else if(Char == 3)
			{
				temp_string = "Mermaid";
			}

			ninescreen = new Form("Status");
			ninescreen.append(new StringItem("Name : ",name));
			ninescreen.append(new StringItem("Level : ",level+" "));
			ninescreen.append(new StringItem("Job : ",temp_string+" "+job));
			ninescreen.append(new StringItem("Money : ",money+" baht"));
			ninescreen.addCommand(okCommand);
			ninescreen.setCommandListener(this);
		}
		public String chkid(String id,String pass)
		{
			String urlstring = addidurl+id+"&pass="+pass;
			//system.out.println(urlstring);
			String resultstring="";
			try
			{
				resultstring=sendGetRequest(urlstring);
			}
			catch(IOException e)
			{
				//do nothing;
			}
			//--------------------
			if(!resultstring.equals(""))
			{
				realid = resultstring;
			}
			return resultstring;
		}
		public String sendGetRequest(String urlstring) throws IOException
		{
			HttpConnection hc=null;
			DataInputStream dis=null;
	
			String message="";
			try
			{
				hc=(HttpConnection) Connector.open(urlstring);
				dis=new DataInputStream(hc.openInputStream());		

				int ch;
				while((ch=dis.read())!=-1)
				{
					message=message+(char)ch;
				}
			}
			finally
			{
				if(hc!=null) hc.close();
				if(dis!=null) dis.close();
			}
		
			return message ;
		}
		public void addnametype() 
		{
			
			String resultstring="";
			try
			{
				resultstring=sendGetRequest(addnametypeurl);
			}
			catch(IOException e)
			{
				//resultstring="no";
			}
		}
		public String chkcon(String id,String pass)
		{
			String urlstring = chkconurl+id+"&pass="+pass;
			System.out.println(urlstring);
			String resultstring="";
			try
			{
				resultstring=sendGetchkcon(urlstring);
			}
			catch(IOException e)
			{
				//do nothing;
			}
			//--------------------
			if(!resultstring.equals(""))
			{
				realid = resultstring;
			}
			return resultstring;
		}
		public String sendGetchkcon(String urlstring) throws IOException
		{
			HttpConnection hc=null;
			DataInputStream dis=null;
			int i = 0;
			String message="";
			try
			{
				hc=(HttpConnection) Connector.open(urlstring);
				dis=new DataInputStream(hc.openInputStream());		

				int ch;
				while((ch=dis.read())!=-1)
				{
					if (ch != 32)
					{
						message=message+(char)ch;
					}
					else
					{
						i = i+1;
						if(i ==1)
						{
							name = message;
							message = "";
						}
						else if(i==2)
						{
							level = Integer.parseInt(message);
							message = "";
						}
						else if(i==3)
						{
							canvas.m = Integer.parseInt(message);
							message = "";
						}
						else if(i==4)
						{
							canvas.l = Integer.parseInt(message);
							message = "";
						}
						else if(i==5)
						{
							canvas.k = Integer.parseInt(message);
							message = "";
						}
						else if(i==6)
						{
							temp_red = Integer.parseInt(message);
							message = "";
						}
						else if(i==7)
						{
							temp_white = Integer.parseInt(message);
							message = "";
						}
						else if(i==8)
						{
							exp = Integer.parseInt(message);
							message = "";
						}
						else if(i==9)
						{
							temp_human_hp = Integer.parseInt(message);
							message = "";
						}
						else if(i==10)
						{
							money = Integer.parseInt(message);
							message = "";
						}
						else if(i==11)
						{
							Char = Integer.parseInt(message);
							message = "";
						}
						else if(i==12)
						{
							job = Integer.parseInt(message);
							message = "";
						}
						else if(i==13)
						{
							realid = message;
							message = "";
						}
					}
					
					
				}
			}
			finally
			{
				if(hc!=null) hc.close();
				if(dis!=null) dis.close();
			}
			if (Char ==0)
			{
				human_special = (level*30)+250;
			}
			else
			{
				human_special = (level*20)+250;
			}
			max_human_hp = (level*level)+198;
			if( Char == 1 )
			{
				human_attack = (15*level)+40;
			}
			else
			{
				human_attack = (5*level)+40;
			}
			 if(canvas.m == 2)
			{
				battle.random_monster(2,canvas.xmap2,canvas.ymap2);
			}
			else if(canvas.m == 3)
			{
				battle.random_monster(3,canvas.xmap3,canvas.ymap3);
			}
			else if(canvas.m == 4)
			{
				battle.random_monster(4,canvas.xmap4,canvas.ymap4);
			}
			else if(canvas.m == 5)
			{
				battle.random_monster(5,canvas.xmap5,canvas.ymap5);
			}
			else if(canvas.m == 6)
			{
				battle.random_monster(6,canvas.xmap6,canvas.ymap6);
			}

			
			agi = level;	
			
			
			
			return message ;
		}
		
}







class MyCanvas extends Canvas
{
//----------------------------talk
boolean gameover=false;
int tboss=0;
boolean ttboss=false;
int intalk=0;
int stalk=0;
int talk=0;
int talknpc=0;
private Image[] arraytalk = new Image[22];
int in=1;
int temp=0;//----------------1_white,2_red
int startpic1=0;
int startpic2=0;
boolean batt;
String temp_string;

//-------------------------------end talk
//-------------------------define class
Prapaimanee prapaimanee;
Apaimanee apaimanee;
Fish fish;
Seesuwun seesuwun;
Kaewkaesa kaewkaesa;
//-------------------------end define class
//*****************************
Battle battle;
//*****************************
//----------------------------timer
private Timer tm;
private TestTimerTask tt;
//----------------------------end timer

int m=0;//--------------------index map 0,1,2,3,4,5
int w,h;
int i,j,k,l,hun=1,cf=0,cr=0,cl=0,cb=0,xmapna,ymapna,button;
//-------------------------------------------------map0
public Image[] arrayP0 = new Image[12];
int xmap0[]={0,1,2,5,6,0,1,2,5,6};
int ymap0[]={1,1,1,0,0,2,2,2,2,2};
int m0wx3=3,m0wy3=6;

//--------------------------------------------------end map0
//---------------------------------- map1
int xmap1[]={0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,1,1,5,5,17,17,13,13,0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,10,11,12,13,14,15,16,17,18};
int ymap1[]={0,1,2,0,0,0,0,0,0,0,0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,3,4,3,4,3 ,4 ,3 ,4 ,9,9,9,9,9,9,9,9,9,9 ,9 ,9 ,9 ,9 , 9, 9, 9, 9,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10};
int m1wx1=9,m1wy1=1;
int m1wx3=9,m1wy3=14;
private Image arrayP ;
private Image[] arrayP1 = new Image[17];

//---------------------------------------------------end map1
//---------------------------------- map2 
int xmap2[]={2,3,4,5,6,7,8,9,10,2,3,4,5,6,7,8,9,10,2,3,4,5,6,7,8,9,10,2,3,2,3,2,3,2,3,2,3,14,15,16,17,18,19,20,21,22,23,24,25,26,20,21,22,14,15,16,17,18,19,20,21,15,16,17,18,19,20,21,16,17,18,19,20,21,17,18,19,20,21,18,19,20,21,25,26,25,26,25,26,13,14,15,13,14,15,18,19,20,21,22,23,24,25,26,18,19,20,21,1 , 2, 1, 2, 1, 2, 1, 2,2 ,3 ,2 ,3 ,2 ,3 ,2 ,3 ,4 ,5 ,4 ,5 ,4 ,5 ,27,28,28,27,28,27,28,27,28,27 };
int ymap2[]={0,0,0,0,0,0,0,0,0 ,1,1,1,1,1,1,1,1,1 ,2,2,2,2,2,2,2,2,2 ,3,3,4,4,5,5,6,6,7,7,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,9 ,8 ,8 ,8 ,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,22,22,22,22,22,22,23,23,23,23,23,24,24,24,24,3 ,3 ,4 , 4,5 ,5 ,11,11,11,12,12,12,26,26,26,26,26,26,26,26,26,27,27,27,27,16,16,17,17,18,18,19,19,21,21,22,22,23,23,24,24,25,25,26,26,27,27,18,18,19,19,20,20,21,21,22,22};
int m2wx1=15,m2wy1=0;
int m2wx2=29,m2wy2=12;
int m2wx4=0,m2wy4=14;
int m2wx3=11,m2wy3=29;
private Image[] arrayP2 = new Image[16];


//---------------------------------------------------end map2
//---------------------------------- map3
int xmap3[]={0,1,2,3,4,29,28,27,26,25,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10,11,12,13,14,15,16,17,18,19,20,21,23,22,24,25,26,27,28,29,9,10,11,12,13,14,15,16,17,18,19,9 ,10,11,12,13,14,15,16,17,18,19};
int ymap3[]={7,7,7,7,7,7 ,7 ,7 ,7 ,7 ,6,5,4,3,2,2 ,2 ,2 ,2 ,2 ,2 ,2 ,2 ,2 ,2 ,3 ,3 ,4 ,4 ,5 ,6 ,6 ,13,13,13,13,13,14,15,16,17,17,17,17,17,17,17,17,17,17,17,17,16,16,15,15,14,13,13,13,13,13,9, 9, 9,9 ,9 ,9 , 9,9 ,9 ,9 ,9 ,10,10,10,10,10,10,10,10,10,10,10};
int m3wx4=0,m3wy4=10;
int m3wx2=29,m3wy2=10;


//---------------------------------------------------end map3

//---------------------------------- map4
int xmap4[]={4,5,6,7,8,9,10,11,10,9,8,7,8,9,10,10,11,10,9 ,8 ,7 ,6 ,5 , 4,3 ,3 ,2 ,1 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,10,11,12,13,14,15,16,17,18,19,20,21,22,22,21,21,20,19,18,17,16,17,18,19,20,21,22,23,24,25,26,27,28,29,19,20,21,18,18,18,22,22,22,19,20,21,19,19};
int ymap4[]={0,1,1,2,2,3,4 ,4 ,5 ,6,7,8,9,9,9 ,10,11,11,11,11,10,10,10,10,11,12,13,14,15,16,17,17,17,17,18,18,19,19,19,19,19,19,18,18,18,18,18,18,18,17,16,15,14,13,13,12,12,11,11,11,11,11,12,12,11,11,11,10,10,10,10,1 ,1 ,1 ,2 ,3 ,4 ,2 ,3 ,4 ,5 , 5,5 ,15,16};
int m4wx2=29,m4wy2=5;
private Image[] arrayP4 = new Image[16];
//---------------------------------------------------end map4

//---------------------------------- map5
int xmap5[]={7,15,3,16,9,12,1,7,11,3,13,2,14,6,13,13,16,2,5,16,1 ,6 ,8 ,7 ,11,16,6 ,17,6 ,12,18,18};
int ymap5[]={0,0 ,1,1 ,2,2 ,4,4,4 ,5,5 ,6,6 ,7,7 ,8 ,8 ,9,9,10,11,12,13,14,14,15,16,16,18,18,0 ,1 };
int m5wx4=0,m5wy4=14;
private Image[] arrayP5 = new Image[10];

//---------------------------------------------------end map5

//---------------------------------- map6
int xmap6[]={};
int ymap6[]={};
int m6wx1=2,m6wy1=0;
int m6wx3=2,m6wy3=29;
private Image[] arrayP6 = new Image[8];

//---------------------------------------------------end map6

//---------------------------------- map7
int xmap7[]={3,3};
int ymap7[]={4,5};
int m7wx1=9,m7wy1=1;
private Image[] arrayP7 = new Image[12];

//---------------------------------------------------end map7
MapGame map;
public MyCanvas(Prapaimanee prapaimanee,Battle battle)
{
map=new MapGame();
this.prapaimanee=prapaimanee;
this.battle = battle;
//-----------------------------------------------apaimanee
//if(prapaimanee.Char==0){
apaimanee = new Apaimanee();
//}
//-----------------------------------------------end apaimanee
//-----------------------------------------------seesueun
//if(prapaimanee.Char==1){
seesuwun = new Seesuwun();
//}
//-----------------------------------------------end Seesuwun
//-----------------------------------------------kaewkaesa
//if(prapaimanee.Char==2){
kaewkaesa = new Kaewkaesa();
//}
//-----------------------------------------------end kaewkaesa


//-----------------------------------------------Fish
//if(prapaimanee.Char==3){
fish = new Fish();
//}
//-----------------------------------------------end fish

//------------------------------------------------timer
tm=new Timer();
tt=new TestTimerTask();
//-------------------------------------------------end timer

w=getWidth();
h=getHeight();
l=3;
k=3;
//********************************


tm.schedule(tt,150,150);
//********************************
try
{
	//------------------------------------------map0
arrayP0[0]=Image.createImage("/black.png");
arrayP0[1]=Image.createImage("/1_1.png");
arrayP0[2]=Image.createImage("/1_2.png");
arrayP0[3]=Image.createImage("/1_3.png");
arrayP0[4]=Image.createImage("/1_4.png");
arrayP0[5]=Image.createImage("/1_5.png");
arrayP0[6]=Image.createImage("/1_6.png");
arrayP0[7]=Image.createImage("/1_7.png");
arrayP0[8]=Image.createImage("/not.png");
arrayP0[9]=Image.createImage("/npc.png");
arrayP0[10] = Image.createImage("/money.png");
arrayP0[11] = Image.createImage("/level.png");

	//-----------------------------------------end map0
	//------------------------------------------map1
arrayP1[0]=Image.createImage("/black.png");
arrayP1[1]=Image.createImage("/2_1.png");
arrayP1[2]=Image.createImage("/2_2.png");
arrayP1[3]=Image.createImage("/2_3.png");
arrayP1[4]=Image.createImage("/2_4.png");
arrayP1[5]=Image.createImage("/2_5.png");
arrayP1[6]=Image.createImage("/2_6.png");
arrayP1[7]=Image.createImage("/2_7.png");
arrayP1[8]=Image.createImage("/2_8.png");
arrayP1[9]=Image.createImage("/2_9.png");
arrayP1[10]=Image.createImage("/2_10.png");
arrayP1[11]=Image.createImage("/2_11.png");
arrayP1[12]=Image.createImage("/2_12.png");
arrayP1[13]=Image.createImage("/2_13.png");
arrayP1[14]=Image.createImage("/2_14.png");
arrayP1[15]=Image.createImage("/j11.png");
arrayP1[16]=Image.createImage("/j12.png");
	//-----------------------------------------end map1
		//------------------------------------------map2
arrayP2[0]=Image.createImage("/black.png");
arrayP2[1]=Image.createImage("/2_8.png");
arrayP2[2]=Image.createImage("/3_2.png");
arrayP2[3]=Image.createImage("/2_9.png");
arrayP2[4]=Image.createImage("/3_4.png");
arrayP2[5]=Image.createImage("/3_5.png");
arrayP2[6]=Image.createImage("/3_6.png");
arrayP2[7]=Image.createImage("/3_7.png");
arrayP2[8]=Image.createImage("/3_8.png");
arrayP2[9]=Image.createImage("/3_9.png");
arrayP2[10]=Image.createImage("/3_10.png");
arrayP2[11]=Image.createImage("/3_11.png");
arrayP2[12]=Image.createImage("/3_12.png");
arrayP2[13]=Image.createImage("/3_13.png");
arrayP2[14]=Image.createImage("/2_14.png");
arrayP2[15]=Image.createImage("/3_15.png");

	//-----------------------------------------end map2
/*			//------------------------------------------map3
arrayP3[0]=Image.createImage("/black.png");
arrayP3[1]=Image.createImage("/2_1.png");
arrayP3[2]=Image.createImage("/2_2.png");
arrayP3[3]=Image.createImage("/2_3.png");
arrayP3[4]=Image.createImage("/2_4.png");
arrayP3[5]=Image.createImage("/2_5.png");
arrayP3[6]=Image.createImage("/2_6.png");
arrayP3[7]=Image.createImage("/2_7.png");
arrayP3[8]=Image.createImage("/2_8.png");
arrayP3[9]=Image.createImage("/2_9.png");
arrayP3[10]=Image.createImage("/2_10.png");
arrayP3[11]=Image.createImage("/2_11.png");
arrayp3[12]=Image.createImage("/2_12.png");
arrayP3[13]=Image.createImage("/2_13.png");
*/

	//-----------------------------------------end map3
	//------------------------------------------map4
arrayP4[0]=Image.createImage("/black.png");
arrayP4[1]=Image.createImage("/3_4.png");
arrayP4[2]=Image.createImage("/4_2.png");
arrayP4[3]=Image.createImage("/4_3.png");
arrayP4[4]=Image.createImage("/4_4.png");
arrayP4[5]=Image.createImage("/4_5.png");
arrayP4[6]=Image.createImage("/4_6.png");
arrayP4[7]=Image.createImage("/4_7.png");
arrayP4[8]=Image.createImage("/4_8.png");
arrayP4[9]=Image.createImage("/4_9.png");
arrayP4[10]=Image.createImage("/4_10.png");
arrayP4[11]=Image.createImage("/4_11.png");
arrayP4[12]=Image.createImage("/4_12.png");
arrayP4[13]=Image.createImage("/3_15.png");
arrayP4[14]=Image.createImage("/j22.png");
arrayP4[15]=Image.createImage("/j21.png");
//-----------------------------------------end map4
//-----------------------------------------end map5
arrayP5[0]=Image.createImage("/black.png");
arrayP5[1]=Image.createImage("/5_1.png");
arrayP5[2]=Image.createImage("/5_2.png");
arrayP5[3]=Image.createImage("/5_3.png");
arrayP5[4]=Image.createImage("/5_4.png");
arrayP5[5]=Image.createImage("/5_5.png");
arrayP5[6]=Image.createImage("/5_6.png");
arrayP5[7]=Image.createImage("/5_7.png");
arrayP5[8]=Image.createImage("/j32.png");
arrayP5[9]=Image.createImage("/j31.png");
//-----------------------------------------end map5
//-----------------------------------------end map6
arrayP6[0]=Image.createImage("/black.png");
arrayP6[1]=Image.createImage("/6_1.png");
arrayP6[2]=Image.createImage("/6_2.png");
arrayP6[3]=Image.createImage("/6_3.png");
arrayP6[4]=Image.createImage("/6_4.png");
arrayP6[5]=Image.createImage("/6_5.png");
arrayP6[6]=Image.createImage("/6_6.png");
arrayP6[7]=Image.createImage("/6_7.png");

//-----------------------------------------end map6
//-----------------------------------------end map7
arrayP7[0]=Image.createImage("/6_2.png");
arrayP7[1]=Image.createImage("/7_1.png");
arrayP7[2]=Image.createImage("/7_2.png");
arrayP7[3]=Image.createImage("/7_3.png");
arrayP7[4]=Image.createImage("/7_4.png");
arrayP7[5]=Image.createImage("/7_5.png");
arrayP7[6]=Image.createImage("/7_6.png");
arrayP7[7]=Image.createImage("/7_7.png");
arrayP7[8]=Image.createImage("/7_8.png");
arrayP7[9]=Image.createImage("/7_9.png");
arrayP7[10]=Image.createImage("/boss1.png");
arrayP7[11]=Image.createImage("/boss2.png");


//-----------------------------------------end map7
//-------------------------------------------pic to talk
arraytalk[0]=Image.createImage("/b1.png");
arraytalk[1]=Image.createImage("/b2.png");
arraytalk[2]=Image.createImage("/b3.png");
arraytalk[3]=Image.createImage("/b4.png");
arraytalk[4]=Image.createImage("/b5.png");
arraytalk[5]=Image.createImage("/picnpc.png");
arraytalk[6]=Image.createImage("/j1_t1.png");
arraytalk[7]=Image.createImage("/j1_t2.png");
arraytalk[8]=Image.createImage("/j2_t1.png");
arraytalk[9]=Image.createImage("/j2_t2.png");
arraytalk[10]=Image.createImage("/j3_t1.png");
arraytalk[11]=Image.createImage("/j3_t2.png");
arraytalk[12]=Image.createImage("/picj1.png");
arraytalk[13]=Image.createImage("/picj2.png");
arraytalk[14]=Image.createImage("/picj3.png");
arraytalk[15]=Image.createImage("/picboss.png");
arraytalk[16]=Image.createImage("/b_t1.png");
arraytalk[17]=Image.createImage("/b_t2.png");
arraytalk[18]=Image.createImage("/b_t3.png");
arraytalk[19]=Image.createImage("/b_t4.png");
arraytalk[20]=Image.createImage("/gameover.png");
arraytalk[21]=Image.createImage("/win.png");



//------------------------------------------------end pic to talk

arrayP=Image.createImage("/status.png");
}
catch (java.io.IOException e){}
}

	
	//--------------------------------------------PAINT---------------------------------------------
	
	
	public void paint(Graphics g)
	{
if (gameover==false)
{


//**********************************
//**********************************

	if((m!=0)&&(m!=1)){
	battle.monhere = battle.chkmonster(m,k,l);
	batt=battle.monhere;
	}
	if (batt==true)
	{

		battle.drawBattle(g);
	}


//***********************************
//***********************************
	else
	{
		//-----------------------------------------------darw map
	if(m==0){
	DrawMap0(g);
	if((l==3)&&(k==1)&&(in==1))
		{talk=1;in=0;}else
	if((l!=3)||(k!=1)){talk=0;in=1;}
	}else if(m==1){
		DrawMap1(g);
		if (startpic1==0)
				{
					battle.createpic1();
					startpic1=1;
				}
		if((l==2)&&(k==1)&&(in==1))
		{talk=2;in=0;}else
		if((l!=2)||(k!=1)){talk=0;in=1;}
		}else if(m==2){
			DrawMap2(g);
			
			}else if(m==3){
				DrawMap3(g);
				}else if(m==4){
					DrawMap4(g);
					if((l==16)&&(k==18)&&(in==1))
						{talk=3;in=0;}else
					if((l!=16)||(k!=18)){talk=0;in=1;}
					}else if(m==5){
						DrawMap5(g);
						if((l==2)&&(k==18)&&(in==1))
						{talk=4;in=0;}else
						if((l!=2)||(k!=18)){talk=0;in=1;}
						}else if(m==6){
							DrawMap6(g);
							}else if(m==7){
								DrawMap7(g);
								} 


		
		g.drawImage(arrayP0[10],113,126,0);
		g.setColor(0,74,128);
		g.drawString(""+this.prapaimanee.money,132,130,0);

		g.drawImage(arrayP0[11],0,30,0);
		g.setColor(0,0,175);
		g.drawString(prapaimanee.level+"",40,33,0);

//-----------------------------------------------end darw map
		//-----------------------------------------------darw character
		if (m!=9)
		{
	
				if (prapaimanee.Char==0)
				{
						apaimanee.draw(g,hun,cb,cf,cl,cr);
				}else
				if (prapaimanee.Char==1)
				{
						seesuwun.draw(g,hun,cb,cf,cl,cr);
				}else
				if (prapaimanee.Char==2)
				{
						kaewkaesa.draw(g,hun,cb,cf,cl,cr);
				}else
				if (prapaimanee.Char==3)
				{
					fish.draw(g,hun,cb,cf,cl,cr);
				}


		}
		//-----------------------------------------------end darw character
		//--------------------------------------------------draw talk npc ----------------	
	if ((talk==1)&&(stalk==1))
	{
		
		if(talknpc==1)
			{
		g.drawImage(arraytalk[0],14,30,0);
			}else
			if(talknpc==2)
			{
			g.drawImage(arraytalk[1],14,30,0);
			}else
				if(talknpc==3)
				{
				g.drawImage(arraytalk[2],14,30,0);
				}else
					if(talknpc==4)
					{
					g.drawImage(arraytalk[3],14,30,0);
					}else
						if(talknpc==5)
						{
						g.drawImage(arraytalk[4],14,30,0);
						stalk=0;
						}
		g.drawImage(arraytalk[5],0,117,0);
	}

//--------------------------------------------------end draw talk npc ----------------	
//-----------------------------------------------draw talk father kaewkaesa-----
	if ((talk==2)&&(stalk==1))
	{
		if(talknpc==1)
		{
			g.drawImage(arraytalk[6],14,30,0);
		}else
		if(talknpc==2)
		{
			g.drawImage(arraytalk[7],14,30,0);
		}
		g.drawImage(arraytalk[12],0,117,0);
	}


//-----------------------------------------------end draw talk father kaewkaesa-----

//-----------------------------------------------draw talk oldman-----
	if ((talk==3)&&(stalk==1))
	{
		if(talknpc==1)
		{
			g.drawImage(arraytalk[8],14,30,0);
		}else
		if(talknpc==2)
		{
			g.drawImage(arraytalk[9],14,30,0);
		}
		g.drawImage(arraytalk[13],0,117,0);
	}


//-----------------------------------------------end draw talk oldman-----
//-----------------------------------------------draw talk man-----
	if ((talk==4)&&(stalk==1))
	{
		if(talknpc==1)
		{
			g.drawImage(arraytalk[10],14,30,0);
		}else
		if(talknpc==2)
		{
			g.drawImage(arraytalk[11],14,30,0);
		}
		g.drawImage(arraytalk[14],0,117,0);
	}

								if (m==8)
								{
									talkboss(g);
								}
//-----------------------------------------------end draw talk man-----
////system.out.println("potion "+prapaimanee.temp_white);
////system.out.println("skill point "+prapaimanee.temp_red);
////system.out.println("money "+prapaimanee.money);
////system.out.println("job "+prapaimanee.job);
////system.out.println("level "+prapaimanee.level);
////system.out.println(xmap5.length);
	}
	//*****************************
			battle.drawstatus_up(g);
		//	//system.out.println("m = "+m);
		//	//system.out.println("battle.monhere = "+battle.monhere);
		//	//system.out.println("realid ="+prapaimanee.realid);
	//*****************************
		if (prapaimanee.temp_human_hp <=0)
			{

				
				gameover=true;
				repaint();
			}
	
	}else {
			if (prapaimanee.temp_human_hp <=0)
			{
			
			g.drawImage(arraytalk[20],0,0,0);
			battle.rdy = false;
			battle.xbox = 0;
			battle.warn_time = 0;
			battle.mon_attack_time = 0;
			battle.temp_mondelay = 0;
			battle.temp_monhp = -10000;
			m = 0;
			k = 3;
			l = 3;
			prapaimanee.temp_human_hp = 100;
			batt = false;
			battle.monhere = false;
		
			
			
			prapaimanee.addnametypeurl = "http://161.246.6.95/project/newnametype.asp?id="+prapaimanee.realid+"&char="+prapaimanee.Char+"&name="+ prapaimanee.name+"&level="+prapaimanee.level+"&human_hp="+prapaimanee.temp_human_hp+"&exp="+prapaimanee.exp+"&red="+prapaimanee.temp_red+"&white="+prapaimanee.temp_white+"&m="+m+"&l="+l+"&k="+k+"&money="+prapaimanee.money+"&job="+prapaimanee.job;
			prapaimanee.addnametype();
			}else
				{	
						
						//m=0;
						g.drawImage(arraytalk[21],0,0,0);
			
				}



			}
	

	

}
	//------------------------------------------------end paint--------------------------------------

//------------------------------------------------receive EVENT----------------------------------------
public void keyPressed(int keyCode)
	{

if (gameover==false)
{


		//****************************
		if (battle.monhere == false)//------------------normal----------------------------------------
		{
		//****************************
					button=getGameAction(keyCode);
					if(stalk!=1)
	{
		if(m==0)
		{
		Map0Checkbutton(button);
	
		}else	
		if (m==1)
		{
		Map1Checkbutton(button);
		}else
		if (m==2)
		{
		Map2Checkbutton(button);
		}else
		if (m==3)
		{
		Map3Checkbutton(button);
		}else
		if (m==4)
		{
		Map4Checkbutton(button);
	
		}else
		if (m==5)
		{
		Map5Checkbutton(button);
		}else
		if (m==6)
		{
		Map6Checkbutton(button);
		}else
		if (m==7)
		{
		Map7Checkbutton(button);
		}
	}


	if (talk==1)//------------if talk=1
	{
	
	if (talknpc==0)
	{
		if(keyCode==53){talknpc=1;stalk=1;repaint();}
	}else
	if (talknpc==1)
	{
		if(keyCode==49){talknpc=2;repaint();}
	}else
	if (talknpc==2)
	{
		if(keyCode==49){temp=1;talknpc=3;repaint();}
		if(keyCode==50){temp=2;talknpc=3;repaint();}
		if(keyCode==51){talknpc=5;repaint();}
	}else
	if (talknpc==3)
	{
	  if (prapaimanee.Char==2)
	  {	if(temp==1)//-----------------------------white
			{
				if((keyCode==49)&&(prapaimanee.money>=30))
				{
				prapaimanee.money=prapaimanee.money-30;
				prapaimanee.temp_white=prapaimanee.temp_white+1;
				talknpc=5;
				repaint();
				}else if((keyCode==50)&&(prapaimanee.money>=150))
				{
				prapaimanee.money=prapaimanee.money-150;
				prapaimanee.temp_white=prapaimanee.temp_white+5;
				talknpc=5;
				repaint();
				}else if((keyCode==51)&&(prapaimanee.money>=300))
				{
				prapaimanee.money=prapaimanee.money-300;
				prapaimanee.temp_white=prapaimanee.temp_white+10;
				talknpc=5;
				repaint();
				}else if((keyCode==52)&&(prapaimanee.money>=600))
				{
				prapaimanee.money=prapaimanee.money-600;
				prapaimanee.temp_white=prapaimanee.temp_white+20;
				talknpc=5;
				repaint();
				}else {talknpc=4;repaint();	}
			
			
		}else
		if (temp==2)
		{
				if((keyCode==49)&&(prapaimanee.money>=300))
				{
				prapaimanee.money=prapaimanee.money-300;
				prapaimanee.temp_red=prapaimanee.temp_red+1;
				talknpc=5;
				repaint();
				}else if((keyCode==50)&&(prapaimanee.money>=1500))
				{
				prapaimanee.money=prapaimanee.money-1500;
				prapaimanee.temp_red=prapaimanee.temp_red+5;
				talknpc=5;
				repaint();
				}else if((keyCode==51)&&(prapaimanee.money>=3000))
				{
				prapaimanee.money=prapaimanee.money-3000;
				prapaimanee.temp_red=prapaimanee.temp_red+10;
				talknpc=5;
				repaint();
				}else if((keyCode==52)&&(prapaimanee.money>=6000))
				{
				prapaimanee.money=prapaimanee.money-6000;
				prapaimanee.temp_red=prapaimanee.temp_red+20;
				talknpc=5;
				repaint();
				}else{talknpc=4;repaint();}
		}
	  }	
	else{	if(temp==1)//-----------------------------white
			{
				if((keyCode==49)&&(prapaimanee.money>=50))
				{
				prapaimanee.money=prapaimanee.money-50;
				prapaimanee.temp_white=prapaimanee.temp_white+1;
				talknpc=5;
				repaint();
				}else if((keyCode==50)&&(prapaimanee.money>=250))
				{
				prapaimanee.money=prapaimanee.money-250;
				prapaimanee.temp_white=prapaimanee.temp_white+5;
				talknpc=5;
				repaint();
				}else if((keyCode==51)&&(prapaimanee.money>=500))
				{
				prapaimanee.money=prapaimanee.money-500;
				prapaimanee.temp_white=prapaimanee.temp_white+10;
				talknpc=5;
				repaint();
				}else if((keyCode==52)&&(prapaimanee.money>=1000))
				{
				prapaimanee.money=prapaimanee.money-1000;
				prapaimanee.temp_white=prapaimanee.temp_white+20;
				talknpc=5;
				repaint();
				}else {talknpc=4;repaint();	}
			
			
		}else
		if (temp==2)
		{
				if((keyCode==49)&&(prapaimanee.money>=500))
				{
				prapaimanee.money=prapaimanee.money-500;
				prapaimanee.temp_red=prapaimanee.temp_red+1;
				talknpc=5;
				repaint();
				}else if((keyCode==50)&&(prapaimanee.money>=2500))
				{
				prapaimanee.money=prapaimanee.money-2500;
				prapaimanee.temp_red=prapaimanee.temp_red+5;
				talknpc=5;
				repaint();
				}else if((keyCode==51)&&(prapaimanee.money>=5000))
				{
				prapaimanee.money=prapaimanee.money-5000;
				prapaimanee.temp_red=prapaimanee.temp_red+10;
				talknpc=5;
				repaint();
				}else if((keyCode==52)&&(prapaimanee.money>=10000))
				{
				prapaimanee.money=prapaimanee.money-10000;
				prapaimanee.temp_red=prapaimanee.temp_red+20;
				talknpc=5;
				repaint();
				}else{talknpc=4;repaint();}
		}
	}
	}else
	if (talknpc==4)
	{
		if(keyCode==49){talk=0;talknpc=0;stalk=0;repaint();}
	}else 
	if (talknpc==5)
	{
		if(keyCode==49){talk=0;talknpc=0;stalk=0;repaint();}
	}

	}//------------if talk=1

	if (talk==2)//------------if talk=2
	{
		if (talknpc==0)
	{
		if((keyCode==53)&&(prapaimanee.level>=20)&&(prapaimanee.Char==2)){talknpc=2;stalk=1;prapaimanee.job=2; repaint();}
		else if ((keyCode==53)&&(prapaimanee.level<20)&&(prapaimanee.Char==2))
		{
			 talknpc=1; stalk=1; repaint();
		}
			
	
	}else if ((talknpc==1)||(talknpc==2))
	{
		if (keyCode==49)
		{
			talk=0; talknpc=0; stalk=0; repaint();
		}
	}


	}//------------if talk=2
if (talk==3)//------------if talk=3
	{
		if (talknpc==0)
	{
		if((keyCode==53)&&(prapaimanee.level>=20)&&(prapaimanee.Char==3)){talknpc=2;stalk=1;prapaimanee.job=2; repaint();}
		else if ((keyCode==53)&&(prapaimanee.level<20)&&(prapaimanee.Char==3))
		{
			 talknpc=1; stalk=1; repaint();
		}
			
	
	}else if ((talknpc==1)||(talknpc==2))
	{
		if (keyCode==49)
		{
			talk=0; talknpc=0; stalk=0; repaint();
		}
	}


	}//------------if talk=3

if (talk==4)//------------if talk=4
	{
		if (talknpc==0)
	{
		if((keyCode==53)&&(prapaimanee.level>=20)&&((prapaimanee.Char==0)||(prapaimanee.Char==1))){talknpc=2;stalk=1;prapaimanee.job=2; repaint();}
		else if ((keyCode==53)&&(prapaimanee.level<20)&&((prapaimanee.Char==0)||(prapaimanee.Char==1)))
		{
			 talknpc=1; stalk=1; repaint();
		}
			
	
	}else if ((talknpc==1)||(talknpc==2))
	{
		if (keyCode==49)
		{
			talk=0; talknpc=0; stalk=0; repaint();
		}
	}


	}//------------if talk=4
		//*************************************
		}
		else//--------------------------------------battle mode-----------------------------------------
		{
			k=battle.chkbutton(keyCode,k);

		}	
		////system.out.println(k+" "+l);
		//*************************************
		}
	}
	

public void keyRepeated(int keyCode)
	{
if (gameover==false)
{


	//****************************
	if (battle.monhere == false)//------------------normal----------------------------------------
	{
	//****************************
	button=getGameAction(keyCode);
		if(stalk!=1)
	{	
		if(m==0)
		{
		Map0Checkbutton(button);
	
		}else
		if (m==1)
		{
		Map1Checkbutton(button);
		}else
		if (m==2)
		{
		Map2Checkbutton(button);
		}else
		if (m==3)
		{
		Map3Checkbutton(button);
		}else
		if (m==4)
		{
		Map4Checkbutton(button);
		}else
		if (m==5)
		{
		Map5Checkbutton(button);
		}else
		if (m==6)
		{
		Map6Checkbutton(button);
		}
		else
		if (m==7)
		{
		Map7Checkbutton(button);
		}
	}
	}
	}

	}
public void keyReleased(int keyCode)
	{		
			
	}
//------------------------------------------------end  receive EVENT----------------------------------------
//                                     //////////Strat Map/////////////
//------------------------------------------------MAP 0---------------------------------------------------

public void DrawMap0(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap0.length-1);a++ )
		{
			if ((k!=xmap0[a])||(l!=ymap0[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP0[map.M0[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	//------------------------------------mod pic-------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------mod pic-------------------------------------

								
					//-------------------------end draw map------------------------------	
				
				//---------------------------warp------------------------
				if((k==m0wx3)&&(l==m0wy3))
					{
					m=1;
					l=2;k=9;
					repaint();
					}
				//---------------------------warp------------------------
	}
//------------------------------------------------end MAP 0---------------------------------------------------
//------------------------------------------------MAP 1---------------------------------------------------

public void DrawMap1(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap1.length-1);a++ )
		{
			if ((k!=xmap1[a])||(l!=ymap1[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP1[map.M1[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m1wx1)&&(l==m1wy1))
					{
					m=0;
					l=5;k=3;
					repaint();
					}else
					if((k==m1wx3)&&(l==m1wy3))
					{
					m=2;
					l=1;k=15;
					if (startpic2==0)
						{	
								battle.createpic2();
								startpic2=1;
						}
					battle.random_monster(2,xmap2,ymap2);
					repaint();
					}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 1---------------------------------------------------	
//------------------------------------------------MAP 2---------------------------------------------------

public void DrawMap2(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap2.length-1);a++ )
		{
			if ((k!=xmap2[a])||(l!=ymap2[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP2[map.M2[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m2wx1)&&(l==m2wy1))
					{
					m=1;
					l=13;k=9;
					repaint();
					}else if((k==m2wx2)&&(l==m2wy2))
							{
							m=3;
							l=10;k=1;
							battle.random_monster(3,xmap3,ymap3);
							repaint();
							}else if((k==m2wx4)&&(l==m2wy4))
								{
								m=4;
								l=5;k=28;
								battle.random_monster(4,xmap4,ymap4);
								repaint();
								}else if((k==m2wx3)&&(l==m2wy3))
									{
									m=6;
									l=1;k=2;
									battle.random_monster(6,xmap6,ymap6);
									repaint();
									}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 2---------------------------------------------------	
//------------------------------------------------MAP 3---------------------------------------------------

public void DrawMap3(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap3.length-1);a++ )
		{
			if ((k!=xmap3[a])||(l!=ymap3[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP2[map.M3[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m3wx4)&&(l==m3wy4))
					{
					m=2;
					l=12;k=28;
					battle.random_monster(2,xmap2,ymap2);
					repaint();
					}else if((k==m3wx2)&&(l==m3wy2))
					{
					m=5;
					l=14;k=1;
					battle.random_monster(5,xmap5,ymap5);
					repaint();
					}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 3---------------------------------------------------	
//------------------------------------------------MAP 4---------------------------------------------------

public void DrawMap4(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap4.length-1);a++ )
		{
			if ((k!=xmap4[a])||(l!=ymap4[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP4[map.M4[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m4wx2)&&(l==m4wy2))
					{
					m=2;
					l=14;k=1;
					battle.random_monster(2,xmap2,ymap2);
					repaint();
					}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 4---------------------------------------------------	
//------------------------------------------------MAP 5---------------------------------------------------

public void DrawMap5(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap5.length-1);a++ )
		{
			if ((k!=xmap5[a])||(l!=ymap5[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP5[map.M5[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m5wx4)&&(l==m5wy4))
					{
					m=3;
					l=10;k=28;
					repaint();
					}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 5---------------------------------------------------	
//------------------------------------------------MAP 6---------------------------------------------------

public void DrawMap6(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap6.length-1);a++ )
		{
			if ((k!=xmap6[a])||(l!=ymap6[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP6[map.M6[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
				if((k==m6wx1)&&(l==m6wy1))
					{
					m=2;
					l=28;k=11;
					battle.random_monster(2,xmap2,ymap2);
					repaint();
				}else if((k==m6wx3)&&(l==m6wy3))
					{
					m=7;
					l=0;k=3;
					repaint();
				}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 6---------------------------------------------------
//------------------------------------------------MAP 7---------------------------------------------------

public void DrawMap7(Graphics g)
	{
					//-------------------------checkmap--------------------------

	for (int a=0;a<=(xmap7.length-1);a++ )
		{
			if ((k!=xmap7[a])||(l!=ymap7[a]))
			{

			}
			else{k=xmapna;l=ymapna;}

		}

					//-------------------------end checkmap--------------------------
					//-------------------------draw map------------------------------
	
	for(j=0;j<=6;j++)
		{
	
	for(i=0;i<=8;i++)
		{
	g.drawImage(arrayP7[map.M7[j+l][i+k]],i*20,j*17+25,0);
	}
		}
	
	//------------------------------------ mod pic -------------------------------------
	cf=cf%2;
	cb=cb%2;
	cl=cl%2;
	cr=cr%2;
	//------------------------------------ mod pic -------------------------------------

								
					//-------------------------end draw map------------------------------	

					//---------------------------warp------------------------
			//	if((k==m6wx1)&&(l==m6wy1))
			//		{
			//		m=2;
			//		l=28;k=11;
			//		repaint();
			//	}
				//---------------------------warp------------------------


	}
//------------------------------------------------end MAP 7---------------------------------------------------
//---------------------------------------------------check map0---------------------------------------------
public void Map0Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=5)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=5)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}
//---------------------------------------------------end check map0---------------------------------------------
//--------------------------------------------------- check map1---------------------------------------------
public void Map1Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=17)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=13)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}


//--------------------------------------------------------END chack map1----------------------------------------------
//--------------------------------------------------- check map2---------------------------------------------
public void Map2Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=28)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=28)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}
//--------------------------------------------------- check map2---------------------------------------------
//--------------------------------------------------- check map3---------------------------------------------
public void Map3Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=28)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=18)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}

//--------------------------------------------------------END chack map3----------------------------------------------
//--------------------------------------------------- check map4---------------------------------------------
public void Map4Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=28)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=18)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}

//--------------------------------------------------------END chack map4----------------------------------------------
//--------------------------------------------------- check map5---------------------------------------------
public void Map5Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=18)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=18)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}

//--------------------------------------------------------END chack map5----------------------------------------------
//--------------------------------------------------- check map6---------------------------------------------
public void Map6Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=3)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=28)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}
		
		}

//--------------------------------------------------------END chack map6----------------------------------------------
//--------------------------------------------------- check map7---------------------------------------------
public void Map7Checkbutton(int b)
	{
	xmapna=k;
	ymapna=l;
	switch(b)
		{
		case LEFT : 
			{
			
			if(k>=1)
				{k=k-1;}
				hun=2;cl++;cb=-1;cf=-1;cr=-1;repaint();break;
			}
		case RIGHT :{
			if(k<=5)
				{k=k+1;}
			hun=3;cl=-1;cb=-1;cf=-1;cr++;repaint();break;
			}
		case UP : {
			if(l>=1)
				{l=l-1;}
			hun=0;cl=-1;cb++;cf=-1;cr=-1;repaint();break;
			}
		case DOWN : {
			if(l<=5)
				{l=l+1;}
			hun=1;cl=-1;cb=-1;cf++;cr=-1;repaint();break;
			}
		}

		if ((k==3)&&(l==3))
		{
				
			m=8;repaint();

		}



		
		}
       public void talkboss (Graphics g)
		   {
				if (intalk==0)
				{
						g.drawImage(arraytalk[16],14,30,0); 
						ttboss=true;
						
				}else
				if (intalk==1)
				{
						g.drawImage(arraytalk[17],14,30,0);
						
				}else
				if (intalk==2)
				{
						g.drawImage(arraytalk[18],14,30,0); 
				}else
				if (intalk==3)
				{
						g.drawImage(arraytalk[19],14,30,0); 
				}
		 										
				g.drawImage(arraytalk[15],0,117,0);
				
				if (intalk==4)
				{
					m=9;
					repaint();

				}
				//system.out.print("map prapaimanee ="+m);

			}

		public void runtalk ()
			{  
			
			if (tboss==45)
			{		intalk++;
					repaint() ; 
					tboss=0;
					if (intalk==4)
					{
						ttboss=false;
					}
			}
					
		
				
			};

//--------------------------------------------------------END chack map7----------------------------------------------
//								/////////////end map////////////////
//----------------------------------------------------Task---------------------------------------------------
private class TestTimerTask extends TimerTask
	{
			//*****************************
			public final void run() 
			{
			int temp_int;
			if (gameover==false)
			{
			
			if ((battle.monhere==true)&&(battle.rdy==false))//----------------chk run battle
			{
				k =	battle.run(k);
				battle.mon_run();
				repaint();
				
			}else if (battle.monhere==true)
			 {battle.mon_run();repaint();}

			if (ttboss==true)
			{
				tboss++;
				runtalk();	
			}
			
			if ((battle.holy_time>0)&&(battle.holy_time<4))
			{
				battle.holy_time = ++battle.holy_time;
				battle.temp_mondelay = battle.temp_mondelay-1;
			}
			else
			{
				battle.holy_time = 0;
			}

}

			
			}
			//******************************
			



	}; 

//------------------------------------------------------end Task-----------------------------------------




}//end canvas