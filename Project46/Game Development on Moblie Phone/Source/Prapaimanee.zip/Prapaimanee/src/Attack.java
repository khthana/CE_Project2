//-----------------------------------------------------class attack--------------------------------
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;

public class Attack
	{
		
		public Image[]normal = new Image[4];
		public Image[]special = new Image[4];
		
		
		public Attack(int Char)
		{
		try
			{	
			if( Char == 0)//-----------apaimanee
				{
					normal[0] = Image.createImage("/attack_pic/normal/pic0.png");
					

					special[3] = Image.createImage("/attack_pic/special/pic3.png");
					
					System.out.println("apaimanee");
				}
				else if(Char == 1)//--------------------sreesuwan
				{
					normal[1] = Image.createImage("/attack_pic/normal/pic1.png");
					

					special[1]= Image.createImage("/attack_pic/special/pic1.png");
					
				}
				else if(Char == 2)//---------------------karekasa
				{
					normal[2] = Image.createImage("/attack_pic/normal/pic2.png");
					
					
					special[0] = Image.createImage("/attack_pic/special/pic0.png");
					System.out.println("karekasa");
				}
				else if(Char == 3)//------------------------------mer
				{
					normal[3] = Image.createImage("/attack_pic/normal/pic3.png");
					
					special[2] = Image.createImage("/attack_pic/special/pic2.png");
				
					System.out.println("mer");
				}
				
				
				
				
			}
		catch (java.io.IOException e){}
		}
		
	}
//------------------------------------------------------end attack-----------------------------------