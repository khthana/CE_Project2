//-----------------------------------------------------class background--------------------------------
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;

public class Backgrounds
	{
		
		public Image[] background = new Image[6];
		public Image[] statusb = new Image[20];
		public Image[] face = new Image[5];
		public Backgrounds()
		{
		try
			{
			//---------------------background----------------------------
				background[0] = Image.createImage("/background_pic/SeaBeach.png");
				background[1] = Image.createImage("/background_pic/Ship.png");
				background[2] = Image.createImage("/background_pic/Forest1.png");
				background[3] = Image.createImage("/background_pic/LavaCave2.png");
				background[4] = Image.createImage("/background_pic/Desert.png");
				background[5] = Image.createImage("/background_pic/Grass.png");
			//----------------------status--------------------------------
				statusb[0] = Image.createImage("/status_pic/statusb.png");
				statusb[1] = Image.createImage("/status_pic/statusbdown.png");
				statusb[2] = Image.createImage("/status_pic/warning1.png");
				statusb[3] = Image.createImage("/status_pic/warning2.png");
				statusb[4] = Image.createImage("/status_pic/nameapai.png");
				statusb[5] = Image.createImage("/status_pic/namesee.png");
				statusb[6] = Image.createImage("/status_pic/namekaew.png");
				statusb[7] = Image.createImage("/status_pic/namemer.png");
				statusb[8] = Image.createImage("/status_pic/n0.png");
				statusb[9] = Image.createImage("/status_pic/n1.png");
				statusb[10] = Image.createImage("/status_pic/n2.png");
				statusb[11] = Image.createImage("/status_pic/n3.png");
				statusb[12] = Image.createImage("/status_pic/n4.png");
				statusb[13] = Image.createImage("/status_pic/n5.png");
				statusb[14] = Image.createImage("/status_pic/n6.png");
				statusb[15] = Image.createImage("/status_pic/n7.png");
				statusb[16] = Image.createImage("/status_pic/n8.png");
				statusb[17] = Image.createImage("/status_pic/n9.png");
				statusb[18] = Image.createImage("/status_pic/n10.png");
				statusb[19] = Image.createImage("/status_pic/n11.png");

			//------------------------face--------------------------------
				face[0] = Image.createImage("/status_pic/apaimanee.png");
				face[1] = Image.createImage("/status_pic/seesuwun.png");
				face[2] = Image.createImage("/status_pic/kaewkaesa.png");
				face[3] = Image.createImage("/status_pic/Mer.png");
				

			}
		catch (java.io.IOException e){}
		}
		
	}
//------------------------------------------------------end background-----------------------------------