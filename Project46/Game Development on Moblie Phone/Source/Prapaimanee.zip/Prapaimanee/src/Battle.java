//-----------------------------------------------------class battle--------------------------------
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;

public class Battle 
	{
		public boolean monhere = false,rdy = false,mon_die = false,mon = false;
		public int xbox,warn_time,where,injury_time,monster_id,temp_monhp = -10000,
			attack_time,temp_mondelay,mon_attack_time,w,h,max_xbox,gain,white_hp,
			holy_time,max_injury_time,special_time,delay_special,temp_random,exp;
		//                                1			  2				  3				   4			   5			  6				   7		       8			   9			 10
		public int[] exp_rate = {30			,60			,90			,120			,150			,200			,250			,300			,350			,500,
										 800			,1300		,1800		,2300		,2900		,3400		,3700		,4000		,4200		,4500,
										4700			,5300		,5800		,6250		,6750		,7500		,7850		,8300		,8700		,9000,
										10000		,11000		,12000		,13000		,14000		,15000		,16000		,17000		,18000		,19000,
										20000		,21000		,22000		,23000		,24000		,25000		,26000		,27000		,28000		,29000,
										30000		,31000		,32000		,33000		,34000		,35000		,36000		,37000		,38000		,39000,
										40000		,41000		,42000		,43000		,44000		,45000		,46000		,47000		,48000		,49000,
										50000		,51000		,52000		,53000		,54000		,55000		,56000		,57000		,58000		,59000,
										60000		,61000		,62000		,63000		,64000		,65000		,66000		,67000		,68000		,69000,
										70000		,71000		,72000		,73000		,74000		,75000		,76000		,77000		,78000		,79000,									};
		private String temp_string,human_damage,mon_damage;
		private Random randomnum;
		private Backgrounds bg ;
		private Monsters monster ;
		private Attack attack ;
		private Prapaimanee prapaimanee;
		private Randommon randommon;
		
		
		public Battle(Prapaimanee prapaimanee)
		{
			w = 176;
			h = 144;
			randommon = new Randommon();
			randomnum = new Random();
			bg = new Backgrounds();
			this.prapaimanee = prapaimanee;
			max_xbox = 84;
			gain = 5;//----------------gain agi
			white_hp = 200;//--------------- white + hp;
		
			
		}
		public void createpic1()
		{	attack = new Attack(this.prapaimanee.Char);}
		public void createpic2()
		{	monster = new Monsters();} 
		

		public void drawBattle(Graphics g)
		{	
			
			//---------------- background -------------------------------------------------------------
			Image temp_image = bg.background[where];
			g.drawImage(temp_image,0,30,0);
			//---------------- status up ---------------------------------------------------------------
			drawstatus_up(g);
			//----------------------------battle.warn_timeing---------------------------------------------------------
			if(warn_time<15)
			{
				if ((warn_time%2)==0)
				{
					g.drawImage(bg.statusb[2],38,23,0);
					g.drawImage(bg.statusb[monster_id+8],38,47,0);
					
				}
				else
				{
					g.drawImage(bg.statusb[3],38,25,0);
					g.drawImage(bg.statusb[monster_id+8],38,47,0);
				}
			}
			else
			{
			    //---------------------------battle.monster---------------------------------------------------
				draw_monster_injury(g);
				//----------------------------------human attack-----------------------------
				if(attack_time !=0)
				{
					draw_human_attack(g);
				}
				//----------------------------------monster attack----------------------------
				if(mon_attack_time !=0)
				{
					draw_monster_attack(g);	
				}
				//----------------------------------holy----------------------------------------------
				if(holy_time !=0)
				{
					g.setColor(255,255,0);
					temp_string = Integer.toString(white_hp);
					g.drawString(temp_string,8,33,0);
					
				}
				if(special_time != 0)
				{
					draw_human_special(g);
				}
			}
			//---------------- status down --------------------------------------------------------------
			temp_image = bg.statusb[1];
			g.drawImage(temp_image,0,118,0); 
			g.setColor(237,28,36);
			g.fillRect(4,126,xbox,10);//----------- x+4 , y+4  height 9 weight 55
		
			temp_image = bg.statusb[this.prapaimanee.Char+4];
			g.drawImage(temp_image,88,118,0);

			
			//-----------------------------try to do delay--------------------------------------------------
			

		}
		//---------------------------------------------------chk battle button ---------------------------------
		public int chkbutton(int keycode,int k)
		{
			int temp_int = k;
			int key = keycode ;
			if(key == 50)//------------------2
				{
					if(this.prapaimanee.temp_white != 0)
					{
						if(this.prapaimanee.temp_human_hp != this.prapaimanee.max_human_hp)
						{
							this.prapaimanee.temp_white = this.prapaimanee.temp_white - 1;
							this.prapaimanee.temp_human_hp = this.prapaimanee.temp_human_hp + white_hp;
							if(this.prapaimanee.temp_human_hp>this.prapaimanee.max_human_hp)
							{
								this.prapaimanee.temp_human_hp = this.prapaimanee.max_human_hp;
							}
							holy_time = 1;
						}
						
					}
				}
				
			if (rdy == true)
			{
				if(key == 49)//------------------------1
				{
					injury_time = 1;
					attack_time = 1;
					rdy=false;
					xbox = 0;
					temp_monhp = temp_monhp-get_human_attack();	//-------------hit monster--------------------
					max_injury_time = 10;
				}
				else  if(key == 51)//-----------------------3
				{
					if((this.prapaimanee.temp_red != 0)&&(this.prapaimanee.job != 1))
					{
							if(this.prapaimanee.Char == 2)
							{
								delay_special =16;//********up with 2
							}
							if(this.prapaimanee.Char == 1)
							{
								delay_special = 20;//*********up to 1
							}
							if(this.prapaimanee.Char == 3)
							{
								delay_special = 20;//*********up to 3
								this.prapaimanee.temp_human_hp = this.prapaimanee.temp_human_hp + (this.prapaimanee.level*5);
								if(this.prapaimanee.temp_human_hp>this.prapaimanee.max_human_hp)
								{
									this.prapaimanee.temp_human_hp = this.prapaimanee.max_human_hp;
								}
							}
							if(this.prapaimanee.Char == 0)
							{
								delay_special = 23;//*********up to 0
							}
							rdy=false;
							xbox = 0;
							this.prapaimanee.temp_red = this.prapaimanee.temp_red - 1;
							injury_time = 1;
							special_time = 1;
							max_injury_time = delay_special+5;
							temp_monhp = temp_monhp-get_human_special();	//-------------hit monster--------------------
							
						
						
					}
				}
				else if(key == 52)//-----------------------4
				{
				if((this.prapaimanee.canvas.m != 6)&&(this.prapaimanee.canvas.m != 9)	)
				{
					rdy = false;
					xbox = 0;
					warn_time = 0;
					mon_attack_time = 0;
					temp_mondelay = 0;
					temp_monhp = -10000;
					if(this.prapaimanee.canvas.m == 2)
					{
						random_monster(2,this.prapaimanee.canvas.xmap2,this.prapaimanee.canvas.ymap2);
					}
					else if(this.prapaimanee.canvas.m == 3)
					{
						random_monster(3,this.prapaimanee.canvas.xmap3,this.prapaimanee.canvas.ymap3);
					}
					else if(this.prapaimanee.canvas.m == 4)
					{
						random_monster(4,this.prapaimanee.canvas.xmap4,this.prapaimanee.canvas.ymap4);
					}
					else if(this.prapaimanee.canvas.m == 5)
					{
						random_monster(5,this.prapaimanee.canvas.xmap5,this.prapaimanee.canvas.ymap5);
					}
					mon = false;
				}
				}

				//system.out.println("temp_mon "+temp_monhp);
			}
			
			return temp_int;
		}
//------------------------------------------------------end chk button-----------------------------------------
//----------------------------------------------------chk monster----------------------------------------
		public boolean chkmonster(int map,int x,int y)
		{
			int k = x;
			int l = y;
			int m = map;
	
			
			
	if(mon == false)
	{
			if(m == 2)
			{
				for(int i = 0;i<randommon.max_mon[m];i++)
				{
					if((randommon.xm2[i] == k )&&(randommon.ym2[i] == l))
					{
						mon = true;
						do
						{
							temp_random = randomnum.nextInt() % 2 ;
							
						}while(temp_random < 0);
						//system.out.println("where = "+temp_random);
						if(temp_random == 0)
						{
							where = 4;
						}else 
						{
							where = 5;
						}
						do
						{
						temp_random = randomnum.nextInt() % 50; 
						
						}while(temp_random < 0);
						
						if(temp_random < 5)
						{
							monster_id = 8;
						}
						else if((temp_random >=5)&&(temp_random <10))
						{
							monster_id = 4;
						}
						else
						{
							monster_id = 9;
						}
						//system.out.println("monster id ="+temp_random);
						if(temp_monhp == -10000)
						{
							temp_monhp = monster.hp[monster_id];
						}
						
						break;
					}
				}
				//system.out.println("mon temp hp ="+temp_monhp);
				//system.out.println("monster.hp[monster_id] ="+monster.hp[monster_id]);
			}
			
			else if(m == 3)
			{
				for(int i = 0;i<randommon.max_mon[m];i++)
				{
					if((randommon.xm3[i] == k )&&(randommon.ym3[i] == l))
					{
						mon = true;
						do
						{
							temp_random = randomnum.nextInt() % 2 ;
							
						}while(temp_random < 0);
						//system.out.println("where = "+temp_random);
						if(temp_random == 0)
						{
							where = 4;
						}else 
						{
							where = 2;
						}
						do
						{
						temp_random = randomnum.nextInt() % 50; 
						
						}while(temp_random < 0);
						
						if(temp_random < 15)
						{
							monster_id = 6;
						}
						else if((temp_random >=15)&&(temp_random <30))
						{
							monster_id = 7;
						}
						else
						{
							monster_id = 8;
						}
						//system.out.println("monster id ="+temp_random);
						if(temp_monhp == -10000)
						{
							temp_monhp = monster.hp[monster_id];
						}
						
						break;
					}
				}
				//system.out.println("mon temp hp ="+temp_monhp);
				//system.out.println("monster.hp[monster_id] ="+monster.hp[monster_id]);
			}


			else if(m == 4)
			{
				for(int i = 0;i<randommon.max_mon[m];i++)
				{
					if((randommon.xm4[i] == k )&&(randommon.ym4[i] == l))
					{
						mon = true;
						do
						{
							temp_random = randomnum.nextInt() % 2 ;
							
						}while(temp_random < 0);
						//system.out.println("where = "+temp_random);
						if(temp_random == 0)
						{
							where = 0;
							monster_id = 1;
						}else 
						{
							where = 1;
							monster_id = 3;
						}
					
						//system.out.println("monster id ="+temp_random);
						if(temp_monhp == -10000)
						{
							temp_monhp = monster.hp[monster_id];
						}
						
						break;
					}
				}
				//system.out.println("mon temp hp ="+temp_monhp);
				//system.out.println("monster.hp[monster_id] ="+monster.hp[monster_id]);
			}


			else if(m == 5)
			{
				for(int i = 0;i<randommon.max_mon[m];i++)
				{
					if((randommon.xm5[i] == k )&&(randommon.ym5[i] == l))
					{
						mon = true;
						do
						{
							temp_random = randomnum.nextInt() % 2 ;
							
						}while(temp_random < 0);
						//system.out.println("where = "+temp_random);
						if(temp_random == 0)
						{
							where = 2;
						}
						else 
						{
							where = 5;
						}
						do
						{
						temp_random = randomnum.nextInt() % 50; 
						
						}while(temp_random < 0);
						
						if(temp_random < 15)
						{
							monster_id = 10;
						}
						else if((temp_random >=15)&&(temp_random <30))
						{
							monster_id = 0;
						}
						else
						{
							monster_id = 7;
						}
						//system.out.println("monster id ="+temp_random);
						if(temp_monhp == -10000)
						{
							temp_monhp = monster.hp[monster_id];
						}
						
						break;
					}
				}
				//system.out.println("mon temp hp ="+temp_monhp);
				//system.out.println("monster.hp[monster_id] ="+monster.hp[monster_id]);
			}
			
			else if(m ==6)
			{
				for(int i = 0;i<randommon.max_mon[m];i++)
				{
					if((randommon.xm6[i] == k )&&(randommon.ym6[i] == l))
					{
						mon = true;
						
						//system.out.println("where = "+temp_random);
						where = 3;
						
						do
						{
						temp_random = randomnum.nextInt() % 50; 
						
						}while(temp_random < 0);
						
						if(temp_random < 15)
						{
							monster_id = 5;
						}
						else if((temp_random >=15)&&(temp_random <30))
						{
							monster_id = 0;
						}
						else
						{
							monster_id = 2;
						}
						//system.out.println("monster id ="+temp_random);
						if(temp_monhp == -10000)
						{
							temp_monhp = monster.hp[monster_id];
						}
						
						break;
					}
				}
				//system.out.println("mon temp hp ="+temp_monhp);
				//system.out.println("monster.hp[monster_id] ="+monster.hp[monster_id]);
			}

			if(m == 9)
			{
				mon = true;
				where = 3;
				monster_id = 11;
				if(temp_monhp == -10000)
				{
						temp_monhp = monster.hp[monster_id];
				}
				//system.out.println("m ="+m);
				//system.out.println("mon ="+mon);
				//system.out.println("monster id "+monster_id);
			}
			

	}
			
			
			
			return mon;
	
		}
//---------------------------------------------------end chk monster------------------------------------
//---------------------------------------------------chk monster die------------------------------------
		public void chkmonsterdie()
		{
			
			if((temp_monhp <=0)&&(temp_monhp!=-10000))
			{
				temp_monhp = -10000;
				
				warn_time = 0;
				xbox = 0;
				mon_attack_time = 0;
				temp_mondelay = 0;
				this.prapaimanee.exp = this.prapaimanee.exp + monster.exp[monster_id];
				if(this.prapaimanee.exp >= exp_rate[this.prapaimanee.level])
				{
					if(this.prapaimanee.level < 99)
					{
						this.prapaimanee.level = this.prapaimanee.level + 1;
						this.prapaimanee.human_attack = (this.prapaimanee.level*5)+40;
						this.prapaimanee.human_special =  (this.prapaimanee.level*20)+250;
						this.prapaimanee.max_human_hp = (this.prapaimanee.level*this.prapaimanee.level)+198;
						if (this.prapaimanee.level <= 40)
						{
							this.prapaimanee.agi = this.prapaimanee.agi + 1;
						}
						
						if(this.prapaimanee.Char == 0)
						{
							this.prapaimanee.human_special =  (this.prapaimanee.level*30)+250;
						}
						else if(this.prapaimanee.Char == 1)
						{
							this.prapaimanee.human_attack = (this.prapaimanee.level*15)+40;
						}
					
					}


				}
				//system.out.println("exp ="+this.prapaimanee.exp);
				//system.out.println("level ="+this.prapaimanee.level);
				//system.out.println("agi ="+this.prapaimanee.agi);


				this.prapaimanee.money = this.prapaimanee.money + monster.money[monster_id];
				if(this.prapaimanee.money > 9999999)
				{
					this.prapaimanee.money = 9999999;
				}
				if(this.prapaimanee.canvas.m == 2)
				{
					random_monster(2,this.prapaimanee.canvas.xmap2,this.prapaimanee.canvas.ymap2);
				}
				else if(this.prapaimanee.canvas.m == 3)
				{
					random_monster(3,this.prapaimanee.canvas.xmap3,this.prapaimanee.canvas.ymap3);
				}
				else if(this.prapaimanee.canvas.m == 4)
				{
					random_monster(4,this.prapaimanee.canvas.xmap4,this.prapaimanee.canvas.ymap4);
				}
				else if(this.prapaimanee.canvas.m == 5)
				{
					random_monster(5,this.prapaimanee.canvas.xmap5,this.prapaimanee.canvas.ymap5);
				}
				else if(this.prapaimanee.canvas.m == 6)
				{
					random_monster(6,this.prapaimanee.canvas.xmap6,this.prapaimanee.canvas.ymap6);
				}
				else if (this.prapaimanee.canvas.m == 9)
				{
					this.prapaimanee.canvas.m=10;
					
				}
				mon = false;
				if (monster_id==11)
				{
					this.prapaimanee.canvas.gameover=true;
					this.prapaimanee.canvas.m=9;
					this.prapaimanee.canvas.repaint();
					
				}

			}
			
		}
//-----------------------------------------------end chk monster die------------------------------------
//------------------------------------------------battle run---------------------------------------------
		public int run(int k)
		{
			int temp_int = k;
			//--------------------------------------------------------dalay warning time----------------------------------------------
			if(warn_time<15)
			{
					warn_time = ++warn_time;	
			}
			else
			{
					if(xbox<84)//-------------------------------------delay human------------------------------
					{
						////system.out.println( "Running the task"+xbox );
						xbox = xbox+2+(this.prapaimanee.agi/gain);
						if(xbox >= max_xbox)
						{
							xbox = max_xbox;
						}
					}
					else
					{
						rdy = true;
					}
			}
			if ((attack_time>0)&&(attack_time<4))
			{
				attack_time = ++attack_time;
				xbox = 0;
			}
			else
			{
				attack_time = 0;
			}
			if((injury_time>0)&&(injury_time<max_injury_time))//--------------------------to swap when monster be attack
			{
				injury_time = ++injury_time;
				xbox = 0;
				temp_mondelay = temp_mondelay-1;//--------------------------sub delay_monster when injury or die
			}
			else
			{
				injury_time = 0;
				chkmonsterdie();
			}
			//----------------------------++ delay monster-----------------------------------------------
			/*if (warn_time == 15)
			{
				if(temp_mondelay<monster.delay[monster_id])
				{
					temp_mondelay = temp_mondelay + 1;
					////system.out.println(temp_mondelay);
				}
				else
				{
					temp_mondelay = 0;
					mon_attack_time = 1;
					int mon_attack = monster.getdamage(monster_id);
					this.prapaimanee.temp_human_hp = this.prapaimanee.temp_human_hp - mon_attack;
					mon_damage = Integer.toString(mon_attack);
					
				}
			}*/
			//--------------------------attack time monster----------------------------------------------
			/*if ((mon_attack_time>0)&&(mon_attack_time<4))
			{
				mon_attack_time = ++mon_attack_time;
				temp_mondelay = 0;
				xbox = xbox-1-(this.prapaimanee.agi/gain);
			}
			else
			{
				mon_attack_time = 0;
			}*/
			//----------------------------holy time-----------------------------------------------------------
		/*	if ((holy_time>0)&&(holy_time<4))
			{
				holy_time = ++holy_time;
				temp_mondelay = temp_mondelay-1;
				
			}
			else
			{
				holy_time = 0;
			}*/
			//------------------------------special time-----------------------------------------------------
			if ((special_time>0)&&(special_time<delay_special))
			{
				special_time = ++special_time;
				//temp_mondelay = temp_mondelay-1;
				xbox = 0;
			}
			else
			{
				special_time = 0;
			}
			return temp_int;
		}
//-------------------------------------------------end battle run ---------------------------------------
//-------------------------------------------------get human attack-----------------------------------
		public int get_human_attack()
		{
			int temp_int = (((this.prapaimanee.human_attack/2)*(100-this.prapaimanee.dex))/100);
			int temp_random ;
			do
			{
				temp_random = randomnum.nextInt() % temp_int;
			}while(temp_random<0);
			if(temp_random > (temp_int/2))
			{
					temp_random = temp_random - (temp_int/2);
					temp_int = temp_random + (this.prapaimanee.human_attack*(this.prapaimanee.str+100))/100;
			}
			else
			{
					temp_int = (this.prapaimanee.human_attack*(this.prapaimanee.str+100))/100 - temp_random;
			}
			human_damage = Integer.toString(temp_int);
			return temp_int;
			
		}
//---------------------------------------------------end get human attack---------------------------
//----------------------------------------------------draw monster injury-----------------------------	
		public void draw_monster_injury(Graphics g)
		{
			if(injury_time <4)
				{
					if(this.prapaimanee.canvas.m == 9)
					{
						draw_monsters(g,monster_id);
						
					}
					else
					{
						draw_monsters(g,monster_id);
					}
				}
				else if(injury_time <max_injury_time)
				{
					g.setColor(255,184,255);
					if ((injury_time%2)==0)
					{
						if(temp_monhp<=0)
						{
							if(this.prapaimanee.canvas.m == 9)
							{
								draw_monsters(g,monster_id);
							}
							else
							{
								draw_monsters(g,monster_id);
							}
							
							
						}	
						else
						{
							g.fillRect(0,0,w,h);//-----------------------red box
							
						}
					}
					else
					{
						if(temp_monhp<=0)
						{
							g.fillRect(0,0,w,h);
						}	
						else
						{
							if(this.prapaimanee.canvas.m == 9)
							{
								draw_monsters(g,monster_id);
							}
							else
							{
								draw_monsters(g,monster_id);
							}
						}
					}
				}
		}

//---------------------------------------------------end draw monster injury------------------------
//-----------------------------------------------------draw monster---------------------------
		public void draw_monsters(Graphics g , int id)
		{
			g.setClip(38,33,100,80);
			if(id == 0)
			{
				g.drawImage(monster.normal,38,33,0);
			}
			else if(id == 1)
			{
				g.drawImage(monster.normal,-62,33,0);
			}
			else if(id == 2)
			{
				g.drawImage(monster.normal,-162,33,0);
			}
			else if(id == 3)
			{
				g.drawImage(monster.normal,-262,33,0);
			}
			else if(id ==4)
			{
				g.drawImage(monster.normal,-362,33,0);
			}
			else if(id == 5)
			{
				g.drawImage(monster.normal,-462,33,0);
			}
			else if(id == 6)
			{
				g.drawImage(monster.normal,-562,33,0);
			}
			else if(id == 7)
			{
				g.drawImage(monster.normal,-662,33,0);
			}
			else if(id == 8)
			{
				g.drawImage(monster.normal,-762,33,0);
			}
			else if(id == 9)
			{
				g.drawImage(monster.normal,-862,33,0);
			}
			else if(id == 10)
			{
				g.drawImage(monster.normal,-962,33,0);
			}
			else if(id == 11)
			{
				g.setClip(8,33,160,80);
				g.drawImage(monster.normal,-1092,33,0);
			}
			g.setClip(0,0,w,h);
		}
//------------------------------------------------------end draw monster--------------------
//---------------------------------------------------draw status up-------------------------------------
		public void drawstatus_up(Graphics g)
		{
			Image	temp_image = bg.statusb[0];
			
			g.drawImage(temp_image,0,0,0);
			temp_image = bg.face[this.prapaimanee.Char];
			g.drawImage(temp_image,2,1,0);//-----------face
			g.setColor(246,150,0);
			temp_string = Integer.toString(this.prapaimanee.temp_red);//---------------red
			g.drawString(temp_string,160,10,0);
			temp_string = Integer.toString(this.prapaimanee.temp_white);//--------------write
			g.drawString(temp_string,131,10,0);
			g.setColor(255,242,0);
			g.drawString(this.prapaimanee.name,35,10,0);//---------name
			g.setColor(250,66,39);
			g.drawString(this.prapaimanee.temp_human_hp+"/"+this.prapaimanee.max_human_hp,65,10,0);
			
		}
//----------------------------------------------------end draw status up-----------------------------
//------------------------------------------------draw_human_attack-------------------------------
		public void draw_human_attack(Graphics g)
		{
					g.setClip(50,40,100,80);
					if((attack_time - 2) == 0)
					{
						g.drawImage(attack.normal[this.prapaimanee.Char],38,33,0);//------------------attack
					}
					else if((attack_time - 2) == 1)
					{
						g.drawImage(attack.normal[this.prapaimanee.Char],-62,33,0);//------------------attack
					}
					else if((attack_time - 2) == 2)
					{
						g.drawImage(attack.normal[this.prapaimanee.Char],-162,33,0);//------------------attack
					}
					g.setColor(0,0,255);
					g.drawString(human_damage,80,100,0);//--------------------damage
			
					g.setClip(0,0,w,h);
		}
//--------------------------------------------------end draw human attack------------------------
//-----------------------------------------------draw monster attack-------------------------------
		public void draw_monster_attack(Graphics g)
		{			
					if((mon_attack_time%2)==0)
					{
						g.setColor(255,255,255);
						g.fillRect(0,0,w,h);//-----------------------white box
					}
					g.setColor(255,0,0);
					g.drawString(mon_damage,8,33,0);
		}
//-----------------------------------------end draw monster attack-----------------------------------
//----------------------------------------draw human special attack----------------------------------
		public void draw_human_special(Graphics g)
		{
				g.setClip(50,40,75,75);
				if(this.prapaimanee.Char == 2)//-----------------------------------------this.prapaimanee.Char = 2
				{
					g.setColor(0,0,255);
					if(special_time == 2)
					{
							g.drawImage(attack.special[0],50,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 3)
					{
							g.drawImage(attack.special[0],-25,45,0);
					}
					else
					if(special_time == 4)
					{
							g.drawImage(attack.special[0],-100,50,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 5)
					{
							g.drawImage(attack.special[0],-175,55,0);
					}
					else
					if(special_time == 6)
					{
							g.drawImage(attack.special[0],-265,25,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if((special_time == 8)||(special_time == 7))
					{
							g.drawImage(attack.special[0],-240,45,0);
					}
					else
					if((special_time == 9)||(special_time == 10))
					{
							g.drawImage(attack.special[0],-260,35,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if((special_time == 11)||(special_time == 12))
					{
							g.drawImage(attack.special[0],-253,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time > 12)
					{
							g.drawImage(attack.special[0],-325,35,0);
					}
				}
				else
				if(this.prapaimanee.Char == 1)//------------------------------this.prapaimanee.Char = 1
				{
					g.setColor(0,0,255);
					if(special_time == 2)
					{
							g.drawImage(attack.special[1],50,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 3)
					{
							g.drawImage(attack.special[1],-25,40,0);
					}
					else
					if(special_time == 4)
					{
							g.drawImage(attack.special[1],-100,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 5)
					{
							g.drawImage(attack.special[1],-175,40,0);
					}
					else
					if(special_time == 6)
					{
							g.drawImage(attack.special[1],-250,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 8)
					{
							g.drawImage(attack.special[1],-325,40,0);
					}
					else
					if(special_time == 9)
					{
							g.drawImage(attack.special[1],-400,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 10)
					{
							g.drawImage(attack.special[1],-475,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 12)
					{
							g.drawImage(attack.special[1],-550,40,0);
					}
					else
					if(special_time == 13)
					{
							g.drawImage(attack.special[1],-400,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 14)
					{
							g.drawImage(attack.special[1],-475,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 15)
					{
							g.drawImage(attack.special[1],-550,40,0);
					}
					else
					if(special_time == 16)
					{
							g.drawImage(attack.special[1],-400,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 17)
					{
							g.drawImage(attack.special[1],-475,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 18)
					{
							g.drawImage(attack.special[1],-550,40,0);
					}
				}
				else
				if(this.prapaimanee.Char == 3)//------------------------------this.prapaimanee.Char = 3
				{
					g.setColor(255,255,0);
					temp_string = Integer.toString(this.prapaimanee.level*5);
					g.drawString(temp_string,8,33,0);
					g.setColor(0,0,255);
					if(special_time == 2)
					{
							g.drawImage(attack.special[2],50,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 3)
					{
							g.drawImage(attack.special[2],-25,40,0);
					}
					else
					if(special_time == 4)
					{
							g.drawImage(attack.special[2],-100,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 5)
					{
							g.drawImage(attack.special[2],-175,40,0);
					}
					else
					if(special_time == 6)
					{
							g.drawImage(attack.special[2],-250,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 8)
					{
							g.drawImage(attack.special[2],-325,30,0);
					}
					else
					if(special_time == 9)
					{
							g.drawImage(attack.special[2],-400,30,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 10)
					{
							g.drawImage(attack.special[2],-475,30,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 12)
					{
							g.drawImage(attack.special[2],-550,30,0);
					}
					else
					if(special_time == 13)
					{
							g.drawImage(attack.special[2],-625,30,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 14)
					{
							g.drawImage(attack.special[2],-700,30,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 15)
					{
							g.drawImage(attack.special[2],-700,20,0);
					}
					else
					if(special_time == 16)
					{
							g.drawImage(attack.special[2],-700,10,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
				}
				else
				if(this.prapaimanee.Char == 0)//------------------------------this.prapaimanee.Char = 3
				{
					g.setColor(0,0,255);
					if((special_time == 2)||(special_time == 3))
					{
							g.drawImage(attack.special[3],50,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if((special_time == 4)||(special_time == 5))
					{
							g.drawImage(attack.special[3],-25,40,0);
					}
					else
					if((special_time == 6)||(special_time == 7))
					{
							g.drawImage(attack.special[3],-100,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if((special_time == 8)||(special_time == 9))
					{
							g.drawImage(attack.special[3],-175,40,0);
					}
					else
					if(special_time == 10)
					{
							g.drawImage(attack.special[3],-250,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 11)
					{
							g.drawImage(attack.special[3],-325,40,0);
					}
					else
					if(special_time == 12)
					{
							g.drawImage(attack.special[3],-400,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 13)
					{
							g.drawImage(attack.special[3],-475,40,0);
							g.drawImage(attack.special[3],-540,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 14)
					{
							g.drawImage(attack.special[3],-250,40,0);
							g.drawImage(attack.special[3],-550,40,0);
					}
					else
					if(special_time == 15)
					{
							g.drawImage(attack.special[3],-325,40,0);
							g.drawImage(attack.special[3],-635,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if(special_time == 16)
					{
							g.drawImage(attack.special[3],-400,40,0);
							g.drawImage(attack.special[3],-625,40,0);
							g.drawString(human_damage,80,100,0);//--------------------damage
					}
					else
					if((special_time == 17)||(special_time == 18))
					{
							g.drawImage(attack.special[3],-550,40,0);
					}
					else
					if(special_time > 19)
					{
							g.drawImage(attack.special[3],-625,40,0);
							
					}
					
					
					
				}
				g.setClip(0,0,w,h);
		}
//-------------------------------------------end draw human special attack------------------------

//-------------------------------------------get human special-----------------------------------------

//---------------------------------------------end get human special---------------------------------
		public int get_human_special()
		{
			int temp_int = ((50*(100-this.prapaimanee.inti))/100);
			int temp_random ;
			do
			{
				temp_random = randomnum.nextInt() % temp_int;
			}while(temp_random < 0);
			if(temp_random > (temp_int/2))
			{
					temp_random = temp_random - (temp_int/2);
					temp_int = temp_random + (this.prapaimanee.human_special*(this.prapaimanee.inti+100))/100;
			}
			else
			{
					temp_int = (this.prapaimanee.human_special*(this.prapaimanee.inti+100))/100 - temp_random;
			}
			human_damage = Integer.toString(temp_int);
			return temp_int;
			
		}

//-------------------------------------start mon run--------------------------------------
		public void mon_run()
		{
			if (warn_time == 15)
			{
				if(temp_mondelay<monster.delay[monster_id])
				{
					temp_mondelay = temp_mondelay + 1;
					////system.out.println(temp_mondelay);
				}
				else
				{
					temp_mondelay = 0;
					mon_attack_time = 1;
					int mon_attack = monster.getdamage(monster_id);
					this.prapaimanee.temp_human_hp = this.prapaimanee.temp_human_hp - mon_attack;
					mon_damage = Integer.toString(mon_attack);
					
				}
				if ((mon_attack_time>0)&&(mon_attack_time<4))
				{
					mon_attack_time = ++mon_attack_time;
					temp_mondelay = 0;
					//xbox = xbox-1-(this.prapaimanee.agi/gain);
				}
				else
				{
					mon_attack_time = 0;
				}
			}
			
		


		}
//-------------------------------------end mon run--------------------------------------
//-----------------------------------------start random mon----------------------------
		public void random_monster(int m,int[] cantx,int[] canty)
		{
			int map = m;
			int num_mon= 0,xmon,ymon;
			boolean can_be_here = true;
			//system.out.println("random monster");
			if(map == 2)
			{
		x2 :	while(num_mon != randommon.max_mon[2])
				{
					can_be_here = true;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					xmon = temp_random;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					ymon = temp_random;
					for(int i = 0 ; i < cantx.length ; i++)
						{
								if((xmon == this.prapaimanee.canvas.m2wx1)&&(ymon==this.prapaimanee.canvas.m2wy1))
								{
									can_be_here = false;
									continue x2;
								}
								else if((xmon == this.prapaimanee.canvas.m2wx2)&&(ymon==this.prapaimanee.canvas.m2wy2))
								{
									can_be_here = false;
									continue x2;
								}
								else if((xmon == this.prapaimanee.canvas.m2wx3)&&(ymon==this.prapaimanee.canvas.m2wy3))
								{
									can_be_here = false;
									continue x2;
								}
								else if((xmon == this.prapaimanee.canvas.m2wx4)&&(ymon==this.prapaimanee.canvas.m2wy4))
								{
									can_be_here = false;
									continue x2;
								}
								else if((cantx[i] == xmon)&&(canty[i] == ymon))
								{
									can_be_here = false;
									continue x2;
								}
						}
					if (can_be_here == true)
					{
						randommon.xm2[num_mon] = xmon;
						randommon.ym2[num_mon] = ymon;
						num_mon = ++num_mon;
					}
				}
			}

			else if(map == 3)
			{
		x3 :	while(num_mon != randommon.max_mon[3])
				{
					can_be_here = true;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					xmon = temp_random;
					do
					{
						temp_random = randomnum.nextInt() % 20;
					}
					while(temp_random < 0);
					ymon = temp_random;
					for(int i = 0 ; i < cantx.length ; i++)
						{
								if((xmon == this.prapaimanee.canvas.m3wx4)&&(ymon==this.prapaimanee.canvas.m3wy4))
								{
									can_be_here = false;
									continue x3;
								}
								else if((xmon == this.prapaimanee.canvas.m3wx2)&&(ymon==this.prapaimanee.canvas.m4wy2))
								{
									can_be_here = false;
									continue x3;
								}
								else if((cantx[i] == xmon)&&(canty[i] == ymon))
								{
									can_be_here = false;
									continue x3;
								}
						}
					if (can_be_here == true)
					{
						randommon.xm3[num_mon] = xmon;
						randommon.ym3[num_mon] = ymon;
						num_mon = ++num_mon;
					}
				}
			}

			else if(map == 4)
			{
		x4 :	while(num_mon != randommon.max_mon[4])
				{
					can_be_here = true;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					xmon = temp_random;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					ymon = temp_random;
					for(int i = 0 ; i < cantx.length ; i++)
						{
								if((xmon == this.prapaimanee.canvas.m4wx2)&&(ymon==this.prapaimanee.canvas.m4wy2))
								{
									can_be_here = false;
									continue x4;
								}
								else if((cantx[i] == xmon)&&(canty[i] == ymon))
								{
									can_be_here = false;
									continue x4;
								}
						}
					if (can_be_here == true)
					{
						randommon.xm4[num_mon] = xmon;
						randommon.ym4[num_mon] = ymon;
						num_mon = ++num_mon;
					}
				}
			}

			else if(map == 5)
			{
		x5 :	while(num_mon != randommon.max_mon[5])
				{
					can_be_here = true;
					do
					{
						temp_random = randomnum.nextInt() % 20;
					}
					while(temp_random < 0);
					xmon = temp_random;
					do
					{
						temp_random = randomnum.nextInt() % 20;
					}
					while(temp_random < 0);
					ymon = temp_random;
					for(int i = 0 ; i < cantx.length ; i++)
						{
								if((xmon == this.prapaimanee.canvas.m5wx4)&&(ymon==this.prapaimanee.canvas.m5wy4))
								{
									can_be_here = false;
									continue x5;
								}
								else if((cantx[i] == xmon)&&(canty[i] == ymon))
								{
									can_be_here = false;
									continue x5;
								}
						}
					if (can_be_here == true)
					{
						randommon.xm5[num_mon] = xmon;
						randommon.ym5[num_mon] = ymon;
						num_mon = ++num_mon;
					}
				}
			}

			else if(map == 6)
			{
		 	while(num_mon != randommon.max_mon[6])
				{
					can_be_here = true;
					do
					{
						temp_random = randomnum.nextInt() % 10;
					}
					while(temp_random < 0);
					xmon = temp_random;
					do
					{
						temp_random = randomnum.nextInt() % 30;
					}
					while(temp_random < 0);
					ymon = temp_random;
					
					if (can_be_here == true)
					{
						randommon.xm6[num_mon] = xmon;
						randommon.ym6[num_mon] = ymon;
						num_mon = ++num_mon;
					}
				}
			}




			
		}
//------------------------------------------end random mon------------------------------


//------------------------------------------------------end battle-----------------------------------
	}
