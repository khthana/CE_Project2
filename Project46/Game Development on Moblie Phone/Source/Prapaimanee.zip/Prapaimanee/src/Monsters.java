//-----------------------------------------------------class monsters--------------------------------
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;

public class Monsters
	{
		
		public Image normal;


					//		0		1	2		3		4		5	6		7		8	9	10			11
		public int[] hp =  {4000  ,2200 ,5000  ,2500  ,300  ,6000  ,1200  ,1500  ,500  ,200  ,2200   ,5000};
public int[] damage =  { 160    ,100   ,240   ,80     ,8    ,300     ,32     ,45      ,12    ,5      ,60       ,550 };
	 public int[] delay = { 30       ,30    ,30     ,30     ,30    ,30    ,30     ,30     ,30     ,30    ,30        ,30};	
   public int[] money = {550    ,350   ,1000   ,400   ,40  ,1200  ,100   ,150    ,50    ,30    ,220        ,0};
		public int[] exp ={500    ,300   ,1000 ,200   ,20    ,1200  ,80     ,100   ,30     ,10     ,150       ,0};

		private Random randomnum;
		private int temp_random;
		public Monsters()
		{
			randomnum = new Random();
			
			try
				{
				//-----------------normal----------------------

					normal = Image.createImage("/monster_pic/normal/pic.png");
					
				
				}
			catch (java.io.IOException e){}
		}
		public int getdamage(int id)
		{
			do
			{
				temp_random = randomnum.nextInt() % (damage[id]/2);
			}while(temp_random<0);
			if(temp_random > (damage[id]/4) )
			{
				temp_random = temp_random - (damage[id]/4);
				temp_random = temp_random + damage[id];
			}
			else
			{
				temp_random = damage[id] - temp_random;
			}
			return temp_random;
		}
		
	}
//------------------------------------------------------end monsters-----------------------------------