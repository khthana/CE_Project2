import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.lang.*;
import java.util.*;



public class Kaewkaesa
{

public Image[] Fai = new Image[12];

public Kaewkaesa ()
	{


		try
			{
			
		Fai[0]=Image.createImage("/k1.png");
		Fai[1]=Image.createImage("/k2.png");
		Fai[2]=Image.createImage("/k3.png");
		Fai[3]=Image.createImage("/k4.png");
		Fai[4]=Image.createImage("/k5.png");
		Fai[5]=Image.createImage("/k6.png");
		Fai[6]=Image.createImage("/k7.png");
		Fai[7]=Image.createImage("/k8.png");
		Fai[8]=Image.createImage("/k9.png");
		Fai[9]=Image.createImage("/k10.png");
		Fai[10]=Image.createImage("/k11.png");
		Fai[11]=Image.createImage("/k12.png");
		
			}
		catch (java.io.IOException e){}
	}

public void draw(Graphics g,int hun,int cb,int cf,int cl,int cr)
	{
		
		switch(hun)
		{

		case 0 : { 
			
			if(cb==0){
			g.drawImage(Fai[0],79,67,0);
			}
			else
			{
			g.drawImage(Fai[2],79,67,0);
			}
			break;
			}
		case 1 : { 	
			if(cf==0){
			g.drawImage(Fai[6],79,67,0);
			}else
			{
			g.drawImage(Fai[8],79,67,0);
			}
			break;}
		case 2 : { 
			if(cl==0){
			g.drawImage(Fai[9],79,67,0);
			}
			else
			{
			g.drawImage(Fai[11],79,67,0);
			}
			break;}

		case 3 :  { 
			if(cr==0){
			g.drawImage(Fai[3],79,67,0);
			}
			else
			{
			g.drawImage(Fai[5],79,67,0);
			}
			break;}
	
	}



	}


};