#ifdef __BORLANDC__
#pragma hdrstop            // borland specific
#include <condefs.h>       
#pragma argsused           
USEUNIT("Tserial.cpp");    
#endif

/* ---------------------------------------------------------------------- */
#include "conio.h"
#include "Tserial.h"



int main(int argc, char* argv[])
{
    char c,i;
   	ofstream text;
    
    Tserial *com;
  
    com = new Tserial();
    if (com!=0)
    {
        com->connect("COM1", 2400, spNONE);

       
        while(true)
        {
            c = com->getChar();
            
           
			if(c=="s"){
			text.open("C:/eclipse-SDK-2.1.2-win32/eclipse/workspace/project1/images/out.txt");
	
			c=com->getChar();
			while(c!="n")
			text<<a;
			text.close();
			}
		
		}

     
      

        // ------------------
        com->disconnect();

        // ------------------
        delete com;
        com = 0;
    }
    return 0;
}

