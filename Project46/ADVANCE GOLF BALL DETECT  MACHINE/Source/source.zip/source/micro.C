#pragma code
#include<reg51.h>
#include<stdio.h>	
#define ON 1
#define OFF 0

sbit D1=P1^0;
sbit D2=P1^1;
sbit D3=P1^2;
sbit D4=P1^3;
sbit D5=P1^4;
sbit D6=P1^5;
sbit D7=P1^6;
sbit D8=P1^7;

sbit V_CONTROL=P0^6;

sbit S1=P2^0;
sbit S2=P2^1;

sbit CONTROL1=P2^2;
sbit A1=P0^0;
sbit B1=P0^1;
sbit C1=P0^2;

sbit CONTROL2=P2^3;
sbit A2=P0^3;
sbit B2=P0^4;
sbit C2=P0^5;

  

void time(unsigned char fiftyms)
{
	unsigned char x;
	for(x=0;x<fiftyms;x++)
	{
		TH0=0xcc;
		TL0=0x00;
		TF0=0;
		TR0=1;
		while(TF0==0);
		TR0=0;
	}
}

void main(void)
{
   	unsigned int data_a;
	unsigned int data_b;
	unsigned int data_a1;
	unsigned int data_b1;
	unsigned char data1;
	unsigned char data2;
	unsigned char t;
	unsigned char n;
	unsigned char h;
	n=10;
	h=13;

        V_CONTROL=ON;
	time(10000);
	V_CONTROL=OFF;
        t=0;
	S1=OFF;
	S2=OFF; 
	SCON=0x52;
	TMOD=0x20;
	TCON=0x69;
        TH1=0xf4;
	CONTROL1=OFF;
	CONTROL2=OFF;
	time(10000);

	
       while(1){
	data_a=0;
	data_b=0;
	data_a1=0;
	data_b1=0;
	if(S1==ON){
	                if(S2==OFF){
				time(1);
				t++;}
				
			
			if(S2==ON){
				
				A1=OFF;
				B1=OFF;
				C1=OFF;
				CONTROL2=OFF;
        			CONTROL1=ON;
				time(100);
				if(D8==ON){
					if(data_a==0)data_a=1;
					data_b=1;
					}
				if(D7==ON){
					if(data_a==0)data_a=2;
					data_b=2;
					}
				if(D6==ON){
					if(data_a==0)data_a=3;
					data_b=3;
					}
				if(D5==ON){
					if(data_a==0)data_a=4;
					data_b=4;
					}
				if(D4==ON){
					if(data_a==0)data_a=5;
					data_b=5;
					}
				if(D3==ON){
					if(data_a==0)data_a=6;
					data_b=6;
					}
 				if(D2==ON){
					if(data_a==0)data_a=7;
					data_b=7;
					}
				if(D1==ON){
					if(data_a==0)data_a=8;
					data_b=8;
					}
				A1=ON;
       				B1=OFF;
				C1=OFF;
        			CONTROL1=ON;
			       	time(100);
				if(D8==ON){
					if(data_a==0)data_a=9;
					data_b=9;
					}
				if(D7==ON){
					if(data_a==0)data_a=10;
					data_b=10;
					}
				if(D6==ON){
					if(data_a==0)data_a=11;
					data_b=11;
					}
				if(D5==ON){
					if(data_a==0)data_a=12;
					data_b=12;
					}
				if(D4==ON){
					if(data_a==0)data_a=13;
					data_b=13;
					}
				if(D3==ON){
					if(data_a==0)data_a=14;
					data_b=14;
					}
 				if(D2==ON){
					if(data_a==0)data_a=15;
					data_b=15;
					}
				if(D1==ON){
					if(data_a==0)data_a=16;
					data_b=16;
					}
				A1=OFF;
				B1=ON;
			      	C1=OFF;
        			CONTROL1=ON;
			       	time(100);
				if(D8==ON){
					if(data_a==0)data_a=17;
					data_b=17;
					}
				if(D7==ON){
					if(data_a==0)data_a=18;
					data_b=18;
					}
				if(D6==ON){
					if(data_a==0)data_a=19;
					data_b=19;
					}
				if(D6==ON){
					if(data_a==0)data_a=20;
					data_b=20;
					}
				if(D4==ON){
					if(data_a==0)data_a=21;
					data_b=21;
					}
				if(D3==ON){
					if(data_a==0)data_a=22;
					data_b=22;
					}
 				if(D2==ON){
					if(data_a==0)data_a=23;
					data_b=23;
					}
				if(D1==ON){
					if(data_a==0)data_a=24;
					data_b=24;
					}
				A1=ON;
				B1=ON;
				C1=OFF;
        			CONTROL1=ON;
			       	time(100);
				if(D8==ON){
					if(data_a==0)data_a=25;
					data_b=25;
					}
				if(D7==ON){
					if(data_a==0)data_a=26;
					data_b=26;
					}
				if(D6==ON){
					if(data_a==0)data_a=27;
					data_b=27;
					}
				if(D5==ON){
					if(data_a==0)data_a=28;
					data_b=28;
					}
				if(D4==ON){
					if(data_a==0)data_a=29;
					data_b=29;
					}
				if(D3==ON){
					if(data_a==0)data_a=30;
					data_b=30;
					}
 				if(D2==ON){
					if(data_a==0)data_a=31;
					data_b=31;
					}
				if(D1==ON){
					if(data_a==0)data_a=32;
					data_b=32;
					}
				A1=OFF;
				B1=OFF;
				C1=ON;
             			CONTROL1=ON;
			       	time(100);
				if(D8==ON){
					if(data_a==0)data_a=33;
					data_b=33;
					}
				if(D7==ON){
					if(data_a==0)data_a=34;
					data_b=34;
					}
				if(D6==ON){
					if(data_a==0)data_a=35;
					data_b=35;
					}
				if(D5==ON){
					if(data_a==0)data_a=36;
					data_b=36;
					}
				if(D4==ON){
					if(data_a==0)data_a=37;
					data_b=37;
					}
				if(D3==ON){
					if(data_a==0)data_a=38;
					data_b=38;
					}
 				if(D2==ON){
					if(data_a==0)data_a=39;
					data_b=39;
					}
				if(D1==ON){
					if(data_a==0)data_a=40;
					data_b=40;
					}
				A1=ON;
			    	B1=OFF;
				C1=ON;
        			CONTROL1=ON;
			       	time(100);
				if(D8==ON){
					if(data_a==0)data_a=41;
					data_b=41;
					}
				if(D7==ON){
					if(data_a==0)data_a=42;
					data_b=42;
					}
				if(D6==ON){
					if(data_a==0)data_a=43;
					data_b=43;
					}
				if(D5==ON){
					if(data_a==0)data_a=44;
					data_b=44;
					}
				if(D4==ON){
					if(data_a==0)data_a=45;
					data_b=45;
					}
				if(D3==ON){
					if(data_a==0)data_a=46;
					data_b=46;
					}
 				if(D2==ON){
					if(data_a==0)data_a=47;
					data_b=47;
					}
				if(D1==ON){
					if(data_a==0)data_a=48;
					data_b=48;
					}

				A1=OFF;
				B1=ON;
				C1=ON;
       			     	CONTROL1=ON;
				time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=1;
					data_b1=1;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=2;
					data_b1=2;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=3;
					data_b1=3;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=4;
					data_b1=4;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=5;
					data_b1=5;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=6;
					data_b1=6;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=7;
					data_b1=7;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=8;
					data_b1=8;
					}

				A1=ON;
				B1=ON;
				C1=ON;
			  	CONTROL1=ON;
			       	time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=9;
					data_b1=9;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=10;
					data_b1=10;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=11;
					data_b1=11;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=12;
					data_b1=12;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=13;
					data_b1=13;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=14;
					data_b1=14;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=15;
					data_b1=15;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=16;
					data_b1=16;
					}
				
				CONTROL1=OFF;
				CONTROL2=ON;
				A2=OFF;
				B2=OFF;
				C2=OFF;
				time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=17;
					data_b1=17;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=18;
					data_b1=18;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=19;
					data_b1=19;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=20;
					data_b1=20;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=21;
					data_b1=21;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=22;
					data_b1=22;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=23;
					data_b1=23;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=24;
					data_b1=25;
					}
				
				A2=ON;
				B2=OFF;
				C2=OFF;
				time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=25;
					data_b1=25;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=26;
					data_b1=26;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=27;
					data_b1=27;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=28;
					data_b1=28;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=29;
					data_b1=29;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=30;
					data_b1=30;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=31;
					data_b1=31;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=32;
					data_b1=32;
					}
				A2=OFF;
				B2=ON;
				C2=OFF;
				time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=33;
					data_b1=33;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=34;
					data_b1=34;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=35;
					data_b1=35;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=36;
					data_b1=36;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=37;
					data_b1=37;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=38;
					data_b1=38;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=39;
					data_b1=39;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=40;
					data_b1=40;
					}
				
				A2=ON;
				B2=ON;
				C2=OFF;
				time(100);
				if(D1==ON){
					if(data_a1==0)data_a1=41;
					data_b1=41;
					}
				if(D2==ON){
					if(data_a1==0)data_a1=42;
					data_b1=42;
					}
				if(D3==ON){
					if(data_a1==0)data_a1=43;
					data_b1=43;
					}
				if(D4==ON){
					if(data_a1==0)data_a1=44;
					data_b1=44;
					}
				if(D5==ON){
					if(data_a1==0)data_a1=45;
					data_b1=45;
					}
				if(D6==ON){
					if(data_a1==0)data_a1=46;
					data_b1=46;
					}
 				if(D7==ON){
					if(data_a1==0)data_a1=47;
					data_b1=47;
					}
				if(D8==ON){
					if(data_a1==0)data_a1=48;
					data_b1=48;
					}

				V_CONTROL=ON;
			
				time(200);
				V_CONTROL=OFF;
				S1=OFF;
				S2=OFF;
				data_a=data_a+data_b;
				data_a1=data_a1+data_b1;
				data1=(char)data_a;
				data2=(char)data_a1;
//				t=11;
//				data2=60;
//				data1=45;
				printf("s");
				printf("%d",0,t);
				printf("u");
                           	printf("%d",0,data1);
				printf("u");
                               	printf("%d",0,data2);
//				printf("u");
                               	printf("n");
				t=0;

				}
			
		}
	}		

}
