#ifdef __BORLANDC__
#pragma hdrstop            // borland specific
#include <condefs.h>
#pragma argsused           
USEUNIT("Tserial.cpp");    
#endif

/* ---------------------------------------------------------------------- */
#include "conio.h"
#include "Tserial.h"
#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;  



int main(int argc, char* argv[])
{
    char c;
	ofstream text;
    int i,j,b1,b2,b3;
	int bu1,e1,e2,e3;
	int bu2,t1,t2,t3;
	int bu3,g1,g2,g3;
    Tserial *com;
  
    com = new Tserial();
    if (com!=0)
    {
        com->connect("COM1", 2400, spNONE);

         
        while(true)
        {
            c = com->getChar();
            
           
			if(c=='s')
			{
				
				i=0;j=0;bu1=0;bu2=0;bu3=0;
			
				c=com->getChar();
				while(c!='n')
				{	
					if(c=='u')
					{
						i++;
						j=0;
					}
					if(i==0)
					{
						if(j==0)
							e1=(int)c;
						if(j==1)
							e2=(int)c;
						if(j==2)
							e3=(int)c;
						bu1=j;
						j++;
						
					}
					if(i==1)
					{
						if(j==0)
							t1=(int)c;
						if(j==1)
							t2=(int)c;
						if(j==2)
							t3=(int)c;
						bu2=j;
						j++;
						
					}
					if(i==2)
					{
						if(j==0)
							g1=(int)c;
						if(j==1)
							g2=(int)c;
						if(j==2)
							g3=(int)c;
						bu3=j;
						j++;
						
					}

					c=com->getChar();
				}
				if(bu1==2)
				{
					b1=e1*100;
					b1=b1+e2*10;
					b1=b1+e3;
				}
				if(bu1==1)
				{
					b1=b1+e1*10;
					b1=b1+e2;
				}
				if(bu1==0)
				{
					b1=b1+e1;
				}
				if(bu2==2)
				{
					b2=t1*100;
					b2=b2+t2*10;
					b2=b2+t3;
				}
				if(bu2==1)
				{
					b2=b2+t1*10;
					b2=b2+t2;
				}
				if(bu2==0)
				{
					b2=b2+t1;
				}
				if(bu3==2)
				{
					b3=g1*100;
					b3=b3+g2*10;
					b3=b3+g3;
				}
				if(bu3==1)
				{
					b3=b3+g1*10;
					b3=b3+g2;
				}
				if(bu3==0)
				{
					b3=b3+g1;
				}
				text.open("C:/WINDOWS/Desktop/workspace/project1/images/out.txt");
				cout<<b1<<endl<<b2<<endl<<b3<<endl;
				text.close;
			
			}

		}

        // ------------------
        com->disconnect();

        // ------------------
        delete com;
        com = 0;
    }
    return 0;
}

