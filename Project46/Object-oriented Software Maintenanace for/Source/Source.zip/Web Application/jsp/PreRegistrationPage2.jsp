<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.*" %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Database.connect();
	Student student = (Student)session.getAttribute("StudentInfo");
	Registration registration = (Registration)session.getAttribute("Registration");
	Semester semester = (Semester)session.getAttribute("Semester");
	java.util.Date currentDate = (java.util.Date)session.getAttribute("CurrentDate");
/*	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandlePreRegister hPreregister = (HandlePreRegister)session.getAttribute("PreRegister");
	hPreregister.clearAllRegister();*/
	String errorMessage = "";
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr>
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/preregistration.gif" width="425" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr>
    <td height="17" bgcolor="#FFCC66" width="67%" align="center"> <font class="normal1"><b>����
      - ���ʡ��</b> <%= student.getStudentTname() %></font> <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= student.getStudentID() %></font>
      <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b>
      <%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
	%>
      </font> <br>
        <font class="normal1"><%= (student.getMinor().getTname() == null) ? "" : "<b>ᢹ��Ԫ�</b> " + student.getMinor().getTname() %></font>
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= student.getMajor() %></font>
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= student.getMajor().getDepartment().getTname() %></font>
        <font class="normal1"><b>���&nbsp;</b><%= student.getMajor().getDepartment().getFaculty().getTname() %></font>
    </td>
  </tr>
  <tr>
    <td width="67%" height="13">&nbsp;</td>
  </tr>
  <tr>
    <td height="495" align="center" valign="top" bordercolor="#000000" width="67%">
  <table width="600" border="0" align="center" height="203">
    <tr>
      <td height="247">
            <div align="center"><font class="headline4"><b>����Ԫҷ��������ŧ����¹</b></font></div>
		<br>
            <table width="100%" border="2" cellspacing="2" cellpadding="5" bgcolor="#E3EFFB" bordercolor="#CCCCCC"align="center" height="100">
              <tr bgcolor="#FFFF99" align="center"> 
                <td width="57" align="center" height="56" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="262" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="67" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                </td>
                <td width="61" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>૤���</b></font></div>
                </td>
                <td width="81" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>������</b></font></div>
                </td>
              </tr>
              <%
                      	int allCredit = 0;
	int showCredit = 0;
	int credit = 0;
  	int normMaxCredit = 15;
  	int normMinCredit = 9;
  	int summerMaxCredit = 6;
	Subject subject = new Subject();
      	student.setCurrentRegistration(new Vector());
	Section section = new Section();

                     	 for(int i=0; i<8; i++)
                     	 {
                         	String subjectID = request.getParameter("subId" + Integer.toString(i + 1));

                              if(!subjectID.equals(""))
                              {
         		Registration r = new Registration();
                                      try
                                      {
                                      	String sec = Integer.toString(Integer.parseInt(request.getParameter("subSec"+Integer.toString(i + 1)).trim()));

		subject = subject.retrieveSubject(subjectID.trim(),student.getMajor());
        		int si = Integer.parseInt(sec);
	        	section = subject.getSection(si);
        		r.setStudent(student);
        		r.setSection(section);
        		r.setSemester(semester);
        		r.setRegisterType(new RegisterType(1));
		String str = request.getParameter("subType"+Integer.toString(i + 1));
		if (str.trim().equals("Credit")) r.setType("Cr");
                		else if (str.trim().equals("NonCredit")) r.setType("Nc");
		else r.setType("Au");
        		r.setGrade("X");
        		r.setPayDate(currentDate);
        		r.setRegistrar(new Registrar());

      		if (subject.getSection() == null) {
			Section errSec = new Section();
			errSec.setSubject(subject);
                        			r.setSection(errSec);
                			errorMessage = "������硪��";
                                              		session.setAttribute("errorMessage", errorMessage);
                                              		session.setAttribute("errorRegister", r);
                                              		response.sendRedirect("ErrorSection.jsp");
		        	return;
		}
                                      }
                                      catch(NumberFormatException nfex)
                                      {
        		r.setStudent(student);
		section.setSec(0);
        		r.setSection(section);
        		r.setSemester(semester);
        		r.setRegisterType(new RegisterType(2));
        		r.setType(request.getParameter("subType"+Integer.toString(i + 1)));
        		r.setGrade("X");
        		r.setPayDate(currentDate);
        		r.setRegistrar(new Registrar());
                                              	errorMessage = "����硪�����١��ͧ";
                                              	session.setAttribute("errorMessage", errorMessage);
                                              	session.setAttribute("errorRegister", r);
                                              	response.sendRedirect("ErrorSection.jsp");
                                              	return;
                                      }
                                      catch(Exception nfex)
                                      {
        		r.setStudent(student);
		section.setSec(0);
        		r.setSection(section);
        		r.setSemester(semester);
        		r.setRegisterType(new RegisterType(2));
        		r.setType(request.getParameter("subType"+Integer.toString(i + 1)));
        		r.setGrade("X");
        		r.setPayDate(currentDate);
        		r.setRegistrar(new Registrar());
                                              	errorMessage = "��س�����硪�����١��ͧ";
                                              	session.setAttribute("errorMessage", errorMessage);
                                              	session.setAttribute("errorRegister", r);
                                              	response.sendRedirect("ErrorSection.jsp");
                                              	return;
                                      }

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        if (r.isRegistered(student,subject)){
                                              errorMessage = "��ҹ��ŧ����Ԫҹ��������";
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
          return;
        }
        if (subject.checkPrerequisite(subject) && !r.isPrerequisiteRegistered(student,subject)){
                                              errorMessage = "�ԪҴѧ������� Prerequisite �ô��Ǩ�ͺ����Ԫҷ���Դ�͹�ա����";
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
          return;
        }
        if (student.checkSectionConflict(section)){
                                              errorMessage = "�������¹���������ͺ���ѹ �������öŧ����¹��";
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
          return;
        }
        if (!section.checkAvailable()){
          String str = "����Ԫ�" + section.getSubject().getSubjectTname() + " �硪�� " + section.getSec() + "\n";
          str += "�չѡ�֡��ŧ�ú�ӹǹ����";
                                              errorMessage = str;
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
          return;
        }
        credit = subject.getCredit() + student.sumRegistrationUnit();
        if (semester.getSemesterType() == 1){
          if (credit > normMaxCredit) {
                                              errorMessage = "�ӹǹ˹��¡Ե����ҡ�Թ�";
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
            return;
          }
        }
        else {
          if (credit > summerMaxCredit) {
                                              errorMessage = "�ӹǹ˹��¡Ե����ҡ�Թ�";
                                              session.setAttribute("errorMessage", errorMessage);
                                              session.setAttribute("errorRegister", r);
                                              response.sendRedirect("ErrorSection.jsp");
            return;
          }
        }
                                      // display
                                      out.println(
                                      "<tr>" +
                                      "<td align=\"center\" bgcolor=\"#E3EFFB\" valign=\"top\" width=\"13%\" height=\"30\"><font class=\"normal1\">" + request.getParameter("subId"+Integer.toString(i + 1)) + "</font></td>"+
                                      "<td bgcolor=\"#E3EFFB\" valign=\"top\" width=\"70%\" height=\"30\"><font class=\"normal1\">" + request.getParameter("subName"+Integer.toString(i + 1)) + "</font></td>" +
                                      "<td bgcolor=\"#E3EFFB\" valign=\"top\" width=\"15%\" height=\"30\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subCredit"+Integer.toString(i + 1)) + "</font></div></td>" +
                                      "<td bgcolor=\"#E3EFFB\" width=\"6%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subSec"+Integer.toString(i + 1)) + "</font></div></td>" +
                                      "<td bgcolor=\"#E3EFFB\" width=\"17%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subType"+Integer.toString(i + 1)) + "</font></div></td>" +
                                      "</tr>");
              	student.addCurrentRegistration(r);
                              }// End if(!subjectID.equals(""))
                      } //End for

      // check min, max credit

      if (semester.getSemesterType() == 1){
        if (student.sumRegistrationUnit() < normMinCredit){
        		Registration r = null;
                                                      	errorMessage = "�ӹǹ˹��¡Ե��������Թ�";
                                                      	session.setAttribute("errorMessage", errorMessage);
                                                      	session.setAttribute("errorRegister", r);
                                                      	response.sendRedirect("ErrorSection.jsp");
          return;
        }
      }
      //insert into Registration Table------------------------------------------------------------------------------------------------------------------------------

/*      Vector regVector = student.getCurrentRegistration();
      Enumeration regEnum = regVector.elements();
      while (regEnum.hasMoreElements()){
        Registration reg = (Registration)regEnum.nextElement();
        reg.getSection().incrementStudent(reg.getSection());
        reg.insertRegistration(reg);
      }*/
      Database.disconnect();

      session.setAttribute("credit",Integer.toString(credit));
/*              if(!hPreregister.checkMinMaxCredit(allCredit))
              {
                      errorMessage = "˹��¡Ԩ�������ͧ���ŧ����¹����Ԫҹ��������ҡ�Թ�";
                      session.setAttribute("errorMessage", errorMessage);
                      session.setAttribute("errorRegister", null);

                      response.sendRedirect("ErrorSection.jsp");
                      return;
              }

              session.setAttribute("showCredit", Integer.toString(showCredit));*/

       %>
              <tr bordercolor="#FFFFCC"> 
                <td colspan="2" valign="top" align="center" bgcolor="#6699CC" height="34" bordercolor="#CCCCCC"> 
                  <div align="right"><font class="headline2"><b>���</b></font></div>
                </td>
                <td valign="top" bgcolor="#6699CC" bordercolor="#CCCCCC"> 
                  <div align="center"><font class="headline2"><b><%= Integer.toString(credit) %></b></font></div>
                </td>
                <td colspan="2" valign="top" bgcolor="#6699CC" bordercolor="#CCCCCC"><font class="headline2"><b>˹��¡Ե</b></font></td>
              </tr>
            </table>
        <div align="right">
		<form name="form1" method="post" action="PreRegistrationPage3.jsp">
            <input type="submit" name="Next" value=" ���� ">
            <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-1)">
        </form>
        </div>
      </td>
    </tr>
  </table>
    </td>
  </tr>
  <tr>
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
