<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.* " %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<%
	Student student = (Student)session.getAttribute("StudentInfo");
	Registration registration = (Registration)session.getAttribute("Registration");
/*	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandlePreRegister hPreregister = (HandlePreRegister)session.getAttribute("PreRegister");
*/
	Subject subject = new Subject();
	Database.connect();
	subject.writeAllSubjectToJavaScriptFile(student.getMajor());
	Database.disconnect();
%>

<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<script language="javascript" src="/Script/Script.js">
</script>
<script language="javascript">
	function search(id)
	{
		for(var i=0; i<subjectId.length; i++)
		{
			if(subjectId[i] == id)
			{
				return i;
			}
		}

		return -1;
	}

	function getId(i)
	{
		return subjectId[i];
	}

	function getName(i)
	{
		return subjectName[i];
	}

	function getCredit(i)
	{
		return subjectCredit[i];
	}

	function isDuplicate(subjId1,subjId2)
	{
		return ((subjId1.value == subjId2.value) && (subjId1.name != subjId2.name)) ? true : false;
	}

	function restoreName(subjId,subjName)
	{
		i = search(subjId.value);
		if(i != -1)
		{
			subjName.value = getName(i);
		}
		else
		{
			subjName.value = "";
		}
	}

	function restoreCredit(subjId,subjCredit)
	{
		i = search(subjId.value);
		if(i != -1)
		{
			subjCredit.value = getCredit(i);
		}
		else
		{
			subjCredit.value = "";
		}
	}

	function checkSection(subjId,subjName,subjCredit,subjSec,subjType)
	{
		var length = subjId.value.length;
		if(length != 8)
		{
			subjId.value = "";
			subjName.value = "";
			subjCredit.value = "";
			subjSec.value = "1";
			subjType.value = "Credit";
		}
		else
		{
			if(isDuplicate(subjId,form.subId1) ||
			   isDuplicate(subjId,form.subId2) ||
			   isDuplicate(subjId,form.subId3) ||
			   isDuplicate(subjId,form.subId4) ||
			   isDuplicate(subjId,form.subId5) ||
			   isDuplicate(subjId,form.subId6) ||
			   isDuplicate(subjId,form.subId7) ||
			   isDuplicate(subjId,form.subId8))
			{
				alert("�����Ԫҫ�� ��سһ�͹�����Ԫ�����");
				subjId.value = "";
				subjName.value = "";
				subjCredit.value = "";
				subjSec.value = "1";
				subjType.value = "Credit";
			}
			else
			{
				i = search(subjId.value);
				if(i != -1)
				{
					subjName.value = getName(i);
					subjCredit.value = getCredit(i);
				}
				else
				{
					subjId.value = "";
					subjName.value = "";
					subjCredit.value = "";
					subjSec.value = "1";
					subjType.value = "Credit";
				}
			}
		}
	}
</script>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507">
  <tr>
      <td height="19" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/preregistration.gif" width="425" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr>
    <td height="17" bgcolor="#FFCC66" width="67%" align="center"> <font class="normal1"><b>����
      - ���ʡ��</b> <%= student.getStudentTname() %> </font> <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= student.getStudentID() %></font>
      <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b>
      <%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
	%>
      </font> <br>
        <font class="normal1"><%= (student.getMinor().getTname() == null) ? "" : "<b>ᢹ��Ԫ�</b> " + student.getMinor().getTname() %></font>
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= student.getMajor().getTname() %></font>
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= student.getMajor().getDepartment().getTname() %></font>
        <font class="normal1"><b>���&nbsp;</b><%= student.getMajor().getDepartment().getFaculty().getTname() %></font>
    </td>
  </tr>
  <tr>
    <td align="center" height="48" valign="middle">
      <div align="center"><font class="headline4"><b>���͡��¡��ŧ����¹���¹</b></font></div>
    </td>
  </tr>
  <tr>
    <td height="453" align="center" valign="top" bordercolor="#000000" width="67%">
      <form method="post" action="PreRegistrationPage2.jsp" name="form">
        <table width="600" border="0" align="center" class="normaldetail">
          <tr>
            <td height="225" colspan="2">
              <table width="85%" border="1" cellspacing="2" cellpadding="5" align="center" bgcolor="#E3EFFB" bordercolor="#CCCCCC">
                <tr align="center">
                  <td width="11%" align="center" height="40" bgcolor="#6699CC">
                    <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                  </td>
                  <td width="56%" height="40" bgcolor="#6699CC">
                    <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                  </td>
                  <td width="10%" height="40" bgcolor="#6699CC">
                    <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                  </td>
                  <td width="6%" height="40" bgcolor="#6699CC">
                    <div align="center"><font class="headline2"><b>૤���</b></font></div>
                  </td>
                  <td width="17%" height="40" bgcolor="#6699CC">
                    <div align="center"><font class="headline2"><b>������</b></font></div>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="20">
                    <input type="text" name="subId1" maxlength="8" size="8" value = "" onBlur=checkSection(form.subId1,form.subName1,form.subCredit1,form.subSec1,form.subType1)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="20">
                    <input readonly="true" type="text" name="subName1" size="60" value = "" style="thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="20">
                    <input readonly="true" type="text" name="subCredit1" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="20" valign="bottom">
                    <input type="text" name="subSec1" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="20" valign="bottom">
                    <select name="subType1">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="28">
                    <input type="text" name="subId2" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId2,form.subName2,form.subCredit2,form.subSec2,form.subType2)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="28">
                    <input readonly="true" type="text" name="subName2" size="60" value = "" style="thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="28">
                    <input readonly="true" type="text" name="subCredit2" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="28" valign="bottom">
                    <input type="text" name="subSec2" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="28" valign="bottom">
                    <select name="subType2">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId3" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId3,form.subName3,form.subCredit3,form.subSec3,form.subType3)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName3" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit3" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec3" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType3">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId4" size="8" maxlength="8"value = "" onBlur=checkSection(form.subId4,form.subName4,form.subCredit4,form.subSec4,form.subType4)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName4" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit4" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec4" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType4">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId5" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId5,form.subName5,form.subCredit5,form.subSec5,form.subType5)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName5" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit5" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec5" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType5">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId6" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId6,form.subName6,form.subCredit6,form.subSec6,form.subType6)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName6" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit6" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec6" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType6">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId7" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId7,form.subName7,form.subCredit7,form.subSec7,form.subType7)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName7" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit7" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec7" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType7">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="center" bgcolor="#E3EFFB" valign="top" width="11%" height="30">
                    <input type="text" name="subId8" size="8" maxlength="8" value = "" onBlur=checkSection(form.subId8,form.subName8,form.subCredit8,form.subSec8,form.subType8)>
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="56%" height="30">
                    <input readonly="true" type="text" name="subName8" size="60" value="" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" valign="top" width="10%" height="30">
                    <input readonly="true" type="text" name="subCredit8" size="5" value = "" style=" thin solid;COLOR:#000000;BACKGROUND-COLOR: #FFFFFF;">
                  </td>
                  <td bgcolor="#E3EFFB" width="6%" height="30" valign="bottom">
                    <input type="text" name="subSec8" size="3" value="1">
                  </td>
                  <td bgcolor="#E3EFFB" width="17%" height="30" valign="bottom">
                    <select name="subType8">
                      <option value="Credit">Credit</option>
                      <option value="NonCredit">NonCredit</option>
                      <option value="Audit">Audit</option>
                    </select>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td height="50" valign="bottom">
              <li ><font class="normal1"><a href="ReviewCoursePage.jsp" target="_blank">����Ԫҷ���Դ�͹</a></font></li>
			  <li><font class="normal1"><a href="RegisConstraint.html" target="_blank">���͹䢡��ŧ����¹</a></font></li>
            </td>
            <td height="50" align="right" valign="bottom">
              <input type="submit" name="Submit" value="   ����   ">
              <input type="reset" name="Reset" value="   ¡��ԡ   ">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
  <tr>
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
