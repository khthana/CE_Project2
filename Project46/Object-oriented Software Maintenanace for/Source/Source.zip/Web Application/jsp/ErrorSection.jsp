<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, graduate.*"  %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Student student = (Student)session.getAttribute("StudentInfo");
	Registration errorRegister = (Registration)session.getAttribute("errorRegister");
	String errorMessage = (String)session.getAttribute("errorMessage");
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
    <td height="14" colspan="5" bgcolor="#000000"> <font class="headline1"> <b> 
      King Mongkut's Institute of Technology Ladkrabang </b> </font> </td>
  </tr>
  <tr> 
    <td rowspan="6" align="center" valign="top" width="103">&nbsp;</td>
    <td height="46" align="center" valign="bottom" colspan="3"><img src="images/registration.gif" width="227" height="57"></td>
    <td rowspan="6" width="214">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFCC66" colspan="3" align="center"> <font class="normal1"><b>���� 
      - ���ʡ��</b> <%= student.getStudentTname() %></font> <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= student.getStudentID() %></font> 
      <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b> 
      <%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
	%>
      </font> <br>
      <font class="normal1"><%= (student.getMinor().getTname() == null) ? "" : "<b>ᢹ��Ԫ�</b> " + student.getMinor().getTname() %></font> 
      <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= student.getMajor() %></font> 
      <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= student.getMajor().getDepartment().getTname() %></font> 
      <font class="normal1"><b>���&nbsp;</b><%= student.getMajor().getDepartment().getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td colspan="3" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td height="2" width="28"></td>
    <td width="592"></td>
    <td width="29"></td>
  </tr>
  <tr>
    <td height="489"></td>
    <td valign="top" align="center" bordercolor="#000000"> 
      <table width="600" border="0" align="center" height="203">
        <tr> 
          <td height="247"> 
            <div align="center"><font class="warning2"><b>* <%= errorMessage %> 
              *</b></font></div>
            <br>
            <table width="100%" border="2" cellspacing="2" cellpadding="5" bgcolor="#E3EFFB" bordercolor="#CCCCCC" align="center" height="100">
              <tr align="center"> 
                <td width="12%" align="center" height="54" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="289" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="70" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                </td>
                <td width="44" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>�硪��</b></font></div>
                </td>
                <td width="59" valign="middle" bgcolor="#6699CC"> 
                  <div align="center"><font class="headline2"><b>������</b></font></div></td>
              </tr>
              <%
					if(errorRegister != null && errorRegister.getSection() != null)
					{
						/* display error register */
						out.println(
						"<tr>" +
						"<td align=\"center\" bgcolor=\"#E3EFFB\" valign=\"top\" width=\"12%\" height=\"30\"><font class=\"normal1\">" + errorRegister.getSection().getSubject().getSubjectID() + "</font></td>"+
						"<td bgcolor=\"#E3EFFB\" valign=\"top\" width=\"56%\" height=\"30\"><font class=\"normal1\">" + errorRegister.getSection().getSubject().getSubjectEname() + "</font></td>" +
						"<td bgcolor=\"#E3EFFB\" valign=\"top\" width=\"10%\" height=\"30\"><div align=\"center\"><font class=\"normal1\">" + errorRegister.getSection().getSubject().getCredit() + "</font></div></td>" +
						"<td bgcolor=\"#E3EFFB\" width=\"10%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + errorRegister.getSection().getSec() + "</font></div></td>" +
						"<td bgcolor=\"#E3EFFB\" width=\"10%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + errorRegister.getType() + "</font></div></td>" +

						"</tr>");
					}
			  %>
              <tr bordercolor="#FFFFCC" bgcolor="#6699CC"> 
                <td align="left" valign="top" colspan="5" bordercolor="#CCCCCC" height="36">&nbsp;</td>
              </tr>
            </table>
            <div align="center"> 
              <form name="form1" method="post" action="PreRegistrationPage3.jsp">
                <p>&nbsp;</p>
                <p>
                  <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-1)">
                </p>
              </form>
            </div>
          </td>
        </tr>
        <tr> 
          <td height="238"></td>
        </tr>
      </table>
    </td>
  <td></td>
  </tr>
  <tr>
    <td height="26"></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
