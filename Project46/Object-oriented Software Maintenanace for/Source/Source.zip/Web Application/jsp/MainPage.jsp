<%@ page import= "java.sql.*, java.util.*, java.io.*, graduate.*" %>
<%@ page contentType= "text/html;charset=WINDOWS-874" %>
<%@ page session= "true" %>
<%@ include file = "checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ˹����ѡ</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">

<script language="javascript">
	function MM_jumpMenu(targ,selObj)
	{
		eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
		selObj.selectedIndex=0;
	}
</script>

</head>

<body bgcolor="#FFFFFF">
<%
	Database.connect();
	Student student = (Student)session.getAttribute("StudentInfo");
	Semester semester = new Semester();
	semester = semester.retrieveCurrentSemester();
	Appointment appointment = new Appointment();
	Vector av = new Vector();
	av = appointment.retrieveAppointment(semester);
	Registration registration = new Registration();
	java.util.Date date = new java.util.Date();
	session.setAttribute("Semester",semester);
	session.setAttribute("Appointment",appointment);
	session.setAttribute("Registration",registration);
	session.setAttribute("CurrentDate",date);
%>
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507">
    <tr>
    <td height="19" colspan="3" bgcolor="#000000">
	<font class="headline5">
	<b>
    		King Mongkut's Institute of Technology Ladkrabang
	</b>
	</font>
	</td>
  </tr>
  <tr bgcolor="#000000">
    <td colspan="3" height="46"><img src="images/background.gif" width="100%" height="42"></td>
  </tr>
  <tr>
    <td rowspan="9" height="367" align="center" valign="top" width="16%"><img src="images/logo-kmitl.gif" width="139" height="137"></td>
    <td width="53%" height="76" align="center" valign="top"><img src="images/logo-2.gif" width="496" height="85"></td>
    <td rowspan="9" height="338" width="31%">&nbsp;</td>
  </tr>
  <tr>
    <td width="53%" height="24" bgcolor="#FFCC66">
      <div align="center"><font class="warning2">
        <b>
      <%
      boolean preExpire = appointment.checkInTime(new RegisterType(1),semester);
      boolean preRegistered = registration.isRegister(student,semester,new RegisterType(1));
      boolean regExpire = appointment.checkInTime(new RegisterType(2),semester);
      boolean regRegistered = registration.isRegister(student,semester,new RegisterType(2));
      int isNorm = student.getStatus();

      if(isNorm != 1)
      {
              out.println("��ҹ�������öŧ����¹�� ��سҵԴ��ͽ��·���¹�´�ǹ");
      }
      else if(!preExpire && !preRegistered)
      {
              out.println("����㹪�ǧ���ŧ����¹��ǧ˹��");
      }
      else if(!regExpire && !regRegistered)
      {
              out.println("����㹪�ǧ���ŧ����¹����");
      }
      else if(!preExpire && preRegistered)
      {
              out.println("��ҹ��ӡ��ŧ����¹��ǧ˹�������");
      }
      else if(!regExpire && regRegistered)
      {
              out.println("��ҹ��ӡ��ŧ����¹���������");
      }
      else
      {
              out.println("����ش��ǧ���ҡ��ŧ����¹");
      }
      %>
       </b>
	   </font> </div>
    </td>
  </tr>
  <tr>
    <td width="53%" height="3"> </td>
  </tr>
  <tr>
    <td width="53%" height="51" bgcolor="#FFCC66">
      <div align="center">
	  <font class="normal1"><b>���� - ���ʡ��</b></font>
	  <span class="normal1"><%= student.getStudentTname() %></span>
	  <font class="normal1"><b>����</b></font>
      <span class="normal1"><%= student.getStudentID() %></span><br>
      <font class="normal1"><b>�Ҥ�Ԫ�</b></font>
      <span class="normal1"><%= student.getMajor().getDepartment().getTname() %></span>
	  <font class="normal1"><b>���</b></font>
      <span class="normal1"><%= student.getMajor().getDepartment().getFaculty().getTname() %></span>
	  </div>
    </td>
  </tr>
  <tr>
    <td width="53%" height="6">&nbsp;</td>
  </tr>
  <tr>
    <td width="53%" height="24" bgcolor="#6699CC" align="center" valign="middle" bordercolor="#FF0000">
      <div align="center"><b><font class="headline3">���ǻ�С��</font></b></div>
    </td>
  </tr>
  <tr>
    <td width="53%" height="52">
      <ul>
        <li><font class="normal1"><a href="StepRegistration.jsp">��鹵͹���ŧ����¹ - �ѳ�Ե�Է�����</a></font></li>
        <li><font class="normal1">��õ�Ǩ�ͺ�Է�����ŧ����¹�ͧ�ѡ�֡������� - �ѳ�Ե�֡�� ��������</font></li>
      </ul>
    </td>
  </tr>
  <tr>
    <td width="53%" height="24" bgcolor="#6699CC">
      <div align="center"><b><font class="headline3">��ǹ���ʹ�ȹѡ�֡��</font></b></div>
    </td>
  </tr>
  <tr>
    <td height="133" width="53%">
      <ul>
        <li><font class="normal1"><a href="EditStudentInfoPage.jsp" target="_blank">��������ǹ���</a></font></li>
        <li>
			<font class="normal1">�š���֡��
			<select  name="menu1" onChange="MM_jumpMenu('parent',this)">
				<option value="#" selected>���͡�Ҥ����֡��</option>
				<%
						Vector vr = registration.retrieveSemesterRegistered(student);
						Enumeration er = vr.elements();

						while(er.hasMoreElements())
						{
							Semester sr = (Semester)er.nextElement();
							out.println("<option value=\"ReviewGradePage.jsp?semid=" + sr.getSemesterID() + "&sem=" + sr.getSemester() + "&year=" + sr.getYear() + "\">" + sr.getSemester() + "/" + sr.getYear() + "</otpion>");
						}
                              	Database.disconnect();
				%>
	            <option value="ReviewGradePage.jsp?sem=all">������</option>
			</select>
			</font>
		</li>
        <li><font class="normal1">���ҧ���¹ ��� ���ҧ�ͺ</font></li>
        <li><font class="normal1"><a href="ReviewCoursePage.jsp" target="_blank">����Ԫҷ���Դ�͹</a></font></li>
        <%
                if (isNorm == 1)
                {
                        if(!preExpire && !preRegistered)
                                out.println( "<li><font class=\"normal1\"><a href=\"PreRegistrationPage1.jsp\">"+"\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E25\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32</a></font></li>");
                        else if(!regExpire && !regRegistered)
                                out.println("<li><font class=\"normal1\"><a href=\"RegistrationPage1.jsp\">"+"\u0E25\u0E07\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19</a></font></li>");
                        else if(regRegistered)
                                out.println("<li><font class=\"normal1\"><a href=\"PrintRegisterData.jsp\" target=\"_blank\">" + "������͡��á��ŧ����¹</a></font></li>");
                }
      %>
        <li>
			<font class="normal1">Ẻ���������ͧ
				<select  name="menu2" onChange="MM_jumpMenu('parent',this)">
					<option value="#" selected>���͡Ẻ���������ͧ</option>
					<option value="FillForm.jsp">����ͧ�����</option>
		        </select>
			</font>
        </li>
        <li><font class="normal1"><a href="Logout.jsp">��ԡ�����ҹ</a></font></li>
      </ul>
    </td>
  </tr>
</table>
</body>
</html>
