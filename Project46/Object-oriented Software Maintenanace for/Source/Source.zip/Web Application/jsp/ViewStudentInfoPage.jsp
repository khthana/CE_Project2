<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.* " %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ����Ԫҷ���Դ�͹</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%! public static String filter(String input)
{
	StringBuffer temp = new StringBuffer(input.length());
	char c;
	for(int i=0; i<input.length();i++)
	{
		c = input.charAt(i);
		if(c == '<' ) temp.append("&lt;");
		else if (c == '>') temp.append("&gt;");
		else if (c == '\'') temp.append("&#039;");
                		else if (c == '"') temp.append("&quot;");
		else if (c == '&') temp.append("&amp;");
		else if (c =='\\') temp.append("&#92;");
		else temp.append(c);
	}
	return(temp.toString());
}
%>
<%
        	int error = 0;

	String recentAddress = " ",registerAddress = " ",recentTel = " ", email = " ";
	Student student = (Student)session.getAttribute("StudentInfo");
      	recentAddress = filter(new String(request.getParameter("recentaddress").getBytes("ISO8859_1"),"TIS-620"));
      	registerAddress = filter(new String(request.getParameter("realaddress").getBytes("ISO8859_1"),"TIS-620"));
      	recentTel = filter(new String(request.getParameter("homephone").getBytes("ISO8859_1"),"TIS-620"));
      	email = filter(new String(request.getParameter("email").getBytes("ISO8859_1"),"TIS-620"));

	student.setRecentAddress(recentAddress);
	student.setRegisterAddress(registerAddress);
	student.setRecentTel(recentTel);
	student.setEmail(email);

	// update to database
	Database.connect();
	student.updateStudentForWeb(student);
	Database.disconnect();
%>
</head>

<body bgcolor="#FFFFFF">
<form method="post" action="viewStudentInfoPage.jsp" name="form">
  <table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
    <tr>
    <td height="14" colspan="5" bgcolor="#000000"> <font class="headline1"> <b>
      King Mongkut's Institute of Technology Ladkrabang </b> </font> </td>
  </tr>
  <tr>
    <td rowspan="3" height="400" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="14%" height="46" align="right" valign="middle"><img src="images/images2.jpg" width="65" height="60"></td>
      <td width="32%" height="46" align="center" valign="bottom"><img src="images/edit2.gif" width="198" height="85"></td>
    <td width="14%" height="46" align="left" valign="middle"><img src="images/images.jpg" width="65" height="60"></td>
    <td rowspan="3" height="400" width="29%">&nbsp;</td>
  </tr>
  <tr>
      <td height="53" bgcolor="#FFCC66" align="center" colspan="3"> <font class="normal1"><b>���� 
        - ���ʡ��</b></font> <span class="normal1"><%= student.getStudentTname() %></span> 
        <font class="normal1"><b>����</b></font> <span class="normal1"><%= student.getStudentID()%></span><br>
        <font class="normal1"><b>�Ҥ�Ԫ�</b></font> <span class="normal1"><%= student.getMajor().getDepartment().getTname()%></span>
        <font class="normal1"><b>���</b></font> <span class="normal1"><%= student.getMajor().getDepartment().getFaculty().getTname()%></span>
    </td>
  </tr>
  <tr>
      <td height="369" align="center" valign="top" bordercolor="#000000" colspan="3">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="250">
          <tr>
            <td align="left" valign="top" height="19" width="26%">&nbsp;</td>
            <td align="left" valign="middle" height="19" width="2%">&nbsp;</td>
            <td align="left" valign="middle" height="19" width="72%"><font class="warning1">
              </font></td>
        </tr>
        <tr>
            <td align="right" valign="top" width="26%" height="10"><font class="normal1">�������Ѩ�غѹ</font></td>
            <td align="left" valign="top" width="2%" height="10">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="10"><font class="normal1"><font color="#005CA2"><%= recentAddress %></font></font></td>
        </tr>
        <tr>
            <td align="right" valign="top" width="26%" height="10"><font class="normal1">�������������¹��ҹ</font></td>
            <td align="left" valign="top" width="2%" height="10">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="10"><font class="normal1"><font color="#005CA2"><%= registerAddress%></font></font></td>
        </tr>
        <tr>
            <td align="right" valign="top" width="26%" height="14"><font class="normal1">���Ѿ���ҹ</font></td>
            <td align="left" valign="top" width="2%" height="14">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="14"><font class="normal1"><font color="#005CA2"><%= recentTel%></font></font></td>
        </tr>
        <tr>
          <td align="right" valign="top" width="26%"><font class="normal1">������</font></td>
          <td align="left" valign="top" width="2%">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="30"><font class="normal1"><font color="#005CA2"><%= email%></font></font></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td height="48" width="35%" rowspan="2">&nbsp;</td>
            <td height="46" width="65%">&nbsp;</td>
        </tr>
        <tr>
            <td height="34" width="65%">
              <input type="button" name="Back" value="��Ѻ��ѧ������ѡ" OnClick="history.go(-2)">
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
