<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.text.*, java.util.*, java.io.*,graduate.*" %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Student student = (Student)session.getAttribute("StudentInfo");
	Semester semester = (Semester)session.getAttribute("Semester");
	Database.connect();
	if (student.verifyUsername(student.getStudentID(), request.getParameter("password"))){
      		Vector regVector = student.getCurrentRegistration();
      		Enumeration regEnum = regVector.elements();
      		while (regEnum.hasMoreElements()){
        			Registration reg = (Registration)regEnum.nextElement();
        			reg.getSection().incrementStudent(reg.getSection());
        			reg.insertRegistration(reg);
     		 }
		session.invalidate();
	}
	else {
		response.sendRedirect("PreRegistrationPage3.jsp?error=true");
		return;
	}
	Appointment advance = new Appointment();
	advance = advance.retrieveAppointment(semester,new RegisterType(1));
	Appointment normal = new Appointment();
	normal = normal.retrieveAppointment(semester,new RegisterType(2));
        	Database.disconnect();
/*
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandlePreRegister hPreregister = (HandlePreRegister)session.getAttribute("PreRegister");

	Verify verify = new Verify();

	if(verify.validateStudent(hStudent.getStudent().getId(), request.getParameter("password")))
	{
		hPreregister.register();
		session.invalidate();
	}
	else
	{
		response.sendRedirect("PreRegistrationPage3.jsp?error=true");
		return;
	}

	TimeSchedule preregisterTime = null;
	TimeSchedule registerTime = null;

	HandleTimeSchedule hSchedule = new HandleTimeSchedule();
	Vector v = hSchedule.retrieveTimeSchedule("4");
	Enumeration e = v.elements();

	if(e.hasMoreElements())
	{
		preregisterTime = (TimeSchedule)e.nextElement();
	}

	v = hSchedule.retrieveTimeSchedule("5");
	e = v.elements();

	if(e.hasMoreElements())
	{
		registerTime = (TimeSchedule)e.nextElement();
	}
*/
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr>
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/preregistration.gif" width="425" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="top" height="35"><img src="images/logo-kmitl.gif" width="139" height="137"></td>
  </tr>
  <tr>
    <td align="center" valign="top" height="138">
      <p align="center">&nbsp;</p>
      <p align="center">
		<font class="normal3">��й��س��ӡ��ŧ����¹��ǧ˹����������ó�����</font><br>
        <font class="normal3">��ѧ�ҡ���ࢵŧ����¹��ǧ˹��(</font>
        <font class="warning1">
		<b>
        <%= DateFormat.getDateInstance().format(advance.getFromDate()) %> - <%= DateFormat.getDateInstance().format(advance.getToDate()) %>
		</b>
        </font>
		<font class="normal3">)<br>
        �س���繵�ͧ��Ǩ�ͺ�š��ŧ����¹��ԧ�ա����
		</font><br>
        <font class="normal3"><b>����</b></font>
        <font class="normal3">(</font>
        <font class="warning1">
		<b>
        <%= DateFormat.getDateInstance().format(normal.getFromDate()) %> - <%= DateFormat.getDateInstance().format(normal.getToDate()) %>
		</b>
        </font>
		<font class="normal3">)</font>
      </p>
    </td>
  </tr>
  <tr>
    <td  align="center" valign="top" height="34">
      <input type="button" name="Button" value="������鹡��ŧ����¹" OnClick="window.location='/jsp/LoginPage.jsp'">
    </td>
  </tr>
  <tr>
    <td  align="center" valign="top" height="51"></td>
  </tr>
</table>
</body>
</html>