<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, java.text.*, graduate.*"  %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ��������´�ͧ����Ԫ�</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Database.connect();
	Student student = (Student)session.getAttribute("StudentInfo");
	String subjectID = request.getParameter("id");
	String sec = request.getParameter("sec");
	Subject subject = new Subject();
	subject = subject.retrieveSubject(subjectID,student.getMajor());
	Section section = subject.getSection(Integer.parseInt(sec));

%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="730" bgcolor="#FFFFFF">
  <tr>
    <td height="14" colspan="5" bgcolor="#000000">
	<font class="headline1">
	<b>
      King Mongkut's Institute of Technology Ladkrabang
	 </b>
	 </font>
	 </td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="15%">&nbsp;</td>
    <td width="11%" height="87" align="center" valign="middle"><img src="images/book3.gif" width="65" height="66"></td>
    <td width="34%" height="87" align="center" valign="middle"><img src="images/subject2.gif" width="283" height="65"></td>
    <td width="14%" height="87" align="center" valign="middle"><img src="images/book3.gif" width="65" height="66"></td>
    <td rowspan="5" height="338" width="26%">&nbsp;</td>
  </tr>
  <tr>
    <td height="128" align="left" colspan="3">
      <table width="100%" border="1" cellspacing="1" cellpadding="3" bgcolor="#FFFFCC" bordercolor="#CCCCCC">
        <tr>
          <td width="35%" bgcolor="#FFCC66"><font class="normal1"><b>�����Ԫ�</b></font></td>
          <td width="65%" bgcolor="#FFCC66"><font class="normal1"> <%= subject.getSubjectID() %>
            </font></td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#FFCC66"><font class="normal1"><b>�����Ԫ������ѧ���</b></font></td>
          <td width="65%" bgcolor="#FFCC66"><font class="normal1">
            <%
				if(subject.getSubjectEname() == null || subject.getSubjectEname().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					out.print(subject.getSubjectEname());
				}
		  %>
            </font></td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#FFCC66"><font class="normal1"><b>�����Ԫ�������</b></font></td>
          <td width="65%" bgcolor="#FFCC66"><font class="normal1">
            <%
				if(subject.getSubjectTname() == null || subject.getSubjectTname().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					out.print(subject.getSubjectTname());
				}
		  %>
            </font></td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#FFCC66"> <font class="normal1"> <b> ˹��¡Ե
            (��ɯ� - ��Ժѵ� - �鹤���) </b> </font> </td>
          <td width="65%" bgcolor="#FFCC66"><font class="normal1">
            <%
			if(subject.getCredit() == 0)
			{
				out.print("0");
			}
			else
			{
				out.print(subject.getCredit());
			}

		   out.print(" (");

		   if(subject.getLecture() == 0)
		   {
			   out.print("0");
		   }
		   else
		   {
				out.print(subject.getLecture());
		   }

		   out.print(" - ");

		   if(subject.getPractice() == 0)
		   {
			   out.print("0");
		   }
		   else
		   {
			   out.print(subject.getPractice());
		   }

		   out.print(" - ");

  		   if(subject.getResearch() == 0)
		   {
			   out.print("0");
		   }
		   else
		   {
   			   out.print(subject.getResearch());
		   }

		   out.print(")");
		  %>
            </font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="30" align="center" colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td height="495" align="center" valign="top" bordercolor="#000000" colspan="3">
      <table width="100%" border="1" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC">
        <tr>
          <td colspan="2" bgcolor="#6699CC"> <font class="headline3"><b>Section
            <%
	Vector disv = subject.getSection();
                              Enumeration e = disv.elements();
                              int i = 0;
                              while (e.hasMoreElements()){
                                      i++;
		Section ss = (Section)e.nextElement();
                                      if(request.getParameter("sec").equals(Integer.toString(i)))
                                      {
                                                      out.println(Integer.toString(i));
                                       }
                                      else
                                      {
                                                      out.println("<a href=\"ReviewSubjectPage.jsp?id=" + request.getParameter("id") + "&sec=" + ss.getSec() + "\"><font color=\"#FFFFFF\">" + ss.getSec() + "</font></a>");
                                      }

                              }

                 %>
            </b></font></td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>����͹</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
                  		if (section != null) {
			Vector pv = section.retrieveProfessor(section);
			Enumeration epv = pv.elements();
			while (epv.hasMoreElements()){
                        				Professor prof = (Professor)epv.nextElement();
				out.print(prof.getPrename().getTPrename());
				out.print(prof.getTprofessorName() + "<br />");
			}
                  		}
		else out.print("-");
		  %>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>�ѹ���ҷ���͹</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			    if(section == null || section.getDay() <= 0)
			   {
				   out.print("-");
			   }
			   else
			   {
				if (section.getDay() == 1) out.print("�ѹ���");
				else if (section.getDay() == 2) out.print("�ѧ���");
				else if (section.getDay() == 3) out.print("�ظ");
				else if (section.getDay() == 4) out.print("����ʺ��");
				else if (section.getDay() == 5) out.print("�ء��");
				else if (section.getDay() == 6) out.print("�����");
				else out.print("�ҷԵ��");
			   }

	  		   if(section == null || section.getBeginTime().trim().length() == 0)
			   {
                           				out.print("&nbsp;");
			   }
			   else
			   {
                           				out.print(" (" + section.getBeginTime() + " - ");
			   }

  			   if(section == null || section.getEndTime().trim().length() == 0)
			   {
                           				out.print("&nbsp;");
			   }
			   else
			   {
                           				out.print(section.getEndTime() + ")");
			   }
		 %>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>��ͧ������͹</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
  		   if(section == null || section.getRoom().trim().length() == 0)
		   {
                   			out.print("-");
		   }
		   else
		   {
                   			out.print(section.getRoom());
		   }
		   %>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>�ѹ�ͺ��ҧ�Ҥ</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			if(section == null || section.getMidtermDate() == null)
			{
				out.print("-");
			}
			else
			{
				String date = new SimpleDateFormat().getDateInstance().format(section.getMidtermDate());
				out.print(date);
			}

                        			if(section == null || section.getMidtermBtime() == null)
			{
				out.print("&nbsp;");
		 	}
			else
		   	{
                           				out.print(" (" + section.getMidtermBtime() + " - ");
			}

			if(section == null || section.getMidtermEtime().trim().length() == 0)
			{
				out.print("&nbsp;");
			}
			 else
			{
				out.print(section.getMidtermEtime() + ")");
			}
		   %>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>��ͧ������ͺ��ҧ�Ҥ</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			   if(section == null || section.getMidtermRoom().trim().length() == 0)
			   {
				out.print("-");
			   }
			   else
			   {
				out.print(section.getMidtermRoom());
			   }
			%>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>�ѹ�ͺ����Ш��Ҥ</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			if(section == null || section.getFinalDate() == null)
			{
				out.print("-");
			}
			else
			{
				String date = new SimpleDateFormat().getDateInstance().format((java.util.Date)section.getFinalDate());
				out.print(date);
			}

			   if(section == null || section.getFinalBtime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
				out.print(" (" + section.getFinalBtime() + " - ");
			   }

			   if(section == null || section.getFinalEtime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
				out.print(section.getFinalEtime() + ")");
			   }
		   %>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>��ͧ������ͺ����Ш��Ҥ</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			   if(section == null || section.getFinalRoom().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
				out.print(section.getFinalRoom());
			   }
			%>
            </font> </td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>�ӹǹ�ѡ�֡�ҷ���Ѻ</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
			   if(section == null || section.getMax() == 0)
				{
					out.print("N/A");
				}
				else
				{
					out.print(section.getMax());
				}
		  %>
            </font> </td>
        </tr>
        <tr>
          <td bgcolor="#E3EFFB"><font class="headline2"><b>�ӹǹ�ѡ�֡�ҷ��ŧ����¹</b></font></td>
          <td bgcolor="#E3EFFB"> <font class="normal1">
            <%
			    if(section == null || section.getCurent() == 0)
				{
					out.print("N/A");
				}
				else
				{
					out.print(section.getCurent());
				}
		  %>
            </font> </td>
        </tr>
        <tr>
          <td bgcolor="#E3EFFB"><font class="headline2"><b>ʶҹС���Դ - �Դ</b></font></td>
          <td bgcolor="#E3EFFB"> <font class="normal1">
            <%
			if(section == null)
			{
				out.print("N/A");
			}
			else
			{
				if(section.getStatus())
				{
					out.print("�Դ");
				}
				else
				{
					out.print("�Դ");
				}
			}
		 %>
            </font> </td>
        </tr>
        <tr bgcolor="#6699CC">
          <td colspan="2"><font class="headline3"><b>�ԪҺѧ�Ѻ��͹</b></font></td>
        </tr>
        <tr>
          <td width="35%" bgcolor="#E3EFFB"><font class="headline2"><b>�����Ԫ�</b></font></td>
          <td width="65%" bgcolor="#E3EFFB"> <font class="normal1">
            <%
				Enumeration preEnum = subject.getPrerequisite().elements();
				while (preEnum.hasMoreElements()){
					Subject pre = (Subject)preEnum.nextElement();
					if (pre != null && pre.getSubjectID().trim().length() != 0){
						out.print(pre.getSubjectID() + "    " + pre.getSubjectEname());

					}
				}
				out.print("-");
			%>
            </font> </td>
        </tr>
        <tr bgcolor="#6699CC">
          <td colspan="2"><font class="headline3"><b>��͸Ժ������Ԫ�</b></font></td>
        </tr>
        <tr bgcolor="#E3EFFB">
          <td colspan="2"> <font class="normal1">
            <%
			   if(subject.getEdescription() == null || subject.getEdescription().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
                           				out.print(subject.getEdescription());
			   }
		 %>
            </font> </td>
        </tr>
        <tr bgcolor="#E3EFFB">
          <td colspan="2"> <font class="normal1">
            <p>
		 <%
			   if(subject.getTdescription() == null || subject.getTdescription().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
				out.print(subject.getTdescription());
			   }
	Database.disconnect();
		 %>
		 </p>
		  </font>
		  </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="58" align="center" valign="top" bordercolor="#000000" colspan="3"></td>
  </tr>
</table>
</body>
</html>
