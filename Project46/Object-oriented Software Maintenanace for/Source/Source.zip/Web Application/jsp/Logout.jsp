<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true" %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<meta http-equiv="Content-Type">
<body>
<%
try {
	session.invalidate();
    response.sendRedirect("/jsp/LoginPage.jsp");
    }
	catch (Exception ex) {
	ex.printStackTrace();
   }    
%>
 </body>
</html>