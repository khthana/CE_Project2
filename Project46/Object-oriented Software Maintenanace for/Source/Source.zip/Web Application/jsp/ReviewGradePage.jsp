<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, java.text.*, graduate.*" %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �š���֡��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Student student = (Student)session.getAttribute("StudentInfo");
	Registration registration = (Registration)session.getAttribute("Registration");
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr>
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/gradeing.gif" width="227" height="71"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr>
    <td height="17" bgcolor="#FFCC66" width="67%" align="center">
		<font class="normal1"><b>���� - ���ʡ��</b> <%= student.getStudentTname() %></font>
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= student.getStudentID() %></font>
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b>
	<%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
	%>

      </font>
        <br>
        <font class="normal1"><%= (student.getMinor().getTname() == null) ? "" : "<b>ᢹ��Ԫ�</b> " + student.getMinor().getTname() %></font>
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= student.getMajor() %></font>
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= student.getMajor().getDepartment().getTname() %></font>
        <font class="normal1"><b>���&nbsp;</b><%= student.getMajor().getDepartment().getFaculty().getTname() %></font>
    </td>
  </tr>
  <tr>
    <td width="67%" height="13">&nbsp;</td>
  </tr>
  <tr>
    <td height="495" align="center" valign="top" bordercolor="#000000" width="67%">
<%
      Database.connect();
      String semID = request.getParameter("semid");
      String semesterNo = request.getParameter("sem");
      String semesterYear = request.getParameter("year");
      if (semID == null || semID.equals("")) semID = "0";
      int semesterID = Integer.parseInt(semID);

      Vector registrationVector = registration.retrieveRegistration(student);
      int showCredit = 0;
      boolean all = (semesterNo.equals("all"))?true : false;

      Vector conVector = new Vector();
      Vector termVector = registration.retrieveSemesterRegistered(student);
      Enumeration termEnum = termVector.elements();
      while (termEnum.hasMoreElements())
     {
       Semester s1 = (Semester)termEnum.nextElement();
     //-----------------------------------------Header--------------------------------------------------
       if(all || (s1.getSemesterID() == semesterID))
      {
         out.println(
                "<table width=\"600\" border=\"1\" cellspacing=\"2\" cellpadding=\"5\" align=\"center\" bgcolor=\"#E3EFFB\" bordercolor=\"#CCCCCC\">" +
                                      "<caption>" +
                                              "<font class=\"headline4\"><b>" + "�Ҥ����֡�ҷ�� " + s1.getSemester() + " �ա���֡�� " + s1.getYear() + "</b></font>" +
                                              "</caption>" +
                                          "<tr bgcolor=\"#FFFF99\">" +
                                          "<td width=\"12%\" bgcolor=\"#6699CC\" align=\"center\" height=\"40\">" +
                                          "<font class=\"headline2\"><b>" +
                                          "�����Ԫ�" +
                                          "</b></font>" +
                                      "</td>" +
                                      "<td width=\"53%\" bgcolor=\"#6699CC\" align=\"center\">" +
                                          "<font class=\"headline2\"><b>" +
                                          "�����Ԫ�" +
                                      "</b></font>" +
                                              "</td>" +
                                              "<td width=\"10%\" bgcolor=\"#6699CC\" align=\"center\">" +
                                              "<font class=\"headline2\"><b>" +
                                              "˹��¡Ե" +
                                              "</b></font>" +
                                              "</td>" +
                                              "<td width=\"12%\" bgcolor=\"#6699CC\" align=\"center\">" +
                                              "<font class=\"headline2\"><b>" +
                                              "�š���֡��" +
                                              "</b></font>" +
                                              "</td>"+
                                              "</tr>"
                                              );
      }
      //----------------------------------------Content------------------------------------------------------------------
       if(all || (s1.getSemesterID() == semesterID)) {
      	Vector termRegisVector = student.retrieveRegistrationPerSemester(s1);
      	Enumeration termRegisEnum = termRegisVector.elements();
      	while (termRegisEnum.hasMoreElements()){
      	Registration r2 = (Registration)termRegisEnum.nextElement();
      	out.println("<tr>" +
                                   "<td width=\"12%\" bgcolor=\"#E3EFFB\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
                                   "<font class=\"normal1\">" +
                                   r2.getSection().getSubject().getSubjectID() +
                                   "</font>" +
                                   "</td>" +
                                   "<td width=\"53%\" bgcolor=\"#E3EFFB\" bordercolor=\"#CCCCCC\" height=\"30\">" +
                                   "<font class=\"normal1\">" +
                                   r2.getSection().getSubject().getSubjectEname() + " (" + r2.getType() + ") " +
                                   "</font>" +
                                   "</td>" +
                                   "<td width=\"10%\" bgcolor=\"#E3EFFB\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
                                   "<font class=\"normal1\">" +
                                   r2.getSection().getSubject().getCredit() +
                                   "</font>" +
                                   "</td>" +
                                   "<td width=\"12%\" bgcolor=\"#E3EFFB\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
                                   "<font class=\"normal1\">" +
                                   r2.getGrade() +
                                   "</font>" +
                                   "</td>" +
                                   "</tr>");
      	}
      }
      //-------------------------------show GPS GPA----------------------------------------------------

      Vector tempVector = student.retrieveRegistrationPerSemester(s1);
      double totalGPS = student.calculateCredit(tempVector);
      showCredit = student.getAllCredit();
      conVector.addAll(tempVector);
      if(all || (s1.getSemesterID() == semesterID))
      {
              DecimalFormat format = new DecimalFormat("0.00");

              out.println("<tr bgcolor=\"#6699CC\">" +
                                         "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
                                         "˹��¡Ե��� " + Integer.toString(showCredit) + " ˹��¡Ե" +
                                         "</b></td>" +
                                             "</tr>" +
                                     "<tr bgcolor=\"#6699CC\">" +
                                     "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
                                     "GPS " + format.format(totalGPS) +
                                     "</b></td>" +
                                     "</tr>" +
                                     "<tr bgcolor=\"#6699CC\">" +
                                     "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
                                     "GPA " + format.format(student.calculateCredit(conVector)) +
                                     "</b></td>" +
                                     "</tr>" +
                                     "</table>" +
                                     "<br><br><br>");
      }
      showCredit = 0;
  }
  Database.disconnect();
%>
	</table>
    </body>
</html>
