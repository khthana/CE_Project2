<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.text.*, java.io.*,graduate.*" %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Database.connect();
	Student student = (Student)session.getAttribute("StudentInfo");
	Semester semester = (Semester)session.getAttribute("Semester");
	Registration registration = (Registration)session.getAttribute("Registration");
	String conditions = "";
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr>
    <td height="14" colspan="4" bgcolor="#000000">
	<font class="headline1">
	<b>
      King Mongkut's Institute of Technology Ladkrabang
	</b>
	</font>
	</td>
  </tr>
  <tr>
    <td rowspan="5" height="367" align="center" valign="top" width="10%">&nbsp;</td>
    <td height="46" align="center" valign="bottom" colspan="2"><img src="images/preregistration.gif" width="425" height="57"></td>
    <td rowspan="5" height="338" width="25%">&nbsp;</td>
  </tr>
  <tr>
    <td height="17" bgcolor="#FFCC66" align="center" colspan="2"> <font class="normal1"><b>���� 
      - ���ʡ��</b> <%= student.getStudentTname() %></font> <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= student.getStudentID() %></font> 
      <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b> 
      <%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
	%>
      </font> <br>
        <font class="normal1"><%= (student.getMinor().getTname() == null) ? "" : "<b>ᢹ��Ԫ�</b> " + student.getMinor().getTname() %></font>
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= student.getMajor() %></font>
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= student.getMajor().getDepartment().getTname() %></font>
        <font class="normal1"><b>���&nbsp;</b><%= student.getMajor().getDepartment().getFaculty().getTname() %></font>
    </td>
  </tr>
  <tr>
    <td height="6" colspan="2">
      <div align="center"> <br>
        <font class="headline4">
        <b>
        <%
		out.println("��������´�������� �Ҥ���¹��� " + semester.getSemester() + " �ա���֡�� " +  semester.getYear());
		%>
        </b>
		</font>
		<br>
        <br>
      </div>
      <table width="81%" border="2" cellspacing="2" cellpadding="5" bgcolor="#E3EFFB" bordercolor="#CCCCCC" align="center" height="129">
        <tr bgcolor="#FFFF99">
          <td align="center" height="30" bgcolor="#6699CC"> 
            <div align="center"><font class="headline2"><b>��������´</b></font></div>
          </td>
          <td width="20%" height="40" align="center" bgcolor="#6699CC"> 
            <div align="center"><font class="headline2"><b>�ӹǹ�Թ (�ҷ)</b></font></div>
          </td>
        </tr>
        <%
              DecimalFormat format = new DecimalFormat("0.00");
              double totalCost = 0.00f;
	int countTerm = 0;
      	countTerm = registration.countTermRegisted(student);
	boolean newStudent = student.isNewStudent(semester);
	int condition = student.getPaymentCondition();

	student.InitCost();
	if (condition == 1 || condition == 2 || condition == 3 || condition == 6) {
//-----------------------------------------UNIT------------------------------------------------------------------------------------------------------------------------------------
		if (condition == 1 || condition ==3){ //normal + support exception
			totalCost += student.calculateCost();
		        	if (student.getTotalCredit() != 0.0){
                                			out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">���ŧ����¹����Ԫ�</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + student.getTotalCredit() + "</font></div></td>" +
		                              	"</tr>");
			}
			else if (student.getTotalNoncredit() != 0.0){
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">���ŧ����¹����Ԫ��дѺ��ԭ�ҵ��</font></div></td>"+
		                              	"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + student.getTotalNoncredit() + "</font></div></td>" +
                              			"</tr>");
			}
			else if (student.getTotalAudit() != 0.0){
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">���ŧ����¹����֡�����������ѧ</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + student.getTotalNoncredit() + "</font></div></td>" +
		                              	"</tr>");
			}
			else if (student.getTotalThesis() != 0.0){
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">���ŧ����¹�Է�ҹԾ���</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + student.getTotalNoncredit() + "</font></div></td>" +
		                              	"</tr>");
			}

		}
//-------------------------------------NewStudent---------------------------------------------------------------------------------------------------------------------------------
		if (newStudent && countTerm == 0){
			for(int i=0;i<4;i++){
				double newstud = student.getCost(i+17).getValue();
				totalCost += newstud;
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(i+17).getCostName() + "</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + newstud + "</font></div></td>" +
		                              	"</tr>");
			}
		}
//-------------------------------------Maintenance Cost-----------------------------------------------------------------------------------------------------------------------
		double institute = student.getCost(12).getValue();
		totalCost += institute;
              		out.println("<tr>" +
                        		"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(12).getCostName() + "</font></div></td>"+
                                        	"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + institute + "</font></div></td>" +
                                              	"</tr>");
		if (semester.getSemesterType() == 1){
				double library = student.getCost(13).getValue();
				totalCost += library;
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(13).getCostName() + "</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + library + "</font></div></td>" +
		                              	"</tr>");
				double health = student.getCost(15).getValue();
				totalCost += health;
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(15).getCostName() + "</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + health + "</font></div></td>" +
		                              	"</tr>");
		}
		else {
				double library = student.getCost(14).getValue();
				totalCost += library;
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(14).getCostName() + "</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + library + "</font></div></td>" +
		                              	"</tr>");
				double health = student.getCost(16).getValue();
				totalCost += health;
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\"> " + student.getCost(16).getCostName() + "</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + health + "</font></div></td>" +
		                              	"</tr>");
		}
//-------------------------------------SUPPORT---------------------------------------------------------------------------------------------------------------------------------
		if (condition == 1 || condition ==2) { //normal + unit exception
			if (countTerm < student.getNoSupportTerm()){
			              	double sup = student.getSupport();
				totalCost += sup;
				if (student.getStudyGroup() == 1){
        				out.println("<tr>" +
		                              	"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">�Թ�����������֡��</font></div></td>"+
                              			"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + sup + "</font></div></td>" +
		                              	"</tr>");
				}
				else {
		        		out.println("<tr>" +
                              			"<td bgcolor=\"#E3EFFB\" height=\"27\"><div align=\"left\"><font class=\"normal1\">�Թ�ش˹ع����֡��</font></div></td>"+
		                              	"<td bgcolor=\"#E3EFFB\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + sup + "</font></div></td>" +
                              			"</tr>");
				}
			}
		}
	}
          %>
        <tr>
          <td align="center" bgcolor="#6699CC" height="27"> 
            <div align="right"><font class="headline2"><b>����Թ����ͧ����</b></font></div>
          </td>
          <td bgcolor="#6699CC" width="9%" height="27"> 
            <div align="center"><font class="headline2"><b><%= format.format(totalCost) %></b></font></div>
          </td>
        </tr>
      </table>
      <table width="81%" align="center">
        <form name="form1" method="post" action="RegistrationPage4.jsp">
          <tr>
            <td> <br>
              <font class="normal3"><b>������ʼ�ҹ�ա���������׹�ѹ���ŧ����¹</b></font>
              <input type="password" name="password">
            </td>
            <td align="right"> <br>
              <input type="submit" name="Next" value=" ��ŧ ">
              <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-2)">
            </td>
          </tr>
        </form>
      </table>
    </td>
  </tr>
  <tr>
    <td width="7%" height="6">&nbsp;</td>
    <td width="58%" height="6">
	<font class="warning1">
	<b>
        <%
        		 String error = request.getParameter("error");
                        		String msg = "* ���ʼ�ҹ�Դ��Ҵ ��سһ�͹���ʼ�ҹ����";
		%>
        <%=((error!=null)?msg : "")%>
	</b>
	</font>
	</td>
  </tr>
  <tr>
    <td height="42" align="center" valign="top" bordercolor="#000000" colspan="2">
    </td>
  </tr>
</table>
</body>
</html>
