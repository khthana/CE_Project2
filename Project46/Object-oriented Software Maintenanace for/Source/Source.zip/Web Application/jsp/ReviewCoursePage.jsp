<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.*" %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ����Ԫҷ���Դ�͹</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	Student student = (Student)session.getAttribute("StudentInfo");
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr>
    <td height="14" colspan="5" bgcolor="#000000">
	<font class="headline1">
	<b>
      King Mongkut's Institute of Technology Ladkrabang
	 </b>
	</font>
	</td>
  </tr>
  <tr>
    <td rowspan="4" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="14%" height="46" align="right" valign="middle"><img src="images/book.gif" width="46" height="52"></td>
    <td width="32%" height="46" align="center" valign="bottom"><img src="images/subject.gif" width="198" height="85"></td>
    <td width="14%" height="46" align="left" valign="middle"><img src="images/book2.gif" width="46" height="52"></td>
    <td rowspan="4" height="338" width="29%">&nbsp;</td>
  </tr>
  <tr>
    <td height="32" bgcolor="#FFCC66" align="center" colspan="3"> <font class="normal1"><b>��ѡ�ٵ� 
      </b> 
      <%
         	   	switch (student.getDegree()){
		  case 1: case 2: case 3: case 4: student.getMajor().getPhDTname(); break;
                  		  case 5: case 6: case 7: student.getMajor().getMasterTname(); break;
		  default : break;
		}
                	%>
      </font> </td>
  </tr>
  <tr>
    <td height="495" align="center" valign="top" bordercolor="#000000" colspan="3">
      <table width="99%" border="1" cellspacing="1" cellpadding="5" bordercolor="#FFFFFF" height="36">
        <tr>
          <td bgcolor="#6699CC" width="17%" height="34" valign="middle" align="center"> 
            <font class="headline2"><b>�����Ԫ�</b></font> </td>
          <td bgcolor="#6699CC" width="55%" height="34" valign="middle" align="center"> 
            <font class="headline2"><b>�����Ԫ�</b></font> </td>
          <td bgcolor="#6699CC" width="28%" height="34" valign="middle" align="center"> 
            <font class="headline2"> <b>˹��¡Ԩ<br>
            (������ - ��Ժѵ� - �鹤���)
			</b>
			</font>
          </td>
        </tr>
              <%
	Database.connect();
	Subject sub = new Subject();
                              Vector v = sub.retrieveSubjectForReview(student.getMajor());
                              Enumeration e = v.elements();

                              while(e.hasMoreElements())
                              {
                                      Subject subject = (Subject)e.nextElement();
                                      out.println("<tr><td width=\"17%\" align=\"center\"><font class=\"normal1\"><a href=\"ReviewSubjectPage.jsp?id=" + subject.getSubjectID() + "&sec=0\" target=\"_blank\"><b>" + subject.getSubjectID() + "</b></a></font></td>" +
                                                                                               "<td width=\"55%\"><font class=\"normal1\">" + subject.getSubjectEname() + "</font></td>" +
                                                                                               "<td width=\"28%\" align=\"center\"><font class=\"normal1\">" + subject.getCredit() + " (" + subject.getLecture() + "-" + subject.getPractice() + "-" + subject.getResearch() + ")</font></td>" +
                                                                                "</tr>");
                              }
	Database.disconnect();
		%>
      </table>
    </td>
  </tr>
  <tr>
    <td height="23" align="center" valign="top" bordercolor="#000000" colspan="3"></td>
  </tr>
</table>
</body>
</html>
