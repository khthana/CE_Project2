package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class DepartmentUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  Border border1;
  BorderLayout borderLayout4 = new BorderLayout();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel2 = new JPanel();
  FlowLayout flowLayout5 = new FlowLayout();
  JPanel jPanel19 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  JTextField depEnameText = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel10 = new JPanel();
  JLabel jLabel2 = new JLabel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JTextField depTnameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  FlowLayout flowLayout4 = new FlowLayout();
  JTextField depIDText = new JTextField();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel16 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel generalPanel = null;
//-----------------------------------------------------------------------------
  Faculty faculty = null;
  Department department = null;
  boolean newRecord = false;

  public DepartmentUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public DepartmentUI(JPanel general) {
    try {
      jbInit();
      this.generalPanel = general;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel4.setBorder(null);
    jPanel4.setPreferredSize(new Dimension(440, 240));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    titledBorder6 = new TitledBorder(null, "��������´�Ҥ�Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel2.setBorder(titledBorder1);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 250));
    jPanel2.setLayout(borderLayout2);
    jPanel2.setBorder(titledBorder1);
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("�����Ҥ�Ԫ� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setText("�����Ҥ�Ԫ�[�] :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    depEnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    depEnameText.setPreferredSize(new Dimension(380, 22));
    depEnameText.setText("");
    flowLayout2.setAlignment(FlowLayout.LEFT);
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(4);
    gridLayout1.setVgap(5);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("�����Ҥ�Ԫ�[�] :");
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(4);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 220));
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    flowLayout3.setAlignment(FlowLayout.LEFT);
    depTnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    depTnameText.setPreferredSize(new Dimension(380, 22));
    depTnameText.setText("");
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 120));
    flowLayout4.setAlignment(FlowLayout.LEFT);
    depIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    depIDText.setOpaque(true);
    depIDText.setPreferredSize(new Dimension(380, 22));
    depIDText.setText("");
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    jPanel16.setLayout(flowLayout1);
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setPreferredSize(new Dimension(161, 35));
    flowLayout1.setAlignment(FlowLayout.CENTER);
    flowLayout1.setHgap(5);
    flowLayout1.setVgap(15);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new DepartmentUI_saveButton_actionAdapter(this));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setText("������");
    clearButton.addActionListener(new DepartmentUI_clearButton_actionAdapter(this));
    this.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel4, BorderLayout.CENTER);
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel9.add(jPanel17, null);
    jPanel17.add(depIDText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(depTnameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(depEnameText, null);
    jPanel4.add(jPanel16, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
  }
  public void showUI(Department department){
    newRecord = false;
    this.department = department;
    depIDText.setText(department.getDepartmentID());
    depTnameText.setText(department.getTname());
    depEnameText.setText(department.getEname());
  }
  public void clear(){
    depIDText.setText("");
    depTnameText.setText("");
    depEnameText.setText("");
  }
  public boolean removeDepartment(Department dep){
    Database.connect();
    boolean complete = this.department.deleteDepartment(dep);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }
  public void addDepartment(Faculty fac){
    faculty = fac;
    newRecord = true;
    clear();
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    Database.connect();
    Department dep = new Department();
    dep.setDepartmentID(depIDText.getText());
    dep.setEname(depEnameText.getText());
    dep.setTname(depTnameText.getText());
    dep.setFaculty(this.faculty);
    if (newRecord) {
      if (dep.insertDepartment(dep)) {
        ((GeneralUI) generalPanel).addNode(2,dep);
      }
    }
    else {
      if (dep.updateDepartment(department,dep)) {
        ((GeneralUI)generalPanel).updateNode(dep);
      }
    }
    Database.disconnect();
  }
}

class DepartmentUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  DepartmentUI adaptee;

  DepartmentUI_clearButton_actionAdapter(DepartmentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class DepartmentUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  DepartmentUI adaptee;

  DepartmentUI_saveButton_actionAdapter(DepartmentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}