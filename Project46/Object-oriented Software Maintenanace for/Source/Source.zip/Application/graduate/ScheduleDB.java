package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class ScheduleDB {
  public ScheduleDB() {
  }
  public Vector retrieveSchedule(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Schedule ORDER BY FromDate,ToDate";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Schedule schedule = new Schedule();
          schedule.setScheduleID(rs.getLong("ScheduleID"));
          schedule.setFromDate(rs.getDate("FromDate"));
          schedule.setToDate(rs.getDate("ToDate"));
          v.addElement(schedule);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertSchedule(Schedule schedule){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Schedule(FromDate,ToDate) ";
    query += "VALUES('" + formatter.format(schedule.getFromDate()) + "','" + formatter.format(schedule.getToDate())+ "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateSchedule(Schedule schedule){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Schedule SET ";
    query += "FromDate = '" + formatter.format(schedule.getFromDate()) + "', ";
    query += "ToDate = '" + formatter.format(schedule.getToDate())+ "' ";
    query += "WHERE ScheduleID = " + schedule.getScheduleID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSchedule(Schedule schedule){
    String query = "DELETE FROM Schedule WHERE ScheduleID = " + schedule.getScheduleID();
    if (Database.update(query) != 0) return true;
    return false;
  }

  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ScheduleDB db = new ScheduleDB();
    GregorianCalendar g = new GregorianCalendar(2004,0,20,6,0);
    GregorianCalendar c = new GregorianCalendar(2004,0,20,6,0);
    java.util.Date dd = c.getTime();
    java.util.Date d = g.getTime();
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    System.out.println(formatter.format(dd));
    System.out.println( formatter.format(d));
    System.out.println(dd.equals(d));

/*    String a ="44015343";
    String b = a.substring(0,2);
    System.out.println(Integer.parseInt(b));*/
/*    Schedule s = new Schedule(2,d,d);
    s.updateSchedule(s);*/

/*    Vector v = db.retrieveSchedule();
    Enumeration e = v.elements();
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    while (e.hasMoreElements()){
      Schedule m = (Schedule)e.nextElement();
      System.out.println(formatter.format(m.getFromDate()) + "       " + formatter.format(m.getToDate()));
      System.out.println(m.getFromDate().before(new java.util.Date()));
    }*/
    Database.disconnect();
  }

}