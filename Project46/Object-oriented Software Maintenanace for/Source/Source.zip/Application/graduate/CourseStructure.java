package graduate;

import java.util.*;
public class CourseStructure {
  private long courseStructureID;
  private Major major;
  private Degree degree;
  private int totalUnit;
  private CourseStructureDB csDB = new CourseStructureDB();
  private Vector planVector = new Vector();
  //Constructor
  public CourseStructure() {
  }
  public CourseStructure(long csid){
    this.setCourseStructureID(csid);
  }
  public CourseStructure(long csID,Major major,Degree degree,int tu){
    this.setCourseStructureID(csID);
    this.setMajor(major);
    this.setDegree(degree);
    this.setTotalUnit(tu);
  }
  public CourseStructure(Major major,Degree degree,int tu){
    this.setMajor(major);
    this.setDegree(degree);
    this.setTotalUnit(tu);
  }
  //getMethod
  public long getCourseStructureID(){
    return this.courseStructureID;
  }
  public Major getMajor(){
    return this.major;
  }
  public Degree getDegree(){
    return this.degree;
  }
  public int getTotalUnit(){
    return this.totalUnit;
  }
  //setMethod
  public void setCourseStructureID(long courseStructureID){
    this.courseStructureID = courseStructureID;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void setDegree(Degree degree){
    this.degree = degree;
  }
  public void setTotalUnit(int totalUnit){
    this.totalUnit = totalUnit;
  }
  //Business Method
  public void addPlan(Plan plan){
    planVector.addElement(plan);
  }
  public void setPlan(Vector plan){
    planVector = plan;
  }
  public Enumeration retrievePlan(){
    return planVector.elements();
  }
  public Plan retrievePlan(long pID){
    Enumeration e = retrievePlan();
    while (e.hasMoreElements()){
      Plan plan = (Plan)e.nextElement();
      if (plan.getPlanID() == pID)
        return plan;
    }
    return null;
  }
  //Access Method
  public Vector retrieveCourseStructureAll(Major major){
    return csDB.retrieveCourseStructureAll(major);
  }
  public Vector retrieveCourseStructure(Major major,Degree degree){
    return csDB.retrieveCourseStructure(major,degree);
  }
  public boolean insertCourseStructure(CourseStructure cs){
    return csDB.insertCourseStructure(cs);
  }
  public boolean updateCourseStructure(CourseStructure cs){
    return csDB.updateCourseStructure(cs);
  }
  public boolean deleteCourseStructure(CourseStructure cs){
    return csDB.deleteCourseStructure(cs);
  }
}