package graduate;

import java.sql.*;
import java.util.*;
public class MajorDB {
  public MajorDB() {
  }
  public Vector retrieveMajorAll(Department dep){
    Vector v = new Vector();
    try {
      String query = "SELECT * FROM Major WHERE DepartmentID = '" + dep.getDepartmentID() + "' ORDER BY MajorTname";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        Major major = new Major();
        major.setMajorID(rs.getString("MajorID"));
        major.setEname(rs.getString("MajorEname"));
        major.setTname(rs.getString("MajorTname"));
        major.setDepartment(dep);
        major.setMasterEname(rs.getString("MasterEname"));
        major.setMasterTname(rs.getString("MasterTname"));
        major.setMasterEabbr(rs.getString("MasterEAbbr"));
        major.setMasterTabbr(rs.getString("MasterTAbbr"));
        major.setPhDEname(rs.getString("PhDEname"));
        major.setPhDTname(rs.getString("PhDTname"));
        major.setPhDEabbr(rs.getString("PhDEAbbr"));
        major.setPhDTabbr(rs.getString("PhDTAbbr"));
        v.addElement(major);
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveMajor(Department dep){
  Vector v = new Vector();
  try {
    String query = "SELECT MajorID,MajorTname FROM Major WHERE DepartmentID = '" + dep.getDepartmentID() + "' ORDER BY MajorTname";
    ResultSet rs = Database.getResultSet(query);

    while (rs.next()) {
      Major major = new Major();
      major.setMajorID(rs.getString("MajorID"));
      major.setTname(rs.getString("MajorTname"));
      major.setDepartment(dep);
      v.addElement(major);
    }
  }
  catch (SQLException sqlex) {
    System.out.println(sqlex.toString());
  }
  return v;
}
public Major retrieveMajor(String majorID) {
  Major major = new Major();
  try {
    String query = "SELECT * FROM Major WHERE MajorID = '" + majorID + "' ORDER BY MajorTname";
    ResultSet rs = Database.getResultSet(query);

    while (rs.next()) {
      major.setMajorID(rs.getString("MajorID"));
      major.setEname(rs.getString("MajorEname"));
      major.setTname(rs.getString("MajorTname"));
    }
  }
  catch (SQLException sqlex) {
    System.out.println(sqlex.toString());
  }
  return major;
}
public boolean insertMajor(Major major) {
  String query = "INSERT INTO Major(MajorID,MajorEname,MajorTname,DepartmentID,MasterEname";
  query += ",MasterTname,MasterEAbbr,MasterTAbbr,PhDEname,PhDTname,PhDEAbbr,PhDTAbbr) ";
    query += "VALUES('"+ major.getMajorID() + "' , '" + major.getEname() + "' , '" + major.getTname() + "'";
    query += ", '" + major.getDepartment().getDepartmentID() + "','" + major.getMasterEname() + "'";
    query += ", '" + major.getMasterTname() + "','" + major.getMasterEabbr() + "','" + major.getMasterTabbr() + "'";
    query += ", '" + major.getPhDEname() + "','" + major.getPhDTname() + "','" + major.getPhDEabbr() + "'";
    query += ", '" + major.getPhDTabbr() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateMajor(Major oldmajor,Major major){
    String query = "UPDATE Major SET ";
    query += "MajorID = '" + major.getMajorID() + "', ";
    query += "MajorEname = '" + major.getEname() + "', ";
    query += "MajorTname = '" + major.getTname() + "', ";
//    query += "DepartmentID = '" + major.getDepartment().getDepartmentID() + "', ";
    query += "MasterEname = '" + major.getMasterEname() + "', ";
    query += "MasterTname = '" + major.getMasterTname() + "', ";
    query += "MasterEAbbr = '" + major.getMasterEabbr() + "', ";
    query += "MasterTAbbr = '" + major.getMasterTabbr() + "', ";
    query += "PhDEname = '" + major.getPhDEname() + "', ";
    query += "PhDTname = '" + major.getPhDTname() + "', ";
    query += "PhDEAbbr = '" + major.getPhDEabbr() + "', ";
    query += "PhDTAbbr = '" + major.getPhDTabbr() + "' ";
    query += "WHERE MajorID = '" + oldmajor.getMajorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteMajor(Major major){
    String query = "DELETE FROM Major WHERE MajorID = '" + major.getMajorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    MajorDB mDB= new MajorDB();
    Major m = new Major();
    m.setMajorID("003");
    m.setEname("Information");
    m.setDepartment(new Department("001"));
//    m.updateMajor(m);//
/*    Vector v = m.retrieveMajorAll(new Department("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Major m1 = (Major)e.nextElement();
      System.out.println(m1.getMajorID()+ " " + m1.getEname());
    }*/
    Database.disconnect();
  }

}