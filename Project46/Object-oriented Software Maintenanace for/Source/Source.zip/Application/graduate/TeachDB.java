package graduate;

public class TeachDB {
  public TeachDB() {
  }
  public boolean insertTeach(Teach teach){
    String query = "INSERT INTO Teach(SectionID,ProfessorID) ";
    query = query + "VALUES('" + teach.getSection().getSectionID()+ "','" + teach.getProfessor().getProfessorID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateTeach(Teach oldTeach,Teach newTeach){
    String query = "UPDATE Teach SET ";
    query = query + "SectionID = '" + newTeach.getSection().getSectionID() + "', ";
    query = query + "ProfessorID = '" + newTeach.getProfessor().getProfessorID()+ "' ";
    query = query + "WHERE SectionID = '" + oldTeach.getSection().getSectionID() + "' AND ";
    query = query + "ProfessorID = '" + oldTeach.getProfessor().getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteTeach(Teach teach){
    String query = "DELETE FROM Teach ";
    query = query + "WHERE SectionID = '" + teach.getSection().getSectionID() + "' AND ";
    query = query + "ProfessorID = '" + teach.getProfessor().getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }

}