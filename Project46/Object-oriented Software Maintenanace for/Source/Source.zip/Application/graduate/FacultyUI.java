package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.util.*;

public class FacultyUI extends JPanel {

  Border loweredBorder = new CompoundBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED),
                                            new EmptyBorder(5,5,5,5));
  CompoundBorder titledBorder1;
  Border border4;
  TitledBorder titledBorder2;
  Border border5;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  TitledBorder titledBorder6;
  Border border6;
  BorderLayout borderLayout4 = new BorderLayout();
  Border border7;
  JPanel jPanel16 = new JPanel();
  JPanel jPanel13 = new JPanel();
  JTextField positionText = new JTextField();
  FlowLayout flowLayout12 = new FlowLayout();
  JLabel jLabel9 = new JLabel();
  JPanel jPanel14 = new JPanel();
  JLabel jLabel8 = new JLabel();
  JPanel jPanel24 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel jPanel8 = new JPanel();
  JButton saveButton = new JButton();
  JTextField appoverText = new JTextField();
  JButton clearButton = new JButton();
  GridLayout gridLayout5 = new GridLayout();
  JPanel jPanel15 = new JPanel();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  BorderLayout borderLayout6 = new BorderLayout();
  GridLayout gridLayout6 = new GridLayout();
  GridLayout gridLayout4 = new GridLayout();
  FlowLayout flowLayout7 = new FlowLayout();
  GridLayout gridLayout7 = new GridLayout();
  JPanel jPanel30 = new JPanel();
  FlowLayout flowLayout8 = new FlowLayout();
  FlowLayout flowLayout6 = new FlowLayout();
  JPanel jPanel7 = new JPanel();
  JTextField deanEnameText = new JTextField();
  JPanel jPanel34 = new JPanel();
  JLabel jLabel6 = new JLabel();
  FlowLayout flowLayout9 = new FlowLayout();
  JLabel jLabel4 = new JLabel();
  JPanel jPanel31 = new JPanel();
  JComboBox tPrenameCombo = new JComboBox();
  JPanel jPanel11 = new JPanel();
  JTextField deanTnameText = new JTextField();
  JPanel jPanel22 = new JPanel();
  JLabel jLabel11 = new JLabel();
  FlowLayout flowLayout10 = new FlowLayout();
  JPanel jPanel21 = new JPanel();
  FlowLayout flowLayout11 = new FlowLayout();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel29 = new JPanel();
  JLabel jLabel10 = new JLabel();
  JPanel jPanel23 = new JPanel();
  FlowLayout flowLayout5 = new FlowLayout();
  JPanel jPanel19 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  BorderLayout borderLayout7 = new BorderLayout();
  JPanel jPanel12 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JPanel jPanel6 = new JPanel();
  FlowLayout flowLayout4 = new FlowLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  JTextField facultyIDText = new JTextField();
  BorderLayout borderLayout9 = new BorderLayout();
  JTextField facultyAnameText = new JTextField();
  JTextField approverText = new JTextField();
  JPanel jPanel20 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JTextField facultyTnameText = new JTextField();
  BorderLayout borderLayout1 = new BorderLayout();
  //---------------------------------------------------------------------------------------------------------------------------------------------------------------
  JPanel generalPanel = null;
  boolean newRecord = false;
  Faculty oldFaculty = null;
  JTextField facultyEnameText = new JTextField();
  JTextField ePrenameCombo = new JTextField();

  public FacultyUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public FacultyUI(JPanel general) {
    try {
      jbInit();
      generalPanel = general;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder2 = new TitledBorder(BorderFactory.createEmptyBorder(),"");
    border4 = BorderFactory.createEmptyBorder(5,5,5,5);
    border5 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder3 = new TitledBorder(border5,"�����");
    titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�����");
    border7 = BorderFactory.createEmptyBorder(10,5,5,5);
    titledBorder4.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    border6 = BorderFactory.createEmptyBorder(5,0,0,0);
    this.setLayout(borderLayout1);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setInputVerifier(null);
    jPanel16.setLayout(flowLayout1);
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setBorder(border6);
    jPanel16.setPreferredSize(new Dimension(161, 35));
    jPanel13.setLayout(gridLayout6);
    jPanel13.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel13.setPreferredSize(new Dimension(320, 49));
    positionText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    positionText.setPreferredSize(new Dimension(300, 22));
    jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel9.setText("���͹��ѵԷ�ҹʤ�Ի�� :");
    jPanel14.setLayout(gridLayout5);
    jPanel14.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel8.setText("���˹� :");
    jPanel24.setLayout(flowLayout12);
    jPanel24.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel24.setPreferredSize(new Dimension(312, 55));
    flowLayout1.setAlignment(FlowLayout.CENTER);
    flowLayout1.setHgap(5);
    flowLayout1.setVgap(15);
    jPanel8.setLayout(borderLayout6);
    jPanel8.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel8.setAlignmentX((float) 0.5);
    jPanel8.setBorder(border4);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new FacultyUI_saveButton_actionAdapter(this));
    approverText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    approverText.setPreferredSize(new Dimension(300, 22));
    approverText.setText("");
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setText("������");
    clearButton.addActionListener(new FacultyUI_clearButton_actionAdapter(this));
    gridLayout5.setColumns(1);
    gridLayout5.setRows(2);
    gridLayout5.setVgap(5);
    jPanel15.setLayout(boxLayout21);
    jPanel15.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel15.setForeground(Color.black);
    titledBorder6 = new TitledBorder(null, "��������´���",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel15.setBorder(titledBorder1);
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    gridLayout6.setColumns(1);
    gridLayout6.setRows(2);
    gridLayout6.setVgap(5);
    gridLayout4.setColumns(1);
    gridLayout4.setRows(4);
    gridLayout4.setVgap(5);
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    gridLayout7.setColumns(1);
    gridLayout7.setRows(4);
    gridLayout7.setVgap(5);
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    flowLayout8.setAlignment(FlowLayout.LEFT);
    jPanel7.setLayout(borderLayout5);
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel7.setBorder(titledBorder4);
    jPanel7.setMinimumSize(new Dimension(135, 160));
    jPanel7.setPreferredSize(new Dimension(440, 190));
    deanEnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    deanEnameText.setPreferredSize(new Dimension(270, 22));
    deanEnameText.setToolTipText("");
    deanEnameText.setText("");
    jPanel34.setLayout(flowLayout8);
    jPanel34.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel6.setToolTipText("");
    jLabel6.setText("����-���ʡ��[�] :");
    flowLayout9.setAlignment(FlowLayout.LEFT);
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel4.setText("�ӹ�˹�Ҫ���[�] :");
    jPanel31.setLayout(flowLayout10);
    jPanel31.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    tPrenameCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tPrenameCombo.setPreferredSize(new Dimension(150, 22));
    tPrenameCombo.addActionListener(new FacultyUI_tPrenameCombo_actionAdapter(this));
    jPanel11.setLayout(gridLayout4);
    jPanel11.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    deanTnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    deanTnameText.setPreferredSize(new Dimension(270, 22));
    deanTnameText.setText("");
    jPanel22.setLayout(flowLayout11);
    jPanel22.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel22.setPreferredSize(new Dimension(300, 133));
    jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel11.setMinimumSize(new Dimension(85, 20));
    jLabel11.setPreferredSize(new Dimension(84, 16));
    jLabel11.setText("����-���ʡ��[�] :");
    flowLayout10.setAlignment(FlowLayout.LEFT);
    jPanel21.setLayout(flowLayout6);
    jPanel21.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel21.setBorder(titledBorder2);
    jPanel21.setPreferredSize(new Dimension(432, 200));
    borderLayout5.setVgap(0);
    jPanel29.setLayout(gridLayout7);
    jPanel29.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel29.setDebugGraphicsOptions(0);
    jPanel29.setMaximumSize(new Dimension(32767, 32767));
    jPanel29.setMinimumSize(new Dimension(100, 95));
    jPanel29.setOpaque(true);
    jPanel29.setPreferredSize(new Dimension(100, 133));
    jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel10.setMaximumSize(new Dimension(67, 15));
    jLabel10.setMinimumSize(new Dimension(84, 20));
    jLabel10.setPreferredSize(new Dimension(67, 16));
    jLabel10.setText("�ӹ�˹��[�] :");
    jPanel23.setLayout(flowLayout9);
    jPanel23.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(65, 120));
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(4);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 120));
    flowLayout3.setAlignment(FlowLayout.LEFT);
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 120));
    flowLayout4.setAlignment(FlowLayout.LEFT);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("���ʤ�� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setText("���ͤ��[�] :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(4);
    gridLayout1.setVgap(5);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("���ͤ��[�] :");
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    facultyIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    facultyIDText.setOpaque(true);
    facultyIDText.setPreferredSize(new Dimension(380, 22));
    facultyIDText.setText("");
    facultyEnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    facultyEnameText.setPreferredSize(new Dimension(380, 22));
    facultyEnameText.setText("");
    jPanel20.setLayout(borderLayout7);
    jPanel20.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel20.setPreferredSize(new Dimension(440, 100));
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    facultyTnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    facultyTnameText.setPreferredSize(new Dimension(380, 22));
    facultyTnameText.setText("");
    facultyEnameText.setText("");
    facultyEnameText.setPreferredSize(new Dimension(380, 22));
    facultyEnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    ePrenameCombo.setText("");
    ePrenameCombo.setPreferredSize(new Dimension(150, 22));
    ePrenameCombo.setEnabled(false);
    ePrenameCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.add(jPanel15, BorderLayout.CENTER);
    jPanel11.add(jPanel30, null);
    jPanel30.add(tPrenameCombo, null);
    jPanel11.add(jPanel34, null);
    jPanel34.add(deanTnameText, null);
    jPanel11.add(jPanel23, null);
    jPanel23.add(ePrenameCombo, null);
    jPanel11.add(jPanel31, null);
    jPanel31.add(deanEnameText, null);
    jPanel22.add(jPanel29, null);
    jPanel22.add(jPanel11, null);
    jPanel29.add(jLabel4, null);
    jPanel29.add(jLabel6, null);
    jPanel29.add(jLabel10, null);
    jPanel29.add(jLabel11, null);
    jPanel9.add(jPanel17, null);
    jPanel17.add(facultyIDText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(facultyTnameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(facultyEnameText, null);
    jPanel19.add(facultyEnameText, null);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel15.add(jPanel20, null);
    jPanel20.add(jPanel12, BorderLayout.CENTER);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel15.add(jPanel21, null);
    jPanel21.add(jPanel7, null);
    jPanel7.add(jPanel22, BorderLayout.CENTER);
    jPanel15.add(jPanel8, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    jPanel8.add(jPanel24, BorderLayout.NORTH);
    jPanel8.add(jPanel16, BorderLayout.CENTER);
    jPanel14.add(jLabel8, null);
    jPanel14.add(jLabel9, null);
    jPanel24.add(jPanel14, null);
    jPanel24.add(jPanel13, null);
    jPanel13.add(positionText, null);
    jPanel13.add(approverText, null);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    addPrename();
  }
  public void addPrename(){
    Database.connect();
    Prename prename = new Prename();
    Vector v = prename.retrievePrename();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Prename pre  = (Prename)e.nextElement();
      tPrenameCombo.addItem(pre);
    }
    Database.disconnect();
  }
  public void showUI(Faculty faculty){
    newRecord = false;
    oldFaculty = faculty;
    facultyIDText.setText(faculty.getFacultyID());
    facultyTnameText.setText(faculty.getTname());
    facultyEnameText.setText(faculty.getEname());
    setSelectedName(faculty.getPrename().getEprename());
    deanTnameText.setText(faculty.getDeanTname());
    ePrenameCombo.setText(faculty.getPrename().getEprename());
    deanEnameText.setText(faculty.getDeanEname());
    positionText.setText(faculty.getPosition());
    approverText.setText(faculty.getApprover());
  }
  public void setSelectedName(String name)
  {
     for (int i = 0;i < tPrenameCombo.getItemCount();++i)
     {
        Prename item = (Prename)tPrenameCombo.getItemAt(i);
        if (item.getEprename().equals(name))
        {
           tPrenameCombo.setSelectedItem(item);
           return;
        }
     }
  }
  public void clear(){
    facultyIDText.setText("");
    facultyEnameText.setText("");
    facultyTnameText.setText("");
    tPrenameCombo.setSelectedItem(null);
    deanTnameText.setText("");
    ePrenameCombo.setText("");
    deanEnameText.setText("");
    positionText.setText("");
    approverText.setText("");
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  public boolean removeFaculty(Faculty fac){
    Database.connect();
    boolean complete = fac.deleteFaculty(fac);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }
  public void addFaculty(Faculty faculty){
    newRecord = true;
    clear();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Database.connect();
    if (tPrenameCombo.getSelectedItem() == null) {
      JOptionPane.showMessageDialog(this,"��س����͡�ӹ�˹�Ҫ���","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    Faculty faculty = new Faculty();
    faculty.setFacultyID(facultyIDText.getText());
    faculty.setEname(facultyEnameText.getText());
    faculty.setTname(facultyTnameText.getText());
    faculty.setPrename((Prename)tPrenameCombo.getSelectedItem());
    faculty.setDeanEname(deanEnameText.getText());
    faculty.setDeanTname(deanTnameText.getText());
    faculty.setPosition(positionText.getText());
    faculty.setApprover(approverText.getText());
    if (newRecord) {
      complete = faculty.insertFaculty(faculty);
      if (complete) ((GeneralUI)generalPanel).addNode(1,faculty);
      else {
        JOptionPane.showMessageDialog(this,"���ʤ�Ы�� ��س�����¹����","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
    }
    else {
      complete = faculty.updateFaculty(oldFaculty, faculty);
      if (complete) {
        ((GeneralUI)generalPanel).updateNode(faculty);
      }
    }
    Database.disconnect();
  }

  void tPrenameCombo_actionPerformed(ActionEvent e) {
    if (tPrenameCombo.getSelectedItem() != null)
      ePrenameCombo.setText(((Prename)tPrenameCombo.getSelectedItem()).getEprename());
  }
}

class FacultyUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  FacultyUI adaptee;

  FacultyUI_clearButton_actionAdapter(FacultyUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class FacultyUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  FacultyUI adaptee;

  FacultyUI_saveButton_actionAdapter(FacultyUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class FacultyUI_tPrenameCombo_actionAdapter implements java.awt.event.ActionListener {
  FacultyUI adaptee;

  FacultyUI_tPrenameCombo_actionAdapter(FacultyUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.tPrenameCombo_actionPerformed(e);
  }
}