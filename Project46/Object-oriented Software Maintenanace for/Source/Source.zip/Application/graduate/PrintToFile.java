package graduate;

/*
 * PrintToFile.java
 *
 * Created on 24 \u00BE\u00C4\u00C8\u00A8\u00D4\u00A1\u00D2\u00C2\u00B9 2545, 13:57 \u00B9.
 */

import java.io.*;

/**
 *
 * @author  KUKI
 */
public class PrintToFile {

    private String path;

    /** Creates a new instance of PrintToFile */
    public PrintToFile()
    {
    }

    public void getDataToOutFile(String data, String path)
    {
        this.path = path;

        try
        {
            FileOutputStream output = new FileOutputStream(path);

            try
            {
                output.close();
                RandomAccessFile rfile = new RandomAccessFile(path, "rw");
                rfile.writeBytes(data);
                rfile.close();
            }
            catch(IOException ioex)
            {
                System.out.println(ioex.toString());
            }
        }
        catch(FileNotFoundException fnfex)
        {
            System.out.println(fnfex.toString());
        }
    }

    public static String convertToUnicode(String ascii)
    {
        String unicode = new String("");

        for(int i=0;i<ascii.length();i++)
        {
            unicode = unicode + "&#" + (int)ascii.charAt(i) + ";";
        }

        return unicode;
    }

    public void print()
    {
        try
           {
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec("SHELEXEC " + path);
        }
        catch(IOException ioex)
        {
            ioex.printStackTrace();
        }
    }
}
