 package graduate;

import java.sql.*;
import java.util.*;
public class CourseStructureDB {
  public CourseStructureDB() {
  }
  public Vector retrieveCourseStructureAll(Major major){
    Vector v = new Vector();
    try
    {
        String query = "SELECT d.*,c.* FROM Degree d,CourseStructure c WHERE ";
        query += "d.DegreeID = c.DegreeID AND majorID = '" + major.getMajorID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          CourseStructure course = new CourseStructure();
          Degree degree = new Degree(rs.getLong("DegreeID"),rs.getBoolean("DegreeLevel"),rs.getBoolean("PT"),rs.getBoolean("MBN"));
          course.setCourseStructureID(rs.getLong("CourseStructureID"));
          course.setDegree(degree);
          course.setMajor(major);
          course.setTotalUnit(rs.getInt("TotalUnit"));
          v.addElement(course);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveCourseStructure(Major major,Degree degree){
    Vector v = new Vector();
    try
    {
        String query = "SELECT d.*,c.* FROM Degree d,CourseStructure c WHERE ";
        query += "d.DegreeID = c.DegreeID AND majorID = '" + major.getMajorID() + "'";
        query += "AND c.DegreeID = " + degree.getDegreeID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          CourseStructure course = new CourseStructure();
          course.setCourseStructureID(rs.getLong("CourseStructureID"));
          course.setDegree(degree);
          course.setMajor(major);
          course.setTotalUnit(rs.getInt("TotalUnit"));
          v.addElement(course);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertCourseStructure(CourseStructure courseStructure){
    String query = "INSERT INTO CourseStructure(MajorID,DegreeID,TotalUnit) ";
    query += "VALUES('"+ courseStructure.getMajor().getMajorID() + "'," + courseStructure.getDegree().getDegreeID();
    query += ", " + courseStructure.getTotalUnit() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateCourseStructure(CourseStructure courseStructure){
    String query = "UPDATE CourseStructure SET ";
    query += "MajorID = '" + courseStructure.getMajor().getMajorID() + "', ";
    query += "DegreeID = " + courseStructure.getDegree().getDegreeID() + ",";
    query += "TotalUnit = " + courseStructure.getTotalUnit() + " ";
    query += "WHERE CourseStructureID = " + courseStructure.getCourseStructureID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteCourseStructure(CourseStructure courseStructure){
    String query = "DELETE FROM CourseStructure WHERE CourseStructureID = " + courseStructure.getCourseStructureID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    CourseStructureDB csDB = new CourseStructureDB();
    CourseStructure g = new CourseStructure(1,new Major("002"),new Degree(1,false,false,false),38);
//    csDB.updateCourseStructure(g);
    Vector v = csDB.retrieveCourseStructureAll(new Major("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      CourseStructure m1 = (CourseStructure)e.nextElement();
      System.out.println(m1.getCourseStructureID() + " " + m1.getDegree().getDegreeID() + " " + m1.getMajor().getMajorID() + " " + m1.getTotalUnit());
    }
    Database.disconnect();
  }

}