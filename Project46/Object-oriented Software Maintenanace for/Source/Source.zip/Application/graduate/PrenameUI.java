package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class PrenameUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel8 = new JPanel();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  JPanel jPanel10 = new JPanel();
  JButton saveButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton clearButton = new JButton();
  JPanel jPanel7 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  BorderLayout borderLayout7 = new BorderLayout();
  JTextField ePrenameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  JTextField tPrenameText = new JTextField();
  BorderLayout borderLayout6 = new BorderLayout();
  JPanel jPanel9 = new JPanel();
  BoxLayout2 boxLayout22 = new BoxLayout2();
//-------------------------------------------------------------------------------------------------------------------------------------------------------
  boolean newRecord = false;
  Prename prename = null;
  JPanel etcUI = null;

  public PrenameUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public PrenameUI(JPanel panel) {
    try {
      jbInit();
      etcUI = panel;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(400, 150));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "�ӹ�˹�Ҫ���",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    jPanel2.setBorder(titledBorder1);
    jPanel8.setLayout(borderLayout4);
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel8.setPreferredSize(new Dimension(400, 150));
    jPanel10.setLayout(flowLayout1);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new PrenameUI_saveButton_actionAdapter(this));
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    clearButton.setText("������");
    clearButton.addActionListener(new PrenameUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setAlignmentY((float) 0.5);
    jPanel7.setLayout(borderLayout5);
    jPanel7.setMinimumSize(new Dimension(141, 35));
    jPanel7.setPreferredSize(new Dimension(400, 100));
    jPanel4.setLayout(boxLayout22);
    jPanel4.setPreferredSize(new Dimension(400, 50));
    jLabel1.setText("�ӹ�˹�Ҫ���[�] :");
    jLabel1.setPreferredSize(new Dimension(80, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setDoubleBuffered(false);
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setMinimumSize(new Dimension(62, 16));
    jLabel2.setPreferredSize(new Dimension(80, 16));
    jLabel2.setText("�ӹ�˹�Ҫ���[�] :");
    ePrenameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    ePrenameText.setOpaque(true);
    ePrenameText.setPreferredSize(new Dimension(300, 22));
    ePrenameText.setText("");
    jPanel6.setLayout(borderLayout6);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 20));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(400, 22));
    tPrenameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    tPrenameText.setOpaque(true);
    tPrenameText.setPreferredSize(new Dimension(300, 22));
    tPrenameText.setText("");
    jPanel9.setPreferredSize(new Dimension(400, 22));
    jPanel9.setOpaque(true);
    jPanel9.setMinimumSize(new Dimension(78, 20));
    jPanel9.setDoubleBuffered(true);
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setLayout(borderLayout7);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    this.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel8, null);
    jPanel8.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(jPanel10, BorderLayout.NORTH);
    jPanel10.add(saveButton, null);
    jPanel10.add(clearButton, null);
    jPanel8.add(jPanel4, BorderLayout.NORTH);
    jPanel9.add(jLabel2, BorderLayout.WEST);
    jPanel9.add(ePrenameText, BorderLayout.CENTER);
    jPanel4.add(jPanel6, null);
    jPanel4.add(jPanel9, null);
    jPanel6.add(jLabel1, BorderLayout.WEST);
    jPanel6.add(tPrenameText, BorderLayout.CENTER);
  }

  public void showUI(Prename prename){
    newRecord = false;
    this.prename = prename;
    tPrenameText.setText(prename.getTPrename());
    ePrenameText.setText(prename.getEprename());
  }
  public void clear(){
    tPrenameText.setText("");
    ePrenameText.setText("");
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  public void addprename(){
    newRecord = true;
    clear();
  }
  public boolean removePrename(Prename pre){
    Database.connect();
    boolean complete = pre.deletePrename(pre);
    Database.disconnect();
    if (complete) return true;
    return false;
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Prename prename = new Prename(ePrenameText.getText(),tPrenameText.getText());
    Database.connect();
    if (newRecord){
      complete = prename.insertPrename(prename);
      if (complete) ((EtcUI)etcUI).addNode(prename);
    }
    else {
      prename.setPrenameID(this.prename.getPrenameID());
      complete = prename.updatePrename(prename);
      if (complete) ((EtcUI)etcUI).updateNode(prename);
    }
    Database.disconnect();
  }
}

class PrenameUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  PrenameUI adaptee;

  PrenameUI_clearButton_actionAdapter(PrenameUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class PrenameUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  PrenameUI adaptee;

  PrenameUI_saveButton_actionAdapter(PrenameUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}