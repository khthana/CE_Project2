package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class GradeStudentUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  CompoundBorder titledBorder2;
  TitledBorder titledBorder5;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  BorderLayout borderLayout3 = new BorderLayout();
  JTable jTable1 = new JTable();
  Border border1;
  JPanel jPanel4 = new JPanel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
  Student student = new Student();
  Vector registrationVector = new Vector();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField nameText = new JTextField();
  JTextField majorText = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField typeText = new JTextField();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel7 = new JPanel();
  JTextField studentIDText = new JTextField();
  JTextField degreeText = new JTextField();
  JTextField facultyText = new JTextField();
  JLabel jLabel5 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();

  public GradeStudentUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder6 = new TitledBorder(null, "����ô�ѡ�֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));

    titledBorder5 = new TitledBorder(null, "�ѡ�֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder5,new EmptyBorder(5,5,5,5));

    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    this.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(borderLayout3);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder1);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setMinimumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("������");
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setMinimumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("��ŧ");
    jButton2.addActionListener(new GradeStudentUI_jButton2_actionAdapter(this));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder2);
    jPanel2.setLayout(borderLayout4);
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setBounds(new Rectangle(225, 37, 34, 15));
    jLabel4.setText("���");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setBounds(new Rectangle(225, 3, 72, 15));
    jLabel7.setText("����-���ʡ��");
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setBounds(new Rectangle(297, 0, 203, 24));
    nameText.setText("");
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setEnabled(true);
    majorText.setBounds(new Rectangle(297, 66, 203, 24));
    majorText.setText("");
    majorText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorText.setEnabled(true);
    jLabel6.setBounds(new Rectangle(7, 71, 89, 15));
    jLabel6.setText("�������ѡ�֡��");
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    typeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    typeText.setText("");
    typeText.setBounds(new Rectangle(105, 66, 111, 24));
    jLabel8.setBounds(new Rectangle(7, 3, 75, 15));
    jLabel8.setText("���ʹѡ�֡��");
    jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setBounds(new Rectangle(7, 37, 84, 15));
    jLabel3.setText("�дѺ��ԭ��");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setLayout(null);
    jPanel7.setPreferredSize(new Dimension(487, 100));
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setBorder(null);
    studentIDText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setText("");
    studentIDText.setBounds(new Rectangle(105, 0, 111, 24));
    studentIDText.addActionListener(new GradeStudentUI_studentIDText_actionAdapter(this));
    degreeText.setBounds(new Rectangle(105, 32, 111, 24));
    degreeText.setText("");
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setBounds(new Rectangle(297, 32, 203, 24));
    facultyText.setText("");
    facultyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setEnabled(true);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�Ң��Ԫ�");
    jLabel5.setBounds(new Rectangle(225, 71, 79, 15));
    jTable1.setRowHeight(18);
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(majorText, null);
    jPanel7.add(studentIDText, null);
    jPanel7.add(degreeText, null);
    jPanel7.add(jLabel3, null);
    jPanel7.add(jLabel8, null);
    jPanel7.add(jLabel4, null);
    jPanel7.add(facultyText, null);
    jPanel7.add(jLabel6, null);
    jPanel7.add(typeText, null);
    jPanel7.add(nameText, null);
    jPanel7.add(jLabel7, null);
    jPanel7.add(jLabel5, null);
    jPanel1.add(jPanel3,  BorderLayout.CENTER);
    jPanel3.add(jScrollPane1,  BorderLayout.CENTER);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    jPanel4.add(jButton2, null);
    jPanel4.add(jButton1, null);
    jScrollPane1.getViewport().add(jTable1, null);
    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setRowSelectionAllowed(true);
    jTable1.getTableHeader().setReorderingAllowed(false);
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
        , {null, null, null, "1", null,null}
    }
        ,
        new String[] {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au","�ô"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Integer.class, java.lang.Integer.class,java.lang.Object.class
      };
      boolean[] canEdit = new boolean[] {
          false, false, false, false, false,true
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setColumnSelectionAllowed(false);
    jTable1.setCellSelectionEnabled(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(0, 0));
    jTable1.setMaximumSize(new Dimension(0, 0));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY( (float) 0.5);
    jTable1.setAlignmentX( (float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);
  }
  public void createTable(Vector registrationVector){
    Object obj[][] = new Object[registrationVector.size()][6];
    Enumeration eRegis = registrationVector.elements();
    int row = 0;
    while (eRegis.hasMoreElements()){
      Registration r = (Registration)eRegis.nextElement();
      obj[row][0] = r.getSection().getSubject().getSubjectID();
      obj[row][1] = r.getSection().getSubject().getSubjectTname();
      obj[row][2] =  new Integer(r.getSection().getSubject().getCredit());
      obj[row][3] = new Integer(r.getSection().getSec());
      obj[row][4] = r.getType();
      obj[row][5] = (r.getGrade().equals("X") || r.getGrade().equals("") || r.getGrade() == null)?"":r.getGrade();
      row++;
    }
    String[] columnHeader = {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au","�ô"};

    jTable1.setModel(new javax.swing.table.DefaultTableModel(obj,columnHeader));
    JComboBox comboBox = new JComboBox();
    comboBox.addItem("A");
    comboBox.addItem("B+");
    comboBox.addItem("B");
    comboBox.addItem("C+");
    comboBox.addItem("C");
    comboBox.addItem("D+");
    comboBox.addItem("D");
    comboBox.addItem("F");
    comboBox.addItem("W");
    comboBox.addItem("I");
    comboBox.addItem("S");
    comboBox.addItem("U");
    TableColumn typeColumn = jTable1.getColumn("�ô");
    typeColumn.setCellEditor(new DefaultCellEditor(comboBox));
  }
  void studentIDText_actionPerformed(ActionEvent e) {
    Database.connect();
    student = student.retrieveStudent(new Student(studentIDText.getText()));
    if (student == null){
      JOptionPane.showMessageDialog(this,"����չѡ�֡�����ʹ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    nameText.setText(student.getStudentTname());
    degreeText.setText(String.valueOf(student.getDegree()));
    facultyText.setText(student.getMajor().getDepartment().getFaculty().getTname());
    typeText.setText(String.valueOf(student.getStudentType()));
    majorText.setText(student.getMajor().getTname());

    Registration registration = new Registration();
    registrationVector = registration.retrieveRegistration(student);
    if (registrationVector == null) {
      JOptionPane.showMessageDialog(this,"����բ����š��ŧ����¹�ͧ�ѡ�֡�ҷ�ҹ���","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    createTable(registrationVector);
    Database.disconnect();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    int i =0;
    Enumeration re = registrationVector.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      String str = (String)jTable1.getModel().getValueAt(i++,5);
      if (str == null || str.equals("")){
        JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      r.setGrade(str);
    }
    boolean complete = false;
    Database.connect();
    re = registrationVector.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      complete = r.updateRegistration(r);
    }
    if (complete) {
      JOptionPane.showMessageDialog(this,"�ӡ�úѹ�֡���º��������","ʶҹС�÷ӧҹ",JOptionPane.INFORMATION_MESSAGE);
    }
    Database.disconnect();
  }
}

class GradeStudentUI_studentIDText_actionAdapter implements java.awt.event.ActionListener {
  GradeStudentUI adaptee;

  GradeStudentUI_studentIDText_actionAdapter(GradeStudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.studentIDText_actionPerformed(e);
  }
}

class GradeStudentUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  GradeStudentUI adaptee;

  GradeStudentUI_jButton2_actionAdapter(GradeStudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}