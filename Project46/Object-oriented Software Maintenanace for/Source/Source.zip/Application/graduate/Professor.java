package graduate;

import java.util.*;
public class Professor {
  private String professorID;
  private Prename prename;
  private String eProfessorName;
  private String tProfessorName;
  private String password;
  private String position;
  private Department  department;
  private ProfessorDB professorDB = new ProfessorDB();
  private Vector studentVector  = new Vector();
  private Vector thesisVector = new Vector();
  private Vector sectionVector = new Vector();

  //Constructor
  public Professor() {
  }
  public Professor(String profID){
    this.setProfessorID(profID);
  }
  //getMethod
  public String getProfessorID(){
    return this.professorID;
  }
  public Prename getPrename(){
    return this.prename;
  }
  public String getEprofessorName(){
    return this.eProfessorName;
  }
  public String getTprofessorName(){
    return this.tProfessorName;
  }
  public String getPassword(){
    return this.password;
  }
  public String getPosition(){
    return this.position;
  }
  public Department getDepartment(){
    return this.department;
  }
  //setMethod
  public void setProfessorID(String professorID){
    this.professorID = professorID;
  }
  public void setPrename(Prename prename){
    this.prename = prename;
  }
  public void setEprofessorName(String eProfessorName){
    this.eProfessorName = eProfessorName;
  }
  public void setTprofessorName(String tProfessorName){
    this.tProfessorName = tProfessorName;
  }
  public void setPassword(String pw){
    this.password = pw;
  }
  public void setPosition(String position){
    this.position = position;
  }
  public void setDepartment(Department department){
    this.department = department;
  }
  //Business Method
  //-----------------------------------------------------------------------studentVector--------------------------------------------------------------
  public void addStudent(Student student){
    studentVector.addElement(student);
  }
  public void setStudent(Vector sv){
    studentVector = sv;
  }
  public Enumeration retrieveStudent(){
    return studentVector.elements();
  }
  public Student retrieveStudent(String studentID){
    Enumeration e = retrieveStudent();
    while (e.hasMoreElements()){
      Student student = (Student)e.nextElement();
      if (student.getStudentID().equals(studentID))
        return student;
    }
    return null;
  }
  //-----------------------------------------------------------------------thesisVector--------------------------------------------------------------
  public void addThesis(Thesis thesis){
    thesisVector.addElement(thesis);
  }
  public void setThesis(Vector thesisvector){
    thesisVector = thesisvector;
  }
  public Enumeration retrieveThesis(){
    return thesisVector.elements();
  }
  public Thesis retrieveThesis(long thesisID){
    Enumeration e = retrieveThesis();
    while (e.hasMoreElements()){
      Thesis thesis = (Thesis)e.nextElement();
      if (thesis.getThesisID() == thesisID)
        return thesis;
    }
    return null;
  }
  //-----------------------------------------------------------------------sectionVector--------------------------------------------------------------
  public void addSection(Section section){
    sectionVector.addElement(section);
  }
  public void setSection(Vector secvector){
    sectionVector = secvector;
  }
  public Enumeration retrieveSection(){
    return sectionVector.elements();
  }
  public Section retrieveSection(long sectionID){
    Enumeration e = retrieveSection();
    while (e.hasMoreElements()){
      Section section = (Section)e.nextElement();
      if (section.getSectionID() == sectionID)
        return section;
    }
    return null;
  }
    //---------------------------------------------------------------------Access Layer--------------------------------------------------------------
  public Vector retrieveProfessor(Department department){
    return professorDB.retrieveProfessor(department);
  }
  public Professor retrieveProfessor(String profid){
    return professorDB.retrieveProfessor(profid);
  }
  public boolean insertProfessor(Professor prof){
    return professorDB.insertProfessor(prof);
  }
  public boolean updateProfessor(Professor oldprofessor,Professor prof){
    return professorDB.updateProfessor(oldprofessor,prof);
  }
  public boolean deleteProfessor(Professor prof){
    return professorDB.deleteProfessor(prof);
  }
  public String toString(){
    return this.getPrename().getTPrename() + " " + this.getTprofessorName();
  }
}