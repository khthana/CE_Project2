package graduate;

import java.sql.*;
import java.util.*;
public class PlanDB {
  public PlanDB() {
  }
  public Vector retrievePlanAll(CourseStructure cs){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Plan WHERE CourseStructureID = " + cs.getCourseStructureID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Plan plan = new Plan();
          plan.setPlanID(rs.getLong("PlanID"));
          plan.setCourseStructure(cs);
          plan.setYearNumber(rs.getInt("YearNumber"));
          plan.setSemester(rs.getInt("Semester"));
          plan.setSubjectID(rs.getString("SubjectID"));
          plan.setSubjectEname(rs.getString("SubjectEname"));
          plan.setSubjectTname(rs.getString("SubjectTname"));
          plan.setSubjectType(rs.getInt("SubjectType"));
          plan.setCredit(rs.getInt("Credit"));
          plan.setLecture(rs.getInt("Lecture"));
          plan.setPractice(rs.getInt("Practice"));
          plan.setResearch(rs.getInt("Research"));
          v.addElement(plan);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertPlan(Plan plan){
    String query = "INSERT INTO Plan(CourseStructureID,YearNumber,Semester,";
    query += "SubjectID,SubjectEname,SubjectTname,SubjectType,Credit,Lecture,Practice,Research) ";
    query += "VALUES("+ plan.getCourseStructure().getCourseStructureID() + " , " + plan.getYearNumber();
    query += ", " + plan.getSemester() + ",'" + plan.getSubjectID() + "','" + plan.getSubjectEname() + "'";
    query += ", '" + plan.getSubjectTname() + "'," + plan.getSubjectType() + "," + plan.getCredit();
    query += "," + plan.getLecture() + "," + plan.getPractice() + "," + plan.getResearch() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updatePlan(Plan plan){
    String query = "UPDATE Plan SET ";
    query += "CourseStructureID = " + plan.getCourseStructure().getCourseStructureID() + ", ";
    query += "YearNumber = " + plan.getYearNumber() + ", ";
    query += "Semester = " + plan.getSemester() + ", ";
    query += "SubjectID = '" + plan.getSubjectID() + "', ";
    query += "SubjectEname = '" + plan.getSubjectEname() + "', ";
    query += "SubjectTname = '" + plan.getSubjectTname() + "', ";
    query += "Credit = " + plan.getCredit() + ", ";
    query += "Lecture = " + plan.getLecture() + ", ";
    query += "Practice = " + plan.getPractice() + ", ";
    query += "Research = " + plan.getResearch() + " ";
    query += "WHERE PlanID = " + plan.getPlanID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deletePlan(Plan plan){
    String query = "DELETE FROM Plan WHERE PlanID = '" + plan.getPlanID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    PlanDB db = new PlanDB();
    Plan d = new Plan(1);
    d.setCourseStructure(new CourseStructure(1));
    d.setYearNumber(1);
    d.setSemester(1);
    d.setSubjectID("001");
    d.setSubjectEname("English");
    d.setSubjectTname("Thai");
    d.setSubjectType(2);
    d.setCredit(3);
    d.setLecture(0);
    d.setPractice(3);
    d.setResearch(0);
//    db.updatePlan(d);
    Vector v = db.retrievePlanAll(new CourseStructure(1));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Plan p = (Plan)e.nextElement();
      System.out.println(p.getPlanID() + " " + p.getCourseStructure().getCourseStructureID() + " " + p.getYearNumber());
      System.out.println(p.getSemester() + " " + p.getSubjectID() + " " + p.getSubjectEname() + " " + p.getSubjectTname());
      System.out.println(p.getSubjectType() + " " + p.getCredit() + "  " + p.getLecture() + " " + p.getPractice() + " " + p.getResearch());
    }
    Database.disconnect();
  }

}