package graduate;

public class Teach {
  private Section section;
  private Professor professor;
  //Constructor
  public Teach() {
  }
  //getMethod
  public Section getSection(){
    return this.section;
  }
  public Professor getProfessor(){
    return this.professor;
  }
  //setMethod
  public void setSection(Section sec){
    this.section = sec;
  }
  public void setProfessor(Professor prof){
    this.professor = prof;
  }

}