package graduate;

import java.util.*;
public class Schedule {
  private long scheduleID;
  private Date fromDate;
  private Date toDate;
  private ScheduleDB scheduleDB = new ScheduleDB();
  //Constructor
  public Schedule() {
  }
  public Schedule(long id){
    this.setScheduleID(id);
  }
  public Schedule(Date f,Date t){
    this.setFromDate(f);
    this.setToDate(t);
  }
  public Schedule(long id,Date f,Date t){
    this.setScheduleID(id);
    this.setFromDate(f);
    this.setToDate(t);
  }
  //getMethod
  public long getScheduleID(){
    return this.scheduleID;
  }
  public Date getFromDate(){
    return this.fromDate;
  }
  public Date getToDate(){
    return this.toDate;
  }
  //setMethod
  public void setScheduleID(long scheduleID){
    this.scheduleID = scheduleID;
  }
  public void setFromDate(Date fromdate){
    this.fromDate = fromdate;
  }
  public void setToDate(Date todate){
    this.toDate = todate;
  }
  //Busines Method

  //Access Method
  public Vector retrieveSchedule(){
    return scheduleDB.retrieveSchedule();
  }
  public boolean insertSchedule(Schedule s){
    return scheduleDB.insertSchedule(s);
  }
  public boolean updateSchedule(Schedule s){
    return scheduleDB.updateSchedule(s);
  }
  public boolean deleteSchedule(Schedule s){
    return scheduleDB.deleteSchedule(s);
  }

}