package graduate;

import java.util.*;
public class Section {
  private long  SectionID;
  private Semester semester;
  private int level;
  private String  beginTime;
  private String endTime;
  private String room;
  private int day;
  private Date midtermDate;
  private String midtermBtime;
  private String midtermEtime;
  private String  midtermRoom;
  private Date FinalDate;
  private String finalBtime;
  private String finalEtime;
  private String finalRoom;
  private int max;
  private int current;
  private int sec;
  private boolean lock;
  private boolean status;
  private Subject subject;
  private SectionDB sectionDB = new SectionDB();
  private Vector professorVector = new Vector();
  //Constructor
  public Section() {
  }
  public Section(long sectionID){
    this.setSectionID(sectionID);
  }
  //getMethod
  public long getSectionID(){
    return this.SectionID;
  }
  public Semester getSemester(){
    return this.semester;
  }
  public int getLevel(){
    return this.level;
  }
  public String getBeginTime(){
    return this.beginTime;
  }
  public String getEndTime(){
    return this.endTime;
  }
  public String getRoom(){
    return this.room;
  }
  public int getDay(){
    return this.day;
  }
  public Date getMidtermDate(){
    return this.midtermDate;
  }
  public String getMidtermBtime(){
    return this.midtermBtime;
  }
  public String getMidtermEtime(){
    return this.midtermEtime;
  }
  public String getMidtermRoom(){
    return this.midtermRoom;
  }
  public Date getFinalDate(){
    return this.FinalDate;
  }
  public String getFinalBtime(){
    return this.finalBtime;
  }
  public String getFinalEtime(){
    return this.finalEtime;
  }
  public String getFinalRoom(){
    return this.finalRoom;
  }
  public int getMax(){
    return this.max;
  }
  public int getCurent(){
    return this.current;
  }
  public int getSec(){
    return this.sec;
  }
  public boolean getLock(){
    return this.lock;
  }
  public boolean getStatus(){
    return this.status;
  }
  public Subject getSubject(){
    return this.subject;
  }
  //setMethod
  public void setSectionID(long sectionid){
    this.SectionID = sectionid;
  }
  public void setSemeter(Semester semester){
    this.semester = semester;
  }
  public void setLevel(int level){
    this.level = level;
  }
  public void setBeginTime(String btime){
    this.beginTime = btime;
  }
  public void setEndTime(String  etime){
    this.endTime = etime;
  }
  public void setRoom(String room){
    this.room = room;
  }
  public void setDay(int day){
    this.day = day;
  }
  public void setMidtermDate(Date d){
    this.midtermDate = d;
  }
  public void setMidtermBtime(String btime){
    this.midtermBtime = btime;
  }
  public void setMidtermEtime(String etime){
    this.midtermEtime = etime;
  }
  public void setMidtermRoom(String r){
    this.midtermRoom = r;
  }
  public void setFinalDate(Date f){
    this.FinalDate = f;
  }
  public void setFinalBtime(String btime){
    this.finalBtime = btime;
  }
  public void setFinalEtime(String etime){
    this.finalEtime = etime;
  }
  public void setFinalRoom(String rm){
    this.finalRoom = rm;
  }
  public void setMax(int max){
    this.max = max;
  }
  public void setCurrent(int current){
    this.current = current;
  }
  public void setSec(int sec){
    this.sec = sec;
  }
  public void setLock(boolean lock){
    this.lock = lock;
  }
  public void setStatus(boolean status){
    this.status = status;
  }
  public void setSubject(Subject s){
    this.subject = s;
  }
  //Business Method
  //-------------------------------------------------------------------------professorVector---------------------------------------------------------------
  public void addProfessor(Professor prof){
    professorVector.addElement(prof);
  }
  public void setProfessor(Vector prof){
    professorVector = prof;
  }
  public Enumeration retrieveProfessor(){
    return professorVector.elements();
  }
  public Professor retrieveProfessor(String profID){
    Enumeration e = retrieveProfessor();
    while (e.hasMoreElements()){
      Professor professor = (Professor)e.nextElement();
      if (professor.getProfessorID().equals(profID))
        return professor;
    }
    return null;
  }
  //---------------------------------------------------------------------------Access Layer----------------------------------------------------------------
  public Vector retrieveSection(Subject subject){
    return sectionDB.retrieveSection(subject);
  }
  public Vector retrieveProfessor(Section section){
    return sectionDB.retrieveProfessor(section);
  }
  public boolean insertSection(Section section){
    return sectionDB.insertSection(section);
  }
  public boolean updateSection(Section oldsection,Section section){
    return sectionDB.updateSection(oldsection,section);
  }
  public boolean deleteSection(Section section){
    return sectionDB.deleteSection(section);
  }
  public String toString(){
    return  Integer.toString(this.getSec());
  }
  public boolean checkAvailable(){
    if (this.lock){
      return (this.max-this.current > 0)?true:false;
    }
    return true;
  }
  public boolean incrementStudent(Section section) {
      return sectionDB.incrementStudent(section);
  }
}