package graduate;

import java.sql.*;
import java.util.*;
public class SupportDB {
  public SupportDB() {
  }
  public Vector retrieveSupportAll(Major major){
    Vector v = new Vector();
    try
    {
        String query = "SELECT l.*,s.* FROM Location l, Support s WHERE l.LocationID = s.LocationID AND ";
        query += "s.MajorID = '" + major.getMajorID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Support support = new Support();
          Location location = new Location();
          support.setSupportID(rs.getLong("SupportID"));
          support.setStudyGroup(rs.getInt("StudyGroup"));
          support.setStudentType(rs.getInt("StudentType"));
          location.setLocationID(rs.getLong("LocationID"));
          location.setLocationName(rs.getString("LocationName"));
          support.setLocation(location);
          support.setNationalStatus(rs.getBoolean("NationalStatus"));
          support.setNumterm(rs.getInt("NumTerm"));
          support.setMoney(rs.getDouble("SupportMoney"));
          support.setMajor(major);
          v.addElement(support);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveSupport(Major major,int study,int studentType,long locationID,boolean national){
  Vector v = new Vector();
  try
  {
      String query = "SELECT * FROM Support  WHERE ";
      query += "MajorID = '" + major.getMajorID() + "' AND ";
      query += "StudyGroup = " + study + " AND ";
      query += "StudentType = " + studentType + " AND ";
      query += "LocationID = " + locationID + " AND ";
      query += "NationalStatus = " + ((national)?2:1);
      ResultSet rs = Database.getResultSet(query);

      while(rs.next()){
        Support support = new Support();
        support.setSupportID(rs.getLong("SupportID"));
        support.setStudyGroup(rs.getInt("StudyGroup"));
        support.setStudentType(rs.getInt("StudentType"));
        support.setLocation(new Location(rs.getLong("LocationID")));
        support.setNationalStatus((rs.getInt("NationalStatus")==1)?false:true);
        support.setNumterm(rs.getInt("NumTerm"));
        support.setMoney(rs.getDouble("SupportMoney"));
        support.setMajor(major);
        v.addElement(support);
      }
  }
  catch(SQLException sqlex)
  {
      System.out.println(sqlex.toString());
  }
  return v;
}
  public boolean insertSupport(Support support){
    String query = "INSERT INTO Support(StudyGroup,StudentType,LocationID,NationalStatus,Numterm,SupportMoney,MajorID) ";
    query += "VALUES("+ support.getStudyGroup() + " , " + support.getStudentType();
    query += ", " + support.getLocation().getLocationID() + "," + Integer.toString((support.getNationalStatus())?2:1) + "," + support.getNumterm();
    query += ", " + support.getMoney() + ", '" + support.getMajor().getMajorID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateSupport(Support support){
    String query = "UPDATE Support SET ";
    query += "StudyGroup = " + support.getStudyGroup() + ", ";
    query += "StudentType = " + support.getStudentType() + ", ";
    query += "LocationID = " + support.getLocation().getLocationID() + ", ";
    query += "NationalStatus = " + ((support.getNationalStatus())?2:1) + ", ";
    query += "Numterm = " + support.getNumterm() + ", ";
    query += "SupportMoney = " + support.getMoney() + ", ";
    query += "MajorID = '" + support.getMajor().getMajorID() + "' ";
    query += "WHERE SupportID = " + support.getSupportID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSupport(Support support){
    String query = "DELETE FROM Support WHERE SupportID = " + support.getSupportID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    SupportDB db = new SupportDB();
    Vector v = db.retrieveSupport(new Major("004"),1,1,1,false);
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Support ss = (Support) e.nextElement();
      System.out.print(ss.getSupportID() + " " + ss.getStudyGroup() + " " +
                       ss.getStudentType() + " " +
                       ss.getLocation().getLocationName());
      System.out.println(" " + ss.getNationalStatus() + " " + ss.getNumterm() +
                       " " + ss.getMoney() + " " + ss.getMajor().getMajorID());
    }
    Database.disconnect();
  }

}