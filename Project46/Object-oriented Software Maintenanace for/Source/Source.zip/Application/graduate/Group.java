package graduate;

import java.util.*;
public class Group {
  private long groupID;
  private String groupName;
  private GroupDB groupDB = new GroupDB();
  //Constructor
  public Group() {
  }
  public Group(long id){
    this.setGroupID(id);
  }
  public Group(String name){
    this.setGroupName(name);
  }
  public Group(long id,String name){
    this.setGroupID(id);
    this.setGroupName(name);
  }
  //getMethod
  public long getGroup(){
    return this.groupID;
  }
  public String getGroupName(){
    return this.groupName;
  }
  //setMethod
  public void setGroupID(long groupID){
    this.groupID = groupID;
  }
  public void setGroupName(String groupName){
    this.groupName = groupName;
  }
  public Vector retrieveGroup(){
    return  groupDB.retrieveGroup();
  }
  public boolean insertGroup(Group gp){
    return groupDB.insertGroup(gp);
  }
  public boolean updateGroup(Group gp){
    return groupDB.updateGroup(gp);
  }
  public boolean deleteGroup(Group gp){
    return groupDB.deleteGroup(gp);
  }
  public String toString(){
    return this.getGroupName();
  }
}