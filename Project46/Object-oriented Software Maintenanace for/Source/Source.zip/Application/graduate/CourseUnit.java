package graduate;

import java.util.*;
public class CourseUnit {
  private Group group;
  private Major major;
  private Degree degree;
  private int groupUnit;
  private CourseUnitDB cuDB = new CourseUnitDB();
  //Constructor
  public CourseUnit() {
  }
  //getMethod
  public Group getGroup(){
    return this.group;
  }
  public Major getMajor(){
    return this.major;
  }
  public Degree getDegree(){
    return this.degree;
  }
  public int getGroupUnit(){
    return this.groupUnit;
  }
  //setMethod
  public void setGroup(Group group){
    this.group = group;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void setDegree(Degree degree){
    this.degree  = degree;
  }
  public void setGroupUnit(int groupUnit){
    this.groupUnit = groupUnit;
  }
  //Business method-------------------------------------------------------------------------------------------------------------------------------------
  public Vector retrieveCourseUnit(Major major){
    return cuDB.retrieveCourseUnit(major);
  }
  public Vector retrieveCourseUnit(Major major,Degree degree){
    return cuDB.retrieveCourseUnit(major,degree);
  }
  public boolean insertCourseUnit(CourseUnit cu){
    return cuDB.insertCourseUnit(cu);
  }
  public boolean updateCourseUnit(CourseUnit cu,CourseUnit nw){
    return cuDB.updateCourseUnit(cu,nw);
  }
  public boolean deleteCourseUnit(CourseUnit cu){
    return cuDB.deleteCourseUnit(cu);
  }
}