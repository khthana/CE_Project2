package graduate;

public class PrerequisiteDB {
  public PrerequisiteDB() {
  }
  public boolean insertPrerequisite(Prerequisite prerequisite){
    String query = "INSERT INTO Prerequisite(SubjectID,PreSubjectID) ";
    query = query + "VALUES('" + prerequisite.getSubject().getSubjectID() + "','" + prerequisite.getPreSubject().getSubjectID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updatePrerequisite(Prerequisite oldPrerequisite,Prerequisite newPrerequisite){
    String query = "UPDATE Prerequisite SET ";
    query = query + "SubjectID = '" + newPrerequisite.getSubject().getSubjectID() + "', ";
    query = query + "PreSubjectID = '" + newPrerequisite.getSubject().getSubjectID()+ "' ";
    query = query + "WHERE SubjectID = '" + oldPrerequisite.getSubject().getSubjectID() + "' AND ";
    query = query + "PreSubjectID = '" + oldPrerequisite.getPreSubject().getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deletePrerequisite(Prerequisite prerequisite){
    String query = "DELETE FROM Prerequisite ";
    query = query + "WHERE SubjectID = '" + prerequisite.getSubject().getSubjectID() + "' AND ";
    query = query + "PreSubjectID = '" + prerequisite.getPreSubject().getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }

}