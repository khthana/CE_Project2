package graduate;

public class Scholar {
  private Student student;
  private Scholarship scholarship;
  //Constructor
  public Scholar() {
  }
  //getMethod
  public Student getStudent(){
    return this.student;
  }
  public Scholarship getScholarship(){
    return this.scholarship;
  }
  //setMethod
  public void setStudent(Student s){
    this.student = s;
  }
  public void setScholarship(Scholarship ss){
    this.scholarship = ss;
  }

}