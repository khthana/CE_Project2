package graduate;

import java.sql.*;
import java.util.*;
public class RegistrarDB {
  public RegistrarDB() {
  }
  public Vector retrieveRegistrarAll(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,p.* FROM Registrar r,Prename p WHERE r.PrenameID = p.PrenameID ORDER BY RegistrarTname";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Registrar registrar = new Registrar();
          registrar.setRegistrarID(rs.getString("RegistrarID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          registrar.setPrename(p);
          registrar.setEname(rs.getString("RegistrarEname"));
          registrar.setTname(rs.getString("RegistrarTname"));
          registrar.setPosition(rs.getString("Position"));
          registrar.setPassword(rs.getString("Password"));
          registrar.setPermission(rs.getInt("Permission"));
          v.addElement(registrar);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveRegistrar(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,p.* FROM Registrar r,Prename p WHERE r.PrenameID = p.PrenameID ORDER BY RegistrarTname";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Registrar registrar = new Registrar();
          registrar.setRegistrarID(rs.getString("RegistrarID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          registrar.setPrename(p);
          registrar.setTname(rs.getString("RegistrarTname"));
          v.addElement(registrar);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean validate(Registrar person){
    try {
      String query = "SELECT r.RegistrarID,r.Password FROM Registrar r WHERE ";
      query += "r.RegistrarID = '" + person.getRegistrarID() +
          "' AND r.Password = '" + person.getPassword() + "'";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        return true;
      }
    }
      catch (SQLException sqlex) {
        System.out.println(sqlex.toString());
      }
      return false;
  }
  public boolean insertRegistrar(Registrar registrar){
    String query = "INSERT INTO Registrar(RegistrarID,PrenameID,RegistrarEname,RegistrarTname,Position,Password,Permission) ";
    query += "VALUES('"+ registrar.getRegistrarID() + "' , " + registrar.getPrename().getPrenameID() + " , '" + registrar.getEname() + "'";
    query += ", '" + registrar.getTname() + "','" + registrar.getPosition() + "','" + registrar.getPassword() + "'";
    query += ", " + registrar.getPermission() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateRegistrar(Registrar oldregistrar,Registrar registrar){
    String query = "UPDATE Registrar SET ";
    query += "RegistrarID = '" + registrar.getRegistrarID() + "', ";
    query += "PrenameID = " + registrar.getPrename().getPrenameID() + ", ";
    query += "RegistrarEname = '" + registrar.getEname() + "', ";
    query += "RegistrarTname = '" + registrar.getTname() + "', ";
    query += "Position = '" + registrar.getPosition() + "', ";
    query += "Password = '" + registrar.getPassword() + "', ";
    query += "Permission = " + registrar.getPermission() + " ";
    query += "WHERE RegistrarID = '" + oldregistrar.getRegistrarID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteRegistrar(Registrar registrar){
    String query = "DELETE FROM Registrar WHERE RegistrarID = '" + registrar.getRegistrarID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    RegistrarDB db = new RegistrarDB();
    Registrar p = new Registrar("001");
    p.setPrename(new Prename(1));
    p.setEname("BBBBBB");
    p.setTname("AAAAAAA");
    p.setPassword("123456");
    p.setPosition("Dean");
    p.setPermission(1);
//    p.updateRegistrar(p);
/*    Vector v = db.retrieveProfessor(new Department("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Professor prof = (Professor)e.nextElement();
      System.out.println(prof.getProfessorID() + " " + prof.getPrename().getEprename() + " " + prof.getEprofessorName());
      System.out.println(prof.getTprofessorName() + " " + prof.getPosition() + " " + prof.getPassword() + " " + prof.getDepartment().getDepartmentID());
    }*/
    Database.disconnect();
  }

}