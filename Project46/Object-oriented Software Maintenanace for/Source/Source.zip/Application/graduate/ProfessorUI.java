package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class ProfessorUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("�Ҩ����");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  FlowLayout flowLayout5 = new FlowLayout();
  JPanel jPanel19 = new JPanel();
  JTextField positionText = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JTextField profEnameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  FlowLayout flowLayout4 = new FlowLayout();
  JTextField profIDText = new JTextField();
  JPanel jPanel25 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel16 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  JPanel jPanel8 = new JPanel();
  FlowLayout flowLayout6 = new FlowLayout();
  JTextField profTnameText = new JTextField();
  JPanel jPanel110 = new JPanel();
  JTextField ePrenameText = new JTextField();
  FlowLayout flowLayout7 = new FlowLayout();
  JPanel jPanel30 = new JPanel();
  JComboBox tPrenameCombo = new JComboBox();
  FlowLayout flowLayout8 = new FlowLayout();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel2 = new JLabel();
  Border border1;
  Border border2;
  //-----------------------------------------------------------------------------------------------------------------------------------------------------
  Faculty facultyInit = new Faculty();
  Department departmentInit = new Department();
  Department department = null;
  Professor currentProf = null;
  Professor professor = new Professor();
  boolean newRecord = false;
  boolean canAdd = false;

  public ProfessorUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    border2 = BorderFactory.createEmptyBorder(10,5,5,5);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("����");
    jButton2.addActionListener(new ProfessorUI_jButton2_actionAdapter(this));
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new ProfessorUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border2);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder6 = new TitledBorder(null, "��������´�Ҩ����",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel4.setBorder(titledBorder1);
    jPanel4.setPreferredSize(new Dimension(440, 240));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(border1);
    jSplitPane1.setContinuousLayout(true);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 250));
    jPanel2.setLayout(boxLayout21);
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    positionText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    positionText.setPreferredSize(new Dimension(380, 22));
    positionText.setText("");
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(6);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 220));
    flowLayout3.setAlignment(FlowLayout.LEFT);
    profEnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    profEnameText.setPreferredSize(new Dimension(380, 22));
    profEnameText.setText("");
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 200));
    flowLayout4.setAlignment(FlowLayout.LEFT);
    profIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    profIDText.setOpaque(true);
    profIDText.setPreferredSize(new Dimension(380, 22));
    profIDText.setText("");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(6);
    gridLayout1.setVgap(5);
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    jPanel16.setLayout(flowLayout1);
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setPreferredSize(new Dimension(161, 35));
    flowLayout1.setVgap(15);
    flowLayout1.setHgap(5);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new ProfessorUI_saveButton_actionAdapter(this));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setText("������");
    clearButton.addActionListener(new ProfessorUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout6.setAlignment(FlowLayout.LEFT);
    profTnameText.setPreferredSize(new Dimension(380, 22));
    profTnameText.setText("");
    profTnameText.setOpaque(true);
    profTnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel110.setLayout(flowLayout6);
    jPanel110.setPreferredSize(new Dimension(320, 32));
    jPanel110.setMaximumSize(new Dimension(32767, 32767));
    jPanel110.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    ePrenameText.setPreferredSize(new Dimension(380, 22));
    ePrenameText.setText("");
    ePrenameText.setOpaque(true);
    ePrenameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    tPrenameCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
    tPrenameCombo.setPreferredSize(new Dimension(150, 22));
    jPanel8.setPreferredSize(new Dimension(320, 32));
    jPanel8.setLayout(flowLayout8);
    flowLayout8.setAlignment(FlowLayout.LEFT);
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("���˹�");
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�ӹ�˹�Ҫ���[�] :");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("�ӹ�˹�Ҫ���[�] :");
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("�����Ҩ���� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setText("�����Ҩ����[�] :");
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("�����Ҩ����[�] :");
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel6.add(jPanel9,  BorderLayout.CENTER);
    jPanel6.add(jPanel10,  BorderLayout.WEST);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel4, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel5, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(jLabel6, null);
    jPanel9.add(jPanel17, null);
    jPanel17.add(profIDText, null);
    jPanel9.add(jPanel30, null);
    jPanel30.add(tPrenameCombo, null);
    jPanel9.add(jPanel110, null);
    jPanel110.add(profTnameText, null);
    jPanel9.add(jPanel8, null);
    jPanel8.add(ePrenameText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(profEnameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(positionText, null);
    jPanel4.add(jPanel16, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    jSplitPane1.add(jPanel2, JSplitPane.RIGHT);
    jPanel2.add(jPanel4, null);
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jPanel2.setBorder(border1);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());

    createTree();
    addPrename();
  }

  public void clear(){
    profIDText.setText("");
    tPrenameCombo.setSelectedIndex(0);
    profTnameText.setText("");
    ePrenameText.setText(((Prename)tPrenameCombo.getSelectedItem()).getEprename());
    profEnameText.setText("");
    positionText.setText("");
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Professor professor = new Professor();
    if (profIDText.getText().equals("")){
      JOptionPane.showMessageDialog(this,"��سҡ�͡�����Ҩ����","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    professor.setProfessorID(profIDText.getText());
    professor.setPrename((Prename)tPrenameCombo.getSelectedItem());
    professor.setEprofessorName(profEnameText.getText());
    professor.setTprofessorName(profTnameText.getText());
    professor.setPosition(positionText.getText());
    professor.setPassword("xxxxxx");
    professor.setDepartment(department);
    Database.connect();
    if (newRecord){
      complete = professor.insertProfessor(professor);
      if (complete) addNode(professor);
    }
    else {
      complete = professor.updateProfessor(currentProf,professor);
      updateNode(professor);
    }
    Database.disconnect();
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof Department){
        canAdd = true;
      }
      if (nodeInfo instanceof Professor){
        canAdd = false;
        DefaultMutableTreeNode departmentNode = (DefaultMutableTreeNode)node1.getParent();
        department = (Department)departmentNode.getUserObject();
        currentProf = (Professor)nodeInfo;
        showUI((Professor)nodeInfo);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode facultyNode = null;
    DefaultMutableTreeNode departmentNode = null;
    DefaultMutableTreeNode profNode = null;

    Vector facultyVector = facultyInit.retrieveFacultyAll();
    Enumeration facultyEnum = facultyVector.elements();
    while (facultyEnum.hasMoreElements()){
      Faculty fac = (Faculty)facultyEnum.nextElement();
      facultyNode = new DefaultMutableTreeNode(fac);
      root.add(facultyNode);

      Vector departmentVector = departmentInit.retrieveDepartmentAll(fac);
      Enumeration departmentEnum = departmentVector.elements();
      while (departmentEnum.hasMoreElements()){
        Department dep = (Department)departmentEnum.nextElement();
        departmentNode = new DefaultMutableTreeNode(dep);
        facultyNode.add(departmentNode);

        Vector profVector = professor.retrieveProfessor(dep);
        Enumeration profEnum = profVector.elements();
        while (profEnum.hasMoreElements()){
          Professor prof = (Professor)profEnum.nextElement();
          profNode = new DefaultMutableTreeNode(prof);
          departmentNode.add(profNode);
        }
      }
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }
  public void addPrename(){
    Database.connect();
    Prename prename = new Prename();
    Vector v = prename.retrievePrename();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Prename pre  = (Prename)e.nextElement();
      tPrenameCombo.addItem(pre);
    }
    Database.disconnect();
  }
  public void showUI(Professor prof){
    newRecord = false;
    profIDText.setText(prof.getProfessorID());
    setSelectedName(prof.getPrename().getTPrename());
    profTnameText.setText(prof.getTprofessorName());
    profEnameText.setText(prof.getEprofessorName());
    positionText.setText(prof.getPosition());
  }

  public void updateNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    lastItem.setUserObject(obj);
    jTree1.repaint();
  }

  public void setSelectedName(String name)
  {
     for (int i = 0;i < tPrenameCombo.getItemCount();++i)
     {
        Prename item = (Prename)tPrenameCombo.getItemAt(i);
        if (item.getTPrename() .equals(name))
        {
           tPrenameCombo.setSelectedItem(item);
           ePrenameText.setText(item.getEprename());
           return;
        }
     }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    newRecord = true;
    clear();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Professor) {
          Professor del = (Professor)obj;
          Database.connect();
          complete = del.deleteProfessor(del);
          Database.disconnect();
        }
        if (complete) {
          treeModel.removeNodeFromParent(node);
          clear();
        }
      }
    }
  }
}

class ProfessorUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  ProfessorUI adaptee;

  ProfessorUI_clearButton_actionAdapter(ProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class ProfessorUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  ProfessorUI adaptee;

  ProfessorUI_saveButton_actionAdapter(ProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class ProfessorUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  ProfessorUI adaptee;

  ProfessorUI_jButton2_actionAdapter(ProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class ProfessorUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  ProfessorUI adaptee;

  ProfessorUI_jButton3_actionAdapter(ProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}