package graduate;

import java.util.*;
public class Occupation {
  private long occupationID;
  private String occupationName;
  private OccupationDB occupationDB = new OccupationDB();
  //Constructor
  public Occupation() {
  }
  public Occupation(long id){
    this.setOccupationID(id);
  }
  public Occupation(String name){
    this.setOccupationName(name);
  }
  public Occupation(long id,String name){
    this.setOccupationID(id);
    this.setOccupationName(name);
  }
  //getMethod
  public long getOccupationID(){
    return this.occupationID;
  }
  public String getOccupationName(){
    return this.occupationName;
  }
  public void setOccupationID(long occupationID){
    this.occupationID = occupationID;
  }
  public void setOccupationName(String occupationName){
    this.occupationName = occupationName;
  }
  //Access method
  public Vector retrieveOccupation(){
    return occupationDB.retrieveOccupation();
  }
  public Occupation retrieveOccupation(long oid){
    return occupationDB.retrieveOccupation(oid);
  }
  public boolean insertOccupation(Occupation c){
    return occupationDB.insertOccupation(c);
  }
  public boolean updateOccupation(Occupation c){
    return occupationDB.updateOccupation(c);
  }
  public boolean deleteOccupation(Occupation c){
    return occupationDB.deleteOccupation(c);
  }
  public String toString(){
    return  this.getOccupationName();
  }

}