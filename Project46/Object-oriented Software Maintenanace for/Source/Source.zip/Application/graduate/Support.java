package graduate;

import java.util.*;
public class Support {
  private long supportID;
  private int studyGroup;
  private int studentType;
  private Location location;
  private boolean nationalStatus;
  private int numterm;
  private double money;
  private Major major;
  private SupportDB supportDB = new SupportDB();
  //Constructor
  public Support() {
  }
  public Support(long id){
    this.setSupportID(id);
  }
  //getMethod
  public long getSupportID(){
    return this.supportID;
  }
  public int getStudyGroup(){
    return this.studyGroup;
  }
  public int getStudentType(){
    return this.studentType;
  }
  public Location getLocation(){
    return this.location;
  }
  public boolean getNationalStatus(){
    return this.nationalStatus;
  }
  public int getNumterm(){
    return this.numterm;
  }
  public double getMoney(){
    return this.money;
  }
  public Major getMajor(){
    return this.major;
  }
  //setMethod
  public void setSupportID(long sid){
    this.supportID = sid;
  }
  public void setStudyGroup(int sg){
    this.studyGroup = sg;
  }
  public void setStudentType(int st){
    this.studentType = st;
  }
  public void setLocation(Location l){
    this.location = l;
  }
  public void setNationalStatus(boolean ns){
    this.nationalStatus = ns;
  }
  public void setNumterm(int nt){
    this.numterm = nt;
  }
  public void setMoney(double money){
    this.money = money;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  //Business Method
  public Vector retrieveSupportAll(Major major){
    return supportDB.retrieveSupportAll(major);
  }
  public Vector retrieveSupport(Major major,int study,int studentType,long locationID,boolean national){
    return supportDB.retrieveSupport(major,study,studentType,locationID,national);
  }
  public boolean insertSupport(Support support){
    return supportDB.insertSupport(support);
  }
  public boolean updateSupport(Support support){
    return supportDB.updateSupport(support);
  }
  public boolean deleteSupport(Support support){
    return supportDB.deleteSupport(support);
  }
  public String toString(){
    String study = "",type = "",nation="";
    switch (this.getStudyGroup())
    {
      case 1: study = "�Ҥ����"; break;
      case 2: study = "�Ҥ����"; break;
      case 3: study = "�Ҥ����� (�����-�ҷԵ��)"; break;
      case 4: study = "�Ҥ����� (�͡�����Ҫ���)"; break;
      case 5: study = "��ѡ�ٵùҹҪҵ�"; break;
      default : break;
    }
    switch (this.getStudentType())
    {
      case 1: type = "���ѭ"; break;
      case 2: type = "���ͧ���¹"; break;
      default : break;
    }
    if (this.getNationalStatus()) nation = "��ҧ�ҵ�";
    else nation = "��";
    return type + ":" + study + ":" + nation;
  }
}