package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import java.awt.event.*;
import java.util.*;

public class SubjectUI extends JPanel {
  CompoundBorder titledBorder4;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  Border border1;
  TitledBorder titledBorder3;
  Border border2;
  Border border3;
  JLabel jLabel4 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JTextField tSubjectText = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField lectureText = new JTextField();
  JTextField subjectIDText = new JTextField();
  JLabel jLabel14 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JTextField eSubjectText = new JTextField();
  JTextField creditText = new JTextField();
  JScrollPane jScrollPane2 = new JScrollPane();
  JLabel jLabel9 = new JLabel();
  JTextField prerequisiteText1 = new JTextField();
  JTextField practiceText = new JTextField();
  JTextField prerequisiteText2 = new JTextField();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField researchText = new JTextField();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JScrollPane jScrollPane3 = new JScrollPane();
  JComboBox groupCombo = new JComboBox();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextArea eDescriptionText = new JTextArea();
  JTextArea tDescriptionText = new JTextArea();
  Border border4;
  JButton clearButton = new JButton();
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  boolean newRecord = false;
  Major major;
  Subject subject;
  CourseUI courseUI;
  JPanel jPanel3 = new JPanel();
  Border border5;
  TitledBorder titledBorder5;
  JRadioButton normRadio = new JRadioButton();
  JRadioButton baseRadio = new JRadioButton();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  JButton jButton1 = new JButton();
  public SubjectUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public SubjectUI(CourseUI courseUI) {
    try {
      this.courseUI = courseUI;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�ԪҺѧ�Ѻ");
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"˹��¡Ե");
    titledBorder6 = new TitledBorder(null, "����Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    border4 = BorderFactory.createEmptyBorder(5,5,5,5);
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder5 = new TitledBorder(border5,"�������Ԫ�");
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder4 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    border1 = BorderFactory.createEmptyBorder();
    titledBorder3 = new TitledBorder(BorderFactory.createEmptyBorder(5,5,5,5),"");
    border2 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(165, 163, 151)),"����Ԫ�");
    border3 = BorderFactory.createEmptyBorder(5,5,5,5);
    this.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(titledBorder4);
    jPanel1.setDebugGraphicsOptions(0);
    jPanel1.setOpaque(true);
    jPanel1.setPreferredSize(new Dimension(380, 500));
    this.setBorder(border4);
    this.setPreferredSize(new Dimension(380, 530));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel4.setText("1 :");
    jLabel4.setBounds(new Rectangle(14, 31, 34, 15));
    jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel8.setText("��͸Ժ������Ԫ� [�]");
    jLabel8.setBounds(new Rectangle(6, 347, 126, 24));
    jLabel12.setBounds(new Rectangle(6, 251, 126, 24));
    jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel12.setText("��͸Ժ������Ԫ� [�]");
    jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel13.setText("2 :");
    jLabel13.setBounds(new Rectangle(14, 69, 40, 15));
    tSubjectText.setPreferredSize(new Dimension(300, 25));
    tSubjectText.setText("");
    tSubjectText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    tSubjectText.setOpaque(true);
    tSubjectText.setBounds(new Rectangle(110, 64, 350, 25));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setText("�����Ԫ������ѧ���");
    jLabel3.setBounds(new Rectangle(5, 32, 126, 24));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setText("�����Ԫ�");
    jLabel2.setBounds(new Rectangle(8, 0, 126, 24));
    lectureText.setBounds(new Rectangle(118, 23, 72, 21));
    lectureText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    lectureText.setText("");
    subjectIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    subjectIDText.setText("");
    subjectIDText.setBounds(new Rectangle(111, 0, 114, 25));
    jLabel14.setBounds(new Rectangle(309, 98, 66, 25));
    jLabel14.setText("˹��¡Ե���");
    jLabel14.setToolTipText("");
    jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder3);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(380, 500));
    jPanel2.setLayout(null);
    eSubjectText.setBounds(new Rectangle(110, 32, 350, 25));
    eSubjectText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    eSubjectText.setOpaque(true);
    eSubjectText.setPreferredSize(new Dimension(300, 25));
    eSubjectText.setText("");
    creditText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    creditText.setText("");
    creditText.setBounds(new Rectangle(385, 98, 74, 25));
    jScrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    jScrollPane2.setAutoscrolls(false);
    jScrollPane2.setVerifyInputWhenFocusTarget(true);
    jScrollPane2.setBounds(new Rectangle(110, 251, 350, 87));
    jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel9.setText("˹��¡Ե�鹤���");
    jLabel9.setBounds(new Rectangle(30, 82, 72, 15));
    prerequisiteText1.setBounds(new Rectangle(47, 24, 81, 25));
    prerequisiteText1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    prerequisiteText1.setText("");
    practiceText.setBounds(new Rectangle(118, 52, 72, 21));
    practiceText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    practiceText.setText("");
    prerequisiteText2.setBounds(new Rectangle(47, 66, 81, 24));
    prerequisiteText2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    prerequisiteText2.setText("");
    jLabel11.setBounds(new Rectangle(5, 64, 126, 24));
    jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel11.setText("�����Ԫ�������");
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel7.setText("˹��¡Ե������");
    jLabel7.setBounds(new Rectangle(30, 26, 76, 15));
    researchText.setBounds(new Rectangle(118, 79, 72, 21));
    researchText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    researchText.setText("");
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel7.setBorder(titledBorder2);
    jPanel7.setBounds(new Rectangle(241, 130, 221, 114));
    jPanel7.setLayout(null);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setBorder(titledBorder1);
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setBounds(new Rectangle(3, 131, 141, 112));
    jPanel6.setLayout(null);
    jScrollPane3.setBounds(new Rectangle(109, 347, 351, 87));
    jScrollPane3.setVerifyInputWhenFocusTarget(true);
    jScrollPane3.setAutoscrolls(false);
    jScrollPane3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    groupCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    groupCombo.setBounds(new Rectangle(110, 98, 169, 25));
    jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel10.setText("˹��¡Ե��Ժѵ�");
    jLabel10.setBounds(new Rectangle(30, 55, 68, 15));
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel5.setToolTipText("");
    jLabel5.setText("��Ǵ�Ԫ�");
    jLabel5.setBounds(new Rectangle(5, 98, 126, 24));
    eDescriptionText.setText("");
    tDescriptionText.setText("");
    clearButton.setBounds(new Rectangle(266, 447, 80, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setMaximumSize(new Dimension(80, 25));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setText("������");
    clearButton.addActionListener(new SubjectUI_clearButton_actionAdapter(this));
    clearButton.addActionListener(new SubjectUI_clearButton_actionAdapter(this));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder5);
    jPanel3.setBounds(new Rectangle(146, 131, 94, 112));
    jPanel3.setLayout(null);
    normRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    normRadio.setSelected(true);
    normRadio.setText("���ѭ");
    normRadio.setBounds(new Rectangle(15, 26, 65, 23));
    baseRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    baseRadio.setText("��鹰ҹ");
    baseRadio.setBounds(new Rectangle(15, 60, 65, 23));
    jButton1.setBounds(new Rectangle(177, 447, 80, 25));
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("�ѹ�֡");
    jButton1.addActionListener(new SubjectUI_jButton1_actionAdapter(this));
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2,  BorderLayout.CENTER);
    jPanel7.add(practiceText, null);
    jPanel7.add(jLabel7, null);
    jPanel7.add(jLabel10, null);
    jPanel7.add(jLabel9, null);
    jPanel7.add(lectureText, null);
    jPanel7.add(researchText, null);
    jPanel2.add(jButton1, null);
    jPanel2.add(clearButton, null);
    jPanel2.add(jPanel3, null);
    jPanel3.add(normRadio, null);
    jPanel3.add(baseRadio, null);
    jPanel2.add(jScrollPane3, null);
    jScrollPane3.getViewport().add(tDescriptionText, null);
    jPanel2.add(jScrollPane2, null);
    jScrollPane2.getViewport().add(eDescriptionText, null);
    jPanel2.add(tSubjectText, null);
    jPanel2.add(creditText, null);
    jPanel2.add(jLabel12, null);
    jPanel2.add(jLabel14, null);
    jPanel2.add(groupCombo, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(eSubjectText, null);
    jPanel2.add(jLabel11, null);
    jPanel2.add(jPanel6, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(subjectIDText, null);
    jPanel6.add(prerequisiteText1, null);
    jPanel6.add(prerequisiteText2, null);
    jPanel6.add(jLabel4, null);
    jPanel6.add(jLabel13, null);
    jPanel2.add(jLabel8, null);
    jPanel2.add(jPanel7, null);
    buttonGroup1.add(normRadio);
    buttonGroup1.add(baseRadio);
    addGroup();
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void addGroup(){
    Database.connect();
    Group group = new Group();
    Vector v = group.retrieveGroup();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Group g  = (Group)e.nextElement();
      groupCombo.addItem(g);
    }
    Database.disconnect();
  }
  public void addSubject(Subject subject){
    newRecord = true;
    clear();
  }
  public boolean removeSubject(Subject subject){
    Database.connect();
    boolean complete = subject.deleteSubject(subject);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }

  public void showUI(Subject subject){
    Database.connect();
    subject.retrievePrerequisite(subject);
    Database.disconnect();
    newRecord = false;
    this.subject = subject;
    subjectIDText.setText(subject.getSubjectID());
    eSubjectText.setText(subject.getSubjectEname());
    tSubjectText.setText(subject.getSubjectTname());
    setSelectedName(subject.getGroup().getGroupName());
    if (subject.getSubjectType() == 1) normRadio.setSelected(true);
    else baseRadio.setSelected(true);
    creditText.setText(Integer.toString(subject.getCredit()));
    lectureText.setText(Integer.toString(subject.getLecture()));
    practiceText.setText(Integer.toString(subject.getPractice()));
    researchText.setText(Integer.toString(subject.getResearch()));
    eDescriptionText.setText(subject.getEdescription());
    tDescriptionText.setText(subject.getTdescription());
    Enumeration e = subject.getPrerequisite().elements();
    if (e.hasMoreElements()){
      Subject s = (Subject)e.nextElement();
      prerequisiteText1.setText(s.getSubjectID());
      if (e.hasMoreElements()){
        prerequisiteText2.setText(((Subject)e.nextElement()).getSubjectID());
      }
      else {
        prerequisiteText2.setText("");
      }
    }
    else {
      prerequisiteText1.setText("");
      prerequisiteText2.setText("");
    }
  }
  public void setSelectedName(String name)
  {
     for (int i = 0;i < groupCombo.getItemCount();++i)
     {
        Group item = (Group)groupCombo.getItemAt(i);
        if (item.getGroupName().equals(name))
        {
           groupCombo.setSelectedItem(item);
           return;
        }
     }
  }
  public void clear(){
    subjectIDText.setText("");
    eSubjectText.setText("");
    tSubjectText.setText("");
    groupCombo.setSelectedItem(null);
    creditText.setText("");
    lectureText.setText("");
    practiceText.setText("");
    researchText.setText("");
    eDescriptionText.setText("");
    tDescriptionText.setText("");
    prerequisiteText1.setText("");
    prerequisiteText2.setText("");
  }
  void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Database.connect();
    Subject subject = new Subject();
    if (subjectIDText.getText() == null || subjectIDText.getText().equals("")) {
      JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (eSubjectText.getText() == null || eSubjectText.getText().equals("")){
        JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (tSubjectText.getText() == null || tSubjectText.getText().equals("")) {
      JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (creditText.getText().equals("") || lectureText.getText().equals("") || practiceText.getText().equals("") || researchText.getText().equals("")){
      JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (groupCombo.getSelectedItem() == null){
      JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    subject.setSubjectID(subjectIDText.getText());
    subject.setSubjectEname(eSubjectText.getText());
    subject.setSubjectTname(tSubjectText.getText());
    subject.setGroup((Group)groupCombo.getSelectedItem());
    subject.setCredit(Integer.parseInt(creditText.getText()));
    subject.setLecture(Integer.parseInt(lectureText.getText()));
    subject.setPractice(Integer.parseInt(practiceText.getText()));
    subject.setResearch(Integer.parseInt(researchText.getText()));
    subject.setEdescription(eDescriptionText.getText());
    subject.setTdescription(tDescriptionText.getText());
    if (normRadio.isSelected()){
      subject.setSubjectType(1);
    }
    else {
      subject.setSubjectType(2);
    }
    subject.setMajor(this.major);
    String str = prerequisiteText1.getText();
    String str1 = prerequisiteText2.getText();

    if (newRecord){
      complete = subject.insertSubject(subject);
    }
    else{
      complete = subject.updateSubject(this.subject,subject);
    }
    boolean pre = false;
    if (!str.equals(""))  {subject.addPrerequisite(new Subject(str)); pre = true;}
    if (!str1.equals("")) {subject.addPrerequisite(new Subject(str1)); pre = true;}
    if (pre) subject.insertPrerequisite();
    if (newRecord && complete) {
      courseUI.addNode(subject);
    }
    else courseUI.updateNode(subject);
    Database.disconnect();
  }
}

class SubjectUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  SubjectUI adaptee;

  SubjectUI_clearButton_actionAdapter(SubjectUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class SubjectUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  SubjectUI adaptee;

  SubjectUI_jButton1_actionAdapter(SubjectUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}