package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class SectionDB {
  public SectionDB() {
  }
  public Vector retrieveSection(Subject subject){
    Vector v = new Vector();
    try
    {
        String query = "SELECT s.*,t.* FROM Section s,Semester t WHERE s.SemesterID = t.SemesterID AND ";
        query += "t.CurrentSemester = 1 AND ";
        query += "s.SubjectID = '" + subject.getSubjectID() + "' ORDER BY Sec";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Section section = new Section();
          section.setSectionID(rs.getLong("SectionID"));
          Semester semester = new Semester();
          semester.setSemesterID(rs.getLong("SemesterID"));
          semester.setYear(rs.getInt("Year"));
          semester.setSemester(rs.getInt("SemesterNo"));
          semester.setSemesterType(rs.getInt("SemesterType"));
          section.setSemeter(semester);
          section.setLevel(rs.getInt("DegreeLevel"));
          section.setBeginTime(rs.getString("BeginTime"));
          section.setEndTime(rs.getString("EndTime"));
          section.setRoom(rs.getString("Room"));
          section.setDay(rs.getInt("Day"));
/*          section.setMidtermDate(rs.getDate("MidtermDate"));
          section.setMidtermBtime(rs.getString("MidtermBTime"));
          section.setMidtermEtime(rs.getString("MidtermETime"));
          section.setMidtermRoom(rs.getString("MidtermRoom"));*/

          section.setFinalDate(rs.getDate("FinalDate"));
          int date = section.getFinalDate().getDate();
          int month = section.getFinalDate().getMonth();
          int year = section.getFinalDate().getYear();
          GregorianCalendar g = new GregorianCalendar(year+1900+543,month,date);
          java.util.Date d = g.getTime();
          section.setFinalDate(d);

          section.setFinalBtime(rs.getString("FinalBTime"));
          section.setFinalEtime(rs.getString("FinalETime"));
          section.setFinalRoom(rs.getString("FinalRoom"));
          section.setMax(rs.getInt("MaxStudent"));
          section.setCurrent(rs.getInt("CurrentStudent"));
          section.setSec(rs.getInt("Sec"));
          section.setLock((rs.getInt("Lock")== 1)?true:false);
          section.setStatus((rs.getInt("Status")==1)?true:false);
          section.setSubject(subject);
          v.addElement(section);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveProfessor(Section section){
    Vector v = new Vector();
    try
    {
        String query = "SELECT p.*,l.*,t.* FROM Prename p,Professor l,Teach t WHERE ";
        query += "p.PrenameID = l.PrenameID AND l.ProfessorID = t.ProfessorID AND SectionID = " + section.getSectionID() + " ORDER BY TProfessorName";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Professor prof = new Professor();
          prof.setProfessorID(rs.getString("ProfessorID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          prof.setPrename(p);
          prof.setEprofessorName(rs.getString("EProfessorName"));
          prof.setTprofessorName(rs.getString("TProfessorName"));
          prof.setPosition(rs.getString("Position"));
          v.addElement(prof);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertSection(Section section){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Section(SemesterID,DegreeLevel,BeginTime,EndTime,Room,Day,";
    query += "FinalDate,FinalBTime,FinalETime,FinalRoom,";
    query += "MaxStudent,CurrentStudent,Sec,Lock,Status,SubjectID) ";
    query += "VALUES("+ section.getSemester().getSemesterID() + " , " + section.getLevel();
    query += ", '" + section.getBeginTime() + "','" + section.getEndTime() + "','" + section.getRoom() + "'";
    query += ", " + section.getDay() + ",'" + formatter.format(section.getFinalDate()) + "'";
    query += ", '" + section.getFinalBtime() + "','" + section.getFinalEtime() + "','" + section.getFinalRoom() + "'";
    query += ", " + section.getMax() + "," + section.getCurent()+ "," + section.getSec();
    query += ", " + Integer.toString((section.getLock())?1:0) + "," + Integer.toString((section.getStatus())?1:0) + ",'" + section.getSubject().getSubjectID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean insertProfessor(Section section,Professor professor){
    String query = "INSERT INTO Teach(SectionID,ProfessorID) VALUES(" + section.getSectionID();
    query += ",'" + professor.getProfessorID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateSection(Section oldsection,Section section){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Section SET ";
    query += "SemesterID = " + section.getSemester().getSemesterID() + ", ";
    query += "DegreeLevel = " + section.getLevel() + ", ";
    query += "BeginTime = '" + section.getBeginTime() + "', ";
    query += "EndTime = '" + section.getEndTime() + "', ";
    query += "Room = '" + section.getRoom() + "', ";
    query += "Day = " + section.getDay() + ", ";
/*    query += "MidtermDate = '" + formatter.format(section.getMidtermDate()) + "', ";
    query += "MidtermBTime = '" + section.getMidtermBtime() + "', ";
    query += "MidtermETime = '" + section.getMidtermEtime() + "', ";
    query += "MidtermRoom = '" + section.getMidtermRoom() + "', ";*/
    query += "FinalDate = '" + formatter.format(section.getFinalDate()) + "', ";
    query += "FinalBTime = '" + section.getFinalBtime() + "' ,";
    query += "FinalETime = '" + section.getFinalEtime() + "', ";
    query += "FinalRoom = '" + section.getFinalRoom() + "', ";
    query += "MaxStudent = " + section.getMax() + ", ";
    query += "CurrentStudent = " + section.getCurent() + ", ";
    query += "Sec = " + section.getSec() + ", ";
    query += "Lock = " + Integer.toString((section.getLock())?1:0) + ", ";
    query += "Status = " + Integer.toString((section.getStatus())?1:0) + ", ";
    query += "SubjectID = '" + section.getSubject().getSubjectID() + "' ";
    query += "WHERE SectionID = " + oldsection.getSectionID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean incrementStudent(Section section){
    String query = "UPDATE Section SET CurrentStudent = CurrentStudent + 1 WHERE SectionID = " + section.getSectionID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSection(Section section){
    String query = "DELETE FROM Section WHERE Sec = " + section.getSec();
    query += " AND SubjectID = '" + section.getSubject().getSubjectID() + "' ";
    query += "AND SemesterID = " + section.getSemester().getSemesterID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSectionFromID(Section section){
    String query = "DELETE FROM Section WHERE SectionID = " + section.getSectionID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteProfessor(Section section){
    String query = "DELETE FROM Teach WHERE SectionID = " + section.getSectionID();
    if (Database.update(query) != 0) return true;
    return false;
  }

  public static void main(String[] args){
    GregorianCalendar g = new GregorianCalendar(2004,0,1);
    java.util.Date d = new java.util.Date();
    System.out.print(d);
    SectionDB db = new SectionDB();
    Database.connect();
    Vector v = db.retrieveSection(new Subject("01077100"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Section sss = (Section)e.nextElement();
      System.out.print(sss.getFinalDate());
    }
    Database.disconnect();
  }

}