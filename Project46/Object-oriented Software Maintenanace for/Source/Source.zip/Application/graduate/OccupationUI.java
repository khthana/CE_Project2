package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class OccupationUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JButton saveButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel jPanel8 = new JPanel();
  JButton clearButton = new JButton();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JTextField occupationText = new JTextField();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  BorderLayout borderLayout6 = new BorderLayout();
//---------------------------------------------------------------------------------------------------------------------------------------------------
  JPanel etcUI = null;
  boolean newRecord = false;
  Occupation occupation = null;

  public OccupationUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public OccupationUI(JPanel panel) {
    try {
      jbInit();
      etcUI = panel;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jLabel1.setText("�����Ҫվ :");
    jLabel1.setPreferredSize(new Dimension(80, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setLayout(flowLayout1);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(400, 100));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "�Ҫվ",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    jPanel2.setBorder(titledBorder1);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new OccupationUI_saveButton_actionAdapter(this));
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jPanel8.setLayout(borderLayout4);
    clearButton.setText("������");
    clearButton.addActionListener(new OccupationUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setAlignmentY((float) 0.5);
    jPanel7.setLayout(borderLayout5);
    jPanel7.setMinimumSize(new Dimension(141, 35));
    jPanel7.setPreferredSize(new Dimension(400, 50));
    jPanel6.setLayout(borderLayout6);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 20));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(400, 22));
    occupationText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    occupationText.setOpaque(true);
    occupationText.setPreferredSize(new Dimension(300, 22));
    occupationText.setText("");
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    this.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel8, null);
    jPanel6.add(jLabel1, BorderLayout.WEST);
    jPanel6.add(occupationText, BorderLayout.CENTER);
    jPanel8.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(jPanel10, BorderLayout.NORTH);
    jPanel8.add(jPanel6, BorderLayout.NORTH);
    jPanel10.add(saveButton, null);
    jPanel10.add(clearButton, null);
  }
  public void showUI(Occupation occ){
    newRecord = false;
    this.occupation = occ;
    occupationText.setText(occ.getOccupationName());
  }
  public void clear(){
    occupationText.setText("");
  }
  public void addOccupation(){
    newRecord = true;
    clear();
  }
  public boolean removeOccupation(Occupation occ){
    Database.connect();
    boolean complete = occ.deleteOccupation(occ);
    Database.disconnect();
    if (complete) return true;
    return false;
  }
  void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Database.connect();
    Occupation occupation = new Occupation(occupationText.getText());
    if (newRecord){
      complete = occupation.insertOccupation(occupation);
      if (complete) ((EtcUI)etcUI).addNode(occupation);
    }
    else {
      occupation.setOccupationID(this.occupation.getOccupationID());
      complete = occupation.updateOccupation(occupation);
      if (complete) ((EtcUI)etcUI).updateNode(occupation);
    }
    Database.disconnect();
  }
}

class OccupationUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  OccupationUI adaptee;

  OccupationUI_clearButton_actionAdapter(OccupationUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class OccupationUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  OccupationUI adaptee;

  OccupationUI_saveButton_actionAdapter(OccupationUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}