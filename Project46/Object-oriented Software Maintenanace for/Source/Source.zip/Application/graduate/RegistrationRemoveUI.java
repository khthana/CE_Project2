package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RegistrationRemoveUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JTextField typeText = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField degreeText = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField nameText = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField studentIDText = new JTextField();
  JPanel jPanel2 = new JPanel();
  JTextField majorText = new JTextField();
  JTextField facultyText = new JTextField();
  JLabel jLabel5 = new JLabel();
  TitledBorder titledBorder1;
  JPanel jPanel4 = new JPanel();
  JPanel jPanel3 = new JPanel();
  TitledBorder titledBorder2;
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  TitledBorder titledBorder3;
  JButton jButton2 = new JButton();
  JButton jButton1 = new JButton();
  JPanel jPanel7 = new JPanel();
  JRadioButton jRadioButton3 = new JRadioButton();
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  JPanel jPanel8 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable2 = new JTable();
  JScrollPane jScrollPane2 = new JScrollPane();
  JTable jTable3 = new JTable();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  //------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Student student = new Student();
  Date currentDate = new Date();
  Semester semester = new Semester();
  boolean canRegister = false;
  boolean newStudent = false;
  Vector registrationVector = new Vector();
  Vector removeVector = new Vector();
  int selectedRow = 0;
  int selectedColumn = 0;
  int pastRow = 0;
  int pastColumn = 0;
  int normMaxCredit = 15;
  int normMinCredit = 9;
  int summerMaxCredit = 6;
  JButton removeButton = new JButton();
  JButton cancelButton = new JButton();
  Vector columnHeaders = new Vector();
  //-------------------------------------------------------------------------------------------------------------------------------------------------------------------

  public RegistrationRemoveUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 165, 165)), "�ѡ�֡��");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 165, 165)), "��¡���Ԫҷ��ŧ����¹");
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 163, 151)), "����Ԫҷ��͹");
    titledBorder3.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(null);
    typeText.setBounds(new Rectangle(113, 97, 111, 24));
    typeText.setText("");
    typeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("���");
    jLabel4.setBounds(new Rectangle(233, 66, 34, 15));
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("���ʹѡ�֡��");
    jLabel1.setBounds(new Rectangle(15, 30, 75, 15));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setText("�дѺ��ԭ��");
    jLabel3.setBounds(new Rectangle(15, 66, 84, 15));
    degreeText.setBounds(new Rectangle(113, 61, 111, 24));
    degreeText.setText("");
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("����-���ʡ��");
    jLabel2.setBounds(new Rectangle(233, 30, 72, 15));
    nameText.setEnabled(true);
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setText("");
    nameText.setBounds(new Rectangle(305, 25, 203, 24));
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("�������ѡ�֡��");
    jLabel6.setBounds(new Rectangle(15, 102, 89, 15));
    studentIDText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setText("");
    studentIDText.setBounds(new Rectangle(113, 25, 111, 24));
    studentIDText.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        studentIDText_actionPerformed(e);
      }
    });
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder1);
    jPanel2.setDebugGraphicsOptions(0);
    jPanel2.setBounds(new Rectangle(15, 9, 524, 144));
    jPanel2.setLayout(null);
    majorText.setEnabled(true);
    majorText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorText.setText("");
    majorText.setBounds(new Rectangle(305, 97, 203, 24));
    facultyText.setBounds(new Rectangle(305, 61, 203, 24));
    facultyText.setText("");
    facultyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setEnabled(true);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�Ң��Ԫ�");
    jLabel5.setBounds(new Rectangle(233, 102, 60, 15));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setPreferredSize(new Dimension(5, 5));
    jPanel4.setBounds(new Rectangle(13, 22, 652, 140));
    jPanel4.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder2);
    jPanel3.setPreferredSize(new Dimension(5, 5));
    jPanel3.setBounds(new Rectangle(15, 162, 686, 174));
    jPanel3.setLayout(null);
    jPanel5.setLayout(borderLayout2);
    jPanel5.setBounds(new Rectangle(24, 22, 635, 159));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setPreferredSize(new Dimension(5, 5));
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setBorder(titledBorder3);
    jPanel6.setPreferredSize(new Dimension(5, 5));
    jPanel6.setBounds(new Rectangle(15, 367, 686, 192));
    jPanel6.setLayout(null);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("������");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("�ѹ�֡");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setBounds(new Rectangle(283, 564, 186, 35));
    jRadioButton3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton3.setText("�Ҿѡ");
    jRadioButton3.setBounds(new Rectangle(26, 96, 91, 23));
    jRadioButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton1.setSelected(true);
    jRadioButton1.setText("����");
    jRadioButton1.setBounds(new Rectangle(26, 29, 91, 23));
    jRadioButton2.setBounds(new Rectangle(26, 62, 91, 23));
    jRadioButton2.setText("�ѡ����Ҿ");
    jRadioButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel8.setLayout(null);
    jPanel8.setBounds(new Rectangle(552, 10, 150, 143));
    jPanel8.setBorder(titledBorder3);
    jPanel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setPreferredSize(new Dimension(454, 404));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setMaximumSize(new Dimension(32767, 32767));
    jTable2.setMaximumSize(new Dimension(32767, 32767));
    jTable2.setMinimumSize(new Dimension(454, 100));
    jTable2.setPreferredSize(new Dimension(454, 404));
    jTable2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable2.setIntercellSpacing(new Dimension(0, 0));
    jTable2.setRowSelectionAllowed(true);
    jTable2.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
    }
        ,
        new String[] {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Object.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean[] {
          false, false, false, false, false
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jScrollPane2.setPreferredSize(new Dimension(454, 404));
    jScrollPane2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane2.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane2.setMaximumSize(new Dimension(32767, 32767));
    jTable3.setMaximumSize(new Dimension(32767, 32767));
    jTable3.setMinimumSize(new Dimension(454, 404));
    jTable3.setPreferredSize(new Dimension(454, 404));
    jTable3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable3.setIntercellSpacing(new Dimension(0, 0));
    jTable3.setRowSelectionAllowed(true);
    jTable3.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
    }
        ,
        new String[] {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Object.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean[] {
          false, false, false, false, false
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable3.setRowHeight(16);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    removeButton.setBounds(new Rectangle(505, 341, 93, 26));
    removeButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    removeButton.setMaximumSize(new Dimension(80, 25));
    removeButton.setPreferredSize(new Dimension(80, 25));
    removeButton.setText("�͹");
    removeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeButton_actionPerformed(e);
      }
    });
    cancelButton.setText("¡��ԡ");
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancelButton_actionPerformed(e);
      }
    });
    cancelButton.setPreferredSize(new Dimension(80, 25));
    cancelButton.setMaximumSize(new Dimension(80, 25));
    cancelButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    cancelButton.setBounds(new Rectangle(605, 341, 93, 26));
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(jLabel1, null);
    jPanel2.add(nameText, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(facultyText, null);
    jPanel2.add(degreeText, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(studentIDText, null);
    jPanel2.add(majorText, null);
    jPanel2.add(jLabel6, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(typeText, null);
    jPanel8.add(jRadioButton1, null);
    jPanel8.add(jRadioButton3, null);
    jPanel8.add(jRadioButton2, null);
    jPanel1.add(cancelButton, null);
    jPanel1.add(cancelButton, null);
    jPanel1.add(removeButton, null);
    jPanel1.add(jPanel2, null);
    jPanel7.add(jButton1, null);
    jPanel7.add(jButton2, null);
    jPanel1.add(jPanel6, null);
    jPanel6.add(jPanel5, null);
    jPanel5.add(jScrollPane1, BorderLayout.CENTER);
    jPanel1.add(jPanel7, null);
    jScrollPane1.getViewport().add(jTable2, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jPanel4, null);
    jPanel4.add(jScrollPane2, BorderLayout.CENTER);
    jPanel1.add(jPanel8, null);
    jScrollPane2.getViewport().add(jTable3, null);
    buttonGroup1.add(jRadioButton1);
    buttonGroup1.add(jRadioButton2);
    buttonGroup1.add(jRadioButton3);

    TableColumn typeColumn = jTable3.getColumn("Cr/Nc/Au");

//Ask to be notified of selection changes.
    ListSelectionModel rowSM = jTable3.getSelectionModel();
    rowSM.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //Ignore extra messages.
        if (e.getValueIsAdjusting())
          return;

        ListSelectionModel lsm = (ListSelectionModel) e.getSource();
        if (lsm.isSelectionEmpty()) {
          //no rows are selected
        }
        else {
          //selectedRow is selected
          pastRow = selectedRow;
          selectedRow = lsm.getMinSelectionIndex();
        }
      }
    });
    Database.connect();
    this.semester = semester.retrieveCurrentSemester();
    Database.disconnect();
    columnHeaders.addElement("�����Ԫ�");
    columnHeaders.addElement("�����Ԫ�");
    columnHeaders.addElement("˹��¡Ե");
    columnHeaders.addElement("�礪��");
    columnHeaders.addElement("Cr/Nc/Au");
  }
  public void retrieveRegistrationRegistered(Student student) {
    Database.connect();
    Registration r = new Registration();
    registrationVector = r.retrieveRegistration(student,semester,new RegisterType(1));
    if (registrationVector.isEmpty()) {
      registrationVector = r.retrieveRegistration(student,semester,new RegisterType(2));
      if (registrationVector.isEmpty()) {
        Database.disconnect();
        return;
      }
    }

    Enumeration e = registrationVector.elements();
    int i = 0;
    while (e.hasMoreElements()){
      Registration reg = (Registration)e.nextElement();
      jTable3.getModel().setValueAt(reg.getSection().getSubject().getSubjectID(),i,0);
      jTable3.getModel().setValueAt(reg.getSection().getSubject().getSubjectTname(),i,1);
      jTable3.getModel().setValueAt(new Integer(reg.getSection().getSubject().getCredit()),i,2);
      jTable3.getModel().setValueAt(new Integer(reg.getSection().getSec()),1,3);
      jTable3.getModel().setValueAt(reg.getType(),i,4);
      i++;
    }

    Database.disconnect();
  }

  public void clearRow() {
    jTable3.getModel().setValueAt(null,pastRow,1);
    jTable3.getModel().setValueAt(null,pastRow,2);
    jTable3.getModel().setValueAt(new Integer(1),pastRow,3);
    jTable3.getModel().setValueAt(null,pastRow,4);
  }
  //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  public void clearTable(JTable table){
    for(int i=0;i<table.getRowCount();i++)
      for(int j=0;j<table.getColumnCount();j++) {
        if (j!=3) table.setValueAt(null,i,j);
        else table.setValueAt(new Integer(1),i,j);
      }
  }

  void studentIDText_actionPerformed(ActionEvent e) {//StudentID TextField
    Database.connect();
    student = student.retrieveStudent(new Student(studentIDText.getText()));
    Database.disconnect();
    //---------------------------------------------------------------------retrieve Registration-----------------------------------------------------------------------
    retrieveRegistrationRegistered(student);
    nameText.setText(student.getStudentTname());
    degreeText.setText(String.valueOf(student.getDegree()));
    facultyText.setText(student.getMajor().getDepartment().getFaculty().getTname());
    typeText.setText(String.valueOf(student.getStudentType()));
    majorText.setText(student.getMajor().getTname());
    if (student.getStatus() != 1) {
      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getRegisterStatus() != 1){

      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getDebtStatus()){
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ�����Թ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getLibraryStatus()) {
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ˹ѧ�����ͧ��ش","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    canRegister = true;
    if (registrationVector != null) newStudent = true;
  }

  void jButton1_actionPerformed(ActionEvent e) { //Save Button
    Database.connect();
    boolean complete = false;
    Enumeration re = removeVector.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      r.setRegisterType(new RegisterType(8));
      r.setGrade("W");
      complete = r.updateRegistration(r);
    }
    Database.disconnect();
  }

  void jButton2_actionPerformed(ActionEvent e) { //Clear Button
    removeVector.removeAllElements();
    clearTable(jTable2);
  }

  void removeButton_actionPerformed(ActionEvent e) {
    clearTable(jTable2);
    removeVector.removeAllElements();
    int[] rows = jTable3.getSelectedRows();
    for (int i =0;i<jTable3.getSelectedRowCount();i++){
      if (jTable3.getModel().getValueAt(rows[i],0) != null){
        Registration reg = (Registration)registrationVector.elementAt(rows[i]);
        removeVector.addElement(reg);
        jTable2.getModel().setValueAt(reg.getSection().getSubject().getSubjectID(),i,0);
        jTable2.getModel().setValueAt(reg.getSection().getSubject().getSubjectTname(),i,1);
        jTable2.getModel().setValueAt(new Integer(reg.getSection().getSubject().getCredit()),i,2);
        jTable2.getModel().setValueAt(new Integer(reg.getSection().getSec()),1,3);
        jTable2.getModel().setValueAt(reg.getType(),i,4);
      }
    }
  }

  void cancelButton_actionPerformed(ActionEvent e) {
    clearTable(jTable2);
    Vector tempVector = new Vector();

    int[] rows = jTable2.getSelectedRows();
    for (int i =0;i<jTable2.getSelectedRowCount();i++){
      if (jTable2.getModel().getValueAt(rows[i],0) != null){
        Registration reg = (Registration)removeVector.elementAt(rows[i]);
        tempVector.addElement(reg);
      }
    }

    if (removeVector.removeAll(tempVector)){
      Enumeration re = removeVector.elements();
      int i = 0;
      while (re.hasMoreElements()){
        Registration reg = (Registration)re.nextElement();
        jTable2.getModel().setValueAt(reg.getSection().getSubject().getSubjectID(),i,0);
        jTable2.getModel().setValueAt(reg.getSection().getSubject().getSubjectTname(),i,1);
        jTable2.getModel().setValueAt(new Integer(reg.getSection().getSubject().getCredit()),i,2);
        jTable2.getModel().setValueAt(new Integer(reg.getSection().getSec()),1,3);
        jTable2.getModel().setValueAt(reg.getType(),i,4);
        i++;
      }
    }
  }
}