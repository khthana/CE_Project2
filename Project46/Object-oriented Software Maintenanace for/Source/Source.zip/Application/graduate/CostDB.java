package graduate;

import java.sql.*;
import java.util.*;
public class CostDB {
  public CostDB() {
  }
  public Vector retrieveCost(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Cost ORDER BY CostID";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Cost cost = new Cost();
          cost.setCostID(rs.getLong("CostID"));
          cost.setCostName(rs.getString("CostName"));
          cost.setValue(rs.getDouble("Val"));
          v.addElement(cost);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertCost(Cost cost){
    String query = "INSERT INTO Cost(CostName,Val) ";
    query += "VALUES('" + cost.getCostName() + "'," + cost.getValue() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateCost(Cost cost){
    String query = "UPDATE Cost SET ";
    query += "CostName = '" + cost.getCostName() + "', ";
    query += "Val = " + cost.getValue()+ " ";
    query += "WHERE CostID = " + cost.getCostID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteCost(Cost cost){
    String query = "DELETE FROM Cost WHERE CostID = " + cost.getCostID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    CostDB gdb = new CostDB();
    Cost g = new Cost(2,"�Է�ҹԾ���",200);
    gdb.updateCost(g);
/*    Vector v = gdb.retrieveCost();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Cost m1 = (Cost)e.nextElement();
      System.out.println(m1.getCostID() + " " + m1.getCostName() + " " + m1.getValue());
    }*/
    Database.disconnect();
  }

}