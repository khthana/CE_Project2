package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class LocationUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JButton saveButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel jPanel8 = new JPanel();
  JButton clearButton = new JButton();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JTextField locationText = new JTextField();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  BorderLayout borderLayout6 = new BorderLayout();
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------
  boolean newRecord = false;
  Location location = null;
  JPanel etcUI = null;

  public LocationUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public LocationUI(JPanel panel) {
    try {
      jbInit();
      etcUI = panel;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jLabel1.setText("�����ٹ�����¹ :");
    jLabel1.setPreferredSize(new Dimension(80, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setLayout(flowLayout1);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(400, 100));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "�ٹ�����¹",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    jPanel2.setBorder(titledBorder1);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new LocationUI_saveButton_actionAdapter(this));
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jPanel8.setLayout(borderLayout4);
    clearButton.setText("������");
    clearButton.addActionListener(new LocationUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel7.setLayout(borderLayout5);
    jPanel7.setMinimumSize(new Dimension(141, 35));
    jPanel7.setPreferredSize(new Dimension(400, 50));
    jPanel6.setLayout(borderLayout6);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 20));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(400, 22));
    locationText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    locationText.setOpaque(true);
    locationText.setPreferredSize(new Dimension(300, 22));
    locationText.setText("");
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    this.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jPanel8, null);
    jPanel10.add(saveButton, null);
    jPanel10.add(clearButton, null);
    jPanel8.add(jPanel6, BorderLayout.NORTH);
    jPanel8.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(jPanel10, BorderLayout.NORTH);
    jPanel6.add(jLabel1, BorderLayout.WEST);
    jPanel6.add(locationText, BorderLayout.CENTER);
  }
  public void showUI(Location location){
    newRecord = false;
    this.location = location;
    locationText.setText(location.getLocationName());
  }
  public void clear(){
    locationText.setText("");
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  public void addLocation(){
    newRecord = true;
    clear();
  }
  public boolean removeLocation(Location location){
    Database.connect();
    boolean complete = location.deleteLocation(location);
    Database.disconnect();
    if (complete) return true;
    return false;
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Location location = new Location(locationText.getText());
    Database.connect();
    if (newRecord){
      complete = location.insertLocation(location);
      if (complete) ((EtcUI)etcUI).addNode(location);
    }
    else {
      location.setLocationID(this.location.getLocationID());
      complete = location.updateLocation(location);
      if (complete) {
        ((EtcUI)etcUI).updateNode(location);
      }
    }
    Database.disconnect();
  }
}

class LocationUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  LocationUI adaptee;

  LocationUI_clearButton_actionAdapter(LocationUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class LocationUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  LocationUI adaptee;

  LocationUI_saveButton_actionAdapter(LocationUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}