package graduate;

public class ScholarDB {
  public ScholarDB() {
  }
  public boolean insertScholar(Scholar scholar){
    String query = "INSERT INTO Scholar(StudentID,ScholarshipID) ";
    query = query + "VALUES('" + scholar.getStudent().getStudentID()+ "','" + scholar.getScholarship().getID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateScholar(Scholar oldScholar,Scholar newScholar){
    String query = "UPDATE Scholar SET ";
    query = query + "SubjectID = '" + newScholar.getStudent().getStudentID() + "', ";
    query = query + "PreSubjectID = '" + newScholar.getScholarship().getID()+ "' ";
    query = query + "WHERE SubjectID = '" + oldScholar.getStudent().getStudentID() + "' AND ";
    query = query + "PreSubjectID = '" + oldScholar.getScholarship().getID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteScholar(Scholar scholar){
    String query = "DELETE FROM Scholar ";
    query = query + "WHERE SubjectID = '" + scholar.getStudent().getStudentID() + "' AND ";
    query = query + "PreSubjectID = '" + scholar.getScholarship().getID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }

}