package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class DebtDB {
  public DebtDB() {
  }
  public Vector retrieveDebt(Student student){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Debt WHERE StudentID = '" + student.getStudentID() + "' ORDER BY DebtDate";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Debt debt = new Debt();
          debt.setDebtID(rs.getLong("DebtID"));
          debt.setMoney(rs.getDouble("DebtMoney"));
          debt.setType(rs.getBoolean("DebtType"));
          debt.setBalance(rs.getDouble("Balance"));
          debt.setDebtDeate(rs.getDate("DebtDate"));
          debt.setStudent(student);
          v.addElement(debt);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertDebt(Debt debt){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Debt(DebtMoney,DebtType,Balance,DebtDate,StudentID) ";
    query += "VALUES("+ debt.getMoney() + " , " + debt.getType();
    query += ", " + debt.getBalance() + ",'" +formatter.format(debt.getDebtDate()) + "','" + debt.getStudent().getStudentID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateDebt(Debt debt){
    String query = "UPDATE Debt SET ";
    query += "DebtMoney = " + debt.getMoney() + ", ";
    query += "DebtType = " + debt.getType() + ", ";
    query += "Balance = " + debt.getBalance() + ", ";
    query += "DebtDate = '" + debt.getDebtDate() + "', ";
    query += "StudentID = '" + debt.getStudent().getStudentID() + "' ";
    query += "WHERE DebtID = " + debt.getDebtID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteDebt(Debt debt){
    String query = "DELETE FROM Debt WHERE DebtID = " + debt.getDebtID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    String aa = "09.00";
    String bb = "09.00";
    System.out.print(bb.equals(aa));
/*    Database.connect("jdbc:odbc:Graduate","Admin","123");
    DebtDB db = new DebtDB();
    Debt d = new Debt(1);
    d.setMoney(20000);
    d.setBalance(20000);
    d.setStudent(new Student("001"));
    d.setType(false);
//    db.updateDebt(d);
    Vector v = db.retrieveDebt(new Student("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Debt m1 = (Debt)e.nextElement();
      System.out.println(m1.getDebtID() + " " + m1.getMoney() + " " + m1.getType() + " " + m1.getBalance() + " " + m1.getStudent().getStudentID());
    }
    Database.disconnect();*/
  }
}