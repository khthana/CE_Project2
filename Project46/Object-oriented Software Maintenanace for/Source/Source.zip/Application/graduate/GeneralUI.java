package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class GeneralUI extends JPanel {
  Border loweredBorder;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("�����ŷ����");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  Border border1;

//--------------------------------------------------------------------------------Panel-------------------------------------------------------------------------
  JPanel facultyPanel = new FacultyUI(this);
  JPanel departmentPanel = new DepartmentUI(this);
  JPanel majorPanel = new MajorUI(this);
  JPanel minorPanel = new MinorUI(this);
  JPanel switchPanel = new JPanel();
  Faculty faculty = null;
  Department department = null;
  Major major = null;
  Minor minor = null;
  Faculty facultyInit = new Faculty();
  Department departmentInit = new Department();
  Major majorInit = new Major();
  Minor minorInit = new Minor();
  boolean canAdd = false;

  int currentPanel = 0;

  public GeneralUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    loweredBorder = BorderFactory.createEmptyBorder(5,5,5,5);
    jButton2.setText("����");
    jButton2.addActionListener(new GeneralUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new GeneralUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border1);
    jPanel1.setPreferredSize(new Dimension(622, 500));
    switchPanel.setLayout(boxLayout22);
    switchPanel.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    switchPanel.setBorder(loweredBorder);
    switchPanel.setPreferredSize(new Dimension(472, 462));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(loweredBorder);
    jPanel3.setPreferredSize(new Dimension(175, 462));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setBorder(null);
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jSplitPane1.add(switchPanel, JSplitPane.RIGHT);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    switchPanel.add(facultyPanel);
    switchPanel.add(departmentPanel);
    departmentPanel.setVisible(false);
    switchPanel.add(majorPanel);
    majorPanel.setVisible(false);
    switchPanel.add(minorPanel);
    minorPanel.setVisible(false);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());
    createTree();
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode) jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String){
        canAdd = true;
        currentPanel = 0;
      }
      if (nodeInfo instanceof Faculty) {
        canAdd = true;
        currentPanel = 1;
        faculty = (Faculty)nodeInfo;
        facultyPanel.setVisible(true);
        ((FacultyUI)facultyPanel).showUI(faculty);
        departmentPanel.setVisible(false);
        majorPanel.setVisible(false);
        minorPanel.setVisible(false);
      }
      else if (nodeInfo instanceof Department) {
        canAdd = true;
        currentPanel = 2;
        department = (Department)nodeInfo;
        DefaultMutableTreeNode facultyNode = (DefaultMutableTreeNode)node1.getParent();
        faculty = (Faculty)facultyNode.getUserObject();
        facultyPanel.setVisible(false);
        departmentPanel.setVisible(true);
        ((DepartmentUI)departmentPanel).showUI(department);
        majorPanel.setVisible(false);
        minorPanel.setVisible(false);
      }
      else if (nodeInfo instanceof Major) {
        canAdd = true;
        currentPanel = 3;
        major = (Major)nodeInfo;
        DefaultMutableTreeNode departmentNode  = (DefaultMutableTreeNode)node1.getParent();
        department = (Department)departmentNode.getUserObject();
        facultyPanel.setVisible(false);
        departmentPanel.setVisible(false);
        majorPanel.setVisible(true);
        ((MajorUI)majorPanel).showUI(major);
        minorPanel.setVisible(false);
      }
      else if (nodeInfo instanceof Minor) {
        canAdd = false;
        currentPanel = 4;
        minor = (Minor)nodeInfo;
        DefaultMutableTreeNode  majorNode = (DefaultMutableTreeNode)node1.getParent();
        major = (Major)majorNode.getUserObject();
        facultyPanel.setVisible(false);
        departmentPanel.setVisible(false);
        majorPanel.setVisible(false);
        minorPanel.setVisible(true);
        ((MinorUI)minorPanel).showUI(minor);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void clearTree(){
    root.removeAllChildren();
    treeModel.reload();
  }

  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode facultyNode = null;
    DefaultMutableTreeNode departmentNode = null;
    DefaultMutableTreeNode majorNode = null;
    DefaultMutableTreeNode minorNode = null;

    Vector facultyVector = facultyInit.retrieveFacultyAll();
    Enumeration facultyEnum = facultyVector.elements();
    while (facultyEnum.hasMoreElements()){
      Faculty fac = (Faculty)facultyEnum.nextElement();
      facultyNode = new DefaultMutableTreeNode(fac);
      root.add(facultyNode);

      Vector departmentVector = departmentInit.retrieveDepartmentAll(fac);
      Enumeration departmentEnum = departmentVector.elements();
      while (departmentEnum.hasMoreElements()){
        Department dep = (Department)departmentEnum.nextElement();
        departmentNode = new DefaultMutableTreeNode(dep);
        facultyNode.add(departmentNode);

        Vector majorVector = majorInit.retrieveMajorAll(dep);
        Enumeration majorEnum = majorVector.elements();
        while (majorEnum.hasMoreElements()){
          Major maj = (Major)majorEnum.nextElement();
          majorNode = new DefaultMutableTreeNode(maj);
          departmentNode.add(majorNode);

          Vector minorVector = minorInit.retrieveMinorAll(maj);
          Enumeration minorEnum = minorVector.elements();
          while (minorEnum.hasMoreElements()){
            Minor min = (Minor)minorEnum.nextElement();
            minorNode = new DefaultMutableTreeNode(min);
            majorNode.add(minorNode);
          }
        }
      }
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }
  public void addNode(int instance,Object obj){
      DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
      DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
      if (canAdd) {
        int newIndex = lastItem.getChildCount();
        treeModel.insertNodeInto(newNode, lastItem, newIndex);
      }
      else {
        int newIndex = parent.getIndex(lastItem);
        treeModel.insertNodeInto(newNode, parent, newIndex+1);
      }
      jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void updateNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    lastItem.setUserObject(obj);
    jTree1.repaint();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    facultyPanel.setVisible(false);
    departmentPanel.setVisible(false);
    majorPanel.setVisible(false);
    minorPanel.setVisible(false);
    if (currentPanel == 0) {
      facultyPanel.setVisible(true);
      ((FacultyUI)facultyPanel).addFaculty(faculty);
    }
    else if (currentPanel == 1) {
      departmentPanel.setVisible(true);
      ((DepartmentUI)departmentPanel).addDepartment(faculty);
    }
    else if (currentPanel == 2) {
      majorPanel.setVisible(true);
      ((MajorUI)majorPanel).addMajor(department);
    }
    else if (currentPanel == 3) {
      minorPanel.setVisible(true);
      ((MinorUI)minorPanel).addMinor(major);
    }
    else if (currentPanel == 4) {
      minorPanel.setVisible(true);
      ((MinorUI)minorPanel).addMinor(major);
    }

/*    String str = "xxx"; //jTextField1.getText();
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(str);
//    int newIndex = parent.getIndex(lastItem);
//    treeModel.insertNodeInto(newNode,parent,newIndex);
    int newIndex = lastItem.getChildCount();
    treeModel.insertNodeInto(newNode,lastItem,newIndex);*/
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) jTree1.
        getSelectionPath().getLastPathComponent();
    if (currentNode != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode) currentNode.
          getParent();
      if (currentNode.isLeaf() && parent != null){
        if (currentPanel == 1) {
          complete = ((FacultyUI)facultyPanel).removeFaculty(faculty);
        }
        else if (currentPanel == 2) {
          complete = ((DepartmentUI)departmentPanel).removeDepartment(department);
        }
        else if (currentPanel == 3) {
          complete = ((MajorUI)majorPanel).removeMajor(major);
        }
        else if (currentPanel == 4) {
          complete = ((MinorUI)minorPanel).removeMinor(minor);
        }
        if (complete) treeModel.removeNodeFromParent(currentNode);
      }
    }
  }
}

class GeneralUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  GeneralUI adaptee;

  GeneralUI_jButton2_actionAdapter(GeneralUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class GeneralUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  GeneralUI adaptee;

  GeneralUI_jButton3_actionAdapter(GeneralUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}