package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;

public class OrganizationPanel extends JPanel {
  JPanel jPanel1 = new JPanel();
  JTree jTree1 = new JTree();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel2 = new JPanel();
  Border border1;
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;

  public OrganizationPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder();
    titledBorder1 = new TitledBorder(border1,"������˹��¡���֡��");
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"������˹��¡���֡��");
    this.setLayout(boxLayout22);
    jTree1.setDebugGraphicsOptions(0);
    jPanel1.setLayout(boxLayout21);
    jPanel2.setBorder(titledBorder2);
    jPanel2.setDebugGraphicsOptions(0);
    this.add(jPanel1, null);
    jPanel1.add(jTree1, null);
    this.add(jPanel2, null);
  }
}