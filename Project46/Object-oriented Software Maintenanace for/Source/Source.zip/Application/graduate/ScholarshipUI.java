package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class ScholarshipUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("�ع����֡��");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  FlowLayout flowLayout5 = new FlowLayout();
  JTextField nameText = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JPanel jPanel17 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel16 = new JPanel();
  JButton clearButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  Border border1;
  Border border2;
  JLabel jLabel7 = new JLabel();
  JComboBox tPrenameCombo1 = new JComboBox();
  JPanel jPanel19 = new JPanel();
  JPanel jPanel110 = new JPanel();
  JTextField noText = new JTextField();
  FlowLayout flowLayout7 = new FlowLayout();
  JPanel jPanel30 = new JPanel();
  FlowLayout flowLayout8 = new FlowLayout();
  JTextField intervalText = new JTextField();
  FlowLayout flowLayout6 = new FlowLayout();
  FlowLayout flowLayout4 = new FlowLayout();
  JComboBox typeCombo = new JComboBox();
  JPanel jPanel8 = new JPanel();
  JLabel jLabel10 = new JLabel();
  JTextField moneyText = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField yearText = new JTextField();
  //------------------------------------------------------------------------------------------------------------------------------------
  Scholarship scholarship = new Scholarship();
  Scholarship currentS = null;
  boolean newRecord = false;
  boolean canAdd = false;
  String[] strCombo = {"¡��鹤��˹��¡Ե","¡����ԹʹѺʹع","¡��鹷�����",
      "¡��鹷�����(���������)","¡��鹤��˹��¡Ե/�ԹʹѺʹع"};
  JComboBox exceptionCombo = new JComboBox(strCombo);
  JTree jTree1 = new JTree(treeModel);

  public ScholarshipUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    jButton2.setText("����");
    jButton2.addActionListener(new ScholarshipUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new ScholarshipUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border1);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel4.setPreferredSize(new Dimension(440, 240));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(border2);
    jSplitPane1.setContinuousLayout(true);
    jPanel2.setBorder(border2);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 250));
    jPanel2.setLayout(boxLayout21);
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setOpaque(true);
    nameText.setPreferredSize(new Dimension(380, 22));
    nameText.setText("");
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(120, 120));
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(6);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 220));
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 200));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setPreferredSize(new Dimension(100, 16));
    jLabel4.setText("�������ع����֡�� :");
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(100, 16));
    jLabel1.setText("���ͷع����֡�� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setPreferredSize(new Dimension(100, 16));
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setText("�����������ع :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(6);
    gridLayout1.setVgap(5);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setPreferredSize(new Dimension(100, 16));
    jLabel2.setText("�ӹǹ :");
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    jPanel16.setPreferredSize(new Dimension(161, 35));
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setLayout(flowLayout1);
    clearButton.setText("������");
    clearButton.addActionListener(new ScholarshipUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout1.setVgap(15);
    flowLayout1.setHgap(5);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new ScholarshipUI_saveButton_actionAdapter(this));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setPreferredSize(new Dimension(100, 16));
    jLabel7.setText("�ع¡��� :");
    exceptionCombo.setPreferredSize(new Dimension(300, 22));
    exceptionCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    jPanel110.setLayout(flowLayout6);
    jPanel110.setPreferredSize(new Dimension(320, 32));
    jPanel110.setMaximumSize(new Dimension(32767, 32767));
    jPanel110.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    noText.setPreferredSize(new Dimension(50, 22));
    noText.setText("");
    noText.setOpaque(true);
    noText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    flowLayout8.setAlignment(FlowLayout.LEFT);
    intervalText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    intervalText.setPreferredSize(new Dimension(50, 22));
    intervalText.setText("");
    flowLayout6.setAlignment(FlowLayout.LEFT);
    flowLayout4.setAlignment(FlowLayout.LEFT);
    typeCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    typeCombo.setPreferredSize(new Dimension(150, 22));
    jPanel8.setPreferredSize(new Dimension(320, 32));
    jPanel8.setLayout(flowLayout8);
    jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel10.setText("��");
    moneyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    moneyText.setPreferredSize(new Dimension(100, 22));
    moneyText.setText("");
    jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel9.setText("�ҷ");
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setPreferredSize(new Dimension(50, 16));
    jLabel5.setText("�ع � �� :");
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setPreferredSize(new Dimension(90, 16));
    jLabel6.setText("��Шӻա���֡�� :");
    yearText.setPreferredSize(new Dimension(100, 22));
    yearText.setText("");
    yearText.setOpaque(true);
    yearText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    exceptionCombo.setPreferredSize(new Dimension(300, 22));
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jSplitPane1.add(jPanel2, JSplitPane.RIGHT);
    jPanel2.add(jPanel4, null);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel4, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(jLabel7, null);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel9.add(jPanel17, null);
    jPanel17.add(nameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(typeCombo, null);
    jPanel9.add(jPanel110, null);
    jPanel110.add(noText, null);
    jPanel110.add(jLabel5, null);
    jPanel110.add(moneyText, null);
    jPanel110.add(jLabel9, null);
    jPanel9.add(jPanel30, null);
    jPanel30.add(intervalText, null);
    jPanel30.add(jLabel10, null);
    jPanel30.add(jLabel6, null);
    jPanel30.add(yearText, null);
    jPanel9.add(jPanel8, null);
    jPanel8.add(exceptionCombo, null);
    jPanel8.add(exceptionCombo, null);
    jPanel4.add(jPanel16, null);
    titledBorder6 = new TitledBorder(null, "�ع����֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel4.setBorder(titledBorder1);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());

    createTree();
    addScholarshipGroup();
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void addScholarshipGroup(){
    Database.connect();
    ScholarshipGroup ssg = new ScholarshipGroup();
    Vector v = ssg.retrieveScholarshipGroup();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      ScholarshipGroup sg  = (ScholarshipGroup)e.nextElement();
      typeCombo.addItem(sg);
    }
    Database.disconnect();
  }

  public void showUI(Scholarship scholar){
    newRecord = false;
    nameText.setText(scholar.getName());
    setSelectedGroupName(scholar.getGroup().getSgroupName());
    noText.setText(String.valueOf(scholar.getNo()));
    moneyText.setText(String.valueOf(scholar.getMoney()));
    intervalText.setText(String.valueOf(scholar.getInterval()));
    yearText.setText(String.valueOf(scholar.getYear()));
    exceptionCombo.setSelectedIndex(scholar.getException()-1);
  }

  public void setSelectedGroupName(String name)
  {
     for (int i = 0;i < typeCombo.getItemCount();++i)
     {
        ScholarshipGroup item = (ScholarshipGroup)typeCombo.getItemAt(i);
        if (item.getSgroupName().equals(name))
        {
           typeCombo.setSelectedItem(item);
           return;
        }
     }
  }

  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String){
        canAdd = true;
      }
      if (nodeInfo instanceof Scholarship){
        canAdd = false;
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)node1.getParent();
        currentS = (Scholarship)nodeInfo;
        showUI(currentS);
      }
    }
  }

  public void clear(){
    nameText.setText("");
    noText.setText("");
    moneyText.setText("");
    intervalText.setText("");
    yearText.setText("");
  }

  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode node = null;

    Vector sVector = scholarship.retrieveScholarship();
    Enumeration sEnum = sVector.elements();
    while (sEnum.hasMoreElements()){
      Scholarship s = (Scholarship)sEnum.nextElement();
      node = new DefaultMutableTreeNode(s);
      root.add(node);
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    newRecord = true;
    clear();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Scholarship) {
          Scholarship del = (Scholarship)obj;
          Database.connect();
          complete = del.deleteScholarship(del);
          Database.disconnect();
        }
        if (complete) treeModel.removeNodeFromParent(node);
      }
    }
  }

  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Scholarship s = new Scholarship();
    s.setName(nameText.getText());
    s.setGroup((ScholarshipGroup)typeCombo.getSelectedItem());

    int no = 0;
    try{
      no = Integer.parseInt(noText.getText());
      s.setNo(no);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ӹǹ�Թ�繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    double money = 0.0;
    try{
      money = Double.parseDouble(moneyText.getText());
      s.setMoney(money);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ӹǹ�Թ�繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    int year = 0;
    try{
      year = Integer.parseInt(yearText.getText());
      s.setYear(year);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ӹǹ�Թ�繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    int Interval = 0;
    try{
      Interval = Integer.parseInt(intervalText.getText());
      s.setInterval(Interval);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ӹǹ�Թ�繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    s.setException(exceptionCombo.getSelectedIndex()+1);
    Database.connect();
    if (newRecord){
      complete = s.insertScholarship(s);
      if (complete) addNode(s);
    }
    else {
      s.setID(this.currentS.getID());
      complete = s.updateScholarship(s);
      if (complete) this.currentS = s;
    }
    newRecord = false;
    Database.disconnect();
  }
  void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
}

class ScholarshipUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  ScholarshipUI adaptee;

  ScholarshipUI_jButton2_actionAdapter(ScholarshipUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class ScholarshipUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  ScholarshipUI adaptee;

  ScholarshipUI_jButton3_actionAdapter(ScholarshipUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class ScholarshipUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  ScholarshipUI adaptee;

  ScholarshipUI_saveButton_actionAdapter(ScholarshipUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class ScholarshipUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  ScholarshipUI adaptee;

  ScholarshipUI_clearButton_actionAdapter(ScholarshipUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}