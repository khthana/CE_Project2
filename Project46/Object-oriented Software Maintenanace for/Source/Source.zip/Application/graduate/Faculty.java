package graduate;

import java.util.*;
public class Faculty {
  private String facultyID;
  private String ename;
  private String tname;
  private Prename prename;
  private String deanEname;
  private String deanTname;
  private String position;
  private String approver;
  private Vector departmentVector = new Vector();
  private FacultyDB facDB = new FacultyDB();
  //Constructor
  public Faculty() {
  }
  public Faculty(String faculty){
    this.setFacultyID(faculty);
  }
  public Faculty(String facid,String facname){
    this.setFacultyID(facid);
    this.setTname(facname);
  }
  //getMethod
  public String getFacultyID(){
    return this.facultyID;
  }
  public String getEname(){
    return this.ename;
  }
  public String getTname(){
    return this.tname;
  }
  public Prename getPrename(){
    return this.prename;
  }
  public String getDeanEname(){
    return this.deanEname;
  }
  public String getDeanTname(){
    return this.deanTname;
  }
  public String getPosition(){
    return this.position;
  }
  public String getApprover(){
    return this.approver;
  }
  //setMethod
  public void setFacultyID(String facultyID){
    this.facultyID = facultyID;
  }
  public void setEname(String ename){
    this.ename = ename;
  }
  public void setTname(String tname){
    this.tname = tname;
  }
  public void setPrename(Prename prename){
    this.prename = prename;
  }
  public void setDeanEname(String deanEname){
    this.deanEname = deanEname;
  }
  public void setDeanTname(String deanTname){
    this.deanTname = deanTname;
  }
  public void setPosition(String position){
    this.position = position;
  }
  public void setApprover(String approver){
    this.approver = approver;
  }
  //Business method
  public void addDepartment(Department dep){
    departmentVector.addElement(dep);
  }
  public void setDepartment(Vector dep){
    departmentVector = dep;
  }
  public Enumeration retrieveDepartment(){
    return departmentVector.elements();
  }
  public Department retrieveDepartment(String dep){
    Enumeration e = departmentVector.elements();
    if (!e.hasMoreElements()) return null;
    return (Department)e.nextElement();
  }
  //Access method
  public Vector retrieveFacultyAll(){
    return  facDB.retrieveFacultyAll();
  }
  public Vector retrieveFaculty(){
    return facDB.retrieveFaculty();
  }
  public Faculty retrieveFaculty(String fac){
    return facDB.retrieveFaculty(fac);
  }
  public boolean insertFaculty(Faculty fac){
    return facDB.insertFaculty(fac);
  }
  public boolean updateFaculty(Faculty oldfaculty,Faculty newfaculty){
    return facDB.updateFaculty(oldfaculty,newfaculty);
  }
  public boolean deleteFaculty(Faculty fac){
    return facDB.deleteFaculty(fac);
  }
  public String toString(){
    return "���" + this.getTname();
  }
  public static void main(String[] args){
      Database.connect("jdbc:odbc:Graduate","Admin","123");
      Semester s = new Semester();
      s = s.retrieveCurrentSemester();
      System.out.println("�ա���֡�ҷ�� " + s.getYear() + " �Ҥ���¹��� " + s.getSemester() + " ���Ҥ���¹ " + s.getSemesterType());
/*      Occupation location = new Occupation();
      Enumeration e = location.retrieveOccupation().elements();
      while (e.hasMoreElements()){
        Occupation l = (Occupation) e.nextElement();
        System.out.println(l.getOccupationID() + " " + l.getOccupationName());
      }*/

/*      Location location = new Location();
      Enumeration e = location.retrieveLocation().elements();
      while (e.hasMoreElements()){
        Location l = (Location) e.nextElement();
        System.out.println(l.getLocationID() + " " + l.getLocationName());
      }*/

/*      Group group = new Group();
      Enumeration e = group.retrieveGroup().elements();
      while (e.hasMoreElements()){
        Group g = (Group)e.nextElement();
        System.out.print(g.getGroup() + " " + g.getGroupName());
      }*/
/*      Faculty fac = new Faculty();
      Department dep = new Department();
      Major maj = new Major();
      Minor mn = new Minor();
      Vector v = new Vector();
      //Test Major Minor------------------------------------------------------------------------------------------------------------------------------------
      v = fac.retrieveFacultyAll();
      Enumeration e = v.elements();
      while (e.hasMoreElements()){
        Vector w = new Vector();
        Faculty f = (Faculty)e.nextElement();
        w = dep.retrieveDepartmentAll(f);
        Enumeration ed = w.elements();
        while (ed.hasMoreElements()){
          Vector x = new Vector();
          Department d = (Department)ed.nextElement();
          x = maj.retrieveMajorAll(d);
          Enumeration em = x.elements();
          while(em.hasMoreElements()){
            Vector y = new Vector();
            Major ma = (Major)em.nextElement();
            y = mn.retrieveMinorAll(ma);
          }
        }
      }

      e = v.elements();
      while (e.hasMoreElements()){
        Faculty f = (Faculty)e.nextElement();
        System.out.println(f.getFacultyID() + " " + f.getEname());
        Enumeration ed = f.retrieveDepartment();
        while (ed.hasMoreElements()){
          Department d = (Department)ed.nextElement();
          System.out.println("    " + d.getDepartmentID() + " " + d.getEname());
          Enumeration em = d.retrieveMajor();
          while (em.hasMoreElements()){
            Major mj = (Major)em.nextElement();
            System.out.println("         " +mj.getMajorID() + " " + mj.getEname());
            Enumeration emn = mj.retrieveMinor();
            while (emn.hasMoreElements()){
              Minor mnr = (Minor)emn.nextElement();
              System.out.println("              " + mnr.getMinorID() + " " + mnr.getEname());
            }
          }
        }
      }
*/
      //Test Department-----------------------------------------------------------------------------------------------------------------------------------------
/*      v = fac.retrieveFacultyAll();
      Enumeration e = v.elements();
      while (e.hasMoreElements()){
        Vector w = new Vector();
        Faculty f = (Faculty)e.nextElement();
        System.out.println(f.getFacultyID() + " " + f.getEname());

        w = dep.retrieveDepartmentAll(f);
        Enumeration ed = w.elements();
        while (ed.hasMoreElements()){
          Department d = (Department)ed.nextElement();
          System.out.println("    " + d.getDepartmentID() + " " + d.getEname());
        }
      }

      e = v.elements();
      while (e.hasMoreElements()){
        Faculty f = (Faculty)e.nextElement();
        System.out.println(f.getFacultyID() + " " + f.getEname());

        Enumeration ed = f.retrieveDepartment();
        while (ed.hasMoreElements()){
          Department d = (Department)ed.nextElement();
          System.out.println("    " + d.getDepartmentID() + " " + d.getEname());
        }
      }
*/


      //Test Faculty-----------------------------------------------------------------------------------------------------------------------------------------
/*      Enumeration e = v.elements();
      while(e.hasMoreElements()){
        Faculty f = (Faculty)e.nextElement();
        System.out.println(f.getFacultyID() + " " + f.getEname());
        System.out.println(f.getTname());
        System.out.println(f.getPrename().getPrenameID());
        System.out.println(f.getPrename().getEprename());
        System.out.println(f.getPrename().getTPrename());
        System.out.println(f.getDeanEname());
        System.out.println(f.getDeanTname());
        System.out.println(f.getApprover());
      }*/

      Database.disconnect();
    }

}