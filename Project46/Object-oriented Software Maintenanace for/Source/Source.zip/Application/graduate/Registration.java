package graduate;

import java.util.*;
public class Registration {
  private long registrationID;
  private Student student;
  private Section section;
  private Semester semester;
  private RegisterType registerType;
  private String type;
  private String grade;
  private Date payDate;
  private Registrar registrar;
  private RegistrationDB registrationDB = new RegistrationDB();
  //Constructor
  public Registration() {
  }
  public Registration(long id){
    this.setRegistrationID(id);
  }
  //getMethod
  public long getRegistrationID(){
    return this.registrationID;
  }
  public Student getStudent(){
    return this.student;
  }
  public Section getSection(){
    return this.section;
  }
  public Semester getSemester(){
    return this.semester;
  }
  public RegisterType getRegisterType(){
    return this.registerType;
  }
  public String getType(){
    return this.type;
  }
  public String getGrade(){
    return this.grade;
  }
  public Date getPayDate(){
    return this.payDate;
  }
  public Registrar getRegistrar(){
    return this.registrar;
  }
  //setMethod
  public void setRegistrationID(long rid){
    this.registrationID = rid;
  }
  public void setStudent(Student s){
    this.student = s;
  }
  public void setSection(Section sec){
    this.section = sec;
  }
  public void setSemester(Semester sem){
    this.semester = sem;
  }
  public void setRegisterType(RegisterType regt){
    this.registerType = regt;
  }
  public void setType(String type){
    this.type = type;
  }
  public void setGrade(String g){
    this.grade = g;
  }
  public void setPayDate(Date pay){
    this.payDate = pay;
  }
  public void setRegistrar(Registrar regis){
    this.registrar = regis;
  }
  //Business Method
  public Vector retrieveRegistration(Student student){
    Vector v = registrationDB.retrieveRegistration(student);
    student.setRegistration(v);
    return v;
  }
 public Vector retrieveRegistration(Section sec){
   return registrationDB.retrieveRegistration(sec);
 }
  public int countTermRegisted(Student student){
    return registrationDB.countTermRegisted(student);
  }
  public boolean isPrerequisiteRegistered(Student student,Subject subject){
   return registrationDB.isPrerequisiteRegistered(student,subject);
  }
  public Vector retrieveRegistration(Student student,Semester semester,RegisterType registerType){
    Vector v = registrationDB.retrieveRegistration(student,semester,registerType);
    student.setRegistration(v);
    return v;
  }
  public Vector retrieveSemesterRegistered(Student student){
    return registrationDB.retrieveSemesterRegistered(student);
  }
  public Vector retrieveGroupedCourseWork(Student student){
    return registrationDB.retrieveGroupedCourseWork(student);
  }
  public boolean insertRegistration(Registration registration){
    return registrationDB.insertRegistration(registration);
  }
  public boolean updateRegistration(Registration registration){
    return registrationDB.updateRegistration(registration);
  }
  public boolean deleteRegistration(Registration registration){
    return registrationDB.deleteRegistration(registration);
  }

  public boolean isRegister(Student student,Semester semester,RegisterType registerType){
    Vector rv = registrationDB.retrieveRegistration(student,semester,registerType);
    if (rv.isEmpty()) return false;
    else return true;
  }
  public boolean isRegistered(Student student,Subject subject){
    return registrationDB.isRegistered(student,subject);
  }
}