package graduate;

import java.sql.*;
import java.util.*;
public class SemesterDB {
  public SemesterDB() {
  }
  public Vector retrieveCurrentSemester(){
    Vector semVector = new Vector();
    try
    {
      String query = "SELECT * FROM Semester WHERE CurrentSemester = 1";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Semester semester = new Semester();
          semester.setSemesterID(rs.getLong("SemesterID"));
          semester.setYear(rs.getInt("Year"));
          semester.setSemester(rs.getInt("SemesterNo"));
          semester.setSemesterType(rs.getInt("SemesterType"));
          semVector.addElement(semester);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return semVector;
  }

  public Semester retrieveSemester(Semester semester){
    Semester s = new Semester();
    try
    {
        String query = "SELECT * FROM Semester WHERE SemesterNo = " + semester.getSemester() + " AND ";
        query += "Year = " + semester.getYear();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          s.setSemesterID(rs.getLong("SemesterID"));
          s.setYear(rs.getInt("Year"));
          s.setSemester(rs.getInt("SemesterNo"));
          s.setSemesterType(rs.getInt("SemesterType"));
          s.setCurrentSemester(rs.getBoolean("CurrentSemester"));
          return s;
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return null;
  }

  public Semester retrieveSemester(long sid){
    Semester s = new Semester();
    try
    {
        String query = "SELECT * FROM Semester WHERE SemesterID = " + sid;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          s.setSemesterID(rs.getLong("SemesterID"));
          s.setYear(rs.getInt("Year"));
          s.setSemester(rs.getInt("SemesterNo"));
          s.setSemesterType(rs.getInt("SemesterType"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return s;
  }
  public boolean insertSemester(Semester semester){
    String query1 = "UPDATE Semester SET CurrentSemester = 0 WHERE CurrentSemester = 1";
    Database.update(query1);
    String query = "INSERT INTO Semester(Year,SemesterNo,SemesterType,CurrentSemester) ";
    query += "VALUES("+ semester.getYear() + " , " + semester.getSemester();
    query += ", " + semester.getSemesterType() + "," + ((semester.getCurrentSemester())?1:2) + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateSemester(Semester semester){
    String query1 = "UPDATE Semester SET CurrentSemester = 0 WHERE CurrentSemester = 1";
    Database.update(query1);
    String query = "UPDATE Semester SET ";
    query += "Year = " + semester.getYear() + ", ";
    query += "SemesterNo = " + semester.getSemester() + ", ";
    query += "SemesterType = " + semester.getSemesterType() + ", ";
    query += "CurrentSemester = " + ((semester.getCurrentSemester())?1:2) + " ";
    query += "WHERE SemesterID = " + semester.getSemesterID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSemester(Semester semester){
    String query = "DELETE FROM Semester WHERE SemesterID = " + semester.getSemesterID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    SemesterDB db = new SemesterDB();
    Semester s = new Semester(4);
    s.setYear(2547);
    s.setSemester(4);
    s.setSemesterType(1);
    s.setCurrentSemester(true);
//    s.updateSemester(s);
//    Semester ss = db.retrieveCurrentSemester();
//    System.out.println(ss.getSemesterID() + " " + ss.getYear() + " " + ss.getSemester() + " " + ss.getSemesterType());
    Database.disconnect();
  }
}