package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class ThesisDB {
  public ThesisDB() {
  }
  public Thesis retrieveThesis(Student student){
    Thesis thesis = new Thesis();
    try
    {
        String query = "SELECT * FROM Thesis WHERE ThesisID = " + student.getThesis().getThesisID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          thesis.setThesisID(rs.getLong("ThesisID"));
          thesis.setThesisEname(rs.getString("ThesisEname"));
          thesis.setThesisTname(rs.getString("ThesisTname"));
          thesis.setStartDate(rs.getDate("StartDate"));
          thesis.setFinishDate(rs.getDate("FinishDate"));
          thesis.setStudent(student);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return thesis;
  }
  public Thesis retrieveThesis(Student student, long thesisID){
    Thesis thesis = new Thesis();
    try
    {
        String query = "SELECT * FROM Thesis WHERE ThesisID = " + thesisID;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          thesis.setThesisID(rs.getLong("ThesisID"));
          thesis.setThesisEname(rs.getString("ThesisEname"));
          thesis.setThesisTname(rs.getString("ThesisTname"));
          thesis.setStartDate(rs.getDate("StartDate"));
          thesis.setFinishDate(rs.getDate("FinishDate"));
          thesis.setStudent(student);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return thesis;
  }
  public boolean insertThesis(Thesis thesis){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Thesis(ThesisEname,ThesisTname,StartDate,FinishDate) ";
    query = query + "VALUES('"+ thesis.getThesisEname() + "' , '" + thesis.getThesisTname() + "'";
    query = query + ", '" + formatter.format(thesis.getStartDate()) + "','" + formatter.format(thesis.getFinishDate()) + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateThesis(Thesis thesis){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Thesis SET ";
    query = query + "ThesisEname = '" + thesis.getThesisEname() + "', ";
    query = query + "ThesisTname = '" + thesis.getThesisTname() + "', ";
    query = query + "StartDate = '" + formatter.format(thesis.getStartDate()) + "', ";
    query = query + "FinishDate = '" + formatter.format(thesis.getFinishDate()) + "' ";
    query = query + "WHERE ThesisID = " + thesis.getThesisID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteThesis(Thesis thesis){
    String query = "DELETE FROM Thesis WHERE ThesisID = " + thesis.getThesisID();
    if (Database.update(query) != 0) return true;
    return false;
  }

  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ThesisDB db = new ThesisDB();
    Thesis t = new Thesis();
    t.setThesisID(2);
    t.setThesisEname("Test2");
    t.setThesisTname("Test2");
    GregorianCalendar g = new GregorianCalendar(2004,0,1);
    java.util.Date d = g.getTime();
    t.setStartDate(d);
    t.setFinishDate(d);
//    db.updateThesis(t);
    Student sd = new Student("001");
    sd.setThesis(new Thesis(1));
    Thesis v = db.retrieveThesis(sd);
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    System.out.println(v.getThesisID() + " " + v.getThesisEname() + " " + v.getThesisTname() + " " + formatter.format(v.getStartDate()) + "       " + formatter.format(v.getFinishDate()));
    Database.disconnect();
  }

}