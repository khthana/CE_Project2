package graduate;

import javax.swing.*;
import java.awt.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.border.*;

public class CourseMainUI extends JFrame {
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Faculty faculty = new Faculty();
  Department department = new Department();
  Major major = new Major();
  Border border1;
  JLabel jLabel4 = new JLabel();
  JComboBox facultyCombo = new JComboBox();
  JButton jButton2 = new JButton();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel110 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel10 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JButton jButton1 = new JButton();
  FlowLayout flowLayout7 = new FlowLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel30 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JComboBox departmentCombo = new JComboBox();
  BorderLayout borderLayout3 = new BorderLayout();
  FlowLayout flowLayout6 = new FlowLayout();
  JPanel jPanel17 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  BorderLayout borderLayout5 = new BorderLayout();
  JComboBox majorCombo = new JComboBox();
  JPanel jPanel9 = new JPanel();
  Border border2;

  public CourseMainUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(0,5,0,0);
    border2 = BorderFactory.createEmptyBorder(20,10,10,10);
    this.getContentPane().setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    this.setSize(new Dimension(400, 200));
    this.setTitle("��������ѡ�ٵ�");
    jLabel4.setText("�Ң��Ԫ� :");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    facultyCombo.setPreferredSize(new Dimension(270, 22));
    facultyCombo.addActionListener(new CourseMainUI_facultyCombo_actionAdapter(this));
    facultyCombo.addActionListener(new CourseMainUI_facultyCombo_actionAdapter(this));
    facultyCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton2.setText("��ŧ");
    jButton2.addActionListener(new CourseMainUI_jButton2_actionAdapter(this));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jPanel4.setLayout(flowLayout3);
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setText("�Ҥ�Ԫ� :");
    jPanel110.setLayout(flowLayout6);
    jPanel110.setPreferredSize(new Dimension(320, 32));
    jPanel110.setMaximumSize(new Dimension(32767, 32767));
    jPanel110.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel3.setLayout(borderLayout3);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setBorder(border1);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(6);
    gridLayout1.setVgap(5);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setText("��� :");
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setToolTipText("");
    jButton1.setText("¡��ԡ");
    jButton1.addActionListener(new CourseMainUI_jButton1_actionAdapter(this));
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(6);
    gridLayout2.setVgap(5);
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    jPanel12.setLayout(borderLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setBorder(border2);
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(350, 100));
    departmentCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    departmentCombo.setPreferredSize(new Dimension(270, 22));
    departmentCombo.addActionListener(new CourseMainUI_departmentCombo_actionAdapter(this));
    departmentCombo.addActionListener(new CourseMainUI_departmentCombo_actionAdapter(this));
    flowLayout6.setAlignment(FlowLayout.LEFT);
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    flowLayout3.setHgap(5);
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(380, 200));
    majorCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorCombo.setMinimumSize(new Dimension(26, 21));
    majorCombo.setPreferredSize(new Dimension(270, 22));
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(270, 22));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    this.getContentPane().add(jPanel1,  BorderLayout.CENTER);
    jPanel4.add(jButton2, null);
    jPanel4.add(jButton1, null);
    jPanel1.add(jPanel12,  BorderLayout.CENTER);
    jPanel12.add(jPanel6, BorderLayout.NORTH);
    jPanel9.add(jPanel17, null);
    jPanel17.add(facultyCombo, null);
    jPanel9.add(jPanel30, null);
    jPanel30.add(departmentCombo, null);
    jPanel9.add(jPanel110, null);
    jPanel110.add(majorCombo, null);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(jLabel4, null);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel4, BorderLayout.CENTER);
    addFaculty();
  }
  public Major getMajor(){
    return this.major;
  }
  public void addFaculty(){
      Database.connect();
      Vector v = faculty.retrieveFacultyAll();
      Enumeration e = v.elements();
      while (e.hasMoreElements()){
        Faculty fac = (Faculty)e.nextElement();
        facultyCombo.addItem(fac);
      }
      Database.disconnect();
    }

  void facultyCombo_actionPerformed(ActionEvent ea) {
    Faculty fac = (Faculty)facultyCombo.getSelectedItem();
    departmentCombo.removeAllItems();
    if (fac != null){
    Database.connect();
    Vector v = department.retrieveDepartmentAll(fac);
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Department d = (Department)e.nextElement();
      departmentCombo.addItem(d);
    }
    Database.disconnect();
   }
  }

  void departmentCombo_actionPerformed(ActionEvent ea) {
    Department dep = (Department)departmentCombo.getSelectedItem();
    majorCombo.removeAllItems();
    if (dep != null){
      Database.connect();
      Vector v = major.retrieveMajorAll(dep);
      Enumeration e = v.elements();
      while (e.hasMoreElements()){
        Major maj = (Major)e.nextElement();
        majorCombo.addItem(maj);
      }
      Database.disconnect();
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    boolean packFrame = false;
    Major maj = (Major)majorCombo.getSelectedItem();
    if (maj != null){
      major = maj;
      CourseUI frame = new CourseUI(this);
      if (packFrame) {
        frame.pack();
      }
      else {
        frame.validate();
      }
      //Center the window
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = frame.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
      frame.setVisible(true);
    }
  }
}

class CourseMainUI_facultyCombo_actionAdapter implements java.awt.event.ActionListener {
  CourseMainUI adaptee;

  CourseMainUI_facultyCombo_actionAdapter(CourseMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.facultyCombo_actionPerformed(e);
  }
}

class CourseMainUI_departmentCombo_actionAdapter implements java.awt.event.ActionListener {
  CourseMainUI adaptee;

  CourseMainUI_departmentCombo_actionAdapter(CourseMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.departmentCombo_actionPerformed(e);
  }
}

class CourseMainUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  CourseMainUI adaptee;

  CourseMainUI_jButton1_actionAdapter(CourseMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class CourseMainUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  CourseMainUI adaptee;

  CourseMainUI_jButton2_actionAdapter(CourseMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}