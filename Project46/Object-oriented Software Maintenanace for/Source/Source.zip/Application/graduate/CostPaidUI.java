package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.awt.event.*;
//import java.text.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class CostPaidUI extends JDialog {
  CompoundBorder titledBorder2;
  TitledBorder titledBorder6;
  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  Border border1;
  JPanel jPanel2 = new JPanel();
  JButton jButton1 = new JButton();
  //-------------------------------------------------------------------------------------------------------------------------------------------------------------
  Vector costv = null;

  public CostPaidUI(Frame frame, String title, boolean modal,Vector v) {
    super(frame, title, modal);
    try {
      costv = v;
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public CostPaidUI() {
    this(null, "", false,null);
  }
  private void jbInit() throws Exception {
    titledBorder6 = new TitledBorder(null, "�ӹǹ�Թ����ͧ����",  TitledBorder.LEFT, TitledBorder.TOP);
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder2);
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setPreferredSize(new Dimension(360, 404));
    panel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    panel1.setBorder(border1);
    panel1.setDebugGraphicsOptions(0);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("��ŧ");
    jButton1.addActionListener(new CostPaidUI_jButton1_actionAdapter(this));
    jTable1.setRowHeight(18);
    getContentPane().add(panel1);
    panel1.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jScrollPane1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2,  BorderLayout.SOUTH);
    jPanel2.add(jButton1, null);
    jScrollPane1.getViewport().add(jTable1, null);
    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setRowSelectionAllowed(true);
    jTable1.getTableHeader().setReorderingAllowed(false);
//    DecimalFormat format = new DecimalFormat("0.00");
//---------------------------------------------------------------------------------------------------------------------
    Object obj[][] = new Object[costv.size()][2];
    Enumeration ecost = costv.elements();
    int row = 0;
    while (ecost.hasMoreElements()){
      Cost c = (Cost)ecost.nextElement();
      obj[row][0] = c.getCostName();
      obj[row][1] = new Double(c.getValue());
      row++;
    }
//---------------------------------------------------------------------------------------------------------------------

    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        obj,new String[] {"��������´", "�ӹǹ�Թ (�ҷ)"}) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Double.class
      };
      boolean[] canEdit = new boolean[] {
          false, false
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setColumnSelectionAllowed(false);
    jTable1.setCellSelectionEnabled(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(0, 0));
    jTable1.setMaximumSize(new Dimension(0, 0));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY( (float) 0.5);
    jTable1.setAlignmentX( (float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);
    this.setSize(new Dimension(404, 250));
  }

  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }
}

class CostPaidUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  CostPaidUI adaptee;

  CostPaidUI_jButton1_actionAdapter(CostPaidUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}