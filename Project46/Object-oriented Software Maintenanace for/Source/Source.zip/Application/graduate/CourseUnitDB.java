package graduate;

import java.sql.*;
import java.util.*;
public class CourseUnitDB {
  public CourseUnitDB() {
  }
  public Vector retrieveCourseUnit(Major major){
    Vector v = new Vector();
    try
    {
        String query = "SELECT c.*,g.*,d.* FROM CourseUnit c,SubjectGroup g,Degree d WHERE ";
        query += "c.GroupID = g.GroupID AND d.DegreeID = c.DegreeID AND ";
        query += "majorID = '" + major.getMajorID() + "' ORDER BY d.DegreeID,g.GroupName";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          CourseUnit cu = new CourseUnit();
          Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
          Degree d = new Degree(rs.getLong("DegreeID"),rs.getBoolean("DegreeLevel"),rs.getBoolean("PT"),rs.getBoolean("MBN"));
          cu.setGroup(g);
          cu.setDegree(d);
          cu.setGroupUnit(rs.getInt("GroupUnit"));
          cu.setMajor(major);
          v.addElement(cu);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveCourseUnit(Major major,Degree degree){
    Vector v = new Vector();
    try
    {
        String query = "SELECT c.*,g.*,d.* FROM CourseUnit c,SubjectGroup g,Degree d WHERE ";
        query += "c.GroupID = g.GroupID AND d.DegreeID = c.DegreeID AND majorID = '" + major.getMajorID() + "' AND ";
        query += "c.DegreeID = " + degree.getDegreeID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          CourseUnit cu = new CourseUnit();
          Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
          cu.setGroup(g);
          cu.setDegree(degree);
          cu.setMajor(major);
          v.addElement(cu);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertCourseUnit(CourseUnit courseUnit){
    String query = "INSERT INTO CourseUnit(MajorID,GroupID,DegreeID,GroupUnit) ";
    query += "VALUES('"+ courseUnit.getMajor().getMajorID() + "' , " + courseUnit.getGroup().getGroup() + " ";
    query += ", " + courseUnit.getDegree().getDegreeID() + "," + courseUnit.getGroupUnit() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateCourseUnit(CourseUnit oldCourse,CourseUnit newCourse){
    String query = "UPDATE CourseUnit SET ";
    query += "MajorID = '" + newCourse.getMajor().getMajorID() + "', ";
    query += "GroupID = " + newCourse.getGroup().getGroup() + ", ";
    query += "DegreeID = " + newCourse.getDegree().getDegreeID() + ", ";
    query += "GroupUnit = " + newCourse.getGroupUnit() + " ";
    query += "WHERE MajorID = '" + oldCourse.getMajor().getMajorID() + "' AND ";
    query += "GroupID = " + oldCourse.getGroup().getGroup() + " AND ";
    query += "DegreeID = " + oldCourse.getDegree().getDegreeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteCourseUnit(CourseUnit courseUnit){
    String query = "DELETE FROM CourseUnit ";
    query +=  "WHERE MajorID = '" + courseUnit.getMajor().getMajorID() + "' AND ";
    query +=  "DegreeID = " + courseUnit.getDegree().getDegreeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    CourseUnitDB db = new CourseUnitDB();
    CourseUnit g = new CourseUnit();
    g.setGroup(new Group(1));
    g.setMajor(new Major("001"));
    g.setDegree(new Degree(1));
    g.setGroupUnit(48);
    CourseUnit gg = new CourseUnit();
    gg.setGroup(new Group(1));
    gg.setMajor(new Major("001"));
    gg.setDegree(new Degree(1));
    gg.setGroupUnit(36);

//    db.updateCourseUnit(g,gg);

    Vector v = db.retrieveCourseUnit(new Major("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      CourseUnit m = (CourseUnit)e.nextElement();
      System.out.println(m.getGroup().getGroupName() + " " + m.getMajor().getMajorID() + " " + m.getDegree().getDegreeID() + " " + m.getGroupUnit());
    }
    Database.disconnect();
  }

}