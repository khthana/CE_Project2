package graduate;

import java.sql.*;
import java.util.*;
public class PrenameDB {
  public PrenameDB() {
  }
  public Vector retrievePrename(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Prename ORDER BY TPrename";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Prename prename = new Prename();
          prename.setPrenameID(rs.getInt("PrenameID"));
          prename.setEPrename(rs.getString("EPrename"));
          prename.setTPrename(rs.getString("TPrename"));
          v.addElement(prename);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;

  }
  public boolean insertPrename(Prename prename){
    String query = "INSERT INTO Prename(EPrename,TPrename) ";
    query += "VALUES('" + prename.getEprename() + "','" + prename.getTPrename() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updatePrename(Prename prename){
    String query = "UPDATE Prename SET ";
    query += "EPrename = '" + prename.getEprename() + "', ";
    query += "TPrename = '" + prename.getTPrename()+ "' ";
    query += "WHERE PrenameID = " + prename.getPrenameID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deletePrename(Prename prename){
    String query = "DELETE FROM Prename WHERE PrenameID = " + prename.getPrenameID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    PrenameDB mDB= new PrenameDB();
    Prename m = new Prename();
/*    m.setPrenameID(2);
    m.setEPrename("Information");
    m.setTPrename("Ts");
    m.updatePrename(m);*/
    Vector v = m.retrievePrename();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Prename m1 = (Prename)e.nextElement();
      System.out.println(m1.getPrenameID()+ " " + m1.getEprename() + " " + m1.getTPrename());
    }
    Database.disconnect();
  }
}