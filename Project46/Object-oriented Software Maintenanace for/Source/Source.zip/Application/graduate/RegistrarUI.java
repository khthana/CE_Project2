package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class RegistrarUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("���˹�ҷ��");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  ButtonGroup buttonGroup1 = new ButtonGroup();
  TitledBorder titledBorder2;
  Border border1;
  Border border2;
  JPanel jPanel13 = new JPanel();
  JTextField eNameText = new JTextField();
  FlowLayout flowLayout5 = new FlowLayout();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel19 = new JPanel();
  JRadioButton specialRadio = new JRadioButton();
  JPanel jPanel110 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout8 = new BorderLayout();
  FlowLayout flowLayout7 = new FlowLayout();
  GridLayout gridLayout2 = new GridLayout();
  JTextField ePrenameText = new JTextField();
  JPanel jPanel30 = new JPanel();
  FlowLayout flowLayout8 = new FlowLayout();
  JPanel jPanel12 = new JPanel();
  JComboBox jComboBox3 = new JComboBox();
  JComboBox tPrenameCombo = new JComboBox();
  JRadioButton normalRadio = new JRadioButton();
  FlowLayout flowLayout6 = new FlowLayout();
  BoxLayout2 boxLayout23 = new BoxLayout2();
  JPanel jPanel7 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JPanel jPanel111 = new JPanel();
  JTextField positionText = new JTextField();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel6 = new JLabel();
  FlowLayout flowLayout4 = new FlowLayout();
  JTextField idText = new JTextField();
  FlowLayout flowLayout9 = new FlowLayout();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel8 = new JPanel();
  FlowLayout flowLayout10 = new FlowLayout();
  JLabel jLabel7 = new JLabel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  JPanel jPanel9 = new JPanel();
  JTextField tNameText = new JTextField();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel16 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  JPasswordField passwordText = new JPasswordField();
  //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
  Registrar registrar = new Registrar();
  Registrar currentReg = null;
  boolean newRecord = true;
  boolean canAdd = false;

  public RegistrarUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�Է���");
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton2.setText("����");
    jButton2.addActionListener(new RegistrarUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setLayout(borderLayout1);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new RegistrarUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border1);
    jPanel1.setPreferredSize(new Dimension(644, 460));
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(border2);
    jPanel3.setPreferredSize(new Dimension(175, 410));
    jSplitPane1.setPreferredSize(new Dimension(644, 460));
    jSplitPane1.setContinuousLayout(true);
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setPreferredSize(new Dimension(644, 460));
    eNameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    eNameText.setOpaque(true);
    eNameText.setPreferredSize(new Dimension(380, 22));
    eNameText.setSelectionStart(11);
    eNameText.setText("");
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    specialRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    specialRadio.setAction(null);
    specialRadio.setText("�����");
    jPanel110.setLayout(flowLayout6);
    jPanel110.setPreferredSize(new Dimension(320, 32));
    jPanel110.setMaximumSize(new Dimension(32767, 32767));
    jPanel110.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 130));
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(7);
    gridLayout2.setVgap(5);
    ePrenameText.setPreferredSize(new Dimension(380, 22));
    ePrenameText.setText("");
    ePrenameText.setOpaque(true);
    ePrenameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    flowLayout8.setAlignment(FlowLayout.LEFT);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 320));
    tPrenameCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tPrenameCombo.setPreferredSize(new Dimension(150, 22));
    tPrenameCombo.addActionListener(new RegistrarUI_tPrenameCombo_actionAdapter(this));
    normalRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    normalRadio.setText("�����");
    flowLayout6.setAlignment(FlowLayout.LEFT);
    boxLayout23.setAxis(BoxLayout.Y_AXIS);
    jPanel7.setBorder(titledBorder2);
    jPanel7.setMinimumSize(new Dimension(117, 30));
    jPanel7.setPreferredSize(new Dimension(400, 30));
    jPanel7.setLayout(flowLayout10);
    flowLayout3.setAlignment(FlowLayout.LEFT);
    jPanel111.setLayout(flowLayout9);
    jPanel111.setPreferredSize(new Dimension(320, 32));
    jPanel111.setMaximumSize(new Dimension(32767, 32767));
    jPanel111.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    positionText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    positionText.setPreferredSize(new Dimension(380, 22));
    positionText.setText("");
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 300));
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("���˹�");
    flowLayout4.setAlignment(FlowLayout.LEFT);
    idText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    idText.setOpaque(true);
    idText.setPreferredSize(new Dimension(380, 22));
    flowLayout9.setAlignment(FlowLayout.LEFT);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�ӹ�˹�Ҫ���[�] :");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("�ӹ�˹�Ҫ���[�] :");
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel4.setBorder(null);
    jPanel4.setPreferredSize(new Dimension(440, 450));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("�������˹�ҷ�� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setText("�������˹�ҷ��[�] :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel25.setPreferredSize(new Dimension(440, 300));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(7);
    gridLayout1.setVgap(5);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("�������˹�ҷ��[�] :");
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 450));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "��������´���˹�ҷ��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel2.setBorder(titledBorder1);
    jPanel11.setLayout(boxLayout23);
    jPanel11.setDebugGraphicsOptions(0);
    jPanel11.setPreferredSize(new Dimension(432, 80));
    jPanel8.setPreferredSize(new Dimension(320, 32));
    jPanel8.setLayout(flowLayout8);
    flowLayout10.setAlignment(FlowLayout.CENTER);
    flowLayout10.setVgap(10);
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setText("���ʼ�ҹ :");
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 130));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    tNameText.setPreferredSize(new Dimension(380, 22));
    tNameText.setText("");
    tNameText.setOpaque(true);
    tNameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel13.setLayout(borderLayout4);
    jPanel16.setPreferredSize(new Dimension(161, 35));
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setLayout(flowLayout1);
    flowLayout1.setVgap(15);
    flowLayout1.setHgap(5);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new RegistrarUI_saveButton_actionAdapter(this));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setText("������");
    clearButton.addActionListener(new RegistrarUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    passwordText.setMinimumSize(new Dimension(100, 21));
    passwordText.setPreferredSize(new Dimension(100, 21));
    passwordText.setSelectionStart(0);
    passwordText.setText("");
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jSplitPane1.add(jPanel13, JSplitPane.RIGHT);
    jPanel13.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jPanel4, null);
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel4, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel5, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(jLabel6, null);
    jPanel10.add(jLabel7, null);
    jPanel6.add(jPanel11, BorderLayout.SOUTH);
    jPanel11.add(jPanel7, null);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel7.add(normalRadio, null);
    jPanel7.add(specialRadio, null);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel9.add(jPanel17, null);
    jPanel17.add(idText, null);
    jPanel9.add(jPanel111, null);
    jPanel111.add(tPrenameCombo, null);
    jPanel9.add(jPanel30, null);
    jPanel30.add(tNameText, null);
    jPanel9.add(jPanel110, null);
    jPanel110.add(ePrenameText, null);
    jPanel9.add(jPanel8, null);
    jPanel8.add(eNameText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(positionText, null);
    jPanel9.add(jPanel19, null);
    jPanel4.add(jPanel16, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    buttonGroup1.add(normalRadio);
    buttonGroup1.add(specialRadio);
    jPanel19.add(passwordText, null);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());

    createTree();
    addPrename();
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void clear(){
    idText.setText("");
    tPrenameCombo.setSelectedIndex(0);
    tNameText.setText("");
    ePrenameText.setText("");
    eNameText.setText("");
    positionText.setText("");
    passwordText.setText("");
    normalRadio.setSelected(true);
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  public void showUI(Registrar reg){
    newRecord = false;
    idText.setText(reg.getRegistrarID());
    setSelectedName(reg.getPrename().getTPrename());
    tNameText.setText(reg.getTname());
    eNameText.setText(reg.getEname());
    positionText.setText(reg.getPosition());
    passwordText.setText(reg.getPassword());
    if (reg.getPermission() == 1) normalRadio.setSelected(true);
    else specialRadio.setSelected(true);
  }

  public void updateNode(Object obj){
  DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
  lastItem.setUserObject(obj);
  jTree1.repaint();
}
  public void setSelectedName(String name)
  {
     for (int i = 0;i < tPrenameCombo.getItemCount();++i)
     {
        Prename item = (Prename)tPrenameCombo.getItemAt(i);
        if (item.getTPrename() .equals(name))
        {
           tPrenameCombo.setSelectedItem(item);
           ePrenameText.setText(item.getEprename());
           return;
        }
     }
  }
  public void addPrename(){
    Database.connect();
    Prename prename = new Prename();
    Vector v = prename.retrievePrename();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Prename pre  = (Prename)e.nextElement();
      tPrenameCombo.addItem(pre);
    }
    Database.disconnect();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Registrar registrar = new Registrar();
    if (idText.getText().equals("")){
        JOptionPane.showMessageDialog(this,"��سҡ�͡�������˹�ҷ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (passwordText.getPassword().equals("")) {
      JOptionPane.showMessageDialog(this,"��س�������ʼ�ҹ���˹�ҷ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    registrar.setRegistrarID(idText.getText());
    registrar.setPrename((Prename)tPrenameCombo.getSelectedItem());
    registrar.setEname(eNameText.getText());
    registrar.setTname(tNameText.getText());
    registrar.setPosition(positionText.getText());
    registrar.setPassword(new String(passwordText.getPassword()));
    registrar.setPermission((normalRadio.isSelected())?1:2);
    Database.connect();
    if (newRecord) {
      complete = registrar.insertRegistrar(registrar);
      if (complete) addNode(registrar);
    }
    else {
      complete = registrar.updateRegistrar(currentReg,registrar);
      if (complete) {
        updateNode(registrar);
      }
    }
    Database.disconnect();
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String) canAdd = true;
      else canAdd =false;
      if (nodeInfo instanceof Registrar){
        currentReg = (Registrar)nodeInfo;
        showUI(currentReg);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode registrarNode = null;

    Vector regVector = registrar.retrieveRegistrarAll();
    Enumeration regEnum = regVector.elements();
    while (regEnum.hasMoreElements()) {
      Registrar regr = (Registrar) regEnum.nextElement();
      registrarNode = new DefaultMutableTreeNode(regr);
      root.add(registrarNode);
    }

    Database.disconnect();
    jTree1.expandRow(0);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    newRecord = true;
    clear();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Registrar) {
          Registrar del = (Registrar)obj;
          Database.connect();
          complete = del.deleteRegistrar(del);
          Database.disconnect();
        }
        if (complete) {
          treeModel.removeNodeFromParent(node);
          clear();
        }
      }
    }
  }

  void tPrenameCombo_actionPerformed(ActionEvent e) {
    if (tPrenameCombo.getSelectedItem() != null){
      Prename p = (Prename)tPrenameCombo.getSelectedItem();
      ePrenameText.setText(p.getEprename());
    }
  }
}

class RegistrarUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  RegistrarUI adaptee;

  RegistrarUI_clearButton_actionAdapter(RegistrarUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class RegistrarUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  RegistrarUI adaptee;

  RegistrarUI_saveButton_actionAdapter(RegistrarUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class RegistrarUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  RegistrarUI adaptee;

  RegistrarUI_jButton2_actionAdapter(RegistrarUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class RegistrarUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  RegistrarUI adaptee;

  RegistrarUI_jButton3_actionAdapter(RegistrarUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class RegistrarUI_tPrenameCombo_actionAdapter implements java.awt.event.ActionListener {
  RegistrarUI adaptee;

  RegistrarUI_tPrenameCombo_actionAdapter(RegistrarUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.tPrenameCombo_actionPerformed(e);
  }
}