package graduate;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class SectionProfessorUI extends JDialog {
  BorderLayout borderLayout1 = new BorderLayout();
//--------------------------------------------------------------------------------------------------------------------------------------------------
  Professor professor = new Professor();
  Border border1;
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  Border border2;
  Border border3;
  TitledBorder titledBorder1;
  Border border4;
  TitledBorder titledBorder2;
  Border border5;
  Border border6;
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton jButton1 = new JButton();
  JList jList1 = new JList();
  JPanel jPanel4 = new JPanel();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel jPanel2 = new JPanel();
  JList jList2 = new JList();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel7 = new JPanel();
  JButton saveButton = new JButton();
  FlowLayout flowLayout2 = new FlowLayout();
  JButton jButton2 = new JButton();
  Border border7;

  public SectionProfessorUI() {
    try {
      JDialog jd = new JDialog();
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    border1 = BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),BorderFactory.createEmptyBorder(5,5,5,5));
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�Ҩ�����Ш��Ҥ�Ԫ�");
    border7 = BorderFactory.createEmptyBorder(0,0,0,15);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�Ҩ�������͹");
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border5 = BorderFactory.createCompoundBorder(titledBorder1,BorderFactory.createEmptyBorder(5,5,5,5));
    border6 = BorderFactory.createCompoundBorder(titledBorder2,BorderFactory.createEmptyBorder(5,5,5,5));
    this.getContentPane().setLayout(borderLayout1);
    jPanel3.setLayout(borderLayout2);
    jPanel3.setBorder(border2);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setBorder(border1);
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setLayout(borderLayout5);
    jPanel1.setLayout(flowLayout1);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("���� >>");
    jButton1.addActionListener(new SectionProfessorUI_jButton1_actionAdapter(this));
    jPanel4.setLayout(borderLayout3);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setBorder(border5);
    jPanel4.setPreferredSize(new Dimension(162, 237));
    jPanel2.setLayout(verticalFlowLayout1);
    jList2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jList2.setMaximumSize(new Dimension(400, 300));
    jList2.setPreferredSize(new Dimension(140, 200));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setBorder(border6);
    jPanel5.setPreferredSize(new Dimension(162, 237));
    jPanel5.setLayout(borderLayout4);
    jList1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jList1.setMaximumSize(new Dimension(400, 300));
    jList1.setPreferredSize(new Dimension(140, 200));
    jPanel1.setBorder(null);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    saveButton.setMaximumSize(new Dimension(80, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    jPanel7.setLayout(flowLayout2);
    flowLayout2.setAlignment(FlowLayout.RIGHT);
    flowLayout2.setHgap(5);
    flowLayout2.setVgap(5);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("�Դ");
    jButton2.setVerticalAlignment(SwingConstants.CENTER);
    jButton2.addActionListener(new SectionProfessorUI_jButton2_actionAdapter(this));
    jPanel7.setBorder(border7);
    this.getContentPane().add(jPanel3,  BorderLayout.CENTER);
    jPanel3.add(jPanel6,  BorderLayout.CENTER);
    jPanel6.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel4, null);
    jPanel4.add(jList1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, null);
    jPanel2.add(jButton1, null);
    jPanel1.add(jPanel5, null);
    jPanel5.add(jList2, BorderLayout.CENTER);
    jPanel6.add(jPanel7,  BorderLayout.SOUTH);
    jPanel7.add(saveButton, null);
    jPanel7.add(jButton2, null);
    this.setSize(new Dimension(480,350));
    this.setTitle("�Ҩ�������͹");
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    addList1();
  }
  public void addList1(){
    Database.connect();
    Vector v = professor.retrieveProfessor(new Department("001"));
    Database.disconnect();
    jList1.setListData(v);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    jList2.setListData( jList1.getSelectedValues());
  }

  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }
}

class SectionProfessorUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  SectionProfessorUI adaptee;

  SectionProfessorUI_jButton2_actionAdapter(SectionProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class SectionProfessorUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  SectionProfessorUI adaptee;

  SectionProfessorUI_jButton1_actionAdapter(SectionProfessorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}