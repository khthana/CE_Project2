package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class StudentDB {
  Faculty faculty;
  Department department;
  Major major = new Major();
  public StudentDB() {
  }
  public Vector retrieveStudent(Student student){
    Vector v = new Vector();
    try
    {
        String query = "SELECT p.*,s.* FROM Prename p,Student s ";
        query += "WHERE p.PrenameID = s.PrenameID AND ";
        query += "s.StudentID ='" + student.getStudentID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Student s = new Student();
          s.setStudentID(rs.getString("StudentID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          s.setPrename(p);
          s.setStudentEname(rs.getString("StudentEname"));
          s.setStudentTname(rs.getString("StudentTname"));
          s.setPassword(rs.getString("Password"));
          s.setEmail(rs.getString("Email"));
          s.setDegree(rs.getInt("Degree"));
          s.setStudentType(rs.getInt("StudentType"));
          s.setStudyGroup(rs.getInt("StudyGroup"));
          s.setStatus(rs.getInt("Status"));
          s.setRegisterStatus(rs.getInt("RegisterStatus"));
          s.setApproved(rs.getBoolean("Approved"));
          s.setDebtStatus(rs.getBoolean("DebtStatus"));
          s.setLibraryStatus(rs.getBoolean("LibraryStatus"));
          s.setNationalStatus(rs.getBoolean("NationalStatus"));
          s.setPaymentCondition(rs.getInt("PaymentCondition"));
          s.setNoSupportTerm(rs.getInt("NoSupportTerm"));
          s.setMajor(retrieveMajor(rs.getString("MajorID")));
          s.setMinor(retrieveMinor(rs.getString("MinorID")));
          s.setLocation(retrieveLocation(rs.getLong("LocationID")));
          s.setAdoptDate(rs.getDate("AdoptDate"));
          s.setEntraceSemester(retrieveSemester(rs.getLong("EntranceSemesterID")));
          s.setEntranceDate(rs.getDate("EntranceDate"));
          s.setLeaveSemester(retrieveSemester(rs.getLong("LeaveSemesterID")));
          s.setLeaveDate(rs.getDate("LeaveDate"));
          s.setProfessor(retrieveProfessor(rs.getString("ProfessorID")));

          s.setThesis(new Thesis(rs.getLong("ThesisID")));
/*          Thesis thesis = new Thesis();
          s.setThesis(thesis.retrieveThesis(s,rs.getLong("ThesisID")));*/

          s.setBirthday(rs.getDate("Birthday"));
          s.setReligion(rs.getString("Religion"));
          s.setRace(rs.getString("Race"));
          s.setNationality(rs.getString("Nationality"));
          s.setGender(rs.getString("Gender"));
          s.setOccupation(retrieveOccupation(rs.getLong("OccupationID")));
          s.setSalary(rs.getDouble("Salary"));
          s.setOldInstitute(rs.getString("OldInstitute"));
          s.setOldDegree(rs.getString("OldDegree"));
          s.setOldGPA(rs.getDouble("OldGpa"));
          s.setOldLeaveYear(rs.getInt("OldLeaveYear"));
          s.setRegisterAddress(rs.getString("RegisterAddress"));
          s.setRegisterTel(rs.getString("RegisterTel"));
          s.setRecentAddress(rs.getString("RecentAddress"));
          s.setRecentTel(rs.getString("RecentTel"));
          s.setFatherName(rs.getString("FatherName"));
          s.setFatherOccupation(retrieveOccupation(rs.getLong("FatherOccupationID")));
          s.setMotherName(rs.getString("MotherName"));
          s.setMotherOccupation(retrieveOccupation(rs.getLong("MotherOccupationID")));
          s.setCoupleName(rs.getString("CoupleName"));
          s.setCoupleOccupation(retrieveOccupation(rs.getLong("CoupleOccupationID")));
          s.setChildren(rs.getInt("Children"));
          s.setParentName(rs.getString("ParentName"));
          s.setRelation(rs.getString("Relationship"));
          s.setParentAddress(rs.getString("ParentAddress"));
          s.setParentTel(rs.getString("ParentTel"));
          v.addElement(s);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Major retrieveMajor(){
    return major;
  }
  public Department retrieveDepartment(){
    return department;
  }
  public Faculty retrieveFaculty(){
    return faculty;
  }
  private Major retrieveMajor(String majorID){
    try {
      String query = "SELECT m.*,d.DepartmentID,d.DepartmentTname,d.DepartmentEname,f.FacultyID,f.FacultyTname,f.FacultyEname ";
      query += "FROM Major m,Department d,Faculty f WHERE ";
      query += "m.DepartmentID = d.DepartmentID AND d.FacultyID = f.FacultyID AND ";
      query += "MajorID = '" + majorID + "'";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        faculty = new Faculty(rs.getString("FacultyID"),rs.getString("FacultyTname"));
        faculty.setEname(rs.getString("FacultyEname"));
        department = new Department(rs.getString("DepartmentID"),rs.getString("DepartmentTname"));
        department.setEname(rs.getString("DepartmentEname"));
        major.setMajorID(rs.getString("MajorID"));
        major.setEname(rs.getString("MajorEname"));
        major.setTname(rs.getString("MajorTname"));
        major.setMasterEname(rs.getString("MasterEname"));
        major.setMasterTname(rs.getString("MasterTname"));
        major.setMasterEabbr(rs.getString("MasterEAbbr"));
        major.setMasterTabbr(rs.getString("MasterTAbbr"));
        major.setPhDEname(rs.getString("PhDEname"));
        major.setPhDTname(rs.getString("PhDTname"));
        major.setPhDEabbr(rs.getString("PhDEAbbr"));
        major.setPhDTabbr(rs.getString("PhDTAbbr"));
        major.setDepartment(department);
        department.setFaculty(faculty);
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return major;
  }
  private Minor retrieveMinor(String minorID){
    Minor minor = new Minor();
    try {
      String query = "SELECT * FROM Minor WHERE MinorID = '" + minorID + "'";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        minor.setMinorID(rs.getString("MinorID"));
        minor.setEname(rs.getString("MinorEname"));
        minor.setTname(rs.getString("MinorTname"));
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return minor;
  }
  private Location retrieveLocation(long loc){
    Location l = new Location();
    try
    {
        String query = "SELECT * FROM Location WHERE LocationID = " + loc;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          l.setLocationID(rs.getLong("LocationID"));
          l.setLocationName(rs.getString("LocationName"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return l;
  }
  private Professor retrieveProfessor(String profid){
    Professor prof = new Professor();
    try {
      String query =
          "SELECT t.*,p.* FROM Professor t,Prename p WHERE t.PrenameID = p.PrenameID AND ";
      query += "t.ProfessorID = '" + profid +"'";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        prof.setProfessorID(rs.getString("ProfessorID"));
        Prename p = new Prename(rs.getInt("PrenameID"), rs.getString("EPrename"),
                                rs.getString("TPrename"));
        prof.setPrename(p);
        prof.setEprofessorName(rs.getString("EprofessorName"));
        prof.setTprofessorName(rs.getString("TProfessorName"));
        prof.setPassword(rs.getString("Password"));
        prof.setPosition(rs.getString("Position"));
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return prof;
  }
  private Vector retrieveScholar(Student student){
    Vector v = new Vector();
    try
    {
        String query = "SELECT s.StudentID,l.*,g.*,p.* FROM Student s,Scholar l,ScholarshipGroup g,Scholarship p WHERE ";
        query += "s.StudentID = l.StudentID AND p.ScholarshipGroupID = g.ScholarshipGroupID AND ";
        query += "l.ScholarshipID = p.ScholarshipID AND l.StudentID = '" + student.getStudentID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Scholarship s = new Scholarship();
          s.setID(rs.getLong("ScholarshipID"));
          s.setName(rs.getString("ScholarshipName"));
          s.setYear(rs.getLong("ScholarshipYear"));
          s.setGroup(new ScholarshipGroup(rs.getLong("ScholarshipGroupID"),rs.getString("ScholarshipGroupName")));
          s.setMoney(rs.getDouble("ScholarshipMoney"));
          s.setNo(rs.getInt("ScholarshipNo"));
          s.setInterval(rs.getInt("Interval"));
          s.setException(rs.getInt("Exception"));
          v.addElement(s);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  private Semester retrieveSemester(long sid){
    Semester s = new Semester();
    try
    {
        String query = "SELECT * FROM Semester WHERE SemesterID = " + sid;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          s.setSemesterID(rs.getLong("SemesterID"));
          s.setYear(rs.getInt("Year"));
          s.setSemester(rs.getInt("SemesterNo"));
          s.setSemesterType(rs.getInt("SemesterType"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return s;
  }
  private Occupation retrieveOccupation(long oid){
    Occupation o = new Occupation();
    try
    {
        String query = "SELECT * FROM Occupation WHERE OccupationID = " + oid;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          o.setOccupationID(rs.getLong("OccupationID"));
          o.setOccupationName(rs.getString("OccupationName"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return o;
  }

  public boolean verifyUsername(String uname,String password){
    try
    {
        String query = "SELECT * FROM Student WHERE StudentID = '" + uname + "' AND Password = '" + password +"'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          return true;
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return false;
  }

  public boolean insertStudent(Student student){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Student(StudentID,PrenameID,StudentEname,StudentTname,Password,Email,";
    query += "Degree,StudentType,StudyGroup,Status,RegisterStatus,Approved,DebtStatus,LibraryStatus,";
    query += "NationalStatus,PaymentCondition,NoSupportTerm,MajorID,MinorID,LocationID,";
/*    query += " AdoptDateEntranceSemesterID,EntranceDate,LeaveSemesterID,LeaveDate,ProfessorID,ThesisID,Birthday,";
    query += "Religion,Race,Nationality,Gender,OccupationID,Salary,OldInstitute,OldDegree,OldGpa,OldLeaveYear,";
    query += "RegisterAddress,RegisterTel,RecentAddress,RecentTel,FatherName,FatherOccupationID,MotherName,";
    query += "MotherOccupationID,CoupleName,CoupleOccupationID,Children,ParentName,";*/
    query += "Relationship,ParentAddress,ParentTel)";
    query += "VALUES('"+ student.getStudentID() + "' , " + student.getPrename().getPrenameID();
    query += ", '" + student.getStudentEname() + "','" + student.getStudentTname() + "','" + student.getPassword() + "'";
    query += ", '" + student.getEmail() + "'," + student.getDegree() + "," + student.getStudentType();
    query += ", " + student.getStudyGroup() + "," + student.getStatus() + "," + student.getRegisterStatus();
    query += ", " + (student.getApproved()?1:0) + "," + (student.getDebtStatus()?1:0) + "," + (student.getLibraryStatus()?1:0);
    query += ", " + (student.getNationalStatus()?1:0) + "," + student.getPaymentCondition() + "," + student.getNoSupportTerm();
    query += ", '" + student.getMajor().getMajorID() + "','" + ((student.getMinor()!=null)?student.getMinor().getMinorID():"") + "'";
    query += "," +  ((student.getLocation() != null)?Long.toString(student.getLocation().getLocationID()):"");
/*    query += ", '" + ((student.getAdoptDate() != null)? formatter.format(student.getAdoptDate()):"");
    query += "," + ((student.getEntraceSemester() != null)?Long.toString(student.getEntraceSemester().getSemesterID()):"");
    query += ",'" + ((student.getEntraceDate()!= null)?formatter.format(student.getEntraceDate()):"") + "'";
    query += ", " + ((student.getLeaveSemester() != null)?Long.toString(student.getLeaveSemester().getSemesterID()):"");
    query += ",'" + ((student.getLeaveDate() != null)?formatter.format(student.getLeaveDate()):"") + "'";
    query += ",'" + ((student.getProfessor() != null)?student.getProfessor().getProfessorID():"") + "'";
    query += ", " + ((student.getThesis() != null)?Long.toString(student.getThesis().getThesisID()):"");
    query += ",'" + ((student.getBirthday() != null)? formatter.format(student.getBirthday()):"") + "','" + student.getReligion() + "'";
    query += ", '" + student.getRace() + "','" + student.getNationality() + "','" + student.getGender() + "'";
    query += ", " + ((student.getOccupation() != null)?Long.toString(student.getOccupation().getOccupationID()):"");
    query += "," + student.getSalary() + ",'" + student.getOldInstitute() + "'";
    query += ", '" + student.getOldDegree() + "','" + student.getOldGPA() + "'," + student.getOldLeaveYear();
    query += ", '" + student.getRegisterAddess() + "','" + student.getRegisterTel() + "','" + student.getRecentAddress() + "'";
    query += ", '" + student.getRecentTel() + "','" + student.getFatherName() +"'";
    query += "," + ((student.getFatherOccupation() != null)?Long.toString(student.getFatherOccupation().getOccupationID()):"");
    query += ", '" + student.getMotherName() + "'," + ((student.getMotherOccupation()!=null)?Long.toString(student.getMotherOccupation().getOccupationID()):"");
    query += ",'" + student.getCoupleName() + "'";
    query += ", " + ((student.getCoupleOccupation() != null)?Long.toString(student.getCoupleOccupation().getOccupationID()):"") + "," + student.getChildren() + ",'" + student.getParentName() + "'";*/
    query += ", '" + student.getRelation() + "','" + student.getParentAddress()+ "','" + student.getParentTel() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean insertScholarship(Student student,Scholarship scho){
    String query = "INSERT INTO Scholar(StudentID,ScholarshipID) VALUES ('" + student.getStudentID() + "'";
    query += "," + scho.getID() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateStudent(Student student){
    SimpleDateFormat formatter = new SimpleDateFormat("d/M/yyyy");
    String query = "UPDATE Student SET ";
    query += "StudentID = '" + student.getStudentID() + "', ";
    query += "PrenameID = " + student.getPrename().getPrenameID() + ", ";
    query += "StudentEname = '" + student.getStudentEname() + "', ";
    query += "StudentTname = '" + student.getStudentTname() + "', ";
    query += "Password = '" + student.getPassword() + "', ";
    query += "Email = '" + student.getEmail() + "', ";
    query += "Degree = " + student.getDegree() + ", ";
    query += "StudentType = " + student.getStudentType() + ", ";
    query += "StudyGroup = " + student.getStudyGroup() + ", ";
    query += "Status = " + student.getStatus() + ", ";
    query += "RegisterStatus = " + student.getRegisterStatus() + " ";
/*    query += "Approved = " + (student.getApproved()?1:0) + " ,";
    query += "DebtStatus = " + (student.getDebtStatus()?1:0) + ", ";
    query += "LibraryStatus = " + (student.getLibraryStatus()?1:0) + ", ";
    query += "NationalStatus = " + (student.getNationalStatus()?1:0) + ", ";
    query += "PaymentCondition = " + student.getPaymentCondition() + ", ";
    query += "NoSupportTerm = " + student.getNoSupportTerm() + ", ";
    query += "MajorID = '" + student.getMajor().getMajorID() + "', ";
    query += "MinorID = '" + ((student.getMinor()!= null)?student.getMinor().getMinorID():"") + "', ";
    query += "LocationID = " + ((student.getLocation()!=null)?Long.toString(student.getLocation().getLocationID()):"") + ", ";
//    query += "AdoptDate = '" + formatter.format(student.getAdoptDate()) + "', ";
    query += "EntranceSemesterID = " + ((student.getEntraceSemester()!=null)?Long.toString(student.getEntraceSemester().getSemesterID()):"") + ", ";
    query += "EntranceDate = '" + ((student.getEntraceDate()!=null)?formatter.format(student.getEntraceDate()):"") + "', ";
    query += "LeaveSemesterID = " + ((student.getLeaveSemester()!=null)?Long.toString(student.getLeaveSemester().getSemesterID()):"") + ", ";
    query += "LeaveDate = '" + ((student.getLeaveDate()!=null)?formatter.format(student.getLeaveDate()):"") + "', ";
//    query += "ProfessorID = '" + ((student.getProfessor()!=null)?student.getProfessor().getProfessorID():"") + "', ";
//    query += "ThesisID = " + ((student.getThesis()!=null)?Long.toString(student.getThesis().getThesisID()):"") + ", ";
    query += "Birthday = '" + ((student.getBirthday()!=null)? formatter.format(student.getBirthday()):"") + "', ";
    query += "Religion = '" + student.getReligion() + "', ";
    query += "Race = '" + student.getRace() + "', ";
    query += "Nationality = '" + student.getNationality() + "', ";
    query += "Gender = '" + student.getGender() + "', ";
    query += "OccupationID = " + ((student.getOccupation()!=null)?Long.toString(student.getOccupation().getOccupationID()):"0") + ", ";
    query += "Salary = " + student.getSalary() + ", ";
    query += "OldInstitute = '" + student.getOldInstitute() + "', ";
    query += "OldDegree = '" + student.getOldDegree() + "', ";
    query += "OldGpa = " + student.getOldGPA() + ", ";
    query += "OldLeaveYear = " + student.getOldLeaveYear() + ", ";
    query += "RegisterAddress = '" + student.getRegisterAddess() + "', ";
    query += "RegisterTel = '" + student.getRegisterTel() + "', ";
    query += "RecentAddress = '" + student.getRecentAddress() + "', ";
    query += "RecentTel = '" + student.getRecentTel() + "', ";
    query += "FatherName = '" + student.getFatherName() + "', ";
    query += "FatherOccupationID = " + ((student.getFatherOccupation()!=null)?Long.toString(student.getFatherOccupation().getOccupationID()):"") + ", ";
    query += "MotherName = '" + student.getMotherName() + "', ";
    query += "MotherOccupationID = " + ((student.getMotherOccupation()!=null)?Long.toString(student.getMotherOccupation().getOccupationID()):"") + ", ";
    query += "CoupleName = '" + student.getCoupleName() + "', ";
    query += "CoupleOccupationID = " + ((student.getCoupleOccupation()!=null)?Long.toString(student.getCoupleOccupation().getOccupationID()):"") + ", ";
    query += "Children = '" + student.getChildren() + "', ";
    query += "ParentName = '" + student.getParentName() + "', ";
    query += "Relationship = '" + student.getRelation() + "', ";
    query += "ParentAddress = '" + student.getParentAddress() + "', ";
    query += "ParentTel = '" + student.getParentTel() + "' ";*/
    query += "WHERE StudentID = '" + student.getStudentID() + "'";
     if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean updateStudentForWeb(Student student){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Student SET ";
    query += "Email = '" + student.getEmail() + "', ";
    query += "RegisterAddress = '" + student.getRegisterAddess() + "', ";
    query += "RecentAddress = '" + student.getRecentAddress() + "', ";
    query += "RecentTel = '" + student.getRecentTel() + "' ";
    query += "WHERE StudentID = '" + student.getStudentID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteStudent(Student student){
    String query = "DELETE FROM Student WHERE StudentID = '" + student.getStudentID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteScholar(Student student){
    String query = "DELETE FROM Scholar WHERE StudentID = '" + student.getStudentID() + "'";
   if (Database.update(query) != 0) return true;
   return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    StudentDB db = new StudentDB();
    Student s = new Student("001");
    s.setPrename(new Prename(1));
    s.setStudentEname("Test1");
    s.setStudentTname("Test1");
    s.setPassword("123456");
    s.setEmail("dasdfaf");
    s.setDegree(1);
    s.setStudentType(1);
    s.setStatus(1);
    s.setRegisterStatus(1);
    s.setApproved(false);
    s.setDebtStatus(false);
    s.setLibraryStatus(false);
    s.setNationalStatus(false);
    s.setPaymentCondition(1);
    s.setNoSupportTerm(4);
    s.setMajor(new Major("001"));
    s.setMinor(new Minor());
    s.setLocation(new Location(1));
    GregorianCalendar g = new GregorianCalendar(2004,2,1);
    java.util.Date d = g.getTime();
    s.setAdoptDate(d);
    s.setEntraceSemester(new Semester(1));
    s.setEntranceDate(d);
    s.setLeaveSemester(new Semester(1));
    s.setLeaveDate(d);
    s.setProfessor(new Professor("002"));

    s.setThesis(new Thesis(1));

    s.setBirthday(d);
    s.setReligion("Buddhism");
    s.setRace("Thai");
    s.setNationality("Thai");
    s.setGender("male");
    s.setOccupation(new Occupation(1));
    s.setOldInstitute("Ladkrabang");
    s.setOldDegree("Master Degree");
    s.setOldGPA(3.55);
    s.setOldLeaveYear(2547);
    s.setRegisterAddress("88 Toasura soi 3 Muang NM");
    s.setRegisterTel("044-267822");
    s.setRecentAddress("Rimnum Dormitory (Room no. 114) 9 Moo 2 Ladkrabang Bangkok");
    s.setRecentTel("02-7390312-7 extension 114");
    s.setFatherName("Charurat Misila");
    s.setFatherOccupation(new Occupation(1));
    s.setMotherName("Sukanya Misila");
    s.setMotherOccupation(new Occupation(1));
    s.setCoupleName("T");
    s.setCoupleOccupation(new Occupation(1));
    s.setChildren(0);
    s.setParentName("Charurat Misila");
    s.setRelation("Father");
    s.setParentAddress("88 Toasura soi 3 Muang NM");
    s.setParentTel("01-9487885");
//    db.insertStudent(s);
/*    Vector v = s.retrieveStudent(s);
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Student ss = (Student)e.nextElement();
      System.out.println(ss.getStudentID());
      System.out.println(ss.getPrename().getEprename());
      System.out.println(ss.getStudentEname());
      System.out.println(ss.getStudentTname());
      System.out.println(ss.getPassword());
      System.out.println(ss.getEmail());
      System.out.println(ss.getDegree());
      System.out.println(ss.getStudentType());
      System.out.println(ss.getStudyGroup());
      System.out.println(ss.getStatus());
      System.out.println(ss.getRegisterStatus());
      System.out.println(ss.getApproved());
      System.out.println(ss.getDebtStatus());
      System.out.println(ss.getLibraryStatus());
      System.out.println(ss.getNationalStatus());
      System.out.println(ss.getPaymentCondition());
      System.out.println(ss.getNoSupportTerm());
      System.out.println(ss.getMajor().getEname());
      System.out.println(ss.getMinor().getEname());
      System.out.println(ss.getLocation().getLocationName());
      System.out.println(ss.getAdoptDate());
      System.out.println(ss.getEntraceSemester().getSemesterID());
      System.out.println(ss.getEntraceDate());
      System.out.println(ss.getLeaveSemester().getSemesterID());
      System.out.println(ss.getProfessor().getEprofessorName());
      System.out.println("Thesis : " + ss.getThesis().getThesisEname());
      System.out.println(ss.getBirthday());
      System.out.println(ss.getReligion());
      System.out.println(ss.getRace());
      System.out.println(ss.getNationality());
      System.out.println(ss.getGender());
      System.out.println(ss.getOccupation().getOccupationName());
      System.out.println(ss.getSalary());
      System.out.println(ss.getOldInstitute());
      System.out.println(ss.getOldDegree());
      System.out.println(ss.getOldGPA());
      System.out.println(ss.getOldLeaveYear());
      System.out.println(ss.getRegisterAddess());
      System.out.println(ss.getRegisterTel());
      System.out.println(ss.getRecentAddress());
      System.out.println(ss.getRecentTel());
      System.out.println(ss.getFatherName());
      System.out.println(ss.getFatherOccupation().getOccupationName());
      System.out.println(ss.getMotherName());
      System.out.println(ss.getMotherOccupation().getOccupationName());
      System.out.println(ss.getCoupleName());
      System.out.println(ss.getCoupleOccupation().getOccupationName());
      System.out.println(ss.getChildren());
      System.out.println(ss.getParentName());
      System.out.println(ss.getRelation());
      System.out.println(ss.getParentAddress());
      System.out.println(ss.getParentTel());
    }*/

    Database.disconnect();
  }

}