package graduate;

import java.util.*;
public class Department {
  private String departmentID;
  private String ename;
  private String tname;
  private Faculty faculty;
  private DepartmentDB depDB = new DepartmentDB();
  private Vector majorVector = new Vector();
  //Constructor
  public Department() {
  }
  public Department(String depid){
    this.setDepartmentID(depid);
  }
  public Department(String depid,String depname){
    this.setDepartmentID(depid);
    this.setTname(depname);
  }
  //getMethod
  public String getDepartmentID(){
    return this.departmentID;
  }
  public String getEname(){
    return this.ename;
  }
  public String getTname(){
    return this.tname;
  }
  public Faculty getFaculty(){
    return this.faculty;
  }
  //setMethod
  public void setDepartmentID(String departmentID){
    this.departmentID = departmentID;
  }
  public void setEname(String ename){
    this.ename = ename;
  }
  public void setTname(String tname){
    this.tname = tname;
  }
  public void setFaculty(Faculty faculty){
    this.faculty = faculty;
  }
  //Business Method
  public void addMajor(Major major){
    majorVector.addElement(major);
  }
  public void setMajor(Vector major){
    majorVector = major;
  }
  public Enumeration retrieveMajor(){
    return majorVector.elements();
  }
  public Major retrieveMajor(String mid){
    Enumeration e = retrieveMajor();
    if (!e.hasMoreElements()) return null;
    return (Major)e.nextElement();
  }
  //Access Method
  public Vector retrieveDepartmentAll(Faculty fac){
    Vector v = depDB.retrieveDepartmentAll(fac);
    fac.setDepartment(v);
    return v;
  }
  public Vector retrieveDepartment(Faculty fac){
    Vector v = depDB.retrieveDepartment(fac);
    fac.setDepartment(v);
    return v;
  }
  public boolean insertDepartment(Department dep){
    return depDB.insertDepartment(dep);
  }
  public boolean updateDepartment(Department oldDep,Department dep){
    return depDB.updateDepartment(oldDep,dep);
  }
  public boolean deleteDepartment(Department dep){
    return depDB.deleteDepartment(dep);
  }
  public String toString(){
    return "�Ҥ�Ԫ�" + this.getTname();
  }
}