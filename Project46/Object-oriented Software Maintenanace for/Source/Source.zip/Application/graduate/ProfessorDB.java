package graduate;

import java.sql.*;
import java.util.*;
public class ProfessorDB {
  public ProfessorDB() {
  }
  public Vector retrieveProfessor(Department department){
    Vector v = new Vector();
    try
    {
        String query = "SELECT t.*,p.* FROM Professor t,Prename p WHERE t.PrenameID = p.PrenameID AND ";
        query += "t.DepartmentID = '" + department.getDepartmentID() + "' ORDER BY TprofessorName";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Professor prof = new Professor();
          prof.setProfessorID(rs.getString("ProfessorID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          prof.setPrename(p);
          prof.setEprofessorName(rs.getString("EprofessorName"));
          prof.setTprofessorName(rs.getString("TProfessorName"));
          prof.setPassword(rs.getString("Password"));
          prof.setPosition(rs.getString("Position"));
          prof.setDepartment(department);
          v.addElement(prof);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Professor retrieveProfessor(String profid){
    Professor prof = new Professor();
    try {
      String query =
          "SELECT t.*,p.* FROM Professor t,Prename p WHERE t.PrenameID = p.PrenameID AND ";
      query += "t.ProfessorID = '" + profid +"' ORDER BY TprofessorName";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        prof.setProfessorID(rs.getString("ProfessorID"));
        Prename p = new Prename(rs.getInt("PrenameID"), rs.getString("EPrename"),
                                rs.getString("TPrename"));
        prof.setPrename(p);
        prof.setEprofessorName(rs.getString("EprofessorName"));
        prof.setTprofessorName(rs.getString("TProfessorName"));
        prof.setPassword(rs.getString("Password"));
        prof.setPosition(rs.getString("Position"));
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return prof;
  }
  public boolean insertProfessor(Professor professor) {
    String query = "INSERT INTO Professor(ProfessorID,PrenameID,EProfessorName,TProfessorName,Password,Position,DepartmentID) ";
    query += "VALUES('"+ professor.getProfessorID() + "' , " + professor.getPrename().getPrenameID() + " , '" + professor.getEprofessorName() + "'";
    query += ", '" + professor.getTprofessorName() + "','" + professor.getPassword() + "','" + professor.getPosition() + "','" + professor.getDepartment().getDepartmentID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateProfessor(Professor oldprofessor,Professor professor){
    String query = "UPDATE Professor SET ";
    query +=  "ProfessorID = '" + professor.getProfessorID() + "', ";
    query +=  "PrenameID = " + professor.getPrename().getPrenameID() + ", ";
    query +=  "EProfessorName = '" + professor.getEprofessorName() + "', ";
    query +=  "TProfessorName = '" + professor.getTprofessorName() + "', ";
    query +=  "Password = '" + professor.getPassword() + "',";
    query +=  "Position = '" + professor.getPosition() + "', ";
    query +=  "DepartmentID = '" + professor.getDepartment().getDepartmentID() + "' ";
    query +=  "WHERE ProfessorID = '" + oldprofessor.getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteProfessor(Professor professor){
    String query = "DELETE FROM Professor WHERE ProfessorID = '" + professor.getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ProfessorDB db = new ProfessorDB();
    Professor p = new Professor("003");
    p.setPrename(new Prename(1));
    p.setEprofessorName("TTTTTTT");
    p.setTprofessorName("AAAAAAA");
    p.setPassword("123456");
    p.setPosition("Dean");
    p.setDepartment(new Department("001"));
//    p.updateProfessor(p);
    Vector v = db.retrieveProfessor(new Department("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Professor prof = (Professor)e.nextElement();
      System.out.println(prof.getProfessorID() + " " + prof.getPrename().getEprename() + " " + prof.getEprofessorName());
      System.out.println(prof.getTprofessorName() + " " + prof.getPosition() + " " + prof.getPassword() + " " + prof.getDepartment().getDepartmentID());
    }
    Database.disconnect();
  }
}