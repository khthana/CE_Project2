package graduate;

import java.util.*;
public class Registrar {
  private String registrarID;
  private Prename prename;
  private String ename;
  private String tname;
  private String position;
  private String password;
  private int permission;
  private RegistrarDB registrarDB = new RegistrarDB();
  //Constructor
  public Registrar() {
  }
  public Registrar(String id){
    this.setRegistrarID(id);
  }
  //getMethod
  public String getRegistrarID(){
    return this.registrarID;
  }
  public Prename getPrename(){
    return this.prename;
  }
  public String getEname(){
    return this.ename;
  }
  public String getTname(){
    return this.tname;
  }
  public String getPosition(){
    return this.position;
  }
  public String getPassword(){
    return this.password;
  }
  public int getPermission(){
    return this.permission;
  }
  //setMethod
  public void setRegistrarID(String registrarID){
    this.registrarID = registrarID;
  }
  public void setPrename(Prename prename){
    this.prename = prename;
  }
  public void setEname(String ename){
    this.ename = ename;
  }
  public void setTname(String tname){
    this.tname = tname;
  }
  public void setPosition(String position){
    this.position = position;
  }
  public void setPassword(String password){
    this.password  = password;
  }
  public void setPermission(int permission){
    this.permission = permission;
  }
  public Vector retrieveRegistrarAll(){
    return registrarDB.retrieveRegistrarAll();
  }
  public Vector retrieveRegistrar(){
    return registrarDB.retrieveRegistrar();
  }
  public boolean validate(Registrar person){
   return registrarDB.validate(person);
  }
  public boolean insertRegistrar(Registrar registrar) {
    return registrarDB.insertRegistrar(registrar);
  }
  public boolean updateRegistrar(Registrar oldregistrar,Registrar registrar){
    return registrarDB.updateRegistrar(oldregistrar,registrar);
  }
  public boolean deleteRegistrar(Registrar registrar){
    return registrarDB.deleteRegistrar(registrar);
  }
  public String toString(){
    return this.getPrename().getTPrename() + " " + this.getTname();
  }
}