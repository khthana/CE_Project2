package graduate;

import java.sql.*;
import java.util.*;
public class OccupationDB {
  public OccupationDB() {
  }
  public Vector retrieveOccupation(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Occupation ORDER BY OccupationName";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Occupation occupation = new Occupation();
          occupation.setOccupationID(rs.getInt("OccupationID"));
          occupation.setOccupationName(rs.getString("OccupationName"));
          v.addElement(occupation);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Occupation retrieveOccupation(long oid){
    Occupation o = new Occupation();
    try
    {
        String query = "SELECT * FROM Occupation WHERE OccupationID = " + oid;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          o.setOccupationID(rs.getLong("OccupationID"));
          o.setOccupationName(rs.getString("OccupationName"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return o;
  }
  public boolean insertOccupation(Occupation occupation){
    String query = "INSERT INTO Occupation(OccupationName) ";
    query += "VALUES('" + occupation.getOccupationName() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateOccupation(Occupation occupation){
    String query = "UPDATE Occupation SET ";
    query += "OccupationName = '" + occupation.getOccupationName() + "' ";
    query += "WHERE OccupationID = " + occupation.getOccupationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteOccupation(Occupation occupation){
    String query = "DELETE FROM Occupation WHERE OccupationID = " + occupation.getOccupationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    OccupationDB gdb = new OccupationDB();
    Occupation g = new Occupation(2,"�ԪҺѧ�Ѻ");
    gdb.updateOccupation(g);
    Vector v = gdb.retrieveOccupation();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Occupation m1 = (Occupation)e.nextElement();
      System.out.println(m1.getOccupationID() + " " + m1.getOccupationName());
    }
    Database.disconnect();
  }

}