package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SupportUI extends JDialog {
  CompoundBorder titledBorder2;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel5 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JPanel jPanel6 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  TitledBorder titledBorder1;
  JPanel jPanel3 = new JPanel();
  TitledBorder titledBorder5;
  JPanel jPanel4 = new JPanel();
  TitledBorder titledBorder6;
  JPanel jPanel7 = new JPanel();
  TitledBorder titledBorder7;
  JRadioButton studyRadio1 = new JRadioButton();
  JRadioButton studyRadio3 = new JRadioButton();
  JRadioButton studyRadio2 = new JRadioButton();
  JRadioButton studyRadio4 = new JRadioButton();
  JRadioButton studyRadio5 = new JRadioButton();
  JRadioButton typeRadio1 = new JRadioButton();
  JRadioButton typeRadio2 = new JRadioButton();
  JRadioButton courseRadio1 = new JRadioButton();
  JRadioButton courseRadio2 = new JRadioButton();
  JLabel jLabel1 = new JLabel();
  JTextField moneyText = new JTextField();
  JLabel jLabel2 = new JLabel();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  Border border1;
  Border border2;
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("�Թ�ش˹ع����֡��/�Թ��������֡��");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  //---------------------------------------------------------------------------------------------------------------------------------------------------
  Faculty facultyInit = new Faculty();
  Department departmentInit = new Department();
  Major majorInit = new Major();
  Major currentMajor = null;
  Support currentSupport = null;
  Support support = new Support();
  boolean newRecord = false;
  boolean canAdd = false;
  ButtonGroup buttonGroup1 = new ButtonGroup();
  ButtonGroup buttonGroup2 = new ButtonGroup();
  ButtonGroup buttonGroup3 = new ButtonGroup();

  public SupportUI(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SupportUI() {
    this(null, "", false);
  }
  void jbInit() throws Exception {
    titledBorder5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�����������������¹");
    titledBorder6 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�������ѡ�֡��");
    titledBorder7 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"��ѡ�ٵ�");
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder7.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder1 = new TitledBorder(null, "��������´�ԹʹѺʹع����֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder1,new EmptyBorder(5,5,5,5));

    this.getContentPane().setLayout(borderLayout1);
    jPanel5.setLayout(borderLayout2);
    jSplitPane1.setBorder(null);
    jSplitPane1.setDebugGraphicsOptions(0);
    jPanel1.setLayout(borderLayout3);
    jPanel2.setLayout(null);
    jButton2.setText("����");
    jButton2.addActionListener(new SupportUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton3.setText("ź");
    jButton3.addActionListener(new SupportUI_jButton3_actionAdapter(this));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setAlignmentX((float) 10.0);
    jPanel2.setAlignmentY((float) 10.0);
    jPanel2.setBorder(titledBorder2);
    jPanel2.setDebugGraphicsOptions(0);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder5);
    jPanel3.setDebugGraphicsOptions(0);
    jPanel3.setBounds(new Rectangle(39, 48, 243, 222));
    jPanel3.setLayout(null);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setBorder(titledBorder6);
    jPanel4.setBounds(new Rectangle(293, 48, 207, 108));
    jPanel4.setLayout(null);
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setBorder(titledBorder7);
    jPanel7.setBounds(new Rectangle(296, 162, 205, 108));
    jPanel7.setLayout(null);
    studyRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRadio1.setToolTipText("");
    studyRadio1.setSelected(true);
    studyRadio1.setText("�Ҥ����");
    studyRadio1.setBounds(new Rectangle(45, 29, 91, 23));
    studyRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRadio3.setText("�Ҥ����� (�����-�ҷԵ��)");
    studyRadio3.setBounds(new Rectangle(45, 99, 162, 23));
    studyRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRadio2.setText("�Ҥ����");
    studyRadio2.setBounds(new Rectangle(45, 63, 91, 23));
    studyRadio4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRadio4.setText("�Ҥ����ɹ͡�����Ҫ���");
    studyRadio4.setBounds(new Rectangle(45, 135, 182, 23));
    studyRadio5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRadio5.setText("��ѡ�ٵùҹҪҵ�");
    studyRadio5.setBounds(new Rectangle(45, 172, 155, 23));
    typeRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    typeRadio1.setSelected(true);
    typeRadio1.setText("���ѭ");
    typeRadio1.setBounds(new Rectangle(36, 30, 91, 23));
    typeRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    typeRadio2.setText("���ͧ���¹");
    typeRadio2.setBounds(new Rectangle(36, 69, 91, 23));
    courseRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    courseRadio1.setSelected(true);
    courseRadio1.setText("�ѡ�֡����");
    courseRadio1.setBounds(new Rectangle(32, 29, 121, 23));
    courseRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    courseRadio2.setText("�ѡ�֡�ҵ�ҧ�����");
    courseRadio2.setBounds(new Rectangle(32, 66, 143, 23));
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("�ӹǹ�Թ����ͧ����");
    jLabel1.setBounds(new Rectangle(99, 310, 131, 15));
    moneyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    moneyText.setText("");
    moneyText.setBounds(new Rectangle(236, 303, 140, 28));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("�ҷ");
    jLabel2.setBounds(new Rectangle(403, 310, 34, 15));
    jButton4.setText("������");
    jButton4.addActionListener(new SupportUI_jButton4_actionAdapter(this));
    jButton4.setPreferredSize(new Dimension(80, 25));
    jButton4.setMaximumSize(new Dimension(100, 25));
    jButton4.setBounds(new Rectangle(291, 424, 80, 25));
    jButton4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton5.setText("�ѹ�֡");
    jButton5.addActionListener(new SupportUI_jButton5_actionAdapter(this));
    jButton5.setPreferredSize(new Dimension(80, 25));
    jButton5.setMaximumSize(new Dimension(100, 25));
    jButton5.setBounds(new Rectangle(206, 424, 80, 25));
    jButton5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setBorder(border1);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(border2);
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.add(jButton2, null);
    jPanel6.add(jButton3, null);
    jPanel1.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jSplitPane1.add(jPanel2, JSplitPane.RIGHT);
    jPanel3.add(studyRadio4, null);
    jPanel3.add(studyRadio5, null);
    jPanel3.add(studyRadio3, null);
    jPanel3.add(studyRadio2, null);
    jPanel3.add(studyRadio1, null);
    jPanel2.add(moneyText, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(jButton5, null);
    jPanel2.add(jButton4, null);
    jPanel2.add(jPanel4, null);
    jPanel4.add(typeRadio1, null);
    jPanel4.add(typeRadio2, null);
    jPanel2.add(jPanel7, null);
    jPanel7.add(courseRadio2, null);
    jPanel7.add(courseRadio1, null);
    jPanel2.add(jPanel3, null);
    jPanel1.add(jPanel6, BorderLayout.SOUTH);
    jSplitPane1.add(jPanel1, JSplitPane.LEFT);
    this.getContentPane().add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(jSplitPane1, BorderLayout.CENTER);
    this.setSize(new Dimension(750, 550));
    createTree();
    buttonGroup1.add(studyRadio1);
    buttonGroup1.add(studyRadio2);
    buttonGroup1.add(studyRadio3);
    buttonGroup1.add(studyRadio4);
    buttonGroup1.add(studyRadio5);
    buttonGroup2.add(typeRadio1);
    buttonGroup2.add(typeRadio2);
    buttonGroup3.add(courseRadio1);
    buttonGroup3.add(courseRadio2);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof Faculty || nodeInfo instanceof Department) return;
      if (nodeInfo instanceof Major){
        currentMajor = (Major)nodeInfo;
        canAdd = true;
      }
      if (nodeInfo instanceof Support){
        canAdd = false;
        DefaultMutableTreeNode majorNode = (DefaultMutableTreeNode)node1.getParent();
        currentMajor = (Major)majorNode.getUserObject();
        currentSupport = (Support)nodeInfo;
        showUI();
      }
    }
  }

  public void showUI(){
    switch (currentSupport.getStudyGroup())
    {
      case 1: studyRadio1.setSelected(true); break;
      case 2: studyRadio2.setSelected(true); break;
      case 3: studyRadio3.setSelected(true); break;
      case 4: studyRadio4.setSelected(true); break;
      case 5: studyRadio5.setSelected(true); break;
      default : break;
    }
    switch (currentSupport.getStudentType())
    {
      case 1: typeRadio1.setSelected(true); break;
      case 2: typeRadio2.setSelected(true); break;
    }
    if (currentSupport.getNationalStatus()) courseRadio2.setSelected(true);
    else courseRadio1.setSelected(true);

    moneyText.setText(Double.toString(currentSupport.getMoney()));
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode facultyNode = null;
    DefaultMutableTreeNode departmentNode = null;
    DefaultMutableTreeNode majorNode = null;
    DefaultMutableTreeNode supNode = null;

    Vector facultyVector = facultyInit.retrieveFacultyAll();
    Enumeration facultyEnum = facultyVector.elements();
    while (facultyEnum.hasMoreElements()){
      Faculty fac = (Faculty)facultyEnum.nextElement();
      facultyNode = new DefaultMutableTreeNode(fac);
      root.add(facultyNode);

      Vector departmentVector = departmentInit.retrieveDepartmentAll(fac);
      Enumeration departmentEnum = departmentVector.elements();
      while (departmentEnum.hasMoreElements()){
        Department dep = (Department)departmentEnum.nextElement();
        departmentNode = new DefaultMutableTreeNode(dep);
        facultyNode.add(departmentNode);

        Vector majorVector = majorInit.retrieveMajor(dep);
        Enumeration majorEnum = majorVector.elements();
        while (majorEnum.hasMoreElements()){
          Major maj = (Major)majorEnum.nextElement();
          majorNode = new DefaultMutableTreeNode(maj);
          departmentNode.add(majorNode);

          Vector supportVector = support.retrieveSupportAll(maj);
          Enumeration supportEnum = supportVector.elements();
          while (supportEnum.hasMoreElements()){
            Support sup = (Support)supportEnum.nextElement();
            supNode = new DefaultMutableTreeNode(sup);
            majorNode.add(supNode);
          }
        }
      }
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }
  public void updateNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    lastItem.setUserObject(obj);
    jTree1.repaint();
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }

  public void clear(){
    studyRadio1.setSelected(true);
    typeRadio1.setSelected(true);
    courseRadio1.setSelected(true);
    moneyText.setText("");
  }

  void jButton4_actionPerformed(ActionEvent e) {
    clear();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    newRecord = true;
    clear();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Support) {
          Support del = (Support)obj;
          Database.connect();
          complete = del.deleteSupport(del);
          Database.disconnect();
        }
        if (complete) treeModel.removeNodeFromParent(node);
      }
    }
  }

  void jButton5_actionPerformed(ActionEvent e) {
    boolean complete = false;
    int study=0;
    double money;
    Support support = new Support();
    support.setMajor(currentMajor);
    if (studyRadio1.isSelected()) study = 1;
    else if (studyRadio2.isSelected()) study = 2;
    else if (studyRadio3.isSelected()) study = 3;
    else if (studyRadio4.isSelected()) study = 4;
    else if (studyRadio5.isSelected()) study = 5;
    support.setStudyGroup(study);

    if (typeRadio1.isSelected()) support.setStudentType(1);
    else support.setStudentType(2);

    if (courseRadio1.isSelected()) support.setNationalStatus(false);
    else support.setNationalStatus(true);
    support.setNumterm(4);
    support.setLocation(new Location(1));
    try{
      money = Double.parseDouble(moneyText.getText());
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ա���֡���繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    support.setMoney(money);
    Database.connect();
    if (newRecord){
    complete = support.insertSupport(support);
    if (complete) addNode(support);
  }
  else {
    if (currentSupport == null) {
      JOptionPane.showMessageDialog(this,"��سҷӡ��������͹�ӡ�����","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    support.setSupportID(currentSupport.getSupportID());
    complete = support.updateSupport(support);
    updateNode(support);
  }
  Database.disconnect();
  }
}
class SupportUI_jButton4_actionAdapter implements java.awt.event.ActionListener {
  SupportUI adaptee;

  SupportUI_jButton4_actionAdapter(SupportUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class SupportUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  SupportUI adaptee;

  SupportUI_jButton2_actionAdapter(SupportUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class SupportUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  SupportUI adaptee;

  SupportUI_jButton3_actionAdapter(SupportUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class SupportUI_jButton5_actionAdapter implements java.awt.event.ActionListener {
  SupportUI adaptee;

  SupportUI_jButton5_actionAdapter(SupportUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton5_actionPerformed(e);
  }
}

